CharacterAnimations = {
	ExploreFail = "exp_fail",
	ExploreDisappear = "exp_disappear",
	ExploreWin = "exp_win",
	Idle = "exp_talk",
	Walk = "exp_walk_win",
	Sitting = "sitting_idle",
	Hit = "Hit",
	Dodge = "Dodge",
}

PlanetAnimations = {
	Appear = "Appear",
	Disappear = "Disappear",
	Idle = "Idle",
	IdleExplore = "IdleExplore",
}

WorkShopNPCAnimations = {
	enter = "enter",
	exit = "exit",
	exit_box = "exit_box",
	stand_1 = "stand_1",
	stand_2 = "stand_2",
	stand_3 = "stand_3",
	stand_4 = "stand_4",
	walk_1 = "walk_1",
	walk_2 = "walk_2",
	walk_3 = "walk_3",
	walk_4 = "walk_4",
	walk_box_1 = "walk_box_1",
	walk_box_2 = "walk_box_2",
	walk_box_3 = "walk_box_3",
	walk_box_4 = "walk_box_4",
}

BattleInterval = 0.5