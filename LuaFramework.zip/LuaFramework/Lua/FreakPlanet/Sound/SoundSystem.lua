SoundSystem = {}

SoundNames = {
	Music1 = "BGM_Main_Menu",
	Music2 = "BGM_Main_Menu3",
	Music3 = "Music_SEA",
	ArenaMusic = "BGM_ExileStreet",
	AccountMusic = "BGM_Account",
	BattleMusic = "BGM_Combat",
	UIClick = "SE_Confirm",
	UICancel = "SE_Cancel",
	Warning = "SE_Fail",
	Summon = "SE_Lottery1",
	SummonNormal = "SE_Lottery2",
	SummonSSR = "SE_Lottery3",
	Reward = "SE_Reward",
	RewardSpecial = "SE_Reward_SP",
	Money = "SE_Money",
	CharacterLevelUp = "SE_Levelup",
	CharacterLevelUpMax = "SE_Levelup",
	CharacterStageUp = "SE_Levelup_starup",
	Craft = "SE_Lab_Creating",
	MapNewNode = "SE_Map_NewBuilding",
	WorkshopNewItem = "SE_Work_NewItem",
	WorkshopOvertime = "SE_Work_Overtime",
	--DemandCancel = "SE_Demand_Renew",

	ExploreResultEvent = "SE_Explore_Event",
	ExploreResultPetSpecial = "SE_Explore_Pet1",
	ExploreResultPetNormal = "SE_Explore_Pet2",
	ExploreResultNoPet = "SE_Explore_Pet3",

	BattleLose = "BGM_Combat_Lose",
	BattleWin = "BGM_Combat_Win",
	SwitchPage = "SE_SwitchPage",
	SwitchPlanet = "SE_SwitchPlanet",

	BattleEnter = "SE_Combat_Walk_In",
	BattleLevelSkillEffect = "SE_Combat_SP_LvDown",
	BattleHealSkillEffect = "SE_Combat_Heal",
	BattleCommonSkillEffect = "SE_Combat_SkillGeneral",
	BattleDodge = "SE_Combat_Dodge",
	BattleElementSwitch = "SE_Combat_SP_ChangeProp",
	BattleDead = "SE_Combat_Fall",

	HitSoundWind = "SE_Combat_Hit1",
	HitSoundFire = "SE_Combat_Hit2",
	HitSoundWater = "SE_Combat_Hit3",
	HitSoundLight = "SE_Combat_Hit4",
	HitSoundDard = "SE_Combat_Hit5",

	AttackSoundMeleeWind = "SE_Combat_Melee1",
	AttackSoundMeleeFire = "SE_Combat_Melee2",
	AttackSoundMeleeWater = "SE_Combat_Melee3",
	AttackSoundMeleeLight = "SE_Combat_Melee4",
	AttackSoundMeleeDark = "SE_Combat_Melee5",

	AttackSoundRangeWind = "SE_Combat_Range1",
	AttackSoundRangeFire = "SE_Combat_Range2",
	AttackSoundRangeWater = "SE_Combat_Range3",
	AttackSoundRangeLight = "SE_Combat_Range4",
	AttackSoundRangeDark = "SE_Combat_Range5",

	TouristStart = "SE_Zoo_StartShow",
	TouristRank1 = "SE_Zoo_ShowResult1",
	TouristRank2 = "SE_Zoo_ShowResult2",
	TouristRank3 = "SE_Zoo_ShowResult3",
	TouristRank4 = "SE_Zoo_ShowResult4",
	TouristRank5 = "SE_Zoo_ShowResult5",

	ComicGuGuSound = "SE_gugu",
	ComicWuWuSound = "SE_wuwu",
	ComicZongGuanSound = "SE_zongguan",
	ComicCrash = "SE_crash",
	ComicWarning = "SE_warning",

	--
	BGM_CatchFish = "BGM_CatchFish",
	SE_CatchFish_DoCatch = "SE_CatchFish_DoCatch",

	--
	BGM_2021MidAutumn = "BGM_2021MidAutumn",

	BGM_Halloween = "BGM_Halloween",
}

local this = SoundSystem

local _loadedClips = {}
local _audioSource -- 1st one for music, 2nd for sound

local _curMusic = nil
local _isPlayBGM = false
local _isFading = false
--淡出效果时长
local FadeTime = 1

-- init sound system
function SoundSystem.Init()
	_curMusic = nil
	local soundPrefab = resMgr:LoadAsset("SoundObject")
	local soundObject = Helper.NewObject(soundPrefab)
	-- set name
	soundObject.name = "SoundSystem"
	_audioSource = soundObject:GetComponent('AudioSource')

	--音效
	resMgr:LoadBundle("sound_se")

	_loadedClips = {}
end

function SoundSystem.GetOrCreateSoundClip(strClipName)
	if not strClipName or strClipName == "" then
		return nil
	end
	if not _loadedClips[strClipName] then
		_loadedClips[strClipName] = resMgr:LoadSound(strClipName)
	end
	return _loadedClips[strClipName]
end

function SoundSystem.IsMusicOn()
	return GameData.IsMusicOn()
end

function SoundSystem.IsSoundOn()
	return GameData.IsSoundOn()
end

-- play music
function SoundSystem.PlayAccountMusic()
	if not this.IsMusicOn() then
		return
	end

	if _audioSource.isPlaying then
		_audioSource:Stop()
	end

	local clip = this.GetOrCreateSoundClip(SoundNames.AccountMusic)
	_audioSource.clip = clip
	_audioSource.loop = true
	_audioSource:Play()
end

function SoundSystem.PlayMusic()
	if not this.IsMusicOn() then
		return
	end

	if _audioSource.isPlaying then
		_audioSource:Stop()
	end
	this.PlayBgmOnStart()
end

function SoundSystem.PlayBgmOnStart()
	if not this.IsMusicOn() then
		return
	end
	_curMusic = _curMusic or GameData.GetRecordBGM()
	local clip = this.GetOrCreateSoundClip(_curMusic)
	_audioSource.clip = clip
	_audioSource:Play()
	GameNotifier.Notify(GameEvent.BGMChanged,_curMusic)
	_audioSource.loop = GameData.GetBGMType() == 1
	_isPlayBGM = true
end

function SoundSystem.SwitchBGM()
	if not this.IsMusicOn() then
		return
	end
	_curMusic = GameData.GetRecordBGM()
	_isFading = true
end

function SoundSystem.GetCurPlayBGM()
	return _curMusic
end

local _time = 0
local _volume = 1

function SoundSystem.Update(deltaTime)
	if not GameData.IsMusicOn() then
		return
	end
	if not _isPlayBGM then
		return
	end
	if GameData.GetBGMType() ~= 1 then
		if not _audioSource.isPlaying then
			local _nextMusic = ConfigUtils.GetNextBgm(_curMusic, GameData.GetBGMType() == 2, true)
			_curMusic = _nextMusic
			local clip = this.GetOrCreateSoundClip(_nextMusic)
			assert(clip ~= nil, "invalid clip")
			_audioSource.clip = clip
			_audioSource.loop = false
			_audioSource:Play()
			GameNotifier.Notify(GameEvent.BGMChanged, _curMusic)
		end
	end
	--	当前歌曲淡出
	if _isFading then
		_time = _time + deltaTime
		_volume = 1 - _time * (1 / FadeTime)
		_audioSource.volume = _volume

		if _volume < 0 then
			_isFading = false
			local clip = this.GetOrCreateSoundClip(_curMusic)
			_audioSource.clip = clip
			_audioSource:Play()
			_audioSource.volume = 1
			_time = 0
			GameNotifier.Notify(GameEvent.BGMChanged, _curMusic)
			_audioSource.loop = GameData.GetBGMType() == 1
			_isPlayBGM = true
		end
	end
end

function SoundSystem.SetBgmLoop(isOn)
	_audioSource.loop = isOn
end

function SoundSystem.PlayBattleMusic()
	if not this.IsMusicOn() then
		return
	end

	if _audioSource.isPlaying then
		_audioSource:Stop()
	end

	local clip = this.GetOrCreateSoundClip(SoundNames.BattleMusic)
	_audioSource.clip = clip
	_audioSource.loop = true
	_audioSource:Play()
end

function SoundSystem.PlayArenaMusic()
	if not this.IsMusicOn() then
		return
	end

	if _audioSource.isPlaying then
		_audioSource:Stop()
	end

	local clip = this.GetOrCreateSoundClip(SoundNames.ArenaMusic)
	_audioSource.clip = clip
	_audioSource.loop = true
	_audioSource:Play()
end

-- stop music
function SoundSystem.StopMusic()
	if _audioSource.isPlaying then
		_audioSource:Stop()
	end
end

-- play ui click sound
function SoundSystem.PlayUIClickSound()
	if not this.IsSoundOn() then
		return
	end

	local clip = this.GetOrCreateSoundClip(SoundNames.UIClick)
	_audioSource:PlayOneShot(clip)
end

-- play ui cancel sound
function SoundSystem.PlayUICancelSound()
	if not this.IsSoundOn() then
		return
	end

	local clip = this.GetOrCreateSoundClip(SoundNames.UICancel)
	_audioSource:PlayOneShot(clip)
end

-- play warning sound
function SoundSystem.PlayWarningSound()
	if not this.IsSoundOn() then
		return
	end

	local clip = this.GetOrCreateSoundClip(SoundNames.Warning)
	_audioSource:PlayOneShot(clip)
end

-- play summon sound
function SoundSystem.PlaySummonSound()
	if not this.IsSoundOn() then
		return
	end

	local clip = this.GetOrCreateSoundClip(SoundNames.Summon)
	_audioSource:PlayOneShot(clip)
end

-- play character upgrade sound
function SoundSystem.PlayCharacterUpgradeSound()
	this.PlaySoundOfName(SoundNames.CharacterLevelUp)
end

function SoundSystem.PlayCharacterUpgradeMaxSound()
	this.PlaySoundOfName(SoundNames.CharacterLevelUpMax)
end

function SoundSystem.PlayCharacterUpStageSound()
	this.PlaySoundOfName(SoundNames.CharacterStageUp)
end

-- play general reward sound
function SoundSystem.PlayRewardSound()
	if not this.IsSoundOn() then
		return
	end

	local clip = this.GetOrCreateSoundClip(SoundNames.Reward)
	_audioSource:PlayOneShot(clip)
end

-- play special reward sound
function SoundSystem.PlayRewardSpecialSound()
	if not this.IsSoundOn() then
		return
	end

	local clip = this.GetOrCreateSoundClip(SoundNames.RewardSpecial)
	_audioSource:PlayOneShot(clip)
end

-- play money sound
function SoundSystem.PlayMoneySound()
	if not this.IsSoundOn() then
		return
	end

	local clip = this.GetOrCreateSoundClip(SoundNames.Money)
	_audioSource:PlayOneShot(clip)
end

-- tab switch sound
function SoundSystem.PlaySwitchSound()
	if not this.IsSoundOn() then
		return
	end

	local clip = this.GetOrCreateSoundClip(SoundNames.SwitchPage)
	_audioSource:PlayOneShot(clip)
end

-- play sound with a name
function SoundSystem.PlaySoundOfName(name, volumeScale)
	if not this.IsSoundOn() then
		return
	end

	local clip = this.GetOrCreateSoundClip(name)
	if clip == nil then
		return
	end

	volumeScale = volumeScale or 1
	_audioSource:PlayOneShot(clip, volumeScale)
end

--
function SoundSystem.PlayMusicByName(name)
	if not this.IsMusicOn() then
		return
	end

	if _audioSource.isPlaying then
		_audioSource:Stop()
	end

	local clip = this.GetOrCreateSoundClip(name)
	_audioSource.clip = clip
	_audioSource.loop = true
	_audioSource:Play()
end

--
function SoundSystem.IsExistSoundClip(name)
	return _loadedClips[name] ~= nil
end