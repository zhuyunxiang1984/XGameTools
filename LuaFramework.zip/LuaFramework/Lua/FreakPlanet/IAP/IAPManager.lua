IAPManager = {}

local json = require "cjson"

local this = IAPManager

local CHECK_ORDER_DELTA = 5
local MAX_CHECK_NUM = 15

local _initialized = false
local _processingIaps = nil

local _storeToProductMap = nil
local _sendedProductId = nil

local _isWaitingSdk = false
local _waitingSdkCooldownHandle = nil

-- 买量需要传递的参数
local _paymentType = nil

-- 礼包：一旦收到sdk成功的结果，就标记为已购买，即使未收到服务器的结果；防止重复购买
local _completedIapMap = nil

function IAPManager.Init()
	_isWaitingSdk = false
	_waitingSdkCooldownHandle = nil
	_completedIapMap = {}
	_initialized = true
	_processingIaps = GameData.ConstructPrcoessIapList(MAX_CHECK_NUM)
	_storeToProductMap = ConfigUtils.GetIapStoreToProductMap()
	-- install store kit and restore it
	ScriptBridge.InitStore()
	this.RestoreStore(false)
end

function IAPManager.RestoreStore(check)
	if check and not this.CanBuy() then
		return
	end

	if Global.ChannelId == GameChannels.APPSTORE or Global.ChannelId == GameChannels.ANDROID_HUAWEI then
		ScriptBridge.RestoreStore()
	end
end

-- only for iOS
function IAPManager.GetIapIdByStoreId(storeId)
	-- general iap use different store id with packages
	-- find it just return directly
	local iapId = _storeToProductMap[storeId]
	if iapId ~= nil then
		return iapId
	end

	if _sendedProductId ~= nil then
		return _sendedProductId
	end

	-- iap package
	local iapPackageId = GameData.GetActiveIapPackage()
	if iapPackageId ~= nil then
		local packageInfo = GameData.GetIapPackageInfo(iapPackageId)
		if packageInfo.storeId == storeId and GameData.GetIapFirstOrder(iapPackageId) ~= nil then
			return iapPackageId
		end
	end
	-- custom package
	local customPackageId = GameData.GetActiveCustomPackage()
	if customPackageId ~= nil then
		local customStoreId = ConfigUtils.GetCustomPackageStoreId(customPackageId)
		if customStoreId == storeId and GameData.GetIapFirstOrder(customPackageId) ~= nil then
			return customPackageId
		end
	end

	--[[
	-- activity package
	local activityPackages = GameData.GetActiveActivityPackages()
	for idx = 1, #activityPackages do
		local packageId = activityPackages[idx]
		local packageInfo = GameData.GetActivityPackageInfo(packageId)
		if packageInfo.storeId == storeId and GameData.GetIapFirstOrder(packageId) ~= nil then
			return packageId
		end
	end
	--]]
	
	-- no found
	return nil
end

function IAPManager.GetStoreIdByIapId(iapId)
	local iapType = ConfigUtils.GetItemTypeFromId(iapId)
	if iapType == ItemType.IAPPackage then
		local packageInfo = GameData.GetIapPackageInfo(iapId)
		return packageInfo.storeId
	elseif iapType == ItemType.CustomPackage then
		return ConfigUtils.GetCustomPackageStoreId(iapId)
	elseif iapType == ItemType.IAP then
		return ConfigUtils.GetIapStoreId(iapId)
	--elseif iapType == ItemType.ActivityPackage then
		--local packageInfo = GameData.GetActivityPackageInfo(iapId)
		--return packageInfo.storeId
	else
		assert(false, "un-handle iap type: "..tostring(iapId))
	end
end

function IAPManager.Update(deltaTime)
	if not _initialized then
		return
	end

	if #_processingIaps > 0 then
		local element = _processingIaps[1]
		if not element.checking and element.nextCheck ~= nil then
			local nextCheck = element.nextCheck - deltaTime
			if nextCheck <= 0 then
				local order = element.order
				local productId = element.product
				element.checking = true
				element.nextCheck = CHECK_ORDER_DELTA
				NetManager.Send("GetPookOrderStatus", {CenterOrderNo = order, ProductId = productId}, IAPManager.OnHandleProto)
			else
				element.nextCheck  = nextCheck
			end
		end
	end
end

function IAPManager.Exit()
	_initialized = false
end

function IAPManager.CanBuy()
	if #_processingIaps > 0 then
		return false
	end

	return true
end

function IAPManager.Buy(productId, paymentType)
	if Util.IsEditor then
		--如果是编辑器模式直接购买成功
		NetManager.Send("DebugPayNotify", { IAPID = productId }, IAPManager.OnHandleProto)
		return
	end

	_isWaitingSdk = false
	_paymentType = paymentType
	this.CancelCooldown()
	local payReq = this.ConstructPayReq(productId, paymentType)
	this.ProcessNewIap(productId)
	NetManager.Send("CreatePookOrder", payReq, IAPManager.OnHandleProto)
end

function IAPManager.BuyWithAutoPaymentType(productId)
	local paymentType = this.GetPaymentType(Global.ChannelId)
	--苹果支付
	if paymentType == PaymentType.Apple then
		local existOrderId = GameData.GetIapFirstOrder(productId)
		if existOrderId then
			CtrlManager.ShowMessageBox({
				message = SAFE_LOC("该商品有未完成订单，请稍后重新登录尝试获取收据凭证。继续购买可能会导致未完成订单丢失\n继续购买？"),
				single = false,
				onConfirm = function()
					this.Buy(productId, paymentType)
				end,
			})
		else
			this.Buy(productId, paymentType)
		end
		return
	end
	--其他支付
	if paymentType ~= PaymentType.None then
		this.Buy(productId, paymentType)
		return
	end
	--自由选择支付模式
	CtrlManager.OpenPanel(CtrlNames.IAPPaymentSelect, {callback = function(receiver, paymentType)
		this.Buy(productId, paymentType)
	end})
end

function IAPManager.OnPurchaseFailed(result)
	log("purchase fail result: "..tostring(result))
	_isWaitingSdk = false
	this.CancelCooldown()
	local elements = Helper.StringSplit(result, ";")
	local productId = _sendedProductId
	if Game.CurrentPlatformId() == 2 then
		-- android
		if #elements >= 2 then
			productId = tonumber(elements[2])
		end
	else
		-- apple
		if #elements >= 3 then
			productId = tonumber(elements[3])
		elseif #elements >= 2 then
			local storeId = elements[2]
			productId = this.GetIapIdByStoreId(storeId)
		end
	end
	-- if still not found, just skip it
	if productId ~= nil then
		-- remove from processing list as failed
		this.RemoveIapByProductId(productId)
		-- remove the lastest order
		GameData.PopIapOrder(productId)
	end

	local errorCode = tonumber(elements[1])
	this.ShowIapResult(errorCode)
	-- not need anymore
	_sendedProductId = nil
end

function IAPManager.OnPurchaseSucceed(result)
	log("purchase success result: "..tostring(result))
	_isWaitingSdk = false
	this.CancelCooldown()
	-- android
	if Game.CurrentPlatformId() == 2 then
		if Global.ChannelId == GameChannels.ANDROID_HUAWEI then
			this.OnHuaweiPurchaseSucceed(result)
		else
			this.OnAndroidPurchaseSucceed(result)
		end
	else
		this.OnApplePurchaseSucceed(result)
	end
	-- not need anymore
	_sendedProductId = nil
end

--[[
如果 transaction.payment.applicationUsername 存在:
	result = {receipt, productId, appData}
如果 有记录过productId
	result = {receipt, productId, _iapId, _order}
否则
	result = {receipt, productId}

--]]
function IAPManager.OnApplePurchaseSucceed(result)
	local elements = Helper.StringSplit(result, ";")

	local receipt = elements[1]
	local storeId = elements[2]
	if #elements >= 4 then
		local productId = tonumber(elements[3])
		local order = elements[4]
		-- mark as succeed
		_completedIapMap[productId] = 1
		-- maybe get the data after re-open the app
		this.RefreshProductOrder(productId, order, receipt, false)
		local receiptJson = {}
		receiptJson["receipt-data"] = receipt
		local finalReceipt = json.encode(receiptJson)
		NetManager.Send("SubmitPookIAPReceipt", {ProductId = productId, CenterOrderNo = order, ReceiptData = finalReceipt}, IAPManager.OnHandleProto)
	else
		local productId = nil
		local order = nil
		if #elements >= 3 then
			local temp = string.split(elements[3], ";")
			productId = tonumber(temp[1])
			order = tonumber(temp[2])
		else
			productId = this.GetIapIdByStoreId(storeId)
		end
		-- has product id or not
		if productId == nil then
			-- can't find the product id
			this.ShowIapResult(PaymentResult.LostIapId)
			return
		end
		-- mark as succeed
		_completedIapMap[productId] = 1
		-- get order
		if not order then
			order = GameData.GetIapFirstOrder(productId)
		end
		if order == nil then
			-- remove from processing list as order lost
			this.RemoveIapByProductId(productId)
			-- not found the order, need to cancel the transaction
			this.ShowIapResult(PaymentResult.LostOrder)
		else
			-- maybe get the data after re-open the app
			this.RefreshProductOrder(productId, order, receipt, false)
			local receiptJson = {}
			receiptJson["receipt-data"] = receipt
			local finalReceipt = json.encode(receiptJson)
			NetManager.Send("SubmitPookIAPReceipt", {ProductId = productId, CenterOrderNo = order, ReceiptData = finalReceipt}, IAPManager.OnHandleProto)
		end
	end
end

function IAPManager.OnHuaweiPurchaseSucceed(result)
	local paymentResult = json.decode(result)
	local paymentData = paymentResult.data
	local paymentSignature = paymentResult.signature
	local paymentToken = paymentResult.token
	local paymentPayload = json.decode(paymentResult.payload)
	local orderId = paymentPayload.orderId
	local productId = tonumber(paymentPayload.productId)
	-- mark as succeed
	_completedIapMap[productId] = 1
	-- maybe get the data after re-open the app, the receipt is not important here
	this.RefreshProductOrder(productId, orderId, "", false)

	local req = {}
	req.CenterOrderNo = orderId
	req.ProductId = productId
	req.ReceiptData = paymentData
	req.SignatureData = paymentSignature
	req.Token = paymentToken
	NetManager.Send("SubmitHuaWeiReceipt", req, IAPManager.OnHandleProto)
end

function IAPManager.OnAndroidPurchaseSucceed(result)
	local elements = Helper.StringSplit(result, ";")
	local productId = tonumber(elements[1])
	-- mark as succeed
	_completedIapMap[productId] = 1
	-- wait to check with server
	local orderId = this.MarkToCheckProduct(productId)
	-- report event
	this.PurchaseSuccessAndReportEvent(productId, orderId)
end

function IAPManager.PurchaseSuccessAndReportEvent(productId, orderId)
	local iapPrice = GameData.GetIapBaseInfo(productId)
	local infullType = _paymentType or -1
	ChannelHelper.ReportToBokeAd(BokeAdEventType.Purchase, {
		uid = GameData.GetDefaultAccountUserId(),
		orderId = orderId,
		infullType = infullType,
		amount = math.floor(iapPrice * 100),
	})
end

function IAPManager.OnResume()
	if _isWaitingSdk then
		this.CancelCooldown()
		_waitingSdkCooldownHandle = GlobalScheduler:DoActionAfterTime(5, IAPManager.OnWaitingSdkTimeout)
	end
end

function IAPManager.OnWaitingSdkTimeout()
	_waitingSdkCooldownHandle = nil
	this.OnPurchaseFailed(tostring(PaymentResult.WaitingSdkTimeout))
end

function IAPManager.CancelCooldown()
	if _waitingSdkCooldownHandle ~= nil then
		GlobalScheduler:Cancel(_waitingSdkCooldownHandle)
		_waitingSdkCooldownHandle = nil
	end
end

-- 作为GameData.IsIapCompleted的辅助使用，收到sdk成功的时候就标记未已购买
function IAPManager.IsIapCompleted(iapId)
	return _completedIapMap[iapId] ~= nil
end
-----------------------------------------------------------------------------------
function IAPManager.OnHandleProto(proto, data, requestData)
	if proto == "CreatePookOrder" or proto == "SubmitPookIAPReceipt" or proto == "SubmitHuaWeiReceipt" then
		local hasIapError = data.HasIapError or false
		local productId = nil
		if proto == "CreatePookOrder" then
			productId = requestData.IAPID
		elseif proto == "SubmitPookIAPReceipt" or proto == "SubmitHuaWeiReceipt" then
			productId = requestData.ProductId
		end
		if hasIapError then
			-- remove from the processing list
			this.RemoveIapByProductId(productId)
			-- clean the orders
			GameData.CleanIapOfProduct(productId)
			-- handle error
			if proto == "CreatePookOrder" then
				-- create order error
				this.ShowIapResult(PaymentResult.CreateOrderError)
			elseif proto == "SubmitPookIAPReceipt" or proto == "SubmitHuaWeiReceipt" then
				-- submit receipt error
				this.ShowIapResult(PaymentResult.SubmitReceiptError)
			end
		else
			if proto == "CreatePookOrder" then
				local paymentType = requestData.InfullType
				local order = data.CenterOrderNo
				-- refresh order
				this.RefreshProductOrder(productId, order, nil, true)
				_sendedProductId = productId
				local passThroughPayment = this.GetPaymentPassThrough(paymentType)
				local productInfo = this.ConstructBuyProductInfo(productId, order, data)
				ScriptBridge.BuyProduct(passThroughPayment, productInfo, tostring(productId), order)
				if this.NeedToCheckWaitingSdk(paymentType) then
					_isWaitingSdk = true
				else
					_isWaitingSdk = false
				end
			elseif proto == "SubmitPookIAPReceipt" or proto == "SubmitHuaWeiReceipt" then
				if proto == "SubmitHuaWeiReceipt" then
					ScriptBridge.ConsumePurchase(requestData.Token)
				end
				-- wait to check with server
				local orderId = this.MarkToCheckProduct(productId)
				-- report event
				this.PurchaseSuccessAndReportEvent(productId, orderId)
			end
		end
	elseif proto == "GetPookOrderStatus" then
		local productId = requestData.ProductId
		local finished = data.OrderResult or false
		local payTime = data.PayTime

		local idx = this.GetIndexByProductId(productId)
		if idx ~= nil then
			if finished then
				-- remove from the processing as finished
				this.RemoveIapByProductIndex(idx)
			else
				local leftCheckNum = _processingIaps[idx].checkNum - 1
				if leftCheckNum < 1 then
					-- remove from the processing as have tried enough time
					this.RemoveIapByProductIndex(idx)
					-- clean the orders, as at this step, the server has received the receipt
					GameData.CleanIapOfProduct(productId)
					-- message box
					this.ShowIapResult(PaymentResult.CheckOrderTimeout)
				else
					_processingIaps[idx].checking = false
					_processingIaps[idx].checkNum = leftCheckNum
				end
			end
		end

		if finished then
			-- clean the orders
			GameData.CleanIapOfProduct(productId)
			-- message box
			this.ShowIapSuccess(productId, data)
		end
	elseif proto == "DebugPayNotify" then
		local productId = requestData.IAPID
		this.ShowIapSuccess(productId, data)
	end
end
------------------------------------------------------------------------------------
function IAPManager.ProcessNewIap(productId)
	-- filtered by can buy product, should no other processing iaps
	_processingIaps = {}
	_processingIaps[1] = {product = productId}
	GameNotifier.Notify(GameEvent.IapStateChanged)
end

function IAPManager.RefreshProductOrder(productId, order, receipt, refreshOrder)
	local idx = this.GetIndexByProductId(productId)
	local productIndex = idx
	if idx == nil then
		local count = #_processingIaps
		_processingIaps[count + 1] = {product = productId, order = order}
		productIndex = count + 1
		GameNotifier.Notify(GameEvent.IapStateChanged)
	else
		_processingIaps[idx].order = order
	end

	if refreshOrder then
		GameData.PushIapOrder(productId, order)
	end

	GameData.RecordProductReceipt(productId, receipt)
	return productIndex
end

function IAPManager.MarkToCheckProduct(productId)
	local checkNum = MAX_CHECK_NUM
	local idx = this.GetIndexByProductId(productId)
	assert(idx ~= nil, "no product in processing list: "..tostring(productId))
	_processingIaps[idx].nextCheck = 2 --第一次检测在2秒后,防止服务器当时还没有完成验证,白白再等5秒
	_processingIaps[idx].checkNum = checkNum
	_processingIaps[idx].checking = false

	return _processingIaps[idx].order
end

function IAPManager.GetIndexByProductId(productId)
	for idx = 1, #_processingIaps do
		if _processingIaps[idx].product == productId then
			return idx
		end
	end

	return nil
end

function IAPManager.RemoveIapByProductId(productId)
	local productIdx = this.GetIndexByProductId(productId)
	if productIdx ~= nil then
		table.remove(_processingIaps, productIdx)
		GameNotifier.Notify(GameEvent.IapStateChanged)
	end
end

function IAPManager.RemoveIapByProductIndex(productIdx)
	assert(productIdx <= #_processingIaps, "exceed the iap processing list: "..tostring(productIdx).."; "..tostring(#_processingIaps))
	table.remove(_processingIaps, productIdx)
	GameNotifier.Notify(GameEvent.IapStateChanged)
end

function IAPManager.HasProcessingOrder()
	return #_processingIaps > 0
end
------------------------------------------------------------------------------------
function IAPManager.GetResultMessage(resultCode)
	local msg = ""
	if resultCode == PaymentResult.Success then
		msg = "购买成功"
	elseif resultCode == PaymentResult.Cancel then
		msg = "支付被取消"
	elseif resultCode == PaymentResult.PurchasingUnavailable then
		msg = "支付未开放"
	elseif resultCode == PaymentResult.ExistingPurchasePending then
		msg = "有未完成订单"
	elseif resultCode == PaymentResult.ProductUnavailable then
		msg = "商品信息配置有误"
	elseif resultCode == PaymentResult.RequestProductFail then
		msg = "查询商品信息出错"
	elseif resultCode == PaymentResult.CheckOrderTimeout then
		msg = "等待支付结果超时\n如已支付成功，请重新登录游戏"
	elseif resultCode == PaymentResult.LostOrder then
		msg = "无法获取订单号，请联系客服"
	elseif resultCode == PaymentResult.LostIapId then
		msg = "无法获取商品信息，请联系客服 "
	elseif resultCode == PaymentResult.Failed then
		msg = "支付失败"
	elseif resultCode == PaymentResult.CreateOrderError then
		msg = "创建订单出错"
	elseif resultCode == PaymentResult.SubmitReceiptError then
		msg = "验证订单出错"
	elseif resultCode == PaymentResult.NetworkError then
		msg = "网络出错"
	elseif resultCode == PaymentResult.Checking then
		msg = "正在确认中..."
	elseif resultCode == PaymentResult.PaymentInUpgrade then
		msg = "支付服务正在升级"
	elseif resultCode == PaymentResult.RepeatRequest then
		msg = "重复请求"
	elseif resultCode == PaymentResult.AuthSuccess then
		msg = "授权成功"
	elseif resultCode == PaymentResult.AuthFailed then
		msg = "授权失败"
	elseif resultCode == PaymentResult.WaitingSdkTimeout then
		msg = "支付非正常退出\n如已支付成功，请重新登录游戏"
	elseif resultCode == PaymentResult.IapInProcessing then
		msg = "该商品有订单正在处理中，请稍后再试"
	elseif resultCode == PaymentResult.AccountInvalid then
		return "登录账号失效，请重新登录"
	elseif resultCode == PaymentResult.PurchaseAfterAuth then
		return "授权结束后请重新购买"
	else
		msg = "支付出错 errorcode" .. resultCode
	end

	return msg
end

function IAPManager.ShowIapResult(resultCode)
	local msg = this.GetResultMessage(resultCode)
	local callback = nil
	if resultCode == PaymentResult.AccountInvalid then
		callback = Game.Restart
	end
	CtrlManager.ShowAlert(SAFE_LOC(msg), callback)
end

function IAPManager.ShowIapSuccess(productId, data)
	local isPackage = ConfigUtils.IsPackageIap(productId)
	local price = GameData.GetIapBaseInfo(productId)
	local curDiamond = GameData.GetMoney(ItemType.Diamond)
	local goldNum = data.RemainGold
	local diamondNum = data.RemainDiamond
	local monthPay = data.MonthPay or 0
	local monthCard1ExpireTime = data.ExpireCardTime or 0
	local monthCard2ExpireTime = data.ExpireCardTimeV2 or 0

	local msg = ""
	--新增活动通行证购买成功
	if ConfigUtils.IsPassportIap(productId) then

		local addDiamond = ConfigUtils.GetIapRewardDiamond(productId)
		if addDiamond > 0 then
			msg = string.format("购买%s成功\n获得玉璧%s", ConfigUtils.GetIapName(productId), tostring(addDiamond))
		else
			msg = string.format("购买%s成功", ConfigUtils.GetIapName(productId))
		end

		GameData.SetActivityPassort(ConfigUtils.GetPassportIapActivityId(productId))
		GameNotifier.Notify(GameEvent.CatchFish_PurchasPassportSuccess)

		local rewards = GameData.GetActivityNeedCompensateItems()
		for k, v in ipairs(rewards) do
			GameData.CollectItem(v.Id, v.Num, false)
		end
		GameData.SetMoney(ItemType.Gold, goldNum)
		GameData.SetMoney(ItemType.Diamond, diamondNum)
		GameData.SetMonthPay(monthPay)
		GameData.AddSumPay(price)
		-- record completed iap
		GameData.CompleteIap(productId)
		CtrlManager.ShowAlert(msg, function()
			if not GameData.GetCurrentActivityTheme() then
				return
			end
			--local rewards = GameData.GetActivityNeedCompensateItems()
			if not rewards or #rewards < 1 then
				return
			end
			local showRewards = {}
			for _,reward in ipairs(rewards) do
				table.insert(showRewards, {value = reward.Id, num = reward.Num, unlocked = false})
			end
			NewItemCtrl.ShowNewItemList(showRewards)
		end)
		return
	end

	if isPackage then
		msg = SAFE_LOC("购买礼包成功")
		-- not repeated
		if not data.RepeatPackage and not GameData.IsIapCompleted(productId) then
			local rewards = GameData.GetRewardsOfPackage(productId)
			for k, v in pairs(rewards) do
				GameData.CollectItem(v.id, v.num, true)
			end
		end
	else
		-- 本地玉璧和月卡礼包
		local iapType = ConfigUtils.GetIapType(productId)
		local addDiamond = (diamondNum - curDiamond)
		if iapType == IAPType.MonthCard then
			local iapInternalId = ConfigUtils.GetIapInternalId(productId)
			if iapInternalId == ItemType.Card then
				local preExpireTime = GameData.GetMonthCardExpiredTime(EMonthCardType.WuwuMonthCard)
				if monthCard1ExpireTime > preExpireTime then
					if addDiamond > 0 then
						msg = SAFE_LOC("购买呜呜月卡成功\n获得玉璧")..tostring(addDiamond)
					else
						msg = SAFE_LOC("购买呜呜月卡成功成功")
					end
				end
				GameData.SetExpiredCardTime(monthCard1ExpireTime)
				GameNotifier.Notify(GameEvent.MonthCard1Changed)
			elseif iapInternalId == ItemType.Card2 then
				local preExpireTime = GameData.GetMonthCardExpiredTime(EMonthCardType.QiqiMonthCard)
				if monthCard2ExpireTime > preExpireTime then
					if addDiamond > 0 then
						msg = SAFE_LOC("购买呜呜月卡成功\n获得玉璧")..tostring(addDiamond)
					else
						msg = SAFE_LOC("购买呜呜月卡成功成功")
					end
				end
				GameData.SetExpiredCardTimeV2(monthCard2ExpireTime)
				GameNotifier.Notify(GameEvent.MonthCard2Changed)
			end
		elseif iapType == IAPType.Normal then
			if addDiamond > 0 then
				msg = SAFE_LOC("购买成功\n获得玉璧")..tostring(addDiamond)
			else
				msg = SAFE_LOC("购买成功")
			end
		end
		if addDiamond > 0 then
			local rewards = ConfigUtils.GetIapRewards(productId)
			for k, v in pairs(rewards) do
				local itemType = ConfigUtils.GetItemTypeFromId(v.Value)
				-- < 10 is special rewards
				if itemType >= 10 then
					GameData.CollectItem(v.Value, v.Num, true)
				end
			end
		end
	end
	-- sync data
	GameData.SetMoney(ItemType.Gold, goldNum)
	GameData.SetMoney(ItemType.Diamond, diamondNum)
	GameData.SetMonthPay(monthPay)
	GameData.AddSumPay(price)
	-- record completed iap
	GameData.CompleteIap(productId)
	CtrlManager.ShowAlert(msg)
end

-- payment type pass to sdk
function IAPManager.GetPaymentPassThrough(paymentType)
	if paymentType == PaymentType.Zhifubao then
		return "zhifubao"
	elseif paymentType == PaymentType.Weixin then
		return "weixin"
	end

	return ""
end
------------------------------------------------------------------------------------
function IAPManager.ConstructTencentOrderData(productId)
	local channelExtendData = json.decode(ScriptBridge.ChannelExtendData)
	local isQQ = (channelExtendData.platform == 1)
	
	local finalData = {}
	finalData.itemId = this.GetStoreIdByIapId(productId)
	finalData.openId = channelExtendData.userId
	finalData.payToken = ""
	finalData.pf = channelExtendData.pf
	finalData.pfKey = channelExtendData.pfKey
	finalData.zoneId = 1
	if isQQ then
		finalData.openKey = channelExtendData.payToken
		finalData.sessionId = "openid"
		finalData.sessionType = "kp_actoken"
	else
		finalData.openKey = channelExtendData.accessToken
		finalData.sessionId = "hy_gameid"
		finalData.sessionType = "wc_actoken"
	end

	return json.encode(finalData)
end

function IAPManager.ConstructPayReq(productId, paymentType)
	local payReq = {}

	payReq.IAPID = productId
	payReq.Channelid = Global.ChannelId
	payReq.Platform = 61
	payReq.InfullType = paymentType
	payReq.Mac = Global.deviceIdentifier
	payReq.Imsi = ""
	payReq.Platformid = Game.CurrentPlatformId()
	payReq.ProductInfo = UnityEngine.Application.identifier
	payReq.ClientVersion = Game.CurrentGameVersion()
	payReq.ThirdOrderid = ""
	payReq.OutUid = ""

	-- android
	if Game.CurrentPlatformId() == 2 then
		if paymentType == PaymentType.Zhifubao then
			payReq.ThirdOrderid = "2019050664387084"
		elseif paymentType == PaymentType.Weixin then
			payReq.ThirdOrderid = "wxbf09780e995fe743"
		elseif paymentType == PaymentType.Vivo then
			payReq.ThirdOrderid = "103867270"
		elseif paymentType == PaymentType.Huawei then
			payReq.ThirdOrderid = "101939663"
		elseif paymentType == PaymentType.Uc then
			payReq.OutUid = ScriptBridge.ChannelUid
		elseif paymentType == PaymentType.Bilibili then
			payReq.ThirdOrderid = "4452"
		elseif paymentType == PaymentType.Tencent then
			payReq.ThirdOrderid = "1110374906"
			payReq.ChannelSpecialData = this.ConstructTencentOrderData(productId)
		end
	end

	return payReq
end

function IAPManager.NeedToCheckWaitingSdk(paymentType)
	-- 确认是否需要check：支付界面切换到后台，回来支付界面消失又没返回的话就是true
	if paymentType == PaymentType.Zhifubao or 
		paymentType == PaymentType.Weixin or 
		paymentType == PaymentType.Oppo or 
		paymentType == PaymentType.Uc or
		paymentType == PaymentType.Mi or 
		paymentType == PaymentType.Tencent or 
		paymentType == PaymentType.Bilibili then
		return true
	end

	return false
end

function IAPManager.ConstructBuyProductInfo(productId, orderId, dataFromServer)
	local iapPrice, iapName, iapDesc = GameData.GetIapBaseInfo(productId)

	if Global.ChannelId == GameChannels.APPSTORE then
		return this.GetStoreIdByIapId(productId)
	elseif Global.ChannelId == GameChannels.ANDROID_OPPO then
		local serverExtraInfo = json.decode(dataFromServer.ExtraInfo)
		local info = {}
		info["amount"] = math.floor(iapPrice * 100)
		info["productDesc"] = iapDesc
		info["productName"] = iapName
		info["orderId"] = orderId
		info["callback"] = serverExtraInfo.notifyUrl

		return json.encode(info)
	elseif Global.ChannelId == GameChannels.ANDROID_VIVO then
		local channelExtendData = json.decode(ScriptBridge.ChannelExtendData)
		local info = json.decode(dataFromServer.ExtraInfo)
		info.extuid = channelExtendData.uid
		return json.encode(info)
	elseif Global.ChannelId == GameChannels.ANDROID_HUAWEI then
		local info = {}
		info["productId"] = tostring(productId)
		-- 0: 消耗型商品
		-- 1: 非消耗型商品
		info["priceType"] = 0
		info["productName"] = iapName
		info["amount"] = string.format("%.2f", iapPrice)
		info["country"] = "CN"
		info["currency"] = "CNY"
		info["sdkChannel"] = "1"        -- 1：代表应用市场渠道
		info["serviceCatalog"] = "X6"   -- X6：游戏
		local payload = {}
		payload.productId = tostring(productId)
		payload.orderId = orderId
		info["developerPayload"] = json.encode(payload)
		return json.encode(info)
	elseif Global.ChannelId == GameChannels.ANDROID_MI then
		local info = {}
		info["cpOrderId"] = orderId
		info["cpUserInfo"] = tostring(productId)
		info["amount"] = math.floor(iapPrice)
		info["balance"] = "0"
		info["vip"] = "vip0"
		info["level"] = "1"
		info["party"] = "妙奇星球"
		info["roleName"] = GameData.GetDefaultNickName()
		info["roleId"] = tostring(GameData.GetDefaultAccountUserId())
		info["serverName"] = "正式服"

		return json.encode(info)
	elseif Global.ChannelId == GameChannels.ANDROID_BILIBILI then
		local serverExtraInfo = json.decode(dataFromServer.ExtraInfo)
		local channelExtendData = json.decode(ScriptBridge.ChannelExtendData)

		local info = {}
		info["uid"] = tonumber(channelExtendData.uid)
		info["username"] = channelExtendData.username
		info["role"] = GameData.GetDefaultNickName()
		info["serverId"] = "3592"
		info["total_fee"] = serverExtraInfo.total_fee
		info["game_money"] = serverExtraInfo.game_money
		info["out_trade_no"] = serverExtraInfo.out_trade_no
		info["subject"] = iapName
		info["body"] = iapDesc
		local payload = {}
		payload.productId = tostring(productId)
		payload.orderId = orderId
		info["extension_info"] = json.encode(payload)
		info["notify_url"] = serverExtraInfo.notify_url
		info["order_sign"] = serverExtraInfo.order_sign

		return json.encode(info)
	elseif Global.ChannelId == GameChannels.ANDROID_TENCENT then
		local info = {}
		info["zoneId"] = "1"
		info["extraInfo"] = dataFromServer.ExtraInfo
		return json.encode(info)
	else
		return dataFromServer.ExtraInfo
	end
end

--通过渠道获取IAP类型
function IAPManager.GetPaymentType(channelId)
	if channelId == GameChannels.APPSTORE then
		return PaymentType.Apple
	end
	if channelId == GameChannels.ANDROID_OPPO then
		return PaymentType.Oppo
	end
	if channelId == GameChannels.ANDROID_VIVO then
		return PaymentType.Vivo
	end
	if channelId == GameChannels.ANDROID_HUAWEI then
		return PaymentType.Huawei
	end
	if channelId == GameChannels.ANDROID_UC then
		return PaymentType.Uc
	end
	if channelId == GameChannels.ANDROID_MI then
		return PaymentType.Mi
	end
	if channelId == GameChannels.ANDROID_BILIBILI then
		return PaymentType.Bilibili
	end
	if channelId == GameChannels.ANDROID_TENCENT then
		return PaymentType.Tencent
	end
	if channelId == GameChannels.ANDROID_MOMOYU then
		return PaymentType.MoMoYu
	end
	return PaymentType.None
end