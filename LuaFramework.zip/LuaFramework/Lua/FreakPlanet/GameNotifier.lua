GameNotifier = {}

local this = GameNotifier

GameEvent = {
	MoneyChanged = "MoneyChanged",
	TokenChanged = "TokenChanged",
	ItemNumChanged = "ItemNumChanged",   -- for now, only goods notified
	JumpGoalChanged = "JumpGoalChanged",
	
	CharacterSkinChanged = "CharacterSkinChanged",
	CharacterStageChanged = "CharacterStageChanged",
	CharacterLevelChanged = "CharacterLevelChanged",
	CharacterEquipmentUpgraded = "CharacterEquipmentUpgraded",
	CharacterAppearanceChanged = "CharacterAppearanceChanged",

	GoalChanged = "GoalChanged",
	BulletinStateChanged = "BulletinStateChanged",
	MailStateChanged = "MailStateChanged",
	WeeklyReportStateChanged = "WeeklyReportStateChanged",
	WeeklyReportTextureLoaded = "WeeklyReportTextureLoaded",

	MarkStateChanged = "MarkStateChanged",
	PlanetAreaUnlocked = "PlanetAreaUnlocked",
	ExploreTeamUnlocked = "ExploreTeamUnlocked",

	PlanetAreaExplore = "PlanetAreaExplore",
	PlanetAreaSpeedUp = "PlanetAreaSpeedUp",
	PlanetAreaSettle = "PlanetAreaSettle",

	ActivityExplore = "ActivityExplore",
	ActivityExploreSpeedUp = "ActivityExploreSpeedUp",
	ActivityExploreSettle = "ActivityExploreSettle",

	WorkShopListChanged = "WorkShopListChanged",
	WorkShopLevelChanged = "WorkShopLevelChanged",
	WorkShopExchanged = "WorkShopExchanged",

	ArenaBattleRankChanged = "ArenaBattleRankChanged",

	DemandChanged = "DemandChanged",

	AreaNodeAdded = "AreaNodeAdded",
	PlanetNodeAdded = "PlanetNodeAdded",
	CharacterNodeVisibleChanged = "CharacterNodeVisibleChanged",

	ChallengeFinished = "ChallengeFinished",

	IapCompleted = "IapCompleted",
	IapPackageChanged = "IapPackageChanged",
	IapStateChanged = "IapStateChanged",
	MonthCard1Changed = "MonthCard1Changed",
	MonthCard2Changed = "MonthCard2Changed",
	--ActivityPackageChanged = "ActivityPackageChanged",
	TouristChanged = "TouristChanged",

	ChannelTokenChecked = "ChannelTokenChecked",
	SummonPoolChanged = "SummonPoolChanged",
	TimeLimitActivityChanged = "TimeLimitActivityChanged",

	MoveSpaceTravelCamera = "MoveSpaceTravelCamera",

	SpaceTravelGoodsChanged = "SpaceTravelGoodsChanged",
	SpaceTravelFoodChanged = "SpaceTravelFoodChanged",
	SpaceTravelFuelChanged = "SpaceTravelFuelChanged",
	SpaceTravelScoreChanged = "SpaceTravelScoreChanged",
	SpaceTravelCapacityChanged = "SpaceTravelCapacityChanged",

	ActivityBattleChanged = "ActivityBattleChanged",

	BGMChanged = "BGMChanged",

	--界面关闭
	PanelClosed = "PanelClosed",

	---商品已购买数量改变 Id,Num
	ClothesShopProductBoughtNumChanged = "ClothesShopProductBoughtNumChanged",

	---商店状态更新
	ClothesShopStateUpdated = "ClothesShopStateUpdated",
	---商店购买商品完成
	ClothesShopPurchseCompleted = "ClothesShopPurchseCompleted",

	---[捞鱼活动]创建了一条鱼 fishUid
	CatchFish_AddFish = "CatchFish_OnAddFish",
	---[捞鱼活动]销毁了一条鱼 fishUid
	CatchFish_DelFish = "CatchFish_OnDelFish",
	---[捞鱼活动]鱼儿游走 fishUid srcIndex dstIndex
	CatchFish_Move = "CatchFish_Move",
	---[捞鱼活动]鱼儿挣扎 fishUid
	CatchFish_Struggle = "CatchFish_Struggle",
	---[捞鱼活动]鱼儿重生 fishUid
	CatchFish_Reborn = "CatchFish_Reborn",
	---[捞鱼活动]购买能量成功
	CatchFish_BuyEnergyComplete = "CatchFish_BuyEnergyComplete",
	---捞鱼通行证
	CatchFish_PurchasPassportSuccess = "CatchFish_PurchasPassportSuccess",

	HideSeekDataChanged = "HideSeekDataChanged",
	HideSeekActivityOver = "HideSeekActivityOver",
	--

	--敏感词库准备完毕
	WordFilterLoadComplete = "WordFilterLoadComplete",

	FurnitureChanged = "FurnitureChanged",
	DeliverFurnitureStatusChanged = "DeliverFurnitureStatusChanged",
    
    ---家园清理障碍相关
    HomeObstacleCleaned = "HomeObstacleCleaned",
    HomeWorldCameraMove = "HomeWorldCameraMove",
    HomeWorldCameraZoom = "HomeWorldCameraZoom",
}

local _listeners = {
	-- 
}

function GameNotifier.Init()
	_listeners = {}
end

function GameNotifier.AddListener(eventName, func, receiver)
	if _listeners[eventName] == nil then
		_listeners[eventName] = {}
	end

	table.insert(_listeners[eventName], {obj = receiver, func = func})
end

function GameNotifier.RemoveListener(eventName, func, receiver)
	if _listeners[eventName] == nil then
		return
	end

	for i, v in ipairs(_listeners[eventName]) do
		if v.obj == receiver and v.func == func then
			table.remove(_listeners[eventName], i)
			return
		end
	end
end

function GameNotifier.Notify(eventName, ...)
	if _listeners[eventName] == nil then
		return
	end

	local args = {...}

	for i, v in ipairs(_listeners[eventName]) do
		if #args == 0 then
			if v.obj ~= nil then
				v.func(v.obj)
			else
				v.func()
			end
		elseif #args == 1 then
			if v.obj ~= nil then
				v.func(v.obj, args[1])
			else
				v.func(args[1])
			end
		elseif #args == 2 then
			if v.obj ~= nil then
				v.func(v.obj, args[1], args[2])
			else
				v.func(args[1], args[2])
			end
		elseif #args == 3 then
			if v.obj ~= nil then
				v.func(v.obj, args[1], args[2], args[3])
			else
				v.func(args[1], args[2], args[3])
			end
		elseif #args == 4 then
			if v.obj ~= nil then
				v.func(v.obj, args[1], args[2], args[3], args[4])
			else
				v.func(args[1], args[2], args[3], args[4])
			end
		else
			assert(false, "un-handled argument count: "..tostring(#args))
		end
	end
end