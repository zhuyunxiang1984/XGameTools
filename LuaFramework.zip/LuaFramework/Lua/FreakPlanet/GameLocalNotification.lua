GameLocalNotification = {}

local this = GameLocalNotification

function GameLocalNotification.Init()
	NotificationScheduler.RegisterNotification();
    -- iphone won't cancel the scheduled notifications when startup
	GameLocalNotification.CancelAll()
end

function GameLocalNotification.CancelAll()
	NotificationScheduler.CleanNotification()
end

function GameLocalNotification.DoSchedule()
	if not GameData.IsNotificationOn() then
		return
	end
	--注册推送前,先清空已注册的推送
	this.CancelAll()
	local curTime = GameData.GetServerTime()
	local exploreData = GameData.GetExploreNotifyData()

	for idx, data in pairs(exploreData) do
		if data.endTime > curTime then
			local areaId = data.areaId
			local areaName = ConfigUtils.GetAreaName(areaId)
			NotificationScheduler.ScheduleNotification(SAFE_LOC("loc_global_freakplanet"), areaName..SAFE_LOC("loc_global_finish_explore"), data.endTime - curTime)
		end
	end

	local workShopId, workShopEndTime = GameData.GetWorkShopNotifyData()
	if workShopId ~= nil and workShopEndTime > curTime then
		NotificationScheduler.ScheduleNotification(SAFE_LOC("loc_global_freakplanet"), SAFE_LOC("loc_global_finish_workshop"), workShopEndTime - curTime)
	end

	local touristNotifyTime = GameData.GetTouristNotifyData()
	if touristNotifyTime ~= nil and touristNotifyTime > curTime then
		NotificationScheduler.ScheduleNotification(SAFE_LOC("loc_global_freakplanet"), SAFE_LOC("loc_global_tourist_coming"), touristNotifyTime - curTime)
	end

	local newActivityTime = GameData.GetLatestNewActivity()
	if newActivityTime ~= nil then
		NotificationScheduler.ScheduleNotification(SAFE_LOC("loc_global_freakplanet"), SAFE_LOC("loc_global_new_activity_start"), newActivityTime - curTime)
	end

	local newSummonTime = GameData.GetLatestNewSummonPool()
	if newSummonTime ~= nil then
		NotificationScheduler.ScheduleNotification(SAFE_LOC("loc_global_freakplanet"), SAFE_LOC("loc_global_new_sommon_pool_start"), newSummonTime - curTime)
	end

	local activityExploreData = GameData.GetActivityExploreNotifyData()
	if activityExploreData ~= nil then
		NotificationScheduler.ScheduleNotification(SAFE_LOC("loc_global_freakplanet"), SAFE_LOC("活动探索已完成"), activityExploreData.endTime - curTime)
	end
end