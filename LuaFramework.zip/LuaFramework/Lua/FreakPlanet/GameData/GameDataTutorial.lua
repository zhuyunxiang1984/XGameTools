
local this = GameData

local _tutorialData = nil
local _isDataDirty = false

local _pendingTutorials = nil

function GameData.InitTutorialData(data)
	_pendingTutorials = {}
	local tutorialList = data.TutorialList or {}
	this.SetTutorialFromServerData(tutorialList)
end

function GameData.SetTutorialFromServerData(data)
	_tutorialData = {}
	_isDataDirty = false

	-- init data
	for k, v in pairs(TutorialConfig) do
		local branch = v.Branch
		if branch > 0 then
			_tutorialData[branch] = 0
		end
	end

	--log("tutorial data: "..Helper.Format(data))

	for idx = 1, #data do
		local branch = data[idx].Branch
		local step = data[idx].Step
		_tutorialData[branch] = step
	end

	this.ValidateTutorial()
end

function GameData.ValidateTutorial()
	if _tutorialData[1] < 1 and this.IsPlanetAreaExploring(TutorialConstData.ExploreAreaId) then
		_tutorialData[1] = 1
		_isDataDirty = true
	end

	if this.IsGoalCompletedOrFinished(TutorialConstData.ExploreGoal) then
		if _tutorialData[1] < 2 then
			_tutorialData[1] = 2
			_isDataDirty = true
		end
	end

	if this.IsGoalCompletedOrFinished(TutorialConstData.ChallengeGoal) then
		if _tutorialData[2] < 1 then
			_tutorialData[2] = 1
			_isDataDirty = true
		end
	end

	if this.IsGoalCompletedOrFinished(TutorialConstData.CharacterUpgradeGoal) then
		if _tutorialData[3] < 1 then
			_tutorialData[3] = 1
			_isDataDirty = true
		end
	end

	if this.IsGoalCompletedOrFinished(TutorialConstData.WorkShopGoal) then
		if _tutorialData[4] < 1 then
			_tutorialData[4] = 1
			_isDataDirty = true
		end
	end

	if this.IsGoalCompletedOrFinished(TutorialConstData.DemandGoal) then
		if _tutorialData[5] < 1 then
			_tutorialData[5] = 1
			_isDataDirty = true
		end
	end

	if this.IsGoalCompletedOrFinished(TutorialConstData.EquipmentUpgradeGoal) then
		if _tutorialData[6] < 1 then
			_tutorialData[6] = 1
			_isDataDirty = true
		end
	end

	if this.IsGoalCompletedOrFinished(TutorialConstData.WorkShopUpgradeGoal) then
		if _tutorialData[7] < 1 then
			_tutorialData[7] = 1
			_isDataDirty = true
		end
	end

	if this.IsGoalCompletedOrFinished(TutorialConstData.SummonGoal) then
		if _tutorialData[8] < 1 then
			_tutorialData[8] = 1
			_isDataDirty = true
		end
	end

	if this.IsGoalCompletedOrFinished(TutorialConstData.CraftGoal) then
		if _tutorialData[9] < 1 then
			_tutorialData[9] = 1
			_isDataDirty = true
		end
	end
end

function GameData.IsTutorialFinished(tutorialId)
	if not _tutorialData then
		return false
	end
	local branch, step = ConfigUtils.GetTutorialInfo(tutorialId)

	local finishedStep = _tutorialData[branch] or 0
	return finishedStep >= step
end

function GameData.IsTutorialNotFinished(tutorialId)
	return not this.IsTutorialFinished(tutorialId)
end

function GameData.IsFirstBranchTutorialFinished()
	return this.IsTutorialFinished(Tutorials.Tutorial_1_12)
end

function GameData.AppendTutorial(ctrlName, functionName, tutorials)
	assert(_pendingTutorials ~= nil, "pending tutorials must have been inited")

	_pendingTutorials[ctrlName] = {func = functionName, tutorials = tutorials}
end

function GameData.GetTutorialsOfCtrl(ctrlName, functionName)
	if _pendingTutorials[ctrlName] == nil then
		return nil
	end

	if _pendingTutorials[ctrlName].func ~= functionName then
		return nil
	end

	return _pendingTutorials[ctrlName].tutorials
end

function GameData.CleanTutorialsOfCtrl(ctrlName)
	_pendingTutorials[ctrlName] = nil
end

function GameData.FinishTutorial(tutorialId)
	-- utility tutorials, just skip it
	local branch, step = ConfigUtils.GetTutorialInfo(tutorialId)
	if branch <= 0 then
		return false
	end

	-- already recorded
	local curStep = _tutorialData[branch] or 0
	if curStep >= step then
		return false
	end

	-- record it in local anyway
	_tutorialData[branch] = step
	_isDataDirty = true
end

function GameData.SyncTutorialData()
	if not _isDataDirty then
		return
	end

	local sendData = {}
	for k, v in pairs(_tutorialData) do
		table.insert(sendData, {Branch = k, Step = v})
	end

	_isDataDirty = false
	NetManager.Send("SyncTutorial", {TutorialList = sendData}, nil, nil)
end