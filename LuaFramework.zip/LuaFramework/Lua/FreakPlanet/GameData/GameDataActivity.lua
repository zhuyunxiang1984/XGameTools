------------------------------------------------------------------
-- 流亡街活动数据
------------------------------------------------------------------
local this = GameData
------------------------------------------------------------------
local _activityThemeData = nil
-- 未结算的活动探索，时间可能已过期
local _currentUnsettledThemeId = nil
local _activityExploreData = nil
local _activityBattleData = nil

-------------------------------------------------------------------------------------------------
function GameData.InitActivityThemeData(data)
    _activityThemeData = {}
    data = data or {}
    --log("-------------------activity theme data: "..Helper.Format(data))
    XDebug.LogTable("LZ",'Activity', "InitActivityThemeData", data)
    local curTime = this.GetServerTime()
    for k, v in pairs(data) do
        local themeId = v.ActivityThemeId
        if ConfigUtils.IsValidActivityTheme(themeId) then
            local startTime = v.StartTime or 0
            local endTime = v.EndTime or 0
            _activityThemeData[themeId] = {startTime = startTime, endTime = endTime}
        end
    end
end

function GameData.IsActivityThemeValid(themeId)
    if not ConfigUtils.IsValidItem(themeId) then
        return false
    end

    local v = _activityThemeData[themeId]
    if v == nil then
        return false
    end

    local curTime = this.GetServerTime()
    return curTime >= v.startTime and curTime < v.endTime
end

function GameData.GetCurrentActivityTheme()
    for k, v in pairs(_activityThemeData) do
        local curTime = this.GetServerTime()
        if curTime >= v.startTime and curTime < v.endTime then
            return k, v.endTime
        end
    end

    return nil
end

function GameData.GetActivityStartAndEndTime(activityId)
    if  this.IsActivityThemeValid(activityId) then
        local data = _activityThemeData[activityId]
        return data.startTime, data.endTime
    end
end

function GameData.CanShowActivityTheme(themeId)
    local characterList = ConfigUtils.GetActivityThemeCharacters(themeId)
    for idx = 1, #characterList do
        local characterId = characterList[idx]
        if GameData.IsCharacterUnlocked(characterId) then
            return true
        end
    end

    return false
end

--获取居酒屋显示的房间
function GameData.GetActivityThemeListToShow()
    local currentThemeId = this.GetCurrentActivityTheme()
    local alreadyExist = {}

    local themeList = {}
    if currentThemeId then
        local roomPrefab = ConfigUtils.GetActivityThemePrefab(currentThemeId)
        alreadyExist[roomPrefab] = true
        table.insert(themeList, currentThemeId)
    end
    local otherList = ConfigUtils.GetActivityThemeList(function(themeId)
        if currentThemeId == themeId then
            return false
        end
        if not GameData.CanShowActivityTheme(themeId) then
            return false
        end
        local roomPrefab = ConfigUtils.GetActivityThemePrefab(themeId)
        if alreadyExist[roomPrefab] then
            return false
        end
        alreadyExist[roomPrefab] = true
        return true
    end)
    table.AddRange(themeList, otherList)

    table.sort(themeList, function(themeId1, themeId2)
        if themeId1 == currentThemeId then
            return true
        end
        if themeId2 == currentThemeId then
            return false
        end
        return themeId1 < themeId2
    end)

    return themeList
end
-------------------------------------------------------------------------------------------------
function GameData.InitActivityData(data)
    _currentUnsettledThemeId = nil
    data = data or {}
    this.ConstructActivityExploreData(data.ActivityExploreList)
    this.ConstructActivityBattleData(data.ActivityBattleList)
end

function GameData.ConstructActivityExploreData(data)
    data = data or {}
    log("-------------------activity explore data: "..Helper.Format(data))
    _activityExploreData = {}
    for k, v in pairs(data) do
        local themeId = v.ActivityThemeId
        local status, exploreData, usedCharacters, usedPet = this.ConstructExploreData(v)
        _activityExploreData[themeId] = exploreData
        if status > 0 then
            if _currentUnsettledThemeId == nil then
                _currentUnsettledThemeId = themeId
                GameData.SetActivityExploreTeam(themeId, usedCharacters, usedPet)
            else
                log("has more than one unsettled activity theme")
            end
        end
    end
end

function GameData.GetActivityExploreLeftTime(themeId)
    local v = _activityExploreData[themeId]
    assert(v ~= nil, "invalid activity theme id: "..tostring(themeId))
    assert(v.settleStatus > 0, "activity theme is not exploring: "..tostring(themeId))

    local endTime = v.endTime
    local curTime = GameData.GetServerTime()
    return math.max(endTime - curTime, 0)
end

function GameData.GetActivityExploreTime(themeId)
    local v = _activityExploreData[themeId]
    assert(v ~= nil, "invalid activity theme id: "..tostring(themeId))
    assert(v.settleStatus > 0, "activity theme is not exploring: "..tostring(themeId))

    return v.startTime, v.endTime
end

function GameData.SpeedUpActivityExplore(themeId)
    local v = _activityExploreData[themeId]
    assert(v ~= nil, "invalid activity theme id: "..tostring(themeId))
    assert(v.settleStatus > 0, "activity theme is not exploring: "..tostring(themeId))
    
    v.endTime = this.GetServerTime()
    GameNotifier.Notify(GameEvent.ActivityExploreSpeedUp, themeId, v.endTime)
end

function GameData.GetMeetEnemyListOfActivityExplore(themeId)
    local v = _activityExploreData[themeId]
    assert(v ~= nil, "invalid activity theme id: "..tostring(themeId))
    assert(v.settleStatus > 0, "activity theme is not exploring: "..tostring(themeId))

    local ret = {}

    local enemyList = v.enemyList
    for idx = 1, #enemyList do
        local enemyId = enemyList[idx][1]
        ret[idx] = enemyId
    end

    return ret
end

function GameData.StartActivityExplore(themeId, data)
    _currentUnsettledThemeId = themeId
    -- set data
    local status, exploreData, usedCharacters, usedPet = this.ConstructExploreData(data)
    _activityExploreData[themeId] = exploreData
    GameData.SetActivityExploreTeam(themeId, usedCharacters, usedPet)
    -- must mark it before the notify send
    this.MarkBusyCharacterDirty()
    this.MarkBusyPetDirty()
    -- notify
    GameNotifier.Notify(GameEvent.ActivityExplore, themeId, exploreData.endTime)
end

function GameData.GetActivityExploreResult(themeId)
    local data = _activityExploreData[themeId]
    assert(data ~= nil, "activity theme not exist: "..tostring(themeId))
    assert(data.settleStatus > 0, "activity theme is not exploring: "..tostring(themeId))
    return this.GetExploreResultByData(data)
end

function GameData.GetEventUnlockOfActivityExplore(themeId)
    local exploreId = ConfigUtils.GetActivityThemeExplore(themeId)
    local eventList = ConfigUtils.GetActivityExploreEventList(exploreId)
    local totalNum = #eventList
    local unlockNum = 0

    for idx = 1, totalNum do
        local eventId = eventList[idx]
        if this.IsEventUnlocked(eventId) then
            unlockNum = unlockNum + 1
        end
    end

    return unlockNum, totalNum
end

function GameData.FinishExploreOfActivityExplore(themeId)
    local data = _activityExploreData[themeId]
    local exploreId = ConfigUtils.GetActivityThemeExplore(themeId)
    local characters = this.GetActivityExploreCharacters(themeId)
    local skins = {}
    for idx = 1, #characters do
        skins[idx] = this.GetCharacterSkin(characters[idx])
    end
    local petId = data.pet
    if not ConfigUtils.IsValidItem(petId) then
        petId = nil
    end

    local costTime = data.costTime
    local totalTime = data.totalExploreTime or 0
    totalTime = totalTime + costTime

    local exploreCostItems = {}
    local goalData = {}
    -- drop list
    local dropList = data.dropList
    for idx = 1, #dropList do
        local itemId = dropList[idx][1]
        local itemNum = dropList[idx][2]
        this.CollectItem(itemId, itemNum)
        -- goal
        local e = this.SetupItemGoalData(itemId, itemNum)
        e.Characters = characters
        e.Pet = petId
        e.Skins = skins
        table.insert(goalData, e)
    end
    -- event list
    local eventList = data.eventList
    for idx = 1, #eventList do
        local eventId = eventList[idx].EventId
        this.UnlockEvent(eventId)
        -- event rewards
        local eventRewards = ConfigUtils.GetEventReward(eventId)
        for eventRewardIdx = 1, #eventRewards do
            local eventRewardId = eventRewards[eventRewardIdx].Value
            local eventRewardNum = eventRewards[eventRewardIdx].Num
            this.CollectItem(eventRewardId, eventRewardNum)
        end
    end
    -- catch item list
    local catchItemList = data.catchItemList
    for catchItemIdx = 1, #catchItemList do
        local catchItemId = catchItemList[catchItemIdx].CatchItemId
        local catchItemState = catchItemList[catchItemIdx].Status
        local petList = catchItemList[catchItemIdx].CatchPetList or {}
        --assert(#petList <= 1, "one catch item can catch one pet at most")
        if #petList > 0 then
            for idx = 1, #petList do
                local petId = petList[idx][1]
                local petState = petList[idx][2]
                -- success
                if petState == 1 then
                    this.UnlockPet(petId, 1)
                    -- catch pet
                    local e = this.SetupItemGoalData(petId, 1)
                    e.Characters = characters
                    e.Pet = petId
                    e.Skins = skins
                    table.insert(goalData, e)
                end
            end

        end
        -- not broken: 0 - not used; 1 - used but not broken
        if catchItemState == 0 or catchItemState == 1 then
            this.CollectItem(catchItemId, 1)
        else
            -- used catch items
            local preCostNum = exploreCostItems[catchItemId] or 0
            exploreCostItems[catchItemId] = preCostNum + 1
        end
    end
    -- time data
    table.insert(goalData, {Type = ItemType.Time, Num = costTime, Value = -1, Characters = characters, Skins = skins, Pet = petId})
    -- enemy list
    local enemyList = data.enemyList
    for idx = 1, #enemyList do
        local enemyId = enemyList[idx][1]
        local enemyPower= enemyList[idx][2]
        local winEnemy= (enemyList[idx][3] > 0)
        local enemyNum = enemyList[idx][4]

        if winEnemy then
            local e = this.SetupItemGoalData(enemyId, enemyNum)
            table.insert(goalData, e)
            e.Characters = characters
            e.Pet = petId
            e.Skins = skins
        end
    end
    -- explore cost
    local foodList = data.foodList
    for idx = 1, #foodList do
        local itemId = foodList[idx][1]
        exploreCostItems[itemId] = foodList[idx][2]
    end
    -- explore cost goal data
    local exploreCostGoalData = {}
    for k, v in pairs(exploreCostItems) do
        local e = this.SetupItemGoalData(k, v)
        table.insert(exploreCostGoalData, e)
        e.Characters = characters
        e.Pet = petId
        e.Skins = skins
    end
    -- goal
    this.DoGoalSettle(TriggerType.ActivityExplore, goalData)
    this.DoGoalSettle(TriggerType.ActivityExploreCost, exploreCostGoalData)
    -- empty the explore data
    _activityExploreData[themeId] = {settleStatus = 0, totalExploreTime = totalTime}
    -- must mark it before the notify send
    this.MarkBusyCharacterDirty()
    this.MarkBusyPetDirty()
    -- actual just notify the completed goals, as we will refresh goal list
    this.CheckAndHintGoalsOfCurrentCountType()
    -- notify
    GameNotifier.Notify(GameEvent.ActivityExploreSettle)
    -- settled, end
    _currentUnsettledThemeId = nil
end

function GameData.CancelExploreOfActivityExplore(themeId)
    local exploreId = ConfigUtils.GetActivityThemeExplore(themeId)
    local data = _activityExploreData[themeId]
    local totalTime = data.totalExploreTime or 0
    -- catch item list
    local catchItemList = data.catchItemList
    for catchItemIdx = 1, #catchItemList do
        local catchItemId = catchItemList[catchItemIdx].CatchItemId
        this.CollectItem(catchItemId, 1)
    end
    -- food list
    local foodList = data.foodList
    for idx = 1, #foodList do
        local itemId = foodList[idx][1]
        local itemNum = foodList[idx][2]
        this.CollectItem(itemId, itemNum)
    end
    -- empty the explore data
    _activityExploreData[themeId] = {settleStatus = 0, totalExploreTime = totalTime}
    -- must mark it before the notify send
    this.MarkBusyCharacterDirty()
    this.MarkBusyPetDirty()
    -- notify
    GameNotifier.Notify(GameEvent.ActivityExploreSettle)
    -- settled, end
    _currentUnsettledThemeId = nil
end

function GameData.GetUnsettledActivityTheme()
    return _currentUnsettledThemeId
end

function GameData.HasFinishedActivityExplore()
    if _currentUnsettledThemeId == nil then
        return false
    end

    local leftTime = this.GetActivityExploreLeftTime(_currentUnsettledThemeId)
    return leftTime <= 0
end

function GameData.GetActivityExploreNotifyData()
    if _currentUnsettledThemeId == nil then
        return nil
    end

    local _, endTime = GameData.GetActivityExploreTime(_currentUnsettledThemeId)
    local curTime = GameData.GetServerTime()
    if endTime > curTime then
        return {endTime = endTime, themeId = _currentUnsettledThemeId}
    end

    return nil
end
-------------------------------------------------------------------------------------------------
function GameData.ConstructActivityBattleData(data)
    data = data or {}
    log("-------------------activity battle data: "..Helper.Format(data))
    _activityBattleData = {}
    for k, v in pairs(data) do
        local themeId = v.ActivityThemeId
        local battleList = v.BattleList
        this.SetActivityBattleDataOfTheme(themeId, battleList)
    end
end

function GameData.SetActivityBattleDataOfTheme(themeId, battleList)
    battleList = battleList or {}

    local battleRecords = {}
    for idx = 1, #battleList do
        local battleId = battleList[idx][1]
        local unlock = battleList[idx][2]
        local win = battleList[idx][3]
        battleRecords[idx] = {id = battleId, unlock = unlock, win = win}
    end

    _activityBattleData[themeId] = {
        battleRecords = battleRecords
    }

    GameNotifier.Notify(GameEvent.ActivityBattleChanged)
end

function GameData.GetActivityBattleRecords(themeId)
    if _activityBattleData[themeId] == nil then
        _activityBattleData[themeId] = {battleRecords = {}}
    end

    return _activityBattleData[themeId].battleRecords or {}
end

function GameData.GetActivityBattleStage()
    local themeId = GameData.GetCurrentActivityTheme()
    if themeId == nil then
        return 0
    end

    local battleRecords = this.GetActivityBattleRecords(themeId)
    for idx = #battleRecords, 1, -1 do
        local winNum = battleRecords[idx].win or 0
        if winNum > 0 then
            return idx
        end
    end

    return 0
end

function GameData.IsActivityBattleUnlocked(battleId)
    for k, v in pairs(_activityBattleData) do
        local battleRecords = v.battleRecords
        for idx = 1, #battleRecords do
            if battleRecords[idx].id == battleId then
                local unlockCount = battleRecords[idx].unlock or 0
                if unlockCount > 0 then
                    return true
                end
            end
        end
    end

    return false
end
-------------------------------------------------------------------------------------------------
function GameData.HasCompletedActivityGoal()
    local activityId = GameData.GetValidActivityId()
    if activityId ~= nil then
        local activityInfo = GameData.GetActivityInfo(activityId)
        local goalId = GameData.GetCurrentActivityGoalOfPool(activityInfo.poolId)
        if goalId ~= nil then
            local goalState = GameData.GetGoalInfo(goalId)
            return goalState == GoalState.Complete
        end
    end

    return false
end

-- 当前活动是否有签到功能
function GameData.IsValidActivitySignIn()
    local themeId = GameData.GetCurrentActivityTheme()
    if themeId then
        return ConfigUtils.IsValidActivitySignIn(themeId)
    end
   return false
end

--获取当前活动小游戏
function GameData.GetCurrentActivityThemeGameModule()
    local themeId = GameData.GetCurrentActivityTheme()
    if not themeId then
        return nil
    end
    return ConfigUtils.GetActivityThemeGameModule(themeId)
end

--获取当前活动通行证的购买结束时间
function GameData.GetBuyActivityPassportLeftTime()
    local themeId, endTime = this.GetCurrentActivityTheme()
    if not themeId then
        return 0
    end
    --比活动时间提前24h结束
    endTime = endTime - 24 * 3600
    return math.max(0, endTime - this.GetServerTime())
end