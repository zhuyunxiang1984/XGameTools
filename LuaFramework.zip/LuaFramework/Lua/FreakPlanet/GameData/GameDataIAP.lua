
local this = GameData

local _iapPackageList = {}
local _completedIapList = {}

local _activityPackageList = {}

local _customPackageData = {}
local _customDetailPackageData = nil


local _monthCardExpireTime
local _monthCardLastRewardTime

local _monthCardExpireTimeV2
local _monthCardLastRewardTimeV2

local _activityPassport

EMonthCardType = {
	WuwuMonthCard = 1,
	QiqiMonthCard = 2,
}

--------------------------------------------------------------------------------
function GameData.InitIapMonthCard(data)
	_monthCardExpireTime = data.ExpireCardTime or 0
	_monthCardLastRewardTime = data.LastCardRewardTime or 0

	_monthCardExpireTimeV2 = data.ExpireCardTimeV2 or 0
	_monthCardLastRewardTimeV2 = data.LastCardRewardTimeV2 or 0

	_activityPassport = data.ActivityPass or 0

	XDebug.Log('GGYY', "活动通行证 " .. tostring(_activityPassport))
end

function GameData.HasMonthCardReward(monthCardType)
	if monthCardType == EMonthCardType.WuwuMonthCard then
		-- no month card
		if _monthCardExpireTime == 0 then
			return false
		end

		-- expired
		local currentTime = GameData.GetServerTime()
		if _monthCardExpireTime <= currentTime then
			return false
		end

		-- in differen day or not
		return GameData.IsDifferentDay(currentTime, _monthCardLastRewardTime)
	elseif monthCardType == EMonthCardType.QiqiMonthCard then
		if _monthCardExpireTimeV2 == 0 then
			return false
		end

		-- expired
		local currentTime = GameData.GetServerTime()
		if _monthCardExpireTimeV2 <= currentTime then
			return false
		end

		-- in differen day or not
		return GameData.IsDifferentDay(currentTime, _monthCardLastRewardTimeV2)
	end

end

function GameData.HasAnyMonthCardReward()
	return this.HasMonthCardReward(EMonthCardType.WuwuMonthCard) or this.HasMonthCardReward(EMonthCardType.QiqiMonthCard)
end


function GameData.IsMonthCardBought(monthCardType)
	if monthCardType == EMonthCardType.WuwuMonthCard then
		return _monthCardExpireTime > 0
	elseif monthCardType == EMonthCardType.QiqiMonthCard then
		return _monthCardExpireTimeV2 > 0
	end
end

function GameData.GetMonthCardLeftDays(monthCardType)
	local currentTime = GameData.GetServerTime()
	if monthCardType == EMonthCardType.WuwuMonthCard then
		if _monthCardExpireTime == 0 or _monthCardExpireTime <= currentTime then
			return 0
		end
		return GameData.GetDayDiffer(_monthCardExpireTime, currentTime) + 1
	elseif monthCardType == EMonthCardType.QiqiMonthCard then
		if _monthCardExpireTimeV2 == 0 or _monthCardExpireTimeV2 <= currentTime then
			return 0
		end
		return GameData.GetDayDiffer(_monthCardExpireTimeV2, currentTime) + 1
	end
end

function GameData.GetMonthCardExpiredTime(monthCardType)
	if monthCardType == EMonthCardType.WuwuMonthCard then
		return _monthCardExpireTime
	elseif monthCardType == EMonthCardType.QiqiMonthCard then
		return _monthCardExpireTimeV2
	end
end

function GameData.SetExpiredCardTime(expiredTime)
	expiredTime = expiredTime or 0
	_monthCardExpireTime = expiredTime
end

function GameData.SetExpiredCardTimeV2(expiredTime)
	expiredTime = expiredTime or 0
	_monthCardExpireTimeV2 = expiredTime
end

function GameData.GetMonthCardRewardAt(lastRewardTime, monthCardType)
	lastRewardTime = lastRewardTime or 0
	if monthCardType == EMonthCardType.WuwuMonthCard then
		_monthCardLastRewardTime = lastRewardTime
	elseif monthCardType == EMonthCardType.QiqiMonthCard then
		_monthCardLastRewardTimeV2 = lastRewardTime
	end
end

function GameData.SetMonthCardLastReward(lastRewardTime)
	lastRewardTime = lastRewardTime or 0
	_monthCardLastRewardTime = lastRewardTime
end

function GameData.SetMonthCardLastRewardV2(lastRewardTime)
	lastRewardTime = lastRewardTime or 0
	_monthCardLastRewardTimeV2 = lastRewardTime
end

--------------------------------------------------------------------------------
function GameData.SetActivityPackageList(packages)
	do
		return
	end
	packages = packages or {}
	log("activity packages: "..Helper.Format(packages))

	_activityPackageList = ConstructPackageList(packages)
	GameNotifier.Notify(GameEvent.ActivityPackageChanged)
end

function GameData.SetCustomPackage(data)
	_customPackageData = {}

	--if data ~= nil then
	if not Helper.IsEmpty(data) then
		local packageId = data.PackageId or 0
		local endTime = data.EndTime or 0
		local isBuy = data.IsBuy or 0
		local startTime = data.StartTime or 0

		local currentTime = GameData.GetServerTime()

		if ConfigUtils.IsValidItem(packageId) and currentTime < endTime and isBuy == 0 then
			_customPackageData = {id = packageId,startTime = startTime, endTime = endTime, isBuy = isBuy}
		end

		local price = ConfigUtils.GetCustomPackagePrice(packageId)
		local name, desc, buttonDesc, rate, icon = ConfigUtils.GetCustomPackageInfo(packageId)
		local rewards = ConfigUtils.GetCustomPackageRewards(packageId)
		_customDetailPackageData = {
			id = packageId,
			startTime = startTime,
			endTime = endTime,
			price = price,
			name = name,
			desc = desc,
			buttonDesc = buttonDesc,
			rewards = rewards,
			rate = rate or 0,
			icon = icon,
			isLimit = true,
			type = 0,
			sellTime = startTime,
			pTxtLimitTime = nil,
			IsPreSell = false,
			sort = 0,
			isBuy = isBuy,
		}
		GameNotifier.Notify(GameEvent.IapPackageChanged)
	end

end

function GameData.GetActiveCustomPackage()
	if _customPackageData == nil or _customPackageData.id == nil then
		return nil
	end

	local iapId = _customPackageData.id
	if this.IsIapReallyCompleted(iapId) then
		return nil
	end

	local currentTime = GameData.GetServerTime()
	local endTime = _customPackageData.endTime
	local startTime = _customPackageData.startTime
	local isBuy = _customPackageData.isBuy
	if currentTime >= endTime then
		return nil
	end

	return iapId, endTime, startTime, isBuy
end

function GameData.GetActiveCustomDetailPackageData()
	if _customDetailPackageData then
		local currentTime = GameData.GetServerTime()
		local endTime = _customDetailPackageData.endTime
		if endTime > currentTime then
			return _customDetailPackageData
		end
	end
	return nil
end


function GameData.IsValidPeriodOfMonthCard2()
	if this.IsMonthCardBought(EMonthCardType.QiqiMonthCard) and this.GetMonthCardLeftDays(EMonthCardType.QiqiMonthCard) > 0 then
		return true
	end
	return false
end

function GameData.GetActiveActivityPackages()
	local ret = {}

	-- 活动礼包即使已经购买也会显示，不同于其他礼包，只要在时间范围内
	local serverTime = this.GetServerTime()
	for iapId, info in pairs(_activityPackageList) do
		local startTime = info.startTime
		local endTime = info.endTime
		if startTime <= serverTime and serverTime < endTime then
			table.insert(ret, iapId)
		end
	end

	table.sort(ret, function(idA, idB)
		if idA == nil or idB == nil then
			return false
		end

		return idA < idB
	end)

	return ret
end

function GameData.HasActiveActivityPackage()
	-- 活动礼包即使已经购买也会显示，不同于其他礼包，只要在时间范围内
	local serverTime = this.GetServerTime()
	for _, info in pairs(_activityPackageList) do
		local startTime = info.startTime
		local endTime = info.endTime
		if startTime <= serverTime and serverTime < endTime then
			return true
		end
	end

	return false
end

function GameData.GetActivePackage()
	local customPackageId, customPackageEndTime = this.GetActiveCustomPackage()
	local iapPackageId, iapPackageEndTime = this.GetActiveIapPackage()
	if customPackageId == nil and iapPackageId == nil then
		return nil
	end

	local useIapPackage = true
	if customPackageId ~= nil and iapPackageId ~= nil then
		if customPackageEndTime < iapPackageEndTime then
			useIapPackage = false
		end
	elseif customPackageId ~= nil then
		useIapPackage = false
	end

	if useIapPackage then
		return iapPackageId, iapPackageEndTime
	else
		return customPackageId, customPackageEndTime
	end
end

--- 废弃
function GameData.GetActivityPackageInfo(iapId)
	return _activityPackageList[iapId]
end

function GameData.GetRewardsOfPackage(iapId)
	local iapType = ConfigUtils.GetItemTypeFromId(iapId)
	local ret = {}

	if iapType == ItemType.IAPPackage then
		local config = _iapPackageList[iapId]
		if config ~= nil then
			ret = config.rewards or {}
		end
	elseif iapType == ItemType.CustomPackage then
		ret = ConfigUtils.GetCustomPackageRewards(iapId)
	--[[
	elseif iapType == ItemType.ActivityPackage then
		local config = _activityPackageList[iapId]
		if config ~= nil then
			ret = config.rewards or {}
		end
	--]]
	end

	return ret
end

function GameData.GetIapBaseInfo(iapId)
	local iapType = ConfigUtils.GetItemTypeFromId(iapId)
	if iapType == ItemType.IAPPackage then
		local info = this.GetIapPackageInfo(iapId)
		return info.price, info.name, info.desc
	elseif iapType == ItemType.CustomPackage then
		return ConfigUtils.GetCustomPackagePrice(iapId), ConfigUtils.GetCustomPackageInfo(iapId)
	elseif iapType == ItemType.IAP then
		return ConfigUtils.GetIapPrice(iapId), ConfigUtils.GetIapInfo(iapId)
	else
		assert(false, "un-handle iap type: "..tostring(iapId))
	end
end

--玩家是否拥有礼包内的角色,皮肤,玩具,家具
function GameData.HasPackageAnyOneReward(rewards)
	for idx = 1, #rewards do
		local itemId = rewards[idx].id
		local itemType = ConfigUtils.GetItemTypeFromId(itemId)
		--角色,皮肤,家具
		if itemType == ItemType.Character or itemType == ItemType.Skin or itemType == ItemType.RoomPiece then
			if this.IsItemUnlocked(itemId) then
				return true
			end
		end
		--玩具
		if itemType == ItemType.Goods then
			if ConfigUtils.GetGoodsOnlyOne(itemId) and this.IsItemUnlocked(itemId) then
				return true
			end
		end
	end
	return false
end

--------------------------------------------------------------------------------
function GameData.SetCompletedIapList(iapList)
	_completedIapList = {}

	iapList = iapList or {}
	for idx = 1, #iapList do
		_completedIapList[idx] = {id = iapList[idx].IAPID, time = iapList[idx].PayTime}
	end

	log("completed iap list: "..Helper.Format(_completedIapList))
end

function GameData.CompleteIap(iapId, payTime)
	payTime = payTime or this.GetServerTime()
	table.insert(_completedIapList, {id = iapId, time = payTime})
	GameNotifier.Notify(GameEvent.IapCompleted, iapId)

	if ConfigUtils.IsPackageIap(iapId) then
		GameNotifier.Notify(GameEvent.IapPackageChanged)
	end
end


--
function GameData.HasActivityPassport(activityThemeId)
	return _activityPassport == activityThemeId
end

--
function GameData.SetActivityPassort(activityThemeId)
	_activityPassport = activityThemeId
end

--是否拥有当前活动的通行证
function GameData.HasCurrActivityPassport()
	local activityThemeId = this.GetCurrentActivityTheme()
	if not activityThemeId then
		return false
	end
	return this.HasActivityPassport(activityThemeId)
end


-- 新的接口
--------------------------------------------------------------------------------


local function ConstructPackageList(packages)
	local ret = {}

	for k, v in pairs(packages.PackageTimeConfigList) do
		-- 这个iapId是后台生成的唯一礼包id，会一直递增；不是IAPPackage对应的IAPPackageID
		local iapId = v.IAPID
		local startTime = v.StartTime
		local sellTime = v.SellTime
		local endTime = v.EndTime
		local price = v.Price
		local name = v.Name
		local desc = v.Desc
		local buttonDesc = v.ButtonDesc
		local type = v.Type    -- 0:推荐礼包,1:周礼包,2:月礼包,3:活动礼包
		local sort = v.Sort
		local isBuy = v.IsBuy
		local rewards = {}
		local isPreSell = sellTime > startTime --sellTime
		for rewardIdx = 1, #v.Rewards do
			local rewardItem = v.Rewards[rewardIdx]
			table.insert(rewards, {id = rewardItem.Value, num = rewardItem.Num})
		end

		ret[iapId] = {
			startTime = startTime,
			sellTime = sellTime,
			endTime = endTime,
			price = price,
			name = name,
			desc = desc,
			buttonDesc = buttonDesc,
			rewards = rewards,
			storeId = ConfigUtils.GetPackageIapStoreId(price),
			rate = v.PackageRate,
			icon = v.Icon,
			type = type,
			sort = sort,
			isPreSell = isPreSell,
			isBuy = isBuy,
		}
	end

	return ret
end


function GameData.SetIapPackageList(packages)
	packages = packages or {}
	log("iap packages: "..Helper.Format(packages))

	_iapPackageList = ConstructPackageList(packages)
	GameNotifier.Notify(GameEvent.IapPackageChanged)
end

---获取可显示的礼包(包括预售和普通的在时间范围内的礼包)
function GameData.GetActiveIapPackage()
	local serverTime = this.GetServerTime()
	for iapId, info in pairs(_iapPackageList) do
		local startTime = info.startTime
		local endTime = info.endTime
		if startTime <= serverTime and serverTime < endTime and not this.IsIapReallyCompleted(iapId) then
			return iapId, endTime
		end
	end
	return nil
end

function GameData.IsIapCompleted(iapId)
	for idx = 1, #_completedIapList do
		if iapId == _completedIapList[idx].id then
			if ConfigUtils.IsPackageIap(iapId) then
				return true
			else
				local payTime = _completedIapList[idx].time
				local startTime = ConfigUtils.GetStartTimeOfDoubleIap(iapId)
				if payTime >= startTime then
					return true
				end
			end
		end
	end

	return false
end

function GameData.IsIapReallyCompleted(iapId)
	local iapInfo = this.GetIapPackageInfo(iapId)
	if iapInfo.type == 1 or iapInfo.type == 2 then  -- mark for lz: isBuy 每周每月礼包可以多次购买
		return false
	end
	if this.IsIapCompleted(iapId) then
		return true
	end

	if IAPManager.IsIapCompleted(iapId) then
		return true
	end

	return false
end

function GameData.GetIapPackageInfo(iapId)
	local iapData = _iapPackageList[iapId]
	if iapData then
		return iapData
	else
		if iapId == _customDetailPackageData.id then
			return _customDetailPackageData
		end
	end
	XDebug.Log("LZ", "未找到对应的iapId!")
	return nil
end

function GameData.IsPreSellIapId(iapId)
	local bIsPreSell = nil
	local strPreSellTime = nil
	local strEndTime = nil
	local iapPackageList = this.GetActiveIapPackages()
	for idx = 1, #iapPackageList do
		local info = GameData.GetIapPackageInfo(iapPackageList[idx])
		if iapId == info.id then
			bIsPreSell = info.sellTime > info.EndTime
			strPreSellTime = info.sellTime
			strEndTime = info.endTime
		end
	end
	return bIsPreSell, strPreSellTime, strEndTime
end

function GameData.GetActiveIapPackageByType(type)
	local giftType = nil
	local list = {}
	if type == EMallModuleNames.RecommendGift then
		giftType = 0
		local customPackage = this.GetActiveCustomDetailPackageData()
		if customPackage then
			table.insert(list, customPackage)
		end
	elseif type == EMallModuleNames.WeeklyGift then
		giftType = 1
	elseif type == EMallModuleNames.MonthlyGift then
		giftType = 2
	elseif type == EMallModuleNames.CharacterGift then
		giftType = 3
	else
		XDebug.LogError("LZ", "invalid type:", type)
	end
	local iapPackageList = GameData.GetActiveIapPackages()
	for idx = 1, #iapPackageList do
		local info = GameData.GetIapPackageInfo(iapPackageList[idx])
		if info.type == giftType then
			local iapType = ConfigUtils.GetItemTypeFromId(iapPackageList[idx])
			local b_IsLimit = info.type == EMallModuleNames.RecommendGift and iapType == ItemType.CustomPackage
			table.insert(list, {
				id = iapPackageList[idx],
				startTime = info.startTime,
				endTime = info.endTime,
				price = info.price,
				name = info.name,
				desc = info.desc,
				buttonDesc = info.buttonDesc,
				rewards = info.rewards,
				rate = info.rate or 0,
				icon = info.icon,
				isLimit = b_IsLimit,
				type = info.type,
				sellTime = info.sellTime,
				pTxtLimitTime = nil,
				IsPreSell = info.sellTime > info.startTime, -- startTime
				sort = info.sort,
				isBuy = info.isBuy,
			})
		end
	end
	return list
end

function GameData.GetActiveIapPackages()
	local serverTime = this.GetServerTime()
	local iapList = {}
	for iapId, info in pairs(_iapPackageList) do
		local startTime = info.startTime
		local endTime = info.endTime
		if startTime <= serverTime and serverTime < endTime and not this.IsIapReallyCompleted(iapId) then
			table.insert(iapList, iapId)
		end
	end
	return iapList
end

function GameData.GetActiveCharacterIapPackages()
	local serverTime = this.GetServerTime()
	local characterTbl = {}
	for iapId, info in pairs(_iapPackageList) do
		local startTime = info.startTime
		local endTime = info.endTime
		if info.type == 3 then
			if startTime <= serverTime and serverTime < endTime and not this.IsIapReallyCompleted(iapId) then
				characterTbl[iapId] = info
				characterTbl[iapId].id = iapId
			end
		end

	end
	return characterTbl
end

function GameData.GetActiveCharacterIapPackageList()
	local serverTime = this.GetServerTime()
	local list = {}
	for iapId, info in pairs(_iapPackageList) do
		local startTime = info.startTime
		local endTime = info.endTime
		if info.type == 3 then
			if startTime <= serverTime and serverTime < endTime and not this.IsIapReallyCompleted(iapId) then
				table.insert(list, iapId)
			end
		end
	end
	return list
end

function GameData.HasActiveIap(module)
	if module == EMallModuleNames.DiamondGift then
		return false
	elseif module == EMallModuleNames.MonthCardGift then
		return false
	else
		local list = this.GetActiveIapPackageByType(module)
		if not Helper.IsEmpty(list) then
			return #list > 0
		end
		return false
	end

end

function GameData.GetIapPackagePurchaseStatus(iapId)
	local purchaseStatus = EMallIapPurchaseStatus.CanBuy
	local iapInfo = this.GetIapPackageInfo(iapId)
	if (iapInfo.type == 1 or iapInfo.type == 2) and iapInfo.isBuy then  -- 每周每月礼包优先使用服务器的参数
		purchaseStatus = EMallIapPurchaseStatus.HasBoughtInServer
	else
		local currentTime = GameData.GetServerTime()
		local endTime = iapInfo.endTime
		if endTime - currentTime > 0 then
			local hasPreSell = iapInfo.isPreSell
			if this.CanBuyPackage(iapInfo.rewards) then
				if hasPreSell then
					local leftSellTime = iapInfo.sellTime - currentTime
					if leftSellTime > 0 then
						purchaseStatus = EMallIapPurchaseStatus.PreSell
					end
				end
			else
				purchaseStatus = EMallIapPurchaseStatus.HasBought
			end
		else
			purchaseStatus = EMallIapPurchaseStatus.OutDate
		end
	end
	return purchaseStatus
end


function GameData.CanBuyPackage(rewards)
	if this.HasPackageAnyOneReward(rewards) then
		return false
	end
	return true
end
--------------------------------------------------------------------------------





