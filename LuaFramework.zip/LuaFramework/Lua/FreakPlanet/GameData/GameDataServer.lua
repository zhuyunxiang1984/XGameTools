local this = GameData

local _serverTime = nil

local _gameData = {
	---gold(金币)
	ownGold = 0,
	--- diamond(玉璧)
	ownDiamond = 0,
	--- team limit(探索小队数量，Max=4)
	teamLimit = 0,
	--- tokens 卡池抽奖使用的道具 (瓶盖)
	ownTokens = {
		--{ 1 = { Num = 3, TokenId = 330001 }, 2 = { Num = 0, TokenId = 330003 } }
	},
	--- unlocked Planets
	unlockPlanets = {
		-- PlanetId001 = {},
	},
	--- explored planet areas
	unlockPlanetAreas = {
		-- areaId001 = {},
	},
	--- unlock characters
	unlockCharacters = {
		-- CharacterId001 = {equipments = {{id = id001, level = 3, {id = id002, level = 1}}, skin = 120018, appearance = 0, level = 1, stage = 1},
	},
	--- unlock goods
	unlockGoods = {
		-- GoodsId001 = 0
	},
	--- 实验室解锁的配方
	unlockLabRecipes = {
		--labRecipe001 = 1, labRecipe002 = 1,
	},

	--- unlock pets
	unlockPets = {
		-- petId001 = {num = 4, planet = planetId001}
	},
	--- unlock challenges
	unlockChallenges = {
		-- challengeId001 = {win = 0, lose = 0, maxStar = 0, minRound = 0},
	},
	--- unlock events(日志)
	unlockEvents = {
		-- eventId001 = 1,
	},
	--- unlock postcards(明信片)
	unlockPostcards = {
		-- cardId001 = unlockTime
	},
	-- unlock room pieces
	unlockRoomPieces = {
		-- roomPieceId001 = 1,
	},
	--- 家具
	unlockFurniture = {

	},
	--- 会员积分存钱罐
	MoneyBoxReward = {

	},

}

----------------------------------------------------------------
local _teamGroups = {
	--challenge = {{characters = {}, pet = nil, name = "xxx"}, ...},
	--explore = {{characters = {}, pet = nil, name = "xxx"}, ...},
	--workshop = {{characters = {}, pet = nil, name = "xxx"}, ...},
}
----------------------------------------------------------------
-- temp data
local recordedAreaData = nil

----------------------------------------------------------------
-- init user data from server
function GameData.InitGameData(data)
	-- server data
	_gameData = {}
	_gameData.ownGold = data.BaseInfo.Gold
	_gameData.ownDiamond = data.BaseInfo.Diamond
	-- default limit
	_gameData.teamLimit = data.BaseInfo.TeamUnlockCount or 0
	-- tokens
	_gameData.ownTokens = {}
	local tokenList = data.TokenList or {}
	log("ownTokens:" .. Helper.Format(data.TokenList))
	for idx = 1, #tokenList do
		local tokenId = tokenList[idx].TokenId
		_gameData.ownTokens[tokenId] = tokenList[idx].Num
	end
	-- characters
	_gameData.unlockCharacters = {}
	--log("character list: "..Helper.Format(data.CharList))
	for idx = 1, #data.CharList do
		local id = data.CharList[idx].Id
		local equipments = ConfigUtils.CheckEquipments(id, data.CharList[idx].EquipIds)
		local skinId = data.CharList[idx].SkinId or INVALID_ID_0
		local appearanceId = data.CharList[idx].AppearanceId or INVALID_ID_0

		_gameData.unlockCharacters[id] = {
			equipments = equipments,
			skin = skinId,
			appearance = appearanceId,
			level = data.CharList[idx].Level,
			stage = data.CharList[idx].Stage,
		}
	end
	-- goods
	_gameData.unlockGoods = {}
	for idx = 1, #data.GoodsList do
		local id = data.GoodsList[idx].Id
		local num = data.GoodsList[idx].Num
		_gameData.unlockGoods[id] = num
	end
	-- lab recipes
	_gameData.unlockLabRecipes = {}
	local labRecipeList = data.LabRecipeList or {}
	for idx = 1, #labRecipeList do
		local id = labRecipeList[idx].Id
		-- filter space travel recipe
		--if ConfigUtils.IsNormalLabRecipe(id) then
		local type = ConfigUtils.GetLabRecipeType(id)
		if type == LabRecipeType.Normal or type == LabRecipeType.HomeFurniture then
			_gameData.unlockLabRecipes[id] = 1
		end
	end
	-- challenges
	_gameData.unlockChallenges = {}
	local challengeList = data.ChallengeList or {}
	for idx = 1, #challengeList do
		local challengeId = challengeList[idx].Id
		local win = challengeList[idx].Win or 0
		local lose = challengeList[idx].Failed or 0
		local maxStar = challengeList[idx].MaxStar or 0
		local minRound = challengeList[idx].MinRound or 0
		_gameData.unlockChallenges[challengeId] = { win = win, lose = lose, maxStar = maxStar, minRound = minRound}
	end
	-- pets
	_gameData.unlockPets = {}
	local petList = data.PetList or {}
	for idx = 1, #petList do
		local petId = petList[idx].PetId
		local petNum = petList[idx].Num
		local petPlanetId = petList[idx].PlanetId
		_gameData.unlockPets[petId] = {num = petNum, planet = petPlanetId}
	end
	-- events
	_gameData.unlockEvents = {}
	local eventList = data.EventList or {}
	for idx = 1, #eventList do
		local eventId = eventList[idx].EventId
		_gameData.unlockEvents[eventId] = 1
	end
	-- postcards
	_gameData.unlockPostcards = {}
	local postcardList = data.PostCardList or {}
	for idx = 1, #postcardList do
		local postcardId = postcardList[idx].Id
		local unlockTime = postcardList[idx].GetTime

		_gameData.unlockPostcards[postcardId] = unlockTime
	end
	-- room pieces
	_gameData.unlockRoomPieces = {}
	local roomPieceList  = data.RoomPieceList or {}
	for idx = 1, #roomPieceList do
		local roomPieceId = roomPieceList[idx].Id
		_gameData.unlockRoomPieces[roomPieceId] = 1
	end

	-- skin
	_gameData.unlockSkins = {}
	local skinList = data.SkinList or {}
	for i,v in ipairs(skinList) do
		_gameData.unlockSkins[v.SkinId] = 1
	end

	_gameData.unlockFurniture = {}
	local furnitureList = data.FurnitureList or {}
	for idx = 1, #furnitureList do
		local info = furnitureList[idx]
		local furnitureId = info[1]
		local furnitureNum = info[2]
		_gameData.unlockFurniture[furnitureId] = furnitureNum
	end

	_gameData.MoneyBoxReward = {}
	local moneyBoxList = data.MoneyBoxInfo or {}
	for idx = 1, #moneyBoxList do
		local info = moneyBoxList[idx]
		local rewardId = info[1]
		local rewardNum = info[2]
		_gameData.MoneyBoxReward[rewardId] = rewardNum
	end

	this.InitAreaData(recordedAreaData)

	-- local data
	this.Save()
end

function GameData.RecordAreaData(data)
	recordedAreaData = data
end

function GameData.InitAreaData(data)
	_gameData.unlockPlanetAreas = {}

	local areaList = data.AreaList or {}

	for idx = 1, #areaList do
		local areaId = areaList[idx].AreaId
		local status, exploreData, usedCharacters, usedPet = this.ConstructExploreData(areaList[idx])
		_gameData.unlockPlanetAreas[areaId] = exploreData
		if status > 0 then
			this.SetPlanetAreaExploreCharacters(areaId, usedCharacters)
			this.SetPlanetAreaExplorePet(areaId, usedPet)
		end
	end

	this.CheckUnlockPlanets()
end

function GameData.ConstructExploreData(data)
	local settleStatus = data.SettleStatus or 0
	local totalExploreTime = data.SumCostTime

	local exploreData = nil
	local usedCharacters = {}
	local usedPet = nil

	if settleStatus > 0 then
		local startTime = data.StartTime
		local endTime = data.EndTime
		local costTime = data.CostTime
		local characters = data.CharList or {}
		local pet = data.PetId or INVALID_ID_0
		local dropList = data.DropList or {}
		local catchItemList = data.CatchItemList or {}
		local eventList = data.EventList or {}
		local foodList = data.FoodList or {}
		local enemyList = data.EnemyList or {}
		-- if do speed up, the end time in server is 0
		endTime = math.max(endTime, startTime)
		-- copy the characters
		Helper.CopyTable(usedCharacters, characters)
		-- use pet
		if ConfigUtils.IsValidItem(pet) then
			usedPet = pet
		end

		exploreData = {
			settleStatus = settleStatus,
			totalExploreTime = totalExploreTime,
			startTime = startTime,
			endTime = endTime,
			costTime = costTime,
			pet = pet,
			dropList = dropList,
			catchItemList = catchItemList,
			eventList = eventList,
			foodList = foodList,
			enemyList = enemyList,
		}
	else
		exploreData = {
			settleStatus = settleStatus,
			totalExploreTime = totalExploreTime,
		}
	end

	return settleStatus, exploreData, usedCharacters, usedPet
end
----------------------------------------------------------------
-- data
function GameData.HasServerTime()
	return _serverTime ~= nil
end

function GameData.GetServerTime()
	assert(_serverTime ~= nil, "server time not set")
	return math.floor(_serverTime or 0)
end

function GameData.SetServerTime(t)
	XDebug.Log('GGYY', string.format("servertime: %d date:%s", t, os.date("%Y-%m-%d-%H:%M", t)))
	_serverTime = t
end

function GameData.StepServerTime(t)
	if _serverTime == nil then
		return
	end

	_serverTime = _serverTime + t
end

function GameData.AddMoney(itemType, num)
	if itemType == ItemType.Gold then
		_gameData.ownGold = _gameData.ownGold + num
		if num ~= 0 then
			GameNotifier.Notify(GameEvent.MoneyChanged, itemType)
		end
	elseif itemType == ItemType.Diamond then
		_gameData.ownDiamond = _gameData.ownDiamond + num
		if num ~= 0 then
			GameNotifier.Notify(GameEvent.MoneyChanged, itemType)
		end
	else
		assert(false, "money is gold, diamond or arena token: "..tostring(itemType))
	end
end

function GameData.UseMoney(itemType, num)
	if itemType == ItemType.Gold then
		_gameData.ownGold = _gameData.ownGold - num
		assert(_gameData.ownGold >= 0, "gold is not enough")
		if num ~= 0 then
			GameNotifier.Notify(GameEvent.MoneyChanged, itemType)
		end
	elseif itemType == ItemType.Diamond then
		_gameData.ownDiamond = _gameData.ownDiamond - num
		assert(_gameData.ownDiamond >= 0, "diamond is not enough")
		if num ~= 0 then
			GameNotifier.Notify(GameEvent.MoneyChanged, itemType)
		end
	else
		assert(false, "money is gold, diamond or arena token: "..tostring(itemType))
	end
end

function GameData.GetMoney(itemType)
	if itemType == ItemType.Gold then
		return _gameData.ownGold
	elseif itemType == ItemType.Diamond then
		return _gameData.ownDiamond
	else
		assert(false, "money is gold, diamond or arena token: "..tostring(itemType))
	end
end

function GameData.SetMoney(itemType, num)
	if itemType == ItemType.Gold then
		if _gameData.ownGold ~= num then
			_gameData.ownGold = num
			GameNotifier.Notify(GameEvent.MoneyChanged, itemType)
		end
	elseif itemType == ItemType.Diamond then
		if _gameData.ownDiamond ~= num then
			_gameData.ownDiamond = num
			GameNotifier.Notify(GameEvent.MoneyChanged, itemType)
		end
	else
		assert(false, "money is gold, diamond or arena token: "..tostring(itemType))
	end
end
----------------------------------------------------------------
function GameData.CollectItem(itemId, itemNum, showNew)
	local itemType = ConfigUtils.GetItemTypeFromId(itemId)
	local unlocked = this.IsItemUnlocked(itemId)
	if itemType == ItemType.Gold or itemType == ItemType.Diamond then
		this.AddMoney(itemType, itemNum)
	elseif itemType == ItemType.Token then
		this.CollectToken(itemId, itemNum)
	elseif itemType == ItemType.Goods then
		this.CollectGoods(itemId, itemNum)
	elseif itemType == ItemType.Character then
		this.UnlockCharacter(itemId)
	elseif itemType == ItemType.LabRecipe then
		this.UnlockLabRecipe(itemId)
	elseif itemType == ItemType.Pet then
		this.UnlockPet(itemId, itemNum)
	elseif itemType == ItemType.PlanetArea then
		this.UnlockPlanetArea(itemId)
	elseif itemType == ItemType.Event then
		this.UnlockEvent(itemId)
	elseif itemType == ItemType.WorkShop then
		this.UnlockWorkShop(itemId)
	elseif itemType == ItemType.RoomPiece then
		this.UnlockRoomPiece(itemId)
	elseif itemType == ItemType.Skin then
		this.UnlockSkin(itemId)
	elseif itemType == ItemType.HomeFurniture then
		this.CollectFurniture(itemId, itemNum)
	elseif itemType == ItemType.ActivityPassport then
		local activityThemeId = this.GetCurrentActivityTheme()
		if activityThemeId then
			this.SetActivityPassort(activityThemeId)
		end
	elseif itemType == ItemType.Postcard then
		local type = ConfigUtils.GetPostcardType(itemId)
		-- 仅支持活动明信片的解锁,成就明信片在发送GetGoalReward协议时服务器解锁
		if type == EnumPostcardType.Activity then
			GameData.UnlockPostcard(itemId)
		end

	else
		assert(false, "un-handled item type: "..tostring(itemType))
	end

	showNew = showNew or false
	if showNew then
		NewItemCtrl.ShowNewItem(itemId, itemNum, unlocked)
	end
end

function GameData.ConsumeItem(itemId, itemNum)
	local itemType = ConfigUtils.GetItemTypeFromId(itemId)
	if itemType == ItemType.Gold or itemType == ItemType.Diamond then
		this.UseMoney(itemType, itemNum)
	elseif itemType == ItemType.Token then
		this.ConsumeToken(itemId, itemNum)
	elseif itemType == ItemType.Goods then
		this.ConsumeGoods(itemId, itemNum)
	elseif itemType == ItemType.HomeFurniture then
		this.ConsumeFurniture(itemId, itemNum)
	else
		assert(false, "un-handled item type: "..tostring(itemType))
	end
end

function GameData.GetItemNum(itemId)
	local itemType = ConfigUtils.GetItemTypeFromId(itemId)
	if itemType == ItemType.Gold or itemType == ItemType.Diamond then
		return this.GetMoney(itemType)
	elseif itemType == ItemType.Token then
		return this.GetTokenNum(itemId)
	elseif itemType == ItemType.Goods then
		return this.GetGoodsNum(itemId)
	elseif itemType == ItemType.Pet then
		return this.GetPetNum(itemId)
	elseif itemType == ItemType.HomeFurniture then
		return this.GetFurnitureNum(itemId)
	elseif itemType == ItemType.Character or
		itemType == ItemType.Planet or
		itemType == ItemType.LabRecipe or
		itemType == ItemType.Event or
		itemType == ItemType.WorkShop or
		itemType == ItemType.Challenge or
		itemType == ItemType.Equipment or
		itemType == ItemType.Skin or
		itemType == ItemType.RoomPiece then
		-- only allow to have one
		if this.IsItemUnlocked(itemId) then
			return 1
		else
			return 0
		end
	else
		return 0
		--assert(false, "un-handled item type: "..tostring(itemType))
	end
end

function GameData.IsItemUnlocked(itemId)
	local itemType = ConfigUtils.GetItemTypeFromId(itemId)
	if itemType == ItemType.Gold or itemType == ItemType.Diamond then
		return true
	elseif itemType == ItemType.Token then
		return this.IsTokenUnlocked(itemId)
	elseif itemType == ItemType.Goods then
		return this.IsGoodsUnlocked(itemId)
	elseif itemType == ItemType.Equipment then
		return this.IsEquipmentUnlocked(itemId)
	elseif itemType == ItemType.Character then
		return this.IsCharacterUnlocked(itemId)
	elseif itemType == ItemType.Skin then
		return this.IsSkinUnlocked(itemId)
	elseif itemType == ItemType.Planet then
		return this.IsPlanetUnlocked(itemId)
	elseif itemType == ItemType.LabRecipe then
		return this.IsLabRecipeUnlocked(itemId)
	elseif itemType == ItemType.Pet then
		return this.IsPetUnlocked(itemId)
	elseif itemType == ItemType.PlanetArea then
		return this.IsPlanetAreaUnlocked(itemId)
	elseif itemType == ItemType.Event then
		return this.IsEventUnlocked(itemId)
	elseif itemType == ItemType.WorkShop then
		return this.IsWorkShopUnlocked(itemId)
	elseif itemType == ItemType.Challenge then
		return this.IsChallengeCompleted(itemId)
	elseif itemType == ItemType.RoomPiece then
		return this.IsRoomPieceUnlocked(itemId)
	elseif itemType == ItemType.HomeFurniture then
		return this.IsHomeFurnitureUnlocked(itemId)
	elseif itemType == ItemType.ActivityPassport then
		return true
	elseif itemType == ItemType.Postcard then
		return true
	else
		assert(false, "un-handled item type: "..tostring(itemType))
	end
end
----------------------------------------------------------------
-- lab recipe
function GameData.GetUnlockedLabRecipesByType(type)
	local recipes = {}
	for k, v in pairs(_gameData.unlockLabRecipes) do
		local labRecipeType = ConfigUtils.GetLabRecipeType(k)
		if v == 1 and labRecipeType == type then
			table.insert(recipes, k)
		end
	end
	return recipes
end


function GameData.UnlockLabRecipe(recipeId)
	-- filter space travel recipe
	local type = ConfigUtils.GetLabRecipeType(recipeId)
	if type == LabRecipeType.Normal or type == LabRecipeType.HomeFurniture then
		if _gameData.unlockLabRecipes[recipeId] == nil then
			_gameData.unlockLabRecipes[recipeId] = 1
		end
	end
end

function GameData.IsLabRecipeUnlocked(recipeId)
	if _gameData.unlockLabRecipes[recipeId] == nil then
		return false
	end

	return true
end

function GameData.DoCraft(craftGoods, costGoods)
	local craftGoalData = {}
	for idx = 1, #craftGoods do
		local goodsId = craftGoods[idx].value
		local goodsNum = craftGoods[idx].num
		this.CollectItem(goodsId, goodsNum, false)
		local e = this.SetupItemGoalData(goodsId, goodsNum)
		table.insert(craftGoalData, e)
	end

	local craftUseGoalData = {}
	for k, v in pairs(costGoods) do
		this.ConsumeItem(k, v)
		local e = this.SetupItemGoalData(k, v)
		table.insert(craftUseGoalData, e)
	end

	this.DoGoalSettle(TriggerType.Craft, craftGoalData)
	this.DoGoalSettle(TriggerType.CraftUse, craftUseGoalData)
	this.CheckAndHintGoalsOfCurrentCountType()
end

function GameData.IsLabRecipeUnlocked(recipeId)
	if _gameData.unlockLabRecipes[recipeId] == nil then
		return false
	end

	return true
end

function GameData.DoCraft(craftGoods, costGoods)
	local craftGoalData = {}
	for idx = 1, #craftGoods do
		local goodsId = craftGoods[idx].value
		local goodsNum = craftGoods[idx].num
		this.CollectItem(goodsId, goodsNum, false)
		local e = this.SetupItemGoalData(goodsId, goodsNum)
		table.insert(craftGoalData, e)
	end

	local craftUseGoalData = {}
	for k, v in pairs(costGoods) do
		this.ConsumeItem(k, v)
		local e = this.SetupItemGoalData(k, v)
		table.insert(craftUseGoalData, e)
	end

	this.DoGoalSettle(TriggerType.Craft, craftGoalData)
	this.DoGoalSettle(TriggerType.CraftUse, craftUseGoalData)
	this.CheckAndHintGoalsOfCurrentCountType()
end
----------------------------------------------------------------

-- event
function GameData.IsEventUnlocked(itemId)
	return _gameData.unlockEvents[itemId] ~= nil
end

function GameData.UnlockEvent(itemId)
	_gameData.unlockEvents[itemId] = 1
end

function GameData.GetEventUnlockOfArea(areaId)
	local eventList = ConfigUtils.GetAreaEventList(areaId)
	local totalNum = #eventList
	local unlockNum = 0

	for idx = 1, totalNum do
		local eventId = eventList[idx]
		if this.IsEventUnlocked(eventId) then
			unlockNum = unlockNum + 1
		end
	end

	return unlockNum, totalNum
end
----------------------------------------------------------------
-- token
function GameData.IsTokenUnlocked(itemId)
	return _gameData.ownTokens[itemId] ~= nil
end

function GameData.CollectToken(itemId, itemNum)
	local preNum = _gameData.ownTokens[itemId] or 0
	local curNum = preNum + itemNum
	if preNum ~= curNum then
		_gameData.ownTokens[itemId] = curNum
		GameNotifier.Notify(GameEvent.TokenChanged, itemId)
	end
end

function GameData.ConsumeToken(itemId, itemNum)
	local preNum = _gameData.ownTokens[itemId] or 0
	local curNum = preNum - itemNum
	assert(curNum >= 0, "the token num should always >= 0: "..tostring(itemId))
	if preNum ~= curNum then
		_gameData.ownTokens[itemId] = curNum
		GameNotifier.Notify(GameEvent.TokenChanged, itemId)
	end
end

function GameData.SetTokenNum(itemId, itemNum)
	assert(itemNum >= 0, "the token num should always >= 0: "..tostring(itemId))
	local preNum = _gameData.ownTokens[itemId] or 0
	if preNum ~= itemNum then
		_gameData.ownTokens[itemId] = itemNum
		GameNotifier.Notify(GameEvent.TokenChanged, itemId)
	end
end

function GameData.GetTokenNum(itemId)
	return _gameData.ownTokens[itemId] or 0
end
----------------------------------------------------------------
-- pets
function GameData.UnlockPet(petId, petNum)
	if _gameData.unlockPets[petId] == nil then
		_gameData.unlockPets[petId] = {num = 0}
		if this.IsModuleUnlocked(ModuleNames.Warehouse) then
			this.AddNewCheck(petId)
		end
	end

	_gameData.unlockPets[petId].num = _gameData.unlockPets[petId].num + petNum
end

function GameData.IsPetUnlocked(petId)
   	return _gameData.unlockPets[petId] ~= nil
end

function GameData.GetPetNum(petId)
	if _gameData.unlockPets[petId] == nil then
		return 0
	end

    return _gameData.unlockPets[petId].num or 0
end

function GameData.HasUnlockedPet()
	for k, v in pairs(_gameData.unlockPets) do
        return true
    end

    return false
end

function GameData.GetPetLevel(petId)
	if _gameData.unlockPets[petId] == nil then
		return 1
	end

	local num = GameData.GetPetNum(petId)
	return ConfigUtils.GetPetLevelByNum(petId, num)
end

function GameData.SetPetPlanetId(petId, planetId)
	assert(_gameData.unlockPets[petId] ~= nil, "pet is not unlocked: "..tostring(petId))
    _gameData.unlockPets[petId].planet = planetId
end

function GameData.GetUnlockPetList()
	local ret = {}

    for k, v in pairs(_gameData.unlockPets) do
        table.insert(ret, k)
    end

	return ret
end

function GameData.GetUnlockPetListInPlanetId(planetId)
	local ret = {}

    for k, v in pairs(_gameData.unlockPets) do
        if v.planet == planetId then
            table.insert(ret, k)
        end
    end

	return ret
end
----------------------------------------------------------------
-- room piece
function GameData.UnlockRoomPiece(roomPieceId)
	if _gameData.unlockRoomPieces[roomPieceId] == nil then
		_gameData.unlockRoomPieces[roomPieceId] = 1
	end
end

function GameData.IsRoomPieceUnlocked(roomPieceId)
	return _gameData.unlockRoomPieces[roomPieceId] ~= nil
end
----------------------------------------------------------------
-- skins
function GameData.GetCharacterDefaultSkin(characterId)
	local stage = GameData.GetCharacterCurrentStage(characterId)
	return ConfigUtils.GetDefaultSkinOfCharacter(characterId, stage)
end

function GameData.GetCharacterSkin(characterId)
	local unlocked = this.IsCharacterUnlocked(characterId)

	if unlocked then
		local skinId = _gameData.unlockCharacters[characterId].skin
		if ConfigUtils.IsValidItem(skinId) then
			return skinId
		end
	end

	return this.GetCharacterDefaultSkin(characterId)
end

function GameData.IsCharacterSkinChanged(characterId)
	local unlocked = this.IsCharacterUnlocked(characterId)

	if unlocked then
		local currentSkin = _gameData.unlockCharacters[characterId].skin
		if ConfigUtils.IsValidItem(currentSkin) and not ConfigUtils.IsDefaultSkin(currentSkin) then
			return true
		end
	end

	return false
end

function GameData.GetCharacterIcon(characterId, useDefaultIcon)
	useDefaultIcon = useDefaultIcon or false
	local skinId = this.GetCharacterSkin(characterId)
	if useDefaultIcon then
		skinId = this.GetCharacterDefaultSkin(characterId)
	end
	return ConfigUtils.GetSkinCharacterIcon(skinId)
end

function GameData.SetCharacterSkin(characterId, skinId)
	local unlocked = this.IsCharacterUnlocked(characterId)
	assert(unlocked, "character is not unlocked: "..tostring(characterId).."; can not set skin")
	if not ConfigUtils.IsValidItem(skinId) then
		skinId = INVALID_ID_0
	end

	_gameData.unlockCharacters[characterId].skin = skinId
	GameNotifier.Notify(GameEvent.CharacterSkinChanged, characterId)
end

function GameData.IsSkinUnlocked(skinId)
	if _gameData.unlockSkins[skinId] == 1 then
		return true
	end
	local challenge = ConfigUtils.GetSkinUnlockChallenge(skinId)
	return challenge and this.IsChallengeCompleted(challenge)
end

function GameData.GetUnlockSkins()
	local ret = {}
	
	for characterId, v in pairs(_gameData.unlockCharacters) do
		local skinList = ConfigUtils.GetCharacterSkinList(characterId)
		for idx = 1, #skinList do
			if this.IsSkinUnlocked(skinList[idx]) then
				table.insert(ret, skinList[idx])
			end
		end
	end

	return ret
end

--获取指定角色的所有已解锁皮肤
function GameData.GetUnlockSkinsByCharacter(characterId)
	local ret = {}
	local skinList = ConfigUtils.GetCharacterSkinList(characterId)
	for i, skin in ipairs(skinList) do
		if this.IsSkinUnlocked(skin) then
			table.insert(ret, skin)
		end
	end
	return ret
end

function GameData.UnlockSkin(skinId)
	_gameData.unlockSkins[skinId] = 1
end
----------------------------------------------------------------
-- characters
function GameData.GetUnlockCharacters()
	local ret = {}

	for k, v in pairs(_gameData.unlockCharacters) do
		table.insert(ret, k)
	end

	return ret
end

function GameData.GetUnlockCharactersWithSkills()
	local ret = {}

	for k, v in pairs(_gameData.unlockCharacters) do
		if this.IsCharacterSkillActivated(k) then
			table.insert(ret, k)
		end
	end

	return ret
end

function GameData.GetUnlockCharactersWithSkins()
	local ret = {}

	for k, v in pairs(_gameData.unlockCharacters) do
		if this.IsCharacterSkinChanged(k) then
			table.insert(ret, k)
		end
	end

	return ret
end

function GameData.GetUnlockCharacterCount()
	return Helper.TableLength(_gameData.unlockCharacters)
end

function GameData.UnlockCharacter(characterId)
	if _gameData.unlockCharacters == nil then
		_gameData.unlockCharacters = {}
	end

	if _gameData.unlockCharacters[characterId] == nil then
		if this.IsModuleUnlocked(ModuleNames.CharacterList) then
			this.AddNewCheck(characterId)
		end

		local equipments = ConfigUtils.CheckEquipments(characterId, nil)
		local skinId = INVALID_ID_0
		_gameData.unlockCharacters[characterId] = {
			equipments = equipments,
			skin = skinId,
			appearance = 0,
			level = 1,
			stage = 1,
		}
		-- check node
		NodeHelper.OnCharacterUnlocked()
	end
end

function GameData.IsCharacterUnlocked(characterId)
	if _gameData.unlockCharacters == nil then
		return false
	end

	return _gameData.unlockCharacters[characterId] ~= nil
end

function GameData.IsCharacterPromoteMatch(characterId)
	local currentStage = this.GetCharacterCurrentStage(characterId)
	local stageLimit = ConfigUtils.GetCharacterStageLimit(characterId)
	if currentStage == stageLimit then
		return false
	end

	local currentLevel = this.GetCharacterLevel(characterId)
	local levelLimit = ConfigUtils.GetCharacterLevelLimitAtStage(characterId, currentStage)
	if currentLevel < levelLimit then
		return false
	end

	local promoteGoodsId, promoteGoodsNum = ConfigUtils.GetCharacterUpStageCost(characterId, currentStage)
	local curNum = GameData.GetItemNum(promoteGoodsId)
	return curNum >= promoteGoodsNum
end

function GameData.IsCharacterEquipmentUpgradeMatch(characterId)
	local equipmentList = this.GetCharacterUnlockedEquipments(characterId)
    for idx = 1, #equipmentList do
        local equipmentId = equipmentList[idx].id
        local equipmentLevel = equipmentList[idx].level
           
        local upgradeMatch = this.IsEquipmentUpgradeMatch(equipmentId, equipmentLevel)
        if upgradeMatch then
        	return true
        end
    end

    return false
end

function GameData.HasMatchedCharacterToPromote()
	for k, v in pairs(_gameData.unlockCharacters) do
		if this.IsCharacterPromoteMatch(k) then
			return true
		end
	end

	return false
end

function GameData.HasMatchedCharacterToUpgradeEquipment()
	for k, v in pairs(_gameData.unlockCharacters) do
		if this.IsCharacterEquipmentUpgradeMatch(k) then
			return true
		end
	end

	return false
end

function GameData.IsCharacterSkillActivated(characterId)
	local curStage = this.GetCharacterCurrentStage(characterId)
	local activatedSkills = ConfigUtils.GetCharacterActivedSkillsAt(characterId, curStage)
	return #activatedSkills > 0
end

function GameData.IsCharacterAtTopStage(characterId)
	local stage = this.GetCharacterCurrentStage(characterId)
	local stageLimit = ConfigUtils.GetCharacterStageLimit(characterId)
	return stage >= stageLimit
end

function GameData.IsCharacterAtTopLevel(characterId)
	local currentLevel = this.GetCharacterLevel(characterId)
	local maxLevel = ConfigUtils.GetCharacterMaxLevel(characterId)
	return currentLevel >= maxLevel
end

function GameData.GetCharacterLevel(characterId)
	if _gameData.unlockCharacters == nil then
		return 1
	end

	local info =  _gameData.unlockCharacters[characterId]
	if info == nil then
		return 1
	end

	local level = info.level or 1
	local maxLevel = ConfigUtils.GetCharacterMaxLevel(characterId)
	if level > (maxLevel + 1) then
		level = 1
	end

	return level
end

function GameData.SetCharacterLevel(characterId, level)
	_gameData.unlockCharacters[characterId].level = level
	GameNotifier.Notify(GameEvent.CharacterLevelChanged, characterId)
end

--
function GameData.GetCharacterAppearance(characterId)
	if not _gameData.unlockCharacters or not _gameData.unlockCharacters[characterId] then
		return 0
	end
	local info = _gameData.unlockCharacters[characterId]
	return info.appearance or 0
end
--
function GameData.SetCharacterAppearance(characterId, appearanceId)
	_gameData.unlockCharacters[characterId].appearance = appearanceId
	GameNotifier.Notify(GameEvent.CharacterAppearanceChanged, characterId)
end

function GameData.GetCharacterCurrentStage(characterId)
	if _gameData.unlockCharacters == nil or _gameData.unlockCharacters[characterId] == nil then
		return 1
	end

	local stage = _gameData.unlockCharacters[characterId].stage or 1
	return stage
end

function GameData.SetCharacterStage(characterId, stage)
	-- ge the cur skin before the stage set
	local curSkinId = this.GetCharacterSkin(characterId)
	_gameData.unlockCharacters[characterId].stage = stage
	local skinChanged = false
	if ConfigUtils.IsDefaultSkin(curSkinId) then
		local newSkinId = ConfigUtils.GetDefaultSkinOfCharacter(characterId, stage)
		if curSkinId ~= newSkinId then
			GameNotifier.Notify(GameEvent.CharacterSkinChanged, characterId)
			skinChanged = true
		end
	end

	GameNotifier.Notify(GameEvent.CharacterStageChanged, characterId)
end

function GameData.GetCharacterEquipments(characterId)
	if _gameData.unlockCharacters == nil or _gameData.unlockCharacters[characterId] == nil then
		return {}
	end

	return _gameData.unlockCharacters[characterId].equipments
end

function GameData.GetCharacterUnlockedEquipments(characterId)
	local equipmentList = this.GetCharacterEquipments(characterId)
	local ret = {}

	for idx = 1, #equipmentList do
		local equipmentId = equipmentList[idx].id
		local challenge = ConfigUtils.GetEquipmentUnlockChallenge(equipmentId)
		if challenge == nil or this.IsChallengeCompleted(challenge) then
			table.insert(ret, {id = equipmentList[idx].id, level = equipmentList[idx].level})
		end
	end

	return ret
end

function GameData.SetCharacterEquipmentLevel(characterId, equipSlot, level)
	local equipments = _gameData.unlockCharacters[characterId].equipments
	local preLevel = equipments[equipSlot].level or 1
	if preLevel ~= level then
		equipments[equipSlot].level = level
	end
end

function GameData.GetCharacterEquipmentLevel(characterId, equipSlot)
	if _gameData.unlockCharacters[characterId] == nil then
		return 1
	end

	local equipments = _gameData.unlockCharacters[characterId].equipments
	local equipmentId = equipments[equipSlot].id
	local level = equipments[equipSlot].level or 1
	local maxLevel = ConfigUtils.GetEquipmentMaxLevel(equipmentId)
	if level > (maxLevel + 1) then
		level = 1
	end

	return level
end

-- if equipment id is not null, want to get the sepcific equipment level and its character
function GameData.GetUnlockedEquipments(equipmentId)
	local ret = {}
	for characterId, characterData in pairs(_gameData.unlockCharacters) do
		local equipments = characterData.equipments or {}
		for idx = 1, #equipments do
			local thisEquipId = equipments[idx].id
			if this.IsEquipmentUnlocked(thisEquipId) and (equipmentId == nil or equipmentId == thisEquipId) then
				local thisEquipLevel = equipments[idx].level
				table.insert(ret, {id = thisEquipId, level = thisEquipLevel, character = characterId})
			end
		end
	end

	return ret
end

function GameData.IsEquipmentUpgradeMatch(equipmentId, equipmentLevel)
	local maxLevel = ConfigUtils.GetEquipmentMaxLevel(equipmentId)
	if equipmentLevel == maxLevel then
		return false
	end

	local upLevelCost = ConfigUtils.GetEquipmentUpgradeCost(equipmentId, equipmentLevel)
	for idx = 1, #upLevelCost do
		local itemId = upLevelCost[idx].Value
		local needNum = upLevelCost[idx].Num
		local curNum = this.GetItemNum(itemId)
		if curNum < needNum then
			return false
		end
	end

	return true
end

function GameData.IsSkinChallengeMatch(skinId)
	-- no challenge
	local challengeId = ConfigUtils.GetSkinUnlockChallenge(skinId)
	if challengeId == nil then
		return false
	end
	-- no need to consume item now
	local unlocked = this.IsChallengeUnlocked(challengeId)
	if unlocked then
		return true
	end

	local unlockCost = ConfigUtils.GetChallengeUnlockCost(challengeId)
	for idx = 1, #unlockCost do
		local itemId = unlockCost[idx].Value
		local needNum = unlockCost[idx].Num
		local curNum = this.GetItemNum(itemId)
		if curNum < needNum then
			return false
		end
	end

	return true
end
----------------------------------------------------------------
-- planets
function GameData.CheckUnlockPlanets()
	local planetMap = {}
	for k, v in pairs(_gameData.unlockPlanetAreas) do
		local planetId = ConfigUtils.GetPlanetOfArea(k)
		if planetMap[planetId] == nil then
			planetMap[planetId] = {}
		end
	end

	_gameData.unlockPlanets = planetMap
	log("unlockPlanets:" .. Helper.Format(_gameData.unlockPlanets))
end

function GameData.IsPlanetUnlocked(planetId)
	return _gameData.unlockPlanets[planetId] ~= nil
end

function GameData.GetUnlockPlanets()
	local ret = {}

	for k, v in  pairs(_gameData.unlockPlanets) do
		table.insert(ret, k)
	end

	return ret
end

function GameData.UnlockPlanetArea(areaId)
	if _gameData.unlockPlanetAreas[areaId] == nil then
		_gameData.unlockPlanetAreas[areaId] = {settleStatus = 0, totalExploreTime = 0}

		this.AddNewCheck(areaId)
		this.CheckUnlockPlanets()
		GameNotifier.Notify(GameEvent.PlanetAreaUnlocked, areaId)
	end
 end

function GameData.GetExploringAreaOfPlanet(planetId)
	for k, v in pairs(_gameData.unlockPlanetAreas) do
		if v.settleStatus > 0 then
			if ConfigUtils.GetPlanetOfArea(k) == planetId then
				return k
			end
		end
	end

	return nil
end

function GameData.GetUnlokcedAreasOfPlanet(planetId)
	local ret = {}
	for k, v in pairs(_gameData.unlockPlanetAreas) do
		if ConfigUtils.GetPlanetOfArea(k) == planetId then
			table.insert(ret, k)
		end
	end

	return ret
end

local function ResultEnemySortFunc(elementA, elementB)
	if elementA == nil or elementB == nil then
		return false
	end

	local valueA = elementA.power
	local valueB = elementB.power

	return valueA < valueB
end

function GameData.GetExploreResultByData(data)
	local exploreCostTime = data.costTime

	local resultdEventList = {}
	local eventRewardItemMap = {}
	local eventList = data.eventList
	for idx = 1, #eventList do
		local eventId = eventList[idx].EventId
		resultdEventList[idx] = eventId
		-- event drop
		local eventRewards = ConfigUtils.GetEventReward(eventId)
		for eventRewardIdx = 1, #eventRewards do
			local eventRewardId = eventRewards[eventRewardIdx].Value
			local preNum = eventRewardItemMap[eventRewardId] or 0
			eventRewardItemMap[eventRewardId] = preNum + eventRewards[eventRewardIdx].Num
		end
	end

	local resultDropList = {}
	local dropList = data.dropList
	for idx = 1, #dropList do
		local dropId = dropList[idx][1]
		local dropNum = dropList[idx][2]
		resultDropList[idx] = {id = dropId, num = dropNum, isEvent = false}
	end

	for k, v in pairs(eventRewardItemMap) do
		table.insert(resultDropList, {id = k, num = v, isEvent = true})
	end

	local resultCatchPetList = {}
	local catchItemList = data.catchItemList
	for catchItemIdx = 1, #catchItemList do
		local catchItemId = catchItemList[catchItemIdx].CatchItemId
		local catchItemStatus = catchItemList[catchItemIdx].Status
		if ConfigUtils.GetGoodsTamePrefab(catchItemId) ~= nil then
			local petList = catchItemList[catchItemIdx].CatchPetList or {}
			XDebug.Log("LZ", "petListCount:", #petList)
			--assert(#petList <= 1, "one catch item can catch one pet at most")
			if #petList > 0 then
				for idx = 1, #petList do
					local pet = petList[idx]
					local petId = pet[1]
					local petState = pet[2]
					-- status: 0 - not used; 1 - catch and not broken; 2 - broken, may catch pet and may not
					-- state: 0 - no catch; 1 - catch and tame; 2 - catch and no tame
					table.insert(resultCatchPetList, {itemId = catchItemId, itemStatus = catchItemStatus, petId = petId, petState = petState})
				end
			else
				-- no catch pet
				table.insert(resultCatchPetList, {itemId = catchItemId, itemStatus = catchItemStatus, petId = -1, petState = 0})
			end
		end
	end

	local resultEnemyList = {}
	local enemyList = data.enemyList
	for idx = 1, #enemyList do
		local enemyId = enemyList[idx][1]
		local enemyPower = enemyList[idx][2]
		local winEnemy= (enemyList[idx][3] > 0)
		local enemyNum = enemyList[idx][4]
		resultEnemyList[idx] = {id = enemyId, power = enemyPower, win = winEnemy, num = enemyNum}
	end

	table.sort(resultEnemyList, ResultEnemySortFunc)

	return exploreCostTime, resultdEventList, resultDropList, resultCatchPetList, resultEnemyList
end

function GameData.GetPlanetAreaExploreResult(planetAreaId)
	local data = _gameData.unlockPlanetAreas[planetAreaId]
	assert(data ~= nil, "planet area is not unlocked: "..tostring(planetAreaId))
	assert(data.settleStatus > 0, "planet area is not exploring: "..tostring(planetAreaId))
	return this.GetExploreResultByData(data)
end

function GameData.GetMeetEnemyListOfArea(planetAreaId)
	local ret = {}

	local enemyList = _gameData.unlockPlanetAreas[planetAreaId].enemyList
	for idx = 1, #enemyList do
		local enemyId = enemyList[idx][1]
		ret[idx] = enemyId
	end

	return ret
end

function GameData.IsPlanetAreaUnlocked(planetAreaId)
	return _gameData.unlockPlanetAreas[planetAreaId] ~= nil
end

function GameData.IsPlanetAreaExploring(planetAreaId)
	local data = _gameData.unlockPlanetAreas[planetAreaId]
	if data == nil then
		return false
	end

	return data.settleStatus > 0
end

function GameData.GetExploreTimeOfPlanetArea(planetAreaId)
	local startTime = _gameData.unlockPlanetAreas[planetAreaId].startTime
	local endTime = _gameData.unlockPlanetAreas[planetAreaId].endTime

	return startTime, endTime
end

function GameData.GetLeftTimeOfPlanetArea(planetAreaId)
	local startTime = _gameData.unlockPlanetAreas[planetAreaId].startTime
	local endTime = _gameData.unlockPlanetAreas[planetAreaId].endTime
	local costTime = (endTime - startTime)

	local curTime = this.GetServerTime()
	local diff = (endTime - curTime)
	diff = math.max(0, diff)
	return diff, costTime, startTime, endTime
end

function GameData.StartExploreOfPlanetArea(planetAreaId, data)
	local status, exploreData, usedCharacters, usedPet = this.ConstructExploreData(data)
	-- set data
	_gameData.unlockPlanetAreas[planetAreaId] = exploreData
	this.SetPlanetAreaExploreCharacters(planetAreaId, usedCharacters)
	this.SetPlanetAreaExplorePet(planetAreaId, usedPet)

	-- must mark it before the notify send
	this.MarkBusyCharacterDirty()
	this.MarkBusyPetDirty()
	this.MarkExploreTeamDirty()
	-- notify
	GameNotifier.Notify(GameEvent.PlanetAreaExplore, planetAreaId)
end

function GameData.SpeedUpExploreOfPlanetArea(planetAreaId)
	_gameData.unlockPlanetAreas[planetAreaId].endTime = this.GetServerTime()
	-- notify
	GameNotifier.Notify(GameEvent.PlanetAreaSpeedUp, planetAreaId)
end

function GameData.FinishExploreOfPlanetArea(planetAreaId)
	local planetId = ConfigUtils.GetPlanetOfArea(planetAreaId)
	local characters = this.GetPlanetAreaExploreCharacters(planetAreaId)
	local skins = {}
	for idx = 1, #characters do
		skins[idx] = this.GetCharacterSkin(characters[idx])
	end
	local petId = _gameData.unlockPlanetAreas[planetAreaId].pet
	if not ConfigUtils.IsValidItem(petId) then
		petId = nil
	end
	local costTime = _gameData.unlockPlanetAreas[planetAreaId].costTime
	local totalTime = _gameData.unlockPlanetAreas[planetAreaId].totalExploreTime or 0
	totalTime = totalTime + costTime

	local exploreCostItems = {}

	local goalData = {}
	-- drop list
	local dropList = _gameData.unlockPlanetAreas[planetAreaId].dropList
	for idx = 1, #dropList do
		local itemId = dropList[idx][1]
		local itemNum = dropList[idx][2]
		this.CollectItem(itemId, itemNum)

		local e = this.SetupItemGoalData(itemId, itemNum)
		e.Characters = characters
		e.Pet = petId
		e.Skins = skins
		table.insert(goalData, e)
	end
	-- event list
	local eventList = _gameData.unlockPlanetAreas[planetAreaId].eventList
	for idx = 1, #eventList do
		local eventId = eventList[idx].EventId
		this.UnlockEvent(eventId)
		-- event rewards
		local eventRewards = ConfigUtils.GetEventReward(eventId)
		for eventRewardIdx = 1, #eventRewards do
			local eventRewardId = eventRewards[eventRewardIdx].Value
			local eventRewardNum = eventRewards[eventRewardIdx].Num
			this.CollectItem(eventRewardId, eventRewardNum)
		end
	end
	-- catch item list
	local catchItemList = _gameData.unlockPlanetAreas[planetAreaId].catchItemList
	for catchItemIdx = 1, #catchItemList do
		local catchItemId = catchItemList[catchItemIdx].CatchItemId
		local catchItemState = catchItemList[catchItemIdx].Status
		local petList = catchItemList[catchItemIdx].CatchPetList or {}
		--assert(#petList <= 1, "one catch item can catch one pet at most")
		if #petList > 0 then
			for idx = 1, #petList do
				local petId = petList[idx][1]
				local petState = petList[idx][2]
				-- success
				if petState == 1 then
					this.UnlockPet(petId, 1)
					-- unlock pet
					local e = this.SetupItemGoalData(petId, 1)
					e.Characters = characters
					e.Pet = petId
					e.Skins = skins
					table.insert(goalData, e)
				end
			end

		end
		-- not broken: 0 - not used; 1 - used but not broken
		if catchItemState == 0 or catchItemState == 1 then
			this.CollectItem(catchItemId, 1)
		else
			-- used catch items
			local preCostNum = exploreCostItems[catchItemId] or 0
			exploreCostItems[catchItemId] = preCostNum + 1
		end
	end

	table.insert(goalData, {Type = ItemType.Time, Num = costTime, Value = planetId, Characters = characters, Skins = skins, Pet = petId})
	table.insert(goalData, {Type = ItemType.Time, Num = costTime, Value = planetAreaId, Characters = characters, Skins = skins, Pet = petId})

	-- enemy list
	local enemyList = _gameData.unlockPlanetAreas[planetAreaId].enemyList
	local defeatEnemyGroup = {}
	for idx = 1, #enemyList do
		local enemyId = enemyList[idx][1]
		local enemyPower= enemyList[idx][2]
		local winEnemy= (enemyList[idx][3] > 0)
		local enemyNum = enemyList[idx][4]

		if winEnemy then
			local e = this.SetupItemGoalData(enemyId, enemyNum)
			table.insert(goalData, e)
			e.Characters = characters
			e.Pet = petId
			e.Skins = skins
			e.Area = planetAreaId

			if defeatEnemyGroup[enemyId] == nil then
				defeatEnemyGroup[enemyId] = 1
			end
		end
	end

	-- explore cost
	local foodList = _gameData.unlockPlanetAreas[planetAreaId].foodList
	for idx = 1, #foodList do
		local itemId = foodList[idx][1]
		exploreCostItems[itemId] = foodList[idx][2]
	end

	local exploreCostGoalData = {}
	for k, v in pairs(exploreCostItems) do
		local e = this.SetupItemGoalData(k, v)
		table.insert(exploreCostGoalData, e)
		e.Characters = characters
		e.Pet = petId
		e.Skins = skins
		e.Area = planetAreaId
	end

	local defeatEnemyGroupNum = Helper.TableLength(defeatEnemyGroup)
	local enemyGroupGoalData = GameData.SetupItemGoalDataWithType(ItemType.Enemy, -1, defeatEnemyGroupNum)
	enemyGroupGoalData.Characters = characters
	enemyGroupGoalData.Pet = petId
	enemyGroupGoalData.Skins = skins
	enemyGroupGoalData.Area = planetAreaId

	-- empty the explore data
	_gameData.unlockPlanetAreas[planetAreaId] = {settleStatus = 0, totalExploreTime = totalTime}

	-- goal
	this.DoGoalSettle(TriggerType.Explore, goalData)
	this.DoGoalSettle(TriggerType.ExploreCost, exploreCostGoalData)
	this.DoGoalSettle(TriggerType.ExploreEnemyGroup, {enemyGroupGoalData})
	this.TriggerStartExplore(planetAreaId)
	-- must mark it before the notify send
	this.MarkBusyCharacterDirty()
	this.MarkBusyPetDirty()
	this.MarkExploreTeamDirty()
	-- actual just notify the completed goals, as we will refresh goal list
	this.CheckAndHintGoalsOfCurrentCountType()
	-- check node visible
	NodeHelper.OnAreaSettled()
	-- notify
	GameNotifier.Notify(GameEvent.PlanetAreaSettle, planetAreaId)
end

function GameData.CancelExploreOfPlanetArea(planetAreaId)
	local totalTime = _gameData.unlockPlanetAreas[planetAreaId].totalExploreTime or 0
	-- catch item list
	local catchItemList = _gameData.unlockPlanetAreas[planetAreaId].catchItemList
	for catchItemIdx = 1, #catchItemList do
		local catchItemId = catchItemList[catchItemIdx].CatchItemId
		this.CollectItem(catchItemId, 1)
	end
	-- food list
	local foodList = _gameData.unlockPlanetAreas[planetAreaId].foodList
	for idx = 1, #foodList do
		local itemId = foodList[idx][1]
		local itemNum = foodList[idx][2]
		this.CollectItem(itemId, itemNum)
	end
	-- empty the explore data
	_gameData.unlockPlanetAreas[planetAreaId] = {settleStatus = 0, totalExploreTime = totalTime}
	-- must mark it before the notify send
	this.MarkBusyCharacterDirty()
	this.MarkBusyPetDirty()
	this.MarkExploreTeamDirty()
	-- notify
	GameNotifier.Notify(GameEvent.PlanetAreaSettle, planetAreaId)
end

function GameData.GetPlanetShowPlanetArea(planetId)
	local minStartTime = nil
	local retAreaId = nil

	for k, v in pairs(_gameData.unlockPlanetAreas) do
		if v.settleStatus > 0 then
			if ConfigUtils.GetPlanetOfArea(k) == planetId then
				if minStartTime == nil or v.startTime < minStartTime then
					retAreaId = k
					minStartTime = v.startTime
				end
			end
		end
	end

	return retAreaId
end

function GameData.GetTotalExploreTimeOfPlanetArea(planetAreaId)
	if _gameData.unlockPlanetAreas[planetAreaId] == nil then
		return 0
	end

	return _gameData.unlockPlanetAreas[planetAreaId].totalExploreTime or 0
end

function GameData.GetTotalExploreTimeOfPlanet(planetId)
	local ret = 0

	for k, v in pairs(_gameData.unlockPlanetAreas) do
		local thisPlanetId = ConfigUtils.GetPlanetOfArea(k)
		if thisPlanetId == planetId then
			ret = ret + (v.totalExploreTime or 0)
		end
	end

	return ret
end
----------------------------------------------------------------
-- goods
function GameData.IsGoodsUnlocked(goodsId)
	return _gameData.unlockGoods[goodsId] ~= nil
end

function GameData.GetGoodsNum(goodsId)
	return _gameData.unlockGoods[goodsId] or 0
end

function GameData.CollectGoods(goodsId, num)
	if _gameData.unlockGoods[goodsId] == nil then
		if this.IsModuleUnlocked(ModuleNames.Warehouse) then
			this.AddNewCheck(goodsId)
		end
	end

	local preNum = _gameData.unlockGoods[goodsId] or 0
	_gameData.unlockGoods[goodsId] = preNum + num
	GameNotifier.Notify(GameEvent.ItemNumChanged, goodsId, num)
end

function GameData.ConsumeGoods(goodsId, num)
	if _gameData.unlockGoods == nil then
		_gameData.unlockGoods = {}
	end

	local preNum = _gameData.unlockGoods[goodsId] or 0
	assert(preNum >= num, "not enough goods: "..tostring(goodsId).."; cur num: "..tostring(preNum).."; consume num: "..tostring(num))
	_gameData.unlockGoods[goodsId] = preNum - num
	GameNotifier.Notify(GameEvent.ItemNumChanged, goodsId, -num)
end

function GameData.GetUnlockedGoods()
	return this.GetUnlockedGoodsOfType(nil)
end

function GameData.GetUnlockedGoodsOfType(subType)
	local ret = {}

	if _gameData.unlockGoods ~= nil then
		for k, v in pairs(_gameData.unlockGoods) do
			if subType == nil or ConfigUtils.GetGoodsSubType(k) == subType then
				table.insert(ret, k)
			end
		end
	end

	return ret
end

function GameData.GetUnlockedGoodsOfTypes(...)
	local ret = {}

	local subTypes = {...}
	if _gameData.unlockGoods ~= nil then
		for k, v in pairs(_gameData.unlockGoods) do
			local thisSubType = ConfigUtils.GetGoodsSubType(k)
			if Helper.TableContains(subTypes, thisSubType) then
				table.insert(ret, k)
			end
		end
	end

	return ret
end
----------------------------------------------------------------
function GameData.GetUnlockTimeOfPostcard(postcardId)
	return _gameData.unlockPostcards[postcardId]
end

function GameData.UnlockPostcard(postcardId)
	_gameData.unlockPostcards[postcardId] = this.GetServerTime()
end

function GameData.IsUnlockPoscard(postcardId)
	return _gameData.unlockPostcards[postcardId] ~= nil
end
----------------------------------------------------------------
function GameData.IsEquipmentUnlocked(equipId)
	local characterId = ConfigUtils.GetCharacterOfEquipment(equipId)
	if not this.IsCharacterUnlocked(characterId) then
		return false
	end

	local unlockChallenge = ConfigUtils.GetEquipmentUnlockChallenge(equipId)
	return unlockChallenge == nil or this.IsChallengeCompleted(unlockChallenge)
end
----------------------------------------------------------------
function GameData.IsChallengeCompleted(challengeId)
	if _gameData.unlockChallenges[challengeId] == nil then
		return false
	end
	
	local win = _gameData.unlockChallenges[challengeId].win
	return win > 0
end

function GameData.IsChallengeUnlocked(challengeId)
	return _gameData.unlockChallenges[challengeId] ~= nil
end

function GameData.GetUnlockedChallengeRecord(challengeId)
	local v = _gameData.unlockChallenges[challengeId]
	return v.maxStar, v.minRound
end

function GameData.FinishChallenge(challengeId, win, star, round)
	if _gameData.unlockChallenges[challengeId] == nil then
		local unlockCost = ConfigUtils.GetChallengeUnlockCost(challengeId)
		for idx = 1, #unlockCost do
			local itemId = unlockCost[idx].Value
			local itemNum = unlockCost[idx].Num
			this.ConsumeItem(itemId, itemNum)
		end

		_gameData.unlockChallenges[challengeId] = {win = 0, lose = 0, maxStar = 0, minRound = 0}
	end

	star = star or 0
	round = round or 0

	local winNum = _gameData.unlockChallenges[challengeId].win
	local loseNum = _gameData.unlockChallenges[challengeId].lose
	local preStar = _gameData.unlockChallenges[challengeId].maxStar
	local preRound = _gameData.unlockChallenges[challengeId].minRound

	if win then
		winNum = winNum + 1
		_gameData.unlockChallenges[challengeId].win = winNum

		if star > preStar then
			_gameData.unlockChallenges[challengeId].maxStar = star
		end

		if preRound <= 0 or round < preRound then
			_gameData.unlockChallenges[challengeId].minRound = round
		end

		local firstComplete = (winNum == 1)
		-- only trigger once
		if firstComplete then
			NodeHelper.OnChallengeFinished()
		end

		GameNotifier.Notify(GameEvent.ChallengeFinished, challengeId, firstComplete)
	else
		loseNum = loseNum + 1
		-- unlock challenge
		_gameData.unlockChallenges[challengeId].lose = loseNum
	end
end

function GameData.GetFinishedChallengeList(isCharacterChallenge)
	isCharacterChallenge = isCharacterChallenge or false
	local ret = {}
	for k, v in pairs(_gameData.unlockChallenges) do
		if v.win > 0 and (not isCharacterChallenge or ConfigUtils.GetCharacterOfChallenge(k) ~= nil) then
			table.insert(ret, k)
		end
	end

	return ret
end

function GameData.IsChallengeConditionMatch(challengeId)
	local preCondition = ConfigUtils.GetPreConditionOfChallenge(challengeId)
	local preGoals = {}
	if preCondition ~= nil then
		preGoals = preCondition.PreGoal or {}
	end

	-- main goals
	for idx = 1, #preGoals do
		local preGoalId = preGoals[idx]
		if not this.IsGoalFinished(preGoalId) then
			return false, preGoalId
		end
	end

	return true
end

-- the first challenge not completed
function GameData.GetActiveChallengeOfArea(areaId)
	local challengeList = ConfigUtils.GetAreaChallengeList(areaId)

	for idx = 1, #challengeList do
		local challengeId = challengeList[idx]
		if not this.IsChallengeCompleted(challengeId) then
			return challengeId
		end
	end

	return nil
end

function GameData.GetActiveChallengeIndexOfArea(areaId)
	local challengeList = ConfigUtils.GetAreaChallengeList(areaId)

	for idx = 1, #challengeList do
		local challengeId = challengeList[idx]
		if not this.IsChallengeCompleted(challengeId) then
			return idx
		end
	end

	return nil
end
----------------------------------------------------------------
local _busyCharacterDirty = true

local _busyCharacters = {
	-- id002 = {status = Explore, value = areaId001},
}

local function GetBusyCharactersInternal()
	local ret = {}

	for areaId, data in pairs(_gameData.unlockPlanetAreas) do
		if this.IsPlanetAreaExploring(areaId) then
			local characters = this.GetPlanetAreaExploreCharacters(areaId)
			for idx = 1, #characters do
				local characterId = characters[idx]
				ret[characterId] = {status = CharacterStatus.Explore, value = areaId}
			end
		end
	end

	local workShopList = GameData.GetWorkShopList()
	for workShopId, data in pairs(workShopList) do
		local characters = data.characters or {}
		for idx = 1, #characters do
			local characterId = characters[idx]
			ret[characterId] = {status = CharacterStatus.WorkShop, value = workShopId}
		end
	end

	local themeId = GameData.GetUnsettledActivityTheme()
	if themeId ~= nil then
		local characters = GameData.GetActivityExploreCharacters(themeId)
		for idx = 1, #characters do
			local characterId = characters[idx]
			ret[characterId] = {status = CharacterStatus.ActivityExplore, value = themeId}
		end
	end

	return ret
end

function GameData.GetBusyCharacters()
	if _busyCharacterDirty then
		_busyCharacters = GetBusyCharactersInternal()
		_busyCharacterDirty = false
	end

	return _busyCharacters
end

function GameData.MarkBusyCharacterDirty()
	_busyCharacterDirty = true
end

function GameData.GetCharacterStatus(characterId)
	local busyCharacters = this.GetBusyCharacters()

	if busyCharacters[characterId] ~= nil then
		return busyCharacters[characterId].status
	else
		return CharacterStatus.Idle
	end
end

function GameData.IsBusyCharacter(characterId, mode)
	local status = this.GetCharacterStatus(characterId)

	if mode == CharacterSelectMode.Explore or mode == CharacterSelectMode.WorkShop or mode == CharacterSelectMode.ActivityExplore then
		if status ~= CharacterStatus.Idle then
			return true, status
		end
	elseif mode == CharacterSelectMode.Challenge or mode == CharacterSelectMode.Arena or mode == CharacterSelectMode.ActivityBattle then
		return false
	elseif mode == CharacterSelectMode.SpaceTravelChat then
		return false
	else
		assert(false, "un-handled character select mode: "..tostring(mode))
	end

	return false
end
----------------------------------------------------------------
local _busyPetDirty = true

local _busyPets = {
	-- id002 = {status = Explore, value = areaId001},
}

local function GetBusyPetsInternal()
	local ret = {}

	for areaId, data in pairs(_gameData.unlockPlanetAreas) do
		if this.IsPlanetAreaExploring(areaId) then
			local petId = data.pet
			if ConfigUtils.IsValidItem(petId) then
				ret[petId] = {status = CharacterStatus.Explore, value = areaId}
			end
		end
	end

	local themeId = GameData.GetUnsettledActivityTheme()
	if themeId ~= nil then
		local petId = GameData.GetActivityExplorePet(themeId)
		if ConfigUtils.IsValidItem(petId) then
			ret[petId] = {status = CharacterStatus.ActivityExplore, value = themeId}
		end
	end

	return ret
end

function GameData.GetBusyPets()
	if _busyPetDirty then
		_busyPets = GetBusyPetsInternal()
		_busyPetDirty = false
	end

	return _busyPets
end

function GameData.MarkBusyPetDirty()
	_busyPetDirty = true
end

function GameData.GetPetStatus(petId)
	local busyPets = this.GetBusyPets()

	if busyPets[petId] ~= nil then
		return busyPets[petId].status
	else
		return CharacterStatus.Idle
	end
end

function GameData.IsBusyPet(petId, mode)
	local status = this.GetPetStatus(petId)

	if mode == CharacterSelectMode.Explore or mode == CharacterSelectMode.ActivityExplore then
		if status ~= CharacterStatus.Idle then
			return true, status
		end
	elseif mode == CharacterSelectMode.Challenge or mode == CharacterSelectMode.Arena or mode == CharacterSelectMode.ActivityBattle then
		return false
	else
		assert(false, "un-handled pet select mode: "..tostring(mode))
	end

	return false
end
----------------------------------------------------------------
local _exploreTeamDirty = true
local _exploreTeam = nil

ExploreTeamStatus = {
	Lock = "Lock",
	Idle = "Idle",
	Exploring = "Exploring",
}

local function GetExploreTeamInternal()
	local ret = {}

	local currentLimit, maxLimit = this.CurrentTeamLimit()

	for areaId, data in pairs(_gameData.unlockPlanetAreas) do
		if this.IsPlanetAreaExploring(areaId) then
			if #ret < currentLimit then
				table.insert(ret, {status = ExploreTeamStatus.Exploring, area = areaId})
			end
		end
	end

	for idx = #ret + 1, currentLimit do
		table.insert(ret, {status = ExploreTeamStatus.Idle})
	end

	for idx = currentLimit + 1, maxLimit do
		table.insert(ret, {status = ExploreTeamStatus.Lock})
	end

	return ret
end

function GameData.CurrentTeamLimit()
	return _gameData.teamLimit, ExploreTeamLimit
end

function GameData.UnlockTeam(newTeamLimit)
	_gameData.teamLimit = newTeamLimit
	this.MarkExploreTeamDirty()
	GameNotifier.Notify(GameEvent.ExploreTeamUnlocked)
end

function GameData.MarkExploreTeamDirty()
	_exploreTeamDirty = true
end

function GameData.GetExploreTeam()
	if _exploreTeamDirty then
		_exploreTeam = GetExploreTeamInternal()
		_exploreTeamDirty = false
	end

	return _exploreTeam
end

function GameData.GetTeamCountOfExploring()
	local exploreTeam = this.GetExploreTeam()
	local count = 0
	for idx = 1, #exploreTeam do
		if exploreTeam[idx].status == ExploreTeamStatus.Exploring then
			count = count + 1
		end
	end

	return count
end

function GameData.HasAvailableExploreTeam()
	local exploringCount = this.GetTeamCountOfExploring()
	local teamLimit = this.CurrentTeamLimit()

	return exploringCount < teamLimit
end
----------------------------------------------------------------
function GameData.GetExploreNotifyData()
	local exploreNotify = {}

	local currentTime = this.GetServerTime()

	for planetAreaId, data in pairs(_gameData.unlockPlanetAreas) do
		if data.settleStatus > 0 and data.endTime > currentTime then
			table.insert(exploreNotify, {areaId = planetAreaId, endTime = data.endTime})
		end
	end

	return exploreNotify
end
----------------------------------------------------------------
TeamType = {
	Challenge = 1,
	Explore = 2,
	WorkShop = 3,

	Count = 3,
}

function GameData.SetPresetTeamList(teamList)
	_teamGroups = {}

	local tempGroups = {}
	for idx = 1, TeamType.Count do
		tempGroups[idx] = {}
	end

	teamList = teamList or {}
	for idx = 1, #teamList do
		local teamType = teamList[idx].TeamType
		table.insert(tempGroups[teamType], teamList[idx])
	end

	for idx = 1, TeamType.Count do
		GameData.SetPresetTeamOfType(idx, tempGroups[idx])
	end
end

function GameData.SetPresetTeamOfType(teamType, teamList)
	_teamGroups[teamType] = {}

	teamList = teamList or {}
	for idx = 1, #teamList do
		local teamName = teamList[idx].TeamName

		local characters = {}
		local petId = nil
		local members = teamList[idx].TeamList or {}
		for m = 1, #members do
			local memberId = members[m]
			if ConfigUtils.IsValidItem(memberId) then
				local itemType = ConfigUtils.GetItemTypeFromId(memberId)
				if itemType == ItemType.Character then
					table.insert(characters, memberId)
				elseif itemType == ItemType.Pet then
					petId = memberId
				else
					assert(false, "un-handled item type in team list: "..tostring(memberId))
				end
			end
		end

		table.insert(_teamGroups[teamType], {characters = characters, pet = petId, name = teamName})
	end

	for idx = #_teamGroups[teamType] + 1, MAX_TEAM_COUNT do
		_teamGroups[teamType][idx] = {characters = {}}
	end
end

function GameData.RenameTeamOfType(teamType, teamIdx, teamName)
	_teamGroups[teamType][teamIdx].name = teamName
end

function GameData.ValidPresetTeams()
	for idx = 1, #_teamGroups do
		local teamGroup = _teamGroups[idx]
		for m = 1, #teamGroup do
			local v = teamGroup[m]
			-- not unlocked pet, remove it
			if ConfigUtils.IsValidItem(v.pet) then
				if not this.IsPetUnlocked(v.pet) then
					v.pet = nil
				end
			else
				v.pet = nil
			end

			for idx = #v.characters, 1, -1 do
				local characterId = v.characters[idx]
				local needRemove = false
				-- not unlocked character, remove it
				if ConfigUtils.IsValidItem(characterId) then
					if not this.IsCharacterUnlocked(characterId) then
						needRemove = true
					end
				else
					needRemove = true
				end

				if needRemove then
					table.remove(v.characters, idx)
				end
			end
		end
	end
end

function GameData.GetTeamGroups(teamType)
	local ret = {}

	local teamGroup = _teamGroups[teamType]

	for idx = 1, #teamGroup do
		local oneTeam = teamGroup[idx]
		local characters = {}
		Helper.CopyTable(characters, oneTeam.characters or {})
		local petId = nil
		if ConfigUtils.IsValidItem(oneTeam.pet) then
			petId = oneTeam.pet
		end

		ret[idx] = {characters = characters, pet = petId, name = oneTeam.name}
	end

	for idx = #ret + 1, MAX_TEAM_COUNT do
		ret[idx] = {characters = {}}
	end

	return ret
end
----------------------------------------------------------------

---定制外观-------------------------------------------------------------

---获取玩家拥有的所有外观
function GameData.GetAvailableAppearances(characterId)
	local ret = {}
	--角色升阶皮肤
	local stage = this.GetCharacterCurrentStage(characterId)
	for i = 1, stage do
		local skin = ConfigUtils.GetDefaultSkinOfCharacter(characterId, i)
		if not table.Contains(ret, skin) then
			table.insert(ret, skin)
		end
	end
	--解锁的皮肤
	local skins = this.GetUnlockSkinsByCharacter(characterId)
	table.AddRange(ret, skins)

	return ret
end


---家具----------------------------------------------------------------
function GameData.CollectFurniture(furnitureId, num)
	local preNum = _gameData.unlockFurniture[furnitureId] or 0
	local curNum = preNum + num
	if curNum ~= preNum then
		_gameData.unlockFurniture[furnitureId] = curNum
		--GameDataHome.SetFurnitureBuyCostHistoryData(furnitureId, curNum)
		GameNotifier.Notify(GameEvent.FurnitureChanged)
	end
end

function GameData.ConsumeFurniture(furnitureId, num)
	local preNum = _gameData.unlockFurniture[furnitureId] or 0
	local curNum = preNum - num
	assert(curNum >= 0, "the furniture num should always >= 0" .. tostring(furnitureId))
	if preNum ~= curNum then
		_gameData.unlockFurniture[furnitureId] = curNum
		GameNotifier.Notify(GameEvent.FurnitureChanged)
	end
end

function GameData.GetFurnitureNum(goodsId)
	return _gameData.unlockFurniture[goodsId] or 0
end

function GameData.IsHomeFurnitureUnlocked(furnitureId)
	if _gameData.unlockFurniture == nil then
		return false
	end
	return _gameData.unlockFurniture[furnitureId] ~= nil
end

function GameData.GetUnlockHomeFurniture()
	local ret = {}
	if _gameData.unlockFurniture then
		for k, v in pairs(_gameData.unlockFurniture) do
			table.insert(ret, {id = k, num = v})
		end
	end
	return ret
end
-----------------------------------------------------------------------
function GameData.GetActiveWeeklyMoneyBoxReward()
	local list = {}
	for k, v in pairs(_gameData.MoneyBoxReward) do
		table.insert(list, {Id = k, Num = v})
	end
	return list
end

function GameData.SetWeeklyMoneyBoxReward(reward)
	_gameData.MoneyBoxReward = {}
	local moneyBoxList = reward or {}
	for idx = 1, #moneyBoxList do
		local info = reward[idx]
		local rewardId = info[1]
		local rewardNum = info[2]
		_gameData.MoneyBoxReward[rewardId] = rewardNum
	end
end
-----------------------------------------------------------------------
