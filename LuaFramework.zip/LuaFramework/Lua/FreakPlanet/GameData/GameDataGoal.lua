
local this = GameData

GoalState = {
	Running = "Running",
	Complete = "Complete",
	Closed = "Closed",
	Locked = "Locked",
}

local _activeGoals = {
	-- goalId001 = {state = GoalState.Running, number = {2, 5}}, ...
}

local _closedGoals = {
	-- goalId001 = 1
}

local _finishGoalId = nil
local _finishGoalRewards = nil

-----------------------------------------------------------------------
-- 主线任务刷新条件
  -- 完成主线任务
  -- 解锁区域
-- 挑战前置条件
  -- 区域解锁
  -- 主线任务完成
-- 新手任务刷新条件
  -- 完成主线任务解锁每条新手线的第一个任务
  -- 完成新手任务解锁每条线后面的新手任务
-----------------------------------------------------------------------
local function CheckGoalType(condition, input)
	return condition.Type == input.Type
end

local function CheckGoalValue(condition, input, strictCheck)
	if strictCheck then
		return condition.Value == input.Value
	else
		return condition.Value < 0 or condition.Value == input.Value
	end
end

local function CheckGoalRarity(condition, input)
	if condition.Rarity == nil then
		return true
	end

	if input.Rarity == nil then
		return false
	end

	return input.Rarity >= condition.Rarity
end

local function CheckGoalCategory(condition, input)
	if condition.Category == nil then
		return true
	end

	if input.Category == nil then
		return false
	end

	return input.Category == condition.Category
end

local function CheckGoalRank(condition, input)
	if condition.Rank == nil then
		return true
	end

	if input.Rank == nil then
		return false
	end

	return input.Rank >= condition.Rank
end

local function CheckGoalLevel(condition, input)
	if condition.Level == nil then
		return true
	end

	if input.Level == nil then
		return false
	end

	return input.Level >= condition.Level
end

local function CheckGoalStage(condition, input)
	if condition.Stage == nil then
		return true
	end

	if input.Stage == nil then
		return false
	end

	return input.Stage >= condition.Stage
end

local function CheckGoalCharacter(condition, input)
	if condition.Character == nil or #condition.Character == 0 then
		return true
	end

	if input.Characters == nil or #input.Characters == 0 then
		return false
	end

	for idx = 1, #condition.Character do
		if not Helper.TableContains(input.Characters, condition.Character[idx]) then
			return false
		end
	end

	return true
end

local function CheckGoalElement(condition, input)
	if condition.Element == nil then
		return true
	end

	return condition.Element == input.Element
end

local function CheckGoalSkin(condition, input)
	if condition.Skin == nil or #condition.Skin == 0 then
		return true
	end

	if input.Skins == nil or #input.Skins == 0 then
		return false
	end

	for idx = 1, #condition.Skin do
		if not Helper.TableContains(input.Skins, condition.Skin[idx]) then
			return false
		end
	end

	return true
end

local function CheckGoalArea(condition, input)
	if condition.Area == nil then
		return true
	end

	return condition.Area == input.Area
end

local function CheckGoalPet(condition, input)
	if condition.Pet == nil then
		return true
	end

	return condition.Pet == input.Pet
end

local function CheckGoalDicePoint(condition, input)
	if condition.DicePoints == nil then
		return true
	end

	if input.DicePoint == nil then
		return false
	end

	return Helper.TableContains(condition.DicePoints, input.DicePoint)
end

local function CheckGoalTagList(condition, input)
	if condition.TagList == nil then
		return true
	end

	--if specified the condition value, should no need to set the tag list for the condition value
	if not ConfigUtils.IsValidItem(condition.Value) then
		if input.Type == ItemType.Pet or 
			input.Type == ItemType.Goods or
			input.Type == ItemType.Character or 
			input.Type == ItemType.SpaceTravelGoods or
			input.Type == ItemType.SpaceTravelChoice or
			input.Type == ItemType.HomeFurniture or
			input.Type == ItemType.HomeObstacle or
			input.Type == ItemType.HomeFurnitureGashapon or
			input.Type == ItemType.LabRecipe then
			local match = ConfigUtils.IsItemMatchTagList(input.Value, condition.TagList)
			return match
		end
	end

	local characterNum = condition.CharacterNum or 0
	if characterNum > 0 then
		local characters = input.Characters or {}
		local pet = input.Pet

		local matchCount = 0
		for idx = 1, #characters do
			local characterId = characters[idx]
			local match = ConfigUtils.IsItemMatchTagList(characterId, condition.TagList)
			if match then
				matchCount = matchCount + 1
			end
		end

		if ConfigUtils.IsValidItem(pet) then
			local match = ConfigUtils.IsItemMatchTagList(pet, condition.TagList)
			if match then
				matchCount = matchCount + 1
			end
		end

		return matchCount >= characterNum
	end

	return false
end

local function IsGoalConditionMatchedInternal(goalCondition, input, strictCheck)
	local isFit = true

	if isFit then
		isFit = CheckGoalType(goalCondition, input)
	end

	if isFit then
		isFit = CheckGoalValue(goalCondition, input, strictCheck)
	end

	if isFit then
		isFit = CheckGoalRarity(goalCondition, input)
	end

	if isFit then
		isFit = CheckGoalRank(goalCondition, input)
	end

	if isFit then
		isFit = CheckGoalLevel(goalCondition, input)
	end

	if isFit then
		isFit = CheckGoalStage(goalCondition, input)
	end

	if isFit then
		isFit = CheckGoalCharacter(goalCondition, input)
	end

	if isFit then
		isFit = CheckGoalElement(goalCondition, input)
	end

	if isFit then
		isFit = CheckGoalSkin(goalCondition, input)
	end

	if isFit then
		isFit = CheckGoalArea(goalCondition, input)
	end

	if isFit then
		isFit = CheckGoalPet(goalCondition, input)
	end

	if isFit then
		isFit = CheckGoalTagList(goalCondition, input)
	end

	return isFit
end

local function IsSpaceTravelGoalConditionMatchedInternal(goalCondition, input, strictCheck)
	local isFit = true

	if isFit then
		isFit = CheckGoalType(goalCondition, input)
	end

	if isFit then
		isFit = CheckGoalValue(goalCondition, input, strictCheck)
	end

	if isFit then
		isFit = CheckGoalTagList(goalCondition, input)
	end

	if isFit then
		isFit = CheckGoalDicePoint(goalCondition, input)
	end

	return isFit
end
-----------------------------------------------------------------------
local function GetItemCurrentList(goalTriggers, goalType, goalValue)
	local itemList = {}
	local specified = false
	local isUnlockSkill = Helper.TableContains(goalTriggers, TriggerType.UnlockSkill)
	local isUseSkin = Helper.TableContains(goalTriggers, TriggerType.UsingCostume)
	local isCharacterChallenge = Helper.TableContains(goalTriggers, TriggerType.CharacterChallenge)

	if goalValue ~= INVALID_ID then
		if goalType == ItemType.Equipment then
			itemList = GameData.GetUnlockedEquipments(goalValue)
		elseif goalType == ItemType.ArenaBattle then
			itemList[1] = GameData.GetArenaRecordAt(goalValue)
		else
			local matched = true
			if isUnlockSkill then
				matched = GameData.IsCharacterSkillActivated(goalValue)
			elseif isUseSkin then
				matched = GameData.IsCharacterSkinChanged(goalValue)
			else
				specified = true
			end

			if matched then
				itemList[1] = goalValue
			end
		end
	else
		if goalType == ItemType.Character then
			if isUnlockSkill then
				itemList = GameData.GetUnlockCharactersWithSkills()
			elseif isUseSkin then
				itemList = GameData.GetUnlockCharactersWithSkins()
			else
				itemList = GameData.GetUnlockCharacters()
			end
		elseif goalType == ItemType.Planet then
			itemList = GameData.GetUnlockPlanets()
		elseif goalType == ItemType.Goods then
			itemList = GameData.GetUnlockedGoods()
		elseif goalType == ItemType.Skin then
			itemList = GameData.GetUnlockSkins()
		elseif goalType == ItemType.Challenge then
			itemList = GameData.GetFinishedChallengeList(isCharacterChallenge)
		elseif goalType == ItemType.Equipment then
			itemList = GameData.GetUnlockedEquipments()
		elseif goalType == ItemType.WorkShop then
			itemList = GameData.GetUnlockedWorkShopList()
		elseif goalType == ItemType.Pet then
			itemList = GameData.GetUnlockPetList()
		elseif goalType == ItemType.ActivityBattle then
			itemList[1] = GameData.GetActivityBattleStage()
		elseif goalType == ItemType.HomeFurniture then
			itemList = GameData.GetUnlockHomeFurniture()
		else
			assert(false, "un-handled goal item type: "..tostring(goalType))
		end
	end

	return itemList, specified
end

--- mark for lz,家园成就的逻辑单独放在这里
function GameData.IsAchievementGoal(goalTriggers, goalType)
	local ret = {}
	if goalType == ItemType.HomeFurniture then
		if Helper.TableContains(goalTriggers, TriggerType.CollectItem) then
			ret = GameData.GetUnlockHomeFurniture()
			return true, ret
		elseif Helper.TableContains(goalTriggers, TriggerType.HomeFurnitureSell) then
			ret = GameDataHome.GetFurnitureBuyHistoryData()
			return true, ret
		elseif Helper.TableContains(goalTriggers, TriggerType.ArrangeHomeFurniture) then
			ret = GameDataHome.GetHomePlacementInfoData()
			return true, ret
		end
	elseif goalType == ItemType.Goods then
		if Helper.TableContains(goalTriggers, TriggerType.HomeFurnitureSellCost) then
			ret = GameDataHome.GetFurnitureBuyCostHistoryData()
			return true, ret
		end
	elseif goalType == ItemType.HomeFurnitureGashapon then
		if Helper.TableContains(goalTriggers, TriggerType.HomeFurnitureGashapon) then
			ret = GameDataHome.GetFurnitureGashaponBuyHistoryData()
			return true, ret
		end
	elseif goalType == ItemType.HomeObstacle then
		if Helper.TableContains(goalTriggers, TriggerType.ClearObstacle) then
			ret = GameDataHome.GetHomeCleanItemList()
			return true, ret
		end
	end
	return false, ret
end

local function GetGoalActualNum(goalTriggers, goalCondition, numFromServer)
	local countType = goalCondition.CountType
	if countType == GoalCountType.Current then
		-- handle sepcial types
		local isUpgradeEquipment = Helper.TableContains(goalTriggers, TriggerType.UpgradeEquipment)

		local curNum = 0
		local isAchievement, list = GameData.IsAchievementGoal(goalTriggers, goalCondition.Type)
		if isAchievement then
			for idx = 1, #list do
				local itemId = list[idx].id
				local itemNum = list[idx].num
				local input = this.SetupItemGoalData(itemId, itemNum)
				if IsGoalConditionMatchedInternal(goalCondition, input, false) then
					local isUniqueId = goalCondition.IsUniqueId
					if isUniqueId then
						curNum = curNum + 1
					else
						curNum = curNum + itemNum
					end
				end
			end
		else
			local itemList, specified = GetItemCurrentList(goalTriggers, goalCondition.Type, goalCondition.Value)
			if goalCondition.Type == ItemType.Equipment then
				for idx = 1, #itemList do
					local itemId = itemList[idx].id
					local itemLevel = itemList[idx].level
					local itemCharacter = itemList[idx].character
					local itemNum = 1
					if isUpgradeEquipment then
						itemNum = itemLevel - 1
					end
					local input = this.SetupItemGoalData(itemId, itemNum)
					input.Characters = {itemCharacter}
					input.Level = itemLevel
					if IsGoalConditionMatchedInternal(goalCondition, input, false) then
						curNum = curNum + itemNum
					end
				end
			elseif goalCondition.Type == ItemType.ArenaBattle then
				curNum = itemList[1]
			elseif goalCondition.Type == ItemType.ActivityBattle then
				curNum = itemList[1]
			else
				for idx = 1, #itemList do
					local itemId = itemList[idx]
					local itemNum = 1
					if specified then
						itemNum = this.GetItemNum(itemId)
					end
					local input = this.SetupItemGoalData(itemId, itemNum)
					if IsGoalConditionMatchedInternal(goalCondition, input, false) then
						curNum = curNum + itemNum
					end
				end
			end
		end


		return curNum, true
	end

	return numFromServer, false
end
--------------------------------------------------
function GameData.InitGoalData(data)
	_finishGoalId = nil
	_finishGoalRewards = nil
	_activeGoals = {}
	_closedGoals = {}

	local closedGoalList = data.CompleteGoalList or {}
	--log("closed goals: "..Helper.Format(closedGoalList))
	for idx = 1, #closedGoalList do
		local goalId = closedGoalList[idx]
		_closedGoals[goalId] = 1
	end

	local mainGoals = data.StoryGoalList or {}
	log("main goal: "..Helper.Format(mainGoals))
	local achievementGoals = data.AchievementList or {}
	log("achievement goal: "..Helper.Format(achievementGoals))
	local activityGoals = data.ActivityGoalList or {}
	log("activity goal: "..Helper.Format(activityGoals))
	local newbieGoals = data.NewbieGoalList or {}
	log("newbie goal: "..Helper.Format(newbieGoals))

	-- 每周任务
	local weeklyGoals = data.WeeklyGoalList or {}
	log("weekly goal: "..Helper.Format(weeklyGoals))

	--家园成就
	local homeAchievementGoals = data.HomeAchievementList or {}
	log("home Achievement goal: "..Helper.Format(homeAchievementGoals))


	this.AddGoals(mainGoals)
	this.AddGoals(achievementGoals)
	this.AddGoals(activityGoals)
	this.AddGoals(newbieGoals)
	this.AddGoals(weeklyGoals)
	this.AddGoals(homeAchievementGoals)

	--log("active goals: "..Helper.Format(_activeGoals))
end

function GameData.AddGoals(goals)
	for k, v in pairs(goals) do
		local goalType = ConfigUtils.GetGoalType(v.GoalId)
		if not v.GetReward or goalType == GoalType.Weekly then   --mark for lz, 每周任务会一直都在_activeGoals里面,不会在任务领取奖励后消失
			local goalId = v.GoalId
			local completedInServer = v.IsComplete or false
			-- number list
			local conditions = ConfigUtils.GetGoalConditions(goalId)
			local goalTriggers = ConfigUtils.GetGoalTriggers(goalId)
			assert(#conditions == #v.CurrentNumList, "the number list is not same with server data: "..tostring(goalId))
			local number = {}
			local hasLocal = false
			local actualNumMatch = true
			for idx = 1, #conditions do
				local goalNeedNum = conditions[idx].Num
				local numFromServer = v.CurrentNumList[idx]
				-- do not check
				if completedInServer then
					number[idx] = math.max(numFromServer, goalNeedNum)
				else
					local finalNum, useLocal = GetGoalActualNum(goalTriggers, conditions[idx], numFromServer)

					if useLocal then
						hasLocal = true
					end

					if finalNum < goalNeedNum then
						actualNumMatch = false
					end

					number[idx] = finalNum
				end
			end

			-- state
			local state = GoalState.Complete
			if hasLocal or not actualNumMatch then
				state = GoalState.Running
			end

			local lastCompleted = actualNumMatch
			local getReward = v.GetReward
			_activeGoals[goalId] = {state = state, number = number, lastCompleted = lastCompleted, getReward = getReward}
		end
	end
end

function GameData.IsGoalFinished(goalId)
	return _closedGoals[goalId] ~= nil
end

function GameData.IsGoalConditionMatched(goalCondition, input, strictCheck)
	return IsGoalConditionMatchedInternal(goalCondition, input, strictCheck)
end

function GameData.IsSpaceTravelGoalConditionMatched(goalCondition, input, strictCheck)
	return IsSpaceTravelGoalConditionMatchedInternal(goalCondition, input, strictCheck)
end

function GameData.IsGoalCompleted(goalId)
	local goalState = this.GetGoalInfo(goalId)
	return goalState == GoalState.Complete
end

function GameData.IsUnlockAllPreGoal(goalId)
	local preGoalList = ConfigUtils.GetPreGoalList(goalId)
	for idx = 1, #preGoalList do
		if not this.IsGoalFinished(preGoalList[idx]) then
			return false, preGoalList[idx]
		end
	end
	return true, nil
end

function GameData.IsGoalCompletedOrFinished(goalId)
	if this.IsGoalFinished(goalId) then
		return true
	end

	if this.IsGoalCompleted(goalId) then
		return true
	end

	return false
end

function GameData.IsWeekGoalGetReward(goalId)
	local goalType = ConfigUtils.GetGoalType(goalId)
	assert(goalType == GoalType.Weekly, "invalid Weekly Goal Id: ", goalId)
	if _activeGoals[goalId] ~= nil then
		local curState = _activeGoals[goalId].state
		if curState == GoalState.Complete then
			return _activeGoals[goalId].getReward
		else
			return false
		end
	end
	return false
end

function GameData.IsGoalRunning(goalId)
	local goalState = this.GetGoalInfo(goalId)
	return goalState == GoalState.Running
end

--- 重置每周的任务进度
function GameData.ResetWeeklyGoals()
	for k, v in pairs(_activeGoals) do
		local goalType = ConfigUtils.GetGoalType(k)
		if goalType == GoalType.Weekly then
			local conditions = ConfigUtils.GetGoalConditions(k)
			local numbers = {}
			for idx = 1, #conditions do
				numbers[idx] = 0
			end
			v.state = GoalState.Running
			v.number = numbers
			v.lastCompleted = false
			v.getReward = false
		end
	end
end

function GameData.RemoveGoalsOfType(goalType)
	local toRemove = {}
	for k, v in pairs(_activeGoals) do
		if goalType == nil or goalType == ConfigUtils.GetGoalType(k) then
			table.insert(toRemove, k)
		end
	end

	for idx = 1, #toRemove do
		local goalId = toRemove[idx]
		_activeGoals[goalId] = nil
	end
end

function GameData.GetCurrentActivityGoalOfPool(poolId)
	for k, v in pairs(_activeGoals) do
		if ConfigUtils.IsActivityGoal(k) and v.state ~= GoalState.Closed and ConfigUtils.GetGoalPoolId(k) == poolId  then
			return k
		end
	end

	return nil
end

function GameData.GetActiveGoalsOfHomeAchievement()
	local achievementGoal = {}
	for k, v in pairs(_activeGoals) do
		if v.state ~= GoalState.Closed and ConfigUtils.GetGoalType(k) == GoalType.HomeAchievement then
			achievementGoal[k] = v
		end
	end

	for k, v in pairs(_closedGoals) do
		if ConfigUtils.GetGoalType(k) == GoalType.HomeAchievement then
			local goalInfo = {state = GoalState.Complete, number = {}, lastCompleted = true, getReward = true}
			achievementGoal[k] = goalInfo
		end
	end

	return achievementGoal
end

function GameData.GetActiveGoalsOfType(goalType)
	local ret = {}

	if goalType == GoalType.Weekly then  -- 每周任务从本地配置表读
		for k, v in pairs(GoalConfig) do
			local goalType = ConfigUtils.GetGoalType(k)
			if goalType == GoalType.Weekly then
				table.insert(ret, k)
			end
		end
	else
		for k, v in pairs(_activeGoals) do
			if v.state ~= GoalState.Closed and ConfigUtils.GetGoalType(k) == goalType then
				table.insert(ret, k)
			end
		end
	end

	return ret
end

function GameData.GetFirstActiveMainGoal()
	for k, v in pairs(_activeGoals) do
		if v.state ~= GoalState.Closed and ConfigUtils.GetGoalType(k) == GoalType.Main and ConfigUtils.IsMainGoal(k) then
			return k
		end
	end

	return nil
end

function GameData.GetFirstRunningMainGoal()
	for k, v in pairs(_activeGoals) do
		if ConfigUtils.GetGoalType(k) == GoalType.Main and ConfigUtils.IsMainGoal(k) then
			local goalState = this.GetGoalInfo(k)
			if goalState == GoalState.Running then
				return k
			end
		end
	end

	return nil
end

function GameData.FinishGoal(goalId)
	local goalType = ConfigUtils.GetGoalType(goalId)
	assert(_activeGoals[goalId] ~= nil, "no record data for goal: "..tostring(goalId))
	if goalType ~= GoalType.Weekly then
		-- remove
		_activeGoals[goalId] = nil
		_closedGoals[goalId] = 1
	end

	local refreshActivity = this.OnGoalClosed(goalId)

	-- consume goods
	if ConfigUtils.IsSubmitGoodsGoal(goalId) then
		local conditions = ConfigUtils.GetGoalConditions(goalId)
		for idx = 1, #conditions do
			local itemId = conditions[idx].Value
			local itemNum = conditions[idx].Num
			this.ConsumeItem(itemId, itemNum)
		end
	end

	-- collect rewards
	local rewards = ConfigUtils.GetGoalActualRewards(goalId)
	local showRewards = {}
	for idx = 1, #rewards do
		local rewardId = rewards[idx].Value
		local rewardNum = rewards[idx].Num
		local rewardType = ConfigUtils.GetItemTypeFromId(rewardId)
		local isPlanetArea = (rewardType == ItemType.PlanetArea)
		local unlocked = this.IsItemUnlocked(rewardId)

		this.CollectItem(rewardId, rewardNum, false)
		showRewards[idx] = {value = rewardId, num = rewardNum, unlocked = unlocked}
	end

	_finishGoalId = goalId
	_finishGoalRewards = showRewards

	if goalType == GoalType.Main then
		NetManager.Send("GoalList", {GoalType = GoalType.Main}, GameData.OnHandleProto)
		NetManager.Send("GoalList", {GoalType = GoalType.Newbie}, GameData.OnHandleProto)
		if refreshActivity then
			NetManager.Send("GoalList", {GoalType = GoalType.Activity}, GameData.OnHandleProto)
		end
		NetManager.Send("DemandList", {}, GameData.OnHandleProto)
		NetManager.Send("GoalList", {GoalType = GoalType.Weekly}, GameData.OnHandleProto)
		NetManager.Send("GoalList", {GoalType = GoalType.HomeAchievement}, GameData.OnHandleProto)
	elseif goalType == GoalType.Activity then
		NetManager.Send("GoalList", {GoalType = GoalType.Activity}, GameData.OnHandleProto)
	elseif goalType == GoalType.Newbie then
		NetManager.Send("GoalList", {GoalType = GoalType.Newbie}, GameData.OnHandleProto)
	elseif goalType == GoalType.Weekly then
		NetManager.Send("GoalList", {GoalType = GoalType.Weekly}, GameData.OnHandleProto)
	elseif goalType == GoalType.HomeAchievement then
		NetManager.Send("GoalList", {GoalType = GoalType.HomeAchievement}, GameData.OnHandleProto)
	else
		-- no need to update goal list
		this.HandleGoalFinished(goalType)
	end
end

function GameData.FinishAchievementGoal(goalId)
	assert(_activeGoals[goalId] ~= nil, "no record data for goal: "..tostring(goalId))
	-- remove
	_activeGoals[goalId] = nil
	_closedGoals[goalId] = 1
	GameNotifier.Notify(GameEvent.GoalChanged, GoalType.Achievement)
end

function GameData.GetGoalInfo(goalId)
	if _activeGoals[goalId] ~= nil then
		local curState = _activeGoals[goalId].state
		if curState == GoalState.Running then
			local serverNumbers = _activeGoals[goalId].number
			local conditions = ConfigUtils.GetGoalConditions(goalId)
			local goalTriggers = ConfigUtils.GetGoalTriggers(goalId)
			local numbers = {}
			local state = GoalState.Complete
			for idx = 1, #conditions do
				local needNum = conditions[idx].Num
				local numFromServer = serverNumbers[idx]
				local ownNum = GetGoalActualNum(goalTriggers, conditions[idx], numFromServer)
				numbers[idx] = ownNum
				if ownNum < needNum then
					state = GoalState.Running
				end
			end
			return state, numbers
		else
			return _activeGoals[goalId].state, _activeGoals[goalId].number
		end
	end

	local state = GoalState.Locked
	if _closedGoals[goalId] ~= nil then
		state = GoalState.Closed
	end
	
	local conditions = ConfigUtils.GetGoalConditions(goalId)
	local numbers = {}
	for idx = 1, #conditions do
		if state == GoalState.Closed then
			numbers[idx] = conditions[idx].Num
		else
			numbers[idx] = 0
		end
	end

	return state, numbers
end

function GameData.IsGoalValid(goalId)
	local goalType = ConfigUtils.GetGoalType(goalId)
	if goalType ~= GoalType.Activity then
		return true
	end

	local goalPoolId = ConfigUtils.GetGoalPoolId(goalId)
	return this.IsGoalPoolValid(goalPoolId)
end

function GameData.DoGoalSettle(triggerType, input)
	local dirty = false
	for goalId, goalData in pairs(_activeGoals) do
		if this.IsGoalValid(goalId) and goalData.state == GoalState.Running then
			local triggers = ConfigUtils.GetGoalTriggers(goalId)
			if Helper.TableContains(triggers, triggerType) then
				local changed = this.RefreshGoalData(goalId, goalData, input)
				if changed then
					this.CheckGoalComplete(goalId, goalData)
					dirty = true
				end
			end 
		end
	end
end

function GameData.TriggerStartExplore(areaId)
	local planetId = ConfigUtils.GetPlanetOfArea(areaId)
	for goalId, goalData in pairs(_activeGoals) do
		if not this.IsGoalValid(goalId) or goalData.state ~= GoalState.Running then
			goto continue
		end
		local triggers = ConfigUtils.GetGoalTriggers(goalId)
		if not Helper.TableContains(triggers, TriggerType.StartExplore) then
			goto continue
		end

		local conditions = ConfigUtils.GetGoalConditions(goalId)
		for i, condition in ipairs(conditions) do
			local success = false
			if ConfigUtils.IsValidPlanet(condition.Value) then
				if condition.Value == planetId then
					success = true
				end
			else
				if condition.Value == areaId then
					success = true
				end
			end
			if success then
				goalData.number[i] = condition.Num
			end
		end
		this.CheckGoalComplete(goalId, goalData)
		::continue::
	end
end

function GameData.CheckAndHintGoalsOfCurrentCountType()
	for goalId, goalData in pairs(_activeGoals) do
		if this.IsGoalValid(goalId) and goalData.state == GoalState.Running then
			if ConfigUtils.IsGoalOfCurrentCountType(goalId) then
				local serverNumbers = goalData.number
				local conditions = ConfigUtils.GetGoalConditions(goalId)
				local goalTriggers = ConfigUtils.GetGoalTriggers(goalId)
				local curCompleted = true
				for idx = 1, #conditions do
					local needNum = conditions[idx].Num
					local numFromServer = serverNumbers[idx]
					local curNum = GetGoalActualNum(goalTriggers, conditions[idx], numFromServer)
					if curNum < needNum then
						curCompleted = false
					end
				end

				local lastCompleted = goalData.lastCompleted
				if curCompleted ~= lastCompleted then
					if curCompleted then
						-- show hint
						CtrlManager.ShowGoalHint(goalId)
					end
					goalData.lastCompleted = curCompleted
				end
			end
		end
	end
end

function GameData.CheckGoalComplete(goalId, goalData)
	local conditions = ConfigUtils.GetGoalConditions(goalId)

	local isOk = true
	for idx = 1, #conditions do
		local needNum = conditions[idx].Num
		local curNum = goalData.number[idx]
		if curNum < needNum then
			isOk = false
		end
	end

	if isOk then
		local preCompleted = goalData.lastCompleted
		-- mark as completed
		goalData.lastCompleted = true
		-- show hint
		if not preCompleted then
			CtrlManager.ShowGoalHint(goalId)
		end
	end
end

function GameData.HasCompletedGoalOfType(checkGoalType)
	for k, v in pairs(_activeGoals) do
		local goalType = ConfigUtils.GetGoalType(k)
		if checkGoalType == goalType then 
			local state = this.GetGoalInfo(k)
			if state == GoalState.Complete then
				return true
			end
		end
	end

	return false
end

function GameData.HandleGoalFinished(goalType)
	assert(_finishGoalId ~= nil, "finishe goal id should not be nil")

	local goalSpeeches = {}
	local finishSpeechId = ConfigUtils.GetGoalFinishDialog(_finishGoalId)
	if finishSpeechId ~= nil then
		table.insert(goalSpeeches, finishSpeechId)
	end

	if #goalSpeeches > 0 then
		CtrlManager.LaunchPanel(CtrlNames.GoalDialog, {goalSpeechList = goalSpeeches, rewards = _finishGoalRewards})   -- depth = 57
	else
		NewItemCtrl.ShowNewItemList(_finishGoalRewards)
	end

	GameNotifier.Notify(GameEvent.GoalChanged, goalType)

	_finishGoalId = nil
	_finishGoalRewards = nil
end

--------------------------------------------------------------------------
function GameData.OnHandleProto(proto, data, requestData)
	if proto == "GoalList" then
		local goalTypeToUpdate = requestData.GoalType
		assert(goalTypeToUpdate ~= nil, "must send goal type")
		-- remove the existing goals first
		this.RemoveGoalsOfType(goalTypeToUpdate)
		local goalList = {}
		if goalTypeToUpdate == GoalType.Main then
			goalList = data.StoryGoalList or {}
		elseif goalTypeToUpdate == GoalType.Achievement then
			goalList = data.AchievementList or {}
		elseif goalTypeToUpdate == GoalType.Activity then
			goalList = data.ActivityGoalList or {}
		elseif goalTypeToUpdate == GoalType.Newbie then
			goalList = data.NewbieGoalList or {}
		elseif goalTypeToUpdate == GoalType.Weekly then
			goalList = data.WeeklyGoalList or {}
		elseif goalTypeToUpdate == GoalType.HomeAchievement then
			goalList = data.HomeAchievementList or {}
		else
			assert(false, "un-handle goal type: "..tostring(goalTypeToUpdate))
		end
		
		this.AddGoals(goalList)

		if _finishGoalId ~= nil then
			this.HandleGoalFinished(goalTypeToUpdate)
		end
	elseif proto == "DemandList" then
		this.RefreshDemandList(data)
	end
end
--------------------------------------------------------------------------
function GameData.RefreshGoalData(goalId, goalData, input)
	local dirty = false
	local isSpaceTravelGoal = ConfigUtils.IsSpaceTravelGoal(goalId)
	local conditions = ConfigUtils.GetGoalConditions(goalId)
	for idx = 1, #conditions do
		for k, v in pairs(input) do
			-- condition match or not
			local isFit = false
			if isSpaceTravelGoal then
				isFit = IsSpaceTravelGoalConditionMatchedInternal(conditions[idx], v, false)
			else
				isFit = IsGoalConditionMatchedInternal(conditions[idx], v, false)
			end

			if isFit then
				local countType = conditions[idx].CountType
				-- count type of current is handled in other function
				if countType == GoalCountType.StartNow then
					local preNum = goalData.number[idx] or 0
					goalData.number[idx] = preNum + v.Num
					dirty = true
				elseif countType == GoalCountType.OneShot then
					local preNum = goalData.number[idx] or 0
					local curNum = v.Num
					local newNum = math.max(preNum, curNum)
					goalData.number[idx] = newNum
					dirty = (newNum > preNum)
				elseif 	countType == GoalCountType.Weekly then
					local preNum = goalData.number[idx] or 0
					goalData.number[idx] = preNum + v.Num
					dirty = true
				end
			end
		end
	end

	return dirty
end

--------------------------------------------------------------------------
function GameData.SetupItemGoalData(itemId, itemNum, extraData)
	local itemType = ConfigUtils.GetItemTypeFromId(itemId)
	return this.SetupItemGoalDataWithType(itemType, itemId, itemNum, extraData)
end

function GameData.SetupItemGoalDataWithType(itemType, itemId, itemNum, extraData)
	local data = nil
	if itemType == ItemType.Goods then
		local rarity = ConfigUtils.GetGoodsRarity(itemId)
		data = {
			Type = itemType, 
			Value = itemId, 
			Num = itemNum, 
			Rarity = rarity,
		}
	elseif itemType == ItemType.Character then
		local rarity = ConfigUtils.GetCharacterRarity(itemId)
		local stage = GameData.GetCharacterCurrentStage(itemId)
		local level = GameData.GetCharacterLevel(itemId)
		local element = ConfigUtils.GetCharacterElement(itemId)
		data = {
			Type = itemType,
			Value = itemId,
			Num = itemNum,
			Rarity = rarity,
			Level = level,
			Element = element,
			Stage = stage,
		}
	elseif itemType == ItemType.Planet then
		data = {
			Type = itemType,
			Value = itemId,
			Num = itemNum,
		}
	elseif itemType == ItemType.Skin then
		local rarity = ConfigUtils.GetSkinRarity(itemId)
		data = {
			Type = itemType, 
			Value = itemId, 
			Num = itemNum,
			Rarity = rarity,
		}
	elseif itemType == ItemType.WorkShop then
		local level = GameData.GetWorkShopLevel(itemId)
		local bestRank = GameData.GetWorkShopBestRank(itemId)
		data = {
			Type = itemType,
			Value = itemId,
			Num = itemNum,
			Level = level,
			Rank = bestRank,
		}
	elseif itemType == ItemType.Challenge then
		local characters = nil
		local challengeCharacter = ConfigUtils.GetCharacterOfChallenge(itemId)
		if challengeCharacter ~= nil then
			characters = {}
			characters[1] = challengeCharacter
		end
		data = {
			Type = itemType,
			Value = itemId,
			Num = itemNum,
			Characters = characters,
		}
	elseif itemType == ItemType.Enemy then
		local rarity = nil
		if ConfigUtils.IsValidItem(itemId) then
			rarity = ConfigUtils.GetEnemyRarity(itemId)
		end
		data = {
			Type = itemType, 
			Value = itemId, 
			Num = itemNum,
			Rarity = rarity,
		}
	elseif itemType == ItemType.Pet then
		local rarity = ConfigUtils.GetPetRarity(itemId)
		data = {
			Type = itemType, 
			Value = itemId, 
			Num = itemNum,
			Rarity = rarity,
		}
	elseif itemType == ItemType.DicePoint then
		data = {
			Type = itemType, 
			Value = itemId,
			Num = itemNum,
			DicePoint = extraData,
		}
	elseif itemType == ItemType.HomeFurniture then
		local rarity = ConfigUtils.GetHomeFurnitureRarity(itemId)
		local category = ConfigUtils.GetHomeFurnitureCategory(itemId)
		data = {
			Type = itemType,
			Value = itemId,
			Num = itemNum,
			Rarity = rarity,
			Category = category,
		}
	else
		data = {
			Type = itemType, 
			Value = itemId,
			Num = itemNum,
		}
	end

	return data
end
--------------------------------------------------------------------------
-- modules
function GameData.IsModuleUnlocked(moduleName)
	local unlockGoal = ConfigUtils.GetModuleUnlockGoal(moduleName)
	if unlockGoal == nil or unlockGoal < 0 then
		return true
	end

	-- no exist goal
	if GoalConfig[unlockGoal] == nil then
		return false
	end

	return this.IsGoalFinished(unlockGoal)
end

function GameData.OnGoalClosed(goalId)
	local refreshActivity = false
	for k, v in pairs(ModulesUnlockConfig) do
		if v.Unlock == goalId and (v.Name == ModuleNames.Demand or v.Name == ModuleNames.Tourist) then
			GameData.AddNewCheck(v.Name)
		end

		if v.Unlock == goalId and v.Name == ModuleNames.Activity then
			refreshActivity = true
		end

		if v.Unlock == goalId and v.Name == ModuleNames.CustomDemand then
			GameData.InitializeCustomDemandInfo()
		end
	end

	-- check node visible
	NodeHelper.OnGoalClosed()

	return refreshActivity
end

function GameData.HasUnlockedPostcard()
	return this.HasCompletedGoalOfType(GoalType.Achievement)
end

function GameData.HasUnlockedPostcardOfGallery(galleryId)
	for k, v in pairs(_activeGoals) do
		local goalType = ConfigUtils.GetGoalType(k)
		if GoalType.Achievement == goalType then
			local thisGalleryId = ConfigUtils.GetGalleryOfAchievementGoal(k)
			if thisGalleryId == galleryId then
				local state = this.GetGoalInfo(k)
				if state == GoalState.Complete then
					return true
				end
			end
		end
	end

	return false
end
--------------------------------------------------------------------------