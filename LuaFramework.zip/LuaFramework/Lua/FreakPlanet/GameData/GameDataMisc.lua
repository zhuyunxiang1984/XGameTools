local this = GameData

-- notice
local _noticeData = {
	-- title = "xxx", content = "xxx", time = 1000000,
}
-- weekly report
local _weeklyReportData = {
	-- url = "xxx", time = 1000000, texture = tex, textureTime = 1111, isLoading = false
}
-- bulletin
local _bulletinTexture = nil
local _bulletinData = {
	--[[
	{title = "title", content = "content", Time = " ", type = 1},...
	]]--
}
-- mail data
local _mailData = {
	--[[ 
	mailId001 = {
		title = "title",
		content = "content",
		time = "1111",
		read = false,
		rewarded = false,
		rewardList = { {id = id001, num = 2}, ... },
	}, ...
	]]
}
-- sign-in
local _signInInDays = 0
local _signInRewardTimestamp = 0
-- arena market
local _marketRefreshTimestamp = 0
local _marketData = {
	--[[
	{id = goodsId01, num = 100, price = 1000, sold = 0}, ...
	]]
}
---------------------------------------------------------------
-- demand
local _demandList = {
	--[[
	{id = demandId001, activateTime = 0, groupId = groupId001}, ...
	]]
}
-- custom demand
local _customDemand = nil
local _customDemandInfo = nil
---------------------------------------------------------------
-- tourist
local _touristData = {
	--[[
	id = touristId001, startTime = 1000000, endTime = 2000000
	]]
}
-- activity summon pools
local _activitySummonPools = {
	--[[
	id = {startTime = 1000000, endTime = 2000000}, ...
	]]
}
---------------------------------------------------------------
local _timeLimitedActivities = {
	--[[
	id = {startTime = 1000000, endTime = 2000000, poolId = poolId001}, ...
	]]
}

local _timeLimitedDemandList = {
	--[[
	activityId = activityId001, demandList = {...},
	]]
}
---------------------------------------------------------------
local _statisticsData = {
	--[[
		exploreSettle = 0, workshopSettle = 0, ...
	]]
}
---------------------------------------------------------------
local SERVER_TIME_ZONE = 8
local _timeZoneOffset = nil        -- seconds
----------------------------------------------------------------
-- 活动签到
local _activitySignInDays = 0
local _activitySignInRewardTimestamp = 0

----------------------------------------------------------------
local _hideSeekFindCount = 0
local _unlockHideSeekActivity = false
local _hideSeekData = {
	--[[
	{RabbitId = goodsId01, IsFind = 100, IsNew = 1000}, ...
	]]
}
----------------------------------------------------------------
local _deliverFurnitureData = {
	--[[
		{FurnitureId = 1, DeliverTime = 0},
	--]]
}
----------------------------------------------------------------
local function TimeZoneOffsetInternal()
	if _timeZoneOffset == nil then
		local time = os.time({year = 1970, month = 1, day = 2, hour = 0})
		local timeZone = math.floor(time / 3600)
		timeZone = 24 - timeZone - SERVER_TIME_ZONE

		local date = os.date("*t", os.time())
		if date.isdst then
			timeZone = timeZone + 1
		end

		_timeZoneOffset = timeZone * 3600
	end

	return _timeZoneOffset
end

local function DemandSortFunc(elementA, elementB)
	if elementA == nil or elementB == nil then
		return false
	end

	local groupIdA = elementA.groupId
	local groupIdB = elementB.groupId

	local valueA = ConfigUtils.GetDemandGroupSortId(groupIdA)
	local valueB = ConfigUtils.GetDemandGroupSortId(groupIdB)

	return valueA < valueB
end
---------------------------------------------------------------
function GameData.InitMiscData(data)
	GameData.InitBaseInfo(data.BaseInfo)
	--GameData.InitNotice(data.Notice)
	GameData.InitBulletinData(data.Notice)
	GameData.InitMail(data.MailList)
	GameData.InitMarketData(data.BlackMarketList)
	GameData.InitWeeklyReport(data.WeeklyReport)
	GameData.InitTouristData(data.ZooObj)
	GameData.InitStatisticsData(data.StatisticsObj)
	GameData.InitActivitySignInData(data.ActivitySignInInfo)
end
---------------------------------------------------------------
function GameData.InitBaseInfo(data)
	_signInInDays = data.SignInDays or 0
	_signInRewardTimestamp = data.LastSignInTime or 0
	_marketRefreshTimestamp = data.LastBlackMarketRefreshTime
end
---------------------------------------------------------------
function GameData.InitStatisticsData(data)
	data = data or {}

	_statisticsData = {}
	_statisticsData.workShopSettle = data.WorkShopSettle or 0
	_statisticsData.exploreSettle = data.ExploreSettle or 0
end

function GameData.IncWorkShopSettle()
	_statisticsData.workShopSettle = _statisticsData.workShopSettle + 1
end

function GameData.IncExploreSettle()
	_statisticsData.exploreSettle = _statisticsData.exploreSettle + 1
end

function GameData.IsFirstWorkShopSettle()
	return _statisticsData.workShopSettle < 1
end

function GameData.IsFirstExploreSettle()
	return _statisticsData.exploreSettle < 1
end
---------------------------------------------------------------
function GameData.InitDemandData(data)
	this.RefreshDemandList(data)
end

function GameData.GetDemandList()
	return _demandList, _customDemand
end

function GameData.GetCustomDemandInfo()
	this.ValidCustomDemandInfo()
	return _customDemandInfo
end

function GameData.ValidCustomDemandInfo()
	local ts = _customDemandInfo.timestamp
	if not GameData.IsModuleUnlocked(ModuleNames.CustomDemand) or ts == 0 then
		-- force can not do it
		_customDemandInfo.leftCount = 0
		return
	end

	local curTime = GameData.GetServerTime()
	local diff = GameData.GetDayDiffer(curTime, ts)
	if diff > 0 then
		local newCount = _customDemandInfo.leftCount + diff * CustomDemandDailyRefresh
		_customDemandInfo.leftCount = math.min(newCount, CustomDemandRefreshLimit)
		_customDemandInfo.timestamp = curTime
	end
end

function GameData.RefreshDemandList(data, selectCustom)
	selectCustom = selectCustom or false
	demands = data.ItemList or {}
	log("demand list: "..Helper.Format(demands))
	_demandList = this.ConstructDemandList(demands)
	_customDemand = this.ConstructCustomDemandList(data.ItemCustom)
	table.sort(_demandList, DemandSortFunc)
	-- refresh custom demand info
	this.RefreshCustomDemandInfo(data)

	GameNotifier.Notify(GameEvent.DemandChanged, selectCustom)
end

function GameData.RefreshCustomDemandInfo(data)
	_customDemandInfo = {}
	_customDemandInfo.rewardId = data.LastCustomReward or 0
	_customDemandInfo.submitId = data.LastCustomSubmit or 0
	_customDemandInfo.leftCount = data.CustomRefreshChance or 0
	_customDemandInfo.timestamp = data.LastRefreshChanceTime or 0
end

function GameData.InitializeCustomDemandInfo()
	_customDemandInfo = {}
	_customDemandInfo.rewardId = 0
	_customDemandInfo.submitId = 0
	_customDemandInfo.leftCount = CustomDemandDailyRefresh
	_customDemandInfo.timestamp = GameData.GetServerTime()
end

function GameData.ConstructDemandList(demands)
	local demandList = {}

	for idx = 1, #demands do
		local demandId = demands[idx].DemandID
		local activateTime = demands[idx].RefreshTime
		local groupId = demands[idx].DemandGroupID or 0
		local demandRewards = demands[idx].RewardList or {}
		local locked = demands[idx].Lock or false
		
		local rewardList = {}
		for m = 1, #demandRewards do
			local rewardItemId = demandRewards[m][1]
			local rewardItemNum = demandRewards[m][2]
			rewardList[m] = {id = rewardItemId, num = rewardItemNum}
		end

		demandList[idx] = {id = demandId, activateTime = activateTime, groupId = groupId, rewardList = rewardList, locked = locked}
	end

	return demandList
end

function GameData.ConstructCustomDemandList(demandData)
	if demandData == nil or demandData.DemandID == nil then
		return nil
	end

	local demandId = demandData.DemandID
	local activateTime = demandData.RefreshTime
	local groupId = demandData.DemandGroupID or 0
	local demandRewards = demandData.RewardList or {}
		
	local rewardList = {}
	for m = 1, #demandRewards do
		local rewardItemId = demandRewards[m][1]
		local rewardItemNum = demandRewards[m][2]
		rewardList[m] = {id = rewardItemId, num = rewardItemNum}
	end

	return {id = demandId, activateTime = activateTime, groupId = groupId, rewardList = rewardList, locked = false}
end
---------------------------------------------------------------
function GameData.SetTimeLimitedActivity(activityList)
	_timeLimitedActivities = {}

	activityList = activityList or {}
	--log("time limited activity list: "..Helper.Format(activityList))
	--XDebug.LogTable('Activity', "SetTimeLimitedActivity", activityList)
	for k, v in pairs(activityList) do
		local activityId = v.ActivityId
		local startTime = v.StartTime or 0
		local endTime = v.EndTime or 0
		local poolId = v.PoolId

		_timeLimitedActivities[activityId] = {startTime = startTime, endTime = endTime, poolId = poolId}
	end

	GameNotifier.Notify(GameEvent.TimeLimitActivityChanged)
end

function GameData.HasTimeLimitActivity()
	local activityId = this.GetValidActivityId()
	return activityId ~= nil
end

function GameData.GetValidActivityId()
	local curTime = this.GetServerTime()
	for k, v in pairs(_timeLimitedActivities) do
		if curTime >= v.startTime and curTime < v.endTime then
			return k
		end
	end

	return nil
end

function GameData.IsGoalPoolValid(goalPoolId)
	local curTime = this.GetServerTime()
	for k, v in pairs(_timeLimitedActivities) do
		if curTime >= v.startTime and curTime < v.endTime and goalPoolId == v.poolId then
			return true
		end
	end

	return false
end

function GameData.GetActivityInfo(activityId)
	return _timeLimitedActivities[activityId]
end

function GameData.SetTimeLimitedDemandList(activityId, demandList)
	_timeLimitedDemandList = {}

	demandList = demandList or {}
	log("time limited demand activity: "..tostring(activityId).."; demand list: "..Helper.Format(demandList))

	if ConfigUtils.IsValidItem(activityId) and _timeLimitedActivities[activityId] ~= nil then
		_timeLimitedDemandList = {
			activityId = activityId,
			demandList = this.ConstructDemandList(demandList)
		}
		-- do sort
		table.sort(_timeLimitedDemandList.demandList, DemandSortFunc)
	end
end

function GameData.GetTimeLimitedDemandList()
	return _timeLimitedDemandList
end

function GameData.GetLatestNewActivity()
	local tmpTime = nil

	local curTime = this.GetServerTime()
	for k, v in pairs(_timeLimitedActivities) do
		if v.startTime > curTime and (tmpTime == nil or v.startTime < tmpTime) then
			tmpTime = v.startTime
		end 
	end

	return tmpTime
end

---------------------------------------------------------------
function GameData.InitBulletinData(data)
	data = data or {}
	_bulletinData = {}
	for i, v in pairs(data) do
		local time = v.Time
		if this.GetServerTime() <= time then
			local notice = {}
			local title = v.Title
			local content = v.Content
			local type = v.Type
			local id = v.Id
			notice = { id = id, title = title, time = time, content = content, type = type }
			table.insert(_bulletinData, notice)
			GameData.CheckBulletinStr(content)
		end
	end
	table.sort(_bulletinData, GameData.BulletinDataSortFunc)
end

function GameData.CheckBulletinTextureContainUrl(url)
	if _bulletinTexture == nil then
		return false
	end

	for _, textureTab in pairs(_bulletinTexture) do
		if textureTab.url == url then
			if textureTab.texture ~= nil then
				return true
			end
		end
	end

	return false
end

function GameData.CheckBulletinStr(str)
	str = str or {}
	local finaStr = str
	local urls = {}
	local labelStart = 0
	local labelEnd = nil

	while labelStart ~= nil do
		labelStart = string.find(str, "%[sprite=")
		if labelStart ~= nil then
			labelEnd = string.find(str, "%]%[/sprite%]")
			local url = string.sub(str, labelStart + 8, labelEnd - 1)
			table.insert(urls, url)
			str = string.sub(str, labelEnd + 10)
		end
	end

	GameData.SetBulletinTexture(urls)

	return finaStr
end

function GameData.SetBulletinTexture(urls)
	_bulletinTexture = _bulletinTexture or {}
	for k, url in pairs(urls) do
		if not GameData.CheckBulletinTextureContainUrl(url) then
			NetManager.DownloadTexture(url, function(texture)
				table.insert(_bulletinTexture, { url = url, texture = texture })
			end)
		end
	end
end

function GameData.GetBulletinTexture(url)
	if _bulletinTexture ~= nil then
		for k, v in pairs(_bulletinTexture) do
			if v.url == url then
				return v.texture
			end
		end
	end
	return nil
end

function GameData.BulletinDataSortFunc(elementA, elementB)
	if elementA == nil or elementB == nil then
		return false
	end

	local valueA = elementA.type
	local valueB = elementB.type
	return valueA < valueB
end

function GameData.GetBulletinData()
	return _bulletinData
end

function GameData.HasNewBulletin(type)
	for k, v in pairs(_bulletinData) do
		if v.type == type then
			return v.id > GameData.GetLastBulletinId(type)
		end
	end
	return false
end

function GameData.MarkBulletinRead(type)
	for k, v in pairs(_bulletinData) do
		if v.type == type then
			GameData.SetLastBulletinId(v.type, v.id)
			GameNotifier.Notify(GameEvent.BulletinStateChanged)
		end
	end
end

function GameData.ShowBulletinHit()
	if _bulletinData == nil then
		return false
	end

	for k, v in pairs(_bulletinData) do
		local result = v.id > this.GetLastBulletinId(v.type)
		if result then
			return true
		end
	end

	return false
end
---------------------------------------------------------------
function GameData.InitWeeklyReport(data)
	data = data or {}
	_weeklyReportData =  {}
	_weeklyReportData.url = data.Url
	_weeklyReportData.time = data.Time or 0
	_weeklyReportData.texture = nil
	_weeklyReportData.textureTime = 0
	_weeklyReportData.isLoading = false

	GameNotifier.Notify(GameEvent.WeeklyReportStateChanged)
end

function GameData.MarkWeeklyReport()
	this.SetWeeklyReadTimestamp(_weeklyReportData.time)
	GameNotifier.Notify(GameEvent.WeeklyReportStateChanged)
end

function GameData.HasWeeklyReport()
	if _weeklyReportData.time == 0 then
		return false
	end

	if Helper.IsEmptyOrNull(_weeklyReportData.url) then
		return false
	end

	return true
end

function GameData.HasNewWeeklyReport()
	if not this.HasWeeklyReport() then
		return false
	end

	local lastReadTime = this.GetWeeklyReadTimestamp()
	if lastReadTime == nil then
		return true
	end

	return _weeklyReportData.time ~= lastReadTime
end

function GameData.GetWeeklyReportTexture()
	return _weeklyReportData.texture
end

function GameData.NeedUpdateWeeklyTexture()
	if not this.HasWeeklyReport() then
		return false
	end

	if _weeklyReportData.isLoading then
		return false
	end

	return _weeklyReportData.texture == nil or _weeklyReportData.textureTime ~= _weeklyReportData.time
end

function GameData.IsLoadingWeeklyTexture()
	if not this.HasWeeklyReport() then
		return false
	end

	return _weeklyReportData.isLoading or false
end

function GameData.CleanWeeklyTexture()
	_weeklyReportData.textureTime = 0
	if _weeklyReportData.texture ~= nil then
		destroy(_weeklyReportData.texture)
		_weeklyReportData.texture = nil
	end
end

function GameData.UpdateWeeklyTexture()
	this.CleanWeeklyTexture()
	_weeklyReportData.isLoading = true
	local url = _weeklyReportData.url.."?v="..tostring(_weeklyReportData.time)
	NetManager.DownloadTexture(url, GameData.OnWeeklyTextureDownloaded)
end

function GameData.OnWeeklyTextureDownloaded(texture)
	_weeklyReportData.isLoading = false
	if texture ~= nil then
		_weeklyReportData.texture = texture
		_weeklyReportData.textureTime = _weeklyReportData.time
		GameNotifier.Notify(GameEvent.WeeklyReportTextureLoaded, true)
	else
		GameNotifier.Notify(GameEvent.WeeklyReportTextureLoaded, false)
	end
end
---------------------------------------------------------------
function GameData.InitTouristData(data)
	_touristData = {}

	if data ~= nil then
		_touristData.id = data.TouristID
		_touristData.lastId = data.LastTouristID
		_touristData.startTime = data.StartTime or 0
		_touristData.endTime = data.EndTime or 0
	end

	log("tourist data: "..Helper.Format(_touristData))
	GameNotifier.Notify(GameEvent.TouristChanged)
end

function GameData.HasValidTourist()
	if not ConfigUtils.IsValidItem(_touristData.id) then
		return false
	end

	local startTime = _touristData.startTime
	local endTime = _touristData.endTime
	local currentTime = this.GetServerTime()

	return currentTime >= startTime and currentTime < endTime
end

function GameData.GetLastTouristId()
	return _touristData.lastId
end

function GameData.GetTouristId()
	return _touristData.id, _touristData.endTime
end

function GameData.GetTouristNotifyData()
	if not GameData.IsModuleUnlocked(ModuleNames.Tourist) then
		return nil
	end

	if not ConfigUtils.IsValidItem(_touristData.id) then
		return nil
	end

	local startTime = _touristData.startTime
	local endTime = _touristData.endTime
	local currentTime = this.GetServerTime()

	---延时推送
	local delta = 12 * 3600
	-- the current tourist
	if currentTime < startTime + delta then
		return startTime + delta
	end

	-- the next tourist
	if currentTime < endTime + delta then
		return endTime + delta
	end

	return nil
end

function GameData.NeedUpdateTourist()
	if not GameData.IsModuleUnlocked(ModuleNames.Tourist) then
		return false
	end

	if not ConfigUtils.IsValidItem(_touristData.id) then
		return true
	end

	local endTime = _touristData.endTime
	local currentTime = this.GetServerTime()
	return currentTime >= endTime
end
---------------------------------------------------------------
function GameData.SetSummonPoolList(summonList)
	_activitySummonPools = {}

	summonList = summonList or {}
	log("activity summon list: "..Helper.Format(summonList))
	for k, v in pairs(summonList) do
		local summonId = v.Summonid
		local startTime = v.StartTime or 0
		local endTime = v.EndTime or 0

		_activitySummonPools[summonId] = {startTime = startTime, endTime = endTime}
	end

	GameNotifier.Notify(GameEvent.SummonPoolChanged)
end

function GameData.GetActiveSummonList()
	local curTime = this.GetServerTime()
	local ret = {}
	-- first get from server configed summons
	for k, v in pairs(_activitySummonPools) do
		if ConfigUtils.IsEventSummon(k) then
			if curTime >= v.startTime and curTime < v.endTime then
				table.insert(ret, {id = k, startTime = v.startTime, endTime = v.endTime})
			end
		else
			table.insert(ret, {id = k})
		end
	end
	-- not configed yet, use local data
	if #ret == 0 then
		ret = ConfigUtils.GetNonEventSummonList()
	end

	return ret
end

function GameData.HasEventPool()
	local curTime = this.GetServerTime()

	for k, v in pairs(_activitySummonPools) do
		if ConfigUtils.IsEventSummon(k) then
			if curTime >= v.startTime and curTime < v.endTime then
				return true
			end
		end
	end

	return false
end

function GameData.IsSummonPoolOpen(summonId)
	if not ConfigUtils.IsEventSummon(summonId) then
		return true
	end

	local config = _activitySummonPools[summonId]
	if config == nil then
		return false
	end

	local curTime = this.GetServerTime()
	local startTime = config.startTime
	local endTime = config.endTime
	if curTime >= startTime and curTime < endTime then
		return true
	end

	return false
end

function GameData.GetLatestNewSummonPool()
	local tmpTime = nil

	local curTime = this.GetServerTime()
	for k, v in pairs(_activitySummonPools) do
		if v.startTime > curTime and (tmpTime == nil or v.startTime < tmpTime) then
			tmpTime = v.startTime
		end 
	end

	return tmpTime
end
---------------------------------------------------------------
function GameData.GetTimeZoneOffset()
	return TimeZoneOffsetInternal()
end

function GameData.GetBeginTimeOfDay(time)
	time = time or 0
	if time <= 0 then
		return 0
	end

	time = time - TimeZoneOffsetInternal()
	local date = os.date("*t", time)
	local weekDay = date.wday

	if time > 0 then
        date.hour = 0
        date.min = 0
        date.sec = 0
    end

    local ret = os.time(date)
    ret = ret + TimeZoneOffsetInternal()
    return ret, weekDay
end

function GameData.GetBeginTimeOfWeek(time)
	local beginOfDay, weekDay = this.GetBeginTimeOfDay(time)
	
	local diff = 0
	-- sunday
	if weekDay == 1 then
		diff = 6 * 3600 * 24
	else
		diff = (weekDay - 2) * 3600 * 24
	end

	local weekBegin = beginOfDay - diff
	return  weekBegin
end

function GameData.IsDifferentDay(time1, time2)
    local day1 = Helper.GetDayOfTime(time1 + SERVER_TIME_ZONE * 3600)
    local day2 = Helper.GetDayOfTime(time2 + SERVER_TIME_ZONE * 3600)

    return day1 ~= day2
end

function GameData.GetDayDiffer(bigTime, smallTime)
	local bidDay = Helper.GetDayOfTime(bigTime + SERVER_TIME_ZONE * 3600)
    local smallDay = Helper.GetDayOfTime(smallTime + SERVER_TIME_ZONE * 3600)

    return bidDay - smallDay
end

function GameData.HasSignInReward()
	local lastTime = _signInRewardTimestamp
	local curTime = this.GetServerTime()
	return this.IsDifferentDay(lastTime, curTime)
end

function GameData.MarkSignIn()
	_signInInDays = _signInInDays + 1
	_signInRewardTimestamp = this.GetServerTime()
end

function GameData.GetSignInDays()
	return math.max(1, _signInInDays)
end

-- return the n-th group since signed-in
function GameData.GetSignInGroup(daysPerGroup)
	local thisDay = _signInInDays
	if this.CanSignIn(thisDay + 1) then
		thisDay = thisDay + 1
	end

	local group = math.ceil(thisDay / daysPerGroup)
	group = math.max(1, group)
	return group
end

function GameData.CanSignIn(thisDay)
	if _signInInDays == 0 or _signInRewardTimestamp == 0 then
		return thisDay == 1
	end

	if thisDay <= _signInInDays then
		return false
	end

	local nextDay = _signInInDays + 1
	if thisDay == nextDay then
		local lastTime = _signInRewardTimestamp
		local curTime = this.GetServerTime()
		return this.IsDifferentDay(lastTime, curTime)
	end

	return false
end

function GameData.HasDrawedSignInReward(thisDay)
	return thisDay <= _signInInDays
end

function GameData.GetCurrentSignInDay()
	if _signInInDays == 0 or _signInRewardTimestamp == 0 then
		return 1
	end

	local lastTime = _signInRewardTimestamp
	local curTime = this.GetServerTime()
	local thisDay = _signInInDays
	if this.IsDifferentDay(lastTime, curTime) then
		thisDay = thisDay + 1
	end

	return thisDay
end
---------------------------------------------------------------
function GameData.InitMail(mailList)
	_mailData = {}
	local mailList = mailList or {}
	--log("======================mail list: "..Helper.Format(mailList))
	for idx = 1, #mailList do
		local mailId = mailList[idx].MailId
		local mailType = mailList[idx].MailType
		local mailTitle = mailList[idx].Title
		local mailContent = mailList[idx].Content
		local mailTime = mailList[idx].ReceiveTime or 0
		local mailRead = mailList[idx].IsRead
		local mailRewarded = mailList[idx].IsReward
		local expireTime = mailList[idx].ExpireTime
		local mailRewardList = mailList[idx].RewardList or {}
		local rewardList = {}
		for rewardIdx = 1, #mailRewardList do
			rewardList[rewardIdx] = {id = mailRewardList[rewardIdx][1], num = mailRewardList[rewardIdx][2]}
		end

		if expireTime == nil then
			expireTime = mailTime + 10 * 24 * 3600
		end

		_mailData[mailId] = {
			title = mailTitle,
			content = mailContent,
			time = mailTime,
			read = mailRead,
			rewarded = mailRewarded,
			rewardList = rewardList,
			expireTime = expireTime,
		}
	end

	GameNotifier.Notify(GameEvent.MailStateChanged)
end

function GameData.HasNewMail()
	local currentTime = this.GetServerTime()
	for k, v in pairs(_mailData) do
		-- make sure not expired
		if v.expireTime > currentTime then
			-- not read
			if not v.read then
				return true
			end

			-- read but not get reward
			if #v.rewardList > 0 and not v.rewarded then
				return true
			end
		end
	end

	return false
end

function GameData.GetMailTime(mailId)
	assert(_mailData[mailId] ~= nil, "mail not exist: "..tostring(mailId))
	return _mailData[mailId].time
end

function GameData.GetMailExpireTime(mailId)
	assert(_mailData[mailId] ~= nil, "mail not exist: "..tostring(mailId))
	return _mailData[mailId].expireTime
end

function GameData.GetMailData(mailId)
	assert(_mailData[mailId] ~= nil, "mail not exist: "..tostring(mailId))

	local data = _mailData[mailId]
	return data.title, data.content, data.read, data.rewarded, data.rewardList
end

function GameData.ReadMail(mailId)
	assert(_mailData[mailId] ~= nil, "mail not exist: "..tostring(mailId))
	_mailData[mailId].read = true
end

function GameData.GetRewardOfMail(mailId)
	assert(_mailData[mailId] ~= nil, "mail not exist: "..tostring(mailId))
	_mailData[mailId].rewarded = true

	local rewardList = _mailData[mailId].rewardList
	for _, v in pairs(rewardList) do
		this.CollectItem(v.id, v.num, true)
	end
end

function GameData.GetValidMailList()
	local ret = {}

	local currentTime = this.GetServerTime()
	for k, v in pairs(_mailData) do
		if v.expireTime > currentTime then
			table.insert(ret, k)
		end
	end

	return ret
end
---------------------------------------------------------------
function GameData.InitMarketData(data)
	_marketData = {}

	local marketList = data or {}

	--log("market data: "..Helper.Format(marketList))

	for idx = 1, #marketList do
		local e = marketList[idx]
		_marketData[idx] = {id = e[1], num = e[2], price = e[3], sold = (e[4] == 1)}
	end
end

function GameData.GetMarketRefreshTime()
	return _marketRefreshTimestamp + 3600
end

function GameData.MarkMarketRefreshTime(timestamp)
	_marketRefreshTimestamp = timestamp
end

function GameData.CanRefreshMarket()
	if _marketRefreshTimestamp == 0 then
		return false
	end

	local nextRefreshTime = this.GetMarketRefreshTime()
	local curTime = this.GetServerTime()

	return curTime >= nextRefreshTime
end

function GameData.GetMarketData()
	return _marketData
end

function GameData.SoldMarketItemAt(idx)
	_marketData[idx].sold = true

	local itemId = _marketData[idx].id
	local itemNum = _marketData[idx].num
	local goldSold = _marketData[idx].price
	this.ConsumeItem(itemId, itemNum)
end

function GameData.HasMarketData()
	if _marketRefreshTimestamp == 0 or #_marketData == 0 then
		return false
	end

	return true
end
-----------------------------------------------------------------
---- 活动签到数据
function GameData.InitActivitySignInData(data)
	_activitySignInDays = data.SignInDays or 0
	_activitySignInRewardTimestamp = data.LastSignInTime
end

-- 获取活动签到的天数
function GameData.GetActivitySignInDays()
	--return _activitySignInDays
	if _activitySignInDays == 0 or _activitySignInRewardTimestamp == 0 then
		return 1
	end

	local lastTime = _activitySignInRewardTimestamp
	local curTime = this.GetServerTime()
	local thisDay = _activitySignInDays
	if this.IsDifferentDay(lastTime, curTime) then
		thisDay = thisDay + 1
	end

	return thisDay
end

function GameData.GetActivityNeedCompensateItems()
	if _activitySignInDays < 1 then
		return nil
	end
	local days = _activitySignInDays
	local rewardList = GameData.GetCurrentActivityExtraDailyReward()
	local rewards = {}
	for idx = 1, #rewardList do
		local rewardId = rewardList[idx].Value
		local rewardNum = rewardList[idx].Num * days
		table.insert(rewards, { Id = rewardId, Num = rewardNum })
	end
	return rewards
end

function GameData.GetActivitySignInGroup(daysPerGroup)
	local thisDay = _activitySignInDays
	if this.CanActivitySignIn(thisDay + 1) then
		thisDay = thisDay + 1
	end

	local group = math.ceil(thisDay / daysPerGroup)
	group = math.max(1, group)
	return group
end

function GameData.CanActivitySignIn(thisDay)
	-- 活动时间可能会多于签到时间
	if thisDay > #GameData.GetCurrentActivitySignInList() then
		return false
	end
	if _activitySignInDays == 0 or _activitySignInRewardTimestamp == 0 then
		return thisDay == 1
	end
	if thisDay <= _activitySignInDays then
		return false
	end

	local nextDay = _activitySignInDays + 1
	if thisDay == nextDay then
		local lastTime = _activitySignInRewardTimestamp
		local curTime = this.GetServerTime()
		return this.IsDifferentDay(lastTime, curTime)
	end

	return false
end

function GameData.HasYetActivitySignInReward(thisDay)
	return thisDay <= _activitySignInDays
end

function GameData.GetCurrentActivitySignInDay()
	if _activitySignInDays == 0 or _activitySignInRewardTimestamp == 0 then
		return 1
	end

	local lastTime = _activitySignInRewardTimestamp
	local curTime = this.GetServerTime()
	local thisDay = _activitySignInDays
	if this.IsDifferentDay(lastTime, curTime) then
		thisDay = thisDay + 1
	end
	return thisDay
end

function GameData.HasActivitySignInPassCheck()
	local currentTheme = GameData.GetCurrentActivityTheme()
	if currentTheme then
		local config = ActivityThemeConfig[currentTheme]
		--assert(config ~= nil and config.ActivityPassCheck ~= nil, "invalid activity id:" .. tostring(currentTheme))
		return config.ActivityPassCheck ~= nil
	end
	--assert(currentTheme ~= nil, "invalid activity id!")
	return false
end

function GameData.HasActivitySignInReward()
	local curDay = GameData.GetActivitySignInDays()
	return GameData.CanActivitySignIn(curDay)
end

function GameData.IsShowActivitySignIn()
	local curDay = GameData.GetActivitySignInDays()
	-- 活动时间可能会多于签到时间
	if curDay > #GameData.GetCurrentActivitySignInList() then
		return false
	end
	return true
end

function GameData.MarkActivitySignIn()
	_activitySignInDays = _activitySignInDays + 1
	_activitySignInRewardTimestamp = this.GetServerTime()
end

-- 获取活动签到奖励列表
function GameData.GetCurrentActivitySignInList()
	local currentTheme = GameData.GetCurrentActivityTheme()
	assert(currentTheme ~= nil, "invalid activity id!")
	local config = ActivityThemeConfig[currentTheme]
	assert(config ~= nil and config.ActivityDailyLoginList, "invalid activity id:" .. tostring(currentTheme))
	return config.ActivityDailyLoginList
end

-- 获取活动通行证签到特权奖励
function GameData.GetCurrentActivityExtraDailyReward()
	local currentTheme = GameData.GetCurrentActivityTheme()
	assert(currentTheme ~= nil, "invalid activity id!")
	local config = ActivityThemeConfig[currentTheme]
	assert(config ~= nil and config.ActivityPassCheck, "invalid activity id:" .. tostring(currentTheme))
	return config.ActivityPassCheck.ExtraActivityDailyLogin
end

function GameData.GetCurrentActivityPassCheck()
	local currentTheme = GameData.GetCurrentActivityTheme()
	assert(currentTheme ~= nil, "invalid activity id!")
	local config = ActivityThemeConfig[currentTheme]
	assert(config ~= nil and config.ActivityPassCheck, "invalid activity id:" .. tostring(currentTheme))
	return config.ActivityPassCheck
end

function GameData.GetActivitySignInReward(index)
	local rewardList = GameData.GetCurrentActivitySignInList()
	local rewardId, rewardNum = ConfigUtils.GetActivitySignInReward(rewardList[index])
	return rewardId, rewardNum
end

local hasOpenActivitySignIn = false
-- 活动签到界面展示逻辑
function GameData.CanOpenActivitySignInPanel()
	if hasOpenActivitySignIn then
		return false
	end
	hasOpenActivitySignIn = true
	if GameData.IsModuleUnlocked(ModuleNames.Activity) then
		local currentThemeId = GameData.GetCurrentActivityTheme()
		XDebug.Log("LZ","currentThemeId:",currentThemeId)
		if currentThemeId ~= nil and ConfigUtils.IsValidActivitySignIn(currentThemeId) then
			if this.HasActivitySignInReward() then
				return true
			end
		end
	end
	return false
end

-- 获取当前活动的通行证IAPId
function GameData.GetCurrentActivityPassport()
	local currentTheme = GameData.GetCurrentActivityTheme()
	if not currentTheme then
		return -1
	end
	local config = ActivityThemeConfig[currentTheme]
	if not config or not config.ActivityPassCheck then
		return -1
	end
	return config.ActivityPassCheck.IAPId
end

-- 捉迷藏
--- 初始化捉迷藏数据
function GameData.InitHideSeekData(data)
	data = data or {} 
	_hideSeekData = {}
	if data.Status then
		_unlockHideSeekActivity = data.Status == 1
	else
		_unlockHideSeekActivity = false
	end

	if data.RabbitFindCount then
		_hideSeekFindCount = data.RabbitFindCount
	else
		_hideSeekFindCount = 0
	end
	if data.RabbitList then
		XDebug.LogTable("LZ", "Rabbit data:", data)
		local RabbitList = data.RabbitList
		for idx = 1, #RabbitList do
			if RabbitList[idx].IsFind then
				RabbitList[idx].IsNew = false
			end
			table.insert(_hideSeekData, RabbitList[idx])
		end
		GameNotifier.Notify(GameEvent.HideSeekDataChanged)
	end

end

function GameData.GetHideSeekData()
	return _hideSeekData
end

--- 捉迷藏的抓到兔子的总数
function GameData.GetTotalHideSeekFindCount()
	return _hideSeekFindCount
end

---今天捉迷藏的抓到兔子的数量
function GameData.GetTodayHideSeekFindCount()
	local num = 0
	for idx = 1, #_hideSeekData do
		if _hideSeekData[idx].IsFind then
			num = num + 1
		end
	end
	return num
end

--- 是否开启捉迷藏活动
function GameData.UnlockHideSeekActivity()
	return _unlockHideSeekActivity
end

--- 更改已找到兔子的状态
function GameData.SetHideSeekRabbitData(rabbitId)
	for idx = 1, #_hideSeekData do
		if _hideSeekData[idx].RabbitId == rabbitId then
			_hideSeekData[idx].IsFind = true
		end
	end
	_hideSeekFindCount = _hideSeekFindCount + 1
	GameNotifier.Notify(GameEvent.HideSeekDataChanged)
end

function GameData.GetHideSeekRabbitIsFind(rabbitId)
	for idx = 1, #_hideSeekData do
		if _hideSeekData[idx].RabbitId == rabbitId then
			return _hideSeekData[idx].IsFind
		end
	end
	return false
end

function GameData.SetHideSeekRabbitDataWithNewTag(rabbitId)
	for idx = 1, #_hideSeekData do
		if _hideSeekData[idx].RabbitId == rabbitId then
			_hideSeekData[idx].IsNew = false
		end
	end
	--GameNotifier.Notify(GameEvent.HideSeekDataChanged)
end

--- 已经显示过的兔子数量
function GameData.GetOldHideSeekDataCount()
	local num = 0
	for idx = 1, #_hideSeekData do
		if not _hideSeekData[idx].IsNew then
			num = num + 1
		end
	end
	return num
end
-----------------------------------------------------------------------

function GameData.InitFurnitureDeliveryData(data)
	data = data or {}
	_deliverFurnitureData = {}
	for k, v in pairs(data) do
		for idx = 1, #v do
			table.insert(_deliverFurnitureData, {id = tonumber(k), deliverTime = v[idx]})
		end
	end
	GameNotifier.Notify(GameEvent.DeliverFurnitureStatusChanged)
end

function GameData.GetFurnitureDeliveryData(data)
	_deliverFurnitureData = _deliverFurnitureData or {}
	return _deliverFurnitureData
end

function GameData.GetFurnitureDeliveryStatus()
	local status = EFurnitureDeliveryStatus.Empty
	if not Helper.IsEmpty(_deliverFurnitureData) then
		local curTime = GameData.GetServerTime()
		for idx = 1, #_deliverFurnitureData do
			if _deliverFurnitureData[idx].deliverTime <= curTime then
				status = EFurnitureDeliveryStatus.Arrived
				break
			else
				status = EFurnitureDeliveryStatus.Transporting
			end
		end
	end
	return status
end


-----------------------------------------------------------------------
