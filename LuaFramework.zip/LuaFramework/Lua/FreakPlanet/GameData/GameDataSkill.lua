local this = GameData

FilterSkillType = {
	NoBattleRoundSkill = 1,
	OnlyBattleRoundSkill = 2,
	NoFilter = 3,
}
------------------------------------------------------------------------------------
local function CheckRarity(thisRarity, rarity, rarityOp)
	rarityOp = rarityOp or RarityOp.GE
	if rarityOp == RarityOp.GE then
		return thisRarity >= rarity
	elseif rarityOp == RarityOp.LE then
		return thisRarity <= rarity
	else
		assert(false, "un-handled rarity operator: "..tostring(rarityOp))
	end
end
------------------------------------------------------------------------------------
function GameData.IsSkillConditionMatch(skillId, skillSourceMember, sourceMemberPosition, characters, conditionMustBeNull)
	local effectCondition = ConfigUtils.GetSkillEffectCondition(skillId)
	if effectCondition == nil then
		return true, #characters
	end

	conditionMustBeNull = conditionMustBeNull or false
	if conditionMustBeNull then
		return false
	end
	
	-- teamer
	local needCharacters = effectCondition.Teamer or {}
	for idx = 1, #needCharacters do
		local needCharacterId = needCharacters[idx]
		if not Helper.TableContains(characters, needCharacterId) then
			return false
		end
	end
	-- source member position
	if effectCondition.SelfPosition ~= nil then
		-- position of pet is nil, as pet has no position
		if sourceMemberPosition == nil then
			return false
		end

		local needPosition = effectCondition.SelfPosition
		assert(needPosition ~= 0, "need self postion can't be 0")
		local thisPosition = sourceMemberPosition
		local thisReversePosition = thisPosition - #characters - 1

		if needPosition > 0 then
			if needPosition ~= thisPosition then
				return false
			end
		else
			if needPosition ~= thisReversePosition then
				return false
			end
		end
	end
	-- rarity, element and tag
	local matchNum = 0
	for idx = 1, #characters do
		local characterId = characters[idx]
		
		local match = true
		if match and effectCondition.Rarity ~= nil then
			local thisRarity = ConfigUtils.GetItemRarity(characterId)
			local rarityOp = effectCondition.RarityOp
			match = CheckRarity(thisRarity, effectCondition.Rarity, rarityOp)
		end

		if match and effectCondition.Element ~= nil then
			local thisElement = ConfigUtils.GetElementOfItem(characterId)
			match = (thisElement == effectCondition.Element)
		end

		if match and effectCondition.Tag ~= nil then
			local thisTags = ConfigUtils.GetItemTags(characterId)
			local needTags = effectCondition.Tag
			-- should contain all the need tags
			for tagIdx = 1, #needTags do
				if not Helper.TableContains(thisTags, needTags[tagIdx]) then
					match = false
					break
				end
			end
		end

		if match then
			matchNum = matchNum + 1
		end
	end

	return matchNum > 0, matchNum
end
------------------------------------------------------------------------------------
function GameData.ConstructAbilityMapOfSkills(skills)
	local ret = {}

	for idx = 1, #skills do
		local skillId = skills[idx].id
		local skillValue = skills[idx].value
		local skillEffectParameter = ConfigUtils.GetSkillEffectParameter(skillId)
		if skillEffectParameter.EffectAttribute == EffectAttribute.Ability or 
			skillEffectParameter.EffectAttribute == EffectAttribute.SpecificEnemyAbility or 
			skillEffectParameter.EffectAttribute == EffectAttribute.AttributeWithHurt then
			local skillEffectAbilityId = skillEffectParameter.EffectValue
			local effectedAbilities = {}
			if skillEffectAbilityId == nil or skillEffectAbilityId == -1 then
				for k, v in  pairs(AbilityConfig) do
					table.insert(effectedAbilities, k)
				end
			else
				effectedAbilities[1] = skillEffectAbilityId
			end

			local calcType = skillEffectParameter.CalculateType
			for m = 1, #effectedAbilities do
				local abilityId = effectedAbilities[m]
				if ret[abilityId] == nil then
					ret[abilityId] = {abs = 0, percent = 0}
				end

				if calcType == CalculateType.Percent then
					ret[abilityId].percent = ret[abilityId].percent + skillValue * 0.01
				elseif calcType == CalculateType.Abs then
					ret[abilityId].abs = ret[abilityId].abs + skillValue
				else
					assert(false, "un-handled calculate type: "..tostring(calcType).." from skill: "..tostring(skillId))
				end
			end
		end
	end

	return ret
end

function GameData.ConstructElementMapOfSkills(skills)
	local ret = {}

	for idx = 1, #skills do
		local skillId = skills[idx].id
		local skillValue = skills[idx].value
		local skillEffectParameter = ConfigUtils.GetSkillEffectParameter(skillId)
		if skillEffectParameter.EffectAttribute == EffectAttribute.DamageToElement or 
		   skillEffectParameter.EffectAttribute == EffectAttribute.DamageFromElement then
			local skillEffectElementId = skillEffectParameter.EffectValue
			local effectedElements = {}
			if skillEffectElementId == nil or skillEffectElementId == -1 then
				for k, v in  pairs(ElementConfig) do
					table.insert(effectedElements, k)
				end
			else
				effectedElements[1] = skillEffectElementId
			end

			local calcType = skillEffectParameter.CalculateType
			for m = 1, #effectedElements do
				if calcType == CalculateType.Percent then
					local elementId = effectedElements[m]
					local preValue = ret[elementId] or 0
					ret[elementId] = preValue + skillValue * 0.01
				else
					assert(false, "un-handled calculate type: "..tostring(calcType).." from skill: "..tostring(skillId))
				end
			end
		end
	end

	return ret
end

function GameData.GetSkillTotalValue(skillMap)
	local addValue = 0
	local addPercent = 0
	for k, skills in pairs(skillMap) do
		for idx = 1, #skills do
			local skillId = skills[idx].id
			local skillValue = skills[idx].value
			local calcType = ConfigUtils.GetSkillEffectCalculateType(skillId)

			if calcType == CalculateType.Percent then
				addPercent = addPercent + skillValue * 0.01
			elseif calcType == CalculateType.Abs then
				addValue = addValue + skillValue
			else
				assert(false, "un-handled calculate type: "..tostring(calcType).." for skill: "..tostring(skillId))
			end
		end
	end

	addPercent = Helper.Round(addPercent, 2)
	return addValue, addPercent
end

function GameData.GetSkillListTotalValue(skillList)
	local addValue = 0
	local addPercent = 0
	for idx = 1, #skillList do
		local skillId = skillList[idx].id
		local skillValue = skillList[idx].value
		local calcType = ConfigUtils.GetSkillEffectCalculateType(skillId)

		if calcType == CalculateType.Percent then
			addPercent = addPercent + skillValue * 0.01
		elseif calcType == CalculateType.Abs then
			addValue = addValue + skillValue
		else
			assert(false, "un-handled calculate type: "..tostring(calcType).." for skill: "..tostring(skillId))
		end
	end

	addPercent = Helper.Round(addPercent, 2)
	return addValue, addPercent
end

function GameData.GetSkillAddPercentValue(skillMap)
	local addPercent = 0
	for k, skills in pairs(skillMap) do
		addPercent = addPercent + this.GetAddPercentValueOfSkillList(skills)
	end

	addPercent = Helper.Round(addPercent, 2)
	return addPercent
end

function GameData.GetAddPercentValueOfSkillList(skillList)
	local addPercent = 0

	for idx = 1, #skillList do
		local skillId = skillList[idx].id
		local skillValue = skillList[idx].value
		local calcType = ConfigUtils.GetSkillEffectCalculateType(skillId)

		if calcType == CalculateType.Percent then
			addPercent = addPercent + skillValue * 0.01
		else
			assert(false, "un-handled calculate type: "..tostring(calcType).." for skill: "..tostring(skillId))
		end
	end

	addPercent = Helper.Round(addPercent, 2)
	return addPercent
end

---获得角色的所有已激活的技能(自身+装备+皮肤+房间)
---@param characterId 角色ID
function GameData.GetCharacterSkillList(characterId)
	-- skills from stage
	local characterStage = this.GetCharacterCurrentStage(characterId)
	local activatedSkillList = ConfigUtils.GetCharacterActivedSkillsAt(characterId, characterStage)
	-- skills from equipment
	local unlockedEquipments = this.GetCharacterUnlockedEquipments(characterId)
	local equipmentSkillList = ConfigUtils.GetEquipmentSkillList(unlockedEquipments)
	-- skills from skin
	local skinId = this.GetCharacterSkin(characterId)
	local skinSkillList = ConfigUtils.GetSkinSkill(skinId)
	-- skills from room
	local roomSkillList = this.GetCharacterRoomSkillList(characterId)

	local ret = {}

	for idx = 1, #activatedSkillList do
		table.insert(ret, {id = activatedSkillList[idx].id, value = activatedSkillList[idx].value})
	end

	for idx = 1, #equipmentSkillList do
		table.insert(ret, {id = equipmentSkillList[idx].id, value = equipmentSkillList[idx].value})
	end

	for idx = 1, #skinSkillList do
		table.insert(ret, {id = skinSkillList[idx].id, value = skinSkillList[idx].value})
	end

	for idx = 1, #roomSkillList do
		table.insert(ret, {id = roomSkillList[idx].id, value = roomSkillList[idx].value})
	end

	return ret
end

function GameData.GetPetSkillList(petId)
	local petLevel = this.GetPetLevel(petId)
	local ret = ConfigUtils.GetPetActivedSkillsAt(petId, petLevel)
	return ret
end

function GameData.GetSkillEffectedMembers(skillId, skillSourceMember, sourceMemberPosition, characters)
	local effectRange = ConfigUtils.GetSkillEffectRange(skillId)
	assert(effectRange ~= nil, "empty effect range of skill: "..tostring(effectRange))
	local effectScope = effectRange.EffectScope

	local memberList = {}
	if effectScope == EffectScope.Self then
		memberList[1] = skillSourceMember
	elseif effectScope == EffectScope.Team then
		if effectRange.Characters == nil then
			-- the whole selected characters
			Helper.CopyTable(memberList, characters)
		else
			-- specific characters
			for idx = 1, #effectRange.Characters do
				local effectCharacterId = effectRange.Characters[idx]
				if Helper.TableContains(characters, effectCharacterId) then
					table.insert(memberList, effectCharacterId)
				end
			end
		end
	elseif effectScope == EffectScope.RelativePosition then
		if sourceMemberPosition ~= nil then
			local positions = effectRange.PositionValue or {}
			for idx = 1, #positions do
				-- relative position to source member position
				local actualPosition = sourceMemberPosition + positions[idx]
				if actualPosition >= 1 and actualPosition <= #characters then
					table.insert(memberList, characters[actualPosition])
				end
			end
		end
	elseif effectScope == EffectScope.FixPosition then
		local positions = effectRange.PositionValue or {}
		for idx = 1, #positions do
			local actualPosition = positions[idx]
			actualPosition = actualPosition >= 0 and actualPosition or (actualPosition + #characters + 1)
			if actualPosition >= 1 and actualPosition <= #characters then
				table.insert(memberList, characters[actualPosition])
			end
		end
	else
		assert(false, "un-handled effect scope type: "..tostring(effectScope))
	end

	local ret = {}

	for idx = 1, #memberList do
		local memberId = memberList[idx]

		local match = true
		if match and effectRange.Rarity ~= nil then
			local thisRarity = ConfigUtils.GetItemRarity(memberId)
			local rarityOp = effectRange.RarityOp
			match = CheckRarity(thisRarity, effectRange.Rarity, rarityOp)
		end

		if match and effectRange.Element ~= nil then
			local thisElement = ConfigUtils.GetElementOfItem(memberId)
			match = (thisElement == effectRange.Element)
		end

		if match and effectRange.Tag ~= nil then
			local thisTags = ConfigUtils.GetItemTags(memberId)
			local needTags = effectRange.Tag
			-- should contain all the need tags
			for tagIdx = 1, #needTags do
				if not Helper.TableContains(thisTags, needTags[tagIdx]) then
					match = false
					break
				end
			end
		end

		if match then
			table.insert(ret, memberId)
		end
	end

	return ret
end

-- filters
--  effectAttribute
--  effectModule
--  effectScope
--  nullCondition : if true, the condition must be null
--  skillType : FilterSkillType; if is null, only return skills not battle round
--  globalSkills: some occasion provide global buffs; for now: arena and couple skills
function GameData.GetGroupSkillMap(characters, petId, filters)
	filters = filters or {}
	characters = characters or {}

	local globalSkills = filters.globalSkills or {}

	if not ConfigUtils.IsValidItem(petId) then
		petId = nil
	end

	local group = {}
	Helper.CopyTable(group, characters)
	-- pet should always at end, so the position of the character is same with position in character array
	if petId ~= nil then
		table.insert(group, petId)
	end

	local globalMemberId = -1
	if #globalSkills > 0 then
		table.insert(group, globalMemberId)
	end

	local memberToSkills = {}

	for idx = 1, #group do
		local memberId = group[idx]
		local skillList = {}
		if memberId == globalMemberId then
			skillList = globalSkills
		else
			local itemType = ConfigUtils.GetItemTypeFromId(memberId)
			if itemType == ItemType.Character then
				skillList = this.GetCharacterSkillList(memberId)
			elseif itemType == ItemType.Pet then
				skillList = this.GetPetSkillList(memberId)
			else
				assert(false, "un-handled member type: "..tostring(memberId))
			end
		end

		local sourceMemberPosition = idx
		-- global skill or pet skill
		if memberId == globalMemberId or itemType == ItemType.Pet then
			sourceMemberPosition = nil
		end

		for skillIdx = 1, #skillList do
			local skillId = skillList[skillIdx].id
			local skillMatchCount = 0
			-- skill effect attribute
			local skillMatch = true
			if skillMatch and filters.effectAttribute ~= nil then
				local skillEffectParameter = ConfigUtils.GetSkillEffectParameter(skillId)
				local thisEffectAttribute = skillEffectParameter.EffectAttribute
				skillMatch = (filters.effectAttribute == thisEffectAttribute)
			end
			-- skill effect scope
			if skillMatch and filters.effectScope ~= nil then
				local skillEffectRange = ConfigUtils.GetSkillEffectRange(skillId)
				local thisEffectScope = skillEffectRange.EffectScope
				skillMatch = (filters.effectScope == thisEffectScope)
			end
			-- skill effect module
			if skillMatch and filters.effectModule ~= nil then
				local thisEffectModule = ConfigUtils.GetSkillEffectModule(skillId)
				skillMatch = (filters.effectModule == thisEffectModule)
			end
			-- filter skill types
			filters.skillType = filters.skillType or FilterSkillType.NoBattleRoundSkill
			if skillMatch and filters.skillType ~= nil then
				local isBattleRoundSkill = ConfigUtils.IsBattleRoundSkill(skillId)
				if filters.skillType == FilterSkillType.NoBattleRoundSkill then
					skillMatch = not isBattleRoundSkill
				elseif filters.skillType == FilterSkillType.OnlyBattleRoundSkill then
					skillMatch = isBattleRoundSkill
				end
			end

			-- skill condition
			if skillMatch then
				local conditionMustBeNull = filters.nullCondition or false
				skillMatch, skillMatchCount = this.IsSkillConditionMatch(skillId, memberId, sourceMemberPosition, characters, conditionMustBeNull)
			end

			if skillMatch then
				local isMultiCount = ConfigUtils.IsSkillMultiCount(skillId)
				local skillValue = skillList[skillIdx].value
				if isMultiCount then
					skillValue = skillValue * skillMatchCount
				end

				local effectedMembers = this.GetSkillEffectedMembers(skillId, memberId, sourceMemberPosition, characters)
				for memberIdx = 1, #effectedMembers do
					local skillEffectedMemberId = effectedMembers[memberIdx]
					assert(skillEffectedMemberId ~= globalMemberId, "global member should not have skills")

					if memberToSkills[skillEffectedMemberId] == nil then
						memberToSkills[skillEffectedMemberId] = {}
					end

					table.insert(memberToSkills[skillEffectedMemberId], {id = skillId, value = skillValue, source = memberId})
				end
			end
		end
	end

	return memberToSkills
end

--  effectAttribute
--  skillType : FilterSkillType; if is null, only return skills not battle round
function GameData.GetEnemySkillList(enemyId, filters)
	filters = filters or {}
	
	local skillList = ConfigUtils.GetEnemySkillList(enemyId)
	local ret = {}

	for skillIdx = 1, #skillList do
		local skillId = skillList[skillIdx].id
		-- skill effect attribute
		local skillMatch = true
		if skillMatch and filters.effectAttribute ~= nil then
			local skillEffectParameter = ConfigUtils.GetSkillEffectParameter(skillId)
			local thisEffectAttribute = skillEffectParameter.EffectAttribute
			skillMatch = (filters.effectAttribute == thisEffectAttribute)
		end
		-- filter skill types
		filters.skillType = filters.skillType or FilterSkillType.NoBattleRoundSkill
		if skillMatch and filters.skillType ~= nil then
			local isBattleRoundSkill = ConfigUtils.IsBattleRoundSkill(skillId)
			if filters.skillType == FilterSkillType.NoBattleRoundSkill then
				skillMatch = not isBattleRoundSkill
			elseif filters.skillType == FilterSkillType.OnlyBattleRoundSkill then
				skillMatch = isBattleRoundSkill
			end
		end

		if skillMatch then
			local skillValue = skillList[skillIdx].value
			table.insert(ret, {id = skillId, value = skillValue})
		end
	end

	return ret
end

function GameData.GetCharacterRoomSkillList(characterId)
	local ret = {}

	local roomPrefabName = ConfigUtils.GetCharacterRoom(characterId)
	if roomPrefabName ~= nil then
		local roomPieces = ConfigUtils.GetRoomPieces(roomPrefabName)
		local roomUnlocked = true
		for _, roomPieceId in pairs(roomPieces) do
			if not this.IsRoomPieceUnlocked(roomPieceId) then
				roomUnlocked = false
				break
			end
		end

		if roomUnlocked then
			ret = ConfigUtils.GetRoomSkillList(roomPrefabName)
		end
	end

	return ret
end
------------------------------------------------------------------------------------
function GameData.GetCharacterAbilityListWithDetail(characterId, characterLevel, equipments, skills)
	local baseAbilityList = ConfigUtils.GetCharacterBaseAbilityList(characterId)
	local equipmentAbilityMap = ConfigUtils.GetEquipmentAbilityMap(equipments)
	local skillAbilityMap = this.ConstructAbilityMapOfSkills(skills)
	local roomPieceAbilityMap = this.GetCharacterRoomPieceAbilityMap(characterId)

	local ret = {}

	for idx = 1, #baseAbilityList do
		local abilityId = baseAbilityList[idx].Value
		local levelAddValue = (characterLevel - 1) * baseAbilityList[idx].Gain
		local baseValue = (baseAbilityList[idx].Base + levelAddValue)

		local addValue = 0
		local addPercent = 0

		if skillAbilityMap[abilityId] ~= nil then
			addValue = addValue + skillAbilityMap[abilityId].abs
			addPercent = addPercent + skillAbilityMap[abilityId].percent
		end

		local equipmentAddValue = equipmentAbilityMap[abilityId] or 0
		addValue = addValue + equipmentAddValue

		local roomPieceAddValue = roomPieceAbilityMap[abilityId] or 0
		addValue = addValue + roomPieceAddValue

		local finalPercent = Helper.Round(1 + addPercent, 2)
		local finalValue = Helper.RoundAndCeil((baseValue + addValue) * finalPercent)
		ret[idx] = {id = abilityId, value = finalValue, base = baseValue, add = (finalValue - baseValue)}
	end

	return ret
end

function GameData.GetCharacterAbilityMapWithDetail(characterId, characterLevel, equipments, skills)
	local finalRet = {}
	local baseRet = {}
	local addRet = {}

	local abilityList = this.GetCharacterAbilityListWithDetail(characterId, characterLevel, equipments, skills)
	for k, v in pairs(abilityList) do
		local abilityId = v.id
		finalRet[abilityId] = v.value or 0
		baseRet[abilityId] = v.base or 0
		addRet[abilityId] = v.add or 0
	end

	return finalRet, baseRet, addRet
end

function GameData.GetPetAbilityListWithDetail(petId, petLevel, skills)
	local baseAbilityList = ConfigUtils.GetPetBaseAbilityList(petId)
	local skillAbilityMap = this.ConstructAbilityMapOfSkills(skills)

	local ret = {}

	for idx = 1, #baseAbilityList do
		local abilityId = baseAbilityList[idx].Value
		local levelAddValue = (petLevel - 1) * baseAbilityList[idx].Gain
		local baseValue = (baseAbilityList[idx].Base + levelAddValue)

		if baseValue > 0 then
			local addValue = 0
			local addPercent = 0

			if skillAbilityMap[abilityId] ~= nil then
				addValue = skillAbilityMap[abilityId].abs
				addPercent = skillAbilityMap[abilityId].percent
			end

			local finalPercent = Helper.Round(1 + addPercent, 2)
			local finalValue = Helper.RoundAndCeil((baseValue + addValue) * finalPercent)
			ret[idx] = {id = abilityId, value = finalValue, base = baseValue, add = (finalValue - baseValue)}
		else
			ret[idx] = {id = abilityId, value = 0, base = 0, add = 0}
		end
	end

	return ret
end

function GameData.GetPetAbilityMapWithDetail(petId, petLevel, skills)
	local finalRet = {}
	local baseRet = {}
	local addRet = {}

	local abilityList = this.GetPetAbilityListWithDetail(petId, petLevel, skills)
	for k, v in pairs(abilityList) do
		local abilityId = v.id
		finalRet[abilityId] = v.value or 0
		baseRet[abilityId] = v.base or 0
		addRet[abilityId] = v.add or 0
	end

	return finalRet, baseRet, addRet
end

function GameData.GetCharacterAbilityList(characterId)
	local skillMap = this.GetGroupSkillMap(
		{characterId}, 
		nil, 
		{
			effectAttribute = EffectAttribute.Ability, 
			effectScope = EffectScope.Self, 
			nullCondition = true,
		}
	)
	local skills = skillMap[characterId] or {}
	local equipments = this.GetCharacterUnlockedEquipments(characterId)
	local characterLevel = this.GetCharacterLevel(characterId)

	return this.GetCharacterAbilityListWithDetail(characterId, characterLevel, equipments, skills)
end

-- preview character ability list
function GameData.GetPreviewCharacterAbilityList(characterId, characterLevel, characterStage, skinId, equipments)
	local activatedSkillList = ConfigUtils.GetCharacterActivedSkillsAt(characterId, characterStage)
	local skinSkillList = ConfigUtils.GetSkinSkill(skinId)
	local equipmentSkillList = ConfigUtils.GetEquipmentSkillList(equipments)
	-- here seems no need to include room skills 
	
	local skillList = {}

	for idx = 1, #activatedSkillList do
		table.insert(skillList, {id = activatedSkillList[idx].id, value = activatedSkillList[idx].value})
	end

	for idx = 1, #equipmentSkillList do
		table.insert(skillList, {id = equipmentSkillList[idx].id, value = equipmentSkillList[idx].value})
	end

	for idx = 1, #skinSkillList do
		table.insert(skillList, {id = skinSkillList[idx].id, value = skinSkillList[idx].value})
	end

	local filters = {
		effectAttribute = EffectAttribute.Ability, 
		effectScope = EffectScope.Self, 
		nullCondition = true,
	}
	local characters = {characterId}
	local sourceMemberPosition = 1

	local validSkillList = {}
	for skillIdx = 1, #skillList do
		local skillId = skillList[skillIdx].id
		local skillMatchCount = 0
		-- skill effect attribute
		local skillMatch = true
		if skillMatch then
			local skillEffectParameter = ConfigUtils.GetSkillEffectParameter(skillId)
			local thisEffectAttribute = skillEffectParameter.EffectAttribute
			skillMatch = (filters.effectAttribute == thisEffectAttribute)
		end
		-- skill effect scope
		if skillMatch then
			local skillEffectRange = ConfigUtils.GetSkillEffectRange(skillId)
			local thisEffectScope = skillEffectRange.EffectScope
			skillMatch = (filters.effectScope == thisEffectScope)
		end
		-- filter skill types
		if skillMatch then
			local isBattleRoundSkill = ConfigUtils.IsBattleRoundSkill(skillId)
			skillMatch = not isBattleRoundSkill
		end
		-- skill condition
		if skillMatch then
			local conditionMustBeNull = filters.nullCondition
			skillMatch, skillMatchCount = this.IsSkillConditionMatch(skillId, characterId, sourceMemberPosition, characters, conditionMustBeNull)
		end

		if skillMatch then
			local isMultiCount = ConfigUtils.IsSkillMultiCount(skillId)
			local skillValue = skillList[skillIdx].value
			if isMultiCount then
				skillValue = skillValue * skillMatchCount
			end

			table.insert(validSkillList, {id = skillId, value = skillValue, source = characterId})
		end
	end

	return this.GetCharacterAbilityListWithDetail(characterId, characterLevel, equipments, validSkillList)
end

function GameData.GetCharacterAbilityMapAtLevel(characterId, characterLevel)
	-- for now, this method is only called for preview: so only level changed, but stage don't
	-- so the skill map is right, if you want to preview two levels in differen stage, this will not return the right data
	local skillMap = this.GetGroupSkillMap(
		{characterId}, 
		nil, 
		{
			effectAttribute = EffectAttribute.Ability, 
			effectScope = EffectScope.Self, 
			nullCondition = true,
		}
	)
	local skills = skillMap[characterId] or {}
	local equipments = this.GetCharacterUnlockedEquipments(characterId)

	return this.GetCharacterAbilityMapWithDetail(characterId, characterLevel, equipments, skills)
end

function GameData.GetCharacterAbilityMap(characterId)
	local finalRet = {}
	local baseRet = {}
	local addRet = {}

	local abilityList = this.GetCharacterAbilityList(characterId)
	for k, v in pairs(abilityList) do
		local abilityId = v.id
		finalRet[abilityId] = v.value or 0
		baseRet[abilityId] = v.base or 0
		addRet[abilityId] = v.add or 0
	end

	return finalRet, baseRet, addRet
end

function GameData.GetCharacterAbilityOf(characterId, abilityId)
	local abilityMap = this.GetCharacterAbilityMap(characterId)
	return abilityMap[abilityId] or 0
end

function GameData.GetCharacterAbilitySumOf(characterId, abilityList)
	local abilityMap = this.GetCharacterAbilityMap(characterId)
	local sum = 0
	abilityList = abilityList or {}
	for idx = 1, #abilityList do
		local abilityId = abilityList[idx]
		sum = sum + abilityMap[abilityId] or 0
	end
	
	return sum
end

function GameData.GetPetAbilityList(petId)
	local skillMap = this.GetGroupSkillMap(
		nil, 
		petId, 
		{
			effectAttribute = EffectAttribute.Ability, 
			effectScope = EffectScope.Self,
			nullCondition = true,
		}
	)
	local skills = skillMap[petId] or {}
	local petLevel = this.GetPetLevel(petId)

	return this.GetPetAbilityListWithDetail(petId, petLevel, skills)
end

function GameData.GetPetAbilityOf(petId, abilityId)
	local abilityMap = this.GetPetAbilityMap(petId)
	return abilityMap[abilityId] or 0
end

function GameData.GetPetAbilityMap(petId)
	local finalRet = {}
	local baseRet = {}
	local addRet = {}

	local abilityList = this.GetPetAbilityList(petId)
	for k, v in pairs(abilityList) do
		local abilityId = v.id
		finalRet[abilityId] = v.value or 0
		baseRet[abilityId] = v.base or 0
		addRet[abilityId] = v.add or 0
	end

	return finalRet, baseRet, addRet
end

function GameData.GetGroupAbilityMap(characters, petId, globalSkillList)
	if not ConfigUtils.IsValidItem(petId) then
		petId = nil
	end
	
	local groupSkillMap = this.GetGroupSkillMap(characters, petId, {effectAttribute = EffectAttribute.Ability, globalSkills = globalSkillList})

	local ret = {}
	-- group includes selected characters and pet
	local group = {}
	Helper.CopyTable(group, characters)
	if petId ~= nil then
		table.insert(group, petId)
	end
	for idx = 1, #group do
		local memberId = group[idx]
		local memberType = ConfigUtils.GetItemTypeFromId(memberId)
		local skills = groupSkillMap[memberId] or {}

		local abilityMap = {}
		if memberType == ItemType.Character then
			local characterLevel = this.GetCharacterLevel(memberId)
			local equipments = this.GetCharacterUnlockedEquipments(memberId)
			abilityMap = this.GetCharacterAbilityMapWithDetail(memberId, characterLevel, equipments, skills)
		elseif memberType == ItemType.Pet then
			local petLevel = this.GetPetLevel(memberId)
			abilityMap = this.GetPetAbilityMapWithDetail(memberId, petLevel, skills)
		else
			assert(false, "un-handled member type: "..tostring(memberId))
		end

		ret[memberId] = abilityMap
	end

	return ret
end

function GameData.GetCharacterRoomPieceAbilityMap(characterId)
	local ret = {}

	local roomPrefabName = ConfigUtils.GetCharacterRoom(characterId)
	if roomPrefabName ~= nil then
		local roomPieces = ConfigUtils.GetRoomPieces(roomPrefabName)
		for _, roomPieceId in pairs(roomPieces) do
			if this.IsRoomPieceUnlocked(roomPieceId) then
				local abilityList = ConfigUtils.GetRoomPiecesAbility(roomPieceId)
				for k, v in pairs(abilityList) do
					local abilityId = v.Value
					local abilityValue = v.Num
					local preValue = ret[abilityId] or 0
					ret[abilityId] = preValue + abilityValue
				end
			end
		end
	end

	return ret
end
------------------------------------------------------------------------------------
-- character skills for battle
function GameData.GetGroupDamageToElement(characters, petId, globalSkillList)
	if not ConfigUtils.IsValidItem(petId) then
		petId = nil
	end

	local groupSkillMap = this.GetGroupSkillMap(characters, petId, {effectAttribute = EffectAttribute.DamageToElement, globalSkills = globalSkillList})

	local ret = {}
	-- group includes selected characters and pet
	local group = {}
	Helper.CopyTable(group, characters)
	if petId ~= nil then
		table.insert(group, petId)
	end

	for idx = 1, #group do
		local memberId = group[idx]
		local skills = groupSkillMap[memberId] or {}
		ret[memberId] = this.ConstructElementMapOfSkills(skills)
	end

	return ret
end

function GameData.GetGroupDamageFromElement(characters, petId, globalSkillList)
	if not ConfigUtils.IsValidItem(petId) then
		petId = nil
	end

	local groupSkillMap = this.GetGroupSkillMap(characters, petId, {effectAttribute = EffectAttribute.DamageFromElement, globalSkills = globalSkillList})

	local ret = {}
	-- group includes selected characters and pet
	local group = {}
	Helper.CopyTable(group, characters)
	if petId ~= nil then
		table.insert(group, petId)
	end

	for idx = 1, #group do
		local memberId = group[idx]
		local skills = groupSkillMap[memberId] or {}
		ret[memberId] = this.ConstructElementMapOfSkills(skills)
	end

	return ret
end

function GameData.GetGroupPercentValueMapOf(characters, petId, effectAttribute, globalSkillList)
	if not ConfigUtils.IsValidItem(petId) then
		petId = nil
	end

	local groupSkillMap = this.GetGroupSkillMap(characters, petId, {effectAttribute = effectAttribute, globalSkills = globalSkillList})

	local ret = {}
	-- group includes selected characters and pet
	local group = {}
	Helper.CopyTable(group, characters)
	if petId ~= nil then
		table.insert(group, petId)
	end

	for idx = 1, #group do
		local memberId = group[idx]
		local skills = groupSkillMap[memberId] or {}
		ret[memberId] = this.GetAddPercentValueOfSkillList(skills)
	end

	return ret
end

function GameData.GetGroupExtraAttackMap(characters, petId, globalSkillList)
	if not ConfigUtils.IsValidItem(petId) then
		petId = nil
	end

	local groupSkillMap = this.GetGroupSkillMap(characters, petId, {effectAttribute = EffectAttribute.ExtraAttack, globalSkills = globalSkillList})

	local ret = {}
	-- group includes selected characters and pet
	local group = {}
	Helper.CopyTable(group, characters)
	if petId ~= nil then
		table.insert(group, petId)
	end

	for idx = 1, #group do
		local memberId = group[idx]
		local skills = groupSkillMap[memberId] or {}
		local extraAttackList = {}
		for skillIdx = 1, #skills do
			local skillId = skills[skillIdx].id
			local chance = skills[skillIdx].value * 0.01
			local extraAttackNum = ConfigUtils.GetSkillEffectValue(skillId)

			table.insert(extraAttackList, {extraAttackNum = extraAttackNum, chance = chance})
		end

		table.sort(extraAttackList, this.ExtraAttackSortFunc)
		ret[memberId] = extraAttackList
	end

	return ret
end

function GameData.GetGroupDodgeMap(characters, petId, globalSkillList)
	if not ConfigUtils.IsValidItem(petId) then
		petId = nil
	end

	local groupSkillMap = this.GetGroupSkillMap(characters, petId, {effectAttribute = EffectAttribute.Dodge, globalSkills = globalSkillList})

	local ret = {}
	-- group includes selected characters and pet
	local group = {}
	Helper.CopyTable(group, characters)
	if petId ~= nil then
		table.insert(group, petId)
	end

	for idx = 1, #group do
		local memberId = group[idx]
		local skills = groupSkillMap[memberId] or {}
		local dodgeList = {}
		for skillIdx = 1, #skills do
			local chance = skills[skillIdx].value * 0.01
			table.insert(dodgeList, chance)
		end

		ret[memberId] = dodgeList
	end

	return ret
end

function GameData.GetGroupDodgeIgnoreMap(characters, petId, globalSkillList)
	if not ConfigUtils.IsValidItem(petId) then
		petId = nil
	end

	local groupSkillMap = this.GetGroupSkillMap(characters, petId, {effectAttribute = EffectAttribute.DodgeIgnore, globalSkills = globalSkillList})

	local ret = {}
	-- group includes selected characters and pet
	local group = {}
	Helper.CopyTable(group, characters)
	if petId ~= nil then
		table.insert(group, petId)
	end

	for idx = 1, #group do
		local memberId = group[idx]
		local skills = groupSkillMap[memberId] or {}
		local dodgeIgnoreList = {}
		for skillIdx = 1, #skills do
			local chance = skills[skillIdx].value * 0.01
			table.insert(dodgeIgnoreList, chance)
		end

		ret[memberId] = dodgeIgnoreList
	end

	return ret
end

function GameData.GetGroupSpecificEnemySkillMap(characters, petId, globalSkillList)
	if not ConfigUtils.IsValidItem(petId) then
		petId = nil
	end

	local groupAbilitySkillMap = this.GetGroupSkillMap(characters, petId, {effectAttribute = EffectAttribute.SpecificEnemyAbility, globalSkills = globalSkillList})
	local groupLevelSkillMap = this.GetGroupSkillMap(characters, petId, {effectAttribute = EffectAttribute.SpecificEnemyLevel, globalSkills = globalSkillList})

	local ret = {}
	-- group includes selected characters and pet
	local group = {}
	Helper.CopyTable(group, characters)
	if petId ~= nil then
		table.insert(group, petId)
	end

	for idx = 1, #group do
		local memberId = group[idx]
		local memberAbilitySkillMap = groupAbilitySkillMap[memberId] or {}
		local memberLevelSkillMap = groupLevelSkillMap[memberId] or {}

		local memberSkills = {}
		Helper.CopyTable(memberSkills, memberAbilitySkillMap)
		Helper.CopyTable(memberSkills, memberLevelSkillMap)
		ret[memberId] = memberSkills
	end

	return ret
end
------------------------------------------------------------------------------------
-- enemy skills
function GameData.GetEnemyCritChance(enemyId)
	local skills = this.GetEnemySkillList(enemyId, {effectAttribute = EffectAttribute.CritChance})
	return this.GetAddPercentValueOfSkillList(skills)
end

function GameData.GetEnemyCritDamage(enemyId)
	local skills = this.GetEnemySkillList(enemyId, {effectAttribute = EffectAttribute.CritDamage})
	return this.GetAddPercentValueOfSkillList(skills)
end

function GameData.GetEnemyCritDamageDefend(enemyId)
	local skills = this.GetEnemySkillList(enemyId, {effectAttribute = EffectAttribute.DamageFromCritDamage})
	return this.GetAddPercentValueOfSkillList(skills)
end

function GameData.GetEnemyDamageToElement(enemyId)
	local skills = this.GetEnemySkillList(enemyId, {effectAttribute = EffectAttribute.DamageToElement})
	local ret = this.ConstructElementMapOfSkills(skills)
	return ret
end

function GameData.GetEnemyDamageFromElement(enemyId)
	local skills = this.GetEnemySkillList(enemyId, {effectAttribute = EffectAttribute.DamageFromElement})
	local ret = this.ConstructElementMapOfSkills(skills)
	return ret
end

function GameData.GetEnemyExtraAttack(enemyId)
	local skills = this.GetEnemySkillList(enemyId, {effectAttribute = EffectAttribute.ExtraAttack})

	local ret = {}
	for skillIdx = 1, #skills do
		local skillId = skills[skillIdx].id
		local chance = skills[skillIdx].value * 0.01
		local extraAttackNum = ConfigUtils.GetSkillEffectValue(skillId)

		table.insert(ret, {extraAttackNum = extraAttackNum, chance = chance})
	end

	table.sort(ret, this.ExtraAttackSortFunc)

	return ret
end

function GameData.GetEnemyDodge(enemyId)
	local skills = this.GetEnemySkillList(enemyId, {effectAttribute = EffectAttribute.Dodge})

	local ret = {}
	for skillIdx = 1, #skills do
		local chance = skills[skillIdx].value * 0.01
		table.insert(ret, chance)
	end

	return ret
end

function GameData.GetEnemyDodgeIngore(enemyId)
	local skills = this.GetEnemySkillList(enemyId, {effectAttribute = EffectAttribute.DodgeIgnore})

	local ret = {}
	for skillIdx = 1, #skills do
		local chance = skills[skillIdx].value * 0.01
		table.insert(ret, chance)
	end

	return ret
end

function GameData.GetEnemyLevelIgnore(enemyId)
	local skills = this.GetEnemySkillList(enemyId, {effectAttribute = EffectAttribute.EnemyLevelIgnore})
	local absValue, percentValue = GameData.GetSkillListTotalValue(skills)
	absValue = math.abs(absValue)
	percentValue = math.abs(percentValue)
	return absValue, percentValue
end

function GameData.GetEnemySkillAbilityMap(enemyId)
	local skills = this.GetEnemySkillList(enemyId, {effectAttribute = EffectAttribute.Ability})
	return GameData.ConstructAbilityMapOfSkills(skills)
end
------------------------------------------------------------------------------------
function GameData.ExtraAttackSortFunc(elementA, elementB)
	if elementA == nil or elementB == nil then
		return false
	end

	local valueA = elementA.extraAttackNum
	local valueB = elementB.extraAttackNum

	if valueA == valueB then
		valueA = elementA.chance
		valueB = elementB.chance
	end

	return valueA > valueB
end
------------------------------------------------------------------------------------
function GameData.IsItemMatchSkill(skillId, itemId)
	local effectParameter = ConfigUtils.GetSkillEffectParameter(skillId)
	-- exactly equal - yes
	local effectValue = effectParameter.EffectValue
	if effectValue == itemId then
		return true
	end
	-- exactly not equal - no
	if ConfigUtils.IsValidItem(effectValue) then
		return false
	end
	-- not specific item, check tag
	if effectParameter.Tag == nil then
		return true
	end
	-- has tag and check match or not
	return ConfigUtils.IsItemMatchTagList(itemId, effectParameter.Tag or {})
end

function GameData.GetItemMatchedSkills(skillsMap, itemId)
	local ret = {}

	for _, skills in pairs(skillsMap) do
		for idx = 1, #skills do
			local skillId = skills[idx].id
			local skillValue = skills[idx].value
			if GameData.IsItemMatchSkill(skillId, itemId) then
				table.insert(ret, {id = skillId, value = skillValue})
			end
		end
	end

	return ret
end

function GameData.IsEnemyMatchSkill(skillId, enemyId)
	local effectParameter = ConfigUtils.GetSkillEffectParameter(skillId)

	local match = true
	if match and effectParameter.Rarity ~= nil then
		local thisRarity = ConfigUtils.GetItemRarity(enemyId)
		local rarityOp = effectParameter.RarityOp
		match = CheckRarity(thisRarity, effectParameter.Rarity, rarityOp)
	end

	if match and effectParameter.Element ~= nil then
		local thisElement = ConfigUtils.GetElementOfItem(enemyId)
		match = (thisElement == effectParameter.Element)
	end

	if match and effectParameter.Tag ~= nil then
		local thisTags = ConfigUtils.GetItemTags(enemyId)
		local needTags = effectParameter.Tag
		-- should contain all the need tags
		for tagIdx = 1, #needTags do
			if not Helper.TableContains(thisTags, needTags[tagIdx]) then
				match = false
				break
			end
		end
	end

	return match
end

function GameData.GetEnemyFightPowerSkillValue(skillMap, enemyId)
	local addPercent = 0

	for k, skills in pairs(skillMap) do
		for idx = 1, #skills do
			local skillId = skills[idx].id
			if this.IsEnemyMatchSkill(skillId, enemyId) then
				local skillValue = skills[idx].value
				local calcType = ConfigUtils.GetSkillEffectCalculateType(skillId)

				if calcType == CalculateType.Percent then
					addPercent = addPercent + skillValue * 0.01
				else
					assert(false, "un-handled calculate type: "..tostring(calcType).." for skill: "..tostring(skillId))
				end
			end
		end
	end

	addPercent = Helper.Round(addPercent, 2)
	return addPercent
end
-----------------------------------------------------------------------------------------------
-- couple
function GameData.IsCoupleMatched(coupleId, characters)
	local conditions = ConfigUtils.GetCoupleConditions(coupleId)
	for idx = 1, #conditions do
		local matched = GameData.IsCoupleConditionMatched(conditions[idx], characters)
		if not matched then
			return false
		end
	end

	return true
end

function GameData.IsCoupleConditionMatched(condition, characters)
	local characterId = condition.Id
	local skinId = condition.SkinId
	local characterStage = condition.Stage
	local characterLevel = condition.Level

	if not Helper.TableContains(characters, characterId) then
		return false
	end

	if skinId ~= nil then
		local currentSkin = GameData.GetCharacterSkin(characterId)
		if skinId ~= currentSkin then
			return false
		end
	end

	if characterStage ~= nil then
		local currentStage = GameData.GetCharacterCurrentStage(characterId)
		if currentStage < characterStage then
			return false
		end
	end

	if characterLevel ~= nil then
		local currentLevel = GameData.GetCharacterLevel(characterId)
		if currentLevel < characterLevel then
			return false
		end
	end

	return true
end
-----------------------------------------------------------------------------------------------