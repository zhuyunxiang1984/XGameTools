local DATA_SAVE_VERSION = 0

local _gameLocalData = {
	accounts = {
		--[[
		-- exploring characters
		exploringCharacters = {
			areaId001 = {id001, id002}, areaId002 = {id003, id004}
		},
		exploringItems = {
			areaId001 = {id001, id002}, areaId002 = {id003, id004}
		},
		catchFishCharacters = {
			areaId001 = {id001, id002}, areaId002 = {id003, id004}
		},
		-- exploring pets
		exploringPets = {
			areaId001 = id001, areaId002 = id010
		},
		-- new check
		newCheck = {
			id001 = false, id002 = true,
		},
		-- marked item
		markedItem = {
			id001 = false, id002 = true,
		},
		-- iap data 
		iapData = {
			iapId001 = {orders = {orderId001, orderId002}, receipt = xxxxx }
		},
		-- level data: 1 - new unlocked; 2 - finished explore
		planetLevelData = {
			levelId001 = 1, levelId002 = 2
		},
		{userId = 1, nickName = "a", password = "123", exploringCharacters = {}, newCheck = {}, markedItem = {}, iapData = {}, planetLevelData = {}},
		{userId = 2, nickName = "b", password = "123", exploringCharacters = {}, newCheck = {}, markedItem = {}, iapData = {}, planetLevelData = {}},
		]]
	},
	-- account name
	defaultNickName = nil,
	-- options
	bgmType = 1, -- 1 = 单曲循环, 2 = 列表循环, 3 = 列表随机
	bgmName = nil,
	musicOn = true,
	soundOn = true,
	notificationOn = true,
	saveVersion = DATA_SAVE_VERSION,
	-- bulletin
	lastBulletinId = nil,
	-- weekly report
	weeklyReadTimestamp = nil,
	-- review
	reviewFinished = false,
	-- last package id
	lastPackageId = nil,
	-- last tencent login platform
	lastTencentPlantform = nil,
	-- never sleep
	neverSleep = false,
	-----------------------------------
	lastActivityExploreTheme = nil,
	-----------------------------------
	-- for check version
	lastDrawTime = nil,
	lastDrawCount = 0,
	-----------------------------------
    -- 家园布置数据
    homeArrangeData = nil
}

local this = GameData

--------------------------------------------------------------
function GameData.Init()
	_gameLocalData.accounts = {}
	_gameLocalData.defaultNickName = nil
	_gameLocalData.musicOn = true
	_gameLocalData.soundOn = true
	_gameLocalData.notificationOn = true
	_gameLocalData.saveVersion = DATA_SAVE_VERSION

	_gameLocalData.noticeReadTimestamp = nil
	_gameLocalData.weeklyReadTimestamp = nil

	_gameLocalData.reviewFinished = false
	_gameLocalData.lastPackageId = nil

	_gameLocalData.neverSleep = false
	-----------------------------------
	-- for check version
	lastDrawTime = nil
	lastDrawCount = 0
	-----------------------------------
end

function GameData.Load()
	local data = GameSave.Load()

	if data == nil then
		return false
	end

	_gameLocalData = data
	return true
end

function GameData.Save()
	GameSave.Save(_gameLocalData)
end

function GameData.VersionUpdate()
	-- TODO
end

function GameData.SetDefaultNickName(nickName)
	_gameLocalData.defaultNickName = nickName
end

function GameData.GetDefaultNickName(checkSensitive)
	if checkSensitive then
		return WordFilterHelper.FilterSensitiveWord(_gameLocalData.defaultNickName)
	end
	return _gameLocalData.defaultNickName
end

function GameData.AddAccount(userId, name, password)
	local accountIndex = GameData.GetAccountIndexByName(name)
	if accountIndex == nil then
		table.insert(_gameLocalData.accounts, {userId = userId, nickName = name, password = password})
	else
		_gameLocalData.accounts[accountIndex] = {userId = userId, nickName = name, password = password}
	end
end

function GameData.CheckAddNewAccount(userId, name, password)
	local account = GameData.GetAccountByUserId(userId)
	if account == nil then
		table.insert(_gameLocalData.accounts, {userId = userId, nickName = name, password = password})
		return true
	else
		account.userId = userId
		account.nickName = name
		account.password = password
	end

	return false
end

function GameData.GetAccountByName(name)
	for idx = 1, #_gameLocalData.accounts do
		if _gameLocalData.accounts[idx].nickName == name then
			return _gameLocalData.accounts[idx]
		end
	end

	return nil
end

function GameData.GetAccountIndexByName(name)
	for idx = 1, #_gameLocalData.accounts do
		if _gameLocalData.accounts[idx].nickName == name then
			return idx
		end
	end

	return nil
end

function GameData.GetAccountByUserId(userId)
	for idx = 1, #_gameLocalData.accounts do
		if _gameLocalData.accounts[idx].userId == userId then
			return _gameLocalData.accounts[idx]
		end
	end
	return nil
end

function GameData.GetAccountInfoByName(name)
	local account = this.GetAccountByName(name)
	assert(account ~= nil, "can't find account by name: "..tostring(name))
	return account.nickName, account.password, account.userId
end

function GameData.ModifyAccountPassword(name, password)
	local account = this.GetAccountByName(name)
	if account ~= nil then
		account.password = password
	end
end

function GameData.CheckDefaultAccountSafeState()
	local account = this.GetDefaultAccount()
	if account ~= nil then
		account.safe = GameData.IsAccountVerified()
		this.Save()
	end
end

function GameData.GetDefaultAccount()
	assert(_gameLocalData.defaultNickName ~= nil, "invalid default nick name")
	for idx = 1, #_gameLocalData.accounts do
		if _gameLocalData.accounts[idx].nickName == _gameLocalData.defaultNickName then
			return _gameLocalData.accounts[idx]
		end
	end

	assert(false, "no default account")
end

function GameData.GetDefaultAccountInfo()
	local account = this.GetDefaultAccount()
	return account.nickName, account.password, account.userId
end

function GameData.GetDefaultAccountUserId()
	local account = this.GetDefaultAccount()
	return account.userId
end

function GameData.GetSafeDefaultAccountUserId()
	if _gameLocalData == nil or _gameLocalData.defaultNickName == nil then
		return nil
	end

	return GameData.GetDefaultAccountUserId()
end

function GameData.GetLocalAccountList()
	local ret = {}

	for idx = 1, #_gameLocalData.accounts do
		ret[idx] = {id = _gameLocalData.accounts[idx].nickName, safe = _gameLocalData.accounts[idx].safe}
	end

	return ret
end
function GameData.ModifyNickName(newNickName)
	this.BindAccountNickname()
	local preNickName= _gameLocalData.defaultNickName
	_gameLocalData.defaultNickName= newNickName

	local existAccountIndex= this.GetAccountIndexByName(newNickName)
	if existAccountIndex~= nil then
		table.remove(_gameLocalData.accounts,existAccountIndex)
	end
	for idx = 1, #_gameLocalData.accounts do
		if _gameLocalData.accounts[idx].nickName == preNickName then
			_gameLocalData.accounts[idx].nickName = newNickName
			break
		end
	end

end
function GameData.BindAccount(newNickName, newPassword)
	this.BindAccountNickname()
	local preNickName = _gameLocalData.defaultNickName
	_gameLocalData.defaultNickName = newNickName

	-- if already has exist account with the new nick name, remove it
	local existAccountIndex = this.GetAccountIndexByName(newNickName)
	if existAccountIndex ~= nil then
		table.remove(_gameLocalData.accounts, existAccountIndex)
	end

	for idx = 1, #_gameLocalData.accounts do
		if _gameLocalData.accounts[idx].nickName == preNickName then
			_gameLocalData.accounts[idx].nickName = newNickName
			_gameLocalData.accounts[idx].password = newPassword
			break
		end
	end
end
--------------------------------------------------------------
-- options
function GameData.IsMusicOn()
	return _gameLocalData.musicOn
end

function GameData.ToggleMusic()
	_gameLocalData.musicOn = not _gameLocalData.musicOn
end

function GameData.IsSoundOn()
	return _gameLocalData.soundOn
end

function GameData.GetBGMType()
	return _gameLocalData.bgmType or 1
end

function GameData.SetNextBGMType()
	local type = this.GetBGMType()
	if type == 3 then
		type = 1
	else
		type = type + 1
	end
	_gameLocalData.bgmType = type
end

function GameData.GetRecordBGM()
	if _gameLocalData.bgmName ~= nil then
		return _gameLocalData.bgmName
	else
		return ConfigUtils.GetDefaultBGMKey()
	end
end

function GameData.SetRecordBGM(bgm)
	_gameLocalData.bgmName = bgm
end

function GameData.ToggleSound()
	_gameLocalData.soundOn = not _gameLocalData.soundOn
end

function GameData.IsNotificationOn()
	return _gameLocalData.notificationOn
end

function GameData.ToggleNotification()
	_gameLocalData.notificationOn = not _gameLocalData.notificationOn
end

--------------------------------------------------------------
function GameData.GetLastBulletinId(type)
	_gameLocalData.lastBulletinId = _gameLocalData.lastBulletinId or {}
	for k, v in pairs(_gameLocalData.lastBulletinId) do
		if k == type then
			return v
		end
	end
	return INVALID_ID
end

function GameData.SetLastBulletinId(type, id)
	id = id or INVALID_ID
	_gameLocalData.lastBulletinId = _gameLocalData.lastBulletinId or {}
	_gameLocalData.lastBulletinId[type] = id
	this.Save()
end
--------------------------------------------------------------
function GameData.GetWeeklyReadTimestamp()
	return _gameLocalData.weeklyReadTimestamp
end

function GameData.SetWeeklyReadTimestamp(time)
	_gameLocalData.weeklyReadTimestamp = time
	this.Save()
end
--------------------------------------------------------------
function GameData.GetTencentLastLoginPlatform()
	return _gameLocalData.lastTencentPlantform
end

function GameData.SetTencentLastLoginPlatform(platform)
	_gameLocalData.lastTencentPlantform = platform
	this.Save()
end
--------------------------------------------------------------
function GameData.GetLastActivityExploreTheme()
	return _gameLocalData.lastActivityExploreTheme
end

function GameData.SetLastActivityExploreTheme(themeId)
	_gameLocalData.lastActivityExploreTheme = themeId
	this.Save()
end
--------------------------------------------------------------
function GameData.IsAutoLockOn()
	local neverSleep = _gameLocalData.neverSleep or false
	return not neverSleep
end

function GameData.ToggleAutoLock()
	local neverSleep = _gameLocalData.neverSleep or false
	_gameLocalData.neverSleep = not neverSleep
	this.Save()
end
--------------------------------------------------------------
function GameData.GetBattleSpeed()
	local speed = _gameLocalData.battleSpeed
	if speed == nil then
		return 1
	end

	return speed
end

function GameData.SetBattleSpeed(speed)
	_gameLocalData.battleSpeed = speed
	this.Save()
end
--------------------------------------------------------------
function GameData.GetPlanetAreaExploreCharacters(planetAreaId)
	local account = GameData.GetDefaultAccount()
	if account.exploringCharacters == nil then
		account.exploringCharacters = {}
	end

	local ret = {}
	local characterMap = {}
	local characters = account.exploringCharacters[planetAreaId] or {}
	for idx = 1, #characters do
		local characterId = characters[idx]
		if characterMap[characterId] == nil then
			table.insert(ret, characterId)
			characterMap[characterId] = 1
		end
	end

	return ret
end

function GameData.SetPlanetAreaExploreCharacters(planetAreaId, characters)
	local account = GameData.GetDefaultAccount()
	if account.exploringCharacters == nil then
		account.exploringCharacters = {}
	end

	account.exploringCharacters[planetAreaId] = characters
end
--------------------------------------------------------------
-- ExploreItems
function GameData.GetPlanetAreaExploreItems(planetAreaId)
	local account = GameData.GetDefaultAccount()
	if account.exploringItems == nil then
		account.exploringItems = {}
	end
	local items = account.exploringItems[planetAreaId] or {}
	local ret = Helper.CloneMap(items)
	return ret
end

function GameData.SetPlanetAreaExploreItems(planetAreaId, selectedItems)
	local account = GameData.GetDefaultAccount()
	if account.exploringItems == nil then
		account.exploringItems = {}
	end
	account.exploringItems[planetAreaId] = selectedItems
end
-----------------------------------------------------------------
-- catchFishCharacters
function GameData.GetCatchFishCharacters(StageId)
	local account = GameData.GetDefaultAccount()
	if account.catchFishCharacters == nil then
		account.catchFishCharacters = {}
	end

	local ret = {}
	local characters = account.catchFishCharacters[StageId] or {}
 	Helper.CopyTable(ret, characters)
    	return ret
end

function GameData.SetCatchFishCharacters(StageId, characters)
	local account = GameData.GetDefaultAccount()
	if account.catchFishCharacters == nil then
		account.catchFishCharacters = {}
	end
	account.catchFishCharacters[StageId] = characters
	this.Save()
end
-----------------------------------------------------------------
function GameData.GetPlanetAreaExplorePet(planetAreaId)
	local account = GameData.GetDefaultAccount()
	if account.exploringPets == nil then
		account.exploringPets = {}
	end

	return account.exploringPets[planetAreaId]
end

function GameData.SetPlanetAreaExplorePet(planetAreaId, petId)
	local account = GameData.GetDefaultAccount()
	if account.exploringPets == nil then
		account.exploringPets = {}
	end

	account.exploringPets[planetAreaId] = petId
end
--------------------------------------------------------------
function GameData.SetArenaBattleTeam(battleId, characters, petId)
	local account = GameData.GetDefaultAccount()
	account.arenaTeam = {battle = battleId, characters = characters, pet = petId}
end

function GameData.GetArenaBattleCharacters(battleId)
	local account = GameData.GetDefaultAccount()

	local ret = {}

	if account.arenaTeam ~= nil and account.arenaTeam.battle == battleId then
		local characters = account.arenaTeam.characters or {}
		Helper.CopyTable(ret, characters)
	end

	return ret
end

function GameData.GetArenaBattlePet(battleId)
	local account = GameData.GetDefaultAccount()
	
	if account.arenaTeam ~= nil and account.arenaTeam.battle == battleId then
		return account.arenaTeam.pet
	end

	return nil
end
--------------------------------------------------------------
function GameData.SetChallengeBattleTeam(challengeId, characters, petId)
	local account = GameData.GetDefaultAccount()
	account.challengeTeam = {challenge = challengeId, characters = characters, pet = petId}
end

function GameData.GetChallengeBattleCharacters(challengeId)
	local account = GameData.GetDefaultAccount()

	local ret = {}

	if account.challengeTeam ~= nil and account.challengeTeam.challenge == challengeId then
		local characters = account.challengeTeam.characters or {}
		Helper.CopyTable(ret, characters)
	end

	return ret
end

function GameData.GetChallengeBattlePet(challengeId)
	local account = GameData.GetDefaultAccount()
	
	if account.challengeTeam ~= nil and account.challengeTeam.challenge == challengeId then
		return account.challengeTeam.pet
	end

	return nil
end
--------------------------------------------------------------
function GameData.SetActivityExploreTeam(themeId, characters, petId)
	local account = GameData.GetDefaultAccount()
	account.activityExploreTeam = {theme = themeId, characters = characters, pet = petId}
end

function GameData.GetActivityExploreCharacters(themeId)
	local account = GameData.GetDefaultAccount()

	local ret = {}

	if account.activityExploreTeam ~= nil and account.activityExploreTeam.theme == themeId then
		local characters = account.activityExploreTeam.characters or {}
		Helper.CopyTable(ret, characters)
	end

	return ret
end

function GameData.GetActivityExplorePet(themeId)
	local account = GameData.GetDefaultAccount()
	
	if account.activityExploreTeam ~= nil and account.activityExploreTeam.theme == themeId then
		return account.activityExploreTeam.pet
	end

	return nil
end
--------------------------------------------------------------
function GameData.SetActivityBattleTeam(battleId, characters, petId)
	local account = GameData.GetDefaultAccount()
	account.activityBattleTeam = {battle = battleId, characters = characters, pet = petId}
end

function GameData.GetActivityBattleCharacters(battleId)
	local account = GameData.GetDefaultAccount()

	local ret = {}

	if account.activityBattleTeam ~= nil and account.activityBattleTeam.battle == battleId then
		local characters = account.activityBattleTeam.characters or {}
		Helper.CopyTable(ret, characters)
	end

	return ret
end

function GameData.GetActivityBattlePet(battleId)
	local account = GameData.GetDefaultAccount()
	
	if account.activityBattleTeam ~= nil and account.activityBattleTeam.battle == battleId then
		return account.activityBattleTeam.pet
	end

	return nil
end
--------------------------------------------------------------
function GameData.ConstructPrcoessIapList(maxCheckNum)
	local ret = {}

	local account = GameData.GetDefaultAccount()
	local iapData = account.iapData or {}
	for productId, v in pairs(iapData) do
		local orders = v.orders or {}
		local receipt = v.receipt

		if #orders > 0 and receipt ~= nil then
			table.insert(ret, {product = productId, order = orders[1], nextCheck = 0, checking = false, checkNum = maxCheckNum})
		end
	end

	return ret
end

function GameData.PushIapOrder(productId, order)
	local account = GameData.GetDefaultAccount()
	if account.iapData == nil then
		account.iapData = {}
	end

	if account.iapData[productId] == nil then
		account.iapData[productId] = {}
	end

	if account.iapData[productId].orders == nil then
		account.iapData[productId].orders = {}
		account.iapData[productId].receipt = nil
	end

	table.insert(account.iapData[productId].orders, order)
	GameData.Save()
end

function GameData.PopIapOrder(productId)
	local account = GameData.GetDefaultAccount()
	if account.iapData == nil or account.iapData[productId] == nil then
		return
	end

	local orders = account.iapData[productId].orders or {}
	local count = #orders
	if count > 0 then
		table.remove(account.iapData[productId].orders, count)
		GameData.Save()
	end
end

function GameData.CleanIapOfProduct(productId)
	local account = GameData.GetDefaultAccount()
	if account.iapData == nil then
		return
	end

	account.iapData[productId] = nil
	GameData.Save()
end

function GameData.GetIapFirstOrder(productId)
	local account = GameData.GetDefaultAccount()
	if account.iapData == nil or account.iapData[productId] == nil then
		return nil
	end

	local orders = account.iapData[productId].orders or {}
	if #orders > 0 then
		return orders[1]
	end

	return nil
end

function GameData.RecordProductReceipt(productId, receipt)
	local account = GameData.GetDefaultAccount()
	if account.iapData == nil or account.iapData[productId] == nil then
		return
	end

	account.iapData[productId].receipt = receipt
	GameData.Save()
end
--------------------------------------------------------------
function GameData.AddNewCheck(itemId)
	local account = GameData.GetDefaultAccount()
	if account.newCheck == nil then
		account.newCheck = {}
	end

	-- need check
	account.newCheck[itemId] = true
end

function GameData.IsItemNew(itemId)
	local account = GameData.GetDefaultAccount()
	if account.newCheck == nil then
		account.newCheck = {}
	end

	return account.newCheck[itemId] or false
end

function GameData.HasNewOfType(itemType)
	local account = GameData.GetDefaultAccount()
	if account.newCheck == nil then
		return false
	end

	for k, v in pairs(account.newCheck) do
		if type(k) == "number" then
			local thisType = ConfigUtils.GetItemTypeFromId(k)
			if thisType == itemType then
				return true
			end
		end
	end

	return false
end

function GameData.HasNewSkinOfUnlockCharacters()
	local account = GameData.GetDefaultAccount()
	if account.newCheck == nil then
		return false
	end

	local unlockCharacters = GameData.GetUnlockCharacters()
	for idx = 1, #unlockCharacters do
		local characterId = unlockCharacters[idx]
		if GameData.HasNewSkinOfCharacter(characterId) then
			return true
		end
	end

	return false
end

function GameData.HasNewSkinOfCharacter(characterId)
	local account = GameData.GetDefaultAccount()
	if account.newCheck == nil then
		return false
	end

	for k, v in pairs(account.newCheck) do
		if type(k) == "number" then
			local thisType = ConfigUtils.GetItemTypeFromId(k)
			if thisType == ItemType.Skin then
				local configedChacter = ConfigUtils.GetCharacterOfSkin(k)
				if configedChacter == characterId then
					return true
				end
			end
		end
	end

	return false
end

function GameData.HasNewGoodsOfSubType(subType)
	local account = GameData.GetDefaultAccount()
	if account.newCheck == nil then
		return false
	end

	for k, v in pairs(account.newCheck) do
		if type(k) == "number" then
			local thisType = ConfigUtils.GetItemTypeFromId(k)
			if thisType == ItemType.Goods and ConfigUtils.GetGoodsSubType(k) == subType then
				return true
			end
		end
	end

	return false
end

function GameData.CheckItem(itemId)
	local account = GameData.GetDefaultAccount()
	if account.newCheck == nil then
		return
	end

	if account.newCheck[itemId] ~= nil then
		-- empty the data
		account.newCheck[itemId] = nil
		this.Save()
	end
end

function GameData.CheckItemsOfType(itemType)
	local dirty = false
	local account = GameData.GetDefaultAccount()
	if account.newCheck == nil then
		return
	end

	local toCheck = {}
	for k, v in pairs(account.newCheck) do
		if type(k) == "number" then
			local thisType = ConfigUtils.GetItemTypeFromId(k)
			if thisType == itemType then
				table.insert(toCheck, k)
			end
		end
	end

	for idx = 1, #toCheck do
		local itemId = toCheck[idx]
		account.newCheck[itemId] = nil
		dirty = true
	end

	if dirty then
		this.Save()
	end
end

function GameData.CheckSkinOfCharacter(characterId)
	local dirty = false
	local account = GameData.GetDefaultAccount()
	if account.newCheck == nil then
		return
	end

	local toCheck = {}
	for k, v in pairs(account.newCheck) do
		if type(k) == "number" then
			local thisType = ConfigUtils.GetItemTypeFromId(k)
			if thisType == ItemType.Skin and ConfigUtils.GetCharacterOfSkin(k) == characterId then
				table.insert(toCheck, k)
			end
		end
	end

	for idx = 1, #toCheck do
		local itemId = toCheck[idx]
		account.newCheck[itemId] = nil
		dirty = true
	end

	if dirty then
		this.Save()
	end
end
--------------------------------------------------------------
function GameData.IsItemMarked(itemId)
	local account = GameData.GetDefaultAccount()
	if account.markedItem == nil then
		return false
	end

	local marked = account.markedItem[itemId] or false
	return marked
end

function GameData.ToggleItemMark(itemId)
	local account = GameData.GetDefaultAccount()
	if account.markedItem == nil then
		account.markedItem = {}
	end

	local marked = account.markedItem[itemId] or false
	local newMarked = not marked
	account.markedItem[itemId] = newMarked
	this.Save()

	GameNotifier.Notify(GameEvent.MarkStateChanged, itemId, newMarked)

	return newMarked
end
--------------------------------------------------------------
function GameData.IsReviewFinished()
	-- not can review, finished as default
	if not Game.CanReview() then
		return true
	end

	return _gameLocalData.reviewFinished or false
end

function GameData.IsReviewUnlocked()
	return this.IsEventUnlocked(ReviewEventId)
end

function GameData.FinishReview()
	_gameLocalData.reviewFinished = true
	this.Save()
end
--------------------------------------------------------------
function GameData.GetLastPackageId()
	return _gameLocalData.lastPackageId
end

function GameData.RecordPackage(packageId)
	_gameLocalData.lastPackageId = packageId
	this.Save()
end

function GameData.GetHomeSettleData()
    return _gameLocalData.homeSettleData
end
function GameData.SetHomeSettleData(data)
    _gameLocalData.homeSettleData = data
end