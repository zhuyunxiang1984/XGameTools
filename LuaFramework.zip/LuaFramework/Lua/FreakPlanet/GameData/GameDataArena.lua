local this = GameData
------------------------------------------------------------------
local _arenaConfigList = nil
local _activatedArenaConfigId = nil
local _activatedArenaId = nil
local _arenaDataList = nil
------------------------------------------------------------------
local _arenaRecords = nil
------------------------------------------------------------------
local _arenaShopMap = nil
local _arenaShopRefreshTime = nil

local WEEK_SECONDS = 7 * 24 * 3600
------------------------------------------------------------------
function GameData.InitSysArenaConfig(data)
	_arenaConfigList = data.ConfigList or {}
	log("arena config list: "..Helper.Format(_arenaConfigList))
	_activatedArenaConfigId, _activatedArenaId = this.GetActivatedArenaConfigId()
	log("activated arena config id: "..tostring(_activatedArenaConfigId))
end

function GameData.GetActivatedArenaConfigId()
	local currentTime = this.GetServerTime()
	for idx = 1, #_arenaConfigList do
		if _arenaConfigList[idx].StartTime <= currentTime and _arenaConfigList[idx].EndTime > currentTime then
			return _arenaConfigList[idx].Id, _arenaConfigList[idx].ArenaId, _arenaConfigList[idx].EndTime
		end
	end

	return nil
end

function GameData.ValidateArenaData()
	-- no valid arena
	if _activatedArenaConfigId == nil then
		return
	end

	-- already in the data list
	local dataIndex = this.GetArenaDataIndexOf(_activatedArenaConfigId)
	if dataIndex ~= nil then
		return
	end

	-- not in the list, add new one
	local data = this.ConstructDataOfArena(_activatedArenaConfigId, _activatedArenaId)
	table.insert(_arenaDataList, data)
end

function GameData.ConstructDataOfArena(arenaConfigId, arenaId)
	local arenaData = {}
	local battleList = ConfigUtils.GetBattleListOfArena(arenaId)
	for idx = 1, #battleList do
		-- default difficulty
		arenaData[idx] = 0
	end

	return {Id = arenaConfigId, ArenaData = arenaData}
end

function GameData.HasActivatedArena()
	local arenaConfigId = this.GetActivatedArenaConfigId()
	return arenaConfigId ~= nil
end

function GameData.RefreshActivatedArenaConfig()
	_activatedArenaConfigId, _activatedArenaId = this.GetActivatedArenaConfigId()
	this.ValidateArenaData()
end

function GameData.InitArenaData(data)
	_arenaDataList = data.ArenaList or {}
	log("arena data list: "..Helper.Format(_arenaDataList))
	this.ValidateArenaData()

	local arenaShopList = data.ArenaShopList or {}
	log("arena shop list: "..Helper.Format(arenaShopList))
	_arenaShopMap = {}
	for _, v in pairs(arenaShopList) do
		local shopId = v.ArenaShopId
		local buyCount = v.BuyCount or 0
		local lastBuyTime = v.LastBuyTime or 0
		_arenaShopMap[shopId] = {count = buyCount, timestamp = lastBuyTime}
	end

	-- arena records
	_arenaRecords = data.RecordArena or {}
	log("arena records: "..Helper.Format(_arenaRecords))
	-- refresh time
	this.CheckArenaShopRefreshTime()
end

function GameData.GetArenaDataIndexOf(arenaConfigId)
	for idx = 1, #_arenaDataList do
		if _arenaDataList[idx].Id == arenaConfigId then
			return idx
		end
	end

	return nil
end

function GameData.GetArenaDataOf(arenaConfigId)
	local dataIndex = this.GetArenaDataIndexOf(arenaConfigId)
	assert(dataIndex ~= nil, "no arena data for: "..tostring(arenaConfigId))
	return _arenaDataList[dataIndex].ArenaData or {}
end

function GameData.GetCurrentDifficultyOfArenaBattle(arenaConfigId, battleIndex)
	local dataIndex = this.GetArenaDataIndexOf(arenaConfigId)
	if dataIndex ~= nil then
		return _arenaDataList[dataIndex].ArenaData[battleIndex] or 0
	end
	
	-- not exist
	return 0
end

function GameData.SetCurrentDifficultyOfArenaBattle(arenaConfigId, battleIndex, difficulty)
	if _activatedArenaConfigId ~= arenaConfigId then
		return false
	end

	local dataIndex = this.GetArenaDataIndexOf(arenaConfigId)
	if dataIndex == nil then
		return false
	end

	local preValue = _arenaDataList[dataIndex].ArenaData[battleIndex] or 0
	if difficulty > preValue then
		_arenaDataList[dataIndex].ArenaData[battleIndex] = difficulty
		GameNotifier.Notify(GameEvent.ArenaBattleRankChanged)
		return true, preValue
	end

	return false
end

function GameData.GetActivatedArenaData()
	return _activatedArenaConfigId, _activatedArenaId
end
----------------------------------------------------------------------------------
function GameData.RefreshSysArenaConfig()
	if this.GetActivatedArenaConfigId() == nil then
		NetManager.Send("SysArenaConfig", {}, GameData.OnSysArenaConfigRefreshed, nil)
	end
end

function GameData.OnSysArenaConfigRefreshed(proto, data, requestData)
	if proto == "SysArenaConfig" then
		_arenaConfigList = data.ConfigList or {}
	end
end
----------------------------------------------------------------------------------
-- arena shop
function GameData.GetArenaShopRefreshTimeInternal()
	local currentTime = this.GetServerTime()
	local weekBegin = GameData.GetBeginTimeOfWeek(currentTime)
	local startTime = weekBegin
	if currentTime < startTime then
		refreshTime = startTime
	else
		refreshTime = startTime + WEEK_SECONDS
	end

	return refreshTime
end

function GameData.CheckArenaShopRefreshTime()
	local newRefreshTime = this.GetArenaShopRefreshTimeInternal()
	if newRefreshTime ~= _arenaShopRefreshTime then
		_arenaShopRefreshTime = newRefreshTime

		for k, v in pairs(_arenaShopMap) do
			-- reset the buy count if last buy is last week
			local info = ConfigUtils.GetArenaShopInfo(k)
			if info.WeeklyRefresh and (_arenaShopRefreshTime - v.timestamp >= WEEK_SECONDS) then
				v.count = 0
			end
		end
	end
end

function GameData.GetArenaShopRefreshTime()
	return _arenaShopRefreshTime
end

function GameData.GetBuyCountOfArenaShop(arenaShopId)
	if _arenaShopMap[arenaShopId] == nil then
		return 0
	end

	return _arenaShopMap[arenaShopId].count or 0
end

function GameData.AddBuyCountOfArenaShop(arenaShopId, addCount)
	local preCount = this.GetBuyCountOfArenaShop(arenaShopId)
	_arenaShopMap[arenaShopId] = {count = preCount + addCount, timestamp = this.GetServerTime()}
end
--------------------------------------------------------------------------------
function GameData.GetArenaRecordAt(battleIndex)
	return _arenaRecords[battleIndex] or 0
end

function GameData.SetArenaRecordAt(battleIndex, difficulty)
	local len = #_arenaRecords
	for idx = len + 1, battleIndex do
		_arenaRecords[idx] = 0
	end

	local preDifficulty = _arenaRecords[battleIndex]
	if difficulty > preDifficulty then
		_arenaRecords[battleIndex] = difficulty
	end
end
--------------------------------------------------------------------------------