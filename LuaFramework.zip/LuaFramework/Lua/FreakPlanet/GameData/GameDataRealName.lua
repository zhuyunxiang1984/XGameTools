local this = GameData

local _accountInfo = nil
local _currentPlayTime = nil
local _playTimeSyncTimestamp = nil
local _canStepPlayTime = false

local _enableRealName
local _useRestrictRealName
local _checkIpAddress

RealNameData = {
    GuestTimeLimit = 3600,               -- 游客游戏时间上限
    GuestStartHour = 8,                  -- 游客可以游戏 - 开始时间
    GuestEndHour = 22,                   -- 游客可以游戏 - 结束时间
    UnderageTimeLimit = 3600,            -- 未成年平常游戏时间上限
    UnderageHolidayTimeLimit = 10800,    -- 未成年节假日游戏时间上限
    UnderageStartHour = 8,               -- 未成年可以游戏 - 开始时间
    UnderageEndHour = 22,                -- 未成年可以游戏 - 结束时间        
    
    UnderAge1 = 18,                      -- 未成年年龄
    UnderAge2 = 16,                      -- 未成年年龄 - 可以充值，限制消费金额
    UnderAge3 = 8,                       -- 未成年年龄 - 不能充值

    Age1LimitMoneyPerOrder = 100,        -- Age1对应年龄每笔限制消费金额
    Age2LimitMoneyPerOrder = 50,         -- Age2对应年龄每笔限制消费金额

    Age1LimitMoneyPerMonth = 400,        -- Age1对应年龄每月限制消费金额
    Age2LimitMoneyPerMonth = 200,        -- Age2对应年龄每月限制消费金额
}

--------------------------------------------------------------------------------
function GameData.InitAccountInfo(data)
	_accountInfo = {}
	_accountInfo.accountType = data.AccountType
    _accountInfo.phone = data.Phone
    _accountInfo.idCard = data.IdCard or ""
    _accountInfo.sumPlayTime = data.SumPlayTime or 0
    _accountInfo.todayPlayTime = data.TodayPlayTime or 0
    _accountInfo.monthPay = data.MonthPay or 0
    _accountInfo.sumPay = data.SumPay or 0
    _accountInfo.age = nil
    _accountInfo.country = data.Country or ""
    _accountInfo.province = data.Province or ""

    _currentPlayTime = 0
    _playTimeSyncTimestamp = data.PlayTimeUpdate or 0
    local curTime = GameData.GetServerTime()
    if GameData.IsDifferentDay(curTime, _playTimeSyncTimestamp) then
        _accountInfo.todayPlayTime = 0
        _playTimeSyncTimestamp = curTime
    end
    _canStepPlayTime = false

    log("account info: "..Helper.Format(_accountInfo))
    -- real name switch
    this.CheckRealNameSwitch()
end

function GameData.CheckRealNameSwitch()
    local switches = Helper.StringSplit(Global.SpecialSwitch, ":")
    _enableRealName = true
    _useRestrictRealName = false
    _checkIpAddress = true

    if #switches >= 1 then
        _enableRealName = (tonumber(switches[1]) == 1)
    end

    if #switches >= 2 then
        _useRestrictRealName = (tonumber(switches[2]) == 1)
    end

    if #switches >= 3 then
        _checkIpAddress = (tonumber(switches[3]) == 1)
    end
end

function GameData.IsGuestAccount()
    if this.IsAccountVerified() then
        return false
    end

    if _useRestrictRealName then
        return true
    end

    return not this.IsAccountNicknameBinded()
end

function GameData.IsAccountNicknameBinded()
    return _accountInfo.accountType == 1
end

function GameData.BindAccountNickname()
	_accountInfo.accountType = 1
end

function GameData.IsAccountVerified()
    return not Helper.IsEmptyOrNull(_accountInfo.idCard)
end

function GameData.VerifyAccount(idCard, phone)
    _accountInfo.idCard = idCard
    _accountInfo.phone = phone
    -- force to update when called GetAccountAge
    _accountInfo.age = nil
end

function GameData.GetAccountBindedPhone()
    return _accountInfo.phone
end

function GameData.GetMonthPay()
    return _accountInfo.monthPay
end

function GameData.SetMonthPay(monthPay)
    if monthPay > 0 then
        _accountInfo.monthPay = monthPay
    end
end

function GameData.GetSumPay()
    return _accountInfo.sumPay
end

function GameData.AddSumPay(pay)
    _accountInfo.sumPay = _accountInfo.sumPay + pay
end

function GameData.GetCurrentPlayTime()
    return _currentPlayTime or 0
end

function GameData.SettleCurrentPlayTime(playTime)
    if _accountInfo == nil then
        return
    end

    _currentPlayTime = 0
    _accountInfo.sumPlayTime = _accountInfo.sumPlayTime + playTime
    _accountInfo.todayPlayTime = _accountInfo.todayPlayTime + playTime
    local preSyncTime = _playTimeSyncTimestamp
    _playTimeSyncTimestamp = GameData.GetServerTime()

    if GameData.IsDifferentDay(preSyncTime, _playTimeSyncTimestamp) then
        _accountInfo.todayPlayTime = 0
    end
end

function GameData.GetSumPlayTime()
    if _accountInfo == nil then
        return 0
    end

    return _accountInfo.sumPlayTime
end

function GameData.GetTodayPlayTime()
    if _accountInfo == nil then
        return 0
    end

    return _accountInfo.todayPlayTime
end
--------------------------------------------------------------------------------
function GameData.GetAccountAge()
    --没有绑定身份证,属于未成年人
    if not this.IsAccountVerified() then
        return RealNameData.UnderAge2
    end

    if _accountInfo.age == nil then
        _accountInfo.age = Helper.CalcAge(_accountInfo.idCard)
    end

    return _accountInfo.age
end

function GameData.EnableRealName()
    -- 如果是Editor模式可以跳过
    if Util.IsEditor then
        return false
    end

    if Util.HasMacroDefinition("QA_AUTO") then
        return false
    end

    -- 接入渠道账号，由渠道负责实名
    if Global.HasChannelAccount then
        return false
    end

    -- 审核版本不实名
    if Global.CurrentBigVersion() > Global.MaxServerVersion then
        return false
    end

    if not _enableRealName then
        return false
    end

    if _checkIpAddress then
        if _accountInfo.country ~= "中国" then
            return false
        end

        if _accountInfo.province == "香港" or _accountInfo.province == "澳门" or _accountInfo.province == "台湾" then
            return false
        end
    end

    return true
end

function GameData.IsRestrictRealName()
    return _useRestrictRealName
end

function GameData.GetUnderageDayTimeLimit(weekDay)
    log("week day: "..tostring(weekDay))

    if weekDay == 1 or weekDay == 7 then
        return RealNameData.UnderageHolidayTimeLimit
    end

    return RealNameData.UnderageTimeLimit
end

--是否在未成年可游玩时间段
function GameData.IsAllowUnderAgeToPlay(timestamp)
    local hour = tonumber(os.date("%H",timestamp))
    local min = tonumber(os.date("%M",timestamp))
    --检测时间
    if not ConfigUtils.IsInUnderAgeAvailableHour(hour, min) then
        return false
    end
    local year = tonumber(os.date("%Y",timestamp))
    local month = tonumber(os.date("%m",timestamp))
    local day = tonumber(os.date("%d",timestamp))

    --检测黑名单
    if ConfigUtils.IsInUnderAgeAvailableBlackList(year, month, day) then
        return false
    end
    --检测白名单
    if ConfigUtils.IsInUnderAgeAvailableWhiteList(year, month, day) then
        return true
    end

    --检测周几
    local weekday = tonumber(os.date("%w",timestamp))
    if not ConfigUtils.IsInUnderAgeAvailableWeekday(weekday) then
        return false
    end

    return true
end


--------------------------------------------------------------------------------
function GameData.ShowRealNameHint()
    CtrlManager.OpenPanel(CtrlNames.AccountRealName)
end

function GameData.CheckRealNameOfIap(price)
    if not this.EnableRealName() then
        return true
    end

    if not this.IsAccountVerified() then
        local msg = SAFE_LOC("很抱歉，该账号现在无法充值，请先完成实名认证")
        CtrlManager.ShowMessageBox({message = msg, single = false, onConfirm = GameData.ShowRealNameHint})
        return false
    end

    local age = this.GetAccountAge()
    if age >= RealNameData.UnderAge1 then
        return true
    end

    local msg = nil
    if age < RealNameData.UnderAge3 then
        msg = SAFE_LOC("对不起\n8岁以下用户不可充值")
    end

    if msg == nil and age < RealNameData.UnderAge2 and price > RealNameData.Age2LimitMoneyPerOrder then
        msg = SAFE_LOC("很抱歉，充值金额超过当前年龄限制")
    end

    if msg == nil and price > RealNameData.Age1LimitMoneyPerOrder then
        msg = SAFE_LOC("很抱歉，充值金额超过当前年龄限制")
    end

    local monthCost = this.GetMonthPay() + price
    if msg == nil and age < RealNameData.UnderAge2 and monthCost > RealNameData.Age2LimitMoneyPerMonth then
        msg = SAFE_LOC("很抱歉，充值金额超过当前年龄限制")
    end

    if msg == nil and monthCost > RealNameData.Age1LimitMoneyPerMonth then
        msg = SAFE_LOC("很抱歉，充值金额超过当前年龄限制")
    end

    if msg == nil then
        return true
    end

    CtrlManager.ShowAlert(msg)
    return false
end
--------------------------------------------------------------------------------
function GameData.SetCanStepPlayTime(canStep)
    _canStepPlayTime = canStep
end

function GameData.StepPlayTime(dt)
    if _accountInfo == nil or not _canStepPlayTime then
        return
    end

    local prePlayTime = _currentPlayTime or 0
    _currentPlayTime = prePlayTime + dt
end
--------------------------------------------------------------------------------
--是否在游客可游玩时间段
function GameData.IsGuestAvailableTime(hour)
    if RealNameData.GuestStartHour == RealNameData.GuestEndHour then
        return true
    end
    return hour >= RealNameData.GuestStartHour and hour < RealNameData.GuestEndHour
end
--是否在未成年可游玩时间段
function GameData.IsUnderageAvailableTime(hour)
    if RealNameData.UnderageStartHour == RealNameData.UnderageEndHour then
        return true
    end
    return hour >= RealNameData.UnderageStartHour and hour < RealNameData.UnderageEndHour
end