
local this = GameData

local _spaceTravelSeasonConfig = nil
local _spaceTravelData = nil
local _newSpaceTravelGoals = nil

SpaceTravelSeasonStatus = {
    Idle = "Idle",
    Playing = "Playing",
    Settled = "Settled",
}

SpaceTravelNodeStatus = {
    Idle = 0,
    Move = 1,
    SelectChoice = 2,
    FinishChoice = 3,
    Completed = 4,
}
----------------------------------------------------------------------------------
local function GetSpaceTravelItemCurrentList(seasonId, goalTriggers, goalType, goalValue)
    local itemList = {}

    local specified = false

    if goalValue ~= INVALID_ID then
        specified = true
        itemList[1] = goalValue
    else
        if goalType == ItemType.SpaceTravelGoods then
            itemList = GameData.GetSpaceTravelGoodsList(seasonId)
        else
            assert(false, "un-handled goal item type: "..tostring(goalType))
        end
    end

    return itemList, specified
end

local function GetSpaceTravelGoalActualNum(seasonId, goalTriggers, goalCondition, numFromServer)
    local countType = goalCondition.CountType
    if countType == GoalCountType.Current then
        local curNum = 0
        local itemList, specified = GetSpaceTravelItemCurrentList(seasonId, goalTriggers, goalCondition.Type, goalCondition.Value)
        if specified then
            curNum = this.GetSpaceTravelItemNum(seasonId, itemList[1])
        else
            for idx = 1, #itemList do
                local itemId = itemList[idx]
                local itemNum = this.GetSpaceTravelItemNum(seasonId, itemId)
                local input = this.SetupItemGoalData(itemId, itemNum)
                if this.IsSpaceTravelGoalConditionMatched(goalCondition, input, false) then
                    curNum = curNum + itemNum
                end
            end
        end

        return curNum, true
    end

    return numFromServer, false
end
----------------------------------------------------------------------------------
function GameData.InitSpaceTravelSeasonConfig(seasonList)
    seasonList = seasonList or {}

    _spaceTravelSeasonConfig = {}
    for k, v in pairs(seasonList) do
        local seasonId = v.STSeasonID
        local scoreCapList = {}
        Helper.CopyTable(scoreCapList, v.ScoreCapList or {})
        local mapList = {}
        Helper.CopyTable(mapList, v.MapList or {})

        if #scoreCapList > 0 and #mapList > 0 then

            local startTime = v.StartTime or 0
            local endTime = v.EndTime or 0
            endTime = math.max(endTime - 5, startTime)

            _spaceTravelSeasonConfig[seasonId] = {
                startTime = startTime,
                endTime = endTime,
                scoreCapList = scoreCapList,
                mapList = mapList,
            }
        end
    end
end

function GameData.GetScoreCapOfSpaceTravelSeason(seasonId, scoreCapRank)
    local config = _spaceTravelSeasonConfig[seasonId]
    if config == nil then
        return nil
    end

    return config.scoreCapList[scoreCapRank] 
end

function GameData.GetWorldOfSpaceTravelSeason(seasonId, worldIndex)
    local config = _spaceTravelSeasonConfig[seasonId]
    if config == nil then
        return nil
    end

    return config.mapList[worldIndex]
end

function GameData.GetSpaceTravelSeasonWorldCount(seasonId)
    local config = _spaceTravelSeasonConfig[seasonId]
    if config == nil then
        return 0
    end

    return #config.mapList
end

function GameData.IsSpaceTravelSeasonStillValid(seasonId)
    local config = _spaceTravelSeasonConfig[seasonId]
    if config == nil then
        return false
    end

    local curTime = GameData.GetServerTime()
    local startTime = config.startTime
    local endTime = config.endTime

    return curTime >= startTime and curTime < endTime
end

function GameData.GetSpaceTravelActiveSeason()
    local curTime = GameData.GetServerTime()
    for k, v in pairs(_spaceTravelSeasonConfig) do
        local startTime = v.startTime
        local endTime = v.endTime
        if curTime >= startTime and curTime < endTime then
            return k
        end
    end

    return nil
end

function GameData.GetSpaceTravelSeasonEndTime(seasonId)
    local config = _spaceTravelSeasonConfig[seasonId]
    assert(config ~= nil, "not found space travel season: "..tostring(seasonId))

    return config.endTime, config.startTime
end

function GameData.GetSpaceTravelSeasonRegisterEndTime(seasonId)
    local config = _spaceTravelSeasonConfig[seasonId]
    assert(config ~= nil, "not found space travel season: "..tostring(seasonId))

    return math.max(config.endTime - SpaceTravelRegisterEarlyTime, config.startTime)
end
----------------------------------------------------------------------------------
-- Tips:
-- 食物，燃料不能超上限；负重可以超上限，但是会受到惩罚
-- 友好度有上限，上限在配置文件中配置

function GameData.InitSpaceTravelData(data)
	_spaceTravelData = {}

    log("===================space travel data: "..Helper.Format(data))

    -- life data
    local lifeData = data.STLifeData
    -- score cap
    _spaceTravelData.scoreCap = lifeData.ScoreCap or 0
    -- unlock ships
    _spaceTravelData.unlockShips = {}
    local shipList = lifeData.ShipList or {}
    for idx = 1, #shipList do
        local shipId = shipList[idx]
        _spaceTravelData.unlockShips[shipId] = 1
    end
    -- friendliness
    _spaceTravelData.friendliness = {}
    local friendlinessList = lifeData.Friendliness or {}
    for idx = 1, #friendlinessList do
        local friendlinessId = friendlinessList[idx][1]
        local friendlinessNum = friendlinessList[idx][2]
        _spaceTravelData.friendliness[friendlinessId] = friendlinessNum
    end
    -- career data
    _spaceTravelData.careerList = this.ConstructDefaultCareerList()
    local careerList = lifeData.CareerList or {}
    for k, v in pairs(careerList) do
        local careerId = v[1]
        _spaceTravelData.careerList[careerId] = v[2]
    end
    -- season data
    _spaceTravelData.seasons = {}
    local seasonData = data.STSeasonData or {}
    for idx = 1, #seasonData do
        local e = seasonData[idx]
        this.SetSpaceTravelSeasonData(e.STSeasonID, e)
    end
end

function GameData.SetSpaceTravelSeasonData(seasonId, data)
    local shipId = data.Ship
    local labId = ConfigUtils.GetSpaceShipLabraroty(shipId)
    local relicMax = ConfigUtils.GetSpaceShipRelicSlot(shipId)
    local goodsMax = ConfigUtils.GetSpaceShipStorageSlot(shipId)
    -- current space travel goods
    local spaceTravelGoods = {}
    -- current space travel relics
    local spaceTravelRelics = {}
    -- current space travel friendliness
    local spaceTravelFriendliness = {}
    -- goods
    local goodsList = data.GoodsList or {}
    for idx = 1, #goodsList do
        local goodsId = goodsList[idx][1]
        local goodsNum = goodsList[idx][2]
        if goodsNum > 0 then
            local subType = ConfigUtils.GetSpaceTravelGoodsSubType(goodsId)
            if subType == SpaceTravelGoodsSubType.Relic then
                for m = 1, goodsNum do
                    table.insert(spaceTravelRelics, goodsId)
                end
            else
                table.insert(spaceTravelGoods, {id = goodsId, num = goodsNum})
            end
        end
    end
    -- friendliness
    local friendliness = data.Friendliness or {}
    for idx = 1, #friendliness do
        local fid = friendliness[idx][1]
        local fnum = friendliness[idx][2]
        spaceTravelFriendliness[fid] = fnum
    end
    -- node
    local nodeId = data.Node
    if nodeId == "" or not ConfigUtils.IsValidItem(nodeId) then
        nodeId = nil
    end
    -- the first try, no result select
    if data.TryCount == 1 and data.Status > 0 then
        data.Status = 2
    end

    _spaceTravelData.seasons[seasonId] = {
        status = data.Status,
        seasonRetry = data.TryCount,
        scoreCap = data.ScoreCap,
        timestamp = data.SignupTime,
        fuel = data.Fuel,
        fuelMax = data.FuelMax,
        food = data.Food,
        foodMax = data.FoodMax,
        capacity = 0,                      -- calculated by goods
        capacityMax = data.CapacityMax,
        lastScore = data.LastScore or 0,
        score = data.Score,
        ship = shipId,
        lab = labId,
        labLevel = data.LabLevel,
        world = data.World,
        node = nodeId,
        nodeStatus = data.NodeStatus,
        forwardStep = data.ForwardStep,
        goods = spaceTravelGoods,
        goodsMax = goodsMax,
        relic = spaceTravelRelics,
        relicMax = relicMax,
        choiceEvent = data.EventID,
        choiceList = data.ChoiceList or {},
        choiceIdx = data.ChoiceIndex or 0,
        friendliness = spaceTravelFriendliness,
        choiceRetry = data.CurChoiceRetry or 0,
        leftBattleRetry = data.LeftBattleRetry or 0,
        nodeCount = data.NodeCount,
    }
    -- refresh capacity
    this.RefreshSpaceTravelCapacity(seasonId)
    -- check score career
    this.ModifySpaceTravelAbsoluteCareerData(SpaceTravelCareerType.HighestScore, data.Score)
    -- check node num career
    this.ModifySpaceTravelAbsoluteCareerData(SpaceTravelCareerType.HighestNodeNum, data.NodeCount or 0)
    -- goal list, should construct after the season data is ok
    local goals = data.GoalList or {}
    _spaceTravelData.seasons[seasonId].goals = this.ConstructSpaceTravelGoals(seasonId, goals)

    -- is first try or not
    return (data.TryCount == 1)
end

function GameData.ConstructSpaceTravelGoals(seasonId, goals)
    local ret = {}
    for k, v in pairs(goals) do
        if not v.GetReward then
            local goalId = v.GoalId
            local completedInServer = v.IsComplete or false
            -- number list
            local conditions = ConfigUtils.GetGoalConditions(goalId)
            local goalTriggers = ConfigUtils.GetGoalTriggers(goalId)
            assert(#conditions == #v.CurrentNumList, "the number list of space travel goal is not same with server data: "..tostring(goalId))
            local number = {}
            local hasLocal = false
            local actualNumMatch = true
            for idx = 1, #conditions do
                local goalNeedNum = conditions[idx].Num
                local numFromServer = v.CurrentNumList[idx]
                -- do not check
                if completedInServer then
                    number[idx] = math.max(numFromServer, goalNeedNum)
                else
                    local finalNum, useLocal = GetSpaceTravelGoalActualNum(seasonId, goalTriggers, conditions[idx], numFromServer)

                    if useLocal then
                        hasLocal = true
                    end

                    if finalNum < goalNeedNum then
                        actualNumMatch = false
                    end

                    number[idx] = finalNum
                end
            end

            -- state
            local state = GoalState.Complete
            if hasLocal or not actualNumMatch then
                state = GoalState.Running
            end

            ret[goalId] = {state = state, number = number}
        end
    end

    return ret
end

function GameData.ConstructDefaultCareerList()
    local ret = {}

    for k, v in pairs(SpaceTravelCareerType) do
        ret[v] = 0
    end

    return ret
end

function GameData.RefreshSpaceTravelCapacity(seasonId)
    local seasonData = _spaceTravelData.seasons[seasonId]
    if seasonData == nil then
        return
    end

    local capacity = 0
    for k, v in pairs(seasonData.goods) do
        capacity = capacity + ConfigUtils.GetSpaceTravelGoodsSupplyCapacity(v.id) * v.num
    end

    for k, v in pairs(seasonData.relic) do
        capacity = capacity + ConfigUtils.GetSpaceTravelGoodsSupplyCapacity(v)
    end

    local preValue = seasonData.capacity
    seasonData.capacity = capacity
    GameNotifier.Notify(GameEvent.SpaceTravelCapacityChanged, capacity - preValue, false)
end

function GameData.SwitchWorld(seasonId)
    local seasonData = this.GetSpaceTravelSeasonData(seasonId)
    seasonData.world = seasonData.world + 1
    seasonData.node = nil
    seasonData.nodeStatus = SpaceTravelNodeStatus.Idle
end

function GameData.GetSpaceTravelSeasonData(seasonId)
    return _spaceTravelData.seasons[seasonId]
end

function GameData.GetSpaceTravelScoreCapRank()
    return _spaceTravelData.scoreCap
end

function GameData.GetSpaceTravelFriendliness(friendlinessId)
    return _spaceTravelData.friendliness[friendlinessId] or 0
end

function GameData.IsSpaceTravelSeasonOn()
    return this.GetSpaceTravelActiveSeason() ~= nil
end

function GameData.GetSpaceTravelSeasonTimestamp(seasonId)
    local seasonData = this.GetSpaceTravelSeasonData(seasonId)
    return seasonData.timestamp
end

function GameData.IsSpaceTravelSeasonFoodMaxed(seasonId)
    local seasonData = this.GetSpaceTravelSeasonData(seasonId)
    return seasonData.food >= seasonData.foodMax
end

function GameData.IsSpaceTravelSeasonFuelMaxed(seasonId)
    local seasonData = this.GetSpaceTravelSeasonData(seasonId)
    return seasonData.fuel >= seasonData.fuelMax
end

function GameData.ModifySpaceTravelFood(seasonId, num)
    local seasonData = this.GetSpaceTravelSeasonData(seasonId)
    local preNum = seasonData.food
    local curNum = preNum + num
    curNum = math.min(curNum, seasonData.foodMax)
    seasonData.food = curNum

    if preNum ~= curNum then
        GameNotifier.Notify(GameEvent.SpaceTravelFoodChanged, curNum - preNum, false)
    end
end

function GameData.ModifySpaceTravelFuel(seasonId, num)
    local seasonData = this.GetSpaceTravelSeasonData(seasonId)
    local preNum = seasonData.fuel
    local curNum = preNum + num
    curNum = math.min(curNum, seasonData.fuelMax)
    seasonData.fuel = curNum

    if preNum ~= curNum then
        GameNotifier.Notify(GameEvent.SpaceTravelFuelChanged, curNum - preNum, false)
    end
end

function GameData.ModifySpaceTravelScore(seasonId, num)
    local seasonData = this.GetSpaceTravelSeasonData(seasonId)
    local preScore = seasonData.score
    local curScore = preScore + num
    seasonData.score = curScore
    GameNotifier.Notify(GameEvent.SpaceTravelScoreChanged, curScore - preScore)
    -- check score career
    this.ModifySpaceTravelAbsoluteCareerData(SpaceTravelCareerType.HighestScore, curScore)
end

function GameData.ModifySpaceTravelFoodMax(seasonId, num)
    local seasonData = this.GetSpaceTravelSeasonData(seasonId)
    local preValue = seasonData.foodMax
    local curValue = seasonData.foodMax + num
    seasonData.foodMax = curValue
    GameNotifier.Notify(GameEvent.SpaceTravelFoodChanged, curValue - preValue, true)
end

function GameData.ModifySpaceTravelFuelMax(seasonId, num)
    local seasonData = this.GetSpaceTravelSeasonData(seasonId)
    local preValue = seasonData.fuelMax
    local curValue = seasonData.fuelMax + num
    seasonData.fuelMax = curValue
    GameNotifier.Notify(GameEvent.SpaceTravelFuelChanged, curValue - preValue, true)
end

function GameData.ModifySpaceTravelCapacityMax(seasonId, num)
    local seasonData = this.GetSpaceTravelSeasonData(seasonId)
    local preValue = seasonData.capacityMax
    local curValue = preValue + num
    seasonData.capacityMax = curValue
    GameNotifier.Notify(GameEvent.SpaceTravelCapacityChanged, curValue - preValue, true)
end

function GameData.ModifySpaceTravelFriendliness(seasonId, fid, num)
    local seasonData = this.GetSpaceTravelSeasonData(seasonId)
    local preValue = seasonData.friendliness[fid] or 0
    local curValue = preValue + num
    this.SetSpaceTravelFriendliness(seasonId, fid, curValue)
    -- goal
    local goalData = this.SetupItemGoalData(fid, num)
    this.DoSpaceTravelGoalSettle(seasonId, TriggerType.FriendlinessUp, {goalData})
end

function GameData.SetSpaceTravelFriendliness(seasonId, fid, num)
    local maxNum = ConfigUtils.GetSpaceTravelFriendlinessMax(fid)
    num = math.max(num, 0)
    num = math.min(num, maxNum)

    local seasonData = this.GetSpaceTravelSeasonData(seasonId)
    seasonData.friendliness[fid] = num
end

function GameData.SyncSpaceTravelSeasonBaseData(seasonId, data)
    local food = data.Food or 0
    local fuel = data.Fuel or 0
    local score = data.Score or 0

    local seasonData = this.GetSpaceTravelSeasonData(seasonId)
    local preFood = seasonData.food
    local preFuel = seasonData.fuel
    local preScore = seasonData.score

    if food ~= preFood then
        seasonData.food = food
        GameNotifier.Notify(GameEvent.SpaceTravelFoodChanged, food - preFood, false)
    end

    if fuel ~= preFuel then
        seasonData.fuel = fuel
        GameNotifier.Notify(GameEvent.SpaceTravelFuelChanged, fuel - preFuel, false)
    end

    if score ~= preScore then
        seasonData.score = score
        GameNotifier.Notify(GameEvent.SpaceTravelScoreChanged, score - preScore)
        -- check score career
        this.ModifySpaceTravelAbsoluteCareerData(SpaceTravelCareerType.HighestScore, score)
    end
end

function GameData.GetStatusOfSpaceTravelSeason(seasonId)
    if _spaceTravelData.seasons[seasonId] == nil then
        return SpaceTravelSeasonStatus.Idle
    end

    local status = _spaceTravelData.seasons[seasonId].status
    if status == 0 or status == 1 then
        return SpaceTravelSeasonStatus.Playing
    end

    return SpaceTravelSeasonStatus.Settled
end

function GameData.GetNodeStatusOfSpaceTravelSeason(seasonId)
    local seasonData = this.GetSpaceTravelSeasonData(seasonId)
    return seasonData.nodeStatus
end

function GameData.GetForwardOfSpaceTravelSeason(seasonId)
    local seasonData = this.GetSpaceTravelSeasonData(seasonId)
    return seasonData.forwardStep
end

function GameData.SetDiceResultForSpaceTravelSeason(seasonId, forwardStep)
    local seasonData = this.GetSpaceTravelSeasonData(seasonId)
    seasonData.nodeStatus = SpaceTravelNodeStatus.Move
    seasonData.forwardStep = forwardStep
end

function GameData.StepNodeForSpaceTravelSeason(seasonId, nodeId, choiceEvent, choiceList)
    local seasonData = this.GetSpaceTravelSeasonData(seasonId)
    seasonData.nodeStatus = SpaceTravelNodeStatus.SelectChoice
    seasonData.node = nodeId
    seasonData.choiceEvent = choiceEvent
    seasonData.choiceList = choiceList
    -- all steps forwarded
    local preCount = seasonData.nodeCount or 0
    local thisStep = seasonData.forwardStep
    -- season node count
    seasonData.nodeCount = preCount + thisStep
    -- career node count
    this.ModifySpaceTravelCareerData(SpaceTravelCareerType.TotalNodeNum, thisStep)
    this.ModifySpaceTravelAbsoluteCareerData(SpaceTravelCareerType.HighestNodeNum, seasonData.nodeCount)
end

function GameData.SelectChoiceForSpaceTravelSeason(seasonId, choiceIdx)
    local seasonData = this.GetSpaceTravelSeasonData(seasonId)
    local choiceId = seasonData.choiceList[choiceIdx]
    local choiceType = ConfigUtils.GetSpaceTravelChoiceType(choiceId)
    if choiceType == SpaceTravelChoiceType.Command or choiceType == SpaceTravelChoiceType.Goal then
        seasonData.nodeStatus = SpaceTravelNodeStatus.Completed

    else
        seasonData.nodeStatus = SpaceTravelNodeStatus.FinishChoice
    end
    seasonData.choiceIdx = choiceIdx
    seasonData.choiceRetry = 0

    this.CheckSpaceTravelSeasonWorldFinish(seasonId)
end

function GameData.FinishChoiceForSpaceTravelSeason(seasonId, friendliness)
    local seasonData = this.GetSpaceTravelSeasonData(seasonId)
    -- node status
    seasonData.nodeStatus = SpaceTravelNodeStatus.Completed
    -- friendliness
    if friendliness ~= nil then
        local spaceTravelFriendliness = {}
        for idx = 1, #friendliness do
            local fid = friendliness[idx][1]
            local fnum = friendliness[idx][2]
            spaceTravelFriendliness[fid] = fnum
        end
        seasonData.friendliness = spaceTravelFriendliness
    end

    this.CheckSpaceTravelSeasonWorldFinish(seasonId)
end

function GameData.CheckSpaceTravelSeasonWorldFinish(seasonId)
    local seasonData = this.GetSpaceTravelSeasonData(seasonId)
    if seasonData.nodeStatus ~= SpaceTravelNodeStatus.Completed then
        return
    end

    local worldIndex = seasonData.world
    local worldId = GameData.GetWorldOfSpaceTravelSeason(seasonId, worldIndex)
    local isLastNode = ConfigUtils.IsLastNodeOfSpaceTravelWorld(worldId, seasonData.node)
    if isLastNode then
        this.ModifySpaceTravelCareerData(SpaceTravelCareerType.WorldCompleteCount, 1)
    end
end

function GameData.IsSpaceTravelShipUnlocked(shipId)
    return _spaceTravelData.unlockShips[shipId] ~= nil
end

function GameData.UnlockSpaceTravelShip(shipId)
    _spaceTravelData.unlockShips[shipId] = 1
end

function GameData.GetSpaceTravelCareerValue(careerId)
    return _spaceTravelData.careerList[careerId] or 0
end

function GameData.ModifySpaceTravelCareerData(careerId, value)
    local preValue = _spaceTravelData.careerList[careerId] or 0
    _spaceTravelData.careerList[careerId] = preValue + value
    --log("career data 1: "..Helper.Format(_spaceTravelData.careerList))
end

function GameData.ModifySpaceTravelAbsoluteCareerData(careerId, value)
    local preValue = _spaceTravelData.careerList[careerId] or 0
    if value > preValue then
        _spaceTravelData.careerList[careerId] = value
        --log("career data 2: "..Helper.Format(_spaceTravelData.careerList))
    end
end

function GameData.GetSpaceTravelGoodsNum(seasonId, goodsId)
    local seasonData = this.GetSpaceTravelSeasonData(seasonId)
    local subType = ConfigUtils.GetSpaceTravelGoodsSubType(goodsId)
    if subType == SpaceTravelGoodsSubType.Relic then
        local num = 0
        for idx = 1, #seasonData.relic do
            if seasonData.relic[idx] == goodsId then
                num = num + 1
            end
        end

        return num
    else
        for idx = 1, #seasonData.goods do
            if seasonData.goods[idx].id == goodsId then
                return seasonData.goods[idx].num
            end
        end
    end

    return 0
end

function GameData.ConsumeSpaceTravelItem(seasonId, itemId, itemNum)
    local itemType = ConfigUtils.GetItemTypeFromId(itemId)
    if itemType == ItemType.Fuel then
        this.ModifySpaceTravelFuel(seasonId, -itemNum)
    elseif itemType == ItemType.Food then
        this.ModifySpaceTravelFood(seasonId, -itemNum)
    elseif itemType == ItemType.SpaceTravelFriendliness then
        this.ModifySpaceTravelFriendliness(seasonId, itemId, -itemNum)
    elseif itemType == ItemType.SpaceTravelGoods then
        this.ConsumeSpaceTravelGoods(seasonId, itemId, itemNum)
    else
        assert(false, "un-handled space travel item type: "..tostring(itemId))
    end
end

function GameData.ConsumeSpaceTravelGoods(seasonId, goodsId, goodsNum)
    if goodsNum <= 0 then
        return
    end

    local seasonData = this.GetSpaceTravelSeasonData(seasonId)
    local subType = ConfigUtils.GetSpaceTravelGoodsSubType(goodsId)
    if subType == SpaceTravelGoodsSubType.Relic then
        local leftCount = goodsNum
        for idx = #seasonData.relic, 1, -1 do
            if seasonData.relic[idx] == goodsId then
                table.remove(seasonData.relic, idx)
                leftCount = leftCount - 1
                if leftCount <= 0 then
                    break
                end
            end
        end
    else
        for idx = 1, #seasonData.goods do
            if seasonData.goods[idx].id == goodsId then
                local leftNum = seasonData.goods[idx].num - goodsNum
                assert(leftNum >= 0, "goods is not enough: "..tostring(goodsId))
                if leftNum == 0 then
                    table.remove(seasonData.goods, idx)
                else
                    seasonData.goods[idx].num = leftNum
                end
                break
            end
        end
    end

    this.RefreshSpaceTravelCapacity(seasonId)
    GameNotifier.Notify(GameEvent.SpaceTravelGoodsChanged, goodsId)
end

function GameData.CollectSpaceTravelItem(seasonId, itemId, itemNum)
    local itemType = ConfigUtils.GetItemTypeFromId(itemId)
    if itemType == ItemType.Fuel then
        this.ModifySpaceTravelFuel(seasonId, itemNum)
    elseif itemType == ItemType.FuelMax then
        this.ModifySpaceTravelFuelMax(seasonId, itemNum)
    elseif itemType == ItemType.Food then
        this.ModifySpaceTravelFood(seasonId, itemNum)
    elseif itemType == ItemType.FoodMax then
        this.ModifySpaceTravelFoodMax(seasonId, itemNum)
    elseif itemType == ItemType.CapacityMax then
        this.ModifySpaceTravelCapacityMax(seasonId, itemNum)
    elseif itemType == ItemType.SpaceTravelScore then
        this.ModifySpaceTravelScore(seasonId, itemNum)
    elseif itemType == ItemType.SpaceTravelFriendliness then
        this.ModifySpaceTravelFriendliness(seasonId, itemId, itemNum)
    elseif itemType == ItemType.SpaceTravelGoods then
        this.CollectSpaceTravelGoods(seasonId, itemId, itemNum)
    else
        assert(false, "un-handled space travel item type: "..tostring(itemId))
    end
end

function GameData.CollectSpaceTravelGoods(seasonId, goodsId, goodsNum)
    local seasonData = this.GetSpaceTravelSeasonData(seasonId)
    local subType = ConfigUtils.GetSpaceTravelGoodsSubType(goodsId)
    if subType == SpaceTravelGoodsSubType.Relic then
        for idx = 1, goodsNum do
            table.insert(seasonData.relic, goodsId)
        end
    else
        local found = false
        for idx = 1, #seasonData.goods do
            if seasonData.goods[idx].id == goodsId then
                seasonData.goods[idx].num = seasonData.goods[idx].num + goodsNum
                found = true
                break
            end
        end

        if not found then
            table.insert(seasonData.goods, {id = goodsId, num = goodsNum})
        end
    end

    this.RefreshSpaceTravelCapacity(seasonId)
    GameNotifier.Notify(GameEvent.SpaceTravelGoodsChanged, goodsId)
end

function GameData.SetSpaceTravelSeasonGoods(seasonId, relicList, goodsList)
    local seasonData = this.GetSpaceTravelSeasonData(seasonId)
    seasonData.relic = relicList
    seasonData.goods = goodsList

    this.RefreshSpaceTravelCapacity(seasonId)
    GameNotifier.Notify(GameEvent.SpaceTravelGoodsChanged, nil)
end

function GameData.GetSpaceTravelItemNum(seasonId, itemId)
    local seasonData = this.GetSpaceTravelSeasonData(seasonId)
    local itemType = ConfigUtils.GetItemTypeFromId(itemId)
    if itemType == ItemType.Fuel then
        return seasonData.fuel
    elseif itemType == ItemType.FuelMax then
        return seasonData.fuelMax
    elseif itemType == ItemType.Food then
        return seasonData.food
    elseif itemType == ItemType.FoodMax then
        return seasonData.foodMax
    elseif itemType == ItemType.CapacityMax then
        return seasonData.capacityMax
    elseif itemType == ItemType.SpaceTravelScore then
        return seasonData.score
    elseif itemType == ItemType.SpaceTravelFriendliness then
        return seasonData.friendliness[itemId] or 0
    elseif itemType == ItemType.SpaceTravelGoods then
        return this.GetSpaceTravelGoodsNum(seasonId, itemId)
    else
        assert(false, "un-handled space travel item type: "..tostring(itemId))
    end
end

function GameData.GetSpaceTravelGoodsList(seasonId)
    local ret = {}
    local goodsMap = {}

    local seasonData = this.GetSpaceTravelSeasonData(seasonId)
    for idx = 1, #seasonData.relic do
        local goodsId = seasonData.relic[idx]
        if goodsMap[goodsId] == nil then
            table.insert(ret, goodsId)
            goodsMap[goodsId] = 1
        end
    end

    for idx = 1, #seasonData.goods do
        local goodsId = seasonData.goods[idx].id
        if goodsMap[goodsId] == nil then
            table.insert(ret, goodsId)
            goodsMap[goodsId] = 1
        end
    end

    return ret
end

function GameData.ConvertSpaceTravelRewardDataFormat(dropList)
    local ret = {}

    for k, v in pairs(dropList) do
        table.insert(ret, {v.Value, v.Num})
    end

    return ret
end

function GameData.GetSpaceTravelFriendlinessChanges(seasonId, friendliness)
    local ret = {}

    local seasonData = this.GetSpaceTravelSeasonData(seasonId)

    for k, v in pairs(friendliness) do
        local friendlinessId = v[1]
        local friendlinessValue = v[2]
        local curValue = seasonData.friendliness[friendlinessId] or 0
        if friendlinessValue ~= curValue then
            ret[friendlinessId] = (friendlinessValue - curValue)
        end
    end

    return ret
end

function GameData.SettleSpaceTravelChoiceCancel(seasonId, choiceId)
    -- sync status
    this.FinishChoiceForSpaceTravelSeason(seasonId, nil)

    local ret = {}

    local rewardMap = {}
    local goodsList = ConfigUtils.GetSpaceTravelChoiceCancelResult(choiceId)
    for k, v in pairs(goodsList) do
        local itemId = v.Value
        local itemNum = v.Num
        local itemType = ConfigUtils.GetItemTypeFromId(itemId)
        -- goods consume directly
        if itemType == ItemType.SpaceTravelGoods and itemNum < 0 then
            this.ConsumeSpaceTravelItem(itemId, -itemNum)
        else
            local preNum = rewardMap[itemId] or 0
            rewardMap[itemId] = preNum + itemNum
        end
    end

    for k, v in pairs(rewardMap) do
        if v ~= 0 then
            table.insert(ret, {k, v})
        end
    end

    return ret
end

function GameData.SettleSpaceTravelChoiceResult(seasonId, choiceId, isWin)
    -- sync status
    this.FinishChoiceForSpaceTravelSeason(seasonId, nil)

    local ret = {}

    local rewardMap = {}
    local goodsList = ConfigUtils.GetSpaceTravelChoiceResult(choiceId, isWin)
    for k, v in pairs(goodsList) do
        local itemId = v.Value
        local itemNum = v.Num
        local itemType = ConfigUtils.GetItemTypeFromId(itemId)
        -- goods consume directly
        if itemType == ItemType.SpaceTravelGoods and itemNum < 0 then
            this.ConsumeSpaceTravelItem(itemId, -itemNum)
        else
            local preNum = rewardMap[itemId] or 0
            rewardMap[itemId] = preNum + itemNum
        end
    end

    for k, v in pairs(rewardMap) do
        if v ~= 0 then
            table.insert(ret, {k, v})
        end
    end

    return ret
end

function GameData.ConstructSpaceTravelChoiceResultParameter(seasonId, dropList, baseData)
    local foodMaxChange = 0
    local fuelMaxChange = 0
    local capacityMaxChange = 0

    local foodClientChange = 0
    local fuelClientChange = 0
    local scoreClientChange = 0

    local friendliness = {}
    local goodsMap = {}

    for idx = 1, #dropList do
        local itemId = dropList[idx][1]
        local itemNum = dropList[idx][2]
        local itemType = ConfigUtils.GetItemTypeFromId(itemId)
        if itemType == ItemType.Fuel then
            fuelClientChange = fuelClientChange + itemNum
        elseif itemType == ItemType.Food then
            foodClientChange = foodClientChange + itemNum
        elseif itemType == ItemType.SpaceTravelScore then
            scoreClientChange = scoreClientChange + itemNum
        elseif itemType == ItemType.FuelMax then
            fuelMaxChange = fuelMaxChange + itemNum
        elseif itemType == ItemType.FoodMax then
            foodMaxChange = foodMaxChange + itemNum
        elseif itemType == ItemType.CapacityMax then
            capacityMaxChange = capacityMaxChange + itemNum 
        elseif itemType == ItemType.SpaceTravelFriendliness then
            local preNum = friendliness[itemId] or 0
            friendliness[itemId] = preNum + itemNum
        elseif itemType == ItemType.SpaceTravelGoods then
            local preNum = goodsMap[itemId] or 0
            goodsMap[itemId] = preNum + itemNum
        else
            assert(false, "un-handled space travel item type: "..tostring(itemId))
        end
    end

    return {
        seasonId = seasonId,
        foodMax = foodMaxChange,
        fuelMax = fuelMaxChange,
        capacityMax = capacityMaxChange,
        friendliness = friendliness,
        goods = goodsMap,
        finalFood = baseData.Food,
        finalFuel = baseData.Fuel,
        finalScore = baseData.Score,
        clientFood = foodClientChange,
        clientFuel = fuelClientChange,
        clientScore = scoreClientChange,
    }
end
--------------------------------------------------------------------------------
function GameData.GetSpaceTravelGoalsOfSeason(seasonId)
    local ret = {}

    local seasonData = this.GetSpaceTravelSeasonData(seasonId)
    for k, v in pairs(seasonData.goals) do
        if v.state ~= GoalState.Closed then
            table.insert(ret, k)
        end
    end

    return ret
end

function GameData.HasSpaceTravelGoal(seasonId, goalId)
    local seasonData = this.GetSpaceTravelSeasonData(seasonId)
    return seasonData.goals[goalId] ~= nil
end

function GameData.CloseSpaceTravelGoal(seasonId, goalId)
    local seasonData = this.GetSpaceTravelSeasonData(seasonId)
    seasonData.goals[goalId] = nil
end

function GameData.IsSpaceTravelGoalCompleted(seasonId, goalId)
    local goalState = this.GetSpaceTravelGoalInfo(seasonId, goalId)
    return goalState == GoalState.Complete
end

function GameData.IsSpaceTravelGoalRunning(seasonId, goalId)
    local goalState = this.GetSpaceTravelGoalInfo(seasonId, goalId)
    return goalState == GoalState.Running
end

function GameData.IsNewSpaceTravelGoal(goalId)
    if _newSpaceTravelGoals == nil then
        return false
    end

    return _newSpaceTravelGoals[goalId] ~= nil
end

function GameData.CleanNewSpaceTravelGoal()
    _newSpaceTravelGoals = {}
end

function GameData.AddSpaceTravelGoal(seasonId, goalId)
    local seasonData = this.GetSpaceTravelSeasonData(seasonId)
    if seasonData.goals[goalId] ~= nil then
        return
    end

    local conditions = ConfigUtils.GetGoalConditions(goalId)
    local goalTriggers = ConfigUtils.GetGoalTriggers(goalId)
    local number = {}
    local hasLocal = false
    local actualNumMatch = true
    for idx = 1, #conditions do
        local goalNeedNum = conditions[idx].Num
        local finalNum, useLocal = GetSpaceTravelGoalActualNum(seasonId, goalTriggers, conditions[idx], 0)
        if useLocal then
            hasLocal = true
        end

        if finalNum < goalNeedNum then
            actualNumMatch = false
        end

        number[idx] = finalNum
    end

    -- state
    local state = GoalState.Complete
    if hasLocal or not actualNumMatch then
        state = GoalState.Running
    end

    seasonData.goals[goalId] = {state = state, number = number}

    if _newSpaceTravelGoals == nil then
        _newSpaceTravelGoals = {}
    end
    _newSpaceTravelGoals[goalId] = 1
end

function GameData.HasNewSpaceTravelGoal()
    if _newSpaceTravelGoals == nil then
        return false
    end

    for k, v in pairs(_newSpaceTravelGoals) do
        return true
    end

    return false
end

function GameData.HasCompletedSpaceTravelGoal(seasonId)
    local seasonData = this.GetSpaceTravelSeasonData(seasonId)
    for k, v in pairs(seasonData.goals) do
        local goalState = this.GetSpaceTravelGoalInfo(seasonId, k)
        if goalState == GoalState.Complete then
            return true
        end
    end

    return false
end

function GameData.GetSpaceTravelGoalInfo(seasonId, goalId)
    local seasonData = this.GetSpaceTravelSeasonData(seasonId)
    if seasonData.goals[goalId] ~= nil then
        local curState = seasonData.goals[goalId].state
        if curState == GoalState.Running then
            local serverNumbers = seasonData.goals[goalId].number
            local conditions = ConfigUtils.GetGoalConditions(goalId)
            local goalTriggers = ConfigUtils.GetGoalTriggers(goalId)
            local numbers = {}
            local state = GoalState.Complete
            for idx = 1, #conditions do
                local needNum = conditions[idx].Num
                local numFromServer = serverNumbers[idx]
                local ownNum = GetSpaceTravelGoalActualNum(seasonId, goalTriggers, conditions[idx], numFromServer)
                numbers[idx] = ownNum
                if ownNum < needNum then
                    state = GoalState.Running
                end
            end
            return state, numbers
        else
            return seasonData.goals[goalId].state, seasonData.goals[goalId].number
        end
    end

    return nil
end

function GameData.DoSpaceTravelGoalSettle(seasonId, triggerType, input)
    local seasonData = this.GetSpaceTravelSeasonData(seasonId)
    for goalId, goalData in pairs(seasonData.goals) do
        if goalData.state == GoalState.Running then
            local triggers = ConfigUtils.GetGoalTriggers(goalId)
            if Helper.TableContains(triggers, triggerType) then
                this.RefreshGoalData(goalId, goalData, input)
            end 
        end
    end
end