
local this = GameData

local _workShopList = {
	-- workShopId001 = exp, 
}

WorkShopState = {
	Lock = "Lock",
	Idle = "Idle",
	Working = "Working",
}

function GameData.InitWorkShopList(data)
	this.SetWorkShopData(data)
end

function GameData.SetWorkShopData(data)
	_workShopList = {}

	local workShopList = data.WorkShopList or {}
	--log("work shop list: "..Helper.Format(workShopList))
	for idx = 1, #workShopList do
		this.SetDataOfWorkShop(workShopList[idx])
	end
end

function GameData.SetDataOfWorkShop(data)
	local workShopId = data.WorkShopId
	local workShopLevel = data.Level
	local workShopBestRank = data.MaxRank or 0
	local lastRefreshTime = data.LastRefreshTime or 0
	local characterList = {}
	local characterMap = {}
	local recordCharacters = data.CharacterList or {}
	for idx = 1, #recordCharacters do
		local characterId = recordCharacters[idx]
		if characterMap[characterId] == nil then
			table.insert(characterList, characterId)
			characterMap[characterId] = 1
		end
	end
	-- production list since last refresh
	local productionList = {}
	Helper.CopyTable(productionList, data.ProductionList or {})
	-- ability map
	local abilities = data.Abilities or {}
	local abilityValue = {}
	for k, v in pairs(abilities) do
		local abilityId = tonumber(k)
		abilityValue[abilityId] = v
	end
	-- max work time
	local maxWorkTime = this.CalculateWorkShopTimeLimit(workShopId, workShopLevel, characterList)
	-- current rank
	local currentRank = ConfigUtils.GetWorkShopRankByAbilityMap(workShopId, workShopLevel, abilityValue)

	_workShopList[workShopId] = {
		level = workShopLevel,
		currentRank = currentRank,
		characters = characterList,
		lastRefreshTime = lastRefreshTime,
		productionList = productionList,
		abilityValue = abilityValue,
		maxWorkTime = maxWorkTime,
		bestRank = workShopBestRank,
	}
end

function GameData.GetWorkShopBestRank(workShopId)
	if not this.IsWorkShopUnlocked(workShopId) then
		return 0
	end

	local data = _workShopList[workShopId]
	return data.bestRank
end

function GameData.GetWorkShopRefreshTime(workShopId)
	if not this.IsWorkShopUnlocked(workShopId) then
		return 0
	end

	local data = _workShopList[workShopId]
	return data.lastRefreshTime or 0
end

function GameData.GetWorkShopMaxWorkTime(workShopId)
	if not this.IsWorkShopUnlocked(workShopId) then
		return 0
	end

	local data = _workShopList[workShopId]
	return data.maxWorkTime or 0
end

function GameData.GetWorkShopList()
	return _workShopList
end

function GameData.GetUnlockedWorkShopList()
	local ret = {}

	for k, v in pairs(_workShopList) do
		table.insert(ret, k)
	end

	return ret
end

function GameData.UnlockWorkShop(workShopId)
	_workShopList[workShopId] = {level = 1}
end

function GameData.IsWorkShopUnlocked(workShopId)
	return _workShopList[workShopId] ~= nil
end

function GameData.GetWorkShopState(workShopId)
	local v = _workShopList[workShopId]
	-- still lock
	if v == nil then
		return WorkShopState.Lock
	end

	local characters = v.characters or {}
	-- if character num is 0, then it is not working
	if #characters == 0 then
		return WorkShopState.Idle
	end

	return WorkShopState.Working
end

function GameData.GetWorkShopLevel(workShopId)
	if _workShopList[workShopId] == nil then
		return 1
	end

	return _workShopList[workShopId].level
end

function GameData.GetCharactersOfWorkShop(workShopId)
	if _workShopList[workShopId] == nil then
		return {}
	end

	return _workShopList[workShopId].characters or {}
end

function GameData.GetDropDataOfWorkShop(workShopId)
	if _workShopList[workShopId] == nil then
		return nil
	end

	local v = _workShopList[workShopId]
	-- character ability map
	local abilityMap = v.abilityValue or {}
	-- production list of rewards
	local productionList = v.productionList or {}
	-- workshop level
	local workShopLevel = v.level
	-- storage time limit
	local timeLimit = v.maxWorkTime or 0
	-- rank
	local productionSpeedList = {}
	if v.currentRank ~= nil then
		local rankList = ConfigUtils.GetWorkShopRankList(workShopId)
		productionSpeedList = rankList[v.currentRank].Production
	end
	-- all rewards
	local rewards = ConfigUtils.GetWorkShopRewards(workShopId)

	local ret = {}

	for idx = 1, #rewards do
		local dropId = rewards[idx].Value
		local unlockLevel = rewards[idx].NeedLevel
		local productionPerCycle = rewards[idx].NeedProduction
		local productionSpeed = 0
		if workShopLevel >= unlockLevel then
			productionSpeed = productionSpeedList[idx] or 0
		end
		-- interval in seconds
		local intervalPerCycle = -1
		if productionSpeed > 0 then
			intervalPerCycle = math.ceil(productionPerCycle / productionSpeed)
		end

		ret[idx] = {
			dropId = dropId,
			unlocked = (workShopLevel >= unlockLevel),
			unlockLevel = unlockLevel,
			productionPerCycle = productionPerCycle,
			productionSpeed = productionSpeed,
			recordProduction = productionList[idx] or 0,
			maxProduction = productionSpeed * timeLimit,
			intervalPerCycle = intervalPerCycle,
		}
	end

	return ret
end

function GameData.HasCompletedWorkShop()
	-- current time
	local currentTime = this.GetServerTime()

	for workShopId, _ in pairs(_workShopList) do
		local lastRefreshTime = this.GetWorkShopRefreshTime(workShopId)
		local timeDiff = math.max(currentTime - lastRefreshTime, 0)

		local rewards = this.GetDropDataOfWorkShop(workShopId) or {}
		for idx = 1, #rewards do
			local v = rewards[idx]
			local currentProduction = v.recordProduction + v.productionSpeed * timeDiff
			local hasDrop = (currentProduction >= v.productionPerCycle)
			if hasDrop and currentProduction >= v.maxProduction then
				return true
			end
		end
	end

	return false
end

function GameData.GetWorkShopNotifyData()
	local notifyWorkShopId = nil
	local notifyEndTime = nil

	-- current time
	local currentTime = this.GetServerTime()

	for workShopId, _ in pairs(_workShopList) do
		local lastRefreshTime = this.GetWorkShopRefreshTime(workShopId)
		local timeDiff = math.max(currentTime - lastRefreshTime, 0)

		local rewards = this.GetDropDataOfWorkShop(workShopId) or {}
		for idx = 1, #rewards do
			local v = rewards[idx]
			if v.productionSpeed > 0 then
				local currentProduction = v.recordProduction + v.productionSpeed * timeDiff
				local maxProduction = v.maxProduction
				if maxProduction > currentProduction then
					local needTime = (maxProduction - currentProduction) / v.productionSpeed
					local thisEndTime = math.ceil(needTime) + currentTime
					if notifyEndTime == nil or thisEndTime < notifyEndTime then
						notifyEndTime = thisEndTime
						notifyWorkShopId = workShopId
					end
				end
			end
		end
	end

	return notifyWorkShopId, notifyEndTime
end

function GameData.CalculateWorkShopTimeLimit(workShopId, level, characters)
	local baseValue = ConfigUtils.GetWorkShopMaxWorkTime(workShopId, level)
	if #characters == 0 then
		return baseValue
	end

	local coupleKey = CoupleNodeKey.WorkShop
	local availableCoupleList = ConfigUtils.GetMatchedCoupleList(coupleKey)
	local acitveCoupleList = {}
	for idx = 1, #availableCoupleList do
		local coupleId = availableCoupleList[idx]
		if GameData.IsCoupleMatched(coupleId, characters) then
			table.insert(acitveCoupleList, coupleId)
		end
	end

	local coupleSkills = {}
	for idx = 1, #acitveCoupleList do
		local coupleId = acitveCoupleList[idx]
		local skillList = ConfigUtils.GetCoupleSkillList(coupleId)
		for m = 1, #skillList do
			local skillId = skillList[m].Id
			local skillValue = skillList[m].Value
			table.insert(coupleSkills, {id = skillId, value = skillValue})
		end
	end

	local skills = GameData.GetGroupSkillMap(characters, nil, {effectAttribute = EffectAttribute.WorkShopMaxWorkTime, globalSkills = coupleSkills})
	local addValue, addPercent = GameData.GetSkillTotalValue(skills)
	local finalPercent = Helper.Round(1 + addPercent, 2)
	local timeLimit = Helper.RoundAndCeil((baseValue + addValue) * finalPercent)
	timeLimit = math.max(1, timeLimit)
	return timeLimit
end

function GameData.RefreshWorkShopList()
	NetManager.Send("WorkShopList", {}, GameData.OnHandleWorkShopList, nil)
end

function GameData.OnHandleWorkShopList(proto, data, requestData)
	if proto == "WorkShopList" then
		this.SetWorkShopData(data)
		GameNotifier.Notify(GameEvent.WorkShopListChanged)
	end
end