require "FreakPlanet/Design/LocalizationConfig"
require "FreakPlanet/Design/LanguageConfig_CN"

LocalizationManager = {}

local this = LocalizationManager
local _selectedLanguage = nil

function LocalizationManager.Init()
	_selectedLanguage = this.CheckLanguage()
end

--临时获取文本,多语言整理后会移除 add by ggyy
function LocalizationManager.Get(key)

	if LocalizationConfig[key] then
		local config = LocalizationConfig[key]
		local languageKey = this.GetCurrentLanguageKey()
		if config[languageKey] == nil then
			return tostring(key).."-"..languageKey
		end
		return config[languageKey]
	end

	if LanguageConfig_CN[key] then
		return LanguageConfig_CN[key]
	end

	XDebug.Error("not found localization key: " .. key)
	return key
end
--[[
function LocalizationManager.Get(key)
	local config = LocalizationConfig[key]

	if config == nil then
		log("not found localization key: "..tostring(key))
		return tostring(key)
	end

	local languageKey = this.GetCurrentLanguageKey()
	if config[languageKey] == nil then
		return tostring(key).."-"..languageKey
	end

	return config[languageKey]
end
--]]
function LocalizationManager.GetCurrentLanguageKey()
	local languageKey = nil
	if _selectedLanguage == Language.CN_HANS then
		languageKey = "zh"
	elseif _selectedLanguage == Language.EN then
		languageKey = "en"
	elseif _selectedLanguage == Language.CN_HANT then
		languageKey = "zht"
	else
		languageKey = "<none>"
	end

	return languageKey
end

function LocalizationManager.CheckGet(key)
	if key == nil then
		return "<NULL>"
	end

	if Helper.StartWith(key, "loc_") then
		return this.Get(key)
	end

	return key
end

function LocalizationManager.SetLanguage(language)
	if _selectedLanguage == language then
		return
	end

	_selectedLanguage = language
	Global.SetLanguage(_selectedLanguage)
	NGUITools.Broadcast("OnLuaLocalize")
end

function LocalizationManager.ToggleLanguage()
	if _selectedLanguage == Language.EN then
		this.SetLanguage(Language.CN_HANS)
	elseif _selectedLanguage == Language.CN_HANS then
		this.SetLanguage(Language.CN_HANT)
	elseif _selectedLanguage == Language.CN_HANT then
		this.SetLanguage(Language.EN)
	end

	return _selectedLanguage
end

function LocalizationManager.DoLocalize(go, key)
	local label = go:GetComponent("UILabel")
	if label ~= nil then
		label.text = this.Get(key)
		return
	end

	local sprite = go:GetComponent("UISprite")
	if sprite ~= nil then
		sprite.spriteName = this.Get(key)
	end
end

function LocalizationManager.CheckLanguage()
	local storedLanguage = Global.GetLanguage()
	if storedLanguage ~= Language.CN_HANS and storedLanguage ~= Language.EN and storedLanguage ~= Language.CN_HANT then
		storedLanguage = ConvertSystemLanguage()
	end

	return storedLanguage
end

