
SBTree = {}
local this = SBTree

--配置构建行为树 ################################################################################
--[[
    config =
    {
        node,
        node,
        config=
        {
        }
    }
--]]
function SBTree.BuildTree(config)
    if not config or #config < 1 then
        return nil
    end
    if #config == 1 then
        return config[1]
    end
    local parent = config[1]
    for i = 2, #config do
        local data = config[i]
        if #data > 0 then
            local node = this.BuildTree(data)
            if node then
                parent:AddNode(node)
            end
        else
            parent:AddNode(data)
        end
    end
    return parent
end