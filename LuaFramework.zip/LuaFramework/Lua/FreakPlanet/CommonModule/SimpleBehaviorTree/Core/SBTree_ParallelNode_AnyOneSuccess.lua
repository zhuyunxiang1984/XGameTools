--平行节点(有一个成功则返回成功) ################################################################################
SBTree_ParallelNode_AnyOneSuccess = class("SBTree_ParallelNode_AnyOneSuccess", SBTree_CompositeNode)

function SBTree_ParallelNode_AnyOneSuccess:EnterImpl()

end
function SBTree_ParallelNode_AnyOneSuccess:ExitImpl()
    for _, node in ipairs(self._Nodes) do
        if node:IsRunning() then
            node:Exit()
        end
    end
end
function SBTree_ParallelNode_AnyOneSuccess:TickImpl(deltaTime)
    if #self._Nodes < 1 then
        return EnumSBTreeNodeExecuteResult.Success
    end
    local allComplete = true
    for _, node in ipairs(self._Nodes) do
        local result = node:Tick(deltaTime)
        if result == EnumSBTreeNodeExecuteResult.Success then
            return EnumSBTreeNodeExecuteResult.Success
        end
        if result == EnumSBTreeNodeExecuteResult.Process then
            allComplete = false
        end
    end
    if allComplete then
        return EnumSBTreeNodeExecuteResult.Failure
    end
    return EnumSBTreeNodeExecuteResult.Process
end