
--顺序节点 ################################################################################
SBTree_SequenceNode = class("SBTree_SequenceNode", SBTree_CompositeNode)

function SBTree_SequenceNode:EnterImpl()
    self._Index = 1
end
function SBTree_SequenceNode:ExitImpl()

end
function SBTree_SequenceNode:TickImpl(deltaTime)
    if self._Index > #self._Nodes then
        return EnumSBTreeNodeExecuteResult.Success
    end
    local node = self._Nodes[self._Index]
    local result = node:Tick(deltaTime)
    if result == EnumSBTreeNodeExecuteResult.Failure then
        return EnumSBTreeNodeExecuteResult.Failure
    end
    if result == EnumSBTreeNodeExecuteResult.Success then
        self._Index = self._Index + 1
    end
    return EnumSBTreeNodeExecuteResult.Process
end