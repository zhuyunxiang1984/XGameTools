--组合节点 ################################################################################
SBTree_CompositeNode = class("SBTree_CompositeNode", SBTree_Node)
local this = SBTree_CompositeNode
function SBTree_CompositeNode:initialize()
    this.super.initialize(self)
    self._Nodes = {}
end
function SBTree_CompositeNode:AddNode(node)
    table.insert(self._Nodes, node)
end