--选择节点 ################################################################################
SBTree_SelectorNode = class("SBTree_SelectorNode", SBTree_CompositeNode)

function SBTree_SelectorNode:EnterImpl()
    self._Index = 1
end
function SBTree_SelectorNode:ExitImpl()

end
function SBTree_SelectorNode:TickImpl(deltaTime)
    if self._Index > #self._Nodes then
        return EnumSBTreeNodeExecuteResult.Failure
    end
    local node = self._Nodes[self._Index]
    local result = node:Tick(deltaTime)
    if result == EnumSBTreeNodeExecuteResult.Success then
        return EnumSBTreeNodeExecuteResult.Success
    end
    if result == EnumSBTreeNodeExecuteResult.Failure then
        self._Index = self._Index + 1
    end
    return EnumSBTreeNodeExecuteResult.Process
end