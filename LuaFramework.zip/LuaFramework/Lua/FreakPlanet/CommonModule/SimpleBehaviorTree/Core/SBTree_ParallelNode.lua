--平行节点(等待全部完成返回成功) ################################################################################
SBTree_ParallelNode = class("SBTree_ParallelNode", SBTree_CompositeNode)

function SBTree_ParallelNode:EnterImpl()

end
function SBTree_ParallelNode:ExitImpl()
    for _, node in ipairs(self._Nodes) do
        if node:IsRunning() then
            node:Exit()
        end
    end
end
function SBTree_ParallelNode:TickImpl(deltaTime)
    if #self._Nodes < 1 then
        return EnumSBTreeNodeExecuteResult.Success
    end
    local allComplete = true
    for _, node in ipairs(self._Nodes) do
        local result = node:Tick(deltaTime)
        if result == EnumSBTreeNodeExecuteResult.Process then
            allComplete = false
        end
    end
    if allComplete then
        return EnumSBTreeNodeExecuteResult.Success
    end
    return EnumSBTreeNodeExecuteResult.Process
end