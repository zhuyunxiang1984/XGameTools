--基础节点 ################################################################################
--[[ 节点模版
SBTree_XXX = class("SBTree_XXX", SBTree_Node)
local this = SBTree_XXX

function SBTree_XXX:initialize()
    this.super.initialize(self)
end

function SBTree_XXX:EnterImpl()
end

function SBTree_XXX:ExitImpl()

end

function SBTree_XXX:TickImpl(deltaTime)
    return EnumSBTreeNodeExecuteResult.Success
end
--]]

EnumSBTreeNodeExecuteResult =
{
    Process = 0,--执行中
    Success = 1,--成功
    Failure = 2,--失败
}

SBTree_Node = class("SBTree_Node")

function SBTree_Node:initialize()
    self._Enter     = false
    self._Completed = false
    self._Result    = EnumSBTreeNodeExecuteResult.Process
end
function SBTree_Node:Enter()
    self:EnterImpl()
end
function SBTree_Node:Exit()
    self:ExitImpl()
    self._Enter = false
end
function SBTree_Node:Tick(deltaTime)
    if not self._Entered then
        --XDebug.Log('GGYY', 'enter node ' .. self:GetName())
        self:Enter()
        self._Entered = true
        self._Completed = false
        self._Result = EnumSBTreeNodeExecuteResult.Process
    end

    if not self._Completed then
        self._Result = self:TickImpl(deltaTime)
        if self._Result ~= EnumSBTreeNodeExecuteResult.Process then
            self:Exit()
            self._Completed = true
            --XDebug.Log('GGYY', 'complete node ' .. self:GetName() .. ' ' .. self._Result)
        end
    end
    return self._Result
end
function SBTree_Node:EnterImpl()

end
function SBTree_Node:ExitImpl()

end
function SBTree_Node:TickImpl(deltaTime)
    return EnumSBTreeNodeExecuteResult.Success
end
function SBTree_Node:IsRunning()
    return self._Entered and not self._Completed
end
function SBTree_Node:GetName()
    return self.class.name
end
function SBTree_Node:ToString()
    return self:GetName()
end