--平行节点(有一个失败则返回失败) ################################################################################
SBTree_ParallelNode_AnyOneFail = class("SBTree_ParallelNode_AnyOneFail", SBTree_CompositeNode)

function SBTree_ParallelNode_AnyOneFail:EnterImpl()

end
function SBTree_ParallelNode_AnyOneFail:ExitImpl()
    for _, node in ipairs(self._Nodes) do
        if node:IsRunning() then
            node:Exit()
        end
    end
end
function SBTree_ParallelNode_AnyOneFail:TickImpl(deltaTime)
    if #self._Nodes < 1 then
        return EnumSBTreeNodeExecuteResult.Success
    end
    local allComplete = true
    for _, node in ipairs(self._Nodes) do
        local result = node:Tick(deltaTime)
        if result == EnumSBTreeNodeExecuteResult.Failure then
            return EnumSBTreeNodeExecuteResult.Failure
        end
        if result == EnumSBTreeNodeExecuteResult.Process then
            allComplete = false
        end
    end
    if allComplete then
        return EnumSBTreeNodeExecuteResult.Success
    end
    return EnumSBTreeNodeExecuteResult.Process
end