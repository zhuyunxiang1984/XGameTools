--等待时间
SBTree_TimeNode = class("SBTree_TimeNode", SBTree_Node)
function SBTree_TimeNode:initialize(time)
    SBTree_TimeNode.super.initialize(self)
    self._Time = time
end
function SBTree_TimeNode:EnterImpl()
    self._TimeCounter = 0
end
function SBTree_TimeNode:ExitImpl()

end
function SBTree_TimeNode:TickImpl(deltaTime)
    if self._TimeCounter < self._Time then
        self._TimeCounter = self._TimeCounter + deltaTime
    end
    if self._TimeCounter >= self._Time then
        return EnumSBTreeNodeExecuteResult.Success
    end
    return EnumSBTreeNodeExecuteResult.Process
end