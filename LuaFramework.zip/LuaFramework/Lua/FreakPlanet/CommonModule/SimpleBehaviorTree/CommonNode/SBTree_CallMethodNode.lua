--执行函数
SBTree_CallMethodNode = class("SBTree_CallMethod", SBTree_Node)
function SBTree_CallMethodNode:initialize(method)
    self.class.super.initialize(self)
    self._Method = method
end
function SBTree_CallMethodNode:EnterImpl()
end
function SBTree_CallMethodNode:ExitImpl()

end
function SBTree_CallMethodNode:TickImpl(deltaTime)
    local result = nil
    if self._Method then
        result = self._Method()
    end
    if result and result == false then
        return EnumSBTreeNodeExecuteResult.Failure
    end
    return EnumSBTreeNodeExecuteResult.Success
end