require "FreakPlanet/Utils/Serializer"

GameSave = {}

local _saveDataFile = UnityEngine.Application.persistentDataPath.."/planet.dat"

-- save game data
function GameSave.Save(obj)
	local data = Serialize(obj)

	-- encode
	local encodedData = data 
	if not AppConst.DebugMode then
		encodedData = DataDecode.EncryptWithKey(data, ScriptBridge.EntryG)
	end

	local file = io.open(_saveDataFile, "wb")
	file:write(encodedData)
	file:close()

	XDebug.Log("GGYY", "game data saved OK.... " .. _saveDataFile)
end

-- load saved game data
function GameSave.Load()
	local file = io.open(_saveDataFile, "rb")
	-- not exist
	if file == nil then
		log("game data is empty....")
		return nil
	end

	local data = file:read("*all")
	file:close()
    XDebug.Log("GGYY", "game data loaded OK.... " .. _saveDataFile)
	-- decode
	local decodedData = data
	if not AppConst.DebugMode then
		decodedData = DataDecode.DecryptWithKey(data, ScriptBridge.EntryG)
	end

	local obj = Deserialize(decodedData)
	return obj
end