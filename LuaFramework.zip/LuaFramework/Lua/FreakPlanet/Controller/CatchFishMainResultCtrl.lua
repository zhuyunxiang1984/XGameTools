require "FreakPlanet/View/CatchFishMainResultPanel"

local class = require "FreakPlanet/Utils/middleclass"
CatchFishMainResultCtrl  = class(CtrlNames.CatchFishMainResult, BaseCtrl)

-- load the ui prefab
function CatchFishMainResultCtrl:LoadPanel()
	self:CreatePanel("CatchFishMainResult")
end

local MAX_FISH_COUNT = 3

-- construct ui panel data
function CatchFishMainResultCtrl:ConstructUI(obj)
	self._ui = CatchFishMainResultPanel.Init(obj)
end

-- fill ui with the data
--[[
参数 = {
	StageId
	IsSuccess
	IsChallenge
	Score
	Stars
}
--]]
function CatchFishMainResultCtrl:SetupUI()
	local ui = self._ui
	local data = self._parameter
	self._leftContentPivot = ui.FishScrollView.contentPivot
	self._centerContentPivot = ui.EmptyScrollView.contentPivot
	if data.IsChallenge then
		SoundSystem.PlaySoundOfName(SoundNames.BattleWin)
		GameDataCatchFish.SetChallengeRank(data.ChallengeRank)
		ui.SuccessObj:SetActive(true)
		ui.FailureObj:SetActive(false)
		ui.RankLayout:SetActive(true)
		ui.Title.text = "挑战成功"

		ui.txtRank.text = tostring(GameDataCatchFish.GetCurChallengeRank())

		ui.ChallengeExchangeObj:SetActive(true)
		ui.NormalAwardObj:SetActive(false)
		ui.btnNext:SetActive(false)
		ui.ButtonRoot:Reposition()

		ui.ScoreTxt.text = string.format("本关得分%d", data.Score)
		ui.HistoryScore:SetActive(true)
		ui.HistoryScoreTxt.text = string.format("历史最高%d", data.ChallengeScore)
		ui.ScoreRoot:Reposition()

		ui.SubTitle.text = string.format("捞金鱼得分%d",(data.Score - data.EnergyScore))

		ui.StarLayout.gameObject:SetActive(false)
		ui.ChallengeExchangeScoreTxt.text = tostring(data.EnergyScore)
	else
		GameDataCatchFish.SetCatchFishLevelData(data.StageId, data.Score, data.Stars)
		ui.Title.text = SAFE_LOC("闯关成功")
		ui.SuccessObj:SetActive(data.IsSuccess)
		ui.FailureObj:SetActive(not data.IsSuccess)
		ui.RankLayout:SetActive(false)
		ui.ChallengeExchangeObj:SetActive(false)
		ui.StarLayout.gameObject:SetActive(true)

		for idx = 1, #ui.Stars do
			if idx <= data.Stars then
				ui.Stars[idx].bright:SetActive(true)
				ui.Stars[idx].gray:SetActive(false)
			else
				ui.Stars[idx].bright:SetActive(false)
				ui.Stars[idx].gray:SetActive(true)
			end
		end

		if data.IsSuccess then
			SoundSystem.PlaySoundOfName(SoundNames.BattleWin)
			ui.NormalAwardObj:SetActive(true)
			local rewardList = data.RewardList
			for idx = 1, #rewardList do
				local item = Helper.NewObject(ui.RewardTemplate, ui.NormalAwardRoot)
				item:SetActive(true)
				item.name = rewardList[idx].ItemId
				UIHelper.ConstructItemIconAndNum(self, item.transform, rewardList[idx].ItemId, rewardList[idx].Num)
				GameData.CollectItem(rewardList[idx].ItemId, rewardList[idx].Num, false)
			end
			ui.NormalAwardRoot:GetComponent("UITable"):Reposition()
			ui.btnNext:SetActive(data.StageId < GameDataCatchFish.GetLastCatchFishLevelId())
		else
			SoundSystem.PlaySoundOfName(SoundNames.BattleLose)
			ui.NormalAwardObj:SetActive(false)
			ui.btnNext:SetActive(false)
		end

		ui.ButtonRoot:Reposition()
		ui.ScoreTxt.text = string.format("本关得分%d", data.Score)
		ui.HistoryScore:SetActive(false)
		ui.ScoreRoot:Reposition()

		ui.SubTitle.text = SAFE_LOC("金鱼展示")

	end
	local fishInfo = GameDataCatchFish.GetCatchedFishTypeOfFishPool()
	for idx = 1, #fishInfo do
		local fishItem = Helper.NewObject(ui.FishItemTemplate, ui.FishUIGrid.transform)
		fishItem:SetActive(true)
		local icon = fishItem.transform:Find("Icons"):GetComponent("UISprite")
		local numTxt = fishItem.transform:Find("Num"):GetComponent("UILabel")
		icon.spriteName = ConfigUtils.GetCatchFishIcon(fishInfo[idx].Id)
		numTxt.text = "x"..tostring(fishInfo[idx].Num)
	end
	-- 为了间接获得UIWidget.Pivot.Center的值,我们在Prefab里新建了一个空的且contentPivot为Center的UIScrollView 2021/08/04 @lz
	ui.FishScrollView.contentPivot = #fishInfo <= MAX_FISH_COUNT and self._centerContentPivot or self._leftContentPivot
	ui.FishScrollView.disableDragIfFits = (#fishInfo <= MAX_FISH_COUNT)
	ui.FishUIGrid:Reposition()
	ui.FishScrollView:ResetPosition()

	CtrlManager.AddClick(self, ui.Blocker)
	CtrlManager.AddClick(self, ui.btnMap)
	CtrlManager.AddClick(self, ui.btnRetry)
	CtrlManager.AddClick(self, ui.btnNext)
	CtrlManager.AddClick(self, ui.RankLayout)
end

-- handle the escape button
function CatchFishMainResultCtrl:HandleEscape()
	self:OnClicked(self._ui.Blocker)
end

-- on clicked
function CatchFishMainResultCtrl:OnClicked(go)
	local ui = self._ui
	local data = self._parameter
	if go == ui.Blocker then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanelByName(CtrlNames.CatchFishMain)
		self:Close()
	elseif go == ui.btnMap then
		SoundSystem.PlayUIClickSound()
		XDebug.Log('GGYY', "click btnMap")
		CtrlManager.PopPanelByName(CtrlNames.CatchFishMain)
		self:Close()
	elseif go == ui.btnRetry then
		SoundSystem.PlayUIClickSound()
		XDebug.Log('GGYY', "click btnRetry")
		CtrlManager.PopPanelByName(CtrlNames.CatchFishMain)
		self:Close()
		CtrlManager.OpenPanel(CtrlNames.CatchFishStageDetail, { fishPoolId = data.StageId })
	elseif go == ui.btnNext then
		SoundSystem.PlayUIClickSound()
		XDebug.Log('GGYY', "click btnNext")
		CtrlManager.PopPanelByName(CtrlNames.CatchFishMain)
		self:Close()
		CtrlManager.OpenPanel(CtrlNames.CatchFishStageDetail, { fishPoolId = (data.StageId + 1) })
	elseif go == ui.RankLayout then
		SoundSystem.PlayUIClickSound()
		CtrlManager.OpenPanel(CtrlNames.CatchFishRank)
	end
	return true
end
