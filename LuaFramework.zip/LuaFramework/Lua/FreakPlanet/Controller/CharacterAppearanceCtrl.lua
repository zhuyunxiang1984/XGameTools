require "FreakPlanet/View/CharacterAppearancePanel"

local class = require "FreakPlanet/Utils/middleclass"
CharacterAppearanceCtrl  = class(CtrlNames.CharacterAppearance, BaseCtrl)

local MAX_COUNT_PER_ROW = 4

-- load the ui prefab
function CharacterAppearanceCtrl:LoadPanel()
	self:CreatePanel("CharacterAppearance")
end

-- construct ui panel data
function CharacterAppearanceCtrl:ConstructUI(obj)
	self._ui = CharacterAppearancePanel.Init(obj)
end

-- fill ui with the data
function CharacterAppearanceCtrl:SetupUI()
	self.CharacterId = self._parameter.CharacterId

	self.Select = -1 --当前选择的外观(皮肤id)
	self.Item2Id = {} --obj:外观 映射表
	self.Id2Item = {} --外观:obj 映射表

	local ui = self._ui
	self:InitAppearanceList()
	self:InitAvatar(self.CharacterId)

	CtrlManager.AddClick(self, ui.Blocker)
	CtrlManager.AddClick(self, ui.btnDressUp)
	CtrlManager.AddClick(self, ui.btnDressDown)
end

-- on clicked
function CharacterAppearanceCtrl:OnClicked(go)
	local ui = self._ui
	if go == ui.Blocker then
		self:Close()
	elseif go == ui.btnDressUp then
		if self.Select < 1 then
			return
		end
		self:DressUp(self.Select)
	elseif go == ui.btnDressDown then
		self:DressDown()
	else
		if self.Item2Id[go] then
			self:SelectAppearance(self.Item2Id[go])
		end
	end
	return true
end

--
function CharacterAppearanceCtrl:DressUp(appearanceId)
	XDebug.Log('GGYY', "穿上外观 " .. appearanceId)
	local costId, costNum = ConfigUtils.GetSkinAppearanceCost(appearanceId)
	if costId > 0 and GameData.GetItemNum(costId) < costNum then
		CtrlManager.ShowMessageBox({message = string.format(LANGUAGE("hideseek_hint_noenoughcost"), ConfigUtils.GetItemName(costId)), single = true})
		return
	end
	ProtocolManager.RequestSetAppearance(self.CharacterId, appearanceId)
	self:Close()
end

--
function CharacterAppearanceCtrl:DressDown()
	XDebug.Log('GGYY', "脱下外观 ")
	ProtocolManager.RequestSetAppearance(self.CharacterId, 0)
	self:Close()
end

--
function CharacterAppearanceCtrl:InitAppearanceList()
	local ui = self._ui
	ui.ObjPool:RecycleAllObj()

	self.AppearanceList = GameData.GetAvailableAppearances(self.CharacterId)

	self.ItemTypes = {}
	self.ItemObj2Data = {}
	ui.ScrollView:SetCallback(self, CharacterAppearanceCtrl.OnCreateRow, CharacterAppearanceCtrl.OnUpdateRow)
	ui.ScrollView:InitScrollView(math.ceil(#self.AppearanceList / MAX_COUNT_PER_ROW))
end

--
function CharacterAppearanceCtrl:OnCreateRow()
	local ui = self._ui
	return ui.ObjPool:GetOrCreateObj(ui.EnumPrefabType.Row)
end
--
function CharacterAppearanceCtrl:OnUpdateRow(rowObj, rowIndex, dataIndex)
	local ui = self._ui

	for i = 1, MAX_COUNT_PER_ROW do
		local node = rowObj.transform:Find("Slot"..i)
		local index = (dataIndex - 1) * MAX_COUNT_PER_ROW + i
		local appearanceId = self.AppearanceList[index] or -1
		if appearanceId > 0 then
			local obj = self:UpdateAppearanceObj(node, ui.EnumPrefabType.Appearance)
			self:UpdateAppearanceItem(obj, appearanceId)
		else
			self:UpdateAppearanceObj(node, 0)
		end
	end
end
--
function CharacterAppearanceCtrl:UpdateAppearanceObj(node, type)
	local ui = self._ui
	local item = nil
	if node.childCount > 0 then
		item = node:GetChild(0)
		if self.ItemTypes[item] == type then
			return item
		end
		ui.ObjPool:RecycleObj(item.gameObject)
	end
	if type == 0 then
		return nil
	end
	item = ui.ObjPool:GetOrCreateObj(type, function(newObj)
		self.ItemTypes[newObj] = type
		CtrlManager.AddClick(self, newObj)
	end)
	local trans = item.transform
	trans:SetParent(node)
	trans.localScale = Vector3.New(1, 1, 1)
	trans.localPosition = Vector3.zero
	trans.localRotation = Vector3.zero
	return item
end

--
function CharacterAppearanceCtrl:UpdateAppearanceItem(obj, appearanceId)
	self.Item2Id[obj] = appearanceId
	self.Id2Item[appearanceId] = obj

	local ui = self._ui
	local view = ui.ViewManager:GetView(obj, ui.EnumPrefabType.Appearance)
	view.BG.spriteName = UIHelper.GetBorderAndBgByItemId(appearanceId)
	view.txtName.text = ConfigUtils.GetSkinName(appearanceId)
	UIHelper.SetItemIcon(self, view.imgIcon, appearanceId)
	view.Addressed:SetActive(appearanceId == GameData.GetCharacterAppearance(self.CharacterId))
	view.Select:SetActive(appearanceId == self.Select)
end
--
function CharacterAppearanceCtrl:UpdateAppearanceItemSelectState(obj, appearanceId)
	local ui = self._ui
	local view = ui.ViewManager:GetView(obj, ui.EnumPrefabType.Appearance)
	view.Select:SetActive(appearanceId == self.Select)
end

--
function CharacterAppearanceCtrl:InitAvatar(characterId)
	local ui = self._ui

	local prefabName, prefabBundle = ConfigUtils.GetCharacterPrefab(characterId)
	local prefab = self:DynamicLoadAsset(prefabBundle, prefabName)
	local itemObj = Helper.NewObject(prefab, ui.AvatarRoot, 50)

	self.CharacterObj = itemObj
	self.CharacterAnimation = itemObj:GetComponent('SkeletonAnimation')
	self.CharacterAnimationRenderer = self.CharacterAnimation:GetComponent("Renderer");
	self.CharacterAnimationRenderer.sortingOrder = 6;

	self.CharacterObjInMirror = Helper.NewObject(prefab, ui.AvatarRootInMirror, 50)
	self.CharacterAnimationInMirror = self.CharacterObjInMirror:GetComponent('SkeletonAnimation')
	self.CharacterAnimationInMirrorRenderer = self.CharacterObjInMirror:GetComponent("Renderer");
	self.CharacterAnimationInMirrorRenderer.sortingOrder = -1;

	UIHelper.SetCharacterSkin(self.CharacterAnimation, characterId)
	UIHelper.SetCharacterSkin(self.CharacterAnimationInMirror, characterId)
	Helper.PlayAnimation(self.CharacterAnimation, CharacterAnimations.Idle, true)
	Helper.PlayAnimation(self.CharacterAnimationInMirror, CharacterAnimations.Idle, true)

	local appearanceId = GameData.GetCharacterAppearance(characterId)
	if appearanceId > 0 then
		self:SelectAppearance(appearanceId)
	end
	self:UpdateUI()
end

--
function CharacterAppearanceCtrl:SelectAppearance(appearanceId)
	local ui = self._ui

	local src = self.Select
	local dst = appearanceId
	if src == dst then
		return
	end
	self.Select = dst

	if src > 0 and self.Id2Item[src] then
		self:UpdateAppearanceItemSelectState(self.Id2Item[src], src)
	end
	if dst > 0 and self.Id2Item[dst] then
		self:UpdateAppearanceItemSelectState(self.Id2Item[dst], dst)
	end

	self:UpdateUI()
end

--
function CharacterAppearanceCtrl:UpdateUI()
	local ui = self._ui
	--
	if self.Select > 0 then
		UIHelper.SetCharacterSkinWithSkin(self.CharacterAnimation, self.Select)
		UIHelper.SetCharacterSkinWithSkin(self.CharacterAnimationInMirror, self.Select)
	end

	--
	if self.Select > 0 then
		if GameData.GetCharacterAppearance(self.CharacterId) == self.Select then
			ui.btnDressUp:SetActive(false)
			ui.btnDressDown:SetActive(true)
		else
			ui.btnDressUp:SetActive(true)
			ui.btnDressDown:SetActive(false)

			local costId, costNum = ConfigUtils.GetSkinAppearanceCost(self.Select)
			if costId > 0 then
				ui.txtCostText1.gameObject:SetActive(true)
				ui.txtCostText2.gameObject:SetActive(true)
				ui.imgCostIcon.gameObject:SetActive(true)

				ui.txtCostText1.text = string.format(LANGUAGE("hideseek_button_text1"), costNum)
				ui.txtCostText2.text = LANGUAGE("hideseek_button_text2")
				UIHelper.SetItemIcon(self, ui.imgCostIcon, costId)
			else
				ui.txtCostText1.gameObject:SetActive(false)
				ui.txtCostText2.gameObject:SetActive(true)
				ui.imgCostIcon.gameObject:SetActive(false)

				ui.txtCostText2.text = LANGUAGE("hideseek_button_text2")
			end
			ui.dressUpLayout:Reposition()
		end
	else
		ui.btnDressUp:SetActive(false)
		ui.btnDressDown:SetActive(false)
	end

end