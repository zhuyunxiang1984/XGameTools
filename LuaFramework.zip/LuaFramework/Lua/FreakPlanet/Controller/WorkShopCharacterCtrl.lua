require "FreakPlanet/View/WorkShopCharacterPanel"
require "FreakPlanet/Controller/CharacterSelectBaseCtrl"

local class = require "FreakPlanet/Utils/middleclass"
WorkShopCharacterCtrl  = class(CtrlNames.WorkShopCharacter, CharacterSelectBaseCtrl)

local POSITION_MOVE_DURATION = 0.5
local PROGRESS_MOVE_DURATION = 0.7

local RANK_NOT_MATCH_COLOR = Color.New(107 / 255, 68 / 255, 57 / 255, 1)
local RANK_MATCH_COLOR = Color.New(1, 149 / 255, 0, 1)

local _sortAbilityList = nil
----------------------------------------------------------------
local function CharacterSortFunc(idA, idB)
	if idA == nil or idB == nil then
		return false
	end

	if GameData.IsGoalRunning(TutorialConstData.WorkShopGoal) then
		local goalNeedA = (idA == TutorialConstData.JuminId)
		local goalNeedB = (idB == TutorialConstData.JuminId)
		if goalNeedA ~= goalNeedB then
			return goalNeedA
		end
	end

	local markedA = GameData.IsItemMarked(idA)
	local markedB = GameData.IsItemMarked(idB)
	if markedA ~= markedB then
		return markedA
	end

	local selectableMap = CharacterSelectBaseCtrl.GetCharacterSelectableMap()
	if selectableMap ~= nil then
		local selectableA = selectableMap[idA]
		local selectableB = selectableMap[idB]

		if selectableA ~= selectableB then
			return selectableA
		end
	end

	local valueA = 0
    local valueB = 0

    local sortAbilityId = CharacterSelectBaseCtrl.GetSortValue()
	if sortAbilityId ~= nil then
        valueA = CharacterSelectBaseCtrl.GetAbilityValueOfCharacter(idA, sortAbilityId)
        valueB = CharacterSelectBaseCtrl.GetAbilityValueOfCharacter(idB, sortAbilityId)
    else
    	valueA = CharacterSelectBaseCtrl.GetAbilitySumOfCharacter(idA, _sortAbilityList)
    	valueB = CharacterSelectBaseCtrl.GetAbilitySumOfCharacter(idB, _sortAbilityList)
    end

    if valueA == valueB then
		valueA = GameData.GetCharacterLevel(idA)
		valueB = GameData.GetCharacterLevel(idB)
	end

	if valueA == valueB then
		valueA = ConfigUtils.GetCharacterRarity(idA)
		valueB = ConfigUtils.GetCharacterRarity(idB)
	end

	if valueA == valueB then
		valueA = ConfigUtils.GetCharacterSortId(idA)
		valueB = ConfigUtils.GetCharacterSortId(idB)
	end

	return valueA > valueB
end
----------------------------------------------------------------
-- load the ui prefab
function WorkShopCharacterCtrl:LoadPanel()
	self:CreatePanel("WorkShopCharacter")
end

-- construct ui panel data
function WorkShopCharacterCtrl:ConstructUI(obj)
	self._ui = WorkShopCharacterPanel.Init(obj)
end

-- destroy implementation
function WorkShopCharacterCtrl:DestroyImpl()
	GameNotifier.RemoveListener(GameEvent.WorkShopLevelChanged, WorkShopCharacterCtrl.OnWorkShopLevelChanged, self)
	GameNotifier.RemoveListener(GameEvent.CharacterSkinChanged, WorkShopCharacterCtrl.OnCharacterSkinChanged, self)
    GameNotifier.RemoveListener(GameEvent.CharacterStageChanged, WorkShopCharacterCtrl.OnCharacterStageChanged, self)
    GameNotifier.RemoveListener(GameEvent.CharacterLevelChanged, WorkShopCharacterCtrl.OnCharacterLevelChanged, self)
    GameNotifier.RemoveListener(GameEvent.CharacterEquipmentUpgraded, WorkShopCharacterCtrl.OnCharacterEquipmentUpgraded, self)
    GameNotifier.RemoveListener(GameEvent.MarkStateChanged, WorkShopCharacterCtrl.OnMarkStateChanged, self)
end

-- fill ui with the data
function WorkShopCharacterCtrl:SetupUI()
	self._workShopId = self._parameter.workShopId
	self._workShopLevel = GameData.GetWorkShopLevel(self._workShopId)
	self._ui.ItemGridWrap.OnItemUpdate = WorkShopCharacterCtrl.OnItemUpdateGlobal
	self._characterSelectMode = CharacterSelectMode.WorkShop
	_sortAbilityList = ConfigUtils.GetWorkShopNeedAbilityList(self._workShopId)
	-- rank data
	local rankList = ConfigUtils.GetWorkShopRankList(self._workShopId)
	self._maxRank = #rankList
	self._topRank = ConfigUtils.GetWorkShopTopRank(self._workShopId, self._workShopLevel)
	-- 段数 = 个数 - 1
	self._rankElementCount = #rankList - 1
	self._rankElementWidth = self._ui.WorkShopAbilities[1].rankBar.width / self._rankElementCount
	-- require sort ability list
	self:SetupNeedAbilities()
	-- share data
	local numLimit = ConfigUtils.GetWorkShopNumCapacity(self._workShopId, self._workShopLevel)
	self:InitializeShared(numLimit, CharacterSortFunc, nil)
	-- record the original characters
	-- must be initialized before call OnSelectionModeChanged
	self:RecordOriginalCharacters()
	self:OnSelectionModeChanged()
	self:OnSelectedCharacterChanged(false)
	self:RefreshUpgradeButtonState()
	self:RefreshSortState()

	-- bg
	self._ui.WorkShopBG.spriteName = ConfigUtils.GetWorkShopBG(self._workShopId)
	self._ui.WorkShopMan.spriteName = ConfigUtils.GetWorkShopBossIcon(self._workShopId)

	CtrlManager.AddClick(self, self._ui.ButtonCharacter.gameObject)
    CtrlManager.AddClick(self, self._ui.ButtonTeam.gameObject)
    CtrlManager.AddClick(self, self._ui.ButtonCouple.gameObject)

	-- team button default states
    self._ui.ButtonTeamSort:SetActive(false)
    self._ui.ButtonTeamSortConfirm:SetActive(false)
    self._ui.ButtonTeamDelete:SetActive(false)
    self._ui.ButtonTeamDeleteConfirm:SetActive(false)

	CtrlManager.AddClick(self, self._ui.ButtonGo.gameObject)
	CtrlManager.AddClick(self, self._ui.ButtonClose)
	CtrlManager.AddClick(self, self._ui.ButtonUpgrade)
	CtrlManager.AddClick(self, self._ui.ButtonFilter)

	-- team
    CtrlManager.AddClick(self, self._ui.ButtonTeamSort)
    CtrlManager.AddClick(self, self._ui.ButtonTeamSortConfirm)
    CtrlManager.AddClick(self, self._ui.ButtonTeamDelete)
    CtrlManager.AddClick(self, self._ui.ButtonTeamDeleteConfirm)

	GameNotifier.AddListener(GameEvent.WorkShopLevelChanged, WorkShopCharacterCtrl.OnWorkShopLevelChanged, self)
	GameNotifier.AddListener(GameEvent.CharacterSkinChanged, WorkShopCharacterCtrl.OnCharacterSkinChanged, self)
    GameNotifier.AddListener(GameEvent.CharacterStageChanged, WorkShopCharacterCtrl.OnCharacterStageChanged, self)
    GameNotifier.AddListener(GameEvent.CharacterLevelChanged, WorkShopCharacterCtrl.OnCharacterLevelChanged, self)
    GameNotifier.AddListener(GameEvent.CharacterEquipmentUpgraded, WorkShopCharacterCtrl.OnCharacterEquipmentUpgraded, self)
    GameNotifier.AddListener(GameEvent.MarkStateChanged, WorkShopCharacterCtrl.OnMarkStateChanged, self)

    self:CheckTutorial()
end

function WorkShopCharacterCtrl:SetupNeedAbilities()
	local rankList = ConfigUtils.GetWorkShopRankList(self._workShopId)

	for idx = 1, #self._ui.WorkShopAbilities do
		local abilityId = _sortAbilityList[idx]
		self._ui.WorkShopAbilities[idx].name.text = ConfigUtils.GetAbilityName(abilityId)
		self._ui.WorkShopAbilities[idx].icon.spriteName = ConfigUtils.GetAbilityIcon(abilityId)

		local elementRoot = self._ui.WorkShopAbilities[idx].rankElementRoot
		for m = 1, self._rankElementCount do
			local elementObj = Helper.NewObject(self._ui.AbilityRankElementTemplate, elementRoot)
			elementObj.name = tostring(m)
			elementObj:SetActive(true)
			-- the target value of this rank equals to the next rank value
			local nextRank = m + 1
			local rankInfo = rankList[nextRank]

			local elementTitle = elementObj.transform:Find("Right/Title"):GetComponent("UILabel")
			elementTitle.text = rankInfo.RankText

			local elementValue = elementObj.transform:Find("Right/Value"):GetComponent("UILabel")
			elementValue.text = tostring(rankInfo.NeedAttribute[idx].Num)

			local elementRightMark = elementObj.transform:Find("Right")
			local pos = elementRightMark.localPosition
			pos.x = self._rankElementWidth
			elementRightMark.localPosition = pos

			pos = elementObj.transform.localPosition
			pos.x = (m - 1) * self._rankElementWidth
			elementObj.transform.localPosition = pos
		end

		CtrlManager.AddClick(self, self._ui.WorkShopAbilities[idx].item)
	end
end

function WorkShopCharacterCtrl:GetInitialCharacters()
	local characters = GameData.GetCharactersOfWorkShop(self._workShopId) or {}
	return characters
end

function WorkShopCharacterCtrl:GetItemPrefabAndPool()
	return self._ui.CharacterItemTemplate, self._ui.CharacterItemPool
end

function WorkShopCharacterCtrl:RefreshSortState()
	local sortAbilityId = CharacterSelectBaseCtrl.GetSortValue()
	for idx = 1, #self._ui.WorkShopAbilities do
		local hasAbility = (idx <= #_sortAbilityList)
		if hasAbility and _sortAbilityList[idx] == sortAbilityId then
			self._ui.WorkShopAbilities[idx].selected:SetActive(true)
		else
			self._ui.WorkShopAbilities[idx].selected:SetActive(false)
		end
	end
end

function WorkShopCharacterCtrl:ConstructCharacterItem(item, itemId)
	local abilityList = _sortAbilityList
	local sortAbilityId = CharacterSelectBaseCtrl.GetSortValue()
	if sortAbilityId ~= nil then
		abilityList = {sortAbilityId}
	end
	local abilityMap = CharacterSelectBaseCtrl.GetAbilityMapOfCharacter(itemId)
	UIHelper.ConstructWorkShopCharacterItem(self, item, itemId, abilityMap, abilityList)
	local selected = self:IsCharacterSelected(itemId)
	self:RefreshGridItemSelectedState(itemId, selected)
	self:RefreshCharacterStatus(item, itemId)
    -- marked
    local marked = GameData.IsItemMarked(itemId)
    local markedMark = item:Find("Mark/Marked").gameObject
    markedMark:SetActive(marked)
end

function WorkShopCharacterCtrl:CanSelectCharacter(itemId)
	local selected = self:IsCharacterSelected(itemId)
	local originalSelected = self:IsOriginalSelected(itemId)
	if not selected and not originalSelected then
		local selectableCharacterMap = self:GetCharacterSelectableMap()
		if not selectableCharacterMap[itemId] then
			return false, SelectionFailReason.BreakRule
		end

		local isBusy, characterStatus = GameData.IsBusyCharacter(itemId, self._characterSelectMode)
		if isBusy then
			if characterStatus == CharacterSelectMode.Explore then
				return false, SelectionFailReason.ExploreMember
			elseif characterStatus == CharacterSelectMode.ActivityExplore then
				return false, SelectionFailReason.ActivityExploreMember
			elseif characterStatus == CharacterSelectMode.WorkShop then
				return false, SelectionFailReason.WorkShopMember
			else
				assert(false, "un-handled busy character status")
			end
		end
	end

	return true
end

function WorkShopCharacterCtrl:UpdateImpl(deltaTime)
	WorkShopCharacterCtrl.super.UpdateImpl(self, deltaTime)

	if self._rankPosition ~= nil and self._rankPosition.dirty then
		for k, v in pairs(self._ui.WorkShopAbilities) do
			local rankRoot = v.rankRoot
			local pos = rankRoot.localPosition
			local speed = self._rankPosition.speed
			local finished, newX = self:DoLerp(self._rankPosition.target, pos.x, speed, deltaTime)
			pos.x = newX
			rankRoot.localPosition = pos
			self._rankPosition.dirty = not finished
		end
	end

	if self._rankAbilityValues ~= nil then
		local allFinalFinished = true

		for idx = 1, #self._rankAbilityValues do
			if self._rankAbilityValues[idx].finalDirty then
				local currentFinal = self._rankAbilityValues[idx].currentFinal
				local targetFinal = self._rankAbilityValues[idx].targetFinal
				local speed = self._rankAbilityValues[idx].finalSpeed
				local finalFinished, newFinal = self:DoLerp(targetFinal, currentFinal, speed, deltaTime)
				self._rankAbilityValues[idx].currentFinal = newFinal
				self._ui.WorkShopAbilities[idx].rankBar.fillAmount = newFinal
				self._rankAbilityValues[idx].finalDirty = not finalFinished
			end

			if self._rankAbilityValues[idx].realDirty then
				local currentReal = self._rankAbilityValues[idx].currentReal
				local targetReal = self._rankAbilityValues[idx].targetReal
				local speed = self._rankAbilityValues[idx].realSpeed
				local realFinished, newReal = self:DoLerp(targetReal, currentReal, speed, deltaTime)
				self._rankAbilityValues[idx].currentReal = newReal
				self._ui.WorkShopAbilities[idx].hintBar.fillAmount = newReal
				self._rankAbilityValues[idx].realDirty = not realFinished
			end

			if self._rankAbilityValues[idx].finalDirty then
				allFinalFinished = false
			end
		end

		if allFinalFinished and self._lastRank ~= self._currentRank then
			self:RefreshRankLevel(true)
			self:RefreshRankElementStatus()
		end
	end
end

function WorkShopCharacterCtrl:DoLerp(targetValue, currentValue, speed, deltaTime)	
	local diff = (targetValue - currentValue)
	local sign = Helper.GetSign(diff)
	if sign == 0 then
		return true, currentValue
	end

	local finished = false
	local newValue = sign * speed * deltaTime + currentValue
	if sign > 0 and newValue > targetValue then
		newValue = targetValue
		finished = true
	end 

	if sign < 0 and newValue < targetValue then
		newValue = targetValue
		finished = true
	end

	return finished, newValue
end

function WorkShopCharacterCtrl:RefreshCharacterAbilities()
	local globalBuffList = self:GetArenaAndCoupleSkills()
	local selectedCharacters = self:GetSelectedCharacterList()
	local characterAbilityMaps = GameData.GetGroupAbilityMap(selectedCharacters, nil, globalBuffList)

	self._totalAbilityMap = {}
	for _, abilityMap in pairs(characterAbilityMaps) do
		for abilityId, abilityValue in pairs(abilityMap) do
			local preValue = self._totalAbilityMap[abilityId] or 0
			self._totalAbilityMap[abilityId] = preValue + abilityValue
		end
	end

	local isFirstEnter = (self._rankAbilityValues == nil)

	if self._rankAbilityValues == nil then
		self._rankAbilityValues = {}
	end

	if self._rankPosition == nil then
		self._rankPosition = {}
	end

	self._currentRank = ConfigUtils.GetWorkShopRankByAbilityMap(self._workShopId, self._workShopLevel, self._totalAbilityMap)
	local startRankToShow = self:GetStartRankToShow()
	local targetPosition = self._ui.RankOriginPosition - (startRankToShow - 1) * self._rankElementWidth

	for idx = 1, #self._ui.WorkShopAbilities do
		local abilityId = _sortAbilityList[idx]
		local abilityValue = self._totalAbilityMap[abilityId] or 0
		self._ui.WorkShopAbilities[idx].currentValue.text = tostring(abilityValue)
		local finalPercent, realPercent = self:GetShowProgressOfAbility(idx, abilityValue)

		local rankRoot = self._ui.WorkShopAbilities[idx].rankRoot
		local rankRootPos = rankRoot.localPosition

		-- move target
		if isFirstEnter then
			rankRootPos.x = targetPosition
			rankRoot.localPosition = rankRootPos

			self._ui.WorkShopAbilities[idx].rankBar.fillAmount = finalPercent
			self._ui.WorkShopAbilities[idx].hintBar.fillAmount = realPercent
			self._rankAbilityValues[idx] = {
				currentFinal = finalPercent,
				targetFinal = finalPercent,
				finalDirty = false,
				currentReal = realPercent,
				targetReal = realPercent,
				realDirty = false,
			}
			self._rankPosition = {
				target = targetPosition,
				speed = 0,
				dirty = false
			}
			-- rank level
			self:RefreshRankLevel(false)
		else
			local currentFinal = self._rankAbilityValues[idx].currentFinal
			local currentReal = self._rankAbilityValues[idx].currentReal
			self._rankAbilityValues[idx].targetFinal = finalPercent
			self._rankAbilityValues[idx].finalDirty = true
			self._rankAbilityValues[idx].finalSpeed = math.abs(finalPercent - currentFinal) / PROGRESS_MOVE_DURATION
			self._rankAbilityValues[idx].targetReal = realPercent
			self._rankAbilityValues[idx].realDirty = true
			self._rankAbilityValues[idx].realSpeed = math.abs(realPercent - currentReal) / PROGRESS_MOVE_DURATION
			self._rankPosition.target = targetPosition
			self._rankPosition.dirty = true
			self._rankPosition.speed = math.abs(rankRootPos.x - targetPosition) / POSITION_MOVE_DURATION
		end
	end

	-- base rank info
	self:RefreshBaseRankInfo(selectedCharacters)
	-- do refresh here
	if isFirstEnter then
		self:RefreshRankElementStatus()
	end

	local characterDirty = self:IsCharacterDirty()
	self._ui.ButtonGo.gameObject:SetActive(characterDirty)
end

function WorkShopCharacterCtrl:RefreshRankElementStatus()
	if self._rankAbilityValues == nil then
		return
	end

	for idx = 1, #self._ui.WorkShopAbilities do
		local elementRoot = self._ui.WorkShopAbilities[idx].rankElementRoot
		for rank = 1, elementRoot.childCount do
			local elementItem = elementRoot:GetChild(rank - 1)
			local titleLabel = elementItem:Find("Right/Title"):GetComponent("UILabel")
			if rank < self._currentRank then
				titleLabel.color = RANK_MATCH_COLOR
			else
				titleLabel.color = RANK_NOT_MATCH_COLOR
			end

			local upgradeHint = elementItem:Find("UpgradeHint").gameObject
			local showHint = (self._currentRank >= self._topRank and self._currentRank < self._maxRank and rank == self._currentRank)
			upgradeHint:SetActive(showHint)
		end
	end
end

function WorkShopCharacterCtrl:GetStartRankToShow()
	local rank = self._currentRank - 1
	rank = math.max(rank, 1)
	-- the max element to show is 3
	rank = math.min(self._maxRank - 3, rank)

	return rank
end

function WorkShopCharacterCtrl:GetShowProgressOfAbility(abilityIdx, abilityValue)
	local finalPercent = self:GetAbilityRankProgressWithinTopRank(self._currentRank, abilityIdx, abilityValue)

	local realRank = ConfigUtils.GetWorkShopRealRankOfAbility(self._workShopId, abilityIdx, abilityValue)
	local realPercent = self:GetAbilityRankProgress(realRank, abilityIdx, abilityValue)
	return finalPercent, realPercent
end

function WorkShopCharacterCtrl:GetAbilityRankProgressWithinTopRank(rank, abilityIdx, abilityValue)
	local nextRank = rank + 1
	if nextRank > self._topRank then
		return (rank - 1) / self._rankElementCount
	end

	nextRank = math.min(nextRank, self._maxRank)
	if rank >= nextRank then
		return 1
	end

	local rankList = ConfigUtils.GetWorkShopRankList(self._workShopId)
	local rankInfo = rankList[rank]
	local nextRankInfo = rankList[nextRank]
	local startValue = rankInfo.NeedAttribute[abilityIdx].Num
	local endValue = nextRankInfo.NeedAttribute[abilityIdx].Num
	abilityValue = math.min(abilityValue, endValue)
	abilityValue = math.max(abilityValue, startValue)

	local percent = (abilityValue - startValue) / (endValue - startValue)
	percent = (percent + rank - 1) / self._rankElementCount
	return percent
end

function WorkShopCharacterCtrl:GetAbilityRankProgress(rank, abilityIdx, abilityValue)
	local nextRank = rank + 1
	nextRank = math.min(nextRank, self._maxRank)
	if rank >= nextRank then
		return 1
	end

	local rankList = ConfigUtils.GetWorkShopRankList(self._workShopId)
	local rankInfo = rankList[rank]
	local nextRankInfo = rankList[nextRank]
	local startValue = rankInfo.NeedAttribute[abilityIdx].Num
	local endValue = nextRankInfo.NeedAttribute[abilityIdx].Num
	abilityValue = math.min(abilityValue, endValue)
	abilityValue = math.max(abilityValue, startValue)

	local percent = (abilityValue - startValue) / (endValue - startValue)
	percent = (percent + rank - 1) / self._rankElementCount
	return percent
end

function WorkShopCharacterCtrl:RefreshRankLevel(playAnimation)
	self._lastRank = self._currentRank
	local rankList = ConfigUtils.GetWorkShopRankList(self._workShopId)
	local currentRankInfo = rankList[self._currentRank]
	self._ui.WorkShopLevel.text = SAFE_LOC(currentRankInfo.RankText)

	local showFullLevelHint = (self._currentRank >= self._maxRank)
	-- full level hint
	self._ui.WorkShopFullLevelHint:SetActive(showFullLevelHint)

	if playAnimation then
		self._ui.WorkShopLevelHintAnimator:Play("WorkShopLevel", 0, 0)
	end
end

function WorkShopCharacterCtrl:RefreshBaseRankInfo(characterList)
	-- max work time
	local maxWorkTime = GameData.CalculateWorkShopTimeLimit(self._workShopId, self._workShopLevel, characterList)
	self._ui.WorkShopRewardTime.text = SAFE_LOC("最大工时：")..Helper.GetLongTimeString(maxWorkTime)
	-- drop rewards
	self:RefreshDropRewards(maxWorkTime, characterList)
end

function WorkShopCharacterCtrl:RefreshDropRewards(maxWorkTime, characterList)
	self._workShopHasDrop = false
	local currentRank = self._currentRank
	local rankList = ConfigUtils.GetWorkShopRankList(self._workShopId)
	local currentRankInfo = rankList[currentRank]
	local currentRankProduction = currentRankInfo.Production or {}

	local globalBuffList = self:GetArenaAndCoupleSkills()
	local goodsSkillMap = GameData.GetGroupSkillMap(characterList, nil, {effectAttribute = EffectAttribute.WorkShopGoodsNumber, globalSkills = globalBuffList})

	local dropList = ConfigUtils.GetWorkShopRewards(self._workShopId)
	for idx = 1, #self._ui.WorkShopRewards do
		local hasDrop = (idx <= #dropList)
		local rewardItem = self._ui.WorkShopRewards[idx].item
		rewardItem:SetActive(hasDrop)
		if hasDrop then
			local dropId = dropList[idx].Value
			local unlockLevel = dropList[idx].NeedLevel
			local needProduction = dropList[idx].NeedProduction
			local numPerProdcution = dropList[idx].Num
			local thisProduction = currentRankProduction[idx] or 0

			UIHelper.ConstructItemIconAndNum(self, rewardItem.transform, dropId)
			local locked = (self._workShopLevel < unlockLevel)
			self._ui.WorkShopRewards[idx].locked:SetActive(locked)
			if locked then
				self._ui.WorkShopRewards[idx].unlock.text = tostring(unlockLevel).."级解锁"
				self._ui.WorkShopRewards[idx].num.text = ""
			else
				local numPerWorkTime = math.floor((thisProduction * maxWorkTime * numPerProdcution) / needProduction)
				local matchedSkills = GameData.GetItemMatchedSkills(goodsSkillMap, dropId)
				local dropAddPercent = GameData.GetAddPercentValueOfSkillList(matchedSkills)
				numPerWorkTime = Helper.Round(numPerWorkTime * (1 + dropAddPercent), 2)
				numPerWorkTime = math.ceil(numPerWorkTime)
				self._ui.WorkShopRewards[idx].num.text = tostring(numPerWorkTime)

				if thisProduction > 0 then
					self._workShopHasDrop = true
				end
			end
		end
	end
end

function WorkShopCharacterCtrl:RecordOriginalCharacters()
	self._originalCharacters = {}
	for idx = 1, #self._selectedCharacters do
		self._originalCharacters[idx] = self._selectedCharacters[idx].id
	end
end

function WorkShopCharacterCtrl:IsOriginalSelected(characterId)
	for idx = 1, #self._originalCharacters do
		if self._originalCharacters[idx] == characterId then
			return true
		end
	end

	return false
end

function WorkShopCharacterCtrl:IsCharacterDirty()
	if #self._selectedCharacters ~= #self._originalCharacters then
		return true
	end

	for idx = 1, #self._selectedCharacters do
		if self._selectedCharacters[idx].id ~= self._originalCharacters[idx] then
			return true
		end
	end

	return false
end

function WorkShopCharacterCtrl.OnItemUpdateGlobal(itemObj, itemIndex, itemRealIndex)
	local ctrl = CtrlManager.GetCtrlByName(CtrlNames.WorkShopCharacter)
	if ctrl ~= nil then
		ctrl:OnItemUpdate(itemObj, itemIndex, itemRealIndex)
	end
end

function WorkShopCharacterCtrl:OnWorkShopLevelChanged(workShopId)
	if workShopId ~= self._workShopId then
		return
	end

	self._workShopLevel = GameData.GetWorkShopLevel(self._workShopId)
	self._numLimit = ConfigUtils.GetWorkShopNumCapacity(self._workShopId, self._workShopLevel)
	self._topRank = ConfigUtils.GetWorkShopTopRank(self._workShopId, self._workShopLevel)
	-- force to update the rank elements and upgrade hint
	self._lastRank = -1
	self:InitCharacterPositionHint()
	-- current rank, top rank and drop both may changed
	self:OnSelectedCharacterChanged(false)
	self:RefreshUpgradeButtonState()
end

function WorkShopCharacterCtrl:RefreshUpgradeButtonState()
	local unlocked = GameData.IsModuleUnlocked(ModuleNames.WorkShopUpgrade)
	local maxLevel = ConfigUtils.GetWorkShopMaxLevel(self._workShopId)
	self._ui.ButtonUpgrade:SetActive(unlocked and self._workShopLevel < maxLevel)
end

function WorkShopCharacterCtrl:OnCharacterConfirm()
	local characterList = self:GetSelectedCharacterList()
	if #characterList == 0 then
		characterList = nil
	end
	NetManager.Send("WorkShopTeamSet", 
		{
			WorkShopId = self._workShopId, 
			CharacterList = characterList, 
		}, 
		WorkShopCharacterCtrl.OnHandleProto, self
	)
end

-- on clicked
function WorkShopCharacterCtrl:OnClicked(go)

	if go == self._ui.ButtonClose then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
	elseif go == self._ui.ButtonGo.gameObject then
		local characterList = self:GetSelectedCharacterList()
		if #characterList > 0 and not self._workShopHasDrop then
			SoundSystem.PlayWarningSound()
			CtrlManager.ShowMessageBox({
				message = SAFE_LOC("loc_msg_workshop_not_start"), 
				single = false, 
				onConfirm = WorkShopCharacterCtrl.OnCharacterConfirm, 
				receiver = self}
			)
			return true
		end

		SoundSystem.PlayUIClickSound()
		self:OnCharacterConfirm()
	elseif go == self._ui.ButtonUpgrade then
		SoundSystem.PlayUIClickSound()
		CtrlManager.OpenPanel(CtrlNames.WorkShopUpgrade, {workShopId = self._workShopId})
	elseif go == self._ui.ButtonFilter then
		SoundSystem.PlayUIClickSound()
		self:ShowFilterPanel()
	elseif go.transform.parent == self._ui.ItemGrid then
		local roleId = tonumber(go.name)
		local characterIdx = self:GetExploreCharacterIdx(roleId)
		if characterIdx ~= nil then
			SoundSystem.PlayUIClickSound()
			self:RemoveExploreCharacterAt(characterIdx)
		else
			local originalSelected = self:IsOriginalSelected(roleId)
			-- busy character
			local isBusy = GameData.IsBusyCharacter(roleId, self._characterSelectMode)
			if not originalSelected and isBusy then
				SoundSystem.PlayWarningSound()
				return true
			end
			-- character is full
			if #self._selectedCharacters >= self._numLimit then
				SoundSystem.PlayWarningSound()
				self:NotifyCharacterFull()
				return true
			end
			-- tag not fit
			local selectableMap = CharacterSelectBaseCtrl.GetCharacterSelectableMap()
			if not selectableMap[roleId] then
				SoundSystem.PlayWarningSound()
				return true
			end

			SoundSystem.PlayUIClickSound()
			self:AppendExploreCharacter(roleId)
		end
	elseif go.transform.parent == self._ui.CharacterRoot then
		SoundSystem.PlayUIClickSound()
		local characterId = tonumber(go.name)
		local characterIdx = self:GetExploreCharacterIdx(characterId)
		assert(characterIdx ~= nil, "clicked character but not in explore character list: "..go.name)
		self:RemoveExploreCharacterAt(characterIdx)
	elseif Helper.StartWith(go.name, "SelectedCharacter_") then
		local names = Helper.StringSplit(go.name)
		assert(#names == 2, "invalid explore skill item name: "..tostring(go.name))
		local idx = tonumber(names[2])
		local characterId = self._selectedCharacters[idx].id
		if ConfigUtils.IsValidItem(characterId) then
			SoundSystem.PlayUIClickSound()
			self:RemoveExploreCharacterAt(idx)
		end
	elseif go.transform.parent == self._ui.WorkShopAbilityRoot then
		SoundSystem.PlayUIClickSound()
		local names = Helper.StringSplit(go.name)
		assert(#names == 2, "invalid ability item name: "..tostring(go.name))
		local idx = tonumber(names[2])
		local abilityId = _sortAbilityList[idx]
		local preAbilityId, preSortPower = CharacterSelectBaseCtrl.GetSortValue()
		if abilityId == preAbilityId then
			abilityId = nil 
		end
		CharacterSelectBaseCtrl.SetSortValue(abilityId, preSortPower)
		-- only in character mode need to refresh the character items
		if self._currentMode == ExploreSelectionMode.Character then
			self:RecycleGridItems()
        	self:OnSelectionModeChanged()
        end
		self:RefreshSortState()
	elseif go == self._ui.ButtonCharacter.gameObject then
		SoundSystem.PlaySwitchSound()
        CharacterSelectBaseCtrl.ResetFilterName()
		self:RecycleGridItems()
		self._currentMode = ExploreSelectionMode.Character
		self:OnSelectionModeChanged()
    elseif go == self._ui.ButtonTeam.gameObject then
        SoundSystem.PlaySwitchSound()
        CharacterSelectBaseCtrl.ResetFilterName()
        self:RecycleGridItems()
        self._currentMode = ExploreSelectionMode.Team
        self:OnSelectionModeChanged()
    elseif go == self._ui.ButtonCouple.gameObject then
        SoundSystem.PlaySwitchSound()
        CharacterSelectBaseCtrl.ResetFilterName()
        self:RecycleGridItems()
        self._currentMode = ExploreSelectionMode.Couple
        self:OnSelectionModeChanged()
       elseif go == self._ui.ButtonTeamSort then
        if self._teamMode == TeamEditMode.Normal then
            SoundSystem.PlayUIClickSound()
            self:StartSortTeam()
        else
            SoundSystem.PlayWarningSound()
        end
    elseif go == self._ui.ButtonTeamDelete then
        if self._teamMode == TeamEditMode.Normal then
            SoundSystem.PlayUIClickSound()
            self:StartDeleteTeam()
        else
            SoundSystem.PlayWarningSound()
        end
    elseif go == self._ui.ButtonTeamSortConfirm then
        SoundSystem.PlayUIClickSound()
        self:BackToNormalTeam()
    elseif go == self._ui.ButtonTeamDeleteConfirm then
        SoundSystem.PlayUIClickSound()
        self:BackToNormalTeam()
    elseif go.transform.parent == self._ui.TeamGrid then
        if self._teamMode == TeamEditMode.Normal then
            local idx = tonumber(go.name)
            self:UseTeam(idx)
        end
    elseif go.transform.parent == self._ui.CoupleGrid then
        local coupleId = tonumber(go.name)
        self:UseCouple(coupleId)
    elseif go.name == "ButtonDelete" then
        SoundSystem.PlayUIClickSound()
        local idx = tonumber(go.transform.parent.gameObject.name)
        self:DeleteTeam(idx)
    elseif go.name == "ButtonRename" then
        local idx = tonumber(go.transform.parent.gameObject.name)
        self:RenameTeam(idx)
    elseif go.name == "ButtonMoveUp" then
        SoundSystem.PlayUIClickSound()
        local idx = tonumber(go.transform.parent.gameObject.name)
        self:MoveUpTeam(idx)
    elseif go.name == "ButtonMoveDown" then
        SoundSystem.PlayUIClickSound()
        local idx = tonumber(go.transform.parent.gameObject.name)
        self:MoveDownTeam(idx)
    elseif go.name == "ButtonSave" or go.name == "ButtonReplace" then
        SoundSystem.PlayUIClickSound()
        local idx = tonumber(go.transform.parent.gameObject.name)
        local charactes = self:GetSelectedCharacterList()
        self:ReplaceTeam(idx, charactes, self._selectedPet)
	end

	return true
end

-- on pressed
function WorkShopCharacterCtrl:OnPressed(go, pressed, isLong)
	if pressed and isLong then
		if go.transform.parent == self._ui.ItemGrid then
			SoundSystem.PlayUIClickSound()
			local itemId = tonumber(go.name)
			CtrlManager.OpenPanel(CtrlNames.CharacterQuickDetail, {characterId = itemId})
		elseif go.transform.parent == self._ui.CharacterRoot then
			local characterId = tonumber(go.name)
			self:StartDrag(characterId)
		end
	elseif not pressed and self._dragCharacterId ~= nil then
		self:EndDrag()
	end
end

function WorkShopCharacterCtrl:OnHandleProto(proto, data, requestData)
	if proto == "WorkShopTeamSet" then
		GameData.SetDataOfWorkShop(data.WorkShopStatus)
		GameData.MarkBusyCharacterDirty()
		GameData.SyncTutorialData()
		GameData.CheckAndHintGoalsOfCurrentCountType()
		GameNotifier.Notify(GameEvent.WorkShopListChanged)
		CtrlManager.PopPanel()
	end
end
--------------------------------------------------------
-- skills
function WorkShopCharacterCtrl:GetSkillListToScope()
	local ret = {}

	local attributes = {}
	attributes[EffectAttribute.WorkShopMaxWorkTime] = 1
	attributes[EffectAttribute.WorkShopGoodsNumber] = 1

	for idx = 1, #self._selectedCharacters do
		local characterId = self._selectedCharacters[idx].id
		local skillList = GameData.GetCharacterSkillList(characterId)
		for skillIdx = 1, #skillList do
			local skillId = skillList[skillIdx].id
			local skillValue = skillList[skillIdx].value
			local effectAttribute = ConfigUtils.GetSkillEffectAttribute(skillId)
			if attributes[effectAttribute] ~= nil then
				table.insert(ret, {id = skillId, value = skillValue, source = characterId})
			end
		end
	end

	return ret
end

function WorkShopCharacterCtrl:GetSkillMapOfMembers()
	local attributes = {}
	attributes[EffectAttribute.Ability] = 1

	local characterList = {}
	for idx = 1, #self._selectedCharacters do
		characterList[idx] = self._selectedCharacters[idx].id
	end

	local ret = {}

	for idx = 1, #characterList do
		local characterId = characterList[idx]
		local skillList = GameData.GetCharacterSkillList(characterId)
		for skillIdx = 1, #skillList do
			local skillId = skillList[skillIdx].id
			local skillValue = skillList[skillIdx].value
			if self:ShouldShowMemberSkill(skillId, attributes) then
				local isMatch, matchCount = GameData.IsSkillConditionMatch(skillId, characterId, idx, characterList)
				if isMatch then
					local effectMembers = GameData.GetSkillEffectedMembers(skillId, characterId, idx, characterList)
					if ret[characterId] == nil then
						ret[characterId] = {}
					end
					table.insert(ret[characterId], {id = skillId, value = skillValue, target = effectMembers, matchCount = matchCount})
				end
			end
		end
	end

	return ret
end

function WorkShopCharacterCtrl:MatchableAbilityMap()
	local ret = {}
	
	ret[AbilityType.CRA] = 1
	ret[AbilityType.AFF] = 1
	ret[AbilityType.STR] = 1
	ret[AbilityType.INT] = 1

	return ret
end

function WorkShopCharacterCtrl:GetCoupleKey()
	return CoupleNodeKey.WorkShop
end
-------------------------------------------------------------------------------------------
-- tutorial
function WorkShopCharacterCtrl:CheckTutorial()
	local tutorials = {}

	if GameData.IsTutorialNotFinished(Tutorials.Tutorial_4_4) and GameData.IsGoalRunning(TutorialConstData.WorkShopGoal) then
		local roleItem = self._ui.ItemGrid:Find(TutorialConstData.JuminId)
		local position = self._ui.Camera:WorldToScreenPoint(roleItem.position)
		tutorials[1] = {event = Tutorials.Tutorial_4_2, position = position, sender = self}
		position = self._ui.Camera:WorldToScreenPoint(self._ui.WorkShopLevel.transform.position)
		tutorials[2] = {event = Tutorials.Tutorial_4_3, position = position, sender = self}
		position = self._ui.Camera:WorldToScreenPoint(self._ui.ButtonGo.transform:Find("TutorialMark").position)
		tutorials[3] = {event = Tutorials.Tutorial_4_4, position = position, sender = self}
	elseif GameData.IsTutorialNotFinished(Tutorials.Tutorial_7_4) and GameData.IsGoalRunning(TutorialConstData.WorkShopUpgradeGoal) then
		local position = self._ui.Camera:WorldToScreenPoint(self._ui.ButtonUpgrade.transform.position)
		tutorials[1] = {event = Tutorials.Tutorial_7_2, position = position, sender = self}
	end

	if #tutorials > 0 then
		CtrlManager.ShowTutorials(tutorials)
	end

	return #tutorials > 0
end

function WorkShopCharacterCtrl:OnTutorialClicked(tutorial)
	if tutorial == Tutorials.Tutorial_4_2 then
		local roleItem = self._ui.ItemGrid:Find(TutorialConstData.JuminId)
		self:OnClicked(roleItem.gameObject)
	elseif tutorial == Tutorials.Tutorial_4_4 then
		GameData.AppendTutorial(CtrlNames.WorkShop, "NotifyFocus", {
			--打工界面修改了,所以不需要这一步了 add by ggyy
			--Tutorials.Tutorial_WorkshopRewardHint,
			Tutorials.Tutorial_WorkshopExchange			
		})
		self:OnClicked(self._ui.ButtonGo.gameObject)
	elseif tutorial == Tutorials.Tutorial_7_2 then
		self:OnClicked(self._ui.ButtonUpgrade)
	else
		SoundSystem.PlayUIClickSound()
	end
end
-------------------------------------------------------------------------------------------