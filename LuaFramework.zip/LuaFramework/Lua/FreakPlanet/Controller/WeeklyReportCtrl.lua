require "FreakPlanet/View/WeeklyReportPanel"

local class = require "FreakPlanet/Utils/middleclass"
WeeklyReportCtrl  = class(CtrlNames.WeeklyReport, BaseCtrl)

-- load the ui prefab
function WeeklyReportCtrl:LoadPanel()
	self:CreatePanel("WeeklyReport")
end

-- construct ui panel data
function WeeklyReportCtrl:ConstructUI(obj)
	self._ui = WeeklyReportPanel.Init(obj)
end

-- destructor
function WeeklyReportCtrl:DestroyImpl()
	GameNotifier.RemoveListener(GameEvent.WeeklyReportTextureLoaded, WeeklyReportCtrl.OnTextureLoaded, self)
end

-- fill ui with the data
function WeeklyReportCtrl:SetupUI()
	self._ui.ContextSprite.gameObject:SetActive(false)
	self._ui.Empty:SetActive(false)

	if GameData.HasWeeklyReport() then
		if GameData.NeedUpdateWeeklyTexture() then
			GameData.UpdateWeeklyTexture()
			self:HintLoading(true)
		else
			self:ShowWeeklyReport()
			local isLoading = GameData.IsLoadingWeeklyTexture()
			self:HintLoading(isLoading)
		end
	else
		self._ui.Empty:SetActive(true)
		self:HintLoading(false)
	end

	CtrlManager.AddClick(self, self._ui.Blocker)
	GameNotifier.AddListener(GameEvent.WeeklyReportTextureLoaded, WeeklyReportCtrl.OnTextureLoaded, self)

	if GameData.HasNewWeeklyReport() then
		GameData.MarkWeeklyReport()
	end
end

function WeeklyReportCtrl:HintLoading(isLoading)
	self._ui.LoadMark:SetActive(isLoading)
	if isLoading then
		self._ui.LoadState.text = SAFE_LOC("加载中...")
	end
end

function WeeklyReportCtrl:ShowWeeklyReport()
	local texture = GameData.GetWeeklyReportTexture()
	self._ui.ContextSprite.gameObject:SetActive(texture ~= nil)
	if texture ~= nil then
		local w = texture.width
		local h = texture.height
		local pivot = Vector2.one * 0.5
		self._ui.ContextSprite.sprite2D = UnityEngine.Sprite.Create(texture, UnityEngine.Rect.New(0, 0, w, h), pivot)
		--self._ui.ContextSprite.width = w
		--self._ui.ContextSprite.height = h
	end
end

function  WeeklyReportCtrl:OnTextureLoaded(success)
	if success then
		self:ShowWeeklyReport()
		self:HintLoading(false)
	else
		self._ui.LoadState.text = SAFE_LOC("加载失败")
	end
end

-- on clicked
function WeeklyReportCtrl:OnClicked(go)

	if go == self._ui.Blocker then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
	end

	return true
end
