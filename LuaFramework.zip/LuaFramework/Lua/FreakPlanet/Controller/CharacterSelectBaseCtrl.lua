local class = require "FreakPlanet/Utils/middleclass"
CharacterSelectBaseCtrl  = class(CtrlNames.CharacterSelectBase, BaseCtrl)

--------------------------------------------------------------------------------------
local MOVE_SPEED = 100
local COUPLE_HINT_TIME = 2.5 -- second
local MAX_COUPLE_NUM = 5
--------------------------------------------------------------------------------------
local _characterSortFunc = nil
local _petSortFunc = nil
--------------------------------------------------------------------------------------
-- store the values of characters
local _characterAbilityMap = nil
local _characterMatchGoalMap = nil
-- store the values of pets
local _petAbilityMap = nil
local _petMatchGoalMap = nil
--------------------------------------------------------------------------------------
local _characterSelectableMap = nil
local _needCharacterMap = nil
-- character filter and sort
local _sortAbilityId = nil
local _sortPower = false
local _filterElements = nil
local _filterRarities = nil
local _filterTags = nil
local _filterStages = nil
local _filterSkills = nil
local _filterName = nil
--------------------------------------------------------------------------------------
ExploreSelectionMode = {
	Character = "Character",
	Pet = "Pet",
    Team = "Team",
    Couple = "Couple",
}

TeamEditMode = {
	Normal = "Normal",
	Sort = "Sort",
	Delete = "Delete",
}

SelectionFailReason = {
	BreakRule = "BreakRule",
	ExploreMember = "ExploreMember",
	ActivityExploreMember = "ActivityExploreMember",
	WorkShopMember = "WorkShopMember",
}
--------------------------------------------------------------------------------------
-- notity it has been focused
function CharacterSelectBaseCtrl:NotifyFocus()
	self._muteSound = false
end

-- handle the escapse button
function CharacterSelectBaseCtrl:HandleEscape()
	self:OnClicked(self._ui.ButtonClose)
end

-- can do jump or not
function CharacterSelectBaseCtrl:CanJump()
	-- space travel no jump
	return self._seasonId == nil
end
--------------------------------------------------------------------------------------
-- sort and filter
function CharacterSelectBaseCtrl.SetSortValue(abilityId, power)
	_sortAbilityId = abilityId
	_sortPower = power
end

function CharacterSelectBaseCtrl.GetSortValue()
	return _sortAbilityId, _sortPower
end

function CharacterSelectBaseCtrl.SetCharacterSelectableMap(map)
	_characterSelectableMap = map
end

function CharacterSelectBaseCtrl.GetCharacterSelectableMap()
	return _characterSelectableMap or {}
end

function CharacterSelectBaseCtrl.SetNeedCharacterMap(map)
	_needCharacterMap = map
end

function CharacterSelectBaseCtrl.GetNeedCharacterMap()
	return _needCharacterMap or {}
end

function CharacterSelectBaseCtrl.ResetNeedCharacterMap()
	_needCharacterMap = nil
end

function CharacterSelectBaseCtrl.ResetSortValue()
	_sortAbilityId = nil
	_sortPower = true
end

function CharacterSelectBaseCtrl.ResetFilterName()
	_filterName = nil
end

function CharacterSelectBaseCtrl.ResetSortAndFilter()
	CharacterSelectBaseCtrl.ResetFilterName()
	CharacterSelectBaseCtrl.ResetSortValue()
	_filterElements = nil
	_filterRarities = nil
	_filterTags = nil
	_filterStages = nil
	_filterSkills = nil
end

function CharacterSelectBaseCtrl.DoItemFilter(itemList)
	local ret = {}

	for idx = 1, #itemList do
		local itemId = itemList[idx]
		local match = CharacterSelectBaseCtrl.IsItemMatchFilter(itemId, _filterName, _filterElements, _filterRarities, _filterTags, _filterStages, _filterSkills)
		if match then
			table.insert(ret, itemId)
		end
	end

	return ret
end

function CharacterSelectBaseCtrl.GetItemSkillList(itemId)
	local itemType = ConfigUtils.GetItemTypeFromId(itemId)
	if itemType == ItemType.Character then
		return GameData.GetCharacterSkillList(itemId)
	elseif itemType == ItemType.Pet then
		return GameData.GetPetSkillList(itemId)
	end

	return {}
end

function CharacterSelectBaseCtrl.IsItemMatchFilter(itemId, filterName, filterElements, filterRarities, filterTags, filterStages, filterSkills)
	if filterName ~= nil then
		local itemName = ConfigUtils.GetItemName(itemId)
		return string.match(itemName, filterName) ~= nil
	end

	if filterElements ~= nil then
		local elementId = ConfigUtils.GetElementOfItem(itemId)
       	if filterElements[elementId] == nil then
            return false
        end
	end

	if filterRarities ~= nil then
		local rarity = ConfigUtils.GetItemRarity(itemId)
		if filterRarities[rarity] == nil then
			return false
		end
	end

	if filterTags ~= nil then
		local hasMatched = false
		local tagMap = ConfigUtils.GetItemTagMap(itemId)
       	for tagId, _ in pairs(filterTags) do
       		if tagMap[tagId] ~= nil then
       			hasMatched = true
       			break
       		end
       	end

        if not hasMatched then
        	return false
        end
	end

	if filterStages ~= nil then
		local itemType = ConfigUtils.GetItemTypeFromId(itemId)
		-- pet has no stage
		if itemType == ItemType.Character then
			local stage = GameData.GetCharacterCurrentStage(itemId)
			if filterStages[stage] == nil then
				return false
			end
		end
	end

	if filterSkills ~= nil then
		local hasMatched = false
		local skillList = CharacterSelectBaseCtrl.GetItemSkillList(itemId)
		for idx = 1, #skillList do
			local skillId = skillList[idx].id
			if ConfigUtils.IsSkillMatchFilterMap(filterSkills, skillId) then
				hasMatched = true
				break
			end
		end

		if not hasMatched then
			return false
		end
	end

	return true
end
--------------------------------------------------------------------------------------
function CharacterSelectBaseCtrl:InitializeCharacterAbiltiyAndGoalMap(characterList)
	if _characterAbilityMap ~= nil and _characterMatchGoalMap ~= nil then
		return
	end

	_characterAbilityMap = {}
	_characterMatchGoalMap = {}
	for idx = 1, #characterList do
		local characterId = characterList[idx]
		_characterAbilityMap[characterId] = GameData.GetCharacterAbilityMap(characterId)
		_characterMatchGoalMap[characterId] = self:CheckCharacterMatchGoal(characterId)
	end
end

function CharacterSelectBaseCtrl:InitializePetAbilityAndGoalMap(petList)
	if _petAbilityMap ~= nil and _petMatchGoalMap ~= nil then
		return
	end

	_petAbilityMap = {}
	_petMatchGoalMap = {}
	for idx = 1, #petList do
		local petId = petList[idx]
		_petAbilityMap[petId] = GameData.GetPetAbilityMap(petId)
		_petMatchGoalMap[petId] = self:CheckPetMatchGoal(petId)
	end
end

function CharacterSelectBaseCtrl:CheckCharacterMatchGoal(characterId)
	return false
end

function CharacterSelectBaseCtrl:CheckPetMatchGoal(petId)
	return false
end

function CharacterSelectBaseCtrl.IsCharacterGoalNeeded(characterId)
	if _characterMatchGoalMap == nil then
		return false
	end

	return _characterMatchGoalMap[characterId] or false
end

function CharacterSelectBaseCtrl.IsPetGoalNeeded(petId)
	if _petMatchGoalMap == nil then
		return false
	end

	return _petMatchGoalMap[petId] or false
end

function CharacterSelectBaseCtrl.GetAbilityValueOfCharacter(characterId, abilityId)
	if _characterAbilityMap == nil then
		return 0
	end

	local abilityMap = _characterAbilityMap[characterId] or {}
	return abilityMap[abilityId] or 0
end

function CharacterSelectBaseCtrl.GetAbilitySumOfCharacter(characterId, abilityList)
	if _characterAbilityMap == nil then
		return 0
	end

	local sum = 0
	local abilityMap = _characterAbilityMap[characterId] or {}
	for idx = 1, #abilityList do
		local abilityId = abilityList[idx]
		local abilityValue = abilityMap[abilityId] or 0
		sum = sum + abilityValue
	end

	return sum
end

function CharacterSelectBaseCtrl.GetPowerValueOfCharacter(characterId)
	if _characterAbilityMap == nil then
		return 0
	end

	local abilityMap = _characterAbilityMap[characterId] or {}
	return ConfigUtils.GetPowerOfAbilityMap(abilityMap)
end

function CharacterSelectBaseCtrl.GetAbilityMapOfCharacter(characterId)
	if _characterAbilityMap == nil then
		return {}
	end

	return _characterAbilityMap[characterId] or {}
end

function CharacterSelectBaseCtrl.GetAbilityValueOfPet(petId, abilityId)
	if _petAbilityMap == nil then
		return 0
	end

	local abilityMap = _petAbilityMap[petId] or {}
	return abilityMap[abilityId] or 0
end

function CharacterSelectBaseCtrl.GetAbilitySumOfPet(petId, abilityList)
	if _petAbilityMap == nil then
		return 0
	end

	local sum = 0
	local abilityMap = _petAbilityMap[petId] or {}
	for idx = 1, #abilityList do
		local abilityId = abilityList[idx]
		local abilityValue = abilityMap[abilityId] or 0
		sum = sum + abilityValue
	end

	return sum
end

function CharacterSelectBaseCtrl.GetPowerValueOfPet(petId)
	if _petAbilityMap == nil then
		return 0
	end

	local abilityMap = _petAbilityMap[petId] or {}
	return ConfigUtils.GetPowerOfAbilityMap(abilityMap)
end

function CharacterSelectBaseCtrl.GetAbilityMapOfPet(petId)
	if _petAbilityMap == nil then
		return {}
	end

	return _petAbilityMap[petId] or {}
end
--------------------------------------------------------------------------------------
-- initialize
function CharacterSelectBaseCtrl:InitializeShared(numLimit, characterSortFunc, petSortFunc)
	-----------------------------------------------------------
	_characterMatchGoalMap = nil
	_characterAbilityMap = nil
	_petMatchGoalMap = nil
	_petAbilityMap = nil
	_characterSelectableMap = nil
	_needCharacterMap = nil
	-----------------------------------------------------------
	_characterSortFunc = characterSortFunc
	_petSortFunc = petSortFunc
	-----------------------------------------------------------
	-- do reset
	CharacterSelectBaseCtrl.ResetSortAndFilter()

	self._dragCharacterId = nil
	self._dragPosition = nil
	self._suspendCoupleHint = false
	-- prefabs
	self._characterItemPrefab = self:LoadAsset("CharacterItem")
	self._coupleItemPrefab = self:LoadAsset("CoupleItem")
	self._coupleSelectItemPrefab = self:LoadAsset("CoupleSelectItem")
	if self._characterSelectMode == CharacterSelectMode.WorkShop then
		self._teamSelectItemPrefab = self:LoadAsset("WorkShopTeamSelectItem")
		self._teamType = TeamType.WorkShop
	else
		self._teamSelectItemPrefab = self:LoadAsset("TeamSelectItem")
		if self._characterSelectMode == CharacterSelectMode.Explore or 
		   self._characterSelectMode == CharacterSelectMode.ActivityExplore then
			self._teamType = TeamType.Explore
		else
			self._teamType = TeamType.Challenge
		end
	end

	self:DynamicLoadBundle(Const.CoupeAvatarBundleName)
	local coupleKey = self:GetCoupleKey()
	self._availableCoupleList = ConfigUtils.GetMatchedCoupleList(coupleKey)

	self:InitializeCharacters(numLimit)
	self:InitializeExploreRules()
	self:RefreshDragHints()
	self:SortCharacterPetPositionHint()

	-- scope skill hint
	self._scopeSkillList = {}
	self._scopeSkillsToHint = {}
	self._scopeSkillHintState = nil
	-- member skill hint
	self._memberSkillMap = {}
	self._memberSkillsToHint = {}
	self._memberSkillHintStates = {}
	-- activated couple list
	self._coupleList = {}
	self._coupleHintState = nil

	self._muteSound = false
	-- default selection mode
	self._currentMode = ExploreSelectionMode.Character
	self._teamMode = TeamEditMode.Normal
	-- the count of playing sounds
	self._soundCount = 0
	-- initial state
	self._ui.GlobalSkillHintAnimator.gameObject:SetActive(false)
end

function CharacterSelectBaseCtrl:InitializeCharacters(numLimit)
	self._numLimit = numLimit
	self._selectedCharacters = {}
	local characters = self:GetInitialCharacters()
	for idx = 1, #characters do
		local characterId = characters[idx]
		local characterItem = self:CreateNewCharacterObj(characterId)
		-- face right
		Helper.CheckDirection(characterItem, 1)
		-- position
		characterItem.localPosition = self:GetCharacterSettingPosition(idx)
		-- skeleton
		local skeletonAnimation = characterItem:Find("Avatar"):GetChild(0):GetComponent("SkeletonAnimation")
		-- initial animation: idle
		Helper.PlayAnimation(skeletonAnimation, CharacterAnimations.Idle, true)
		-- skin
		UIHelper.SetCharacterSkin(skeletonAnimation, characterId)
		-- data element
		self._selectedCharacters[idx] = {id = characterId, item = characterItem, skeletonAnimation = skeletonAnimation}
	end


end



function CharacterSelectBaseCtrl:MuteSound()
	self._muteSound = true
end

function CharacterSelectBaseCtrl:InitializeExploreRules()
	self._exploreRules = {}
end

--- 重新排序
---顺序如下(Pet)(5)(4)(3)(2)(1)
function CharacterSelectBaseCtrl:SortCharacterPetPositionHint()
	self._CharacterPositionHint = {}
	self._PetPositionHint = nil
	if self:HasPetPositionHint() then
		self._PetPositionHint = self._ui.CharacterPositionHint[1]
		for idx = #self._ui.CharacterPositionHint , 2, -1 do
			table.insert(self._CharacterPositionHint, self._ui.CharacterPositionHint[idx])
		end
	else
		for idx = #self._ui.CharacterPositionHint, 1, -1 do
			table.insert(self._CharacterPositionHint, self._ui.CharacterPositionHint[idx])
		end
	end

	self:InitCharacterPositionHint()
end

function CharacterSelectBaseCtrl:InitCharacterPositionHint()
	local totalNum = self:HasPetPositionHint() and self._numLimit + 1 or self._numLimit
	--[[
	for idx = 1, #self._ui.CharacterPositionHint do
		local item = self._ui.CharacterPositionHint[idx].item
		item.gameObject:SetActive(idx <= totalNum)
		if idx <= totalNum then
			UIHelper.PlaceHorizontalItemPosition(item, idx, totalNum, 30)
		end
	end
	--]]
	if self._PetPositionHint then
		self._PetPositionHint.item.gameObject:SetActive(true)
	end
	if self._CharacterPositionHint then
		for idx = 1, #self._CharacterPositionHint do
			local item = self._CharacterPositionHint[idx].item
			item.gameObject:SetActive( idx<= self._numLimit)
		end
	end

	if self._ui.CharacterPositionHintUIGrid then
		self._ui.CharacterPositionHintUIGrid:Reposition()
	end

end

-- 是否需要显示宠物位置
function CharacterSelectBaseCtrl:HasPetPositionHint()
	return false
end


function CharacterSelectBaseCtrl:GetSelectedPet()
	return nil
end

function CharacterSelectBaseCtrl:GetInitialCharacters()
	-- explore area: has initial characters
	-- work shop goal: no initial characters
	-- challenge: no initial characters
	return {}
end

function CharacterSelectBaseCtrl:GetItemGrid()
	if self._currentMode == ExploreSelectionMode.Character or self._currentMode == ExploreSelectionMode.Pet then
		return self._ui.ItemGrid
    elseif self._currentMode == ExploreSelectionMode.Team then
        return self._ui.TeamGrid
    elseif self._currentMode == ExploreSelectionMode.Couple then
    	return self._ui.CoupleGrid
	else
		assert(false, "un-handled character select mode: "..tostring(self._currentMode))
	end

	return nil
end

function CharacterSelectBaseCtrl:GetItemPrefabAndPool()
	return self._characterItemPrefab, self._ui.CharacterItemPool
end

function CharacterSelectBaseCtrl:RecycleGridItems()
	if self._currentMode == ExploreSelectionMode.Team or self._currentMode == ExploreSelectionMode.Couple then
        return
    end

	local gridRoot = self:GetItemGrid()
	local _, poolRoot = self:GetItemPrefabAndPool()
	-- move item icon pool
	for idx = gridRoot.childCount, 1, -1 do
		local item = gridRoot:GetChild(idx - 1)
		item.parent = poolRoot
	end
end

function CharacterSelectBaseCtrl:GetAvatarItem(itemId)
	return self._ui.CharacterRoot:Find(itemId)
end
--------------------------------------------------------------------------------------
-- drag
function CharacterSelectBaseCtrl:StartDrag(characterId)
	self._dragCharacterId = characterId
	local worldPosition = self._ui.Camera:ScreenToWorldPoint(Input.mousePosition)
	self._dragPosition = self._ui.CharacterRoot:InverseTransformPoint(worldPosition)
	local idx = self:GetExploreCharacterIdx(self._dragCharacterId)
	self:SetDragDepth(idx, -20)
	self:PlayCharacterAnimation(idx, CharacterAnimations.Sitting, true)
	self:RefreshDragHints()
end

function CharacterSelectBaseCtrl:EndDrag()
	local idx = self:GetExploreCharacterIdx(self._dragCharacterId)
	self:SetDragDepth(idx, 0)
	self:NotifyCharacterMove(idx)

	self._dragCharacterId = nil
	self._dragPosition = nil
	self:RefreshDragHints()
end

function CharacterSelectBaseCtrl:RefreshDragHints()
	for idx = 1, #self._ui.DragHints do
		local hasCharacter = (idx <= #self._selectedCharacters)
		local showHint = false
		if hasCharacter then
			showHint = (self._dragCharacterId == self._selectedCharacters[idx].id)
		end
		self._ui.DragHints[idx]:SetActive(showHint)
	end
end

function CharacterSelectBaseCtrl:SetDragDepth(idx, depth)
	local item = self._selectedCharacters[idx].item
	local pos = item.localPosition
	pos.z = depth
	item.localPosition = pos
end

function CharacterSelectBaseCtrl:GetPositionIndex(positionX)
	local count = #self._ui.CharacterPositions
	for idx = 2, count do
		local x = self._ui.CharacterPositions[idx].x
		if positionX > x then
			return idx - 1
		end
	end

	return count
end
--------------------------------------------------------------------------------------
-- update

-- update per frame
function CharacterSelectBaseCtrl:UpdateImpl(deltaTime)
	-- move character
	for idx = 1, #self._selectedCharacters do
		self:MoveCharacter(deltaTime, idx)
	end
	-- drag
	self:UpdateDrag(deltaTime)
	-- skill hint
	self:UpdateScopeSkillHint(deltaTime)
	self:UpdateMemberSkillHint(deltaTime)

	if self._coupleHintState ~= nil then
		local finished = self._coupleHintState:Tick(deltaTime)
		if finished then
			self._coupleHintState = nil
		end
	end
end

function CharacterSelectBaseCtrl:UpdateDrag(deltaTime)
	if self._dragCharacterId ~= nil then
		local worldPosition = self._ui.Camera:ScreenToWorldPoint(Input.mousePosition)
		local dragPosition = self._ui.CharacterRoot:InverseTransformPoint(worldPosition)
		local diffX = (dragPosition.x - self._dragPosition.x)

		local idx = self:GetExploreCharacterIdx(self._dragCharacterId)
		local item = self._selectedCharacters[idx].item 
		local pos = item.localPosition
		local newX = pos.x + diffX
		newX = math.max(newX, self._ui.LimitMin)
		newX = math.min(newX, self._ui.LimitMax)
		pos.x = newX
		item.localPosition = pos

		local newIdx = self:GetPositionIndex(newX)
		if newIdx ~= idx then
			newIdx = math.min(newIdx, #self._selectedCharacters)
		end

		if newIdx ~= idx then
			local copyData = self._selectedCharacters[idx]
			if newIdx > idx then
				for itemIdx = idx + 1, newIdx do
					self._selectedCharacters[itemIdx - 1] = self._selectedCharacters[itemIdx]
					self:NotifyCharacterMove(itemIdx - 1)
				end
			else
				for itemIdx = idx - 1, newIdx, -1 do
					self._selectedCharacters[itemIdx + 1] = self._selectedCharacters[itemIdx]
					self:NotifyCharacterMove(itemIdx + 1)
				end
			end

			self._selectedCharacters[newIdx] = copyData
			self:RefreshDragHints()
			self:OnSelectedCharacterChanged(true)
		end

		self._dragPosition = dragPosition
	end
end

function CharacterSelectBaseCtrl:UpdateScopeSkillHint(deltaTime)
	if self._scopeSkillHintState ~= nil then
		local finished = self._scopeSkillHintState:Tick(deltaTime)
		if finished then
			self._scopeSkillHintState = nil
			self._ui.GlobalSkillHintAnimator.gameObject:SetActive(false)
		end
	end

	if self._scopeSkillHintState == nil then
		if #self._scopeSkillsToHint > 0 then
			local skillId = self._scopeSkillsToHint[1].id
			local skillValue = self._scopeSkillsToHint[1].value
			local source = self._scopeSkillsToHint[1].source
			self._ui.GlobalSkillValue.text = UIHelper.GetSkillShowText(skillId, skillValue)
			self._scopeSkillHintState = AnimatorState:new(self._ui.GlobalSkillHintAnimator, "GlobalSkillHint", nil, self._ui.GlobalSkillHintAnimator.gameObject)
			table.remove(self._scopeSkillsToHint, 1)
		end
	end
end

local _FinishedMembers = {}
function CharacterSelectBaseCtrl:UpdateMemberSkillHint(deltaTime)
	for memberId, state in pairs(self._memberSkillHintStates) do
		local finished = state:Tick(deltaTime)
		if finished then
			_FinishedMembers[memberId] = 1
		end
	end
	if not Helper.IsEmpty(_FinishedMembers) then
		for memberId, _ in pairs(_FinishedMembers) do
			self._memberSkillHintStates[memberId] = nil
		end
		_FinishedMembers = {}
	end

	for memberId, skillList in pairs(self._memberSkillsToHint) do
		if #skillList > 0 and self._memberSkillHintStates[memberId] == nil then
			local state = nil
			if skillList[1].isSelf then
				state = self:GenerateMemberSelfSkillHint(memberId, skillList[1].skills)
			else
				state = self:GenerateMemberSkillHint(memberId, skillList[1])
			end
			if state ~= nil then
				self._memberSkillHintStates[memberId] = state
			end
			table.remove(skillList, 1)
		end
	end
end

function CharacterSelectBaseCtrl:GetSkillAnimation(sourceId)
	local finalId = sourceId
	local itemType = ConfigUtils.GetItemTypeFromId(sourceId)
	if itemType == ItemType.Character then
		finalId = GameData.GetCharacterSkin(sourceId)
	end

	local battleResource = ConfigUtils.GeBattleResourceOfItem(finalId)
	return battleResource.SkillAnim
end

function CharacterSelectBaseCtrl:GenerateMemberSelfSkillHint(memberId, skills)
	local state = nil
	-- can' find the member character
	local targetAvatarItem = self:FindAvatarItem(memberId)
	if targetAvatarItem ~= nil then
		for idx = 1, #skills do
			local skillId = skills[idx].id
			local skillHintPrefabName = ConfigUtils.GetSkillEffectPrefab(skillId)
			if skillHintPrefabName ~= nil then
				local skillHintItem = self._ui.MemberSkillHintPool:Find(skillHintPrefabName)
				if skillHintItem == nil then
					local skillHintPrefab = self:DynamicLoadAsset(Const.SkillEffectBundleName, skillHintPrefabName)
					local skillHintObj = Helper.NewObject(skillHintPrefab, self._ui.MemberSkillHintRoot)
					skillHintObj.name = skillHintPrefabName
					skillHintItem = skillHintObj.transform
				else
					skillHintItem.parent = self._ui.MemberSkillHintRoot
					skillHintItem.localScale = Vector3.one
					skillHintItem.localPosition = Vector3.zero
				end

				local pos = self._ui.MemberSkillHintRoot:InverseTransformPoint(targetAvatarItem.position)
				pos.z = 0
				skillHintItem.localPosition = pos
				-- real info
				self:ConstructSkillHintItem(skills[idx], skillHintItem)
				-- hide at first, because it is not show immediately
				skillHintItem.gameObject:SetActive(false)

				local skillHintAnimator = skillHintItem:GetComponent("Animator")
				local childState = AnimatorState:new(skillHintAnimator, "SkillEffect", nil, skillHintItem.gameObject)
				childState:ActionOnEnter(CharacterSelectBaseCtrl.OnShowSelfSkill, self, skillHintItem)
				childState:ActionOnExit(CharacterSelectBaseCtrl.RecycleSkillHint, self, skillHintItem)

				if state == nil then
					state = SequenceState:new()
				end

				state:Push(childState)
			end
		end
	end

	return state
end

function CharacterSelectBaseCtrl:OnShowSelfSkill(skillHintItem)
	-- sound
	self:PlaySoundEffect(SoundNames.BattleCommonSkillEffect)
	-- play animation
	local skillEffectSkeleton1 = skillHintItem:Find("SkillEffect_1"):GetComponent("SkeletonAnimation")
	Helper.PlayAnimation(skillEffectSkeleton1, "SkillEffect", false)
	local skillEffectSkeleton2 = skillHintItem:Find("SkillEffect_2"):GetComponent("SkeletonAnimation")
	Helper.PlayAnimation(skillEffectSkeleton2, "SkillEffect", false)
end

function CharacterSelectBaseCtrl:GenerateMemberSkillHint(sourceId, skillData)
	local state = nil
	local skillId = skillData.id
	local skillValue = skillData.value
	local skillTargets = skillData.target

	local sourceAvatarItem, sourceSkeletonAnimation = self:FindAvatarItem(sourceId)
	if ConfigUtils.IsSkillHasDialog(skillId) and sourceAvatarItem ~= nil then
		local skillDialogItem = nil
		if self._ui.MemberSkillDialogPool.childCount == 0 then
			local skillDialogObj = Helper.NewObject(self._ui.SkillDialogObjectTemplate, self._ui.MemberSkillDialogRoot)
			skillDialogObj.name = "SkillDialog"
			skillDialogItem = skillDialogObj.transform
		else
			skillDialogItem = self._ui.MemberSkillDialogPool:GetChild(0)
			skillDialogItem.parent = self._ui.MemberSkillDialogRoot
			skillDialogItem.localScale = Vector3.one
			skillDialogItem.localPosition = Vector3.zero
		end

		local pos = skillDialogItem.localPosition
		pos.x = self._ui.MemberSkillDialogRoot:InverseTransformPoint(sourceAvatarItem.position).x
		skillDialogItem.localPosition = pos

		local skillDescLabel = skillDialogItem:Find("Label"):GetComponent("UILabel")
		skillDescLabel.text = ConfigUtils.GetSkillDialog(skillId)

		local skillDialogAnimator = skillDialogItem:GetComponent("Animator")
		local dialogState = AnimatorState:new(skillDialogAnimator, "Dialog", nil, skillDialogItem.gameObject)
		dialogState:ActionOnExit(CharacterSelectBaseCtrl.RecycleSkillDialog, self, skillDialogItem)

		local skillAnimationName = self:GetSkillAnimation(sourceId)
		if sourceSkeletonAnimation ~= nil and skillAnimationName ~= nil then
			Helper.PlayAnimation(sourceSkeletonAnimation, skillAnimationName, false)
			Helper.AddAnimation(sourceSkeletonAnimation, CharacterAnimations.Idle, true)
		end

		if state == nil then
			state = ParallelState:new()
		end
		state:Push(dialogState)
	end

	local skillHintPrefabName = ConfigUtils.GetSkillEffectPrefab(skillId)
	if skillHintPrefabName ~= nil then
		for idx = 1, #skillTargets do
			local targetId = skillTargets[idx]
			local targetAvatarItem = self:FindAvatarItem(targetId)
			if targetAvatarItem ~= nil then
				local skillHintItem = self._ui.MemberSkillHintPool:Find(skillHintPrefabName)
				if skillHintItem == nil then
					local skillHintPrefab = self:DynamicLoadAsset(Const.SkillEffectBundleName, skillHintPrefabName)
					local skillHintObj = Helper.NewObject(skillHintPrefab, self._ui.MemberSkillHintRoot)
					skillHintObj.name = skillHintPrefabName
					skillHintItem = skillHintObj.transform
				else
					skillHintItem.parent = self._ui.MemberSkillHintRoot
					skillHintItem.localScale = Vector3.one
					skillHintItem.localPosition = Vector3.zero
				end

				local pos = self._ui.MemberSkillHintRoot:InverseTransformPoint(targetAvatarItem.position)
				pos.z = 0
				skillHintItem.localPosition = pos

				-- real info
				self:ConstructSkillHintItem(skillData, skillHintItem)

				local skillEffectSkeleton1 = skillHintItem:Find("SkillEffect_1"):GetComponent("SkeletonAnimation")
				Helper.PlayAnimation(skillEffectSkeleton1, "SkillEffect", false)
				local skillEffectSkeleton2 = skillHintItem:Find("SkillEffect_2"):GetComponent("SkeletonAnimation")
				Helper.PlayAnimation(skillEffectSkeleton2, "SkillEffect", false)

				local skillHintAnimator = skillHintItem:GetComponent("Animator")
				local childState = AnimatorState:new(skillHintAnimator, "SkillEffect", nil, skillHintItem.gameObject)
				childState:ActionOnEnter(CharacterSelectBaseCtrl.PlaySoundEffect, self, SoundNames.BattleCommonSkillEffect)
				childState:ActionOnExit(CharacterSelectBaseCtrl.RecycleSkillHint, self, skillHintItem)

				if state == nil then
					state = ParallelState:new()
				end
				state:Push(childState)
			end
		end
	end

	return state
end

function CharacterSelectBaseCtrl:PlaySoundEffect(soundName)
	if self._muteSound then
		return
	end

	self._soundCount = self._soundCount + 1
	SoundSystem.PlaySoundOfName(soundName, 1 / self._soundCount)
end

function CharacterSelectBaseCtrl:ConstructSkillHintItem(skillData, skillHintItem)
	local skillId = skillData.id
	local skillValue = skillData.value
	local matchCount = skillData.matchCount

	local iconNumRoot = skillHintItem:Find("Hint/IconNum")
	local numRoot = skillHintItem:Find("Hint/Num")

	local effectAttribute = ConfigUtils.GetSkillEffectAttribute(skillId)
	if effectAttribute == EffectAttribute.Ability or 
		effectAttribute == EffectAttribute.DamageToElement or 
		effectAttribute == EffectAttribute.DamageFromElement then

		iconNumRoot.gameObject:SetActive(true)
		numRoot.gameObject:SetActive(false)

		local finalValue = skillValue
		if ConfigUtils.IsSkillMultiCount(skillId) then
			finalValue = skillValue * matchCount
		end

		local iconName, valueText = UIHelper.GetSkillHintWithIcon(skillId, finalValue)

		local icon = iconNumRoot:Find("Icon"):GetComponent("UISprite")
		local valueLabel = iconNumRoot:Find("Value"):GetComponent("UILabel")

		icon.spriteName = iconName
		valueLabel.text = valueText
	elseif effectAttribute == EffectAttribute.FightPower then
		iconNumRoot.gameObject:SetActive(false)
		numRoot.gameObject:SetActive(true)

		local valueLabel = numRoot:Find("Value"):GetComponent("UILabel")
		valueLabel.text = SAFE_LOC("loc_skillhint_fightpower")..UIHelper.GetSkillHintValueOnly(skillId, skillValue)
	else
		iconNumRoot.gameObject:SetActive(false)
		numRoot.gameObject:SetActive(true)

		local valueLabel = numRoot:Find("Value"):GetComponent("UILabel")
		valueLabel.text = UIHelper.GetSkillShowText(skillId, skillValue)
	end
end

function CharacterSelectBaseCtrl:FindAvatarItem(memberId)
	if memberId == nil then
		return nil
	end

	for idx = 1, #self._selectedCharacters do
		if self._selectedCharacters[idx].id == memberId then
			return self._selectedCharacters[idx].item, self._selectedCharacters[idx].skeletonAnimation
		end
	end

	return nil
end

function CharacterSelectBaseCtrl:RecycleSkillDialog(item)
	item.parent = self._ui.MemberSkillDialogPool
end

function CharacterSelectBaseCtrl:RecycleSkillHint(item)
	item.parent = self._ui.MemberSkillHintPool
	self._soundCount = math.max(0, self._soundCount - 1)
end
--------------------------------------------------------------------------------------
-- character
function CharacterSelectBaseCtrl:MoveCharacter(deltaTime, idx)
	if self._selectedCharacters[idx].moving then
		local target = self._selectedCharacters[idx].target
		local cur = self._selectedCharacters[idx].item.localPosition
		if Helper.PointCloseEnough(target, cur, 8) then
			--cur.x = target.x
			--cur.y = target.y
			self._selectedCharacters[idx].moving = false
			self:PlayCharacterAnimation(idx, CharacterAnimations.Idle, true)
			Helper.CheckDirection(self._selectedCharacters[idx].item, 1)
		else
			local dir = target - cur
			dir.z = 0 -- ignore z value
			dir:SetNormalize()
			
			cur.x = cur.x + dir.x * MOVE_SPEED * deltaTime
			cur.y = cur.y + dir.y * MOVE_SPEED * deltaTime
		end

		cur.z = cur.y
		self._selectedCharacters[idx].item.localPosition = cur
	end
end

function CharacterSelectBaseCtrl:GetExploreCharacterIdx(characterId)
	for idx = 1, #self._selectedCharacters do
		if self._selectedCharacters[idx].id == characterId then
			return idx
		end
	end

	return nil
end

function CharacterSelectBaseCtrl:IsCharacterSelected(characterId)
	return self:GetExploreCharacterIdx(characterId) ~= nil
end

function CharacterSelectBaseCtrl:RefreshGridItemSelectedState(itemId, selected)
	local gridItem = self._ui.ItemGrid:Find(itemId)
	if gridItem ~= nil then
		local selectedMark = gridItem:Find("Mark/Select").gameObject
		selectedMark:SetActive(selected)
	end
end

function CharacterSelectBaseCtrl:RefreshCharacterStatus(characterItem, itemId)
	local canSelect, failReason = self:CanSelectCharacter(itemId)
	local statusMark = characterItem:Find("Mark/Status").gameObject
	statusMark:SetActive(not canSelect)
	if not canSelect then
		local statusLabel = statusMark.transform:Find("Label"):GetComponent("UILabel")
		statusLabel.text = UIHelper.GetSelectionFailReasonShowText(failReason)
	end
end

function CharacterSelectBaseCtrl:RefreshPetStatus(itemId)
	local petItem = self._ui.ItemGrid:Find(itemId)
	if petItem ~= nil then
		local canSelect, failReason = self:CanSelectPet(itemId)
		local statusMark = petItem:Find("Mark/Status").gameObject
		statusMark:SetActive(not canSelect)
		if not canSelect then
			local statusLabel = statusMark.transform:Find("Label"):GetComponent("UILabel")
			statusLabel.text = UIHelper.GetSelectionFailReasonShowText(failReason)
		end
	end
end

function CharacterSelectBaseCtrl:CheckCanSelectCharacter(characterId)
	return self:CanSelectCharacter(characterId)
end

function CharacterSelectBaseCtrl:CheckCanSelectPet(petId)
	return self:CanSelectPet(petId)
end

function CharacterSelectBaseCtrl:CanSelectCharacter(characterId)
	local selectableCharacterMap = self:GetCharacterSelectableMap()
	if not selectableCharacterMap[characterId] then
		return false, SelectionFailReason.BreakRule
	end

	local isBusy, characterStatus = GameData.IsBusyCharacter(characterId, self._characterSelectMode)
	if isBusy then
		if characterStatus == CharacterSelectMode.Explore then
			return false, SelectionFailReason.ExploreMember
		elseif characterStatus == CharacterSelectMode.ActivityExplore then
			return false, SelectionFailReason.ActivityExploreMember
		elseif characterStatus == CharacterSelectMode.WorkShop then
			return false, SelectionFailReason.WorkShopMember
		else
			assert(false, "un-handled busy character status")
		end
	end

	return true
end

function CharacterSelectBaseCtrl:CanSelectPet(petId)
	local isBusy, petStatus = GameData.IsBusyPet(petId, self._characterSelectMode)
	if isBusy then
		if petStatus == CharacterSelectMode.Explore then
			return false, SelectionFailReason.ExploreMember
		elseif petStatus == CharacterSelectMode.ActivityExplore then
			return false, SelectionFailReason.ActivityExploreMember
		elseif petStatus == CharacterSelectMode.WorkShop then
			return false, SelectionFailReason.WorkShopMember
		else
			assert(false, "un-handled busy character status")
		end
	end

	return true
end

function CharacterSelectBaseCtrl:NotifyCharacterFull()
	for idx = 1, #self._ui.CharacterPositionHint do
		local itemObj = self._ui.CharacterPositionHint[idx].item.gameObject
		if itemObj.activeSelf then
			local animator = self._ui.CharacterPositionHint[idx].animator
			animator:Play("PositionHint", 0, 0)
		end
	end
end

function CharacterSelectBaseCtrl:CreateNewCharacterObj(characterId)
	local characterObj = Helper.NewObject(self._ui.CharacterObjectTemplate, self._ui.CharacterRoot)
	characterObj.name = tostring(characterId)
	characterObj:SetActive(true)
	characterItem = characterObj.transform

	local prefabName, prefabBundle = ConfigUtils.GetCharacterPrefab(characterId)
	local prefab = self:DynamicLoadAsset(prefabBundle, prefabName)
	local avatarRoot = characterItem:Find("Avatar")
	local characterAvatarObj = Helper.NewObject(prefab, avatarRoot, 50)

	CtrlManager.AddClick(self, characterObj)
	CtrlManager.AddPress(self, characterObj)

	return characterItem
end

function CharacterSelectBaseCtrl:RemoveExploreCharacterAt(idx)
	local preNum = #self._selectedCharacters
	local characterId = self._selectedCharacters[idx].id
	local characterItem = self._ui.CharacterRoot:Find(characterId)

	if characterItem ~= nil then
		characterItem.parent = self._ui.CharacterPool
	else
		assert(false, "can't find character item of: "..tostring(characterId))
	end

	table.remove(self._selectedCharacters, idx)

	local startIdx = idx
	for moveIdx = startIdx, preNum - 1 do
		self:NotifyCharacterMove(moveIdx)
	end

	self:RefreshGridItemSelectedState(characterId, false)
	self:OnSelectedCharacterChanged(true)
end

function CharacterSelectBaseCtrl:AppendExploreCharacter(characterId)
	local characterItem = self._ui.CharacterPool:Find(characterId)
	if characterItem == nil then
		characterItem = self:CreateNewCharacterObj(characterId)
	else
		characterItem.parent = self._ui.CharacterRoot
	end

	Helper.CheckDirection(characterItem, 1)
	local skeletonAnimation = characterItem:Find("Avatar"):GetChild(0):GetComponent("SkeletonAnimation")
	table.insert(self._selectedCharacters, {id = characterId, item = characterItem, skeletonAnimation = skeletonAnimation})
	self:PlayCharacterAnimation(#self._selectedCharacters, CharacterAnimations.Idle, true)
	-- skin
	UIHelper.SetCharacterSkin(skeletonAnimation, characterId)

	local curNum = #self._selectedCharacters
	characterItem.localPosition = self:GetCharacterSettingPosition(curNum)

	self:RefreshGridItemSelectedState(characterId, true)
	self:OnSelectedCharacterChanged(true, characterId)
end

function CharacterSelectBaseCtrl:OnItemUpdate(itemObj, itemIndex, itemRealIndex)
	itemRealIndex = itemRealIndex + 1
	if itemRealIndex <= 0 or itemRealIndex > #self._itemList then
		itemObj:SetActive(false)
	else
		itemObj:SetActive(true)
		local itemId = self._itemList[itemRealIndex]
		itemObj.name = itemId
		local item = itemObj.transform
		-- construct item
		self:ConstructGridItem(item, itemId)
	end
end

function CharacterSelectBaseCtrl:RefreshCharacterAbilities()
	-- implement in child ctrl
end

function CharacterSelectBaseCtrl:NotifyCharacterMove(idx)
	local targetPosition = self:GetCharacterSettingPosition(idx)
	self._selectedCharacters[idx].moving = true
	self._selectedCharacters[idx].target = targetPosition
	self:PlayCharacterAnimation(idx, CharacterAnimations.Walk, true)

	local curPosition = self._selectedCharacters[idx].item.localPosition
	local diff = targetPosition - curPosition
	Helper.CheckDirection(self._selectedCharacters[idx].item, diff.x)
end

function CharacterSelectBaseCtrl:GetCharacterSettingPosition(idx)
	local pos = self._ui.CharacterPositions[idx]
	pos.z = pos.y
	return pos
end

function CharacterSelectBaseCtrl:GetSelectedCharacterList()
	local ret = {}
	for idx = 1, #self._selectedCharacters do
		local itemId = self._selectedCharacters[idx].id
		table.insert(ret, itemId)
	end

	return ret
end

function CharacterSelectBaseCtrl:GetSelectedCharacterNum()
	return #self._selectedCharacters
end

function CharacterSelectBaseCtrl:RefreshCharacterPositionHint()
	local pet = self:GetSelectedPet()
	if self:HasPetPositionHint() then
		if self._PetPositionHint then
			UIHelper.ConstructExploreItemPositionHint(self._PetPositionHint, pet ~= nil, pet)
		end
		if self._CharacterPositionHint then
			for idx = 1, #self._CharacterPositionHint do
				local characterId = self._selectedCharacters[idx] and self._selectedCharacters[idx].id or nil
				UIHelper.ConstructExploreItemPositionHint(self._CharacterPositionHint[idx], idx<= #self._selectedCharacters, characterId)
			end
		end
	else
		if self._CharacterPositionHint then
			for idx = 1, #self._CharacterPositionHint do
				local activeMark = self._CharacterPositionHint[idx].mark
				activeMark:SetActive(idx <= #self._selectedCharacters)
			end
		end
	end

end

function CharacterSelectBaseCtrl:PlayCharacterAnimation(idx, animation, loop)
	Helper.PlayAnimation(self._selectedCharacters[idx].skeletonAnimation, animation, loop)
end

-- skills not to specific character but the while scope, like explore time
function CharacterSelectBaseCtrl:GetSkillListToScope()
	return {}
end

function CharacterSelectBaseCtrl:GetSkillMapOfMembers()
	return {}
end

function CharacterSelectBaseCtrl:GetCouplesOfMembers()
	local characters = self:GetSelectedCharacterList()
	return self:GetCouplesByCharacters(characters)
end

function CharacterSelectBaseCtrl:GetCouplesByCharacters(characters)
	local ret = {}

	for k, coupleId in pairs(self._availableCoupleList) do
		local matched = GameData.IsCoupleMatched(coupleId, characters)
		if matched then
			table.insert(ret, coupleId)
		end
	end

	return ret
end

function CharacterSelectBaseCtrl:MatchableAbilityMap()
	return {}
end

function CharacterSelectBaseCtrl:IsScopeSkillExist(skillId, sourceId)
	for idx = 1, #self._scopeSkillList do
		if self._scopeSkillList[idx].id == skillId and self._scopeSkillList[idx].source == sourceId then
			return true
		end
	end

	return false
end

function CharacterSelectBaseCtrl:IsMemberSkillExist(skillId, sourceId)
	if self._memberSkillMap[sourceId] == nil then
		return false
	end

	local skillList = self._memberSkillMap[sourceId]
	for idx = 1, #skillList do
		if skillList[idx].id == skillId then
			return true
		end
	end

	return false
end

function CharacterSelectBaseCtrl:ShouldShowMemberSkill(skillId, filterAttributes)
	if ConfigUtils.IsBattleRoundSkill(skillId) then
		return false
	end

	local effectAttribute = ConfigUtils.GetSkillEffectAttribute(skillId)
	if filterAttributes[effectAttribute] == nil then
		return false
	end

	if effectAttribute == EffectAttribute.Ability then
		local effectRange = ConfigUtils.GetSkillEffectRange(skillId)
		local effectCondition = ConfigUtils.GetSkillEffectCondition(skillId)
		if effectRange.EffectScope == EffectScope.Self and effectCondition == nil then
			return false
		end

		local showAbilityMap = self:MatchableAbilityMap()
		local effectParameter = ConfigUtils.GetSkillEffectParameter(skillId)
		local effectValue = effectParameter.EffectValue
		if showAbilityMap[effectValue] == nil then
			return false
		end
	end

	return true
end

function CharacterSelectBaseCtrl:IsMemberStillSelected(memberId)
	if memberId == nil then
		return false
	end

	for idx = 1, #self._selectedCharacters do
		if self._selectedCharacters[idx].id == memberId then
			return true
		end
	end

	return false
end

function CharacterSelectBaseCtrl:RecycleMemberSkillHints()
	local memberToRemove = {}
	for memberId, _ in pairs(self._memberSkillsToHint) do
		if not self:IsMemberStillSelected(memberId) then
			memberToRemove[memberId] = 1
		end
	end
	-- do remove
	for memberId, _ in pairs(memberToRemove) do
		self._memberSkillsToHint[memberId] = {}
	end
	-- check the self skills
	for memberId, v in pairs(self._memberSkillsToHint) do
		for idx = 1, #v do
			local data = v[idx]
			if data.isSelf then
				for m = #data.skills, 1, -1 do
					local sourceId = data.skills[m].source
					if memberToRemove[sourceId] ~= nil then
						table.remove(data.skills, m)
					end
				end
			end
		end
	end
end

function CharacterSelectBaseCtrl:OnSelectedCharacterChanged(hintSkill, newCharacterId)
	if hintSkill then
		local scopeSkillList = self:GetSkillListToScope()
		for idx = 1, #scopeSkillList do
			local skillId = scopeSkillList[idx].id
			local skillValue = scopeSkillList[idx].value
			local source = scopeSkillList[idx].source
			if not self:IsScopeSkillExist(skillId, source) then
				table.insert(self._scopeSkillsToHint, {id = skillId, value = skillValue, source = source})
			end
		end

		-- cancel all the current hints
		self:RecycleMemberSkillHints()

		local checkNewCharacter = ConfigUtils.IsValidItem(newCharacterId)
		local newCharacterSkills = {}

		local memberSkillMap = self:GetSkillMapOfMembers()
		for memberId, skillList in pairs(memberSkillMap) do
			for idx = 1, #skillList do
				local skillId = skillList[idx].id
				local skillValue = skillList[idx].value
				local skillTargets = skillList[idx].target
				local matchCount = skillList[idx].matchCount
				if not self:IsMemberSkillExist(skillId, memberId) then
					if self._memberSkillsToHint[memberId] == nil then
						self._memberSkillsToHint[memberId] = {}
					end

					table.insert(self._memberSkillsToHint[memberId], {id = skillId, value = skillValue, matchCount = matchCount, target = skillTargets})
				end

				-- 1. valid new character id
				-- 2. skills not from himself
				-- 3. skill target contains the new character
				if checkNewCharacter and memberId ~= newCharacterId and Helper.TableContains(skillTargets, newCharacterId) then
					table.insert(newCharacterSkills, {id = skillId, value = skillValue, matchCount = matchCount, source = memberId})
				end
			end
		end

		if #newCharacterSkills > 0 then
			if self._memberSkillsToHint[newCharacterId] == nil then
				self._memberSkillsToHint[newCharacterId] = {}
			end

			table.insert(self._memberSkillsToHint[newCharacterId], {isSelf = true, skills = newCharacterSkills})
		end

		-- when use team, we don't want to hint the couple one by one; show them all
		if not self._suspendCoupleHint then
			self:CheckCouplesToHint()
		end

		self._scopeSkillList = scopeSkillList
		self._memberSkillMap = memberSkillMap
	else
		self._scopeSkillList = self:GetSkillListToScope()
		self._memberSkillMap = self:GetSkillMapOfMembers()
		self._coupleList = self:GetCouplesOfMembers()
	end

	if not self._suspendCoupleHint then
		self:RefreshCharacterAbilities()
		self:RefreshCharacterPositionHint()
	end
end

function CharacterSelectBaseCtrl:CheckCouplesToHint()
	-- couple list
	local coupleListToHint = {}
	local coupleList = self:GetCouplesOfMembers()
	for idx = 1, #coupleList do
		local coupleId = coupleList[idx]
		if not Helper.TableContains(self._coupleList, coupleId) then
			table.insert(coupleListToHint, coupleId)
		end
	end
	-- show hint
	if #coupleListToHint > 0 then
		self:ShowCoupleHints(coupleListToHint)
	end

	self._coupleList = coupleList
end

function CharacterSelectBaseCtrl:OnCharacterSkinChanged(characterId)
	-- change skin
	local characterItem = self._ui.CharacterRoot:Find(characterId)
	if characterItem ~= nil then
		local skeletonAnimation = characterItem:Find("Avatar"):GetChild(0):GetComponent("SkeletonAnimation")
		UIHelper.SetCharacterSkin(skeletonAnimation, characterId)
	end

	self:DoRefreshInternal(characterId)
end

function CharacterSelectBaseCtrl:OnCharacterLevelChanged(characterId)
	self:DoRefreshInternal(characterId)
end

function CharacterSelectBaseCtrl:OnCharacterStageChanged(characterId)
	self:DoRefreshInternal(characterId)
end

function CharacterSelectBaseCtrl:OnCharacterEquipmentUpgraded(characterId)
	self:DoRefreshInternal(characterId)
end

function CharacterSelectBaseCtrl:DoRefreshInternal(characterId)
	-- do update
	_characterAbilityMap[characterId] = GameData.GetCharacterAbilityMap(characterId)

	if self._currentMode == ExploreSelectionMode.Character then
		local characterItem = self._ui.ItemGrid:Find(characterId)
		if characterItem ~= nil then
			self:ConstructCharacterItem(characterItem, characterId)
		end
	elseif self._currentMode == ExploreSelectionMode.Team then
		for idx = 1, #self._itemList do
			local characters = self._itemList[idx].characters
			local characterIdx = Helper.IndexOfArray(characters, characterId)
			if characterIdx ~= nil then
				local teamItem = self._ui.TeamGrid:GetChild(idx - 1)
				local characterRoot = teamItem:Find("Characters")
				local characterItem = characterRoot:GetChild(characterIdx - 1)
				self:ConstructTeamCharacter(characterItem, characterId)
			end
		end
	elseif self._currentMode == ExploreSelectionMode.Couple then
		for idx = 1, #self._itemList do
			local coupleId = self._itemList[idx]
			local conditionList = ConfigUtils.GetCoupleConditions(coupleId)
			local characterIdx = self:GetCharacterIndexInCouple(coupleId, characterId)
			if characterIdx ~= nil then
				local coupleItem = self._ui.CoupleGrid:Find(coupleId)
				local conditionRoot = coupleItem:Find("Conditions")
				local conditionItem = conditionRoot:GetChild(characterIdx - 1)
				self:ConstructCoupleConditionItem(conditionItem, conditionList[characterIdx])
			end
		end
	end

	-- refresh ability
	if self:IsMemberStillSelected(characterId) then
		self:OnSelectedCharacterChanged(false)
	end
end
--------------------------------------------------------------------------------------
-- team
function CharacterSelectBaseCtrl:SetupTeamGrid(doReset)
	-- reset the mode
	if doReset then
		self._teamMode = TeamEditMode.Normal
	end

	if self._ui.TeamGrid.childCount == 0 then
		for idx = 1, MAX_TEAM_COUNT do
			local teamItemObj = Helper.NewObject(self._teamSelectItemPrefab, self._ui.TeamGrid)
			teamItemObj.name = tostring(idx)
			teamItemObj:SetActive(true)
			CtrlManager.AddClick(self, teamItemObj)

			local teamItem = teamItemObj.transform
			local buttonReplace = teamItem:Find("ButtonReplace").gameObject
			local buttonSave = teamItem:Find("ButtonSave").gameObject
			local buttonMoveUp = teamItem:Find("ButtonMoveUp").gameObject
			local buttonMoveDown = teamItem:Find("ButtonMoveDown").gameObject
			local buttonDelete = teamItem:Find("ButtonDelete").gameObject
			local buttonRename = teamItem:Find("ButtonRename").gameObject
			CtrlManager.AddClick(self, buttonReplace)
			CtrlManager.AddClick(self, buttonSave)
			CtrlManager.AddClick(self, buttonMoveUp)
			CtrlManager.AddClick(self, buttonMoveDown)
			CtrlManager.AddClick(self, buttonDelete)
			CtrlManager.AddClick(self, buttonRename)
		end

		self._ui.TeamScrollView:ResetPosition()
	end

	for idx = 1, self._ui.TeamGrid.childCount do
		local item = self._ui.TeamGrid:GetChild(idx - 1)
		self:ConstructTeamItem(item, idx)
	end
end

function CharacterSelectBaseCtrl:ConstructTeamItem(item, idx)
	local isEmpty = true

	local petId = nil
	local characters = {}
	local teamName = nil
	if idx <= #self._itemList then
		petId = self._itemList[idx].pet
		characters = self._itemList[idx].characters
		teamName = self._itemList[idx].name
	end
	-- name
	local nameLabel = item:Find("Name"):GetComponent("UILabel")
	if Helper.IsEmptyOrNull(teamName) then
		nameLabel.text = tostring("队伍 - "..tostring(idx))
	else
		nameLabel.text = teamName
	end
	-- pet - workshop team has no pet
	local petItem = item:Find("Pet")
	if petItem ~= nil then
		local isPetValid = ConfigUtils.IsValidItem(petId)
		petItem.gameObject:SetActive(isPetValid)
		if isPetValid then
			self:ConstructTeamPet(petItem, petId)
			isEmpty = false
		end
	end
	-- characters
	local characterRoot = item:Find("Characters")
	for m = 1, characterRoot.childCount do
		local isCharacterValid = (m <= #characters)
		local characterItem = characterRoot:GetChild(m - 1)
		characterItem.gameObject:SetActive(isCharacterValid)

		if isCharacterValid then
			local characterId = characters[m]
			self:ConstructTeamCharacter(characterItem, characterId)
			isEmpty = false
		end
	end
	-- buttons
	local buttonReplace = item:Find("ButtonReplace").gameObject
	local buttonSave = item:Find("ButtonSave").gameObject
	local buttonMoveUp = item:Find("ButtonMoveUp").gameObject
	local buttonMoveDown = item:Find("ButtonMoveDown").gameObject
	local buttonDelete = item:Find("ButtonDelete").gameObject
	local emptyMark = item:Find("EmptyMark").gameObject
	buttonReplace:SetActive(self._teamMode == TeamEditMode.Normal and not isEmpty)
	buttonSave:SetActive(self._teamMode == TeamEditMode.Normal and isEmpty)
	buttonMoveUp:SetActive(self._teamMode == TeamEditMode.Sort and not isEmpty)
	buttonMoveDown:SetActive(self._teamMode == TeamEditMode.Sort and not isEmpty)
	buttonDelete:SetActive(self._teamMode == TeamEditMode.Delete and not isEmpty)
	emptyMark:SetActive(self._teamMode ~= TeamEditMode.Normal and isEmpty)
	-- power - workshop team no need to show 
	local powerRoot = item:Find("Power")
	if powerRoot ~= nil then
		local powerLabel = powerRoot:Find("Num"):GetComponent("UILabel")
		local coupleList = self:GetCouplesByCharacters(characters)
		local globalBuffList = self:GetArenaAndCoupleSkillsInternal(coupleList, self._arenaId)
		local finalFightPower = self:CalculateFightPower(characters, petId, globalBuffList)
		powerLabel.text = tostring(finalFightPower)
	end
end

function CharacterSelectBaseCtrl:ConstructTeamPet(petItem, petId)
	local icon = petItem:Find("Icon"):GetComponent("UISprite")
	local element = petItem:Find("Element"):GetComponent("UISprite")
	local level = petItem:Find("Level"):GetComponent("UILabel")
	-- base info
	UIHelper.SetCharacterIcon(self, icon, petId)
	element.spriteName = ConfigUtils.GetElementIconOfItem(petId)
	local petLevel = GameData.GetPetLevel(petId)
	level.text = string.format(SAFE_LOC("loc_SimpleLevel"), petLevel)
	-- status
	self:RefreshTeamPetStatus(petItem, petId)
end

function CharacterSelectBaseCtrl:RefreshTeamPetStatus(petItem, petId)
	local canSelect, failReason = self:CanSelectPet(petId)
	local statusMark = petItem:Find("Mark/Status").gameObject
	statusMark:SetActive(not canSelect)
	if not canSelect then
		local statusLabel = statusMark.transform:Find("Label"):GetComponent("UILabel")
		statusLabel.text = UIHelper.GetSelectionFailReasonShowText(failReason)
	end
end

function CharacterSelectBaseCtrl:ConstructTeamCharacter(characterItem, characterId)
	local icon = characterItem:Find("Icon"):GetComponent("UISprite")
	local element = characterItem:Find("Element"):GetComponent("UISprite")
	local level = characterItem:Find("Level"):GetComponent("UILabel")
	-- base info
	UIHelper.SetCharacterIcon(self, icon, characterId)
	element.spriteName = ConfigUtils.GetElementIconOfItem(characterId)
	local characterLevel = GameData.GetCharacterLevel(characterId)
	level.text = string.format(SAFE_LOC("loc_SimpleLevel"), characterLevel)
	-- status
	self:RefreshCharacterStatus(characterItem, characterId)
end

function CharacterSelectBaseCtrl:IsValidTeam(idx)
	if idx > #self._itemList then
		return false
	end

	local petId = self._itemList[idx].pet
	if ConfigUtils.IsValidItem(petId) then
		return true
	end

	local characters = self._itemList[idx].characters
	if #characters > 0 then
		return true
	end

	return false
end

function CharacterSelectBaseCtrl:StartSortTeam()
	self._teamMode = TeamEditMode.Sort
	self._teamDirty = false
	self._ui.ButtonTeamSort:SetActive(false)
    self._ui.ButtonTeamSortConfirm:SetActive(true)
	self:SetupTeamGrid(false)
end

function CharacterSelectBaseCtrl:StartDeleteTeam()
	self._teamMode = TeamEditMode.Delete
	self._teamDirty = false
	self._ui.ButtonTeamDelete:SetActive(false)
    self._ui.ButtonTeamDeleteConfirm:SetActive(true)
	self:SetupTeamGrid(false)
end

function CharacterSelectBaseCtrl:IsTwoSameTeam(team1, team2)
	if team1.pet ~= team2.pet then
		return false
	end

	if #team1.characters ~= #team2.characters then
		return false
	end

	for idx = 1, #team1.characters do
		if team1.characters[idx] ~= team2.characters[idx] then
			return false
		end
	end

	return true
end

function CharacterSelectBaseCtrl:GetFinalTeamList()
	local ret = {}

	for idx = 1, #self._itemList do
		local characters = self._itemList[idx].characters
		local petId = self._itemList[idx].pet
		local teamName = self._itemList[idx].name or ""

		local members = {}
		Helper.CopyTable(members, characters)

		if ConfigUtils.IsValidItem(petId) then
			table.insert(members, petId)
		end
		-- 假如为空，服务器会认为格式不对
		if #members == 0 then
			members[1] = INVALID_ID
		end

		table.insert(ret, {TeamType = self._teamType, TeamName = teamName, TeamList = members})
	end

	return ret
end

function CharacterSelectBaseCtrl:BackToNormalTeam()
	if self._teamDirty then
		local teamList = self:GetFinalTeamList()
		NetManager.Send("SyncPresetTeamList", {TeamType = self._teamType, TeamList = teamList, IsBack = true}, CharacterSelectBaseCtrl.OnHandleTeamProto, self)
	else
		self:DoBackToNormalTeam()
	end
end

function CharacterSelectBaseCtrl:DoBackToNormalTeam()
	self._teamDirty = false
	self._teamMode = TeamEditMode.Normal
	self._ui.ButtonTeamSort:SetActive(true)
	self._ui.ButtonTeamSortConfirm:SetActive(false)
	self._ui.ButtonTeamDelete:SetActive(true)
	self._ui.ButtonTeamDeleteConfirm:SetActive(false)
	self:SetupTeamGrid(false)
end

function CharacterSelectBaseCtrl:DeleteTeam(idx)
	assert(self._teamMode == TeamEditMode.Delete)
	self._itemList[idx] = {characters = {}}
	
	local item = self._ui.TeamGrid:GetChild(idx - 1)
	self:ConstructTeamItem(item, idx)

	self._teamDirty = true
end

function CharacterSelectBaseCtrl:MoveUpTeam(idx)
	assert(self._teamMode == TeamEditMode.Sort)

	-- the first one can't move up
	if idx == 1 then
		return
	end

	-- if same team no need to move
	local isSame = self:IsTwoSameTeam(self._itemList[idx], self._itemList[idx - 1])
	if isSame then
		return
	end

	local tmp = self._itemList[idx]
	self._itemList[idx] = self._itemList[idx - 1]
	self._itemList[idx - 1] = tmp

	local item = self._ui.TeamGrid:GetChild(idx - 1)
	self:ConstructTeamItem(item, idx)

	item = self._ui.TeamGrid:GetChild(idx - 2)
	self:ConstructTeamItem(item, idx - 1)

	self._teamDirty = true
end

function CharacterSelectBaseCtrl:MoveDownTeam(idx)
	assert(self._teamMode == TeamEditMode.Sort)

	-- the last one can't move down
	if idx == #self._itemList then
		return
	end

	-- if same team no need to move
	local isSame = self:IsTwoSameTeam(self._itemList[idx], self._itemList[idx + 1])
	if isSame then
		return
	end

	local tmp = self._itemList[idx]
	self._itemList[idx] = self._itemList[idx + 1]
	self._itemList[idx + 1] = tmp

	local item = self._ui.TeamGrid:GetChild(idx - 1)
	self:ConstructTeamItem(item, idx)

	item = self._ui.TeamGrid:GetChild(idx)
	self:ConstructTeamItem(item, idx + 1)

	self._teamDirty = true
end

function CharacterSelectBaseCtrl:ReplaceTeam(idx, characters, pet)
	if #characters == 0 and not ConfigUtils.IsValidItem(pet) then
		return
	end

	assert(self._teamMode == TeamEditMode.Normal)
	local newTeam = {characters = characters, pet = pet, }
	local isSame = self:IsTwoSameTeam(self._itemList[idx], newTeam)
	if isSame then
		return
	end

	-- restore name
	newTeam.name = self._itemList[idx].name
	self._itemList[idx] = newTeam
	local item = self._ui.TeamGrid:GetChild(idx - 1)
	self:ConstructTeamItem(item, idx)

	local teamList = self:GetFinalTeamList()
	NetManager.Send("SyncPresetTeamList", {TeamType = self._teamType, TeamList = teamList, IsBack = false}, CharacterSelectBaseCtrl.OnHandleTeamProto, self)
end

function CharacterSelectBaseCtrl:CheckTeamMembers(teamIdx)
	local selectableMembers = {}

	local characters = self._itemList[teamIdx].characters
	local pet = self._itemList[teamIdx].pet
	local hasFailed = false

	if #characters > self._numLimit then
		hasFailed = true
	end

	-- 保证这个插入顺序不要变，决定了在TeamSelect界面的显示顺序
	-- characters
	for idx = 1, #characters do
		local characterId = characters[idx]
		local canSelect = self:CanSelectCharacter(characterId)
		table.insert(selectableMembers, characterId)
		if not canSelect then
			hasFailed = true
		end
	end
	-- pet
	if ConfigUtils.IsValidItem(pet) then
		local canSelect = self:CanSelectPet(pet)
		table.insert(selectableMembers, pet)
		if not canSelect then
			hasFailed = true
		end
	end

	return hasFailed, selectableMembers
end

function CharacterSelectBaseCtrl:UseTeam(teamIdx)
	-- empty team, just return
	if not self:IsValidTeam(teamIdx) then
		SoundSystem.PlayWarningSound()
		return
	end

	local hasFailed, selectableMembers = self:CheckTeamMembers(teamIdx)
	if hasFailed then
		SoundSystem.PlayWarningSound()
		if #selectableMembers == 0 then
			CtrlManager.ShowMessageBox({message = SAFE_LOC("可用人员为空"), single = true})
		else
			CtrlManager.OpenPanel(CtrlNames.TeamSelect, {members = selectableMembers, numLimit = self._numLimit, ctrl = CharacterSelectBaseCtrl, receiver = self})
		end
		return
	end

	SoundSystem.PlayUIClickSound()

	local characters = self._itemList[teamIdx].characters
	local pet = self._itemList[teamIdx].pet
	self:OnTeamSelected(characters, pet, false)
end

function CharacterSelectBaseCtrl:OnTeamSelected(characters, pet, append)
	-- do not show the couple hint
	self._suspendCoupleHint = true
	-- if is not append, remove the current selected members
	if not append then
		for idx = #self._selectedCharacters, 1, -1 do
			self:RemoveExploreCharacterAt(idx)
		end
	end

	for idx = 1, #characters do
		local characterId = characters[idx]
		local selected = self:IsCharacterSelected(characterId)
		if not selected then
			self:AppendExploreCharacter(characterId)
		end
	end

	if not append then
		self:ChangeSelectPet(pet, true)
		XDebug.Log("LZ", "pet:", pet)
	end
	-- cancel the suspend
	self._suspendCoupleHint = false
	-- empty the couple list first
	if not append then
		self._coupleList = {}
	end
	-- show them all
	self:CheckCouplesToHint()

	-- do refresh now
	self:RefreshCharacterAbilities()
	self:RefreshCharacterPositionHint()
end

function CharacterSelectBaseCtrl:RenameTeam(teamIdx)
	if self._teamMode ~= TeamEditMode.Normal then
		SoundSystem.PlayWarningSound()
		return
	end

	SoundSystem.PlayUIClickSound()
	local teamName = self._itemList[teamIdx].name
	CtrlManager.OpenPanel(CtrlNames.TeamModifyName, {name = teamName, index = teamIdx, callback = CharacterSelectBaseCtrl.HandleTeamNameModified, receiver = self})
end

function CharacterSelectBaseCtrl:HandleTeamNameModified(teamIdx, teamName)
	NetManager.Send("ChangeTeamName", {TeamType = self._teamType, TeamNum = teamIdx, TeamName = teamName}, CharacterSelectBaseCtrl.OnHandleTeamProto, self)
end

function CharacterSelectBaseCtrl:OnHandleTeamProto(proto, data, requestData)
	if proto == "SyncPresetTeamList" then
		-- sync data
		GameData.SetPresetTeamOfType(requestData.TeamType, requestData.TeamList)

		if requestData.IsBack then
			self:DoBackToNormalTeam()
		end
	elseif proto == "ChangeTeamName" then
		local teamType = requestData.TeamType
		local teamIdx = requestData.TeamNum
		local teamName = requestData.TeamName
		-- sync data
		GameData.RenameTeamOfType(teamType, teamIdx, teamName)
		self._itemList[teamIdx].name = teamName
		--refresh ui
		local item = self._ui.TeamGrid:GetChild(teamIdx - 1)
		self:ConstructTeamItem(item, teamIdx)
		
	end
end
--------------------------------------------------------------------------------------
function CharacterSelectBaseCtrl:UseCouple(coupleId)
	local conditions = ConfigUtils.GetCoupleConditions(coupleId)
	local characters = {}
	local hasFailed = false
	local selectedNum = self:GetSelectedCharacterNum()

	for idx = 1, #conditions do
		local characterId = conditions[idx].Id
		local skinId = conditions[idx].SkinId
		-- check skin
		if skinId ~= nil then
			local currentSkin = GameData.GetCharacterSkin(characterId)
			if not hasFailed and currentSkin ~= skinId then
				hasFailed = true
			end
		end

		if not hasFailed then
			local canSelect = self:CanSelectCharacter(characterId)
			if not canSelect then
				hasFailed = true
			end
		end

		if hasFailed then
			break
		end
	end

	for idx = 1, #conditions do
		local characterId = conditions[idx].Id
		-- need select
		local isSelected = self:IsCharacterSelected(characterId)
		if not isSelected then
			table.insert(characters, characterId)
		end
	end

	-- all selected and match the conditions
	if #characters == 0 then
		SoundSystem.PlayUIClickSound()
		return
	end

	-- exceed the num limit - failed
	local leftNum = self._numLimit - selectedNum
	if not hasFailed and #characters > leftNum then
		hasFailed = true
	end

	if hasFailed then
		SoundSystem.PlayWarningSound()
		CtrlManager.OpenPanel(CtrlNames.TeamSelect, {members = characters, numLimit = leftNum, couple = coupleId, ctrl = CharacterSelectBaseCtrl, receiver = self})
		return
	end

	SoundSystem.PlayUIClickSound()
	self:OnTeamSelected(characters, nil, true)
end
--------------------------------------------------------------------------------------
function CharacterSelectBaseCtrl:GetCoupleKey()
	return nil
end

function CharacterSelectBaseCtrl:RecycleCoupleHint()
	local num = self._ui.CoupleHintRoot.childCount
	for idx = num, 1, -1 do
		local item = self._ui.CoupleHintRoot:GetChild(idx - 1)
		local avatarRoot = item:Find("Avatar")
		for m = avatarRoot.childCount, 1, -1 do
			local avatarItem = avatarRoot:GetChild(m - 1)
			avatarItem.parent = self._ui.CoupleAvatarPool
		end

		item.parent = self._ui.CoupleHintPool
	end
end

function CharacterSelectBaseCtrl:ShowCoupleHints(coupleList)
	-- do recycle first
	self:RecycleCoupleHint()

	local numToShow = math.min(#coupleList, MAX_COUPLE_NUM)
	for idx = 1, numToShow do
		local coupleId = coupleList[idx]
		local coupleItem = nil
		if self._ui.CoupleHintPool.childCount == 0 then
			local coupleObj = Helper.NewObject(self._coupleItemPrefab, self._ui.CoupleHintRoot)
			coupleItem = coupleObj.transform
		else
			coupleItem = self._ui.CoupleHintPool:GetChild(0)
			coupleItem.parent = self._ui.CoupleHintRoot
			coupleItem.localScale = Vector3.one
		end

		coupleItem.gameObject:SetActive(true)
		coupleItem.gameObject.name = tostring(idx)
		-- do construct
		self:ConstructCoupleHintItem(coupleItem, coupleId)
		-- set position
		UIHelper.PlaceVerticalItemPosition(coupleItem, idx, numToShow, 190)
	end

	self._coupleHintState = TimerState:new(COUPLE_HINT_TIME)
	self._coupleHintState:ActionOnExit(CharacterSelectBaseCtrl.RecycleCoupleHint, self)
end

function CharacterSelectBaseCtrl:ConstructCoupleHintItem(item, coupleId)
	-- name
	local nameLabel = item:Find("Name"):GetComponent("UILabel")
	nameLabel.text = ConfigUtils.GetCoupleName(coupleId)
	-- skill
	local skillDescLabel = item:Find("SkillDesc"):GetComponent("UILabel")
	skillDescLabel.text = ConfigUtils.GetCoupleSkillDesc(coupleId)
	-- avatar
	local avatarRoot = item:Find("Avatar")
	local prefabName, prefabBundle = ConfigUtils.GetCouplePrefabName(coupleId)
	local prefabItem = self._ui.CoupleAvatarPool:Find(prefabName)
    if prefabItem == nil then
        local avatarPrefab = self:DynamicLoadAsset(prefabBundle, prefabName)
        local prefabObj = Helper.NewObject(avatarPrefab, avatarRoot)
        prefabObj:SetActive(true)
        prefabObj.name = prefabName
        prefabItem = prefabObj.transform
    else
        prefabItem.parent = avatarRoot
        prefabItem.localPosition = Vector3.zero
        prefabItem.localScale = Vector3.one
    end
end
--------------------------------------------------------------------------------------
function CharacterSelectBaseCtrl:GetArenaAndCoupleSkills()
	return self:GetArenaAndCoupleSkillsInternal(self._coupleList, self._arenaId, self._fishPoolId)
end

function CharacterSelectBaseCtrl:GetArenaAndCoupleSkillsInternal(coupleList, arenaId, fishPoolId)
	local ret = {}

	for idx = 1, #coupleList do
		local coupleId = coupleList[idx]
		local skillList = ConfigUtils.GetCoupleSkillList(coupleId)
		for m = 1, #skillList do
			local skillId = skillList[m].Id
			local skillValue = skillList[m].Value
			table.insert(ret, {id = skillId, value = skillValue})
		end
	end

	if arenaId ~= nil then
		local skillList = ConfigUtils.GetArenaBuffList(arenaId)
		for m = 1, #skillList do
			local skillId = skillList[m].Id
			local skillValue = skillList[m].Value
			table.insert(ret, { id = skillId, value = skillValue })
		end
	end

	if fishPoolId ~= nil then
		local skillList =GameDataCatchFish.GetFishPoolBuffList(fishPoolId)
		for idx = 1, #skillList do
			local skillId = skillList[idx].Id
			local skillValue = skillList[idx].Value
			table.insert(ret, { id = skillId, value = skillValue })
		end
	end

	return ret
end
--------------------------------------------------------------------------------------
function CharacterSelectBaseCtrl:ShowFilterPanel()
	local params = {
		mode = self._characterSelectMode,
		filterElements = nil,
		filterRarities = nil,
		filterTags = nil,
		filterSkills = nil,
		filterStages = nil,
		numCallback = CharacterSelectBaseCtrl.GetMatchNumByFilter,
		resultCallback = CharacterSelectBaseCtrl.OnGetFilterResult,
		receiver = self,
	}

	if _filterElements ~= nil then
		params.filterElements = Helper.CloneMap(_filterElements)
	end

	if _filterRarities ~= nil then
		params.filterRarities = Helper.CloneMap(_filterRarities)
	end

	if _filterTags ~= nil then
		params.filterTags = Helper.CloneMap(_filterTags)
	end

	if _filterStages ~= nil then
		params.filterStages = Helper.CloneMap(_filterStages)
	end

	if _filterSkills ~= nil then
		params.filterSkills = Helper.CloneMap(_filterSkills)
	end

	CtrlManager.OpenPanel(CtrlNames.CharacterFilter, params)
end

function CharacterSelectBaseCtrl:GetMatchNumByFilter(data)
	local filterElements = data.filterElements
	local filterRarities = data.filterRarities
	local filterTags = data.filterTags
	local filterStages = data.filterStages
	local filterSkills = data.filterSkills

	local itemNum = 0
	local itemList = self:GetItemListOfCurrentMode()
	for idx = 1, #itemList do
		local itemId = itemList[idx]
		if CharacterSelectBaseCtrl.IsItemMatchFilter(itemId, nil, filterElements, filterRarities, filterTags, filterStages, filterSkills) then
			itemNum = itemNum + 1
		end
	end

	return itemNum
end

function CharacterSelectBaseCtrl:OnGetFilterResult(data)
	_filterElements = nil
	_filterRarities = nil
	_filterTags = nil
	_filterSkills = nil
	_filterStages = nil
	_filterName = data.filterName

	if data.filterElements ~= nil then
		_filterElements = Helper.CloneMap(data.filterElements)
	end

	if data.filterRarities ~= nil then
		_filterRarities = Helper.CloneMap(data.filterRarities)
	end

	if data.filterTags ~= nil then
		_filterTags = Helper.CloneMap(data.filterTags)
	end

	if data.filterStages ~= nil then
		_filterStages = Helper.CloneMap(data.filterStages)
	end

	if data.filterSkills ~= nil then
		_filterSkills = Helper.CloneMap(data.filterSkills)
	end
	
	self:OnFilterChanged()
end

function CharacterSelectBaseCtrl:OnFilterChanged()
	self:RecycleGridItems()
    self:OnSelectionModeChanged()
end
--------------------------------------------------------------------------------------
function CharacterSelectBaseCtrl:GetUnlockedCoupleList()
	local ret = {}

	for idx = 1, #self._availableCoupleList do
		local coupleId = self._availableCoupleList[idx]
		local coupleMatched = ConfigUtils.IsCoupleUnlocked(coupleId)
		if coupleMatched then
			table.insert(ret, coupleId)
		end
	end

	return ret
end

function CharacterSelectBaseCtrl:GetItemListOfCurrentMode()
	local ret = {}
	if self._currentMode == ExploreSelectionMode.Character then
		ret = GameData.GetUnlockCharacters()
	elseif self._currentMode == ExploreSelectionMode.Pet then
		ret = GameData.GetUnlockPetList()
    elseif self._currentMode == ExploreSelectionMode.Team then
        ret = GameData.GetTeamGroups(self._teamType)
    elseif self._currentMode == ExploreSelectionMode.Couple then
    	ret = self:GetUnlockedCoupleList()
	else
		assert(false, "un-handled character select mode: "..tostring(self._currentMode))
	end

	return ret
end

function CharacterSelectBaseCtrl:RefreshItemList()
	if self._currentMode == ExploreSelectionMode.Character then
		self:RefreshCharacterList()
	elseif self._currentMode == ExploreSelectionMode.Pet then
		self:RefreshPetList()
    elseif self._currentMode == ExploreSelectionMode.Team then
        self:RefreshTeamList()
    elseif self._currentMode == ExploreSelectionMode.Couple then
    	self:RefreshCoupleList()
	else
		assert(false, "un-handled selection mode: "..tostring(self._currentMode))
	end
end

function CharacterSelectBaseCtrl:RefreshCharacterList()
    local characterList = GameData.GetUnlockCharacters()
    -- check and refresh goal and ability map
    self:InitializeCharacterAbiltiyAndGoalMap(characterList)
    -- set it before filter
    local characterSelectableMap = {}
	for idx = 1, #characterList do
		local characterId = characterList[idx]
		local selectable = ConfigUtils.IsCharacterMatchExploreRules(self._exploreRules, characterId)
		characterSelectableMap[characterId] = selectable
	end
	-- set it before do sort
	CharacterSelectBaseCtrl.SetCharacterSelectableMap(characterSelectableMap)
    -- do filter
    self._itemList = CharacterSelectBaseCtrl.DoItemFilter(characterList)
    -- set it before do sort
    local needMap = ConfigUtils.GetNeedCharacterMap(self._exploreRules)
    CharacterSelectBaseCtrl.SetNeedCharacterMap(needMap)
    -- do sort
	table.sort(self._itemList, _characterSortFunc)
end

function CharacterSelectBaseCtrl:RefreshPetList()
    local petList = GameData.GetUnlockPetList()
    -- check and refresh goal and ability map
    self:InitializePetAbilityAndGoalMap(petList)
    -- do filter
    self._itemList = CharacterSelectBaseCtrl.DoItemFilter(petList)
    -- do sort
    table.sort(self._itemList, _petSortFunc)
end

function CharacterSelectBaseCtrl:RefreshTeamList()
    self._itemList = GameData.GetTeamGroups(self._teamType)
end

function CharacterSelectBaseCtrl:RefreshCoupleList()
	self._itemList = self:GetUnlockedCoupleList()
end

function CharacterSelectBaseCtrl:RefreshButtonState()
	self:SetButtonState(self._ui.ButtonCharacter, self._currentMode ~= ExploreSelectionMode.Character)
	self:SetButtonState(self._ui.ButtonPet, self._currentMode ~= ExploreSelectionMode.Pet)
    self:SetButtonState(self._ui.ButtonTeam, self._currentMode ~= ExploreSelectionMode.Team)
    self:SetButtonState(self._ui.ButtonCouple, self._currentMode ~= ExploreSelectionMode.Couple)
end

function CharacterSelectBaseCtrl:RefreshSortState()
    -- implement in child class
end

function CharacterSelectBaseCtrl:SetButtonState(button, enabled)
	if button == nil then
		return
	end

	button.isEnabled = enabled
	if enabled then
		button.transform.localScale = Vector3.one
	else
		button.transform.localScale = Vector3.New(1.3, 1.3, 1)
	end
end

function CharacterSelectBaseCtrl:OnSelectionModeChanged()
    self._ui.ItemScrollView.gameObject:SetActive(self._currentMode == ExploreSelectionMode.Character or self._currentMode == ExploreSelectionMode.Pet)
    self._ui.TeamScrollView.gameObject:SetActive(self._currentMode == ExploreSelectionMode.Team)
    self._ui.CoupleScrollView.gameObject:SetActive(self._currentMode == ExploreSelectionMode.Couple)
    if self._ui.ButtonSort ~= nil then
    	self._ui.ButtonSort:SetActive(self._currentMode == ExploreSelectionMode.Character or self._currentMode == ExploreSelectionMode.Pet)	
    end
    self._ui.ButtonFilter:SetActive(self._currentMode == ExploreSelectionMode.Character or self._currentMode == ExploreSelectionMode.Pet)
    self._ui.ButtonTeamSort:SetActive(self._currentMode == ExploreSelectionMode.Team)
    self._ui.ButtonTeamDelete:SetActive(self._currentMode == ExploreSelectionMode.Team)
    self._ui.ButtonTeamSortConfirm:SetActive(false)
    self._ui.ButtonTeamDeleteConfirm:SetActive(false)

	self:RefreshItemList()
	self:SetupItemGrid()
    -- button state
	self:RefreshButtonState()
end

function CharacterSelectBaseCtrl:SetupItemGrid()
	if self._currentMode == ExploreSelectionMode.Team then
        self:SetupTeamGrid(true)
    elseif self._currentMode == ExploreSelectionMode.Couple then
    	self:SetupCoupleGrid()
    else
        self:SetupCharacterPetGrid()
    end
end

function CharacterSelectBaseCtrl:SetupCoupleGrid()
	local existCount = self._ui.CoupleGrid.childCount
	if existCount == 0 then
		for idx = 1, #self._itemList do
			local coupleId = self._itemList[idx]
			local itemObj = Helper.NewObject(self._coupleSelectItemPrefab, self._ui.CoupleGrid)
			itemObj:SetActive(true)
			itemObj.name = tostring(coupleId)

			CtrlManager.AddClick(self, itemObj)
		end

		self._ui.CoupleScrollView:ResetPosition()
	end

	for idx = 1, self._ui.CoupleGrid.childCount do
		local coupleId = self._itemList[idx]
		local coupleItem = self._ui.CoupleGrid:GetChild(idx - 1)
		self:ConstructCoupleItem(coupleItem, coupleId)
	end
end

function CharacterSelectBaseCtrl:SetupCharacterPetGrid()
	local itemCount = self._ui.ItemGridWrap.NeedCellCount
	itemCount = math.min(#self._itemList, itemCount)
	self._ui.ItemGridWrap.MaxRow = math.ceil(#self._itemList / self._ui.ItemGridWrap.ColumnLimit)

	local itemPrefab, itemPool = self:GetItemPrefabAndPool()

	for idx = 1, itemCount do
		local itemId = self._itemList[idx]
		local item = nil
		if itemPool.childCount == 0 then
			local itemObj = Helper.NewObject(itemPrefab, self._ui.ItemGrid)
			CtrlManager.AddClick(self, itemObj)
			CtrlManager.AddPress(self, itemObj)
			item = itemObj.transform
		else
			item = itemPool:GetChild(0)
			item.parent = self._ui.ItemGrid
			item.localScale = Vector3.one
		end

		item.gameObject:SetActive(true)
		item.gameObject.name = tostring(itemId)

		-- construct item
		self:ConstructGridItem(item, itemId)
	end

	self._ui.ItemGridWrap:SortBasedOnScrollMovement()
	self._ui.ItemScrollView.restrictWithinPanel = true
	self._ui.ItemScrollView.disableDragIfFits = (#self._itemList <= itemCount)
	self._ui.ItemScrollView:ResetPosition()
end

function CharacterSelectBaseCtrl:ConstructGridItem(item, value)
	if self._currentMode == ExploreSelectionMode.Character then
		self:ConstructCharacterItem(item, value)
	elseif self._currentMode == ExploreSelectionMode.Pet then
    	self:ConstructPetItem(item, value)
	elseif self._currentMode == ExploreSelectionMode.Team then
        self:ConstructTeamItem(item, value)
    elseif self._currentMode == ExploreSelectionMode.Couple then
    	self:ConstructCoupleItem(item, value)
	else
		assert(false, "un-handle selection mode: "..tostring(self._currentMode))    
    end
end

function CharacterSelectBaseCtrl:ConstructCharacterItem(item, itemId)
	-- implement in child class
end

function CharacterSelectBaseCtrl:ConstructPetItem(item, itemId)
	-- implement in child class
end

function CharacterSelectBaseCtrl:ConstructCoupleItem(item, itemId)
	local nameLabel = item:Find("Name"):GetComponent("UILabel")
    nameLabel.text = ConfigUtils.GetCoupleName(itemId)

    local descLabel = item:Find("SkillDesc"):GetComponent("UILabel")
    descLabel.text = ConfigUtils.GetCoupleSkillDesc(itemId)

    local conditionList = ConfigUtils.GetCoupleConditions(itemId)
    local conditionUnlocked = true
    local conditionRoot = item:Find("Conditions")
    for idx = 1, conditionRoot.childCount do
        local hasCondition = (idx <= #conditionList)
        local conditionItem = conditionRoot:GetChild(idx - 1)
        conditionItem.gameObject:SetActive(hasCondition)
        if hasCondition then
            -- construct condition
            self:ConstructCoupleConditionItem(conditionItem, conditionList[idx])
        end
    end

    conditionRoot:GetComponent("UITable"):Reposition()
end

function CharacterSelectBaseCtrl:ConstructCoupleConditionItem(conditionItem, data)
	local characterId = data.Id
    local skinId = data.SkinId

    local currentSkin = GameData.GetCharacterSkin(characterId)
    local showSkinId = currentSkin
    if ConfigUtils.IsValidItem(skinId) then
        showSkinId = skinId
    end
    -- base info
    UIHelper.ConstructCoupleCharacterItem(self, conditionItem, characterId, showSkinId)
    -- status
    self:RefreshCharacterStatus(conditionItem, characterId)
    -- skin lock
    local lockMark = conditionItem:Find("Mark/Lock").gameObject
    lockMark:SetActive(currentSkin ~= showSkinId)
end

function CharacterSelectBaseCtrl:OnMarkStateChanged(itemId, marked)
	local itemType = ConfigUtils.GetItemTypeFromId(itemId)
	if (itemType == ItemType.Character and self._currentMode == ExploreSelectionMode.Character) or 
       (itemType == ItemType.Pet and self._currentMode == ExploreSelectionMode.Pet) then
		-- re-sort
		self:RecycleGridItems()
		self:OnSelectionModeChanged()
	end
end

function CharacterSelectBaseCtrl:GetCharacterIndexInCouple(coupleId, characterId)
	local conditions = ConfigUtils.GetCoupleConditions(coupleId)
	for idx = 1, #conditions do
		if conditions[idx].Id == characterId then
			return idx
		end
	end

	return nil
end

function CharacterSelectBaseCtrl:OnCharacterStatusChanged(itemId)
	if self._currentMode == ExploreSelectionMode.Character then
		local characterItem = self._ui.ItemGrid:Find(itemId)
		if characterItem ~= nil then
			self:RefreshCharacterStatus(characterItem, itemId)
		end
	elseif self._currentMode == ExploreSelectionMode.Team then
		for idx = 1, #self._itemList do
			local characters = self._itemList[idx].characters
			local characterIdx = Helper.IndexOfArray(characters, itemId)
			if characterIdx ~= nil then
				local teamItem = self._ui.TeamGrid:GetChild(idx - 1)
				local characterRoot = teamItem:Find("Characters")
				local characterItem = characterRoot:GetChild(characterIdx - 1)
				self:RefreshCharacterStatus(characterItem, itemId)
			end
		end
	elseif self._currentMode == ExploreSelectionMode.Couple then
		for idx = 1, #self._itemList do
			local coupleId = self._itemList[idx]
			local coupleItem = self._ui.CoupleGrid:Find(coupleId)
			if coupleItem ~= nil then
				local characterIdx = self:GetCharacterIndexInCouple(coupleId, itemId)
				if characterIdx ~= nil then
					local conditionRoot = coupleItem:Find("Conditions")
					local conditionItem = conditionRoot:GetChild(characterIdx - 1)
					self:RefreshCharacterStatus(conditionItem, itemId)
				end
			end
		end
	end
end

function CharacterSelectBaseCtrl:CalculateFightPower(characters, pet, globalBuffList)
    return 0
end

function CharacterSelectBaseCtrl:ChangeSelectPet(newPetId, hintSkill)
	-- workshop no pet
end
--------------------------------------------------------------------------------------