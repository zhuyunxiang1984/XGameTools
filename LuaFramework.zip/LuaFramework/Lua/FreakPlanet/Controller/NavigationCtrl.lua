require "FreakPlanet/View/NavigationPanel"

local class = require "FreakPlanet/Utils/middleclass"
NavigationCtrl  = class(CtrlNames.Navigation, BaseCtrl)

local UPDATE_DURATION = 1

local GOAL_MOVE_VALUE = 500
local GOAL_HOLD_DURATION = 3
local GOAL_MOVE_SPEED = 2000
local GoalMoveState = {
	None = "None",
	MoveIn = "MoveIn",
	Hold = "Hold",
	MoveOut = "MoveOut",
}

-- load the ui prefab
function NavigationCtrl:LoadPanel()
	self:CreatePanel("Navigation")
end

-- construct ui panel data
function NavigationCtrl:ConstructUI(obj)
	self._ui = NavigationPanel.Init(obj)
end

function NavigationCtrl:DestroyImpl()
	GameNotifier.RemoveListener(GameEvent.MoneyChanged, NavigationCtrl.OnMoneyChanged, self)
	GameNotifier.RemoveListener(GameEvent.JumpGoalChanged, NavigationCtrl.OnJumpGoalChanged, self)
end

function NavigationCtrl:SetupUI()
	self._ui.PlayerName.text = GameData.GetDefaultNickName(true)
	self._suspendUpdate = false

	local gold = GameData.GetMoney(ItemType.Gold)
	local diamond = GameData.GetMoney(ItemType.Diamond)

	self._updateList = {}
	self._updateList[ItemType.Gold] = {curNum = gold, targetNum = gold, step = 0, label = self._ui.GoldNum}
	self._updateList[ItemType.Diamond] = {curNum = diamond, targetNum = diamond, step = 0, label = self._ui.DiamondNum}

	-- init ui
	self:SetMoneyNum(ItemType.Gold, gold)
	self:SetMoneyNum(ItemType.Diamond, diamond)
	-- hide default
	self._hintGoal = nil
	self._goalMoveState = GoalMoveState.None
	self._goalHoldTime = 0
	self._goalMoveValue = 0
	self._goalRawPosition = self._ui.GoalRoot.localPosition
	self._ui.GoalInfoRoot:SetActive(false)
	self:SyncGoalTransform()

	CtrlManager.AddClick(self, self._ui.ButtonDiamond)
	CtrlManager.AddClick(self, self._ui.ButtonGold)
	CtrlManager.AddClick(self, self._ui.GoalCollider)

	GameNotifier.AddListener(GameEvent.MoneyChanged, NavigationCtrl.OnMoneyChanged, self)
	GameNotifier.AddListener(GameEvent.JumpGoalChanged, NavigationCtrl.OnJumpGoalChanged, self)
end

function NavigationCtrl:ConstructJumpGoal()
	local goalId = self._hintGoal
	self._ui.GoalEmptyRoot:SetActive(goalId == nil)
	self._ui.GoalDetailRoot:SetActive(goalId ~= nil)
	if goalId ~= nil then
		self:RefreshJumpGoalState()
	end
end

function NavigationCtrl:RefreshJumpGoal()
	local hintGoals = JumpManager.GetHintGoals()
	local goalId = nil
	if #hintGoals > 0 then
		goalId = hintGoals[1]
	else
		goalId = GameData.GetFirstActiveMainGoal()
	end

	self._hintGoal = goalId
	self:ConstructJumpGoal()
end

function NavigationCtrl:RefreshJumpGoalState()
	if self._hintGoal == nil then
		return
	end

	local goalId = self._hintGoal
	local goalType = ConfigUtils.GetGoalType(goalId)
	local goalState, goalNumbers = GameData.GetGoalInfo(goalId)
	-- title
	self._ui.GoalTitle.text = ConfigUtils.GetGoalName(goalId)
	-- conditions
	local goalConditions = ConfigUtils.GetGoalConditions(goalId)
	self._ui.GoalTaskName.text = UIHelper.GetGoalFinalName(goalConditions[1])
	if goalType == GoalType.Achievement then
		local currentNum, totalNum = UIHelper.GetAchievementGoalNum(goalConditions, goalNumbers)
		self._ui.GoalTaskNum.text = UIHelper.GetGoalShowTextWithNum(currentNum, totalNum)
	else
		self._ui.GoalTaskNum.text = UIHelper.GetGoalShowNum(goalConditions[1], goalNumbers[1])
	end
end

-- update per frame
function NavigationCtrl:UpdateImpl(deltaTime)
	if self._suspendUpdate then
		return
	end

	for k, v in pairs(self._updateList) do
		if v.step > 0 then
			local num = math.ceil(v.curNum + v.step * deltaTime)
			v.curNum = math.min(v.targetNum, num)
			self:SetMoneyNum(k, v.curNum)
			if v.curNum >= v.targetNum then
				v.step = 0
			end
		elseif v.step < 0 then
			local num = math.floor(v.curNum + v.step * deltaTime)
			v.curNum = math.max(v.targetNum, num)
			self:SetMoneyNum(k, v.curNum)
			if v.curNum <= v.targetNum then
				v.step = 0
			end
		end
	end

	self:UpdateGoalHint(deltaTime)
end

function NavigationCtrl:UpdateGoalHint(deltaTime)
	if self._goalMoveState == GoalMoveState.MoveIn then
		self._goalMoveValue = self._goalMoveValue - GOAL_MOVE_SPEED * deltaTime
		self._goalMoveValue = math.max(self._goalMoveValue, -GOAL_MOVE_VALUE)
		self:SyncGoalTransform()
		if self._goalMoveValue == -GOAL_MOVE_VALUE then
			self._goalMoveState = GoalMoveState.Hold
			self._goalHoldTime = 0
		end
	elseif self._goalMoveState == GoalMoveState.MoveOut then
		self._goalMoveValue = self._goalMoveValue + GOAL_MOVE_SPEED * deltaTime
		self._goalMoveValue = math.min(self._goalMoveValue, 0)
		self:SyncGoalTransform()
		if self._goalMoveValue == 0 then
			self._goalMoveState = GoalMoveState.None
			self._ui.GoalInfoRoot:SetActive(false)
		end
	elseif self._goalMoveState == GoalMoveState.Hold then
		self._goalHoldTime = self._goalHoldTime + deltaTime
		if self._goalHoldTime >= GOAL_HOLD_DURATION then
			self._goalMoveState = GoalMoveState.MoveOut
		end
	end
end

function NavigationCtrl:SyncGoalTransform()
	local pos = self._ui.GoalRoot.localPosition
	pos.x = self._goalRawPosition.x + self._goalMoveValue
	self._ui.GoalRoot.localPosition = pos
end

function NavigationCtrl:HintGoal()
	if self._goalMoveState == GoalMoveState.MoveOut then
		self._goalMoveState = GoalMoveState.MoveIn
	elseif self._goalMoveState == GoalMoveState.Hold then
		self._goalHoldTime = GOAL_HOLD_DURATION
	elseif self._goalMoveState == GoalMoveState.MoveIn then
		self._goalMoveState = GoalMoveState.MoveOut
	elseif self._goalMoveState == GoalMoveState.None then
		self._goalMoveState = GoalMoveState.MoveIn
		self:RefreshJumpGoal()
		self._ui.GoalInfoRoot:SetActive(true)
	end
end

-- on clicked
function NavigationCtrl:OnClicked(go)
	local ctrl = CtrlManager.GetCtrlByName(CtrlNames.Battle)
	if ctrl ~= nil then
		return true
	end

	if go == self._ui.ButtonDiamond then
		if CtrlManager.GetCtrlByName(CtrlNames.Mall) == nil and
			GameData.IsFirstBranchTutorialFinished() and 
			CtrlManager.CanJump() then
			-- open it
			SoundSystem.PlayMoneySound()
			CtrlManager.OpenPanel(CtrlNames.Mall, {MallModule = EMallModuleNames.MonthCardGift})
		end
	elseif go == self._ui.ButtonGold then
		if CtrlManager.GetCtrlByName(CtrlNames.GoldExchange) == nil and 
			GameData.IsFirstBranchTutorialFinished() and 
			CtrlManager.CanJump() then
			-- open it
			SoundSystem.PlayUIClickSound()
			CtrlManager.OpenPanel(CtrlNames.GoldExchange)
		end
	elseif go == self._ui.GoalCollider then
		SoundSystem.PlayUIClickSound()
		self:HintGoal()
	end

	return true
end

function NavigationCtrl:SetMoneyNum(itemType, num)
	self._updateList[itemType].label.text = tostring(num)
end

function NavigationCtrl:OnMoneyChanged(itemType)
	if self._updateList[itemType] == nil then
		return
	end
	
	local curNum = self._updateList[itemType].curNum
	local newNum = GameData.GetMoney(itemType)

	self._updateList[itemType].targetNum = newNum
	self._updateList[itemType].step = (newNum - curNum) / UPDATE_DURATION
end

function NavigationCtrl:OnJumpGoalChanged()
	self:RefreshJumpGoal()
end

function NavigationCtrl:EnableSuspendInternal(enable)
	self._suspendUpdate = enable
end

function NavigationCtrl:RefreshAccountInfoInternal()
	self._ui.PlayerName.text = GameData.GetDefaultNickName(true)
end

function NavigationCtrl.EnableSuspend(enable)
	local ctrl = CtrlManager.GetCtrlByName(CtrlNames.Navigation)
	if ctrl ~= nil then
		ctrl:EnableSuspendInternal(enable)
	end
end

function NavigationCtrl.RefreshAccountInfo()
	local ctrl = CtrlManager.GetCtrlByName(CtrlNames.Navigation)
	if ctrl ~= nil then
		ctrl:RefreshAccountInfoInternal()
	end
end

function NavigationCtrl:GetGoldPositionInternal()
	return self._ui.Camera:WorldToScreenPoint(self._ui.GoldMark.position)
end

function NavigationCtrl:ShowIapInternal()
	self:OnClicked(self._ui.ButtonDiamond)
end

function NavigationCtrl:ShowOrHideInternal(show)
	self._ui.RootPanel:SetActive(show)
end

function NavigationCtrl.GetGoldPosition()
	local ctrl = CtrlManager.GetCtrlByName(CtrlNames.Navigation)
	if ctrl ~= nil then
		return ctrl:GetGoldPositionInternal()
	end

	return Vector3.zero
end

function NavigationCtrl.ShowIap()
	local ctrl = CtrlManager.GetCtrlByName(CtrlNames.Navigation)
	if ctrl ~= nil then
		ctrl:ShowIapInternal()
	end
end

function NavigationCtrl.ShowOrHide(show)
	local ctrl = CtrlManager.GetCtrlByName(CtrlNames.Navigation)
	if ctrl ~= nil then
		ctrl:ShowOrHideInternal(show)
	end
end