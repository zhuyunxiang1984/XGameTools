require "FreakPlanet/View/SpaceTravelGoodsActionPanel"

local class = require "FreakPlanet/Utils/middleclass"
SpaceTravelGoodsActionCtrl  = class(CtrlNames.SpaceTravelGoodsAction, BaseCtrl)

local ActionState = {
    None = "None",
    Use = "Use",
    Discard = "Discard",
}

-- load the ui prefab
function SpaceTravelGoodsActionCtrl:LoadPanel()
	self:CreatePanel("SpaceTravelGoodsAction")
end

-- construct ui panel data
function SpaceTravelGoodsActionCtrl:ConstructUI(obj)
	self._ui = SpaceTravelGoodsActionPanel.Init(obj)
end

-- fill ui with the data
function SpaceTravelGoodsActionCtrl:SetupUI()
	local goodsId = self._parameter.goodsId
    self._currentActionState = ActionState.None
    self._seasonId = self._parameter.seasonId
    self._goodsId = goodsId
    self._goodsSubType = ConfigUtils.GetSpaceTravelGoodsSubType(goodsId)
    self._maxNum = self:GetMaxGoodsNum()
    self._ui.MaxNumber.text = string.format("库存x%d", self._maxNum)
    local capacity = ConfigUtils.GetSpaceTravelGoodsSupplyCapacity(self._goodsId)
    self._ui.Capacity.text = string.format("单个重量%d", capacity)
    
    self._isPressing = false
    self._pressingSign = 0
    self._pressingTime = 0
    self._floatNum = 0

    self._ui.ActionRoot:SetActive(true)
    self._ui.NumberRoot:SetActive(false)

    local usable = ConfigUtils.IsSpaceTravelGoodsUsable(self._goodsId)
    local isUseEnable = true
    if usable then
        if self._goodsSubType == SpaceTravelGoodsSubType.SupplyFood then
            isUseEnable = not GameData.IsSpaceTravelSeasonFoodMaxed(self._seasonId)
        elseif self._goodsSubType == SpaceTravelGoodsSubType.SupplyFuel then
            isUseEnable = not GameData.IsSpaceTravelSeasonFuelMaxed(self._seasonId)
        elseif self._goodsSubType == SpaceTravelGoodsSubType.Dice then
            local nodeStatus = GameData.GetNodeStatusOfSpaceTravelSeason(self._seasonId)
            isUseEnable = (nodeStatus == SpaceTravelNodeStatus.Idle or nodeStatus == SpaceTravelNodeStatus.Completed)
        end
    end

    self._ui.Title.text = ConfigUtils.GetSpaceTravelGoodsName(goodsId)
    self._ui.Desc.text = ConfigUtils.GetSpaceTravelGoodsDesc(goodsId)
    UIHelper.SetItemIcon(self,self._ui.Icon, goodsId)

    self._ui.ButtonDiscard:SetActive(true)
    self._ui.ButtonUse:SetActive(usable)
    self._ui.ButtonUse:GetComponent("UIButton").isEnabled = isUseEnable
    self._ui.ActionTable:Reposition()

    CtrlManager.AddClick(self, self._ui.ButtonUse)
    CtrlManager.AddClick(self, self._ui.ButtonDiscard)
    CtrlManager.AddClick(self, self._ui.ButtonConfirm)
    CtrlManager.AddClick(self, self._ui.ButtonIncrease)
    CtrlManager.AddClick(self, self._ui.ButtonDecrease)
    CtrlManager.AddClick(self, self._ui.ButtonMax)
    CtrlManager.AddClick(self, self._ui.Blocker)

    CtrlManager.AddPress(self, self._ui.ButtonDecrease)
    CtrlManager.AddPress(self, self._ui.ButtonIncrease)
end

-- update implementation
function SpaceTravelGoodsActionCtrl:UpdateImpl(deltaTime)
    if  self._isPressing then
        local step = math.ceil(self._maxNum / 5)
        step = math.max(step, 10)
        self._pressingTime = self._pressingTime + deltaTime
        self._floatNum = self._floatNum + deltaTime * step * math.ceil(self._pressingTime) * self._pressingSign
        self._selectedNum = math.floor(self._floatNum)
        self._selectedNum = math.max(0, self._selectedNum)
        self._selectedNum = math.min(self._maxNum, self._selectedNum)
        self:OnSelectedNumChanged()
    end
end


function SpaceTravelGoodsActionCtrl:GetMaxGoodsNum()
    local goodsList = GameData.GetSpaceTravelSeasonData(self._seasonId).goods
    for k, v in pairs(goodsList) do
        if v.id == self._goodsId then
            return v.num
        end
    end

    return 0
end

function SpaceTravelGoodsActionCtrl:StartChooseNumber()
    self._ui.NumberRoot:SetActive(true)
    self._selectedNum = 0
    self:OnSelectedNumChanged()
end

function SpaceTravelGoodsActionCtrl:EndChooseNumber()
    self._ui.NumberRoot:SetActive(false)
end

function SpaceTravelGoodsActionCtrl:OnSelectedNumChanged()
    self._ui.Number.text = tostring(self._selectedNum)
end

-- on pressed
function SpaceTravelGoodsActionCtrl:OnPressed(go, pressed, isLong)
    if pressed and isLong then
        if go == self._ui.ButtonIncrease or go == self._ui.ButtonDecrease then
            self._isPressing = true
            self._pressingTime = 0
            self._floatNum = self._selectedNum
            if go == self._ui.ButtonIncrease then
                self._pressingSign = 1
            else
                self._pressingSign = -1
            end
        end
    elseif not pressed and self._isPressing then
        self._isPressing = false
    end
end

-- on clicked
function SpaceTravelGoodsActionCtrl:OnClicked(go)

    if go == self._ui.Blocker then
        SoundSystem.PlayUICancelSound()
        CtrlManager.PopPanel()
    elseif go == self._ui.ButtonUse then
        if self._currentActionState == ActionState.Discard then
            self._currentActionState = ActionState.None
            self:EndChooseNumber()
        end

        local isValid = CtrlManager.CheckSpaceTravelSeasonValid(self._seasonId, true)
        if not isValid then
            return true
        end

        SoundSystem.PlayUIClickSound()
        local seasonData = GameData.GetSpaceTravelSeasonData(self._seasonId)
        local scoreCapId = GameData.GetScoreCapOfSpaceTravelSeason(self._seasonId, seasonData.scoreCap)
        if self._goodsSubType == SpaceTravelGoodsSubType.Dice then
            NetManager.Send('STUseDice', {
                STSeasonID = self._seasonId, 
                STScoreCapID = scoreCapId, 
                UseItem = self._goodsId,
            }, SpaceTravelGoodsActionCtrl.OnHandleProto, self)
        else
            NetManager.Send('STUseGoods', {
                STSeasonID = self._seasonId, 
                STScoreCapID = scoreCapId, 
                GoodsId = self._goodsId,
            }, SpaceTravelGoodsActionCtrl.OnHandleProto, self)
        end
    elseif go == self._ui.ButtonDiscard then
        local isValid = CtrlManager.CheckSpaceTravelSeasonValid(self._seasonId, true)
        if not isValid then
            return true
        end

        SoundSystem.PlayUIClickSound()
        -- relic can only drop one per time
        if self._goodsSubType == SpaceTravelGoodsSubType.Relic then
            local seasonData = GameData.GetSpaceTravelSeasonData(self._seasonId)
            local scoreCapId = GameData.GetScoreCapOfSpaceTravelSeason(self._seasonId, seasonData.scoreCap)
            NetManager.Send('STDropGoods', {
                STSeasonID = self._seasonId, 
                STScoreCapID = scoreCapId, 
                GoodsList = {{self._goodsId, 1}},
            }, SpaceTravelGoodsActionCtrl.OnHandleProto, self)
        else
            if self._currentActionState ~= ActionState.Discard then
                self._currentActionState = ActionState.Discard
                self:StartChooseNumber()
            else
                self._currentActionState = ActionState.None
                self:EndChooseNumber()
            end
        end
    elseif go == self._ui.ButtonDecrease then
        if self._selectedNum > 0 then
            SoundSystem.PlayUIClickSound()
            self._selectedNum = self._selectedNum - 1
            self:OnSelectedNumChanged()
        else
            SoundSystem.PlayWarningSound()
        end
    elseif go == self._ui.ButtonIncrease then
        if self._selectedNum < self._maxNum then
            SoundSystem.PlayUIClickSound()
            self._selectedNum = self._selectedNum + 1
            self:OnSelectedNumChanged()
        else
            SoundSystem.PlayWarningSound()
        end
    elseif go == self._ui.ButtonMax then
        SoundSystem.PlayUIClickSound()
        if self._selectedNum < self._maxNum then
            self._selectedNum = self._maxNum
            self:OnSelectedNumChanged()
        end
    elseif go == self._ui.ButtonConfirm then
        local isValid = CtrlManager.CheckSpaceTravelSeasonValid(self._seasonId, true)
        if not isValid then
            return true
        end
        
        if self._selectedNum > 0 then
            SoundSystem.PlayUIClickSound()
            local seasonData = GameData.GetSpaceTravelSeasonData(self._seasonId)
            local scoreCapId = GameData.GetScoreCapOfSpaceTravelSeason(self._seasonId, seasonData.scoreCap)
            NetManager.Send('STDropGoods', {
                STSeasonID = self._seasonId, 
                STScoreCapID = scoreCapId, 
                GoodsList = {{self._goodsId, self._selectedNum}},
            }, SpaceTravelGoodsActionCtrl.OnHandleProto, self)
        else
            SoundSystem.PlayWarningSound()
        end
    end

	return true
end

function SpaceTravelGoodsActionCtrl:OnHandleProto(proto, data, requestData)
    if proto == 'STDropGoods' then
        local seasonId = requestData.STSeasonID
        local goodsList = requestData.GoodsList
        for idx = 1, #goodsList do
            local goodsId = goodsList[idx][1]
            local goodsNum = goodsList[idx][2]
            GameData.ConsumeSpaceTravelGoods(seasonId, goodsId, goodsNum)
        end
        GameData.SyncSpaceTravelSeasonBaseData(seasonId, data)
        CtrlManager.PopPanel()
    elseif proto == 'STUseGoods' then
        local seasonId = requestData.STSeasonID
        local goodsId = requestData.GoodsId
        local supplyNum = ConfigUtils.GetSpaceTravelGoodsSupplyNum(goodsId)

        local goodsSubType = ConfigUtils.GetSpaceTravelGoodsSubType(goodsId)
        if goodsSubType == SpaceTravelGoodsSubType.SupplyFood then
            GameData.ModifySpaceTravelFood(seasonId, supplyNum)
        elseif goodsSubType == SpaceTravelGoodsSubType.SupplyFuel then
            GameData.ModifySpaceTravelFuel(seasonId, supplyNum)
        elseif goodsSubType == SpaceTravelGoodsSubType.FoodLimit then
            GameData.ModifySpaceTravelFoodMax(seasonId, supplyNum)
        elseif goodsSubType == SpaceTravelGoodsSubType.FuelLimit then
            GameData.ModifySpaceTravelFuelMax(seasonId, supplyNum)
        else
            assert(false, "un-handled goods id: "..tostring(goodsId))
        end

        GameData.ConsumeSpaceTravelGoods(seasonId, goodsId, 1)
        GameData.SyncSpaceTravelSeasonBaseData(seasonId, data)
        -- goal
        local goalData = GameData.SetupItemGoalData(goodsId, 1)
        GameData.DoSpaceTravelGoalSettle(seasonId, TriggerType.UseItem, {goalData})
        -- back to space travel main
        CtrlManager.PopPanel()
    elseif proto == 'STUseDice' then
        local seasonId = requestData.STSeasonID
        local goodsId = requestData.UseItem
        local forwardStep = data.ForwardStep
        GameData.SetDiceResultForSpaceTravelSeason(seasonId, forwardStep)
        GameData.ConsumeSpaceTravelGoods(seasonId, goodsId, 1)
        GameData.SyncSpaceTravelSeasonBaseData(seasonId, data)
        -- goal
        local goalData = GameData.SetupItemGoalData(ItemType.DicePoint, 1, forwardStep)
        GameData.DoSpaceTravelGoalSettle(seasonId, TriggerType.UseDice, {goalData})
        -- back to space travel main
        CtrlManager.PopPanel()
    end
end