require "FreakPlanet/View/ArenaBattleDetailPanel"

local class = require "FreakPlanet/Utils/middleclass"
ArenaBattleDetailCtrl  = class(CtrlNames.ArenaBattleDetail, BaseCtrl)

local MAX_DIFFICULTY = 3

-- load the ui prefab
function ArenaBattleDetailCtrl:LoadPanel()
	self:CreatePanel("ArenaBattleDetail")
end

-- construct ui panel data
function ArenaBattleDetailCtrl:ConstructUI(obj)
	self._ui = ArenaBattleDetailPanel.Init(obj)
end

-- fill ui with the data
function ArenaBattleDetailCtrl:SetupUI()
	self._arenaConfigId = self._parameter.arenaConfigId
	self._arenaId = self._parameter.arenaId
	self._thisBattleIndex = self._parameter.battleIndex

	local arenaBattleList = ConfigUtils.GetBattleListOfArena(self._arenaId)
	self._arenaBattleId = arenaBattleList[self._thisBattleIndex]

	self._currentDifficulty = GameData.GetCurrentDifficultyOfArenaBattle(self._arenaConfigId, self._thisBattleIndex)
	self._selectedDifficulty = math.min(self._currentDifficulty + 1, MAX_DIFFICULTY)
	self:OnSelectedDifficultyChanged()

	self._ui.BattleDesc.text = ConfigUtils.GetArenaBattleIntroduction(self._arenaBattleId)
	
	CtrlManager.AddClick(self, self._ui.Blocker)
	CtrlManager.AddClick(self, self._ui.ButtonConfirm)
	CtrlManager.AddClick(self, self._ui.EnemyCollider)

	for k, v in pairs(self._ui.BattleDifficulties) do
		CtrlManager.AddClick(self, v.item)
	end
end

function ArenaBattleDetailCtrl:OnSelectedDifficultyChanged()
	local data = ConfigUtils.GetArenaBattleDifficultyData(self._arenaBattleId)
	local thisData = data[self._selectedDifficulty]
	self._ui.RecommendLevel.text = string.format(SAFE_LOC('loc_SimpleLevel'), thisData.SupportLevel)

	local difficultyTitles = {SAFE_LOC("简单"), SAFE_LOC("困难"), SAFE_LOC("超凶")}
	self._ui.SelectedDifficulty.text = difficultyTitles[self._selectedDifficulty]

	-- enemy
	local enemyId, enemyLevel = ConfigUtils.GetArenaBattleLastEnmeyAt(self._arenaBattleId, self._selectedDifficulty)
	-- icon
	UIHelper.SetCharacterIcon(self, self._ui.EnemyIcon, enemyId)
	-- name
	self._ui.EnemyName.text = ConfigUtils.GetEnemyName(enemyId)
	-- element
	self._ui.EnemyElement.spriteName = ConfigUtils.GetElementIconOfItem(enemyId)
	-- power
	local abilityMap = ConfigUtils.GetEnemyAbilityMap(enemyId, enemyLevel)
	self._ui.EnemyPower.text = ConfigUtils.GetPowerOfAbilityMap(abilityMap)

	-- reward items
	local rewardItemMap = {}
	local rewardItemList = {}
	local start = self._currentDifficulty + 1
	for idx = start, self._selectedDifficulty, 1 do
		local rewards = data[idx].Reward or {}
		for m = 1, #rewards do
			local rewardItemId = rewards[m].Value
			if rewardItemMap[rewardItemId] == nil then
				table.insert(rewardItemList, rewardItemId)
			end
			local preNum = rewardItemMap[rewardItemId] or 0
			rewardItemMap[rewardItemId] = preNum + rewards[m].Num
		end
	end

	for idx = 1, #self._ui.BattleRewards do
		local hasReward = (idx <= #rewardItemList)
		self._ui.BattleRewards[idx].item:SetActive(hasReward)
		if hasReward then
			local rewardItemId = rewardItemList[idx]
			local rewardItemNum = rewardItemMap[rewardItemId]
			UIHelper.ConstructItemIconAndNum(self, self._ui.BattleRewards[idx].root, rewardItemId, rewardItemNum)
		end
	end

	for idx = 1, #self._ui.BattleDifficulties do
		local v = self._ui.BattleDifficulties[idx]
		v.selected:SetActive(idx <= self._selectedDifficulty)
		v.unlocked:SetActive(idx <= self._currentDifficulty)
	end

	local showDone = (self._selectedDifficulty <= self._currentDifficulty)
	self._ui.DoneMark:SetActive(showDone)
	local showConfirm = (self._selectedDifficulty > self._currentDifficulty)
	self._ui.ButtonConfirm:SetActive(showConfirm)
end

function ArenaBattleDetailCtrl:CloseToCharacter()
	CtrlManager.PopPanel()
	CtrlManager.OpenPanel(CtrlNames.ArenaCharacter, {
		arenaConfigId = self._arenaConfigId,
		arenaId = self._arenaId,
		battleIndex = self._thisBattleIndex,
		difficulty = self._selectedDifficulty,
	})
end

-- on clicked
function ArenaBattleDetailCtrl:OnClicked(go)

	if go == self._ui.Blocker then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
	elseif go == self._ui.EnemyCollider then
		SoundSystem.PlayUIClickSound()
		local enemyId, enemyLevel = ConfigUtils.GetArenaBattleLastEnmeyAt(self._arenaBattleId, self._selectedDifficulty)
		CtrlManager.ShowItemDetail({itemId = enemyId, itemLevel = enemyLevel})
	elseif go.transform.parent == self._ui.BattleDifficultyRoot then
		local difficulty = tonumber(go.name)
		if difficulty ~= self._selectedDifficulty then
			SoundSystem.PlayUIClickSound()
			self._selectedDifficulty = difficulty
			self:OnSelectedDifficultyChanged()
		end
	elseif go == self._ui.ButtonConfirm then
		if GameData.GetActivatedArenaConfigId() == self._arenaConfigId then
			SoundSystem.PlayUIClickSound()
			CtrlManager.DoWaitTransition(CtrlNames.ArenaCharacter, self, ArenaBattleDetailCtrl.CloseToCharacter)
		else
			SoundSystem.PlayWarningSound()
			CtrlManager.ShowMessageBox({message = SAFE_LOC("流亡街已刷新"), single = true})
		end
	end

	return true
end
