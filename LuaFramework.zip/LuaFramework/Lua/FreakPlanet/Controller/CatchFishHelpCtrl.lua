require "FreakPlanet/View/CatchFishHelpPanel"

local class = require "FreakPlanet/Utils/middleclass"
CatchFishHelpCtrl  = class(CtrlNames.CatchFishHelp, BaseCtrl)

-- load the ui prefab
function CatchFishHelpCtrl:LoadPanel()
	self:CreatePanel("CatchFishHelp")
end

-- construct ui panel data
function CatchFishHelpCtrl:ConstructUI(obj)
	self._ui = CatchFishHelpPanel.Init(obj)
end

-- fill ui with the data
function CatchFishHelpCtrl:SetupUI()
	local ui = self._ui

	CtrlManager.AddClick(self, ui.Blocker)
end

-- on clicked
function CatchFishHelpCtrl:OnClicked(go)
	local ui = self._ui

	if go == ui.Blocker then
		SoundSystem.PlayUICancelSound()
		self:Close()
	end

	return true
end
