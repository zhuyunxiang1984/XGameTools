---
--- Created by lizheng.
--- DateTime: 2021-09-06 10:23:47
---

require "FreakPlanet/View/HideSeekRewardPanel"

local class = require "FreakPlanet/Utils/middleclass"
HideSeekRewardCtrl  = class(CtrlNames.HideSeekReward, BaseCtrl)

-- load the ui prefab
function HideSeekRewardCtrl:LoadPanel()
	local panelName = string.format("HideSeek%sReward", GameDataHideSeek.GetHideSeekPrefabSuffix())
	self:CreatePanel(panelName)
end

-- construct ui panel data
function HideSeekRewardCtrl:ConstructUI(obj)
	self._ui = HideSeekRewardPanel.Init(obj)
end

-- fill ui with the data
function HideSeekRewardCtrl:SetupUI()
	CtrlManager.AddClick(self, self._ui.Blocker)
	self._animatorState = AnimatorState:new(self._ui.AwardAnimator, "UI_AwardAnimation", "Award_Rabbit", nil)
	self:ConstructRewardUI()
end

function HideSeekRewardCtrl:UpdateImpl(deltaTime)
	if self._animatorState ~= nil then
		local finished = self._animatorState:Tick(deltaTime)
		if finished then
			self._animatorState = nil
		end
	end
end

-- on clicked
function HideSeekRewardCtrl:OnClicked(go)
	if go == self._ui.Blocker then
		NavigationCtrl.EnableSuspend(false)
		SoundSystem.PlayUICancelSound() 
		CtrlManager.PopPanel()
	end
	return true
end

function HideSeekRewardCtrl:ConstructRewardUI()
	local ui = self._ui
	local reward = self._parameter.Reward
	local rabbitId = self._parameter.RabbitId
	for id, num in pairs(reward) do
		local item = Helper.NewObject(ui.AwardItemTemplate, ui.AwardGrid.transform)
		item:SetActive(true)
		local icons = item.transform:Find("Icons").gameObject
		local postcard = item.transform:Find("Postcard").gameObject
		local itemType = ConfigUtils.GetItemTypeFromId(id)
		if itemType == ItemType.Postcard then
			icons:SetActive(false)
			postcard:SetActive(true)
			local postcardSprite = postcard:GetComponent("UI2DSprite")
			local iconName, iconAtlas, iconBundle = ConfigUtils.GetPostcardIcon(id)
			postcardSprite.sprite2D = self:DynamicLoadSprite(iconBundle, iconAtlas, iconName)
			local Numlabel = item.transform:Find("Num"):GetComponent("UILabel")
			Numlabel.text = "x" .. tostring(num)
		elseif itemType == ItemType.Pet then
			icons:SetActive(true)
			postcard:SetActive(false)
			local petIcon = icons.transform:Find("Character"):GetComponent("UISprite")
			UIHelper.SetCharacterIcon(self, petIcon, id)
			petIcon.gameObject:SetActive(true)
			local Numlabel = item.transform:Find("Num"):GetComponent("UILabel")
			Numlabel.text = "x" .. tostring(num)
		else
			icons:SetActive(true)
			postcard:SetActive(false)
			UIHelper.ConstructItemIconAndNum(self, item.transform, id, num)
		end
	end
	ui.AwardGrid:Reposition()
	ui.DetailInfo.text = GameDataHideSeek.GetHideSeekRabbitDailogInfo(rabbitId) or ""
end


