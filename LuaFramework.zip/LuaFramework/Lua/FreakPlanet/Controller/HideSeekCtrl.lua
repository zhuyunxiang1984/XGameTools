---
--- Created by lizheng.
--- DateTime: 2021-09-01 11:10:05
---

require "FreakPlanet/View/HideSeekPanel"

local class = require "FreakPlanet/Utils/middleclass"
HideSeekCtrl  = class(CtrlNames.HideSeek, BaseCtrl)

-- load the ui prefab
function HideSeekCtrl:LoadPanel()
	self:CreatePanel("HideSeek")
end

-- construct ui panel data
function HideSeekCtrl:ConstructUI(obj)
	self._ui = HideSeekPanel.Init(obj)
end

-- fill ui with the data
function HideSeekCtrl:SetupUI()
	self._RefreshCount = 0
	self:DynamicLoadBundle(Const.HideSeekComicBundleName)
	self:EnableSecondUpdate()
end

function HideSeekCtrl:UpdateImplBySecond(deltaTime)
	if GameDataHideSeek.GetCurrentActiveHideSeekActivity() then
		local showNum = GameDataHideSeek.GetHideSeekActiveRabbitCount()
		if showNum ~= self._RefreshCount then
			self._RefreshCount = showNum
			GameNotifier.Notify(GameEvent.HideSeekDataChanged)
		end
	else
		GameNotifier.Notify(GameEvent.HideSeekActivityOver)
	end
end