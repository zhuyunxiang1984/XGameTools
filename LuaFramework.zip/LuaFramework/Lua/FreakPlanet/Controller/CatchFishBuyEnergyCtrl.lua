require "FreakPlanet/View/CatchFishBuyEnergyPanel"

local class = require "FreakPlanet/Utils/middleclass"
CatchFishBuyEnergyCtrl  = class(CtrlNames.CatchFishBuyEnergy, BaseCtrl)

-- load the ui prefab
function CatchFishBuyEnergyCtrl:LoadPanel()
	self:CreatePanel("CatchFishBuyEnergy")
end

-- construct ui panel data
function CatchFishBuyEnergyCtrl:ConstructUI(obj)
	self._ui = CatchFishBuyEnergyPanel.Init(obj)
	self.CostId = self._parameter.CostId
	self.CostNum = self._parameter.CostNum
	self.ItemId = self._parameter.ItemId
	self.ItemNum = self._parameter.ItemNum
	self.CurBuy = self._parameter.CurBuy
	self.MaxBuy = self._parameter.MaxBuy
	self.OnConfirm = self._parameter.OnConfirm
end

-- fill ui with the data
function CatchFishBuyEnergyCtrl:SetupUI()
	local ui = self._ui

	if self.CostId > 0 then
		UIHelper.SetItemIcon(self, ui.imgCostIcon, self.CostId)
	end
	if self.ItemId > 0 then
		UIHelper.SetItemIcon(self, ui.imgItemIcon, self.ItemId)
	end
	ui.txtCostNum.text = self.CostNum
	ui.txtItemNum.text = self.ItemNum
	ui.txtLabel.text = string.format("剩余购买次数:%d/%d", self.MaxBuy - self.CurBuy, self.MaxBuy)

	CtrlManager.AddClick(self, ui.Blocker)
	CtrlManager.AddClick(self, ui.btnConfirm)
	CtrlManager.AddClick(self, ui.btnReturn)
end

-- on clicked
function CatchFishBuyEnergyCtrl:OnClicked(go)
	local ui = self._ui
	if go == ui.Blocker then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
	elseif go == ui.btnConfirm then
		SoundSystem.PlayUIClickSound()
		CtrlManager.PopPanel()
		if self.OnConfirm then
			self.OnConfirm()
		end

	elseif go == ui.btnReturn then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
	end
	return true
end
