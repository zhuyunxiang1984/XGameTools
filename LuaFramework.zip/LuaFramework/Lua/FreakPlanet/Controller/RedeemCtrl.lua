require "FreakPlanet/View/RedeemPanel"

local class = require "FreakPlanet/Utils/middleclass"
RedeemCtrl  = class(CtrlNames.Redeem, BaseCtrl)

-- load the ui prefab
function RedeemCtrl:LoadPanel()
	self:CreatePanel("Redeem")
end

-- construct ui panel data
function RedeemCtrl:ConstructUI(obj)
	self._ui = RedeemPanel.Init(obj)
end

-- fill ui with the data
function RedeemCtrl:SetupUI()
	CtrlManager.AddClick(self, self._ui.Blocker)
    CtrlManager.AddClick(self, self._ui.ButtonConfirm)
end

function RedeemCtrl:CheckInput()
    local code = self._ui.InputCodeSafeInput:GetText()
    if Helper.IsEmptyOrNull(code) then
        SoundSystem.PlayWarningSound()
        CtrlManager.ShowMessageBox({message = SAFE_LOC("请输入兑换码"), single = true})
        return false
    end

    return true
end

-- on clicked
function RedeemCtrl:OnClicked(go)

    if go == self._ui.Blocker then
        SoundSystem.PlayUICancelSound()
        CtrlManager.PopPanel()
    elseif go == self._ui.ButtonConfirm then
        local valid = self:CheckInput()
        if valid then
            SoundSystem.PlayUIClickSound()
            local code = self._ui.InputCodeSafeInput:GetText()
            NetManager.Send("ExchangeCode", {Code = code}, RedeemCtrl.OnHandleProto, self)
        end
    end

	return true
end

function RedeemCtrl:OnHandleProto(proto, data, requestData)
    if proto == "ExchangeCode" then
        local rewardList = data.RewardList or {}
        if #rewardList == 0 then
            CtrlManager.ShowMessageBox({message = data.Tip, single = true})
        else
            for idx = 1, #rewardList do
                local itemId = rewardList[idx].GoodsCode
                local itemNum = rewardList[idx].GoodsNum
                GameData.CollectItem(itemId, itemNum, true)
            end

            GameData.CheckAndHintGoalsOfCurrentCountType()
        end
    end
end
