---
--- Created by lizheng.
--- DateTime: 2021-09-02 11:05:56
---

require "FreakPlanet/View/HideSeekDetailPanel"

local class = require "FreakPlanet/Utils/middleclass"
HideSeekDetailCtrl  = class(CtrlNames.HideSeekDetail, BaseCtrl)

local _CurrentPage = 1
-- load the ui prefab
function HideSeekDetailCtrl:LoadPanel()
	local panelName = string.format("HideSeek%sDetail", GameDataHideSeek.GetHideSeekPrefabSuffix())
	self:CreatePanel(panelName)
end

-- construct ui panel data
function HideSeekDetailCtrl:ConstructUI(obj)
	self._ui = HideSeekDetailPanel.Init(obj)
end

-- fill ui with the data
function HideSeekDetailCtrl:SetupUI()

	local ui = self._ui

	CtrlManager.AddClick(self, ui.Blocker)
	CtrlManager.AddClick(self, ui.ButtonReviewComic)
	CtrlManager.AddClick(self, ui.ButtonNext)
	CtrlManager.AddClick(self, ui.ButtonPrevious)
	CtrlManager.AddClick(self, ui.ButtonUnlock)

	local isUnlock = GameData.UnlockHideSeekActivity()
	ui.DetailPanel:SetActive(isUnlock)
	ui.ComicPanel:SetActive(not isUnlock)
	if isUnlock then
		self:ConstructDetailPanelUI()
	else
		self:ConstructComicPanelUI()
	end
end

-- on clicked
function HideSeekDetailCtrl:OnClicked(go)
	local ui = self._ui
	if go == ui.Blocker then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
	elseif go == ui.ButtonReviewComic then
		ui.DetailPanel:SetActive(false)
		ui.ComicPanel:SetActive(true)
		_CurrentPage = 1
		self:ConstructComicPanelUI()
	elseif go == ui.ButtonUnlock then
		NetManager.Send("HideSeekJoin", {}, HideSeekDetailCtrl.OnHandleProto, self)
	elseif go == ui.ButtonPrevious then
		_CurrentPage = _CurrentPage - 1
		self:ConstructComicPanelUI()
	elseif go == ui.ButtonNext then
		if _CurrentPage < #ui.ComicSequence then
			_CurrentPage = _CurrentPage + 1
			self:ConstructComicPanelUI()
		else
			if GameData.UnlockHideSeekActivity() then
				ui.DetailPanel:SetActive(true)
				ui.ComicPanel:SetActive(false)
				self:ConstructDetailPanelUI()
			end
		end
	end
	return true
end

function HideSeekDetailCtrl:UpdateImpl(deltaTime)
	if self._animatorState ~= nil then
		local finished = self._animatorState:Tick(deltaTime)
		if finished then
			self._animatorState = nil
		end
	end
end

function HideSeekDetailCtrl:ConstructDetailPanelUI()
	if not GameDataHideSeek.IsUnlockHideSeekActivity() then
		return
	end
	self._animatorState = AnimatorState:new(self._ui.PanelAnimator, "UI_Animation", "Idle_HideSeek", nil)
	self._ui.ButtonNumberTotal:SetActive(not GameDataHideSeek.FindAllHideSeekRabbit())
	self._ui.ButtonNumberToday:SetActive(not GameDataHideSeek.FindAllHideSeekRabbit())
	self._ui.RuleInfo.text = GameDataHideSeek.GetHideSeekRuleInfo()
	if GameDataHideSeek.FindAllHideSeekRabbit() then
		self._ui.TipsLabel.gameObject:SetActive(false)
		self._ui.DetailInfo.text = GameDataHideSeek.GetHideSeekResultInfo()
	else
		self._ui.TipsLabel.gameObject:SetActive(true)
		self._ui.TipsLabel.text = GameDataHideSeek.GetHideSeekTips()
		self._ui.DetailInfo.text = GameDataHideSeek.GetHideSeekIntroduceInfo()
	end

	local starTime, endTime = GameDataHideSeek.GetCurrentHideSeekStartAndEndTime()
	self._ui.ActivityTime.text = string.format("活动时间:%s-%s", starTime, endTime)
	self._ui.TotalNumberTxt.text = string.format("[FCFE79]%d[-]/%d", GameData.GetTotalHideSeekFindCount(), GameDataHideSeek.GetHideSeekTotalLimit())
	self._ui.TodayNumberTxt.text = string.format("[FCFE79]%d[-]/%d", GameData.GetTodayHideSeekFindCount(), GameDataHideSeek.GetHideSeekActiveRabbitCount())
end

function HideSeekDetailCtrl:ConstructComicPanelUI()
	if not GameDataHideSeek.IsUnlockHideSeekActivity() then
		return
	end
	self:RefreshComicSequence()
	if GameData.UnlockHideSeekActivity() then
		self._ui.ButtonNext:SetActive(true)
	else
		self._ui.ButtonNext:SetActive(_CurrentPage < #self._ui.ComicSequence)
	end
	self._ui.ButtonPrevious:SetActive(_CurrentPage > 1)
	self._ui.ButtonUnlock:SetActive(not GameData.UnlockHideSeekActivity() and (_CurrentPage == #self._ui.ComicSequence))
end

function HideSeekDetailCtrl:RefreshComicSequence()
	for idx = 1, #self._ui.ComicSequence do
		local comicItem = self._ui.ComicSequence[idx]
		comicItem:SetActive(idx == _CurrentPage)
	end
end

function HideSeekDetailCtrl:OnHandleProto(proto, data, requestData)
	if proto == "HideSeekJoin" then
		GameData.InitHideSeekData(data.HideSeekInfo)
		self._ui.DetailPanel:SetActive(true)
		self._ui.ComicPanel:SetActive(false)
		self:ConstructDetailPanelUI()
	end
end