require "FreakPlanet/View/ExploreUnlockTeamPanel"

local class = require "FreakPlanet/Utils/middleclass"
ExploreUnlockTeamCtrl  = class(CtrlNames.ExploreUnlockTeam, BaseCtrl)

-- load the ui prefab
function ExploreUnlockTeamCtrl:LoadPanel()
	self:CreatePanel("ExploreUnlockTeam")
end

-- construct ui panel data
function ExploreUnlockTeamCtrl:ConstructUI(obj)
	self._ui = ExploreUnlockTeamPanel.Init(obj)
end

-- fill ui with the data
function ExploreUnlockTeamCtrl:SetupUI()
    local currentTeamLimit, maxTeamLimit = GameData.CurrentTeamLimit()
    assert(currentTeamLimit < maxTeamLimit, "invalid current team limit: "..tostring(currentTeamLimit))
    local nextLimit = currentTeamLimit + 1
    local needGold = TeamUnlockGoldCost[nextLimit]
    local currentGold = GameData.GetMoney(ItemType.Gold)
    self._ui.UnlockCost.text = tostring(needGold)
    if needGold > currentGold then
        self._ui.UnlockCost.color = Color.red
        self._ui.ButtonConfirm:SetActive(false)
        self._ui.AlertHint:SetActive(true)
    else
        self._ui.UnlockCost.color = self._ui.UnlockCostColor
        self._ui.ButtonConfirm:SetActive(true)
        self._ui.AlertHint:SetActive(false)
    end

	
    CtrlManager.AddClick(self, self._ui.Blocker)
    CtrlManager.AddClick(self, self._ui.ButtonConfirm)
end

-- on clicked
function ExploreUnlockTeamCtrl:OnClicked(go)

    if go == self._ui.Blocker then
        SoundSystem.PlayUICancelSound()
        CtrlManager.PopPanel()
    elseif go == self._ui.ButtonConfirm then
        SoundSystem.PlayUIClickSound()
        NetManager.Send("TeamUnlock", {}, ExploreUnlockTeamCtrl.OnHandleProto, self)
    end

	return true
end

function ExploreUnlockTeamCtrl:OnHandleProto(proto, data, requestData)
    if proto == "TeamUnlock" then
        local goldNum = data.RemainGold
        local diamondNum = data.RemainDiamond
        GameData.SetMoney(ItemType.Gold, goldNum)
        GameData.SetMoney(ItemType.Diamond, diamondNum)

        local newTeamLimit = data.TeamUnlockCount
        GameData.UnlockTeam(newTeamLimit)

        CtrlManager.PopPanel()
    end
end
