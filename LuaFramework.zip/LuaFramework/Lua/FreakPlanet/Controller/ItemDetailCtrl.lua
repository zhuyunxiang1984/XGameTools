require "FreakPlanet/View/ItemDetailPanel"

local class = require "FreakPlanet/Utils/middleclass"
ItemDetailCtrl  = class(CtrlNames.ItemDetail, BaseCtrl)

-- load the ui prefab
function ItemDetailCtrl:LoadPanel()
	self:CreatePanel("ItemDetail")
end

-- construct ui panel data
function ItemDetailCtrl:ConstructUI(obj)
	self._ui = ItemDetailPanel.Init(obj)
end

function ItemDetailCtrl:GetTotalSkinList(itemId)
	self._totalSkinList = {}
	local type = ConfigUtils.GetItemTypeFromId(itemId)
	if type == ItemType.Character then
		local skinList = ConfigUtils.GetCharacterSkinList(itemId)

		if self._isPreivew then
			local characterStage = ConfigUtils.GetCharacterStageLimit(itemId)
			local characterDefaultSkinId = ConfigUtils.GetDefaultSkinOfCharacter(itemId, characterStage)
			table.insert(self._totalSkinList, characterDefaultSkinId)
		else
			local defaultSkin = GameData.GetCharacterDefaultSkin(itemId)
			table.insert(self._totalSkinList, defaultSkin)
		end
		for idx = 1, #skinList do
			table.insert(self._totalSkinList, skinList[idx])
		end
	end

end

-- fill ui with the data
function ItemDetailCtrl:SetupUI()
	local itemId = self._parameter.itemId
	local itemLevel = self._parameter.itemLevel or 1
	local callback = self._parameter.callback
	local receiver = self._parameter.receiver
	self._isPreivew = self._parameter.preview or false
	XDebug.Log("LZ", "_isPreivew:", self._isPreivew)

	self._itemList = {{id = itemId, level = itemLevel, callback = callback, receiver = receiver}}
	self._equipmentPrefab = self:LoadAsset("EquipmentItem")

	self._totalSkinList = nil
	self:GetTotalSkinList(itemId)

	self._curSkinSlot = nil
	self:SwitchCurrentItem()

	self._ui.AbilityHintRoot:SetActive(false)

	CtrlManager.AddClick(self, self._ui.Blocker)
	CtrlManager.AddClick(self, self._ui.CharacterMark.gameObject)
	CtrlManager.AddClick(self, self._ui.GoodsMark.gameObject)
	CtrlManager.AddClick(self, self._ui.PetMark.gameObject)
	CtrlManager.AddClick(self, self._ui.CharacterCollider)
	CtrlManager.AddClick(self, self._ui.EnemyCollider)
	CtrlManager.AddClick(self, self._ui.PetCollider)
	CtrlManager.AddClick(self, self._ui.ButtonNext)
	CtrlManager.AddClick(self, self._ui.ButtonPrev)
	-- equipments
	for k, v in pairs(self._ui.CharacterEquipments) do
		CtrlManager.AddClick(self, v.item)
	end
	-- goods craft source items
	for idx = 1, #self._ui.GoodsCraftSources do
		CtrlManager.AddClick(self, self._ui.GoodsCraftSources[idx].item)
	end
	-- skins
	--[[
	for k, v in pairs(self._ui.CharacterSkins) do
		CtrlManager.AddClick(self, v.item)
	end
	--]]
	-- enemy catch item
	for k, v in pairs(self._ui.EnemyCatchItems) do
		CtrlManager.AddClick(self, v.item)
	end
	-- pet catch item
	for k, v in pairs(self._ui.PetCatchItems) do
		CtrlManager.AddClick(self, v.item)
	end
	-- character ability item
	for k, v in pairs(self._ui.CharacterAbilities) do
		CtrlManager.AddPress(self, v.item)
	end
	-- enemy ability item
	for k, v in pairs(self._ui.EnemyAbilities) do
		CtrlManager.AddPress(self, v.item)
	end
	-- pet ability item
	for k, v in pairs(self._ui.PetAbilities) do
		CtrlManager.AddPress(self, v.item)
	end

	CtrlManager.AddClick(self, self._ui.ButtonSkinNext)
	CtrlManager.AddClick(self, self._ui.ButtonSkinPreview)
end

function ItemDetailCtrl:SwitchCurrentItem()
	local itemId = self._itemList[#self._itemList].id
	local itemLevel = self._itemList[#self._itemList].level
	local itemType = ConfigUtils.GetItemTypeFromId(itemId)
	self._currentCallback = self._itemList[#self._itemList].callback
	self._callbackReceiver = self._itemList[#self._itemList].receiver
	self._currentItemId = itemId
	self._animationState = nil
	self._abilityList = {}

	self._ui.CharacterRoot.gameObject:SetActive(itemType == ItemType.Character)
	self._ui.GoodsRoot.gameObject:SetActive(itemType == ItemType.Goods)
	self._ui.EquipmentRoot.gameObject:SetActive(itemType == ItemType.Equipment)
	self._ui.GoldRoot.gameObject:SetActive(itemType == ItemType.Gold)
	self._ui.DiamondRoot.gameObject:SetActive(itemType == ItemType.Diamond)
	self._ui.EnemyRoot.gameObject:SetActive(itemType == ItemType.Enemy)
	self._ui.PetRoot.gameObject:SetActive(itemType == ItemType.Pet)
	self._ui.RoomPieceRoot.gameObject:SetActive(itemType == ItemType.RoomPiece)
	self._ui.LabRecipeRoot.gameObject:SetActive(itemType == ItemType.LabRecipe)
	self._ui.pTransHomeFurnitureRoot.gameObject:SetActive(itemType == ItemType.HomeFurniture)
	self._ui.pTransTokenRoot.gameObject:SetActive(itemType == ItemType.Token)

	self._ui.ButtonNext:SetActive(self._currentCallback ~= nil)
	self._ui.ButtonPrev:SetActive(self._currentCallback ~= nil)
	self:GetTotalSkinList(itemId)
	local sourceRoot = nil
	local borderSprite = nil
	if itemType == ItemType.Character then
		if self._isPreivew then
			self:ConstructPreviewCharacter(itemId)
		else
			self:ConstructCharacter(itemId)
		end
		sourceRoot = self._ui.CharacterFrom
		borderSprite = self._ui.CharacterBorder
	elseif itemType == ItemType.Goods then
		self:ConstructGoods(itemId)
		sourceRoot = self._ui.GoodsFrom
	elseif itemType == ItemType.Equipment then
		if self._isPreivew then
			self:ConstructPreviewEquipment(itemId, itemLevel)
		else
			self:ConstructEquipment(itemId, itemLevel)
		end
	elseif itemType == ItemType.Gold or itemType == ItemType.Diamond then
		-- do nothing
	elseif itemType == ItemType.Enemy then
		self:ConstructEnemy(itemId, itemLevel)
		borderSprite = self._ui.EnemyBorder
	elseif itemType == ItemType.Pet then
		self:ConstructPet(itemId)
		borderSprite = self._ui.PetBorder
		sourceRoot = self._ui.PetFrom
	elseif itemType == ItemType.RoomPiece then
		self:ConstructRoomPiece(itemId)
	elseif itemType == ItemType.LabRecipe then
		self:ConstructLabRecipe(itemId)
	elseif itemType == ItemType.HomeFurniture then
		self:ConstructHomeFurniture(itemId)
	elseif itemType == ItemType.Token then
		self:ConstructToken(itemId)
	else
		assert(false, "un-handled item type: "..tostring(itemType))
	end

	if sourceRoot ~= nil then
		self:ConstructItemSources(sourceRoot, itemId)
	end
	if borderSprite ~= nil then
		local itemType = ConfigUtils.GetItemTypeFromId(itemId)
		borderSprite.spriteName = UIHelper.GetItemDetailBorder(itemId)
	end
end

function ItemDetailCtrl.IsAccepted(itemType)
	if itemType == ItemType.Character or
		itemType == ItemType.Goods or
		itemType == ItemType.Equipment or
		itemType == ItemType.Gold or
		itemType == ItemType.Diamond or
		itemType == ItemType.Enemy or
		itemType == ItemType.Pet or
		itemType == ItemType.RoomPiece or
		itemType == ItemType.HomeFurniture or
		itemType == ItemType.LabRecipe then
		return true
	end

	return false
end

function ItemDetailCtrl:RefreshMarkState(sprite, unlocked, marked)
	sprite.gameObject:SetActive(unlocked)
	if unlocked then
		sprite.color = Color.white
		if marked then
			sprite.spriteName = "HintIcon"
		else
			sprite.spriteName = "HintIcon2"
		end
	end
end

function ItemDetailCtrl:ConstructCharacter(itemId)
	self._characterDefaultSkinId = GameData.GetCharacterDefaultSkin(itemId)

	local usedSkinId = GameData.GetCharacterSkin(itemId)
	self._curSkinSlot = Helper.IndexOfArray(self._totalSkinList, usedSkinId) or 1
	self._characterShowSkinId = self._totalSkinList[self._curSkinSlot]

	self:OnCharacterShowSkinChanged()

	local unlocked = GameData.IsCharacterUnlocked(itemId)
	local curStage = GameData.GetCharacterCurrentStage(itemId)
	local curLevel = GameData.GetCharacterLevel(itemId)
	local maxStage = ConfigUtils.GetCharacterStageLimit(itemId)
	local maxLevel = ConfigUtils.GetCharacterMaxLevel(itemId)
	-- name
	self._ui.CharacterName.text = ConfigUtils.GetCharacterName(itemId)
	-- element
	local elementId = ConfigUtils.GetCharacterElement(itemId)
	local style = ConfigUtils.GetCharacterStyle(itemId)
	self._ui.CharacterElement.spriteName = ConfigUtils.GetElementIconWithStyle(elementId)
	self._ui.CharacterStyle.spriteName = ConfigUtils.GetStyleIcon(style)
	self._ui.CharacterStyle.color = ConfigUtils.GetStyleIconColor(elementId)
	-- level
	if unlocked then
		self._ui.CharacterLevel.text = string.format(SAFE_LOC('loc_SimpleLevel'), curLevel)
		self._ui.CharacterFullLevelMark:SetActive(curLevel >= maxLevel)
	else
		self._ui.CharacterLevel.text = SAFE_LOC("loc_global_gallary_didnot_unlock")
		self._ui.CharacterFullLevelMark:SetActive(false)
	end
	-- stage
	for idx = 1, #self._ui.CharacterStages do
		local hasStage = (idx <= maxStage)
		self._ui.CharacterStages[idx].item:SetActive(hasStage)
		if hasStage then
			if curStage < idx then
				self._ui.CharacterStages[idx].icon.color = Color.black
			else
				self._ui.CharacterStages[idx].icon.color = Color.white
			end
		end
	end
	-- ability
	self._abilityList = GameData.GetCharacterAbilityList(itemId)
	for idx = 1, #self._ui.CharacterAbilities do
		local has = (idx <= #self._abilityList)
		self._ui.CharacterAbilities[idx].item:SetActive(has)
		if has then
			local abilityId = self._abilityList[idx].id
			self._ui.CharacterAbilities[idx].icon.spriteName = ConfigUtils.GetAbilityIcon(abilityId)
			if unlocked then
				local abilityValue = self._abilityList[idx].value
				local valueText = "[42261EFF]"..tostring(abilityValue).."[-]"
				self._ui.CharacterAbilities[idx].value.text = valueText
			else
				self._ui.CharacterAbilities[idx].value.text = "[42261EFF]??[-]"
			end
		end
	end

	-- equipments
	local equipmentList = ConfigUtils.GetCharacterEquipmentList(itemId)
    for idx = 1, #self._ui.CharacterEquipments do
        local hasEquipment = (idx <= #equipmentList)
        self._ui.CharacterEquipments[idx].item:SetActive(hasEquipment)

        if hasEquipment then
            local equipmentId = equipmentList[idx]
            local unlockChallenge = ConfigUtils.GetEquipmentUnlockChallenge(equipmentId)
            local equipmentUnlocked = unlockChallenge == nil or GameData.IsChallengeCompleted(unlockChallenge)
            local equipmentLevel = GameData.GetCharacterEquipmentLevel(itemId, idx)
            -- icon
            UIHelper.SetEquipmentIcon(self, self._ui.CharacterEquipments[idx].icon, equipmentId, equipmentLevel)
            -- level and color
            if equipmentUnlocked then
            	self._ui.CharacterEquipments[idx].icon.color = Color.white
            	self._ui.CharacterEquipments[idx].level.text = string.format(SAFE_LOC('loc_SimpleLevel'), equipmentLevel)
            else
            	self._ui.CharacterEquipments[idx].icon.color = Color.black
            	self._ui.CharacterEquipments[idx].level.text = ""
            end
        end
    end
	-- marked
	local marked = GameData.IsItemMarked(itemId)
	self:RefreshMarkState(self._ui.CharacterMark, unlocked, marked)
	-- gallery icon
	local galleryId = ConfigUtils.GetCharacterGallery(itemId)
	self._ui.CharacterGallery.gameObject:SetActive(galleryId ~= nil)
	if galleryId ~= nil then
		self._ui.CharacterGallery.spriteName = ConfigUtils.GetGalleryIcon(galleryId)
	end
	-- preview mark
	self._ui.CharacterPreviewMark:SetActive(false)
end

function ItemDetailCtrl:OnCharacterShowSkinChanged()
	-- remove
	for idx = self._ui.CharacterAvatar.childCount, 1, -1 do
		local obj = self._ui.CharacterAvatar:GetChild(idx - 1).gameObject
		destroy(obj)
	end

	local itemId = self._currentItemId
	local unlocked = GameData.IsCharacterUnlocked(itemId)
	local usedSkinId = GameData.GetCharacterSkin(itemId)

	 -- skins
	local curSkinId = self._totalSkinList[self._curSkinSlot]
	local skinUnlocked = curSkinId == self._characterDefaultSkinId and true or GameData.IsSkinUnlocked(curSkinId)

	self._ui.SkinUnlockObj:SetActive(skinUnlocked)
	self._ui.SkinLockObj:SetActive(not skinUnlocked)
	self._ui.SkinUsedMark:SetActive(curSkinId == usedSkinId)

	self._ui.ButtonSkinPreview:SetActive(self._curSkinSlot ~= 1)
	self._ui.ButtonSkinNext:SetActive(self._curSkinSlot ~= #self._totalSkinList)

	if self._characterDefaultSkinId == curSkinId then
		self._ui.SkinEquipmentSlot.text = ""
		self._ui.SkinName.text = SAFE_LOC("原始形象")
		self._ui.SkinSlotTxt.text = ""
	else
		self._ui.SkinEquipmentSlot.text = tostring(self._curSkinSlot - 1)
		self._ui.SkinSlotTxt.text = string.format("%d/%d", self._curSkinSlot - 1, #self._totalSkinList - 1)
		self._ui.SkinName.text = ConfigUtils.GetSkinName(curSkinId)
	end
	-- desc
	if self._characterDefaultSkinId == self._characterShowSkinId then
		self._ui.CharacterDesc.text = ConfigUtils.GetCharacterDesc(itemId)
	else
		local skinUnlocked = GameData.IsSkinUnlocked(self._characterShowSkinId)
		self._ui.CharacterDesc.text = ConfigUtils.GetSkinDesc(self._characterShowSkinId, skinUnlocked)
	end

    -- avatar
	local prefabName, prefabBundle = ConfigUtils.GetCharacterPrefab(itemId)
	local prefab = self:DynamicLoadAsset(prefabBundle, prefabName)
	local itemObj = Helper.NewObject(prefab, self._ui.CharacterAvatar, 80)
	itemObj.name = tostring(itemId)
	-- skin
	local skeletonAnimation = itemObj:GetComponent("SkeletonAnimation")
	Helper.PlayAnimation(skeletonAnimation, CharacterAnimations.Idle, true)
	UIHelper.SetCharacterSkinWithSkin(skeletonAnimation, self._characterShowSkinId)
	skeletonAnimation.enabled = unlocked
	-- mesh render
	local meshRenderer = itemObj:GetComponent("MeshRenderer")
	for matIdx = 1, meshRenderer.materials.Length do
		if unlocked then
			meshRenderer.materials:GetValue(matIdx - 1).color = Color.New(1, 1, 1, 1)
		else
			meshRenderer.materials:GetValue(matIdx - 1).color = Color.New(0, 0, 0, 1)
		end
	end

	self:ConstructSkillDec(itemId)
end

function ItemDetailCtrl:ConstructSkillDec(characterId)
	-- skill
	local curSkinId = self._totalSkinList[self._curSkinSlot]
	local characterStage = GameData.GetCharacterCurrentStage(characterId)
	if curSkinId == self._characterDefaultSkinId then
		local hasSkill = ConfigUtils.IsCharacterHasSkill(characterId)
		local activatedSkillDesc = ConfigUtils.GetCharacterSkillDescAt(characterId, characterStage)
		local skillActivated = activatedSkillDesc ~= nil
		if not hasSkill then
			self._ui.CharacterSkill.text = "[9F8A83FF]"..SAFE_LOC("loc_CharacterNoSkill").."[-]"
		else
			if skillActivated then
				self._ui.CharacterSkill.text = string.format("[42261EFF]%s[-] [48FF00FF]%s[-]", activatedSkillDesc, SAFE_LOC("loc_Activated"))
			else
				local nextActivatedSkillDesc = ConfigUtils.GetCharacterNextSkillDescAt(characterId, characterStage)
				self._ui.CharacterSkill.text = string.format("[42261EFF]%s[-] [FF0000FF]%s[-]", nextActivatedSkillDesc, SAFE_LOC("loc_NotActivated"))
			end
		end
	else
		local usedSkinId = GameData.GetCharacterSkin(characterId)
		local isDressedSkin = usedSkinId == curSkinId
		if isDressedSkin then
			--self._ui.CharacterSkill.text ="[42261EFF]" ..ConfigUtils.GetSkinSkillDesc(curSkinId).."[-]"
			self._ui.CharacterSkill.text = string.format("[42261EFF]%s[-] [48FF00FF]%s[-]", ConfigUtils.GetSkinSkillDesc(curSkinId), SAFE_LOC("loc_Activated"))
		else
			self._ui.CharacterSkill.text = string.format("[42261EFF]%s[-] [FF0000FF]%s[-]", ConfigUtils.GetSkinSkillDesc(curSkinId), SAFE_LOC("loc_NotActivated"))
		end
	end
end

function ItemDetailCtrl:ConstructPreviewCharacter(itemId)
	local characterLevel = ConfigUtils.GetCharacterMaxLevel(itemId)
	local characterStage = ConfigUtils.GetCharacterStageLimit(itemId)
	self._characterDefaultSkinId = ConfigUtils.GetDefaultSkinOfCharacter(itemId, characterStage)
	self._characterShowSkinId = self._characterDefaultSkinId

	self._curSkinSlot = 1
	self:OnPreviewCharacterShowSkinChanged()

	local equipmentList = ConfigUtils.GetCharacterEquipmentList(itemId)
	local unlockedEquipments = {}
	for idx = 1, #equipmentList do
		local equipmentId = equipmentList[idx]
		-- preview is max level
		local equipmentLevel = ConfigUtils.GetEquipmentMaxLevel(equipmentId)
		unlockedEquipments[idx] = {id = equipmentId, level = equipmentLevel}
	end
	-- name
	self._ui.CharacterName.text = ConfigUtils.GetCharacterName(itemId)
	-- element
	local elementId = ConfigUtils.GetCharacterElement(itemId)
	local style = ConfigUtils.GetCharacterStyle(itemId)
	self._ui.CharacterElement.spriteName = ConfigUtils.GetElementIconWithStyle(elementId)
	self._ui.CharacterStyle.spriteName = ConfigUtils.GetStyleIcon(style)
	self._ui.CharacterStyle.color = ConfigUtils.GetStyleIconColor(elementId)
	-- level
	self._ui.CharacterLevel.text = string.format(SAFE_LOC('loc_SimpleLevel'), characterLevel)
	self._ui.CharacterFullLevelMark:SetActive(true)
	-- stage
	for idx = 1, #self._ui.CharacterStages do
		local hasStage = (idx <= characterStage)
		self._ui.CharacterStages[idx].item:SetActive(hasStage)
		if hasStage then
			self._ui.CharacterStages[idx].icon.color = Color.white
		end
	end
	-- ability
	self._abilityList = GameData.GetPreviewCharacterAbilityList(itemId, characterLevel, characterStage, self._characterShowSkinId, unlockedEquipments)
	for idx = 1, #self._ui.CharacterAbilities do
		local has = (idx <= #self._abilityList)
		self._ui.CharacterAbilities[idx].item:SetActive(has)
		if has then
			local abilityId = self._abilityList[idx].id
			self._ui.CharacterAbilities[idx].icon.spriteName = ConfigUtils.GetAbilityIcon(abilityId)
			local abilityValue = self._abilityList[idx].value
			local valueText = "[42261EFF]"..tostring(abilityValue).."[-]"
			self._ui.CharacterAbilities[idx].value.text = valueText
		end
	end



	-- equipments
    for idx = 1, #self._ui.CharacterEquipments do
        local hasEquipment = (idx <= #unlockedEquipments)
        self._ui.CharacterEquipments[idx].item:SetActive(hasEquipment)

        if hasEquipment then
            local equipmentId = unlockedEquipments[idx].id
            local equipmentLevel = unlockedEquipments[idx].level
            -- icon
            UIHelper.SetEquipmentIcon(self, self._ui.CharacterEquipments[idx].icon, equipmentId, equipmentLevel)
            -- level and color
            self._ui.CharacterEquipments[idx].icon.color = Color.white
            self._ui.CharacterEquipments[idx].level.text = string.format(SAFE_LOC('loc_SimpleLevel'), equipmentLevel)
        end
    end
	-- marked
	self:RefreshMarkState(self._ui.CharacterMark, false, false)
	-- gallery icon
	local galleryId = ConfigUtils.GetCharacterGallery(itemId)
	self._ui.CharacterGallery.gameObject:SetActive(galleryId ~= nil)
	if galleryId ~= nil then
		self._ui.CharacterGallery.spriteName = ConfigUtils.GetGalleryIcon(galleryId)
	end
	-- preview mark
	self._ui.CharacterPreviewMark:SetActive(true)
end

function ItemDetailCtrl:OnPreviewCharacterShowSkinChanged()
	-- remove
	for idx = self._ui.CharacterAvatar.childCount, 1, -1 do
		local obj = self._ui.CharacterAvatar:GetChild(idx - 1).gameObject
		destroy(obj)
	end

	local itemId = self._currentItemId

	-- skins
	local curSkinId = self._totalSkinList[self._curSkinSlot]
	local skinUnlocked = curSkinId == false

	self._ui.SkinUnlockObj:SetActive(skinUnlocked)
	self._ui.SkinLockObj:SetActive(not skinUnlocked)
	self._ui.SkinUsedMark:SetActive(false)

	self._ui.ButtonSkinPreview:SetActive(self._curSkinSlot ~= 1)
	self._ui.ButtonSkinNext:SetActive(self._curSkinSlot ~= #self._totalSkinList)

	if self._characterDefaultSkinId == curSkinId then
		self._ui.SkinEquipmentSlot.text = ""
		self._ui.SkinName.text = SAFE_LOC("原始形象")
		self._ui.SkinSlotTxt.text = ""
	else
		self._ui.SkinEquipmentSlot.text = tostring(self._curSkinSlot - 1)
		self._ui.SkinSlotTxt.text = string.format("%d/%d", self._curSkinSlot - 1, #self._totalSkinList - 1)
		self._ui.SkinName.text = ConfigUtils.GetSkinName(curSkinId)
	end

	-- desc
	if self._characterDefaultSkinId == self._characterShowSkinId then
		self._ui.CharacterDesc.text = ConfigUtils.GetCharacterDesc(itemId)
	else
		local skinUnlocked = GameData.IsSkinUnlocked(self._characterShowSkinId)
		self._ui.CharacterDesc.text = ConfigUtils.GetSkinDesc(self._characterShowSkinId, skinUnlocked)
	end

    -- avatar
	local prefabName, prefabBundle = ConfigUtils.GetCharacterPrefab(itemId)
	local prefab = self:DynamicLoadAsset(prefabBundle, prefabName)
	local itemObj = Helper.NewObject(prefab, self._ui.CharacterAvatar, 80)
	itemObj.name = tostring(itemId)
	-- skin
	local skeletonAnimation = itemObj:GetComponent("SkeletonAnimation")
	Helper.PlayAnimation(skeletonAnimation, CharacterAnimations.Idle, true)
	UIHelper.SetCharacterSkinWithSkin(skeletonAnimation, self._characterShowSkinId)
	--[[
	-- skill
	local curSkinId = self._totalSkinList[self._curSkinSlot]
	local characterStage = ConfigUtils.GetCharacterStageLimit(itemId)
	if curSkinId == self._characterDefaultSkinId then
		local hasSkill = ConfigUtils.IsCharacterHasSkill(itemId)
		if not hasSkill then
			self._ui.CharacterSkill.text = "[9F8A83FF]"..SAFE_LOC("loc_CharacterNoSkill").."[-]"
		else
			local activatedSkillDesc = ConfigUtils.GetCharacterSkillDescAt(itemId, characterStage)
			local text = ""
			if activatedSkillDesc ~= nil then
				text = "[42261EFF]"..activatedSkillDesc.."[-]"
			end

			self._ui.CharacterSkill.text = text
		end
	else
		self._ui.CharacterSkill.text ="[42261EFF]" ..ConfigUtils.GetSkinSkillDesc(curSkinId).."[-]"
	end
	--]]
	self:ConstructSkillDec(itemId)
end

function ItemDetailCtrl:ConstructGoods(itemId)
	-- icon
	UIHelper.SetItemIcon(self,self._ui.GoodsIcon, itemId)
	local unlocked = GameData.IsGoodsUnlocked(itemId)
	if unlocked then
		self._ui.GoodsIcon.color = Color.white
	else
		self._ui.GoodsIcon.color = LOCK_ICON_COLOR
	end
	-- name
	self._ui.GoodsName.text = ConfigUtils.GetGoodsName(itemId)
	-- desc
	self._ui.GoodsDesc.text = ConfigUtils.GetGoodsDesc(itemId)
	-- craft
    local recipeId = ConfigUtils.GetGoodsLabRecipe(itemId)
	self._ui.GoodsCraftRoot:SetActive(recipeId ~= nil)
	if recipeId ~= nil then
		local craftSource = ConfigUtils.GetGoodsCraftSource(itemId)
		for idx = 1, #self._ui.GoodsCraftSources do
			local has = (idx <= #craftSource)
			self._ui.GoodsCraftSources[idx].item:SetActive(has)
			if has then
				local craftItemId = craftSource[idx].id
				UIHelper.SetItemIcon(self,self._ui.GoodsCraftSources[idx].icon, craftItemId)
				self._ui.GoodsCraftSources[idx].num.text = "x"..tostring(craftSource[idx].num)
				if GameData.IsGoodsUnlocked(craftItemId) then
					self._ui.GoodsCraftSources[idx].icon.color = Color.white
				else
					self._ui.GoodsCraftSources[idx].icon.color = LOCK_ICON_COLOR
				end
			end
		end
	end
	-- marked
	local marked = GameData.IsItemMarked(itemId)
	self:RefreshMarkState(self._ui.GoodsMark, true, marked)
end

function ItemDetailCtrl:ConstructEquipment(itemId, itemLevel)
	-- icon
	UIHelper.SetEquipmentIcon(self, self._ui.EquipmentIcon, itemId, itemLevel)
	local unlocked = GameData.IsEquipmentUnlocked(itemId)
	if unlocked then
		self._ui.EquipmentIcon.color = Color.white
	else
		self._ui.EquipmentIcon.color = LOCK_ICON_COLOR
	end
	-- name
	self._ui.EquipmentName.text = ConfigUtils.GetEquipmentName(itemId, itemLevel)
	-- desc
	self._ui.EquipmentDesc.text = ConfigUtils.GetEquipmentDesc(itemId, itemLevel)
	-- skill
	local abilityAndSkillList = ConfigUtils.GetEquipmentAbilityAndSkillList(itemId)
	local finalSkillText = ""
	for idx = 1, #abilityAndSkillList do
		local abilityOrSkillId = abilityAndSkillList[idx].id
		local elementType = ConfigUtils.GetItemTypeFromId(abilityOrSkillId)
		if elementType == ItemType.Skill then
			local skillValue = abilityAndSkillList[idx].value
			local unlockLevel = abilityAndSkillList[idx].unlock
			local skillUnlocked = (unlocked and itemLevel >= unlockLevel)
			if skillUnlocked then
				skillValue = ConfigUtils.GetEquipmentSkillValueAtLevel(itemId, itemLevel, abilityOrSkillId)
			end

			local showText = UIHelper.GetSkillShowText(abilityOrSkillId, skillValue)
			if skillUnlocked then
				showText = "[9F8A83FF]"..showText.."[-] [7BFF47FF]"..SAFE_LOC("loc_Activated").."[-]"
			else
				showText = "[42261EFF]"..showText.."[-] [FF0000FF]"..SAFE_LOC("loc_NotActivated").."[-]"
			end

			finalSkillText = finalSkillText..showText.."\n"
		end
	end
	
	self._ui.EquipmentSkill.text = finalSkillText
	-- preview mark
	self._ui.EquipmentPreviewMark:SetActive(false)
end

function ItemDetailCtrl:ConstructPreviewEquipment(itemId, itemLevel)
	itemLevel = ConfigUtils.GetEquipmentMaxLevel(itemId)
	-- icon
	UIHelper.SetEquipmentIcon(self, self._ui.EquipmentIcon, itemId, itemLevel)
	self._ui.EquipmentIcon.color = Color.white
	-- name
	self._ui.EquipmentName.text = ConfigUtils.GetEquipmentName(itemId, itemLevel)
	-- desc
	self._ui.EquipmentDesc.text = ConfigUtils.GetEquipmentDesc(itemId, itemLevel)
	-- skill
	local abilityAndSkillList = ConfigUtils.GetEquipmentAbilityAndSkillList(itemId)
	local finalSkillText = ""
	for idx = 1, #abilityAndSkillList do
		local abilityOrSkillId = abilityAndSkillList[idx].id
		local elementType = ConfigUtils.GetItemTypeFromId(abilityOrSkillId)
		if elementType == ItemType.Skill then
			local skillValue = ConfigUtils.GetEquipmentSkillValueAtLevel(itemId, itemLevel, abilityOrSkillId)
			local showText = UIHelper.GetSkillShowText(abilityOrSkillId, skillValue)
			showText = "[9F8A83FF]"..showText.."[-]"
			finalSkillText = finalSkillText..showText.."\n"
		end
	end
	
	self._ui.EquipmentSkill.text = finalSkillText
	-- preview mark
	self._ui.EquipmentPreviewMark:SetActive(true)
end

function ItemDetailCtrl:ConstructEnemy(itemId, itemLevel)
	-- remove
	for idx = self._ui.EnemyAvatar.childCount, 1, -1 do
		local obj = self._ui.EnemyAvatar:GetChild(idx - 1).gameObject
		destroy(obj)
	end
	-- avatar
	local prefabName, prefabBundle = ConfigUtils.GetEnemyPrefab(itemId)
	local prefab = self:DynamicLoadAsset(prefabBundle, prefabName)
	local itemObj = Helper.NewObject(prefab, self._ui.EnemyAvatar, 80)
	itemObj.name = tostring(itemId)
	-- animation
	local skeletonAnimation = itemObj:GetComponent("SkeletonAnimation")
	Helper.PlayAnimation(skeletonAnimation, CharacterAnimations.Idle, true)
	-- skin
	local skinName = ConfigUtils.GetEnemySkinName(itemId)
	if skinName ~= nil then
		Helper.SetSkin(skeletonAnimation, skinName)
	end
	-- name
	self._ui.EnemyName.text = ConfigUtils.GetEnemyName(itemId)
	-- level
	self._ui.EnemyLevel.text = string.format(SAFE_LOC("loc_SimpleLevel"), itemLevel)
	-- desc
	self._ui.EnemyDesc.text = ConfigUtils.GetEnemyDesc(itemId)
	-- element
	self._ui.EnemyElement.spriteName = ConfigUtils.GetElementIconOfItem(itemId)
	-- ability
	self._abilityList = ConfigUtils.GetEnemyAbilityList(itemId, itemLevel)
	for idx = 1, #self._ui.EnemyAbilities do
		local has = (idx <= #self._abilityList)
		self._ui.EnemyAbilities[idx].item:SetActive(has)
		if has then
			local abilityId = self._abilityList[idx].id
			self._ui.EnemyAbilities[idx].icon.spriteName = ConfigUtils.GetAbilityIcon(abilityId)
			local abilityValue = self._abilityList[idx].value
			self._ui.EnemyAbilities[idx].value.text = "[42261EFF]"..tostring(abilityValue).."[-]"
		end
	end
	local hasDrop = ConfigUtils.IsEnemyHasDrop(itemId)
	self._ui.EnemyDropRoot:SetActive(hasDrop)
	self._ui.EnemySkillRoot:SetActive(false)
	-- desc
	if not hasDrop then
		local skillDesc = ConfigUtils.GetEnemySkillDesc(itemId)
		self._ui.EnemySkillRoot:SetActive(skillDesc ~= nil)
		if skillDesc ~= nil then
			self._ui.EnemySkillDesc.text = skillDesc
		end
	end
	-- hint
	local enemyPet = ConfigUtils.GetPetOfEnemy(itemId)
	if ConfigUtils.IsValidItem(enemyPet) then
		local enemyPetUnlocked = GameData.IsPetUnlocked(enemyPet)
		self._ui.EnemyNoPet:SetActive(false)
		self._ui.EnemyPetLock:SetActive(not enemyPetUnlocked)
		self._ui.EnemyPetUnlock:SetActive(enemyPetUnlocked)
		if enemyPetUnlocked then
			local petLevel = GameData.GetPetLevel(enemyPet)
			self._ui.EnemyPetLevel.text = string.format(SAFE_LOC("该宠物已%d级"), petLevel)
		end
	else
		self._ui.EnemyNoPet:SetActive(true)
	end
	-- drop
	if hasDrop then
		local dropList = ConfigUtils.GetEnemyDropList(itemId)
		for idx = 1, #self._ui.EnemyDropItems do
			local has = (idx <= #dropList)
			self._ui.EnemyDropItems[idx].item:SetActive(has)
			if has then
				local dropId = dropList[idx]
				local root = self._ui.EnemyDropItems[idx].root
				-- drop icon
				UIHelper.ConstructItemIconAndNum(self, root, dropId, nil)
			end
		end
	end
	-- catch item
	local petId = ConfigUtils.GetPetOfEnemy(itemId)
	local showCatchItem = (hasDrop and petId ~= nil)
	self._ui.EnemyCatchRoot:SetActive(showCatchItem)
	if showCatchItem then
		local catchItemList = ConfigUtils.GetPetCatchItemList(petId)
		for idx = 1, #self._ui.EnemyCatchItems do
			local hasCatchItem = (idx <= #catchItemList)
			self._ui.EnemyCatchItems[idx].item:SetActive(hasCatchItem)
			if hasCatchItem then
				local icon = self._ui.EnemyCatchItems[idx].icon
				local catchItemId = catchItemList[idx].Value
				UIHelper.SetItemIcon(self,icon, catchItemId)
			end
		end
	end
end

function ItemDetailCtrl:ConstructPet(itemId)
	local unlocked = GameData.IsPetUnlocked(itemId)
	-- remove
	for idx = self._ui.PetAvatar.childCount, 1, -1 do
		local obj = self._ui.PetAvatar:GetChild(idx - 1).gameObject
		destroy(obj)
	end
	-- avatar
	local prefabName, prefabBundle = ConfigUtils.GetPetPrefab(itemId)
	local prefab = self:DynamicLoadAsset(prefabBundle, prefabName)
	local itemObj = Helper.NewObject(prefab, self._ui.PetAvatar, 80)
	itemObj.name = tostring(itemId)
	-- animation
	local skeletonAnimation = itemObj:GetComponent("SkeletonAnimation")
	Helper.PlayAnimation(skeletonAnimation, CharacterAnimations.Idle, true)
	skeletonAnimation.enabled = unlocked
	-- mesh render
	local meshRenderer = itemObj:GetComponent("MeshRenderer")
	for matIdx = 1, meshRenderer.materials.Length do
		if unlocked then
			meshRenderer.materials:GetValue(matIdx - 1).color = Color.New(1, 1, 1, 1)
		else
			meshRenderer.materials:GetValue(matIdx - 1).color = Color.New(0, 0, 0, 1)
		end
	end
	-- name
	self._ui.PetName.text = ConfigUtils.GetPetName(itemId)
	self._ui.PetDesc.text = ConfigUtils.GetPetDesc(itemId)
	local petLevel, progressNum, levelNum = GameData.GetPetLevel(itemId)
	-- level
	if unlocked then
		self._ui.PetLevel.text = string.format(SAFE_LOC("loc_SimpleLevel"), petLevel)
		if progressNum ~= nil then
			self._ui.PetNum.text = string.format("升级还需%d只", levelNum - progressNum)
			self._ui.PetLevelProgress.fillAmount = progressNum / levelNum
		else
			self._ui.PetNum.text = SAFE_LOC("loc_Max")
			self._ui.PetLevelProgress.fillAmount = 1
		end
	else
		self._ui.PetLevel.text = "??"
		self._ui.PetNum.text = ""
		self._ui.PetLevelProgress.fillAmount = 0
	end
	-- element
	self._ui.PetElement.spriteName = ConfigUtils.GetElementIconOfItem(itemId)
	-- skill
	local hasSkill = ConfigUtils.IsPetHasSkill(itemId)
	if not hasSkill then
		self._ui.PetSkillDesc.text = "[9F8A83FF]"..SAFE_LOC("loc_CharacterNoSkill").."[-]"
	else
		local activatedSkillDesc = ConfigUtils.GetPetSkillDescAt(itemId, petLevel)
		local text = ""
		if activatedSkillDesc ~= nil then
			if unlocked then
				text = "[42261EFF]"..activatedSkillDesc.."[-] [7BFF47FF]"..SAFE_LOC("loc_Activated").."[-]"
			else
				text = "[9F8A83FF]"..activatedSkillDesc.."[-] [FF0000FF]"..SAFE_LOC("loc_NotActivated").."[-]"
			end
		else
			local nextActivatedSkillDesc = ConfigUtils.GetPetNextSkillDescAt(itemId, petLevel)
			text = "[9F8A83FF]"..nextActivatedSkillDesc.."[-] [FF0000FF]"..SAFE_LOC("loc_NotActivated").."[-]"
		end

		self._ui.PetSkillDesc.text = text
	end
	-- ability
	self._abilityList = GameData.GetPetAbilityList(itemId)
	for idx = 1, #self._ui.PetAbilities do
		local has = (idx <= #self._abilityList)
		self._ui.PetAbilities[idx].item:SetActive(has)
		if has then
			local abilityId = self._abilityList[idx].id
			self._ui.PetAbilities[idx].icon.spriteName = ConfigUtils.GetAbilityIcon(abilityId)
			local abilityValue = self._abilityList[idx].value
			self._ui.PetAbilities[idx].value.text = "[42261EFF]"..tostring(abilityValue).."[-]"
		end
	end
	-- catch item
	local catchItemList = ConfigUtils.GetPetCatchItemList(itemId)
	self._ui.PetCatchItemMark:SetActive(#catchItemList > 0)
	if #catchItemList > 0 then
		for idx = 1, #self._ui.PetCatchItems do
			local hasCatchItem = (idx <= #catchItemList)
			self._ui.PetCatchItems[idx].item:SetActive(hasCatchItem)
			if hasCatchItem then
				local icon = self._ui.PetCatchItems[idx].icon
				local catchItemId = catchItemList[idx].Value
				UIHelper.SetItemIcon(self,icon, catchItemId)
			end
		end
	end
	-- marked
	local marked = GameData.IsItemMarked(itemId)
	self:RefreshMarkState(self._ui.PetMark, true, marked)
end

-- room piece
function ItemDetailCtrl:ConstructRoomPiece(itemId)
	-- name
    self._ui.RoomPieceName.text = ConfigUtils.GetRoomPieceName(itemId)
    -- icon
    self._ui.RoomPieceIcon.spriteName = ConfigUtils.GetRoomPieceIcon(itemId)
    -- desc
    self._ui.RoomPieceDesc.text = ConfigUtils.GetRoomPieceDesc(itemId)
    -- unlock
    local unlocked = GameData.IsRoomPieceUnlocked(itemId)
	if unlocked then
		self._ui.RoomPieceIcon.color = Color.white
	else
		self._ui.RoomPieceIcon.color = LOCK_ICON_COLOR
	end
	-- ability
	local abilities = ConfigUtils.GetRoomPiecesAbility(itemId)
	self._ui.RoomPieceAbilityRoot:SetActive(#abilities > 0)
	if #abilities > 0 then
		for idx = 1, #self._ui.RoomPieceAbilities do
			local hasAbility = (idx <= #abilities)
			self._ui.RoomPieceAbilities[idx].item:SetActive(hasAbility)
			if hasAbility then
				local abilityId = abilities[idx].Value
				self._ui.RoomPieceAbilities[idx].icon.spriteName = ConfigUtils.GetAbilityIcon(abilityId)
				local abilityValue = abilities[idx].Num
				self._ui.RoomPieceAbilities[idx].value.text = "[42261EFF]+"..tostring(abilityValue).."[-]"
			end
		end
	end
end

-- lab recipe
function ItemDetailCtrl:ConstructLabRecipe(itemId)
	-- name
	self._ui.LabRecipeName.name = ConfigUtils.GetLabRecipeName(itemId)
	-- icon
	UIHelper.SetItemIcon(self,self._ui.LabRecipeIcon, itemId)
	-- desc
	self._ui.LabRecipeDesc.text = ConfigUtils.GetLabRecipeDesc(itemId)
end

function ItemDetailCtrl:ConstructHomeFurniture(itemId)
	self._ui.pTxtHomeFurnitureName.text = ConfigUtils.GetHomeFurnitureName(itemId)
	UIHelper.SetItemIcon(self, self._ui.pSpriteHomeFurnitureIcon, itemId)
	self._ui.pTxtHomeFurnitureDesc.text = "家具说明"
end

function ItemDetailCtrl:ConstructToken(itemId)
	self._ui.pTxtTokenName.text = ConfigUtils.GetTokenName(itemId)
	UIHelper.SetItemIcon(self, self._ui.pSpriteTokenIcon, itemId)
	self._ui.pTxtTokenDesc.text = ConfigUtils.GetTokenDesc(itemId)
end

function ItemDetailCtrl:ConstructItemSources(sourceRoot, itemId)
	local count = sourceRoot.childCount
	while count > 0 do
		local sourceItem = sourceRoot:GetChild(0)
		sourceItem.parent = self._ui.SourceItemPool
		count = sourceRoot.childCount
	end

	self._itemSources = {}
	if not self._isPreivew then
		self._itemSources = ConfigUtils.GetItemSource(itemId)
	end

	for idx = 1, #self._itemSources do
		local sourceType = self._itemSources[idx].source
		local sourceValue = self._itemSources[idx].value
		local sourceItem = nil
		if self._ui.SourceItemPool.childCount == 0 then
			local itemObj = Helper.NewObject(self._ui.SourceItemTemplate, sourceRoot)
			CtrlManager.AddClick(self, itemObj)

			sourceItem = itemObj.transform
		else
			sourceItem = self._ui.SourceItemPool:GetChild(0)
			sourceItem.parent = sourceRoot
		end

		sourceItem.gameObject:SetActive(true)
		sourceItem.gameObject.name = "SourceItem_"..tostring(idx)
		local sourceLabel = sourceItem:Find("Label"):GetComponent("UILabel")
		sourceLabel.text = UIHelper.GetSourceShowText(sourceType, sourceValue)
	end

	self._ui.CharacterFromBG:SetActive(#self._itemSources > 0)
	self._ui.GoodsFromBG:SetActive(#self._itemSources > 0)
	self._ui.PetFromMark:SetActive(#self._itemSources > 0)

	local tbl = sourceRoot:GetComponent("UITable")
	tbl:Reposition()
end

function ItemDetailCtrl:ForceChangeSpriteColorInHierarchy(item, color)
	local sprite = item:GetComponent("UISprite")
	if sprite ~= nil then
		sprite.color = color
	end

	for idx = 1, item.childCount do
		local childItem = item:GetChild(idx - 1)
		self:ForceChangeSpriteColorInHierarchy(childItem, color)
	end
end

-- update implementation
function ItemDetailCtrl:UpdateImpl(deltaTime)
	if self._animationState ~= nil then
		local finished = self._animationState:Tick(deltaTime)
		if finished then
			self._animationState = nil
		end
	end
end

-- handle the escapse button
function ItemDetailCtrl:HandleEscape()
	self:OnClicked(self._ui.Blocker)
end

-- on pressed
function ItemDetailCtrl:OnPressed(go, pressed, isLong)
	if go.transform.parent == self._ui.CharacterAbilityRoot or 
	   go.transform.parent == self._ui.EnemyAbilityRoot or 
	   go.transform.parent == self._ui.PetAbilityRoot then
		-- long pressed 
		if pressed then
			local names = Helper.StringSplit(go.name)
			assert(#names == 2, "invalid ability item name: "..tostring(go.name))
			local idx = tonumber(names[2])
			local abilityId = self._abilityList[idx].id
			self._ui.AbilityHintLabel.text = ConfigUtils.GetAbilityDesc(abilityId)
			local pos = self._ui.AbilityHintRoot.transform.parent:InverseTransformPoint(go.transform.position)
			self._ui.AbilityHintRoot.transform.localPosition = pos
			self._ui.AbilityHintRoot:SetActive(true)
		elseif not pressed then
			self._ui.AbilityHintRoot:SetActive(false)
		end
	end
end

function ItemDetailCtrl:SelectShowAnimationName(itemId, hasWin)
	local battleResource = ConfigUtils.GeBattleResourceOfItem(itemId)
	local animations = {}

	if hasWin then
		table.insert(animations, CharacterAnimations.ExploreWin)
	end

	local attackAnimations = battleResource.AttackAnim or {}
	for idx = 1, #attackAnimations do
		table.insert(animations, attackAnimations[idx])
	end

	if battleResource.CritAttackAnim ~= nil then
		table.insert(animations, battleResource.CritAttackAnim)
	end

	if battleResource.RangeAttackAnim ~= nil then
		table.insert(animations, battleResource.RangeAttackAnim)
	end

	if battleResource.SkillAnim ~= nil then
		table.insert(animations, battleResource.SkillAnim)
	end

	local idx = Helper.RandInt(1, #animations)
	return animations[idx]
end

-- on clicked
function ItemDetailCtrl:OnClicked(go)
	if go == self._ui.Blocker then
		if #self._itemList <= 1 then
			SoundSystem.PlayUICancelSound()
			CtrlManager.PopPanel()
		else
			SoundSystem.PlayUIClickSound()
			table.remove(self._itemList, #self._itemList)
			self:SwitchCurrentItem()
		end
	elseif go == self._ui.ButtonPrev then
		SoundSystem.PlayUIClickSound()
		local newItemId = self._currentCallback(self._callbackReceiver, self._currentItemId, false)
		if newItemId ~= self._currentItemId then
			self._itemList[#self._itemList].id = newItemId
			self._curSkinSlot = nil
			self:SwitchCurrentItem()
		end
	elseif go == self._ui.ButtonNext then
		SoundSystem.PlayUIClickSound()
		local newItemId = self._currentCallback(self._callbackReceiver, self._currentItemId, true)
		if newItemId ~= self._currentItemId then
			self._itemList[#self._itemList].id = newItemId
			self._curSkinSlot = nil
			self:SwitchCurrentItem()
		end
	elseif go == self._ui.CharacterCollider then
		local unlocked = GameData.IsCharacterUnlocked(self._currentItemId)
		if self._isPreivew or unlocked then
			SoundSystem.PlayUIClickSound()
			local skeletonAnimation = self._ui.CharacterAvatar:GetChild(0):GetComponent("SkeletonAnimation")
			if skeletonAnimation ~= nil then
				local animationName = self:SelectShowAnimationName(self._characterShowSkinId, true)
				self._animationState = SkeletonAnimationState:new(skeletonAnimation, animationName, CharacterAnimations.Idle)
			end
		end
	elseif go == self._ui.EnemyCollider then
		SoundSystem.PlayUIClickSound()
		local skeletonAnimation = self._ui.EnemyAvatar:GetChild(0):GetComponent("SkeletonAnimation")
		if skeletonAnimation ~= nil then
			local animationName = self:SelectShowAnimationName(self._currentItemId, false)
			self._animationState = SkeletonAnimationState:new(skeletonAnimation, animationName, CharacterAnimations.Idle)
		end
	elseif go == self._ui.PetCollider then
		local unlocked = GameData.IsPetUnlocked(self._currentItemId)
		if unlocked then
			SoundSystem.PlayUIClickSound()
			local skeletonAnimation = self._ui.PetAvatar:GetChild(0):GetComponent("SkeletonAnimation")
			if skeletonAnimation ~= nil then
				local animationName = self:SelectShowAnimationName(self._currentItemId, false)
				self._animationState = SkeletonAnimationState:new(skeletonAnimation, animationName, CharacterAnimations.Idle)
			end
		end
	elseif go == self._ui.CharacterMark.gameObject then
		SoundSystem.PlayUIClickSound()
		local marked = GameData.ToggleItemMark(self._currentItemId)
		self:RefreshMarkState(self._ui.CharacterMark, true, marked)
	elseif go == self._ui.GoodsMark.gameObject then
		SoundSystem.PlayUIClickSound()
		local marked = GameData.ToggleItemMark(self._currentItemId)
		self:RefreshMarkState(self._ui.GoodsMark, true, marked)
	elseif go == self._ui.PetMark.gameObject then
		SoundSystem.PlayUIClickSound()
		local marked = GameData.ToggleItemMark(self._currentItemId)
		self:RefreshMarkState(self._ui.PetMark, true, marked)
	elseif go.transform.parent == self._ui.GoodsCraftSourceRoot then
		local names = Helper.StringSplit(go.name)
		assert(#names == 2, "invalid exclusive item name: "..tostring(go.name))
		local idx = tonumber(names[2])
		local craftSource = ConfigUtils.GetGoodsCraftSource(self._currentItemId)
		local goodsId = craftSource[idx].id
		SoundSystem.PlayUIClickSound()
		table.insert(self._itemList, {id = goodsId, level = 1})
		self:SwitchCurrentItem()
	elseif Helper.StartWith(go.name, "SourceItem_") then
		local names = Helper.StringSplit(go.name)
		assert(#names == 2, "invalid exclusive item name: "..tostring(go.name))
		local idx = tonumber(names[2])
		local sourceType = self._itemSources[idx].source
		local sourceValue = self._itemSources[idx].value

		-- no jump
		if sourceType == SourceType.SignIn or 
			sourceType == SourceType.Event then
			return true
		end

		local ret = UIHelper.GetSourceCtrlByItemSource(sourceType, sourceValue)
		if ret.code ~= RetCode.OK then
			SoundSystem.PlayWarningSound()
			local showMsg = UIHelper.GetReturnCodeShowText(ret.code)
			CtrlManager.ShowMessageBox({message = showMsg, single = true})
		else
			SoundSystem.PlayUIClickSound()
			-- for CtrlNames.Laboratory, no need to close the other panel; but need to close item detail panel
			if ret.ctrlName == CtrlNames.Laboratory and not CtrlManager.IsCtrlOpen(CtrlNames.Laboratory) then
				CtrlManager.PopPanel()
			end

			JumpManager.JumpFromItemSource(ret)
		end
	elseif go.transform.parent == self._ui.CharacterEquipmentRoot then
		local unlocked = GameData.IsCharacterUnlocked(self._currentItemId)
		if self._isPreivew or unlocked then
			SoundSystem.PlayUIClickSound()
			local names = Helper.StringSplit(go.name)
			assert(#names == 2, "invalid character equipment item name: "..tostring(go.name))
			local equipIdx = tonumber(names[2])
			local equipmentList = ConfigUtils.GetCharacterEquipmentList(self._currentItemId)
			local equipmentId = equipmentList[equipIdx]
			local equipmentLevel = GameData.GetCharacterEquipmentLevel(self._currentItemId, equipIdx)
			table.insert(self._itemList, {id = equipmentId, level = equipmentLevel})
			self:SwitchCurrentItem()
		end
	elseif go.transform.parent == self._ui.CharacterSkinRoot then
		local unlocked = GameData.IsCharacterUnlocked(self._currentItemId)
		if self._isPreivew or unlocked then
			SoundSystem.PlaySwitchSound()
			local names = Helper.StringSplit(go.name)
			assert(#names == 2, "invalid character skin item name: "..tostring(go.name))
			local skinIdx = tonumber(names[2])
			local skinList = ConfigUtils.GetCharacterSkinList(self._currentItemId)
			local skinId = skinList[skinIdx]
			if self._characterShowSkinId == skinId then
				self._characterShowSkinId = self._characterDefaultSkinId
				if self._isPreivew then
					self:OnPreviewCharacterShowSkinChanged()
				else
					self:OnCharacterShowSkinChanged()
				end
			else
				self._characterShowSkinId = skinId
				if self._isPreivew then
					self:OnPreviewCharacterShowSkinChanged()
				else
					self:OnCharacterShowSkinChanged()
				end
			end
		end
	elseif go.transform.parent == self._ui.PetCatchItemRoot then
		SoundSystem.PlayUIClickSound()
		local names = Helper.StringSplit(go.name)
		assert(#names == 2, "invalid pet catch item name: "..tostring(go.name))
		local idx = tonumber(names[2])
		local catchItemList = ConfigUtils.GetPetCatchItemList(self._currentItemId)
		local itemId = catchItemList[idx].Value
		table.insert(self._itemList, {id = itemId, level = 1})
		self:SwitchCurrentItem()
	elseif go.transform.parent == self._ui.EnemyCatchItemRoot then
		SoundSystem.PlayUIClickSound()
		local petId = ConfigUtils.GetPetOfEnemy(self._currentItemId)
		assert(petId ~= nil, "enemy should have pet id: "..tostring(self._currentItemId))
		local catchItemList = ConfigUtils.GetPetCatchItemList(petId)
		local names = Helper.StringSplit(go.name)
		assert(#names == 2, "invalid enemy catch item name: "..tostring(go.name))
		local idx = tonumber(names[2])
		local itemId = catchItemList[idx].Value
		table.insert(self._itemList, {id = itemId, level = 1})
		self:SwitchCurrentItem()
	elseif go == self._ui.ButtonSkinPreview then
		SoundSystem.PlayUIClickSound()
		self:SwitchSkinUI(false)
	elseif go ==self._ui.ButtonSkinNext then
		SoundSystem.PlayUIClickSound()
		self:SwitchSkinUI(true)
	end

	return true
end

function ItemDetailCtrl:SwitchSkinUI(isNext)
	local slot = self._curSkinSlot
	if isNext then
		if slot ~= #self._totalSkinList then
			slot = slot + 1
		end
	else
		if slot ~= 1 then
			slot = slot - 1
		end
	end
	self._curSkinSlot = slot
	self._characterShowSkinId = self._totalSkinList[self._curSkinSlot]
	if self._isPreivew then
		self:OnPreviewCharacterShowSkinChanged()
	else
		self:OnCharacterShowSkinChanged()
	end

end
