require "FreakPlanet/View/AlertBoxPanel"

local class = require "FreakPlanet/Utils/middleclass"
AlertBoxCtrl  = class(CtrlNames.AlertBox, BaseCtrl)

-- load the ui prefab
function AlertBoxCtrl:LoadPanel()
	self:CreatePanel("AlertBox")
end

-- construct ui panel data
function AlertBoxCtrl:ConstructUI(obj)
	self._ui = AlertBoxPanel.Init(obj)
end

-- fill ui with the data
function AlertBoxCtrl:SetupUI()
	self._callback = nil
	self._ui.Panel:SetActive(false)
	CtrlManager.AddClick(self, self._ui.ButtonConfirm)
end

-- on clicked
function AlertBoxCtrl:OnClicked(go)

	if go == self._ui.ButtonConfirm then
		SoundSystem.PlayUIClickSound()
		self._ui.Panel:SetActive(false)
		if self._callback ~= nil then
			self._callback()
		end
	end

	return true
end

function AlertBoxCtrl:ShowAlert(msg, callback)
	if self._ui == nil then
		return
	end
	
	self._callback = callback
	self._ui.Message.text = msg
	self._ui.Panel:SetActive(true)
end

function AlertBoxCtrl:IsOn()
	return self._ui ~= nil and self._ui.Panel.activeSelf
end