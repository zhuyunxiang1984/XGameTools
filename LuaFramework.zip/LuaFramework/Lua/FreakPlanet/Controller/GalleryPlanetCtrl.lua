require "FreakPlanet/View/GalleryPlanetPanel"

local class = require "FreakPlanet/Utils/middleclass"
GalleryPlanetCtrl  = class(CtrlNames.GalleryPlanet, BaseCtrl)

------------------------------------------------------------
local function GallerySortFunc(idA, idB)
    if idA == nil or idB == nil then
        return false
    end

    local valueA = ConfigUtils.GetGallerySortId(idA)
    local valueB = ConfigUtils.GetGallerySortId(idB)
    return valueA < valueB
end
------------------------------------------------------------
-- load the ui prefab
function GalleryPlanetCtrl:LoadPanel()
	self:CreatePanel("GalleryPlanet")
end

-- construct ui panel data
function GalleryPlanetCtrl:ConstructUI(obj)
	self._ui = GalleryPlanetPanel.Init(obj)
end

-- destructor 
function GalleryPlanetCtrl:DestroyImpl()
    GameNotifier.RemoveListener(GameEvent.GoalChanged, GalleryPlanetCtrl.OnGoalChanged, self)
end

-- fill ui with the data
function GalleryPlanetCtrl:SetupUI()
	local galleryList = ConfigUtils.GetGalleryList()
    table.sort(galleryList, GallerySortFunc)

    for idx = 1, #galleryList do
        local galleryId = galleryList[idx]
        local itemObj = Helper.NewObject(self._ui.GalleryItemTemplate, self._ui.GalleryGrid)
        itemObj.name = tostring(galleryId)
        itemObj:SetActive(true)

        CtrlManager.AddClick(self, itemObj)

        self:ConstructGalleryItem(itemObj.transform, galleryId)
    end

    self._ui.GalleryGrid:GetComponent('UIGrid'):Reposition()

    CtrlManager.AddClick(self, self._ui.Blocker)
    GameNotifier.AddListener(GameEvent.GoalChanged, GalleryPlanetCtrl.OnGoalChanged, self)
end

function GalleryPlanetCtrl:ConstructGalleryItem(item, galleryId)
    local nameLabel = item:Find("Name"):GetComponent("UILabel")
    local pageLabel = item:Find("Page"):GetComponent("UILabel")
    local percentLabel = item:Find("Percent"):GetComponent("UILabel")
    local hintMark = item:Find("Hint").gameObject

    local unlocked = true
    local planetId = ConfigUtils.GetGalleryPlanet(galleryId)
    if planetId ~= nil then
        unlocked = GameData.IsPlanetUnlocked(planetId)
    end
    local unlockRoot = item:Find("Unlock").gameObject
    local lockRoot = item:Find("Lock").gameObject
    unlockRoot:SetActive(unlocked)
    lockRoot:SetActive(not unlocked)

    nameLabel.text = ConfigUtils.GetGalleryName(galleryId)
    pageLabel.text = ConfigUtils.GetGalleryPageText(galleryId)

    local percent = ConfigUtils.CalculateGalleryUnlock(galleryId)
    percentLabel.text = UIHelper.GetShowPercentText(percent)

    local hasHint = GameData.HasUnlockedPostcardOfGallery(galleryId)
    hintMark:SetActive(hasHint)
end

function GalleryPlanetCtrl:OnGoalChanged(goalType)
    if goalType ~= GoalType.Achievement then
        return
    end

    for idx = 1, self._ui.GalleryGrid.childCount do
        local gridItem = self._ui.GalleryGrid:GetChild(idx - 1)
        local hintMark = gridItem:Find("Hint").gameObject

        local galleryId = tonumber(gridItem.gameObject.name)
        local hasHint = GameData.HasUnlockedPostcardOfGallery(galleryId)
        hintMark:SetActive(hasHint)
    end
end

-- on clicked
function GalleryPlanetCtrl:OnClicked(go)

    if go == self._ui.Blocker then
        SoundSystem.PlayUICancelSound()
        CtrlManager.PopPanel()
    elseif go.transform.parent == self._ui.GalleryGrid then
        SoundSystem.PlayUIClickSound()
        local galleryId = tonumber(go.name)
        CtrlManager.OpenPanel(CtrlNames.GalleryDetail, {galleryId = galleryId})
    end

	return true
end
