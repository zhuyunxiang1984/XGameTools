require "FreakPlanet/View/ArenaCharacterPanel"

local class = require "FreakPlanet/Utils/middleclass"
ArenaCharacterCtrl  = class(CtrlNames.ArenaCharacter, CharacterSelectBaseCtrl)

---------------------------------------------------------------
local ABILITY_SORT_COLOR = Color.New(218 / 255, 1, 1, 1)
local ABILITY_NORMAL_COLOR = Color.New(128 / 255, 1, 1, 1)
---------------------------------------------------------------

local function CharacterSortFunc(idA, idB)
	if idA == nil or idB == nil then
		return false
	end

	local markedA = GameData.IsItemMarked(idA)
	local markedB = GameData.IsItemMarked(idB)
	if markedA ~= markedB then
		return markedA
	end

    local selectableMap = CharacterSelectBaseCtrl.GetCharacterSelectableMap()
	if selectableMap ~= nil then
		local selectableA = selectableMap[idA]
		local selectableB = selectableMap[idB]

		if selectableA ~= selectableB then
			return selectableA
		end
	end

	local valueA = 0
    local valueB = 0

    local sortAbilityId, sortPower = CharacterSelectBaseCtrl.GetSortValue()
    if sortAbilityId ~= nil then
        valueA = CharacterSelectBaseCtrl.GetAbilityValueOfCharacter(idA, sortAbilityId)
        valueB = CharacterSelectBaseCtrl.GetAbilityValueOfCharacter(idB, sortAbilityId)
    elseif sortPower then
        valueA = CharacterSelectBaseCtrl.GetPowerValueOfCharacter(idA)
        valueB = CharacterSelectBaseCtrl.GetPowerValueOfCharacter(idB)
    end

    if valueA == valueB then
        valueA = ConfigUtils.GetCharacterRarity(idA)
        valueB = ConfigUtils.GetCharacterRarity(idB)
    end

    if valueA == valueB then
        valueA = GameData.GetCharacterLevel(idA)
        valueB = GameData.GetCharacterLevel(idB)
    end

    if valueA == valueB then
        valueA = ConfigUtils.GetCharacterSortId(idA)
        valueB = ConfigUtils.GetCharacterSortId(idB)
    end

	return valueA > valueB
end

local function PetSortFunc(idA, idB)
	if idA == nil or idB == nil then
		return false
	end

	local markedA = GameData.IsItemMarked(idA)
	local markedB = GameData.IsItemMarked(idB)
	if markedA ~= markedB then
		return markedA
	end

    local valueA = 0
    local valueB = 0

    local sortAbilityId, sortPower = CharacterSelectBaseCtrl.GetSortValue()
    if sortAbilityId ~= nil then
        valueA = CharacterSelectBaseCtrl.GetAbilityValueOfPet(idA, sortAbilityId)
        valueB = CharacterSelectBaseCtrl.GetAbilityValueOfPet(idB, sortAbilityId)
    elseif sortPower then
        valueA = CharacterSelectBaseCtrl.GetPowerValueOfPet(idA)
        valueB = CharacterSelectBaseCtrl.GetPowerValueOfPet(idB)
    end

    if valueA == valueB then
        valueA = ConfigUtils.GetPetRarity(idA)
        valueB = ConfigUtils.GetPetRarity(idB)
    end

    if valueA == valueB then
	   valueA = GameData.GetPetLevel(idA)
	   valueB = GameData.GetPetLevel(idB)
    end

	if valueA == valueB then
		valueA = ConfigUtils.GetPetSortId(idA)
		valueB = ConfigUtils.GetPetSortId(idB)
	end

	return valueA > valueB
end
---------------------------------------------------------------
-- load the ui prefab
function ArenaCharacterCtrl:LoadPanel()
	self:CreatePanel("ArenaCharacter")
end

-- construct ui panel data
function ArenaCharacterCtrl:ConstructUI(obj)
	self._ui = ArenaCharacterPanel.Init(obj)
end

-- destroy implementation
function ArenaCharacterCtrl:DestroyImpl()
	GameNotifier.RemoveListener(GameEvent.CharacterSkinChanged, ArenaCharacterCtrl.OnCharacterSkinChanged, self)
    GameNotifier.RemoveListener(GameEvent.CharacterStageChanged, ArenaCharacterCtrl.OnCharacterStageChanged, self)
    GameNotifier.RemoveListener(GameEvent.CharacterLevelChanged, ArenaCharacterCtrl.OnCharacterLevelChanged, self)
    GameNotifier.RemoveListener(GameEvent.CharacterEquipmentUpgraded, ArenaCharacterCtrl.OnCharacterEquipmentUpgraded, self)
	GameNotifier.RemoveListener(GameEvent.MarkStateChanged, ArenaCharacterCtrl.OnMarkStateChanged, self)

    -- save team
    local characters = self:GetSelectedCharacterList()
    local petId = self._selectedPet
    GameData.SetArenaBattleTeam(self._arenaBattleId, characters, petId)
    GameData.Save()
end

-- fill ui with the data
function ArenaCharacterCtrl:SetupUI()
	self._arenaConfigId = self._parameter.arenaConfigId
	self._arenaId = self._parameter.arenaId
	self._battleIndex = self._parameter.battleIndex
	self._difficulty = self._parameter.difficulty
	local battleList = ConfigUtils.GetBattleListOfArena(self._arenaId)
	self._arenaBattleId = battleList[self._battleIndex]

    self._ui.ItemGridWrap.OnItemUpdate = ArenaCharacterCtrl.OnItemUpdateGlobal
	self._petItemPrefab = self:LoadAsset("PetItem")
	-- arena enemy
	local lastEnemyId = ConfigUtils.GetArenaBattleLastEnmeyAt(self._arenaBattleId, self._difficulty)
	UIHelper.SetCharacterIcon(self, self._ui.ArenaEnemyIcon, lastEnemyId)
	self._ui.ArenaEnemyNameLabel.text = ConfigUtils.GetEnemyName(lastEnemyId)
	self._ui.ArenaEnemyElementIcon.spriteName = ConfigUtils.GetElementIconOfItem(lastEnemyId)
    -- character select mode
    self._characterSelectMode = CharacterSelectMode.Arena
    -- shared data
    local numLimit = ConfigUtils.GetArenaBattleNumCapacity(self._arenaBattleId)
	self:InitializeShared(numLimit, CharacterSortFunc, PetSortFunc)
	self:OnSelectionModeChanged()

    self._selectedPet = nil
    local savedPet = CharacterSelector.GetAreanaSelectedPet(self._arenaBattleId)
    if self._selectedPet ~= savedPet then
        -- in this method it will also call OnSelectedCharacterChanged
        self:ChangeSelectPet(savedPet, false)
    else
	    self:OnSelectedCharacterChanged(false)
    end

    -- buff desc
    local buffDesc = ConfigUtils.GetArenaBuffDesc(self._arenaId)
    self._ui.ArenaBuffRoot:SetActive(buffDesc ~= nil)
    if buffDesc ~= nil then
    	self._ui.ArenaBuffDesc.text = buffDesc
    end

    -- team button default states
    self._ui.ButtonTeamSort:SetActive(false)
    self._ui.ButtonTeamSortConfirm:SetActive(false)
    self._ui.ButtonTeamDelete:SetActive(false)
    self._ui.ButtonTeamDeleteConfirm:SetActive(false)

    -- couple
    CtrlManager.AddClick(self, self._ui.ButtonCouple.gameObject)

    -- sort
    self._sortOn = false
    self._ui.SortRoot:SetActive(false)
    for k, v in pairs(self._ui.SortAbilityItems) do
        CtrlManager.AddClick(self, v.item)
    end
    CtrlManager.AddClick(self, self._ui.ButtonSort)
    CtrlManager.AddClick(self, self._ui.SortPower)

    CtrlManager.AddClick(self, self._ui.ButtonGo)
	CtrlManager.AddClick(self, self._ui.ButtonClose)
	CtrlManager.AddClick(self, self._ui.ButtonCharacter.gameObject)
	CtrlManager.AddClick(self, self._ui.ButtonPet.gameObject)
	CtrlManager.AddClick(self, self._ui.ArenaEnemyIcon.gameObject)
	CtrlManager.AddClick(self, self._ui.ButtonFilter)
    -- team
    CtrlManager.AddClick(self, self._ui.ButtonTeam.gameObject)
    CtrlManager.AddClick(self, self._ui.ButtonTeamSort)
    CtrlManager.AddClick(self, self._ui.ButtonTeamSortConfirm)
    CtrlManager.AddClick(self, self._ui.ButtonTeamDelete)
    CtrlManager.AddClick(self, self._ui.ButtonTeamDeleteConfirm)

	GameNotifier.AddListener(GameEvent.CharacterSkinChanged, ArenaCharacterCtrl.OnCharacterSkinChanged, self)
    GameNotifier.AddListener(GameEvent.CharacterStageChanged, ArenaCharacterCtrl.OnCharacterStageChanged, self)
    GameNotifier.AddListener(GameEvent.CharacterLevelChanged, ArenaCharacterCtrl.OnCharacterLevelChanged, self)
    GameNotifier.AddListener(GameEvent.CharacterEquipmentUpgraded, ArenaCharacterCtrl.OnCharacterEquipmentUpgraded, self)
	GameNotifier.AddListener(GameEvent.MarkStateChanged, ArenaCharacterCtrl.OnMarkStateChanged, self)
end

function ArenaCharacterCtrl:GetInitialCharacters()
    return CharacterSelector.CheckArenaSelectedCharacters(self._arenaBattleId, self._numLimit)
end

function ArenaCharacterCtrl:GetAvatarItem(itemId)
	if itemId == self._selectedPet then
		return self._ui.PetRoot:Find(itemId)
	end

	return self._ui.CharacterRoot:Find(itemId)
end

function ArenaCharacterCtrl:GetItemPrefabAndPool()
	if self._currentMode == ExploreSelectionMode.Character then
		return self._characterItemPrefab, self._ui.CharacterItemPool
	elseif self._currentMode == ExploreSelectionMode.Pet then
		return self._petItemPrefab, self._ui.PetItemPool
	else
		assert(false, "un-handled selection mode: "..tostring(self._currentMode))
	end
end

function ArenaCharacterCtrl:ConstructCharacterItem(item, characterId)
    local sortAbilityId, sortPower = CharacterSelectBaseCtrl.GetSortValue()
    local abilityMap = CharacterSelectBaseCtrl.GetAbilityMapOfCharacter(characterId)
	UIHelper.ConstructCharacterItem(self, item, characterId, abilityMap, sortAbilityId, sortPower)
	local selected = self:IsCharacterSelected(characterId)
	self:RefreshGridItemSelectedState(characterId, selected)
	self:RefreshCharacterStatus(item, characterId)
	-- goal
    local matchGoal = false
    local goalMark = item:Find("Mark/Goal").gameObject
    goalMark:SetActive(matchGoal)
    -- marked
    local marked = GameData.IsItemMarked(characterId)
    local markedMark = item:Find("Mark/Marked").gameObject
    markedMark:SetActive(marked)
end

function ArenaCharacterCtrl:HasPetPositionHint()
    return true
end

function ArenaCharacterCtrl:GetSelectedPet()
    if self:HasPetPositionHint() then
        return self._selectedPet
    else
        return nil
    end

end

function ArenaCharacterCtrl:ConstructPetItem(item, petId)
    local sortAbilityId, sortPower = CharacterSelectBaseCtrl.GetSortValue()
	UIHelper.ConstructPetItem(self, item, petId, sortAbilityId, sortPower)
	-- level
	local levelLabel = item:Find("Level"):GetComponent("UILabel")
	local petLevel = GameData.GetPetLevel(petId)
	levelLabel.text = string.format(SAFE_LOC("loc_SimpleLevel"), petLevel)
	-- selected
	local selected = (self._selectedPet == petId)
	self:RefreshGridItemSelectedState(petId, selected)
	self:RefreshPetStatus(petId)
	-- goal
	local matchGoal = false
	local goalMark = item:Find("Mark/Goal").gameObject
    goalMark:SetActive(matchGoal)
    -- marked
    local marked = GameData.IsItemMarked(petId)
    local markedMark = item:Find("Mark/Marked").gameObject
    markedMark:SetActive(marked)
end

function ArenaCharacterCtrl.OnItemUpdateGlobal(itemObj, itemIndex, itemRealIndex)
	local ctrl = CtrlManager.GetCtrlByName(CtrlNames.ArenaCharacter)
	if ctrl ~= nil then
		ctrl:OnItemUpdate(itemObj, itemIndex, itemRealIndex)
	end
end

function ArenaCharacterCtrl:CalculateFightPower(characters, pet, globalBuffList)
    -- character and pet
    local characterAbilityMaps = GameData.GetGroupAbilityMap(characters, pet, globalBuffList)
    local fightPowerSkills = GameData.GetGroupSkillMap(
        characters, 
        pet, 
        {
            effectAttribute = EffectAttribute.FightPower,
            globalSkills = globalBuffList,
        }
    )

    -- character fight powers
    local finalFightPowers = 0
    for k, abilityMap in pairs(characterAbilityMaps) do
        local thisFightPower = ConfigUtils.GetPowerOfAbilityMap(abilityMap)
        local thisSkills = fightPowerSkills[k] or {}
        local thisSkillMap = {k = thisSkills}
        local addPercent = GameData.GetSkillAddPercentValue(thisSkillMap)
        thisFightPower = Helper.RoundAndCeil(thisFightPower * (1 + addPercent))
        thisFightPower = math.max(thisFightPower, 1)
        finalFightPowers = finalFightPowers + thisFightPower
    end

    return finalFightPowers
end

function ArenaCharacterCtrl:RefreshCharacterAbilities()
	local selectedList = self:GetSelectedCharacterList()
    local globalBuffList = self:GetArenaAndCoupleSkills()
	self._fightPowers = self:CalculateFightPower(selectedList, self._selectedPet, globalBuffList)
	self._ui.CharacterPower.text = "战斗力 "..tostring(self._fightPowers)
end

function ArenaCharacterCtrl:ChangeSelectPet(newPetId, hintSkill)
	if self._selectedPet ~= nil then
		self:RefreshGridItemSelectedState(self._selectedPet, false)
		local item = self._ui.PetRoot:Find(self._selectedPet)
		if item ~= nil then
			item.parent = self._ui.PetPool
		end
	end

	self._selectedPet = newPetId

	if self._selectedPet ~= nil then
		self:RefreshGridItemSelectedState(self._selectedPet, true)
		local petItem = self._ui.PetPool:Find(self._selectedPet)
		if petItem == nil then
			petItem = self:CreateNewPetObj(self._selectedPet)
		else
			petItem.parent = self._ui.PetRoot
		end

		Helper.CheckDirection(petItem, 1)
		local skeletonAnimation = petItem:GetComponent("SkeletonAnimation")
		Helper.PlayAnimation(skeletonAnimation, CharacterAnimations.Idle, true)
	end

	self:OnSelectedCharacterChanged(hintSkill)
end

function ArenaCharacterCtrl:CreateNewPetObj(petId)
	local prefabName, prefabBundle = ConfigUtils.GetPetPrefab(petId)
	local prefab = self:DynamicLoadAsset(prefabBundle, prefabName)
	local petObj = Helper.NewObject(prefab, self._ui.PetRoot, 50)
	petObj.name = tostring(petId)
	petItem = petObj.transform

	NGUITools.AddRawWidget(petObj, 0)
	NGUITools.AddWidgetCollider(petObj)

	local collider = petObj:GetComponent("BoxCollider")
	collider.size = Vector3.New(1.2, 1.5, 0)
	collider.center = Vector3.New(0, 0.75, 0)

	CtrlManager.AddClick(self, petObj)

	return petItem
end

function ArenaCharacterCtrl:RefreshSortState()
    local sortAbilityId, sortPower = CharacterSelectBaseCtrl.GetSortValue()

    for k, v in pairs(self._ui.SortAbilityItems) do
        local unselected = (sortAbilityId == nil or sortAbilityId ~= k)
        v.selected:SetActive(not unselected)
        v.unselected:SetActive(unselected)
    end

    self._ui.SortAbilityRoot:GetComponent("UITable"):Reposition()

    self._ui.SortPowerSelected:SetActive(sortPower)
    self._ui.SortPowerUnselected:SetActive(not sortPower)
end
--------------------------------------------------------
-- on clicked
function ArenaCharacterCtrl:OnClicked(go)
	if go == self._ui.ButtonClose then
		SoundSystem.PlayUICancelSound()
		CtrlManager:PopPanel()	-- arena character
	elseif go == self._ui.ButtonGo then
		if self._arenaConfigId ~= GameData.GetActivatedArenaConfigId() then
			SoundSystem.PlayWarningSound()
			CtrlManager.ShowMessageBox({message = SAFE_LOC("流亡街已刷新"), single = true})
			return true
		end

		local characterList = self:GetSelectedCharacterList()
		if #characterList == 0 then
			SoundSystem.PlayWarningSound()
			CtrlManager.ShowMessageBox({message = SAFE_LOC("请选择角色"), single = true})
			return true
		end

		local petId = self._selectedPet
		local step = self._difficulty
        local globalBuffList = self:GetArenaAndCoupleSkills()
        local verifyData = ConfigUtils.ConstructBattleVerityData(characterList, petId)

		SoundSystem.PlayUIClickSound()
        self:MuteSound()
		NetManager.Send("ArenaStart", {
			ArenaConfigId = self._arenaConfigId,
			ArenaId = self._arenaId,
			ArenaBattleId = self._arenaBattleId,
			BattleIndex = self._battleIndex,
			Step = step,
			CharacterList = characterList,
			PetId = petId or INVALID_ID,
            GlobalBuffs = globalBuffList,
            VerifyData = verifyData,
		}, ArenaCharacterCtrl.OnHandleProto, self)
	elseif go.transform.parent == self._ui.ItemGrid then
		local itemId = tonumber(go.name)

		if self._currentMode == ExploreSelectionMode.Character then
			-- tag not fit
            local selectableMap = CharacterSelectBaseCtrl.GetCharacterSelectableMap()
			if not selectableMap[itemId] then
				SoundSystem.PlayWarningSound()
				return true
			end

            local isBusy = GameData.IsBusyCharacter(itemId, self._characterSelectMode)
			if not isBusy then
				local characterIdx = self:GetExploreCharacterIdx(itemId)
				if characterIdx == nil then
					if #self._selectedCharacters < self._numLimit then
						SoundSystem.PlayUIClickSound()
						self:AppendExploreCharacter(itemId)
					else
						SoundSystem.PlayWarningSound()
						self:NotifyCharacterFull()
					end
				else
					SoundSystem.PlayUIClickSound()
					self:RemoveExploreCharacterAt(characterIdx)
				end
			else
				SoundSystem.PlayWarningSound()
			end
		elseif self._currentMode == ExploreSelectionMode.Pet then
			if self._selectedPet == itemId then
				SoundSystem.PlayUIClickSound()
				self:ChangeSelectPet(nil, true)
			else
                local isBusy = GameData.IsBusyPet(itemId, self._characterSelectMode)
				if not isBusy then
					SoundSystem.PlayUIClickSound()
					self:ChangeSelectPet(itemId, true)
					self._selectedPet = itemId
				else
					SoundSystem.PlayWarningSound()
				end
			end
		end
	elseif go.transform.parent == self._ui.CharacterRoot then
		SoundSystem.PlayUIClickSound()
		local characterId = tonumber(go.name)
		local characterIdx = self:GetExploreCharacterIdx(characterId)
		assert(characterIdx ~= nil, "clicked character but not in explore character list: "..go.name)
		self:RemoveExploreCharacterAt(characterIdx)
	elseif go.transform.parent == self._ui.PetRoot then
		SoundSystem.PlayUIClickSound()
		self:ChangeSelectPet(nil, true)
	elseif go == self._ui.ButtonCharacter.gameObject then
		SoundSystem.PlayUIClickSound()
        CharacterSelectBaseCtrl.ResetFilterName()
		self:RecycleGridItems()
		self._currentMode = ExploreSelectionMode.Character
        self:OnSelectionModeChanged()
	elseif go == self._ui.ButtonPet.gameObject then
		SoundSystem.PlayUIClickSound()
        CharacterSelectBaseCtrl.ResetFilterName()
		self:RecycleGridItems()
		self._currentMode = ExploreSelectionMode.Pet
        self:OnSelectionModeChanged()
    elseif go == self._ui.ButtonTeam.gameObject then
        SoundSystem.PlaySwitchSound()
        CharacterSelectBaseCtrl.ResetFilterName()
        self:RecycleGridItems()
        self._currentMode = ExploreSelectionMode.Team
        self:OnSelectionModeChanged()
        -- team mode no need sort
        if self._sortOn then
            self._sortOn = false
            self._ui.SortRoot:SetActive(false)
        end
    elseif go == self._ui.ButtonCouple.gameObject then
        SoundSystem.PlaySwitchSound()
        CharacterSelectBaseCtrl.ResetFilterName()
        self:RecycleGridItems()
        self._currentMode = ExploreSelectionMode.Couple
        self:OnSelectionModeChanged()
        -- team mode no need sort
        if self._sortOn then
            self._sortOn = false
            self._ui.SortRoot:SetActive(false)
        end
	elseif go == self._ui.ArenaEnemyIcon.gameObject then
		SoundSystem.PlayUIClickSound()
		local itemId, itemLevel = ConfigUtils.GetArenaBattleLastEnmeyAt(self._arenaBattleId, self._difficulty)
		CtrlManager.ShowItemDetail({itemId = itemId, itemLevel = itemLevel})
	elseif go == self._ui.ButtonFilter then
        SoundSystem.PlayUIClickSound()
        self:ShowFilterPanel()
    elseif go == self._ui.ButtonSort then
        SoundSystem.PlayUIClickSound()
        self._sortOn = not self._sortOn
        self._ui.SortRoot:SetActive(self._sortOn)
        if self._sortOn then
            self:RefreshSortState()
        end
    elseif go.transform.parent == self._ui.SortAbilityRoot then
        SoundSystem.PlayUIClickSound()
        local newAbilityId = tonumber(go.name)
        local sortAbilityId, sortPower = CharacterSelectBaseCtrl.GetSortValue()
        if newAbilityId == sortAbilityId then
            sortAbilityId = nil
        else
            sortAbilityId = newAbilityId
        end
        sortPower = false
        CharacterSelectBaseCtrl.SetSortValue(sortAbilityId, sortPower)
        self:RecycleGridItems()
        self:OnSelectionModeChanged()
        self:RefreshSortState()
    elseif go == self._ui.SortPower then
        SoundSystem.PlayUIClickSound()
        local sortAbilityId, sortPower = CharacterSelectBaseCtrl.GetSortValue()
        sortAbilityId = nil
        sortPower = not sortPower
        CharacterSelectBaseCtrl.SetSortValue(sortAbilityId, sortPower)
        self:RecycleGridItems()
        self:OnSelectionModeChanged()
        self:RefreshSortState()
    elseif go == self._ui.ButtonTeamSort then
        if self._teamMode == TeamEditMode.Normal then
            SoundSystem.PlayUIClickSound()
            self:StartSortTeam()
        else
            SoundSystem.PlayWarningSound()
        end
    elseif go == self._ui.ButtonTeamDelete then
        if self._teamMode == TeamEditMode.Normal then
            SoundSystem.PlayUIClickSound()
            self:StartDeleteTeam()
        else
            SoundSystem.PlayWarningSound()
        end
    elseif go == self._ui.ButtonTeamSortConfirm then
        SoundSystem.PlayUIClickSound()
        self:BackToNormalTeam()
    elseif go == self._ui.ButtonTeamDeleteConfirm then
        SoundSystem.PlayUIClickSound()
        self:BackToNormalTeam()
    elseif go.transform.parent == self._ui.TeamGrid then
        if self._teamMode == TeamEditMode.Normal then
            local idx = tonumber(go.name)
            self:UseTeam(idx)
        end
    elseif go.transform.parent == self._ui.CoupleGrid then
        local coupleId = tonumber(go.name)
        self:UseCouple(coupleId)
    elseif go.name == "ButtonDelete" then
        SoundSystem.PlayUIClickSound()
        local idx = tonumber(go.transform.parent.gameObject.name)
        self:DeleteTeam(idx)
    elseif go.name == "ButtonRename" then
        local idx = tonumber(go.transform.parent.gameObject.name)
        self:RenameTeam(idx)
    elseif go.name == "ButtonMoveUp" then
        SoundSystem.PlayUIClickSound()
        local idx = tonumber(go.transform.parent.gameObject.name)
        self:MoveUpTeam(idx)
    elseif go.name == "ButtonMoveDown" then
        SoundSystem.PlayUIClickSound()
        local idx = tonumber(go.transform.parent.gameObject.name)
        self:MoveDownTeam(idx)
    elseif go.name == "ButtonSave" or go.name == "ButtonReplace" then
        SoundSystem.PlayUIClickSound()
        local idx = tonumber(go.transform.parent.gameObject.name)
        local charactes = self:GetSelectedCharacterList()
        self:ReplaceTeam(idx, charactes, self._selectedPet)
	end

	return true
end

-- on pressed
function ArenaCharacterCtrl:OnPressed(go, pressed, isLong)
	if pressed and isLong then
		if go.transform.parent == self._ui.ItemGrid then
			local itemId = tonumber(go.name)
			local itemType = ConfigUtils.GetItemTypeFromId(itemId)
			if itemType == ItemType.Character then
				SoundSystem.PlayUIClickSound()
				CtrlManager.OpenPanel(CtrlNames.CharacterQuickDetail, {characterId = itemId})
			elseif itemType == ItemType.Pet then
				SoundSystem.PlayUIClickSound()
				CtrlManager.ShowItemDetail({itemId = itemId})
			end
		elseif go.transform.parent == self._ui.CharacterRoot then
			local characterId = tonumber(go.name)
			self:StartDrag(characterId)
		end
	elseif not pressed and self._dragCharacterId ~= nil then
		self:EndDrag()
	end
end
--------------------------------------------------------
function ArenaCharacterCtrl:OnHandleProto(proto, data, requestData)
	if proto == "ArenaStart" then
		local arenaConfigId = requestData.ArenaConfigId
		local arenaId = requestData.ArenaId
		local arenaBattleId = requestData.ArenaBattleId
		local battleIndex = requestData.BattleIndex
		local difficulty = requestData.Step
		local characterList = requestData.CharacterList
		local petId = requestData.PetId
        local globalBuffs = requestData.GlobalBuffs
		local challengeData = data.ChallengeData
		local seed = data.ServerTime

		CtrlManager.OpenPanel(CtrlNames.Battle, {
			arenaConfigId = arenaConfigId,
			arenaId = arenaId,
			arenaBattleId = arenaBattleId,
			battleIndex = battleIndex,
			difficulty = difficulty,
			characterList = characterList,
			petId = petId,
			challengeData = challengeData,
            globalBuffs = globalBuffs,
			seed = seed,
		})
	end
end
--------------------------------------------------------
-- skills
function ArenaCharacterCtrl:GetSkillMapOfMembers()
	local attributes = {}
	attributes[EffectAttribute.Ability] = 1
	attributes[EffectAttribute.CritChance] = 1
	attributes[EffectAttribute.CritDamage] = 1
	attributes[EffectAttribute.DamageFromCritDamage] = 1
	attributes[EffectAttribute.ExtraAttack] = 1
	attributes[EffectAttribute.Dodge] = 1
    attributes[EffectAttribute.DodgeIgnore] = 1
	attributes[EffectAttribute.DamageToElement] = 1
	attributes[EffectAttribute.DamageFromElement] = 1
	attributes[EffectAttribute.EnemyAbility] = 1
    attributes[EffectAttribute.SpecificEnemyAbility] = 1

	local characterList = {}
	for idx = 1, #self._selectedCharacters do
		characterList[idx] = self._selectedCharacters[idx].id
	end

	local ret = {}

	for idx = 1, #characterList do
		local characterId = characterList[idx]
		local skillList = GameData.GetCharacterSkillList(characterId)
		for skillIdx = 1, #skillList do
			local skillId = skillList[skillIdx].id
			local skillValue = skillList[skillIdx].value
			if self:ShouldShowMemberSkill(skillId, attributes) then
				local isMatch, matchCount = GameData.IsSkillConditionMatch(skillId, characterId, idx, characterList)
				if isMatch then
					local effectMembers = GameData.GetSkillEffectedMembers(skillId, characterId, idx, characterList)
					if ret[characterId] == nil then
						ret[characterId] = {}
					end
					table.insert(ret[characterId], {id = skillId, value = skillValue, target = effectMembers, matchCount = matchCount})
				end
			end
		end
	end

	if ConfigUtils.IsValidItem(self._selectedPet) then
		local skillList = GameData.GetPetSkillList(self._selectedPet)
		for skillIdx = 1, #skillList do
			local skillId = skillList[skillIdx].id
			local skillValue = skillList[skillIdx].value
			if self:ShouldShowMemberSkill(skillId, attributes) then
				local isMatch, matchCount = GameData.IsSkillConditionMatch(skillId, self._selectedPet, nil, characterList)
				if isMatch then
					local effectMembers = GameData.GetSkillEffectedMembers(skillId, self._selectedPet, nil, characterList)
					if ret[self._selectedPet] == nil then
						ret[self._selectedPet] = {}
					end
					table.insert(ret[self._selectedPet], {id = skillId, value = skillValue, target = effectMembers, matchCount = matchCount})
				end
			end
		end
	end

	return ret
end

function ArenaCharacterCtrl:FindAvatarItem(memberId)
	if memberId == nil then
		return nil
	end

	if memberId == self._selectedPet then
		local petItem = self._ui.PetRoot:Find(memberId)
        local petSkeletonAnimation = petItem:GetComponent("SkeletonAnimation")
        return petItem, petSkeletonAnimation
	end

	for idx = 1, #self._selectedCharacters do
		if self._selectedCharacters[idx].id == memberId then
			return self._selectedCharacters[idx].item, self._selectedCharacters[idx].skeletonAnimation
		end
	end

	return nil
end

function ArenaCharacterCtrl:IsMemberStillSelected(memberId)
	if memberId == nil then
		return false
	end

	if memberId == self._selectedPet then
		return true
	end

	for idx = 1, #self._selectedCharacters do
		if self._selectedCharacters[idx].id == memberId then
			return true
		end
	end

	return false
end

function ArenaCharacterCtrl:MatchableAbilityMap()
	local ret = {}

	ret[AbilityType.HP] = 1
	ret[AbilityType.ATK] = 1
	ret[AbilityType.DEF] = 1
	ret[AbilityType.LUK] = 1

	return ret
end

function ArenaCharacterCtrl:GetCoupleKey()
    return CoupleNodeKey.Challenge
end