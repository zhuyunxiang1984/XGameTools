require "FreakPlanet/View/ExploreSpeedUpPanel"

local class = require "FreakPlanet/Utils/middleclass"
ExploreSpeedUpCtrl  = class(CtrlNames.ExploreSpeedUp, BaseCtrl)
local MIN_SHOW_ITEM_NUM = 15
-- load the ui prefab
function ExploreSpeedUpCtrl:LoadPanel()
	self:CreatePanel("ExploreSpeedUp")
end

-- construct ui panel data
function ExploreSpeedUpCtrl:ConstructUI(obj)
	self._ui = ExploreSpeedUpPanel.Init(obj)
end

-- destroy implementation
function ExploreSpeedUpCtrl:DestroyImpl()
	if self._enterBattleHandle ~= nil then
		GlobalScheduler:Cancel(self._enterBattleHandle)
		self._enterBattleHandle = nil
	end
end

-- fill ui with the data
function ExploreSpeedUpCtrl:SetupUI()
	self._areaId = self._parameter.areaId
	self._activityThemeId = self._parameter.themeId
	self._firstSpeedUp = false
	if self._areaId ~= nil then
		-- only valid for area explore
		self._firstSpeedUp = GameData.IsFirstExploreSettle()
		-- enemy list
		self._enemyList = GameData.GetMeetEnemyListOfArea(self._areaId)
		-- name
		self._ui.Name.text = ConfigUtils.GetAreaName(self._areaId)
		-- time
		local startTime, endTime = GameData.GetExploreTimeOfPlanetArea(self._areaId)
		self._endTime = endTime
		self._cancelEndTime = math.min(startTime + ExploreCancelTime, endTime)
		-- explore bg
		local bgName, bgAtlas, bgBundle = ConfigUtils.GetAreaBG(self._areaId)
		self._ui.ExploreAreaBG.sprite2D = self:DynamicLoadSprite(bgBundle, bgAtlas, bgName)
	elseif self._activityThemeId ~= nil then
		-- explore id
		self._activityExploreId = ConfigUtils.GetActivityThemeExplore(self._activityThemeId)
		-- enemy list
		self._enemyList = GameData.GetMeetEnemyListOfActivityExplore(self._activityThemeId)
		-- name
		self._ui.Name.text = ConfigUtils.GetActivityExploreName(self._activityExploreId)
		-- time
		local startTime, endTime = GameData.GetActivityExploreTime(self._activityThemeId)
		self._endTime = endTime
		self._cancelEndTime = math.min(startTime + ExploreCancelTime, endTime)
		-- explore bg
		local bgName, bgAtlas, bgBundle = ConfigUtils.GetActivityExploreBG(self._activityExploreId)
		self._ui.ExploreAreaBG.sprite2D = self:DynamicLoadSprite(bgBundle, bgAtlas, bgName)
	else
		assert(false, "un-handled speed up situation")
	end

	self._ui.PropsPanel:SetActive(false)
	self._battleState = nil
	self._showCancel = self:ShowCancelButton()
	self._ui.ButtonCancel:SetActive(self._showCancel)
	if self._showCancel then
		self._ui.CancelCost.text = tostring(ExploreCancelCostDiamond)
		self._ui.CancelLeftTime.text = ""
	end

	self:ConstructScene()
	self:RefreshSpeedUpCost()
	self:PrepareForBattle()

	CtrlManager.AddClick(self, self._ui.Blocker)
	CtrlManager.AddClick(self, self._ui.ButtonSpeedUp)
	CtrlManager.AddClick(self, self._ui.ButtonCancel)
	CtrlManager.AddClick(self, self._ui.ButtonDetail)
	CtrlManager.AddClick(self, self._ui.PropsBlock)

	-- only need check for area explore
	if self._areaId ~= nil then
		self:CheckTutorial()
	end
end

function ExploreSpeedUpCtrl:PrepareForBattle()
	if #self._enemyList > 0 then
		local delay = Helper.RandFloat(3, 5)
		self._enterBattleHandle = GlobalScheduler:DoActionAfterTime(delay, ExploreSpeedUpCtrl.EnterBattleScene, self)
	else
		self._enterBattleHandle = nil
	end
end

function ExploreSpeedUpCtrl:GetExploringCharacters(includePet)
	local characters = {}
	local pet = nil
	if self._areaId ~= nil then
		characters = GameData.GetPlanetAreaExploreCharacters(self._areaId)
		pet = GameData.GetPlanetAreaExplorePet(self._areaId)
	elseif self._activityThemeId ~= nil then
		characters = GameData.GetActivityExploreCharacters(self._activityThemeId)
		pet = GameData.GetActivityExplorePet(self._activityThemeId)
	end

	if ConfigUtils.IsValidItem(pet) and includePet then
		table.insert(characters, pet)
	end

	return characters
end

function ExploreSpeedUpCtrl:ConstructScene()
	local characters = self:GetExploringCharacters(true)
	for idx = 1, #self._ui.CharacterItems do
		local hasCharacter = (idx <= #characters)
		local item = self._ui.CharacterItems[idx].item
		item:SetActive(hasCharacter)
		if hasCharacter then
			local memberId = characters[idx]
			local memberType = ConfigUtils.GetItemTypeFromId(memberId)
			-- prefab
			local prefabName = nil
			local prefabBundle = nil
			local isPet = (memberType == ItemType.Pet)
			if isPet then
				prefabName, prefabBundle = ConfigUtils.GetPetPrefab(memberId)
			else
				prefabName, prefabBundle = ConfigUtils.GetCharacterPrefab(memberId)
			end

			local avatarRoot = self._ui.CharacterItems[idx].avatar
			local avatarScale = ConfigUtils.GetItemAvatarScale(memberId)
			local avatarPrefab = self:DynamicLoadAsset(prefabBundle, prefabName)
			local memberObj = Helper.NewObject(avatarPrefab, avatarRoot, avatarScale)
			memberObj.name = tostring(memberId)
			-- skeleton animation
			local skeleton = memberObj:GetComponent("SkeletonAnimation")
			Helper.PlayAnimation(skeleton, CharacterAnimations.Walk, true)
			if not isPet then
				UIHelper.SetCharacterSkin(skeleton, memberId)
			end
		end
	end
end

function ExploreSpeedUpCtrl:EnterBattleScene()
	local num = self._ui.EnemyAvatar.childCount
	for idx = num, 1, -1 do
		local item = self._ui.EnemyAvatar:GetChild(idx - 1)
		item.parent = self._ui.AvatarPool
	end

	local enemyIdx = Helper.RandInt(1, #self._enemyList)
	local enemyId = self._enemyList[enemyIdx]
	local enemyItem = self._ui.EnemyAvatar:Find(enemyId)
	local avatarScale = ConfigUtils.GetItemAvatarScale(enemyId)

	if enemyItem == nil then
		local avatarPrefabName, avatarBundleName = ConfigUtils.GetEnemyPrefab(enemyId)
		local avatarPrefab = self:DynamicLoadAsset(avatarBundleName, avatarPrefabName)
		local enemyObj = Helper.NewObject(avatarPrefab, self._ui.EnemyAvatar, avatarScale)
		enemyObj.name = tostring(enemyId)
		-- animation
		local skeleton = enemyObj:GetComponent("SkeletonAnimation")
		Helper.PlayAnimation(skeleton, CharacterAnimations.Idle, true)
		-- skin
		local skinName = ConfigUtils.GetEnemySkinName(enemyId)
		if skinName ~= nil then
			Helper.SetSkin(skeleton, skinName)
		end
		enemyItem = enemyObj.transform
	else
		enemyItem.parent = self._ui.EnemyAvatar
		enemyItem.localPosition = Vector3.zero
		enemyItem.localScale = Vector3.one * avatarScale
	end

	self._enterBattleHandle = nil
	self._ui.TweenOfBG.enabled = false
	self._battleState = AnimatorState:new(self._ui.SceneAnimator, "Explore_Battle", "Explore_Idle")
	self._battleState:ActionOnExit(ExploreSpeedUpCtrl.OnBattleFinished, self)
end

function ExploreSpeedUpCtrl:OnBattleFinished()
	self._ui.TweenOfBG.enabled = true
	self:PrepareForBattle()
end

function ExploreSpeedUpCtrl:UpdateImpl(deltaTime)
	self:RefreshSpeedUpCost()
	self:RefreshCancelState()

	if self._battleState ~= nil then
		local finished = self._battleState:Tick(deltaTime)
		if finished then
			self._battleState = nil
		end
	end
end

function ExploreSpeedUpCtrl:RefreshSpeedUpCost()
	local currentTime = GameData.GetServerTime()
	local leftTime = self._endTime - currentTime
	leftTime = math.max(0, leftTime)
	if self._firstSpeedUp then
		self._cost = 0
	else
		self._cost = ConfigUtils.GetSpeedUpDiamondCost(leftTime)
	end
	self._ui.SpeedUpCost.text = tostring(self._cost)

	if leftTime > 0 then
		self._ui.LeftTime.text = Helper.FormatTime(leftTime)
	else
		self._ui.LeftTime.text = SAFE_LOC("loc_Completed")
	end

	local curValue = GameData.GetMoney(ItemType.Diamond)
	if self._cost > curValue then
		self._ui.SpeedUpCost.color = Color.red
	else
		self._ui.SpeedUpCost.color = self._ui.NormalHint
	end
end

function ExploreSpeedUpCtrl:RefreshCancelState()
	if not self._showCancel then
		return
	end

	local curValue = GameData.GetMoney(ItemType.Diamond)
	if ExploreCancelCostDiamond > curValue then
		self._ui.CancelCost.color = Color.red
	else
		self._ui.CancelCost.color = self._ui.NormalHint
	end

	local currentTime = GameData.GetServerTime()
	local leftTime = self._cancelEndTime - currentTime
	if leftTime > 0 then
		self._ui.CancelLeftTime.text = Helper.FormatTime(leftTime)
	else
		self._showCancel = false
		self._ui.ButtonCancel:SetActive(false)
	end
end

function ExploreSpeedUpCtrl:ShowCancelButton()
	if self._firstSpeedUp then
		return false
	end

	if not GameData.IsModuleUnlocked(ModuleNames.ExploreCancel) then
		return false
	end

	local currentTime = GameData.GetServerTime()
	return currentTime < self._cancelEndTime
end

function ExploreSpeedUpCtrl:OnSpeedUpConfirm()
	local currentTime = GameData.GetServerTime()
	local leftTime = self._endTime - currentTime
	if leftTime > 0 then
		SoundSystem.PlayMoneySound()
		if self._areaId ~= nil then
			NetManager.Send("ExploreAccelerate", {AreaId = self._areaId}, ExploreSpeedUpCtrl.OnHandleProto, self)
		elseif self._activityThemeId ~= nil then
			NetManager.Send("ActivityExploreAccelerate", {
				ActivityThemeId = self._activityThemeId,
				ActivityExploreId = self._activityExploreId,
			}, ExploreSpeedUpCtrl.OnHandleProto, self)
		end
	else
		-- time is already ok, go to result panel
		SoundSystem.PlayUIClickSound()
		CtrlManager.PopPanel()
		CtrlManager.OpenPanel(CtrlNames.ExploreResult, {areaId = self._areaId, themeId = self._activityThemeId})
	end
end

function ExploreSpeedUpCtrl:OnCancelConfirm()
	if self._showCancel then
		if self._areaId ~= nil then
			NetManager.Send("ExploreCancel", {AreaId = self._areaId}, ExploreSpeedUpCtrl.OnHandleProto, self)
		elseif self._activityThemeId ~= nil then
			NetManager.Send("ActivityExploreCancel", {
				ActivityThemeId = self._activityThemeId,
				ActivityExploreId = self._activityExploreId,
			}, ExploreSpeedUpCtrl.OnHandleProto, self)
		end
	end
end

-- on clicked
function ExploreSpeedUpCtrl:OnClicked(go)
	if go == self._ui.Blocker then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
	elseif go == self._ui.ButtonSpeedUp then
		local curValue = GameData.GetMoney(ItemType.Diamond)
		if curValue < self._cost then
			SoundSystem.PlayWarningSound()
			CtrlManager.ShowMessageBox({message = SAFE_LOC("loc_DiamondNotEnough"), single = true})
			return true
		end

		local currentTime = GameData.GetServerTime()
		local leftTime = self._endTime - currentTime
		if not self._firstSpeedUp and leftTime > 0 then
			SoundSystem.PlayUIClickSound()
			CtrlManager.ShowMessageBox({
				message = SAFE_LOC("确认消耗玉璧加速？"),
				single = false,
				onConfirm = ExploreSpeedUpCtrl.OnSpeedUpConfirm,
				receiver = self
			})
		else
			self:OnSpeedUpConfirm()
		end

		return true
	elseif go == self._ui.ButtonCancel then
		if not self._showCancel then
			return true
		end

		local curValue = GameData.GetMoney(ItemType.Diamond)
		if curValue < ExploreCancelCostDiamond then
			SoundSystem.PlayWarningSound()
			CtrlManager.ShowMessageBox({message = SAFE_LOC("loc_DiamondNotEnough"), single = true})
			return true
		end

		SoundSystem.PlayUIClickSound()
		CtrlManager.ShowMessageBox({
			message = string.format(SAFE_LOC("确定花费%d玉璧手续费撤回探索？"), ExploreCancelCostDiamond),
			single = false,
			onConfirm = ExploreSpeedUpCtrl.OnCancelConfirm,
			receiver = self
		})
	elseif go == self._ui.ButtonDetail then
		SoundSystem.PlayUIClickSound()
		self:OnButtonCarryDetail()
	elseif go == self._ui.PropsBlock then
		self._ui.PropsPanel:SetActive(false)
	end

	return true
end
--------------------------------------------------------
function ExploreSpeedUpCtrl:OnHandleProto(proto, data, requestData)
	if proto == "ExploreAccelerate" then
		local areaId = requestData.AreaId

		local goldNum = data.RemainGold
		local diamondNum = data.RemainDiamond

		GameData.SpeedUpExploreOfPlanetArea(areaId)
		GameData.SetMoney(ItemType.Gold, goldNum)
		GameData.SetMoney(ItemType.Diamond, diamondNum)

		CtrlManager.PopPanel() -- explore result panel
		CtrlManager.OpenPanel(CtrlNames.ExploreResult, {areaId = areaId})
	elseif proto == "ExploreCancel" then
		local areaId = requestData.AreaId

		local goldNum = data.RemainGold
		local diamondNum = data.RemainDiamond

		GameData.CancelExploreOfPlanetArea(areaId)
		GameData.SetMoney(ItemType.Gold, goldNum)
		GameData.SetMoney(ItemType.Diamond, diamondNum)

		CtrlManager.PopPanel()
	elseif proto == "ActivityExploreAccelerate" then
		local themeId = requestData.ActivityThemeId
		local exploreId = requestData.ActivityExploreId

		local goldNum = data.RemainGold
		local diamondNum = data.RemainDiamond

		GameData.SpeedUpActivityExplore(themeId)
		GameData.SetMoney(ItemType.Gold, goldNum)
		GameData.SetMoney(ItemType.Diamond, diamondNum)

		CtrlManager.PopPanel() -- explore result panel
		CtrlManager.OpenPanel(CtrlNames.ExploreResult, {themeId = self._activityThemeId})
	elseif proto == "ActivityExploreCancel" then
		local themeId = requestData.ActivityThemeId
		local exploreId = requestData.ActivityExploreId

		local goldNum = data.RemainGold
		local diamondNum = data.RemainDiamond

		GameData.CancelExploreOfActivityExplore(themeId)
		GameData.SetMoney(ItemType.Gold, goldNum)
		GameData.SetMoney(ItemType.Diamond, diamondNum)

		CtrlManager.PopPanel()
	end
end

--------------------------------------------------------
-- tutorial
function ExploreSpeedUpCtrl:CheckTutorial()
	local tutorials = {}

	if GameData.IsTutorialNotFinished(Tutorials.Tutorial_1_12) then
		local position = self._ui.Camera:WorldToScreenPoint(self._ui.ButtonSpeedUp.transform.position)
		tutorials[1] = {event = Tutorials.Tutorial_1_11, position = position, sender = self}
	end

	if #tutorials > 0 then
		self._isShowingTutorial = true
		CtrlManager.ShowTutorials(tutorials)
	end

	return #tutorials > 0
end
 
function ExploreSpeedUpCtrl:OnTutorialClicked(tutorial)
	if tutorial == Tutorials.Tutorial_1_11 then
		self:OnClicked(self._ui.ButtonSpeedUp)
	end
end
--------------------------------------------------------
---展示探索中携带的物品(实物,陷阱,道具)
function ExploreSpeedUpCtrl:OnButtonCarryDetail()
	self._ui.PropsPanel:SetActive(true)
	local characters = self:GetExploringCharacters(false)

	self._itemNumLimit = 0
	for idx = 1, #characters do
		local characterId = characters[idx]
		local stage = GameData.GetCharacterCurrentStage(characterId)
		self._itemNumLimit = self._itemNumLimit + stage
	end

	local showNum = math.max(self._itemNumLimit, MIN_SHOW_ITEM_NUM)
	self._selectedItems = self:GetSelectedExploreItems(showNum, self._itemNumLimit)
	for idx = 1, showNum do
		if self._ui.PropsUIGrid.childCount < showNum then
			local itemObj = Helper.NewObject(self._ui.PropsItemPrefab, self._ui.PropsUIGrid)
			itemObj.name = tostring(idx)
			itemObj:SetActive(true)
			self:ConstructSelectedItem(itemObj.transform, idx)
		end
	end

	self._ui.PropsUIGrid:GetComponent("UIGrid"):Reposition()
end

function ExploreSpeedUpCtrl:ConstructSelectedItem(item, idx)
	if item == nil then
		item = self._ui.PropsUIGrid:Find(tostring(idx))
	end
	local showRoot = idx <= self._itemNumLimit
	local itemRoot = item:Find("Root")
	itemRoot.gameObject:SetActive(showRoot)
	if showRoot then
		local itemId = self._selectedItems[idx]
		local iconSprite = item:Find("Root/Icon"):GetComponent("UISprite")
		if ConfigUtils.IsValidItem(itemId) then
			iconSprite.gameObject:SetActive(true)
			UIHelper.SetItemIcon(self,iconSprite, itemId)
		else
			iconSprite.gameObject:SetActive(false)
		end
	end
end

function ExploreSpeedUpCtrl:GetSelectedExploreItems(showNum, numLimit)
	local itemList = {}
	for i = 1, showNum do
		local recordItemId = INVALID_ID
		if i <= numLimit then
			recordItemId = self:GetGameDataSelectedItems(i)
		end

		if ConfigUtils.IsValidItem(recordItemId) then
			table.insert(itemList, recordItemId)
		end
	end

	for i = #itemList + 1, showNum do
		table.insert(itemList, INVALID_ID)
	end

	return itemList
end

function ExploreSpeedUpCtrl:GetGameDataSelectedItems(idx)
	local selectedExploreItems = nil
	if self._areaId ~= nil then
		selectedExploreItems = GameData.GetPlanetAreaExploreItems(self._areaId)
	elseif self._activityThemeId ~= nil then
		selectedExploreItems = GameData.GetPlanetAreaExploreItems(self._activityThemeId)
	end

	if selectedExploreItems == nil then
		return INVALID_ID
	end

	local itemId = selectedExploreItems[idx]
	if not ConfigUtils.IsValidItem(itemId) then
		return INVALID_ID
	end

	local unlocked = GameData.IsItemUnlocked(itemId)
	if not unlocked then
		return INVALID_ID
	end

	return itemId
end

--------------------------------------------------------