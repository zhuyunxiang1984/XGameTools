require "FreakPlanet/View/SpaceTravelNumberPanel"

local class = require "FreakPlanet/Utils/middleclass"
SpaceTravelNumberCtrl  = class(CtrlNames.SpaceTravelNumber, BaseCtrl)

-- load the ui prefab
function SpaceTravelNumberCtrl:LoadPanel()
	self:CreatePanel("SpaceTravelNumber")
end

-- construct ui panel data
function SpaceTravelNumberCtrl:ConstructUI(obj)
	self._ui = SpaceTravelNumberPanel.Init(obj)
end

-- fill ui with the data
function SpaceTravelNumberCtrl:SetupUI()
    self._itemId = self._parameter.itemId
    self._numLimit = self._parameter.numLimit
    self._itemNum = 0
    self._isDraging = false

    self._ui.ItemName.text = ConfigUtils.GetSpaceTravelGoodsName(self._itemId)
    UIHelper.SetItemIcon(self,self._ui.ItemIcon, self._itemId)

    self:OnSelectedNumChanged(true)

    CtrlManager.AddClick(self, self._ui.Blocker)
    CtrlManager.AddClick(self, self._ui.ButtonConfirm)
    CtrlManager.AddClick(self, self._ui.ButtonPlus)
    CtrlManager.AddClick(self, self._ui.ButtonMinus)
    CtrlManager.AddPress(self, self._ui.ButtonCollider)
end

-- update implementation
function SpaceTravelNumberCtrl:UpdateImpl(deltaTime)
    if self._isDraging then
        local newNum = self:MapNumber(Input.mousePosition)
        if newNum ~= self._itemNum then
            self._itemNum = newNum
            self:OnSelectedNumChanged(false)
        end
    end
end

function SpaceTravelNumberCtrl:OnSelectedNumChanged(syncPercent)
    self._ui.ItemNum.text = tostring(self._itemNum)

    local percent = 1
    if self._numLimit > 0 then
        percent = self._itemNum / self._numLimit
    end

    if syncPercent then
        self._ui.ProgressSlider.value = percent
    end
end

function SpaceTravelNumberCtrl:MapNumber(screenPos)
    if self._numLimit == 0 then
        return 0
    end

    local worldPos = self:ScreenToWorld(screenPos)
    local len = (self._ui.Right.position.x - self._ui.Left.position.x)
    local percent = (worldPos.x - self._ui.Left.position.x) / len
    percent = math.max(percent, 0)
    percent = math.min(percent, 1)
    self._ui.ProgressSlider.value = percent
    return math.floor(self._numLimit * percent + 0.5)
end

-- handle the escapse button
function SpaceTravelNumberCtrl:HandleEscape()
    self:OnClicked(self._ui.Blocker)
end

-- on clicked
function SpaceTravelNumberCtrl:OnClicked(go)

    if go == self._ui.Blocker then
        SoundSystem.PlayUICancelSound()
        CtrlManager.PopPanel()
    elseif go == self._ui.ButtonConfirm then
        SoundSystem.PlayUIClickSound()
        CtrlManager.PopPanel()
        if self._itemNum > 0 then
            local cb = self._parameter.callback
            local receiver = self._parameter.receiver
            cb(receiver, self._itemId, self._itemNum)
        end
    elseif go == self._ui.ButtonPlus then
        if self._itemNum < self._numLimit then
            SoundSystem.PlayUIClickSound()
            self._itemNum = self._itemNum + 1
            self:OnSelectedNumChanged(true)
        else
            SoundSystem.PlayWarningSound()
        end
    elseif go == self._ui.ButtonMinus then
        if self._itemNum > 0 then
            SoundSystem.PlayUIClickSound()
            self._itemNum = self._itemNum - 1
            self:OnSelectedNumChanged(true)
        else
            SoundSystem.PlayWarningSound()
        end
    end

	return true
end

-- on pressed
function SpaceTravelNumberCtrl:OnPressed(go, pressed, isLong)
    if go == self._ui.ButtonCollider then
        if pressed then
            self._isDraging = true
        elseif not pressed then
            self._isDraging = false
        end
    end
end
