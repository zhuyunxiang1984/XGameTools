require "FreakPlanet/View/CharacterEquipmentPanel"

local class = require "FreakPlanet/Utils/middleclass"
CharacterEquipmentCtrl  = class(CtrlNames.CharacterEquipment, BaseCtrl)

-----------------------------------------------------
-- load the ui prefab
function CharacterEquipmentCtrl:LoadPanel()
	self:CreatePanel("CharacterEquipment")
end

-- construct ui panel data
function CharacterEquipmentCtrl:ConstructUI(obj)
	self._ui = CharacterEquipmentPanel.Init(obj)
end

-- destroy implementation
function CharacterEquipmentCtrl:DestroyImpl()
    GameNotifier.RemoveListener(GameEvent.ItemNumChanged, CharacterEquipmentCtrl.OnItemNumChanged, self)
end

-- fill ui with the data
function CharacterEquipmentCtrl:SetupUI()
	self._characterId = self._parameter.characterId
	self._currentEquipmentSlot = self._parameter.slot
	self._enableChallenge = self._parameter.enableChallenge
	self:OnEquipmentSlotChanged()

	for idx = 1, #self._ui.EquipmentSlots do
		CtrlManager.AddClick(self, self._ui.EquipmentSlots[idx].item)
	end

	for idx = 1, #self._ui.UpLevelItems do
		CtrlManager.AddClick(self, self._ui.UpLevelItems[idx].item)
	end

	self._ui.LevelUpEffectAnimator.gameObject:SetActive(false)
	CtrlManager.AddClick(self, self._ui.Blocker)
	CtrlManager.AddClick(self, self._ui.ButtonChallenge)
	CtrlManager.AddClick(self, self._ui.ButtonUpLevel)
    GameNotifier.AddListener(GameEvent.ItemNumChanged, CharacterEquipmentCtrl.OnItemNumChanged, self)

	self:CheckTutorial()
end

function CharacterEquipmentCtrl:OnEquipmentSlotChanged()
	local slot = self._currentEquipmentSlot
	local equipmentList = GameData.GetCharacterEquipments(self._characterId)
	self._currentEquipmentId = equipmentList[slot].id
	self._equipmentAbilityAndSkillList = ConfigUtils.GetEquipmentAbilityAndSkillList(self._currentEquipmentId)
	self._currentShowAbilityAndSkill = {}

    local equipmentUnlocked = GameData.IsEquipmentUnlocked(self._currentEquipmentId)
    self._ui.ButtonChallenge:SetActive(self._enableChallenge and not equipmentUnlocked)
    self:InitAbilityAndSkill()
    self:OnEquipmentLevelChanged()

	for idx = 1, #self._ui.EquipmentSlots do
		local hasEquipment = (idx <= #equipmentList)
		self._ui.EquipmentSlots[idx].item:SetActive(hasEquipment)

		if hasEquipment then
			if idx == slot then
				self._ui.EquipmentSlots[idx].icon.spriteName = "CharacterLisOn"
			else
				self._ui.EquipmentSlots[idx].icon.spriteName = "CharacterLisOff"
			end
		end
	end
end

function CharacterEquipmentCtrl:OnEquipmentLevelChanged()
	local slot = self._currentEquipmentSlot
	local equipmentList = GameData.GetCharacterEquipments(self._characterId)
	self._currentEquipmentLevel = equipmentList[slot].level

	local equipmentId = self._currentEquipmentId
	local equipmentLevel = self._currentEquipmentLevel
    local equipmentUnlocked = GameData.IsEquipmentUnlocked(equipmentId)

    UIHelper.SetEquipmentIcon(self, self._ui.EquipmentIcon, equipmentId, equipmentLevel)
    self._ui.EquipmentName.text = ConfigUtils.GetEquipmentName(equipmentId, equipmentLevel)
    self._ui.EquipmentDesc.text = ConfigUtils.GetEquipmentDesc(equipmentId, equipmentLevel)
    self._ui.EquipmentLevel.text = string.format(SAFE_LOC('loc_SimpleLevel'), equipmentLevel)
    if equipmentUnlocked then
    	self._ui.EquipmentIcon.color = Color.white
    else
    	self._ui.EquipmentIcon.color = LOCK_ICON_COLOR
    end
    
    self:RefreshAbilityAndSkill(equipmentUnlocked)
    self:ConstructUpgradeItems()
end

function CharacterEquipmentCtrl:OnItemNumChanged(itemId, changeNum)
    self:ConstructUpgradeItems()
end

function CharacterEquipmentCtrl:ConstructUpgradeItems()
    local equipmentId = self._currentEquipmentId
    local equipmentLevel = self._currentEquipmentLevel
    local maxLevel = ConfigUtils.GetEquipmentMaxLevel(equipmentId)
    local equipmentUnlocked = GameData.IsEquipmentUnlocked(equipmentId)

    local showUpLevel = (equipmentUnlocked and equipmentLevel < maxLevel)
    self._ui.ButtonUpLevel:SetActive(showUpLevel)

    local upLevelCost = {}
    self._upgradeItemEnough = false
    if showUpLevel then
        upLevelCost = ConfigUtils.GetEquipmentUpgradeCost(equipmentId, equipmentLevel)
        self._upgradeItemEnough = true
    end

    for idx = 1, #self._ui.UpLevelItems do
        local hasItem = (idx <= #upLevelCost)
        self._ui.UpLevelItems[idx].item:SetActive(hasItem)
        if hasItem then
            local itemId = upLevelCost[idx].Value
            local needNum = upLevelCost[idx].Num
            local itemUnlocked = GameData.IsItemUnlocked(itemId)
            local curNum = GameData.GetItemNum(itemId)
            -- icon
            local icon = UIHelper.ConstructItemIconAndNum(self, self._ui.UpLevelItems[idx].root, itemId, nil)
            if itemUnlocked then
                icon.color = Color.white
            else
                icon.color = LOCK_ICON_COLOR
            end
            -- num
            local numLabel = self._ui.UpLevelItems[idx].num
            numLabel.text = UIHelper.GetItemNumShowText(curNum, 100000).."/"..tostring(needNum)
            if curNum < needNum then
                numLabel.color = Color.red
                self._upgradeItemEnough = false
            else
                numLabel.color = Color.black
            end
        end
    end
end

function CharacterEquipmentCtrl:InitAbilityAndSkill()
	-- recyle
	local count = self._ui.EquipmentRoot.childCount
	for idx = count, 1, -1 do
		local item = self._ui.EquipmentRoot:GetChild(idx - 1)
		item.parent = self._ui.ItemPool
	end

	local posY = 0
	for idx = 1, #self._equipmentAbilityAndSkillList do
		local itemId = self._equipmentAbilityAndSkillList[idx].id
		local itemType = ConfigUtils.GetItemTypeFromId(itemId)
		local itemPrefab = nil
		local itemGap = 0
		if itemType == ItemType.Ability then
			itemPrefab = self._ui.AbilityItemTemplate
			itemGap = 37
		elseif itemType == ItemType.Skill then
			itemPrefab = self._ui.SkillItemTemplate
			itemGap = 90
		else
			assert(false, "un-handled item id: "..tostring(itemId))
		end

		local prefabName = itemPrefab.name
		local item = self._ui.ItemPool:Find(prefabName)
		if item == nil then
			local itemObj = Helper.NewObject(itemPrefab, self._ui.EquipmentRoot)
			itemObj.name = prefabName
			item = itemObj.transform
		else
			item.parent = self._ui.EquipmentRoot
			item.localPosition = Vector3.zero
			item.localScale = Vector3.one
		end

		local pos = item.localPosition
		pos.y = -posY
		item.localPosition = pos
		item.gameObject:SetActive(true)

		posY = posY + itemGap
		
		if itemType == ItemType.Ability then
			-- ability icon
			local icon = item:Find("Icon"):GetComponent("UISprite")
			icon.spriteName = ConfigUtils.GetAbilityIcon(itemId)
		end
		-- initial value
		local upValueLabel = item:Find("UpEffect/Value"):GetComponent("UILabel")
		local animator = item:Find("UpEffect"):GetComponent("Animator")
		animator.gameObject:SetActive(false)
		self._currentShowAbilityAndSkill[itemId] = {upValueLabel = upValueLabel, animator = animator}
	end
end

function CharacterEquipmentCtrl:RefreshAbilityAndSkill(equipmentUnlocked)
	for idx = 1, #self._equipmentAbilityAndSkillList do
		local itemId = self._equipmentAbilityAndSkillList[idx].id
		local itemType = ConfigUtils.GetItemTypeFromId(itemId)
		local item = self._ui.EquipmentRoot:GetChild(idx - 1)
		if itemType == ItemType.Ability then
			self:RefreshAbilityItem(item, idx, equipmentUnlocked)
		elseif itemType == ItemType.Skill then
			self:RefreshSkillItem(item, idx, equipmentUnlocked)
		else
			assert(false, "un-handled item id: "..tostring(itemId))
		end
	end
end

function CharacterEquipmentCtrl:RefreshAbilityItem(item, idx, equipmentUnlocked)
	local itemId = self._equipmentAbilityAndSkillList[idx].id
	local itemValue = self._equipmentAbilityAndSkillList[idx].value
	local unlockLevel = self._equipmentAbilityAndSkillList[idx].unlock
	local unlocked = (equipmentUnlocked and self._currentEquipmentLevel >= unlockLevel)

	local lockRoot = item:Find("Lock").gameObject
	local unlockRoot = item:Find("Unlock").gameObject

	lockRoot:SetActive(not unlocked)
	unlockRoot:SetActive(unlocked)

	local showValue = itemValue
	local numLabel = nil
	if unlocked then
		showValue = ConfigUtils.GetEquipmentAbilityValueAtLevel(self._currentEquipmentId, self._currentEquipmentLevel, itemId)
		numLabel = item:Find("Unlock/Value"):GetComponent("UILabel")
	else
		numLabel = item:Find("Lock/Value"):GetComponent("UILabel")

		local tipsLabel = item:Find("Lock/Tips"):GetComponent("UILabel")
		tipsLabel.text = tostring(unlockLevel).."级解锁"
	end

	local showText = ""
	if showValue > 0 then
		showText = "+"..tostring(showValue)
	else
		showText = tostring(showValue)
	end
	numLabel.text = showText
	self._currentShowAbilityAndSkill[itemId].value = showValue
end

function CharacterEquipmentCtrl:RefreshSkillItem(item, idx, equipmentUnlocked)
	local itemId = self._equipmentAbilityAndSkillList[idx].id
	local itemValue = self._equipmentAbilityAndSkillList[idx].value
	local unlockLevel = self._equipmentAbilityAndSkillList[idx].unlock
	local unlocked = (equipmentUnlocked and self._currentEquipmentLevel >= unlockLevel)

	local showValue = itemValue
	if unlocked then
		showValue = ConfigUtils.GetEquipmentSkillValueAtLevel(self._currentEquipmentId, self._currentEquipmentLevel, itemId)
	end

	local showText = UIHelper.GetSkillShowText(itemId, showValue)
	if unlocked then
		showText = "[A796FFFF]"..showText.."[-] [48FF00FF]"..SAFE_LOC("loc_Activated").."[-]"
	else
		showText = "[7E65A1FF]"..showText.."[-] [FF0000FF]"..tostring(unlockLevel).."级解锁".."[-]"
	end
	local numLabel = item:Find("Value"):GetComponent("UILabel")
	numLabel.text = showText
	self._currentShowAbilityAndSkill[itemId].value = showValue
end

function CharacterEquipmentCtrl:CloseToChallenge()
	local challengeId = ConfigUtils.GetEquipmentUnlockChallenge(self._currentEquipmentId)
	CtrlManager.PopPanel()
	CtrlManager.OpenPanel(CtrlNames.ExploreCharacter, {challengeId = challengeId})
end

-- on clicked
function CharacterEquipmentCtrl:OnClicked(go)
	if go == self._ui.Blocker then
		-- close ui
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
	elseif go == self._ui.ButtonChallenge then
		SoundSystem.PlayUIClickSound()
		CtrlManager.DoWaitTransition(CtrlNames.ExploreCharacter, self, CharacterEquipmentCtrl.CloseToChallenge)
	elseif go == self._ui.ButtonUpLevel then
		if not self._upgradeItemEnough then
			SoundSystem.PlayWarningSound()
			CtrlManager.ShowMessageBox({message = SAFE_LOC("升级物品不足"), single = true})
			return true
		end

		SoundSystem.PlayCharacterUpgradeSound()
		NetManager.Send("UpEquip", {
			Char = self._characterId, 
			Equip = self._currentEquipmentId,
			Slot = self._currentEquipmentSlot,
			Level = self._currentEquipmentLevel,
		}, CharacterEquipmentCtrl.OnHandleProto, self)
	elseif Helper.StartWith(go.name, "Slot_") then
		local names = Helper.StringSplit(go.name)
        assert(#names == 2, "invalid equipment item name: "..tostring(go.name))
        local slot = tonumber(names[2])
        if slot ~= self._currentEquipmentSlot then
        	SoundSystem.PlaySwitchSound()
        	self._currentEquipmentSlot = slot
        	self:OnEquipmentSlotChanged()
        end
    elseif go.transform.parent == self._ui.UpLevelItemRoot then
    	SoundSystem.PlayUIClickSound()
    	local names = Helper.StringSplit(go.name)
        assert(#names == 2, "invalid equipment item name: "..tostring(go.name))
        local itemIdx = tonumber(names[2])
        local equipmentId = self._currentEquipmentId
		local equipmentLevel = self._currentEquipmentLevel
        local upLevelCost = ConfigUtils.GetEquipmentUpgradeCost(equipmentId, equipmentLevel)
        local itemId = upLevelCost[itemIdx].Value
        CtrlManager.ShowItemDetail({itemId = itemId})
	end

	return true
end
---------------------------------------------------------------------
function CharacterEquipmentCtrl:OnHandleProto(proto, data, requestData)
	if proto == "UpEquip" then
		local characterId = requestData.Char
		local equipmentId = requestData.Equip
		local equipmentSlot = requestData.Slot
		local equipmentLevel = requestData.Level

		local upLevelCost = ConfigUtils.GetEquipmentUpgradeCost(equipmentId, equipmentLevel)
		for idx = 1, #upLevelCost do
			local itemId = upLevelCost[idx].Value
			local itemNum = upLevelCost[idx].Num
			GameData.ConsumeItem(itemId, itemNum)
		end

		local goldNum = data.RemainGold
		local diamondNum = data.RemainDiamond
		GameData.SetMoney(ItemType.Gold, goldNum)
		GameData.SetMoney(ItemType.Diamond, diamondNum)
		GameData.SetCharacterEquipmentLevel(characterId, equipmentSlot, equipmentLevel + 1)
		GameData.CheckAndHintGoalsOfCurrentCountType()
		GameData.SyncTutorialData()

		-- update ui
		self._ui.LevelUpEffectAnimator.gameObject:SetActive(true)
		self._ui.LevelUpEffectAnimator:Play("PromoteEffect", 0, 0)
		self:CheckLevelUpEffect(equipmentLevel + 1)
		-- called after check level-up effect
		self:OnEquipmentLevelChanged()
		GameNotifier.Notify(GameEvent.CharacterEquipmentUpgraded, characterId)
	end
end

function CharacterEquipmentCtrl:CheckLevelUpEffect(newLevel)
	for idx = 1, #self._equipmentAbilityAndSkillList do
		local itemId = self._equipmentAbilityAndSkillList[idx].id
		local itemType = ConfigUtils.GetItemTypeFromId(itemId)
		local unlockLevel = self._equipmentAbilityAndSkillList[idx].unlock

		local play = false
		local upText = ""
		if newLevel == unlockLevel then
			play = true
			upText = SAFE_LOC("解锁")
		elseif newLevel > unlockLevel then
			local preValue = self._currentShowAbilityAndSkill[itemId].value
			local curValue = 0
			if itemType == ItemType.Ability then
				curValue = ConfigUtils.GetEquipmentAbilityValueAtLevel(self._currentEquipmentId, newLevel, itemId)
			elseif itemType == ItemType.Skill then
				curValue = ConfigUtils.GetEquipmentSkillValueAtLevel(self._currentEquipmentId, newLevel, itemId)
			else
				assert(false, "un-handled item id: "..tostring(itemId))
			end

			local diffValue = curValue - preValue
			if diffValue ~= 0 then
				play = true
				upText = tostring(diffValue)
				if diffValue > 0 then
					upText = "+"..upText
				end
			end
		end

		if play then
			local upValueLabel = self._currentShowAbilityAndSkill[itemId].upValueLabel
			local animator = self._currentShowAbilityAndSkill[itemId].animator
			animator.gameObject:SetActive(true)
			animator:Play("UpLevel", 0, 0)
			upValueLabel.text = upText
		end
	end
end
--------------------------------------------------------
-- tutorial
function CharacterEquipmentCtrl:CheckTutorial()
    local tutorials = {}

    if GameData.IsTutorialNotFinished(Tutorials.Tutorial_6_3) and GameData.IsGoalRunning(TutorialConstData.EquipmentUpgradeGoal) then
        local position = self._ui.Camera:WorldToScreenPoint(self._ui.PositionMark.position)
        tutorials[1] = {event = Tutorials.Tutorial_6_2, position = position, sender = self}
        position = self._ui.Camera:WorldToScreenPoint(self._ui.ButtonUpLevel.transform.position)
        tutorials[2] = {event = Tutorials.Tutorial_6_3, position = position, sender = self}
    end

    if #tutorials > 0 then
        CtrlManager.ShowTutorials(tutorials)
    end

    return #tutorials > 0
end

function CharacterEquipmentCtrl:OnTutorialClicked(tutorial)
    if tutorial == Tutorials.Tutorial_6_3 then
        self:OnClicked(self._ui.ButtonUpLevel)
    else
    	SoundSystem.PlayUIClickSound()
    end
end
--------------------------------------------------------