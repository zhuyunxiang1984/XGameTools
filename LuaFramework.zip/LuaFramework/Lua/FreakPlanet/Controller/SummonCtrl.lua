require 'FreakPlanet/View/SummonPanel'

local utf8 = require "FreakPlanet/Utils/Utf8"
local class = require 'FreakPlanet/Utils/middleclass'
SummonCtrl = class(CtrlNames.Summon, BaseCtrl)

------------------------------------------------------------
local function CharacterSortFunc(idA, idB)
    local valueA = ConfigUtils.GetCharacterRarity(idA)
    local valueB = ConfigUtils.GetCharacterRarity(idB)

    if valueA == valueB then
        valueA = ConfigUtils.GetCharacterSortId(idA)
        valueB = ConfigUtils.GetCharacterSortId(idB)
    end

    return valueA > valueB
end

local function PetSortFunc(idA, idB)
    local valueA = ConfigUtils.GetPetRarity(idA)
    local valueB = ConfigUtils.GetPetRarity(idB)

    if valueA == valueB then
        valueA = ConfigUtils.GetPetSortId(idA)
        valueB = ConfigUtils.GetPetSortId(idB)
    end

    return valueA > valueB
end

local function GoodsSortFunc(idA, idB)
    local valueA = ConfigUtils.GetGoodsRarity(idA)
    local valueB = ConfigUtils.GetGoodsRarity(idB)

    if valueA == valueB then
        valueA = ConfigUtils.GetGoodsSortId(idA)
        valueB = ConfigUtils.GetGoodsSortId(idB)
    end

    return valueA > valueB
end

local function RoomPieceSortFunc(idA, idB)
    local valueA = ConfigUtils.GetRoomPieceSortId(idA)
    local valueB = ConfigUtils.GetRoomPieceSortId(idB)

    return valueA > valueB
end

local function GetItemTypeValueOfSummon(itemId)
    local itemType = ConfigUtils.GetItemTypeFromId(itemId)

    if itemType == ItemType.Character then
        return 50
    elseif itemType == ItemType.Pet then
        return 40
    elseif itemType == ItemType.RoomPiece then
        return 30
    elseif itemType == ItemType.Goods then
        local subType = ConfigUtils.GetGoodsSubType(itemId)
        if subType == GoodsSubType.Chip then
            return 22
        elseif subType == GoodsSubType.CatchItem then
            return 21
        else
            return 20
        end
    end
end

local function SummonDropResultSortFunc(elementA, elementB)
    if elementA == nil or elementB == nil then
        return false
    end

    local idA = elementA.id
    local idB = elementB.id
    return SummonCtrl.SummonItemSortFunc(idA, idB)
end

function SummonCtrl.SummonItemSortFunc(idA, idB)
    if idA == nil or idB == nil then
        return false
    end

    if idA == idB then
        return false
    end

    local valueA = GetItemTypeValueOfSummon(idA)
    local valueB = GetItemTypeValueOfSummon(idB)

    if valueA ~= valueB then
        return valueA > valueB
    end
    -- same item type
    local itemType = ConfigUtils.GetItemTypeFromId(idA)
    if itemType == ItemType.Character then
        return CharacterSortFunc(idA, idB)
    elseif itemType == ItemType.Pet then
        return PetSortFunc(idA, idB)
    elseif itemType == ItemType.Goods then
        return GoodsSortFunc(idA, idB)
    elseif itemType == ItemType.RoomPiece then
        return RoomPieceSortFunc(idA, idB)
    end

    return false
end

local function SommonPoolSortFunc(elementA, elementB)
    if elementA == nil or elementB == nil then
        return false
    end

    local idA = elementA.id
    local idB = elementB.id

    local isEventA = ConfigUtils.IsEventSummon(idA)
    local isEventB = ConfigUtils.IsEventSummon(idB)
    if isEventA ~= isEventB then
        return isEventA
    end

    local sortIdA = ConfigUtils.GetSummonSortId(idA)
    local sortIdB = ConfigUtils.GetSummonSortId(idB)

    if isEventA then
        return sortIdA > sortIdB
    else
        return sortIdA < sortIdB
    end
end
--------------------------------------------------

-- load the ui prefab
function SummonCtrl:LoadPanel()
    self:CreatePanel('Summon')
end

-- construct ui panel data
function SummonCtrl:ConstructUI(obj)
    self._ui = SummonPanel.Init(obj)
end

function SummonCtrl:DestroyImpl()
    GameNotifier.RemoveListener(GameEvent.MoneyChanged, SummonCtrl.OnMoneyChanged, self)
    GameNotifier.RemoveListener(GameEvent.TokenChanged, SummonCtrl.OnMoneyChanged, self)
end

-- notity it has been focused
function SummonCtrl:NotifyFocus()
    self:RefreshExchangeCharacterState()
    self:RefreshSummonGiveCharacterState()
end

-- fill ui with the data
function SummonCtrl:SetupUI()
    self._summonPoolCollections = {}
    self._summonPoolEventCollections = {}
	self._showingResult = false
	self._summonList = GameData.GetActiveSummonList()
    table.sort(self._summonList, SommonPoolSortFunc)
    -- fill event summon first
    self:FillEventSummons()

    for summonId, v in pairs(self._ui.SummonItems) do
        CtrlManager.AddClick(self, v.item)
        local unlocked = self:HasSummon(summonId)
        v.item:SetActive(unlocked)
    end

    local summonId = self._parameter.summonId
    if summonId ~= nil and self:HasSummon(summonId) then
        self._summonId = summonId
    else
        self._summonId = self._summonList[1].id
    end
    self:OnSummonPoolChanged()

    for k, v in pairs(self._ui.Tokens) do
        CtrlManager.AddClick(self, v.item)
    end
    
    CtrlManager.AddClick(self, self._ui.ButtonNext)
    CtrlManager.AddClick(self, self._ui.ButtonPrevious)
    CtrlManager.AddClick(self, self._ui.ButtonClose)
    CtrlManager.AddClick(self, self._ui.ButtonPreview)
    CtrlManager.AddClick(self, self._ui.ButtonEventPreview)
    CtrlManager.AddClick(self, self._ui.ButtonSummonOne)
    CtrlManager.AddClick(self, self._ui.ButtonSummonTen)
    CtrlManager.AddClick(self, self._ui.ResultBlocker)
    CtrlManager.AddClick(self, self._ui.ButtonHint)
    CtrlManager.AddClick(self, self._ui.ExchangeRoot)

    self._ui.ResultPanel:SetActive(false)

    self:RefreshExchangeCharacterState()
    self:RefreshSummonGiveCharacterState()
    self:GetSummonReward()
    GameNotifier.AddListener(GameEvent.MoneyChanged, SummonCtrl.OnMoneyChanged, self)
    GameNotifier.AddListener(GameEvent.TokenChanged, SummonCtrl.OnMoneyChanged, self)

    self:CheckTutorial()
end

function SummonCtrl:FillEventSummons()
    -- remove the existed items
    local num = self._ui.EventSummonRoot.childCount
    for idx = num, 1, -1 do
        local item = self._ui.EventSummonRoot:GetChild(idx - 1).gameObject
        destroy(item)
    end
    -- construct event summons
    local eventSlotLimit = self._ui.EventSummonPositionRoot.childCount
    for idx = 1, #self._summonList do
        local summonId = self._summonList[idx].id
        if ConfigUtils.IsEventSummon(summonId) and self._ui.SummonItems[summonId] == nil then
            -- event summon position 
            local summonSlot = ConfigUtils.GetSummonSlot(summonId)
            if summonSlot == nil or summonSlot > eventSlotLimit then
                summonSlot = 1
            end
            -- event summon object
            local summonPrefabName = ConfigUtils.GetSummonPrefab(summonId)
            local summonPrefab = self:LoadAsset(summonPrefabName)
            local summonObj = Helper.NewObject(summonPrefab, self._ui.EventSummonRoot)
            summonObj:SetActive(true)
            summonObj.name = tostring(summonId)
            -- set position
            local positionMark = self._ui.EventSummonPositionRoot:GetChild(summonSlot - 1)
            summonObj.transform.localPosition = self._ui.EventSummonRoot:InverseTransformPoint(positionMark.position)
            -- push ui to list
            local roleAnimator = summonObj.transform:Find("Role"):GetComponent("Animator")
            local selectedMark = summonObj.transform:Find("SelectMark").gameObject
            self._ui.SummonItems[summonId] = {item = summonObj, roleAnimator = roleAnimator, selectedMark = selectedMark}
        end
    end
end

function SummonCtrl:HasSummon(summonId)
    for k, v in pairs(self._summonList) do
        if v.id == summonId then
            return true
        end
    end

    return false
end

function SummonCtrl:IsCurrentSummonValid()
    if self._summonEndTime == nil then
        return true
    end

    local curTime = GameData.GetServerTime()
    return self._summonEndTime > curTime
end

-- update per frame
function SummonCtrl:UpdateImpl(deltaTime)
    if self._summonEndTime ~= nil then
        self:RefreshSummonLeftTime()
    end
end

function SummonCtrl:GetIndexOfCurrentSummon()
	for idx = 1, #self._summonList do
		if self._summonId == self._summonList[idx].id then
			return idx
		end
	end

    assert(false, "can't find current summon id in summon list: "..tostring(self._summonId))
	return nil
end

---获取第一个没有解锁的可换购角色
function SummonCtrl:GetExchangeCharacter()
    local list = ConfigUtils.GetSummonExchangeList()
    for _, characterId in ipairs(list) do
        if not GameData.IsCharacterUnlocked(characterId) and ConfigUtils.GetCharacterExchangeCost(characterId) then
            return characterId
        end
    end
    return -1
end

---刷新可换购角色状态
function SummonCtrl:RefreshExchangeCharacterState()
    local ui = self._ui
    local characterId = self:GetExchangeCharacter()
    self.CurExchangeCharacterId = self.CurExchangeCharacterId or -1
    local srcCharId = self.CurExchangeCharacterId
    local dstCharId = characterId
    if srcCharId == dstCharId then
        return
    end
    self.CurExchangeCharacterId = dstCharId
    ui.ExchangeRoot:SetActive(self.CurExchangeCharacterId > 0)

    if srcCharId > 0 then
        local node = ui.ExchangeRoot.transform:Find("Role" .. srcCharId)
        if node then
            node.gameObject:SetActive(false)
        end
    end
    if dstCharId > 0 then
        local node = ui.ExchangeRoot.transform:Find("Role" .. dstCharId)
        if node then
            node.gameObject:SetActive(true)

            local animator = node.gameObject:GetComponent("Animator")
            if animator then
                local exchangeCost = ConfigUtils.GetCharacterExchangeCost(characterId)
                local exchangeItemId = exchangeCost.Value
                local exchangeItemNum = exchangeCost.Num

                if GameData.GetItemNum(exchangeItemId) >= exchangeItemNum then
                    animator:Play("Enough", 0, 0)
                else
                    animator:Play("NotEnough", 0, 0)
                end
            end
        end
    end
end

function SummonCtrl:OnSummonPoolChanged()
    local summonId = self._summonId
	local isEvent = ConfigUtils.IsEventSummon(summonId)

    self._ui.DefaultStage:SetActive(not isEvent)
    self._ui.EventStage:SetActive(isEvent)

    -- selected mark
	for k, v in pairs(self._ui.SummonItems) do
        v.selectedMark:SetActive(k == summonId)
    end

    -- single cost
    self._singleCostType, self._singleCostNum = ConfigUtils.GetSingleSummonCost(summonId)
    self._singleTokenCostType, self._singleTokenCostNum = ConfigUtils.GetSingleSummonTokenCost(summonId)
    -- multiple cost
    self._multipleCostType, self._multipleCostNum = ConfigUtils.GetMultipleSummonCost(summonId)
    self._multipleTokenCostType, self._multipleTokenCostNum = ConfigUtils.GetMultipleSummonTokenCost(summonId)

    -- summon animator
    if self._singleCostType == 1 then
        self._ui.SummonEffectGoldOne_Anim.gameObject:SetActive(true)
        self._ui.SummonEffectGoldTen_Anim.gameObject:SetActive(true)
        self._ui.SummonEffectDiamondOne_Anim.gameObject:SetActive(false)
        self._ui.SummonEffectDiamondTen_Anim.gameObject:SetActive(false)
    else
        self._ui.SummonEffectGoldOne_Anim.gameObject:SetActive(false)
        self._ui.SummonEffectGoldTen_Anim.gameObject:SetActive(false)
        self._ui.SummonEffectDiamondOne_Anim.gameObject:SetActive(true)
        self._ui.SummonEffectDiamondTen_Anim.gameObject:SetActive(true)
    end

    -- name
    self._ui.SummonName.text = ConfigUtils.GetSummonName(summonId)
    -- icon
    self._ui.SummonIcon.spriteName = ConfigUtils.GetSummonIcon(summonId)
    -- event pool or not
    self._ui.SummonCooldownRoot:SetActive(isEvent)
    -- event pool end time
    local summonIndex = self:GetIndexOfCurrentSummon()
    self._summonEndTime = self._summonList[summonIndex].endTime
    self._ui.SummonCooldownTime.text = ""
    -- collection
    self:RefreshSummonCollectionRatio(summonId)

    self:OnMoneyChanged()
end

-- refresh event
function SummonCtrl:RefreshSummonLeftTime()
    local summonId = self._summonId
    local curTime = GameData.GetServerTime()
    local leftTime = math.max(0, self._summonEndTime - curTime)
    if leftTime > 0 then
        self._ui.SummonCooldownTime.text = Helper.GetLongTimeString(leftTime)
    else
        self._ui.SummonCooldownTime.text = SAFE_LOC("loc_SummonCompleted")
    end
end

function SummonCtrl:ShouldShowSummonHint(summonId)
    -- no give character
    local giveCharacterId = ConfigUtils.GetSummonGiveCharacter(summonId)
    if not ConfigUtils.IsValidItem(giveCharacterId) then
        return false
    end
    -- give character rewarded
    if GameData.IsItemUnlocked(giveCharacterId) then
        return false
    end
    -- still locked and is not goods no need to hint
    local summonItems = ConfigUtils.GetSummonItems(summonId)
    for idx = 1, #summonItems do
        local itemId = summonItems[idx]
        local itemType = ConfigUtils.GetItemTypeFromId(itemId)
        if itemType ~= ItemType.Goods and not GameData.IsItemUnlocked(itemId) then
            return false
        end
    end

    return true
end


---刷新奖池收集度进程
---@param summonId 奖池ID
function SummonCtrl:RefreshSummonCollectionRatio(summonId)
    local summonItems = ConfigUtils.GetSummonItems(summonId)

    local unlockNum = 0
    local totalNum = 0
    for idx = 1, #summonItems do
        totalNum = totalNum + 1
        if GameData.IsItemUnlocked(summonItems[idx]) then
            unlockNum = unlockNum + 1
        end
    end
    -- drops
    local showHint = false
    if self._summonPoolCollections[summonId] == nil then
        self._summonPoolCollections[summonId] = {preNum = unlockNum, curNum = unlockNum}
    else
        local preNum = self._summonPoolCollections[summonId].preNum or 0
        self._summonPoolCollections[summonId] = {preNum = preNum, curNum = unlockNum}
        showHint = (preNum ~= unlockNum)
    end
    self._ui.SummonCollectionHint:SetActive(showHint)
    self._ui.SummonCollectionRatio.text = tostring(unlockNum) .. '/' .. tostring(totalNum)
end

---刷新池底角色的状态
function SummonCtrl:RefreshSummonGiveCharacterState()
    self._summonGiveState = {}
    for k, v in pairs(self._ui.SummonItems) do
        local giveCharacterId = ConfigUtils.GetSummonGiveCharacter(k)
        local characterOnly = ConfigUtils.IsSummonRewardCharacterAndRoomPieceOnly(k)
        if ConfigUtils.IsValidItem(giveCharacterId) then
            local unlocked = GameData.IsCharacterUnlocked(giveCharacterId)
            if unlocked then
                v.roleAnimator:Play("Complete", 0, 0)
                self._summonGiveState[k] = false
            else
                local matchGive = true
                local summonItems = ConfigUtils.GetSummonItems(k)
                for idx = 1, #summonItems do
                    local itemId = summonItems[idx]
                    local itemType = ConfigUtils.GetItemTypeFromId(itemId)
                    local needCheck = not characterOnly or (itemType == ItemType.Character or itemType == ItemType.RoomPiece)
                    if needCheck and not GameData.IsItemUnlocked(itemId) then
                        matchGive = false
                        break
                    end
                end

                if matchGive then
                    v.roleAnimator:Play("Gain", 0, 0)
                    self._summonGiveState[k] = true
                else
                    v.roleAnimator:Play("Idle", 0, 0)
                    self._summonGiveState[k] = false
                end
            end
        else
            v.roleAnimator:Play("Idle", 0, 0)
            self._summonGiveState[k] = false
        end
    end


end

---自动领取池底角色
function SummonCtrl:GetSummonReward()
    for k, v in pairs(self._summonGiveState) do
        if self._summonGiveState[k] then
            NetManager.Send("GetSummonReward", { SummonId = k }, SummonCtrl.OnHandleProto, self)
        end
    end
end

function SummonCtrl:OnMoneyChanged(itemType)
    self._singleUseToken = false
    if self._singleTokenCostType ~= nil then
        local tokenNum = GameData.GetTokenNum(self._singleTokenCostType)
        if self._singleTokenCostNum <= tokenNum then
             self._singleUseToken = true
        end
    end

    if not self._singleUseToken then
        -- icon
        self._ui.SummonOneCostIcon.spriteName = UIHelper.GetItemIconAndNodeName(self._singleCostType)
        -- num
        self._ui.SummonOneCostNum.text = tostring(self._singleCostNum)
        -- color
        local ownNum = GameData.GetMoney(self._singleCostType)
        if ownNum < self._singleCostNum then
            self._ui.SummonOneCostNum.color = Color.red
        else
            self._ui.SummonOneCostNum.color = Color.white
        end
    else
        -- icon
        self._ui.SummonOneCostIcon.spriteName = UIHelper.GetItemIconAndNodeName(self._singleTokenCostType)
        -- num
        self._ui.SummonOneCostNum.text = tostring(self._singleTokenCostNum)
        -- color
        self._ui.SummonOneCostNum.color = Color.white
    end

    self._multipleUseToken = false
    if self._multipleTokenCostType ~= nil then
        local tokenNum = GameData.GetTokenNum(self._multipleTokenCostType)
        if self._multipleTokenCostNum <= tokenNum then
            self._multipleUseToken = true
        end
    end

    if not self._multipleUseToken then
        -- icon
        self._ui.SummonTenCostIcon.spriteName = UIHelper.GetItemIconAndNodeName(self._multipleCostType)
        -- num
        self._ui.SummonTenCostNum.text = tostring(self._multipleCostNum)
        -- color
        local ownNum = GameData.GetMoney(self._multipleCostType)
        if ownNum < self._multipleCostNum then
            self._ui.SummonTenCostNum.color = Color.red
        else
            self._ui.SummonTenCostNum.color = Color.white
        end
    else
        -- icon
        self._ui.SummonTenCostIcon.spriteName = UIHelper.GetItemIconAndNodeName(self._multipleTokenCostType)
        -- num
        self._ui.SummonTenCostNum.text = tostring(self._multipleTokenCostNum)
        -- color
        self._ui.SummonTenCostNum.color = Color.white
    end

    for tokenId, v in pairs(self._ui.Tokens) do
        v.num.text = "x"..tostring(GameData.GetTokenNum(tokenId))
    end
end

-- handle the escapse button
function SummonCtrl:HandleEscape()
    self:OnClicked(self._ui.ButtonClose)
end

-- can do jump or not
function SummonCtrl:CanJump()
    return not self._showingResult
end

-- on clicked
function SummonCtrl:OnClicked(go)
    if self._showingResult then
        return true
    end

    if go == self._ui.ButtonClose then
        SoundSystem.PlayUICancelSound()
        CtrlManager.PopPanel()
    elseif go == self._ui.ButtonNext then
		SoundSystem.PlayUIClickSound()
		local idx = self:GetIndexOfCurrentSummon() + 1
		if idx > #self._summonList then
			idx = 1
		end
		self._summonId = self._summonList[idx].id
		self:OnSummonPoolChanged()
    elseif go == self._ui.ButtonPrevious then
    	SoundSystem.PlayUIClickSound()
		local idx = self:GetIndexOfCurrentSummon() - 1
		if idx < 1 then
			idx = #self._summonList
		end
		self._summonId = self._summonList[idx].id
		self:OnSummonPoolChanged()
    elseif go.transform.parent == self._ui.SummonRoot or go.transform.parent == self._ui.EventSummonRoot then
        SoundSystem.PlayUIClickSound()
        local summonId = tonumber(go.name)
        if summonId ~= self._summonId then
            self._summonId = summonId
            self:OnSummonPoolChanged()
        end

        if self._summonGiveState[summonId] then
            NetManager.Send("GetSummonReward", {SummonId = summonId}, SummonCtrl.OnHandleProto, self)
        end
    elseif go == self._ui.ButtonSummonOne then
        if not self:IsCurrentSummonValid() then
            SoundSystem.PlayWarningSound()
            CtrlManager.ShowMessageBox({message = SAFE_LOC('loc_SummonCompleted'), single = true})
            return true
        end

        local moneyEnough = self:IsMoneyEnough(true)
        if not moneyEnough then
            SoundSystem.PlayWarningSound()
            local locKey = 'loc_DiamondNotEnough'
            if self._singleCostType == ItemType.Gold then
                locKey = 'loc_GoldNotEnough'
            end
            CtrlManager.ShowMessageBox({message = SAFE_LOC(locKey), single = true})
        else
            SoundSystem.PlaySummonSound()
            if self._singleCostType == 1 then
                self._ui.SummonEffectGoldOne_Anim:Play('OnceAction', 0, 0)
            else
                self._ui.SummonEffectDiamondOne_Anim:Play('OnceAction', 0, 0)
            end
            GlobalScheduler:DoActionAfterTime(1, SummonCtrl.OnSummonOne, self)
            self._showingResult = true
        end
    elseif go == self._ui.ButtonSummonTen then
        if self._eventLeftTime ~= nil and self._eventLeftTime == 0 then
            SoundSystem.PlayWarningSound()
            CtrlManager.ShowMessageBox({message = SAFE_LOC('loc_SummonCompleted'), single = true})
            return true
        end

        local moneyEnough = self:IsMoneyEnough(false)
        if not moneyEnough then
            SoundSystem.PlayWarningSound()
            local locKey = 'loc_DiamondNotEnough'
            if self._multipleCostType == ItemType.Gold then
                locKey = 'loc_GoldNotEnough'
            end
            CtrlManager.ShowMessageBox({message = SAFE_LOC(locKey), single = true})
        else
            SoundSystem.PlaySummonSound()
            if self._singleCostType == 1 then
                self._ui.SummonEffectGoldTen_Anim:Play('OnceAction', 0, 0)
            else
                self._ui.SummonEffectDiamondTen_Anim:Play('OnceAction', 0, 0)
            end
            GlobalScheduler:DoActionAfterTime(1, SummonCtrl.OnSummonTen, self)
            self._showingResult = true
        end
    elseif go == self._ui.ButtonPreview then
        SoundSystem.PlayUIClickSound()
        local summonId = self._summonId
        CtrlManager.OpenPanel(CtrlNames.SummonPreview, {summonId = summonId})
        self._summonPoolCollections[summonId].preNum = self._summonPoolCollections[summonId].curNum
        self._ui.SummonCollectionHint:SetActive(false)
    elseif go == self._ui.ResultBlocker then
        SoundSystem.PlayUICancelSound()
        local summonId = self._summonId
        self:RefreshSummonCollectionRatio(summonId)
        self:RefreshExchangeCharacterState()
        self:RefreshSummonGiveCharacterState()
        self:GetSummonReward()
        self._ui.ResultPanel:SetActive(false)
    elseif go == self._ui.ButtonHint then
        SoundSystem.PlayUIClickSound()
        --防止浏览器缓存
        local url = SUMMON_PROBABILITY_URL .. "?timestamp="..os.time()
		Global.OpenURL(url)
    elseif go == self._ui.ExchangeRoot then
        SoundSystem.PlayUIClickSound()
        CtrlManager.OpenPanel(CtrlNames.SummonExchange, {characterId = self.CurExchangeCharacterId})
    elseif go.transform.parent == self._ui.TokenRoot then
        local tokenId = tonumber(go.name)
        local summonId = ConfigUtils.GetTokenSummonPool(tokenId)
        if self:HasSummon(summonId) and summonId ~= self._summonId then 
            SoundSystem.PlayUIClickSound()
            self._summonId = summonId
            self:OnSummonPoolChanged()
        end
    end

    return true
end

function SummonCtrl:IsMoneyEnough(single)
    if single then
        if not self._singleUseToken then
            local ownNum = GameData.GetMoney(self._singleCostType)
            if ownNum < self._singleCostNum then
                return false
            end
        end
    else
        if not self._multipleUseToken then
            local ownNum = GameData.GetMoney(self._multipleCostType)
            if ownNum < self._multipleCostNum then
                return false
            end
        end
    end

    return true
end

-- summon one
function SummonCtrl:OnSummonOne()
    local summonId = self._summonId
    local useToken = self._singleUseToken
    local ownGold = GameData.GetMoney(ItemType.Gold)
    local ownDiamond = GameData.GetMoney(ItemType.Diamond)

    NetManager.Send('Draw', {
        Summonid = summonId, 
        CostType = 'SingleCost', 
        RepeatCount = 1, 
        UseToken = useToken,
        TokenId = self._singleTokenCostType,
        TokenCost = self._singleTokenCostNum,
        Gold = ownGold,
        Diamond = ownDiamond,
    }, SummonCtrl.OnHandleProto, self)
end

-- summon ten
function SummonCtrl:OnSummonTen()
    local summonId = self._summonId
    local useToken = self._multipleUseToken
    local ownGold = GameData.GetMoney(ItemType.Gold)
    local ownDiamond = GameData.GetMoney(ItemType.Diamond)

    NetManager.Send('Draw', {
        Summonid = summonId, 
        CostType = 'MultipleCost', 
        RepeatCount = 1, 
        UseToken = useToken,
        TokenId = self._multipleTokenCostType,
        TokenCost = self._multipleTokenCostNum,
        Gold = ownGold,
        Diamond = ownDiamond,
    }, SummonCtrl.OnHandleProto, self)
end

function SummonCtrl:OnHandleProto(proto, data, requestData)
    if proto == 'Draw' then
        -- 不能操作的时间需要cover弹出抽卡结果的时间
        local useToken = requestData.UseToken
        GlobalScheduler:DoActionAfterTime(1 + 2.2, SummonCtrl.OnEndShowResult, self)

        local dropItems = data.GoodsList or {}
        local finalResult = {}
        for idx = 1, #dropItems do
            local itemId = dropItems[idx][1]
            local itemNum = dropItems[idx][2]
            local isNew = not GameData.IsItemUnlocked(itemId)
            GameData.CollectItem(itemId, itemNum, false)

            finalResult[idx] = {id = itemId, num = itemNum, isNew = isNew}
        end

        if useToken then
            local tokenId = requestData.TokenId
            local tokenCost = requestData.TokenCost
            GameData.ConsumeToken(tokenId, tokenCost)
        end

        local goldNum = data.RemainGold or 0
        local diamondNum = data.RemainDiamond or 0
        GameData.SetMoney(ItemType.Gold, goldNum)
        GameData.SetMoney(ItemType.Diamond, diamondNum)
        GameData.SyncTutorialData()

        table.sort(finalResult, SummonDropResultSortFunc)
        self:ShowResultPanel(finalResult)

        local summonId =  requestData.Summonid
        local showSummonHint = self:ShouldShowSummonHint(summonId)
        self._ui.SummonHint:SetActive(showSummonHint)
    elseif proto == "GetSummonReward" then
        local summonId = requestData.SummonId
        local giveCharacterId = ConfigUtils.GetSummonGiveCharacter(summonId)
        GameData.CollectItem(giveCharacterId, 1, true)
        GameData.CheckAndHintGoalsOfCurrentCountType()
        self:RefreshSummonGiveCharacterState()
    end
end

function SummonCtrl:OnEndShowResult()
	-- 允许点击关闭
	self._showingResult = false
    GameData.CheckAndHintGoalsOfCurrentCountType()

	-- 将New的父节点显示
	for idx = 1, self._ui.ResultBoxOne_Trs.childCount do
		local cardback = self._ui.ResultBoxOne_Trs:GetChild(idx - 1):Find('CardBack')
		if cardback.childCount > 0 then
			cardback:GetChild(0):Find("Hint").gameObject:SetActive(true)
		end
	end
	for idx = 1, self._ui.ResultBoxTen_Trs.childCount do
		local cardback = self._ui.ResultBoxTen_Trs:GetChild(idx - 1):Find('CardBack')
		if cardback.childCount > 0 then
			cardback:GetChild(0):Find("Hint").gameObject:SetActive(true)
		end
	end
end

--- 获取结果中角色的最高稀有度
function SummonCtrl:GetCharacterBestRarityFromResult(dropItems)
    local result = 1
    for k,v in pairs(dropItems) do
        local itemType = ConfigUtils.GetItemTypeFromId(v.id)
        if itemType == ItemType.Character then
            local itemRarity = ConfigUtils.GetItemRarity(v.id)
            if itemRarity > result then
                result = itemRarity
            end
        end
    end
    return result
end

--- 显示抽卡结果
function SummonCtrl:ShowResultPanel(dropItems)
    local ui = self._ui

    self._ui.ResultPanel:SetActive(true)
    self._ui.TweenScale:ResetToBeginning()
    self._ui.TweenScale:PlayForward()

    local characterBestRarity = self:GetCharacterBestRarityFromResult(dropItems)
    ui.BG_Blue:SetActive(characterBestRarity <= 3)
    ui.BG_Gold:SetActive(characterBestRarity == 4)
    ui.BG_Colorful:SetActive(characterBestRarity >= 5)

	-- 金币:铁箱子
	-- 玉璧:金箱子
    if self._singleCostType == ItemType.Gold then
        self._ui.ResultBoxOne_Trs:GetComponent('UISprite').spriteName = 'chest1'
        self._ui.ResultBoxTen_Trs:GetComponent('UISprite').spriteName = 'chest1'
    elseif self._singleCostType == ItemType.Diamond then
        self._ui.ResultBoxOne_Trs:GetComponent('UISprite').spriteName = 'chest2'
        self._ui.ResultBoxTen_Trs:GetComponent('UISprite').spriteName = 'chest2'
    end

    local hasSSR = false
    local totalCount = #dropItems
    -- 一个
    if totalCount == 1 then
        local idx = 1
        local itemTrs = self._ui.ResultBoxOne_Trs:GetChild(0)

        local itemId = dropItems[idx].id
        local itemNum = dropItems[idx].num
        local isNew = dropItems[idx].isNew

        self:ConstructDropItem(itemTrs, dropItems[idx])

        self._ui.ResultBoxOne_Trs.parent.gameObject:SetActive(true)
        self._ui.ResultBoxTen_Trs.parent.gameObject:SetActive(false)
        self._ui.ResultBoxOne_Trs.parent:GetComponent('Animator'):Play('OnceAction', 0, 0)

        if self:IsItemOfSSR(itemId) then
            hasSSR = true
        end
    else
        for idx = 1, totalCount do
            local itemTrs = self._ui.ResultBoxTen_Trs:GetChild(idx - 1)

            local itemId = dropItems[idx].id
            local itemNum = dropItems[idx].num
            local isNew = dropItems[idx].isNew

            self:ConstructDropItem(itemTrs, dropItems[idx])

            if self:IsItemOfSSR(itemId) then
                hasSSR = true
            end
        end

        self._ui.ResultBoxOne_Trs.parent.gameObject:SetActive(false)
        self._ui.ResultBoxTen_Trs.parent.gameObject:SetActive(true)
        self._ui.ResultBoxTen_Trs.parent:GetComponent('Animator'):Play('TenAction', 0, 0)
    end

    local soundName = SoundNames.SummonNormal
    if hasSSR then
        soundName = SoundNames.SummonSSR
    end

    GlobalScheduler:DoActionAfterTime(1.5, SummonCtrl.PlaySoundEffect, self, soundName)
end

function SummonCtrl:PlaySoundEffect(soundName)
    SoundSystem.PlaySoundOfName(soundName)
end

function SummonCtrl:IsItemOfSSR(itemId)
    local itemType = ConfigUtils.GetItemTypeFromId(itemId)
    if itemType == ItemType.Character then
        local rarity = ConfigUtils.GetCharacterRarity(itemId)
        return rarity >= 5
    end

    return false
end

function SummonCtrl:GetItemCardBack(itemId)
    local itemType = ConfigUtils.GetItemTypeFromId(itemId)

    local midName = ""
    local rarity = 1

    if itemType == ItemType.Character then
        midName = "Character"
        rarity = ConfigUtils.GetCharacterRarity(itemId)
    elseif itemType == ItemType.Pet then
        midName = "Pet"
        rarity = ConfigUtils.GetPetRarity(itemId)
    elseif itemType == ItemType.RoomPiece then
        midName = "RoomPiece"
        rarity = ConfigUtils.GetRoomPieceRarity(itemId)
    elseif itemType == ItemType.Goods then
        local goodsSubType = ConfigUtils.GetGoodsSubType(itemId)
        if goodsSubType == GoodsSubType.Chip then
            midName = "GoodsChip"
        else
            midName = "GoodsMaterial"
        end
        rarity = ConfigUtils.GetGoodsRarity(itemId)
    else
        assert(false, "un-handled item type: "..tostring(itemType))
    end

    local postNum = 1
    if rarity >= 5 then
        postNum = 3
    elseif rarity == 4 then
        postNum = 2
    end

    return "CardBack_"..midName.."_"..tostring(postNum)
end

-- 构造抽卡结果中的某一个物品
function SummonCtrl:ConstructDropItem(itemTrs, itemInfo)
	local cardBackTrs = itemTrs:Find('CardBack')
	local itemTrs = nil
	if cardBackTrs.childCount <= 0 then
		local itemObj = Helper.NewObject(self._ui.ResultItem, cardBackTrs)
		CtrlManager.AddClick(self, itemObj)
		itemTrs = itemObj.transform
	else
		itemTrs = cardBackTrs:GetChild(0)
	end

    local itemId = itemInfo.id
    local itemNum = itemInfo.num
    local isNew = itemInfo.isNew
    local bgName, borderName = UIHelper.GetBorderAndBgByItemId(itemId)
    -- 设置卡背
    itemTrs.parent.parent:GetComponent('UISprite').spriteName = self:GetItemCardBack(itemId)
    -- go name
    itemTrs.gameObject:SetActive(true)
    itemTrs.gameObject.name = tostring(itemId)
    -- name
    local nameLabel = itemTrs:Find('Name'):GetComponent('UILabel')
    nameLabel.text = ConfigUtils.GetItemName(itemId)
    -- icon and num
    UIHelper.ConstructItemIconAndNum(self, itemTrs, itemId, nil)
    -- bg
    local bg = itemTrs:Find('BG'):GetComponent('UISprite')
    bg.spriteName = bgName
    -- is new
    local newMark = itemTrs:Find("Hint/New").gameObject
	newMark:SetActive(isNew)
	itemTrs:Find("Hint").gameObject:SetActive(false)
end
---------------------------------------------------------------------------
-- tutorial
function SummonCtrl:CheckTutorial()
    local tutorials = {}

    if GameData.IsTutorialNotFinished(Tutorials.Tutorial_8_2) and GameData.IsGoalRunning(TutorialConstData.SummonGoal) then
        local position = self._ui.Camera:WorldToScreenPoint(self._ui.PositionMark_1.position)
        tutorials[1] = {event = Tutorials.Tutorial_8_1, position = position, sender = self}
        position = self._ui.Camera:WorldToScreenPoint(self._ui.PositionMark_2.position)
        tutorials[2] = {event = Tutorials.Tutorial_8_2, position = position, sender = self}
    end

    if #tutorials > 0 then
        CtrlManager.ShowTutorials(tutorials)
    end

    return #tutorials > 0
end

function SummonCtrl:OnTutorialClicked(tutorial)
    if tutorial == Tutorials.Tutorial_8_2 then
        self:OnClicked(self._ui.ButtonSummonOne)
    else
        SoundSystem.PlayUIClickSound()
    end
end
---------------------------------------------------------------------------