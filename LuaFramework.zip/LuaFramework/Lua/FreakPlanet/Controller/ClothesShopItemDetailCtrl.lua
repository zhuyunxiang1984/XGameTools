require "FreakPlanet/View/ClothesShopItemDetailPanel"

local class = require "FreakPlanet/Utils/middleclass"
ClothesShopItemDetailCtrl  = class(CtrlNames.ClothesShopItemDetail, BaseCtrl)

-- load the ui prefab
function ClothesShopItemDetailCtrl:LoadPanel()
	self:CreatePanel("ClothesShopItemDetail")
end

-- construct ui panel data
function ClothesShopItemDetailCtrl:ConstructUI(obj)
	self._ui = ClothesShopItemDetailPanel.Init(obj)
	self.ShopId = self._parameter.ShopId
	self.ProductId = self._parameter.ProductId
	self.CostDatas = GameDataClothesShop.GetProductCostDatas(self.ShopId, self.ProductId)
	self.CostId, self.CostNum = self.CostDatas[1].CostId, self.CostDatas[1].CostNum
end

-- fill ui with the data
function ClothesShopItemDetailCtrl:SetupUI()
	local ui = self._ui
	local shopId = self.ShopId
	local productId = self.ProductId

	local productInfo = ConfigUtils.GetClothesShopProductInfo(productId)
	local curNum = 0
	if productInfo.Limit > 0 then
		curNum = math.max(0, productInfo.Limit - GameDataClothesShop.GetProductBoughtNum(shopId, productId))
	end
	local itemId, itemCount = ConfigUtils.GetClothesShopProductItem(productId)
	UIHelper.SetItemIcon(self, ui.imgIcon, itemId)
	ui.txtName.text = productInfo.Name
	ui.txtDesc.text = ConfigUtils.GetItemDesc(itemId)

	if productInfo.Limit > 0 then
		ui.txtNum.text = string.format("库存:%d", curNum)
		ui.txtNum.gameObject:SetActive(true)
	else
		ui.txtNum.gameObject:SetActive(false)
	end

	if productInfo.Limit < 1 or curNum > 0 then
		UIHelper.SetIconAndNumForBuyButton(self, ui.imgCostIcon, ui.txtCostNum, self.CostId, self.CostNum, GameData.GetItemNum(self.CostId))
		ui.btnBuy.gameObject:SetActive(true)
	else
		ui.btnBuy.gameObject:SetActive(false)
	end

	CtrlManager.AddClick(self, ui.btnBlocker)
	CtrlManager.AddClick(self, ui.btnBuy)

end

function ClothesShopItemDetailCtrl:DestroyImpl()
end

-- on clicked
function ClothesShopItemDetailCtrl:OnClicked(go)
	local ui = self._ui
	if go == ui.btnBlocker then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
	elseif go == ui.btnBuy then
		--XDebug.Log('GGYY', "购买 " .. self.ProductId)
		SoundSystem.PlayUIClickSound()
		local ownNum = GameData.GetItemNum(self.CostId)
		if ownNum < self.CostNum then
			CtrlManager.ShowMessageBox({message = ConfigUtils.GetItemName(self.CostId).."不足", single = true})
			return
		end
		local productInfo = ConfigUtils.GetClothesShopProductInfo(self.ProductId)
		CtrlManager.ShowMessageBox({message = string.format("是否确认购买%s", productInfo.Name), single = false, onConfirm = function()
			GameDataClothesShop.RequestBuyProduct(self.ShopId, self.ProductId, self.CostId, self.CostNum)
			self:Close()
		end})
	end
	return true
end