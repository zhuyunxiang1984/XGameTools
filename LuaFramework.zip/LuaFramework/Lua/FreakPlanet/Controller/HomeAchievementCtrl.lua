require "FreakPlanet/View/HomeAchievementPanel"

local class = require "FreakPlanet/Utils/middleclass"
HomeAchievementCtrl  = class(CtrlNames.HomeAchievement, BaseCtrl)

local GOAL_INTERVAL_SIZE = 70

-- load the ui prefab
function HomeAchievementCtrl:LoadPanel()
	self:CreatePanel("HomeAchievement")
end

-- construct ui panel data
function HomeAchievementCtrl:ConstructUI(obj)
	self._ui = HomeAchievementPanel.Init(obj)
end

-- fill ui with the data
function HomeAchievementCtrl:SetupUI()
	local ui = self._ui
	self._HomeAchievementGoals = nil

	CtrlManager.AddClick(self, ui.pObjReturn)
	CtrlManager.AddClick(self, ui.Blocker)
	GameNotifier.AddListener(GameEvent.GoalChanged, HomeAchievementCtrl.OnGoalChanged, self)
	NetManager.Send("GoalList", {GoalType = GoalType.HomeAchievement}, HomeAchievementCtrl.OnHandleProto, self)
end

-- on clicked
function HomeAchievementCtrl:OnClicked(go)
	local ui = self._ui
	if go == ui.pObjReturn or go == ui.Blocker then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
	elseif go.transform.parent.parent.parent == ui.pUIGridRoot.transform then
		if go.name == "UnfinishIcon" then
			XDebug.Log("LZ", "页面跳转!")
		else
			local iIndex = tonumber(go.transform.parent.parent.name)
			local iGoalId = tonumber(go.name)
			local goalState = GameData.GetGoalInfo(iGoalId)
			local goalType = ConfigUtils.GetGoalType(iGoalId)
			XDebug.Log("LZ", "iIndex:", iIndex, "iGoalId:", iGoalId)
			if goalState == GoalState.Complete then
				NetManager.Send("GetGoalReward", {GoalId = iGoalId, GoalType = goalType}, HomeAchievementCtrl.OnHandleProto, self)
			end
		end
	end

	return true
end

function HomeAchievementCtrl:DestroyImpl()
	GameNotifier.RemoveListener(GameEvent.GoalChanged, HomeAchievementCtrl.OnGoalChanged, self)
end

function HomeAchievementCtrl:SetupHomeAchievementUI(isfirst)
	self._HomeAchievementGoals = GameData.GetActiveGoalsOfHomeAchievement()
	local iChildCount = self._ui.pUIGridRoot.transform.childCount
	for idx = iChildCount, 1, -1 do
		local pObj = self._ui.pUIGridRoot.transform:GetChild(idx - 1).gameObject
		pObj:SetActive(false)
		self._ui.ObjPool:RecycleObj(pObj)
	end

	for idx = 1, ConfigUtils.GetHomeAchievementsCount() do
		local pObjAchievementItem = self._ui.ObjPool:GetOrCreateObj(self._ui.EnumPrefabType.AchievementItem, function(pObj)
			local pBtnUnfinishIcon = pObj.transform:Find("FinishStatus/UnfinishIcon").gameObject
			CtrlManager.AddClick(self, pBtnUnfinishIcon)
		end)
		pObjAchievementItem.transform:SetParent(self._ui.pUIGridRoot.transform)
		pObjAchievementItem:SetActive(true)
		pObjAchievementItem.transform.localScale = Vector3.one
		pObjAchievementItem.name = tostring(idx)
		self:ConstructAchievementItemUI(pObjAchievementItem, idx)
	end
	if isfirst then
		self._ui.pUIGridRoot:Reposition()
		self._ui.pScrollViewAchievement:ResetPosition()
	end

end

function HomeAchievementCtrl:ConstructAchievementItemUI(item, idx)
	local pTxtTitle = item.transform:Find("Title"):GetComponent("UILabel")
	local pTxtDesc = item.transform:Find("Desc"):GetComponent("UILabel")
	local pUIGridProgressRoot = item.transform:Find("ProgressRoot"):GetComponent("UIGrid")
	local pObjProgressRoot = item.transform:Find("ProcessRoot").gameObject
	local pObjFinishMark = item.transform:Find("FinishStatus/FinishIcon").gameObject
	local pObjUnFinishMark = item.transform:Find("FinishStatus/UnfinishIcon").gameObject

	local achievementConfig = ConfigUtils.GetHomeAchievementConfig(idx)
	local goalList = ConfigUtils.GetHomeAchievementsGoalList(idx)

	pTxtTitle.text = achievementConfig.Name

	local iCurIndex = self:GetNextUnlockGoalIndexOfAchievement(idx)

	local iChildCount = pUIGridProgressRoot.transform.childCount
	for idx = iChildCount, 1, -1 do
		local pObj = pUIGridProgressRoot.transform:GetChild(idx - 1).gameObject
		pObj:SetActive(false)
		self._ui.ObjPool:RecycleObj(pObj)
	end

	for idx = 1, #goalList do
		local iGoalId = goalList[idx]
		local rewards = ConfigUtils.GetGoalActualRewards(iGoalId)
		local pObj = nil

		local matchGoal = self:IsActuallyMatchAchievementGoal(iGoalId)
		local getReward = self:IsGetRewardOfAchievementGoal(iGoalId)

		if matchGoal then
			if getReward then
				pObj = self._ui.ObjPool:GetOrCreateObj(self._ui.EnumPrefabType.LockItem, function(obj)
					CtrlManager.AddClick(self, obj)
				end)
				UIHelper.ConstructItemIconAndNum(self, pObj.transform, rewards[1].Value, rewards[1].Num, false)
			else
				pObj = self._ui.ObjPool:GetOrCreateObj(self._ui.EnumPrefabType.RewardItem, function(obj)
					CtrlManager.AddClick(self, obj)
				end)
				UIHelper.ConstructItemIconAndNum(self, pObj.transform, rewards[1].Value, rewards[1].Num, true)
			end
		else
			pObj = self._ui.ObjPool:GetOrCreateObj(self._ui.EnumPrefabType.UnlockItem, function(obj)
				CtrlManager.AddClick(self, obj)
			end)
			local state = self:GetAchievementGoalState(iGoalId)
			UIHelper.ConstructItemIconAndNum(self, pObj.transform, rewards[1].Value, rewards[1].Num, state == GoalState.Running)
		end

		pObj.transform:SetParent(pUIGridProgressRoot.transform)
		pObj:SetActive(true)
		pObj.transform.localScale = Vector3.one
		pObj.name = tostring(iGoalId)

	end
	pUIGridProgressRoot:Reposition()

	local iGoalCount = #goalList
	if iGoalCount > 1 then
		pObjProgressRoot:SetActive(true)
		local pTransAttain = pObjProgressRoot.transform:Find("Attain")
		local pTransNotAttain = pObjProgressRoot.transform:Find("NotAttain")

		local iSizeWidth = (iGoalCount - 1) * GOAL_INTERVAL_SIZE
		pTransAttain:GetComponent("UIWidget").width = iSizeWidth
		pTransNotAttain:GetComponent("UIWidget").width = iSizeWidth

		pTransAttain.localPosition = Vector3.New(iSizeWidth / 2, 0, 0)
		pTransNotAttain.localPosition = Vector3.New(iSizeWidth / 2, 0, 0)

		pTransAttain:GetComponent("UISprite").fillAmount = (math.min(iCurIndex, iGoalCount)  - 1) / (iGoalCount - 1)
	else
		pObjProgressRoot:SetActive(false)
	end

	local iIsGetAllReward = self:IsGetAllRewardOfAchievement(idx)
	if iIsGetAllReward then
		pObjFinishMark:SetActive(true)
		pObjUnFinishMark:SetActive(false)

		local pSpriteFinishIcon = pObjFinishMark:GetComponent("UISprite")
		pSpriteFinishIcon.spriteName = achievementConfig.IconComplete
	else
		pObjFinishMark:SetActive(false)
		pObjUnFinishMark:SetActive(true)

		local pSpriteUnFinishIcon = pObjUnFinishMark:GetComponent("UISprite")
		pSpriteUnFinishIcon.spriteName = achievementConfig.IconInProgress

		local pTxtNum = pObjUnFinishMark.transform:Find("Num"):GetComponent("UILabel")

		local needShowId = self:GetRunningAchievementGoalId(idx)
		local condition = ConfigUtils.GetGoalConditions(needShowId)
		assert(#condition == 1, "goal should only have one condition: "..tostring(needShowId))
		local triggers = ConfigUtils.GetGoalTriggers(needShowId)
		assert(#triggers == 1, "goal should only have one condition: "..tostring(needShowId))

		local goalState, goalNum = GameData.GetGoalInfo(needShowId)
		pTxtNum.text = UIHelper.GetGoalShowNum(condition[1], goalNum[1], triggers, true)

		pTxtDesc.text = UIHelper.GetGoalFinalName(condition[1])
	end
end

function HomeAchievementCtrl:OnGoalChanged(goalType)
	if goalType == GoalType.HomeAchievement then
		self:SetupHomeAchievementUI(false)
	end
end

function HomeAchievementCtrl:OnHandleProto(proto, data, requestData)
	if proto == "GoalList" then
		local requestGoalType = requestData.GoalType
		GameData.RemoveGoalsOfType(requestGoalType)
		local goalList = data.HomeAchievementList or {}
		GameData.AddGoals(goalList)
		self:SetupHomeAchievementUI(true)
	elseif proto == "GetGoalReward" then
		local iGoalId = requestData.GoalId
		GameData.FinishGoal(iGoalId)
		NavigationCtrl.EnableSuspend(true)
		local goldNum = data.RemainGold
		local diamondNum = data.RemainDiamond
		GameData.SetMoney(ItemType.Gold, goldNum)
		GameData.SetMoney(ItemType.Diamond, diamondNum)
		GameData.CheckAndHintGoalsOfCurrentCountType()

	end
end

--- 是否领取该成就的所有奖励
function HomeAchievementCtrl:IsGetAllRewardOfAchievement(idx)
	local ret = true
	local goalList = ConfigUtils.GetHomeAchievementsGoalList(idx)
	local existedGoalList = self:GetExistedGoalsByIdx(idx)
	if Helper.TableLength(existedGoalList) == #goalList then
		for k, v in pairs(existedGoalList) do
			if not v.GetReward then
				ret = false
				break
			end
		end
	else
		ret = false
	end
	return ret
end

function HomeAchievementCtrl:GetExistedGoalsByIdx(idx)
	local existedGoals = {}
	local goalList = ConfigUtils.GetHomeAchievementsGoalList(idx)
	for idx = 1, #goalList do
		for k , v in pairs(self._HomeAchievementGoals) do
			if k == goalList[idx] then
				existedGoals[k] = v
			end
		end
	end
	return existedGoals
end

--- 获取当前成就中需要解锁的Goal的索引
function HomeAchievementCtrl:GetNextUnlockGoalIndexOfAchievement(idx)
	local iIndex = 0
	local goalList = ConfigUtils.GetHomeAchievementsGoalList(idx)
	for idx = #goalList, 1, -1 do
		if self:IsActuallyMatchAchievementGoal(goalList[idx]) == true then
			iIndex = idx
			break
		end
	end

	return iIndex + 1
end

function HomeAchievementCtrl:GetAchievementGoalState(goalId)
	for k , v in pairs(self._HomeAchievementGoals) do
		if k == goalId then
			return v.state
		end
	end
	return GoalState.Closed
end

function HomeAchievementCtrl:IsGetRewardOfAchievementGoal(goalId)
	for k , v in pairs(self._HomeAchievementGoals) do
		if k == goalId then
			return v.getReward
		end
	end
	return false
end

function HomeAchievementCtrl:IsActuallyMatchAchievementGoal(goalId)
	for k , v in pairs(self._HomeAchievementGoals) do
		if k == goalId then
			return v.lastCompleted
		end
	end
	return false
end

function HomeAchievementCtrl:GetRunningAchievementGoalId(idx)
	local goalList = ConfigUtils.GetHomeAchievementsGoalList(idx)
	for k, v in pairs(self._HomeAchievementGoals) do
		if v.state == GoalState.Running and Helper.TableContains(goalList, k)  then
			return k
		end
	end
	return goalList[#goalList]
end