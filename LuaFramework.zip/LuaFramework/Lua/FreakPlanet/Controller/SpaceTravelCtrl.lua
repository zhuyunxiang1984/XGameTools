require "FreakPlanet/View/SpaceTravelPanel"

local class = require "FreakPlanet/Utils/middleclass"
SpaceTravelCtrl  = class(CtrlNames.SpaceTravel, BaseCtrl)

local PATH_NAME_CURRENT = "Current"
local PATH_NAME_TO_CLEAN = "Clean"
local PATH_NAME_LEFT_CHILD = "LeftChild"
local PATH_NAME_RIGHT_CHILD = "RightChild"
local PATH_NAME_SIBLING = "Sibling"

local ShipState = {
    Idle = "Idle",
    Moving = "Moving",
    WaitSelection = "WaitSelection",
}

local CommonPrefabNames = {
    "SpaceCommon1",
    "SpaceCommon2",
    "SpaceCommon3",
    "SpaceCommon4",
    "SpaceCommon5",
    "SpaceCommon6",
}

local SpecialPrefabNames = {
    "SpaceWorld1_1",
    "SpaceWorld1_2",
    "SpaceWorld1_3",
    "SpaceWorld1_4",
    "SpaceWorld1_5",
    "SpaceWorld1_6",
}

-- load the ui prefab
function SpaceTravelCtrl:LoadPanel()
	self:CreatePanel("SpaceTravel")
end

-- construct ui panel data
function SpaceTravelCtrl:ConstructUI(obj)
	self._ui = SpaceTravelPanel.Init(obj)
    NavigationCtrl.ShowOrHide(false)
end

-- destroy implementation
function SpaceTravelCtrl:DestroyImpl()
    NavigationCtrl.ShowOrHide(true)
    self:CleanWorld()
    GameNotifier.RemoveListener(GameEvent.MoveSpaceTravelCamera, SpaceTravelCtrl.OnMoveSpaceTravelCamera, self)
end

-- fill ui with the data
function SpaceTravelCtrl:SetupUI()
    -- world bg bundle
    self:DynamicLoadBundle(Const.TravelWorldBGBundleName)
    self._worldPrefab = self:DynamicLoadAsset(Const.TravelBundleName, "SpaceWorld")
    self._pathPointPrefab = self:DynamicLoadAsset(Const.TravelBundleName, "PathPoint")

    self._seasonId = self._parameter.season
    self._shipState = ShipState.Idle
    self:SwitchWorld(self._seasonId)
    -- add listener 
    GameNotifier.AddListener(GameEvent.MoveSpaceTravelCamera, SpaceTravelCtrl.OnMoveSpaceTravelCamera, self)
end

function SpaceTravelCtrl:SpawnShip()
    local num = self._ship.childCount
    if num > 0 then
        return
    end

    local seasonData = GameData.GetSpaceTravelSeasonData(self._seasonId)
    local shipId = seasonData.ship
    local prefabName, prefabBundle = ConfigUtils.GetSpaceShipPrefab(shipId)
    local shipPrefab = self:DynamicLoadAsset(prefabBundle, prefabName)
    local shipObj = Helper.NewObject(shipPrefab, self._ship)
    shipObj:SetActive(true)
    shipObj.name = prefabName
    -- default layer, not UI
    shipObj.layer = 0
end

function SpaceTravelCtrl:MarkDirtyBound()
    self._boundDirty = true
end

function SpaceTravelCtrl:GetWorldBound()
    local halfHeight = self._worldCamera.orthographicSize
    local halfWidth = halfHeight * Screen.width / Screen.height

    if self._boundDirty then
        self._leftLimit = nil
        self._rightLimit = nil
        self._bottomLimit = nil
        self._topLimit = nil

        for k, v in pairs(self._groupBG) do
            if self._leftLimit == nil or v.minX < self._leftLimit then
                self._leftLimit = v.minX
            end

            if self._rightLimit == nil or v.maxX > self._rightLimit then
                self._rightLimit = v.maxX
            end

            if self._bottomLimit == nil or v.minY < self._bottomLimit then
                self._bottomLimit = v.minY
            end

            if self._topLimit == nil or v.maxY > self._topLimit then
                self._topLimit = v.maxY
            end
        end

        if self._leftLimit ~= nil then
            self._leftLimit = self._leftLimit + halfWidth * 0.9
        end

        if self._rightLimit ~= nil then
            self._rightLimit = self._rightLimit - halfWidth * 0.9
        end

        if self._bottomLimit ~= nil then
            self._bottomLimit = self._bottomLimit + halfHeight * 0.9
        end

        if self._topLimit ~= nil then
            self._topLimit = self._topLimit - halfHeight * 0.9
        end

        self._boundDirty = false
    end

    return self._leftLimit, self._rightLimit, self._bottomLimit, self._topLimit
end

function SpaceTravelCtrl:InitializeCellList(cell)
    local ret = {}

    for idx = 1, cell * cell do
        table.insert(ret, idx)
    end

    return ret
end

function SpaceTravelCtrl:CleanWorld()
    if self._worldObj ~= nil then
        destroy(self._worldObj)
        self._worldObj = nil
    end
end

function SpaceTravelCtrl:SwitchWorld(seasonId)
    assert(self._seasonId == seasonId, "season is not same: "..tostring(self._seasonId).."; "..tostring(seasonId))
    assert(self._shipState == ShipState.Idle, "ship should be idle")

    self:CleanWorld()
    self:CleanPath()

    local seasonData = GameData.GetSpaceTravelSeasonData(self._seasonId)
    self._worldId = GameData.GetWorldOfSpaceTravelSeason(self._seasonId, seasonData.world)
    self._worldNodeId = seasonData.node

    -- world bg prefab
    local worldObj = Helper.NewObject(self._worldPrefab)
    worldObj:SetActive(true)
    worldObj.name = "WorldBG"

    self._worldCamera = worldObj.transform:Find("Camera"):GetComponent("Camera")
    self._worldCamera.depth = self._ui.Camera.depth
    self._worldObj = worldObj
    self._worldBGRoot = worldObj.transform:Find("BG")
    self._worldPathRoot = worldObj.transform:Find("Paths")
    self._worldEmptyMark = worldObj.transform:Find("EmptyMark")
    self._ship = worldObj.transform:Find("Ship")
    self:SpawnShip()

    -- prepare for group bg
    local halfHeight = self._worldCamera.orthographicSize
    local halfWidth = halfHeight * Screen.width / Screen.height
    self._groupWidth = halfWidth * 4
    self._groupHeight = halfHeight * 2
    self._groupBG = {}
    -- init path
    self:InitPath()
end
----------------------------------------------------------------------------------------------------
function SpaceTravelCtrl:CleanBG()
    if self._groupBG == nil then
        return
    end

    local curCount = #self._groupBG
    for idx = curCount, 1, -1  do
        destroy(self._groupBG[idx].root.gameObject)
    end

    self:MarkDirtyBound()
end

function SpaceTravelCtrl:GetPathObjectsBound(pathObjects)
    local minX = nil
    local maxX = nil
    local minY = nil
    local maxY = nil

    for k, v in pairs(pathObjects) do
        local pointsRoot = v.transform:Find("Points")
        for idx = 1, pointsRoot.childCount do
            local pointItem = pointsRoot:GetChild(idx - 1)
            local pos = pointItem.position
            if minX == nil or pos.x < minX then
                minX = pos.x
            end

            if maxX == nil or pos.x > maxX then
                maxX = pos.x
            end

            if minY == nil or pos.y < minY then
                minY = pos.y
            end

            if maxY == nil or pos.y > maxY then
                maxY = pos.y
            end
        end
    end

    return minX, maxX, minY, maxY
end

function SpaceTravelCtrl:GenerateGroupBG(pathObjects, seed)
    local halfWidth = self._groupWidth * 0.5
    local minX, maxX, minY, maxY = self:GetPathObjectsBound(pathObjects)
    local centerX = (maxX + minX) / 2
    local centerY = (maxY + minY) / 2

    if #pathObjects == 1 then
        minY = minY - self._groupHeight * 0.75
    end

    local itemMinX = math.min(minX, centerX - halfWidth * 1.5)
    local itemMaxX = math.max(maxX, centerX + halfWidth * 1.5)

    local timestamp = GameData.GetSpaceTravelSeasonTimestamp(self._seasonId)
    Helper.RandSeed(timestamp + seed)
    local root = GameObject.New().transform
    root.parent = self._worldBGRoot
    root.position = Vector3.New(centerX, centerY, 0)
    root.gameObject.name = "Group_"..tostring(seed)

    self:GenerateGroupItems(root, itemMinX, itemMaxX, minY, maxY, CommonPrefabNames, 10, 60)
    self:GenerateGroupItems(root, itemMinX, itemMaxX, minY, maxY, SpecialPrefabNames, 5, 5)

    self:MarkDirtyBound()
    Helper.RandSeed()

    local paths = {}
    Helper.CopyTable(paths, pathObjects)

    table.insert(self._groupBG, {root = root, paths = paths, minX = minX, maxX = maxX, minY = minY, maxY = maxY})
end

function SpaceTravelCtrl:GenerateGroupItems(root, minX, maxX, minY, maxY, prefabNameList, cell, num)
    local cellList = self:InitializeCellList(cell)
    local cellWidth = (maxX - minX) / cell
    local cellHeight = (maxY - minY) / cell

    for idx = 1, num do
        local selectedIdx = Helper.RandInt(1, #cellList)
        local cellIndex = cellList[selectedIdx]
        table.remove(cellList, selectedIdx)

        local row = math.floor((cellIndex - 1) / cell)
        local column = cellIndex - cell * row - 1

        local cellMinX = minX + column * cellWidth
        local cellMaxX = minX + (column + 1) * cellWidth
        local cellMinY = minY + row * cellHeight
        local cellMaxY = minY + (row + 1) * cellHeight

        local pos = Vector3.zero 
        pos.x = Helper.RandFloat(cellMinX, cellMaxX)
        pos.y = Helper.RandFloat(cellMinY, cellMaxY)
        pos.z = 10

        local rotation = Vector3.zero
        rotation.z = Helper.RandFloat(-60, 60)

        local scale = Helper.RandFloat(0.9, 1.1)

        local prefabIndex = Helper.RandInt(1, #prefabNameList)
        local prefabName = prefabNameList[prefabIndex]
        local itemPrefab = self:DynamicLoadAsset(Const.TravelBundleName, prefabName)
        local itemObj = Helper.NewObject(itemPrefab, root)
        itemObj:SetActive(true)
        itemObj.name = prefabName

        itemObj.transform.position = pos
        itemObj.transform.eulerAngles = rotation
        itemObj.transform.localScale = Vector3.one * scale
    end
end

function SpaceTravelCtrl:OnPathRemoved(pathObj)
    local curCount = #self._groupBG
    for idx = 1, curCount do
        local pathIndex = Helper.IndexOfArray(self._groupBG[idx].paths, pathObj)
        if pathIndex ~= nil then
            table.remove(self._groupBG[idx].paths, pathIndex)
            if #self._groupBG[idx].paths == 0 then
                destroy(self._groupBG[idx].root.gameObject)
                table.remove(self._groupBG, idx)
                self:MarkDirtyBound() 
            end
            break
        end
    end    
end
----------------------------------------------------------------------------------------------------
function SpaceTravelCtrl:CleanPath()
    if self._worldPathRoot == nil then
        return
    end
    
    local num = self._worldPathRoot.childCount
    for idx = num, 1, -1 do
        local obj = self._worldPathRoot:GetChild(idx - 1).gameObject
        self:RemovePathObject(obj)
    end
end

function SpaceTravelCtrl:RemovePathObject(pathObj)
    self:OnPathRemoved(pathObj)
    destroy(pathObj)
end

function SpaceTravelCtrl:InitPath()
    local nodeId = self._worldNodeId
    if not ConfigUtils.IsValidItem(nodeId) then
        nodeId = ConfigUtils.GetFirstNodeOfSpaceTravelWorld(self._worldId)
    end

    self._currentPathList = ConfigUtils.GetSpaceTravelMapNodePath(self._worldId, nodeId)
    self._nodeMap = {}

    self._currentPath = self:ConstructCurrentPath(nodeId)
    self:ConstructChildPaths(nodeId)

    self:PutShipTo(self._worldNodeId)
end

function SpaceTravelCtrl:SelectRootPathPrefab()
    return "PathFirst"
end

function SpaceTravelCtrl:SelectLeftPathPrefab()
    return "PathLeft_1"
end

function SpaceTravelCtrl:SelectRightPathPrefab()
    return "PathRight_1"
end

function SpaceTravelCtrl:SelectPathPrefab(nodeId, isRoot, isLeft)
    local prefabName = nil

    local seed = ConfigUtils.GetSpaceTravelNodeSeed(self._worldId, nodeId)
    Helper.RandSeed(seed)

    if isRoot then
        prefabName = self:SelectRootPathPrefab()
    elseif isLeft then
        prefabName = self:SelectLeftPathPrefab()
    else
        prefabName = self:SelectRightPathPrefab()
    end

    Helper.RandSeed()

    return prefabName
end

function SpaceTravelCtrl:SetParentPathPosition(pos, pathTransform)
    local pointsRoot = pathTransform:Find("Points")
    local lastPoint = pointsRoot:GetChild(pointsRoot.childCount - 1)
    local relativePosition = pathTransform:InverseTransformPoint(lastPoint.position)

    local curPos = pathTransform.position
    curPos.x = pos.x - relativePosition.x
    curPos.y = pos.y - relativePosition.y
    pathTransform.position = curPos
end

function SpaceTravelCtrl:ConstructNodesOfPath(pathList, pathTransform)
    local nodeMap = {}

    local pointsRoot = pathTransform:Find("Points")
    local pointNum = pointsRoot.childCount
    local nodeNum = #pathList

    log("path node num: "..tostring(nodeNum).."; path point num: "..tostring(pointNum))

    local step = math.floor(pointNum / nodeNum)
    local usedIndices = {}
    for idx = 1, nodeNum do
        usedIndices[idx * step] = idx
    end

    for idx = 1, pointNum do
        local nodeIdx = usedIndices[idx]
        local item = pointsRoot:GetChild(idx - 1)
        item.gameObject:SetActive(nodeIdx ~= nil)

        if nodeIdx ~= nil then
            local nodeId = pathList[nodeIdx]
            nodeMap[nodeId] = item
            item.gameObject.name = nodeId

            local pathPointItem = nil
            if item.childCount > 0 then
                pathPointItem = item:GetChild(0)
            end

            if pathPointItem == nil then
                local pathPointObj = Helper.NewObject(self._pathPointPrefab, item)
                pathPointObj:SetActive(true)
                pathPointObj.name = "PathPoint"

                pathPointItem = pathPointObj.transform
            end

            self:ConstructPathPoint(pathPointItem, nodeId)
        end
    end

    return nodeMap
end

function SpaceTravelCtrl:ConstructPathPoint(item, nodeId)
    local nodeName, effectName = ConfigUtils.GetSpaceTravelNodePathPointName(self._worldId, nodeId)

    local typesRoot = item:Find("Types")
    for idx = 1, typesRoot.childCount do
        local element = typesRoot:GetChild(idx - 1).gameObject
        element:SetActive(element.name == nodeName)
    end

    local effectRoot = item:Find("Effect")
    for idx = 1, effectRoot.childCount do
        local element = effectRoot:GetChild(idx - 1).gameObject
        element:SetActive(element.name == effectName)
    end
end

function SpaceTravelCtrl:MergeNodeMap(nodeMap)
    for k, v in pairs(nodeMap) do
        self._nodeMap[k] = v
    end
end

function SpaceTravelCtrl:ConstructCurrentPath(nodeId)
    local pathPrefabName = self:SelectPathPrefab(nodeId, true)
    local pathPrefab = self:DynamicLoadAsset(Const.TravelBundleName, pathPrefabName)
    local pathPrefabObj = Helper.NewObject(pathPrefab, self._worldPathRoot)
    pathPrefabObj:SetActive(true)
    pathPrefabObj.name = PATH_NAME_CURRENT

    local currentPath = pathPrefabObj.transform
    local currentNodeMap = self:ConstructNodesOfPath(self._currentPathList, pathPrefabObj.transform)
    self:MergeNodeMap(currentNodeMap)

    local seed = ConfigUtils.GetSpaceTravelNodeSeed(self._worldId, self._currentPathList[1])
    self:GenerateGroupBG({pathPrefabObj}, seed)

    return currentPath
end

function SpaceTravelCtrl:ConstructChildPaths(nodeId)
    local leftPathList, rightPathList = ConfigUtils.GetSpaceTravelChildNodePaths(self._worldId, nodeId)
    if #leftPathList == 0 then
        return
    end

    local pointsRoot = self._currentPath:Find("Points")
    local lastPoint = pointsRoot:GetChild(pointsRoot.childCount - 1)

    local leftPrefabName = self:SelectPathPrefab(leftPathList[1], false, true)
    local leftPrefab = self:DynamicLoadAsset(Const.TravelBundleName, leftPrefabName)
    local leftPrefabObj = Helper.NewObject(leftPrefab, self._worldPathRoot)
    leftPrefabObj:SetActive(true)
    leftPrefabObj.name = PATH_NAME_LEFT_CHILD
    leftPrefabObj.transform.position = lastPoint.position
    local leftNodeMap = self:ConstructNodesOfPath(leftPathList, leftPrefabObj.transform)
    self:MergeNodeMap(leftNodeMap)

    local rightPrefabName = self:SelectPathPrefab(rightPathList[1], false, false)
    local rightPrefab = self:DynamicLoadAsset(Const.TravelBundleName, rightPrefabName)
    local rightPrefabObj = Helper.NewObject(rightPrefab, self._worldPathRoot)
    rightPrefabObj:SetActive(true)
    rightPrefabObj.name = PATH_NAME_RIGHT_CHILD
    rightPrefabObj.transform.position = lastPoint.position
    local rightNodeMap = self:ConstructNodesOfPath(rightPathList, rightPrefabObj.transform)
    self:MergeNodeMap(rightNodeMap)

    local seed = ConfigUtils.GetSpaceTravelNodeSeed(self._worldId, leftPathList[1])
    self:GenerateGroupBG({leftPrefabObj, rightPrefabObj}, seed)
end

function SpaceTravelCtrl:PutShipTo(nodeId)
    if ConfigUtils.IsValidItem(nodeId) then
        local nodeItem = self._nodeMap[nodeId]
        assert(nodeItem ~= nil, "can't find node item of: "..tostring(nodeId))
        self._ship.position = nodeItem.position
    else
        if self._worldEmptyMark ~= nil then
            self._ship.position = self._worldEmptyMark.position
        else
            self._ship.position = self._currentPath.position
        end 
    end

    local pos = self._worldCamera.transform.position
    pos.x = self._ship.position.x
    pos.y = self._ship.position.y
    self._worldCamera.transform.position = pos
end

function SpaceTravelCtrl:MoveStep(step, listener)
    self._totalTime = 0.75
    self._moveLeftStep = step
    self._movedNodeList = {}
    self._moveListener = listener
    self:OnCurrentNodeChanged()
end

function SpaceTravelCtrl:OnCurrentNodeChanged()
    -- notify move progress
    self._moveListener:OnMoveProgressChanged(self._moveLeftStep)

    if self._moveLeftStep == 0 then
        self._shipState = ShipState.Idle
        self._moveListener:OnNodeMoveFinished(self._movedNodeList)
        return
    end

    if not ConfigUtils.IsValidItem(self._worldNodeId) then
        self._shipState = ShipState.Moving
        self._targetNodeId = self._currentPathList[1]
        table.insert(self._movedNodeList, self._targetNodeId)
        self:OnMoveTargetChanged()
        return
    end

    local childList = ConfigUtils.GetSpaceTravelNodeChildList(self._worldId, self._worldNodeId)
    if #childList == 0 then
        self._shipState = ShipState.Idle
        self._moveListener:OnNodeMoveFinished(self._movedNodeList)
    elseif #childList == 1 then
        self._shipState = ShipState.Moving
        self._targetNodeId = childList[1]
        table.insert(self._movedNodeList, self._targetNodeId)
        self:OnMoveTargetChanged()
    else
        self._shipState = ShipState.WaitSelection
        local nodeItem = self._nodeMap[self._worldNodeId]
        local screenPos = self._worldCamera:WorldToScreenPoint(nodeItem.position)
        self._moveListener:ChooseLeftOrRightNode(screenPos)
    end
end

function SpaceTravelCtrl:OnBranchNodeChoosen(isLeft)
    -- remove the paths to be removed
    self:RemoveNodePathOfName(PATH_NAME_TO_CLEAN)
    -- current becomes to be removed
    self._currentPath.gameObject.name = PATH_NAME_TO_CLEAN
    -- sibling becomes to be removed
    local siblingPath = self._worldPathRoot:Find(PATH_NAME_SIBLING)
    if siblingPath ~= nil then
        siblingPath.gameObject.name = PATH_NAME_TO_CLEAN
    end

    local childList = ConfigUtils.GetSpaceTravelNodeChildList(self._worldId, self._worldNodeId)
    -- according to the selection
    if isLeft then
        self._targetNodeId = childList[1]
    else
        self._targetNodeId = childList[2]
    end
    -- the new path list
    self._currentPathList = ConfigUtils.GetSpaceTravelMapNodePath(self._worldId, self._targetNodeId)

    local leftChild = self._worldPathRoot:Find(PATH_NAME_LEFT_CHILD)
    local rightChild = self._worldPathRoot:Find(PATH_NAME_RIGHT_CHILD)
    if isLeft then
        leftChild.gameObject.name = PATH_NAME_CURRENT
        rightChild.gameObject.name = PATH_NAME_SIBLING
        self._currentPath = leftChild
    else
        leftChild.gameObject.name = PATH_NAME_SIBLING
        rightChild.gameObject.name = PATH_NAME_CURRENT
        self._currentPath = rightChild
    end

    self:ConstructChildPaths(self._targetNodeId)
    table.insert(self._movedNodeList, self._targetNodeId)
    self._shipState = ShipState.Moving
    self:OnMoveTargetChanged()
end

function SpaceTravelCtrl:RemoveNodePathOfName(name)
    local num = self._worldPathRoot.childCount
    for idx = num, 1, -1 do
        local pathItem = self._worldPathRoot:GetChild(idx - 1)
        if pathItem.gameObject.name == name then
            local points = pathItem:Find("Points")
            for idx = 1, points.childCount do
                local pointItem = points:GetChild(idx - 1).gameObject
                if pointItem.activeSelf then
                    local nodeId = pointItem.name
                    self._nodeMap[nodeId] = nil
                end
            end

            self:RemovePathObject(pathItem.gameObject)
        end
    end
end

function SpaceTravelCtrl:OnMoveTargetChanged()
    self._moveNodeItems = self:GetMoveNodePath()
    self._nextIndex = 1
    self:PeekNextMovePathNode()
end

function SpaceTravelCtrl:GetMoveNodePath()
    local ret = {}

    local startNode = nil
    if ConfigUtils.IsValidItem(self._worldNodeId) then
        local index = Helper.IndexOfArray(self._currentPathList, self._worldNodeId)
        if index ~= nil then
            startNode = self._nodeMap[self._worldNodeId]
        end
    end

    local nodeRoot = self._currentPath:Find("Points")
    local startNodeIndex = 0
    if startNode ~= nil then
        for idx = 1, nodeRoot.childCount do
            local nodeItem = nodeRoot:GetChild(idx - 1)
            if nodeItem == startNode then
                startNodeIndex = idx
                break
            end
        end
    end

    local endNode = self._nodeMap[self._targetNodeId]
    local endNodeIndex = 1
    for idx = 1, nodeRoot.childCount do
        local nodeItem = nodeRoot:GetChild(idx - 1)
        if nodeItem == endNode then
            endNodeIndex = idx
            break
        end
    end

    for idx = startNodeIndex + 1, endNodeIndex do
        local nodeItem = nodeRoot:GetChild(idx - 1)
        table.insert(ret, nodeItem)
    end

    return ret
end

function SpaceTravelCtrl:PeekNextMovePathNode()
    self._beginPosition = self._ship.position
    local curNodeItem = self._moveNodeItems[self._nextIndex]
    self._endPosition = curNodeItem.position
    self._moveTime = 0
    self:CheckShipScale()
end

function SpaceTravelCtrl:CheckShipScale()
    local diff = self._endPosition - self._beginPosition
    local curScale = self._ship.lossyScale
    -- 飞船默认朝左
    if curScale.x * diff.x > 0 then
        local scale = self._ship.localScale
        scale.x = scale.x * -1
        self._ship.localScale = scale
    end
end

-- update implementation
function SpaceTravelCtrl:UpdateImpl(deltaTime)
    if self._shipState == ShipState.Moving then
        self._moveTime = self._moveTime + deltaTime
        self._moveTime = math.min(self._moveTime, self._totalTime)
        local percent = self._moveTime / self._totalTime
        local pos = self._beginPosition * (1 - percent) + self._endPosition * percent
        self._ship.position = pos
        if self._moveTime >= self._totalTime then
            if self._nextIndex >= #self._moveNodeItems then
                self._worldNodeId = self._targetNodeId
                self._targetNodeId = nil
                self._moveLeftStep = self._moveLeftStep - 1
                self:OnCurrentNodeChanged()
            else
                self._nextIndex = self._nextIndex + 1
                self:PeekNextMovePathNode()
            end
        end
    end

    if self._shipState == ShipState.Moving then
        self:CameraFollow(deltaTime)
    end
end

function SpaceTravelCtrl:CameraFollow(deltaTime)
    local x = self._worldCamera.transform.position.x
    local y = self._worldCamera.transform.position.y

    local preX = x
    local preY = y

    local margin = 2
    local smoothing = 0.6

    local playerX = self._ship.position.x
    local playerY = self._ship.position.y

    if math.abs(x - playerX) > margin then
        x = Helper.Lerp(x, playerX, smoothing * deltaTime)
    end

    if math.abs(y - playerY) > margin then
        y = Helper.Lerp(y, playerY, smoothing * deltaTime)
    end

    local pos = self._worldCamera.transform.position
    pos.x = x
    pos.y = y
    self._worldCamera.transform.position = pos

    local bgPos = self._worldBGRoot.position
    bgPos.x = bgPos.x + (x - preX) * 0.2
    bgPos.y = bgPos.y + (y - preY) * 0.2
    self._worldBGRoot.position = bgPos
end

function SpaceTravelCtrl:OnMoveSpaceTravelCamera(diff)
    if self._shipState == ShipState.Moving then
        return
    end

    local leftLimit, rightLimit, bottomLimit, topLimit = self:GetWorldBound()

    local pos = self._worldCamera.transform.position
    pos.x = pos.x - diff.x
    pos.y = pos.y - diff.y
    pos.x = math.max(pos.x, leftLimit)
    pos.x = math.min(pos.x, rightLimit)
    pos.y = math.max(pos.y, bottomLimit)
    pos.y = math.min(pos.y, topLimit)

    self._worldCamera.transform.position = pos

    if self._shipState == ShipState.WaitSelection and self._moveListener ~= nil then
        local nodeItem = self._nodeMap[self._worldNodeId]
        local screenPos = self._worldCamera:WorldToScreenPoint(nodeItem.position)
        self._moveListener:SyncSelectionRootPosition(screenPos)
    end
end

-- handle the escapse button
function SpaceTravelCtrl:HandleEscape()
    -- no escapse
end

-- on clicked
function SpaceTravelCtrl:OnClicked(go)
	return true
end