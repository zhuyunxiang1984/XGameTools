require "FreakPlanet/View/GalleryItemListPanel"

local class = require "FreakPlanet/Utils/middleclass"
GalleryItemListCtrl  = class(CtrlNames.GalleryItemList, BaseCtrl)

-------------------------------------------------------------
local function CharacterSortFunc(idA, idB)
	if idA == nil or idB == nil then
		return false
	end

	local valueA = ConfigUtils.GetCharacterRarity(idA)
	local valueB = ConfigUtils.GetCharacterRarity(idB)

	if valueA == valueB then
		valueA = ConfigUtils.GetCharacterSortId(idA)
		valueB = ConfigUtils.GetCharacterSortId(idB)
	end

	return valueA > valueB
end

local function PetsSortFunc(idA, idB)
	if idA == nil or idB == nil then
		return false
	end

	local valueA = ConfigUtils.GetPetRarity(idA)
	local valueB = ConfigUtils.GetPetRarity(idB)
	if valueA ~= valueB then
		return valueA > valueB
	end

	valueA = ConfigUtils.GetPetSortId(idA)
	valueB = ConfigUtils.GetPetSortId(idB)

	return valueA > valueB
end

local function GoodsSortFunc(idA, idB)
	if idA == nil or idB == nil then
		return false
	end

	local valueA = ConfigUtils.GetGoodsRarity(idA)
	local valueB = ConfigUtils.GetGoodsRarity(idB)
	if valueA ~= valueB then
		return valueA > valueB
	end

	valueA = ConfigUtils.GetGoodsSortId(idA)
	valueB = ConfigUtils.GetGoodsSortId(idB)

	return valueA > valueB
end
-------------------------------------------------------------
-- load the ui prefab
function GalleryItemListCtrl:LoadPanel()
	self:CreatePanel("GalleryItemList")
end

-- construct ui panel data
function GalleryItemListCtrl:ConstructUI(obj)
	self._ui = GalleryItemListPanel.Init(obj)
end

-- destroy implementation
function GalleryItemListCtrl:DestroyImpl()
	GameNotifier.RemoveListener(GameEvent.MarkStateChanged, GalleryItemListCtrl.OnMarkStateChanged, self)
end

-- fill ui with the data
function GalleryItemListCtrl:SetupUI()
	self._itemList = {}
	self._itemPrefab = nil
	local galleryId = self._parameter.galleryId
	local itemType = self._parameter.itemType
	self._ui.ItemGridWrap.OnItemUpdate = GalleryItemListCtrl.OnItemUpdateGlobal

	local collectionPercent = 0
	local collectionUnlockNum = 0
	local collectionTotalNum = 0

	if itemType == ItemType.Character then
		self._itemPrefab = self:LoadAsset("CharacterItem")
		self._itemList = ConfigUtils.GetCharactersOfGallery(galleryId)
		table.sort( self._itemList, CharacterSortFunc)
		collectionPercent, collectionUnlockNum, collectionTotalNum = ConfigUtils.CalculateCharacterUnlock(galleryId)
	elseif itemType == ItemType.Pet then
		self._itemPrefab = self:LoadAsset("PetItem")
		self._itemList = ConfigUtils.GetPetsOfGallery(galleryId)
		table.sort( self._itemList, PetsSortFunc)
		collectionPercent, collectionUnlockNum, collectionTotalNum = ConfigUtils.CalculatePetsUnlock(galleryId)
	elseif itemType == ItemType.Goods then
		self._itemPrefab = self:LoadAsset("GoodsItem")
		self._itemList = ConfigUtils.GetGalleryGoodsOfGallery(galleryId)
		table.sort(self._itemList, GoodsSortFunc)
		collectionPercent, collectionUnlockNum, collectionTotalNum = ConfigUtils.CalculateGoodsUnlock(galleryId)
	else
		assert(false, "un-handled item type: "..tostring(itemType))
	end

	self:SetupItemGrid()
	self._ui.ItemCollection.text = SAFE_LOC("loc_CollectionProgress").." "..tostring(collectionUnlockNum).."/"..tostring(collectionTotalNum)

	CtrlManager.AddClick(self, self._ui.Blocker)
	GameNotifier.AddListener(GameEvent.MarkStateChanged, GalleryItemListCtrl.OnMarkStateChanged, self)
end

function GalleryItemListCtrl:SetupItemGrid()
	-- item count
	local itemCount = self._ui.ItemGridWrap.NeedCellCount
	itemCount = math.min(#self._itemList, itemCount)
	self._ui.ItemGridWrap.MaxRow = math.ceil(#self._itemList / self._ui.ItemGridWrap.ColumnLimit)

	local item = nil
	for idx = 1, itemCount do
		local itemId = self._itemList[idx]
		local itemObj = Helper.NewObject(self._itemPrefab, self._ui.ItemGrid)
		CtrlManager.AddClick(self, itemObj)
		item = itemObj.transform

		item.gameObject:SetActive(true)
		item.gameObject.name = tostring(itemId)

		-- construct item
		self:ConstructItem(item, itemId)
	end

	self._ui.ItemGridWrap:SortBasedOnScrollMovement()
	self._ui.ItemScrollView.restrictWithinPanel = true
end

function GalleryItemListCtrl:ConstructItem(item, itemId)
	local itemType = self._parameter.itemType
	if itemType == ItemType.Character then
		local unlocked = GameData.IsItemUnlocked(itemId)
		if unlocked then
			UIHelper.ConstructGalleryCharacterItem(self, item, itemId)
		else
			UIHelper.ConstructLockedCharacterItem(self, item, itemId, true)
		end
	elseif itemType == ItemType.Pet then
		UIHelper.ConstructPetItem(self, item, itemId)
		-- level
		local levelLabel = item:Find("Level"):GetComponent("UILabel")
		local unlocked = GameData.IsItemUnlocked(itemId)
		if unlocked then
			local petLevel = GameData.GetPetLevel(itemId)
			levelLabel.text = string.format(SAFE_LOC("loc_SimpleLevel"), petLevel)
		else
			levelLabel.text = "??"
		end
	elseif itemType == ItemType.Goods then
		local unlocked = GameData.IsItemUnlocked(itemId)
		if unlocked then
			UIHelper.ConstructGoodsItem(self, item, itemId)
		else
			UIHelper.ConstructLockedGoodsItem(self, item, itemId)
		end

		local numBG = item:Find("NumBG").gameObject
		numBG:SetActive(false)
	else
		assert(false, "un-handled item type: "..tostring(itemType))
	end

	-- marked
	local marked = GameData.IsItemMarked(itemId)
	local markedMark = item:Find("Mark/Marked").gameObject
	markedMark:SetActive(marked)
end

function GalleryItemListCtrl:OnItemUpdate(itemObj, itemIndex, itemRealIndex)
	itemRealIndex = itemRealIndex + 1
	if itemRealIndex <= 0 or itemRealIndex > #self._itemList then
		itemObj:SetActive(false)
	else
		itemObj:SetActive(true)
		local itemId = self._itemList[itemRealIndex]
		itemObj.name = tostring(itemId)
		-- construct item
		self:ConstructItem(itemObj.transform, itemId)
	end
end

function GalleryItemListCtrl.OnItemUpdateGlobal(itemObj, itemIndex, itemRealIndex)
	local ctrl = CtrlManager.GetCtrlByName(CtrlNames.GalleryItemList)
	if ctrl ~= nil then
		ctrl:OnItemUpdate(itemObj, itemIndex, itemRealIndex)
	end
end

function GalleryItemListCtrl:OnMarkStateChanged(itemId, marked)
	local item = self._ui.ItemGrid:Find(itemId)
	if item ~= nil then
		self:ConstructItem(item, itemId)
	end
end

function GalleryItemListCtrl:HandleSwitchItem(itemId, isNext)
	local totalCount = #self._itemList
    local index = Helper.IndexOfArray(self._itemList, itemId)
    if isNext then
        index = index + 1
        if index > totalCount then
            index = 1
        end
    else
        index = index - 1
        if index < 1 then
            index = totalCount
        end
    end

    return self._itemList[index]
end

-- on clicked
function GalleryItemListCtrl:OnClicked(go)
	if go == self._ui.Blocker then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
	elseif go.transform.parent == self._ui.ItemGrid then
		local itemId = tonumber(go.name)
		local itemType = ConfigUtils.GetItemTypeFromId(itemId)
		if ItemDetailCtrl.IsAccepted(itemType) then
			SoundSystem.PlayUIClickSound()
			CtrlManager.ShowItemDetail({itemId = itemId, callback = GalleryItemListCtrl.HandleSwitchItem, receiver = self})
		end
	end

	return true
end
