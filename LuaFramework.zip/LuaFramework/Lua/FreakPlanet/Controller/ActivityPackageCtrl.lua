require "FreakPlanet/View/ActivityPackagePanel"

local class = require "FreakPlanet/Utils/middleclass"
ActivityPackageCtrl  = class(CtrlNames.ActivityPackage, BaseCtrl)

-- load the ui prefab
function ActivityPackageCtrl:LoadPanel()
	self:CreatePanel("ActivityPackage")
end

-- destructor
function ActivityPackageCtrl:DestroyImpl()
    --GameNotifier.RemoveListener(GameEvent.ActivityPackageChanged, ActivityPackageCtrl.OnPackageChanged, self)
    GameNotifier.RemoveListener(GameEvent.IapStateChanged, ActivityPackageCtrl.OnIapStateChanged, self)
end

-- construct ui panel data
function ActivityPackageCtrl:ConstructUI(obj)
	self._ui = ActivityPackagePanel.Init(obj)
end

-- fill ui with the data
function ActivityPackageCtrl:SetupUI()
    IAPManager.RestoreStore(true)
    self._selectedPackageId = nil
    -- init activity packages
    self:InitPackages()

    -- buy button
    for k, v in pairs(self._ui.PackageItems) do
        CtrlManager.AddClick(self, v.button)
        CtrlManager.AddClick(self, v.collider)
    end
    CtrlManager.AddClick(self, self._ui.Blocker)
    --GameNotifier.AddListener(GameEvent.ActivityPackageChanged, ActivityPackageCtrl.OnPackageChanged, self)
    GameNotifier.AddListener(GameEvent.IapStateChanged, ActivityPackageCtrl.OnIapStateChanged, self)
end

function ActivityPackageCtrl:InitPackages()
    self._packageList = GameData.GetActiveActivityPackages()

    for idx = 1, #self._ui.PackageItems do
        local hasPackage = (idx <= #self._packageList)
        self._ui.PackageItems[idx].item:SetActive(hasPackage)
        if hasPackage then
            local packageId = self._packageList[idx]
            local packageInfo = GameData.GetActivityPackageInfo(packageId)
            -- name
            self._ui.PackageItems[idx].title.text = packageInfo.name
            -- desc
            self._ui.PackageItems[idx].desc.text = packageInfo.desc
            -- button desc
            self._ui.PackageItems[idx].buttonDesc.text = packageInfo.buttonDesc
            -- left time
            self._ui.PackageItems[idx].leftTime.text = ""
            -- completed or not
            local isCompleted = GameData.IsIapReallyCompleted(packageId) or not self:CanBuyPackage(packageId)
            self._ui.PackageItems[idx].completed:SetActive(isCompleted)
            self._ui.PackageItems[idx].button:SetActive(not isCompleted)
        end
    end
end

function ActivityPackageCtrl:CanBuyPackage(packageId)
    local packageInfo = GameData.GetActivityPackageInfo(packageId)
    local rewards = packageInfo.rewards

    if GameData.HasPackageAnyOneReward(rewards) then
        return false
    end
    return true
end

function ActivityPackageCtrl:CheckPackageRoomPiece(packageId)
    local packageInfo = GameData.GetActivityPackageInfo(packageId)
    local rewards = packageInfo.rewards

    for idx = 1, #rewards do
        local itemId = rewards[idx].id
        local itemType = ConfigUtils.GetItemTypeFromId(itemId)
        if itemType == ItemType.RoomPiece then
            local characterId = ConfigUtils.GetCharacterOfRoomPiece(itemId)
            local characterName = ConfigUtils.GetCharacterName(characterId)
            if not GameData.IsItemUnlocked(characterId) then
                local str = string.format(SAFE_LOC("家具购买提示\n当前礼包为%s家具礼包，请先获得该角色，然后再进行购买。"), characterName)
                return str
            end
        end
    end

    return nil
end

function ActivityPackageCtrl:UpdateImpl(deltaTime)
    local curTime = GameData.GetServerTime()
    for idx = 1, #self._ui.PackageItems do
        if idx <= #self._packageList then
            local packageId = self._packageList[idx]
            local packageInfo = GameData.GetActivityPackageInfo(packageId)
            local leftTime = math.max(0, packageInfo.endTime - curTime)
            if leftTime == 0 then
                self._ui.PackageItems[idx].leftTime.text = SAFE_LOC("礼包已结束")
            else
                self._ui.PackageItems[idx].leftTime.text = Helper.GetLongTimeString(leftTime)
            end
        end
    end
end

function ActivityPackageCtrl:OnPaymentSelected(payment)
    IAPManager.Buy(self._selectedPackageId, payment)
end

function ActivityPackageCtrl:RefreshPurchasingHint()
    local isPurchasing = IAPManager.HasProcessingOrder()
    self._ui.PurchasingHint:SetActive(isPurchasing)
end

function ActivityPackageCtrl:OnPackageChanged()
    self:InitPackages()
end

function ActivityPackageCtrl:OnIapStateChanged()
    self:RefreshPurchasingHint()
end

function ActivityPackageCtrl:OnProceedApplePay()
    self:OnPaymentSelected(PaymentType.Apple)
end

function ActivityPackageCtrl:GetPackageIndex(packageItem)
    for idx = 1, #self._ui.PackageItems do
        if self._ui.PackageItems[idx].item == packageItem then
            return idx
        end
    end

    return nil
end

function ActivityPackageCtrl:GetFirstItemToShowDetail(packageId)
    local packageInfo = GameData.GetActivityPackageInfo(packageId)
    local rewards = packageInfo.rewards
    for idx = 1, #rewards do
        local itemId = rewards[idx].id
        local itemType = ConfigUtils.GetItemTypeFromId(itemId)
        if itemType == ItemType.Character then
            return itemId
        end
    end

    return nil
end

-- on clicked
function ActivityPackageCtrl:OnClicked(go)

    if go == self._ui.Blocker then
        SoundSystem.PlayUICancelSound()
        CtrlManager.PopPanel()
    elseif go.name == "Collider" then
        local packageIdx = self:GetPackageIndex(go.transform.parent.gameObject)
        if packageIdx ~= nil then
            local packageId = self._packageList[packageIdx]
            local itemId = self:GetFirstItemToShowDetail(packageId)
            if itemId ~= nil then
                SoundSystem.PlayUIClickSound()
                CtrlManager.ShowItemDetail({itemId = itemId, preview = true})
            end
        end
    elseif go.name == "ButtonConfirm" then
        local packageIdx = self:GetPackageIndex(go.transform.parent.gameObject)
        if packageIdx ~= nil then
            local packageId = self._packageList[packageIdx]
            local packageInfo = GameData.GetActivityPackageInfo(packageId)
            -- purchased or not
            local completed = GameData.IsIapReallyCompleted(packageId)
            if completed then
                SoundSystem.PlayWarningSound()
                CtrlManager.ShowAlert(SAFE_LOC("礼包已购买"))
                return true
            end
            -- check time
            local curTime = GameData.GetServerTime()
            if curTime >= packageInfo.endTime then
                SoundSystem.PlayWarningSound()
                CtrlManager.ShowAlert(SAFE_LOC("礼包已结束"))
                return true
            end
            -- has iap processing
            local canBuy = IAPManager.CanBuy()
            if not canBuy then
                SoundSystem.PlayWarningSound()
                IAPManager.ShowIapResult(PaymentResult.IapInProcessing)
                return true
            end
            -- real name related
            local price = packageInfo.price
            local isOK = GameData.CheckRealNameOfIap(price)
            if not isOK then
                SoundSystem.PlayWarningSound()
                return true
            end
            -- room piece
            local alertMessage = self:CheckPackageRoomPiece(packageId)
            if alertMessage ~= nil then
                SoundSystem.PlayWarningSound()
                CtrlManager.ShowAlert(alertMessage)
                return true
            end
            -- real buy
            self._selectedPackageId = packageId
            if Global.ChannelId == GameChannels.APPSTORE then
                local existOrderId = GameData.GetIapFirstOrder(packageId)
                if existOrderId == nil then
                    SoundSystem.PlayUIClickSound()
                    self:OnProceedApplePay()
                else
                    CtrlManager.ShowMessageBox({
                        message = SAFE_LOC("该商品有未完成订单，请稍后重新登录尝试获取收据凭证。继续购买可能会导致未完成订单丢失\n继续购买？"),
                        single = false, 
                        onConfirm = ActivityPackageCtrl.OnProceedApplePay, 
                        receiver = self,
                    })
                end
            elseif Global.ChannelId == GameChannels.ANDROID_OPPO then
                SoundSystem.PlayUIClickSound()
                self:OnPaymentSelected(PaymentType.Oppo)
            elseif Global.ChannelId == GameChannels.ANDROID_VIVO then
                SoundSystem.PlayUIClickSound()
                self:OnPaymentSelected(PaymentType.Vivo)
            elseif Global.ChannelId == GameChannels.ANDROID_HUAWEI then
                SoundSystem.PlayUIClickSound()
                self:OnPaymentSelected(PaymentType.Huawei)
            elseif Global.ChannelId == GameChannels.ANDROID_UC then
                SoundSystem.PlayUIClickSound()
                self:OnPaymentSelected(PaymentType.Uc)
            elseif Global.ChannelId == GameChannels.ANDROID_MI then
                SoundSystem.PlayUIClickSound()
                self:OnPaymentSelected(PaymentType.Mi)
            elseif Global.ChannelId == GameChannels.ANDROID_BILIBILI then
                SoundSystem.PlayUIClickSound()
                self:OnPaymentSelected(PaymentType.Bilibili)
            elseif Global.ChannelId == GameChannels.ANDROID_TENCENT then
                SoundSystem.PlayUIClickSound()
                self:OnPaymentSelected(PaymentType.Tencent)
            elseif Global.ChannelId == GameChannels.ANDROID_MOMOYU then
                SoundSystem.PlayUIClickSound()
                self:OnPaymentSelected(PaymentType.MoMoYu)
            else
                SoundSystem.PlayUIClickSound()
                CtrlManager.OpenPanel(CtrlNames.IAPPaymentSelect, {callback = ActivityPackageCtrl.OnPaymentSelected, receiver = self})
            end
        end
    end

	return true
end
