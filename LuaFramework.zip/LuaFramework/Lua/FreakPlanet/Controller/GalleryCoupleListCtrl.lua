require "FreakPlanet/View/GalleryCoupleListPanel"

local class = require "FreakPlanet/Utils/middleclass"
GalleryCoupleListCtrl  = class(CtrlNames.GalleryCoupleList, BaseCtrl)

-------------------------------------------------------------
local function CoupleSortFunc(idA, idB)
    if idA == nil or idB == nil then
        return false
    end

    local valueA = ConfigUtils.GetCoupleSortId(idA)
    local valueB = ConfigUtils.GetCoupleSortId(idB)

    return valueA < valueB
end
-------------------------------------------------------------

-- load the ui prefab
function GalleryCoupleListCtrl:LoadPanel()
	self:CreatePanel("GalleryCoupleList")
end

-- construct ui panel data
function GalleryCoupleListCtrl:ConstructUI(obj)
	self._ui = GalleryCoupleListPanel.Init(obj)
end

-- fill ui with the data
function GalleryCoupleListCtrl:SetupUI()
    self._ui.CoupleGridWrap.OnItemUpdate = GalleryCoupleListCtrl.OnItemUpdateGlobal
    self._ui.DetailPanel:SetActive(false)
    self:DynamicLoadBundle(Const.CoupeAvatarBundleName)

    self._galleryId = self._parameter.galleryId
    local _, coupleUnlockNum, coupleTotalNum = ConfigUtils.CalculateCoupleUnlock(self._galleryId)
    self._ui.CoupleCollection.text = SAFE_LOC("loc_CollectionProgress").." "..tostring(coupleUnlockNum).."/"..tostring(coupleTotalNum)

    self:SetupCoupleGrid()

    for k, v in pairs(self._ui.DetailConditionItems) do
        CtrlManager.AddClick(self, v.item)
    end

    CtrlManager.AddClick(self, self._ui.Blocker)
    CtrlManager.AddClick(self, self._ui.DetailBlocker)
end

function GalleryCoupleListCtrl:SetupCoupleGrid()
    self._coupleList = ConfigUtils.GetCouplesOfGallery(self._galleryId)
    table.sort(self._coupleList, CoupleSortFunc)

    -- item count
    local itemCount = self._ui.CoupleGridWrap.NeedCellCount
    itemCount = math.min(#self._coupleList, itemCount)
    self._ui.CoupleGridWrap.MaxRow = math.ceil(#self._coupleList / self._ui.CoupleGridWrap.ColumnLimit)

    local item = nil
    for idx = 1, itemCount do
        local itemId = self._coupleList[idx]
        local itemObj = Helper.NewObject(self._ui.CoupleItemTemplate, self._ui.CoupleGrid)
        CtrlManager.AddClick(self, itemObj)
        item = itemObj.transform

        item.gameObject:SetActive(true)
        item.gameObject.name = tostring(itemId)

        -- construct item
        self:ConstructCoupleItem(item, itemId)
    end

    self._ui.CoupleGridWrap:SortBasedOnScrollMovement()
    self._ui.CoupleScrollView.restrictWithinPanel = true
end

function GalleryCoupleListCtrl:ConstructCoupleItem(item, itemId)
    local nameLabel = item:Find("Name"):GetComponent("UILabel")
    nameLabel.text = ConfigUtils.GetCoupleName(itemId)

    local descLabel = item:Find("SkillDesc"):GetComponent("UILabel")
    descLabel.text = ConfigUtils.GetCoupleSkillDesc(itemId)

    local conditionList = ConfigUtils.GetCoupleConditions(itemId)
    local conditionUnlocked = true
    local conditionRoot = item:Find("Conditions")
    for idx = 1, conditionRoot.childCount do
        local hasCondition = (idx <= #conditionList)
        local conditionItem = conditionRoot:GetChild(idx - 1)
        conditionItem.gameObject:SetActive(hasCondition)
        if hasCondition then
            -- construct condition
            local oneMatched = self:ConstructCoupleConditionItem(conditionItem, conditionList[idx])
            if not oneMatched then
                conditionUnlocked = false
            end
            -- place position
            UIHelper.PlaceHorizontalItemPosition(conditionItem, idx, #conditionList, 60)
        end
    end
    local nodeRoot = item:Find("Nodes")
    local coupleNodes = ConfigUtils.GetCoupleNodes(itemId)
    local nodeNum = 0
    for k, v in pairs(coupleNodes) do
        local nodeItem = nodeRoot:GetChild(nodeNum)
        nodeItem.gameObject:SetActive(true)
        local nodeLabel = nodeItem:Find("Label"):GetComponent("UILabel")
        nodeLabel.text = UIHelper.GetCoupleShowTextOfType(k)
        nodeNum = nodeNum + 1
    end
    for idx = nodeNum + 1, nodeRoot.childCount do
        local nodeItem = nodeRoot:GetChild(idx - 1)
        nodeItem.gameObject:SetActive(false)
    end
    -- unlock or not
    local unlockMark = item:Find("Unlock").gameObject
    unlockMark:SetActive(conditionUnlocked)
end

function GalleryCoupleListCtrl:ConstructCoupleConditionItem(conditionItem, data)
    local characterId = data.Id
    local skinId = data.SkinId
    local stage = data.Stage
    local level = data.Level

    local showSkinId = ConfigUtils.GetDefaultSkinOfCharacter(characterId, 1)
    if ConfigUtils.IsValidItem(skinId) then
        showSkinId = skinId
    end

    local matched, failReason = ConfigUtils.IsCoupleConditionMatched(data)

    local icon = conditionItem:Find("Icon"):GetComponent("UISprite")
    UIHelper.SetCharacterIconWithSkin(self, icon, showSkinId)

    local lockMark = conditionItem:Find("Lock").gameObject
    lockMark:SetActive(not matched)
    if not matched then
        local reasonLabel = conditionItem:Find("Lock/Label"):GetComponent("UILabel")
        if failReason == CoupleFailReason.StageLocked then
            reasonLabel.text = string.format(SAFE_LOC("loc_SimpleStage"), stage)
        elseif failReason == CoupleFailReason.LevelLocked then
            reasonLabel.text = string.format(SAFE_LOC("loc_SimpleLevel"), level)
        else
            reasonLabel.text = ""
        end
    end
    
    return matched
end

function GalleryCoupleListCtrl:ShowCoupleDetail(coupleId)
    self._detailCoupleId = coupleId
    self._ui.DetailName.text = ConfigUtils.GetCoupleName(coupleId)
    self._ui.DetailDesc.text = ConfigUtils.GetCoupleDesc(coupleId)

    -- recycle avatar
    for idx = self._ui.DetailAvatarRoot.childCount, 1, -1 do
        local item = self._ui.DetailAvatarRoot:GetChild(idx - 1)
        item.parent = self._ui.DetailAvatarPool
    end

    local prefabName, prefabBundle = ConfigUtils.GetCouplePrefabName(coupleId)
    local prefabItem = self._ui.DetailAvatarPool:Find(prefabName)
    if prefabItem == nil then
        local avatarPrefab = self:DynamicLoadAsset(prefabBundle, prefabName)
        local prefabObj = Helper.NewObject(avatarPrefab, self._ui.DetailAvatarRoot)
        prefabObj:SetActive(true)
        prefabObj.name = prefabName
        prefabItem = prefabObj.transform
    else
        prefabItem.parent = self._ui.DetailAvatarRoot
        prefabItem.localPosition = Vector3.zero
        prefabItem.localScale = Vector3.one
    end

    local conditionList = ConfigUtils.GetCoupleConditions(coupleId)
    for idx = 1, #self._ui.DetailConditionItems do
        local hasCondition = (idx <= #conditionList)
        local conditionItem = self._ui.DetailConditionItems[idx].item.transform
        conditionItem.gameObject:SetActive(hasCondition)
        if hasCondition then
            -- construct condition
            self:ConstructCoupleDetailConditionItem(conditionItem, conditionList[idx])
            -- place position
            UIHelper.PlaceHorizontalItemPosition(conditionItem, idx, #conditionList, 60)
        end
    end

    self._ui.DetailPanel:SetActive(true)
    local tweenScale = self._ui.DetailPanel:GetComponent("TweenScale")
    tweenScale:ResetToBeginning()
    tweenScale:PlayForward()
end

function GalleryCoupleListCtrl:ConstructCoupleDetailConditionItem(conditionItem, data)
    local characterId = data.Id
    local skinId = data.SkinId
    local stage = data.Stage
    local level = data.Level

    local showSkinId = ConfigUtils.GetDefaultSkinOfCharacter(characterId, 1)
    if ConfigUtils.IsValidItem(skinId) then
        showSkinId = skinId
    end

    local icon = conditionItem:Find("Icon"):GetComponent("UISprite")
    UIHelper.SetCharacterIconWithSkin(self, icon, showSkinId)

    local label = conditionItem:Find("Label"):GetComponent("UILabel")
    if stage ~= nil then
        label.text = string.format(SAFE_LOC("loc_SimpleStage"), stage)
    elseif level ~= nil then
        label.text = string.format(SAFE_LOC("loc_SimpleLevel"), level)
    else
        label.text = ""
    end
end

function GalleryCoupleListCtrl:OnItemUpdate(itemObj, itemIndex, itemRealIndex)
    itemRealIndex = itemRealIndex + 1
    if itemRealIndex <= 0 or itemRealIndex > #self._coupleList then
        itemObj:SetActive(false)
    else
        itemObj:SetActive(true)
        local itemId = self._coupleList[itemRealIndex]
        itemObj.name = tostring(itemId)
        -- construct item
        self:ConstructCoupleItem(itemObj.transform, itemId)
    end
end

function GalleryCoupleListCtrl.OnItemUpdateGlobal(itemObj, itemIndex, itemRealIndex)
    local ctrl = CtrlManager.GetCtrlByName(CtrlNames.GalleryCoupleList)
    if ctrl ~= nil then
        ctrl:OnItemUpdate(itemObj, itemIndex, itemRealIndex)
    end
end

-- on clicked
function GalleryCoupleListCtrl:OnClicked(go)

    if go == self._ui.Blocker then
        SoundSystem.PlayUICancelSound()
        CtrlManager.PopPanel()
    elseif go == self._ui.DetailBlocker then
        SoundSystem.PlayUICancelSound()
        self._ui.DetailPanel:SetActive(false)
    elseif go.transform.parent == self._ui.CoupleGrid then
        SoundSystem.PlayUIClickSound()
        local coupleId = tonumber(go.name)
        self:ShowCoupleDetail(coupleId)
    elseif go.transform.parent == self._ui.DetailConditionRoot then
        SoundSystem.PlayUIClickSound()
        local names = Helper.StringSplit(go.name)
        assert(#names == 2, "invalid detail condition item name: "..tostring(go.name))
        local conditionList = ConfigUtils.GetCoupleConditions(self._detailCoupleId)
        local idx = tonumber(names[2])
        local data = conditionList[idx]
        local characterId = data.Id
        CtrlManager.ShowItemDetail({itemId = characterId})
    end

	return true
end

-- handle the escapse button
function GalleryCoupleListCtrl:HandleEscape()
    if self._ui.DetailPanel.activeSelf then
        self:OnClicked(self._ui.DetailBlocker)
    else
        self:OnClicked(self._ui.Blocker)
    end
end