require "FreakPlanet/View/FurnitureShopPanel"

local class = require "FreakPlanet/Utils/middleclass"
FurnitureShopCtrl  = class(CtrlNames.FurnitureShop, BaseCtrl)
local ADS_INTERVAL = 5
local ADS_ITEM_WIDTH = 600

local adsTime = 0

local EnumMenuType = {
	Purchase = 1,    -- 家具购买
	Lottery = 2,	 -- 抽奖
	Auction = 3,	 -- 家具拍卖
}

local EnumGashaponBuyType = {
	GashaponBuySingle = 1,
	GashaponBuyAll = 2,

}
-- load the ui prefab
function FurnitureShopCtrl:LoadPanel()
	self:CreatePanel("FurnitureShop")
end

-- construct ui panel data
function FurnitureShopCtrl:ConstructUI(obj)
	self._ui = FurnitureShopPanel.Init(obj)
end

-- fill ui with the data
function FurnitureShopCtrl:SetupUI()
	local ui = self._ui
	self._TodayTime = nil

	self._SelectModule = EnumMenuType.Purchase

	CtrlManager.AddClick(self, ui.Blocker)
	CtrlManager.AddClick(self, ui.pBtnPurchase)
	CtrlManager.AddClick(self, ui.pBtnReturn)
	CtrlManager.AddClick(self, ui.pBtnLottery)
	CtrlManager.AddClick(self, ui.pBtnVip)
	--CtrlManager.AddClick(self, ui.pBtnAuction)

	CtrlManager.AddClick(self, ui.pTranLotteryAll.gameObject)
	CtrlManager.AddClick(self, ui.pTranLotteryOnce.gameObject)
	CtrlManager.AddClick(self, ui.pObjRewardPanelBlocker)

	CtrlManager.AddClick(self, ui.pObjHelpBlocker)
	CtrlManager.AddClick(self, ui.pBtnGotoMonthCard)

	GameNotifier.AddListener(GameEvent.MonthCard2Changed, FurnitureShopCtrl.OnMonthCardChanged, self)
	GameNotifier.AddListener(GameEvent.ItemNumChanged, FurnitureShopCtrl.OnItemNumChanged, self)

	self:EnableSecondUpdate()
	self:GetTodayTime()

	self._HomeShopList = {}
	self._HomeShopGashaponList = {}
	self._SelectGashaponId = nil
	self._HomeShopGashaponEndTime = nil

	self._FurnitureSellAdsUrl = nil
	self._CurAdsIndex = 1
	self._AdsSelfIncreasing = true

	self:UpdateBottomAdsUI()
	self:UpdateMenuUI()
	self:ConstructFurnitureShopUI()
	self:UpdateCurrencyUI()

end

function FurnitureShopCtrl:DestroyImpl()
	GameNotifier.RemoveListener(GameEvent.MonthCard2Changed, FurnitureShopCtrl.OnMonthCardChanged, self)
	GameNotifier.RemoveListener(GameEvent.ItemNumChanged, FurnitureShopCtrl.OnItemNumChanged, self)
end

-- on clicked
function FurnitureShopCtrl:OnClicked(go)
	local ui = self._ui
    if go == ui.Blocker or go == ui.pBtnReturn then
        SoundSystem.PlayUIClickSound()
        CtrlManager.PopPanel()
    elseif go == ui.pBtnPurchase then
		if self._SelectModule ~= EnumMenuType.Purchase then
			self._SelectModule = EnumMenuType.Purchase
			self:UpdateMenuUI()
			self:ConstructFurnitureShopUI()
			self:UpdateCurrencyUI()
		end
	elseif go == ui.pBtnLottery then
		if self._SelectModule ~= EnumMenuType.Lottery then
			self._SelectModule = EnumMenuType.Lottery
			self:UpdateMenuUI()
			self:ConstructLotteryFurnitureUI()
			self:UpdateCurrencyUI()
		end
	elseif go == ui.pBtnAuction then
		if self._SelectModule ~= EnumMenuType.Auction then
			self._SelectModule = EnumMenuType.Auction
			self:UpdateMenuUI()
		end
	elseif go.transform.parent.parent == ui.pUIGridPurchaseContent.transform then
        local iIdx = tonumber(go.transform.parent.name)
		local furnitureId = self._HomeShopList[iIdx].FurnitureId
        local type = ConfigUtils.GetItemTypeFromId(furnitureId)
        if type == ItemType.HomeFurniture then
            -- 家具购买
            local furnitureInfo = self._HomeShopList[iIdx]
            if furnitureInfo then
				local furnitureConfig = ConfigUtils.GetHomeFurnitureConfig(furnitureId)
				local isEnough, lackList = self:IsEnoughMoney(furnitureConfig.CostList)
				if isEnough then
					self:PurchaseFurniture(furnitureInfo, iIdx)
				else

					CtrlManager.ShowMessageBox({message = "材料不足!", single = true})
				end
            end
        end
    elseif go == ui.pTranLotteryOnce.gameObject then
		if ConfigUtils.IsValidItem(self._SelectGashaponId) then
			local curTime = GameData.GetServerTime()
			local leftTime = self._HomeShopGashaponEndTime - curTime
			if leftTime > 0 then
				local costList = ConfigUtils.GetHomeFurnitureGashaponCost(self._SelectGashaponId)
				local costInfo = costList[1]
				local iCurCostCount = GameData.GetItemNum(costInfo.Id)
				local iNeedCostCount = costInfo.Num
				if iCurCostCount < iNeedCostCount then
					SoundSystem.PlayWarningSound()
					return true
				end
				if self:GetLeftLotteryCount() > 0 then
					NetManager.Send("HomeShopGashaponBuy",{DrawType = EnumGashaponBuyType.GashaponBuySingle, GashaponId = self._SelectGashaponId}, FurnitureShopCtrl.OnHandleProto, self)
				else
					CtrlManager.ShowMessageBox({message = "您已清空奖池!", single = true})
				end

			else
				CtrlManager.ShowMessageBox({message = "当前奖池已过期", single = true})
			end
		end
    elseif go == ui.pTranLotteryAll.gameObject then
		if ConfigUtils.IsValidItem(self._SelectGashaponId) then
			local curTime = GameData.GetServerTime()
			local leftTime = self._HomeShopGashaponEndTime - curTime
			if leftTime > 0 then
				local costList = ConfigUtils.GetHomeFurnitureGashaponCost(self._SelectGashaponId)
				local costInfo = costList[1]
				local iCurCostCount = GameData.GetItemNum(costInfo.Id)
				local iNeedCostCount = costInfo.Num * self:GetLeftLotteryCount()
				if iCurCostCount < iNeedCostCount then
					SoundSystem.PlayWarningSound()
					return true
				end
				if self:GetLeftLotteryCount() > 0 then
					NetManager.Send("HomeShopGashaponBuy",{DrawType = EnumGashaponBuyType.GashaponBuyAll, GashaponId = self._SelectGashaponId}, FurnitureShopCtrl.OnHandleProto, self)
				else
					CtrlManager.ShowMessageBox({message = "您已清空奖池!", single = true})
				end
			else
				CtrlManager.ShowMessageBox({message = "当前奖池已过期", single = true})
			end
		end
	elseif go == ui.pObjRewardPanelBlocker then
		ui.pObjRewardPanel:SetActive(false)
	elseif go == ui.pObjHelpBlocker then
		ui.pObjMonthCardHelpPanel:SetActive(false)
	elseif go == ui.pBtnVip then
		ui.pObjMonthCardHelpPanel:SetActive(true)
		self:UpdateMonthCardUI()
	elseif go == ui.pBtnGotoMonthCard then
		ui.pObjMonthCardHelpPanel:SetActive(false)
		CtrlManager.OpenPanel(CtrlNames.Mall, {MallModule = EMallModuleNames.MonthCardGift})
	elseif go.transform.parent == ui.pUIGridAdsRoot.transform then
		if self._FurnitureSellAdsUrl then
			UnityEngine.Application.OpenURL(self._FurnitureSellAdsUrl)
		end
    end
	return true
end

--- 家具购买
function FurnitureShopCtrl:PurchaseFurniture(furnitureInfo, Idx)
	if furnitureInfo.StockNum > 0 then
		NetManager.Send("HomeShopBuy",{FurnitureId = furnitureInfo.FurnitureId, Index = Idx - 1}, FurnitureShopCtrl.OnHandleProto, self)
	else
		SoundSystem.PlayWarningSound()
		CtrlManager.ShowAlert(SAFE_LOC("库存不足!"))
		return true
	end
end

--- 家具购买UI刷新
function FurnitureShopCtrl:ConstructFurnitureShopUI()
	self._ui.pScrollViewPurchase.gameObject:SetActive(true)
	self._ui.pScrollViewAds.gameObject:SetActive(true)
	self._ui.LotteryPanel:SetActive(false)
	self:UpdateBannerUI()
	self:ConstructAdsUI()
	NetManager.Send("HomeShopList",{}, FurnitureShopCtrl.OnHandleProto, self)
end

function FurnitureShopCtrl:UpdateFurnitureShopUI()
	self._ui.pObjEmpty:SetActive(#self._HomeShopList == 0)
	local iPurchaseCount = self._ui.pUIGridPurchaseContent.transform.childCount

	for idx = iPurchaseCount, 1, -1 do
		local pObj = self._ui.pUIGridPurchaseContent.transform:GetChild(idx - 1).gameObject
		self._ui.ObjPool:RecycleObj(pObj)
	end

	for idx = 1, #self._HomeShopList do
		local pObj = self._ui.ObjPool:GetOrCreateObj(self._ui.EnumPrefabType.FurnitureItem, function(pObj)
			local pBtnBuy = pObj.transform:Find("btn").gameObject
			CtrlManager.AddClick(self, pBtnBuy)
		end)
		pObj.transform:SetParent(self._ui.pUIGridPurchaseContent.transform)
		pObj:SetActive(true)
		pObj.transform.localScale = Vector3.one
		local furnitureInfo = self._HomeShopList[idx]
		pObj.name = tostring(idx)

		self:ConstructSellFurnitureInfo(pObj, furnitureInfo)
	end

	self._ui.pUIGridPurchaseContent:Reposition()
	self._ui.pScrollViewPurchase:ResetPosition()
	
	self:UpdateImplBySecond()
end

function FurnitureShopCtrl:ConstructSellFurnitureInfo(item, furnitureInfo)
	local pSpriteFurnitureIcon = item.transform:Find("furBg/icon"):GetComponent("UISprite")
	local pTxtFurnitureName = item.transform:Find("furName/name"):GetComponent("UILabel")
	local pTxtDeliverTime = item.transform:Find("time/time"):GetComponent("UILabel")
	local pTxtLeftNum = item.transform:Find("leftnum"):GetComponent("UILabel")
	local pObjEmpty = item.transform:Find("empty").gameObject
	local pBtnBuy = item.transform:Find("btn").gameObject

	local pUIGridPrice = item.transform:Find("priceroot/pricegrid"):GetComponent("UIGrid")

	local strIconName, strAtlasName = ConfigUtils.GetHomeFurnitureIcon(furnitureInfo.FurnitureId)
	local furnitureConfig = ConfigUtils.GetHomeFurnitureConfig(furnitureInfo.FurnitureId)
	self:SetIconWithAtlas(pSpriteFurnitureIcon, strIconName, strAtlasName)
	pTxtFurnitureName.text = furnitureConfig.Name

	pTxtLeftNum.text = "库存" .. furnitureInfo.StockNum .. "件"

	pObjEmpty:SetActive(furnitureInfo.StockNum <= 0)
	pBtnBuy:SetActive(furnitureInfo.StockNum > 0)

	if furnitureInfo.StockNum > 0 then
		local bIsValidOfMonthCard = GameData.IsValidPeriodOfMonthCard2()
		local iDeliverTime = furnitureConfig.DeliveryTime
		if bIsValidOfMonthCard then
			iDeliverTime = Helper.RoundAndCeil(iDeliverTime * HomeFurnitureSell.DeliveryTimeRate / 100)
		end
		pTxtDeliverTime.gameObject:SetActive(true)
		pTxtDeliverTime.text = "预计送达时间: " .. Helper.GetShortTimeString(iDeliverTime)
	else
		pTxtDeliverTime.text = ""
	end

	local iPriceItemCount = pUIGridPrice.transform.childCount
	for idx = iPriceItemCount, 1, -1 do
		local pObj = pUIGridPrice.transform:GetChild(idx - 1).gameObject
		self._ui.ObjPool:RecycleObj(pObj)
	end

	local costList = furnitureConfig.CostList
	for idx = 1, #costList do
		local pObjPrice = self._ui.ObjPool:GetOrCreateObj(self._ui.EnumPrefabType.PriceItem)
		pObjPrice.transform:SetParent(pUIGridPrice.transform)
		pObjPrice:SetActive(true)
		pObjPrice.name = tostring(costList[idx].Id)
		pObjPrice.transform.localScale = Vector3.one
		UIHelper.ConstructItemIconAndNum(self, pObjPrice.transform, costList[idx].Id, costList[idx].Num)
	end
	pUIGridPrice:Reposition()
end

function FurnitureShopCtrl:OnHandleProto(proto, data, requestData)
	if proto == "HomeShopList" then
		self._HomeShopList = data.List
		self:UpdateFurnitureShopUI()
	elseif proto == "HomeShopBuy" then
		self._HomeShopList = data.List
		GameData.InitFurnitureDeliveryData(data.DeliverList)
		self:UpdateFurnitureShopUI()
		self._ui.pObjRewardPanel:SetActive(true)

		local furnitureId = requestData.FurnitureId
		local useGoalData = {}
		local furnitureInfo = ConfigUtils.GetHomeFurnitureConfig(furnitureId)
		local furnitureConfig = ConfigUtils.GetHomeFurnitureConfig(furnitureId)
		local costList = furnitureConfig.CostList
		for idx = 1, #costList do
			local itemId = costList[idx].Id
			local num = costList[idx].Num
			GameData.ConsumeItem(itemId, num)
			local itemType = ConfigUtils.GetItemTypeFromId(itemId)
			if itemType == ItemType.Goods then
				local data = GameData.SetupItemGoalData(itemId, num)
				table.insert(useGoalData, data)
				GameDataHome.SetFurnitureBuyCostHistoryData(itemId, num)
			end

		end
		GameData.DoGoalSettle(TriggerType.HomeFurnitureSellCost, {useGoalData})
		GameData.CheckAndHintGoalsOfCurrentCountType()
		local bIsValidOfMonthCard = GameData.IsValidPeriodOfMonthCard2()
		local iDeliverTime = furnitureInfo.DeliveryTime
		if bIsValidOfMonthCard then
			iDeliverTime = Helper.RoundAndCeil(iDeliverTime * HomeFurnitureSell.DeliveryTimeRate / 100)
		end
		self._ui.pTxtRewardPanelDeliveryTime.text = Helper.GetShortTimeString(iDeliverTime)

		local goldNum = data.RemainGold
		local diamondNum = data.RemainDiamond
		GameData.SetMoney(ItemType.Gold, goldNum)
		GameData.SetMoney(ItemType.Diamond, diamondNum)

	elseif proto == "HomeShopGashaponList" then
		self._HomeShopGashaponList = data.List
		self._SelectGashaponId = data.GashaponId
		self._HomeShopGashaponEndTime = data.EndTime
		self:UpdateLotteryFurnitureUI()
	elseif proto == "HomeShopGashaponBuy" then
		local list = data.List
		self:UpdateHomeShopGashaponList(list)
		self:ConstructLotteryFurnitureUI()

		local rewardList = data.List
		for idx = 1, #rewardList do
			local Id = rewardList[idx].Id
			local Num = rewardList[idx].Num
			GameData.CollectItem(Id, Num, true)
		end

		local useGoalData = {}
		local selectGashaponId = requestData.GashaponId
		local costList = ConfigUtils.GetHomeFurnitureGashaponCost(selectGashaponId)
		for idx = 1, #costList do
			local itemId = costList[idx].Id
			local num = costList[idx].Num
			GameData.ConsumeItem(itemId, num)
			local itemType = ConfigUtils.GetItemTypeFromId(itemId)
			if itemType == ItemType.HomeFurnitureGashapon then
				local data = GameData.SetupItemGoalData(itemId, num)
				table.insert(useGoalData, data)
				GameDataHome.SetFurnitureGashaponBuyHistoryData(itemId, num)
			end
		end
		GameData.DoGoalSettle(TriggerType.HomeFurnitureGashapon, {useGoalData})
		local goldNum = data.RemainGold
		local diamondNum = data.RemainDiamond
		GameData.SetMoney(ItemType.Gold, goldNum)
		GameData.SetMoney(ItemType.Diamond, diamondNum)
		GameData.CheckAndHintGoalsOfCurrentCountType()
	end
end

function FurnitureShopCtrl:UpdateImplBySecond(deltaTime)
	local curTime = GameData.GetServerTime()
	if self._SelectModule == EnumMenuType.Purchase and self._TodayTime then
		local leftTime = self._TodayTime - curTime + 1
		if leftTime > 0 then
			self._ui.pTxtLimitTime.text = string.format("%s家具将刷新", Helper.GetLongTimeString(leftTime))
		else
			-- 第二天刷新
			self:ConstructFurnitureShopUI()
		end
	end

	if self._SelectModule == EnumMenuType.Lottery and self._HomeShopGashaponEndTime then
		local leftTime = self._HomeShopGashaponEndTime - curTime
		if leftTime > 0 then
			self._ui.pTxtLimitTime.text = string.format("%s家具将刷新", Helper.GetLongTimeString(leftTime))
		else
			-- 刷新逻辑
			self:ConstructLotteryFurnitureUI()
		end
	end
end


function FurnitureShopCtrl:UpdateImpl(deltaTime)
	if self._SelectModule == EnumMenuType.Purchase then
		if adsTime < ADS_INTERVAL then
			adsTime = adsTime + deltaTime
		else
			self:MoveAdsScrollView()
			adsTime = 0
		end
	end
end

function FurnitureShopCtrl:MoveAdsScrollView()
	if #HomeFurnitureSell.AdsImage > 1 then
		local scrollView = self._ui.pScrollViewAds
		local pTransPanel = scrollView.panel.cachedTransform
		local targetPosition = nil
		if self._AdsSelfIncreasing then
			self._CurAdsIndex = self._CurAdsIndex + 1
			self._AdsSelfIncreasing = self._CurAdsIndex < #HomeFurnitureSell.AdsImage
			targetPosition = Vector3.New(pTransPanel.localPosition.x - ADS_ITEM_WIDTH, pTransPanel.localPosition.y, pTransPanel.localPosition.z)
		else
			self._CurAdsIndex = self._CurAdsIndex - 1
			self._AdsSelfIncreasing = self._CurAdsIndex <= 1
			targetPosition = Vector3.New(pTransPanel.localPosition.x + ADS_ITEM_WIDTH, pTransPanel.localPosition.y, pTransPanel.localPosition.z)
		end
		SpringPanel.Begin(scrollView.panel.cachedGameObject, targetPosition, 8)
	end
end

function FurnitureShopCtrl:GetTodayTime()
	local curTime = GameData.GetServerTime()
	local timeTable = Helper.FormatTimeStamp2Date(curTime)
	self._TodayTime = os.time({year = timeTable.year, month = timeTable.month, day = timeTable.day, hour = 23, min = 59, sec = 59})
end

function FurnitureShopCtrl:GetFurnitureInfoById(id)
	for idx = 1, #self._HomeShopList do
		if self._HomeShopList[idx].FurnitureId == id then
			return self._HomeShopList[idx]
		end
	end
	return nil
end

function FurnitureShopCtrl:ConstructLotteryFurnitureUI()
	self._ui.pScrollViewPurchase.gameObject:SetActive(false)
	self._ui.pScrollViewAds.gameObject:SetActive(false)
	self._ui.LotteryPanel:SetActive(true)
	self._ui.pObjEmpty:SetActive(false)
	NetManager.Send("HomeShopGashaponList",{}, FurnitureShopCtrl.OnHandleProto, self)
end

function FurnitureShopCtrl:UpdateLotteryFurnitureUI()
	local ui = self._ui
	-- 一等奖和二等奖的数量必定都只有一个
	local firstPrizeInfo = ConfigUtils.GetHomeFurnitureGashaponRankInfos(self._HomeShopGashaponList, 1)
	self:ConstructFurniturePrizeItemUI(ui.pObjFirstPrizeItem, firstPrizeInfo[1])

	local secondPrizeInfo = ConfigUtils.GetHomeFurnitureGashaponRankInfos(self._HomeShopGashaponList, 2)
	self:ConstructFurniturePrizeItemUI(ui.pObjSecondPrizeItem, secondPrizeInfo[1])

	local thirdPrizeInfo = ConfigUtils.GetHomeFurnitureGashaponRankInfos(self._HomeShopGashaponList, 3)
	local iThirdPrizeRootChildrenCount = ui.ThirdPrizeRoot.transform.childCount
	for idx = iThirdPrizeRootChildrenCount, 1, -1 do
		local pObj = ui.ThirdPrizeRoot.transform:GetChild(idx - 1).gameObject
		ui.ObjPool:RecycleObj(pObj)
	end

	for idx = 1, #thirdPrizeInfo do
		local pObjPrizeItem = ui.ObjPool:GetOrCreateObj(ui.EnumPrefabType.ThirdPriceItem)
		pObjPrizeItem.transform:SetParent(ui.ThirdPrizeRoot.transform)
		pObjPrizeItem:SetActive(true)
		pObjPrizeItem.name = tostring(thirdPrizeInfo[idx].Id)
		if #thirdPrizeInfo == 3 then
			pObjPrizeItem.transform.localScale = Vector3.one
		elseif #thirdPrizeInfo == 4 then
			pObjPrizeItem.transform.localScale = Vector3.New(0.9, 0.9, 0.9)
		elseif #thirdPrizeInfo == 5 then
			pObjPrizeItem.transform.localScale = Vector3.New(0.8, 0.8, 0.8)
		end
		pObjPrizeItem.transform.localPosition = Vector3.zero
		self:ConstructFurniturePrizeItemUI(pObjPrizeItem, thirdPrizeInfo[idx])
	end
	ui.ThirdPrizeRoot:Reposition()


	local fourthPrizeInfo = ConfigUtils.GetHomeFurnitureGashaponRankInfos(self._HomeShopGashaponList, 4)
	local iFourthPrizeRootChildrenCount = ui.FourthPrizeRoot.transform.childCount
	for idx = iFourthPrizeRootChildrenCount, 1, -1 do
		local pObj = ui.FourthPrizeRoot.transform:GetChild(idx - 1).gameObject
		ui.ObjPool:RecycleObj(pObj)
	end

	for idx = 1, #fourthPrizeInfo do
		local pObjPrizeItem = ui.ObjPool:GetOrCreateObj(ui.EnumPrefabType.FourthPriceItem)
		pObjPrizeItem.transform:SetParent(ui.FourthPrizeRoot.transform)
		pObjPrizeItem:SetActive(true)
		pObjPrizeItem.name = tostring(fourthPrizeInfo[idx].Id)
		if #fourthPrizeInfo == 3 then
			pObjPrizeItem.transform.localScale = Vector3.one
		elseif #fourthPrizeInfo == 4 then
			pObjPrizeItem.transform.localScale = Vector3.New(0.9, 0.9, 0.9)
		elseif #fourthPrizeInfo == 5 then
			pObjPrizeItem.transform.localScale = Vector3.New(0.8, 0.8, 0.8)
		end
		pObjPrizeItem.transform.localPosition = Vector3.zero
		self:ConstructFurniturePrizeItemUI(pObjPrizeItem, fourthPrizeInfo[idx])
	end
	ui.FourthPrizeRoot:Reposition()

	-- 抽奖花费显示
	local costList = ConfigUtils.GetHomeFurnitureGashaponCost(self._SelectGashaponId)
	local costInfo = costList[1]

	ui.pTxtLotteryOnce.text = "x" .. tostring(costInfo.Num)
	UIHelper.ConstructItemIconAndNum(self, ui.pTranLotteryOnce, costInfo.Id, costInfo.Num)

	-- GetLeftLotteryCount
	local iLeftCount = self:GetLeftLotteryCount()
	ui.pTxtLotteryAll.text = "x" .. tostring(costInfo.Num * iLeftCount)
	UIHelper.ConstructItemIconAndNum(self, ui.pTranLotteryAll, costInfo.Id, costInfo.Num * iLeftCount)

end

function FurnitureShopCtrl:ConstructFurniturePrizeItemUI(prizeItem, gashaponInfo)
	local pSpriteIcon = prizeItem.transform:Find("icon"):GetComponent("UISprite")
	local pTxtNum = prizeItem.transform:Find("num"):GetComponent("UILabel")
	local pObjHint = prizeItem.transform:Find("hint").gameObject

	local strIconName, strAtlasName = ConfigUtils.GetHomeFurnitureIcon(gashaponInfo.Id)
	local furnitureConfig = ConfigUtils.GetHomeFurnitureConfig(gashaponInfo.Id)
	pSpriteIcon.spriteName = furnitureConfig.Icon
	self:SetIconWithAtlas(pSpriteIcon, strIconName, strAtlasName)
	pObjHint:SetActive(gashaponInfo.Num <= 0)
	pTxtNum.text = "x" .. tostring(gashaponInfo.Num)
end

function FurnitureShopCtrl:UpdateMenuUI()
	local menuModule = self._ui.MenuModuleUI
	for idx = 1, #menuModule do
		menuModule[idx].select:SetActive(self._SelectModule == idx)
		menuModule[idx].unselect:SetActive(self._SelectModule ~= idx)
	end
end

function FurnitureShopCtrl:UpdateMonthCardUI()
	self._ui.pTxtHelpDeliveryTime.text = " +" .. tostring(HomeFurnitureSell.DeliveryTimeRate) .. "%"
end

function FurnitureShopCtrl:GetHomeFurnitureGashaponList()
 	local config = ConfigUtils.GetHomeFurnitureGashaponConfig(1230001)
	return config.GashaponList
end

--- 抽奖的剩余次数
function FurnitureShopCtrl:GetLeftLotteryCount()
	local iNum = 0
	for idx = 1, #self._HomeShopGashaponList do
		if self._HomeShopGashaponList[idx].Num > 0 then
			iNum = self._HomeShopGashaponList[idx].Num + iNum
		end
	end
	return iNum
end

--- 更新HomeShopGashaponList
function FurnitureShopCtrl:UpdateHomeShopGashaponList(list)
	for idx = 1, #self._HomeShopGashaponList do
		for j = 1, #list do
			if self._HomeShopGashaponList[idx].Id == list[j].Id and self._HomeShopGashaponList[idx].Rank == list[j].Rank then
				local leftNum = self._HomeShopGashaponList[idx].Num - list[j].Num
				leftNum = math.min(0, leftNum)
				self._HomeShopGashaponList[idx].Num = leftNum
			end
		end
	end
end

function FurnitureShopCtrl:UpdateBannerUI()
	local bHasMonthCard = GameData.IsValidPeriodOfMonthCard2()
	local strDesc = nil
	if bHasMonthCard then
		strDesc = "漆漆月卡会员"
	else
		strDesc = "非月卡"
	end
	self._ui.pTxtVipName.text = strDesc

end

function FurnitureShopCtrl:UpdateCurrencyUI()
	if self._SelectModule == EnumMenuType.Purchase then
		UIHelper.SetItemIcon(self, self._ui.pSpriteCurrencyIcon, HomeFurnitureSell.ShowSellCurrencyId)
		self._ui.pTxtCurrencyNum.text = GameData.GetGoodsNum(HomeFurnitureSell.ShowSellCurrencyId)
	elseif self._SelectModule == EnumMenuType.Lottery then
		UIHelper.SetItemIcon(self, self._ui.pSpriteCurrencyIcon, HomeFurnitureSell.ShowGashaponCurrencyId)
		self._ui.pTxtCurrencyNum.text = GameData.GetGoodsNum(HomeFurnitureSell.ShowGashaponCurrencyId)
	end
end

function FurnitureShopCtrl:OnItemNumChanged()
	self._ui.pTxtCurrencyNum.text = GameData.GetGoodsNum(HomeFurnitureSell.ShowCurrencyId)
end

function FurnitureShopCtrl:OnMonthCardChanged()
	self:ConstructFurnitureShopUI()
end

function FurnitureShopCtrl:UpdateBottomAdsUI()
	if Helper.IsEmptyOrNull(Global.ExtraData) then
		return
	end

	local json = require "cjson"
	local extraInfo = json.decode(Global.ExtraData)
	if extraInfo.HomeFurnitureSellAds ~= nil then
		self._FurnitureSellAdsUrl = extraInfo.HomeFurnitureSellAds
	end
end

function FurnitureShopCtrl:ConstructAdsUI()
	local AdsImage = HomeFurnitureSell.AdsImage
	local iChildCount = self._ui.pUIGridAdsRoot.transform.childCount
	for idx = iChildCount, 1, -1 do
		local pObj = self._ui.pUIGridAdsRoot.transform:GetChild(idx - 1).gameObject
		self._ui.ObjPool:RecycleObj(pObj)
	end

	for idx = 1, #AdsImage do
		local pObj = self._ui.ObjPool:GetOrCreateObj(self._ui.EnumPrefabType.AdsItem, function(obj)
			CtrlManager.AddClick(self, obj)
		end)
		pObj.transform:SetParent(self._ui.pUIGridAdsRoot.transform)
		pObj:SetActive(true)
		pObj.name = tostring(idx)
		pObj.transform.localScale = Vector3.one

		local pSpriteIcon = pObj:GetComponent("UISprite")
		pSpriteIcon.spriteName = AdsImage[idx]
	end
end

function FurnitureShopCtrl:IsEnoughMoney(costInfo)
	local isEnough = true
	local lackList = {}
	for idx = 1, #costInfo do
		local itemId = costInfo[idx].Id
		local needNum = costInfo[idx].Num
		local curNum = GameData.GetItemNum(itemId)
		if needNum > curNum then
			isEnough = false
			table.insert(lackList, itemId)
		end
	end
	return isEnough, lackList
end