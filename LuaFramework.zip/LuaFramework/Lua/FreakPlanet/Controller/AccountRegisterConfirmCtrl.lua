require "FreakPlanet/View/AccountRegisterConfirmPanel"

local class = require "FreakPlanet/Utils/middleclass"
AccountRegisterConfirmCtrl  = class(CtrlNames.AccountRegisterConfirm, BaseCtrl)

-- load the ui prefab
function AccountRegisterConfirmCtrl:LoadPanel()
	self:CreatePanel("AccountRegisterConfirm")
end

-- construct ui panel data
function AccountRegisterConfirmCtrl:ConstructUI(obj)
	self._ui = AccountRegisterConfirmPanel.Init(obj)
end

-- fill ui with the data
function AccountRegisterConfirmCtrl:SetupUI()
	CtrlManager.AddClick(self, self._ui.ButtonRule)
    CtrlManager.AddClick(self, self._ui.ButtonPrivacy)
    CtrlManager.AddClick(self, self._ui.ButtonConfirm)
    CtrlManager.AddClick(self, self._ui.ButtonCancel)
end

-- handle the escapse button
function AccountRegisterConfirmCtrl:HandleEscape()
    self:OnClicked(self._ui.ButtonCancel)
end

-- can do jump or not
function AccountRegisterConfirmCtrl:CanJump()
    return false
end

-- on clicked
function AccountRegisterConfirmCtrl:OnClicked(go)

    if go == self._ui.ButtonCancel then
        SoundSystem.PlayUICancelSound()
        CtrlManager.PopPanel()
    elseif go == self._ui.ButtonConfirm then
        SoundSystem.PlayUIClickSound()
        CtrlManager.PopPanel()
        local cb = self._parameter.callback
        local receiver = self._parameter.receiver
        cb(receiver)
    elseif go == self._ui.ButtonRule then
        SoundSystem.PlayUIClickSound()
        Global.OpenURL(USER_NOTICE_URL)
    elseif go == self._ui.ButtonPrivacy then
        SoundSystem.PlayUIClickSound()
        Global.OpenURL(PRIVACY_NOTICE_URL)
    end

	return true
end
