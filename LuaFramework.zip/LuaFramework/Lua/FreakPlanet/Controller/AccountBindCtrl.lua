require "FreakPlanet/View/AccountBindPanel"

local class = require "FreakPlanet/Utils/middleclass"
AccountBindCtrl  = class(CtrlNames.AccountBind, BaseCtrl)

-- load the ui prefab
function AccountBindCtrl:LoadPanel()
	self:CreatePanel("AccountBind")
end

-- construct ui panel data
function AccountBindCtrl:ConstructUI(obj)
	self._ui = AccountBindPanel.Init(obj)
end

-- fill ui with the data
function AccountBindCtrl:SetupUI()
	CtrlManager.AddClick(self, self._ui.Blocker)
	CtrlManager.AddClick(self, self._ui.ButtonConfirm)
end

function AccountBindCtrl:CheckInput()
	local account = self._ui.NickNameSafeInput:GetText()
	if Helper.IsEmptyOrNull(account) then
		SoundSystem.PlayWarningSound()
		CtrlManager.ShowMessageBox({message = SAFE_LOC("loc_global_id_empty"), single = true})
		return false
	end

	local accountLen = Helper.LenOfUtf8(account)
	if accountLen < 1 or accountLen > 10 then
		SoundSystem.PlayWarningSound()
		CtrlManager.ShowMessageBox({message = SAFE_LOC("loc_global_nickname_modify1"), single = true})
		return false
	end

	local accountFiltered = Helper.FilterSpecialChars(account)
	if accountFiltered ~= account then
		SoundSystem.PlayWarningSound()
		CtrlManager.ShowMessageBox({message = SAFE_LOC("loc_global_nickname_modify2"), single = true})
		return false
	end

	local newPassword = self._ui.NewPassword.value
	if Helper.IsEmptyOrNull(newPassword) then
		SoundSystem.PlayWarningSound()
		CtrlManager.ShowMessageBox({message = SAFE_LOC("loc_global_new_password_empty"), single = true})
		return false
	end

	local passwordLen = Helper.LenOfUtf8(newPassword)
	if passwordLen < 6 or passwordLen > 18 then
		SoundSystem.PlayWarningSound()
		CtrlManager.ShowMessageBox({message = SAFE_LOC("loc_global_password_rule1"), single = true})
		return false
	end

	local passwordMatch = Helper.ContainsBothLetterAndNumber(newPassword)
	if not passwordMatch then
		SoundSystem.PlayWarningSound()
		CtrlManager.ShowMessageBox({message = SAFE_LOC("loc_global_password_rule2"), single = true})
		return false
	end

	local confirmPassword = self._ui.ConfirmPassword.value
	if newPassword ~= confirmPassword then
		SoundSystem.PlayWarningSound()
		CtrlManager.ShowMessageBox({message = SAFE_LOC("loc_global_password_no_match"), single = true})
		return false
	end

	return true
end

-- on clicked
function AccountBindCtrl:OnClicked(go)
	if go == self._ui.Blocker then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
	elseif go == self._ui.ButtonConfirm then
		local valid = self:CheckInput()
		if not valid then
			return true
		end

		SoundSystem.PlayUIClickSound()
		NetManager.Send("BindAccount", {
			Nickname = self._ui.NickNameSafeInput:GetText(),
			Password = Helper.CheckMd5(self._ui.NewPassword.value),
		}, 
		AccountBindCtrl.OnHandleProto, 
		self)
	end

	return true
end

function AccountBindCtrl:OnHandleProto(proto, data, requestData)
	if proto == "BindAccount" then
		local nickname = requestData.Nickname
		local password = requestData.Password

		GameData.BindAccount(nickname, password)
		GameData.Save()
		NavigationCtrl.RefreshAccountInfo()

		CtrlManager.PopPanel()
		CtrlManager.ShowMessageBox({message = SAFE_LOC("loc_global_password_change_succeed"), single = true})
	end
end
