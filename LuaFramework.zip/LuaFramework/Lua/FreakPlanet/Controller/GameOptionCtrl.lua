require "FreakPlanet/View/GameOptionPanel"

local class = require "FreakPlanet/Utils/middleclass"
GameOptionCtrl = class(CtrlNames.GameOption, BaseCtrl)

local _BGMTypeIcon = { "music_loop", "music_list", "music_random" }
local _MusicMenu = nil
local _BGMConfig = nil
local _InitShow = true
local _curMusic = nil


-- load the ui prefab
function GameOptionCtrl:LoadPanel()
    self:CreatePanel("GameOption")
end

-- construct ui panel data
function GameOptionCtrl:ConstructUI(obj)
    self._ui = GameOptionPanel.Init(obj)
end

-- notity it has been focused
function GameOptionCtrl:NotifyFocus()
    self:CheckAccount()
end

-- fill ui with the data
function GameOptionCtrl:SetupUI()
    _BGMConfig = ConfigUtils.GetBgmConfig()
    self:RefreshUI()

    CtrlManager.AddClick(self, self._ui.ButtonMusic)
    CtrlManager.AddClick(self, self._ui.ButtonSound)
    CtrlManager.AddClick(self, self._ui.ButtonNotification)
    CtrlManager.AddClick(self, self._ui.ButtonLanguage)
    CtrlManager.AddClick(self, self._ui.ButtonBindAccount)
    CtrlManager.AddClick(self, self._ui.ButtonRealName)
    CtrlManager.AddClick(self, self._ui.ButtonModifyName)
    CtrlManager.AddClick(self, self._ui.ButtonService)
    CtrlManager.AddClick(self, self._ui.ButtonRedeem)
    CtrlManager.AddClick(self, self._ui.ButtonReport)
    CtrlManager.AddClick(self, self._ui.Blocker)
    CtrlManager.AddClick(self, self._ui.ButtonReset)
    CtrlManager.AddClick(self, self._ui.ButtonPrivacy)
    CtrlManager.AddClick(self, self._ui.ButtonUserPrivacy)
    CtrlManager.AddClick(self, self._ui.ButtonAutoLock)
    ---------------------------------------------------
    CtrlManager.AddClick(self, self._ui.ButtonLog)
    CtrlManager.AddClick(self, self._ui.ButtonCleanLog)
    CtrlManager.AddClick(self, self._ui.LogPanelBlocker)

    CtrlManager.AddClick(self, self._ui.ButtonMusicType)
    CtrlManager.AddClick(self, self._ui.ButtonSwitchMusic)
    CtrlManager.AddClick(self, self._ui.MusicBlocker)
    CtrlManager.AddClick(self, self._ui.ButtonPreviousMusic)
    CtrlManager.AddClick(self, self._ui.ButtonNextMusic)
    -- 有的渠道不允许出现客服按钮
    self._ui.ButtonService:SetActive(Game.ShowService())
    -- TODO, hide temporary
    self._ui.ButtonLanguage:SetActive(false)
    self._ui.ButtonLog:SetActive(not Game.IsDistributeVersion())
    self._ui.ButtonCleanLog:SetActive(not Game.IsDistributeVersion())
    -- 审核版本不显示兑换码 - 苹果不允许
    self._ui.ButtonRedeem:SetActive(Global.CurrentBigVersion() <= Global.MaxServerVersion)

    self._ui.Table:Reposition()

    GameNotifier.AddListener(GameEvent.BGMChanged, GameOptionCtrl.OnBGMChanged, self)
end

-- refresh ui
function GameOptionCtrl:RefreshUI()
    self:CheckMusic()
    self:CheckSound()
    self:CheckNotification()
    self:CheckAccount()
    self:CheckAutoLock()

    self._ui.GameVersion.text = UIHelper.GetGameVersion()
    self._ui.ButtonMusicTypeIcon.spriteName = _BGMTypeIcon[GameData.GetBGMType()]
    self._ui.ButtonMusicName.text = ConfigUtils.GetBgmName(SoundSystem.GetCurPlayBGM()) or ""
end

function GameOptionCtrl:DestroyImpl()
    _InitShow = true
    GameNotifier.RemoveListener(GameEvent.BGMChanged, GameOptionCtrl.OnBGMChanged, self)
end

-- music state
function GameOptionCtrl:CheckMusic()
    local isOn = GameData.IsMusicOn()
    self._ui.MusicStateOn:SetActive(isOn)
    self._ui.MusicStateOff:SetActive(not isOn)
end

-- sound state
function GameOptionCtrl:CheckSound()
    local isOn = GameData.IsSoundOn()
    self._ui.SoundStateOn:SetActive(isOn)
    self._ui.SoundStateOff:SetActive(not isOn)
end

-- notification state
function GameOptionCtrl:CheckNotification()
    local isOn = GameData.IsNotificationOn()
    self._ui.NotificationStateOn:SetActive(isOn)
    self._ui.NotificationStateOff:SetActive(not isOn)
end

function GameOptionCtrl:CheckAccount()
    local signInDays = GameData.GetSignInDays()
    self._ui.NickName.text = GameData.GetDefaultNickName(true)
    self._ui.GameDays.text = tostring(signInDays)

    local isBinded = GameData.IsAccountNicknameBinded()
    self._ui.ButtonBindAccount:SetActive(not isBinded)

    local isVerified = GameData.IsAccountVerified()
    self._ui.ButtonRealName:SetActive(not isVerified and not Global.HasChannelAccount)

    self._ui.ButtonModifyName:SetActive(isBinded)
end

function GameOptionCtrl:CheckAutoLock()
    local isOn = GameData.IsAutoLockOn()
    self._ui.AutoLockStateOn:SetActive(isOn)
    self._ui.AutoLockStateOff:SetActive(not isOn)
end

-- on click
function GameOptionCtrl:OnClicked(go)
    if go == self._ui.Blocker then
        SoundSystem.PlayUICancelSound()
        CtrlManager.PopPanel()
        return true
    end

    if go == self._ui.ButtonMusic then
        GameData.ToggleMusic()
        GameData.Save()
        self:CheckMusic()
        if GameData.IsMusicOn() then
            SoundSystem.PlayMusic()
        else
            SoundSystem.StopMusic()
        end
        SoundSystem.PlayUIClickSound()
    elseif go == self._ui.ButtonSound then
        GameData.ToggleSound()
        GameData.Save()
        self:CheckSound()
        if GameData.IsSoundOn() then
            SoundSystem.PlayUIClickSound()
        end
    elseif go == self._ui.ButtonNotification then
        SoundSystem.PlayUIClickSound()
        GameData.ToggleNotification()
        GameData.Save()
        self:CheckNotification()
    elseif go == self._ui.ButtonAutoLock then
        SoundSystem.PlayUIClickSound()
        GameData.ToggleAutoLock()
        self:CheckAutoLock()
        Game.SetAutoLock()
    elseif go == self._ui.ButtonLanguage then
        SoundSystem.PlayUIClickSound()
        LocalizationManager.ToggleLanguage()
        self:RefreshUI()
    elseif go == self._ui.ButtonLog then
        SoundSystem.PlayUIClickSound()
        self._ui.LogPanel:SetActive(true)
        if LogTracker.HasErrorInfo() then
            self._ui.LogLabel.text = LogTracker.GetErrorInfo()
        else
            self._ui.LogLabel.text = "未检测到错误"
        end
    elseif go == self._ui.ButtonCleanLog then
        SoundSystem.PlayUIClickSound()
        if LogTracker.HasErrorInfo() then
            LogTracker.Clean()
        end
    elseif go == self._ui.LogPanelBlocker then
        SoundSystem.PlayUIClickSound()
        self._ui.LogPanel:SetActive(false)
    elseif go == self._ui.ButtonReset then
        SoundSystem.PlayUIClickSound()
        UserPermissionCtrl.SetFlag(0)
        Game.Restart()
    elseif go == self._ui.ButtonPrivacy then
        SoundSystem.PlayUIClickSound()
        Global.OpenURL(PRIVACY_NOTICE_URL)
    elseif go == self._ui.ButtonUserPrivacy then
        SoundSystem.PlayUIClickSound()
        Global.OpenURL(USER_NOTICE_URL)
    elseif go == self._ui.ButtonBindAccount then
        SoundSystem.PlayUIClickSound()
        CtrlManager.OpenPanel(CtrlNames.AccountBind)
    elseif go == self._ui.ButtonModifyName then
        SoundSystem.PlayUIClickSound()
        CtrlManager.OpenPanel(CtrlNames.ModifyNickName)
    elseif go == self._ui.ButtonRealName then
        SoundSystem.PlayUIClickSound()
        CtrlManager.OpenPanel(CtrlNames.AccountRealName)
    elseif go == self._ui.ButtonRedeem then
        SoundSystem.PlayUIClickSound()
        CtrlManager.OpenPanel(CtrlNames.Redeem)
    elseif go == self._ui.ButtonService then
        SoundSystem.PlayUIClickSound()
        Game.OpenService()
    elseif go == self._ui.ButtonMusicType then
        SoundSystem.PlayUIClickSound()
        GameData.SetNextBGMType()
        GameData.Save()
        SoundSystem.SetBgmLoop(GameData.GetBGMType() == 1)
        self._ui.ButtonMusicTypeIcon.spriteName = _BGMTypeIcon[GameData.GetBGMType()]
    elseif go == self._ui.ButtonPreviousMusic then
        SoundSystem.PlayUIClickSound()
        self:PreviousMusicClick(false)
    elseif go == self._ui.ButtonNextMusic then
        SoundSystem.PlayUIClickSound()
        self:PreviousMusicClick(true)
    elseif go == self._ui.ButtonSwitchMusic then
        SoundSystem.PlayUIClickSound()
        self:ShowMusicMenu()

    elseif go == self._ui.MusicBlocker then
        SoundSystem.PlayUIClickSound()
        self._ui.MusicMenuPanel:SetActive(false)

        if _curMusic ~= SoundSystem.GetCurPlayBGM() then
            GameData.SetRecordBGM(_curMusic)
            GameData.Save()
            SoundSystem.SwitchBGM()
        end
    end

    return true
end

function GameOptionCtrl:OnBGMChanged(music)
    _curMusic = music
    self._ui.ButtonMusicName.text = ConfigUtils.GetBgmName(music) or ""
    if _MusicMenu ~= nil then
        for i = 1, #_MusicMenu do
            _MusicMenu[i].mark:SetActive(_curMusic == _MusicMenu[i].item.name)
        end
    end

end

function GameOptionCtrl:ShowMusicMenu()
    self._ui.MusicMenuPanel:SetActive(true)
    if _InitShow then
        _MusicMenu = {}
        for i = 1, #_BGMConfig do
            local musicItem = Helper.NewObject(self._ui.MusicItem, self._ui.MusicGrid.transform, 1)
            musicItem.name = _BGMConfig[i].key
            local musicName = musicItem.transform:Find("Title"):GetComponent("UILabel")
            local mark = musicItem.transform:Find("Mark").gameObject
            musicName.text = _BGMConfig[i].Name
            mark:SetActive(SoundSystem.GetCurPlayBGM() == _BGMConfig[i].key)
            CtrlManager.AddClickWithFunc(self, musicItem, self.OnMusicClick)
            table.insert(_MusicMenu, { item = musicItem, title = musicName, mark = mark })
        end
        _InitShow = false
        self._ui.MusicGrid:Reposition()
    end

end

function GameOptionCtrl:PreviousMusicClick(isNext)
    _curMusic = _curMusic or GameData.GetRecordBGM()
    local music = ConfigUtils.GetNextBgm(_curMusic, GameData.GetBGMType() ~= 3, isNext)
    GameData.SetRecordBGM(music)
    GameData.Save()
    SoundSystem.SwitchBGM()
end

function GameOptionCtrl.OnMusicClick(button)
    _curMusic = button.name
    SoundSystem.PlayUIClickSound()
    for i = 1, #_MusicMenu do
        _MusicMenu[i].mark:SetActive(_curMusic == _MusicMenu[i].item.name)
    end
end