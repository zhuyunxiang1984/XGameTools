require "FreakPlanet/View/NewItemPanel"

local class = require "FreakPlanet/Utils/middleclass"
NewItemCtrl  = class(CtrlNames.NewItem, BaseCtrl)

local _itemList = {}

-- load the ui prefab
function NewItemCtrl:LoadPanel()
	self:CreatePanel("NewItem")
end

-- construct ui panel data
function NewItemCtrl:ConstructUI(obj)
	self._ui = NewItemPanel.Init(obj)
end

-- fill ui with the data
function NewItemCtrl:SetupUI()
	self._isShowing = false
	self:RefreshNextItem()
	CtrlManager.AddClick(self, self._ui.Blocker)
end

function NewItemCtrl:RefreshNextItem()
	if #_itemList == 0 then
		return
	end

	local itemId = _itemList[1].itemId
	local itemNum = _itemList[1].itemNum
	local unlocked = _itemList[1].unlocked or false
	table.remove(_itemList, 1)
	self._currentItemId = itemId
	self._ui.NewMark:SetActive(not unlocked)

	local itemType = ConfigUtils.GetItemTypeFromId(itemId)
	self:Reset(itemType)
	if itemType == ItemType.Character then
		SoundSystem.PlayRewardSpecialSound()
		self:ShowNewCharacter(itemId)
	elseif itemType == ItemType.Goods then
		SoundSystem.PlayRewardSound()
		self:ShowNewGoods(itemId, itemNum)
	elseif itemType == ItemType.PlanetArea then
		SoundSystem.PlayRewardSound()
		self:ShowNewPlanetArea(itemId)
	elseif itemType == ItemType.Gold then
		SoundSystem.PlayMoneySound()
		self:ShowGold(itemNum)
	elseif itemType == ItemType.Diamond then
		SoundSystem.PlayMoneySound()
		self:ShowDiamond(itemNum)
	elseif itemType == ItemType.LabRecipe then
		SoundSystem.PlayRewardSound()
		self:ShowLabRecipe(itemId)
	elseif itemType == ItemType.Token then
		SoundSystem.PlayRewardSound()
		self:ShowToken(itemId, itemNum)
	elseif itemType == ItemType.WorkShop then
		SoundSystem.PlayRewardSound()
		self:ShowWorkShop(itemId)
	elseif itemType == ItemType.Pet then
		SoundSystem.PlayRewardSound()
		self:ShowPet(itemId, itemNum)
	elseif itemType == ItemType.RoomPiece then
		SoundSystem.PlayRewardSound()
		self:ShowRoomPiece(itemId, itemNum)
	elseif itemType == ItemType.Skin then
		SoundSystem.PlayRewardSpecialSound()
		self:ShowNewSkin(itemId)
	elseif itemType == ItemType.CatchFishPoint then
		SoundSystem.PlayRewardSound()
		self:ShowCatchFishPoint(itemNum)
	elseif itemType == ItemType.ActivityPassport then
		SoundSystem.PlayRewardSound()
	elseif itemType == ItemType.HomeFurniture then
		SoundSystem.PlayRewardSound()
		self:ShowFurniture(itemId)
	else
		assert(false, "un-handled item type: "..tostring(itemType))
	end
end

function NewItemCtrl:CleanCharacterAvatar()
	-- clean
	for idx = self._ui.CharacterAvatar.childCount, 1, -1 do
		local obj = self._ui.CharacterAvatar:GetChild(idx - 1).gameObject
		destroy(obj)
	end
end

function NewItemCtrl:CleanSkinAvatar()
	-- clean
	for idx = self._ui.SkinAvatar.childCount, 1, -1 do
		local obj = self._ui.SkinAvatar:GetChild(idx - 1).gameObject
		destroy(obj)
	end
end

function NewItemCtrl:CleanPetAvatar()
	-- clean
	for idx = self._ui.PetAvatar.childCount, 1, -1 do
		local obj = self._ui.PetAvatar:GetChild(idx - 1).gameObject
		destroy(obj)
	end
end

function NewItemCtrl:Reset(itemType)
	self._ui.CharacterRoot.gameObject:SetActive(itemType == ItemType.Character or itemType == ItemType.Skin)
	self._ui.GoodsRoot.gameObject:SetActive(itemType == ItemType.Goods)
	self._ui.GoldRoot.gameObject:SetActive(itemType == ItemType.Gold)
	self._ui.DiamondRoot.gameObject:SetActive(itemType == ItemType.Diamond)
	self._ui.PlanetAreaRoot.gameObject:SetActive(itemType == ItemType.PlanetArea)
	self._ui.LabRecipeRoot.gameObject:SetActive(itemType == ItemType.LabRecipe)
	self._ui.TokenRoot.gameObject:SetActive(itemType == ItemType.Token)
	self._ui.WorkShopRoot.gameObject:SetActive(itemType == ItemType.WorkShop)
	self._ui.PetRoot.gameObject:SetActive(itemType == ItemType.Pet)
	self._ui.RoomPieceRoot.gameObject:SetActive(itemType == ItemType.RoomPiece)
	self._ui.CatchFishPoint.gameObject:SetActive(itemType == ItemType.CatchFishPoint)
	self._ui.ActivityPassport.gameObject:SetActive(itemType == ItemType.ActivityPassport)
	self._ui.pObjFurniture:SetActive(itemType == ItemType.HomeFurniture)

	self._ui.TweenScale:ResetToBeginning()
	self._ui.TweenScale:PlayForward()
	self._isShowing = true
	GlobalScheduler:DoActionAfterTime(0.5, NewItemCtrl.FinishShow, self)
end

function NewItemCtrl:FinishShow()
	self._isShowing = false
end

function NewItemCtrl:ShowNewCharacter(itemId)
	-- remove
	self:CleanCharacterAvatar()
	-- avatar
	local prefabName, prefabBundle = ConfigUtils.GetCharacterPrefab(itemId)
	local prefab = self:DynamicLoadAsset(prefabBundle, prefabName)
	local itemObj = Helper.NewObject(prefab, self._ui.CharacterAvatar, 70)
	itemObj.name = tostring(itemId)
	-- skin
	local skeletonAnimation = itemObj:GetComponent("SkeletonAnimation")
	Helper.PlayAnimation(skeletonAnimation, CharacterAnimations.Idle, true)
	UIHelper.SetCharacterSkin(skeletonAnimation, itemId, true)
	-- name
	self._ui.CharacterName.text = ConfigUtils.GetCharacterName(itemId)
	-- desc
	--self._ui.CharacterDesc.text = ConfigUtils.GetCharacterDesc(itemId)
end

function NewItemCtrl:ShowNewSkin(itemId)
	-- remove
	self:CleanCharacterAvatar()

	local characterId = ConfigUtils.GetCharacterOfSkin(itemId)
	-- avatar
	local prefabName, prefabBundle = ConfigUtils.GetCharacterPrefab(characterId)
	local prefab = self:DynamicLoadAsset(prefabBundle, prefabName)
	local itemObj = Helper.NewObject(prefab, self._ui.CharacterAvatar, 70)
	itemObj.name = tostring(characterId)
	-- skin
	local skeletonAnimation = itemObj:GetComponent("SkeletonAnimation")
	Helper.PlayAnimation(skeletonAnimation, CharacterAnimations.Idle, true)
	UIHelper.SetCharacterSkin(skeletonAnimation, characterId, true)
	UIHelper.SetCharacterSkinWithSkin(skeletonAnimation, itemId)
	-- name
	self._ui.CharacterName.text = ConfigUtils.GetSkinName(itemId)
	-- desc
	--self._ui.CharacterDesc.text = ConfigUtils.GetSkinDesc(itemId, true)
end

function NewItemCtrl:ShowNewGoods(itemId, itemNum)
	-- icon
	UIHelper.SetItemIcon(self,self._ui.GoodsIcon, itemId)
	-- name
	self._ui.GoodsName.text = ConfigUtils.GetGoodsName(itemId)
	-- num
	self._ui.GoodsNum.text = "x"..tostring(itemNum)
	--[[
	-- desc
	local subType = ConfigUtils.GetGoodsSubType(itemId)
	if subType == GoodsSubType.Object then
		self._ui.GoodsDesc.text = SAFE_LOC("loc_Goods")
	elseif subType == GoodsSubType.Chip then
		self._ui.GoodsDesc.text = SAFE_LOC("loc_Chip")
	elseif subType == GoodsSubType.CatchItem then
		self._ui.GoodsDesc.text = SAFE_LOC("loc_CatchItem")
	elseif subType == GoodsSubType.EventItem then
		self._ui.GoodsDesc.text = SAFE_LOC("loc_EventItem")
	elseif subType == GoodsSubType.Food then
		self._ui.GoodsDesc.text = SAFE_LOC("loc_Food")
	else
		assert(false, "un-handled goods subtype: "..tostring(subType))
	end
	--]]
end

function NewItemCtrl:ShowLabRecipe(itemId)
	-- icon
	UIHelper.SetItemIcon(self,self._ui.LabRecipeIcon, itemId)
	-- name
	self._ui.LabRecipeName.text = "[473D52]"..ConfigUtils.GetLabRecipeName(itemId).."[-]"
	-- desc
	--self._ui.LabRecipeDesc.text = ConfigUtils.GetLabRecipeDesc(itemId)
end

function NewItemCtrl:ShowNewPlanetArea(itemId)
	-- icon
	local iconName, iconAtlas, iconBundle = ConfigUtils.GetAreaBG(itemId)
  	self._ui.PlanetAreaIcon.sprite2D = self:DynamicLoadSprite(iconBundle, iconAtlas, iconName)
	-- name
	self._ui.PlanetAreaName.text = ConfigUtils.GetAreaName(itemId)
	-- desc
	--self._ui.PlanetAreaDesc.text = SAFE_LOC("一片奇妙的区域")
end

function NewItemCtrl:ShowGold(itemNum)
	self._ui.GoldNum.text = "x"..tostring(itemNum)
end

function NewItemCtrl:ShowDiamond(itemNum)
	self._ui.DiamondNum.text = "x"..tostring(itemNum)
end

function NewItemCtrl:ShowCatchFishPoint(itemNum)
	self._ui.CatchFishPointNum.text = "x"..tostring(itemNum)
end

function NewItemCtrl:ShowToken(itemId, itemNum)
	self._ui.TokenIcon.spriteName = ConfigUtils.GetTokenIcon(itemId)
	self._ui.TokenName.text = ConfigUtils.GetTokenName(itemId)
	--self._ui.TokenDesc.text = ConfigUtils.GetTokenDesc(itemId)
	self._ui.TokenNum.text = "x"..tostring(itemNum)
end

function NewItemCtrl:ShowWorkShop(itemId)
	self._ui.WorkShopIcon.spriteName = ConfigUtils.GetWorkShopIcon(itemId)
	self._ui.WorkShopName.text = ConfigUtils.GetWorkShopName(itemId)
end

function NewItemCtrl:ShowFurniture(itemId)
	self._ui.pSpriteFurnitureIcon.spriteName = ConfigUtils.GetHomeFurnitureIcon(itemId)
	self._ui.pTxtFurnitureName.text = ConfigUtils.GetHomeFurnitureName(itemId)
end

function NewItemCtrl:ShowPet(itemId, itemNum)
	self:CleanPetAvatar()
	-- avatar
	local prefabName, prefabBundle = ConfigUtils.GetPetPrefab(itemId)
	local prefab = self:DynamicLoadAsset(prefabBundle, prefabName)
	local petObj = Helper.NewObject(prefab, self._ui.PetAvatar, 100)
	petObj.name = tostring(itemId)
	-- skin
	local skeletonAnimation = petObj:GetComponent("SkeletonAnimation")
	Helper.PlayAnimation(skeletonAnimation, CharacterAnimations.Idle, true)

	self._ui.PetName.text = ConfigUtils.GetPetName(itemId)
	self._ui.PetNum.text = "x"..tostring(itemNum)
end

function NewItemCtrl:ShowRoomPiece(itemId, itemNum)
	self._ui.RoomPieceIcon.spriteName = ConfigUtils.GetRoomPieceIcon(itemId)
	self._ui.RoomPieceName.text = ConfigUtils.GetRoomPieceName(itemId)
	--self._ui.RoomPieceDesc.text = ConfigUtils.GetRoomPieceDesc(itemId)
end

-- handle the escapse button
function NewItemCtrl:HandleEscape()
	self:OnClicked(self._ui.Blocker)
end

-- on clicked
function NewItemCtrl:OnClicked(go)
	if self._isShowing then
		return true
	end

	if go == self._ui.Blocker then
		if #_itemList == 0 then
			SoundSystem.PlayUICancelSound()
			CtrlManager.PopPanel()
			NavigationCtrl.EnableSuspend(false)
		else
			self:RefreshNextItem()
		end
	end

	return true
end

--------------------------------------------------------------
-- static method?
function NewItemCtrl.ShowNewItem(itemId, itemNum, unlocked)
	table.insert(_itemList, {itemId = itemId, itemNum = itemNum, unlocked = unlocked})
	if not CtrlManager.IsCtrlOpen(CtrlNames.NewItem) then
		CtrlManager.OpenPanel(CtrlNames.NewItem)
	end
end

function NewItemCtrl.ShowNewItemList(items)
	if items == nil or #items == 0 then
		return
	end

	for idx = 1, #items do
		table.insert(_itemList, {itemId = items[idx].value, itemNum = items[idx].num, unlocked = items[idx].unlocked})
	end

	if not CtrlManager.IsCtrlOpen(CtrlNames.NewItem) then
		CtrlManager.OpenPanel(CtrlNames.NewItem)
	end
end
