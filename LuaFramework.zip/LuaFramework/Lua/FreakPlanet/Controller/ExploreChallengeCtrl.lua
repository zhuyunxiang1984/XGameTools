require "FreakPlanet/View/ExploreChallengePanel"

local class = require "FreakPlanet/Utils/middleclass"
ExploreChallengeCtrl  = class(CtrlNames.ExploreChallenge, BaseCtrl)

-- load the ui prefab
function ExploreChallengeCtrl:LoadPanel()
	self:CreatePanel("ExploreChallenge")
end

-- construct ui panel data
function ExploreChallengeCtrl:ConstructUI(obj)
	self._ui = ExploreChallengePanel.Init(obj)
end

-- fill ui with the data
function ExploreChallengeCtrl:SetupUI()
    self._challengeId = self._parameter.challengeId
    self._enemyList = ConfigUtils.GetChallengeEnemyList(self._challengeId)
    self._currentIndex = 1
    self:OnSelectedEnemyChanged()
    -- name
    self._ui.ChallengeName.text = ConfigUtils.GetChallengeName(self._challengeId)
    local canChallenge, needGoalId = GameData.IsChallengeConditionMatch(self._challengeId)
    self._ui.ButtonChallenge:SetActive(canChallenge)
    self._ui.ChallengeConditionHint:SetActive(not canChallenge)
    if not canChallenge then
        self._ui.ChallengeConditionHintLabel.text = ConfigUtils.GetGoalName(needGoalId)
    end

    CtrlManager.AddClick(self, self._ui.Blocker)
    CtrlManager.AddClick(self, self._ui.ButtonChallenge)
    CtrlManager.AddClick(self, self._ui.ButtonNext)
    CtrlManager.AddClick(self, self._ui.ButtonPrev)
    CtrlManager.AddClick(self, self._ui.ChallengeCollider)

    self:CheckTutorial()
end

function ExploreChallengeCtrl:OnSelectedEnemyChanged()
    -- avatar
    for idx = self._ui.ChallengeAvatar.childCount, 1, -1 do
        local item = self._ui.ChallengeAvatar:GetChild(idx - 1)
        item.parent = self._ui.AvatarPool
    end

    local enemyId = self._enemyList[self._currentIndex].id
    local avatarItem = self._ui.AvatarPool:Find(enemyId)
    if avatarItem == nil then
        local prefabName, prefabBundle = ConfigUtils.GetEnemyPrefab(enemyId)
        local prefab = self:DynamicLoadAsset(prefabBundle, prefabName)
        local avatarItemObj = Helper.NewObject(prefab, self._ui.ChallengeAvatar, 80)
        avatarItemObj.name = tostring(enemyId)
        avatarItem = avatarItemObj.transform
    else
        avatarItem.parent = self._ui.ChallengeAvatar
        avatarItem.localPosition = Vector3.zero
        avatarItem.localScale = Vector3.one * 80
    end
    -- animation
    local skeletonAnimation = avatarItem:GetComponent("SkeletonAnimation")
    Helper.PlayAnimation(skeletonAnimation, CharacterAnimations.Idle, true)
    -- skin
    local skinName = ConfigUtils.GetEnemySkinName(enemyId)
    if skinName ~= nil then
        Helper.SetSkin(skeletonAnimation, skinName)
    end

    self._ui.ButtonNext:SetActive(#self._enemyList > 1 and self._currentIndex < #self._enemyList)
    self._ui.ButtonPrev:SetActive(#self._enemyList > 1 and self._currentIndex > 1)
end

function ExploreChallengeCtrl:CloseToChallenge()
    CtrlManager.PopPanel()
    CtrlManager.OpenPanel(CtrlNames.ExploreCharacter, {challengeId = self._challengeId})
end

-- on clicked
function ExploreChallengeCtrl:OnClicked(go)

    if go == self._ui.Blocker then
        SoundSystem.PlayUICancelSound()
        CtrlManager.PopPanel()
    elseif go == self._ui.ButtonChallenge then
        SoundSystem.PlayUIClickSound()
        CtrlManager.DoWaitTransition(CtrlNames.ExploreCharacter, self, ExploreChallengeCtrl.CloseToChallenge)
    elseif go == self._ui.ButtonNext then
        SoundSystem.PlayUIClickSound()
        self._currentIndex = self._currentIndex + 1
        self:OnSelectedEnemyChanged()
    elseif go == self._ui.ButtonPrev then
        SoundSystem.PlayUIClickSound()
        self._currentIndex = self._currentIndex - 1
        self:OnSelectedEnemyChanged()
    elseif go == self._ui.ChallengeCollider then
        SoundSystem.PlayUIClickSound()
        local enemyId = self._enemyList[self._currentIndex].id
        local enemyLevel = self._enemyList[self._currentIndex].level
        CtrlManager.ShowItemDetail({itemId = enemyId, itemLevel = enemyLevel})
    end

	return true
end

------------------------------------------------------------------------------
function ExploreChallengeCtrl:CheckTutorial()
    local tutorials = {}

    if GameData.IsTutorialNotFinished(Tutorials.Tutorial_2_6) and GameData.IsGoalRunning(TutorialConstData.ChallengeGoal) then
        local position = self._ui.Camera:WorldToScreenPoint(self._ui.ButtonChallenge.transform.position)
        tutorials[1] = {event = Tutorials.Tutorial_2_2_1, position = position, sender = self}
    end

    if #tutorials > 0 then
        CtrlManager.ShowTutorials(tutorials)
    end

    return #tutorials > 0
end

function ExploreChallengeCtrl:OnTutorialClicked(tutorial)
    if tutorial == Tutorials.Tutorial_2_2_1 then
        self:OnClicked(self._ui.ButtonChallenge)
    end
end