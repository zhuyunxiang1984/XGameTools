require "FreakPlanet/View/ReviewConfirmPanel"

local class = require "FreakPlanet/Utils/middleclass"
ReviewConfirmCtrl  = class(CtrlNames.ReviewConfirm, BaseCtrl)

-- load the ui prefab
function ReviewConfirmCtrl:LoadPanel()
	self:CreatePanel("ReviewConfirm")
end

-- construct ui panel data
function ReviewConfirmCtrl:ConstructUI(obj)
	self._ui = ReviewConfirmPanel.Init(obj)
end

-- fill ui with the data
function ReviewConfirmCtrl:SetupUI()
    CtrlManager.AddClick(self, self._ui.ButtonCancel)
    CtrlManager.AddClick(self, self._ui.ButtonConfirm)
end

-- on clicked
function ReviewConfirmCtrl:OnClicked(go)

    if go == self._ui.ButtonCancel then
        SoundSystem.PlayUICancelSound()
        CtrlManager.PopPanel()
    elseif go == self._ui.ButtonConfirm then
        SoundSystem.PlayUIClickSound()
        GameData.FinishReview()
        Game.OpenReview()
        CtrlManager.PopPanel()
    end

	return true
end
