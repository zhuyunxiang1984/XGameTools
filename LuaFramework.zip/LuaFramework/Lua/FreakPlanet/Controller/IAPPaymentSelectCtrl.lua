require "FreakPlanet/View/IAPPaymentSelectPanel"

local class = require "FreakPlanet/Utils/middleclass"
IAPPaymentSelectCtrl  = class(CtrlNames.IAPPaymentSelect, BaseCtrl)

-- load the ui prefab
function IAPPaymentSelectCtrl:LoadPanel()
	self:CreatePanel("IAPPaymentSelect")
end

-- construct ui panel data
function IAPPaymentSelectCtrl:ConstructUI(obj)
	self._ui = IAPPaymentSelectPanel.Init(obj)
end

-- fill ui with the data
function IAPPaymentSelectCtrl:SetupUI()
	CtrlManager.AddClick(self, self._ui.Blocker)
	CtrlManager.AddClick(self, self._ui.ButtonZhifubao)
	CtrlManager.AddClick(self, self._ui.ButtonWeixin)
end

-- on clicked
function IAPPaymentSelectCtrl:OnClicked(go)
	
	if go == self._ui.Blocker then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
	elseif go == self._ui.ButtonZhifubao then
		SoundSystem.PlayUIClickSound()
		self._parameter.callback(self._parameter.receiver, PaymentType.Zhifubao)
		CtrlManager.PopPanel()
	elseif go == self._ui.ButtonWeixin then
		SoundSystem.PlayUIClickSound()
		self._parameter.callback(self._parameter.receiver, PaymentType.Weixin)
		CtrlManager.PopPanel()
	end

	return true
end
