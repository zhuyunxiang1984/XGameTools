require "FreakPlanet/View/GoalDialogPanel"

local class = require "FreakPlanet/Utils/middleclass"
local utf8 = require "FreakPlanet/Utils/Utf8"
GoalDialogCtrl  = class(CtrlNames.GoalDialog, BaseCtrl)

local PRESSED_SKIP_TIME = 1.0 --长按1.0秒执行跳过

-- load the ui prefab
function GoalDialogCtrl:LoadPanel()
	self:CreatePanel("GoalDialog")
end

-- construct ui panel data
function GoalDialogCtrl:ConstructUI(obj)
	self._ui = GoalDialogPanel.Init(obj)
end

-- destroy implementation
function GoalDialogCtrl:DestroyImpl()
	if self._typewriterFinishHandle ~= nil then
		GlobalScheduler:Cancel(self._typewriterFinishHandle)
		self._typewriterFinishHandle = nil
	end
end

-- fill ui with the data
function GoalDialogCtrl:SetupUI()
	self._currentSpeechIdx = 1
	self._typewriterFinishHandle = nil

	self._IsPressSkip = false
	self._PressSkipTimeCounter = 0
	self:_UpdateSkipMask(0)

	self:OnSpeechIndexChanged()
	CtrlManager.AddClick(self, self._ui.Blocker)
	--CtrlManager.AddClick(self, self._ui.ButtonSkip)
	CtrlManager.AddPress(self, self._ui.ButtonSkip)
end

function GoalDialogCtrl:UpdateImpl(deltaTime)
	if self._IsPressSkip then
		self._PressSkipTimeCounter = self._PressSkipTimeCounter + deltaTime

		if self._PressSkipTimeCounter >= PRESSED_SKIP_TIME then
			SoundSystem.PlayUICancelSound()
			self:Finish()
			self._IsPressSkip = false
			self:_UpdateSkipMask(0)
		else
			self:_UpdateSkipMask(self._PressSkipTimeCounter / PRESSED_SKIP_TIME)
		end
	end
end

-- on clicked
function GoalDialogCtrl:OnClicked(go)
	if go == self._ui.Blocker then
		if self._typewriterFinishHandle == nil then
			local nextSpeechId = ConfigUtils.GetNextGoalDialog(self._currentSpeechId)
			if nextSpeechId == nil then
				if self._currentSpeechIdx >= #self._parameter.goalSpeechList then
					SoundSystem.PlayUICancelSound()
					self:Finish()
				else
					SoundSystem.PlayUIClickSound()
					self._currentSpeechIdx = self._currentSpeechIdx + 1
					self:OnSpeechIndexChanged()
				end
			else
				SoundSystem.PlayUIClickSound()
				self._currentSpeechId = nextSpeechId
				self:OnCurrentSpeechChanged()
			end
		else
			SoundSystem.PlayUIClickSound()
			GlobalScheduler:Cancel(self._typewriterFinishHandle)
			self._typewriterFinishHandle = nil
			self._ui.MessageTypeWriter:Finish()
		end
	end

	return true
end

function GoalDialogCtrl:OnPressed(go, pressed, isLong)
	if go == self._ui.ButtonSkip and not isLong then
		--XDebug.Log('GGYY', "press skip " .. tostring(pressed) .. " " .. tostring(isLong))
		if pressed then
			self._PressSkipTimeCounter = 0
		end
		self._IsPressSkip = pressed
		self:_UpdateSkipMask(0)
		return
	end
end

function GoalDialogCtrl:Finish()
	CtrlManager.ClosePanel(CtrlNames.GoalDialog)

	if self._parameter.callback ~= nil then
		self._parameter.callback(self._parameter.reciver)
	end

	NewItemCtrl.ShowNewItemList(self._parameter.rewards)
end

function GoalDialogCtrl:OnSpeechIndexChanged()
	self._currentSpeechId = self._parameter.goalSpeechList[self._currentSpeechIdx]
	self:OnCurrentSpeechChanged()
end

function GoalDialogCtrl:OnCurrentSpeechChanged()
	local name, text, isLeft, iconName, iconAtlas, iconBundle = ConfigUtils.GetGoalDialogShowInfo(self._currentSpeechId)
	local showMessage = SAFE_LOC(text)
	self._ui.MessageTypeWriter:Finish()
	self._ui.Message.text = showMessage
	self._ui.MessageTypeWriter:ResetToBeginning()
	self._typewriterFinishHandle = GlobalScheduler:DoActionAfterTime(utf8.len(showMessage) / self._ui.MessageTypeWriter.charsPerSecond, GoalDialogCtrl.UnlockClick, self)

	self._ui.LeftRoot:SetActive(isLeft)
	self._ui.RightRoot:SetActive(not isLeft)

	if isLeft then
		self:SetIconWithAtlas(self._ui.LeftIcon, iconName, iconAtlas)
		self._ui.LeftName.text = name
	else
		self:SetIconWithAtlas(self._ui.RightIcon, iconName, iconAtlas)
		self._ui.RightName.text = name
	end
end

function GoalDialogCtrl:UnlockClick()
	self._typewriterFinishHandle = nil
end

function GoalDialogCtrl:_UpdateSkipMask(percent)
	self._ui.ButtonSkipMask.fillAmount = math.Clamp01(percent)
end