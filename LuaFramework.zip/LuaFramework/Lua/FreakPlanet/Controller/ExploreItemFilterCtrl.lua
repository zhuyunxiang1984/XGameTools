require "FreakPlanet/View/ExploreItemFilterPanel"

local class = require "FreakPlanet/Utils/middleclass"
ExploreItemFilterCtrl  = class(CtrlNames.ExploreItemFilter, BaseCtrl)

local SELECTED_COLOR = Color.New(1, 206 / 255, 37 / 255, 1)
local UNSELECTED_COLOR = Color.New(44 / 255, 48 / 255, 70 / 255, 1)

-- load the ui prefab
function ExploreItemFilterCtrl:LoadPanel()
	self:CreatePanel("ExploreItemFilter")
end

-- construct ui panel data
function ExploreItemFilterCtrl:ConstructUI(obj)
	self._ui = ExploreItemFilterPanel.Init(obj)
end

-- fill ui with the data
function ExploreItemFilterCtrl:SetupUI()
    self._filterSkills = self._parameter.filterSkills
    self._dirty = false

    self:ConstructSkillItems()
    self:RefreshMatchNum()

	for k, v in pairs(self._ui.SkillItems) do
        CtrlManager.AddClick(self, v.item)
    end

    CtrlManager.AddClick(self, self._ui.Blocker)
end

function ExploreItemFilterCtrl:IsSkillSelected(skillName)
    if Helper.IsEmpty(self._filterSkills) then
        return false
    end

    return self._filterSkills[skillName] ~= nil
end

function ExploreItemFilterCtrl:ConstructSkillItems()
    for k, _ in pairs(self._ui.SkillItems) do
        self:RefreshSkillItem(k)
    end
end

function ExploreItemFilterCtrl:RefreshSkillItem(skillName)
    local v = self._ui.SkillItems[skillName]
    if v == nil then
        return
    end

    local selected = self:IsSkillSelected(skillName)
    if selected then
        v.sprite.color = SELECTED_COLOR
    else
        v.sprite.color = UNSELECTED_COLOR
    end
end

function ExploreItemFilterCtrl:RefreshMatchNum()
    local callback = self._parameter.numCallback
    local receiver = self._parameter.receiver

    local num = callback(receiver, {
        filterSkills = self._filterSkills,
    })

    self._ui.MatchResult.text = string.format(SAFE_LOC("满足条件数量：%d"), num)
end

function ExploreItemFilterCtrl:CheckFilter(itemId, filters)
    if filters == nil then
        filters = {}
        filters[itemId] = 1
    else
        if filters[itemId] == nil then
            filters[itemId] = 1
        else
            filters[itemId] = nil
            if Helper.IsEmpty(filters) then
                filters = nil
            end
        end
    end

    return filters
end

-- on clicked
function ExploreItemFilterCtrl:OnClicked(go)

    if go == self._ui.Blocker then
        SoundSystem.PlayUICancelSound()
        CtrlManager.PopPanel()
        if self._dirty then
            -- notify final filter
            local callback = self._parameter.resultCallback
            local receiver = self._parameter.receiver
            callback(receiver, { filterSkills = self._filterSkills, })
        end
    else
        local skillName = go.name
        if self._ui.SkillItems[skillName] ~= nil then
            SoundSystem.PlayUIClickSound()
            self._filterSkills = self:CheckFilter(skillName, self._filterSkills)
            self:RefreshSkillItem(skillName)
            self:RefreshMatchNum()
            self._dirty = true
        end
    end

	return true
end

-- handle the escapse button
function ExploreItemFilterCtrl:HandleEscape()
    self:OnClicked(self._ui.Blocker)
end
