require 'FreakPlanet/View/CharacterListPanel'

local class = require 'FreakPlanet/Utils/middleclass'
CharacterListCtrl = class(CtrlNames.CharacterList, BaseCtrl)

--------------------------------------------------------------------
local _sortAbilityId = nil
local _sortPower = false
local _filterElements = nil
local _filterRarities = nil
local _filterTags = nil
local _filterStages = nil
local _filterSkills = nil
local _filterName = nil

local _characterMatchGoalMap = nil
local _characterAbilityMap = nil

-- 皮肤拖动效果阈值数
local DRAG_SKIN_LIMIT_COUNT = 3
--
local DRAG_SKIN_TOTAL_COUNT = 4

local MOVE_ANIMATION_TIME = 0.5
-------------------------


local function CharacterSortFunc(idA, idB)
    if idA == nil or idB == nil then
        return false
    end

    local goalNeedA = _characterMatchGoalMap[idA] or false
    local goalNeedB = _characterMatchGoalMap[idB] or false
    if goalNeedA ~= goalNeedB then
        return goalNeedA
    end

    local markedA = GameData.IsItemMarked(idA)
    local markedB = GameData.IsItemMarked(idB)
    if markedA ~= markedB then
        return markedA
    end

    local valueA = 0
    local valueB = 0

    if _sortAbilityId ~= nil then
        local abilityMapA = _characterAbilityMap[idA] or {}
        local abilityMapB = _characterAbilityMap[idB] or {}
        valueA = abilityMapA[_sortAbilityId] or 0
        valueB = abilityMapB[_sortAbilityId] or 0
    elseif _sortPower then
        local abilityMapA = _characterAbilityMap[idA] or {}
        local abilityMapB = _characterAbilityMap[idB] or {}
        valueA = ConfigUtils.GetPowerOfAbilityMap(abilityMapA)
        valueB = ConfigUtils.GetPowerOfAbilityMap(abilityMapB)
    end

    if valueA == valueB then
        valueA = ConfigUtils.GetCharacterRarity(idA)
        valueB = ConfigUtils.GetCharacterRarity(idB)
    end

    if valueA == valueB then
        valueA = GameData.GetCharacterLevel(idA)
        valueB = GameData.GetCharacterLevel(idB)
    end

    if valueA == valueB then
        valueA = ConfigUtils.GetCharacterSortId(idA)
        valueB = ConfigUtils.GetCharacterSortId(idB)
    end

    return valueA > valueB
end

--------------------------------------------------------------------
-- load the ui prefab
function CharacterListCtrl:LoadPanel()
    self:CreatePanel('CharacterList')

    self:PreloadBundle("packedtexture_furniture")
    self:PreloadBundle("packedtexture_furniture2")
end

-- construct ui panel data
function CharacterListCtrl:ConstructUI(obj)
    self._SkinItemPool = {}
    self._dragPosition = nil
    self._dragSkinsItem = {}
    self._moveState = {}
    self._IsMoving = false

	self:DynamicLoadBundle(Const.Room3TextureBundleName)
    self._ui = CharacterListPanel.Init(obj)
end

-- notity it has been focused
function CharacterListCtrl:NotifyFocus()
    self:ConstructCharacterHint()
    self:ConstructEquipments()
    --self:ConstructSkinsUI()
    self:RefreshSkinsUI()

    if self._dirty then
        self._ui.CharacterGridWrap:ForceUpdateItems()
        self._dirty = false
    end
end

-- destructor
function CharacterListCtrl:DestroyImpl()
    GameData.CheckItemsOfType(ItemType.Character)

    GameNotifier.RemoveListener(GameEvent.ItemNumChanged, CharacterListCtrl.OnItemNumChanged, self)
    GameNotifier.RemoveListener(GameEvent.MarkStateChanged, CharacterListCtrl.OnMarkStateChanged, self)
    GameNotifier.RemoveListener(GameEvent.CharacterSkinChanged, CharacterListCtrl.OnCharacterSkinChanged, self)
    GameNotifier.RemoveListener(GameEvent.CharacterStageChanged, CharacterListCtrl.OnCharacterStageChanged, self)
    GameNotifier.RemoveListener(GameEvent.CharacterLevelChanged, CharacterListCtrl.OnCharacterLevelChanged, self)
    GameNotifier.RemoveListener(GameEvent.CharacterEquipmentUpgraded, CharacterListCtrl.OnCharacterEquipmentUpgraded, self)
    GameNotifier.RemoveListener(GameEvent.CharacterAppearanceChanged, CharacterListCtrl.OnCharacterAppearanceChanged, self)
end

-- fill ui with the data
function CharacterListCtrl:SetupUI()
    self._currentMode = ExploreSelectionMode.Character
    self._fullCharacterList = GameData.GetUnlockCharacters()
    self._characterPrefab = self:DynamicLoadAsset(nil, 'CharacterItem')
    self._ui.CharacterGridWrap.OnItemUpdate = CharacterListCtrl.OnItemUpdateGlobal
    -- filter default state
    _sortAbilityId = nil
    _sortPower = false
    _filterElements = nil
    _filterRarities = nil
    _filterTags = nil
    _filterStages = nil
    _filterSkills = nil
    _filterName = nil

    self._filterOn = false
    self._ui.FilterRoot.gameObject:SetActive(false)
    self._ui.CharacterAvatarHintAnimator.gameObject:SetActive(false)
    self._dirty = false
    self._showCharacterDesc = false
    self._skinItemWidth = self._ui.SkinItemTemplate:GetComponent("BoxCollider").size.x
    XDebug.Log("LZ", "self._skinItemWidth:", self._skinItemWidth)

    self:ConstructCharacterGoalAndAbilityMap()
    self:RefreshCharacterList()
    assert(#self._characterList > 0, 'should at least have one character')
    -- character grid
    self:SetupCharacterGrid()
    -- selected character
    local characterId = self._parameter.characterId
    if characterId == nil then
        characterId = self._characterList[1] 
    end
    self:ChangeSelectedCharacter(characterId)
    self:OnFilterChanged()
    self:HideAvatarHint()
    -- buttons
    CtrlManager.AddClick(self, self._ui.ButtonClose)
    CtrlManager.AddClick(self, self._ui.ButtonFilter)
    CtrlManager.AddClick(self, self._ui.ButtonRoom)
    CtrlManager.AddClick(self, self._ui.CharacterCollider)
    CtrlManager.AddClick(self, self._ui.FilterPower)
    CtrlManager.AddClick(self, self._ui.ButtonShowSkillDesc.gameObject)
    CtrlManager.AddClick(self, self._ui.ButtonShowCharacterDesc.gameObject)
    CtrlManager.AddClick(self, self._ui.ButtonFilterDetail)
    CtrlManager.AddClick(self, self._ui.ButtonChangeAppearance)
    CtrlManager.AddClick(self, self._ui.SkinLeftArrow)
    CtrlManager.AddClick(self, self._ui.SkinRightArrow)
    -- equipment
    for k, v in pairs(self._ui.CharacterEquipments) do
        CtrlManager.AddClick(self, v.item)
    end
    -- skin
    --[[for k, v in pairs(self._ui.CharacterSkins) do
        CtrlManager.AddClick(self, v.item)
    end--]]
    -- filter element
    for k, v in pairs(self._ui.FilterElements) do
        CtrlManager.AddClick(self, v.item)
    end
    -- filter ability
    for k, v in pairs(self._ui.FilterAbilities) do
        CtrlManager.AddClick(self, v.item)
    end

    GameNotifier.AddListener(GameEvent.ItemNumChanged, CharacterListCtrl.OnItemNumChanged, self)
    GameNotifier.AddListener(GameEvent.MarkStateChanged, CharacterListCtrl.OnMarkStateChanged, self)
    GameNotifier.AddListener(GameEvent.CharacterSkinChanged, CharacterListCtrl.OnCharacterSkinChanged, self)
    GameNotifier.AddListener(GameEvent.CharacterStageChanged, CharacterListCtrl.OnCharacterStageChanged, self)
    GameNotifier.AddListener(GameEvent.CharacterLevelChanged, CharacterListCtrl.OnCharacterLevelChanged, self)
    GameNotifier.AddListener(GameEvent.CharacterEquipmentUpgraded, CharacterListCtrl.OnCharacterEquipmentUpgraded, self)
    GameNotifier.AddListener(GameEvent.CharacterAppearanceChanged, CharacterListCtrl.OnCharacterAppearanceChanged, self)

    self:CheckTutorial()
end

function CharacterListCtrl:ConstructCharacterGoalAndAbilityMap()
    _characterMatchGoalMap = {}
    _characterAbilityMap = {}
    for idx = 1, #self._fullCharacterList do
        local characterId = self._fullCharacterList[idx]
        _characterMatchGoalMap[characterId] = JumpManager.MatchCharacterInCharacterList(characterId)
        _characterAbilityMap[characterId] = GameData.GetCharacterAbilityMap(characterId)
    end
end

function CharacterListCtrl:RefreshAbilityMapOfCharacter(characterId)
    _characterAbilityMap[characterId] = GameData.GetCharacterAbilityMap(characterId)
end

function CharacterListCtrl:ShowAvatarHint()
    self._avatarShowTime = 3
    self._ui.CharacterAvatarHintAnimator.gameObject:SetActive(true)
    self._hintDelay = nil
end

function CharacterListCtrl:HideAvatarHint()
    self._avatarShowTime = nil
    self._ui.CharacterAvatarHintAnimator.gameObject:SetActive(false)
    self._hintDelay = Helper.RandFloat(3, 6)
end

function CharacterListCtrl:UpdateImpl(deltaTime)
    if self._hintDelay ~= nil then
        self._hintDelay = self._hintDelay - deltaTime
        if self._hintDelay <= 0 then
            self:ShowAvatarHint()
        end
    end

    if self._avatarShowTime ~= nil then
        self._avatarShowTime = self._avatarShowTime - deltaTime
        if self._avatarShowTime <= 0 then
            self:HideAvatarHint()
        end
    end
    if self._dirty then
        self._ui.CharacterGridWrap:ForceUpdateItems()
        self._dirty = false
    end
end

--- get character list
function CharacterListCtrl:RefreshCharacterList()
    self._characterList = {}
    local characterList = GameData.GetUnlockCharacters()
    for idx = 1, #characterList do
        local characterId = characterList[idx]
        if ConfigUtils.IsItemMatchFilter(characterId, _filterName, _filterElements, _filterRarities, _filterTags, _filterStages, _filterSkills) then
            table.insert(self._characterList, characterId)
        end
    end

end

function CharacterListCtrl:SetupCharacterGrid()
    -- sort
    table.sort(self._characterList, CharacterSortFunc)

    local itemCount = self._ui.CharacterGridWrap.NeedCellCount
    itemCount = math.min(#self._characterList, itemCount)
    self._ui.CharacterGridWrap.MaxRow = math.ceil(#self._characterList / self._ui.CharacterGridWrap.ColumnLimit)

    -- move the items to pool
    for idx = self._ui.CharacterGrid.childCount, 1, -1 do
        local characterItem = self._ui.CharacterGrid:GetChild(idx - 1)
        characterItem.parent = self._ui.CharacterItemPool
    end

    local characterItem = nil
    for idx = 1, itemCount do
        local characterId = self._characterList[idx]
        if self._ui.CharacterItemPool.childCount == 0 then
            local itemObj = Helper.NewObject(self._characterPrefab, self._ui.CharacterGrid)
            CtrlManager.AddClick(self, itemObj)
            CtrlManager.AddPress(self, itemObj)
            characterItem = itemObj.transform
        else
            characterItem = self._ui.CharacterItemPool:GetChild(0)
            characterItem.parent = self._ui.CharacterGrid
        end

        characterItem.gameObject:SetActive(true)
        characterItem.gameObject.name = tostring(characterId)

        -- construct item
        self:ConstructCharacterItem(characterItem, characterId)
    end

    self._ui.CharacterGridWrap:SortBasedOnScrollMovement()
    self._ui.CharacterScrollView.restrictWithinPanel = true
    self._ui.CharacterScrollView.disableDragIfFits = (#self._characterList <= itemCount)
    self._ui.CharacterScrollView:ResetPosition()
end

function CharacterListCtrl:ConstructCharacterItem(item, characterId)
    local abilityMap = _characterAbilityMap[characterId] or {}
    UIHelper.ConstructCharacterItem(self, item, characterId, abilityMap, _sortAbilityId, _sortPower)
    -- selected
    local selected = (characterId == self._selectedCharacterId)
    self:ToggleCharacterItemSelectedState(item, characterId, selected)
    -- new
    local isNew = GameData.IsItemNew(characterId)
    self:ToggleCharacterItemNewState(item, characterId, isNew)
    -- goal
    local goalNeed = _characterMatchGoalMap[characterId] or false
    self:ToggleCharacterItemGoalState(item, characterId, goalNeed)
    -- promote
    local canPromote = GameData.IsCharacterPromoteMatch(characterId)
    self:ToggleCharacterItemPromoteState(item, characterId, canPromote)
    -- marked
    local marked = GameData.IsItemMarked(characterId)
    local markedMark = item:Find('Mark/Marked').gameObject
    markedMark:SetActive(marked)
end

function CharacterListCtrl:ToggleCharacterItemSelectedState(characterItem, characterId, selected)
    if characterItem == nil and characterId ~= nil then
        characterItem = self._ui.CharacterGrid:Find(characterId)
    end

    if characterItem ~= nil then
        local selectedMark = characterItem:Find('Mark/Select').gameObject
        selectedMark:SetActive(selected)
    end
end

function CharacterListCtrl:ToggleCharacterItemNewState(characterItem, characterId, isNew)
    if characterItem == nil and characterId ~= nil then
        characterItem = self._ui.CharacterGrid:Find(characterId)
    end

    if characterItem ~= nil then
        local newMark = characterItem:Find('Mark/New').gameObject
        newMark:SetActive(isNew)
    end
end

function CharacterListCtrl:ToggleCharacterItemGoalState(characterItem, characterId, goalNeed)
    if characterItem == nil and characterId ~= nil then
        characterItem = self._ui.CharacterGrid:Find(characterId)
    end

    if characterItem ~= nil then
        local goalMark = characterItem:Find('Mark/Goal').gameObject
        goalMark:SetActive(goalNeed)
    end
end

function CharacterListCtrl:ToggleCharacterItemPromoteState(characterItem, characterId, canPromote)
    if characterItem == nil and characterId ~= nil then
        characterItem = self._ui.CharacterGrid:Find(characterId)
    end

    if characterItem ~= nil then
        local promoteMark = characterItem:Find('Mark/Promote').gameObject
        promoteMark:SetActive(canPromote)
    end
end

function CharacterListCtrl:CheckItem(characterId)
    GameData.CheckItem(characterId)
    self:ToggleCharacterItemNewState(nil, characterId, false)
end

function CharacterListCtrl:ChangeSelectedCharacter(characterId)
    if self._selectedCharacterId ~= nil then
        self:ToggleCharacterItemSelectedState(nil, self._selectedCharacterId, false)
    end

    self._selectedCharacterId = characterId
    self:OnSelectedCharacterChanged()

    if self._selectedCharacterId ~= nil then
        self:ToggleCharacterItemSelectedState(nil, self._selectedCharacterId, true)
    end
end

function CharacterListCtrl:OnSelectedCharacterChanged()
    -- hint
    self:ConstructCharacterHint()
    -- avatar
    self:ConstructCharacterAvatar()
    -- equipments
    self:ConstructEquipments()
    -- skins
    self:ConstructSkinsUI()
    -- skill or character desc
    self:ConstructSkillsOrCharacterDesc()
    -- stages
    self:ConstructStages()
    -- room
    self:ConstructRoom()
end

function CharacterListCtrl:ConstructCharacterHint()
    local characterId = self._selectedCharacterId
    local matchGoal = JumpManager.MatchCharacterOfUpgradeGoal(characterId) or GameData.IsCharacterPromoteMatch(characterId)
    self._ui.CharacterGoalHint:SetActive(matchGoal)
end

function CharacterListCtrl:ConstructCharacterAvatar()
    -- collect to the pool first
    if self._ui.CharacterAvatar.childCount > 0 then
        local item = self._ui.CharacterAvatar:GetChild(0)
        item.parent = self._ui.CharacterAvatarPool
    end

    local avatarItem = self._ui.CharacterAvatarPool:Find(self._selectedCharacterId)
    if avatarItem == nil then
        local prefabName, prefabBundle = ConfigUtils.GetCharacterPrefab(self._selectedCharacterId)
        local prefab = self:DynamicLoadAsset(prefabBundle, prefabName)
        local itemObj = Helper.NewObject(prefab, self._ui.CharacterAvatar, 70)
        itemObj.name = tostring(self._selectedCharacterId)
        avatarItem = itemObj.transform
        -- change the sort order as in planet panel its top panel sort order is 5
        local renderer = itemObj:GetComponent('MeshRenderer')
        renderer.sortingOrder = 8
    else
        avatarItem.parent = self._ui.CharacterAvatar
        avatarItem.localPosition = Vector3.zero
    end

    local skeletonAnimation = avatarItem:GetComponent('SkeletonAnimation')
    -- animation
    Helper.PlayAnimation(skeletonAnimation, CharacterAnimations.Sitting, true)
    -- skin
    UIHelper.SetCharacterSkin(skeletonAnimation, self._selectedCharacterId)
    
end

function CharacterListCtrl:ConstructCharacterAvatarAppearance(characterId, appearanceId)
    local avatarItem = self._ui.CharacterAvatar:Find(characterId)
    if not avatarItem then
        return
    end
    local skeletonAnimation = avatarItem:GetComponent('SkeletonAnimation')
    UIHelper.SetCharacterSkinWithSkin(skeletonAnimation, appearanceId)
end

function CharacterListCtrl:ConstructEquipments()
    local characterId = self._selectedCharacterId
    local equipmentList = GameData.GetCharacterEquipments(characterId)

    for idx = 1, #self._ui.CharacterEquipments do
        local hasEquipment = (idx <= #equipmentList)
        self._ui.CharacterEquipments[idx].item:SetActive(hasEquipment)

        if hasEquipment then
            local equipmentId = equipmentList[idx].id
            local equipmentLevel = equipmentList[idx].level
            local unlockChallenge = ConfigUtils.GetEquipmentUnlockChallenge(equipmentId)
            local equipmentUnlocked = (unlockChallenge == nil or GameData.IsChallengeCompleted(unlockChallenge))
            -- lock mark
            self._ui.CharacterEquipments[idx].lock:SetActive(not equipmentUnlocked)
            -- icon
            UIHelper.SetEquipmentIcon(self, self._ui.CharacterEquipments[idx].icon, equipmentId, equipmentLevel)
            -- name
            self._ui.CharacterEquipments[idx].name.text = ConfigUtils.GetEquipmentName(equipmentId, equipmentLevel)
            -- color and hint
            if not equipmentUnlocked then
                self._ui.CharacterEquipments[idx].icon.color = LOCK_ICON_COLOR
                self._ui.CharacterEquipments[idx].hint:SetActive(false)
            else
                self._ui.CharacterEquipments[idx].icon.color = Color.white
                local showEquipmentHint = GameData.IsEquipmentUpgradeMatch(equipmentId, equipmentLevel)
                self._ui.CharacterEquipments[idx].hint:SetActive(showEquipmentHint)
            end
            -- goal
            local matchGoal = JumpManager.MatchEquipmentGoal(equipmentId)
            self._ui.CharacterEquipments[idx].goal:SetActive(matchGoal)
        end
    end
end

function CharacterListCtrl:GetOrCreateSkinItem()
    local obj = nil
    if #self._SkinItemPool >0 then
        obj = self._SkinItemPool[#self._SkinItemPool]
        table.remove(self._SkinItemPool, #self._SkinItemPool)
    else
        obj = Helper.NewObject(self._ui.SkinItemTemplate, self._ui.SkinPool)
        CtrlManager.AddPress(self, obj)
        CtrlManager.AddClick(self, obj)
    end
    return obj
end

function CharacterListCtrl:RecycleSkinItem()
    for idx = self._ui.SkinParent.childCount, 1, -1 do
        local item = self._ui.SkinParent:GetChild(idx - 1)
        item.gameObject:SetActive(false)
        item:SetParent(self._ui.SkinPool)
        table.insert(self._SkinItemPool, item.gameObject)
    end
end

function CharacterListCtrl:RefreshSkinArrow()
    local isVaildDrag = #self._skinList <= DRAG_SKIN_LIMIT_COUNT
    if not isVaildDrag then
        self._ui.SkinLeftArrow:SetActive(self:IsValidSkinDrag(1))
        self._ui.SkinRightArrow:SetActive(self:IsValidSkinDrag(-1))
    else
        self._ui.SkinLeftArrow:SetActive(not isVaildDrag)
        self._ui.SkinRightArrow:SetActive(not isVaildDrag)
    end
end

function CharacterListCtrl:ConstructSkinsUI()
    local ui = self._ui
    local characterId = self._selectedCharacterId
    ui.SkinParent.gameObject:SetActive(false)
    local skinList = ConfigUtils.GetCharacterSkinList(characterId)
    self._skinList = skinList
    local skinCount = #skinList
    self:RecycleSkinItem()
    local isVaildDrag = skinCount <= DRAG_SKIN_LIMIT_COUNT

    local showNum = isVaildDrag and DRAG_SKIN_LIMIT_COUNT or skinCount
    for idx = 1, showNum do
        local skinItem = self:GetOrCreateSkinItem()
        skinItem:SetActive(true)
        skinItem.transform:SetParent(ui.SkinParent)
        skinItem.transform.localScale = Vector3.New(0.9, 0.9, 1)
        if idx <= skinCount then
            skinItem.name = tostring(skinList[idx])
        else
            skinItem.name = tostring(INVALID_ID)
        end
        UIHelper.SetHorizontalItemPosition(skinItem.transform, idx, self._skinItemWidth, -self._skinItemWidth)
        UIHelper.ConstructCharacterSkinItem(self, skinItem.transform, skinList[idx], idx <= skinCount)
    end
    self:RefreshSkinArrow()
    -- 先关闭再打开，为了让UIPanel的裁剪功能正常
    ui.SkinParent.gameObject:SetActive(true)
end

function CharacterListCtrl:RefreshSkinsUI()
    for idx = 1, self._ui.SkinParent.childCount do
        local child = self._ui.SkinParent:GetChild(idx - 1)
        UIHelper.ConstructCharacterSkinItem(self, child, self._skinList[idx], idx <= #self._skinList)
    end
end

function CharacterListCtrl:ConstructSkillDesc()
    local characterId = self._selectedCharacterId
    local hasSkill = ConfigUtils.IsCharacterHasSkill(characterId)

    if hasSkill then
        local curStage = GameData.GetCharacterCurrentStage(characterId)
        local activatedSkillDesc = ConfigUtils.GetCharacterSkillDescAt(characterId, curStage)
        local skillActivated = (activatedSkillDesc ~= nil)

        if skillActivated then
            local skillText = "[6DFFFFFF]"..activatedSkillDesc.."[-] [48FF00FF]"..SAFE_LOC("loc_Activated").."[-]"
            self._ui.CharacterDesc.text = skillText
        else
            local nextActivatedSkillDesc = ConfigUtils.GetCharacterNextSkillDescAt(characterId, curStage)
            local skillText = "[714747FF]"..nextActivatedSkillDesc.."[-] [FF0000FF]"..SAFE_LOC("loc_NotActivated").."[-]"
            self._ui.CharacterDesc.text = skillText
        end
    else
        self._ui.CharacterDesc.text = "[A6B4D8FF]"..SAFE_LOC("loc_CharacterNoSkill").."[-]"
    end
end

function CharacterListCtrl:ConstructCharacterDesc()
    local characterId = self._selectedCharacterId
    local characterDesc = ConfigUtils.GetCharacterDesc(characterId) 
    self._ui.CharacterDesc.text = "[714747FF]"..characterDesc.."[-] [FF0000FF]"
end

function CharacterListCtrl:ConstructSkillsOrCharacterDesc()
    if  self._showCharacterDesc then
        self:ConstructCharacterDesc()
    else
        self:ConstructSkillDesc()
    end

    self:RefreshShowDescButtonState()
end

function CharacterListCtrl:RefreshShowDescButtonState()
    self:SetShowDescButtonState(self._ui.ButtonShowSkillDesc,  self._showCharacterDesc)
    self:SetShowDescButtonState(self._ui.ButtonShowCharacterDesc, not self._showCharacterDesc)
end

function CharacterListCtrl:SetShowDescButtonState(button, enabled)
    button.isEnabled = enabled
end

function CharacterListCtrl:ConstructStages()
    local curStage = GameData.GetCharacterCurrentStage(self._selectedCharacterId)
    local maxStage = ConfigUtils.GetCharacterStageLimit(self._selectedCharacterId)

    for idx = 1, #self._ui.CharacterStages do
        local hasStage = (idx <= maxStage)
        self._ui.CharacterStages[idx].item:SetActive(hasStage)
        if hasStage then
            local stageActivated = (idx <= curStage)

            local stageColor = Color.black
            if stageActivated then
                stageColor = Color.white
            end
            self._ui.CharacterStages[idx].icon.color = stageColor
        end
    end
end

function CharacterListCtrl:ConstructRoom()
    for idx = self._ui.CharacterRoomRoot.childCount, 1, -1 do
        local roomItem = self._ui.CharacterRoomRoot:GetChild(idx - 1)
        roomItem.parent = self._ui.CharacterRoomPool
    end

    local isDefaultRoom = false
    local roomPrefabName = ConfigUtils.GetCharacterRoom(self._selectedCharacterId)
    if roomPrefabName == nil then
        roomPrefabName = ConfigUtils.GetDefaultRoomName()
        isDefaultRoom = true
    end

    local roomItem = self._ui.CharacterRoomPool:Find(roomPrefabName)
    if roomItem == nil then
        local roomItemPrefab = self:DynamicLoadAsset(Const.RoomBundleName, roomPrefabName)
        local roomItemObj = Helper.NewObject(roomItemPrefab, self._ui.CharacterRoomRoot)
        roomItemObj.name = roomPrefabName
        roomItemObj:SetActive(true)
        roomItem = roomItemObj.transform
    else
        roomItem.parent = self._ui.CharacterRoomRoot
        roomItem.localScale = Vector3.one
        roomItem.localPosition = Vector3.zero
    end

    if not isDefaultRoom then
        local roomPieces = ConfigUtils.GetRoomPieces(roomPrefabName)
        for k, roomPieceId in pairs(roomPieces) do
            local nodeName = ConfigUtils.GetRoomPieceNode(roomPieceId)
            if nodeName ~= nil then
                local nodeItem = roomItem:Find(nodeName)
                if nodeItem ~= nil then
                    local unlocked = GameData.IsRoomPieceUnlocked(roomPieceId)
                    local unlockMark = nodeItem:Find("UnLock")
                    if unlockMark ~= nil then
                        unlockMark.gameObject:SetActive(unlocked)
                    end

                    local lockMark = nodeItem:Find("Lock")
                    if lockMark ~= nil then
                        lockMark.gameObject:SetActive(not unlocked)
                    end
                end
            end
        end
    end

    self._ui.ButtonRoom:SetActive(not isDefaultRoom and ConfigUtils.ViewCharacterRoom(self._selectedCharacterId))
end

function CharacterListCtrl:OnItemUpdate(itemObj, itemIndex, itemRealIndex)
    itemRealIndex = itemRealIndex + 1
    if itemRealIndex <= 0 or itemRealIndex > #self._characterList then
        itemObj:SetActive(false)
    else
        itemObj:SetActive(true)
        local itemId = self._characterList[itemRealIndex]
        itemObj.name = itemId
        local characterItem = itemObj.transform
        -- construct item
        self:ConstructCharacterItem(characterItem, itemId)
    end
end

function CharacterListCtrl.OnItemUpdateGlobal(itemObj, itemIndex, itemRealIndex)
    local ctrl = CtrlManager.GetCtrlByName(CtrlNames.CharacterList)
    if ctrl ~= nil then
        ctrl:OnItemUpdate(itemObj, itemIndex, itemRealIndex)
    end
end

function CharacterListCtrl:OnItemNumChanged(itemId, changeNum)
    -- TODO
end

function CharacterListCtrl:OnMarkStateChanged(itemId, marked)
    local itemType = ConfigUtils.GetItemTypeFromId(itemId)
    if itemType == ItemType.Character then
        table.sort(self._characterList, CharacterSortFunc)
        self:SetupCharacterGrid()
    end
end

function CharacterListCtrl:OnCharacterSkinChanged(characterId)
    self:RefreshAbilityMapOfCharacter(characterId)
    if characterId == self._selectedCharacterId then
        self:ConstructCharacterAvatar()
    end
    self._dirty = true
end

function CharacterListCtrl:OnCharacterStageChanged(characterId)
    self:RefreshAbilityMapOfCharacter(characterId)
    if characterId == self._selectedCharacterId then
        self:ConstructStages()
        -- may unlock skills
        self:ConstructSkillsOrCharacterDesc()
    end
    self._dirty = true
end

function CharacterListCtrl:OnCharacterLevelChanged(characterId)
    self:RefreshAbilityMapOfCharacter(characterId)
    self._dirty = true
end

function CharacterListCtrl:OnCharacterEquipmentUpgraded(characterId)
    self:RefreshAbilityMapOfCharacter(characterId)
    self._dirty = true
end

function CharacterListCtrl:OnCharacterAppearanceChanged(characterId)
    local appearanceId = GameData.GetCharacterAppearance(characterId)
    if appearanceId > 0 then
        self:ConstructCharacterAvatarAppearance(characterId, appearanceId)
    else
        self:ConstructCharacterAvatarAppearance(characterId, GameData.GetCharacterSkin(characterId))
    end
    self._dirty = true
end

function CharacterListCtrl:OnFilterChanged()
    for k, v in pairs(self._ui.FilterElements) do
        local unselected = (_filterElements == nil or _filterElements[k] == nil)
        v.selected:SetActive(not unselected)
        v.unselected:SetActive(unselected)
    end

    for k, v in pairs(self._ui.FilterAbilities) do
        local unselected = (_sortAbilityId == nil or _sortAbilityId ~= k)
        v.selected:SetActive(not unselected)
        v.unselected:SetActive(unselected)
    end

    self._ui.FilterPowerSelected:SetActive(_sortPower)
    self._ui.FilterPowerUnselected:SetActive(not _sortPower)

    self:RefreshCharacterList()
    self:SetupCharacterGrid()
end

function CharacterListCtrl:HandleSwitchCharacter(characterId, isNext)
    local totalCount = #self._characterList
    local index = Helper.IndexOfArray(self._characterList, characterId)
    if isNext then
        index = index + 1
        if index > totalCount then
            index = 1
        end
    else
        index = index - 1
        if index < 1 then
            index = totalCount
        end
    end

    local newCharacterId = self._characterList[index]
    if self._selectedCharacterId ~= newCharacterId then
        self:ChangeSelectedCharacter(newCharacterId)
    end
    return newCharacterId
end

-- on clicked
function CharacterListCtrl:OnClicked(go)
    -- buttons
    if go == self._ui.ButtonClose then
        SoundSystem.PlayUICancelSound()
        CtrlManager.PopPanel()
    elseif go == self._ui.CharacterCollider then
        SoundSystem.PlayUIClickSound()
        CtrlManager.OpenPanel(CtrlNames.CharacterUpgrade, {characterId = self._selectedCharacterId, callback = CharacterListCtrl.HandleSwitchCharacter, receiver = self})
    elseif Helper.StartWith(go.name, "Equipment_") then
        SoundSystem.PlayUIClickSound()
        local names = Helper.StringSplit(go.name)
        assert(#names == 2, "invalid equipment item name: "..tostring(go.name))
        local equipIdx = tonumber(names[2])
        CtrlManager.OpenPanel(CtrlNames.CharacterEquipment, {characterId = self._selectedCharacterId, slot = equipIdx, enableChallenge = true})

    elseif go.transform.parent == self._ui.CharacterGrid then
        SoundSystem.PlayUIClickSound()
        local characterId = tonumber(go.name)
        self:CheckItem(characterId)
        if characterId ~= self._selectedCharacterId then
            self:ChangeSelectedCharacter(characterId)
        end
    elseif go == self._ui.ButtonFilter then
        SoundSystem.PlayUIClickSound()
        self._filterOn = not self._filterOn
        self._ui.FilterRoot.gameObject:SetActive(self._filterOn)
    elseif go == self._ui.ButtonRoom then
        SoundSystem.PlayUIClickSound()
        CtrlManager.OpenPanel(CtrlNames.CharacterRoomDetail, {character = self._selectedCharacterId})
    elseif go.transform.parent == self._ui.FilterElementRoot then
        SoundSystem.PlayUIClickSound()
        local elementId = tonumber(go.name)
        if _filterElements == nil then
            _filterElements = {}
            _filterElements[elementId] = 1
        else
            if _filterElements[elementId] == nil then
                _filterElements[elementId] = 1
            else
                _filterElements[elementId] = nil
                if Helper.TableLength(_filterElements) == 0 then
                    _filterElements = nil
                end
            end
        end

        self:RefreshCharacterList()
        self:SetupCharacterGrid()
        self:OnFilterChanged()
    elseif go.transform.parent == self._ui.FilterAbilityRoot then
        SoundSystem.PlayUIClickSound()
        local abilityId = tonumber(go.name)
        if _sortAbilityId == abilityId then
            _sortAbilityId = nil
        else
            _sortAbilityId = abilityId
        end
        _sortPower = false

        self:SetupCharacterGrid()
        self:OnFilterChanged()
    elseif go == self._ui.FilterPower then
        SoundSystem.PlayUIClickSound()
        _sortAbilityId = nil
        _sortPower = not _sortPower
        self:SetupCharacterGrid()
        self:OnFilterChanged()
    elseif go == self._ui.ButtonShowSkillDesc.gameObject then
        SoundSystem.PlaySwitchSound()
        self._showCharacterDesc = false
        self:ConstructSkillsOrCharacterDesc()
    elseif go == self._ui.ButtonShowCharacterDesc.gameObject then
        SoundSystem.PlaySwitchSound()
        self._showCharacterDesc = true
        self:ConstructSkillsOrCharacterDesc()

    elseif go == self._ui.ButtonFilterDetail then
        SoundSystem.PlayUIClickSound()
        --CharacterSelectBaseCtrl.ResetFilterName()

        self:ShowFilterPanel()
    elseif go == self._ui.ButtonChangeAppearance then
        XDebug.Log('GGYY', 'click ButtonChangeAppearance')
        local characterId = self._selectedCharacterId
        CtrlManager.OpenPanel(CtrlNames.CharacterAppearance, {CharacterId = characterId})
    elseif go == self._ui.SkinLeftArrow then
        local dir = 1
        if self:IsValidSkinDrag(dir) and not self._IsMoving then
            self:ShowSkinAnimation(dir)
        end
    elseif go == self._ui.SkinRightArrow then
        local dir = -1
        if self:IsValidSkinDrag(dir) and not self._IsMoving then
            self:ShowSkinAnimation(dir)
        end
    elseif go.transform.parent == self._ui.SkinParent then
        local skinId = tonumber(go.name)
        if ConfigUtils.IsValidItem(skinId) then
            SoundSystem.PlayUIClickSound()
            CtrlManager.OpenPanel(CtrlNames.CharacterSkin, {characterId = self._selectedCharacterId, skinId = skinId, enableChallenge = true})
        end
    end
    return true
end

-- on pressed
function CharacterListCtrl:OnPressed(go, pressed, isLong)
    if pressed and isLong then
        if go.transform.parent == self._ui.CharacterGrid then
            SoundSystem.PlayUIClickSound()
            local characterId = tonumber(go.name)
            CtrlManager.ShowItemDetail({itemId = characterId})
        end
    elseif pressed and not isLong then
        local skinId = tonumber(go.name)
        self._dragSkinId = skinId
        self:StartDrag()
    elseif not pressed and go.transform.parent == self._ui.SkinParent  then
        self:EndDrag()
    end
end

function CharacterListCtrl:UpdateImpl(deltaTime)
    if self._paralleState ~= nil then
        local finished = self._paralleState:Tick(deltaTime)
        if finished then
            self._paralleState = nil
        end
    end
end

function CharacterListCtrl:ShowSkinAnimation(dir)
    --self._moveState = {}
    self._paralleState = ParallelState:new()
    self._IsMoving = true
    for idx = 1, self._ui.SkinParent.childCount do
        local child = self._ui.SkinParent:GetChild(idx - 1)
        local offsetX = child:GetComponent("BoxCollider").size.x
        local initPos = child.localPosition
        local moveState = MoveInXState:new(child, initPos.x + offsetX * dir, offsetX / MOVE_ANIMATION_TIME, nil, nil,nil)
        --moveState:ActionOnExit(CharacterListCtrl.OnDropItemTransformed, self, child)
        --table.insert(self._moveState, moveState)
        self._paralleState:Push(moveState)
    end
    local timeState = TimerState:new(MOVE_ANIMATION_TIME)
    timeState:ActionOnExit(CharacterListCtrl.OnMoveFinished, self)
    self._paralleState:Push(timeState)
end

function CharacterListCtrl:OnMoveFinished()
    self._IsMoving = false
    self:RefreshSkinArrow()
end

function CharacterListCtrl:StartDrag()
    local worldPosition = self._ui.Camera:ScreenToWorldPoint(Input.mousePosition)
    self._dragPosition = self._ui.SkinParent:InverseTransformPoint(worldPosition)
end

function CharacterListCtrl:EndDrag()
    if self._dragPosition then
        local worldPosition = self._ui.Camera:ScreenToWorldPoint(Input.mousePosition)
        local curPos = self._ui.SkinParent:InverseTransformPoint(worldPosition)
        local offsetX = self._dragPosition.x - curPos.x
        -- 超过一定距离认定可拖动
        if math.abs(offsetX) > self._skinItemWidth / 2 then
            local dir = offsetX > 0 and -1 or 1
            if self:IsValidSkinDrag(dir) and not self._IsMoving then
                self:ShowSkinAnimation(dir)
            end
        end
    end
end

function CharacterListCtrl:IsValidSkinDrag(dir)
    local childCount = self._ui.SkinParent.childCount
    if dir == -1 then
        local lastItem = self._ui.SkinParent:GetChild(childCount - 1)
        local skinId = tonumber(lastItem.name)
        if ConfigUtils.IsValidItem(skinId) then
            if skinId == self._skinList[#self._skinList] then
                if lastItem.localPosition.x <= 60 then
                    return false
                end
            end
        else
            return false
        end
    elseif dir == 1 then
        local firstItem = self._ui.SkinParent:GetChild(0)
        local skinId = tonumber(firstItem.name)
        if skinId == self._skinList[1] then
            if firstItem.localPosition.x >= -60 then
                return false
            end
        end
    end

    return true
end
--------------------------------------------------------
-- tutorial
function CharacterListCtrl:GetFirstEquipmentItem()
    return self._ui.CharacterEquipments[1].item
end

function CharacterListCtrl:CheckTutorial()
    local tutorials = {}

    if GameData.IsTutorialNotFinished(Tutorials.Tutorial_3_2) then
        local position = self._ui.Camera:WorldToScreenPoint(self._ui.CharacterCollider.transform.position)
        tutorials[1] = {event = Tutorials.Tutorial_3_1, position = position, sender = self}
    elseif GameData.IsTutorialNotFinished(Tutorials.Tutorial_6_3) and GameData.IsGoalRunning(TutorialConstData.EquipmentUpgradeGoal) then
        local equipmentItem = self:GetFirstEquipmentItem()
        local position = self._ui.Camera:WorldToScreenPoint(equipmentItem.transform.position)
        tutorials[1] = {event = Tutorials.Tutorial_6_1, position = position, sender = self}
    end

    if #tutorials > 0 then
        CtrlManager.ShowTutorials(tutorials)
    end

    return #tutorials > 0
end

function CharacterListCtrl:OnTutorialClicked(tutorial)
    if tutorial == Tutorials.Tutorial_3_1 then
        self:OnClicked(self._ui.CharacterCollider)
    elseif tutorial == Tutorials.Tutorial_6_1 then
        local equipmentItem = self:GetFirstEquipmentItem()
        self:OnClicked(equipmentItem)
    end
end
--------------------------------------------------------
-- Filter
function CharacterListCtrl.DoItemFilter(itemList)
    local ret = {}

    for idx = 1, #itemList do
        local itemId = itemList[idx]
        local match = CharacterListCtrl.IsItemMatchFilter(itemId, _filterSkills)
        if match then
            table.insert(ret, itemId)
        end
    end

    return ret
end

--- 角色是否匹配
function CharacterListCtrl.IsItemMatchFilter(goodsId, filterSkills)
    if filterSkills ~= nil then
        local hasMatched = false
        local skillList = ConfigUtils.GetGoodsSkillList(goodsId)
        for idx = 1, #skillList do
            local skillId = skillList[idx].id
            if ConfigUtils.IsSkillMatchFilterMap(filterSkills, skillId) then
                hasMatched = true
                break
            end
        end

        if not hasMatched then
            return false
        end
    end

    return true
end

--- 显示过滤面板
function CharacterListCtrl:ShowFilterPanel()
    local params = {
        filterElements = nil,
        filterRarities = nil,
        filterTags = nil,
        filterSkills = nil,
        filterStages = nil,
        numCallback = CharacterListCtrl.GetMatchNumByFilter,
        resultCallback = CharacterListCtrl.OnGetFilterResult,
        receiver = self,
    }

    if _filterElements ~= nil then
        params.filterElements = Helper.CloneMap(_filterElements)
    end

    if _filterRarities ~= nil then
        params.filterRarities = Helper.CloneMap(_filterRarities)
    end

    if _filterTags ~= nil then
        params.filterTags = Helper.CloneMap(_filterTags)
    end

    if _filterStages ~= nil then
        params.filterStages = Helper.CloneMap(_filterStages)
    end

    if _filterSkills ~= nil then
        params.filterSkills = Helper.CloneMap(_filterSkills)
    end

    CtrlManager.OpenPanel(CtrlNames.CharacterFilter, params)
end

--- 获取匹配的角色数量
function CharacterListCtrl:GetMatchNumByFilter(data)
    local filterElements = data.filterElements
    local filterRarities = data.filterRarities
    local filterTags = data.filterTags
    local filterStages = data.filterStages
    local filterSkills = data.filterSkills

    local itemNum = 0
    local characterList = GameData.GetUnlockCharacters()
    for idx = 1, #characterList do
        local characterId = characterList[idx]
        if ConfigUtils.IsItemMatchFilter(characterId, nil, filterElements, filterRarities, filterTags, filterStages, filterSkills) then
            itemNum = itemNum + 1
        end
    end

    return itemNum
end

--- 角色匹配结果回调
function CharacterListCtrl:OnGetFilterResult(data)
    _filterElements = nil
    _filterRarities = nil
    _filterTags = nil
    _filterSkills = nil
    _filterStages = nil
    _filterName = data.filterName

    if data.filterElements ~= nil then
        _filterElements = Helper.CloneMap(data.filterElements)
    end

    if data.filterRarities ~= nil then
        _filterRarities = Helper.CloneMap(data.filterRarities)
    end

    if data.filterTags ~= nil then
        _filterTags = Helper.CloneMap(data.filterTags)
    end

    if data.filterStages ~= nil then
        _filterStages = Helper.CloneMap(data.filterStages)
    end

    if data.filterSkills ~= nil then
        _filterSkills = Helper.CloneMap(data.filterSkills)
    end

    self:OnFilterChanged()
end


--------------------------------------------------------