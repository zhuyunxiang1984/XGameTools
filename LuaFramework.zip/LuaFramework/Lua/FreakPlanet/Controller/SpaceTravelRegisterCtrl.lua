require "FreakPlanet/View/SpaceTravelRegisterPanel"

local class = require "FreakPlanet/Utils/middleclass"
SpaceTravelRegisterCtrl  = class(CtrlNames.SpaceTravelRegister, BaseCtrl)

-- load the ui prefab
function SpaceTravelRegisterCtrl:LoadPanel()
	self:CreatePanel("SpaceTravelRegister")
end

-- construct ui panel data
function SpaceTravelRegisterCtrl:ConstructUI(obj)
	self._ui = SpaceTravelRegisterPanel.Init(obj)
end

-- fill ui with the data
function SpaceTravelRegisterCtrl:SetupUI()
	self._seasonId = self._parameter.season
    local scoreCapRank = GameData.GetSpaceTravelScoreCapRank()
    self._scoreCapId = GameData.GetScoreCapOfSpaceTravelSeason(self._seasonId, scoreCapRank)
    self._seasonEndTime = GameData.GetSpaceTravelSeasonRegisterEndTime(self._seasonId)
    self._needRefreshTime = true
    self:RefreshLeftTime()
    -- detail info
    self._ui.Nickname.text = GameData.GetDefaultNickName(true)
    local title, desc, icon = ConfigUtils.GetScoreCapInfo(self._scoreCapId)
    self._ui.Title.text = title
    self._ui.Desc.text = desc
    self._ui.ScoreCap.spriteName = icon
    self._ui.HistoryScore.text = ""

    CtrlManager.AddClick(self, self._ui.Blocker)
    CtrlManager.AddClick(self, self._ui.ButtonConfirm)
    CtrlManager.AddClick(self, self._ui.ButtonRank)

    local seasonData = GameData.GetSpaceTravelSeasonData(self._seasonId)
    local seasonRetryCount = 0
    if seasonData ~= nil then
        seasonRetryCount = seasonData.seasonRetry or 0
    end

    self._ui.ButtonConfirm:SetActive(seasonRetryCount < SpaceTravelSeasonGameCount)
    self._ui.DisableHint:SetActive(seasonRetryCount >= SpaceTravelSeasonGameCount)
    self._ui.Progress.text = string.format(SAFE_LOC("已经玩了：%d/%d"), seasonRetryCount, SpaceTravelSeasonGameCount)
end

-- update implementation
function SpaceTravelRegisterCtrl:UpdateImpl(deltaTime)
    self:RefreshLeftTime()
end

function SpaceTravelRegisterCtrl:RefreshLeftTime()
    if not self._needRefreshTime then
        return
    end

    local curTime = GameData.GetServerTime()
    local leftTime = math.max(0, self._seasonEndTime - curTime)
    if leftTime > 0 then
        self._ui.LeftTime.text = SAFE_LOC("报名剩余时间：")..Helper.GetLongTimeString(leftTime)
    else
        self._ui.LeftTime.text = SAFE_LOC("报名已结束")
    end
    self._needRefreshTime = (leftTime > 0)
end

-- on clicked
function SpaceTravelRegisterCtrl:OnClicked(go)

    if go == self._ui.Blocker then
        SoundSystem.PlayUICancelSound()
        CtrlManager.PopPanel()
    elseif go == self._ui.ButtonConfirm then
        local curTime = GameData.GetServerTime()
        if curTime >= self._seasonEndTime then
            SoundSystem.PlayWarningSound()
            CtrlManager.ShowMessageBox({message = SAFE_LOC("星际航行报名已结束"), single = true})
            return true
        end

        SoundSystem.PlayUIClickSound()
        CtrlManager.OpenPanel(CtrlNames.SpaceTravelShip, {season = self._seasonId, scoreCap = self._scoreCapId})
    elseif go == self._ui.ButtonRank then
        SoundSystem.PlayUIClickSound()
        CtrlManager.OpenPanel(CtrlNames.SpaceTravelRank, {seasonId = self._seasonId})
    end

	return true
end
