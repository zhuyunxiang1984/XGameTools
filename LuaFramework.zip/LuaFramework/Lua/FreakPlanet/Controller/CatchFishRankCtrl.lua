---
--- Created by lizheng.
--- DateTime: 2021-07-28 10:00:28
---

require "FreakPlanet/View/CatchFishRankPanel"

local class = require "FreakPlanet/Utils/middleclass"
CatchFishRankCtrl = class(CtrlNames.CatchFishRank, BaseCtrl)

-- load the ui prefab
function CatchFishRankCtrl:LoadPanel()
    self:CreatePanel("CatchFishRank")
end

local FIRST_RANK_BG = "GoldFish_Ranking1"
local SECOND_RANK_BG = "GoldFish_Ranking2"
local THIRD_RANK_BG = "GoldFish_Ranking3"
local COMMON_RANK_BG = "GoldFish_Ranking4"


-- construct ui panel data
function CatchFishRankCtrl:ConstructUI(obj)
    self._ui = CatchFishRankPanel.Init(obj)
    self._RankItemPool = {}
    self._RankList = {}
end

-- fill ui with the data
function CatchFishRankCtrl:SetupUI()
    CtrlManager.AddClick(self, self._ui.Blocker)
    CtrlManager.AddClick(self, self._ui.ButtonDetails)
    NetManager.Send("RankList", {}, CatchFishRankCtrl.OnHandleProto, self)
end

-- on clicked
function CatchFishRankCtrl:OnClicked(go)
    if go == self._ui.Blocker then
        SoundSystem.PlayUICancelSound()
        CtrlManager.PopPanel()
    elseif go == self._ui.ButtonDetails then
        SoundSystem.PlayUIClickSound()
        XDebug.Log("LZ", "ButtonDetails")
        CtrlManager.OpenPanel(CtrlNames.CatchFishRankHelp)
    end
    return true
end

function CatchFishRankCtrl:GetOrCreateRankItem()
    local obj = nil
    if #self._RankItemPool > 0 then
        obj = self._RankItemPool[#self._RankItemPool]
        table.remove(self._RankItemPool, #self._RankItemPool)
    else
        obj = Helper.NewObject(self._ui.RankItemTemplate, self._ui.RankPoolRoot)
    end
    return obj
end

local function RankSortFunc(idA, idB)
    if idA == nil or idB == nil then
        return false
    end
    local scoreA = idA.Score
    local scoreB = idB.Score

    return scoreA > scoreB
end

function CatchFishRankCtrl:SetupRankUI()
    local ui = self._ui
    --ui.RankUIGrid.gameObject:SetActive(true)
    --table.sort(self._RankList, RankSortFunc)
    --XDebug.Log("LZ", "count:", #self._RankList)
    ui.RankGridWrap.OnItemUpdate = CatchFishRankCtrl.OnItemUpdateGlobal
    local itemCount = ui.RankGridWrap.NeedCellCount
    itemCount = math.min(#self._RankList, itemCount)
    ui.RankGridWrap.MaxRow = math.ceil(#self._RankList / self._ui.RankGridWrap.ColumnLimit)

    for idx = ui.RankGrid.childCount, 1, -1 do
        local item = ui.RankGrid:GetChild(idx - 1)
        table.insert(self._RankItemPool, item.gameObject)
        item:SetParent(ui.RankPoolRoot)
    end

    for idx = 1, itemCount do
        local item = self:GetOrCreateRankItem()
        item:SetActive(true)
        item.transform.parent = ui.RankGrid
        self:ConstructRankItem(item, idx)
    end

    ui.RankGridWrap:SortBasedOnScrollMovement()
    ui.RankScrollView.restrictWithinPanel = true
    ui.RankScrollView.disableDragIfFits = (#self._RankList <= itemCount)
    ui.RankScrollView:ResetPosition()
end

function CatchFishRankCtrl:ConstructRankItem(item, idx)
    item.name = tostring(idx)
    local top1 = item.transform:Find("Top1").gameObject
    local top2 = item.transform:Find("Top2").gameObject
    local top3 = item.transform:Find("Top3").gameObject
    local common = item.transform:Find("Common").gameObject

    top1:SetActive(idx == 1)
    top2:SetActive(idx == 2)
    top3:SetActive(idx == 3)
    common:SetActive(idx > 3)

    if idx > 3 then
        local rankNum = common.transform:Find("RankNum"):GetComponent("UILabel")
        rankNum.text = tostring(idx)
    end

    local NickName = item.transform:Find("NickName"):GetComponent("UILabel")
    NickName.text = self._RankList[idx].Nickname

    local Score = item.transform:Find("RankScore"):GetComponent("UILabel")
    Score.text = tostring(self._RankList[idx].Score)

    local BG = item.transform:Find("BG"):GetComponent("UISprite")
    BG.spriteName = self:GetRankBG(idx)
end

function CatchFishRankCtrl.OnItemUpdateGlobal(itemObj, itemIndex, itemRealIndex)
    local ctrl = CtrlManager.GetCtrlByName(CtrlNames.CatchFishRank)
    if ctrl ~= nil then
        ctrl:OnItemUpdate(itemObj, itemIndex, itemRealIndex)
    end
end

function CatchFishRankCtrl:OnItemUpdate(itemObj, itemIndex, itemRealIndex)
    itemRealIndex = itemRealIndex + 1
    if itemRealIndex <= 0 or itemRealIndex > #self._RankList then
        itemObj:SetActive(false)
    else
        itemObj:SetActive(true)
        local itemId = self._RankList[itemRealIndex]
        itemObj.name = tostring(itemRealIndex)
        local rankItem = itemObj.transform
        -- construct item
        self:ConstructRankItem(rankItem, itemRealIndex)
    end
end

function CatchFishRankCtrl:SetupMyRankUI(rank, score)
    self._ui.MyRankRoot.gameObject:SetActive(true)
    self._ui.MyRank.num.text = tostring(rank)

    self._ui.MyRank.score.text = score > 0 and tostring(score) or SAFE_LOC("未上榜")
    self._ui.MyRank.name.text = GameData.GetDefaultNickName(true)
end

function CatchFishRankCtrl:GetRankBG(rank)
    local result = nil
    if rank == 1 then
        result = FIRST_RANK_BG
    elseif rank == 2 then
        result = SECOND_RANK_BG
    elseif rank == 3 then
        result = THIRD_RANK_BG
    else
        result = COMMON_RANK_BG
    end
    return result
end

function CatchFishRankCtrl:OnHandleProto(proto, data, requestData)
    if proto == "RankList" then
        self._RankList = data.RankList
        self:SetupRankUI()
        self:SetupMyRankUI(data.RankSelf, data.ScoreSelf)
    end
end

