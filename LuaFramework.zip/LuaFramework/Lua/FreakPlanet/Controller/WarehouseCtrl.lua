require "FreakPlanet/View/WarehousePanel"

local class = require "FreakPlanet/Utils/middleclass"
WarehouseCtrl  = class(CtrlNames.Warehouse, BaseCtrl)

WarehouseSortMode = {
	Food = "Food",
	Event = "Event",
	Object = "Object",
	Chip = "Chip",
	Pet = "Pet",
}

local SubTypeValues = {
	Food = 20,
	CatchItem = 10
}

--------------------------------------------------------------------
local function GoodsSortFunc(idA, idB)
	if idA == nil or idB == nil then
		return false
	end

	local markedA = GameData.IsItemMarked(idA)
	local markedB = GameData.IsItemMarked(idB)
	if markedA ~= markedB then
		return markedA
	end

	local subTypeA = ConfigUtils.GetGoodsSubType(idA)
	local subTypeB = ConfigUtils.GetGoodsSubType(idB)

	local valueA = SubTypeValues[subTypeA] or 0
	local valueB = SubTypeValues[subTypeB] or 0

	if valueA == valueB then
		valueA = ConfigUtils.GetGoodsRarity(idA)
		valueB = ConfigUtils.GetGoodsRarity(idB)
	end

	if valueA == valueB then
		valueA = ConfigUtils.GetGoodsSortId(idA)
		valueB = ConfigUtils.GetGoodsSortId(idB)
	end

	return valueA > valueB
end

local function ChipSortFunc(idA, idB)
	if idA == nil or idB == nil then
		return false
	end

	local markedA = GameData.IsItemMarked(idA)
	local markedB = GameData.IsItemMarked(idB)
	if markedA ~= markedB then
		return markedA
	end

	local valueA = ConfigUtils.GetGoodsStorageSortId(idA)
	local valueB = ConfigUtils.GetGoodsStorageSortId(idB)
	if valueA ~= valueB then
		return valueA < valueB
	end

	valueA = ConfigUtils.GetGoodsSortId(idA)
	valueB = ConfigUtils.GetGoodsSortId(idB)

	return valueA > valueB
end

local function PetSortFunc(idA, idB)
	if idA == nil or idB == nil then
		return false
	end

	local markedA = GameData.IsItemMarked(idA)
	local markedB = GameData.IsItemMarked(idB)
	if markedA ~= markedB then
		return markedA
	end

	local valueA = ConfigUtils.GetPetRarity(idA)
	local valueB = ConfigUtils.GetPetRarity(idB)

	if valueA == valueB then
		valueA = ConfigUtils.GetPetSortId(idA)
		valueB = ConfigUtils.GetPetSortId(idB)
	end

	return valueA > valueB
end
--------------------------------------------------------------------
-- load the ui prefab
function WarehouseCtrl:LoadPanel()
	self:CreatePanel("Warehouse")
end

-- construct ui panel data
function WarehouseCtrl:ConstructUI(obj)
	self._ui = WarehousePanel.Init(obj)
end

-- destructor 
function WarehouseCtrl:DestroyImpl()
	GameData.CheckItemsOfType(ItemType.Goods)
	GameData.CheckItemsOfType(ItemType.Pet)
	GameNotifier.RemoveListener(GameEvent.ItemNumChanged, WarehouseCtrl.OnItemNumChanged, self)
	GameNotifier.RemoveListener(GameEvent.MarkStateChanged, WarehouseCtrl.OnMarkStateChanged, self)
end

-- fill ui with the data
function WarehouseCtrl:SetupUI()
	self._goodsPrefab = self:LoadAsset("GoodsItem")
	self._ui.ItemGridWrap.OnItemUpdate = WarehouseCtrl.OnItemUpdateGlobal

	self._currentMode = self._parameter.sortMode or WarehouseSortMode.Food
	self:OnSortModeChanged()
	self:CheckNewOfAllModes()

	CtrlManager.AddClick(self, self._ui.Blocker)
	CtrlManager.AddClick(self, self._ui.ButtonFood.gameObject)
	CtrlManager.AddClick(self, self._ui.ButtonEvent.gameObject)
	CtrlManager.AddClick(self, self._ui.ButtonObject.gameObject)
	CtrlManager.AddClick(self, self._ui.ButtonChip.gameObject)
	CtrlManager.AddClick(self, self._ui.ButtonPet.gameObject)

	GameNotifier.AddListener(GameEvent.ItemNumChanged, WarehouseCtrl.OnItemNumChanged, self)
	GameNotifier.AddListener(GameEvent.MarkStateChanged, WarehouseCtrl.OnMarkStateChanged, self)
end

function WarehouseCtrl:OnSortModeChanged()
	self._itemList = self:GetItemList()
	self:SetupItemGrid()
	self:RefreshButtonState()
end

function WarehouseCtrl:GetItemList()
	local itemList = {}
	local sortFunc = nil
	if self._currentMode == WarehouseSortMode.Food then
		itemList = GameData.GetUnlockedGoodsOfTypes(GoodsSubType.Food, GoodsSubType.CatchItem)
		sortFunc = GoodsSortFunc
	elseif self._currentMode == WarehouseSortMode.Event then
		itemList = GameData.GetUnlockedGoodsOfType(GoodsSubType.EventItem)
		sortFunc = GoodsSortFunc
	elseif self._currentMode == WarehouseSortMode.Object then
		itemList = GameData.GetUnlockedGoodsOfType(GoodsSubType.Object)
		sortFunc = GoodsSortFunc
	elseif self._currentMode == WarehouseSortMode.Chip then
		itemList = GameData.GetUnlockedGoodsOfType(GoodsSubType.Chip)
		sortFunc = ChipSortFunc
	elseif self._currentMode == WarehouseSortMode.Pet then
		itemList = GameData.GetUnlockPetList()
		sortFunc = PetSortFunc
	else
		assert(false, "un-handled sort mode: "..tostring(self._currentMode))
	end

	table.sort(itemList, sortFunc)
	return itemList
end

function WarehouseCtrl:GetItemPoolAndPrefab()
	if self._currentMode == WarehouseSortMode.Pet then
		return self._ui.PetItemPool, self._ui.PetItemTemplate
	end

	return self._ui.GoodsItemPool, self._goodsPrefab
end

function WarehouseCtrl:RefreshButtonState()
	self:SetButtonState(self._ui.ButtonFood, self._currentMode ~= WarehouseSortMode.Food)
	self:SetButtonState(self._ui.ButtonEvent, self._currentMode ~= WarehouseSortMode.Event)
	self:SetButtonState(self._ui.ButtonObject, self._currentMode ~= WarehouseSortMode.Object)
	self:SetButtonState(self._ui.ButtonChip, self._currentMode ~= WarehouseSortMode.Chip)
	self:SetButtonState(self._ui.ButtonPet, self._currentMode ~= WarehouseSortMode.Pet)
end

function WarehouseCtrl:SetButtonState(button, enabled)
	button.isEnabled = enabled
	--[[if enabled then
		button.transform.localScale = Vector3.one
	else
		button.transform.localScale = Vector3.New(1.3, 1.3, 1)
	end]]
end

function WarehouseCtrl:RecycleGridItems()
	local itemPool = self:GetItemPoolAndPrefab()

	for idx = self._ui.ItemGrid.childCount, 1, -1 do
		local item = self._ui.ItemGrid:GetChild(idx - 1)
		item.parent = itemPool
	end
end

function WarehouseCtrl:SetupItemGrid()
	-- item count
	local itemCount = self._ui.ItemGridWrap.NeedCellCount
	itemCount = math.min(#self._itemList, itemCount)
	self._ui.ItemGridWrap.MaxRow = math.ceil(#self._itemList / self._ui.ItemGridWrap.ColumnLimit)

	local itemPool, itemPrefab = self:GetItemPoolAndPrefab()

	local item = nil
	for idx = 1, itemCount do
		local itemId = self._itemList[idx]
		if itemPool.childCount == 0 then
			local itemObj = Helper.NewObject(itemPrefab, self._ui.ItemGrid)
			CtrlManager.AddClick(self, itemObj)
			CtrlManager.AddPress(self, itemObj)
			item = itemObj.transform
		else
			item = itemPool:GetChild(0)
			item.parent = self._ui.ItemGrid
		end

		item.gameObject:SetActive(true)
		item.gameObject.name = tostring(itemId)

		-- construct item
		self:ConstructGridItem(item, itemId)
	end

	self._ui.ItemGridWrap:SortBasedOnScrollMovement()
	self._ui.ItemScrollView:ResetPosition()
	self._ui.ItemScrollView.disableDragIfFits = (#self._itemList <= itemCount)
	self._ui.ItemScrollView.restrictWithinPanel = true
end

function WarehouseCtrl:ConstructGridItem(item, itemId)
	if self._currentMode == WarehouseSortMode.Pet then
		self:ConstructPetItem(item, itemId)
	else
		self:ConstructGoodsItem(item, itemId)
	end
end

function WarehouseCtrl:ConstructGoodsItem(item, itemId)
	UIHelper.ConstructGoodsItem(self, item, itemId, self._currentMode == WarehouseSortMode.Food)
	-- number
	local numLabel = item:Find("Num"):GetComponent("UILabel")
	local subType = ConfigUtils.GetGoodsSubType(itemId)
	if subType == GoodsSubType.EventItem then
		numLabel.text = SAFE_LOC("loc_setsupply_eventitem_is_free")
	else
		local ownNum = GameData.GetItemNum(itemId)
		numLabel.text = tostring(ownNum)
	end
    -- new
    local isNew = GameData.IsItemNew(itemId)
    self:ToggleItemNewState(item, itemId, isNew)
    -- marked
	local marked = GameData.IsItemMarked(itemId)
    local markedMark = item:Find("Mark/Marked").gameObject
    markedMark:SetActive(marked)
end

function WarehouseCtrl:ConstructPetItem(item, itemId)
	UIHelper.ConstructPetItem(self, item, itemId)
	-- level
	local levelLabel = item:Find("Level"):GetComponent("UILabel")
	local petLevel = GameData.GetPetLevel(itemId)
	levelLabel.text = string.format(SAFE_LOC("loc_SimpleLevel"), petLevel)
	-- new
    local isNew = GameData.IsItemNew(itemId)
    self:ToggleItemNewState(item, itemId, isNew)
    -- marked
	local marked = GameData.IsItemMarked(itemId)
    local markedMark = item:Find("Mark/Marked").gameObject
    markedMark:SetActive(marked)
end

function WarehouseCtrl:ToggleItemNewState(item, itemId, isNew)
	if item == nil then
		item = self._ui.ItemGrid:Find(itemId)
	end

	if item ~= nil then
		local mark = item:Find("Mark/New").gameObject
		mark:SetActive(isNew)
	end
end

function WarehouseCtrl:CheckItem(itemId)
	GameData.CheckItem(itemId)
	self:ToggleItemNewState(nil, itemId, false)

	local sortMode = self:GetSortModeByItemId(itemId)
	self:CheckNewOfMode(sortMode)
end

function WarehouseCtrl:CheckNewOfAllModes()
	for k, v in pairs(WarehouseSortMode) do
		self:CheckNewOfMode(v)
	end
end

function WarehouseCtrl:CheckNewOfMode(sortMode)
	if sortMode == WarehouseSortMode.Food then
		local hasNew = GameData.HasNewGoodsOfSubType(GoodsSubType.Food) or GameData.HasNewGoodsOfSubType(GoodsSubType.CatchItem)
		self._ui.FoodNewMark:SetActive(hasNew)
	elseif sortMode == WarehouseSortMode.Event then
		local hasNew = GameData.HasNewGoodsOfSubType(GoodsSubType.EventItem) 
		self._ui.EventNewMark:SetActive(hasNew)
	elseif sortMode == WarehouseSortMode.Object then
		local hasNew = GameData.HasNewGoodsOfSubType(GoodsSubType.Object) 
		self._ui.ObjectNewMark:SetActive(hasNew)
	elseif sortMode == WarehouseSortMode.Chip then
		local hasNew = GameData.HasNewGoodsOfSubType(GoodsSubType.Chip)
		self._ui.ChipNewMark:SetActive(hasNew)
	elseif sortMode == WarehouseSortMode.Pet then
		local hasNew = GameData.HasNewOfType(ItemType.Pet)
		self._ui.PetNewMark:SetActive(hasNew)
	else
		assert(false, "un-handled sort mode: "..tostring(sortMode))
	end
end

function WarehouseCtrl:OnItemUpdate(itemObj, itemIndex, itemRealIndex)
	itemRealIndex = itemRealIndex + 1
	if itemRealIndex <= 0 or itemRealIndex > #self._itemList then
		itemObj:SetActive(false)
	else
		itemObj:SetActive(true)
		local itemId = self._itemList[itemRealIndex]
		itemObj.name = itemId
		-- construct item
		self:ConstructGridItem(itemObj.transform, itemId)
	end
end

function WarehouseCtrl.OnItemUpdateGlobal(itemObj, itemIndex, itemRealIndex)
	local ctrl = CtrlManager.GetCtrlByName(CtrlNames.Warehouse)
	if ctrl ~= nil then
		ctrl:OnItemUpdate(itemObj, itemIndex, itemRealIndex)
	end
end

-- handle the escapse button
function WarehouseCtrl:HandleEscape()
	self:OnClicked(self._ui.Blocker)
end

-- on clicked
function WarehouseCtrl:OnClicked(go)
	if go == self._ui.Blocker then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
	elseif go == self._ui.ButtonFood.gameObject then
		SoundSystem.PlaySwitchSound()
		self:RecycleGridItems()
		self._currentMode = WarehouseSortMode.Food
		self:OnSortModeChanged()
	elseif go == self._ui.ButtonEvent.gameObject then
		SoundSystem.PlaySwitchSound()
		self:RecycleGridItems()
		self._currentMode = WarehouseSortMode.Event
		self:OnSortModeChanged()
	elseif go == self._ui.ButtonObject.gameObject then
		SoundSystem.PlaySwitchSound()
		self:RecycleGridItems()
		self._currentMode = WarehouseSortMode.Object
		self:OnSortModeChanged()
	elseif go == self._ui.ButtonChip.gameObject then
		SoundSystem.PlaySwitchSound()
		self:RecycleGridItems()
		self._currentMode = WarehouseSortMode.Chip
		self:OnSortModeChanged()
	elseif go == self._ui.ButtonPet.gameObject then
		SoundSystem.PlaySwitchSound()
		self:RecycleGridItems()
		self._currentMode = WarehouseSortMode.Pet
		self:OnSortModeChanged()
	elseif go.transform.parent == self._ui.ItemGrid then
		SoundSystem.PlayUIClickSound()
		local itemId = tonumber(go.name)
		self:CheckItem(itemId)
		CtrlManager.ShowItemDetail({itemId = itemId, callback = WarehouseCtrl.HandleSwitchItem, receiver = self})
	end

	return true
end

function WarehouseCtrl:OnPressed(go, pressed, isLong)
	if go.transform.parent == self._ui.ItemGrid then
		if pressed and isLong then
			SoundSystem.PlayUIClickSound()
			local itemId = tonumber(go.name)
			self:CheckItem(itemId)
			CtrlManager.ShowItemDetail({itemId = itemId, callback = WarehouseCtrl.HandleSwitchItem, receiver = self})
		end
	end
end

function WarehouseCtrl:HandleSwitchItem(itemId, isNext)
	local totalCount = #self._itemList
    local index = Helper.IndexOfArray(self._itemList, itemId)
    if isNext then
        index = index + 1
        if index > totalCount then
            index = 1
        end
    else
        index = index - 1
        if index < 1 then
            index = totalCount
        end
    end

    return self._itemList[index]
end

function WarehouseCtrl:GetSortModeByItemId(itemId)
	local itemType = ConfigUtils.GetItemTypeFromId(itemId)
	if itemType == ItemType.Goods then
		local goodsSubType = ConfigUtils.GetGoodsSubType(itemId)
		if goodsSubType == GoodsSubType.Food or goodsSubType == GoodsSubType.CatchItem then
			return WarehouseSortMode.Food
		elseif goodsSubType == GoodsSubType.EventItem then
			return WarehouseSortMode.Event
		elseif goodsSubType == GoodsSubType.Chip then
			return WarehouseSortMode.Chip
		elseif goodsSubType == GoodsSubType.Object then
			return WarehouseSortMode.Object
		end
	elseif itemType == ItemType.Pet then
		return WarehouseSortMode.Pet
	end

	return nil
end

function WarehouseCtrl:OnMarkStateChanged(itemId, marked)
	local sortMode = self:GetSortModeByItemId(itemId)
	if sortMode == self._currentMode then
		self:RecycleGridItems()
		self._itemList = self:GetItemList()
		self:SetupItemGrid()
	end
end

function WarehouseCtrl:OnItemNumChanged(itemId, changeNum)
	local sortMode = self:GetSortModeByItemId(itemId)
	if sortMode == self._currentMode then
		local item = self._ui.ItemGrid:Find(itemId)
		if item ~= nil then
			self:ConstructGridItem(item, itemId)
		end
	end
end
---------------------------------------------------------------------------