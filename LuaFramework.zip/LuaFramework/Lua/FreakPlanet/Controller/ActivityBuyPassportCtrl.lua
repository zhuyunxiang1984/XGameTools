require "FreakPlanet/View/ActivityBuyPassportPanel"

local class = require "FreakPlanet/Utils/middleclass"
ActivityBuyPassportCtrl = class(CtrlNames.ActivityBuyPassport, BaseCtrl)

-- load the ui prefab
function ActivityBuyPassportCtrl:LoadPanel()
	self:CreatePanel("ActivityBuyPassport")
end

-- construct ui panel data
function ActivityBuyPassportCtrl:ConstructUI(obj)
	self._ui = ActivityBuyPassportPanel.Init(obj)
end

-- fill ui with the data
function ActivityBuyPassportCtrl:SetupUI()
	local ui = self._ui

	self:InitUI()
	self:EnableSecondUpdate()

	CtrlManager.AddClick(self, ui.Blocker)
	CtrlManager.AddClick(self, ui.btnBuy)
end

function ActivityBuyPassportCtrl:InitUI()
	local ui = self._ui

	self.CheckLeftTime = false
	local leftTime = GameData.GetBuyActivityPassportLeftTime()
	if leftTime <= 0 then
		ui.btnBuy:SetActive(false)
		ui.objPurchasedTips:SetActive(false)
		ui.objTimeoutTips:SetActive(true)
	elseif GameData.HasCurrActivityPassport() then
		ui.btnBuy:SetActive(false)
		ui.objPurchasedTips:SetActive(true)
		ui.objTimeoutTips:SetActive(false)
	else
		ui.btnBuy:SetActive(true)
		ui.objPurchasedTips:SetActive(false)
		ui.objTimeoutTips:SetActive(false)
		self:UpdateUILeftTime(leftTime)
		self.CheckLeftTime = true
	end
end

-- update per second
function ActivityBuyPassportCtrl:UpdateImplBySecond(deltaTime)
	if self.CheckLeftTime then
		local ui = self._ui
		local leftTime = GameData.GetBuyActivityPassportLeftTime()
		self:UpdateUILeftTime(leftTime)
		if leftTime <= 0 then
			self:InitUI()
		end
	end
end

-- on clicked
function ActivityBuyPassportCtrl:OnClicked(go)
	local ui = self._ui
	if go == ui.Blocker then
		CtrlManager.PopPanel()
	elseif go == ui.btnBuy then
		CtrlManager.PopPanel()
		self:OnClickBuy()
	end
	return true
end

function ActivityBuyPassportCtrl:OnClickBuy()
	local productId = GameData.GetCurrentActivityPassport()
	if productId == -1 then
		return
	end
	if GameData.GetBuyActivityPassportLeftTime() <= 0 then
		return
	end
	local canBuy = IAPManager.CanBuy()
	if not canBuy then
		SoundSystem.PlayWarningSound()
		IAPManager.ShowIapResult(PaymentResult.IapInProcessing)
		return
	end

	local price = ConfigUtils.GetIapPrice(productId)
	local isOK = GameData.CheckRealNameOfIap(price)
	if not isOK then
		SoundSystem.PlayWarningSound()
		return
	end
	IAPManager.BuyWithAutoPaymentType(productId)
end

function ActivityBuyPassportCtrl:UpdateUILeftTime(leftTime)
	local ui = self._ui
	ui.txtLeftTime.text = Helper.GetLongTimeString(leftTime) .. "后截止"
	--XDebug.Log('GGYY', "通行证剩余购买时间 " .. leftTime)
end