require "FreakPlanet/View/CustomDemandPanel"

local class = require "FreakPlanet/Utils/middleclass"
CustomDemandCtrl  = class(CtrlNames.CustomDemand, BaseCtrl)

local SelectMode = {
    Reward = "Reward",
    Submit = "Submit",
}
-------------------------------------------------------------------
local function GoodsSortFunc(idA, idB)
    local valueA = ConfigUtils.GetGoodsSortId(idA)
    local valueB = ConfigUtils.GetGoodsSortId(idB)

    return valueA > valueB
end

local function ItemSortFunc(idA, idB)
    if idA == nil or idB == nil then
        return false
    end

    local itemTypeA = ConfigUtils.GetItemTypeFromId(idA)
    local itemTypeB = ConfigUtils.GetItemTypeFromId(idB)
    if itemTypeA ~= itemTypeB then
        return itemTypeA < itemTypeB
    end

    if itemTypeA == ItemType.Goods then
        return GoodsSortFunc(idA, idB)
    else
        return idA > idB
    end
end
-------------------------------------------------------------------
-- load the ui prefab
function CustomDemandCtrl:LoadPanel()
	self:CreatePanel("CustomDemand")
end

-- construct ui panel data
function CustomDemandCtrl:ConstructUI(obj)
	self._ui = CustomDemandPanel.Init(obj)
end

-- destructor 
function CustomDemandCtrl:DestroyImpl()
    GameNotifier.RemoveListener(GameEvent.ItemNumChanged, CustomDemandCtrl.OnItemNumChanged, self)
end

-- fill ui with the data
function CustomDemandCtrl:SetupUI()
    local customDemandInfo = GameData.GetCustomDemandInfo()
    self._rewardId = customDemandInfo.rewardId
    self._submitId = customDemandInfo.submitId

    local dialog = ConfigUtils.GetCustomDemandSpeechOfInit()
    if dialog ~= nil then
        self._ui.DialogLabel.text = dialog
    else
        self._ui.DialogLabel.text = ""
    end

    self:OnSelectedRewardChanged()
    self:OnSelectedSubmitChanged()

    -- hide by default
    self._ui.SelectPanel:SetActive(false)
    self._ui.SelectItemGridWrap.OnItemUpdate = CustomDemandCtrl.OnItemUpdateGlobal

	CtrlManager.AddClick(self, self._ui.Blocker)
    CtrlManager.AddClick(self, self._ui.SelectBlocker)
    CtrlManager.AddClick(self, self._ui.ButtonConfirm)
    CtrlManager.AddClick(self, self._ui.SelectedRewardItem)
    CtrlManager.AddClick(self, self._ui.SelectedSubmitItem)

    GameNotifier.AddListener(GameEvent.ItemNumChanged, CustomDemandCtrl.OnItemNumChanged, self)
end

function CustomDemandCtrl:OnSelectedRewardChanged()
    self:ConstructSelectedItem(self._ui.SelectedRewardItem.transform, self._rewardId)
end

function CustomDemandCtrl:OnSelectedSubmitChanged()
    self:ConstructSelectedItem(self._ui.SelectedSubmitItem.transform, self._submitId)
end

function CustomDemandCtrl:ConstructSelectedItem(item, itemId)
    local root = item:Find("Root")
    local empty = item:Find("Empty").gameObject

    local isValid = ConfigUtils.IsValidItem(itemId)
    root.gameObject:SetActive(isValid)
    empty:SetActive(not isValid)

    if isValid then
        UIHelper.ConstructItemIconAndNum(self, root, itemId)
    end
end

function CustomDemandCtrl:GetSelectableItemList()
    if self._selectMode == SelectMode.Reward then
        return ConfigUtils.GetDemandAvailableRewards(self._submitId)
    elseif self._selectMode == SelectMode.Submit then
        return ConfigUtils.GetDemandAvailableSubmits(self._rewardId)
    else
        assert(false, "un-handled select mode: "..tostring(self._selectMode))
    end
end

function CustomDemandCtrl:EnterSelectMode(mode)
    self._ui.SelectPanel:SetActive(true)
    self._selectMode = mode
    if mode == SelectMode.Reward then
        self._selectedItemId = self._rewardId
        self._itemList = ConfigUtils.GetDemandAvailableRewards(self._submitId)
    elseif mode == SelectMode.Submit then
        self._selectedItemId = self._submitId
        self._itemList = ConfigUtils.GetDemandAvailableSubmits(self._rewardId)
    else
        assert(false, "un-handled select mode: "..tostring(mode))
    end
    self._previousSelectedItemId = self._selectedItemId
    table.sort(self._itemList, ItemSortFunc)
    self:SetupSelectItemGrid()
end

function CustomDemandCtrl:ExitSelectMode()
    self._ui.SelectPanel:SetActive(false)
    -- no change
    if self._previousSelectedItemId == self._selectedItemId then
        return
    end

    local dialogCheckList = {}
    if self._selectMode == SelectMode.Reward then
        self._rewardId = self._selectedItemId
        self:OnSelectedRewardChanged()
        dialogCheckList[1] = {itemId = self._rewardId, key = "CustomReward"}
        dialogCheckList[2] = {itemId = self._submitId, key = "CustomSubmit"}
    elseif self._selectMode == SelectMode.Submit then
        self._submitId = self._selectedItemId
        self:OnSelectedSubmitChanged()
        dialogCheckList[1] = {itemId = self._submitId, key = "CustomSubmit"}
        dialogCheckList[2] = {itemId = self._rewardId, key = "CustomReward"}
    else
        assert(false, "un-handled select mode: "..tostring(mode))
    end

    local found = false
    local dialog = nil
    for idx = 1, #dialogCheckList do
        local itemId = dialogCheckList[idx].itemId
        if ConfigUtils.IsValidItem(itemId) then
            local key = dialogCheckList[idx].key
            dialog = ConfigUtils.GetCustomDemandSpeechOfKey(itemId, key)
            found = true
            break
        end
    end

    if not found then
        dialog = ConfigUtils.GetCustomDemandSpeechOfInit()
    end

    if dialog ~= nil then
        self._ui.DialogTypewriter:Finish()
        self._ui.DialogLabel.text = dialog
        self._ui.DialogTypewriter:ResetToBeginning()
    else
        self._ui.DialogLabel.text = ""
    end
end

function CustomDemandCtrl:OnItemNumChanged(itemId, changeNum)
    if not self._ui.SelectPanel.activeSelf then
        return
    end

    local item = self._ui.SelectItemGrid:Find(itemId)
    if item ~= nil then
        self:ConstructGridItem(item, itemId)
    end
end

function CustomDemandCtrl:SetupSelectItemGrid()
    local num = self._ui.SelectItemGrid.childCount
    for idx = num, 1, -1 do
        local item = self._ui.SelectItemGrid:GetChild(idx - 1)
        item.parent = self._ui.SelectItemPool
    end

    -- item count
    local itemCount = self._ui.SelectItemGridWrap.NeedCellCount
    itemCount = math.min(#self._itemList, itemCount)
    self._ui.SelectItemGridWrap.MaxRow = math.ceil(#self._itemList / self._ui.SelectItemGridWrap.ColumnLimit)

    local item = nil
    for idx = 1, itemCount do
        local itemId = self._itemList[idx]
        if self._ui.SelectItemPool.childCount == 0 then
            local itemObj = Helper.NewObject(self._ui.SelectItemTemplate, self._ui.SelectItemGrid)
            CtrlManager.AddClick(self, itemObj)
            CtrlManager.AddPress(self, itemObj)
            item = itemObj.transform
        else
            item = self._ui.SelectItemPool:GetChild(0)
            item.parent = self._ui.SelectItemGrid
            item.localScale = Vector3.one
        end

        item.gameObject:SetActive(true)
        item.gameObject.name = tostring(itemId)

        -- construct item
        self:ConstructGridItem(item, itemId)
    end

    self._ui.SelectItemGridWrap:SortBasedOnScrollMovement()
    self._ui.SelectItemScrollView:ResetPosition()
    self._ui.SelectItemScrollView.disableDragIfFits = (#self._itemList <= itemCount)
    self._ui.SelectItemScrollView.restrictWithinPanel = true
end

function CustomDemandCtrl:ConstructGridItem(item, itemId)
    UIHelper.ConstructItemIconAndNum(self, item, itemId, nil)
    -- name
    local nameLabel = item:Find("Name"):GetComponent("UILabel")
    nameLabel.text = ConfigUtils.GetItemName(itemId)
    -- num
    local itemNum = GameData.GetItemNum(itemId)
    local numLabel = item:Find("Num"):GetComponent("UILabel")
    numLabel.text = "x"..tostring(itemNum)   
    -- selected state
    self:ToggleSelectState(item, itemId, itemId == self._selectedItemId)
end

function CustomDemandCtrl:ToggleSelectState(item, itemId, selected)
    if itemId == nil then
        return
    end

    if item == nil then
        item = self._ui.SelectItemGrid:Find(itemId)
    end

    if item ~= nil then
        local selectedMark = item:Find("Mark/Select").gameObject
        selectedMark:SetActive(selected)
    end
end

function CustomDemandCtrl:OnItemUpdate(itemObj, itemIndex, itemRealIndex)
    itemRealIndex = itemRealIndex + 1
    if itemRealIndex <= 0 or itemRealIndex > #self._itemList then
        itemObj:SetActive(false)
    else
        itemObj:SetActive(true)
        local itemId = self._itemList[itemRealIndex]
        itemObj.name = itemId
        -- construct item
        self:ConstructGridItem(itemObj.transform, itemId)
    end
end

function CustomDemandCtrl.OnItemUpdateGlobal(itemObj, itemIndex, itemRealIndex)
    local ctrl = CtrlManager.GetCtrlByName(CtrlNames.CustomDemand)
    if ctrl ~= nil then
        ctrl:OnItemUpdate(itemObj, itemIndex, itemRealIndex)
    end
end

-- on clicked
function CustomDemandCtrl:OnClicked(go)

    if go == self._ui.Blocker then
        SoundSystem.PlayUICancelSound()
        CtrlManager.PopPanel()
    elseif go == self._ui.ButtonConfirm then
        
        local isRewardValid = ConfigUtils.IsValidItem(self._rewardId)
        local isSubmitValid = ConfigUtils.IsValidItem(self._submitId)
        if not isRewardValid and not isSubmitValid then
            SoundSystem.PlayWarningSound()
            CtrlManager.ShowMessageBox({message = SAFE_LOC("提交和奖励物品不能同时为空"), single = true})
            return true
        end

        local rewardId = self._rewardId
        if not isRewardValid then
            rewardId = INVALID_ID_0
        end

        local submitId = self._submitId
        if not isSubmitValid then
            submitId = INVALID_ID_0
        end

        SoundSystem.PlayUIClickSound()
        NetManager.Send("DemandCustom", {
            CustomSubmit = submitId,
            CustomReward = rewardId,
        }, CustomDemandCtrl.OnHandleProto, self)
    elseif go.transform.parent == self._ui.SelectItemGrid then
        SoundSystem.PlayUIClickSound()
        local itemId = tonumber(go.name)
        if itemId ~= self._selectedItemId then
            self:ToggleSelectState(nil, self._selectedItemId, false)
            self._selectedItemId = itemId
            self:ToggleSelectState(nil, self._selectedItemId, true)
        else
            self:ToggleSelectState(nil, self._selectedItemId, false)
            self._selectedItemId = nil
        end
    elseif go == self._ui.SelectBlocker then
        SoundSystem.PlayUIClickSound()
        self:ExitSelectMode()
    elseif go == self._ui.SelectedRewardItem then
        SoundSystem.PlayUIClickSound()
        self:EnterSelectMode(SelectMode.Reward)
    elseif go == self._ui.SelectedSubmitItem then
        SoundSystem.PlayUIClickSound()
        self:EnterSelectMode(SelectMode.Submit)
    end

	return true
end

-- on pressed
function CustomDemandCtrl:OnPressed(go, pressed, isLong)
    if pressed and isLong then
        SoundSystem.PlayUIClickSound()
        local itemId = tonumber(go.name)
        CtrlManager.ShowItemDetail({itemId = itemId})
    end
end

function CustomDemandCtrl:OnHandleProto(proto, data, requestData)
    if proto == "DemandCustom" then
        -- here will notify DemandChanged
        GameData.RefreshDemandList(data, true)
        -- sync server time
        local serverTime = data.ServerTime or 0
        if serverTime > 0 then
            GameData.SetServerTime(serverTime)
        end

        -- close this panel
        CtrlManager.PopPanel()
    end
end

-- handle the escapse button
function CustomDemandCtrl:HandleEscape()
    if self._ui.SelectPanel.activeSelf then
        self:OnClicked(self._ui.SelectBlocker)
    else
        self:OnClicked(self._ui.Blocker)
    end
end