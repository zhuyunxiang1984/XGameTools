require "FreakPlanet/View/CatchFishMainPanel"
require "FreakPlanet/Module/CatchFish/BehaviorImplement/require"

local class = require "FreakPlanet/Utils/middleclass"
CatchFishMainCtrl  = class(CtrlNames.CatchFishMain, BaseCtrl)

--随机涟漪时间
local RANDOM_RIPPLE_TIME_MIN = 1000
local RANDOM_RIPPLE_TIME_MAX = 3000

-- load the ui prefab
function CatchFishMainCtrl:LoadPanel()
	self:CreatePanel("CatchFishMain")
end

-- construct ui panel data
function CatchFishMainCtrl:ConstructUI(obj)
	self._ui = CatchFishMainPanel.Init(obj)
end

-- fill ui with the data
function CatchFishMainCtrl:SetupUI()
	local ui = self._ui
	self.StageId = self._parameter.StageId
	self.StageType = ConfigUtils.GetCatchFishStageType(self.StageId)
	self.SuppleFish = ConfigUtils.GetCatchFishStageSuppleFish(self.StageId)
	XDebug.Log('GGYY', "play catchfish " .. self.StageId)

	CtrlManager.AddClick(self, ui.btnDone)
	CtrlManager.AddClick(self, ui.btnQuit)
	CtrlManager.AddClick(self, ui.btnAddEnergy)

	CtrlManager.AddClick(self, ui.btnCatchItem1)
	CtrlManager.AddClick(self, ui.btnCatchItem2)
	CtrlManager.AddClick(self, ui.btnCatchItem3)
	CtrlManager.AddClick(self, ui.btnCatchItem4)
	for i,v in ipairs(ui.Grids) do
		CtrlManager.AddClick(self, v.gameObject)
	end
	CtrlManager.AddClick(self, ui.View.btnHelp)

	self.OnCatchFish_AddFish = function(fishUid)
		self:AddFishObj(fishUid)
	end
	self.OnCatchFish_DelFish = function(fishUid, gridx, gridy)
		--不要一起表现捞起
		--self:PerformShipCatched(fishUid)
		table.insert(self.WaitToCatched, {fishUid, gridx, gridy})
	end
	self.OnCatchFish_Move = function(fishUid, gridIndex)
		self:PerformShipMove(fishUid, gridIndex, math.random(0, 1) / 200)
	end
	self.OnCatchFish_Struggle = function(fishUid, gridx, gridy, endurance)
		--不要一起表现捞起
		--self:PerformShipStruggle(fishUid)
		table.insert(self.WaitToCatched, {fishUid, gridx, gridy, endurance})
	end
	self.OnCatchFish_Reborn = function(fishUid)
		self:PerformShipAppear(fishUid, math.random(0, 1) / 200)
	end
	self.OnCatchFish_BuyEnergyComplete = function()
		self:UpdateUIEnergy()
	end

	GameNotifier.AddListener(GameEvent.CatchFish_AddFish, self.OnCatchFish_AddFish)
	GameNotifier.AddListener(GameEvent.CatchFish_DelFish, self.OnCatchFish_DelFish)
	GameNotifier.AddListener(GameEvent.CatchFish_Move, self.OnCatchFish_Move)
	GameNotifier.AddListener(GameEvent.CatchFish_Struggle, self.OnCatchFish_Struggle)
	GameNotifier.AddListener(GameEvent.CatchFish_Reborn, self.OnCatchFish_Reborn)
	GameNotifier.AddListener(GameEvent.CatchFish_BuyEnergyComplete, self.OnCatchFish_BuyEnergyComplete)
	--
	self.FishViews = {}
	self.CatchCards = {}
	self.WaitToCatched = {}
	self.WaitToRecycle = {}
	self.CheckAutoFinish = false --是否检测自动结算
	self.HasGameFinish = false --是否已经结算


	self:InitFishPool(self.StageId)
	self:StartRandomRipple()
	self:PlayBossAnim("CatchFish_BossCommon")
end

function CatchFishMainCtrl:DestroyImpl()
	GameNotifier.RemoveListener(GameEvent.CatchFish_AddFish, self.OnCatchFish_AddFish)
	GameNotifier.RemoveListener(GameEvent.CatchFish_DelFish, self.OnCatchFish_DelFish)
	GameNotifier.RemoveListener(GameEvent.CatchFish_Move, self.OnCatchFish_Move)
	GameNotifier.RemoveListener(GameEvent.CatchFish_Struggle, self.OnCatchFish_Struggle)
	GameNotifier.RemoveListener(GameEvent.CatchFish_Reborn, self.OnCatchFish_Reborn)
	GameNotifier.RemoveListener(GameEvent.CatchFish_BuyEnergyComplete, self.OnCatchFish_BuyEnergyComplete)
end

-- on clicked
function CatchFishMainCtrl:OnClicked(go)
	local ui = self._ui
	if go == ui.btnDone then
		SoundSystem.PlayUIClickSound()
		CtrlManager.ShowMessageBox({ message = "确定结算吗?", single = false, onConfirm = function()
			self:GameFinish()
		end, receiver = self, })

	elseif go == ui.btnQuit then
		SoundSystem.PlayUICancelSound()
		CtrlManager.ShowMessageBox({ message = "确定要放弃吗？\n（当前进度不会保存）", single = false, onConfirm = function()
			self:Close()
		end, receiver = self, })
	elseif go == ui.btnCatchItem1 then
		SoundSystem.PlayUIClickSound()
		self:SelectCatchNet(self.CatchCardIndex == 1 and -1 or 1)
	elseif go == ui.btnCatchItem2 then
		SoundSystem.PlayUIClickSound()
		self:SelectCatchNet(self.CatchCardIndex == 2 and -1 or 2)
	elseif go == ui.btnCatchItem3 then
		SoundSystem.PlayUIClickSound()
		self:SelectCatchNet(self.CatchCardIndex == 3 and -1 or 3)
	elseif go == ui.btnCatchItem4 then
		SoundSystem.PlayUIClickSound()
		self:SelectCatchNet(self.CatchCardIndex == 4 and -1 or 4)
	elseif go == ui.btnAddEnergy then
		SoundSystem.PlayUIClickSound()
		self:OnClickBuyEnergy()
	elseif go == ui.View.btnHelp then
		SoundSystem.PlayUIClickSound()
		CtrlManager.OpenPanel(CtrlNames.CatchFishHelp)
	else
		for i, v in ipairs(ui.Grids) do
			if go == v.gameObject then
				self:OnClickGrid(i)
				break
			end
		end
	end
	return true
end

-- handle the escape button
function CatchFishMainCtrl:HandleEscape()
	self:OnClicked(self._ui.btnQuit)
end

--
function CatchFishMainCtrl:OnClickBuyEnergy()
	if GameDataCatchFish.EnergyPurchaseCount >= ConfigUtils.GetCatchFishBuyEnergyMaxCount() then
		CtrlManager.ShowMessageBox({message = "已达到购买次数上限", single = true, onConfirm = nil})
		return
	end
	local purchaseCount = GameDataCatchFish.EnergyPurchaseCount + 1
	local info = ConfigUtils.GetCatchFishBuyEnergyInfo(purchaseCount)
	CtrlManager.OpenPanel(CtrlNames.CatchFishBuyEnergy,
			{
				CostId = ItemType.Diamond, CostNum= info.CostDiamond, ItemId = ItemType.CatchFishPoint, ItemNum = info.Point,
				CurBuy = GameDataCatchFish.EnergyPurchaseCount, MaxBuy = ConfigUtils.GetCatchFishBuyEnergyMaxCount(),
			 	OnConfirm = function()
					self:OnConfirmBuyEnergy(purchaseCount)
				end})
end

--
function CatchFishMainCtrl:OnConfirmBuyEnergy(purchaseCount)
	local info = ConfigUtils.GetCatchFishBuyEnergyInfo(purchaseCount)
	--XDebug.Log('GGYY', GameData.GetItemNum(ItemType.Diamond), info.CostDiamond)
	if GameData.GetItemNum(ItemType.Diamond) < info.CostDiamond then
		CtrlManager.ShowMessageBox({message = ConfigUtils.GetItemName(ItemType.Diamond) .. "不足", single = true, onConfirm = nil})
		return
	end
	GameDataCatchFish.RequestBuyEnergy(purchaseCount)
end

--
function CatchFishMainCtrl:OnHandleProto(proto, data, requestData)
	if proto == "FishLevelSettle" then
		XDebug.LogTable('GGYY', "FishLevelSettle", data)
		local param = {
			StageId = self.StageId,
			Score = data.Score,
			Stars = data.Stars,
			RewardList = data.RewardList,
			ChallengeRank = data.ChallengeRank,
			ChallengeScore = data.ChallengeScore,
			EnergyScore = data.EnergyScore,
			IsChallenge = data.ChallengeScore > 0,
			IsSuccess = data.ChallengeScore > 0 and true or data.Stars >= 1,
		}
		CtrlManager.OpenPanel(CtrlNames.CatchFishMainResult, param)
	end
end

--update
function CatchFishMainCtrl:UpdateImpl(deltaTime)
	if self.Nodes then
		for i, node in ipairs(self.Nodes) do
			node:Tick(deltaTime)
		end
		for i = #self.Nodes, 1, -1 do
			if not self.Nodes[i]:IsRunning() then
				table.remove(self.Nodes, i)
			end
		end
	end
	if self.WaitToRecycle then
		for i = #self.WaitToRecycle, 1, -1 do
			local data = self.WaitToRecycle[i]
			data.TimeCounter = data.TimeCounter + deltaTime
			if data.TimeCounter >= data.Time then
				self._ui.ObjPool:RecycleObj(data.Obj)
				table.remove(self.WaitToRecycle, i)
			end
		end
	end
	if self.CheckAutoFinish and self:IsPerformCompleted() then
		if not GameDataCatchFish.HasFish() and not self.HasGameFinish then
			self:GameFinish()
		end
		self.CheckAutoFinish = false
	end
	self:TickRandomRipple(deltaTime)
end

--绘制预览
function CatchFishMainCtrl:DrawCatchPerview()
	XDebug.LogTable('GGYY', "catch result:", self.CatchData)
	local ui = self._ui
	self:SetEditLayer1()

end

--初始化鱼塘
function CatchFishMainCtrl:InitFishPool(stageId)
	local stageInfo = GameDataCatchFish.GetFishPoolInfo(stageId)
	if not stageInfo then
		return
	end
	self.Nodes = {}
	GameDataCatchFish.InitData(stageInfo)
	GameDataCatchFish.InitSettleData(stageId)

	local ui = self._ui
	ui.ObstaclesRoot.gameObject:SetActive(true)
	for i,v in ipairs(ui.Obstacles) do
		v:SetActive(v.name == stageInfo.ObstacleNode)
	end

	if self:IsChallenge() then
		--挑战关鱼塘
		local datas = GameDataCatchFish.GenerateChalleagePool(
				CatchFish_CommonConfig.ChallengeFishNum.Fish1Num,
				CatchFish_CommonConfig.ChallengeFishNum.Fish2Num,
				CatchFish_CommonConfig.ChallengeFishNum.Fish3Num,
				CatchFish_CommonConfig.ChallengeFishNum.GoldFishNum)
		for i, v in ipairs(datas) do
			GameDataCatchFish.AddFishByIndex(v.fish, v.slot)
		end
	else
		--普通关鱼塘
		for i, v in ipairs(stageInfo.Data) do
			if v == 0 then
				goto continue
			end
			local x, y = GameDataCatchFish.IndexToGrid(i)
			--XDebug.Log('GGYY', x .. " " .. y .. " " .. i)
			if v > 0 then
				GameDataCatchFish.AddFish(v, x, y)
			else
				GameDataCatchFish.AddObstacle(x, y)
			end
			::continue::
		end
	end

	for i,v in ipairs(GameDataCatchFish.FishDataList) do
		self:PerformShipAppear(v.Uid, math.random(0, 100) / 100)
	end

	self:InitUIStar()
	self:UpdateUIScore()
	self:UpdateUIEnergy()
	self:UpdateUICatchCards()
	self:SelectCatchNet(-1)
end

--选择打捞方式
function CatchFishMainCtrl:SelectCatchNet(catchCardIndex)
	if self.CatchCardIndex == catchCardIndex then
		return
	end
	self.CatchCardIndex = catchCardIndex
	self:UpdateUICatchItemSelectState()
	self.LastClickGrid = -1
	self.CatchData = nil
	self:HideCatchPerview()
	if catchCardIndex > 0 then
		self.CatchId = GameDataCatchFish.GetCatchCard(catchCardIndex)
		self.CatchInfo = GameDataCatchFish.GetCatchInfo(self.CatchId)
		self:EnterCatchMode()
	else
		self.CatchId = -1
		self.CatchInfo = nil

		self:ExitCatchMode()
	end
end

--
function CatchFishMainCtrl:EnterCatchMode()
	local ui = self._ui
	ui.GridsRoot.gameObject:SetActive(true)

	self:ShowNormalGird()
end
--
function CatchFishMainCtrl:ExitCatchMode()
	local ui = self._ui
	ui.GridsRoot.gameObject:SetActive(false)

	self.CatchData = nil
	self.LastClickGrid = -1
	self.CatchData = nil
	self:HideCatchPerview()
end
--
function CatchFishMainCtrl:ShowNormalGird()
	local ui = self._ui
	for i, v in ipairs(ui.Grids) do
		local gridData = GameDataCatchFish.GetGridDataByIndex(i)
		--XDebug.Log('GGYY', "index:"..i .. " value:" .. gridData)
		if gridData == -1 then
			v.gameObject:SetActive(false)
			v.spriteName = ""
		else
			v.gameObject:SetActive(true)
			v.spriteName = "GoldFishGrid_Normal"
		end

	end
end
--
function CatchFishMainCtrl:ShowSelectGird(gridx, gridy)
	local ui = self._ui
	local index = GameDataCatchFish.GridToIndex(gridx, gridy)
	ui.Grids[index].spriteName = "GoldFishGrid_Checked"
end

--
function CatchFishMainCtrl:ShowCatchPerview(catchData)
	local ui = self._ui
	self:ShowNormalGird()
	for i,v in ipairs(catchData.GridsTable) do
		self:ShowSelectGird(GameDataCatchFish.IndexToGrid(v))
	end
	for k,v in pairs(catchData.EscapedTable) do
		local fishData = GameDataCatchFish.GetFish(k)
		if not fishData then
			goto continue
		end
		local index = GameDataCatchFish.GridToIndex(fishData.CurPosX, fishData.CurPosY)
		local position = ui.Grids[index].transform.localPosition
		--
		local arrowObj = ui.ObjPool:GetOrCreateObj(EnumPrefabName.CatchFish_Arrow)
		arrowObj.transform:SetParent(ui.PerviewObjsRoot, false)

		local offsetx = v.MoveX - fishData.CurPosX
		local offsety = v.MoveY - fishData.CurPosY
		--local pos = arrowObj.transform.localPosition
		arrowObj.transform.localPosition = position

		local eular = arrowObj.transform.eulerAngles
		eular.z = GameDataCatchFish.GetRotZ(offsetx, offsety)
		arrowObj.transform.eulerAngles = eular

		::continue::
	end
	for i,v in ipairs(catchData.CatchTable) do
		local fishData = GameDataCatchFish.GetFish(v.fishUid)
		if not fishData then
			goto continue
		end
		local index = GameDataCatchFish.GridToIndex(fishData.CurPosX, fishData.CurPosY)
		local position = ui.Grids[index].transform.localPosition
		--
		local scoreObj = ui.ObjPool:GetOrCreateObj(EnumPrefabName.CatchFish_Score)
		scoreObj.transform:SetParent(ui.PerviewObjsRoot, false)

		scoreObj:GetComponent("UILabel").text = "+" .. v.score

		position.y = position.y + 50
		scoreObj.transform.localPosition = position

		::continue::
	end
end
--
function CatchFishMainCtrl:HideCatchPerview()
	local ui = self._ui
	ui.ObjPool:RecycleAllObjByKey(EnumPrefabName.CatchFish_Arrow)
	ui.ObjPool:RecycleAllObjByKey(EnumPrefabName.CatchFish_Score)
end

--
function CatchFishMainCtrl:OnClickGrid(index)
	if self.CatchCardIndex == -1 then
		return
	end
	if not self:IsPerformCompleted() then
		return
	end
	local gridx, gridy = GameDataCatchFish.IndexToGrid(index)
	local isConfirm = false
	if self.CatchData then
		local catchInfo = GameDataCatchFish.GetCatchInfo(self.CatchId)
		if catchInfo.Type == GameDataCatchFish.EnumCatchType.Cross then
			if self.LastClickGrid == index then
				isConfirm = true
			end
		else
			for i,v in ipairs(self.CatchData.GridsTable) do
				if v == index then
					isConfirm = true
					break
				end
			end
		end
	end

	if isConfirm then
		self:ConfirmCatch()
		self:SelectCatchNet(-1)
		self.LastClickGrid = -1
		self.CatchData = nil
		self:HideCatchPerview()
	else
		self:PerviewCatch(self.CatchId, gridx, gridy)
		self.LastClickGrid = index
	end

end

--打捞预览
function CatchFishMainCtrl:PerviewCatch(catchId, gridx, gridy)
	local catchInfo = GameDataCatchFish.GetCatchInfo(catchId)
	if not catchInfo then
		return
	end
	self.CatchData = GameDataCatchFish.CalcCatch(catchId, gridx, gridy)
	self:HideCatchPerview()
	self:ShowCatchPerview(self.CatchData)
end

--确认打捞
function CatchFishMainCtrl:ConfirmCatch()
	if not self.CatchData then
		return
	end
	if GameDataCatchFish.GetCurPoint() < self.CatchInfo.Cost then
		CtrlManager.ShowMessageBox({message = "能量不足，请补充能量", single = false, onConfirm = function()
			self:OnClickBuyEnergy()
		end})
		return
	end
	--记录捞鱼的数据,用于服务器计算
	local fishIds = {}
	for i,v in ipairs(self.CatchData.CatchTable) do
		local fishData = GameDataCatchFish.GetFish(v.fishUid)
		if fishData then
			table.insert(fishIds, {FishId = fishData.Id, CatchTimes = v.endurance})
		end
	end
	if #fishIds > 0 then
		GameDataCatchFish.AddSettleData_CatchFish(self.CatchId, fishIds, self.CatchData:GetGoldFishNum())
	else
		--空捞也要上传数据
		GameDataCatchFish.AddSettleData_CatchFish(self.CatchId, nil, 0)
	end

	local deadFishes = GameDataCatchFish.GetDeadFishDatas(self.CatchData)

	GameDataCatchFish.ApplyCatchResult(self.CatchData)
	GameDataCatchFish.AddPoint(-self.CatchInfo.Cost)

	--捕捞表现
	--self.CatchInfo.Type == EnumCatchType.Point
	local catchType = ConfigUtils.GetCatchFishCatchType(self.CatchId)
	local gridTable = self.CatchData.GridsTable
	if catchType == GameDataCatchFish.EnumCatchType.Cross then
		self:PerformNetCatchCross(gridTable[1])
	elseif catchType == GameDataCatchFish.EnumCatchType.Point then
		self:PerformNetCatchPoint(gridTable[1])
	elseif catchType == GameDataCatchFish.EnumCatchType.Horn then
		self:PerformNetCatchHorn(gridTable[1], gridTable[#gridTable])
	elseif catchType == GameDataCatchFish.EnumCatchType.Vert then
		self:PerformNetCatchVert(gridTable[1], gridTable[#gridTable])
	end
	SoundSystem.PlaySoundOfName(SoundNames.SE_CatchFish_DoCatch)

	local ui = self._ui
	if #self.WaitToCatched > 0 then
		local catchData = self.CatchData
		for i, v in ipairs(self.WaitToCatched) do
			local fishUid = v[1]
			local gridx = v[2]
			local gridy = v[3]
			local endurance = v[4]

			local sequenceNode = SBTree_SequenceNode:new()
			sequenceNode:AddNode(SBTree_TimeNode:new(i * 0.1))
			local parallelNode = SBTree_ParallelNode:new()
			sequenceNode:AddNode(parallelNode)
			parallelNode:AddNode(SBTree_CallMethodNode:new(function()
				if endurance then
					self:PerformShipStruggle(fishUid)
				else
					self:PerformShipCatched(fishUid)
				end
			end))
			parallelNode:AddNode(SBTree_CallMethodNode:new(function()
				local fishView = self.FishViews[fishUid]
				local objScore = ui.ObjPool:GetOrCreateObj(EnumPrefabName.CatchFish_ScoreAnim)
				objScore.transform:SetParent(ui.PerviewObjsRoot, false)
				local position = fishView.Trans.localPosition
				position.y = position.y + 50
				objScore.transform.localPosition = position
				local score = catchData:GetScoreByFishUid(fishUid)
				objScore.transform:Find("ScoreCommon"):GetComponent("UILabel").text = "+".. score
				self:RecycleAfterTime(objScore, 1)
			end))
			table.insert(self.Nodes, sequenceNode)
		end
		self.WaitToCatched = {}
	end

	--额外分数效果
	local score, bonus = self.CatchData:CalcTotalScore()
	if bonus > 0 then
		local objBonusScore = ui.ObjPool:GetOrCreateObj(EnumPrefabName.CatchFish_SpecialScoreAnim)
		objBonusScore.transform:SetParent(ui.PerviewObjsRoot, false)
		objBonusScore.transform:Find("ScoreSpecial"):GetComponent("UILabel").text = "+".. bonus
		self:RecycleAfterTime(objBonusScore, 1)
	end

	--刷新鱼(延迟)
	if self.SuppleFish then
		local sequenceNode = SBTree_SequenceNode:new()
		sequenceNode:AddNode(SBTree_TimeNode:new(1))
		sequenceNode:AddNode(SBTree_CallMethodNode:new(function()
			GameDataCatchFish.Reborn(deadFishes)
		end))
		table.insert(self.Nodes, sequenceNode)
	end

	--老板表情
	local bossDialogIndex = ConfigUtils.GetBossDialogIndexByScore(score)
	if bossDialogIndex > 0 then
		self:PlayBossAnim(ConfigUtils.GetBossDialogAnim(bossDialogIndex))
		self:PlayBossDialog(ConfigUtils.GetBossDialogEff(bossDialogIndex))
	end


	self:UpdateUIScore()
	self:UpdateUIEnergy()
	self.CheckAutoFinish = true
end

--游戏结算
function CatchFishMainCtrl:GameFinish()
	if self.HasGameFinish then
		return
	end
	self.HasGameFinish = true
	--关闭弹出框
	CtrlManager.PopPanelByName(CtrlNames.MessageBox)
	NetManager.Send('FishLevelSettle', GameDataCatchFish.CatchFishSettleData, CatchFishMainCtrl.OnHandleProto, self, false)
end

---更新UI-------------------------------------------------------------------

--初始化分数星星
function CatchFishMainCtrl:InitUIStar()
	--[[
	local ui = self._ui
	local stageInfo = GameDataCatchFish.GetFishPoolInfo(self.StageId)

	ui.NormalScoreLayoutView:InitStar(
			stageInfo.Score1Star / stageInfo.Score3Star,
			stageInfo.Score2Star / stageInfo.Score3Star,
			1.0)
	--]]
end

--更新分数
function CatchFishMainCtrl:UpdateUIScore()
	local ui = self._ui
	local stageInfo = GameDataCatchFish.GetFishPoolInfo(self.StageId)

	local score = GameDataCatchFish.GetScore()
	ui.NormalScoreLayoutView.txtScore.text = score
	ui.NormalScoreLayoutView.imgProgressBar.fillAmount = self:CalcScoreBarFillAmount(score, stageInfo)

	ui.NormalScoreLayoutView:SetMode(self.StageType)
	if self.StageType == EnumCatchFishStageType.Normal then
		ui.NormalScoreLayoutView:ShowStar(1, score >= stageInfo.Score1Star)
		ui.NormalScoreLayoutView:ShowStar(2, score >= stageInfo.Score2Star)
		ui.NormalScoreLayoutView:ShowStar(3, score >= stageInfo.Score3Star)
	else
	end
end

--
function CatchFishMainCtrl:CalcScoreBarFillAmount(score, stageInfo)
	local score1 = stageInfo.Score1Star
	local score2 = stageInfo.Score2Star
	local score3 = stageInfo.Score3Star
	if score <= score1 then
		return 0.3 * score / score1
	end
	if score <= score2 then
		return 0.3 + 0.3 * (score - score1) / (score2 - score1)
	end
	return 0.6 + 0.4 * (score - score2) / (score3 - score2)
end

--更新能量
function CatchFishMainCtrl:UpdateUIEnergy()
	local ui = self._ui

	ui.txtEnergy.text = string.format("%d", GameDataCatchFish.GetCurPoint())
end
--更新打捞卡片
function CatchFishMainCtrl:UpdateUICatchCards()
	local ui = self._ui
	local cards = GameDataCatchFish.GetCatchCards()

	self:UpdateUICatchCard(ui.objCatchItem1, cards[1] or -1)
	self:UpdateUICatchCard(ui.objCatchItem2, cards[2] or -1)
	self:UpdateUICatchCard(ui.objCatchItem3, cards[3] or -1)
	self:UpdateUICatchCard(ui.objCatchItem4, cards[4] or -1)
	ui.CatchCardContent:Reposition()
end

--
function CatchFishMainCtrl:UpdateUICatchCard(catchItem, catchId)
	if catchId == -1 then
		catchItem.gameObject:SetActive(false)
		return
	end
	local catchInfo = GameDataCatchFish.GetCatchInfo(catchId)
	if not catchInfo then
		return
	end
	catchItem:Find("txtName"):GetComponent("UILabel").text = catchInfo.Name
	catchItem:Find("txtCost"):GetComponent("UILabel").text = catchInfo.Cost
	catchItem:Find("imgIcon1"):GetComponent("UISprite").spriteName = catchInfo.Icon1
	catchItem:Find("imgIcon2"):GetComponent("UISprite").spriteName = catchInfo.Icon2
	catchItem.gameObject:SetActive(true)
end

--
function CatchFishMainCtrl:UpdateUICatchItemSelectState()
	local ui = self._ui

	ui.objCatchItem1:Find("imgSelect").gameObject:SetActive(self.CatchCardIndex == 1)
	ui.objCatchItem2:Find("imgSelect").gameObject:SetActive(self.CatchCardIndex == 2)
	ui.objCatchItem3:Find("imgSelect").gameObject:SetActive(self.CatchCardIndex == 3)
	ui.objCatchItem4:Find("imgSelect").gameObject:SetActive(self.CatchCardIndex == 4)
end

---动画表现-------------------------------------------------------------------

function CatchFishMainCtrl:AddFishObj(fishUid)
	if self.FishViews[fishUid] then
		return
	end
	local ui = self._ui
	local fishData = GameDataCatchFish.GetFish(fishUid)
	if not fishData then
		return
	end
	local index = GameDataCatchFish.GridToIndex(fishData.CurPosX, fishData.CurPosY)
	local prefabName = ConfigUtils.GetCatchFishFishPrefabName(fishData.Id)
	prefabName = prefabName .. "_" .. fishData:GetLeftEndurance()
	local fishObj = ui.ObjPool:GetOrCreateObj(prefabName)
	fishObj.transform:SetParent(ui.FishesRoot)
	local scale = fishObj.transform.localScale
	scale.x = 100
	scale.y = 100
	scale.z = 1
	fishObj.transform.localScale = scale
	fishObj.transform.localPosition = ui:GetGridPos(index)
	fishObj:SetActive(false)
	self.FishViews[fishUid] = {
		Obj = fishObj,
		Trans = fishObj.transform,
		Skeleton = fishObj:GetComponent("SkeletonAnimation"),
		SetDepth = function(view, depth)
			local pos = view.Trans.localPosition
			pos.z = depth
			view.Trans.localPosition = pos
			--XDebug.Log('GGYY', string.format("fish %d depth is %d", fishUid, depth))
		end
	}
end
function CatchFishMainCtrl:DelFishObj(fishUid)
	if not self.FishViews[fishUid] then
		return
	end
	if self.FishViews[fishUid].Obj then
		local ui = self._ui
		ui.ObjPool:RecycleObj(self.FishViews[fishUid].Obj)
	end
	self.FishViews[fishUid] = nil
end

function CatchFishMainCtrl:IsPerformCompleted()
	return #self.Nodes < 1
end

--鱼儿出现
function CatchFishMainCtrl:PerformShipAppear(fishUid, delay)
	if not self.FishViews[fishUid] then
		return
	end
	local fishView = self.FishViews[fishUid]
	local fishData = GameDataCatchFish.GetFish(fishUid)
	local sequenceNode = SBTree_SequenceNode:new()
	if delay then
		sequenceNode:AddNode(SBTree_TimeNode:new(delay))
	end
	sequenceNode:AddNode(SBTree_CallMethodNode:new(function()
		fishView:SetDepth(fishData:GetDepth())
		fishView.Obj:SetActive(true)
	end))
	sequenceNode:AddNode(SBTreeNode_CatchFish_PlayAnim:new(fishView.Skeleton, "GoUp", false))
	sequenceNode:AddNode(SBTree_CallMethodNode:new(function()
		Helper.PlayAnimation(fishView.Skeleton, "Idle", true)
	end))
	table.insert(self.Nodes, sequenceNode)
end

--鱼儿游走
function CatchFishMainCtrl:PerformShipMove(fishUid, gridIndex, delay)
	if not self.FishViews[fishUid] then
		return
	end
	local ui = self._ui
	local fishView = self.FishViews[fishUid]
	local fishData = GameDataCatchFish.GetFish(fishUid)
	local sequenceNode = SBTree_SequenceNode:new()
	if delay then
		sequenceNode:AddNode(SBTree_TimeNode:new(delay))
	end
	sequenceNode:AddNode(SBTree_CallMethodNode:new(function()
		fishView:SetDepth(fishData:GetDepth())
	end))
	sequenceNode:AddNode(SBTreeNode_CatchFish_PlayAnim:new(fishView.Skeleton, "GoDown", false, 0.4))
	sequenceNode:AddNode(SBTreeNode_CatchFish_FishMove:new(fishView, ui:GetGridPos(gridIndex), 1))
	sequenceNode:AddNode(SBTreeNode_CatchFish_PlayAnim:new(fishView.Skeleton, "GoUp", false))
	sequenceNode:AddNode(SBTree_CallMethodNode:new(function()
		Helper.PlayAnimation(fishView.Skeleton, "Idle", true)
	end))

	table.insert(self.Nodes, sequenceNode)
end

--鱼儿捞起
function CatchFishMainCtrl:PerformShipCatched(fishUid)
	if not self.FishViews[fishUid] then
		return
	end
	local ui = self._ui
	local fishView = self.FishViews[fishUid]
	local sequenceNode = SBTree_SequenceNode:new()
	sequenceNode:AddNode(SBTreeNode_CatchFish_PlayAnim:new(fishView.Skeleton, "Catched", false))
	sequenceNode:AddNode(SBTree_CallMethodNode:new(function()
		self:DelFishObj(fishUid)
	end))
	table.insert(self.Nodes, sequenceNode)
end

--鱼儿挣扎
function CatchFishMainCtrl:PerformShipStruggle(fishUid, endurance)
	if not self.FishViews[fishUid] then
		return
	end
	local ui = self._ui
	local fishView = self.FishViews[fishUid]
	local fishData = GameDataCatchFish.GetFish(fishUid)
	local sequenceNode = SBTree_SequenceNode:new()
	sequenceNode:AddNode(SBTreeNode_CatchFish_PlayAnim:new(fishView.Skeleton, "Struggle", false))
	sequenceNode:AddNode(SBTree_CallMethodNode:new(function()
		--小鱼换形象
		self:DelFishObj(fishUid)
		self:AddFishObj(fishUid)

		fishView = self.FishViews[fishUid]
		fishView:SetDepth(fishData:GetDepth())
		fishView.Obj:SetActive(true)
		Helper.PlayAnimation(fishView.Skeleton, "Idle", true)
	end))
	table.insert(self.Nodes, sequenceNode)
end

--捕捞表现
function CatchFishMainCtrl:PerformNetCatchCross(gridIndex)
	local ui = self._ui
	local netObj = ui.ObjPool:GetOrCreateObj(EnumPrefabName.CatchFish_Net3)
	netObj.transform:SetParent(ui.SortLayer3, false)
	local sequenceNode = SBTree_SequenceNode:new()
	sequenceNode:AddNode(SBTree_CallMethodNode:new(function()
		netObj.transform.localPosition = ui:GetGridPos(gridIndex)
	end))
	sequenceNode:AddNode(SBTree_TimeNode:new(1))
	sequenceNode:AddNode(SBTree_CallMethodNode:new(function()
		ui.ObjPool:RecycleObj(netObj)
	end))
	table.insert(self.Nodes, sequenceNode)
end

function CatchFishMainCtrl:PerformNetCatchPoint(gridIndex)
	local ui = self._ui
	local netObj = ui.ObjPool:GetOrCreateObj(EnumPrefabName.CatchFish_Net4)
	netObj.transform:SetParent(ui.SortLayer3, false)
	local sequenceNode = SBTree_SequenceNode:new()
	sequenceNode:AddNode(SBTree_CallMethodNode:new(function()
		netObj.transform.localPosition = ui:GetGridPos(gridIndex)
	end))
	sequenceNode:AddNode(SBTree_TimeNode:new(1))
	sequenceNode:AddNode(SBTree_CallMethodNode:new(function()
		ui.ObjPool:RecycleObj(netObj)
	end))
	table.insert(self.Nodes, sequenceNode)
end
function CatchFishMainCtrl:PerformNetCatchHorn(gridIndex1, gridIndex2)
	local ui = self._ui
	local netObj = ui.ObjPool:GetOrCreateObj(EnumPrefabName.CatchFish_Net1)
	netObj.transform:SetParent(ui.SortLayer3, false)
	local sequenceNode = SBTree_SequenceNode:new()
	sequenceNode:AddNode(SBTreeNode_CatchFish_Catch:new(netObj, ui:GetGridPos(gridIndex1), ui:GetGridPos(gridIndex2), 1))
	sequenceNode:AddNode(SBTree_CallMethodNode:new(function()
		ui.ObjPool:RecycleObj(netObj)
	end))
	table.insert(self.Nodes, sequenceNode)
end
function CatchFishMainCtrl:PerformNetCatchVert(gridIndex1, gridIndex2)
	local ui = self._ui
	local netObj = ui.ObjPool:GetOrCreateObj(EnumPrefabName.CatchFish_Net2)
	netObj.transform:SetParent(ui.SortLayer3, false)
	local sequenceNode = SBTree_SequenceNode:new()
	sequenceNode:AddNode(SBTreeNode_CatchFish_Catch:new(netObj, ui:GetGridPos(gridIndex1), ui:GetGridPos(gridIndex2), 1))
	sequenceNode:AddNode(SBTree_CallMethodNode:new(function()
		ui.ObjPool:RecycleObj(netObj)
	end))
	table.insert(self.Nodes, sequenceNode)
end

function CatchFishMainCtrl:RecycleAfterTime(obj, time)
	table.insert(self.WaitToRecycle, {Obj = obj, Time = time, TimeCounter = 0})
end

function CatchFishMainCtrl:IsChallenge()
	return self.StageType == EnumCatchFishStageType.Challenge
end

function CatchFishMainCtrl:StartRandomRipple()
	self.RandomRippleTime = math.random(RANDOM_RIPPLE_TIME_MIN, RANDOM_RIPPLE_TIME_MAX) / 1000
	self.RandomRippleTimeCounter = 0
end
function CatchFishMainCtrl:TickRandomRipple(deltaTime)
	self.RandomRippleTimeCounter = self.RandomRippleTimeCounter + deltaTime
	if self.RandomRippleTimeCounter >= self.RandomRippleTime then
		self:StartRandomRipple()
		self:PlayRipple(math.random(-250, 250), math.random(-250, 250))
	end
end
function CatchFishMainCtrl:PlayRipple(x, y)
	local ui = self._ui
	local obj = ui.ObjPool:GetOrCreateObj(EnumPrefabName.CatchFish_EffectRipple)
	obj.transform:SetParent(ui.SortLayer3, false)
	local position = obj.transform.localPosition
	position.x = x
	position.y = y
	obj.transform.localPosition= position
	self:RecycleAfterTime(obj, 2.5)
end

function CatchFishMainCtrl:PlayBossAnim(name)
	local view = self._ui.View.Boss
	view:Play(name)
end
function CatchFishMainCtrl:PlayBossDialog(name)
	local view = self._ui.View.BossDialog
	view:Play(name)
	XDebug.Log('GGYY', "play boss dialog " .. name)
end