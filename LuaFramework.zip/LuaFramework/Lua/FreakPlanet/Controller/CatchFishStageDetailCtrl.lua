require "FreakPlanet/View/CatchFishStageDetailPanel"

local class = require "FreakPlanet/Utils/middleclass"
CatchFishStageDetailCtrl  = class(CtrlNames.CatchFishStageDetail, BaseCtrl)

local GOLD_FISH_STAR_SPRITE = "GoldFishStar"
local GRAY_FISH_STAR_SPRITE = "GoldFishStar2"

-- load the ui prefab
function CatchFishStageDetailCtrl:LoadPanel()
	self:CreatePanel("CatchFishStageDetail")
end

-- construct ui panel data
function CatchFishStageDetailCtrl:ConstructUI(obj)
	self._ui = CatchFishStageDetailPanel.Init(obj)
end

-- fill ui with the data
function CatchFishStageDetailCtrl:SetupUI()
	self._FishPoolId = self._parameter.fishPoolId
	local fishPoolInfo = GameDataCatchFish.GetFishPoolInfo(self._FishPoolId)
	local ui = self._ui

	CtrlManager.AddClick(self, ui.Blocker)
	CtrlManager.AddClick(self, ui.ButtonStart)
	CtrlManager.AddClick(self, ui.ButtonRank)

	ui.StageTitle.text = fishPoolInfo.Name
	ui.StageLimitTxt.text = fishPoolInfo.Desc

	ui.ButtonRank:SetActive(false)
	local curStarNum = GameDataCatchFish.GetCatchFishStar(self._FishPoolId)

	for idx = 1, #ui.StageStar do
		if idx <= curStarNum then
			ui.StageStar[idx].spriteName = GOLD_FISH_STAR_SPRITE
		else
			ui.StageStar[idx].spriteName = GRAY_FISH_STAR_SPRITE
		end
	end
	local isChallengeLevel = GameDataCatchFish.IsChallengeFishPool(self._FishPoolId)
	ui.StarRoot.gameObject:SetActive(not isChallengeLevel)
	if isChallengeLevel then
		ui.ButtonRank:SetActive(true)
		ui.AwardRoot:SetActive(false)
		ui.NoAwardRoot:SetActive(true)

		local curRankNum = GameDataCatchFish.GetCurChallengeRank()
		ui.RankNum.text = curRankNum > 0 and tostring(curRankNum) or SAFE_LOC("未上榜")
	else
		ui.ButtonRank:SetActive(false)
		ui.NoAwardRoot:SetActive(false)
		ui.AwardRoot:SetActive(true)
		for idx = 1, #fishPoolInfo.RewardList do
			local reward = fishPoolInfo.RewardList[idx]
			local rewardItem = Helper.NewObject(ui.AwardItemTemplate, ui.AwardGrid.transform)
			rewardItem:SetActive(true)
			local Icon = rewardItem.transform:Find("Icon"):GetComponent("UISprite")
			local NumLabel = rewardItem.transform:Find("Num"):GetComponent("UILabel")
			UIHelper.SetItemIcon(self, Icon, reward.Id)
			NumLabel.text = string.format("x%d", reward.Num)
		end
		ui.AwardGrid:Reposition()
	end
	-- 门票
	if GameDataCatchFish.HasPaidTicketsOfCatchFish(self._FishPoolId) then
		ui.NormalTickets:SetActive(false)
		ui.PassTickets:SetActive(false)
	else
		local CostItem = nil
		local curActivityThemeId = GameData.GetCurrentActivityTheme()
		if GameData.HasActivityPassport(curActivityThemeId) then
			ui.NormalTickets:SetActive(false)
			ui.PassTickets:SetActive(true)
			CostItem = fishPoolInfo.PassCheckCostItem
			local curTicketsNum = GameData.GetItemNum(CostItem.Id)
			UIHelper.SetIconAndNumForBuyButton(self, ui.PassTicketsConsumeIcon, ui.PassTicketsConsumeNum, CostItem.Id, CostItem.Num, curTicketsNum)
		else
			ui.NormalTickets:SetActive(true)
			ui.PassTickets:SetActive(false)
			CostItem = fishPoolInfo.CostItem
			local curTicketsNum = GameData.GetItemNum(CostItem.Id)
			UIHelper.SetIconAndNumForBuyButton(self, ui.NormalTicketsConsumeIcon, ui.NormalTicketsConsumeNum, CostItem.Id, CostItem.Num, curTicketsNum)
		end
		self._CostItem = CostItem
	end
end

-- on clicked
function CatchFishStageDetailCtrl:OnClicked(go)
	local ui = self._ui
	if go == ui.Blocker then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
	elseif go == ui.ButtonStart then
		if GameDataCatchFish.HasPaidTicketsOfCatchFish(self._FishPoolId) then
			SoundSystem.PlayUIClickSound()
			CtrlManager.DoWaitTransition(CtrlNames.CatchFishStagePrepare, self, CatchFishStageDetailCtrl.CloseToCharacter, self._FishPoolId)
		else
			local curTicketsNum = GameData.GetItemNum(self._CostItem.Id)
			if curTicketsNum >= self._CostItem.Num then
				SoundSystem.PlayUIClickSound()
				CtrlManager.DoWaitTransition(CtrlNames.CatchFishStagePrepare, self, CatchFishStageDetailCtrl.CloseToCharacter, self._FishPoolId)
			else
				SoundSystem.PlayWarningSound()
				CtrlManager.ShowMessageBox({ message = "门票不足!", single = true })
			end
		end
	elseif go == ui.ButtonRank then
		SoundSystem.PlayUIClickSound()
		CtrlManager.OpenPanel(CtrlNames.CatchFishRank)
	end
	return true
end

function CatchFishStageDetailCtrl:CloseToCharacter(fishPoolId)
	CtrlManager.PopPanel()
	CtrlManager.OpenPanel(CtrlNames.CatchFishStagePrepare, { FishPoolId = fishPoolId })
end
