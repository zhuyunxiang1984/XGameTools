require "FreakPlanet/View/SignInRewardPanel"

local class = require "FreakPlanet/Utils/middleclass"
SignInRewardCtrl  = class(CtrlNames.SignInReward, BaseCtrl)

local DAYS_PER_GROUP = 8
local MONTH_CARD_COUNT = 2

local COUDLE_GET_REWARD = "SignIn_Tips_no"
local YET_GET_REWARD = "SignIn_Tips_yes"

-- load the ui prefab
function SignInRewardCtrl:LoadPanel()
	self:CreatePanel("SignInReward")
end

-- construct ui panel data
function SignInRewardCtrl:ConstructUI(obj)
	self._ui = SignInRewardPanel.Init(obj)
end

-- destructor 
function SignInRewardCtrl:DestroyImpl()	
	GameNotifier.RemoveListener(GameEvent.IapCompleted, SignInRewardCtrl.OnIapCompleted, self)
end

-- fill ui with the data
function SignInRewardCtrl:SetupUI()
	self._catState = nil
	self._catIndex = Helper.RandInt(1, #self._ui.Cats)
	self._signInGroup = GameData.GetSignInGroup(DAYS_PER_GROUP) - 1
	self._currentDay = GameData.GetCurrentSignInDay()
	local str = SAFE_LOC("loc_global_x_day")
	self._ui.SignInDays.text = string.format(str, self._currentDay)

	self:SetupRewardItems()
	self:SetupMonthCard(true)

	for idx = 1, #self._ui.Cats do
		self._ui.Cats[idx].item:SetActive(idx == self._catIndex)
	end

	CtrlManager.AddClick(self, self._ui.Blocker)
	CtrlManager.AddClick(self, self._ui.CatCollider)
	GameNotifier.AddListener(GameEvent.IapCompleted, SignInRewardCtrl.OnIapCompleted, self)
end

function SignInRewardCtrl:SetupRewardItems()
	for idx = 1, DAYS_PER_GROUP do
		local dayIndex = self._signInGroup * DAYS_PER_GROUP + idx
		local rewardItemId, rewardMin, rewardMax, rewardBG = ConfigUtils.GetSignInReward(dayIndex)
		if rewardItemId == nil then
			break
		end

		local rewardItemObj = Helper.NewObject(self._ui.RewardItemTemplate, self._ui.RewardRoot)
		rewardItemObj.name = tostring(dayIndex)
		rewardItemObj:SetActive(true)
		CtrlManager.AddClick(self, rewardItemObj)

		-- icon
		UIHelper.ConstructItemIconAndNum(self, rewardItemObj.transform, rewardItemId, rewardMin)
		-- bg
		if rewardBG ~= nil then
			rewardItemObj.transform:Find("BG"):GetComponent("UISprite").spriteName = rewardBG
		end
		-- day
		local dayLabel = rewardItemObj.transform:Find("Day"):GetComponent("UILabel")
		if dayIndex == self._currentDay then
			dayLabel.text = SAFE_LOC("loc_global_today")
		else
			local str = SAFE_LOC("loc_global_x_day")
			dayLabel.text = string.format(str, dayIndex)
		end
		-- mark
		local mark = rewardItemObj.transform:Find("Mark").gameObject
		local drawed = GameData.HasDrawedSignInReward(dayIndex)
		mark:SetActive(drawed)
	end

	self._ui.RewardRoot:GetComponent("UITable").repositionNow = true
end

function SignInRewardCtrl:SetupMonthCard(isFirst)
	for idx = 1, MONTH_CARD_COUNT do
		local module = self._ui.MonthCardModule[idx]
		if isFirst then
			CtrlManager.AddClick(self, module.item)
		end

		local hasBought = GameData.IsMonthCardBought(idx)
		local leftDay = GameData.GetMonthCardLeftDays(idx)

		if hasBought then
			if leftDay > 0 then
				module.unlock:SetActive(true)
				module.lock:SetActive(false)
				module.state.gameObject:SetActive(true)
				module.leftDays.text = string.format(SAFE_LOC("剩余%d天"), leftDay)
				if GameData.HasMonthCardReward(idx) then
					module.state.spriteName = COUDLE_GET_REWARD
				else
					module.state.spriteName = YET_GET_REWARD
				end
			else
				module.unlock:SetActive(false)
				module.lock:SetActive(true)
				module.state.gameObject:SetActive(false)
				module.leftDays.text = SAFE_LOC("已过期")
			end
		else
			module.unlock:SetActive(false)
			module.lock:SetActive(true)
			module.state.gameObject:SetActive(false)
			module.leftDays.text = SAFE_LOC("未购买")
		end
	end

	-- actor
	local hasBought = GameData.IsMonthCardBought(EMonthCardType.WuwuMonthCard)
	local leftDay = GameData.GetMonthCardLeftDays(EMonthCardType.WuwuMonthCard)

	self._ui.pObjEmptyActor:SetActive(not hasBought)
	self._ui.pObjDrawActor:SetActive(hasBought and leftDay > 0)
	self._ui.pObjExpireActor:SetActive(hasBought and leftDay <= 0)
end

function SignInRewardCtrl:ToggleStateOfRewardItem(dayIndex, show)
	local item = self._ui.RewardRoot:Find(tostring(dayIndex))
	if item ~= nil then
		local mark = item:Find("Mark").gameObject
		mark:SetActive(show)
	end
end

function SignInRewardCtrl:UpdateImpl(deltaTime)
	if self._catState ~= nil then
		local finished = self._catState:Tick(deltaTime)
		if finished then
			self._catState = nil
		end
	end
end

function SignInRewardCtrl:OnIapCompleted(iapId)
	if ConfigUtils.IsMonthCardIap(iapId) then
		self:SetupMonthCard(false)
	end
end

-- on clicked
function SignInRewardCtrl:OnClicked(go)
	if go == self._ui.Blocker then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
	elseif go == self._ui.CatCollider then
		SoundSystem.PlayUIClickSound()
		local idx = Helper.RandInt(1, 5)
		local skeleton = self._ui.Cats[self._catIndex].skeleton
		local animationName = tostring(idx)
		self._catState = SkeletonAnimationState:new(skeleton, animationName, "Idle")
	elseif go.transform.parent == self._ui.RewardRoot then
		local dayIndex = tonumber(go.name)
		if GameData.CanSignIn(dayIndex) then
			SoundSystem.PlayUIClickSound()
			NetManager.Send("SignIn", {DrawDay = dayIndex}, SignInRewardCtrl.OnHandleProto, self)
		else
			SoundSystem.PlayWarningSound()
		end
	elseif go.transform.parent == self._ui.pTransMonthCardRoot then
		SoundSystem.PlayUIClickSound()
		if go.name == "MonthlyForFive" then
			local bIsGetReward, bNeedGotoMall = self:CanGetTodaySignInReward(EMonthCardType.WuwuMonthCard)
			if bIsGetReward then
				NetManager.Send("GetCardReward", {ItemTypeCard = ItemType.Card}, SignInRewardCtrl.OnHandleProto, self)
			end
			if bNeedGotoMall then
				CtrlManager.OpenPanel(CtrlNames.Mall, {MallModule = EMallModuleNames.MonthCardGift})
			end
		elseif go.name == "MonthlyForSeven" then
			local bIsGetReward, bNeedGotoMall = self:CanGetTodaySignInReward(EMonthCardType.QiqiMonthCard)
			if bIsGetReward then
				NetManager.Send("GetCardReward", {ItemTypeCard = ItemType.Card2}, SignInRewardCtrl.OnHandleProto, self)
			end
			if bNeedGotoMall then
				CtrlManager.OpenPanel(CtrlNames.Mall, {MallModule = EMallModuleNames.MonthCardGift})
			end
		end
	end
	return true
end

function SignInRewardCtrl:OnHandleProto(proto, data, requestData)
	if proto == "SignIn" then
		NavigationCtrl.EnableSuspend(true)
		local dayIndex = requestData.DrawDay
		local reward = data.Reward
		local rewardItemId = reward.ItemId
		local rewardItemNum = reward.Num
		GameData.CollectItem(rewardItemId, rewardItemNum, true)
		if not Helper.IsEmpty(data.CardReward1)  then
			GameData.CollectItem(data.CardReward1.ItemId, data.CardReward1.Num, true)
		end

		if not Helper.IsEmpty(data.CardReward2) then
			GameData.CollectItem(data.CardReward2.ItemId, data.CardReward2.Num, true)
		end

		GameData.SetExpiredCardTime(data.ExpireCardTime)
		GameData.SetExpiredCardTimeV2(data.ExpireCardTimeV2)

		GameData.SetMonthCardLastReward(data.LastCardRewardTime)
		GameData.SetMonthCardLastRewardV2(data.LastCardRewardTimeV2)

		GameData.MarkSignIn()
		self:SetupMonthCard(false)
		local goldNum = data.RemainGold
		local diamondNum = data.RemainDiamond
		GameData.SetMoney(ItemType.Gold, goldNum)
		GameData.SetMoney(ItemType.Diamond, diamondNum)
		GameData.CheckAndHintGoalsOfCurrentCountType()

		local rewardGoalData = GameData.SetupItemGoalDataWithType(ItemType.Time, -1, 1)
		GameData.DoGoalSettle(TriggerType.Signin, {rewardGoalData})
		-- refresh ui
		self:ToggleStateOfRewardItem(dayIndex, true)
	elseif proto == "GetCardReward" then
		local reward = data.Reward
		if not Helper.IsEmpty(reward) then
			GameData.CollectItem(reward.ItemId, reward.Num, true)
		end
		local goldNum = data.RemainGold
		local diamondNum = data.RemainDiamond
		GameData.SetMoney(ItemType.Gold, goldNum)
		GameData.SetMoney(ItemType.Diamond, diamondNum)

		GameData.SetExpiredCardTime(data.ExpireCardTime)
		GameData.SetMonthCardLastReward(data.LastCardRewardTime)

		GameData.SetExpiredCardTimeV2(data.ExpireCardTimeV2)
		GameData.SetMonthCardLastRewardV2(data.LastCardRewardTimeV2)
		self:SetupMonthCard(false)
	end
end


function SignInRewardCtrl:CanGetTodaySignInReward(monthCardType)
	local needGotoMall = false
	if GameData.IsMonthCardBought(monthCardType) and GameData.GetMonthCardLeftDays(monthCardType) > 0 then
		if GameData.HasMonthCardReward(monthCardType) then
			return true
		end
	else
		needGotoMall = true
	end
	return false, needGotoMall
end