require "FreakPlanet/View/BattlePanel"

local BattleCalculator = require "FreakPlanet/BattleCalculator"
local class = require "FreakPlanet/Utils/middleclass"
BattleCtrl  = class(CtrlNames.Battle, BaseCtrl)

local SLOW_DOWN_FACTOR = 0.3

------------------------------------------------------------------------
-- load the ui prefab
function BattleCtrl:LoadPanel()
	self:CreatePanel("Battle")
end

-- destroy implementation
function BattleCtrl:DestroyImpl()
	if self._arenaBattleId ~= nil or self._activityBattleId ~= nil then
		SoundSystem.PlayArenaMusic()
	end
	self:ResetSpeed()
end

-- construct ui panel data
function BattleCtrl:ConstructUI(obj)
	self._ui = BattlePanel.Init(obj)
end

-- fill ui with the data
function BattleCtrl:SetupUI()
	-- challenge
	self._challengeId = self._parameter.challengeId
	-- space travel challenge (additional)
	self._seasonId = self._parameter.seasonId
	self._choiceId = self._parameter.choiceId
	-- arena battle
	self._arenaBattleId = self._parameter.arenaBattleId
	self._arenaBattleDifficulty = self._parameter.difficulty
	-- activity battle
	self._activityBattleId = self._parameter.battleId
	self._activityThemeId = self._parameter.themeId

	self._battleSeed = self._parameter.seed
	self._simulationStates = {}
	self._attackHints = {}
	self._simulationPaused = false
	self._hpUpdateList = {}
	self._playSpeed = GameData.GetBattleSpeed()
	self:OnSpeedChanged()
	-- set bg
	if self._challengeId ~= nil then
		local bgName, bgAtlas, bgBundle = ConfigUtils.GetChallengeBG(self._challengeId)
 		self._ui.ChallengeBG.sprite2D = self:DynamicLoadSprite(bgBundle, bgAtlas, bgName)
	elseif self._arenaBattleId ~= nil then
		local bgName, bgAtlas, bgBundle = ConfigUtils.GetArenaBattleBG(self._arenaBattleId)
 		self._ui.ChallengeBG.sprite2D = self:DynamicLoadSprite(bgBundle, bgAtlas, bgName)
		SoundSystem.PlayBattleMusic()
	elseif self._activityBattleId ~= nil then
		local bgName, bgAtlas, bgBundle = ConfigUtils.GetActivityBattleBG(self._activityBattleId)
 		self._ui.ChallengeBG.sprite2D = self:DynamicLoadSprite(bgBundle, bgAtlas, bgName)
 		SoundSystem.PlayBattleMusic()
	else
		assert(false, "un-handle battle type")
	end
	-- default state
	self._ui.RoundRoot:SetActive(false)
	-- speed up button
	local showSpeedUp = GameData.IsModuleUnlocked(ModuleNames.BattleFast)
	self._ui.ButtonSpeedUp:SetActive(showSpeedUp)
	-- skip button
	local showSkip = GameData.IsModuleUnlocked(ModuleNames.BattleQuit)
	self._ui.ButtonSkip:SetActive(showSkip)

	CtrlManager.AddClick(self, self._ui.ButtonSkip)
	CtrlManager.AddClick(self, self._ui.ButtonSpeedUp)

	-- battle data
	self:PrepareBattleData()
end

function BattleCtrl:PrepareEnemyList()
	local ret = {}
	local challengeData = self._parameter.challengeData
	local enemyList = challengeData.EnemyList or {}
	for idx = 1, #enemyList do
		local enemyId = enemyList[idx][1]
		local enemyLevel = enemyList[idx][2]
		ret[idx] = {id = enemyId, level = enemyLevel}
	end

	return ret
end

function BattleCtrl:PrepareBattleData()
	self._characterList = self._parameter.characterList or {}
	self._petId = self._parameter.petId
	if not ConfigUtils.IsValidItem(self._petId) then
		self._petId = nil
	end
	local challengeData = self._parameter.challengeData
	local globalBuffs = self._parameter.globalBuffs or {}
	-- used rounds list per enemy
	self._enemyUsedRounds = {}
	self._enemyList = self:PrepareEnemyList()

	self._battleEnded = false
	self._settleSended = false
	self._battleCalculator = BattleCalculator:new(self._characterList, self._petId, self._enemyList, challengeData, globalBuffs)
	self._battleData, self._battleWin, self._TotalRound = self._battleCalculator:Start(self._battleSeed)
	self._orderedGroup = self._battleCalculator:ConstructOrderGroup()
	self:ConstructGroupUI()
	self:PrepareEnemyAvatar(self._battleCalculator:GetEnemyList())

	self._battleIdx = 1
	self:StartNextBattle()
end

function BattleCtrl:PrepareEnemyAvatar(enemyList)
	for idx = 1, #enemyList do
		local enemyId = enemyList[idx].id
		local enemyItemObj = Helper.NewObject(self._ui.EnemyAvatarTemplate, self._ui.EnemyAvatarPool)
		enemyItemObj.name = tostring(enemyId)
		enemyItemObj:SetActive(false)
		local enemyItem = enemyItemObj.transform
		-- spine avatar
		local avatarRoot = enemyItem:Find("Animator/Mark")
		local avatarPrefabName, avatarBundleName = ConfigUtils.GetEnemyPrefab(enemyId)
		local avatarPrefab = self:DynamicLoadAsset(avatarBundleName, avatarPrefabName)
		local avatarScale = ConfigUtils.GetItemAvatarScale(enemyId)
		local enemyObj = Helper.NewObject(avatarPrefab, avatarRoot, avatarScale)
		enemyObj.name = tostring(enemyId)
		-- animation
		local skeleton = enemyObj:GetComponent("SkeletonAnimation")
		Helper.PlayAnimation(skeleton, CharacterAnimations.Idle, true)
		-- skin
		local skinName = ConfigUtils.GetEnemySkinName(enemyId)
		if skinName ~= nil then
			Helper.SetSkin(skeleton, skinName)
		end
		-- event tracker
		local enemyEventTracker = enemyObj:GetComponent("SpineEventTracker")
		enemyEventTracker:AddEventListener(BattleCtrl.HandleEventGlobal)
	end
end

function BattleCtrl:StartNextBattle()
	local battleIdx = self._battleIdx
	local thisEnemy = self._battleData[battleIdx].enemy
	local enemyId = thisEnemy.id
	local enemyAbilityMap = thisEnemy.abilityMap
	local maxHp = enemyAbilityMap[AbilityType.HP]
	local enemyElement = ConfigUtils.GetEnemyElement(enemyId)

	self._thisBattleData = self._battleData[self._battleIdx].battle
	self._thisEnemyLevelSkillId = thisEnemy.enemyLevelSkill
	self._thisEnemySkillLevel = thisEnemy.enemySkillLevel
	self._thisEnemyIgnoreLevel = thisEnemy.enemyIgnoreLevel

	self._enemyData = {
		id = enemyId,
		maxHp = maxHp,
		currentHp = maxHp,
		element = enemyElement,
	}

	self:PrepareSpawnEnemy()
end

function BattleCtrl:CurrentEnemyId()
	return self._enemyData.id
end

function BattleCtrl:OnSpeedChanged()
	Time.timeScale = self._playSpeed
	if self._playSpeed > 0 then
		self._ui.SpeedUpLabel.text = "x"..tostring(self._playSpeed)
	else
		self._ui.SpeedUpLabel.text = ""
	end
end

function BattleCtrl:ResetSpeed()
	Time.timeScale = 1
end

function BattleCtrl:ConstructGroupUI()
	-- recycle character avatars
	local count = self._ui.CharacterAvatarRoot.childCount
	for idx = count, 1, -1 do
		local item = self._ui.CharacterAvatarRoot:GetChild(idx - 1)
		item.parent = self._ui.CharacterAvatarPool
	end

	self._groupDataUI = {}
	-- characters in order
	local group = self._orderedGroup
	for idx = 1, #group do
		local memberId = group[idx].id
		local isPet = (memberId == self._petId)
		local memberItemObj = Helper.NewObject(self._ui.CharacterAvatarTemplate, self._ui.CharacterAvatarRoot)
		memberItemObj.name = tostring(memberId)
		memberItemObj:SetActive(true)
		local memberItem = memberItemObj.transform
		-- position
		memberItem.localPosition = self._ui.CharacterSlotPositions[idx].localPosition
		-- avatar
		local prefabName = nil
		local prefabBundle = nil
		if isPet then
			prefabName, prefabBundle = ConfigUtils.GetPetPrefab(memberId)
		else
			prefabName, prefabBundle = ConfigUtils.GetCharacterPrefab(memberId)
		end
		local avatarRoot = memberItem:Find("Animator/Mark")
		local avatarScale = ConfigUtils.GetItemAvatarScale(memberId)
		local avatarPrefab = self:DynamicLoadAsset(prefabBundle, prefabName)
		local memberObj = Helper.NewObject(avatarPrefab, avatarRoot, avatarScale)
		memberObj.name = tostring(memberId)
		local spineEventTracker = memberObj:GetComponent("SpineEventTracker")
		spineEventTracker:AddEventListener(BattleCtrl.HandleEventGlobal)
		-- animator
		local animator = memberItem:Find("Animator"):GetComponent("Animator")
		-- hp
		local hpRoot = memberItem:Find("Animator/HPBar").gameObject
		hpRoot:SetActive(false)
		local hpBar = memberItem:Find("Animator/HPBar/Bar"):GetComponent("UISprite")
		hpBar.fillAmount = 1
		self:PlaceHpBar(hpRoot, memberId)
		-- skeleton animation
		local skeleton = memberObj:GetComponent("SkeletonAnimation")
		Helper.PlayAnimation(skeleton, CharacterAnimations.Idle, true)
		if not isPet then
			UIHelper.SetCharacterSkin(skeleton, memberId)
		end
		-- element and style
		local elementId = ConfigUtils.GetElementOfItem(memberId)
		local style = ConfigUtils.GetStyleOfItem(memberId)
		-- element icon
		local elementIcon = memberItem:Find("Animator/HPBar/Element"):GetComponent("UISprite")
		elementIcon.spriteName =  ConfigUtils.GetElementIconWithStyle(elementId)
		local styleIcon = memberItem:Find("Animator/HPBar/Style"):GetComponent("UISprite")
		styleIcon.spriteName = ConfigUtils.GetStyleIcon(style)
		styleIcon.color = ConfigUtils.GetStyleIconColor(elementId)
		-- shadow
		local shadow = memberItem:Find("Animator/Shadow").gameObject
		shadow:SetActive(true)
		-- battle effect root
		local effectRoot = memberItem:Find("Animator/Mark/BattleEffect")

		self._groupDataUI[memberId] = {
			item = memberItem,
			animator = animator,
			skeleton = skeleton,
			shadow = shadow,
			effectRoot = effectRoot,
			isPet = isPet,
		}

		local curHp = group[idx].maxHp
		self._hpUpdateList[memberId] = {curNum = curHp, targetNum = curHp, maxNum = curHp, step = 0, bar = hpBar, root = hpRoot}
	end
end

function BattleCtrl:ConstructEnemyUI()
	local enemyId = self._enemyData.id
	-- avatar
	local enemyItem = self._ui.EnemyAvatarPool:Find(enemyId)
	assert(enemyItem ~= nil, "can't find enemy item of: "..tostring(enemyId))
	enemyItem.gameObject:SetActive(true)
	enemyItem.parent = self._ui.EnemyAvatarRoot
	enemyItem.localPosition = Vector3.zero
	enemyItem.localScale = Vector3.one
	-- set position
	self._ui.EnemyAvatarRoot.localPosition = self._ui.EnemySpawnMark.localPosition
	-- animator
	local animator = enemyItem:Find("Animator"):GetComponent("Animator")
	-- hp
	local hpRoot = enemyItem:Find("Animator/HPBar").gameObject
	hpRoot:SetActive(false)
	local hpBar = enemyItem:Find("Animator/HPBar/Bar"):GetComponent("UISprite")
	hpBar.fillAmount = 1
	self:PlaceHpBar(hpRoot, enemyId)
	-- skeleton animation
	local avatarRoot = enemyItem:Find("Animator/Mark")
	local skeleton = avatarRoot:Find(enemyId):GetComponent("SkeletonAnimation")
	Helper.PlayAnimation(skeleton, CharacterAnimations.Idle, true)
	-- element icon
	local elementIcon = enemyItem:Find("Animator/HPBar/Element"):GetComponent("UISprite")
	elementIcon.spriteName = ConfigUtils.GetElementIconOfItem(enemyId, false)
	-- shadow
	local shadow = enemyItem:Find("Animator/Shadow").gameObject
	shadow:SetActive(true)
	-- battle effect root
	local effectRoot = enemyItem:Find("Animator/Mark/BattleEffect")

	self._enemyDataUI = {
		item = enemyItem,
		animator = animator,
		skeleton = skeleton,
		shadow = shadow,
		element = elementIcon,
		avatarRoot = avatarRoot,
		effectRoot = effectRoot,
	}

	local curHp = self._enemyData.maxHp
	self._hpUpdateList[enemyId] = {curNum = curHp, targetNum = curHp, maxNum = curHp, step = 0, bar = hpBar, root = hpRoot}
end

function BattleCtrl:PlaceHpBar(hpRoot, memberId)
	local height = nil
	local itemType = ConfigUtils.GetItemTypeFromId(memberId)
	if itemType == ItemType.Character then
		local skinId = GameData.GetCharacterSkin(memberId)
		height = ConfigUtils.GetHpBarHeightWithSkin(skinId)
	elseif itemType == ItemType.Enemy then
		height = ConfigUtils.GetHpBarHeightWithEnemy(memberId)
	end

	if height ~= nil then
		local pos = hpRoot.transform.localPosition
		pos.y = height
		hpRoot.transform.localPosition = pos
	end
end

-- update per frame
function BattleCtrl:UpdateImpl(deltaTime)
	-- attack hints
	for idx = #self._attackHints, 1, -1 do
		local animator = self._attackHints[idx].animator
		if Helper.IsUnityAnimationEnd(animator, 0) then
			local item = self._attackHints[idx].item
			item.parent = self._ui.AttackHintPool
			table.remove(self._attackHints, idx)
		end
	end

	-- simulation states
	for idx = #self._simulationStates, 1, -1 do
		local state = self._simulationStates[idx]
		local finished = state:Tick(deltaTime)
		if finished then
			table.remove(self._simulationStates, idx)
		end
	end

	-- hp bar
	local toRemove = {}
	for k, v in pairs(self._hpUpdateList) do
		if v.step > 0 then
			local num = math.ceil(v.curNum + v.step * deltaTime)
			v.curNum = math.min(v.targetNum, num)
			v.bar.fillAmount = v.curNum / v.maxNum
			if v.curNum >= v.targetNum then
				v.step = 0
			end
		elseif v.step < 0 then
			local num = math.floor(v.curNum + v.step * deltaTime)
			v.curNum = math.max(v.targetNum, num)
			v.bar.fillAmount = v.curNum / v.maxNum
			if v.curNum <= v.targetNum then
				v.step = 0
			end
		end

		if v.curNum == 0 then
			table.insert(toRemove, k)
		end
	end

	for idx = 1, #toRemove do
		local itemId = toRemove[idx]
		local v = self._hpUpdateList[itemId]
		v.root:SetActive(false)
		self._hpUpdateList[itemId] = nil
	end
end

-- on clicked
function BattleCtrl:OnClicked(go)
	if self._simulationPaused or self._battleEnded then
		return
	end

	if go == self._ui.ButtonSkip then
		self._simulationPaused = true
		SoundSystem.PlayUIClickSound()
		CtrlManager.ShowMessageBox({
			message = "确定放弃本次挑战？", 
			single = false, 
			onConfirm = BattleCtrl.OnCancelBattle,
			onCancel = BattleCtrl.OnContinueBattle,
			receiver = self,
		})
	elseif go == self._ui.ButtonSpeedUp then
		SoundSystem.PlayUIClickSound()
		self._playSpeed = self._playSpeed + 1
		if self._playSpeed > 3 then
			self._playSpeed = 1
		end
		self:OnSpeedChanged()
		GameData.SetBattleSpeed(self._playSpeed)
	end

	return true
end

-- handle the escapse button
function BattleCtrl:HandleEscape()
	-- do nothing
end

-- can do jump or not
function BattleCtrl:CanJump()
	-- do not jump
	return false
end

function BattleCtrl.HandleEventGlobal(name, go)
	local ctrl = CtrlManager.GetCtrlByName(CtrlNames.Battle)
	if ctrl ~= nil then
		ctrl:HandleEvent(name, go)
	end
end

function BattleCtrl:OnCancelBattle()
	self._simulationPaused = false
	if not self._settleSended then
		self._battleWin = false
		self._battleEnded = true
		self:EndBattle()
	end
end

function BattleCtrl:OnContinueBattle()
	self._simulationPaused = false
	if self._battleEnded and not self._settleSended then
		self:EndBattle()
	end
end
--------------------------------------------------------
function BattleCtrl:StartMove()
	self:PlaySoundEffect(SoundNames.BattleEnter)
	for k, v in pairs(self._orderedGroup) do
		local memberId = v.id
		local skeletonAnimation = self._groupDataUI[memberId].skeleton
		Helper.PlayAnimation(skeletonAnimation, CharacterAnimations.Walk, true)
	end

	self._ui.LevelTween.enabled = true
end

function BattleCtrl:StopMove()
	self._ui.LevelTween.enabled = false

	for k, v in pairs(self._orderedGroup) do
		local memberId = v.id
		local skeletonAnimation = self._groupDataUI[memberId].skeleton
		Helper.PlayAnimation(skeletonAnimation, CharacterAnimations.Idle, true)
	end
end

function BattleCtrl:HandleEvent(name, go)
	name = string.lower(name)
	if name == "hit" then
		-- being hit
		self:ReceiveHit(go)
	elseif name == "attack" then
		-- do attack
		self:DoAttack(go)
	end
end

function BattleCtrl:GetSlotOfMember(memberId)
	for idx = 1, #self._orderedGroup do
		if self._orderedGroup[idx].id == memberId then
			return idx
		end
	end

	assert(false, "can't find item in ordered group: "..tostring(memberId))
	return nil
end

function BattleCtrl:ReceiveHit(go)
	local attackData = self._battleEffectToAttackDataMap[go]
	local sourceId = attackData.source
	local targetId = attackData.target
	local damage = attackData.damage
	local isDodge = attackData.isDodge
	local isEnemyAttack = (sourceId == self:CurrentEnemyId())
	if isEnemyAttack then
		local slot = self:GetSlotOfMember(targetId)
		-- update hp
		local currentHp = self._orderedGroup[slot].hp
		-- already dead
		if currentHp <= 0 then
			return
		end
		currentHp = math.max(0, currentHp - damage)
		log("receive hit character: "..tostring(targetId).."; damage value: "..tostring(damage).."; now hp: "..tostring(currentHp))
		self._orderedGroup[slot].hp = currentHp
		-- hp
		self:OnMemberHpChanged(slot)
		-- attack hint
		local item = self._groupDataUI[targetId].item
		self:GenerateAttackHint(attackData, item.position)

		local skeleton = self._groupDataUI[targetId].skeleton
		local state = nil
		local isDead = (currentHp == 0)
		if isDead then
			state = SkeletonAnimationState:new(skeleton, CharacterAnimations.Hit, nil)
			state:ActionOnExit(BattleCtrl.OnCharacterDead, self, targetId)			
		else
			self._receiveHitLeftCount = self._receiveHitLeftCount - 1
			local hitAnimationName = CharacterAnimations.Hit
			if isDodge then
				self:PlaySoundEffect(SoundNames.BattleDodge)
				hitAnimationName = CharacterAnimations.Dodge
			else
				local soundName = self:GetHitSoundName(sourceId)
				self:PlaySoundEffect(soundName)
			end
			state = SkeletonAnimationState:new(skeleton, hitAnimationName, CharacterAnimations.Idle)
			state:ActionOnExit(BattleCtrl.OnHitSettleFinished, self)
		end

		table.insert(self._simulationStates, state)
	else
		-- update hp
		local currentHp = self._enemyData.currentHp
		-- already dead
		if currentHp <= 0 then
			return
		end
		currentHp = math.max(0, currentHp - damage)
		log("receive hit enemy, damage value: "..tostring(damage).."; now hp: "..tostring(currentHp))
		self._enemyData.currentHp = currentHp
		local isDead = (currentHp == 0)
		-- hp
		self:OnEnemyHpChanged()
		-- attack hint
		local item = self._enemyDataUI.item
		self:GenerateAttackHint(attackData, item.position)
		-- hit animation
		local skeleton = self._enemyDataUI.skeleton
		local state = nil
		if isDead then
			Time.timeScale = SLOW_DOWN_FACTOR * self._playSpeed
			local state1 = SkeletonAnimationState:new(skeleton, CharacterAnimations.Hit, nil)
			-- shadow
			local shadow = self._enemyDataUI.shadow
			state1:ActionOnExit(BattleCtrl.OnHitToDead, self, {shadow = shadow})
			local state2 = SkeletonAnimationState:new(skeleton, CharacterAnimations.ExploreFail, nil)
			state2:ActionOnEnter(BattleCtrl.PlaySoundEffect, self, SoundNames.BattleDead)
			state = SequenceState:new(state1, state2)
			state:ActionOnExit(BattleCtrl.OnEnemyDead, self)
		else
			local soundName = self:GetHitSoundName(sourceId)
			self:PlaySoundEffect(soundName)
			self._receiveHitLeftCount = self._receiveHitLeftCount - 1
			state = SkeletonAnimationState:new(skeleton, CharacterAnimations.Hit, CharacterAnimations.Idle)
			state:ActionOnExit(BattleCtrl.OnHitSettleFinished, self)
		end
		
		table.insert(self._simulationStates, state)
	end
end

function BattleCtrl:OnHitToDead(params)
	params.shadow:SetActive(false)
	Time.timeScale = self._playSpeed
end

function BattleCtrl:RecycleBattleEffects()
	local enemyEffectRoot = self._enemyDataUI.effectRoot
	for idx = enemyEffectRoot.childCount, 1, -1 do
		local item = enemyEffectRoot:GetChild(idx - 1)
		item.parent = self._ui.BattleEffectPool
	end

	for k, v in pairs(self._groupDataUI) do
		for idx = v.effectRoot.childCount, 1, -1 do
			local item = v.effectRoot:GetChild(idx - 1)
			item.parent = self._ui.BattleEffectPool
		end
	end
end

function BattleCtrl:PeekAttackDataOf(memberId)
	local attackData = self._itemAttackDataMap[memberId]
	assert(#attackData > 0, "no attack data for: "..tostring(memberId))

	local data = attackData[1]
	table.remove(attackData, 1)
	return data
end

function BattleCtrl:DoAttack(go)
	local sourceId = tonumber(go.name)
	local isEnemyAttack = (sourceId == self:CurrentEnemyId())
	local attackData = self:PeekAttackDataOf(sourceId)

	local sourceEffectRoot = nil
	if isEnemyAttack then
		sourceEffectRoot = self._enemyDataUI.effectRoot
	else
		sourceEffectRoot = self._groupDataUI[sourceId].effectRoot
	end

	local soundName = self:GetAttackSoundName(sourceId)
	self:PlaySoundEffect(soundName)
	-- play battle effect of source
	local isRange = attackData[1].isRange
	local isCrit = attackData[1].isCrit or false
	local effectPrefabName, sourceAnimationName, targetAnimationName  = self:GetBattleEffectPrefabName(sourceId, isRange, isCrit)
	-- source
	local sourceEffectItem = self:GenerateBattleEffect(effectPrefabName, sourceEffectRoot)
	local sourceEffectSkeleton = sourceEffectItem:GetComponent("SkeletonAnimation")
	local sourceEffectState = SkeletonAnimationState:new(sourceEffectSkeleton, sourceAnimationName, nil)
	sourceEffectState:ActionOnExit(BattleCtrl.DeactivateGameObject, self, sourceEffectItem.gameObject)
	table.insert(self._simulationStates, sourceEffectState)
	
	-- play battle effect of target
	for idx = 1, #attackData do
		local targetId = attackData[idx].target
		local targetEffectRoot = nil
		if isEnemyAttack then
			targetEffectRoot = self._groupDataUI[targetId].effectRoot
		else
			targetEffectRoot = self._enemyDataUI.effectRoot
		end
		local targetEffectItem = self:GenerateBattleEffect(effectPrefabName, targetEffectRoot)
		-- help to find the needed data when receive hit event
		self._battleEffectToAttackDataMap[targetEffectItem.gameObject] = attackData[idx]

		local targetEffectSkeleton = targetEffectItem:GetComponent("SkeletonAnimation")
		local targetEffectState = SkeletonAnimationState:new(targetEffectSkeleton, targetAnimationName, nil)
		targetEffectState:ActionOnExit(BattleCtrl.DeactivateGameObject, self, targetEffectItem.gameObject)
		table.insert(self._simulationStates, targetEffectState)
	end
end

function BattleCtrl:GenerateBattleEffect(effectPrefabName, root)
	local effectItem = self._ui.BattleEffectPool:Find(effectPrefabName)
	if effectItem == nil then
		local effectPrefab = self:DynamicLoadAsset(Const.SkillEffectBundleName, effectPrefabName)
		local prefabObj = Helper.NewObject(effectPrefab, root)
		prefabObj.name = effectPrefabName
		local eventTracker = prefabObj:GetComponent("SpineEventTracker")
		eventTracker:AddEventListener(BattleCtrl.HandleEventGlobal)
		effectItem = prefabObj.transform
	else
		effectItem.parent = root
	end

	effectItem.gameObject:SetActive(true)
	effectItem.localPosition = Vector3.zero
	effectItem.localScale = Vector3.one * 50

	return effectItem
end

function BattleCtrl:GenerateAttackHint(attackData, position)
	local item = nil
	if self._ui.AttackHintPool.childCount == 0 then
		local itemObj = Helper.NewObject(self._ui.AttackHintTemplate, self._ui.AttackHintRoot)
		itemObj:SetActive(true)
		itemObj.name = "AttackHint"
		item = itemObj.transform
	else
		item = self._ui.AttackHintPool:GetChild(0)
		item.parent = self._ui.AttackHintRoot
		item.localPosition = Vector3.zero
		item.localScale = Vector3.one
	end

	local targetPosition = self._ui.AttackHintRoot:InverseTransformPoint(position)
	local pos = item.localPosition
	pos.x = targetPosition.x
	item.localPosition = pos

	local damage = attackData.damage
	local isDodge = attackData.isDodge
	local isAgainst = (attackData.elementFactor > 1)
	local isCrit = attackData.isCrit
	local isDodgeIgnore = attackData.isDodgeIgnore or false

	local valueLabel = item:Find("AttackHint/Label"):GetComponent("UILabel")
	local r, g, b, a = valueLabel.color:Get()
	r = 1
	g = 1
	b = 1

	if isDodge then
		valueLabel.text = SAFE_LOC("躲")
	else
		if isDodgeIgnore then
			valueLabel.text = "必中 -"..tostring(damage)
		else
			valueLabel.text = "-"..tostring(damage)
		end
	end

	local animationName = ""
	if isDodge then
		animationName = "AttackDodge"
	elseif isAgainst and isCrit then
		animationName = "AttackAgainstCrit1"
		g = 0
		b = 0
	elseif isAgainst then
		animationName = "AttackAgainst"
		r = 251 / 255
		b = 0
	elseif isCrit then
		animationName = "AttackCrit1"
		g = 0
		b = 0
	else
		local index = Helper.RandInt(1, 5)
		animationName = "AttackHint"..tostring(index)
	end

	-- color
	valueLabel.color = Color.New(r, g, b, a)

	local animator = item:GetComponent("Animator")
	animator:Play(animationName, 0, 0)

	table.insert(self._attackHints, {item = item, animator = animator})
end

function BattleCtrl:CleanEnemyAvatar()
	local count = self._ui.EnemyAvatarRoot.childCount
	for idx = count, 1, -1 do
		local item = self._ui.EnemyAvatarRoot:GetChild(idx - 1)
		item.parent = self._ui.EnemyAvatarPool
	end
end

function BattleCtrl:PrepareSpawnEnemy()
	-- clean ui
	self:CleanEnemyAvatar()
	-- move character and bg
	self:StartMove()
	-- start spawn enemy
	local delay = Helper.RandFloat(0.5, 1.5)
	local state = TimerState:new(delay)
	state:ActionOnExit(BattleCtrl.DoEnemySpawn, self)
	table.insert(self._simulationStates, state)
end

function BattleCtrl:DoEnemySpawn()
	self:ConstructEnemyUI()

	local mover = self._ui.EnemyAvatarRoot
	local position = self._ui.EnemyBattleMark.localPosition
	local skeleton = self._enemyDataUI.skeleton
	local avatarRoot = self._enemyDataUI.avatarRoot
	-- make sure direction right
	Helper.CheckDirection(avatarRoot, -1)

	local state = MoveInXState:new(mover, position.x, 170)
	state:ActionOnExit(BattleCtrl.OnEnemyArrived, self)
	table.insert(self._simulationStates, state)
end

function BattleCtrl:OnEnemyArrived()
	self:StopMove()
	self._currentRound = 0
	if self._thisEnemyLevelSkillId ~= nil then
		self:ShowEnemyLevelSkillEffect()
	else
		self:PeekRoundAttack()
	end
end

function BattleCtrl:OnEnemyDead()
	-- no need to update again
	local enemyId = self._enemyData.id
	self._hpUpdateList[enemyId] = nil
	-- clean avatar first
	self:CleanEnemyAvatar()
	self._receiveHitLeftCount = 0
	self:OnHitSettleFinished()
end

function BattleCtrl:OnCharacterDead(memberId)
	-- hide the shadow
	local shadow = self._groupDataUI[memberId].shadow
	shadow:SetActive(false)

	local memberItem = self._groupDataUI[memberId].item
	local deadSkeleton = self._groupDataUI[memberId].skeleton
	local state1 = SkeletonAnimationState:new(deadSkeleton, CharacterAnimations.ExploreFail, nil)
	state1:ActionOnEnter(BattleCtrl.PlaySoundEffect, self, SoundNames.BattleDead)
	local state2 = SkeletonAnimationState:new(deadSkeleton, CharacterAnimations.ExploreDisappear, nil)
	local deadState = SequenceState:new(state1, state2)
	deadState:ActionOnExit(BattleCtrl.OnCharacterDisappear, self, memberItem)
	table.insert(self._simulationStates, deadState)
end

function BattleCtrl:CheckDeadGroupMembers()
	local state = nil

	local aliveMembers = {}
	for slot = #self._orderedGroup, 1, -1 do
		local memberId = self._orderedGroup[slot].id
		if memberId ~= self._petId then
			local currentHp = self._orderedGroup[slot].hp
			if currentHp <= 0 then
				table.remove(self._orderedGroup, slot)
			else
				aliveMembers[memberId] = {prev = slot}
			end
		else
			aliveMembers[memberId] = {prev = slot}
		end
	end

	for slot = 1, #self._orderedGroup do
		local memberId = self._orderedGroup[slot].id
		aliveMembers[memberId].cur = slot
	end

	for itemId, v in pairs(aliveMembers) do
		if v.prev ~= v.cur then
			if state == nil then
				state = ParallelState:new()
			end

			local mover = self._groupDataUI[itemId].item
			local position = self._ui.CharacterSlotPositions[v.cur].localPosition
			local skeleton = self._groupDataUI[itemId].skeleton
			local moveState = MoveInXState:new(mover, position.x, 150, skeleton, CharacterAnimations.Walk, CharacterAnimations.Idle)
			state:Push(moveState)
		end
	end

	return state
end

-- not include the pet
function BattleCtrl:GetAliveCharacterCount()
	local num = 0
	for k, v in pairs(self._orderedGroup) do
		if v.id ~= self._petId and v.hp > 0 then
			num = num + 1
		end
	end

	return num
end

function BattleCtrl:OnMemberHpChanged(slot)
	local memberId = self._orderedGroup[slot].id
	if self._hpUpdateList[memberId] == nil then
		return
	end

	local newNum = self._orderedGroup[slot].hp
	local curNum = self._hpUpdateList[memberId].curNum
	
	self._hpUpdateList[memberId].root:SetActive(true)
	self._hpUpdateList[memberId].targetNum = newNum
	self._hpUpdateList[memberId].step = (newNum - curNum) / 0.2
end

function BattleCtrl:OnEnemyHpChanged()
	local enemyId = self._enemyData.id
	if self._hpUpdateList[enemyId] == nil then
		return
	end
	
	local newNum = self._enemyData.currentHp
	local curNum = self._hpUpdateList[enemyId].curNum

	self._hpUpdateList[enemyId].root:SetActive(true)
	self._hpUpdateList[enemyId].targetNum = newNum
	self._hpUpdateList[enemyId].step = (newNum - curNum) / 0.2
end

function BattleCtrl:OnCharacterDisappear(item)
	item.parent = self._ui.CharacterAvatarPool
	self._receiveHitLeftCount = self._receiveHitLeftCount - 1
	self:OnHitSettleFinished()
end

function BattleCtrl:DeactivateGameObject(go)
	go:SetActive(false)
end

function BattleCtrl:OnFinishAttackAndBackPosition()
	self._attackBackLeftCount = self._attackBackLeftCount - 1
	self:CheckNextSideAttack()
end

function BattleCtrl:OnHitSettleFinished()
	if self._receiveHitLeftCount <= 0 and not self._sideAttackFinished then
		self._sideAttackFinished = true
		local state = self:CheckDeadGroupMembers()
		if state ~= nil then
			state:ActionOnExit(BattleCtrl.CheckNextSideAttack, self)
			table.insert(self._simulationStates, state)
		else
			self:CheckNextSideAttack()
		end
	end
end

function BattleCtrl:CheckNextSideAttack()
	if self._attackBackLeftCount <= 0 and self._sideAttackFinished then
		table.remove(self._thisBattleRoundData.sideData, 1)
		if #self._thisBattleRoundData.sideData == 0 then
			local skillData = self._thisBattleRoundData.skillData
			if skillData ~= nil then
				-- show ui effect
				self:ShowSkillEffect(skillData)
			else
				self:OnSideAttackFinished()
			end
		else
			self:PeekRoundAttackOfOneSide()
		end
	end
end

function BattleCtrl:OnSideAttackFinished()
	table.remove(self._thisBattleData, 1)
	if #self._thisBattleData > 0 then
		self:PeekRoundAttack()
	else
		-- record the round of this enemy
		table.insert(self._enemyUsedRounds, self._currentRound)
		-- check next battle
		self._battleIdx = self._battleIdx + 1
		if self._battleIdx > #self._battleData then
			self._battleEnded = true
			if not self._simulationPaused and not self._settleSended then
				self:EndBattle()
			end
		else
			-- hide the round hint for this enemy
			self._ui.RoundRoot:SetActive(false)
			self:StartNextBattle()
		end
	end
end

function BattleCtrl:ShowEnemyLevelSkillEffect()
	local skillHintPrefabName = "SkillEffect_EnemyLevel"
	-- the first one should always be character, not pet
	local characterId = self._orderedGroup[1].id
	local memberItem = self._groupDataUI[characterId].item
	local memberSkeleton = self._groupDataUI[characterId].skeleton
	local animationName = self:GetSkillAnimation(characterId)

	local state = SequenceState:new()

	local state1 = ParallelState:new()
	-- character animation
	local state11 = SkeletonAnimationState:new(memberSkeleton, animationName, CharacterAnimations.Idle)
	state1:Push(state11)
	-- dialog state
	local state12 = self:GenerateSkillDialogState(self._thisEnemyLevelSkillId, memberItem)
	state1:Push(state12)
	state:Push(state1)
	-- enemy hit and scale
	local skillHintItem = self._ui.SkillEffectPool:Find(skillHintPrefabName)
	if skillHintItem == nil then
		local skillHintPrefab = self:DynamicLoadAsset(Const.SkillEffectBundleName, skillHintPrefabName)
		local skillHintObj = Helper.NewObject(skillHintPrefab, self._ui.SkillEffectRoot)
		skillHintObj.name = skillHintPrefabName
		skillHintItem = skillHintObj.transform
	else
		skillHintItem.parent = self._ui.SkillEffectRoot
		skillHintItem.localPosition = Vector3.zero
		skillHintItem.localScale = Vector3.one
	end

	-- hint animator
	local hintAnimator = skillHintItem:GetComponent("Animator")
	hintAnimator:Play("SkillEffect", 0, 0)
	-- hint skill level
	local levelLabel = skillHintItem:Find("Hint/Num/Value"):GetComponent("UILabel")
	levelLabel.text = string.format(SAFE_LOC("loc_SimpleLevel"), self._thisEnemySkillLevel)

	skillHintItem.gameObject:SetActive(false)
	local enemyItem = self._enemyDataUI.item
	local enemySkeleton = self._enemyDataUI.skeleton
	local skillHintItemPos = skillHintItem.localPosition
	skillHintItemPos.x = self._ui.SkillEffectRoot:InverseTransformPoint(enemyItem.position).x
	skillHintItem.localPosition = skillHintItemPos

	local state2 = ParallelState:new()

	local skillHintSkeleton = skillHintItem:Find("SkillEffect"):GetComponent("SkeletonAnimation")
	local state21 = SkeletonAnimationState:new(skillHintSkeleton, "Hit_Skill", nil, skillHintItem.gameObject)
	state21:ActionOnExit(BattleCtrl.RecycleSkillHintItem, self, skillHintItem)
	state2:Push(state21)

	local state22 = SequenceState:new()
	local state221 = SkeletonAnimationState:new(enemySkeleton, CharacterAnimations.Hit, CharacterAnimations.Idle)
	state221:ActionOnEnter(BattleCtrl.PlaySoundEffect, self, SoundNames.BattleLevelSkillEffect)
	state22:Push(state221)
	local state222 = ScaleState:new(enemyItem, 1.0, 0.8, 0.5)
	state22:Push(state222)
	state2:Push(state22)

	state:Push(state2)

	if self._thisEnemyIgnoreLevel > 0 then
		local state3 = ParallelState:new()
		if self._thisEnemyIgnoreLevel >= math.abs(self._thisEnemySkillLevel) then
			local state31 = ScaleState:new(enemyItem, 0.8, 1, 0.5)
			state3:Push(state31)

			local state32 = self:GenerateEnemyDialogState(enemyItem, SAFE_LOC("降不了！"))
			state3:Push(state32)
		else
			local skillPercent = self._thisEnemyIgnoreLevel / math.abs(self._thisEnemySkillLevel)
			local newScale = 0.8 + skillPercent * 0.2
			local state31 = ScaleState:new(enemyItem, 0.8, newScale, 0.5 * skillPercent)
			state3:Push(state31)

			local state32 = self:GenerateEnemyDialogState(enemyItem, SAFE_LOC("看我加回来"))
			state3:Push(state32)
		end

		state:Push(state3)
	end

	state:ActionOnExit(BattleCtrl.PeekRoundAttack, self)
	table.insert(self._simulationStates, state)
end

function BattleCtrl:RecycleDialogItem(item)
	item.parent = self._ui.DialogPool
end

function BattleCtrl:RecycleSkillHintItem(item)
	item.parent = self._ui.SkillEffectPool
end

function BattleCtrl:ShowSkillEffect(skillData)
	local memberSkillHints = {}
	-- reduce
	local reduceData = skillData.reduce

	-- recover
	local recoverData = skillData.recover
	if recoverData ~= nil then
		for k, v in pairs(recoverData) do
			if memberSkillHints[k] == nil then
				memberSkillHints[k] = {}
			end
			local isReduce = reduceData and reduceData[k] and reduceData[k].recover
			table.insert(memberSkillHints[k], {skillType = "recover", value = v, reduce = isReduce})
		end
	end
	-- crit chance
	local critChanceData = skillData.critChance
	if critChanceData ~= nil then
		for k, v in pairs(critChanceData) do
			if memberSkillHints[k] == nil then
				memberSkillHints[k] = {}
			end

			table.insert(memberSkillHints[k], {skillType = "critChance", value = v})
		end
	end
	-- ability
	local abilityData = skillData.ability
	if abilityData ~= nil then
		for k, v in pairs(abilityData) do
			if memberSkillHints[k] == nil then
				memberSkillHints[k] = {}
			end

			for abilityId, abilityAddValue in pairs(v) do
				local isReduce = reduceData and reduceData[k] and reduceData[k].ability
				table.insert(memberSkillHints[k], {skillType = "ability", abilityId = abilityId, value = abilityAddValue, reduce = isReduce})
			end
		end
	end
	-- element
	local elementData = skillData.element
	if elementData ~= nil then
		for k, v in pairs(elementData) do
			if memberSkillHints[k] == nil then
				memberSkillHints[k] = {}
			end

			table.insert(memberSkillHints[k], {skillType = "element", value = v})
		end
	end

	local sourceMembers = skillData.sourceMembers
	local state1 = nil
	if sourceMembers ~= nil then
		for memberId, v in pairs(sourceMembers) do
			local isEnemy = (memberId == self:CurrentEnemyId())
			local memberItem = nil
			local memberSkeleton = nil

			if isEnemy then
				memberItem = self._enemyDataUI.item
				memberSkeleton = self._enemyDataUI.skeleton
			else
				local slot = self:GetSlotOfMember(memberId)
				if slot ~= nil then
					memberItem = self._groupDataUI[memberId].item
					memberSkeleton = self._groupDataUI[memberId].skeleton
				end
			end
			-- find it
			if memberItem ~= nil then
				local memberState = nil
				local skillAnimationName = self:GetSkillAnimation(memberId)
				for skillId, _ in pairs(v) do
					if ConfigUtils.IsSkillHasDialog(skillId) then
						local animationState = SkeletonAnimationState:new(memberSkeleton, skillAnimationName, CharacterAnimations.Idle)
						local dialogState = self:GenerateSkillDialogState(skillId, memberItem)

						local childState = ParallelState:new(animationState, dialogState)

						if memberState == nil then
							memberState = SequenceState:new()
						end

						memberState:Push(childState)
					end
				end

				if memberState ~= nil then
					if state1 == nil then
						state1 = ParallelState:new()
					end

					state1:Push(memberState)
				end
			end
		end
	end

	local state2 = nil
	for memberId, v in pairs(memberSkillHints) do
		local isEnemy = (memberId == self:CurrentEnemyId())
		local memberItem = nil
		if isEnemy then
			memberItem = self._enemyDataUI.item
		else
			local slot = self:GetSlotOfMember(memberId)
			if slot ~= nil then
				memberItem = self._groupDataUI[memberId].item
			end
		end
		-- find it
		if memberItem ~= nil then
			local memberState = nil
			for idx = 1, #v do
				local hintState = self:GenerateSkillHintState(v[idx], memberItem)

				if memberState == nil then
					memberState = SequenceState:new()
				end

				memberState:Push(hintState)
			end

			if memberState ~= nil then
				if state2 == nil then
					state2 = ParallelState:new()
				end

				state2:Push(memberState)
			end
		end
	end

	if state1 == nil and state2 == nil then
		self:OnShowSkillEffectFinished(skillData)
	else
		local state = SequenceState:new()
		--有削弱技能
		if reduceData then
			local enemyId = self._enemyData.id
			local enemyItem = self._enemyDataUI.item
			local enemySkeleton = self._enemyDataUI.skeleton
			local skillAnimationName = self:GetSkillAnimation(enemyId)
			local animationState = SkeletonAnimationState:new(enemySkeleton, skillAnimationName, CharacterAnimations.Idle)
			state:Push(animationState)
		end
		if state1 ~= nil then
			state:Push(state1)
		end
		if state2 ~= nil then
			state:Push(state2)
		end
		state:ActionOnExit(BattleCtrl.OnShowSkillEffectFinished, self, skillData)
		table.insert(self._simulationStates, state)
	end
end

function BattleCtrl:OnShowSkillEffectFinished(skillData)
	-- add hp first
	if skillData ~= nil and skillData.recover ~= nil then
		for k, v in pairs(skillData.recover) do
			local isEnemy = (k == self:CurrentEnemyId())
			if isEnemy then
				self._enemyData.currentHp = self._enemyData.currentHp + v
				self._enemyData.currentHp = math.min(self._enemyData.currentHp, self._enemyData.maxHp)
				self:OnEnemyHpChanged()
			else
				local slot = self:GetSlotOfMember(k)
				if slot ~= nil then
					local curHp = self._orderedGroup[slot].hp + v
					curHp = math.min(curHp, self._orderedGroup[slot].maxHp)
					self._orderedGroup[slot].hp = curHp
					self:OnMemberHpChanged(slot)
				end
			end
		end
	end
	-- change element
	if skillData ~= nil and skillData.element ~= nil then
		for k, v in pairs(skillData.element) do
			self._enemyData.element = v
			self._enemyDataUI.element.spriteName = ConfigUtils.GetElementIconNoStyle(v)
		end
	end

	self:OnSideAttackFinished()
end

function BattleCtrl:GenerateSkillHintState(skillData, memberItem)
	local skillType = skillData.skillType
	local isReduce = skillData.reduce or false

	local skillHintPrefabName = isReduce and "SkillEffectReduce" or "SkillEffect"
	local soundName = SoundNames.BattleCommonSkillEffect
	if skillType == "recover" then
		skillHintPrefabName = isReduce and "HPRcoverEffectReduce" or "HPRcoverEffect"
		soundName = SoundNames.BattleHealSkillEffect
	elseif skillType == "element" then
		soundName = SoundNames.BattleElementSwitch
	end

	local skillHintItem = self._ui.SkillEffectPool:Find(skillHintPrefabName)
	if skillHintItem == nil then
		local skillHintPrefab = self:DynamicLoadAsset(Const.SkillEffectBundleName, skillHintPrefabName)
		local skillHintObj = Helper.NewObject(skillHintPrefab, self._ui.SkillEffectRoot)
		skillHintObj.name = skillHintPrefabName
		skillHintItem = skillHintObj.transform
	else
		skillHintItem.parent = self._ui.SkillEffectRoot
		skillHintItem.localScale = Vector3.one
		skillHintItem.localPosition = Vector3.zero
	end

	skillHintItem.gameObject:SetActive(false)

	local pos = skillHintItem.localPosition
	pos.x = self._ui.SkillEffectRoot:InverseTransformPoint(memberItem.position).x
	skillHintItem.localPosition = pos

	self:ConstructSkillHintItem(skillData, skillHintItem)

	local skillEffectSkeleton1 = skillHintItem:Find("SkillEffect_1"):GetComponent("SkeletonAnimation")
	Helper.PlayAnimation(skillEffectSkeleton1, "SkillEffect", false)
	local skillEffectSkeleton2 = skillHintItem:Find("SkillEffect_2"):GetComponent("SkeletonAnimation")
	Helper.PlayAnimation(skillEffectSkeleton2, "SkillEffect", false)

	local animator = skillHintItem:GetComponent("Animator")
	local hintState = AnimatorState:new(animator, "SkillEffect", nil, skillHintItem.gameObject)
	hintState:ActionOnEnter(BattleCtrl.PlaySoundEffect, self, soundName)
	hintState:ActionOnExit(BattleCtrl.RecycleSkillHintItem, self, skillHintItem)
	return hintState
end

function BattleCtrl:GenerateSkillDialogState(skillId, memberItem)
	local dialogItem = nil
	if self._ui.DialogPool.childCount == 0 then
		local dialogObj = Helper.NewObject(self._ui.DialogTemplate, self._ui.DialogRoot)
		dialogObj.name = "DialogItem"
		dialogItem = dialogObj.transform
	else
		dialogItem = self._ui.DialogPool:GetChild(0)
		dialogItem.parent = self._ui.DialogRoot
		dialogItem.localScale = Vector3.one
		dialogItem.localPosition = Vector3.zero
	end

	dialogItem.gameObject:SetActive(false)

	local pos = dialogItem.localPosition
	pos.x = self._ui.DialogRoot:InverseTransformPoint(memberItem.position).x
	dialogItem.localPosition = pos

	local dialogLabel = dialogItem:Find("Label"):GetComponent("UILabel")
	dialogLabel.text = ConfigUtils.GetSkillDialog(skillId)

	local animator = dialogItem:GetComponent("Animator")
	local hintState = AnimatorState:new(animator, "Dialog", nil, dialogItem.gameObject)
	hintState:ActionOnExit(BattleCtrl.RecycleDialogItem, self, dialogItem)
	return hintState
end

function BattleCtrl:GenerateEnemyDialogState(enemyItem, msg)
	local dialogItem = nil
	if self._ui.DialogPool.childCount == 0 then
		local dialogObj = Helper.NewObject(self._ui.DialogTemplate, self._ui.DialogRoot)
		dialogObj.name = "DialogItem"
		dialogItem = dialogObj.transform
	else
		dialogItem = self._ui.DialogPool:GetChild(0)
		dialogItem.parent = self._ui.DialogRoot
		dialogItem.localScale = Vector3.one
		dialogItem.localPosition = Vector3.zero
	end

	dialogItem.gameObject:SetActive(false)

	local pos = dialogItem.localPosition
	pos.x = self._ui.DialogRoot:InverseTransformPoint(enemyItem.position).x
	dialogItem.localPosition = pos

	local dialogLabel = dialogItem:Find("Label"):GetComponent("UILabel")
	dialogLabel.text = msg

	local animator = dialogItem:GetComponent("Animator")
	local hintState = AnimatorState:new(animator, "Dialog", nil, dialogItem.gameObject)
	hintState:ActionOnExit(BattleCtrl.RecycleDialogItem, self, dialogItem)
	return hintState
end

function BattleCtrl:ConstructSkillHintItem(skillData, skillHintItem)
	local skillType = skillData.skillType
	local skillValue = skillData.value
	local skillAbilityId = skillData.abilityId
	local isReduce = skillData.reduce or false

	local iconNumRoot = skillHintItem:Find("Hint/IconNum")
	local numRoot = skillHintItem:Find("Hint/Num")

	if skillType == "recover" then
		numRoot.gameObject:SetActive(true)
		local valueLabel = numRoot:Find("Value"):GetComponent("UILabel")
		valueLabel.text = "+"..tostring(skillValue)
	elseif skillType == "critChance" then
		numRoot.gameObject:SetActive(true)
		iconNumRoot.gameObject:SetActive(false)
		local finalValue = math.floor(skillValue * 100)
		local valueLabel = numRoot:Find("Value"):GetComponent("UILabel")
		if finalValue > 0 then
			valueLabel.text = "暴击率 +"..tostring(finalValue).."%"
		else
			valueLabel.text = "暴击率 "..tostring(finalValue).."%"
		end
	elseif skillType == "ability" then
		numRoot.gameObject:SetActive(false)
		iconNumRoot.gameObject:SetActive(true)
		
		local icon = iconNumRoot:Find("Icon"):GetComponent("UISprite")
		local valueLabel = iconNumRoot:Find("Value"):GetComponent("UILabel")

		icon.spriteName = ConfigUtils.GetAbilityIcon(skillAbilityId)
		if isReduce then
			icon.spriteName = icon.spriteName .. '_Reduce'
		end
		if skillValue > 0 then
			valueLabel.text = "+"..tostring(skillValue)
		else
			valueLabel.text = tostring(skillValue)
		end
	elseif skillType == "element" then
		numRoot.gameObject:SetActive(false)
		iconNumRoot.gameObject:SetActive(true)
		
		local icon = iconNumRoot:Find("Icon"):GetComponent("UISprite")
		icon.spriteName = ConfigUtils.GetElementIconNoStyle(skillValue)
		local valueLabel = iconNumRoot:Find("Value"):GetComponent("UILabel")
		valueLabel.text = SAFE_LOC("元素变变变")
	end
end

function BattleCtrl:ConstructAttackData(sourceId, targetId, attackData, isRange)
	local ret = Helper.CloneMap(attackData)
	ret.source = sourceId
	ret.target = targetId
	ret.isRange = isRange
	return ret
end

function BattleCtrl:PeekRoundAttack()
	self._currentRound = self._currentRound + 1
	self._ui.RoundRoot:SetActive(true)
	self._ui.RoundLabel.text = string.format("第%d回合", self._currentRound)

	self._thisBattleRoundData = self._thisBattleData[1]
	self:PeekRoundAttackOfOneSide()
end

function BattleCtrl:PeekRoundAttackOfOneSide()
	self:RecycleBattleEffects()
	
	local sideData = self._thisBattleRoundData.sideData[1]
	local isEnemySide = sideData.isEnemy
	local sideAttackData = sideData.data

	-- attack count
	self._attackBackLeftCount = 0
	self._receiveHitLeftCount = 0

	self._sideAttackFinished = false
	self._itemAttackDataMap = {}
	self._battleEffectToAttackDataMap = {}

	for idx = 1, #sideAttackData do
		local slot = idx
		local sourceId = sideAttackData[idx].source
		local isRange = sideAttackData[idx].rangeAttack or false
		local isMelee = ConfigUtils.IsMeleeItem(sourceId)
		local targets = sideAttackData[idx].targets

		local thisAttackData = {}

		local maxAttackNum = 0
		if isRange then
			for targetIdx = 1, #targets do
				local attackData = targets[targetIdx].attack
				self._receiveHitLeftCount = self._receiveHitLeftCount + #attackData
				if #attackData > maxAttackNum then
					maxAttackNum = #attackData
				end
			end

			for attackIdx = 1, maxAttackNum do
				local attackDataPerRange = {}
				for targetIdx = 1, #targets do
					local targetId = targets[targetIdx].id
					local attackData = targets[targetIdx].attack
					if attackIdx <= #attackData then
						local data = self:ConstructAttackData(sourceId, targetId, attackData[attackIdx], true)
						table.insert(attackDataPerRange, data)
					end
				end

				table.insert(thisAttackData, attackDataPerRange)
			end
		else
			local targetId = targets[1].id
			local attackData = targets[1].attack
			self._receiveHitLeftCount = self._receiveHitLeftCount + #attackData

			for attackIdx = 1, #attackData do
				local data = self:ConstructAttackData(sourceId, targetId, attackData[attackIdx], false)
				table.insert(thisAttackData, {data})
			end
		end

		self._itemAttackDataMap[sourceId] = thisAttackData
		self._attackBackLeftCount = self._attackBackLeftCount + 1
		
		-- wait and then out
		local waitState = TimerState:new(BattleInterval * (idx - 1))

		local state = SequenceState:new()
		state:Push(waitState)

		local itemObj = nil
		local animator = nil
		local skeleton = nil
		local tempId = -1
		if isEnemySide then
			animator = self._enemyDataUI.animator
			skeleton  = self._enemyDataUI.skeleton
			itemObj = self._enemyDataUI.item
			tempId = -1
		else
			animator = self._groupDataUI[sourceId].animator
			skeleton  = self._groupDataUI[sourceId].skeleton
			itemObj = self._groupDataUI[sourceId].item
			tempId = sourceId
		end

		--攻击者绘制层级提高
		self.RecordDepths = self.RecordDepths or {}
		state:Push(CallMethodState:new(function()
			local pos = itemObj.transform.localPosition
			if not self.RecordDepths[tempId] then
				self.RecordDepths[tempId] = pos.z
			end
			pos.z = -1
			itemObj.transform.localPosition = pos
		end))

		if not isRange and isMelee then
			local childState = AnimatorState:new(animator, "Melee_"..tostring(slot), nil)
			state:Push(childState)
		end

		if isRange then
			local attackAnimationName = self:GetRangeAttackAnimation(sourceId)
			for attackIdx = 1, maxAttackNum do
				local nextAnimationName = nil
				if attackIdx == maxAttackNum then
					nextAnimationName = CharacterAnimations.Idle
				end 
				local childState = SkeletonAnimationState:new(skeleton, attackAnimationName, nextAnimationName)
				state:Push(childState)
			end
		else
			local targetId = targets[1].id
			local attackData = targets[1].attack

			for attackIdx = 1, #attackData do
				local attackAnimationName = self:GetAttackAnimation(sourceId, attackData[attackIdx])
				local nextAnimationName = nil
				if attackIdx == #attackData then
					nextAnimationName = CharacterAnimations.Idle
				end 
				local childState = SkeletonAnimationState:new(skeleton, attackAnimationName, nextAnimationName)
				state:Push(childState)
			end
		end

		if not isRange and isMelee then
			local childState = AnimatorState:new(animator, "Back"..tostring(slot), "Empty")
			state:Push(childState)
		end

		--攻击者绘制层级恢复
		state:Push(CallMethodState:new(function()
			if self.RecordDepths[tempId] then
				local pos = itemObj.transform.localPosition
				pos.z = self.RecordDepths[tempId]
				itemObj.transform.localPosition = pos
			end
		end))

		state:ActionOnExit(BattleCtrl.OnFinishAttackAndBackPosition, self)
		table.insert(self._simulationStates, state)
	end
end

function BattleCtrl:GetRangeAttackAnimation(sourceId)
	local finalId = sourceId
	local itemType = ConfigUtils.GetItemTypeFromId(sourceId)
	if itemType == ItemType.Character then
		finalId = GameData.GetCharacterSkin(sourceId)
	end

	local battleResource = ConfigUtils.GeBattleResourceOfItem(finalId)
	return battleResource.RangeAttackAnim
end

function BattleCtrl:GetAttackAnimation(sourceId, attackData)
	local finalId = sourceId
	local itemType = ConfigUtils.GetItemTypeFromId(sourceId)
	if itemType == ItemType.Character then
		finalId = GameData.GetCharacterSkin(sourceId)
	end

	local battleResource = ConfigUtils.GeBattleResourceOfItem(finalId)
	local isCrit = attackData.isCrit

	if isCrit then
		return battleResource.CritAttackAnim
	end

	local animationList = battleResource.AttackAnim
	local idx = Helper.RandInt(1, #animationList)
	return animationList[idx]
end

function BattleCtrl:GetSkillAnimation(sourceId)
	local finalId = sourceId
	local itemType = ConfigUtils.GetItemTypeFromId(sourceId)
	if itemType == ItemType.Character then
		finalId = GameData.GetCharacterSkin(sourceId)
	end

	local battleResource = ConfigUtils.GeBattleResourceOfItem(finalId)
	return battleResource.SkillAnim
end

function BattleCtrl:GetAttackSoundName(sourceId)
	local finalId = sourceId
	local itemType = ConfigUtils.GetItemTypeFromId(sourceId)
	if itemType == ItemType.Character then
		finalId = GameData.GetCharacterSkin(sourceId)
	end

	local battleResource = ConfigUtils.GeBattleResourceOfItem(finalId)
	local battleEffect = battleResource.BattleEffect
	if battleEffect.AttackSound ~= nil then
		return battleEffect.AttackSound
	end

	local element = ConfigUtils.GetElementOfItem(sourceId)
	local attackType = ConfigUtils.GetAttackTypeOfItem(sourceId)
	return ConfigUtils.GetElementAttackSound(element, attackType)
end

function BattleCtrl:GetHitSoundName(sourceId)
	local finalId = sourceId
	local itemType = ConfigUtils.GetItemTypeFromId(sourceId)
	if itemType == ItemType.Character then
		finalId = GameData.GetCharacterSkin(sourceId)
	end

	local battleResource = ConfigUtils.GeBattleResourceOfItem(finalId)
	local battleEffect = battleResource.BattleEffect
	if battleEffect.HitSound ~= nil then
		return battleEffect.HitSound
	end

	local element = ConfigUtils.GetElementOfItem(sourceId)
	return ConfigUtils.GetElementHitSound(element)
end

function BattleCtrl:GetBattleEffectPrefabName(sourceId, isRange, isCrit)
	local finalId = sourceId
	local itemType = ConfigUtils.GetItemTypeFromId(sourceId)
	if itemType == ItemType.Character then
		finalId = GameData.GetCharacterSkin(sourceId)
	end

	local battleResource = ConfigUtils.GeBattleResourceOfItem(finalId)
	local battleEffect = battleResource.BattleEffect
	if isRange then
		battleEffect = battleResource.RangeAttackEffect
	elseif isCrit then
		battleEffect = battleResource.CritBattleEffect
	end

	return battleEffect.Prefab, battleEffect.Attack, battleEffect.Hit
end

function BattleCtrl:PlaySoundEffect(soundName)
	if self._battleEnded then
		return
	end

	SoundSystem.PlaySoundOfName(soundName)
end
-------------------------------------------------------------------------
function BattleCtrl:EndBattle()
	if self._settleSended then
		return
	end

	-- back to normal speed
	self:ResetSpeed()
	self._settleSended = true
	local characterList = self._parameter.characterList or {}
	local fianlCharacterList = {}
	Helper.CopyTable(fianlCharacterList, characterList)
	local petId = self._petId
	if petId == nil then
		petId = INVALID_ID
	end

	local aliveCharacterCount = self:GetAliveCharacterCount()
	local totalCharacterCount = #characterList
	local usedRound = 0
	local challengeStar = CHALLENGE_MAX_STAR - (totalCharacterCount - aliveCharacterCount)
	challengeStar = math.max(0, challengeStar)
	if #self._enemyUsedRounds > 0 then
		usedRound = math.max(unpack(self._enemyUsedRounds))
	end

	if self._challengeId ~= nil then
		if self._seasonId ~= nil then
			local seasonData = GameData.GetSpaceTravelSeasonData(self._seasonId)
            local scoreCapId = GameData.GetScoreCapOfSpaceTravelSeason(self._seasonId, seasonData.scoreCap)
            NetManager.Send("STChoiceChallengeSettle", {
                STSeasonID = self._seasonId, 
                STScoreCapID = scoreCapId,
                ChoiceId = self._choiceId,
                ChallengeId = self._challengeId,
				Result = self._battleWin,
				Round = self._TotalRound,
				CharacterList = fianlCharacterList,
				PetId = petId,
			}, BattleCtrl.OnHandleProto, self)
		else
			NetManager.Send("ChallengeSettle", {
				ChallengeId = self._challengeId,
				Result = self._battleWin,
				Round = usedRound,
				Star = challengeStar,
				Round = self._TotalRound,
				CharacterList = fianlCharacterList,
				PetId = petId,
			}, BattleCtrl.OnHandleProto, self)
		end
	elseif self._arenaBattleId ~= nil then
		local arenaConfigId = self._parameter.arenaConfigId
		local arenaId = self._parameter.arenaId
		local battleIndex = self._parameter.battleIndex

		NetManager.Send("ArenaSettle", {
			ArenaConfigId = arenaConfigId,
			ArenaId = arenaId,
			ArenaBattleId = self._arenaBattleId,
			BattleIndex = battleIndex,
			Step = self._arenaBattleDifficulty,
			Result = self._battleWin,
			Round = self._TotalRound,
			CharacterList = fianlCharacterList,
			PetId = petId,
		}, BattleCtrl.OnHandleProto, self)
	elseif self._activityBattleId ~= nil then
		NetManager.Send("ActivityBattleSettle", {
			ActivityThemeId = self._activityThemeId,
			ActivityBattleId = self._activityBattleId,
			Result = self._battleWin,
			Round = self._TotalRound,
			CharacterList = fianlCharacterList,
			PetId = petId,
		}, BattleCtrl.OnHandleProto, self)
	end
end

function BattleCtrl:OnHandleProto(proto, data, requestData)
	if proto == "ChallengeSettle" then
		local challengeId = requestData.ChallengeId
		local settleResult = requestData.Result
		local challengeStar = requestData.Star
		local challengeRound = requestData.Round
		
		if settleResult then
			-- collect item
			local rewardList = data.RewardList or {}
			for idx = 1, #rewardList do
				local itemId = rewardList[idx].Value
				local itemNum = rewardList[idx].Num
				GameData.CollectItem(itemId, itemNum, false)
			end

			local fullStarRewardSettle = data.FullStarReward or false
			if fullStarRewardSettle then
				local fullStarRewards = ConfigUtils.GetChallengeFullStarRewards(challengeId)
				for idx = 1, #fullStarRewards do
					local itemId = fullStarRewards[idx].Value
					local itemNum = fullStarRewards[idx].Num
					GameData.CollectItem(itemId, itemNum, false)
				end
			end

			local goldNum = data.RemainGold
			local diamondNum = data.RemainDiamond
			GameData.SetMoney(ItemType.Gold, goldNum)
			GameData.SetMoney(ItemType.Diamond, diamondNum)
		end
	
		CtrlManager.OpenPanel(CtrlNames.BattleResult, {
			challengeId = challengeId,
			settleResult = settleResult,
			challengeStar = challengeStar,
			challengeRound = challengeRound,
		})
	elseif proto == "STChoiceChallengeSettle" then
		local seasonId = requestData.STSeasonID
		local choiceId = requestData.ChoiceId
		local challengeId = requestData.ChallengeId
		local settleResult = requestData.Result
		-- lose
		if not settleResult then
			local seasonData = GameData.GetSpaceTravelSeasonData(seasonId)
			local isRetry = (seasonData.choiceRetry > 0)
			seasonData.choiceRetry = seasonData.choiceRetry + 1
			if isRetry then
				seasonData.leftBattleRetry = math.max(seasonData.leftBattleRetry - 1, 0)
			end
		else
			-- career
			GameData.ModifySpaceTravelCareerData(SpaceTravelCareerType.ChallengeWinCount, 1)
			-- goal
        	local goalData = GameData.SetupItemGoalData(choiceId, 1)
        	GameData.DoSpaceTravelGoalSettle(seasonId, TriggerType.ChoiceWin, {goalData})
		end

		local baseResult = {
			Food = data.Food,
			Fuel = data.Fuel,
			Score = data.Score,
		}

        CtrlManager.OpenPanel(CtrlNames.BattleResult, {
			challengeId = challengeId,
			settleResult = settleResult,
			seasonId = seasonId,
			choiceId = choiceId,
			baseResult = baseResult
		})
	elseif proto == "ArenaSettle" then
		local arenaConfigId = requestData.ArenaConfigId
		local battleIndex = requestData.BattleIndex
		local arenaBattleId = requestData.ArenaBattleId
		local difficulty = requestData.Step
		local settleResult = requestData.Result
		local arenaRewards = {}
		if settleResult then
			local isOk, preDifficulty = GameData.SetCurrentDifficultyOfArenaBattle(arenaConfigId, battleIndex, difficulty)
			if isOk then
				local difficultyData = ConfigUtils.GetArenaBattleDifficultyData(arenaBattleId)
				local rewardItemMap = {}
				for idx = preDifficulty + 1, difficulty, 1 do
					local rewards = difficultyData[idx].Reward or {}
					for m = 1, #rewards do
						local rewardId = rewards[m].Value
						local rewardNum = rewards[m].Num
						local preNum = rewardItemMap[rewardId] or 0
						rewardItemMap[rewardId] = preNum + rewardNum
					end
				end

				for k, v in pairs(rewardItemMap) do
					GameData.CollectItem(k, v, false)
					table.insert(arenaRewards, {value = k, num = v, unlocked = true})
				end
			end

			local goldNum = data.RemainGold
			local diamondNum = data.RemainDiamond
			GameData.SetMoney(ItemType.Gold, goldNum)
			GameData.SetMoney(ItemType.Diamond, diamondNum)
		end

		CtrlManager.OpenPanel(CtrlNames.BattleResult, {
			arenaBattleId = arenaBattleId,
			battleIndex = battleIndex,
			difficulty = difficulty,
			settleResult = settleResult,
			showRewards = arenaRewards,
		})
	elseif proto == "ActivityBattleSettle" then
		local themeId = requestData.ActivityThemeId
		local battleId = requestData.ActivityBattleId
		local settleResult = requestData.Result
		local battleList = data.BattleList

		-- cost item
		local costList = data.CostList or {}
		for idx = 1, #costList do
			local itemId = costList[idx].Value
			local itemNum = costList[idx].Num
			GameData.ConsumeItem(itemId, itemNum)
		end
		
		local activityRewards = {}
		if settleResult then
			-- collect item
			local rewardList = data.RewardList or {}
			for idx = 1, #rewardList do
				local itemId = rewardList[idx].Value
				local itemNum = rewardList[idx].Num
				GameData.CollectItem(itemId, itemNum, false)
				table.insert(activityRewards, {value = itemId, num = itemNum, unlocked = true})
			end
		end

		local goldNum = data.RemainGold
		local diamondNum = data.RemainDiamond
		GameData.SetMoney(ItemType.Gold, goldNum)
		GameData.SetMoney(ItemType.Diamond, diamondNum)
	
		CtrlManager.OpenPanel(CtrlNames.BattleResult, {
			activityBattleId = battleId,
			activityThemeId = themeId,
			activityBattleList = battleList,
			settleResult = settleResult,
			showRewards = activityRewards,
		})
	end
end