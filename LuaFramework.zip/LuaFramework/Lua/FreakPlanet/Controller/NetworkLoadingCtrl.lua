require "FreakPlanet/View/NetworkLoadingPanel"

local class = require "FreakPlanet/Utils/middleclass"
NetworkLoadingCtrl  = class(CtrlNames.NetworkLoading, BaseCtrl)

-- load the ui prefab
function NetworkLoadingCtrl:LoadPanel()
	self:CreatePanel("NetworkLoading")
end

-- construct ui panel data
function NetworkLoadingCtrl:ConstructUI(obj)
	self._ui = NetworkLoadingPanel.Init(obj)
end

-- fill ui with the data
function NetworkLoadingCtrl:SetupUI()
	self:HideInternal()
end

function NetworkLoadingCtrl:HideInternal()
	if self._ui == nil or self._ui.Panel == nil or not self._ui.Panel.activeSelf then
		return
	end

	self._ui.Panel:SetActive(false)
end

function NetworkLoadingCtrl:ShowInternal()
	if self._ui == nil or self._ui.Panel == nil or self._ui.Panel.activeSelf then
		return
	end

	self._ui.Panel:SetActive(true)
	self._ui.TweenScale:ResetToBeginning()
	self._ui.TweenScale:PlayForward()
end

function NetworkLoadingCtrl.Show()
	local ctrl = CtrlManager.GetCtrlByName(CtrlNames.NetworkLoading)
	if ctrl ~= nil then
		ctrl:ShowInternal()
	end
end

function NetworkLoadingCtrl.Hide()
	local ctrl = CtrlManager.GetCtrlByName(CtrlNames.NetworkLoading)
	if ctrl ~= nil then
		ctrl:HideInternal()
	end
end
