require "FreakPlanet/View/WorkShopPanel"

local utf8 = require "FreakPlanet/Utils/Utf8"
local class = require "FreakPlanet/Utils/middleclass"
WorkShopCtrl  = class(CtrlNames.WorkShop, BaseCtrl)

local MAX_DROP_ITEM_NUM = 10
local DROP_DURATION = 0.3
local COLLECT_DURATION = 0.3

-----------------------------------------------------------------------------------------
local function WorkShopSortFunc(idA, idB)
	if idA == nil or idB == nil then
		return false
	end

	local valueA = ConfigUtils.GetWorkShopSortId(idA)
	local valueB = ConfigUtils.GetWorkShopSortId(idB)

	return valueA < valueB
end

local function RewardsSortFunc(elementA, elementB)
	if elementA == nil or elementB == nil then
		return false
	end

	local valueA = elementA.time
	local valueB = elementB.time

	return valueA < valueB
end
-----------------------------------------------------------------------------------------
-- load the ui prefab
function WorkShopCtrl:LoadPanel()
	self:CreatePanel("WorkShop")
end

-- construct ui panel data
function WorkShopCtrl:ConstructUI(obj)
	self._ui = WorkShopPanel.Init(obj)
end

function WorkShopCtrl:DestroyImpl()
	GameNotifier.RemoveListener(GameEvent.WorkShopListChanged, WorkShopCtrl.OnWorkShopListChanged, self)
	GameNotifier.RemoveListener(GameEvent.WorkShopExchanged, WorkShopCtrl.OnWorkShopExchanged, self)
end


-- fill ui with the data
function WorkShopCtrl:SetupUI()
	self._npcs = {}
	self._npcList = ConfigUtils.GetNpcList()
	self._npcPrefab = self:DynamicLoadAsset(Const.NpcBundleName, "NPC")
	self._workShopDrops = {}
	self._rewardDropItems = {}
	self._collectDropItems = {}
	self._dialogList = {}
	self._exchangeState = nil

    self._ui.DetailPanel:SetActive(false)
	-- self:SetupWorkShopList()
    self:GenerateNpc()
	NetManager.Send("WorkShopList", {}, WorkShopCtrl.OnHandleProto, self)

	CtrlManager.AddClick(self, self._ui.ButtonClose)
	CtrlManager.AddClick(self, self._ui.ButtonReceiveAll)
	CtrlManager.AddClick(self, self._ui.ButtonEnter)
	CtrlManager.AddClick(self, self._ui.ButtonExchange)
	CtrlManager.AddClick(self, self._ui.DetailPanelBlocker)
	GameNotifier.AddListener(GameEvent.WorkShopListChanged, WorkShopCtrl.OnWorkShopListChanged, self)
	GameNotifier.AddListener(GameEvent.WorkShopExchanged, WorkShopCtrl.OnWorkShopExchanged, self)
end

function WorkShopCtrl:SetupWorkShopList()
	self:RecycleDropItem()
	self._workShopList = ConfigUtils.GetWorkShopList()
	table.sort(self._workShopList, WorkShopSortFunc)

	for idx = 1, #self._ui.WorkShops do
		local icon = self._ui.WorkShops[idx].icon
		local brand = self._ui.WorkShops[idx].brand
		local score = self._ui.WorkShops[idx].score
		local dropCollider = self._ui.WorkShops[idx].dropCollider
		local workShopId = self._workShopList[idx]


		score.text = GameData.GetWorkShopRankLevel(workShopId)
		local item = self._ui.WorkShops[idx].item
		CtrlManager.AddClick(self, item)
		CtrlManager.AddClick(self, dropCollider)

		local state = GameData.GetWorkShopState(workShopId)
		brand:SetActive(state ~= WorkShopState.Lock)
		if state == WorkShopState.Lock then
			icon.color = LOCK_ICON_COLOR
		else
			icon.color = Color.white
		end

		local rewards = GameData.GetDropDataOfWorkShop(workShopId)
		self._workShopDrops[workShopId] = {
			state = state,
			rewards = rewards,
		}

		self:CheckWorkShopHint(workShopId)
	end
	self:ConstructInitialDropItems()
	self:CheckTutorial()
end

function WorkShopCtrl:UpdateWorkShopUI()
	for idx = 1, #self._ui.WorkShops do
		local workShopId = self._workShopList[idx]
		local icon = self._ui.WorkShops[idx].icon
		local state = GameData.GetWorkShopState(workShopId)
		local brand = self._ui.WorkShops[idx].brand
		local score = self._ui.WorkShops[idx].score
		brand:SetActive(state ~= WorkShopState.Lock)

		if state == WorkShopState.Lock then
			icon.color = LOCK_ICON_COLOR
		else
			icon.color = Color.white
			score.text = GameData.GetWorkShopRankLevel(workShopId)
		end
		local rewards = GameData.GetDropDataOfWorkShop(workShopId)
		self._workShopDrops[workShopId] = {
			state = state,
			rewards = rewards,
		}
		self:CheckWorkShopHint(workShopId)
	end
	self:RecycleDropItem()
	self:ConstructInitialDropItems()
end

--- 打工点详情界面UI
function WorkShopCtrl:ConstructWorkShopDetailPanel(workShopId)
	local ui = self._ui
	local state = GameData.GetWorkShopState(workShopId)
	if state == WorkShopState.Lock then
		CtrlManager.ShowMessageBox({ message = SAFE_LOC("loc_global_gallary_didnot_unlock"), single = true })
		return
	end

	local selectedCharacters = {}
	if state == WorkShopState.Working then
		selectedCharacters = GameData.GetCharactersOfWorkShop(workShopId)
	end
	ui.DetailPanel:SetActive(true)
	self._workShopId = workShopId
	ui.WorkShopName.text = ConfigUtils.GetWorkShopName(workShopId)
	ui.WorkShopLevel.text = string.format(SAFE_LOC("loc_SimpleLevel"), GameData.GetWorkShopLevel(workShopId))
	local rewards = GameData.GetDropDataOfWorkShop(workShopId)
	for idx = 1, #ui.WorkShopRewards do
		if idx <= #rewards then
			local unlocked = rewards[idx].unlocked
			local dropId = rewards[idx].dropId
			local productionSpeed = rewards[idx].productionSpeed
			local dropType =ConfigUtils.GetItemTypeFromId(dropId)

			ui.WorkShopRewards[idx].item:SetActive(true)
			ui.WorkShopRewards[idx].gold.gameObject:SetActive(dropType == ItemType.Gold)
			ui.WorkShopRewards[idx].goods.gameObject:SetActive(dropType == ItemType.Goods)
			if dropType == ItemType.Goods then
				UIHelper.SetItemIcon(self,ui.WorkShopRewards[idx].goods,dropId)
			end

			ui.WorkShopRewards[idx].unlocked:SetActive(unlocked)
			ui.WorkShopRewards[idx].locked:SetActive(not unlocked)

			if unlocked then
				ui.WorkShopRewards[idx].progressBar:SetActive(productionSpeed > 0)
				if productionSpeed == 0 then
					ui.WorkShopRewards[idx].unlockedDec.text = SAFE_LOC("loc_global_workshop_not_at_work")
				else
					ui.WorkShopRewards[idx].unlockedDec.text = ""
				end
			else
				local unlockLevel = rewards[idx].unlockLevel
				ui.WorkShopRewards[idx].lockedDesc.text = tostring(unlockLevel) .. SAFE_LOC("级解锁")
			end

		else
			ui.WorkShopRewards[idx].item:SetActive(false)
		end
	end

	ui.EmptyWorkShopTag:SetActive(#selectedCharacters <= 0)
	for idx = 1, ui.CharacterRoot.childCount do
		local hasCharacter = (idx <= #selectedCharacters)
		local item = ui.CharacterRoot:GetChild(idx - 1)
		item.gameObject:SetActive(hasCharacter)
		if hasCharacter then
			local characterIcon = item:GetComponent("UISprite")
			UIHelper.SetCharacterIcon(self, characterIcon, selectedCharacters[idx])
		end
	end
	ui.CharacterRoot:GetComponent("UIGrid"):Reposition()
	local workShopLevel = GameData.GetWorkShopLevel(workShopId)
	local numLimit = ConfigUtils.GetWorkShopNumCapacity(workShopId, workShopLevel)
	ui.CharacterCapacity.text = string.format("%d/%d", #selectedCharacters, numLimit)

	local IconBg, DeskBg = ConfigUtils.GetWorkShopIconBG(workShopId)
	ui.WorkShopDesk.spriteName = DeskBg
end


function WorkShopCtrl:NotifyFocus()
	self:UpdateWorkShopUI()
	if self._workShopId then
		self:ConstructWorkShopDetailPanel(self._workShopId)
	end
	self:CheckTutorialWhenFocus()
end


function WorkShopCtrl:HasAnyRewardSettle()
	for k, v in pairs(self._workShopDrops)  do
		if self:HasRewardToSettle(k) then
			return true
		end
	end
	return false
end

function WorkShopCtrl:HasRewardToSettle(workShopId)
	local state = self._workShopDrops[workShopId].state
	if state == WorkShopState.Lock then
		return false
	end

	local currentTime = GameData.GetServerTime()
	local lastRefreshTime = GameData.GetWorkShopRefreshTime(workShopId)
	local timeDiff = math.max(currentTime - lastRefreshTime, 0)

	local rewards = self._workShopDrops[workShopId].rewards
	for idx = 1, #rewards do
		local v = rewards[idx]
		local currentProduction = v.recordProduction
		local maxProduction = v.maxProduction
		if currentProduction < maxProduction then
			currentProduction = currentProduction + v.productionSpeed * timeDiff
			currentProduction = math.min(currentProduction, maxProduction)
		end

		local productionPerCycle = v.productionPerCycle
		if currentProduction >= productionPerCycle then
			return true
		end
	end

	return false
end

function WorkShopCtrl:UpdateImpl(deltaTime)
	self:UpdateRewards(deltaTime)
	self:UpdateNpc(deltaTime)
	self:UpdateExchangeShow(deltaTime)
end


function WorkShopCtrl:UpdateRewards(deltaTime)
	local currentTime = GameData.GetServerTime()

	for workShopId, v in pairs(self._workShopDrops) do
		if self._WorkShopId == workShopId and v.state ~= WorkShopState.Lock then
			local lastRefreshTime = GameData.GetWorkShopRefreshTime(workShopId)
			local timeDiff = math.max(currentTime - lastRefreshTime, 0)

			local rewardDirty = false
			local rewards = v.rewards
			for idx = 1, #rewards do
				if rewards[idx].unlocked then
					local maxProduction = rewards[idx].maxProduction
					local currentProduction = rewards[idx].recordProduction
					local productionSpeed = rewards[idx].productionSpeed
					if currentProduction < maxProduction then
						currentProduction = currentProduction + productionSpeed * timeDiff
						currentProduction = math.min(currentProduction, maxProduction)
					end
					
					local numCycles = currentProduction / rewards[idx].productionPerCycle
					local currentCycles = math.floor(numCycles)


					if maxProduction > 0 then

						local leftProduction = math.max(maxProduction - currentProduction, 0)
						local leftTime = math.ceil(leftProduction / productionSpeed)
						if leftTime > 0 then
							self._ui.WorkShopRewards[idx].unlockedDec.text = Helper.FormatTime(leftTime)
						else
							self._ui.WorkShopRewards[idx].unlockedDec.text = SAFE_LOC("满啦")
						end

						local lastCycles = rewards[idx].lastCycles
						if lastCycles ~= nil and lastCycles < currentCycles then
							SoundSystem.PlaySoundOfName(SoundNames.WorkshopNewItem)
							local dropSeed = currentCycles * rewards[idx].productionPerCycle + idx
							self:GenerateWorkShopDrop(workShopId, rewards[idx].dropId, dropSeed, false)
							self._ui.WorkShopRewards[idx].hintAnimator:Play("RewardIcon", 0, 0)
						end
						rewards[idx].lastCycles = currentCycles

						if leftProduction == 0 then
							rewardDirty = true
						end
					end
				end
			end

			if rewardDirty then
				self:CheckWorkShopHint(workShopId)
			end
		end
	end

	for idx = #self._rewardDropItems, 1, -1 do
		local state = self._rewardDropItems[idx].state
		local finished = state:Tick(deltaTime)
		if finished then
			-- enable the animation
			local dropAnimator = self._rewardDropItems[idx].item:GetComponent("Animator")
			dropAnimator.enabled = true
			table.remove(self._rewardDropItems, idx)
		end
	end

	local collectDirty = false
	for idx = #self._collectDropItems, 1, -1 do
		local state = self._collectDropItems[idx].state
		local finished = state:Tick(deltaTime)
		if finished then
			local item = self._collectDropItems[idx].item
			item.parent = self._ui.DropItemPool
			table.remove(self._collectDropItems, idx)
			collectDirty = true
		end
	end

	if collectDirty and #self._collectDropItems == 0 then
		self:OnCollectFinish()
	end
end

function WorkShopCtrl:OnCollectFinish()
	NavigationCtrl.EnableSuspend(false)
	GameNotifier.Notify(GameEvent.WorkShopListChanged)
	if #self._finalRewards > 0 then
		CtrlManager.OpenPanel(CtrlNames.WorkShopResult, {rewards = self._finalRewards})
	end
end

function WorkShopCtrl:UpdateNpc(deltaTime)
	local removedCount = 0
	for idx = #self._npcs, 1, -1 do
		local state = self._npcs[idx].state
		local finished = state:Tick(deltaTime)
		if finished then
			removedCount = removedCount + 1
			self._npcs[idx].item.parent = self._ui.NpcPool
			table.remove(self._npcs, idx)
		end
	end

	if removedCount > 0 then
		self:PickNpc(removedCount)
	end
end

function WorkShopCtrl:UpdateExchangeShow(deltaTime)
	if self._exchangeState ~= nil then
		local finished = self._exchangeState:Tick(deltaTime)
		if finished then
			self._exchangeState = nil
		end
	end
end

function WorkShopCtrl:CheckWorkShopHint(workShopId)
	local workShopIdx = Helper.IndexOfArray(self._workShopList, workShopId)
	local hint = self._ui.WorkShops[workShopIdx].hint
	local clock = self._ui.WorkShops[workShopIdx].clock
	-- locked
	local rewards = self._workShopDrops[workShopId].rewards
	if rewards == nil then
		hint:SetActive(false)
		clock.gameObject:SetActive(false)
		return
	end

	local currentTime = GameData.GetServerTime()
	local lastRefreshTime = GameData.GetWorkShopRefreshTime(workShopId)
	local timeDiff = math.max(currentTime - lastRefreshTime, 0)

	local hasWorking = false

	for idx = 1, #rewards do
		local v = rewards[idx]
		if v.unlocked then
			if v.productionSpeed > 0 then
				local maxProduction = v.maxProduction
				local productionSpeed = v.productionSpeed
				local currentProduction = v.recordProduction
				if currentProduction < maxProduction then
					currentProduction = currentProduction + productionSpeed * timeDiff
					currentProduction = math.min(currentProduction, maxProduction)
				end

				if currentProduction < maxProduction then
					hasWorking = true
					break
				end
			end
		end
	end

	clock.gameObject:SetActive(true)
	clock.enabled = hasWorking
	hint:SetActive(not hasWorking)
end

-- handle the escapse button
function WorkShopCtrl:HandleEscape()
	self:OnClicked(self._ui.ButtonClose)
end

-- can do jump or not
function WorkShopCtrl:CanJump()
	if #self._collectDropItems > 0 or self._exchangeState ~= nil then
		return false
	end

	return true
end

function WorkShopCtrl:CloseToCharacter(workShopId)
	CtrlManager.OpenPanel(CtrlNames.WorkShopCharacter, {workShopId = workShopId})
end

-- on clicked
function WorkShopCtrl:OnClicked(go)
	-- do collecting
	if #self._collectDropItems > 0 or self._exchangeState ~= nil then
		return true
	end
	if go == self._ui.ButtonClose then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
	elseif go == self._ui.DetailPanelBlocker then
		self._ui.DetailPanel:SetActive(false)
		self._workShopId = nil
	elseif go == self._ui.ButtonEnter then
		local state = GameData.GetWorkShopState(self._workShopId)
		if state ~= WorkShopState.Lock then
			SoundSystem.PlayUIClickSound()
			CtrlManager.DoWaitTransition(CtrlNames.WorkShopCharacter, self, WorkShopCtrl.CloseToCharacter, self._workShopId)
		else
			SoundSystem.PlayWarningSound()
		end
	elseif Helper.StartWith(go.name, "WorkShop_") then
		local names = Helper.StringSplit(go.name)
		local idx = tonumber(names[2])
		local workShopId = self._workShopList[idx]
		self._WorkShopId = workShopId
		self:ConstructWorkShopDetailPanel(workShopId)
	elseif go.name == "DropCollider" then
		local parent = go.transform.parent
		local names = Helper.StringSplit(parent.name)
		local idx = tonumber(names[2])
		local workShopId = self._workShopList[idx]
		local state = self._workShopDrops[workShopId].state
		if self:HasRewardToSettle(workShopId) then
			SoundSystem.PlayRewardSound()
			self._finalRewards = {}
			NetManager.Send("WorkShopSettle", { WorkShopId = workShopId }, WorkShopCtrl.OnHandleProto, self)
		elseif state == WorkShopState.Working then
			SoundSystem.PlayWarningSound()
			CtrlManager.ShowMessageBox({message = SAFE_LOC("再等等，面包总会有的"), single = true})
		end
	elseif go == self._ui.ButtonExchange then
		SoundSystem.PlayUIClickSound()
		CtrlManager.OpenPanel(CtrlNames.WorkShopExchange, { workShopId = self._workShopId })
	elseif go == self._ui.ButtonReceiveAll then
		if self:HasAnyRewardSettle() then
			SoundSystem.PlayRewardSound()
			self._finalRewards = {}
			NetManager.Send("WorkShopSettleAll", {}, WorkShopCtrl.OnHandleProto, self)
		else
			SoundSystem.PlayWarningSound()
			CtrlManager.ShowMessageBox({message = SAFE_LOC("再等等，面包总会有的"), single = true})
		end
	end
	return true
end

function WorkShopCtrl:OnWorkShopListChanged()
	-- self:SetupWorkShopGrid()
	self:UpdateWorkShopUI()
end

function WorkShopCtrl:OnHandleProto(proto, data, requestData)
	if proto == "WorkShopList" then
		GameData.InitWorkShopList(data)
		GameData.CheckAndHintGoalsOfCurrentCountType()
		self:SetupWorkShopList()
	elseif proto == "WorkShopSettle" then
		NavigationCtrl.EnableSuspend(true)
		local workShopId = requestData.WorkShopId
		local rewardList = data.RewardList or {}
		local dropMap = {}
		for idx = 1, #rewardList do
			local dropId = rewardList[idx].Value
			local dropNum = rewardList[idx].Num
			if dropNum > 0 then
				local preNum = dropMap[dropId] or 0
				dropMap[dropId] = preNum + dropNum
			end
		end

		local finalRewards = {}
		for k, v in pairs(dropMap) do
			GameData.CollectItem(k, v)
			table.insert(finalRewards, {Value = k, Num = v})
		end
		self._finalRewards = finalRewards
		GameData.IncWorkShopSettle()
		GameData.SetDataOfWorkShop(data.WorkShopStatus)
		self:CollectDropItem(workShopId)

		if #self._collectDropItems == 0 then
			self:OnCollectFinish()
		end
	elseif proto == "WorkShopSettleAll" then
		NavigationCtrl.EnableSuspend(true)
		local rewardList = data.RewardList or {}
		local dropMap = {}
		for idx = 1, #rewardList do
			local dropId = rewardList[idx].Value
			local dropNum = rewardList[idx].Num
			if dropNum > 0 then
				local preNum = dropMap[dropId] or 0
				dropMap[dropId] = preNum + dropNum
			end
		end

		local finalRewards = {}
		for k, v in pairs(dropMap) do
			GameData.CollectItem(k, v)
			table.insert(finalRewards, {Value = k, Num = v})
		end
		self._finalRewards = finalRewards
		GameData.IncWorkShopSettle()

		for idx = 1, #data.WorkShopStatus do
			GameData.SetDataOfWorkShop(data.WorkShopStatus[idx])
			local workShopId = data.WorkShopStatus[idx].WorkShopId
			self:CollectDropItem(workShopId)
		end

		if #self._collectDropItems == 0 then
			self:OnCollectFinish()
		end
	end
end

-------------------------------------------------------------------------------------------
function WorkShopCtrl:RecycleDropItem()
	for idx = 1, #self._ui.WorkShops do
		local dropRoot = self._ui.WorkShops[idx].dropRoot
		for dropIdx = dropRoot.childCount, 1, -1 do
			local dropItem = dropRoot:GetChild(dropIdx - 1)
			dropItem.parent = self._ui.DropItemPool
		end
	end
end

function WorkShopCtrl:TrimDropItemOfWorkShop(workShopId)
	local workShopIdx = Helper.IndexOfArray(self._workShopList, workShopId)
	local dropRoot = self._ui.WorkShops[workShopIdx].dropRoot
	if dropRoot.childCount <= MAX_DROP_ITEM_NUM then
		return
	end

	local numToTrim = dropRoot.childCount - MAX_DROP_ITEM_NUM
	for idx = 1, numToTrim do
		local dropItem = dropRoot:GetChild(0)
		dropItem.parent = self._ui.DropItemPool
	end
end

function WorkShopCtrl:ConstructInitialDropItems()
	local currentTime = GameData.GetServerTime()
	for workShopId, v in pairs(self._workShopDrops) do
		if v.state ~= WorkShopState.Lock then
			local dropList = {}

			local lastRefreshTime = GameData.GetWorkShopRefreshTime(workShopId)
			local timeDiff = math.max(currentTime - lastRefreshTime, 0)

			local rewards = v.rewards
			for idx = 1, #rewards do
				if rewards[idx].unlocked then
					local dropId = rewards[idx].dropId
					local maxProduction = rewards[idx].maxProduction
					local currentProduction = rewards[idx].recordProduction
					if currentProduction < maxProduction then
						currentProduction = currentProduction + rewards[idx].productionSpeed * timeDiff
						currentProduction = math.min(currentProduction, maxProduction)
					end

					local productionPerCycle = rewards[idx].productionPerCycle
					local dropCycles = math.floor(currentProduction / productionPerCycle)
					for m = 1, dropCycles do
						local seed = m * productionPerCycle + idx
						local time = 0
						if rewards[idx].productionSpeed > 0 then
							time = m * productionPerCycle / rewards[idx].productionSpeed
						else
							time = m * productionPerCycle
						end
						table.insert(dropList, {id = dropId, seed = seed, time = time})
					end
				end
			end

			-- do sort
			table.sort(dropList, RewardsSortFunc)

			local start = math.max(#dropList - MAX_DROP_ITEM_NUM + 1, 1)
			for idx = start, #dropList do
				local dropId = dropList[idx].id
				local dropSeed = dropList[idx].seed
				self:GenerateWorkShopDrop(workShopId, dropId, dropSeed, true)
			end
		end
	end
end

function WorkShopCtrl:GenerateWorkShopDrop(workShopId, dropId, dropSeed, first)
	local workShopIdx = Helper.IndexOfArray(self._workShopList, workShopId)
	local dropRoot = self._ui.WorkShops[workShopIdx].dropRoot
	local leftLimit = self._ui.WorkShops[workShopIdx].left
	local rightLimit = self._ui.WorkShops[workShopIdx].right

	-- set rand seed
	Helper.RandSeed(dropSeed)
	local initialPosition = Vector3.zero
	local x = Helper.RandFloat(leftLimit.x, rightLimit.x)
	local y = leftLimit.y + Helper.RandFloat(-5, 5)
	local z = y
	local targetPosition = Vector3.New(x, y, z)
	-- reset rand seed
	Helper.RandSeed()

	local dropItem = nil
	if self._ui.DropItemPool.childCount == 0 then
		local dropObj = Helper.NewObject(self._ui.DropItemTemplate, dropRoot)
		dropItem = dropObj.transform
	else
		dropItem = self._ui.DropItemPool:GetChild(0)
		dropItem.parent = dropRoot
	end

	local dropType = ConfigUtils.GetItemTypeFromId(dropId)
	local goldRoot = dropItem:Find("Root/Gold").gameObject
	local goodsIcon =dropItem:Find("Root/Goods"):GetComponent("UISprite")
	goldRoot:SetActive(dropType == ItemType.Gold)
	goodsIcon.gameObject:SetActive(dropType == ItemType.Goods)
	if dropType == ItemType.Goods then
		UIHelper.SetItemIcon(self,goodsIcon, dropId)
	end

	dropItem.gameObject.name = tostring(dropId)
	dropItem.gameObject:SetActive(true)
	dropItem.localScale = Vector3.one

	local dropAnimator = dropItem:GetComponent("Animator")
	dropAnimator.speed = Helper.RandFloat(0.9, 1.1)
	dropAnimator.enabled = first

	if first then
		dropItem.localPosition = targetPosition
	else
		local pos = Vector3.zero
		pos.z = targetPosition.z
		dropItem.localPosition = pos
		local duration = DROP_DURATION
		local xSpeed = x / duration
		local ySpeed = Helper.RandFloat(0, 10)
		local xAcceleration = 0
		local yAcceleration = (y - ySpeed * duration) * 2 / (duration * duration)
		local state = TransformState:new(dropItem, targetPosition, Vector3.New(xSpeed, ySpeed, 0), Vector3.New(xAcceleration, yAcceleration, 0), false, true)
		state:ActionOnExit(WorkShopCtrl.OnDropItemTransformed, self, workShopId)
		table.insert(self._rewardDropItems, {item = dropItem, state = state, workShopId = workShopId})
	end
end

function WorkShopCtrl:OnDropItemTransformed(workShopId)
	self:TrimDropItemOfWorkShop(workShopId)
end

function WorkShopCtrl:CollectDropItem(workShopId)
	for idx = #self._rewardDropItems, 1, -1 do
		if self._rewardDropItems[idx].workShopId == workShopId then
			table.remove(self._rewardDropItems, idx)
		end
	end

	self._collectDropItems = {}
	local duration = COLLECT_DURATION
	local workShopIdx = Helper.IndexOfArray(self._workShopList, workShopId)
	local dropRoot = self._ui.WorkShops[workShopIdx].dropRoot
	local childCount = dropRoot.childCount
	for dropIdx = 1, childCount do
		local dropItem = dropRoot:GetChild(dropIdx - 1)
		local goldMarkPosition = NavigationCtrl.GetGoldPosition()
		local goldWorldPosition = self._ui.Camera:ScreenToWorldPoint(goldMarkPosition)
		local targetPosition = dropRoot:InverseTransformPoint(goldWorldPosition)
		local startPosition = dropItem.localPosition
		local accleration = (targetPosition - startPosition) * 2 / (duration * duration) * Helper.RandFloat(0.8, 1.4)
		local state = TransformState:new(dropItem, targetPosition, Vector3.zero, accleration, true, false)
		table.insert(self._collectDropItems, {item = dropItem, state = state})
	end
end
-------------------------------------------------------------------------------------------
function WorkShopCtrl:OnWorkShopExchanged(workShopId, rewards)
	assert(self._exchangeState == nil, "exchange state is not null")

	self._exchangeState = SequenceState:new()

	local workShopItem = self._ui.CharacterRoot
	if workShopItem ~= nil then
		local characterAnimator = workShopItem:GetComponent("Animator")
		local overtimeState = AnimatorState:new(characterAnimator, "Overtime", "Working", nil)
		overtimeState:ActionOnExit(WorkShopCtrl.OnExchangeShowUp, self)
		self._exchangeState:Push(overtimeState)
	end

	local workShopIdx = Helper.IndexOfArray(self._workShopList, workShopId)
	local overtimeAnimator = self._ui.WorkShops[workShopIdx].overtimeAnimator
	local dropState = AnimatorState:new(overtimeAnimator, "Drop", nil, nil)
	self._exchangeState:Push(dropState)

	self._exchangeState:ActionOnExit(WorkShopCtrl.OnExchangeShowFinished, self, rewards)
end

function WorkShopCtrl:OnExchangeShowUp()
	SoundSystem.PlaySummonSound()
end

function WorkShopCtrl:OnExchangeShowFinished(rewards)
	CtrlManager.OpenPanel(CtrlNames.WorkShopResult, {rewards = rewards})
end
-------------------------------------------------------------------------------------------
function WorkShopCtrl:GenerateNpc()
	local num = Helper.RandInt(1, 2)
	for idx = 1, num do
		self:GenerateNpcGroup(true)
	end
end

function WorkShopCtrl:PickNpc(removed)
	if #self._npcs >= 10 then
		return
	end

	local num = Helper.RandInt(1, removed)

	for idx = 1, num do
		self:GenerateNpcGroup(false)
	end
end

function WorkShopCtrl:GenerateNpcGroup(firstTime)
	local numChance = {0.55, 0.35, 0.1}
	local chance = Helper.RandFloat()
	local num = 1
	if chance <= numChance[1] then
		num = 1
	elseif chance <= (numChance[1] + numChance[2]) then
		num = 2
	else
		num = 3
	end

	local speed = Helper.RandFloat(1, 3)
	for idx = 1, num do
		local npcItem, skeleton = self:GenerateNpcItem()
		--
		local initialPosition = self._ui.NpcRoot:InverseTransformPoint(self._ui.AnimaPathRoot:GetChild(0).position)
		npcItem.transform.localPosition = initialPosition
		--log(string.format("initialPosition x:%s,y:%s", initialPosition.x, initialPosition.y))
		local seqenceState = SequenceState:new()
		local transformState = nil
		for j = 1, self._ui.AnimaPathRoot.childCount - 1 do
			local item = self._ui.AnimaPathRoot:GetChild(j)
			local targetPosition = self._ui.NpcRoot:InverseTransformPoint(item.position)
			--log(string.format("offset x:%s,y:%s", targetPosition.x - initialPosition.x, targetPosition.y - initialPosition.y))
			transformState = TweenState:new(npcItem, initialPosition, targetPosition, speed)
			seqenceState:Push(transformState)
			initialPosition = targetPosition
		end
		table.insert(self._npcs, { item = npcItem, skeleton = skeleton, state = seqenceState })
	end

--[[
	local centerPosX = nil
	local targetX = nil

	if firstTime then
		centerPosX = Helper.RandFloat(self._ui.NpcLeftLimit * 0.6, self._ui.NpcRightLimit * 0.6)
		targetX = self._ui.NpcLeftLimit
		if Helper.RandBool() then
			targetX = self._ui.NpcRightLimit
		end
	else
		centerPosX = self._ui.NpcRightLimit
		targetX = self._ui.NpcLeftLimit
		if Helper.RandBool() then
			centerPosX = self._ui.NpcLeftLimit
			targetX = self._ui.NpcRightLimit
		end
	end

	for idx = 1, num do
		local npcItem, skeleton = self:GenerateNpcItem()
		local posX = centerPosX + (idx - (num + 1) / 2) * 1.2;
		local pos = npcItem.localPosition
		pos.x = posX
		npcItem.localPosition = pos

		Helper.CheckDirection(npcItem, (targetX - posX))

		local state = MoveInXState:new(npcItem, targetX, speed)
		table.insert(self._npcs, {item = npcItem, skeleton = skeleton, state = state})
	end

	--]]
end

function WorkShopCtrl:GenerateNpcItem()
	local npcIdx = Helper.RandInt(1, #self._npcList)
	local npcId = self._npcList[npcIdx]

	local npcItem = nil
	if self._ui.NpcPool.childCount == 0 then
		local npcObj = Helper.NewObject(self._npcPrefab, self._ui.NpcRoot)
		npcItem = npcObj.transform
	else
		npcItem = self._ui.NpcPool:GetChild(0)
		npcItem.parent = self._ui.NpcRoot
		npcItem.localPosition = Vector3.zero
		npcItem.localScale = Vector3.one
	end

	npcItem.gameObject.name = tostring(npcId)
	npcItem.gameObject:SetActive(true)

	local skeleton = npcItem:GetComponent("SkeletonAnimation")
	Helper.PlayAnimation(skeleton, WorkShopNPCAnimations.walk_1, true)

	local renderer = npcItem:GetComponent('MeshRenderer')
 	renderer.sortingOrder = 1

	local skinName = ConfigUtils.GetNpcSkin(npcId)
	Helper.SetSkin(skeleton, skinName)

	return npcItem, skeleton
end
-------------------------------------------------------------------------------------------
-- tutorial
function WorkShopCtrl:GetFirstWorkShopItem()
	return self._ui.WorkShops[1].item.transform
end

function WorkShopCtrl:CheckTutorial()
	local ui = self._ui
	local tutorials = {}

	if GameData.IsTutorialNotFinished(Tutorials.Tutorial_4_4) and GameData.IsGoalRunning(TutorialConstData.WorkShopGoal) then
		local workshopItem = self:GetFirstWorkShopItem()
		local position = self._ui.Camera:WorldToScreenPoint(workshopItem.position)
		tutorials[1] = {event = Tutorials.Tutorial_4_1, position = position, sender = self}
		tutorials[2] = {event = Tutorials.Tutorial_4_1_2, position = ui.Camera:WorldToScreenPoint(ui.ButtonEnter.transform.position), sender = self}
	elseif GameData.IsTutorialNotFinished(Tutorials.Tutorial_7_4) and GameData.IsGoalRunning(TutorialConstData.WorkShopUpgradeGoal) then
		local workshopItem = self:GetFirstWorkShopItem()
		local position = self._ui.Camera:WorldToScreenPoint(workshopItem.position)
		tutorials[1] = {event = Tutorials.Tutorial_7_1, position = position, sender = self}
		tutorials[2] = {event = Tutorials.Tutorial_7_1_2, position = ui.Camera:WorldToScreenPoint(ui.ButtonEnter.transform.position), sender = self}
	end

	if #tutorials > 0 then
		CtrlManager.ShowTutorials(tutorials)
	end

	return #tutorials > 0
end

function WorkShopCtrl:CheckTutorialWhenFocus()
	local tutorials = {}

	local tutorialIds = GameData.GetTutorialsOfCtrl(CtrlNames.WorkShop, "NotifyFocus") or {}
	local workshopItem = self:GetFirstWorkShopItem()

	for idx = 1, #tutorialIds do
		local tutorialId = tutorialIds[idx]
		if tutorialId == Tutorials.Tutorial_WorkshopRewardHint then
			local mark = workshopItem:Find("DropCollider")
			local position = self._ui.Camera:WorldToScreenPoint(mark.position)
			table.insert(tutorials, {event = Tutorials.Tutorial_WorkshopRewardHint, position = position, sender = self})
		elseif tutorialId == Tutorials.Tutorial_WorkshopExchange then
			local position = self._ui.ButtonExchange.transform.position
			table.insert(tutorials, {event = Tutorials.Tutorial_WorkshopExchange, position = position, sender = self})
		end
	end

	GameData.CleanTutorialsOfCtrl(CtrlNames.WorkShop)

	if #tutorials > 0 then
		CtrlManager.ShowTutorials(tutorials)
	end

	return #tutorials > 0
end

function WorkShopCtrl:OnTutorialClicked(tutorial)
	local ui = self._ui
	if tutorial == Tutorials.Tutorial_4_1 or tutorial == Tutorials.Tutorial_7_1 then
		local workshopItem = self:GetFirstWorkShopItem()
		self:OnClicked(workshopItem.gameObject)
	elseif tutorial == Tutorials.Tutorial_WorkshopExchange then
		self:OnClicked(ui.ButtonExchange)
	elseif tutorial == Tutorials.Tutorial_4_1_2 then
		self:OnClicked(ui.ButtonEnter)
	elseif tutorial == Tutorials.Tutorial_7_1_2 then
		self:OnClicked(ui.ButtonEnter)
	else
		SoundSystem.PlayUIClickSound()
	end
end
-------------------------------------------------------------------------------------------
-- 废弃


-------------------------------------------------------------------------------------------