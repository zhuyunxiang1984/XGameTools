require "FreakPlanet/View/WorkShopUpgradePanel"

local class = require "FreakPlanet/Utils/middleclass"
WorkShopUpgradeCtrl  = class(CtrlNames.WorkShopUpgrade, BaseCtrl)

-- load the ui prefab
function WorkShopUpgradeCtrl:LoadPanel()
	self:CreatePanel("WorkShopUpgrade")
end

-- construct ui panel data
function WorkShopUpgradeCtrl:ConstructUI(obj)
	self._ui = WorkShopUpgradePanel.Init(obj)
end

-- destroy implementation
function WorkShopUpgradeCtrl:DestroyImpl()
	GameNotifier.RemoveListener(GameEvent.ItemNumChanged, WorkShopUpgradeCtrl.OnItemNumChanged, self)
	GameNotifier.RemoveListener(GameEvent.MoneyChanged, WorkShopUpgradeCtrl.OnMoneyChanged, self)
end

-- fill ui with the data
function WorkShopUpgradeCtrl:SetupUI()
	self._workShopId = self._parameter.workShopId
	self._ui.WorkShopName.text = ConfigUtils.GetWorkShopName(self._workShopId)

	self:ConstructUpgradeItems()
	self:ConstructUpgradeDescs()

	for idx = 1, #self._ui.UpgradeItems do
		CtrlManager.AddClick(self, self._ui.UpgradeItems[idx].item)
	end
	CtrlManager.AddClick(self, self._ui.Blocker)
	CtrlManager.AddClick(self, self._ui.ButtonConfirm)
	GameNotifier.AddListener(GameEvent.ItemNumChanged, WorkShopUpgradeCtrl.OnItemNumChanged, self)
	GameNotifier.AddListener(GameEvent.MoneyChanged, WorkShopUpgradeCtrl.OnMoneyChanged, self)

	self:CheckTutorial()
end

function WorkShopUpgradeCtrl:ConstructUpgradeItems()
	local level = GameData.GetWorkShopLevel(self._workShopId)
	local needItems = ConfigUtils.GetWorkShopUpgradeItems(self._workShopId, level)
	local numEnough = true
	for idx = 1, #self._ui.UpgradeItems do
		local hasItem = (idx <= #needItems)
		self._ui.UpgradeItems[idx].item:SetActive(hasItem)
		if hasItem then
			local itemId = needItems[idx].Value
			local itemNum = needItems[idx].Num
			local currentItem = GameData.GetItemNum(itemId)

			local root = self._ui.UpgradeItems[idx].root
			UIHelper.ConstructItemIconAndNum(self, root, itemId)

			local numLabel = self._ui.UpgradeItems[idx].num
			numLabel.text = UIHelper.GetItemNumShowText(currentItem, 100000).."/"..UIHelper.GetItemNumShowText(itemNum, 100000)
			if currentItem < itemNum then
				numEnough = false
				numLabel.color = Color.red
			else
				numLabel.color = self._ui.ItemNumLabelColor
			end
		end
	end

	self._ui.ButtonConfirm:SetActive(#needItems > 0 and numEnough)
	self._ui.UpgradeItemHint:SetActive(#needItems > 0 and not numEnough)
	self._ui.UpgradeItemTable:Reposition()
end

function WorkShopUpgradeCtrl:ConstructUpgradeDescs()
	-- level
	local level = GameData.GetWorkShopLevel(self._workShopId)
	local newLevel = level + 1
	self._ui.UpgradeDescs[1].desc.text = SAFE_LOC("等级")
	self._ui.UpgradeDescs[1].value1.text = tostring(level)
	self._ui.UpgradeDescs[1].value2.text = tostring(newLevel)
	local index = 2
	-- capacity
	local preCapacity = ConfigUtils.GetWorkShopNumCapacity(self._workShopId, level)
	local newCapacity = ConfigUtils.GetWorkShopNumCapacity(self._workShopId, newLevel)
	if preCapacity ~= newCapacity then
		self._ui.UpgradeDescs[index].desc.text = SAFE_LOC("招聘人员")
		self._ui.UpgradeDescs[index].value1.text = tostring(preCapacity)
		self._ui.UpgradeDescs[index].value2.text = tostring(newCapacity)
		index = index + 1
	end
	-- max work time
	local preWorkTime = ConfigUtils.GetWorkShopMaxWorkTime(self._workShopId, level)
	local newWorkTime = ConfigUtils.GetWorkShopMaxWorkTime(self._workShopId, newLevel)
	if preWorkTime ~= newWorkTime then
		self._ui.UpgradeDescs[index].desc.text = SAFE_LOC("最大工时")
		self._ui.UpgradeDescs[index].value1.text = Helper.GetShortTimeString(preWorkTime)
		self._ui.UpgradeDescs[index].value2.text = Helper.GetShortTimeString(newWorkTime)
		index = index + 1
	end
	-- top rank
	local rankList = ConfigUtils.GetWorkShopRankList(self._workShopId)
	local preTopRank = ConfigUtils.GetWorkShopTopRank(self._workShopId, level)
	local newTopRank = ConfigUtils.GetWorkShopTopRank(self._workShopId, newLevel)
	if preTopRank ~= newTopRank then
		self._ui.UpgradeDescs[index].desc.text = SAFE_LOC("最高评价")
		self._ui.UpgradeDescs[index].value1.text = SAFE_LOC(rankList[preTopRank].RankText)
		self._ui.UpgradeDescs[index].value2.text = SAFE_LOC(rankList[newTopRank].RankText)
		index = index + 1
	end
	-- rewards
	local newRewards = ConfigUtils.GetWorkShopNewRewardsAtLevel(self._workShopId, newLevel)
	if #newRewards > 0 then
		local rewardText = ""
		for idx = 1, #newRewards do
			local itemName = ConfigUtils.GetItemName(newRewards[idx])
			rewardText = rewardText..itemName
			if idx < #newRewards then
				rewardText = rewardText..", "
			end
		end

		self._ui.UpgradeDescs[index].desc.text = SAFE_LOC("解锁道具")
		self._ui.UpgradeDescs[index].value1.text = rewardText
		self._ui.UpgradeDescs[index].value2.gameObject:SetActive(false)
		self._ui.UpgradeDescs[index].arrow:SetActive(false)
		index = index + 1
	end

	for idx = index, #self._ui.UpgradeDescs do
		local item = self._ui.UpgradeDescs[idx].item
		item:SetActive(false)
	end

	self._ui.UpgradeDescTable:Reposition()
end

function WorkShopUpgradeCtrl:OnItemNumChanged(itemId, changeNum)
	self:ConstructUpgradeItems()
end

function WorkShopUpgradeCtrl:OnMoneyChanged(itemType)
	if itemType == ItemType.Gold then
		self:ConstructUpgradeItems()
	end
end

-- on clicked
function WorkShopUpgradeCtrl:OnClicked(go)

	if go == self._ui.Blocker then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
	elseif go == self._ui.ButtonConfirm then
		SoundSystem.PlayCharacterUpgradeSound()
		NetManager.Send("WorkShopUpLevel", {WorkShopId = self._workShopId}, WorkShopUpgradeCtrl.OnHandleProto, self)
	elseif Helper.StartWith(go.name, "UpgradeItem_") then
		SoundSystem.PlayUIClickSound()
		local names = Helper.StringSplit(go.name)
		local idx = tonumber(names[2])
		local level = GameData.GetWorkShopLevel(self._workShopId)
		local needItems = ConfigUtils.GetWorkShopUpgradeItems(self._workShopId, level)
		local itemId = needItems[idx].Value
		CtrlManager.ShowItemDetail({itemId = itemId})
	end

	return true
end

function WorkShopUpgradeCtrl:OnHandleProto(proto, data, requestData)
	if proto == "WorkShopUpLevel" then
		local workShopId = requestData.WorkShopId
		local preLevel = GameData.GetWorkShopLevel(workShopId)
		-- consume items
		local upgradeItems = ConfigUtils.GetWorkShopUpgradeItems(workShopId, preLevel)
		for idx = 1, #upgradeItems do
			local itemId = upgradeItems[idx].Value
			local itemNum = upgradeItems[idx].Num
			GameData.ConsumeItem(itemId, itemNum)
		end
		GameData.SetDataOfWorkShop(data.WorkShopStatus)
		GameNotifier.Notify(GameEvent.WorkShopLevelChanged, workShopId)
		GameNotifier.Notify(GameEvent.WorkShopListChanged)
		GameData.SyncTutorialData()

		local rewardList = data.RewardList or {}
		local dropMap = {}
		for idx = 1, #rewardList do
			local dropId = rewardList[idx].Value
			local dropNum = rewardList[idx].Num
			if dropNum > 0 then
				local preNum = dropMap[dropId] or 0
				dropMap[dropId] = preNum + dropNum
			end
		end

		local finalRewards = {}
		for k, v in pairs(dropMap) do
			GameData.CollectItem(k, v)
			table.insert(finalRewards, {Value = k, Num = v})
		end

		CtrlManager.PopPanel()
		if #finalRewards > 0 then
			CtrlManager.OpenPanel(CtrlNames.WorkShopResult, {rewards = finalRewards, upgrade = true})
		else
			-- in work shop result, it also will trigger this
			GameData.CheckAndHintGoalsOfCurrentCountType()
		end
	end
end
-------------------------------------------------------------------------------------------
-- tutorial
function WorkShopUpgradeCtrl:CheckTutorial()
	local tutorials = {}

	if GameData.IsTutorialNotFinished(Tutorials.Tutorial_7_4) and GameData.IsGoalRunning(TutorialConstData.WorkShopUpgradeGoal) then
		local position = self._ui.Camera:WorldToScreenPoint(self._ui.PositionMark.position)
		tutorials[1] = {event = Tutorials.Tutorial_7_3, position = position, sender = self}
		position = self._ui.Camera:WorldToScreenPoint(self._ui.ButtonConfirm.transform.position)
		tutorials[2] = {event = Tutorials.Tutorial_7_4, position = position, sender = self}
	end

	if #tutorials > 0 then
		CtrlManager.ShowTutorials(tutorials)
	end

	return #tutorials > 0
end

function WorkShopUpgradeCtrl:OnTutorialClicked(tutorial)
	if tutorial == Tutorials.Tutorial_7_4 then
		self:OnClicked(self._ui.ButtonConfirm)
	else
		SoundSystem.PlayUIClickSound()
	end
end
-------------------------------------------------------------------------------------------
