require "FreakPlanet/View/SpaceTravelLaboratoryPanel"

local class = require "FreakPlanet/Utils/middleclass"
SpaceTravelLaboratoryCtrl  = class(CtrlNames.SpaceTravelLaboratory, BaseCtrl)

-- load the ui prefab
function SpaceTravelLaboratoryCtrl:LoadPanel()
	self:CreatePanel("SpaceTravelLaboratory")
end

-- construct ui panel data
function SpaceTravelLaboratoryCtrl:ConstructUI(obj)
	self._ui = SpaceTravelLaboratoryPanel.Init(obj)
end

-- destroy implementation
function SpaceTravelLaboratoryCtrl:DestroyImpl()
    GameNotifier.RemoveListener(GameEvent.SpaceTravelGoodsChanged, SpaceTravelLaboratoryCtrl.OnSpaceTravelGoodsChanged, self)
end

-- notity it has been focused
function SpaceTravelLaboratoryCtrl:NotifyFocus()
    if self._goodsDirty then
        self:OnSelectedRecipeChanged()
        self._goodsDirty = false
    end
end

-- fill ui with the data
function SpaceTravelLaboratoryCtrl:SetupUI()
    self._seasonId = self._parameter.seasonId
    local seasonData = GameData.GetSpaceTravelSeasonData(self._seasonId)
    self._storageSlot = ConfigUtils.GetSpaceShipStorageSlot(seasonData.ship)
    -- press
    self._isPressing = false
    self._pressingSign = 0
    self._pressingTime = 0
    self._floatNum = 0
    self._goodsDirty = false
    -- default hide
    self._ui.UpgradePanel:SetActive(false)

    self._sortType = LabRecipeSubType.Object
    self:OnSortTypeChanged()
	
    CtrlManager.AddClick(self, self._ui.Blocker)
    CtrlManager.AddClick(self, self._ui.ButtonConfirm)
    CtrlManager.AddClick(self, self._ui.ButtonUpgrade)
    CtrlManager.AddClick(self, self._ui.ButtonMinus)
    CtrlManager.AddClick(self, self._ui.ButtonPlus)
    CtrlManager.AddClick(self, self._ui.ButtonMax)
    CtrlManager.AddClick(self, self._ui.ButtonObjectRecipe)
    CtrlManager.AddClick(self, self._ui.ButtonSupplyRecipe)
    CtrlManager.AddClick(self, self._ui.ButtonArtworkRecipe)
    CtrlManager.AddPress(self, self._ui.ButtonMinus)
    CtrlManager.AddPress(self, self._ui.ButtonPlus)
    -- upgrade
    CtrlManager.AddClick(self, self._ui.ButtonUpgradeConfirm)
    CtrlManager.AddClick(self, self._ui.UpgradeBlocker)

    GameNotifier.AddListener(GameEvent.SpaceTravelGoodsChanged, SpaceTravelLaboratoryCtrl.OnSpaceTravelGoodsChanged, self)
end

function SpaceTravelLaboratoryCtrl:OnSortTypeChanged()
    self:OnLabLevelChanged()

    self:SetButtonState(self._ui.ButtonObjectRecipe, self._sortType ~= LabRecipeSubType.Object)
    self:SetButtonState(self._ui.ButtonSupplyRecipe, self._sortType ~= LabRecipeSubType.Supply)
    self:SetButtonState(self._ui.ButtonArtworkRecipe, self._sortType ~= LabRecipeSubType.Artwork)
end

function SpaceTravelLaboratoryCtrl:SetButtonState(go, enable)
    go:GetComponent("UIButton").isEnabled = enable
end

-- update implementation
function SpaceTravelLaboratoryCtrl:UpdateImpl(deltaTime)
    if  self._isPressing then
        local step = math.ceil(self._maxNumWhenPress / 5)
        step = math.max(step, 10)
        self._pressingTime = self._pressingTime + deltaTime
        self._floatNum = self._floatNum + deltaTime * step * math.ceil(self._pressingTime) * self._pressingSign
        self._selectedNum = math.floor(self._floatNum)
        if self._pressingSign > 0 then
            self._selectedNum = math.min(self._maxNumWhenPress, self._selectedNum)
            self._selectedNum = math.max(1, self._selectedNum)
        else
            self._selectedNum = math.max(1, self._selectedNum)
        end
        self:OnSelectedRecipeNumChanged()
    end
end

function SpaceTravelLaboratoryCtrl:OnLabLevelChanged()
    local seasonData = GameData.GetSpaceTravelSeasonData(self._seasonId)
    self._labId = seasonData.lab
    self._labLevel = seasonData.labLevel
    self._ui.LabBG.spriteName = ConfigUtils.GetSpaceTravelLabBG(self._labId, self._labLevel)
    self._recipeList = ConfigUtils.GetSpaceTravelLabRecipesAtLevel(self._labId, self._labLevel, self._sortType)
    if (self._selectedRecipe == nil and #self._recipeList > 0) or 
        (self._selectedRecipe ~= nil and not Helper.TableContains(self._recipeList, self._selectedRecipe)) then
        if #self._recipeList > 0 then
            self._selectedRecipe = self._recipeList[1]
        else
            self._selectedRecipe = nil
        end
        -- force to refresh
        self._goodsDirty = true
    end
    -- goods number changed
    if self._goodsDirty then
        self:OnSelectedRecipeChanged()
        self._goodsDirty = false
    end
    -- recipes
    self:ConstructRecipeGrid()
end

function SpaceTravelLaboratoryCtrl:ConstructRecipeGrid()
    local childNum = self._ui.RecipeGrid.childCount
    for idx = childNum, 1, -1 do
        local item = self._ui.RecipeGrid:GetChild(idx - 1)
        item.parent = self._ui.RecipePool
    end

    for idx = 1, #self._recipeList do
        local recipeId = self._recipeList[idx]
        local recipeItem = nil
        if self._ui.RecipePool.childCount == 0 then
            local recipeObj = Helper.NewObject(self._ui.RecipeItemTemplate, self._ui.RecipeGrid)
            CtrlManager.AddClick(self, recipeObj)
            CtrlManager.AddPress(self, recipeObj)
            recipeItem = recipeObj.transform
        else
            recipeItem = self._ui.RecipePool:GetChild(0)
            recipeItem.parent = self._ui.RecipeGrid
            recipeItem.localScale = Vector3.one
        end

        recipeItem.gameObject:SetActive(true)
        recipeItem.gameObject.name = tostring(recipeId)

        self:ConstructRecipeItem(recipeItem, recipeId)
    end

    self._ui.RecipeGrid:GetComponent("UIGrid"):Reposition()
end

function SpaceTravelLaboratoryCtrl:ConstructRecipeItem(item, recipeId)
    -- icon
    local icon = item:Find("Icon"):GetComponent("UISprite")
    UIHelper.SetItemIcon(self,icon, recipeId)
    -- num
    local numLabel = item:Find("Num"):GetComponent("UILabel")
    numLabel.text = ""
    -- selected
    local selected = (recipeId == self._selectedRecipe)
    self:ToggleSelectedMark(item, selected)
end

function SpaceTravelLaboratoryCtrl:ToggleSelectedMark(item, selected)
    local selectedMark = item:Find("Select").gameObject
    selectedMark:SetActive(selected)
end

function SpaceTravelLaboratoryCtrl:OnSelectedRecipeChanged()
    -- reset default state
    for idx = 1, #self._ui.ConsumeGoodsItems do
        local item = self._ui.ConsumeGoodsItems[idx].item
        item:SetActive(false)
    end

    self._selectedNum = 1
    self._ui.SelectedRecipe:SetActive(self._selectedRecipe ~= nil)
    self._ui.RecipeHint:SetActive(false)
    if self._selectedRecipe ~= nil then
        -- icon
        UIHelper.SetItemIcon(self,self._ui.SelectedRecipeIcon, self._selectedRecipe)
        -- num
        self:OnSelectedRecipeNumChanged()

        local recipeItem = self._ui.RecipeGrid:Find(self._selectedRecipe)
        if recipeItem ~= nil then
            self:ToggleSelectedMark(recipeItem, true)
        end
    end
end

function SpaceTravelLaboratoryCtrl:OnSelectedRecipeNumChanged()
    -- num
    self._ui.SelectedRecipeNum.text = "x"..tostring(self._selectedNum)
    -- source items
    local sources = ConfigUtils.GetCraftSourceOfLabRecipe(self._selectedRecipe)
    for idx = 1, #self._ui.ConsumeGoodsItems do
        local hasSource = (idx <= #sources)
        local item = self._ui.ConsumeGoodsItems[idx].item
        item:SetActive(hasSource)
        if hasSource then
            local icon = self._ui.ConsumeGoodsItems[idx].icon
            local ownNumLabel = self._ui.ConsumeGoodsItems[idx].ownNum
            local needNumLabel = self._ui.ConsumeGoodsItems[idx].needNum

            local goodsId = sources[idx].id
            local needNum = sources[idx].num * self._selectedNum
            local ownNum = GameData.GetSpaceTravelGoodsNum(self._seasonId, goodsId)

            UIHelper.SetItemIcon(self,icon, goodsId)
            ownNumLabel.text = tostring(ownNum)
            needNumLabel.text = tostring(needNum)

            if needNum > ownNum then
                ownNumLabel.color = Color.red
            else
                ownNumLabel.color = Color.white
            end
        end
    end
end

function SpaceTravelLaboratoryCtrl:IsGoodsEnough(count)
    local sources = ConfigUtils.GetCraftSourceOfLabRecipe(self._selectedRecipe)
    for idx = 1, #sources do
        local goodsId = sources[idx].id
        local needNum = sources[idx].num * count
        local ownNum = GameData.GetSpaceTravelGoodsNum(self._seasonId, goodsId)

        if ownNum < needNum then
            return false
        end
    end

    return true
end

function SpaceTravelLaboratoryCtrl:GetMaxNumCanCraft()
    local numbers = {}
    local sources = ConfigUtils.GetCraftSourceOfLabRecipe(self._selectedRecipe)
    for idx = 1, #sources do
        local goodsId = sources[idx].id
        local needNum = sources[idx].num
        local ownNum = GameData.GetSpaceTravelGoodsNum(self._seasonId, goodsId)
        numbers[idx] = math.floor(ownNum / needNum)
    end

    return math.min(unpack(numbers))
end
----------------------------------------------------------------------------------------
-- upgrade
function SpaceTravelLaboratoryCtrl:ConstructUpgradePanel()
    local unlockRecipes = ConfigUtils.GetSpaceTravelLabUnlockRecipesAtLevel(self._labId, self._labLevel)
    local consumeGoods = ConfigUtils.GetSpaceTravelUpgradeItemsAtLevel(self._labId, self._labLevel)
    -- unlock recipes
    local preCount =self._ui.UpgradeUnlockRecipeGrid.childCount
    for idx = 1, preCount do
        local hasRecipe = (idx <= #unlockRecipes)
        local item = self._ui.UpgradeUnlockRecipeGrid:GetChild(idx - 1)
        item.gameObject:SetActive(hasRecipe)
        if hasRecipe then
            self:ConstructUpgradeRecipeItem(item, unlockRecipes[idx])
        end
    end
    -- exist item is not enough
    for idx = preCount + 1, #unlockRecipes do
        local itemObj = Helper.NewObject(self._ui.UpgradeRecipeItemTemplate, self._ui.UpgradeUnlockRecipeGrid)
        itemObj:SetActive(true)
        itemObj.name = tostring(unlockRecipes[idx])
        self:ConstructUpgradeRecipeItem(itemObj.transform, unlockRecipes[idx])
    end
    -- consume goods
    preCount = self._ui.UpgradeConsumeGoodsGrid.childCount
    for idx = 1, preCount do
        local hasGoods = (idx <= #consumeGoods)
        local item = self._ui.UpgradeConsumeGoodsGrid:GetChild(idx - 1)
        item.gameObject:SetActive(hasGoods)
        if hasGoods then
            local goodsId = consumeGoods[idx].Value
            local goodsNum = consumeGoods[idx].Num
            self:ConstructUpgradeConsumeGoodsItem(item, goodsId, goodsNum)
        end
    end

    for idx = preCount + 1, #consumeGoods do
        local goodsId = consumeGoods[idx].Value
        local goodsNum = consumeGoods[idx].Num
        local itemObj = Helper.NewObject(self._ui.UpgradeGoodsItemTemplate, self._ui.UpgradeConsumeGoodsGrid)
        itemObj:SetActive(true)
        itemObj.name = tostring(goodsId)
        self:ConstructUpgradeConsumeGoodsItem(itemObj.transform, goodsId, goodsNum)
    end

    self._ui.UpgradeUnlockRecipeGrid:GetComponent("UIGrid"):Reposition()
    self._ui.UpgradeConsumeGoodsGrid:GetComponent("UIGrid"):Reposition()
end

function SpaceTravelLaboratoryCtrl:ConstructUpgradeRecipeItem(item, recipeId)
    local icon = item:Find("Icon"):GetComponent("UISprite")
    UIHelper.SetItemIcon(self,icon, recipeId)
end

function SpaceTravelLaboratoryCtrl:ConstructUpgradeConsumeGoodsItem(item, goodsId, goodsNum)
    local icon = item:Find("Icon"):GetComponent("UISprite")
    local numLabel = item:Find("Num"):GetComponent("UILabel")
    local ownNum = GameData.GetSpaceTravelGoodsNum(self._seasonId, goodsId)

    UIHelper.SetItemIcon(self,icon, goodsId)
    numLabel.text = tostring(ownNum).."/"..tostring(goodsNum)
    if ownNum < goodsNum then
        numLabel.color = Color.red
    else
        numLabel.color = Color.white
    end
end

function SpaceTravelLaboratoryCtrl:IsUpgradeGoodsEnough()
    local consumeGoods = ConfigUtils.GetSpaceTravelUpgradeItemsAtLevel(self._labId, self._labLevel)
    for k, v in pairs(consumeGoods) do
        local needNum = v.Num
        local ownNum = GameData.GetSpaceTravelGoodsNum(self._seasonId, v.Value)
        if needNum > ownNum then
            return false
        end
    end

    return true
end

function SpaceTravelLaboratoryCtrl:OnSpaceTravelGoodsChanged(goodsId)
    self._goodsDirty = true
end
----------------------------------------------------------------------------------------
-- on pressed
function SpaceTravelLaboratoryCtrl:OnPressed(go, pressed, isLong)
    if pressed and isLong then
        if go == self._ui.ButtonMinus or go == self._ui.ButtonPlus then
            self._isPressing = true
            self._pressingTime = 0
            self._floatNum = self._selectedNum
            self._maxNumWhenPress = self:GetMaxNumCanCraft()
            if go == self._ui.ButtonPlus then
                self._pressingSign = 1
            else
                self._pressingSign = -1
            end
        elseif go.transform.parent == self._ui.RecipeGrid then
            SoundSystem.PlayUIClickSound()
            local recipeId = tonumber(go.name)
            CtrlManager.ShowItemDetail({itemId = recipeId})
        end
    elseif not pressed and self._isPressing then
        self._isPressing = false
    end
end

-- on clicked
function SpaceTravelLaboratoryCtrl:OnClicked(go)

    if go == self._ui.Blocker then
        SoundSystem.PlayUICancelSound()
        CtrlManager.PopPanel()
    elseif go == self._ui.ButtonConfirm then
        local isValid = CtrlManager.CheckSpaceTravelSeasonValid(self._seasonId, true)
        if not isValid then
            return true
        end

        if not ConfigUtils.IsValidItem(self._selectedRecipe) or self._selectedNum < 1 then
            SoundSystem.PlayWarningSound()
            CtrlManager.ShowMessageBox({message = SAFE_LOC("请先选择需要合成的物品"), single = true})
            return true
        end

        if not self:IsGoodsEnough(self._selectedNum) then
            SoundSystem.PlayWarningSound()
            CtrlManager.ShowMessageBox({message = SAFE_LOC("合成所需物品不足"), single = true})
            return true
        end

        SoundSystem.PlayUIClickSound()
        NetManager.Send('Craft', {STSeasonID = self._seasonId, LabRecipeId = self._selectedRecipe, CraftNum = self._selectedNum}, SpaceTravelLaboratoryCtrl.OnHandleProto, self)
    elseif go == self._ui.ButtonMinus then
        if self._selectedNum > 1 then
            self._selectedNum = self._selectedNum - 1
            self:OnSelectedRecipeNumChanged()
        else
            SoundSystem.PlayWarningSound()
        end
    elseif go == self._ui.ButtonPlus then
        local newNum = self._selectedNum + 1
        if self:IsGoodsEnough(newNum) then
            SoundSystem.PlayUIClickSound()
            self._selectedNum = newNum
            self:OnSelectedRecipeNumChanged()
        else
            SoundSystem.PlayWarningSound()
            self._ui.RecipeHint:SetActive(true)
            self._ui.RecipeHintAnimator:Play("ItemHint", 0, 0)
            self._ui.RecipeHintLabel.text = SAFE_LOC("合成物品不足")
        end
    elseif go == self._ui.ButtonMax then
        local maxNum = self:GetMaxNumCanCraft()
        if maxNum > self._selectedNum then
            SoundSystem.PlayUIClickSound()
            self._selectedNum = maxNum
            self:OnSelectedRecipeNumChanged()
        else
            SoundSystem.PlayWarningSound()
            self._ui.RecipeHint:SetActive(true)
            self._ui.RecipeHintAnimator:Play("ItemHint", 0, 0)
            self._ui.RecipeHintLabel.text = SAFE_LOC("数量已最大")
        end
    elseif go.transform.parent == self._ui.RecipeGrid then
        local recipeId = tonumber(go.name)
        if recipeId ~= self._selectedRecipe then
            SoundSystem.PlayUIClickSound()
            -- toggle the previous one
            if self._selectedRecipe ~= nil then
                local recipeItem = self._ui.RecipeGrid:Find(self._selectedRecipe)
                if recipeItem ~= nil then
                    self:ToggleSelectedMark(recipeItem, false)
                end
            end
            self._selectedRecipe = recipeId
            self:OnSelectedRecipeChanged()
        end
    elseif go == self._ui.ButtonUpgrade then
        SoundSystem.PlayUIClickSound()
        self:ConstructUpgradePanel()
        self._ui.UpgradePanel:SetActive(true)
    elseif go == self._ui.UpgradeBlocker then
        SoundSystem.PlayUIClickSound()
        self._ui.UpgradePanel:SetActive(false)
    elseif go == self._ui.ButtonObjectRecipe then
        SoundSystem.PlaySwitchSound()
        self._sortType = LabRecipeSubType.Object
        self:OnSortTypeChanged()
    elseif go == self._ui.ButtonSupplyRecipe then
        SoundSystem.PlaySwitchSound()
        self._sortType = LabRecipeSubType.Supply
        self:OnSortTypeChanged()
    elseif go == self._ui.ButtonArtworkRecipe then
        SoundSystem.PlaySwitchSound()
        self._sortType = LabRecipeSubType.Artwork
        self:OnSortTypeChanged()
    elseif go == self._ui.ButtonUpgradeConfirm then
        local isValid = CtrlManager.CheckSpaceTravelSeasonValid(self._seasonId, true)
        if not isValid then
            return true
        end
        
        if not self:IsUpgradeGoodsEnough() then
            SoundSystem.PlayWarningSound()
            CtrlManager.ShowMessageBox({message = SAFE_LOC("升级所需物品不足"), single = true})
            return true
        end

        SoundSystem.PlayUIClickSound()
        local seasonData = GameData.GetSpaceTravelSeasonData(self._seasonId)
        local scoreCapId = GameData.GetScoreCapOfSpaceTravelSeason(self._seasonId, seasonData.scoreCap)
        NetManager.Send('STLabUpgrade', {STSeasonID = self._seasonId, STScoreCapID = scoreCapId, LabId = self._labId}, SpaceTravelLaboratoryCtrl.OnHandleProto, self)
    end

	return true
end

function SpaceTravelLaboratoryCtrl:OnHandleProto(proto, data, requestData)
    if proto == 'Craft' then
        local seasonId = requestData.STSeasonID
        local recipeId = requestData.LabRecipeId
        local craftNum = requestData.CraftNum
        local craftSources = ConfigUtils.GetCraftSourceOfLabRecipe(recipeId)
        for idx = 1, #craftSources do
            local goodsId = craftSources[idx].id
            local goodsNum = craftSources[idx].num * craftNum
            GameData.ConsumeSpaceTravelGoods(seasonId, goodsId, goodsNum)
        end
        -- goal
        local goalData = GameData.SetupItemGoalData(recipeId, 1)
        GameData.DoSpaceTravelGoalSettle(seasonId, TriggerType.Craft, {goalData})
        -- craft goods
        local craftGoods = data.EarnGoods or {}
        local parameter = GameData.ConstructSpaceTravelChoiceResultParameter(seasonId, craftGoods, {Score = data.Score})
        CtrlManager.OpenPanel(CtrlNames.SpaceTravelChoiceResult, parameter)
    elseif proto == 'STLabUpgrade' then
        local seasonId = requestData.STSeasonID
        local labId = requestData.LabId
        -- update level
        local seasonData = GameData.GetSpaceTravelSeasonData(seasonId)
        seasonData.labLevel = data.LabLevel
        -- consume goods
        local preLevel = data.LabLevel - 1
        local consumeGoods = ConfigUtils.GetSpaceTravelUpgradeItemsAtLevel(labId, preLevel)
        for k, v in pairs(consumeGoods) do
            GameData.ConsumeSpaceTravelGoods(seasonId, v.Value, v.Num)
        end
        -- update ui
        self:OnLabLevelChanged()
        self._ui.UpgradePanel:SetActive(false)
    end
end
