require "FreakPlanet/View/CharacterUpgradePanel"

local class = require "FreakPlanet/Utils/middleclass"
CharacterUpgradeCtrl  = class(CtrlNames.CharacterUpgrade, BaseCtrl)

local ABILITY_NORMAL_COLOR = Color.New(198 / 255, 190 / 255, 244 / 255, 1)
local PREVIEW_COLOR = Color.New(109 / 255, 1, 1, 1)

-- load the ui prefab
function CharacterUpgradeCtrl:LoadPanel()
	self:CreatePanel("CharacterUpgrade")
end

-- notity it has been focused
function CharacterUpgradeCtrl:NotifyFocus()
	
end

-- construct ui panel data
function CharacterUpgradeCtrl:ConstructUI(obj)
	self._ui = CharacterUpgradePanel.Init(obj)
end

function CharacterUpgradeCtrl:DestroyImpl()
	GameNotifier.RemoveListener(GameEvent.MoneyChanged, CharacterUpgradeCtrl.OnMoneyChanged, self)
end

-- fill ui with the data
function CharacterUpgradeCtrl:SetupUI()
	self._characterId = self._parameter.characterId
	self:OnCharacterChanged()

	CtrlManager.AddClick(self, self._ui.Blocker)
	CtrlManager.AddClick(self, self._ui.ButtonUpLevelMax)
	CtrlManager.AddClick(self, self._ui.ButtonUpLevel)
	CtrlManager.AddClick(self, self._ui.ButtonUpStage)
	CtrlManager.AddClick(self, self._ui.ButtonDetail)
	CtrlManager.AddClick(self, self._ui.ButtonNext)
	CtrlManager.AddClick(self, self._ui.ButtonPrev)
	CtrlManager.AddClick(self, self._ui.UpStageItemRoot.gameObject)

	local hasCallback = (self._parameter.callback ~= nil)
	self._ui.ButtonNext:SetActive(hasCallback)
	self._ui.ButtonPrev:SetActive(hasCallback)

	-- ability item
	for k, v in pairs(self._ui.CharacterAbilites) do
		CtrlManager.AddPress(self, v.item)
	end
	-- preview
	CtrlManager.AddPress(self, self._ui.ButtonPreviewNext)
	CtrlManager.AddPress(self, self._ui.ButtonPreviewMax)
	GameNotifier.AddListener(GameEvent.MoneyChanged, CharacterUpgradeCtrl.OnMoneyChanged, self)

	self:CheckTutorial()
end

function CharacterUpgradeCtrl:OnCharacterChanged()
	local characterId = self._characterId
	local characterLevel = GameData.GetCharacterLevel(characterId)

	UIHelper.SetCharacterIcon(self, self._ui.CharacterIcon, characterId)
	self._ui.CharacterName.text = ConfigUtils.GetCharacterName(characterId)
	self._ui.CharacterLevel.text = string.format(SAFE_LOC('loc_SimpleLevel'), characterLevel)
	self._ui.CharacterDesc.text = ConfigUtils.GetCharacterDesc(characterId)
	self._ui.CharacterBG.spriteName = UIHelper.GetBorderAndBgByItemId(characterId)
	local elementId = ConfigUtils.GetCharacterElement(characterId)
	local style = ConfigUtils.GetCharacterStyle(characterId)
	self._ui.CharacterElement.spriteName = ConfigUtils.GetElementIconWithStyle(elementId)
	self._ui.CharacterStyle.spriteName = ConfigUtils.GetStyleIcon(style)
	self._ui.CharacterStyle.color = ConfigUtils.GetStyleIconColor(elementId)
	self._abilityList = GameData.GetCharacterAbilityList(characterId)
	-- abilities
	self:ConstructAbilities()
	-- upgrade
	self:ConstructUpgrade()
	-- skills
	self:ConstructSkills()

	self._ui.CharacterAbilityHintRoot:SetActive(false)
	self._ui.LevelUpEffectAnimator.gameObject:SetActive(false)
	self._ui.StageUpEffectAnimator.gameObject:SetActive(false)
end

function CharacterUpgradeCtrl:OnMoneyChanged(itemType)
	if itemType ~= ItemType.Gold then
		return
	end

	self:ConstructUpgrade()
end

function CharacterUpgradeCtrl:ConstructAbilities()
	local power = 0
	for idx = 1, #self._ui.CharacterAbilites do
		local valueLabel = self._ui.CharacterAbilites[idx].value
		local icon = self._ui.CharacterAbilites[idx].icon

		local abilityId = self._abilityList[idx].id
		local abilityValue = self._abilityList[idx].value

		valueLabel.text = tostring(abilityValue)
		icon.spriteName = ConfigUtils.GetAbilityIcon(abilityId)
		
		power = power + ConfigUtils.GetAbilityPowerFactor(abilityId) * abilityValue
	end

	self._ui.CharacterPower.text = tostring(power)
end

function CharacterUpgradeCtrl:ConstructUpgrade()
	local characterId = self._characterId
	local curStage = GameData.GetCharacterCurrentStage(characterId)
	local curLevel = GameData.GetCharacterLevel(characterId)
	local stageLevelLimit = ConfigUtils.GetCharacterLevelLimitAtStage(characterId, curStage)
	local stageLimit = ConfigUtils.GetCharacterStageLimit(characterId)
	local levelLimit = ConfigUtils.GetCharacterMaxLevel(characterId)

	self._upLevelCostEnough = true
	self._upLevelMaxCostEnough = true
	self._upStageCostEnough = true

	local isFull = (curLevel >= levelLimit)
	if isFull then
		self._ui.ButtonUpLevelMax:SetActive(false)
		self._ui.ButtonUpLevel:SetActive(false)
		self._ui.ButtonUpStage:SetActive(false)
	else
		local isStageFull = (curLevel >= stageLevelLimit)
		self._ui.ButtonUpLevelMax:SetActive(not isStageFull)
		self._ui.ButtonUpLevel:SetActive(not isStageFull)
		self._ui.ButtonUpStage:SetActive(isStageFull)

		if isStageFull then
			self._ui.UpStageHint:SetActive(false)
			local upStageGoodsId, upStageGoodsNum = ConfigUtils.GetCharacterUpStageCost(characterId, curStage)
			local goodsCurNum = GameData.GetItemNum(upStageGoodsId)
			local costLabel = self._ui.UpStageItemRoot:Find("Cost"):GetComponent("UILabel")
			local costIcon = self._ui.UpStageItemRoot:Find("Icon"):GetComponent("UISprite")
			UIHelper.SetItemIcon(self,costIcon, upStageGoodsId)
			if goodsCurNum < upStageGoodsNum then
				costLabel.text = "[FF0000FF]"..tostring(goodsCurNum).."[-][FFFFFFFF]/"..tostring(upStageGoodsNum).."[-]"
				self._upStageCostEnough = false
			else
				costLabel.text = "[FFFFFFFF]"..tostring(goodsCurNum).."/"..tostring(upStageGoodsNum).."[-]"
			end
		else
			local upgradeCostSkills = GameData.GetGroupSkillMap({characterId}, nil, {effectAttribute = EffectAttribute.CharacterLevelUpCost})
			local costAddPercent = GameData.GetSkillAddPercentValue(upgradeCostSkills)
			costAddPercent = Helper.Round(costAddPercent, 2)
			local upCost = ConfigUtils.GetLevelUpCostByLevel(characterId, curLevel)
			upCost = Helper.RoundAndCeil(upCost * (1 + costAddPercent))
			upCost = math.max(upCost, 1)
			local upMaxCost = ConfigUtils.GetLevelUpCostByLevel(characterId, curLevel, stageLevelLimit)
			upMaxCost = Helper.RoundAndCeil(upMaxCost * (1 + costAddPercent))
			upMaxCost = math.max(upMaxCost, 1)

			self._ui.UpLevelCost.text = tostring(upCost)
			self._ui.UpLevelMaxCost.text = tostring(upMaxCost)

			local curGold = GameData.GetMoney(ItemType.Gold)
			if curGold < upCost then
				self._ui.UpLevelCost.color = Color.red
				self._upLevelCostEnough = false
			else
				self._ui.UpLevelCost.color = Color.white
			end

			if curGold < upMaxCost then
				self._ui.UpLevelMaxCost.color = Color.red
				self._upLevelMaxCostEnough = false
			else
				self._ui.UpLevelMaxCost.color = Color.white
			end
		end
	end
end

function CharacterUpgradeCtrl:ConstructSkills()
    local characterId = self._characterId
    local hasSkill = ConfigUtils.IsCharacterHasSkill(characterId)
    self._ui.SkillRoot:SetActive(hasSkill)

    if hasSkill then
    	local curStage = GameData.GetCharacterCurrentStage(characterId)
    	local stageLimit = ConfigUtils.GetCharacterStageLimit(characterId)
        local activatedSkillDesc = ConfigUtils.GetCharacterSkillDescAt(characterId, curStage)
        local skillActivated = (activatedSkillDesc ~= nil)

        if skillActivated then
            local skillText = "[A796FFFF]"..activatedSkillDesc.."[-] [48FF00FF]"..SAFE_LOC("loc_Activated").."[-]"
            self._ui.SkillDesc.text = skillText
            if curStage < stageLimit then
            	self._ui.SkillTips.text = SAFE_LOC("loc_CharacterStageUp_2")
            else
            	self._ui.SkillTips.text = SAFE_LOC("loc_CharacterStageUp_3")
            end
        else
            local nextActivatedSkillDesc = ConfigUtils.GetCharacterNextSkillDescAt(characterId, curStage)
            local skillText = "[7E65A1FF]"..nextActivatedSkillDesc.."[-] [FF0000FF]"..SAFE_LOC("loc_NotActivated").."[-]"
            self._ui.SkillDesc.text = skillText
            self._ui.SkillTips.text = SAFE_LOC("loc_CharacterStageUp_1")
        end
    end
end

function CharacterUpgradeCtrl:ConstructPreviewAbilities(isMax)
	local characterId = self._characterId
	local curLevel = GameData.GetCharacterLevel(characterId)
	local curStage = GameData.GetCharacterCurrentStage(characterId)
	local stageLevelLimit = ConfigUtils.GetCharacterLevelLimitAtStage(characterId, curStage)

	local previewLevel = curLevel + 1
	if isMax then
		previewLevel = stageLevelLimit
	end

	local abilityMap = GameData.GetCharacterAbilityMapAtLevel(characterId, previewLevel)

	local power = 0
	for idx = 1, #self._ui.CharacterAbilites do
		local valueLabel = self._ui.CharacterAbilites[idx].value
		local abilityId = self._abilityList[idx].id
		local abilityValue = abilityMap[abilityId] or 0

		valueLabel.text = tostring(abilityValue)
		valueLabel.color = PREVIEW_COLOR
		
		power = power + ConfigUtils.GetAbilityPowerFactor(abilityId) * abilityValue
	end

	self._ui.CharacterPower.text = tostring(power)
	self._ui.CharacterLevel.text = string.format(SAFE_LOC('loc_SimpleLevel'), previewLevel)

	self._ui.CharacterPower.color = PREVIEW_COLOR
	self._ui.CharacterLevel.color = PREVIEW_COLOR
end

function CharacterUpgradeCtrl:RestoreFromPreview()
	local power = 0
	for idx = 1, #self._ui.CharacterAbilites do
		local valueLabel = self._ui.CharacterAbilites[idx].value
		local abilityId = self._abilityList[idx].id
		local abilityValue = self._abilityList[idx].value

		valueLabel.text = tostring(abilityValue)
		valueLabel.color = ABILITY_NORMAL_COLOR
		
		power = power + ConfigUtils.GetAbilityPowerFactor(abilityId) * abilityValue
	end

	self._ui.CharacterPower.text = tostring(power)

	-- restore character level
	local characterId = self._characterId
	local characterLevel = GameData.GetCharacterLevel(characterId)
	self._ui.CharacterLevel.text = string.format(SAFE_LOC('loc_SimpleLevel'), characterLevel)

	self._ui.CharacterPower.color = self._ui.PowerColor
	self._ui.CharacterLevel.color = self._ui.LevelColor
end

function CharacterUpgradeCtrl:HandleUpgradeMax()
	SoundSystem.PlayCharacterUpgradeMaxSound()
	local characterId = self._characterId
	local curStage = GameData.GetCharacterCurrentStage(characterId)
	local curLevel = GameData.GetCharacterLevel(characterId)
	local stageLevelLimit = ConfigUtils.GetCharacterLevelLimitAtStage(characterId, curStage)
	local diffLevel = (stageLevelLimit - curLevel)
	NetManager.Send("UpLevel", {Char = characterId, CurLevel = curLevel, Levelup = diffLevel}, CharacterUpgradeCtrl.OnHandleProto, self)
end

-- on pressed
function CharacterUpgradeCtrl:OnPressed(go, pressed, isLong)
	if go.transform.parent == self._ui.CharacterAbilityRoot then
		if pressed then
			local names = Helper.StringSplit(go.name)
			assert(#names == 2, "invalid ability item name: "..tostring(go.name))
			local idx = tonumber(names[2])
			local abilityId = self._abilityList[idx].id
			self._ui.CharacterAbilityHintLabel.text = ConfigUtils.GetAbilityDesc(abilityId)
			local pos = self._ui.CharacterAbilityHintRoot.transform.parent:InverseTransformPoint(go.transform.position)
			self._ui.CharacterAbilityHintRoot.transform.localPosition = pos
			self._ui.CharacterAbilityHintRoot:SetActive(true)
		elseif not pressed then
			self._ui.CharacterAbilityHintRoot:SetActive(false)
		end
	elseif go == self._ui.ButtonPreviewNext or go == self._ui.ButtonPreviewMax then
		if pressed then
			self:ConstructPreviewAbilities(go == self._ui.ButtonPreviewMax)
		elseif not pressed then
			self:RestoreFromPreview()
		end
	end
end

-- on clicked
function CharacterUpgradeCtrl:OnClicked(go)
	if go == self._ui.Blocker then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
	elseif go == self._ui.ButtonUpLevelMax then
		if not self._upLevelMaxCostEnough then
			SoundSystem.PlayWarningSound()
			CtrlManager.ShowMessageBox({message = SAFE_LOC("升级金币不足"), single = true})
			return true
		end

		SoundSystem.PlayUIClickSound()
		local characterId = self._characterId
		local curStage = GameData.GetCharacterCurrentStage(characterId)
		local stageLevelLimit = ConfigUtils.GetCharacterLevelLimitAtStage(characterId, curStage)
		CtrlManager.ShowMessageBox({
            message = string.format(SAFE_LOC("是否一键升到%d级？"), stageLevelLimit),
            single = false, 
            onConfirm = CharacterUpgradeCtrl.HandleUpgradeMax, 
            receiver = self,
            muteSound = true,
        })
	elseif go == self._ui.ButtonUpLevel then
		if not self._upLevelCostEnough then
			SoundSystem.PlayWarningSound()
			CtrlManager.ShowMessageBox({message = SAFE_LOC("升级金币不足"), single = true})
			return true
		end

		SoundSystem.PlayCharacterUpgradeSound()
		local characterId = self._characterId
		local curLevel = GameData.GetCharacterLevel(characterId)
		local diffLevel = 1
		NetManager.Send("UpLevel", {Char = characterId, CurLevel = curLevel, Levelup = diffLevel}, CharacterUpgradeCtrl.OnHandleProto, self)
	elseif go == self._ui.ButtonUpStage then
		if not self._upStageCostEnough then
			SoundSystem.PlayWarningSound()
			CtrlManager.ShowMessageBox({message = SAFE_LOC("突破物品不足"), single = true})
			return true
		end

		SoundSystem.PlayCharacterUpStageSound()
		local characterId = self._characterId
		local curStage = GameData.GetCharacterCurrentStage(characterId)
		NetManager.Send("UpStage", {Char = characterId, CurStage = curStage}, CharacterUpgradeCtrl.OnHandleProto, self)
	elseif go == self._ui.ButtonDetail then
		SoundSystem.PlayUIClickSound()
		CtrlManager.OpenPanel(CtrlNames.CharacterAttributeGuide)
	elseif go == self._ui.UpStageItemRoot.gameObject then
		SoundSystem.PlayUIClickSound()
		local characterId = self._characterId
		local curStage = GameData.GetCharacterCurrentStage(characterId)
		local goodsId = ConfigUtils.GetCharacterUpStageCost(characterId, curStage)
		CtrlManager.ShowItemDetail({itemId = goodsId})
	elseif go == self._ui.ButtonNext then
		SoundSystem.PlayUIClickSound()
		local characterId = self._parameter.callback(self._parameter.receiver, self._characterId, true)
		if characterId ~= self._characterId then
			self._characterId = characterId
			self:OnCharacterChanged()
		end
	elseif go == self._ui.ButtonPrev then
		SoundSystem.PlayUIClickSound()
		local characterId = self._parameter.callback(self._parameter.receiver, self._characterId, false)
		if characterId ~= self._characterId then
			self._characterId = characterId
			self:OnCharacterChanged()
		end
	end

	return true
end

function CharacterUpgradeCtrl:OnHandleProto(proto, data, requestData)
	if proto == "UpStage" then
		local characterId = requestData.Char
		local curStage = GameData.GetCharacterCurrentStage(characterId)
		GameData.SetCharacterStage(characterId, curStage + 1)

		local upStageGoodsId, upStageGoodsNum = ConfigUtils.GetCharacterUpStageCost(characterId, curStage)
		GameData.ConsumeItem(upStageGoodsId, upStageGoodsNum)

		local goldNum = data.RemainGold
		local diamondNum = data.RemainDiamond
		GameData.SetMoney(ItemType.Gold, goldNum)
		GameData.SetMoney(ItemType.Diamond, diamondNum)
		GameData.CheckAndHintGoalsOfCurrentCountType()

		-- update ui
		local preAbilityList = self._abilityList
		self._abilityList = GameData.GetCharacterAbilityList(characterId) 
		self:ConstructAbilities()
		self:ConstructUpgrade()
		self:ConstructSkills()

		self._ui.StageUpEffectAnimator.gameObject:SetActive(true)
		self._ui.StageUpEffectAnimator:Play("PromoteEffect", 0, 0)

		self:CheckLevelUpEffect(preAbilityList)
	elseif proto == "UpLevel" then
		local characterId = requestData.Char
		local curLevel = requestData.CurLevel
		local upLevel = requestData.Levelup
		local newLevel = curLevel + upLevel
		GameData.SetCharacterLevel(characterId, newLevel)

		local goldNum = data.RemainGold
		local diamondNum = data.RemainDiamond
		GameData.SetMoney(ItemType.Gold, goldNum)
		GameData.SetMoney(ItemType.Diamond, diamondNum)
		GameData.CheckAndHintGoalsOfCurrentCountType()
		GameData.SyncTutorialData()

		self._ui.CharacterLevel.text = string.format(SAFE_LOC('loc_SimpleLevel'), newLevel)
		local preAbilityList = self._abilityList
		self._abilityList = GameData.GetCharacterAbilityList(characterId) 
		self:ConstructAbilities()
		self:ConstructUpgrade()

		self:CheckLevelUpEffect(preAbilityList)
	end
end

function CharacterUpgradeCtrl:CheckLevelUpEffect(preAbilityList)
	local dirty = false
	for idx = 1, #self._abilityList do
		local preValue = preAbilityList[idx].value
		local newValue = self._abilityList[idx].value

		local diff = newValue - preValue
		if diff ~= 0 then
			dirty = true
			local text = tostring(diff)
			if diff > 0 then
				text = "+"..text
			end
			self._ui.CharacterAbilites[idx].upValue.text = text
		else
			self._ui.CharacterAbilites[idx].upValue.text = ""
		end
	end

	if dirty then
		self._ui.LevelUpEffectAnimator.gameObject:SetActive(true)
		self._ui.LevelUpEffectAnimator:Play("LevelUpEffect", 0, 0)
	end
end
--------------------------------------------------------
-- tutorial
function CharacterUpgradeCtrl:CheckTutorial()
    local tutorials = {}

    if GameData.IsTutorialNotFinished(Tutorials.Tutorial_3_2) then
        local position = self._ui.Camera:WorldToScreenPoint(self._ui.ButtonUpLevel.transform.position)
        tutorials[1] = {event = Tutorials.Tutorial_3_2, position = position, sender = self}
    end

    if #tutorials > 0 then
        CtrlManager.ShowTutorials(tutorials)
    end

    return #tutorials > 0
end

function CharacterUpgradeCtrl:OnTutorialClicked(tutorial)
    if tutorial == Tutorials.Tutorial_3_2 then
        self:OnClicked(self._ui.ButtonUpLevel)
    end
end
--------------------------------------------------------