require "FreakPlanet/View/ActivityGoalPanel"

local class = require "FreakPlanet/Utils/middleclass"
ActivityGoalCtrl  = class(CtrlNames.ActivityGoal, BaseCtrl)

--------------------------------------------------
-- load the ui prefab
function ActivityGoalCtrl:LoadPanel()
	self:CreatePanel("ActivityGoal")
end

-- construct ui panel data
function ActivityGoalCtrl:ConstructUI(obj)
	self._ui = ActivityGoalPanel.Init(obj)
end

-- notity it has been focused
function ActivityGoalCtrl:NotifyFocus()
    -- number of need item may changed
    if self._selectedDemandIndex ~= nil then
        self:OnSelectedDemandChanged()
    end
    -- refresh demand hint
    self:RefreshAllDemandItemsHint()
    -- refresh goal data
    self:RefreshGoalData()
end

-- destructor 
function ActivityGoalCtrl:DestroyImpl() 
    GameNotifier.RemoveListener(GameEvent.GoalChanged, ActivityGoalCtrl.OnGoalChanged, self)
    GameNotifier.RemoveListener(GameEvent.DemandChanged, ActivityGoalCtrl.OnDemandChanged, self)
end

--上一次打开的时间
local _LastRequstTimestamp = 0
-- fill ui with the data
function ActivityGoalCtrl:SetupUI()
    self._selectedDemandIndex = nil
    self._updateDemandItems = {}
    self._currentActivityData = {}
    local needUpdateActivityDemandList = false
    local activityId = GameData.GetValidActivityId()
    if activityId ~= nil then
        local activityInfo = GameData.GetActivityInfo(activityId)
        self._currentActivityData.id = activityId
        self._currentActivityData.startTime = activityInfo.startTime
        self._currentActivityData.endTime = activityInfo.endTime
        self._currentActivityData.poolId = activityInfo.poolId
        self._currentActivityData.goal = GameData.GetCurrentActivityGoalOfPool(activityInfo.poolId)
        -- check demand data
        local demandListData = GameData.GetTimeLimitedDemandList()
        if demandListData.activityId ~= activityId or self:IsNeedRequestDemandList(_LastRequstTimestamp) then
            needUpdateActivityDemandList = true
        else
            self._currentActivityData.demandList = demandListData.demandList or {}
        end
    end

    -- default
    self._ui.LeftTime.text = ""

    -- check to update demand list or not
    if needUpdateActivityDemandList then
        NetManager.Send("ActivityDemandList", {}, ActivityGoalCtrl.OnHandleProto, self)
        _LastRequstTimestamp = GameData.GetServerTime()
    else
        self:SetupGoal()
        self:SetupDemands()
        self:OnSelectedDemandChanged()
    end

    local buttonGoalGo = self._ui.GoalItem:Find("ButtonGo").gameObject
    local buttonGoalReward = self._ui.GoalItem:Find("ButtonReward").gameObject
    CtrlManager.AddClick(self, buttonGoalGo)
    CtrlManager.AddClick(self, buttonGoalReward)
	
    CtrlManager.AddClick(self, self._ui.Blocker)
    CtrlManager.AddClick(self, self._ui.ButtonDemandSubmit)
    CtrlManager.AddClick(self, self._ui.ButtonDemandGo)
    CtrlManager.AddClick(self, self._ui.ButtonDemandCancel)
    CtrlManager.AddClick(self, self._ui.DemandSelectionCollider)

    -- events
    GameNotifier.AddListener(GameEvent.GoalChanged, ActivityGoalCtrl.OnGoalChanged, self)
    GameNotifier.AddListener(GameEvent.DemandChanged, ActivityGoalCtrl.OnDemandChanged, self)
end

function ActivityGoalCtrl:SetupDemands()
    self._updateDemandItems = {}
    self._demandList = self._currentActivityData.demandList

    local demandGrid = self._ui.DemandGrid
    local existCount = demandGrid.childCount
    for idx = 1, #self._demandList do
        local item = nil
        if idx <= existCount then
            item = demandGrid:GetChild(idx - 1)
        else
            if self._ui.DemandItemPool.childCount == 0 then
                local itemObj = Helper.NewObject(self._ui.DemandItemTemplate, demandGrid)
                item = itemObj.transform
                CtrlManager.AddClick(self, itemObj)
            else
                item = self._ui.DemandItemPool:GetChild(0)
                item.parent = demandGrid
                item.localScale = Vector3.one
                item.localPosition = Vector3.zero
            end
        end

        item.gameObject:SetActive(true)
        item.name = tostring(idx)

        self:ConstructDemandItem(item, idx)
    end

    -- recycle the rest items
    existCount = demandGrid.childCount
    for idx = existCount, #self._demandList + 1, -1 do
        local item = demandGrid:GetChild(idx - 1)
        item.parent = self._ui.DemandItemPool
    end

    demandGrid:GetComponent("UIGrid"):Reposition()
end

function ActivityGoalCtrl:ConstructDemandItem(item, demandIndex)
    local curTime = GameData.GetServerTime()
    local activeTime = self._demandList[demandIndex].activateTime
    local isActivated = (curTime >= activeTime)
    local demandId = self._demandList[demandIndex].id

    local detailRoot = item:Find("Detail").gameObject
    local cooldownRoot = item:Find("Cooldown").gameObject

    local nameLabel = item:Find("Detail/Name"):GetComponent("UILabel")
    nameLabel.text = ConfigUtils.GetDemandName(demandId)
    -- num hint
    self:RefreshDemandItemHint(item, demandIndex)

    local rewardRoot = item:Find("Detail/Rewards")
    local demandRewards = self._demandList[demandIndex].rewardList
    for idx = 1, rewardRoot.childCount do
        local hasReward = (idx <= #demandRewards)
        local rewardItem = rewardRoot:GetChild(idx - 1)
        rewardItem.gameObject:SetActive(hasReward)
        if hasReward then
            local rewardItemId = demandRewards[idx].id
            local rewardItemNum = demandRewards[idx].num

            UIHelper.ConstructItemIconAndNum(self, rewardItem, rewardItemId)

            local numberLabel = rewardItem:Find("Num"):GetComponent("UILabel")
            numberLabel.text = tostring(rewardItemNum)
        end
    end

    detailRoot:SetActive(isActivated)
    cooldownRoot:SetActive(not isActivated)
    if not isActivated then
        local cooldownLabel = item:Find("Cooldown/Time"):GetComponent("UILabel")
        cooldownLabel.text = ""
        self._updateDemandItems[demandIndex] = {detail = detailRoot, cooldown = cooldownRoot, cooldownLabel = cooldownLabel}
    else
        self._updateDemandItems[demandIndex] = nil
    end

    self:ToggleDemandItemSelected(item, false)
end

function ActivityGoalCtrl:ToggleDemandItemSelected(item, show)
    local selectedMark = item:Find("Select").gameObject
    selectedMark:SetActive(show)
end

function ActivityGoalCtrl:ToggleDemandItemSelectedWithIndex(itemIndex, show)
    if itemIndex == nil then
        return
    end

    local item = self._ui.DemandGrid:Find(itemIndex)
    if item ~= nil then
        self:ToggleDemandItemSelected(item, show)
    end
end

function ActivityGoalCtrl:RefreshDemandCooldown(demandIndex)
    local curTime = GameData.GetServerTime()
    local activeTime = self._demandList[demandIndex].activateTime
    local leftTime = math.max(activeTime - curTime, 0)

    local k = self._updateDemandItems[demandIndex]
    k.cooldownLabel.text = Helper.FormatTime(leftTime)

    if leftTime == 0 then
        k.detail:SetActive(true)
        k.cooldown:SetActive(false)
    end

    return (leftTime == 0)
end

function ActivityGoalCtrl:OnSelectedDemandChanged()
    -- force to select the first one, if it has any
    if self._selectedDemandIndex == nil and #self._demandList > 0 then
        self._selectedDemandIndex = 1
    end

    self._ui.DemandSelectionRoot:SetActive(self._selectedDemandIndex ~= nil)

    if self._selectedDemandIndex ~= nil then
        local demandId = self._demandList[self._selectedDemandIndex].id
        local needItemId, needItemNum = ConfigUtils.GetDemandNeedItem(demandId)
        local ownItemNum = GameData.GetItemNum(needItemId)
        local isItemEnough = (ownItemNum >= needItemNum)

        local numText = ""
        if isItemEnough then
            numText = "[FFFFFFFF]"..tostring(ownItemNum).."/"..tostring(needItemNum).."[-]"
        else
            numText = "[FF0000FF]"..tostring(ownItemNum).."[-][FFFFFFFF]/"..tostring(needItemNum).."[-]"
        end

        local activeTime = self._demandList[self._selectedDemandIndex].activateTime
        local curTime = GameData.GetServerTime()
        local isActivated = (curTime >= activeTime)

        UIHelper.ConstructItemIconAndNum(self, self._ui.DemandSelectionRoot.transform, needItemId)
        self._ui.DemandSelectionDesc.text = ConfigUtils.GetDemandDesc(demandId)
        self._ui.ButtonDemandSubmit:SetActive(isActivated and isItemEnough)
        self._ui.ButtonDemandGo:SetActive(isActivated and not isItemEnough)
        self._ui.ButtonDemandCancel:SetActive(isActivated)
        self._ui.DemandSelectionNum.text = numText
    end

    self:ToggleDemandItemSelectedWithIndex(self._selectedDemandIndex, true)
end

function ActivityGoalCtrl:SetupGoal()
    local goalId = self._currentActivityData.goal
    self._ui.GoalEmpty:SetActive(goalId == nil)
    self._ui.GoalItem.gameObject:SetActive(goalId ~= nil)
    if goalId ~= nil then
        local goalItem = self._ui.GoalItem
        -- when on clicked, use name to get goal id
        goalItem.gameObject.name = tostring(goalId)

        local conditions = ConfigUtils.GetGoalConditions(goalId)
        assert(#conditions == 1, "activity goal condition should always be 1")
         -- title
        local goalTitle = goalItem:Find("GoalTitle"):GetComponent("UILabel")
        goalTitle.text = ConfigUtils.GetGoalName(goalId)
        -- name
        local nameLabel = goalItem:Find("Task/Name"):GetComponent("UILabel")
        nameLabel.text = UIHelper.GetGoalFinalName(conditions[1])
        -- icon
        UIHelper.ConstructGoalIcon(self, goalItem:Find("Task"), goalId, conditions[1])
        -- rewards
        local rewards = ConfigUtils.GetGoalActualRewards(goalId)
        local rewardRoot = goalItem:Find("RewardBG")
        for idx = 1, rewardRoot.childCount do
            local rewardItem = rewardRoot:GetChild(idx - 1)
            local hasReward = (idx <= #rewards)
            rewardItem.gameObject:SetActive(hasReward)
            if hasReward then
                local rewardItemId = rewards[idx].Value
                local rewardItemNum = rewards[idx].Num
                -- content
                local rewardLabel = rewardItem:Find("Content"):GetComponent("UILabel")
                rewardLabel.text = UIHelper.ConstructGoalRewardContent(rewardItemId, rewardItemNum)
                -- icon
                UIHelper.ConstructItemIconAndNum(self, rewardItem, rewardItemId, rewardItemNum)
            end
        end
        -- number related
        self:RefreshGoalData()
    end
end

function ActivityGoalCtrl:UpdateImpl(deltaTime)
    local toRemove = {}
    for k, v in pairs(self._updateDemandItems) do
        local cd = self:RefreshDemandCooldown(k)
        if cd then
            -- update button state
            if k == self._selectedDemandIndex then
                self:OnSelectedDemandChanged()
            end
            table.insert(toRemove, k)
        end
    end

    for idx = 1, #toRemove do
        self._updateDemandItems[toRemove[idx]] = nil
    end

    self:RefreshActivityLeftTime()
end

function ActivityGoalCtrl:RefreshActivityLeftTime()
    if self._currentActivityData.id ~= nil then
        local endTime = self._currentActivityData.endTime
        local curTime = GameData.GetServerTime()
        local leftTime = math.max(0, endTime - curTime)
        if leftTime == 0 then
            self._ui.LeftTime.text = SAFE_LOC("活动已结束")
        else
            self._ui.LeftTime.text = SAFE_LOC("活动剩余时间：")..Helper.GetLongTimeString(leftTime)
        end
    end
end

function ActivityGoalCtrl:HasGoto(goalId)
    local trigger = ConfigUtils.GetGoalTriggers(goalId)[1]
    if trigger == TriggerType.SubmitGoods then
        -- the first one
        local itemId = ConfigUtils.GetGoalConditions(goalId)[1].Value
        local sources = ConfigUtils.GetItemSource(itemId)
        if #sources == 0 then
            return false
        end
    end

    return true
end

function ActivityGoalCtrl:RefreshGoalData()
    if self._currentActivityData.goal ~= nil then
        local goalId = self._currentActivityData.goal
        local goalItem = self._ui.GoalItem

        local conditions = ConfigUtils.GetGoalConditions(goalId)
        local goalState, goalNumber = GameData.GetGoalInfo(goalId)

        local buttonGo = goalItem:Find("ButtonGo"):GetComponent("UIButton")
        local buttonReward = goalItem:Find("ButtonReward").gameObject
        local buttonRewardLabel = goalItem:Find("ButtonReward/Label"):GetComponent("UILabel")
        buttonGo.gameObject:SetActive(false)
        buttonReward:SetActive(goalState == GoalState.Complete)
        if goalState == GoalState.Complete then
            local isSubmitGoods = ConfigUtils.IsSubmitGoodsGoal(goalId)
            if isSubmitGoods then
                buttonRewardLabel.text = SAFE_LOC("loc_Submit")
            else
                buttonRewardLabel.text = SAFE_LOC("loc_Reward")
            end
        end

        if goalState == GoalState.Running then
            local hasGoto = self:HasGoto(goalId)
            buttonGo.gameObject:SetActive(hasGoto)
        end

        local completeMark = goalItem:Find("Mark/Complete").gameObject
        completeMark:SetActive(goalState == GoalState.Complete)

        local numberLabel = goalItem:Find("Task/Num"):GetComponent("UILabel")
        numberLabel.text = UIHelper.GetGoalShowNum(conditions[1], goalNumber[1])
    end
end

function ActivityGoalCtrl:CanProceed()
    if self._currentActivityData.id ~= nil then
        local startTime = self._currentActivityData.startTime
        local endTime = self._currentActivityData.endTime
        local curTime = GameData.GetServerTime()
        if curTime >= startTime and curTime < endTime then
            return true
        end
    end

    SoundSystem.PlayWarningSound()
    CtrlManager.ShowMessageBox({message = SAFE_LOC("活动已结束"), single = true})
    return false
end

function ActivityGoalCtrl:RefreshAllDemandItemsHint()
    for idx = 1, self._ui.DemandGrid.childCount do
        local item = self._ui.DemandGrid:GetChild(idx - 1)
        local demandIndex = tonumber(item.gameObject.name)
        self:RefreshDemandItemHint(item, demandIndex)
    end
end

function ActivityGoalCtrl:RefreshDemandItemHint(item, demandIndex)
    local demandId = self._demandList[demandIndex].id
    local needItemId, needItemNum = ConfigUtils.GetDemandNeedItem(demandId)
    local ownItemNum = GameData.GetItemNum(needItemId)
    local isItemEnough = (ownItemNum >= needItemNum)

    local hintMark = item:Find("Detail/Hint").gameObject
    hintMark:SetActive(isItemEnough)
end

function ActivityGoalCtrl:OnGoalChanged(goalType)
    if goalType == GoalType.Activity then
        if self._currentActivityData.id ~= nil then
            local newActivityGoal = GameData.GetCurrentActivityGoalOfPool(self._currentActivityData.poolId)
            if newActivityGoal ~= self._currentActivityData.goal then
                self._currentActivityData.goal = newActivityGoal
                self:SetupGoal()
            end
        end
    end
end

function ActivityGoalCtrl:OnDemandChanged(selectCustom)
    self:SetupDemands()
    if self._selectedDemandIndex ~= nil and self._selectedDemandIndex > #self._demandList then
        self._selectedDemandIndex = nil
    end
    self:OnSelectedDemandChanged()
end

-- on clicked
function ActivityGoalCtrl:OnClicked(go)

    if go == self._ui.Blocker then
        SoundSystem.PlayUICancelSound()
        CtrlManager.PopPanel()
    elseif go == self._ui.ButtonDemandSubmit then
        -- check activity
        if not self:CanProceed() then
            return true
        end

        local demandId = self._demandList[self._selectedDemandIndex].id
        local needItemId, needItemNum = ConfigUtils.GetDemandNeedItem(demandId)
        local ownItemNum = GameData.GetItemNum(needItemId)
        if ownItemNum < needItemNum then
            SoundSystem.PlayWarningSound()
            CtrlManager.ShowMessageBox({message = SAFE_LOC("物品数量不足"), single = true})
            return true
        end

        SoundSystem.PlayUIClickSound()
        local groupId = self._demandList[self._selectedDemandIndex].groupId
        local activityId = self._currentActivityData.id
        NetManager.Send("DemandSubmit", {
            ActivityId = activityId,
            DemandGroupID = groupId,
            DemandId = demandId, 
            DemandIndex = self._selectedDemandIndex,
            IsCustom = false,
        }, ActivityGoalCtrl.OnHandleProto, self)
    elseif go == self._ui.ButtonDemandCancel then
        -- check activity
        if not self:CanProceed() then
            return true
        end

        SoundSystem.PlayUIClickSound()
        local groupId = self._demandList[self._selectedDemandIndex].groupId
        local activityId = self._currentActivityData.id
        NetManager.Send("DemandCancel", {
            ActivityId = activityId,
            DemandGroupID = groupId,
            IsCustom = false,
        }, ActivityGoalCtrl.OnHandleProto, self)
    elseif go == self._ui.ButtonDemandGo then
        -- check activity
        if not self:CanProceed() then
            return true
        end

        local demandId = self._demandList[self._selectedDemandIndex].id
        local needItemId = ConfigUtils.GetDemandNeedItem(demandId)
        local ret = UIHelper.GetSourceCtrlByItemId(needItemId)
        if ret.code ~= RetCode.OK then
            SoundSystem.PlayWarningSound()
            local showMsg = UIHelper.GetReturnCodeShowText(ret.code)
            CtrlManager.ShowMessageBox({message = showMsg, single = true})
        else
            SoundSystem.PlayUIClickSound()
            JumpManager.JumpFromItemSource(ret)
        end
    elseif go.transform.parent == self._ui.DemandGrid then
        SoundSystem.PlayUIClickSound()
        local demandIndex = tonumber(go.name)
        if demandIndex ~= self._selectedDemandIndex then
            self:ToggleDemandItemSelectedWithIndex(self._selectedDemandIndex, false)
            self._selectedDemandIndex = demandIndex
            self:OnSelectedDemandChanged()
        end
    elseif go == self._ui.DemandSelectionCollider then
        if self._selectedDemandIndex ~= nil then
            SoundSystem.PlayUIClickSound()
            local demandId = self._demandList[self._selectedDemandIndex].id
            local needItemId = ConfigUtils.GetDemandNeedItem(demandId)
            CtrlManager.ShowItemDetail({itemId = needItemId})
        end
    elseif go.name == "ButtonGo" then
        -- check activity
        if not self:CanProceed() then
            return true
        end

        local goalId = tonumber(go.transform.parent.gameObject.name)
        local code = JumpManager.JumpFromActivityGoal(goalId)
        if code == RetCode.OK then
            SoundSystem.PlayUIClickSound()
        else
            SoundSystem.PlayWarningSound()
            local msg = UIHelper.GetReturnCodeShowText(code)
            CtrlManager.ShowMessageBox({message = msg, single = true})
        end
    elseif go.name == "ButtonReward" then
        -- check activity
        if not self:CanProceed() then
            return true
        end

        SoundSystem.PlayUIClickSound()
        local goalId = tonumber(go.transform.parent.gameObject.name)
        local goalState = GameData.GetGoalInfo(goalId)
        local goalType = ConfigUtils.GetGoalType(goalId)
        assert(goalState == GoalState.Complete, "state of goal "..tostring(goalId).." is: "..tostring(goalState))
        NetManager.Send("GetGoalReward", {GoalId = goalId, GoalType = goalType}, ActivityGoalCtrl.OnHandleProto, self)
    end

	return true
end

--------------------------------------------------------
function ActivityGoalCtrl:OnHandleProto(proto, data, requestData)
    if proto == "GetGoalReward" then
        local goalId = requestData.GoalId
        NavigationCtrl.EnableSuspend(true)
        GameData.FinishGoal(goalId)
        local goldNum = data.RemainGold
        local diamondNum = data.RemainDiamond
        GameData.SetMoney(ItemType.Gold, goldNum)
        GameData.SetMoney(ItemType.Diamond, diamondNum)
        GameData.CheckAndHintGoalsOfCurrentCountType()
    elseif proto == "DemandSubmit" then
        NavigationCtrl.EnableSuspend(true)
        local demandId = requestData.DemandId
        local demandIndex = requestData.DemandIndex
        local activityId = requestData.ActivityId
        local needItemId, needItemNum = ConfigUtils.GetDemandNeedItem(demandId)
        local costGoalData = GameData.SetupItemGoalData(needItemId, needItemNum)
        GameData.ConsumeItem(needItemId, needItemNum)

        local rewards = self._demandList[demandIndex].rewardList
        local showRewards = {}
        local rewardGoalData = {}
        for idx = 1, #rewards do
            local itemId = rewards[idx].id
            local itemNum = rewards[idx].num
            local unlocked = GameData.IsItemUnlocked(itemId)
            GameData.CollectItem(itemId, itemNum, false)
            showRewards[idx] = {value = itemId, num = itemNum, unlocked = unlocked}

            local e = GameData.SetupItemGoalData(itemId, itemNum)
            table.insert(rewardGoalData, e)
        end
        NewItemCtrl.ShowNewItemList(showRewards)

        local goldNum = data.RemainGold
        local diamondNum = data.RemainDiamond
        GameData.SetMoney(ItemType.Gold, goldNum)
        GameData.SetMoney(ItemType.Diamond, diamondNum)

        local completeDemandGoalData = GameData.SetupItemGoalDataWithType(ItemType.Demand, -1, 1)
        GameData.DoGoalSettle(TriggerType.DemandReward, rewardGoalData)
        GameData.DoGoalSettle(TriggerType.DemandCost, {costGoalData})
        GameData.DoGoalSettle(TriggerType.CompleteDemand, {completeDemandGoalData})

        GameData.SetTimeLimitedDemandList(activityId, data.ItemList)
        local demandListData = GameData.GetTimeLimitedDemandList()
        self._currentActivityData.demandList = demandListData.demandList or {}
        self:OnDemandChanged()
        -- sync server time
        local serverTime = data.ServerTime or 0
        if serverTime > 0 then
            GameData.SetServerTime(serverTime)
        end
    elseif proto == "DemandCancel" then
        local activityId = requestData.ActivityId
        GameData.SetTimeLimitedDemandList(activityId, data.ItemList)
        local demandListData = GameData.GetTimeLimitedDemandList()
        self._currentActivityData.demandList = demandListData.demandList or {}
        self:OnDemandChanged()
        -- sync server time
        local serverTime = data.ServerTime or 0
        if serverTime > 0 then
            GameData.SetServerTime(serverTime)
        end
    elseif proto == "ActivityDemandList" then
        local activityId = data.ActivityId
        local demandList = data.ItemList
        GameData.SetTimeLimitedDemandList(activityId, demandList)
        local demandListData = GameData.GetTimeLimitedDemandList()
        if demandListData.activityId ~= self._currentActivityData.id then
            self._currentActivityData.demandList = {}
        else
            self._currentActivityData.demandList = demandListData.demandList or {}
        end

        self:SetupGoal()
        self:SetupDemands()
        self:OnSelectedDemandChanged()
    end
end

--是否需要请求订单
function ActivityGoalCtrl:IsNeedRequestDemandList(lastRequestTime)
    local serverTime = GameData.GetServerTime()
    if serverTime - lastRequestTime < 5 then
        return false
    end
    local demandListData = GameData.GetTimeLimitedDemandList()
    if demandListData.demandList and #demandListData.demandList > 0 then
        return false
    end
    return true
end