require "FreakPlanet/View/PlanetPanel"
require "FreakPlanet/UI/HideSeek/require"

local class = require "FreakPlanet/Utils/middleclass"
PlanetCtrl  = class(CtrlNames.Planet, BaseCtrl)

local _planetPositions = {
	0,
	math.pi / 2,
	math.pi,
}

local GROUP_SHOW_TIME = 10                  -- seconds

--------------------------------------------------------

local _markNewPlanetId = nil
function PlanetCtrl.MarkShowPlanetGlobal(planetId)
	_markNewPlanetId = planetId
end

function PlanetCtrl.CleanMarkGlobal()
	_markNewPlanetId = nil
end

function PlanetCtrl.CheckMarkGlobal()
	local ctrl = CtrlManager.GetCtrlByName(CtrlNames.Planet)
	if ctrl ~= nil then
		ctrl:CheckMark()
	end
end

local this = PlanetCtrl
--------------------------------------------------------

-- load the ui prefab
function PlanetCtrl:LoadPanel()

	self:CreatePanel("Planet")

end

-- construct ui panel data
function PlanetCtrl:ConstructUI(obj)
	self._ui = PlanetPanel.Init(obj)

	self.HideSeekEntranceLayout = HideSeekEntranceLayout:new(self, self._ui.HideSeekEntrance)
	self:AddLayout(self.HideSeekEntranceLayout)
end

-- notity it has been focused
function PlanetCtrl:NotifyFocus()
	JumpManager.CleanHintGoal(false)
	this.CheckMarkGlobal()
end

-- notity it has been focused
function PlanetCtrl:OnResume()
	if self._ui == nil then
		return
	end
end

-- fill ui with the data
function PlanetCtrl:SetupUI()
	-- reset time scale
	Time.timeScale = 1
	-- mask
	self._ui.MaskPanel:SetActive(true)
	self._ui.MaskAnimator:Play("Mask", 0, 0)
	self._maskVisible = true
	self._maskLeftTime = 0.3
	-- init
	self._planetScale = 1
	self._isMoving = false
	self._isShowingTutorial = false
	self._movingPlanets = {}
	self._planetsWithAvatarGenerated = {}
	-- planet list
	self:RefreshPlanetList()
	-- switch between 2 planet items
	self:PrepareShowPlanet()
	-- current planet
	self._currentPlanetId = self._planetList[1]
	self._showPlanetIdx = 1

	-- show planet
	self:OnShowPlanetChanged()
	--self:CheckModules()
	self:ConstructExploreTeam()
	this.CleanMarkGlobal()

	self:RefreshHideSeek()

	CtrlManager.AddClick(self, self._ui.PlanetCollider)

	CtrlManager.AddClick(self, self._ui.Blocker)

	CtrlManager.AddClick(self, self._ui.m_pAppCenterBtn)
	CtrlManager.AddClick(self, self._ui.m_pHomeBtn)
	CtrlManager.AddClick(self, self._ui.m_pExileStreetBtn)

	CtrlManager.AddPress(self, self._ui.Blocker)
	CtrlManager.AddPress(self, self._ui.PlanetCollider)

	-- team items
	for k, v in pairs(self._ui.ExploreTeamItems) do
		CtrlManager.AddClick(self, v.item)
	end

	GameNotifier.AddListener(GameEvent.PlanetAreaUnlocked, PlanetCtrl.OnPlanetAreaUnlocked, self)
	GameNotifier.AddListener(GameEvent.PlanetAreaExplore, PlanetCtrl.OnPlanetAreaExplore, self)
	GameNotifier.AddListener(GameEvent.PlanetAreaSettle, PlanetCtrl.OnPlanetAreaSettle, self)
	GameNotifier.AddListener(GameEvent.PlanetNodeAdded, PlanetCtrl.OnPlanetNodeAdded, self)
	GameNotifier.AddListener(GameEvent.CharacterNodeVisibleChanged, PlanetCtrl.OnCharacterNodeVisibleChanged, self)
	GameNotifier.AddListener(GameEvent.ExploreTeamUnlocked, PlanetCtrl.OnExploreTeamUnlocked, self)
	----------------------------------------------------------------------------------------------------

	GameNotifier.AddListener(GameEvent.HideSeekDataChanged, PlanetCtrl.ConstructHideSeekCollider, self)
end

function PlanetCtrl:DestroyImpl()
	GameNotifier.RemoveListener(GameEvent.PlanetAreaUnlocked, PlanetCtrl.OnPlanetAreaUnlocked, self)
	GameNotifier.RemoveListener(GameEvent.PlanetAreaExplore, PlanetCtrl.OnPlanetAreaExplore, self)
	GameNotifier.RemoveListener(GameEvent.PlanetAreaSettle, PlanetCtrl.OnPlanetAreaSettle, self)
	GameNotifier.RemoveListener(GameEvent.PlanetNodeAdded, PlanetCtrl.OnPlanetNodeAdded, self)
	GameNotifier.RemoveListener(GameEvent.CharacterNodeVisibleChanged, PlanetCtrl.OnCharacterNodeVisibleChanged, self)
	GameNotifier.RemoveListener(GameEvent.ExploreTeamUnlocked, PlanetCtrl.OnExploreTeamUnlocked, self)

	GameNotifier.RemoveListener(GameEvent.HideSeekDataChanged, PlanetCtrl.ConstructHideSeekCollider, self)

	self.HideSeekEntranceLayout:Hide()
	CtrlManager.ClosePanel(CtrlNames.HideSeek)
end



function PlanetCtrl:PrepareShowPlanet()
	self._showPlanets = {}
	local angles = {_planetPositions[2], _planetPositions[1]}
	for idx = 1, 2 do
		local planetObj = Helper.NewObject(self._ui.PlanetTemplate, self._ui.Center, 0.9)
		planetObj.name = "Planet_"..tostring(idx)
		planetObj:SetActive(true)
		local planetItem = planetObj.transform
		-- mark
		local mark = planetItem:Find("Mark")
		local markAnimator = mark:GetComponent("Animator")

		self:PlacePosition(planetItem, angles[idx], self._ui.RotateRadius)

		self._showPlanets[idx] = {
			item = planetItem,
			mark = mark,
			markAnimator = markAnimator,
		}
	end
end

function PlanetCtrl:CheckPlanetAvatars()
	for idx = 1, #self._planetList do
		local planetId = self._planetList[idx]
		if self._planetsWithAvatarGenerated[planetId] == nil then
			local prefabName = ConfigUtils.GetPlanetPrefab(planetId)
			self:DynamicLoadBundle(string.format("packed_planet_%s", string.lower(prefabName)))
			local planetAvatarPrefab = self:LoadAsset(prefabName)
			local planetAvatarObj = Helper.NewObject(planetAvatarPrefab, self._ui.PlanetAvatarPool, self._planetScale)
			planetAvatarObj.name = prefabName
			planetAvatarObj:SetActive(true)
			self._planetsWithAvatarGenerated[planetId] = 1
		end
	end
end

function PlanetCtrl:OnShowPlanetChanged()
	-- clean dialog first
	self:CleanDialog()
	-- planet avatar
	self:GeneratePlanetAvatar(self._currentPlanetId, self._showPlanetIdx)
    -- planet nodes
    self:ConstructPlanetNodes()
   	-- check explore planet goal
   	JumpManager.CheckToCleanExplorePlanetGoal(self._currentPlanetId)
   	-- sync planet collider
   	self:SyncColliderPosition()

	-- 捉迷藏
	self:ConstructHideSeekCollider()
end

function PlanetCtrl:SyncColliderPosition()
	-- sync planet collider position
   	local planetMark = self._showPlanets[self._showPlanetIdx].mark
   	if planetMark.childCount > 0 then
   		local planetAvatar = planetMark:GetChild(0)
		local exploreMark = planetAvatar:Find("TopPanel/Explore")
		self._ui.PlanetCollider.transform.position = exploreMark.position
	end
end

function PlanetCtrl:RecylePlanetAvatar(showPlanetIdx)
	local planetMark = self._showPlanets[showPlanetIdx].mark
	if planetMark.childCount > 0 then
		local planetAvatar = planetMark:GetChild(0)
		planetAvatar.parent = self._ui.PlanetAvatarPool
	end
end

function PlanetCtrl:GeneratePlanetAvatar(planetId, showPlanetIdx)
	-- do cycle
	self:RecylePlanetAvatar(showPlanetIdx)

	local planetMark = self._showPlanets[showPlanetIdx].mark
	local prefabName = ConfigUtils.GetPlanetPrefab(planetId)
	local planetAvatar = self._ui.PlanetAvatarPool:Find(prefabName)
	assert(planetAvatar ~= nil, "can't find avatar for planet: "..tostring(planetId).."; planet prefab name: "..tostring(prefabName))
	planetAvatar.parent = planetMark
	planetAvatar.localPosition = Vector3.zero
	planetAvatar.localScale = Vector3.one * self._planetScale
	-- skeleton
	local avatarSkeleton = nil
	for idx = 1, planetAvatar.childCount do
		local skeleton = planetAvatar:GetChild(idx - 1):GetComponent("SkeletonAnimation")
		if skeleton ~= nil then
			avatarSkeleton = skeleton
			break
		end
	end

	if avatarSkeleton ~= nil then
		-- default idle explore
		Helper.PlayAnimation(avatarSkeleton, PlanetAnimations.Idle, true)
	end
end

function PlanetCtrl:RefreshPlanetList()
	self._planetList = GameData.GetUnlockPlanets()
	table.sort(self._planetList, ConfigUtils.PlanetSortFunc)
	self:CheckPlanetAvatars()
end

function PlanetCtrl:ConstructExploreTeam()
	self._exploreTeams = GameData.GetExploreTeam()

	for idx = 1, #self._ui.ExploreTeamItems do
		local hasTeam = (idx <= #self._exploreTeams)
		self._ui.ExploreTeamItems[idx].item:SetActive(hasTeam)
		if hasTeam then
			local teamStatus = self._exploreTeams[idx].status
			self._ui.ExploreTeamItems[idx].lock:SetActive(teamStatus == ExploreTeamStatus.Lock)
			self._ui.ExploreTeamItems[idx].idle:SetActive(teamStatus == ExploreTeamStatus.Idle)
			self._ui.ExploreTeamItems[idx].exploring:SetActive(false)
			self._ui.ExploreTeamItems[idx].done:SetActive(false)
			if teamStatus == ExploreTeamStatus.Exploring then
				local areaId = self._exploreTeams[idx].area
				local leftTime = GameData.GetLeftTimeOfPlanetArea(areaId)
				local planetId = ConfigUtils.GetPlanetOfArea(areaId)
				self._ui.ExploreTeamItems[idx].icon.spriteName = ConfigUtils.GetPlanetIcon(planetId)
				self._ui.ExploreTeamItems[idx].doneIcon.spriteName = ConfigUtils.GetPlanetIcon(planetId)
				self._ui.ExploreTeamItems[idx].exploring:SetActive(leftTime > 0)
				self._ui.ExploreTeamItems[idx].done:SetActive(leftTime == 0)
			end
			self._ui.ExploreTeamItems[idx].time.text = ""
		end
	end
end

function PlanetCtrl:ConstructPlanetNodes()
	local planetAvatar = self._showPlanets[self._showPlanetIdx].mark:GetChild(0)
	-- area
	local areaNodeRoot = planetAvatar:Find("Planet/Areas")
	for idx = 1, areaNodeRoot.childCount do
		local nodeItem = areaNodeRoot:GetChild(idx - 1).gameObject
		local nodeName = nodeItem.name
		local isVisible = NodeHelper.IsPlanetNodeVisible(nodeName)
		nodeItem:SetActive(isVisible)
	end
	-- character
	local characterNodeRoot = planetAvatar:Find("Planet/Character")
	for idx = 1, characterNodeRoot.childCount do
		local groupNode = characterNodeRoot:GetChild(idx - 1)
		for m = 1, groupNode.childCount do
			local nodeItem = groupNode:GetChild(m - 1).gameObject
			local nodeName = nodeItem.name
			local isVisible = NodeHelper.IsCharacterNodeVisible(nodeName)
			nodeItem:SetActive(isVisible)
		end
	end
end

-- set planet position
function PlanetCtrl:PlacePosition(planetItem, angle, radius)
	local pos = planetItem.localPosition
	pos.x = math.cos(angle) * radius
	pos.y = math.sin(angle) * radius
	planetItem.localPosition = pos
end

function PlanetCtrl:CloseToTarget(params)
	CtrlManager.OpenPanel(params.ctrlName)
end


--------------------------------------------------------------

-- on clicked
function PlanetCtrl:OnClicked(go, param)
	if not self:AcceptClick() then
		return
	end

	if go == self._ui.Blocker then
		local pos = self:ScreenToWorld(Input.mousePosition)
		local hitResult = UnityEngine.Physics2D.Raycast(pos, Vector3.forward)
		if hitResult.collider ~= nil and hitResult.collider.transform.parent ~= nil and hitResult.collider.transform.parent.parent ~= nil then
			local parentName = hitResult.collider.transform.parent.parent.gameObject.name
			if parentName == "Character" then
				local node = hitResult.collider.transform
				self:OnCharacterNodeClicked(node)
			end
		end
	elseif go == self._ui.PlanetCollider then
		SoundSystem.PlayUIClickSound()
		local exploreId = param or self._currentPlanetId
		CtrlManager.OpenPanel(CtrlNames.ExploreGuide, {exploreId = exploreId})
	elseif go == self._ui.m_pAppCenterBtn then
		SoundSystem.PlayUIClickSound()
		CtrlManager.OpenPanel(CtrlNames.ApplicationCenter)
	elseif go == self._ui.m_pExileStreetBtn then
		SoundSystem.PlayUIClickSound()
		CtrlManager.PopPanel()
		CtrlManager.OpenPanel(CtrlNames.Arena)
	elseif go == self._ui.m_pHomeBtn then
		SoundSystem.PlayUIClickSound()
		CtrlManager.PopPanel()
	elseif go.transform.parent == self._ui.ExploreTeamRoot then
		local names = Helper.StringSplit(go.name)
		assert(#names == 2, "invalid explore team item name: "..tostring(go.name))
		local teamIndex = tonumber(names[2])
		local teamStatus = self._exploreTeams[teamIndex].status
		if teamStatus == ExploreTeamStatus.Exploring then
			local areaId = self._exploreTeams[teamIndex].area
			SoundSystem.PlayUIClickSound()
			CtrlManager.OpenPanel(CtrlNames.ExploreGuide, {exploreId = areaId})
		elseif teamStatus == ExploreTeamStatus.Lock then
			SoundSystem.PlayUIClickSound()
			CtrlManager.OpenPanel(CtrlNames.ExploreUnlockTeam)
		elseif teamStatus == ExploreTeamStatus.Idle then
			SoundSystem.PlayUIClickSound()
			CtrlManager.OpenPanel(CtrlNames.ExploreGuide, {exploreId = self._currentPlanetId})
		end
	elseif self._HideSeekColliderRoot and go.transform.parent == self._HideSeekColliderRoot then
        local rabbitId = tonumber(go.name)
		if GameDataHideSeek.IsValidHideSeekRabbit(rabbitId) then
			XDebug.Log("LZ", "rabbitId:", rabbitId)
			self._CurRabbitId = rabbitId
			local speechId = GameDataHideSeek.GetCurHideSeekStorySpeechId()
			if speechId then
				CtrlManager.LaunchPanel(CtrlNames.GoalDialog, {goalSpeechList = {speechId}, callback = PlanetCtrl.OnDialogFinish, reciver = self})
			else
				self:OnDialogFinish()
			end
		end
	else

	end

	return true
end

function PlanetCtrl:OnPressed(go, pressed, isLong)
	if not self:AcceptClick() then
		return
	end

	if pressed then
		self._touchPosition = Input.mousePosition
	elseif not pressed and self._touchPosition ~= nil then
		local curPosition = Input.mousePosition
		local diffX = curPosition.x - self._touchPosition.x
		if diffX > 50 then
			self:SelectNewPlanet(false)
		elseif diffX < -50 then
			self:SelectNewPlanet(true)
		end
	end
end

function PlanetCtrl:AcceptClick()
	if self._isMoving or self._isShowingTutorial then
		return false
	end

	return true
end

function PlanetCtrl:GetCurrentPlanetIndex()
	local idx = self:GetPlanetIndex(self._currentPlanetId)
	assert(idx ~= nil, "current planet id not in the planet list")
	return idx
end

function PlanetCtrl:GetPlanetIndex(planetId)
	for idx = 1, #self._planetList do
		if self._planetList[idx] == planetId then
			return idx
		end
	end
	-- not found
	return nil
end

function PlanetCtrl:CurrentShowPlanet()
	return self._showPlanets[self._showPlanetIdx]
end

function PlanetCtrl:SelectNewPlanet(add)
	if #self._planetList == 1 then
		return
	end

	local currentIdx = self:GetCurrentPlanetIndex()
	local previousIdx = currentIdx
	if add then
		currentIdx = currentIdx + 1
	else
		currentIdx = currentIdx - 1
	end

	currentIdx = math.max(currentIdx, 1)
	currentIdx = math.min(currentIdx, #self._planetList)
	-- no change
	if currentIdx == previousIdx then
		return
	end

	SoundSystem.PlaySoundOfName(SoundNames.SwitchPlanet)
	-- previous planet
	self._prevPlanetId = self._currentPlanetId
	self._prevShowPlanetIdx = self._showPlanetIdx
	-- current planet
	self._currentPlanetId = self._planetList[currentIdx]
	self._showPlanetIdx = self:GetNextShowPlanetIndex(self._showPlanetIdx)
	self:StartMove()
	local nextPlanetItem = self._showPlanets[self._showPlanetIdx].item
	self._movingPlanets = {}
	if add then
		self:PlacePosition(nextPlanetItem,  _planetPositions[1], self._ui.RotateRadius)
		table.insert(self._movingPlanets, {showIdx = self._prevShowPlanetIdx, current = _planetPositions[2], target = _planetPositions[3], dir = 1})
		table.insert(self._movingPlanets, {showIdx = self._showPlanetIdx, current = _planetPositions[1], target = _planetPositions[2], dir = 1})
	else
		self:PlacePosition(nextPlanetItem,  _planetPositions[3], self._ui.RotateRadius)
		table.insert(self._movingPlanets, {showIdx = self._prevShowPlanetIdx, current = _planetPositions[2], target = _planetPositions[1], dir = -1})
		table.insert(self._movingPlanets, {showIdx = self._showPlanetIdx, current = _planetPositions[3], target = _planetPositions[2], dir = -1})
	end
end

function PlanetCtrl:GetNextShowPlanetIndex(showPlanetIdx)
	showPlanetIdx = showPlanetIdx + 1
	if showPlanetIdx > #self._showPlanets then
		showPlanetIdx = 1
	end

	return showPlanetIdx
end

function PlanetCtrl:StartMove()
	self._isMoving = true
	self:OnShowPlanetChanged()

	if self._ui.TouristAnimator.gameObject.activeInHierarchy then
		self._ui.TouristAnimator:Play("Switch", 0, 0)
	end
end

function PlanetCtrl:EndMove()
	-- do recycle for re-use
	self:RecylePlanetAvatar(self._prevShowPlanetIdx)
	-- sync collider position
	self:SyncColliderPosition()
	-- end move
	self._isMoving = false
	self._movingPlanets = {}
end

-- update per frame
function PlanetCtrl:UpdateImpl(deltaTime)
	if self._isMoving then
		local finished = false
		for idx = 1, #self._movingPlanets do
			local cur = self._movingPlanets[idx].current + deltaTime * self._movingPlanets[idx].dir * 5
			if (self._movingPlanets[idx].dir > 0 and cur >= self._movingPlanets[idx].target) or
			   (self._movingPlanets[idx].dir < 0 and cur <= self._movingPlanets[idx].target) then
				cur = self._movingPlanets[idx].target
				finished = true
			end

			self._movingPlanets[idx].current = cur
			local showPlanetIdx = self._movingPlanets[idx].showIdx
			local planetItem = self._showPlanets[showPlanetIdx].item
			self:PlacePosition(planetItem, cur, self._ui.RotateRadius)
		end

		if finished then
			self:EndMove()
		end
	end

	for idx = 1, #self._ui.ExploreTeamItems do
		local hasTeam = (idx <= #self._exploreTeams)
		if hasTeam then
			local teamStatus = self._exploreTeams[idx].status
			if teamStatus == ExploreTeamStatus.Exploring then
				local areaId = self._exploreTeams[idx].area
				local leftTime = GameData.GetLeftTimeOfPlanetArea(areaId)
				self._ui.ExploreTeamItems[idx].time.text = Helper.FormatTime(leftTime)
				self._ui.ExploreTeamItems[idx].exploring:SetActive(leftTime > 0)
				self._ui.ExploreTeamItems[idx].done:SetActive(leftTime == 0)
			end
		end
	end

	if #self._dialogList > 0 then
		self._ui.DialogItem.localPosition = self._ui.DialogRoot:InverseTransformPoint(self._dialogList[1].root.position)
		local leftTime = self._dialogList[1].leftTime - deltaTime
		self._dialogList[1].leftTime = leftTime
		if leftTime <= 0 then
			table.remove(self._dialogList, 1)
			if #self._dialogList > 0 then
				self:PeekFirstDialog()
			else
				self:HideDialogItem()
			end
		end
	end

	if self._maskVisible then
		self._maskLeftTime = self._maskLeftTime - deltaTime
		if self._maskLeftTime <= 0 then
			self._maskVisible = false
			self._ui.MaskPanel:SetActive(false)
		end
	end
end



function PlanetCtrl:OnPlanetAreaExplore(planetAreaId)
	self:ConstructExploreTeam()
end

function PlanetCtrl:OnPlanetAreaSettle(planetAreaId)
	self:ConstructExploreTeam()
end

function PlanetCtrl:OnExploreTeamUnlocked()
	self:ConstructExploreTeam()
end

function PlanetCtrl:OnPlanetAreaUnlocked(planetAreaId)
	local planetId = ConfigUtils.GetPlanetOfArea(planetAreaId)
	if not Helper.TableContains(self._planetList, planetId) then
		self:RefreshPlanetList()
	end
end

function PlanetCtrl:OnPlanetNodeAdded(nodeName)
	local planetAvatar = self._showPlanets[self._showPlanetIdx].mark:GetChild(0)
	local nodeRoot = planetAvatar:Find("Planet/Areas")

	local nodeItem = nodeRoot:Find(nodeName)
	if nodeItem ~= nil then
		nodeItem.gameObject:SetActive(true)
	end
end

function PlanetCtrl:OnCharacterNodeVisibleChanged(nodeName, visible)
	local planetAvatar = self._showPlanets[self._showPlanetIdx].mark:GetChild(0)
	local nodeRoot = planetAvatar:Find("Planet/Character")
	for idx = 1, nodeRoot.childCount do
		local groupRoot = nodeRoot:GetChild(idx - 1)
		local nodeItem = groupRoot:Find(nodeName)
		if nodeItem ~= nil then
			nodeItem.gameObject:SetActive(visible)
		end
	end
end

function PlanetCtrl:CheckMark()
	local planetChanged = false
	if _markNewPlanetId ~= nil and _markNewPlanetId ~= self._currentPlanetId then
		local planetIdx = Helper.IndexOfArray(self._planetList, _markNewPlanetId)
		assert(planetIdx ~= nil, "can't find planet in planet list: "..tostring(_markNewPlanetId))
		self._currentPlanetId = _markNewPlanetId
		planetChanged = true
	end

	if planetChanged then
		self:OnShowPlanetChanged()
		this.CleanMarkGlobal()
	end
end

function PlanetCtrl:SwitchPlanet(planetId)
	local planetChanged = false
	if ConfigUtils.IsValidPlanet(planetId) and planetId ~= self._currentPlanetId then
		local planetIdx = Helper.IndexOfArray(self._planetList, planetId)
		assert(planetIdx ~= nil, "can't find planet in planet list: "..tostring(planetId))
		self._currentPlanetId = planetId
		planetChanged = true
	end

	if not planetChanged and _markNewPlanetId ~= nil and _markNewPlanetId ~= self._currentPlanetId then
		local planetIdx = Helper.IndexOfArray(self._planetList, _markNewPlanetId)
		assert(planetIdx ~= nil, "can't find planet in planet list: "..tostring(_markNewPlanetId))
		self._currentPlanetId = _markNewPlanetId
		planetChanged = true
	end

	if planetChanged then
		self:OnShowPlanetChanged()
		this.CleanMarkGlobal()
	end
end



--------------------------------------------------------
function PlanetCtrl:OnTouristChanged()
	self:CheckModule(ModuleNames.Tourist)
end

function PlanetCtrl:OnSummonPoolChanged()
	self:CheckModule(ModuleNames.Summon)
end

function PlanetCtrl:OnTimeLimitActivityChanged()
	self:CheckModule(ModuleNames.Mission)
end


function PlanetCtrl:RefreshHideSeek()
	local isUnlock = GameDataHideSeek.IsUnlockHideSeekActivity()
	if isUnlock then
		self.HideSeekEntranceLayout:Show()
		CtrlManager.LaunchPanel(CtrlNames.HideSeek)
	else
		self.HideSeekEntranceLayout:Hide()
		CtrlManager.ClosePanel(CtrlNames.HideSeek)
	end
end


--------------------------------------------------------

function PlanetCtrl:OnTutorialClicked(tutorial)
	self._isShowingTutorial = false
	if tutorial == Tutorials.Tutorial_1_1 then
		self:OnClicked(self._ui.PlanetCollider)
	elseif tutorial == Tutorials.Tutorial_EnterMap then
		self:OnClicked(self._ui.PlanetCollider, TutorialConstData.ExploreAreaId)
	elseif tutorial == Tutorials.Tutorial_PlanetToCharacterList then
		local button = self._ui.Modules[ModuleNames.CharacterList].item
		self:OnClicked(button)
	elseif tutorial == Tutorials.Tutorial_PlanetToWorkShop then
		local button = self._ui.Modules[ModuleNames.WorkShop].item
		self:OnClicked(button)
	elseif tutorial == Tutorials.Tutorial_PlanetToGoal then
		local buttonGoal = self._ui.Modules[ModuleNames.Mission].item
		self:OnClicked(buttonGoal)
	elseif tutorial == Tutorials.Tutorial_Tourist_1 then
		local buttonTourist = self._ui.Modules[ModuleNames.Tourist].item
		self:OnClicked(buttonTourist)
	else
		SoundSystem.PlayUIClickSound()
	end
end


--------------------------------------------------------
function PlanetCtrl:PeekFirstDialog()
	if #self._dialogList == 0 then
		return
	end

	self._ui.DialogTypeEffect:Finish()
	self._ui.DialogItem.gameObject:SetActive(true)
	self._ui.DialogLabel.text = self._dialogList[1].message
	local bgHeight = self._ui.DialogLabel.height + 30
	bgHeight = math.max(55, bgHeight)
	self._ui.DialogBG.height = bgHeight
	self._ui.DialogTypeEffect:ResetToBeginning()
end

function PlanetCtrl:HideDialogItem()
	self._ui.DialogItem.gameObject:SetActive(false)
end

function PlanetCtrl:CleanDialog()
	self._dialogList = {}
	self:HideDialogItem()
end

function PlanetCtrl:OnCharacterNodeClicked(node)
	local dialogRoot = node:Find("DialogRoot")
	if dialogRoot == nil then
		return
	end

	self._dialogList = {}
	local childCount = dialogRoot.childCount

	local nodeName = node.gameObject.name
	local dialogList = ConfigUtils.GetCharacterNodeDialogList(nodeName) or {}
	local totalCount = #dialogList
	if totalCount >= 1 then
		local dialogIdx = Helper.RandInt(1, totalCount)
		local dialogs = dialogList[dialogIdx]
		for idx = 1, #dialogs do
			local text = dialogs[idx].Text
			local pos = dialogs[idx].Position
			if pos <= childCount then
				table.insert(self._dialogList, {
					message = SAFE_LOC(text),
					root = dialogRoot:GetChild(pos - 1),
					leftTime = string.len(text) / self._ui.DialogTypeEffect.charsPerSecond + 0.5,
				})
			end
		end
	end

	self:PeekFirstDialog()
end
--------------------------------------------------------

function PlanetCtrl:OnHideSeekActivityOver()
	self:RefreshHideSeek()

	if self._RabbitRoot and self._HideSeekColliderRoot then
		for idx = 1, self._RabbitRoot.childCount do
			local item = self._RabbitRoot:GetChild(idx - 1)
			item.gameObject:SetActive(false)
		end

		for idx = 1, self._HideSeekColliderRoot.childCount do
			local item = self._HideSeekColliderRoot:GetChild(idx - 1)
			item.gameObject:SetActive(false)
		end
	end
end

function PlanetCtrl:ConstructHideSeekCollider()
	local unlockActivity = GameData.UnlockHideSeekActivity()
	if unlockActivity then
		local currentPlanet = self._showPlanets[self._showPlanetIdx].mark:GetChild(0)
		local unlockPlanet = GameDataHideSeek.GetHideSeekUnlcokPlanetIdList()
		if Helper.TableContains(unlockPlanet, self._currentPlanetId) then
			local IdList, nodeList = GameDataHideSeek.GetActiveHideSeekIdAndNode()
			local hideSeekCollider = currentPlanet:Find("Planet/HideSeekCollider")
			local hideSeekItemTemplate = currentPlanet:Find("Planet/Template/HideSeekColliderItem").gameObject
			local rabbitRootPath = "Planet/" .. GameDataHideSeek.GetHideSeekGameObjectRoot()
			local rabbitRoot = currentPlanet:Find(rabbitRootPath)
			self._RabbitRoot = rabbitRoot
			self._HideSeekColliderRoot = hideSeekCollider
			for idx = 1, rabbitRoot.childCount do
				local item = rabbitRoot:GetChild(idx - 1)
				local nodeIndex = Helper.IndexOfArray(nodeList, item.name)
				if nodeIndex then
					item.gameObject:SetActive(true)
					local rabbidId = IdList[nodeIndex]
					local colliderNode = hideSeekCollider:Find(tostring(rabbidId))
					if not colliderNode then
						local newObj = Helper.NewObject(hideSeekItemTemplate, hideSeekCollider)
						local position = hideSeekCollider:InverseTransformPoint(item.transform.position)
						newObj.transform.localPosition = position
						local originCollider = item:GetComponent("BoxCollider")
						local colliderCenter = originCollider.center
						local colliderSize = originCollider.size
						local newObjCollider = newObj:GetComponent("BoxCollider")
						newObjCollider.center = colliderCenter
						newObjCollider.size = colliderSize
						newObj.name = tostring(rabbidId)
						CtrlManager.AddClick(self, newObj)
					end
				else
					item.gameObject:SetActive(false)
				end
			end
		else
			self._RabbitRoot = nil
			self._HideSeekColliderRoot = nil
		end
	end
	self:RefreshHideSeekUI()
end

function PlanetCtrl:RefreshHideSeekUI()
	if self._RabbitRoot and self._HideSeekColliderRoot then
		local IdList, nodeList = GameDataHideSeek.GetActiveHideSeekIdAndNode()
		for idx = 1, self._RabbitRoot.childCount do
			local item = self._RabbitRoot:GetChild(idx - 1)
			item.gameObject:SetActive(Helper.TableContains(nodeList, item.name))
		end

		for idx = 1, self._HideSeekColliderRoot.childCount do
			local item = self._HideSeekColliderRoot:GetChild(idx - 1)
			item.gameObject:SetActive(Helper.TableContains(IdList, item.name))
		end
	end
end

function PlanetCtrl:OnDialogFinish()
	NetManager.Send("HideSeekFind", { RabbitId = self._CurRabbitId }, PlanetCtrl.OnHandleProto, self)
end

function PlanetCtrl:OnHandleProto(proto, data, requestData)
	if proto == "HideSeekFind" then
		local goldNum = data.RemainGold
		local diamondNum = data.RemainDiamond
		local rabbitId = data.RabbitId
		NavigationCtrl.EnableSuspend(false)
		GameData.SetHideSeekRabbitData(rabbitId)

		local selfReward = GameDataHideSeek.GetHideSeekObjectRewardList(rabbitId)
		-- 阶段奖励
		local isUnlock, stageReward = GameDataHideSeek.IsUnlockHideSeekRewardList(GameData.GetTotalHideSeekFindCount())
		local totalReward = {}
		for idx = 1, #selfReward do
			local id = selfReward[idx].Id
			local num = selfReward[idx].Num
			totalReward[id] = totalReward[id] or 0
			totalReward[id] = totalReward[id] + num
		end

		if isUnlock then
			for idx = 1, #stageReward do
				local id = stageReward[idx].Id
				local num = stageReward[idx].Num
				totalReward[id] = totalReward[id] or 0
				totalReward[id] = totalReward[id] + num
			end
		end
		XDebug.LogTable("LZ", "totalReward:", totalReward)
		for id, num in pairs(totalReward) do
			GameData.CollectItem(id, num, false)
		end

		GameData.SetMoney(ItemType.Gold, goldNum)
		GameData.SetMoney(ItemType.Diamond, diamondNum)
		GameData.CheckAndHintGoalsOfCurrentCountType()

		CtrlManager.OpenPanel(CtrlNames.HideSeekReward, { RabbitId = rabbitId,  Reward = totalReward })
	end
end

--- 不会被迁移的功能
----------------------------------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------------------------------

---被迁移的功能
----------------------------------------------------------------------------------------------------------------------------

function PlanetCtrl:RefreshSignIn()
	local hasNew = GameData.HasSignInReward() or GameData.HasAnyMonthCardReward()
	self._ui.SignInHint:SetActive(hasNew)
end

function PlanetCtrl:RefreshMail()
	local hasNew = GameData.HasNewMail()
	self._ui.MaiHint:SetActive(hasNew)
end

function PlanetCtrl:RefreshNotice()
	local hasNew = GameData.ShowBulletinHit()
	self._ui.NoticeHint:SetActive(hasNew)
end

function PlanetCtrl:RefreshWeeklyReport()
	local hasNew = GameData.HasNewWeeklyReport()
	self._ui.WeeklyHint:SetActive(hasNew)
end

function PlanetCtrl:OnNoticeStateChanged()
	self:RefreshNotice()
end

function PlanetCtrl:OnMailStateChanged()
	self:RefreshMail()
end

function PlanetCtrl:OnWeeklyReportStateChanged()
	self:RefreshWeeklyReport()
end

function PlanetCtrl:RefreshExileStreet()
	local show = GameData.IsModuleUnlocked(ModuleNames.Arena) or GameData.IsModuleUnlocked(ModuleNames.Activity)
	self._ui.ButtonExileStreet:SetActive(show)
	local showHint = show
	if showHint then
		showHint = GameData.HasFinishedActivityExplore() or GameData.HasCompletedActivityGoal()
	end
	self._ui.ExileStreetHint:SetActive(showHint)

	local showActivityHint = (GameData.GetCurrentActivityTheme() ~= nil)
	self._ui.ExileStreetActivityHint:SetActive(showActivityHint)
end



-- tutorial
function PlanetCtrl:CheckTutorial(firstEnter)
	local tutorials = {}

	if GameData.IsTutorialNotFinished(Tutorials.Tutorial_1_9) then
		local position = self._ui.Camera:WorldToScreenPoint(self._ui.PlanetCollider.transform.position)
		tutorials[1] = {event = Tutorials.Tutorial_1_1, position = position, sender = self}
	elseif GameData.IsTutorialNotFinished(Tutorials.Tutorial_1_12) then
		local position = self._ui.Camera:WorldToScreenPoint(self._ui.PlanetCollider.transform.position)
		tutorials[1] = {event = Tutorials.Tutorial_EnterMap, position = position, sender = self}
	elseif firstEnter then
		local showGoalHint = false

		if not showGoalHint then
			showGoalHint = GameData.IsTutorialNotFinished(Tutorials.Tutorial_2_6) and GameData.IsGoalCompleted(TutorialConstData.ExploreGoal)
		end

		if not showGoalHint then
			showGoalHint = GameData.IsTutorialNotFinished(Tutorials.Tutorial_2_6) and GameData.IsGoalRunning(TutorialConstData.ChallengeGoal)
		end

		if not showGoalHint then
			showGoalHint = GameData.IsTutorialNotFinished(Tutorials.Tutorial_3_2) and GameData.IsGoalCompleted(TutorialConstData.ChallengeGoal)
		end

		if not showGoalHint then
			showGoalHint =  GameData.IsTutorialNotFinished(Tutorials.Tutorial_5_6) and GameData.IsGoalRunning(TutorialConstData.DemandGoal)
		end

		if not showGoalHint then
			showGoalHint =  GameData.IsTutorialNotFinished(Tutorials.Tutorial_6_3) and GameData.IsGoalRunning(TutorialConstData.EquipmentUpgradeGoal)
		end

		if not showGoalHint then
			showGoalHint =  GameData.IsTutorialNotFinished(Tutorials.Tutorial_7_4) and GameData.IsGoalRunning(TutorialConstData.WorkShopUpgradeGoal)
		end

		if not showGoalHint then
			showGoalHint =  GameData.IsTutorialNotFinished(Tutorials.Tutorial_8_2) and GameData.IsGoalRunning(TutorialConstData.SummonGoal)
		end

		if not showGoalHint then
			showGoalHint =  GameData.IsTutorialNotFinished(Tutorials.Tutorial_9_3) and GameData.IsGoalRunning(TutorialConstData.CraftGoal)
		end

		-- goal hint
		if showGoalHint then
			local buttonGoal = self._ui.Modules[ModuleNames.Mission].item
			local position = self._ui.Camera:WorldToScreenPoint(buttonGoal.transform.position)
			tutorials[1] = {event = Tutorials.Tutorial_PlanetToGoal, position = position, sender = self}
		end
	end

	if #tutorials == 0 then
		local showCharacterHint = GameData.IsTutorialNotFinished(Tutorials.Tutorial_3_2) and GameData.IsGoalRunning(TutorialConstData.CharacterUpgradeGoal)
		if showCharacterHint then
			local buttonGoal = self._ui.Modules[ModuleNames.CharacterList].item
			local position = self._ui.Camera:WorldToScreenPoint(buttonGoal.transform.position)
			tutorials[1] = {event = Tutorials.Tutorial_PlanetToCharacterList, position = position, sender = self}
		end
	end

	-- workshop hint
	if #tutorials == 0 then
		local showWorkShopHint =  GameData.IsTutorialNotFinished(Tutorials.Tutorial_4_4) and GameData.IsGoalRunning(TutorialConstData.WorkShopGoal)
		if showWorkShopHint then
			local buttonGoal = self._ui.Modules[ModuleNames.WorkShop].item
			local position = self._ui.Camera:WorldToScreenPoint(buttonGoal.transform.position)
			tutorials[1] = {event = Tutorials.Tutorial_PlanetToWorkShop, position = position, sender = self}
		end
	end

	if #tutorials == 0 then
		if GameData.IsItemNew(ModuleNames.Tourist) and GameData.HasValidTourist() then
			local buttonTourist = self._ui.Modules[ModuleNames.Tourist].item
			local position = self._ui.Camera:WorldToScreenPoint(buttonTourist.transform.position)
			tutorials[1] = {event = Tutorials.Tutorial_Tourist_1, position = position, sender = self}
		end
	end

	if #tutorials > 0 then
		self._isShowingTutorial = true
		CtrlManager.ShowTutorials(tutorials)
	end

	return #tutorials > 0
end

function PlanetCtrl:HandleForceRealName()
	CtrlManager.OpenPanel(CtrlNames.AccountRealName, {force = GameData.IsRestrictRealName()})
end

function PlanetCtrl:HandleRealName()
	CtrlManager.OpenPanel(CtrlNames.AccountRealName)
end

function PlanetCtrl:RefreshAccount()
	local isBinded = GameData.IsAccountNicknameBinded()
	self._ui.GameOptionHint:SetActive(not isBinded)
end

function PlanetCtrl:OnCtrlReady()
	local hasTutorial = self:CheckTutorial(true)
	if hasTutorial then
		return
	end
	if not self:CheckRealName(true) then
		self:CheckWeeklyReport()
	end
end

function PlanetCtrl:RefreshReview()
	local hasReview = not GameData.IsReviewFinished() and GameData.IsReviewUnlocked()
	--self._ui.ButtonReview:SetActive(hasReview)
end

function PlanetCtrl:CheckWeeklyReport()
	if GameData.HasNewWeeklyReport() then
		CtrlManager.OpenPanel(CtrlNames.WeeklyReport)
		return true
	else
		return false
	end
end

function PlanetCtrl:CloseToSpaceTravel(seasonId)
	CtrlManager.OpenPanel(CtrlNames.SpaceTravel, {season = seasonId})
	CtrlManager.OpenPanel(CtrlNames.SpaceTravelMain, {season = seasonId})
end

function PlanetCtrl:OnSpaceTravelOpen(params)
	local host = CtrlManager.GetCtrlByName(CtrlNames.SpaceTravel)
	local ctrl = CtrlManager.GetCtrlByName(CtrlNames.SpaceTravelMain)
	ctrl:StartCheck(host)
end

function PlanetCtrl:UpdateGroupButtons(deltaTime)
	PlanetPanel.UpdateCollocateAnim(self._ui, deltaTime)
	self:UpdateUIPackageTime()
end

function PlanetCtrl:CheckModules()
	for k, _ in pairs(self._ui.Modules) do
		self:CheckModule(k)
	end
end

function PlanetCtrl:CheckModule(moduleName)
	--XDebug.Log("LZ", "moduleName:", moduleName)
	local v = self._ui.Modules[moduleName]
	assert(v ~= nil, "not found module: "..tostring(moduleName))

	local unlocked = GameData.IsModuleUnlocked(moduleName)

	local preShow = v.item.activeSelf

	if unlocked then
		if moduleName == ModuleNames.Tourist then
			unlocked = GameData.HasValidTourist()
		elseif moduleName == ModuleNames.SpaceTravel then
			unlocked = GameData.IsSpaceTravelSeasonOn()
		end
	end

	v.item:SetActive(unlocked)

	if unlocked and moduleName == ModuleNames.Tourist then
		if not preShow then
			self._ui.TouristAnimator:Play("In", 0, 0)
		end
	end

	if v.generalHint ~= nil then
		local showGeneral = unlocked and self:HasGeneralHint(moduleName)
		v.generalHint:SetActive(showGeneral)
	end

	return unlocked
end

function PlanetCtrl:HasGeneralHint(moduleName)
	if moduleName == ModuleNames.Mission then
		return GameData.HasCompletedGoalOfType(GoalType.Main) or GameData.IsItemNew(ModuleNames.Demand)
	elseif moduleName == ModuleNames.WorkShop then
		return GameData.HasCompletedWorkShop()
	elseif moduleName == ModuleNames.CharacterList then
		return GameData.HasNewOfType(ItemType.Character) or GameData.HasMatchedCharacterToPromote()
	elseif moduleName == ModuleNames.Gallery then
		return GameData.HasUnlockedPostcard()
	elseif moduleName == ModuleNames.Warehouse then
		return GameData.HasNewOfType(ItemType.Goods)
	elseif moduleName == ModuleNames.Summon then
		return GameData.HasEventPool()
	elseif moduleName == ModuleNames.Newbie then
		return GameData.HasCompletedGoalOfType(GoalType.Newbie)
	end

	return false
end

--初始化展开按钮
function PlanetCtrl:InitGroupButtons()
	-- default data
	self._groupData = {
		packageId = nil,
		isNewPackage = false,
	}
	self._groupHideHandle = nil

	local view = self._ui
	self.groupButtons = {view.ButtonOption
	,view.ButtonSignIn
	,view.ButtonNotice
	,view.ButtonMail
	,view.ButtonWeekly
	,view.ButtonPackage}
	PlanetPanel.InitCollocateButtons(view.GroupBG, self.groupButtons);
	self:UpdatePackageData()

	--默认打开
	self:OpenCollocateGroup()
end

function PlanetCtrl:OpenCollocateGroup()
	local view = self._ui
	self:UpdateUICollocateButtons()
	PlanetPanel.RefreshCollocatePosition()
	PlanetPanel.OpenCollocateButtons(view, function()
		self:RefreshGroupHint()
	end)
end

function PlanetCtrl:CloseCollocateGroup()
	local view = self._ui
	PlanetPanel.CloseCollocateButtons(view, function()
		self:RefreshGroupHint()
	end)
end

--更新展开按钮
function PlanetCtrl:UpdateUICollocateButtons()
	for i,v in ipairs(self.groupButtons) do
		self:UpdateUICollocateButton(v)
	end
end

--更新展开按钮
function PlanetCtrl:UpdateUICollocateButton(go)
	local view = self._ui
	if go == view.ButtonPackage then
		view.PackageHint:SetActive(self._groupData.isNewPackage)
		PlanetPanel.SetCollocateVisible(go, self._groupData.packageId ~= nil)
	end
end

function PlanetCtrl:OnPackageChanged()

	self:UpdatePackageData()

	self:UpdateUICollocateButton(self._ui.ButtonPackage)
	self:UpdateUIPackageTime()

	PlanetPanel.RefreshCollocatePosition()
	PlanetPanel.SyncCollocateButtons()

	self:RefreshGroupHint()
end

function PlanetCtrl:UpdateUIPackageTime()
	local packageId = self._groupData.packageId
	if not packageId then
		return
	end
	if PlanetPanel.collocateState == EnumCollocateState.Closed then
		return
	end
	local endTime = self._groupData.packageEndTime
	local curTime = GameData.GetServerTime()
	local leftTime = math.max(endTime - curTime, 0)
	if leftTime == 0 then
		self._ui.PackageLabel.text = SAFE_LOC("礼包")
		PlanetPanel.SetCollocateLineCount(self._ui.ButtonPackage, 1)
		self:OnPackageChanged()
	else
		self._ui.PackageLabel.text = SAFE_LOC("礼包\n")..Helper.FormatTime(leftTime)
		PlanetPanel.SetCollocateLineCount(self._ui.ButtonPackage, 2)
	end
end

function PlanetCtrl:CheckNewPackage()
	self._ui.PackageHint:SetActive(false)
	if self._groupData.isNewPackage then
		-- checked
		self._groupData.isNewPackage = false
		GameData.RecordPackage(self._groupData.packageId)
	end
end

function PlanetCtrl:CheckPackageAndGroupHint()
	local currentPackageId = self._groupData.packageId
	local activePackageId = GameData.GetActivePackage()
	if currentPackageId ~= activePackageId then
		self:OnPackageChanged()
	else
		self:RefreshGroupHint()
	end
end

function PlanetCtrl:RefreshGroupHint()
	local view = self._ui
	if PlanetPanel.collocateState == EnumCollocateState.Closed then
		view.GroupHint:SetActive(self:HasAnyHintInGroup())
	else
		view.GroupHint:SetActive(false)
	end
end

--按钮组里有至少有一个需要提示
function PlanetCtrl:HasAnyHintInGroup()
	if GameData.ShowBulletinHit() then
		return true
	end
	if GameData.HasNewMail() then
		return true
	end
	if GameData.HasSignInReward() then
		return true
	end
	if GameData.HasMonthCardReward() then
		return true
	end
	if not GameData.IsAccountNicknameBinded() then
		return true
	end
	if GameData.HasNewWeeklyReport() then
		return true
	end
	if self._groupData.isNewPackage then
		return true
	end
	return false
end

--更新礼包数据
function PlanetCtrl:UpdatePackageData()
	local activePackageId, activePackageEndTime = GameData.GetActivePackage()
	local lastCheckPackageId = GameData.GetLastPackageId()
	-- set data
	self._groupData.packageId = activePackageId
	self._groupData.packageEndTime = activePackageEndTime
	self._groupData.isNewPackage = (activePackageId and activePackageId ~= lastCheckPackageId)
end

function PlanetCtrl:JumpTo(jumpParam)
	local dstCtrl = jumpParam.ctrlName

	if dstCtrl == CtrlNames.GalleryDiary then
		-- gallery
		local postcardId = jumpParam.ctrlParameter
		local galleryId = ConfigUtils.GetGalleryOfPostcard(postcardId)
		CtrlManager.OpenPanel(CtrlNames.GalleryPlanet)
		CtrlManager.OpenPanel(CtrlNames.GalleryDetail, {galleryId = galleryId})
		CtrlManager.OpenPanel(CtrlNames.GalleryDiary, {galleryId = galleryId, itemType = ItemType.Postcard})
	elseif dstCtrl == CtrlNames.Planet then
		-- self
		local planetId = jumpParam.ctrlParameter
		if ConfigUtils.IsValidItem(planetId) then
			self:SwitchPlanet(planetId)
		end
	elseif dstCtrl == CtrlNames.ExploreGuide then
		local exploreId = jumpParam.ctrlParameter
		local exploreType = ConfigUtils.GetItemTypeFromId(exploreId)
		local planetId = exploreId
		if exploreType == ItemType.PlanetArea then
			planetId = ConfigUtils.GetPlanetOfArea(exploreId)
		end
		self:SwitchPlanet(planetId)
		if planetId == self._currentPlanetId then
			CtrlManager.OpenPanel(CtrlNames.ExploreGuide, {exploreId = exploreId})
		end
	elseif dstCtrl == CtrlNames.Summon then
		local summonId = jumpParam.ctrlParameter
		CtrlManager.OpenPanel(CtrlNames.Summon, {summonId = summonId})
	elseif dstCtrl == CtrlNames.CharacterList then
		local characterId = jumpParam.ctrlParameter
		CtrlManager.OpenPanel(CtrlNames.CharacterList, {characterId = characterId})
	elseif dstCtrl == CtrlNames.Laboratory then
		local labRecipeId = jumpParam.ctrlParameter
		CtrlManager.OpenPanel(CtrlNames.Laboratory, {targetRecipeId = labRecipeId})
	elseif dstCtrl == CtrlNames.Goal then
		local mode = jumpParam.ctrlParameter
		CtrlManager.OpenPanel(CtrlNames.Goal, {mode = mode})
	elseif dstCtrl == CtrlNames.ExploreCharacter then
		local itemId = jumpParam.ctrlParameter
		local itemType = ConfigUtils.GetItemTypeFromId(itemId)
		if itemType == ItemType.PlanetArea then
			CtrlManager.OpenPanel(CtrlNames.ExploreGuide, {exploreId = itemId})
			CtrlManager.OpenPanel(CtrlNames.ExploreCharacter, {areaId = itemId})
		elseif itemType == ItemType.Challenge then
			CtrlManager.OpenPanel(CtrlNames.ExploreCharacter, {challengeId = itemId})
		else
			assert(false, "un-handled item type: "..tostring(itemType))
		end
	elseif dstCtrl == CtrlNames.ExploreChallenge then
		local challengeId = jumpParam.ctrlParameter
		local areaId = ConfigUtils.GetAreaOfChallenge(challengeId)
		CtrlManager.OpenPanel(CtrlNames.ExploreGuide, {exploreId = areaId})
		CtrlManager.OpenPanel(CtrlNames.ExploreChallenge, {challengeId = challengeId})
	else
		CtrlManager.OpenPanel(dstCtrl)
	end
end

function PlanetCtrl:OnGroupButtonShowTimeUp()
	self._groupHideHandle = nil
	self:CloseCollocateGroup(self._ui)
end

function PlanetCtrl:CancelGroupHideHandle()
	if self._groupHideHandle ~= nil then
		GlobalScheduler:Cancel(self._groupHideHandle)
		self._groupHideHandle = nil
	end
end

function PlanetCtrl:ResetGroupHide()
	if self._groupHideHandle ~= nil then
		GlobalScheduler:Cancel(self._groupHideHandle)
		self._groupHideHandle = GlobalScheduler:DoActionAfterTime(GROUP_SHOW_TIME, PlanetCtrl.OnGroupButtonShowTimeUp, self)
	end
end

local _isRealNameNoticed = false
function PlanetCtrl:CheckRealName(firstEnter)
	local dirty = false

	-- 开发模式 不需要检测实名
	if Util.IsEditor then
		return dirty
	end

	if not GameData.EnableRealName() then
		GameData.SetCanStepPlayTime(true)
		return dirty
	end

	local canStep = true
	if GameData.IsGuestAccount() then
		local curTime = GameData.GetServerTime()
		local date = os.date("*t", curTime)
		if not GameData.IsAccountVerified() and not GameData.IsGuestAvailableTime(date.hour) then
			dirty = true
			canStep = false
			CtrlManager.ShowMessageBox({message = SAFE_LOC("每日22时到次日8时，不会为游客提供游戏服务！"), single = true, onConfirm = PlanetCtrl.HandleForceRealName, receiver = self})
		else
			local totalTime = GameData.GetSumPlayTime()
			if totalTime < RealNameData.GuestTimeLimit then
				if firstEnter then
					dirty = true
					CtrlManager.ShowMessageBox({message = SAFE_LOC("由于当前是游客模式，您已被纳入防沉迷系统，每日累计游玩1小时后将被系统强制下线，请进行实名认证。"), single = false, onConfirm = PlanetCtrl.HandleRealName, receiver = self})
				end
			else
				if firstEnter or GameData.IsRestrictRealName() or not _isRealNameNoticed then
					_isRealNameNoticed = true
					dirty = true
					CtrlManager.ShowMessageBox({message = SAFE_LOC("由于当前是游客模式，您已被纳入防沉迷系统，每日累计游玩1小时后将被系统强制下线，请进行实名认证。"), single = true, onConfirm = PlanetCtrl.HandleForceRealName, receiver = self})
				end
			end
		end
	else
		local age = GameData.GetAccountAge()
		if age < RealNameData.UnderAge1 then
			local curTime = GameData.GetServerTime()
			local date = os.date("*t", curTime)
			if not GameData.IsUnderageAvailableTime(date.hour) then
				dirty = true
				canStep = false
				CtrlManager.ShowMessageBox({message = SAFE_LOC("每日22时到次日8时，不会为未成年人提供游戏服务！"), single = true, onConfirm = Game.Restart})
			else
				local todayTime = GameData.GetTodayPlayTime()
				local timeLimit = GameData.GetUnderageDayTimeLimit(date.wday)
				if todayTime >= timeLimit then
					dirty = true
					canStep = false
					CtrlManager.ShowMessageBox({message = SAFE_LOC("未成年人每日累计游戏时长已达上限，请下线休息！"), single = true, onConfirm = Game.Restart})
				end
			end
		end
	end
	-- can update play time now
	GameData.SetCanStepPlayTime(canStep)

	return dirty
end
----------------------------------------------------------------------------------------------------------------------------