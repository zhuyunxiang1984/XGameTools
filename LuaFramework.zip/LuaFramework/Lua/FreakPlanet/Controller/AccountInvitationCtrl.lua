require "FreakPlanet/View/AccountInvitationPanel"

local class = require "FreakPlanet/Utils/middleclass"
AccountInvitationCtrl  = class(CtrlNames.AccountInvitation, BaseCtrl)

-- load the ui prefab
function AccountInvitationCtrl:LoadPanel()
	self:CreatePanel("AccountInvitation")
end

-- construct ui panel data
function AccountInvitationCtrl:ConstructUI(obj)
	self._ui = AccountInvitationPanel.Init(obj)
end

-- fill ui with the data
function AccountInvitationCtrl:SetupUI()
	CtrlManager.AddClick(self, self._ui.Blocker)
	CtrlManager.AddClick(self, self._ui.ButtonConfirm)
end

-- on clicked
function AccountInvitationCtrl:OnClicked(go)
	if go == self._ui.Blocker then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
	elseif go == self._ui.ButtonConfirm then
		local code = self._ui.InvitationCodeSafeInput:GetText()
		if Helper.IsEmptyOrNull(code) then
			SoundSystem.PlayWarningSound()
			CtrlManager.ShowMessageBox({message = SAFE_LOC("请输入邀请码"), single = true})
			return true
		end

		SoundSystem.PlayUIClickSound()
		CtrlManager.PopPanel()
		self._parameter.callback(self._parameter.receiver, code)
	end

	return true
end
