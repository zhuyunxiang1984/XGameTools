require "FreakPlanet/View/FullStarChallengePanel"

local class = require "FreakPlanet/Utils/middleclass"
FullStarChallengeCtrl  = class(CtrlNames.FullStarChallenge, BaseCtrl)

-- load the ui prefab
function FullStarChallengeCtrl:LoadPanel()
	self:CreatePanel("FullStarChallenge")
end

-- construct ui panel data
function FullStarChallengeCtrl:ConstructUI(obj)
	self._ui = FullStarChallengePanel.Init(obj)
end

-- destructor
function FullStarChallengeCtrl:DestroyImpl()
    GameNotifier.RemoveListener(GameEvent.ChallengeFinished, FullStarChallengeCtrl.OnChallengeFinished, self)
end

-- fill ui with the data
function FullStarChallengeCtrl:SetupUI()
    self._planetId = self._parameter.planetId
    self._ui.ChallengeGridWrap.OnItemUpdate = FullStarChallengeCtrl.OnItemUpdateGlobal
    self:SetupChallengeGrid()
	CtrlManager.AddClick(self, self._ui.Blocker)
    GameNotifier.AddListener(GameEvent.ChallengeFinished, FullStarChallengeCtrl.OnChallengeFinished, self)
end

function FullStarChallengeCtrl:SetupChallengeGrid()
    self._challengeList = {}
    local areaList = ConfigUtils.GetPlanetAreaList(self._planetId)
    for idx = 1, #areaList do
        local areaId = areaList[idx]
        local areaChallenges = ConfigUtils.GetAreaChallengeList(areaId)
        for m = 1, #areaChallenges do
            table.insert(self._challengeList, areaChallenges[m])
        end
    end

    -- item count
    local itemCount = self._ui.ChallengeGridWrap.NeedCellCount
    itemCount = math.min(#self._challengeList, itemCount)
    self._ui.ChallengeGridWrap.MaxRow = math.ceil(#self._challengeList / self._ui.ChallengeGridWrap.ColumnLimit)

    for idx = 1, itemCount do
        local challengeId = self._challengeList[idx]
        local challengeObj = Helper.NewObject(self._ui.ChallengeItemTemplate, self._ui.ChallengeGrid)
        challengeObj:SetActive(true)
        challengeObj.name = tostring(challengeId)

        local challengeItem = challengeObj.transform
        local buttonGo = challengeItem:Find("ButtonGo").gameObject
        CtrlManager.AddClick(self, buttonGo)
        -- construct item
        self:ConstructChallengeItem(challengeItem, challengeId)
    end
    -- set position
    self._ui.ChallengeGridWrap:SortBasedOnScrollMovement()
end

function FullStarChallengeCtrl:ConstructChallengeItem(item, itemId)
    local areaId = ConfigUtils.GetAreaOfChallenge(itemId)
    assert(areaId ~= nil, "area challenge should always has area: "..tostring(itemId))

    local lastEnemyId = ConfigUtils.GetLastEnemyOfChallenge(itemId)

    local enemyIcon = item:Find("Icon"):GetComponent("UISprite")
    local nameLabel = item:Find("Name"):GetComponent("UILabel")
    local roundLabel = item:Find("Round"):GetComponent("UILabel")
    local buttonGo = item:Find("ButtonGo").gameObject
    local lockMark = item:Find("Lock").gameObject

    local completed = GameData.IsChallengeCompleted(itemId)
    local maxStar = 0

    nameLabel.text = ConfigUtils.GetChallengeName(itemId)
    UIHelper.SetCharacterIcon(self, enemyIcon, lastEnemyId)
    buttonGo:SetActive(completed)
    lockMark:SetActive(not completed)

    if completed then
        enemyIcon.color = Color.white
        local ms, mr = GameData.GetUnlockedChallengeRecord(itemId)
        maxStar = ms
        if mr > 0 then
            roundLabel.text = string.format("%d回合胜", mr)
        else
            roundLabel.text = ""
        end
    else
        enemyIcon.color = LOCK_ICON_COLOR
        roundLabel.text = ""
    end

    local starRoot = item:Find("Stars")
    for idx = 1, starRoot.childCount do
        local starMatch = (idx <= maxStar)
        local element = starRoot:GetChild(idx - 1)
        local starUnlocked = element:Find("Unlock").gameObject
        local starLocked = element:Find("Lock").gameObject
        starUnlocked:SetActive(starMatch)
        starLocked:SetActive(not starMatch)
    end
end

function FullStarChallengeCtrl:OnItemUpdate(itemObj, itemIndex, itemRealIndex)
    itemRealIndex = itemRealIndex + 1
    if itemRealIndex <= 0 or itemRealIndex > #self._challengeList then
        itemObj:SetActive(false)
    else
        itemObj:SetActive(true)
        local itemId = self._challengeList[itemRealIndex]
        itemObj.name = itemId
        self:ConstructChallengeItem(itemObj.transform, itemId)
    end
end

function FullStarChallengeCtrl.OnItemUpdateGlobal(itemObj, itemIndex, itemRealIndex)
    local ctrl = CtrlManager.GetCtrlByName(CtrlNames.FullStarChallenge)
    if ctrl ~= nil then
        ctrl:OnItemUpdate(itemObj, itemIndex, itemRealIndex)
    end
end

function FullStarChallengeCtrl:OnChallengeFinished(challengeId, firstComplete)
    local item = self._ui.ChallengeGrid:Find(challengeId)
    if item ~= nil then
        self:ConstructChallengeItem(item, challengeId)
    end
end

function FullStarChallengeCtrl:CloseToChallenge(challengeId)
    CtrlManager.OpenPanel(CtrlNames.ExploreCharacter, {challengeId = challengeId})
end

-- on clicked
function FullStarChallengeCtrl:OnClicked(go)

    if go == self._ui.Blocker then
        SoundSystem.PlayWarningSound()
        CtrlManager.PopPanel()
    elseif go.name == "ButtonGo" then
        SoundSystem.PlayUIClickSound()
        local challengeId = tonumber(go.transform.parent.gameObject.name)
        CtrlManager.DoWaitTransition(CtrlNames.ExploreCharacter, self, FullStarChallengeCtrl.CloseToChallenge, challengeId)
    end

	return true
end
