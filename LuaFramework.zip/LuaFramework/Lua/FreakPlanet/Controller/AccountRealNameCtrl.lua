require "FreakPlanet/View/AccountRealNamePanel"

local class = require "FreakPlanet/Utils/middleclass"
AccountRealNameCtrl  = class(CtrlNames.AccountRealName, BaseCtrl)

-- load the ui prefab
function AccountRealNameCtrl:LoadPanel()
	self:CreatePanel("AccountRealName")
end

-- construct ui panel data
function AccountRealNameCtrl:ConstructUI(obj)
	self._ui = AccountRealNamePanel.Init(obj)
end

-- fill ui with the data
function AccountRealNameCtrl:SetupUI()
    self._force = self._parameter.force or false
    self._callback = self._parameter.callback
    self._vcodeTimestamp = nil
    self._ui.ButtonVCode.isEnabled = true
    self._ui.VCodeLeftTime.text = ""
    self._ui.RulePanel:SetActive(false)
    self._ui.ButtonRule:SetActive(GameData.EnableRealName())
	
    CtrlManager.AddClick(self, self._ui.Blocker)
    CtrlManager.AddClick(self, self._ui.ButtonConfirm)
    CtrlManager.AddClick(self, self._ui.ButtonVCode.gameObject)
    CtrlManager.AddClick(self, self._ui.ButtonRule)
    CtrlManager.AddClick(self, self._ui.RuleBlocker)
end

-- update per frame
function AccountRealNameCtrl:UpdateImpl(deltaTime)
    if self._vcodeTimestamp ~= nil then
        local curTime = GameData.GetServerTime()
        local diffTime = curTime - self._vcodeTimestamp
        if diffTime < VCODE_COOLDOWN then
            local leftTime = VCODE_COOLDOWN - diffTime
            self._ui.VCodeLeftTime.text = Helper.GetShortTimeString(leftTime)
        else
            self._ui.ButtonVCode.isEnabled = true
            self._ui.VCodeLeftTime.text = ""
            self._vcodeTimestamp = nil
        end
    end
end

function AccountRealNameCtrl:CheckInput()
    local realName = self._ui.RealName.value
    if Helper.IsEmptyOrNull(realName) then
        SoundSystem.PlayWarningSound()
        CtrlManager.ShowMessageBox({message = SAFE_LOC("名字不能为空"), single = true})
        return false
    end

    local tmpRealName = Helper.StringFindAndReplace(realName, "·", "")
    local filteredRealName = Helper.FilterSpecChinese(tmpRealName)
    if filteredRealName ~= tmpRealName then
        SoundSystem.PlayWarningSound()
        CtrlManager.ShowMessageBox({message = SAFE_LOC("姓名必须全为汉字"), single = true})
        return false
    end

    local id = self._ui.Identity.value
    if Helper.IsEmptyOrNull(id) then
        SoundSystem.PlayWarningSound()
        CtrlManager.ShowMessageBox({message = SAFE_LOC("身份证号不能为空"), single = true})
        return false
    end

    local idState = Helper.CheckIdentity(id)
    if idState ~= IdentityError.None then
        SoundSystem.PlayWarningSound()
        local msg = Helper.GetIdentityErrorText(idState)
        CtrlManager.ShowMessageBox({message = msg, single = true})
        return false
    end

    local phone = self._ui.Phone.value
    if Helper.IsEmptyOrNull(phone) then
        SoundSystem.PlayWarningSound()
        CtrlManager.ShowMessageBox({message = SAFE_LOC("loc_global_cellphone_empty"), single = true})
        return false
    end

    local phoneState = Helper.CheckPhone(phone)
    if phoneState ~= PhoneError.None then
        SoundSystem.PlayWarningSound()
        local msg = Helper.GetPhoneErrorText(phoneState)
        CtrlManager.ShowMessageBox({message = msg, single = true})
        return false
    end

    local vcode = self._ui.VCode.value
    if Helper.IsEmptyOrNull(vcode) then
        SoundSystem.PlayWarningSound()
        CtrlManager.ShowMessageBox({message = SAFE_LOC("loc_global_cellphone_code_empty"), single = true})
        return false
    end

    return true
end

function AccountRealNameCtrl:CheckInputPhone()
    local phone = self._ui.Phone.value
    local phoneState = Helper.CheckPhone(phone)
    if phoneState ~= PhoneError.None then
        SoundSystem.PlayWarningSound()
        local msg = Helper.GetPhoneErrorText(phoneState)
        CtrlManager.ShowMessageBox({message = msg, single = true})
        return false
    end

    return true
end

-- handle the escapse button
function AccountRealNameCtrl:HandleEscape()
    self:OnClicked(self._ui.Blocker)
end

-- can do jump or not
function AccountRealNameCtrl:CanJump()
    return false
end

-- on clicked
function AccountRealNameCtrl:OnClicked(go)

    if go == self._ui.Blocker then
        if not self._force then
            SoundSystem.PlayUICancelSound()
            CtrlManager.PopPanel()
        end
    elseif go == self._ui.ButtonConfirm then
        local valid = self:CheckInput()
        if valid then
            SoundSystem.PlayUIClickSound()
            NetManager.Send("BindRealName", {
                RealName = self._ui.RealName.value,
                IdCard = self._ui.Identity.value,
                Phone = self._ui.Phone.value,
                SMSCode = self._ui.VCode.value,
                NeedVerify = Helper.IsMainlandIdentity(self._ui.Identity.value),
            },
            AccountRealNameCtrl.OnHandleProto, 
            self)
        end
    elseif go == self._ui.ButtonVCode.gameObject then
        local valid = self:CheckInputPhone()
        if valid then
            SoundSystem.PlayUIClickSound()
            NetManager.Send("BindPhoneSmsCode", {
                Phone = self._ui.Phone.value},
                AccountRealNameCtrl.OnHandleProto, 
                self
            )
        end
    elseif go == self._ui.RuleBlocker then
        SoundSystem.PlayUIClickSound()
        self._ui.RulePanel:SetActive(false)
    elseif go == self._ui.ButtonRule then
        SoundSystem.PlayUIClickSound()
        self._ui.RulePanel:SetActive(true)
    end

	return true
end

function AccountRealNameCtrl:OnHandleProto(proto, data, requestData)
    if proto == "BindRealName" then
        GameData.VerifyAccount(requestData.IdCard, requestData.Phone)
        GameData.CheckDefaultAccountSafeState()
        CtrlManager.PopPanel()
        CtrlManager.ShowMessageBox({message = SAFE_LOC("实名认证成功"), single = true, onConfirm = function()
            self:OnComplete()
        end})
        NetManager.SendMailList()
    elseif proto == "BindPhoneSmsCode" then
        self._ui.ButtonVCode.isEnabled = false
        self._vcodeTimestamp = GameData.GetServerTime()
        self._ui.VCodeLeftTime.text = ""
        CtrlManager.ShowMessageBox({message = SAFE_LOC("loc_global_cellphone_code_sent"), single = true})
    end
end

function AccountRealNameCtrl:OnComplete()
    if self._callback then
        self._callback()
    end
end
