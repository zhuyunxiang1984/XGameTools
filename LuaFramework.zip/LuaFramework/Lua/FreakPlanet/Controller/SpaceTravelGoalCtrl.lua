require "FreakPlanet/View/SpaceTravelGoalPanel"

local class = require "FreakPlanet/Utils/middleclass"
SpaceTravelGoalCtrl  = class(CtrlNames.SpaceTravelGoal, BaseCtrl)

local _sid = nil

local SpaceTravelGoalMode = {
    Goal = "Goal",
    Friendliness = "Friendliness",
}

-------------------------------------------------------------------------
local function GoalSortFunc(idA, idB)
    if idA == nil or idB == nil then
        return false
    end

    local stateA = GameData.GetSpaceTravelGoalInfo(_sid, idA)
    local stateB = GameData.GetSpaceTravelGoalInfo(_sid, idB)
    local valueA = (stateA == GoalState.Complete)
    local valueB = (stateB == GoalState.Complete)
    if valueA ~= valueB then
        return valueA
    end

    valueA = GameData.IsNewSpaceTravelGoal(idA)
    valueB = GameData.IsNewSpaceTravelGoal(idB)
    if valueA ~= valueB then
        return valueA
    end

    return idA < idB
end

-------------------------------------------------------------------------
-- load the ui prefab
function SpaceTravelGoalCtrl:LoadPanel()
	self:CreatePanel("SpaceTravelGoal")
end

-- construct ui panel data
function SpaceTravelGoalCtrl:ConstructUI(obj)
	self._ui = SpaceTravelGoalPanel.Init(obj)
end

-- destroy implementation
function SpaceTravelGoalCtrl:DestroyImpl()
    GameData.CleanNewSpaceTravelGoal()
end

-- fill ui with the data
function SpaceTravelGoalCtrl:SetupUI()
    self._seasonId = self._parameter.seasonId
    _sid = self._seasonId
    self._currentMode = SpaceTravelGoalMode.Goal
    self:OnCurrentModeChanged()

    CtrlManager.AddClick(self, self._ui.Blocker)
    CtrlManager.AddClick(self, self._ui.ButtonGoal)
    CtrlManager.AddClick(self, self._ui.ButtonFriendliness)
end

function SpaceTravelGoalCtrl:OnCurrentModeChanged()
    if self._currentMode == SpaceTravelGoalMode.Goal then
        self:SetupGoalItems()
    elseif self._currentMode == SpaceTravelGoalMode.Friendliness then
        self:SetupFriendlienssItems()
    else
        assert(false, "un-handled space travel goal mode: "..tostring(self._currentMode))
    end

    self._ui.GoalRoot:SetActive(self._currentMode == SpaceTravelGoalMode.Goal)
    self._ui.FriendlinessRoot:SetActive(self._currentMode == SpaceTravelGoalMode.Friendliness)
    self._ui.ButtonGoal:GetComponent("UIButton").isEnabled = (self._currentMode ~= SpaceTravelGoalMode.Goal)
    self._ui.ButtonFriendliness:GetComponent("UIButton").isEnabled = (self._currentMode ~= SpaceTravelGoalMode.Friendliness)
end

function SpaceTravelGoalCtrl:SetupGoalItems()
    -- do recycle first
    self:RecycleGoalItems()

    local yOffset = 0
    local missions = GameData.GetSpaceTravelGoalsOfSeason(self._seasonId)
    table.sort(missions, GoalSortFunc)

    for idx = 1, #missions do
        local goalItem = nil
        if self._ui.GoalItemPool.childCount == 0 then
            local goalItemObj = Helper.NewObject(self._ui.GoalItemTemplate, self._ui.GoalItemRoot)
            goalItem = goalItemObj.transform
            local buttonReward = goalItem:Find("ButtonReward").gameObject
            CtrlManager.AddClick(self, buttonReward)
        else
            goalItem = self._ui.GoalItemPool:GetChild(0)
            goalItem.parent = self._ui.GoalItemRoot
        end
        
        goalItem.gameObject:SetActive(true)
        goalItem.gameObject.name = tostring(missions[idx])

        -- position
        goalItem.localPosition = Vector3.New(0, yOffset, 0)
        local offset = self:ConstructGoalItem(goalItem, missions[idx])
        yOffset = yOffset + offset
    end

    -- update data here
    self:RefreshGoalData()
    
    self._ui.GoalScrollView:ResetPosition()
    self._ui.GoalEmptyHint:SetActive(#missions == 0)
end

function SpaceTravelGoalCtrl:ConstructGoalItem(goalItem, goalId)
    local taskItemTemplate = nil

    local conditions = ConfigUtils.GetGoalConditions(goalId)
    local goalState, goalNumber = GameData.GetSpaceTravelGoalInfo(self._seasonId, goalId)
    local taskNum = #goalNumber
    assert(taskNum > 0, "goal condition number of goal: "..tostring(goalId).." is 0")
    local totalHeight = self._ui.TaskItemGap * taskNum + 55

    local expandableBG = goalItem:Find("ExpandableBG"):GetComponent("UISprite")
    expandableBG.height = totalHeight

    local goalTitle = goalItem:Find("GoalTitle"):GetComponent("UILabel")
    goalTitle.text = ConfigUtils.GetGoalName(goalId)

    local rewardBG = goalItem:Find("RewardBG"):GetComponent("UISprite")
    local pos = rewardBG.transform.localPosition
    pos.y = -totalHeight
    rewardBG.transform.localPosition = pos

    local rewards = ConfigUtils.GetGoalReward(goalId)
    local rewardRoot = goalItem:Find("RewardBG")
    for idx = 1, rewardRoot.childCount do
        local rewardItem = rewardRoot:GetChild(idx - 1)
        local hasReward = (idx <= #rewards)
        rewardItem.gameObject:SetActive(hasReward)
        if hasReward then
            local rewardItemId = rewards[idx].Value
            local rewardItemNum = rewards[idx].Num
            -- content
            local rewardLabel = rewardItem:Find("Content"):GetComponent("UILabel")
            rewardLabel.text = UIHelper.ConstructGoalRewardContent(rewardItemId, rewardItemNum)
            -- icon
            UIHelper.ConstructItemIconAndNum(self, rewardItem, rewardItemId, rewardItemNum)
        end
    end

    local taskRoot = goalItem:Find("Tasks")
    for idx = 1, taskRoot.childCount do
        local taskItemRoot = taskRoot:GetChild(idx - 1)
        local taskItem = taskItemRoot:Find("Task")

        -- the first one
        if taskItemTemplate == nil then
            taskItemTemplate = taskItem.gameObject
        end

        if idx <= taskNum then
            if taskItem == nil then
                if self._ui.TaskItemPool.childCount == 0 then
                    local taskItemObj = Helper.NewObject(taskItemTemplate, taskItemRoot)
                    taskItemObj.name = "Task"
                    taskItemObj:SetActive(true)
                    taskItem = taskItemObj.transform
                else
                    taskItem = self._ui.TaskItemPool:GetChild(0)
                    taskItem.parent = taskItemRoot
                    taskItem.localPosition = Vector3.zero
                end
            end

            self:ConstructTaskItem(taskItem, goalId, idx, conditions[idx], goalNumber[idx])
        else
            if taskItem ~= nil then
                taskItem.parent = self._ui.TaskItemPool
            end
        end
    end

    local boxCollider = goalItem:GetComponent("BoxCollider")
    local center = boxCollider.center
    center.y = -expandableBG.height / 2
    boxCollider.center = center

    local size = boxCollider.size
    size.y = expandableBG.height
    boxCollider.size = size

    return -120 - expandableBG.height
end

function SpaceTravelGoalCtrl:ConstructTaskItem(taskItem, goalId, taskIdx, conditionData, curNum)
    local name = taskItem:Find("Name"):GetComponent("UILabel")
    local num = taskItem:Find("Num"):GetComponent("UILabel")
    local bg = taskItem:Find("BG"):GetComponent("UISprite")

    local finalName = UIHelper.GetGoalFinalName(conditionData)
    name.text = finalName
    num.text = UIHelper.GetGoalShowNum(conditionData, curNum)

    if Helper.IsEvenNumber(taskIdx) then
        bg.color = Color.New(64 /255, 63 / 255, 83 / 255, 1)
    else
        bg.color = Color.New(52 /255, 51 / 255, 69 / 255, 1)
    end

    -- TODO
    --UIHelper.ConstructGoalIcon(self, taskItem, goalId, conditionData)
end

function SpaceTravelGoalCtrl:SetupFriendlienssItems()
    if self._ui.FriendlinessGrid.childCount > 0 then
        return
    end

    local friendlinessList = ConfigUtils.GetSpaceTravelFriendlinessList()
    for idx = 1, #friendlinessList do
        local friendlinessId = friendlinessList[idx]
        local itemObj = Helper.NewObject(self._ui.FriendlinessItemTemplate, self._ui.FriendlinessGrid)
        itemObj:SetActive(true)
        itemObj.name = tostring(friendlinessId)

        self:ConstructFriendlinessItem(itemObj.transform, friendlinessId)
    end

    self._ui.FriendlinessGrid:GetComponent("UIGrid"):Reposition()
end

function SpaceTravelGoalCtrl:ConstructFriendlinessItem(item, itemId)
    local friendlinessValue = GameData.GetSpaceTravelItemNum(self._seasonId, itemId)
    local maxValue = ConfigUtils.GetSpaceTravelFriendlinessMax(itemId)

    local nameLabel = item:Find("Name"):GetComponent("UILabel")
    local numLabel = item:Find("Value"):GetComponent("UILabel")
    local progress = item:Find("Progress"):GetComponent("UISprite")
    local icon = item:Find("Icon"):GetComponent("UISprite")

    icon.spriteName = ConfigUtils.GetSpaceTravelFriendlinessIcon(itemId)
    nameLabel.text = ConfigUtils.GetSpaceTravelFriendlinessName(itemId)
    numLabel.text = string.format("%d/%d", friendlinessValue, maxValue)
    progress.fillAmount = friendlinessValue / maxValue
end

function SpaceTravelGoalCtrl:RefreshGoalData()
    for idx = 1, self._ui.GoalItemRoot.childCount do
        local goalItem = self._ui.GoalItemRoot:GetChild(idx - 1)
        local goalId = tonumber(goalItem.gameObject.name)
        local conditions = ConfigUtils.GetGoalConditions(goalId)
        local goalState, goalNumber = GameData.GetSpaceTravelGoalInfo(self._seasonId, goalId)

        local buttonReward = goalItem:Find("ButtonReward").gameObject
        local buttonRewardLabel = goalItem:Find("ButtonReward/Label"):GetComponent("UILabel")
        buttonReward:SetActive(goalState == GoalState.Complete)
        if goalState == GoalState.Complete then
            local isSubmitGoods = ConfigUtils.IsSubmitGoodsGoal(goalId)
            if isSubmitGoods then
                buttonRewardLabel.text = SAFE_LOC("loc_Submit")
            else
                buttonRewardLabel.text = SAFE_LOC("loc_Reward")
            end
        end
        -- complete mark
        local completeMark = goalItem:Find("Mark/Complete").gameObject
        completeMark:SetActive(goalState == GoalState.Complete)
        -- new mark
        local newMark = goalItem:Find("Mark/New").gameObject
        newMark:SetActive(GameData.IsNewSpaceTravelGoal(goalId))
        -- tasks
        local taskRoot = goalItem:Find("Tasks")
        for idx = 1, taskRoot.childCount do
            local taskItemRoot = taskRoot:GetChild(idx - 1)
            local taskItem = taskItemRoot:Find("Task")
            if taskItem ~= nil then
                local num = taskItem:Find("Num"):GetComponent("UILabel")
                num.text = UIHelper.GetGoalShowNum(conditions[idx], goalNumber[idx])
            end
        end
    end
end

function SpaceTravelGoalCtrl:RecycleGoalItems()
    for idx = self._ui.GoalItemRoot.childCount, 1, -1 do
        local goalItem = self._ui.GoalItemRoot:GetChild(idx - 1)
        goalItem.parent = self._ui.GoalItemPool
    end
end

-- on clicked
function SpaceTravelGoalCtrl:OnClicked(go)

    if go == self._ui.Blocker then
        SoundSystem.PlayUICancelSound()
        CtrlManager.PopPanel()
    elseif go == self._ui.ButtonGoal then
        SoundSystem.PlaySwitchSound()
        self._currentMode = SpaceTravelGoalMode.Goal
        self:OnCurrentModeChanged()
    elseif go == self._ui.ButtonFriendliness then
        SoundSystem.PlaySwitchSound()
        self._currentMode = SpaceTravelGoalMode.Friendliness
        self:OnCurrentModeChanged()
    elseif go.name == "ButtonReward" then
        local isValid = CtrlManager.CheckSpaceTravelSeasonValid(self._seasonId, true)
        if not isValid then
            return true
        end
        
        SoundSystem.PlayUIClickSound()
        local goalId = tonumber(go.transform.parent.gameObject.name)
        local goalState = GameData.GetSpaceTravelGoalInfo(self._seasonId, goalId)
        assert(goalState == GoalState.Complete, "state of space travel goal "..tostring(goalId).." is: "..tostring(goalState))
        local seasonData = GameData.GetSpaceTravelSeasonData(self._seasonId)
        local scoreCapId = GameData.GetScoreCapOfSpaceTravelSeason(self._seasonId, seasonData.scoreCap)
        NetManager.Send("STGetGoalReward", {STSeasonID = self._seasonId, STScoreCapID = scoreCapId, GoalId = goalId}, SpaceTravelGoalCtrl.OnHandleProto, self)
    end

	return true
end

function SpaceTravelGoalCtrl:OnHandleProto(proto, data, requestData)
    if proto == "STGetGoalReward" then
        local seasonId = requestData.STSeasonID
        local goalId = requestData.GoalId
        -- consume goods
        if ConfigUtils.IsSubmitGoodsGoal(goalId) then
            local conditions = ConfigUtils.GetGoalConditions(goalId)
            for idx = 1, #conditions do
                local itemId = conditions[idx].Value
                local itemNum = conditions[idx].Num
                GameData.ConsumeSpaceTravelItem(seasonId, itemId, itemNum)
            end
        end
        -- rewards
        local rewards = ConfigUtils.GetGoalReward(goalId)
        rewards = GameData.ConvertSpaceTravelRewardDataFormat(rewards)
        -- show rewards panel
        local parameter = GameData.ConstructSpaceTravelChoiceResultParameter(seasonId, rewards, data)
        CtrlManager.OpenPanel(CtrlNames.SpaceTravelChoiceResult, parameter)
        -- career
        GameData.ModifySpaceTravelCareerData(SpaceTravelCareerType.GoalCompleteCount, 1)
        -- close it
        GameData.CloseSpaceTravelGoal(seasonId, goalId)
        self:SetupGoalItems()
    end
end
