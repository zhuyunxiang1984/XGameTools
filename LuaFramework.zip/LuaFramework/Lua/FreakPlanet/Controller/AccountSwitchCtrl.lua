require "FreakPlanet/View/AccountSwitchPanel"

local class = require "FreakPlanet/Utils/middleclass"
AccountSwitchCtrl  = class(CtrlNames.AccountSwitch, BaseCtrl)

-- load the ui prefab
function AccountSwitchCtrl:LoadPanel()
	self:CreatePanel("AccountSwitch")
end

-- construct ui panel data
function AccountSwitchCtrl:ConstructUI(obj)
	self._ui = AccountSwitchPanel.Init(obj)
end

-- fill ui with the data
function AccountSwitchCtrl:SetupUI()
	self._accountList =  GameData.GetLocalAccountList()
	self._currentAccount = self._parameter.current
	self:SetupAccountGrid()
	
	CtrlManager.AddClick(self, self._ui.Blocker)
	CtrlManager.AddClick(self, self._ui.ButtonCreate)
	CtrlManager.AddClick(self, self._ui.ButtonModifyPassword)
	CtrlManager.AddClick(self, self._ui.ButtonResetPassword)
	CtrlManager.AddClick(self, self._ui.ButtonService)
	-- 有的渠道不允许出现客服按钮
	self._ui.ButtonService:SetActive(Game.ShowService())
	self._ui.Table:Reposition()
end

function AccountSwitchCtrl:GetUnsafeAccountNum()
	local num = 0

	for k, v in pairs(self._accountList) do
		if v.safe ~= nil and not v.safe then
			num = num + 1
		end
	end

	return num
end

function AccountSwitchCtrl:SetupAccountGrid()
	for idx = 1, #self._accountList do
		local accountId = self._accountList[idx].id
		local safe = self._accountList[idx].safe
		local itemObj = Helper.NewObject(self._ui.AccountItemTemplate, self._ui.AccountGrid)
		itemObj:SetActive(true)
		itemObj.name = tostring(accountId)

		CtrlManager.AddClick(self, itemObj)

		self:ConstructAccountItem(itemObj.transform, accountId, safe)
	end

	self._ui.AccountScrollView.restrictWithinPanel = true
	local uiGrid = self._ui.AccountGrid:GetComponent("UIGrid")
	uiGrid:Reposition()
end

function AccountSwitchCtrl:ConstructAccountItem(item, accountId, safe)
	local account = tostring(accountId)
	local nameLabel = item:Find("Name"):GetComponent("UILabel")
	nameLabel.text = WordFilterHelper.FilterSensitiveWord(account)

	local mark = item:Find("Mark").gameObject
	local isDefault = (self._currentAccount == account)
	mark:SetActive(isDefault)

	local safeLabel = item:Find("Safe"):GetComponent("UILabel")
	if safe == nil then
		safeLabel.text = ""
	else
		if safe then
			safeLabel.text = SAFE_LOC("安全")
		else
			safeLabel.text = SAFE_LOC("非安全")
		end
	end
end

function AccountSwitchCtrl:HandleRegister()
	if true then
		self:HandleInvitationCode(nil)
	else
		CtrlManager.OpenPanel(CtrlNames.AccountInvitation, {callback = AccountSwitchCtrl.HandleInvitationCode, receiver = self})
	end
end

function AccountSwitchCtrl:HandleInvitationCode(code)
	CtrlManager.PopPanel() -- close self
	self._parameter.newCallback(self._parameter.receiver, code)
end

-- on clicked
function AccountSwitchCtrl:OnClicked(go)
	if go == self._ui.Blocker then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
	elseif go == self._ui.ButtonCreate then
		local unsafeNum = self:GetUnsafeAccountNum()
		if unsafeNum >= 5 and not Util.IsEditor then
			SoundSystem.PlayWarningSound()
			CtrlManager.ShowMessageBox({message = SAFE_LOC("为保障您的帐户安全\n请为本设备中其余账户绑定身份信息，以免丢失"), single = true})
			return true
		end

		-- create new account
		SoundSystem.PlayUIClickSound()
		CtrlManager.OpenPanel(CtrlNames.AccountRegisterConfirm, {callback = AccountSwitchCtrl.HandleRegister, receiver = self})
	elseif go.transform.parent == self._ui.AccountGrid then
		-- change current account
		SoundSystem.PlayUIClickSound()
		CtrlManager.PopPanel() -- close self
		local newAccount = go.name
		self._parameter.switchCallback(self._parameter.receiver, newAccount)
	elseif go == self._ui.ButtonModifyPassword then
		SoundSystem.PlayUIClickSound()
		CtrlManager.OpenPanel(CtrlNames.AccountPasswordModify)
	elseif go == self._ui.ButtonResetPassword then
		SoundSystem.PlayUIClickSound()
		CtrlManager.OpenPanel(CtrlNames.AccountPasswordReset)
	elseif go == self._ui.ButtonService then
		SoundSystem.PlayUIClickSound()
		Game.OpenService()
	end

	return true
end
