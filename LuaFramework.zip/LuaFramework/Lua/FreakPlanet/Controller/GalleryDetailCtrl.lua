require "FreakPlanet/View/GalleryDetailPanel"

local class = require "FreakPlanet/Utils/middleclass"
GalleryDetailCtrl  = class(CtrlNames.GalleryDetail, BaseCtrl)

-- load the ui prefab
function GalleryDetailCtrl:LoadPanel()
	self:CreatePanel("GalleryDetail")
end

-- construct ui panel data
function GalleryDetailCtrl:ConstructUI(obj)
	self._ui = GalleryDetailPanel.Init(obj)
end

-- destructor 
function GalleryDetailCtrl:DestroyImpl()
    GameNotifier.RemoveListener(GameEvent.GoalChanged, GalleryDetailCtrl.OnGoalChanged, self)
end

-- fill ui with the data
function GalleryDetailCtrl:SetupUI()
    self._galleryId = self._parameter.galleryId

    self:ConstructCollection()

    CtrlManager.AddClick(self, self._ui.Blocker)
    CtrlManager.AddClick(self, self._ui.ButtonCharacter)
    CtrlManager.AddClick(self, self._ui.ButtonPet)
    CtrlManager.AddClick(self, self._ui.ButtonPostcard)
    CtrlManager.AddClick(self, self._ui.ButtonEvent)
    CtrlManager.AddClick(self, self._ui.ButtonGoods)
    CtrlManager.AddClick(self, self._ui.ButtonCouple)
    GameNotifier.AddListener(GameEvent.GoalChanged, GalleryDetailCtrl.OnGoalChanged, self)
end

function GalleryDetailCtrl:ConstructCollection()
    local characterIconName, petIconName, eventIconName = ConfigUtils.GetGalleryDetailIcon(self._galleryId)
	-- gallery info
	self._ui.GalleryIcon.spriteName = ConfigUtils.GetGalleryIcon(self._galleryId)
	self._ui.GalleryName.text = ConfigUtils.GetGalleryName(self._galleryId)

	local galleryPercent = ConfigUtils.CalculateGalleryUnlock(self._galleryId)
	self._ui.GalleryCollectionProgress.fillAmount = galleryPercent
	self._ui.GalleryCollection.text = SAFE_LOC("loc_CollectionProgress").." "..UIHelper.GetShowPercentText(galleryPercent)
	
    -- base total weight
    local baseTotalWeight = (CollectionWeight.Character + CollectionWeight.Skin + CollectionWeight.Equipment + CollectionWeight.RoomPiece)
    -- character
	local characterPercent, characterUnlockNum, characterTotalNum = ConfigUtils.CalculateCharacterUnlock(self._galleryId)
	self._ui.CharacterNum.text = tostring(characterUnlockNum).."/"..tostring(characterTotalNum)
    self._ui.CharacterIcon.spriteName = characterIconName
	-- equipment
	local equipmentPercent, equipmentUnlockNum, equipmentTotalNum = ConfigUtils.CalculateEquipmentUnlock(self._galleryId)
	self._ui.EquipmentNum.text = tostring(equipmentUnlockNum).."/"..tostring(equipmentTotalNum)
	-- skin
	local skinPercent, skinUnlockNum, skinTotalNum = ConfigUtils.CalculateSkinUnlock(self._galleryId)
	self._ui.SkinNum.text = tostring(skinUnlockNum).."/"..tostring(skinTotalNum)
    -- room piece
    local roomPiecePercent, roomPieceUnlockNum, roomPieceTotalNum = ConfigUtils.CalculateRoomPieceUnlock(self._galleryId)
    self._ui.RoomPieceNum.text = tostring(roomPieceUnlockNum).."/"..tostring(roomPieceTotalNum)
	-- base collection
    local basePercent = 0
    basePercent = basePercent + characterPercent * CollectionWeight.Character / baseTotalWeight
    basePercent = basePercent + equipmentPercent * CollectionWeight.Equipment / baseTotalWeight
    basePercent = basePercent + skinPercent * CollectionWeight.Skin / baseTotalWeight
    basePercent = basePercent + roomPiecePercent * CollectionWeight.RoomPiece / baseTotalWeight
	self._ui.BaseCollection.text = SAFE_LOC("loc_CollectionProgress").." "..UIHelper.GetShowPercentText(basePercent)
	-- pet
	local petPercent, petUnlockNum, petTotalNum = ConfigUtils.CalculatePetsUnlock(self._galleryId)
    self._ui.PetEmpty:SetActive(petTotalNum == 0)
    self._ui.PetContent:SetActive(petTotalNum > 0)
    if petTotalNum > 0 then
	    self._ui.PetNum.text = tostring(petUnlockNum).."/"..tostring(petTotalNum)
	    self._ui.PetCollection.text = SAFE_LOC("loc_CollectionProgress").." "..UIHelper.GetShowPercentText(petPercent)
        self._ui.PetIcon.spriteName = petIconName
    end
	-- post card
	local cardPercent, cardUnlockNum, cardTotalNum = ConfigUtils.CalculatePostcardUnlock(self._galleryId)
    self._ui.PostcardEmpty:SetActive(cardTotalNum == 0)
    self._ui.PostcardContent:SetActive(cardTotalNum > 0)
    if cardTotalNum > 0 then
        self._ui.PostcardNum.text = tostring(cardUnlockNum).."/"..tostring(cardTotalNum)
        self._ui.PostcardCollection.text = SAFE_LOC("loc_CollectionProgress").." "..UIHelper.GetShowPercentText(cardPercent)
        local hasHint = GameData.HasUnlockedPostcardOfGallery(self._galleryId)
        self._ui.PostcardHint:SetActive(hasHint)
    end
	-- event
	local eventPercent, eventUnlockNum, eventTotalNum = ConfigUtils.CalculateEventUnlock(self._galleryId)
    self._ui.EventEmpty:SetActive(eventTotalNum == 0)
    self._ui.EventContent:SetActive(eventTotalNum > 0)
    if eventTotalNum > 0 then
        self._ui.EventNum.text = tostring(eventUnlockNum).."/"..tostring(eventTotalNum)
        self._ui.EventCollection.text = SAFE_LOC("loc_CollectionProgress").." "..UIHelper.GetShowPercentText(eventPercent)
        self._ui.EventIcon.spriteName = eventIconName
    end
    -- goods
    local goodsPercent, goodsUnlockNum, goodsTotalNum = ConfigUtils.CalculateGoodsUnlock(self._galleryId)
    self._ui.GoodsEmpty:SetActive(goodsTotalNum == 0)
    self._ui.GoodsContent:SetActive(goodsTotalNum > 0)
    if goodsTotalNum > 0 then
        self._ui.GoodsNum.text = tostring(goodsUnlockNum).."/"..tostring(goodsTotalNum)
        self._ui.GoodsCollection.text = SAFE_LOC("loc_CollectionProgress").." "..UIHelper.GetShowPercentText(goodsPercent)
    end
    -- couple
    local couplePercent, coupleUnlockNum, coupleTotalNum = ConfigUtils.CalculateCoupleUnlock(self._galleryId)
    self._ui.CoupleContent:SetActive(true)
    self._ui.CoupleCollection.text = SAFE_LOC("loc_CollectionProgress").." "..UIHelper.GetShowPercentText(couplePercent)
    self._ui.CoupleNum.text = tostring(coupleUnlockNum).."/"..tostring(coupleTotalNum)
end

function GalleryDetailCtrl:OnGoalChanged(goalType)
    if goalType ~= GoalType.Achievement then
        return
    end

    self:ConstructCollection()
end

-- on clicked
function GalleryDetailCtrl:OnClicked(go)

    if go == self._ui.Blocker then
        SoundSystem.PlayUICancelSound()
        CtrlManager.PopPanel()
    elseif go == self._ui.ButtonCharacter then
        SoundSystem.PlayUIClickSound()
		CtrlManager.OpenPanel(CtrlNames.GalleryItemList, {galleryId = self._galleryId, itemType = ItemType.Character})
	elseif go == self._ui.ButtonPet then
		SoundSystem.PlayUIClickSound()
		CtrlManager.OpenPanel(CtrlNames.GalleryItemList, {galleryId = self._galleryId, itemType = ItemType.Pet})
	elseif go == self._ui.ButtonPostcard then
		SoundSystem.PlayUIClickSound()
		CtrlManager.OpenPanel(CtrlNames.GalleryDiary, {galleryId = self._galleryId, itemType = ItemType.Postcard})
	elseif go == self._ui.ButtonEvent then
		SoundSystem.PlayUIClickSound()
		CtrlManager.OpenPanel(CtrlNames.GalleryDiary, {galleryId = self._galleryId, itemType = ItemType.Event})
    elseif go == self._ui.ButtonGoods then
        SoundSystem.PlayUIClickSound()
        CtrlManager.OpenPanel(CtrlNames.GalleryItemList, {galleryId = self._galleryId, itemType = ItemType.Goods})
    elseif go == self._ui.ButtonCouple then
        SoundSystem.PlayUIClickSound()
        CtrlManager.OpenPanel(CtrlNames.GalleryCoupleList, {galleryId = self._galleryId, itemType = ItemType.Couple})
    end

	return true
end
