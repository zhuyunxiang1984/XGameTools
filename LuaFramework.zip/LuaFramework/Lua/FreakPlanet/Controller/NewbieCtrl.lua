require "FreakPlanet/View/NewbiePanel"

local class = require "FreakPlanet/Utils/middleclass"
NewbieCtrl  = class(CtrlNames.Newbie, BaseCtrl)

-- load the ui prefab
function NewbieCtrl:LoadPanel()
	self:CreatePanel("Newbie")
end

-- construct ui panel data
function NewbieCtrl:ConstructUI(obj)
	self._ui = NewbiePanel.Init(obj)
end

-- destructor 
function NewbieCtrl:DestroyImpl() 
    GameNotifier.RemoveListener(GameEvent.GoalChanged, NewbieCtrl.OnGoalChanged, self)
end

-- fill ui with the data
function NewbieCtrl:SetupUI()
    self._newbieList = ConfigUtils.GetNewbiewList()
    self._goalList = GameData.GetActiveGoalsOfType(GoalType.Newbie)
    self._newbieGoalMap = self:GetNewbieMapOfCurrentGoals()

    self:SetupNewbieGrid()

    -- hide by default
    self._ui.HintPanel:SetActive(false)

	CtrlManager.AddClick(self, self._ui.Blocker)
    CtrlManager.AddClick(self, self._ui.HintBlocker)

    GameNotifier.AddListener(GameEvent.GoalChanged, NewbieCtrl.OnGoalChanged, self)
end

function NewbieCtrl:GetNewbieMapOfCurrentGoals()
    local ret = {}

    for idx = 1, #self._goalList do
        local goalId = self._goalList[idx]
        local newbieId = ConfigUtils.GetNewbieIdOfGoal(goalId)
        assert(newbieId ~= nil, "no newbie id of goal: "..tostring(goalId))
        if ret[newbieId] ~= nil then
            assert(false, "two active newbie goals have two same newbie id: "..tostring(newbieId))
        end

        ret[newbieId] = goalId
    end

    return ret
end

function NewbieCtrl:IsNewbieUnlocked(newbieId)
    local goalId = self._newbieGoalMap[newbieId]
    if goalId ~= nil then
        return true
    end

    local newbieGoals = ConfigUtils.GetNewbieGoalList(newbieId)
    if #newbieGoals == 0 then
        return false
    end

    local firstGoalId = newbieGoals[1]
    return GameData.IsGoalFinished(firstGoalId)
end

function NewbieCtrl:SetupNewbieGrid()
    for idx = 1, #self._newbieList do
        local newbieId = self._newbieList[idx]
        local newbieUnlocked = self:IsNewbieUnlocked(newbieId)
        if newbieUnlocked then
            local newbieItem = self._ui.NewbieGrid:Find(newbieId)
            if newbieItem == nil then
                local newbieObj = Helper.NewObject(self._ui.NewbieItemTemplate, self._ui.NewbieGrid)
                newbieObj.name = newbieId
                newbieObj:SetActive(true)

                CtrlManager.AddClick(self, newbieObj)
                local buttonReward = newbieObj.transform:Find("Reward").gameObject
                CtrlManager.AddClick(self, buttonReward)

                newbieItem = newbieObj.transform
            end

            self:ConstructNewbieItem(newbieItem, newbieId)
        end
    end

    self._ui.NewbieGrid:GetComponent("UIGrid"):Reposition()
end

function NewbieCtrl:ConstructNewbieItem(item, itemId)
    -- active goal, may nil
    local goalId = self._newbieGoalMap[itemId]

    local titleLabel = item:Find("Title"):GetComponent("UILabel")
    local rewardRoot = item:Find("Reward").gameObject
    local taskNameLabel = item:Find("Task/Name"):GetComponent("UILabel")
    local taskNumLabel = item:Find("Task/Num"):GetComponent("UILabel")
    local hintMark = item:Find("Mark/Hint").gameObject

    rewardRoot:SetActive(goalId ~= nil)

    if goalId == nil then
        titleLabel.text = ConfigUtils.GetNewbieName(itemId)
        taskNameLabel.text = ConfigUtils.GetNewbieDesc(itemId)
        taskNumLabel.text = ""
        hintMark:SetActive(false)
    else
        local conditions = ConfigUtils.GetGoalConditions(goalId)
        local rewards = ConfigUtils.GetGoalReward(goalId)
        assert(#conditions == 1, "goal condition should be only 1, invalid goal: "..tostring(goalId))
        assert(#rewards >= 1, "goal reward is not valid: "..tostring(goalId))
        local goalState, goalNumber = GameData.GetGoalInfo(goalId)

        titleLabel.text = ConfigUtils.GetGoalName(goalId)
        taskNameLabel.text = UIHelper.GetGoalFinalName(conditions[1])
        taskNumLabel.text = UIHelper.GetGoalShowNum(conditions[1], goalNumber[1])
        hintMark:SetActive(goalState == GoalState.Complete)

        local rewardId = rewards[1].Value
        local rewardNum = rewards[1].Num
        UIHelper.ConstructItemIconAndNum(self, rewardRoot.transform, rewardId, rewardNum)
    end
end

-- on clicked
function NewbieCtrl:OnClicked(go)

    if go == self._ui.Blocker then
        SoundSystem.PlayUICancelSound()
        CtrlManager.PopPanel()
    elseif go == self._ui.HintBlocker then
        SoundSystem.PlayUIClickSound()
        self._ui.HintPanel:SetActive(false)
    elseif go.transform.parent == self._ui.NewbieGrid then
        SoundSystem.PlayUIClickSound()
        local newbieId = go.name
        local hintNode = ConfigUtils.GetNewbieHintNode(newbieId)
        for idx = 1, self._ui.HintModuleRoot.childCount do
            local item = self._ui.HintModuleRoot:GetChild(idx - 1).gameObject
            local show = (item.name == hintNode)
            item:SetActive(show)
        end
        self._ui.HintTitle.text = ConfigUtils.GetNewbieName(newbieId)
        self._ui.HintPanel:SetActive(true)
        self._ui.HintScrollView.restrictWithinPanel = true
        self._ui.HintScrollView:ResetPosition()
    elseif go.name == "Reward" then
        local newbieId = go.transform.parent.gameObject.name
        local goalId = self._newbieGoalMap[newbieId]
        if goalId ~= nil then
            local goalState = GameData.GetGoalInfo(goalId)
            if goalState == GoalState.Complete then
                SoundSystem.PlayUIClickSound()
                NetManager.Send("GetGoalReward", {GoalId = goalId, GoalType = GoalType.Newbie}, NewbieCtrl.OnHandleProto, self)
            end
        end
    end

	return true
end

function NewbieCtrl:OnGoalChanged(goalType)
    if goalType ~= GoalType.Newbie then
        return
    end

    -- refresh the goal data
    self._goalList = GameData.GetActiveGoalsOfType(GoalType.Newbie)
    self._newbieGoalMap = self:GetNewbieMapOfCurrentGoals()

    for idx = 1, self._ui.NewbieGrid.childCount do
        local newbieItem = self._ui.NewbieGrid:GetChild(idx - 1)
        local newbieId = newbieItem.gameObject.name
        self:ConstructNewbieItem(newbieItem, newbieId)
    end
end

function NewbieCtrl:OnHandleProto(proto, data, requestData)
    if proto == "GetGoalReward" then
        local goalId = requestData.GoalId
        NavigationCtrl.EnableSuspend(true)
        GameData.FinishGoal(goalId)
        local goldNum = data.RemainGold
        local diamondNum = data.RemainDiamond
        GameData.SetMoney(ItemType.Gold, goldNum)
        GameData.SetMoney(ItemType.Diamond, diamondNum)
    end
end
