require "FreakPlanet/View/GalleryDiaryPanel"

local class = require "FreakPlanet/Utils/middleclass"
GalleryDiaryCtrl  = class(CtrlNames.GalleryDiary, BaseCtrl)
-----------------------------------------------------------------------
local function EventSortFunc(idA, idB)
    if idA == nil or idB == nil then
        return false
    end

    local valueA = ConfigUtils.GetEventSortId(idA)
    local valueB = ConfigUtils.GetEventSortId(idB)

    return valueA < valueB
end

local function PostcardSortFunc(idA, idB)
    if idA == nil or idB == nil then
        return false
    end

    local valueA = ConfigUtils.GetPostcardSortId(idA)
    local valueB = ConfigUtils.GetPostcardSortId(idB)

    return valueA < valueB
end
-----------------------------------------------------------------------
-- load the ui prefab
function GalleryDiaryCtrl:LoadPanel()
	self:CreatePanel("GalleryDiary")
end

-- construct ui panel data
function GalleryDiaryCtrl:ConstructUI(obj)
	self._ui = GalleryDiaryPanel.Init(obj)
end

-- fill ui with the data
function GalleryDiaryCtrl:SetupUI()
    self._galleryId = self._parameter.galleryId
    self._currentItemType = self._parameter.itemType

    self:SetupItemGrid()

    CtrlManager.AddClick(self, self._ui.Blocker)
    CtrlManager.AddClick(self, self._ui.UnlockBlocker)
    self._ui.UnlockPanel:SetActive(false)
    self._ui.ItemGridWrap.OnItemUpdate = GalleryDiaryCtrl.OnItemUpdateGlobal
end

function GalleryDiaryCtrl:SetupItemGrid()
    self._itemList = self:GetItemList()
    local itemTempalte = self:GetItemTemplate()

    -- item count
    local itemCount = self._ui.ItemGridWrap.NeedCellCount
    itemCount = math.min(#self._itemList, itemCount)
    self._ui.ItemGridWrap.MaxRow = math.ceil(#self._itemList / self._ui.ItemGridWrap.ColumnLimit)

    for idx = 1, itemCount do
        local itemId = self._itemList[idx]

        local itemObj = Helper.NewObject(itemTempalte, self._ui.ItemGrid)
        itemObj:SetActive(true)
        itemObj.name = tostring(itemId)

        CtrlManager.AddClick(self, itemObj)

        self:ConstructGridItem(itemObj.transform, itemId)
    end

    self._ui.ItemGridWrap:SortBasedOnScrollMovement()
    self._ui.ItemScrollView:ResetPosition()
    self._ui.ItemScrollView.restrictWithinPanel = true
end

function GalleryDiaryCtrl:GetItemList()
    if self._currentItemType == ItemType.Event then
        local itemList = ConfigUtils.GetEventList(self._galleryId)
        table.sort(itemList, EventSortFunc)
        return itemList
    elseif self._currentItemType == ItemType.Postcard then
        local itemList = ConfigUtils.GetPostcardList(self._galleryId)
        table.sort(itemList, PostcardSortFunc)
        return itemList
    else
        assert(false, "un-handled item type: "..tostring(self._currentItemType))
    end
end

function GalleryDiaryCtrl:GetItemTemplate()
    if self._currentItemType == ItemType.Event then
        return self._ui.EventItemTemplate
    elseif self._currentItemType == ItemType.Postcard then
        return self._ui.PostcardItemTemplate
    else
        assert(false, "un-handled item type: "..tostring(self._currentItemType))
    end
end

function GalleryDiaryCtrl:ConstructGridItem(item, itemId)
    if self._currentItemType == ItemType.Event then
        self:ConstructEventItem(item, itemId)
    elseif self._currentItemType == ItemType.Postcard then
        self:ConstructPostcardItem(item, itemId)
    else
        assert(false, "un-handled item type: "..tostring(self._currentItemType))
    end
end

function GalleryDiaryCtrl:ConstructEventItem(item, itemId)
    local unlocked = GameData.IsEventUnlocked(itemId)

    local lockRoot = item:Find("Lock")
    local unlockRoot = item:Find("Unlock")

    lockRoot.gameObject:SetActive(not unlocked)
    unlockRoot.gameObject:SetActive(unlocked)

    if unlocked then
        -- name
        local nameLabel = unlockRoot:Find("Name"):GetComponent("UILabel")
        nameLabel.text = ConfigUtils.GetEventName(itemId)
        -- icon
        local icon = unlockRoot:Find("Icon"):GetComponent("UI2DSprite")
        local iconName, iconAtlas, iconBundle = ConfigUtils.GetEventIcon(itemId)
        icon.sprite2D = self:DynamicLoadSprite(iconBundle, iconAtlas, iconName)
        
    end
end

function GalleryDiaryCtrl:ConstructPostcardItem(item, itemId)
    local postcardType = ConfigUtils.GetPostcardType(itemId)
    local lockRoot = item:Find("Lock")
    local unlockRoot = item:Find("Unlock")
    local unlocked = false
    local unlockGoal = false
    if postcardType == EnumPostcardType.Achievement then
        unlockGoal = ConfigUtils.GetGoalOfPostcard(itemId)
        unlocked = GameData.IsGoalFinished(unlockGoal)

    elseif postcardType == EnumPostcardType.Activity then
        unlocked = GameData.IsUnlockPoscard(itemId)
    end
    lockRoot.gameObject:SetActive(not unlocked)
    unlockRoot.gameObject:SetActive(unlocked)
    if unlocked then
        local icon = unlockRoot:Find("Icon"):GetComponent("UI2DSprite")
        local iconName, iconAtlas, iconBundle = ConfigUtils.GetPostcardIcon(itemId)
        icon.sprite2D = self:DynamicLoadSprite(iconBundle, iconAtlas, iconName)
    else
        local hintMark = lockRoot:Find("Hint").gameObject
        local goalCompleted = GameData.IsGoalCompleted(unlockGoal)
        hintMark:SetActive(goalCompleted)
    end
end

function GalleryDiaryCtrl:OnItemUpdate(itemObj, itemIndex, itemRealIndex)
    itemRealIndex = itemRealIndex + 1
    if itemRealIndex <= 0 or itemRealIndex > #self._itemList then
        itemObj:SetActive(false)
    else
        itemObj:SetActive(true)
        local itemId = self._itemList[itemRealIndex]
        itemObj.name = itemId
        -- construct item
        self:ConstructGridItem(itemObj.transform, itemId)
    end
end

function GalleryDiaryCtrl.OnItemUpdateGlobal(itemObj, itemIndex, itemRealIndex)
    local ctrl = CtrlManager.GetCtrlByName(CtrlNames.GalleryDiary)
    if ctrl ~= nil then
        ctrl:OnItemUpdate(itemObj, itemIndex, itemRealIndex)
    end
end

-- on clicked
function GalleryDiaryCtrl:OnClicked(go)

    if go == self._ui.Blocker then
        SoundSystem.PlayUICancelSound()
        CtrlManager.PopPanel()
    elseif go == self._ui.UnlockBlocker then
        SoundSystem.PlayUIClickSound()
        self._ui.UnlockPanel:SetActive(false)
        NavigationCtrl.EnableSuspend(false)
        CtrlManager.OpenPanel(CtrlNames.GalleryDiaryDetail, {itemId = self._unlockPostcardId})
    elseif go.transform.parent == self._ui.ItemGrid then
        SoundSystem.PlayUIClickSound()
        local itemId = tonumber(go.name)
        local itemType = ConfigUtils.GetItemTypeFromId(itemId)
        if itemType == ItemType.Postcard then
            local postcardType = ConfigUtils.GetPostcardType(itemId)
            if postcardType == EnumPostcardType.Achievement then
                local goalId = ConfigUtils.GetGoalOfPostcard(itemId)
                local needSettle = not GameData.IsGoalFinished(goalId) and GameData.IsGoalCompleted(goalId)
                if needSettle then
                    NetManager.Send("GetGoalReward", {GoalId = goalId, GoalType = GoalType.Achievement, Postcard = itemId}, GalleryDiaryCtrl.OnHandleProto, self)
                else
                    CtrlManager.OpenPanel(CtrlNames.GalleryDiaryDetail, {itemId = itemId})
                end
            elseif postcardType == EnumPostcardType.Activity then
                CtrlManager.OpenPanel(CtrlNames.GalleryDiaryDetail, {itemId = itemId})
            end
        else
            CtrlManager.OpenPanel(CtrlNames.GalleryDiaryDetail, {itemId = itemId})
        end
    end

	return true
end

--------------------------------------------------------------------
function GalleryDiaryCtrl:OnHandleProto(proto, data, requestData)
    if proto == "GetGoalReward" then
        local goalId = requestData.GoalId
        local postcardId = requestData.Postcard
        NavigationCtrl.EnableSuspend(true)
        GameData.FinishAchievementGoal(goalId)
        local goldNum = data.RemainGold
        local diamondNum = data.RemainDiamond
        local currentDiamond = GameData.GetMoney(ItemType.Diamond)
        GameData.SetMoney(ItemType.Gold, goldNum)
        GameData.SetMoney(ItemType.Diamond, diamondNum)
        GameData.UnlockPostcard(postcardId)

        -- new item
        local rewardDiamond = (diamondNum - currentDiamond)
        self._unlockPostcardId = postcardId
        self._ui.UnlockDiamondReward.text = "x"..tostring(rewardDiamond)
        self._ui.UnlockPanel:SetActive(true)
        self._ui.UnlockTween:ResetToBeginning()
        self._ui.UnlockTween:PlayForward()

        local postcardItem = self._ui.ItemGrid:Find(postcardId)
        if postcardItem ~= nil then
            self:ConstructPostcardItem(postcardItem, postcardId)
        end
    end
end
