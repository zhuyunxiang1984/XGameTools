require "FreakPlanet/View/HomePanel"
require "FreakPlanet/Module/Home/require"
require "FreakPlanet/UI/Home/HomeArrangeLayout"

local class = require "FreakPlanet/Utils/middleclass"
HomeCtrl  = class(CtrlNames.Home, BaseCtrl)

local EnumState = 
{
    Main = 0,
    Arrange = 1,
}

-- load the ui prefab
function HomeCtrl:LoadPanel()
	self:CreatePanel("Home")
end

-- construct ui panel data
function HomeCtrl:ConstructUI(obj)
	self._ui = HomePanel.Init(obj)

    self.m_pArrangeLayout = HomeArrangeLayout:new(self, self._ui.objHomeArrangeLayout)
    self:AddLayout(self.m_pArrangeLayout)
    self.m_OnCameraZoomSliderChanged = EventDelegate.New(EventDelegate.Callback(function()
        self:OnCameraZoomSliderChanged()
    end))
end

-- fill ui with the data
function HomeCtrl:SetupUI()
	local ui = self._ui

	--载入家园
	self.m_pHomeWorld = HomeWorld:new()
	self.m_pHomeWorld:LoadHomeWorld()

    self.m_pHomeWorld:SetCameraZoomPercent(0.5)
    ui.pCameraZoomSlider.value = 0.5
    
    self.m_iState = EnumState.Main

    EventDelegate.Add(ui.pCameraZoomSlider.onChange, self.m_OnCameraZoomSliderChanged)

    self:SetTouch(ui.Blocker)
    
    CtrlManager.AddClick(self, ui.Blocker)
	CtrlManager.AddClick(self, ui.pObjPhone)
	CtrlManager.AddClick(self, ui.pObjFurnish)
	CtrlManager.AddClick(self, ui.pObjPlanet)
    CtrlManager.AddClick(self, ui.btnCleanObstacleConfirm)
    CtrlManager.AddClick(self, ui.btnCleanObstacleCancel)

    GameNotifier.AddListener(GameEvent.HomeWorldCameraMove, self.OnHomeCameraMove, self)
    GameNotifier.AddListener(GameEvent.HomeWorldCameraZoom, self.OnHomeCameraZoom, self)
    
    --
	NetManager.CheckAndFetchCustomPackage()
end
function HomeCtrl:DestroyImpl()
    --GameNotifier.RemoveListener(GameEvent.TouristChanged, HomeCtrl.OnTouristChanged, self)

    GameNotifier.RemoveListener(GameEvent.HomeWorldCameraMove, self.OnHomeCameraMove, self)
    GameNotifier.RemoveListener(GameEvent.HomeWorldCameraZoom, self.OnHomeCameraZoom, self)
    
    if not TutorialManager.IsInTutorial() then
        self._IsInTutorial = false
        self:OnCtrlReady()
    else
        self._IsInTutorial = true
    end

    --
    if self.m_pHomeWorld then
        self.m_pHomeWorld:Term()
        self.m_pHomeWorld = nil
    end
end

-- on clicked
function HomeCtrl:OnClicked(go)
	local ui = self._ui
	if go == ui.pObjPhone then
		SoundSystem.PlayUIClickSound()
		CtrlManager.OpenPanel(CtrlNames.ApplicationCenter)
	elseif go == ui.pObjFurnish then
		SoundSystem.PlayUIClickSound()
        self:EnterArrange()
	elseif go == ui.pObjPlanet then
		SoundSystem.PlayUIClickSound()
		CtrlManager.OpenPanel(CtrlNames.Planet)
	elseif go == ui.pObjExileStreet then
		SoundSystem.PlayUIClickSound()
		CtrlManager.OpenPanel(CtrlNames.Arena)
    elseif go == ui.btnCleanObstacleConfirm then
        if self.m_pSelectObstacle then
            ProtocolManager.CleanHomeObstacle(self.m_pSelectObstacle:GetId())
        end
        self:UnselectCleanObstacle()
    elseif go == ui.btnCleanObstacleCancel then
        self:UnselectCleanObstacle()
    elseif go == ui.Blocker then
        self:OnClickBlocker()
	end
	return true
end

function HomeCtrl:OnClickBlocker()
    local world = self.m_pHomeWorld
    
    local pHitFixedItem = world:RaycastFixedItem(Input.mousePosition)
    if pHitFixedItem then
        if pHitFixedItem:GetId() == HomeUtil.EnumFixItemId.BoxMail then
            CtrlManager.OpenPanel(CtrlNames.FurnitureDeliveryDetail)
        end
        if pHitFixedItem:GetId() == HomeUtil.EnumFixItemId.ExileStreetEntrance then
            self:Close()
            CtrlManager.OpenPanel(CtrlNames.Arena)
        end
        return
    end
    self:UnselectCleanObstacle()
    local pObstacle = world:RaycastObstacle(Input.mousePosition)
    if pObstacle then
        XDebug.Log('GGYY', "hit " .. pObstacle:GetAreaName(), pObstacle:GetGroupName(), pObstacle:GetObstacleName())
        
        self:SelectCleanObstacle(pObstacle)
        return
    end
end

-- handle the escapse button
function HomeCtrl:HandleEscape()
	SoundSystem.PlayUIClickSound()
	if ChannelHelper.UseSdkExit() then
		ScriptBridge.ExitGame()
	else
		CtrlManager.ShowMessageBox({message = SAFE_LOC("loc_QuitGame"), single = false, onConfirm = HomeCtrl.OnQuitConfirm, receiver = self})
	end
end

function HomeCtrl:OnQuitConfirm()
	Game.Quit()
end



function HomeCtrl:UpdateImpl(deltaTime)
	if self.m_pHomeWorld then
		self.m_pHomeWorld:Tick(deltaTime)
	end
	if Input.GetKeyDown(UnityEngine.KeyCode.F2) then
		CtrlManager.OpenPanel(CtrlNames.FurnitureDeliveryDetail)
	end
	if Input.GetKeyDown(UnityEngine.KeyCode.F3) then
		NetManager.Send("HomeShopReward", {}, HomeCtrl.OnHandleProto, self)
	end
end

function HomeCtrl:OnHandleProto(proto, data, requestData)
	if proto == "HomeShopReward" then
		local rewardGoalList = {}
		local rewardList = data.RewardList
		for idx = 1, #rewardList do
			local itemId = rewardList[idx].ItemId
			local num = rewardList[idx].Num
			GameData.CollectItem(itemId, num, true)
			local itemType = ConfigUtils.GetItemTypeFromId(itemId)
			if itemType == ItemType.HomeFurniture then
				local goalData = GameData.SetupItemGoalData(itemId, num)
				table.insert(rewardGoalList, goalData)
				GameDataHome.SetFurnitureBuyHistoryData(itemId, num)
			end
		end
		GameData.DoGoalSettle(TriggerType.HomeFurnitureSellCost, {rewardGoalList})
		GameData.InitFurnitureDeliveryData(data.DeliverList)
		local goldNum = data.RemainGold
		local diamondNum = data.RemainDiamond
		GameData.SetMoney(ItemType.Gold, goldNum)
		GameData.SetMoney(ItemType.Diamond, diamondNum)
		GameData.CheckAndHintGoalsOfCurrentCountType()
	end
end

function HomeCtrl:OnCtrlReady()
	local hasTutorial = self:CheckTutorial(true)
	if hasTutorial then
		return
	end
	if not self:CheckRealName(true) then
		self:CheckWeeklyReport()
	end
end


--- 实名
function HomeCtrl:CheckRealName(firstEnter)
	local dirty = false

	-- 开发模式 不需要检测实名
	if Util.IsEditor then
		return dirty
	end

	if not GameData.EnableRealName() then
		GameData.SetCanStepPlayTime(true)
		return dirty
	end

	local canStep = true
	if GameData.IsGuestAccount() then
		local curTime = GameData.GetServerTime()
		local date = os.date("*t", curTime)
		if not GameData.IsAccountVerified() and not GameData.IsGuestAvailableTime(date.hour) then
			dirty = true
			canStep = false
			CtrlManager.ShowMessageBox({message = SAFE_LOC("每日22时到次日8时，不会为游客提供游戏服务！"), single = true, onConfirm = PlanetCtrl.HandleForceRealName, receiver = self})
		else
			local totalTime = GameData.GetSumPlayTime()
			if totalTime < RealNameData.GuestTimeLimit then
				if firstEnter then
					dirty = true
					CtrlManager.ShowMessageBox({message = SAFE_LOC("由于当前是游客模式，您已被纳入防沉迷系统，每日累计游玩1小时后将被系统强制下线，请进行实名认证。"), single = false, onConfirm = PlanetCtrl.HandleRealName, receiver = self})
				end
			else
				if firstEnter or GameData.IsRestrictRealName() or not _isRealNameNoticed then
					_isRealNameNoticed = true
					dirty = true
					CtrlManager.ShowMessageBox({message = SAFE_LOC("由于当前是游客模式，您已被纳入防沉迷系统，每日累计游玩1小时后将被系统强制下线，请进行实名认证。"), single = true, onConfirm = PlanetCtrl.HandleForceRealName, receiver = self})
				end
			end
		end
	else
		local age = GameData.GetAccountAge()
		if age < RealNameData.UnderAge1 then
			local curTime = GameData.GetServerTime()
			local date = os.date("*t", curTime)
			if not GameData.IsUnderageAvailableTime(date.hour) then
				dirty = true
				canStep = false
				CtrlManager.ShowMessageBox({message = SAFE_LOC("每日22时到次日8时，不会为未成年人提供游戏服务！"), single = true, onConfirm = Game.Restart})
			else
				local todayTime = GameData.GetTodayPlayTime()
				local timeLimit = GameData.GetUnderageDayTimeLimit(date.wday)
				if todayTime >= timeLimit then
					dirty = true
					canStep = false
					CtrlManager.ShowMessageBox({message = SAFE_LOC("未成年人每日累计游戏时长已达上限，请下线休息！"), single = true, onConfirm = Game.Restart})
				end
			end
		end
	end
	-- can update play time now
	GameData.SetCanStepPlayTime(canStep)

	return dirty
end

function HomeCtrl:OnCtrlReady()
	local hasTutorial = self:CheckTutorial(true)
	if hasTutorial then
		return
	end
	if not self:CheckRealName(true) then
		self:CheckWeeklyReport()
	end
end

-- tutorial
function HomeCtrl:CheckTutorial(firstEnter)
	local tutorials = {}

	--[[
	if GameData.IsTutorialNotFinished(Tutorials.Tutorial_1_9) then
		local position = self._ui.Camera:WorldToScreenPoint(self._ui.PlanetCollider.transform.position)
		tutorials[1] = {event = Tutorials.Tutorial_1_1, position = position, sender = self}
	elseif GameData.IsTutorialNotFinished(Tutorials.Tutorial_1_12) then
		local position = self._ui.Camera:WorldToScreenPoint(self._ui.PlanetCollider.transform.position)
		tutorials[1] = {event = Tutorials.Tutorial_EnterMap, position = position, sender = self}
	elseif firstEnter then
		local showGoalHint = false

		if not showGoalHint then
			showGoalHint = GameData.IsTutorialNotFinished(Tutorials.Tutorial_2_6) and GameData.IsGoalCompleted(TutorialConstData.ExploreGoal)
		end

		if not showGoalHint then
			showGoalHint = GameData.IsTutorialNotFinished(Tutorials.Tutorial_2_6) and GameData.IsGoalRunning(TutorialConstData.ChallengeGoal)
		end

		if not showGoalHint then
			showGoalHint = GameData.IsTutorialNotFinished(Tutorials.Tutorial_3_2) and GameData.IsGoalCompleted(TutorialConstData.ChallengeGoal)
		end

		if not showGoalHint then
			showGoalHint =  GameData.IsTutorialNotFinished(Tutorials.Tutorial_5_6) and GameData.IsGoalRunning(TutorialConstData.DemandGoal)
		end

		if not showGoalHint then
			showGoalHint =  GameData.IsTutorialNotFinished(Tutorials.Tutorial_6_3) and GameData.IsGoalRunning(TutorialConstData.EquipmentUpgradeGoal)
		end

		if not showGoalHint then
			showGoalHint =  GameData.IsTutorialNotFinished(Tutorials.Tutorial_7_4) and GameData.IsGoalRunning(TutorialConstData.WorkShopUpgradeGoal)
		end

		if not showGoalHint then
			showGoalHint =  GameData.IsTutorialNotFinished(Tutorials.Tutorial_8_2) and GameData.IsGoalRunning(TutorialConstData.SummonGoal)
		end

		if not showGoalHint then
			showGoalHint =  GameData.IsTutorialNotFinished(Tutorials.Tutorial_9_3) and GameData.IsGoalRunning(TutorialConstData.CraftGoal)
		end

		-- goal hint
		if showGoalHint then
			local buttonGoal = self._ui.Modules[ModuleNames.Mission].item
			local position = self._ui.Camera:WorldToScreenPoint(buttonGoal.transform.position)
			tutorials[1] = {event = Tutorials.Tutorial_PlanetToGoal, position = position, sender = self}
		end
	end

	if #tutorials == 0 then
		local showCharacterHint = GameData.IsTutorialNotFinished(Tutorials.Tutorial_3_2) and GameData.IsGoalRunning(TutorialConstData.CharacterUpgradeGoal)
		if showCharacterHint then
			local buttonGoal = self._ui.Modules[ModuleNames.CharacterList].item
			local position = self._ui.Camera:WorldToScreenPoint(buttonGoal.transform.position)
			tutorials[1] = {event = Tutorials.Tutorial_PlanetToCharacterList, position = position, sender = self}
		end
	end

	-- workshop hint
	if #tutorials == 0 then
		local showWorkShopHint =  GameData.IsTutorialNotFinished(Tutorials.Tutorial_4_4) and GameData.IsGoalRunning(TutorialConstData.WorkShopGoal)
		if showWorkShopHint then
			local buttonGoal = self._ui.Modules[ModuleNames.WorkShop].item
			local position = self._ui.Camera:WorldToScreenPoint(buttonGoal.transform.position)
			tutorials[1] = {event = Tutorials.Tutorial_PlanetToWorkShop, position = position, sender = self}
		end
	end

	if #tutorials == 0 then
		if GameData.IsItemNew(ModuleNames.Tourist) and GameData.HasValidTourist() then
			local buttonTourist = self._ui.Modules[ModuleNames.Tourist].item
			local position = self._ui.Camera:WorldToScreenPoint(buttonTourist.transform.position)
			tutorials[1] = {event = Tutorials.Tutorial_Tourist_1, position = position, sender = self}
		end
	end
--]]
	if #tutorials > 0 then
		self._isShowingTutorial = true
		CtrlManager.ShowTutorials(tutorials)
	end

	return #tutorials > 0
end

function HomeCtrl:HandleForceRealName()
	CtrlManager.OpenPanel(CtrlNames.AccountRealName, {force = GameData.IsRestrictRealName()})
end

function HomeCtrl:HandleRealName()
	CtrlManager.OpenPanel(CtrlNames.AccountRealName)
end

function HomeCtrl:RefreshExileStreet()
	local m_bIsShow = GameData.IsModuleUnlocked(ModuleNames.Arena) or GameData.IsModuleUnlocked(ModuleNames.Activity)
	local m_bIsShowHint =m_bIsShow and (GameData.HasFinishedActivityExplore() or GameData.HasCompletedActivityGoal())
	local m_bIsShowActivityHint = GameData.GetCurrentActivityTheme() ~= nil
end

function HomeCtrl:NotifyFocus()
	local hasTutorial = self:CheckTutorial(false)
	if not hasTutorial and not CtrlManager.IsTutorialGuideOn() then
		if not self:CheckRealName(false) then
			self:CheckWeeklyReport()
		end
	end
end

function HomeCtrl:OnResume()

end

function HomeCtrl:OnTouristChanged()
	self:CheckTourist()
end

function HomeCtrl:CheckWeeklyReport()
	if GameData.HasNewWeeklyReport() then
		CtrlManager.OpenPanel(CtrlNames.WeeklyReport)
		return true
	else
		return false
	end
end

--[[
function HomeCtrl:CheckTourist()
	local unlocked  = GameData.IsModuleUnlocked(ModuleNames.Tourist)
	local preShow = self._ui.m_pTouristBtn.activeSelf
	self._ui.m_pTouristBtn:SetActive(unlocked)
	if unlocked and not preShow then
		self._ui.TouristAnimator:Play("In", 0, 0)
	end
end
--]]

---相机缩放
function HomeCtrl:OnCameraZoomSliderChanged()
    local ui = self._ui
    XDebug.Log('GGYY', "zoom = ", ui.pCameraZoomSlider.value)
    self.m_pHomeWorld:SetCameraZoomPercent(ui.pCameraZoomSlider.value)
end
function HomeCtrl:OnHomeCameraMove()
    if self.m_pSelectObstacle then
        self:UpdateCleanObstacleHudPosition(self.m_pSelectObstacle)
    end
end
function HomeCtrl:OnHomeCameraZoom()
    if self.m_pSelectObstacle then
        self:UpdateCleanObstacleHudPosition(self.m_pSelectObstacle)
    end
end

--------------------------------------------------------------------------
function HomeCtrl:EnterArrange()
    local ui = self._ui
    ui.ButtonGroup:SetActive(false)
    CtrlManager.SetVisible(CtrlNames.Navigation, false)
    if self.m_pSelectObstacle then
        self:UnselectCleanObstacle()
    end
    self.m_pArrangeLayout:Show()
    self.m_iState = EnumState.Arrange
end
function HomeCtrl:LeaveArrange()
    local ui = self._ui
    ui.ButtonGroup:SetActive(true)
    CtrlManager.SetVisible(CtrlNames.Navigation, true)
    self.m_pArrangeLayout:Hide()
    self.m_iState = EnumState.Main
end

function HomeCtrl:OnDrag(deltaTime, point, offset)
    if self.m_iState == EnumState.Main then
        self.m_pHomeWorld:MoveCamera(-offset * deltaTime)
    end
end

function HomeCtrl:GetHomeWorld()
    return self.m_pHomeWorld
end

---清理家具-----------------------------------------------------------------------
function HomeCtrl:SelectCleanObstacle(pObstacle)
    local ui = self._ui
    self.m_pSelectObstacle = pObstacle
    XDebug.Log('GGYY', "选中垃圾 " .. self.m_pSelectObstacle:GetObstacleName())
    
    self:UpdateCleanObstacleHudPosition(pObstacle)
    local view = ui.pViewManager:GetView(ui.objCleanObstacleHud, ui.EnumViewName.CleanObstacleHud)
    local iObstacleId = pObstacle:GetId()
    local listPreNodes = ConfigUtils.GetHomeObstaclePreNodeConfig(iObstacleId)
    if GameDataHome.IsObstaclesAllCleaned(listPreNodes) then
        view.Main:SetActive(true)
        view.Hint:SetActive(false)
        if not view.listHomeCleanItems then
            view.listHomeCleanItems = {view.objHomeCleanItem1 , view.objHomeCleanItem2}
        end
        local listCostItems = ConfigUtils.GetHomeObstacleCostList(iObstacleId)
        self:InitObstacleCostItems(view.listHomeCleanItems, listCostItems)
    else
        --XDebug.LogTable('GGYY', "--前置没有清理完--", listPreNodes)
        view.Main:SetActive(false)
        view.Hint:SetActive(true)
    end
    pObstacle:ShowOutline(true)
    ui.objCleanObstacleHud:SetActive(true)
end
---
function HomeCtrl:InitObstacleCostItems(listItems, listDatas)
    local ui = self._ui
    for i = 1, #listItems do
        local go =  listItems[i]
        if i <= #listDatas then
            local view = self._ui.pViewManager:GetView(go, ui.EnumViewName.HomeCleanItem)
            local data = listDatas[i]
            UIHelper.SetItemIcon(self, view.sprIcon, data.Id)
            view.txtNum.text = "x" .. data.Num
            go:SetActive(true)
        else
            go:SetActive(false)
        end
    end
end

function HomeCtrl:UnselectCleanObstacle()
    local ui = self._ui
    if self.m_pSelectObstacle then
        XDebug.Log('GGYY', "取消选中垃圾 " .. self.m_pSelectObstacle:GetObstacleName())
        self.m_pSelectObstacle:ShowOutline(false)
        self.m_pSelectObstacle = nil
    end
    ui.objCleanObstacleHud:SetActive(false)
end

local _tempPosition = Vector3.zero
function HomeCtrl:UpdateCleanObstacleHudPosition(pObstacle)
    local ui = self._ui
    local world = self.m_pHomeWorld
    local position = pObstacle:GetPosition()
    _tempPosition.x = position.x
    local _,_,_,fMaxY = pObstacle:GetRenderRect()
    _tempPosition.y = position.y + fMaxY
    _tempPosition.z = position.z

    local point = world:WorldToScreenPoint(_tempPosition)
    point = self:ScreenToUIPos(ui.Obj.transform, point)
    point.z = 0
    ui.objCleanObstacleHud.transform.localPosition = point
end 