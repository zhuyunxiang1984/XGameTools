require "FreakPlanet/View/ActivityBattleDetailPanel"

local class = require "FreakPlanet/Utils/middleclass"
ActivityBattleDetailCtrl  = class(CtrlNames.ActivityBattleDetail, BaseCtrl)

-- load the ui prefab
function ActivityBattleDetailCtrl:LoadPanel()
	self:CreatePanel("ActivityBattleDetail")
end

-- construct ui panel data
function ActivityBattleDetailCtrl:ConstructUI(obj)
	self._ui = ActivityBattleDetailPanel.Init(obj)
end

-- fill ui with the data
function ActivityBattleDetailCtrl:SetupUI()
    self._activityThemeId = self._parameter.themeId
    self._battleId = self._parameter.battleId
    self._battleIndex = self._parameter.battleIndex
    -- theme battle title
    self._ui.Title.text = ConfigUtils.GetActivityBattleName(self._battleId)
    -- introduce
    self._ui.Introduce.text = ConfigUtils.GetActivityBattleIntroduction(self._battleId)
    -- support level
    local supportLevel = ConfigUtils.GetActivityBattleSupportLevel(self._battleId)
    self._ui.SupportLevel.text = string.format(SAFE_LOC('loc_SimpleLevel'), supportLevel)
    -- enemy
    local enemyId, enemyLevel = ConfigUtils.GetLastEnemyOfActivityBattle(self._battleId)
    -- icon
    UIHelper.SetCharacterIcon(self, self._ui.EnemyIcon, enemyId)
    -- name
    self._ui.EnemyName.text = ConfigUtils.GetEnemyName(enemyId)
    -- element
    self._ui.EnemyElement.spriteName = ConfigUtils.GetElementIconOfItem(enemyId)
    -- power
    local abilityMap = ConfigUtils.GetEnemyAbilityMap(enemyId, enemyLevel)
    self._ui.EnemyPower.text = ConfigUtils.GetPowerOfAbilityMap(abilityMap)
    -- story bg
    local storyIconName, storyIconAtlas, storyIconBundle = ConfigUtils.GetActivityBattleStoryBG(self._battleId)
    self._ui.StoryBG.sprite2D = self:DynamicLoadSprite(storyIconBundle, storyIconAtlas, storyIconName)

    local battleRecords = GameData.GetActivityBattleRecords(self._activityThemeId)
    local thisBattleData = battleRecords[self._battleIndex] or {}
    local winNum = thisBattleData.win or 0
    local unlockNum = thisBattleData.unlock or 0
    local repeatLimit = ConfigUtils.GetActivityBattleRepeatLimit(self._battleId)
    local isFinished = (winNum >= repeatLimit)
    local needCost = (winNum >= unlockNum)
    local unlockCost = (not isFinished and needCost and winNum == 0)
    local repeatCost = (not isFinished and needCost and winNum > 0)
    self._ui.BattleFinished:SetActive(isFinished)
    self._ui.ButtonConfirm:SetActive(not isFinished and not needCost)
    self._ui.ButtonUnlockConfirm:SetActive(unlockCost)
    self._ui.ButtonRepeatConfirm:SetActive(repeatCost)

    local costRoot = nil
    local costItem = nil
    if unlockCost then
        costRoot = self._ui.ButtonUnlockConfirm.transform
        costItem = ConfigUtils.GetActivityBattleUnlockCost(self._battleId)[1]
    elseif repeatCost then
        costRoot = self._ui.ButtonRepeatConfirm.transform
        costItem = ConfigUtils.GetActivityBattleRepeatCost(self._battleId)[1]
    end

    self._needCostEnough = true
    self._costItemId = nil
    if costItem ~= nil then
        self._costItemId = costItem.Value
        self:ConstructCostItem(costRoot, costItem)
    end

    local rewardItems = {}
    if winNum == 0 then
        rewardItems = ConfigUtils.GetActivityBattleUnlockReward(self._battleId)
    else
        rewardItems = ConfigUtils.GetActivityBattleRepeatReward(self._battleId)
    end
    self:ConstructRewardItems(rewardItems)
	
    CtrlManager.AddClick(self, self._ui.Blocker)
    CtrlManager.AddClick(self, self._ui.ButtonUnlockConfirm)
    CtrlManager.AddClick(self, self._ui.ButtonConfirm)
    CtrlManager.AddClick(self, self._ui.ButtonRepeatConfirm)
    CtrlManager.AddClick(self, self._ui.EnemyCollider)
end

function ActivityBattleDetailCtrl:ConstructCostItem(costRoot, costItem)
    local itemId = costItem.Value
    local itemNum = costItem.Num
    local ownNum = GameData.GetItemNum(itemId)

    UIHelper.ConstructItemIconAndNum(self, costRoot, itemId, itemNum)

    local numLabel = costRoot:Find("Num"):GetComponent("UILabel")
    local itemType = ConfigUtils.GetItemTypeFromId(itemId)
    if itemType == ItemType.Goods then
        numLabel.text = string.format("%d/%d", ownNum, itemNum)
    else
        numLabel.text = string.format("%d", itemNum)
    end
    if ownNum < itemNum then
        numLabel.color = Color.red
        self._needCostEnough = false
    end
end

function ActivityBattleDetailCtrl:ConstructRewardItems(rewardItems)
    for idx = 1, #self._ui.RewardItems do
        local hasReward = (idx <= #rewardItems)
        local item = self._ui.RewardItems[idx].item
        item:SetActive(hasReward)
        if hasReward then
            local root = self._ui.RewardItems[idx].root
            local itemId = rewardItems[idx].Value
            local itemNum = rewardItems[idx].Num
            UIHelper.ConstructItemIconAndNum(self, root, itemId, itemNum)
        end
    end
end

function ActivityBattleDetailCtrl:GotoBattle()
    CtrlManager.PopPanel()
    CtrlManager.OpenPanel(CtrlNames.ExploreCharacter, {
        battleId = self._battleId, 
        themeId = self._activityThemeId,
    })
end

-- on clicked
function ActivityBattleDetailCtrl:OnClicked(go)

    if go == self._ui.Blocker then
        SoundSystem.PlayUICancelSound()
        CtrlManager.PopPanel()
    elseif go == self._ui.ButtonConfirm then
        SoundSystem.PlayUIClickSound()
        CtrlManager.DoWaitTransition(CtrlNames.ExploreCharacter, self, ActivityBattleDetailCtrl.GotoBattle)
    elseif go == self._ui.EnemyCollider then
        SoundSystem.PlayUIClickSound()
        local enemyId, enemyLevel = ConfigUtils.GetLastEnemyOfActivityBattle(self._battleId)
        CtrlManager.ShowItemDetail({itemId = enemyId, itemLevel = enemyLevel})
    elseif go == self._ui.ButtonUnlockConfirm or go == self._ui.ButtonRepeatConfirm then
        if not GameData.IsActivityThemeValid(self._activityThemeId) then
            SoundSystem.PlayWarningSound()
            CtrlManager.ShowMessageBox({message = SAFE_LOC("活动已结束"), single = true})
            return true
        end
        
        if not self._needCostEnough then
            local itemType = ConfigUtils.GetItemTypeFromId(self._costItemId)
            SoundSystem.PlayWarningSound()
            if itemType == ItemType.Diamond then
                CtrlManager.ShowMessageBox({message = SAFE_LOC("玉璧不足"), single = true})
            elseif itemType == ItemType.Gold then
                CtrlManager.ShowMessageBox({message = SAFE_LOC("金币不足"), single = true})
            elseif itemType == ItemType.Goods then
                CtrlManager.ShowMessageBox({message = SAFE_LOC("道具不足\n请搭乘电车出发进行探索"), single = true})
            else
                CtrlManager.ShowMessageBox({message = SAFE_LOC("物品不足"), single = true})
            end
            return true
        end

        SoundSystem.PlayUIClickSound()
        CtrlManager.DoWaitTransition(CtrlNames.ExploreCharacter, self, ActivityBattleDetailCtrl.GotoBattle)
    end

	return true
end
