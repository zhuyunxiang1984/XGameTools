require "FreakPlanet/View/PackagePanel"

local class = require "FreakPlanet/Utils/middleclass"
PackageCtrl  = class(CtrlNames.Package, BaseCtrl)

-- load the ui prefab
function PackageCtrl:LoadPanel()
	self:CreatePanel("Package")
end

-- construct ui panel data
function PackageCtrl:ConstructUI(obj)
	self._ui = PackagePanel.Init(obj)
end

-- notity it has been focused
function PackageCtrl:NotifyFocus()
    -- all packages sold out
    if #self._packageList == 0 then
        CtrlManager.PopPanel()
    end
end

-- destructor
function PackageCtrl:DestroyImpl()
    GameNotifier.RemoveListener(GameEvent.IapPackageChanged, PackageCtrl.OnPackageChanged, self)
    GameNotifier.RemoveListener(GameEvent.IapStateChanged, PackageCtrl.OnIapStateChanged, self)
end

-- fill ui with the data
function PackageCtrl:SetupUI()
    self:DynamicLoadBundle(Const.CoupeAvatarBundleName)
    --礼包icon实例
    self._packageIconInst = {}
    -- title
    self:SetPackageTitle()
    -- init iap package and custom package
	self:InitPackages()
    -- refresh purchasing hint
    self:RefreshPurchasingHint()
    -- restore in-processing orders
    IAPManager.RestoreStore(true)
    -- refresh custom package if no valid one
    NetManager.CheckAndFetchCustomPackage()

    CtrlManager.AddClick(self, self._ui.Blocker)
    GameNotifier.AddListener(GameEvent.IapPackageChanged, PackageCtrl.OnPackageChanged, self)
    GameNotifier.AddListener(GameEvent.IapStateChanged, PackageCtrl.OnIapStateChanged, self)
end

function PackageCtrl:SetPackageTitle()
    if Helper.IsEmptyOrNull(Global.ExtraData) then
        return
    end

    local json = require "cjson"
    local extraInfo = json.decode(Global.ExtraData)
    local title = SAFE_LOC("loc_global_package_title_desc")
    if extraInfo.PackageTitle ~= nil then
        title = extraInfo.PackageTitle
    end
    self._ui.PackageTitle.text = title
end

function PackageCtrl:GetActivePackages()
    local packageList = {}

    local iapPackageId = GameData.GetActiveIapPackage()
    if iapPackageId ~= nil then
        local info = GameData.GetIapPackageInfo(iapPackageId)
        table.insert(packageList, {
            id = iapPackageId,
            endTime = info.endTime,
            price = info.price,
            name = info.name,
            desc = info.desc,
            buttonDesc = info.buttonDesc,
            rewards = info.rewards,
            rate = info.rate or 0,
            icon = info.icon,
            isLimit = false,
        })
    end

    local customPackageId, customPackageEndTime = GameData.GetActiveCustomPackage()
    if customPackageId ~= nil then
        local price = ConfigUtils.GetCustomPackagePrice(customPackageId)
        local name, desc, buttonDesc, rate, icon = ConfigUtils.GetCustomPackageInfo(customPackageId)
        local rewards = ConfigUtils.GetCustomPackageRewards(customPackageId)
        table.insert(packageList, {
            id = customPackageId,
            endTime = customPackageEndTime,
            price = price,
            name = name,
            desc = desc,
            buttonDesc = buttonDesc,
            rewards = rewards,
            rate = rate or 0,
            icon = icon,
            isLimit = true,
        })
    end

    return packageList
end

function PackageCtrl:InitPackages()
    self._packageList = self:GetActivePackages()
    self:ConstructPackages()
end

function PackageCtrl:RecyclePackageItems(root)
    local num = root.childCount
    for idx = num, 1, -1 do
        local item = root:GetChild(idx - 1)

        local rewardRoot = item:Find("ScrollView/Grid")
        local rewardNum = rewardRoot.childCount
        for m = rewardNum, 1, -1 do
            local rewardItem = rewardRoot:GetChild(m - 1)
            rewardItem.parent = self._ui.RewardPool
        end

        item.parent = self._ui.PackagePool
    end
end

function PackageCtrl:ConstructPackages()
    self:RecyclePackageItems(self._ui.PackageRoot_1)
    self:RecyclePackageItems(self._ui.PackageRoot_2)

    if #self._packageList >= 1 then
        self:ConstrcutPackageItem(self._ui.PackageRoot_1, 1)
    end

    if #self._packageList >= 2 then
       self:ConstrcutPackageItem(self._ui.PackageRoot_2, 2) 
    end
end

function PackageCtrl:SetPackageIcon(root, idx, iconName)
    if self._packageIconInst[idx] then
        if self._packageIconInst[idx].name == iconName then
            return
        end
        destroy(self._packageIconInst[idx])
        self._packageIconInst[idx] = nil
    end
    local prefab = self:DynamicLoadAsset("packageicon", iconName)
    local packageIcon = Helper.NewObject(prefab, root)
    packageIcon.name = iconName
    self._packageIconInst[idx] = packageIcon
end

function PackageCtrl:ConstrcutPackageItem(root, idx)
    local packageItem = nil
    if self._ui.PackagePool.childCount == 0 then
        local packageObj = Helper.NewObject(self._ui.PackageItemTemplate, root)
        packageItem = packageObj.transform
        local buttonConfirm = packageItem:Find("ButtonConfirm").gameObject
        CtrlManager.AddClick(self, buttonConfirm)
        local buttonHint = packageItem:Find("ButtonHint").gameObject
        CtrlManager.AddClick(self, buttonHint)
    else
        packageItem = self._ui.PackagePool:GetChild(0)
        packageItem.parent = root
        packageItem.localPosition = Vector3.zero
        packageItem.localScale = Vector3.one
    end

    packageItem.gameObject:SetActive(true)
    packageItem.gameObject.name = tostring(idx)
    -- name
    local title = packageItem:Find("Title"):GetComponent("UILabel")
    title.text = self._packageList[idx].name
    -- icon
    local icon = packageItem:Find("Icon"):GetComponent("UISprite")
    --icon.spriteName = self._packageList[idx].icon
    --这里的icon替换为prefab
    self:SetPackageIcon(icon.transform, idx, self._packageList[idx].icon)


    -- rate
    local rateValue = Helper.Round(self._packageList[idx].rate / 100, 1)
    local rateInt = math.floor(rateValue)
    local rateFloat = rateValue - rateInt
    local finalRateValue = rateInt
    if rateFloat > 0 then
        finalRateValue = rateValue
    end
    local rateRoot = packageItem:Find("Rate").gameObject
    rateRoot:SetActive(finalRateValue > 1)
    if finalRateValue > 1 then
        local rateLabel = packageItem:Find("Rate/Label"):GetComponent("UILabel")
        rateLabel.text = tostring(finalRateValue)
    end
    -- desc
    local desc = packageItem:Find("Desc"):GetComponent("UILabel")
    desc.text = self._packageList[idx].desc
    -- button desc
    local buttonDesc = packageItem:Find("ButtonConfirm/Label"):GetComponent("UILabel")
    buttonDesc.text = self._packageList[idx].buttonDesc
    -- left time
    local leftTime = packageItem:Find("LeftTime"):GetComponent("UILabel")
    leftTime.text = ""
    -- record the time label
    self._packageList[idx].timeLabel = leftTime
    -- rewards
    local rewardRoot = packageItem:Find("ScrollView/Grid")
    local rewardGrid = rewardRoot:GetComponent("UIGrid")
    local rewards = self._packageList[idx].rewards
    local rewardScale = 1
    rewardGrid.maxPerLine = 4
    rewardGrid.cellWidth = 65
    rewardGrid.cellHeight = 65
    if #rewards <= 4 then
        rewardScale = 1.1
        rewardGrid.maxPerLine = 2
        rewardGrid.cellWidth = 75
        rewardGrid.cellHeight = 75
    end
    for rewardIndex = 1, #rewards do
        local itemId = rewards[rewardIndex].id
        local itemNum = rewards[rewardIndex].num
        local rewardItem = nil
        if self._ui.RewardPool.childCount == 0 then
            local rewardObj = Helper.NewObject(self._ui.RewardItemTemplate, rewardRoot)
            CtrlManager.AddClick(self, rewardObj)
            rewardItem = rewardObj.transform
        else
            rewardItem = self._ui.RewardPool:GetChild(0)
            rewardItem.parent = rewardRoot
            rewardItem.localScale = Vector3.one
        end
        rewardItem.gameObject:SetActive(true)
        rewardItem.gameObject.name = tostring(itemId)
        local rewardRoot = rewardItem:Find("Root")
        rewardRoot.localScale = Vector3.New(rewardScale, rewardScale, 1)
        -- icon bg
        local iconBG = rewardItem:Find("Root/IconBG"):GetComponent("UISprite")
        iconBG.spriteName = UIHelper.GetBorderAndBgByItemId(itemId)
        -- icon and num
        UIHelper.ConstructItemIconAndNum(self, rewardRoot, itemId, itemNum)
    end
    -- refresh grid
    rewardGrid:Reposition()
    -- can buy or not
    local canBuy = self:CanBuyPackage(idx)
    local buttonConfirm = packageItem:Find("ButtonConfirm").gameObject
    local buttonHint = packageItem:Find("ButtonHint").gameObject
    buttonConfirm:SetActive(canBuy)
    buttonHint:SetActive(not canBuy)
    -- is limited
    local isLimit = self._packageList[idx].isLimit
    local limitMark = packageItem:Find("Limited").gameObject
    limitMark:SetActive(isLimit)
end

-- update implementation
function PackageCtrl:UpdateImpl(deltaTime)
    -- update time
    local curTime = GameData.GetServerTime()
    for idx = 1, #self._packageList do
        if self._packageList[idx].timeLabel ~= nil then
            local endTime = self._packageList[idx].endTime
            local leftTime = math.max(0, endTime - curTime)
            if leftTime > 0 then
                self._packageList[idx].timeLabel.text = Helper.GetLongTimeString(leftTime)
            else
                self._packageList[idx].timeLabel.text = SAFE_LOC("礼包已结束")
            end
        end
    end
end

function PackageCtrl:OnPaymentSelected(payment)
    IAPManager.Buy(self._selectedPackageId, payment)
end

function PackageCtrl:OnPackageChanged()
    self:InitPackages()
end

function PackageCtrl:RefreshPurchasingHint()
    local isPurchasing = IAPManager.HasProcessingOrder()
    self._ui.PurchasingHint:SetActive(isPurchasing)
end

function PackageCtrl:OnIapStateChanged()
    self:RefreshPurchasingHint()
end

function PackageCtrl:OnProceedApplePay()
    self:OnPaymentSelected(PaymentType.Apple)
end

-- on clicked
function PackageCtrl:OnClicked(go)

    if go == self._ui.Blocker then
        SoundSystem.PlayUICancelSound()
        CtrlManager.PopPanel()
    elseif go == "ButtonHint" then
        SoundSystem.PlayWarningSound()
        CtrlManager.ShowMessageBox({message = SAFE_LOC("您已经拥有该角色\n角色无法重复购买！"), single = true})
    elseif go.name == "ButtonConfirm" then        
        local idx = tonumber(go.transform.parent.gameObject.name)
        local packageId = self._packageList[idx].id
        -- purchased or not
        local completed = GameData.IsIapReallyCompleted(packageId)
        if completed then
            SoundSystem.PlayWarningSound()
            CtrlManager.ShowAlert(SAFE_LOC("礼包已购买"))
            return true
        end
        -- finished or not
        local endTime = self._packageList[idx].endTime
        local curTime = GameData.GetServerTime()
        if curTime >= endTime then
            SoundSystem.PlayWarningSound()
            CtrlManager.ShowAlert(SAFE_LOC("礼包已结束"))
            return true
        end
        -- 是否可以购买礼包
        if not self:CanBuyPackage(idx) then
            SoundSystem.PlayWarningSound()
            CtrlManager.ShowAlert(SAFE_LOC("礼包已购买"))
            return true
        end

        -- has iap processing
        local canBuy = IAPManager.CanBuy()
        if not canBuy then
            SoundSystem.PlayWarningSound()
            IAPManager.ShowIapResult(PaymentResult.IapInProcessing)
            return true
        end
        -- real name related
        local price = self._packageList[idx].price
        local isOK = GameData.CheckRealNameOfIap(price)
        if not isOK then
            SoundSystem.PlayWarningSound()
            return true
        end
        -- real buy
        self._selectedPackageId = packageId
        if Global.ChannelId == GameChannels.APPSTORE then
            local existOrderId = GameData.GetIapFirstOrder(packageId)
            if existOrderId == nil then
                SoundSystem.PlayUIClickSound()
                self:OnProceedApplePay()
            else
                CtrlManager.ShowMessageBox({
                    message = SAFE_LOC("该商品有未完成订单，请稍后重新登录尝试获取收据凭证。继续购买可能会导致未完成订单丢失\n继续购买？"),
                    single = false, 
                    onConfirm = PackageCtrl.OnProceedApplePay, 
                    receiver = self,
                })
            end
        elseif Global.ChannelId == GameChannels.ANDROID_OPPO then
            SoundSystem.PlayUIClickSound()
            self:OnPaymentSelected(PaymentType.Oppo)
        elseif Global.ChannelId == GameChannels.ANDROID_VIVO then
            SoundSystem.PlayUIClickSound()
            self:OnPaymentSelected(PaymentType.Vivo)
        elseif Global.ChannelId == GameChannels.ANDROID_HUAWEI then
            SoundSystem.PlayUIClickSound()
            self:OnPaymentSelected(PaymentType.Huawei)
        elseif Global.ChannelId == GameChannels.ANDROID_UC then
            SoundSystem.PlayUIClickSound()
            self:OnPaymentSelected(PaymentType.Uc)
        elseif Global.ChannelId == GameChannels.ANDROID_MI then
            SoundSystem.PlayUIClickSound()
            self:OnPaymentSelected(PaymentType.Mi)
        elseif Global.ChannelId == GameChannels.ANDROID_BILIBILI then
            SoundSystem.PlayUIClickSound()
            self:OnPaymentSelected(PaymentType.Bilibili)
        elseif Global.ChannelId == GameChannels.ANDROID_TENCENT then
            SoundSystem.PlayUIClickSound()
            self:OnPaymentSelected(PaymentType.Tencent)
        elseif Global.ChannelId == GameChannels.ANDROID_MOMOYU then
            SoundSystem.PlayUIClickSound()
            self:OnPaymentSelected(PaymentType.MoMoYu)
        else
            SoundSystem.PlayUIClickSound()
            CtrlManager.OpenPanel(CtrlNames.IAPPaymentSelect, {callback = PackageCtrl.OnPaymentSelected, receiver = self})
        end
    elseif go.transform.parent.gameObject.name == "Grid" then
        local itemId = tonumber(go.name)
        local itemType = ConfigUtils.GetItemTypeFromId(itemId)
        if itemType == ItemType.Character then
            SoundSystem.PlayUIClickSound()
            CtrlManager.ShowItemDetail({itemId = itemId, preview = true})
        end
    end

	return true
end

--玩家是否拥有礼包内的角色,皮肤,玩具,家具
function PackageCtrl:CanBuyPackage(packageIndex)
    local rewards = self._packageList[packageIndex].rewards
    if GameData.HasPackageAnyOneReward(rewards) then
        return false
    end
    return true
end