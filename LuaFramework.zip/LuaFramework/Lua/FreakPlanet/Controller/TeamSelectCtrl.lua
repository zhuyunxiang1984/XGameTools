require "FreakPlanet/View/TeamSelectPanel"

local class = require "FreakPlanet/Utils/middleclass"
TeamSelectCtrl  = class(CtrlNames.TeamSelect, BaseCtrl)

-- load the ui prefab
function TeamSelectCtrl:LoadPanel()
	self:CreatePanel("TeamSelect")
end

-- construct ui panel data
function TeamSelectCtrl:ConstructUI(obj)
	self._ui = TeamSelectPanel.Init(obj)
end

-- destroy implementation
function TeamSelectCtrl:DestroyImpl()
    GameNotifier.RemoveListener(GameEvent.CharacterSkinChanged, TeamSelectCtrl.OnCharacterSkinChanged, self)
    GameNotifier.RemoveListener(GameEvent.CharacterStageChanged, TeamSelectCtrl.OnCharacterStageChanged, self)
    GameNotifier.RemoveListener(GameEvent.CharacterLevelChanged, TeamSelectCtrl.OnCharacterLevelChanged, self)
    GameNotifier.RemoveListener(GameEvent.CharacterEquipmentUpgraded, TeamSelectCtrl.OnCharacterEquipmentUpgraded, self)
end

-- fill ui with the data
function TeamSelectCtrl:SetupUI()
    self._members = self._parameter.members
    self._ctrl = self._parameter.ctrl
    self._receiver = self._parameter.receiver
    self._coupleId = self._parameter.couple
    self._numLimit = self._parameter.numLimit

    self._finalMembers = {}

    local selectedCharacterNum = 0
    for idx = 1, #self._members do
        local memberId = self._members[idx]
        local itemType = ConfigUtils.GetItemTypeFromId(memberId)
        if self:CanSelectMember(memberId) then
            if itemType == ItemType.Pet then
                self:SelectMember(memberId)
            elseif itemType == ItemType.Character then
                if selectedCharacterNum < self._numLimit then
                    self:SelectMember(memberId)
                    selectedCharacterNum = selectedCharacterNum + 1
                end
            else
                assert(false, "un-handled item id: "..tostring(memberId))
            end
        end
    end

    if self._coupleId == nil then
        self._ui.NumLimit.text = string.format(SAFE_LOC("最多可选角色：%d"), self._numLimit)
    else
        self._ui.NumLimit.text = string.format(SAFE_LOC("剩余可选角色：%d"), self._numLimit)
    end

    self:SetupSelectedTeamMembers()
	
    CtrlManager.AddClick(self, self._ui.Blocker)
    CtrlManager.AddClick(self, self._ui.ButtonConfirm)

    GameNotifier.AddListener(GameEvent.CharacterSkinChanged, TeamSelectCtrl.OnCharacterSkinChanged, self)
    GameNotifier.AddListener(GameEvent.CharacterStageChanged, TeamSelectCtrl.OnCharacterStageChanged, self)
    GameNotifier.AddListener(GameEvent.CharacterLevelChanged, TeamSelectCtrl.OnCharacterLevelChanged, self)
    GameNotifier.AddListener(GameEvent.CharacterEquipmentUpgraded, TeamSelectCtrl.OnCharacterEquipmentUpgraded, self)
end

function TeamSelectCtrl:SetupSelectedTeamMembers()
    for idx = 1, #self._members do
        local itemId = self._members[idx]
        local itemType = ConfigUtils.GetItemTypeFromId(itemId)

        local itemObj = nil
        if itemType == ItemType.Character then
            itemObj = Helper.NewObject(self._ui.CharacterItemTemplate, self._ui.Root)
        elseif itemType == ItemType.Pet then
            itemObj = Helper.NewObject(self._ui.PetItemTemplate, self._ui.Root)
        else
            assert(false, "un-handled item id: "..tostring(itemId))
        end

        itemObj.name = tostring(itemId)
        itemObj:SetActive(true)
        CtrlManager.AddClick(self, itemObj)
        CtrlManager.AddPress(self, itemObj)

        self:ConstructGridItem(itemObj.transform, itemId)
    end

    self._ui.Root:GetComponent("UITable"):Reposition()
end

function TeamSelectCtrl:ConstructGridItem(item, itemId)
    local itemType = ConfigUtils.GetItemTypeFromId(itemId)
    if itemType == ItemType.Character then
        self:ConstructCharacterItem(item, itemId)
    elseif itemType == ItemType.Pet then
        self:ConstructPetItem(item, itemId)
    else
        assert(false, "un-handled item id: "..tostring(itemId))
    end
end

function TeamSelectCtrl:CheckSkin(itemId)
    if self._coupleId == nil then
        return false
    end

    local conditions = ConfigUtils.GetCoupleConditions(self._coupleId)
    for idx = 1, #conditions do
        if conditions[idx].Id == itemId then
            local skinId = conditions[idx].SkinId
            if ConfigUtils.IsValidItem(skinId) then
                local currentSkin = GameData.GetCharacterSkin(itemId)
                return currentSkin ~= skinId
            else
                return false
            end
        end
    end

    return false
end

function TeamSelectCtrl:ConstructCharacterItem(item, itemId)
    UIHelper.ConstructCharacterItem(self, item, itemId)
    -- couple skin
    local showSkinLock = self:CheckSkin(itemId)
    local lockMark = item:Find("Mark/SkinLock").gameObject
    lockMark:SetActive(showSkinLock)
    -- status
    self:RefreshCharacterStatusState(item, itemId)
    -- selected
    local selected = self:IsMemberSelected(itemId)
    self:RefreshSelectedState(item, itemId, selected)
end

function TeamSelectCtrl:ConstructPetItem(item, itemId)
    UIHelper.ConstructPetItem(self, item, itemId)
    -- level
    local levelLabel = item:Find("Level"):GetComponent("UILabel")
    local petLevel = GameData.GetPetLevel(itemId)
    levelLabel.text = string.format(SAFE_LOC("loc_SimpleLevel"), petLevel)
    -- status
    self:RefreshPetStatusState(item, itemId)
    -- selected
    local selected = self:IsMemberSelected(itemId)
    self:RefreshSelectedState(item, itemId, selected)
end

function TeamSelectCtrl:RefreshSelectedState(item, itemId, selected)
    if item == nil then
        item = self._ui.Root:Find(itemId)
    end

    if item ~= nil then
        local selectedMark = item:Find("Mark/Select").gameObject
        selectedMark:SetActive(selected)
    end
end

function TeamSelectCtrl:RefreshCharacterStatusState(item, itemId)
    if item == nil then
        item = self._ui.Root:Find(itemId)
    end

    if item ~= nil then
        local canSelect, failReason = self._ctrl.CheckCanSelectCharacter(self._receiver, itemId)
        local statusMark = item:Find("Mark/Status").gameObject
        statusMark:SetActive(not canSelect)
        if not canSelect then
            local statusLabel = statusMark.transform:Find("Label"):GetComponent("UILabel")
            statusLabel.text = UIHelper.GetSelectionFailReasonShowText(failReason)
        end
    end
end

function TeamSelectCtrl:RefreshPetStatusState(item, itemId)
    if item == nil then
        item = self._ui.Root:Find(itemId)
    end

    if item ~= nil then
        local canSelect, failReason = self._ctrl.CheckCanSelectPet(self._receiver, itemId)
        local statusMark = item:Find("Mark/Status").gameObject
        statusMark:SetActive(not canSelect)
        if not canSelect then
            local statusLabel = statusMark.transform:Find("Label"):GetComponent("UILabel")
            statusLabel.text = UIHelper.GetSelectionFailReasonShowText(failReason)
        end
    end
end

function TeamSelectCtrl:IsMemberSelected(itemId)
    return self._finalMembers[itemId] ~= nil
end

function TeamSelectCtrl:SelectMember(itemId)
    self._finalMembers[itemId] = 1
end

function TeamSelectCtrl:CancelMember(itemId)
    self._finalMembers[itemId] = nil
end

function TeamSelectCtrl:CanSelectMember(itemId)
    local itemType = ConfigUtils.GetItemTypeFromId(itemId)
    if itemType == ItemType.Character then
        return self._ctrl.CheckCanSelectCharacter(self._receiver, itemId)
    elseif itemType == ItemType.Pet then
        return self._ctrl.CheckCanSelectPet(self._receiver, itemId)
    else
        assert(false, "un-handled item id: "..tostring(itemId))
    end
end

function TeamSelectCtrl:OnCharacterSkinChanged(characterId)
    self:DoRefreshInternal(characterId)
end

function TeamSelectCtrl:OnCharacterLevelChanged(characterId)
    self:DoRefreshInternal(characterId)
end

function TeamSelectCtrl:OnCharacterStageChanged(characterId)
    self:DoRefreshInternal(characterId)
end

function TeamSelectCtrl:OnCharacterEquipmentUpgraded(characterId)
    self:DoRefreshInternal(characterId)
end

function TeamSelectCtrl:DoRefreshInternal(characterId)
    local characterItem = self._ui.Root:Find(characterId)
    if characterItem ~= nil then
        self:ConstructCharacterItem(characterItem, characterId)
    end
end

function TeamSelectCtrl:OnReplaceWorkShopCharacter(characterId)
    local busyCharacters = GameData.GetBusyCharacters()
    local data = busyCharacters[characterId]
    assert(data ~= nil and data.status == CharacterStatus.WorkShop, "character status is not corrent: "..tostring(characterId))
    local workShopId = data.value
    local characters = GameData.GetCharactersOfWorkShop(workShopId)
    local finalCharacterList = {}
    for idx = 1, #characters do
        if characters[idx] ~= characterId then
            table.insert(finalCharacterList, characters[idx])
        end
    end

    if #finalCharacterList == 0 then
        finalCharacterList = nil
    end

    NetManager.Send("WorkShopTeamSet", 
        {
            WorkShopId = workShopId, 
            CharacterList = finalCharacterList,
            Character = characterId,
        }, 
        TeamSelectCtrl.OnHandleProto, self
    )
end

function TeamSelectCtrl:GetFinalSelected()
    local characters = {}
    local pet = nil

    for idx = 1, #self._members do
        local memberId = self._members[idx]
        local selected = self:IsMemberSelected(memberId)
        if selected then
            local itemType = ConfigUtils.GetItemTypeFromId(memberId)
            if itemType == ItemType.Character then
                table.insert(characters, memberId)
            elseif itemType == ItemType.Pet then
                pet = memberId
            else
                assert(false, "un-handled item id: "..tostring(itemId))
            end
        end
    end

    return characters, pet
end

-- on clicked
function TeamSelectCtrl:OnClicked(go)

    if go == self._ui.Blocker then
        SoundSystem.PlayUIClickSound()
        CtrlManager.PopPanel()
    elseif go == self._ui.ButtonConfirm then
        local characters, pet = self:GetFinalSelected()
        if #characters == 0 and not ConfigUtils.IsValidItem(pet) then
            SoundSystem.PlayWarningSound()
            CtrlManager.ShowMessageBox({message = SAFE_LOC("选择为空"), single = true})
            return true
        end

        if #characters > self._numLimit then
            SoundSystem.PlayWarningSound()
            CtrlManager.ShowMessageBox({message = SAFE_LOC("队伍人数超出上限"), single = true})
            return true
        end

        SoundSystem.PlayUIClickSound()
        CtrlManager.PopPanel()
        self._ctrl.OnTeamSelected(self._receiver, characters, pet, self._coupleId ~= nil)
    elseif go.transform.parent == self._ui.Root then
        local itemId = tonumber(go.name)
        local canSelect, failReason = self:CanSelectMember(itemId)
        if canSelect then
            SoundSystem.PlayUIClickSound()
            local selected = self:IsMemberSelected(itemId)
            if selected then
                self:CancelMember(itemId)
            else
                self:SelectMember(itemId)
            end

            self:RefreshSelectedState(nil, itemId, not selected)
        else
            if failReason == SelectionFailReason.WorkShopMember then
                SoundSystem.PlayUIClickSound()
                CtrlManager.ShowMessageBox({message = SAFE_LOC("正在打工中\n是否强制换下?"), data = itemId, single = false, onConfirm = TeamSelectCtrl.OnReplaceWorkShopCharacter, receiver = self})
            else
                SoundSystem.PlayWarningSound()
            end
        end
    end

	return true
end

function TeamSelectCtrl:OnHandleProto(proto, data, requestData)
    if proto == "WorkShopTeamSet" then
        GameData.SetDataOfWorkShop(data.WorkShopStatus)
        GameData.MarkBusyCharacterDirty()
        GameData.CheckAndHintGoalsOfCurrentCountType()
        GameNotifier.Notify(GameEvent.WorkShopListChanged)
        -- team select ctrl
        local characterId = requestData.Character
        local characterItem = self._ui.Root:Find(characterId)
        if characterItem ~= nil then
            self:RefreshCharacterStatusState(characterItem, characterId)
        end
        -- notify character base ctrl
        self._ctrl.OnCharacterStatusChanged(self._receiver, characterId)
    end
end

function TeamSelectCtrl:OnPressed(go, pressed, isLong)
    if pressed and isLong then
        SoundSystem.PlayUIClickSound()
        local itemId = tonumber(go.name)
        local itemType = ConfigUtils.GetItemTypeFromId(itemId)
        if itemType == ItemType.Character then
            SoundSystem.PlayUIClickSound()
            CtrlManager.OpenPanel(CtrlNames.CharacterQuickDetail, {characterId = itemId})
        elseif itemType == ItemType.Pet then
            SoundSystem.PlayUIClickSound()
            CtrlManager.ShowItemDetail({itemId = itemId})
        end
    end
end

-- handle the escapse button
function TeamSelectCtrl:HandleEscape()
    self:OnClicked(self._ui.Blocker)
end
