require "FreakPlanet/View/AccountPanel"

local class = require "FreakPlanet/Utils/middleclass"
AccountCtrl  = class(CtrlNames.Account, BaseCtrl)

local SPEED_1 = -10
local SPEED_2 = -5

-- load the ui prefab
function AccountCtrl:LoadPanel()
	self:CreatePanel("Account")
end

-- construct ui panel data
function AccountCtrl:ConstructUI(obj)
	self._ui = AccountPanel.Init(obj)
end

-- destroy implementation
function AccountCtrl:DestroyImpl()
	GameNotifier.RemoveListener(GameEvent.ChannelTokenChecked, AccountCtrl.OnChannelTokenChecked, self)
	GameNotifier.RemoveListener(GameEvent.WordFilterLoadComplete, AccountCtrl.OnCurrentAccountChanged, self)
end

-- fill ui with the data
function AccountCtrl:SetupUI()
	self._ui.OfficalPanel:SetActive(not Global.HasChannelAccount)
	self._ui.ChannelPanel:SetActive(Global.HasChannelAccount and Global.ChannelId ~= GameChannels.ANDROID_TENCENT)
	self._ui.TencentPanel:SetActive(Global.HasChannelAccount and Global.ChannelId == GameChannels.ANDROID_TENCENT)

	if not Global.HasChannelAccount then
		self._currentAccount = GameData.GetDefaultNickName()
		self:OnCurrentAccountChanged()
	else
		if Global.ChannelId ~= GameChannels.ANDROID_TENCENT then
			ChannelHelper.StartWaitToken()
			ScriptBridge.LoginGame()
		else
			local lastPlatform = GameData.GetTencentLastLoginPlatform()
			if lastPlatform ~= nil then
				ChannelHelper.StartWaitToken()
				ScriptBridge.LoginGame(lastPlatform)
			end
		end
	end

	self._ui.Version.text = UIHelper.GetGameVersion()
	self:ShowLoginHint(false)

	CtrlManager.AddClick(self, self._ui.ButtonStart)
	CtrlManager.AddClick(self, self._ui.ButtonNickName)
	CtrlManager.AddClick(self, self._ui.AccountCollider)
	CtrlManager.AddClick(self, self._ui.ButtonRule)
	CtrlManager.AddClick(self, self._ui.ButtonPrivacy)
	CtrlManager.AddClick(self, self._ui.ButtonChannelStart)
	CtrlManager.AddClick(self, self._ui.ButtonQQ)
	CtrlManager.AddClick(self, self._ui.ButtonWeixin)
	CtrlManager.AddClick(self, self._ui.ButtonAge)

	GameNotifier.AddListener(GameEvent.ChannelTokenChecked, AccountCtrl.OnChannelTokenChecked, self)
	GameNotifier.AddListener(GameEvent.WordFilterLoadComplete, AccountCtrl.OnCurrentAccountChanged, self)
end

function AccountCtrl:OnCurrentAccountChanged()
	if self._currentAccount ~= nil then
		self._ui.CurrentAccountId.text = WordFilterHelper.FilterSensitiveWord(self._currentAccount)
	else
		self._ui.CurrentAccountId.text = ""
	end
end

-- on clicked
function AccountCtrl:OnClicked(go)
	if go == self._ui.ButtonStart then
		SoundSystem.PlayUIClickSound()
		self:StartGame()
	elseif go == self._ui.ButtonNickName then
		SoundSystem.PlayUIClickSound()
		CtrlManager.OpenPanel(CtrlNames.AccountLogin, {
			loginCallback = AccountCtrl.HandleAccountLogin, 
			receiver = self}
		)
	elseif go == self._ui.AccountCollider then
		CtrlManager.OpenPanel(CtrlNames.AccountSwitch, {
			current = self._currentAccount, 
			switchCallback = AccountCtrl.HandleSwitchAccount,
			newCallback = AccountCtrl.HandleNewAccount,
			receiver = self}
		)
	elseif go == self._ui.ButtonRule then
		SoundSystem.PlayUIClickSound()
		Global.OpenURL(USER_NOTICE_URL)
	elseif go == self._ui.ButtonPrivacy then
		SoundSystem.PlayUIClickSound()
		Global.OpenURL(PRIVACY_NOTICE_URL)
	elseif go == self._ui.ButtonChannelStart then
		SoundSystem.PlayUIClickSound()
		ScriptBridge.LoginGame()
	elseif go == self._ui.ButtonQQ then
		if ChannelHelper.CanWaitToken() then
			SoundSystem.PlayUIClickSound()
			ChannelHelper.StartWaitToken()
			ScriptBridge.LoginGame(1)       -- 1是QQ
		else
			SoundSystem.PlayWarningSound()
		end
	elseif go == self._ui.ButtonWeixin then
		if ChannelHelper.CanWaitToken() then
			SoundSystem.PlayUIClickSound()
			ChannelHelper.StartWaitToken()
			ScriptBridge.LoginGame(2)       -- 2是微信
		else
			SoundSystem.PlayWarningSound()
		end
	elseif go == self._ui.ButtonAge then
		SoundSystem.PlayUIClickSound()
		local url = Helper.GetFromExtraData("ClassificationDesc")
		if url then
			Global.OpenURL(url)
		end
	end

	return true
end

-- handle the escapse button
function AccountCtrl:HandleEscape()
	-- do nothing
end

function AccountCtrl:HandleSwitchAccount(newAccount)
	if self._currentAccount ~= newAccount then
		self._currentAccount = newAccount
		self:OnCurrentAccountChanged()
	end
end

function AccountCtrl:HandleNewAccount(code)
	XDebug.Log('GGYY', "HandleNewAccount")
	--这里开始一次Geetest验证
	if Util.IsSupportGeetest then
		--设置游戏服url到GeetestSDK
		ScriptBridge.SetGeetestAPIUrl(Global.GameUrl)
		ChannelHelper.StartGeetest(function(success)
			if success then
				self:DoRegister(nil, ChannelHelper.GeetestData)
			end
		end)
	else
		self:DoRegister(nil)
	end
end

function AccountCtrl:HandleRegister()
	self:HandleNewAccount(nil)

	--[[
	-- register
    if true then
    	self:DoRegister(nil)
    else
    	CtrlManager.OpenPanel(CtrlNames.AccountInvitation, {callback = AccountCtrl.HandleNewAccount, receiver = self})
    end
    --]]
end

function AccountCtrl:HandleAccountLogin(newAccount, password)
	self:ShowLoginHint(true)
	NetManager.Send("Login", {Nickname = newAccount, Password = Helper.CheckMd5(password), Mac = Global.deviceIdentifier}, AccountCtrl.OnHandleProto, self)
end

function AccountCtrl:StartGame()
    if self._currentAccount == nil then
		CtrlManager.OpenPanel(CtrlNames.AccountRegisterConfirm, {callback = AccountCtrl.HandleRegister, receiver = self})
    else
    	-- login
    	self:DoLogin()
    end
end

function AccountCtrl:DoRegister(code, geetestData)
	code = code or ""
	local serverType = Game.GetServerType()
	NetManager.Send("Register", {
		InitAccount = "Default", 
		Channelid = Global.ChannelId, 
		Mac = Global.deviceIdentifier,
		InviteCode = code,
		ServerType = serverType,
		Challenge 		 = geetestData and geetestData.Challenge or nil,
		ModelProbability = geetestData and geetestData.ModelProbability or nil,
		WebSimulator 	 = geetestData and geetestData.WebSimulator or nil,
		Duration 		 = geetestData and geetestData.Duration or nil,
	}, AccountCtrl.OnHandleProto, self)
end

function AccountCtrl:DoLogin()
	assert(self._currentAccount ~= nil, "current account can't be nil")
	local nickname, password = GameData.GetAccountInfoByName(self._currentAccount)
	local data = NetManager.ConstructLoginData(nickname, password)
	NetManager.Send("Login", data, AccountCtrl.OnHandleProto, self)
	self:ShowLoginHint(true)
end

function AccountCtrl:ShowLoginHint(show)
	self._ui.LoginHint:SetActive(show)
end

function AccountCtrl:OnChannelTokenChecked(accountExit)
	if accountExit then
		local data = NetManager.ConstructChannelLoginData()
		NetManager.Send("Login3rd", data, AccountCtrl.OnHandleProto, self)
	else
		local serverType = Game.GetServerType()
		NetManager.Send("Register3rd", {
			InitAccount = "Default", 
			Channelid = Global.ChannelId, 
			ChannelUid = ScriptBridge.ChannelUid,
			Mac = Global.deviceIdentifier,
			InviteCode = "qa",
			ServerType = serverType,
		}, AccountCtrl.OnHandleProto, self)
	end
end

function AccountCtrl:OnHandleProto(proto, data, requestData)
	if proto == "Register" or proto == "Register3rd" then
		local userId = data.Userid
		local nickname = data.Nickname
		local password = data.Password
		
		Game.MarkNewAccount()
		GameData.AddAccount(userId, nickname, password)
		GameData.Save()

		if proto == "Register" then
			-- non-channel login
			self._currentAccount = nickname
			self:OnCurrentAccountChanged()
			self:DoLogin()
		else
			-- now account exist, do login for channel
			self:OnChannelTokenChecked(true)
		end
		ChannelHelper.CreateRoleToSdk(userId, nickname)
		ChannelHelper.ReportToBokeAd(BokeAdEventType.Register, {uid = userId})
	elseif proto == "Login" or proto == "Login3rd" then
		local nickname = "" 
		local password = ""
		if proto == "Login" then
			nickname = data.Nickname
			password = requestData.Password
		else
			nickname = data.Nickname
			password = ""                       -- no password
		end
		
		local userId = data.Userid
		local session = data.Session

		ChannelHelper.ResetAccountState()
		ChannelHelper.ReportToBokeAd(BokeAdEventType.Login, {uid = userId})
		GameData.CheckAddNewAccount(userId, nickname, password)
		GameData.SetDefaultNickName(nickname)
		GameData.Save()

		NetManager.SetLoginSession(session)
		NetManager.Send("ServerInfoSimple", {}, NetManager.OnHandleServerInfo)
		NetManager.SendServerTime(false)
		NetManager.Send("AccountInfo", {}, AccountCtrl.OnHandleProto, self)
		NetManager.Send("WorkShopList", {}, AccountCtrl.OnHandleProto, self)
		NetManager.Send("AreaList", {}, AccountCtrl.OnHandleProto, self)
		NetManager.Send("SysArenaConfig", {}, AccountCtrl.OnHandleProto, self)
		NetManager.Send("DemandList", {}, AccountCtrl.OnHandleProto, self)
		NetManager.Send("ActivityGoalTimeConfig", {}, AccountCtrl.OnHandleProto, self)
		NetManager.Send("ActivityThemeTimeConfig", {}, AccountCtrl.OnHandleProto, self)
		NetManager.Send("STSeasonConfig", {}, AccountCtrl.OnHandleProto, self)
		NetManager.Send("STData", {}, AccountCtrl.OnHandleProto, self)
		NetManager.Send("GetIAPCustomPackage", {}, AccountCtrl.OnHandleProto, self)
		--NetManager.Send("ActivityPackageTimeConfig", {}, AccountCtrl.OnHandleProto, self)
		NetManager.Send("GetPresetTeamList", {}, AccountCtrl.OnHandleProto, self)
		NetManager.Send("PackageTimeConfig", {}, AccountCtrl.OnHandleProto, self)
		--活动商店数据
		GameDataClothesShop.RequestActivityShopData()
		--这里保证UserInfo是最后一个发的协议
		NetManager.Send("UserInfo", {}, AccountCtrl.OnHandleProto, self)
	elseif proto == "AccountInfo" then
		GameData.InitAccountInfo(data)
		GameData.CheckDefaultAccountSafeState()
	elseif proto == "WorkShopList" then
		GameData.InitWorkShopList(data)
	elseif proto == "AreaList" then
		GameData.RecordAreaData(data)
	elseif proto == "SysArenaConfig" then
		GameData.InitSysArenaConfig(data)
	elseif proto == "DemandList" then
		GameData.InitDemandData(data)
	elseif proto == "ActivityGoalTimeConfig" then
		GameData.SetTimeLimitedActivity(data.ActivityGoalTimeConfig)
		-- no actual data, just do init
		GameData.SetTimeLimitedDemandList(nil, nil)
	elseif proto == "ActivityThemeTimeConfig" then
		GameData.InitActivityThemeData(data.ActivityThemeTimeConfig)
	elseif proto == "STSeasonConfig" then
		GameData.InitSpaceTravelSeasonConfig(data.ConfigList)
	elseif proto == "STData" then
		GameData.InitSpaceTravelData(data)
	elseif proto == "GetIAPCustomPackage" then
		GameData.SetCustomPackage(data.IAPCustomPackageObj)
	elseif proto == "GetPresetTeamList" then
		GameData.SetPresetTeamList(data.TeamList)
	elseif proto == "PackageTimeConfig" then
		GameData.SetIapPackageList(data)
	elseif proto == "UserInfo" then
		GameData.InitArenaData(data)
		GameData.InitGameData(data)

		--- mark for lz,InitGoalData里需要GameDataHome的数据,所以GameDataHome初始化数据提前
		GameDataHome.Init()
		GameDataHome.InitCleanData(data.HomeCleanItemList)
		GameDataHome.InitSettleData(data.HomePlacementInfo)
		GameDataHome.InitFurnitureBuyHistoryData(data.FurnitureBuyHistory)
		GameDataHome.InitFurnitureBuyCostHistoryData(data.FurnitureBuyCostHistory)
		GameDataHome.InitFurnitureGashaponBuyHistoryData(data.FurnitureGashaponBuyHistory)

		GameData.InitActivityData(data)
		GameData.InitHideSeekData(data.HideSeekInfo)
		-- 任务进度依赖角色账号数据
		GameData.InitGoalData(data)
		GameData.InitMiscData(data)
		-- 教程进度检查依赖已完成任务，必须在任务后设置
		GameData.InitTutorialData(data)
		GameData.InitIapMonthCard(data.BaseInfo)
		GameData.SetCompletedIapList(data.CompleteIAPIDList)
		GameData.SetSummonPoolList(data.DrawTimeConfigList)
		GameData.InitFurnitureDeliveryData(data.DeliverTimeList)
        --TODO:暂时先放在UserInfo这里初始化

		-- valid after all the data is ready
		GameData.ValidPresetTeams()
		CtrlManager.PopPanel()

		--这里登陆完成了,新增先做一次实名检测 add by ggyy
		if GameData.EnableRealName() and not GameData.IsAccountVerified() then
			CtrlManager.OpenPanel(CtrlNames.AccountRealName, {force = true, callback = function()
				self:OnLoginComplete()
			end})
		else
			self:OnLoginComplete()
		end
	end
end

function AccountCtrl:OnLoginComplete()
	if self:IsUnderAge() then
		if not GameData.IsAllowUnderAgeToPlay(GameData.GetServerTime()) then
			CtrlManager.ShowMessageBox({message = "您好，根据国家相关法律法规和政策要求，当前时间段非法定节假日允许登录时间。您无法正常登录游戏，请在法定节假日规定时间内登录。", single = true, onConfirm = Game.Restart})
			return
		end
		Game.SetUnderAge(true)
	else
		Game.SetUnderAge(false)
	end
	Game.OnAccountLogined()
end

--是否未成年
function AccountCtrl:IsUnderAge()
	--是否由渠道负责实名
	if Global.HasChannelAccount then
		if not ChannelHelper.IsAdult() then
			return true
		end
	else
		--是否开启了实名
		if GameData.EnableRealName() and GameData.GetAccountAge() < RealNameData.UnderAge1 then
			return true
		end
	end
	return false
end
