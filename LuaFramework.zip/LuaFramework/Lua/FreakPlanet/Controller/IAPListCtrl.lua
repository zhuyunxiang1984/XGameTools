require "FreakPlanet/View/IAPListPanel"

local class = require "FreakPlanet/Utils/middleclass"
IAPListCtrl  = class(CtrlNames.IAPList, BaseCtrl)

-------------------------------------------------------------
local function IapSortFunc(idA, idB)
	if idA == nil or idB == nil then
		return false
	end

	local isCardA = ConfigUtils.IsMonthCardIap(idA)
	local isCardB = ConfigUtils.IsMonthCardIap(idB)
	if isCardA ~= isCardB then
		return isCardA
	end

	local valueA = ConfigUtils.GetIapSortId(idA)
	local valueB = ConfigUtils.GetIapSortId(idB)

	return valueA < valueB
end
-------------------------------------------------------------
-- load the ui prefab
function IAPListCtrl:LoadPanel()
	self:CreatePanel("IAPList")
end

-- construct ui panel data
function IAPListCtrl:ConstructUI(obj)
	self._ui = IAPListPanel.Init(obj)
end

-- destructor 
function IAPListCtrl:DestroyImpl()	
	GameNotifier.RemoveListener(GameEvent.IapCompleted, IAPListCtrl.OnIapCompleted, self)
	GameNotifier.RemoveListener(GameEvent.IapStateChanged, IAPListCtrl.OnIapStateChanged, self)
end

-- fill ui with the data
function IAPListCtrl:SetupUI()
	self._iapList = ConfigUtils.GetIapList()
	table.sort( self._iapList, IapSortFunc )

	self:ConstructIapGrid()
	self:RefreshPurchasingHint()
	IAPManager.RestoreStore(true)

	CtrlManager.AddClick(self, self._ui.Blocker)
	GameNotifier.AddListener(GameEvent.IapCompleted, IAPListCtrl.OnIapCompleted, self)
	GameNotifier.AddListener(GameEvent.IapStateChanged, IAPListCtrl.OnIapStateChanged, self)

	self._ui.IapGridWrap.OnItemUpdate = IAPListCtrl.OnItemUpdateGlobal
end

function IAPListCtrl:ConstructIapGrid()
	-- item count
	local itemCount = self._ui.IapGridWrap.NeedCellCount
	itemCount = math.min(#self._iapList, itemCount)
	self._ui.IapGridWrap.MaxRow = math.ceil(#self._iapList / self._ui.IapGridWrap.ColumnLimit)

	local item = nil
	for idx = 1, itemCount do
		local itemObj = Helper.NewObject(self._ui.IapItemTemplate, self._ui.IapGrid)
		item = itemObj.transform

		item.gameObject:SetActive(true)
		item.gameObject.name = tostring(idx)

		local buttonBuy = item:Find("ButtonBuy").gameObject
		CtrlManager.AddClick(self, buttonBuy)

		-- construct item
		self:ConstructIapItem(item, idx)
	end

	self._ui.IapGridWrap:SortBasedOnScrollMovement()
	self._ui.IapScrollView:ResetPosition()
	self._ui.IapScrollView.restrictWithinPanel = true
end

function IAPListCtrl:ConstructIapItem(item, idx)
	local iapId = self._iapList[idx]
	local iapName, iapDesc, iapButtonDesc, iapIcon = ConfigUtils.GetIapInfo(iapId)

	local doubleMark = item:Find("DoubleMark").gameObject
	local showDouble = ConfigUtils.IsDoubleIap(iapId) and not GameData.IsIapCompleted(iapId)
	doubleMark:SetActive(showDouble)

	local icon = item:Find("Icon"):GetComponent("UISprite")
	icon.spriteName = iapIcon

	local descLabel = item:Find("Desc"):GetComponent("UILabel")
	descLabel.text = iapDesc

	local costLabel = item:Find("ButtonBuy/Cost"):GetComponent("UILabel")
	costLabel.text = iapButtonDesc

	local monthCardLabel = item:Find("MonthCardDay"):GetComponent("UILabel")
	local isMonthCard = ConfigUtils.IsMonthCardIap(iapId)
	if isMonthCard then
		if GameData.IsMonthCardBought() then
			local leftDay = GameData.GetMonthCardLeftDays()
			monthCardLabel.text = string.format(SAFE_LOC("剩余%d天"), leftDay)
		else
			monthCardLabel.text = SAFE_LOC("新鲜的月卡")	
		end
	else
		monthCardLabel.text = ""
	end
end

function IAPListCtrl:OnItemUpdate(itemObj, itemIndex, itemRealIndex)
	itemRealIndex = itemRealIndex + 1
	if itemRealIndex <= 0 or itemRealIndex > #self._iapList then
		itemObj:SetActive(false)
	else
		itemObj:SetActive(true)
		itemObj.name = tostring(itemRealIndex)
		-- construct item
		self:ConstructIapItem(itemObj.transform, itemRealIndex)
	end
end

function IAPListCtrl.OnItemUpdateGlobal(itemObj, itemIndex, itemRealIndex)
	local ctrl = CtrlManager.GetCtrlByName(CtrlNames.IAPList)
	if ctrl ~= nil then
		ctrl:OnItemUpdate(itemObj, itemIndex, itemRealIndex)
	end
end

function IAPListCtrl:OnPaymentSelected(payment)
	IAPManager.Buy(self._selectedProductId, payment)
end

function IAPListCtrl:OnIapCompleted(iapId)
	local idx = Helper.IndexOfArray(self._iapList, iapId)
	if idx ~= nil then
		local item = self._ui.IapGrid:Find(idx)
		if item ~= nil then
			self:ConstructIapItem(item, idx)
		end
	end
end

function IAPListCtrl:RefreshPurchasingHint()
	local isPurchasing = IAPManager.HasProcessingOrder()
	self._ui.PurchasingHint:SetActive(isPurchasing)
end

function IAPListCtrl:OnIapStateChanged()
	self:RefreshPurchasingHint()
end

function IAPListCtrl:OnProceedApplePay()
	self:OnPaymentSelected(PaymentType.Apple)
end

-- on clicked
function IAPListCtrl:OnClicked(go)

	if go == self._ui.Blocker then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
	elseif go.name == "ButtonBuy" then
		local idx = tonumber(go.transform.parent.gameObject.name)
		local productId = self._iapList[idx]
		local isMonthCard = ConfigUtils.IsMonthCardIap(productId)
		if isMonthCard and GameData.GetMonthCardLeftDays() > MonthCardPurchaseLimit then
			SoundSystem.PlayWarningSound()
			CtrlManager.ShowAlert(SAFE_LOC("loc_global_monthcard_not_reach_limit"))
			return true
		end

		local canBuy = IAPManager.CanBuy()
		if not canBuy then
			SoundSystem.PlayWarningSound()
			IAPManager.ShowIapResult(PaymentResult.IapInProcessing)
			return true
		end

		local price = ConfigUtils.GetIapPrice(productId)
		local isOK = GameData.CheckRealNameOfIap(price)
		if not isOK then
			SoundSystem.PlayWarningSound()
			return true
		end

		self._selectedProductId = productId
		if Global.ChannelId == GameChannels.APPSTORE then
			local existOrderId = GameData.GetIapFirstOrder(productId)
			if existOrderId == nil then
				SoundSystem.PlayUIClickSound()
				self:OnProceedApplePay()
			else
				CtrlManager.ShowMessageBox({
					message = SAFE_LOC("该商品有未完成订单，请稍后重新登录尝试获取收据凭证。继续购买可能会导致未完成订单丢失\n继续购买？"),
					single = false, 
					onConfirm = IAPListCtrl.OnProceedApplePay, 
					receiver = self,
				})
			end
		elseif Global.ChannelId == GameChannels.ANDROID_OPPO then
			SoundSystem.PlayUIClickSound()
			self:OnPaymentSelected(PaymentType.Oppo)
		elseif Global.ChannelId == GameChannels.ANDROID_VIVO then
			SoundSystem.PlayUIClickSound()
			self:OnPaymentSelected(PaymentType.Vivo)
		elseif Global.ChannelId == GameChannels.ANDROID_HUAWEI then
			SoundSystem.PlayUIClickSound()
			self:OnPaymentSelected(PaymentType.Huawei)
		elseif Global.ChannelId == GameChannels.ANDROID_UC then
			SoundSystem.PlayUIClickSound()
			self:OnPaymentSelected(PaymentType.Uc)
		elseif Global.ChannelId == GameChannels.ANDROID_MI then
			SoundSystem.PlayUIClickSound()
			self:OnPaymentSelected(PaymentType.Mi)
		elseif Global.ChannelId == GameChannels.ANDROID_BILIBILI then
			SoundSystem.PlayUIClickSound()
			self:OnPaymentSelected(PaymentType.Bilibili)
		elseif Global.ChannelId == GameChannels.ANDROID_TENCENT then
			SoundSystem.PlayUIClickSound()
			self:OnPaymentSelected(PaymentType.Tencent)
		elseif Global.ChannelId == GameChannels.ANDROID_MOMOYU then
			SoundSystem.PlayUIClickSound()
			self:OnPaymentSelected(PaymentType.MoMoYu)
		else
			SoundSystem.PlayUIClickSound()
			CtrlManager.OpenPanel(CtrlNames.IAPPaymentSelect, {callback = IAPListCtrl.OnPaymentSelected, receiver = self})
		end
	end

	return true
end
