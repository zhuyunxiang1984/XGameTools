require "FreakPlanet/View/ArenaEnemyPanel"

local class = require "FreakPlanet/Utils/middleclass"
ArenaEnemyCtrl  = class(CtrlNames.ArenaEnemy, BaseCtrl)

local NORMAL_COLOR = Color.New(151 / 255, 115 / 255, 93 / 255, 1)
local FINISH_COLOR = Color.New(1, 160 / 255, 28 / 255, 1)

---------------------------------------------------------
-- load the ui prefab
function ArenaEnemyCtrl:LoadPanel()
	self:CreatePanel("ArenaEnemy")
end

-- destructor
function ArenaEnemyCtrl:DestroyImpl()
    GameNotifier.RemoveListener(GameEvent.ArenaBattleRankChanged, ArenaEnemyCtrl.OnArenaBattleRankChanged, self)
end

-- construct ui panel data
function ArenaEnemyCtrl:ConstructUI(obj)
	self._ui = ArenaEnemyPanel.Init(obj)
end

-- fill ui with the data
function ArenaEnemyCtrl:SetupUI()
	-- refresh it before get the activated arena data
	GameData.RefreshActivatedArenaConfig()
	self._arenaConfigId, self._arenaId = GameData.GetActivatedArenaData()
	assert(self._arenaConfigId ~= nil and self._arenaId ~= nil, "no valid arena config id")
	self._arenaBattleList = ConfigUtils.GetBattleListOfArena(self._arenaId)
	self._ui.ArenaTheme.text = ConfigUtils.GetArenaDesc(self._arenaId)
	self._currentArenaBattleIndex = self:GetCurrentArenaBattleIndex()

	self:SetupArena()
	
	CtrlManager.AddClick(self, self._ui.Blocker)

	for k, v in pairs(self._ui.ArenaBattles) do
		CtrlManager.AddClick(self, v.item)
	end

	GameNotifier.AddListener(GameEvent.ArenaBattleRankChanged, ArenaEnemyCtrl.OnArenaBattleRankChanged, self)
end

function ArenaEnemyCtrl:GetCurrentArenaBattleIndex()
	local arenaData = GameData.GetArenaDataOf(self._arenaConfigId)
	for idx = 1, #arenaData do
		-- difficulty is still 0
		if arenaData[idx] == 0 then
			return idx
		end
	end

	return nil
end

function ArenaEnemyCtrl:RefreshLineProgress()
	for idx = 1, self._ui.ArenaLineRoot.childCount do
		local line = self._ui.ArenaLineRoot:GetChild(idx - 1):GetComponent("UISprite")
		local finished = (self._currentArenaBattleIndex == nil or idx < self._currentArenaBattleIndex)
		if finished then
			line.color = FINISH_COLOR
		else
			line.color = NORMAL_COLOR
		end
	end
end

function ArenaEnemyCtrl:SetupArena()
	for idx = 1, #self._ui.ArenaBattles do
		local hasArena = (idx <= #self._arenaBattleList)
		self._ui.ArenaBattles[idx].item:SetActive(hasArena)
		if hasArena then
			local arenaBattleId = self._arenaBattleList[idx]
			local isBoss = ConfigUtils.IsBossArenaBattle(arenaBattleId)

			local arenaPrefab = self._ui.NormalArenaItemTemplate
			if isBoss then
				arenaPrefab = self._ui.BossArenaItemTemplate
			end

			local root = self._ui.ArenaBattles[idx].root
			local arenaObj = Helper.NewObject(arenaPrefab, root)
			arenaObj:SetActive(true)
			arenaObj.name = tostring(arenaBattleId)
			local arenaItem = arenaObj.transform

			self:ConstructArenaItem(arenaItem, idx)
		end
	end

	self:RefreshLineProgress()
end

function ArenaEnemyCtrl:ConstructArenaItem(arenaItem, idx)
	local arenaBattleId = self._arenaBattleList[idx]

	local lockedMark = arenaItem:Find("Locked").gameObject
	local currentMark = arenaItem:Find("Current").gameObject
	local completedMark = arenaItem:Find("Completed").gameObject

	local locked = (self._currentArenaBattleIndex ~= nil and idx > self._currentArenaBattleIndex)
	local completed = (self._currentArenaBattleIndex == nil or idx < self._currentArenaBattleIndex)
	lockedMark:SetActive(locked)
	currentMark:SetActive(idx == self._currentArenaBattleIndex)
	completedMark:SetActive(completed)

	local isBoss = ConfigUtils.IsBossArenaBattle(arenaBattleId)
	if isBoss then
		local icon = arenaItem:Find("Icon"):GetComponent("UISprite")
		local enemyId = ConfigUtils.GetArenaBattleLastEnmeyAt(arenaBattleId, 1)
		UIHelper.SetCharacterIcon(self, icon, enemyId)
		if completed then
			icon.color = Color.white
		else
			icon.color = LOCK_ICON_COLOR
		end
	end

	-- star
	local arenaBattleRank = GameData.GetCurrentDifficultyOfArenaBattle(self._arenaConfigId, idx)
	local rankRoot = arenaItem:Find("Star")
	for m = 1, rankRoot.childCount do
		local doneMark = rankRoot:GetChild(m - 1):Find("Done").gameObject
		doneMark:SetActive(m <= arenaBattleRank)
	end

	-- goal
	local matchGoal = JumpManager.MatchArenaGoal(idx)
	local goalMark = arenaItem:Find("Mark/Goal").gameObject
	goalMark:SetActive(matchGoal)
end

function ArenaEnemyCtrl:OnArenaBattleRankChanged()
	self._currentArenaBattleIndex = self:GetCurrentArenaBattleIndex()
	for idx = 1, #self._arenaBattleList do
		local arenaBattleId = self._arenaBattleList[idx]
		local root = self._ui.ArenaBattles[idx].root
		local arenaItem = root:Find(arenaBattleId)
		if arenaItem ~= nil then
			self:ConstructArenaItem(arenaItem, idx)
		end
	end
	self:RefreshLineProgress()
end

-- on clicked
function ArenaEnemyCtrl:OnClicked(go)

	if go == self._ui.Blocker then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
	elseif go.transform.parent == self._ui.ArenaBattleRoot then
		if GameData.GetActivatedArenaConfigId() == self._arenaConfigId then
			local idx = tonumber(go.name)
			if self._currentArenaBattleIndex == nil or idx <= self._currentArenaBattleIndex then
				SoundSystem.PlayUIClickSound()
				CtrlManager.OpenPanel(CtrlNames.ArenaBattleDetail, {
					arenaConfigId = self._arenaConfigId,
					arenaId = self._arenaId,
					battleIndex = idx,
				})
			end
		else
			SoundSystem.PlayWarningSound()
			CtrlManager.ShowMessageBox({message = SAFE_LOC("流亡街已刷新"), single = true})
		end
	end

	return true
end
