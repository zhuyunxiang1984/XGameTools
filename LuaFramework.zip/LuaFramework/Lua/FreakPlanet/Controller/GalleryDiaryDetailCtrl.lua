require "FreakPlanet/View/GalleryDiaryDetailPanel"

local class = require "FreakPlanet/Utils/middleclass"
GalleryDiaryDetailCtrl  = class(CtrlNames.GalleryDiaryDetail, BaseCtrl)

-- load the ui prefab
function GalleryDiaryDetailCtrl:LoadPanel()
	self:CreatePanel("GalleryDiaryDetail")
end

-- construct ui panel data
function GalleryDiaryDetailCtrl:ConstructUI(obj)
	self._ui = GalleryDiaryDetailPanel.Init(obj)
end

-- fill ui with the data
function GalleryDiaryDetailCtrl:SetupUI()
	local itemId = self._parameter.itemId
	local itemType = ConfigUtils.GetItemTypeFromId(itemId)

	self._ui.EventPanel:SetActive(false)
	self._ui.PostcardPanel:SetActive(false)

	if itemType == ItemType.Event then
		self._ui.EventPanel:SetActive(true)
		self:ConstructEvent(itemId)
	elseif itemType == ItemType.Postcard then
		self._ui.PostcardPanel:SetActive(true)
		self:ConstructPostcard(itemId)
	else
		assert(false, "un-handled item id: "..tostring(itemId))
	end

	for idx = 1, self._ui.PostcardCharacterRoot.childCount do
		local btnObj = self._ui.PostcardCharacterRoot:GetChild(idx - 1).gameObject
		CtrlManager.AddClick(self, btnObj)
	end

	CtrlManager.AddClick(self, self._ui.EventBlocker)
	CtrlManager.AddClick(self, self._ui.PostcardBlocker)
	CtrlManager.AddClick(self, self._ui.ButtonGo)
end

function GalleryDiaryDetailCtrl:ConstructEvent(itemId)
	local unlocked = GameData.IsEventUnlocked(itemId)

	local iconName, iconAtlas, iconBundle = ConfigUtils.GetEventIcon(itemId)
    self._ui.EventIcon.sprite2D = self:DynamicLoadSprite(iconBundle, iconAtlas, iconName)
	self._ui.EventLockHint:SetActive(not unlocked)

	if unlocked then
		self._ui.EventIcon.color = Color.white
		self._ui.EventName.text = ConfigUtils.GetEventName(itemId)
		self._ui.EventDesc.text = ConfigUtils.GetEventDesc(itemId)
	else
		self._ui.EventIcon.color = Color.black
		self._ui.EventName.text = "???"
		self._ui.EventDesc.text = ConfigUtils.GetEventLockDesc(itemId)
	end

	local eventRewards = ConfigUtils.GetEventReward(itemId)
	local showEvent = (unlocked and (#eventRewards > 0))
    self._ui.EventRewardRoot.gameObject:SetActive(showEvent)
    if showEvent then
        local rewardId = eventRewards[1].Value
        local rewardNum = eventRewards[1].Num

        UIHelper.ConstructItemIconAndNum(self, self._ui.EventRewardRoot, rewardId, nil)

        local label = self._ui.EventRewardRoot:Find("Label"):GetComponent("UILabel")
        label.text = SAFE_LOC("事件奖励：")..ConfigUtils.GetItemName(rewardId).."x"..tostring(rewardNum)
    end
end

function GalleryDiaryDetailCtrl:ConstructPostcard(itemId)
	local postcardType = ConfigUtils.GetPostcardType(itemId)
	local unlocked = false
	local goalId = 0
	if postcardType == EnumPostcardType.Achievement then
		goalId = ConfigUtils.GetGoalOfPostcard(itemId)
		unlocked = GameData.IsGoalFinished(goalId)
	elseif postcardType == EnumPostcardType.Activity then
		unlocked = GameData.IsUnlockPoscard(itemId)
	end

    self._postcardSkinList = {}

	self._ui.PostcardName.text = ConfigUtils.GetPostcardName(itemId)
	self._ui.PostcardLockRoot.gameObject:SetActive(not unlocked)
	self._ui.PostcardUnlockRoot.gameObject:SetActive(unlocked)

	if unlocked then
		local headerLabel = self._ui.PostcardUnlockRoot:Find("Header"):GetComponent("UILabel")
		local descLabel = self._ui.PostcardUnlockRoot:Find("Desc"):GetComponent("UILabel")
		local icon = self._ui.PostcardUnlockRoot:Find("Icon"):GetComponent("UI2DSprite")
		local signatureLabel = self._ui.PostcardUnlockRoot:Find("Signature"):GetComponent("UILabel")
		-- header
		headerLabel.text = string.format(SAFE_LOC("loc_golbal_postcard_header"), GameData.GetDefaultNickName(true))
		-- desc
		descLabel.text = ConfigUtils.GetPostcardDesc(itemId)
		-- icon
		local iconName, iconAtlas, iconBundle = ConfigUtils.GetPostcardIcon(itemId)
		icon.sprite2D = self:DynamicLoadSprite(iconBundle, iconAtlas, iconName)
		-- signature
		local signatureText = ConfigUtils.GetPostcardSignature(itemId)
		local unlockTime = GameData.GetUnlockTimeOfPostcard(itemId) or 0
		if unlockTime > 0 then
			unlockTime = unlockTime - GameData.GetTimeZoneOffset()
			signatureText = signatureText.."\n"..os.date("%Y.%m.%d", unlockTime)
		end
		signatureLabel.text = signatureText
	else
		local goalConditions = ConfigUtils.GetGoalConditions(goalId)
		local goalState, goalNumbers = GameData.GetGoalInfo(goalId)
		local currentNum, totalNum = UIHelper.GetAchievementGoalNum(goalConditions, goalNumbers)

		local conditionLabel = self._ui.PostcardLockRoot:Find("Condition"):GetComponent("UILabel")
		conditionLabel.text = UIHelper.GetGoalFinalName(goalConditions[1])

		local progressBar = self._ui.PostcardLockRoot:Find("ProgressBar/Bar"):GetComponent("UISprite")
		progressBar.fillAmount = math.min(1, currentNum / totalNum)

		local progressLabel = self._ui.PostcardLockRoot:Find("ProgressBar/Progress"):GetComponent("UILabel")
		progressLabel.text = tostring(currentNum).."/"..tostring(totalNum)

		self._postcardSkinList = self:GetItemListByGoalConditions(goalConditions)

		local characterRoot = self._ui.PostcardLockRoot:Find("Character")
		for idx = 1, characterRoot.childCount do
			local item = characterRoot:GetChild(idx - 1)
			local hasItem = (idx <= #self._postcardSkinList)
			item.gameObject:SetActive(hasItem)
			if hasItem then
				local icon = item:Find("Icon"):GetComponent("UISprite")
				local skinId = self._postcardSkinList[idx]
				UIHelper.SetCharacterIconWithSkin(self, icon, skinId)
			end
		end

		characterRoot:GetComponent("UITable"):Reposition()
	end
end

function GalleryDiaryDetailCtrl:GetItemListByGoalConditions(goalConditions)
	local ret = {}

	for idx = 1, #goalConditions do
		local e = goalConditions[idx]

		local characters = e.Character or {}
		local skins = e.Skin or {}

		if #skins > 0 then
			for skinIdx = 1, #skins do
				table.insert(ret, skins[skinIdx])
			end
		end

		if #characters > 0 then
			for characterIdx = 1, #characters do
				local skinId = ConfigUtils.GetDefaultSkinOfCharacter(characters[characterIdx], 1)
				table.insert(ret, skinId)
			end
		end

		if e.Type == ItemType.Character then
			if ConfigUtils.IsValidItem(e.Value) then
				local skinId = ConfigUtils.GetDefaultSkinOfCharacter(e.Value, 1)
				table.insert(ret, skinId)
			end
		elseif e.Type == ItemType.Skin then
			if ConfigUtils.IsValidItem(e.Value) then
				table.insert(ret, e.Value)
			end
		end
	end

	return ret
end

-- on clicked
function GalleryDiaryDetailCtrl:OnClicked(go)
	if go == self._ui.EventBlocker or go == self._ui.PostcardBlocker then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
	elseif go == self._ui.ButtonGo then
		local itemId = self._parameter.itemId
		local itemType = ConfigUtils.GetItemTypeFromId(itemId)
		assert(itemType == ItemType.Postcard, "only postcard can get here")
		local goalId = ConfigUtils.GetGoalOfPostcard(itemId)
		local code = JumpManager.JumpFromGoal(goalId)
		if code == RetCode.OK then
			SoundSystem.PlayUIClickSound()
		else
			SoundSystem.PlayWarningSound()
			local msg = UIHelper.GetReturnCodeShowText(code)
			CtrlManager.ShowMessageBox({message = msg, single = true})
		end
	elseif go.transform.parent == self._ui.PostcardCharacterRoot then
		SoundSystem.PlayUIClickSound()
		local index = tonumber(go.name)
		local skinId = self._postcardSkinList[index]
		local characterId = ConfigUtils.GetCharacterOfSkin(skinId)
		CtrlManager.ShowItemDetail({itemId = characterId})
	end

	return true
end
