require "FreakPlanet/View/ComicPanel"

local class = require "FreakPlanet/Utils/middleclass"
ComicCtrl  = class(CtrlNames.Comic, BaseCtrl)

-- load the ui prefab
function ComicCtrl:LoadPanel()
	self:CreatePanel("Comic")
end

-- construct ui panel data
function ComicCtrl:ConstructUI(obj)
	self._ui = ComicPanel.Init(obj)
end

-- fill ui with the data
function ComicCtrl:SetupUI()
	self._currentPage = 1
	self._historyPage = 0
	self:OnSequencePageChanged()

	CtrlManager.AddClick(self, self._ui.ButtonPrev)
	CtrlManager.AddClick(self, self._ui.ButtonNext)
end

function ComicCtrl:OnSequencePageChanged()
	self._pageState = nil
	if self._currentPage > #self._ui.SequencePages then
		self:Finish()
		return
	end

	local animation = self._ui.SequencePages[self._currentPage].animation
	local item = self._ui.SequencePages[self._currentPage].item

	self._pageState = SkeletonAnimationState:new(animation, "Appear", "Idle", item)
	self._ui.ButtonPrev:SetActive(self._currentPage <= self._historyPage and self._currentPage > 1)
	self._ui.ButtonNext:SetActive(self._currentPage <= self._historyPage)
end

function ComicCtrl:Finish()
	-- close the ctrl not in stack
	CtrlManager.ClosePanel(CtrlNames.Comic)
	-- callback
	if self._parameter.callback ~= nil then
		self._parameter.callback()
	end
end

function ComicCtrl:HidePageItem()
	if self._currentPage <= #self._ui.SequencePages then
		local item = self._ui.SequencePages[self._currentPage].item
		item:SetActive(false)
	end
end

function ComicCtrl:UpdateImpl(deltaTime)
	if self._pageState ~= nil then
		local finished = self._pageState:Tick(deltaTime)
		if finished then
			self._ui.ButtonPrev:SetActive(self._currentPage > 1)
			self._ui.ButtonNext:SetActive(true)
			if self._historyPage < self._currentPage then
				self._historyPage = self._currentPage
			end
			self._pageState = nil
		end
	end
end

function ComicCtrl:OnClicked(go)
	if go == self._ui.ButtonPrev then
		SoundSystem.PlayUIClickSound()
		self:HidePageItem()
		self._currentPage = self._currentPage - 1
		self:OnSequencePageChanged()
	elseif go == self._ui.ButtonNext then
		SoundSystem.PlayUIClickSound()
		self:HidePageItem()
		self._currentPage = self._currentPage + 1
		self:OnSequencePageChanged()
	end
end