require "FreakPlanet/View/SpaceTravelChoiceResultPanel"

local class = require "FreakPlanet/Utils/middleclass"
SpaceTravelChoiceResultCtrl  = class(CtrlNames.SpaceTravelChoiceResult, BaseCtrl)

local ResultState = {
    Base = "Base",
    Drop = "Drop",
}

local MAX_DISCARD_NUM = 12

-- load the ui prefab
function SpaceTravelChoiceResultCtrl:LoadPanel()
	self:CreatePanel("SpaceTravelChoiceResult")
end

-- construct ui panel data
function SpaceTravelChoiceResultCtrl:ConstructUI(obj)
	self._ui = SpaceTravelChoiceResultPanel.Init(obj)
end

-- fill ui with the data
function SpaceTravelChoiceResultCtrl:SetupUI()
    self._seasonId = self._parameter.seasonId
	self:CheckResultState()
    self._ui.BasePanel:SetActive(false)
    self._ui.GoodsPanel:SetActive(false)
    self._ui.GoodsHintAnimator.gameObject:SetActive(false)
    if self._currentState == ResultState.Base then
        self:SetupBase()
    elseif self._currentState == ResultState.Drop then
        self:SetupDrop()
    else
        assert(false, "un-handled result state: "..tostring(self._currentState))
    end

    CtrlManager.AddClick(self, self._ui.ButtonConfirm)
    CtrlManager.AddClick(self, self._ui.ButtonCancel)
    CtrlManager.AddClick(self, self._ui.Blocker)
end

function SpaceTravelChoiceResultCtrl:CheckResultState()
    self._friendlinessChange = {}
    local friendlinessChanged = false
    local seasonData = GameData.GetSpaceTravelSeasonData(self._seasonId)
    local currentFood = seasonData.food
    local currentFuel = seasonData.fuel
    local currentScore = seasonData.score

    self._foodMaxChange = self._parameter.foodMax or 0
    self._fuelMaxChange = self._parameter.fuelMax or 0
    self._capacityMaxChange = self._parameter.capacityMax or 0
    self._foodChange = 0
    self._fuelChange = 0
    self._scoreChange = 0

    self._foodClientChange = self._parameter.clientFood or 0
    self._fuelClientChange = self._parameter.clientFuel or 0

    if self._parameter.finalFood ~= nil then
        self._foodChange = (self._parameter.finalFood - currentFood)
    end
    if self._parameter.finalFuel ~= nil then
        self._fuelChange = (self._parameter.finalFuel - currentFuel)
    end
    if self._parameter.finalScore ~= nil then
        self._scoreChange = (self._parameter.finalScore - currentScore)
    end
    
    if self._parameter.friendliness ~= nil then
        for k, v in pairs(self._parameter.friendliness) do
            if v ~= 0 then
                self._friendlinessChange[k] = v
                friendlinessChanged = true
            end
        end
    end

    local baseChanged = ( friendlinessChanged or 
        self._foodChange ~= 0 or 
        self._foodMaxChange ~= 0 or
        self._foodClientChange ~= 0 or
        self._fuelChange ~= 0 or
        self._fuelMaxChange ~= 0 or 
        self._fuelClientChange ~= 0 or
        self._capacityMaxChange ~= 0 or 
        self._scoreChange ~= 0
    )

    if baseChanged then
        self._currentState = ResultState.Base
    else
        self._currentState = ResultState.Drop
    end
end

function SpaceTravelChoiceResultCtrl:GetInfoString(str, ...)
    local args = {...}
    return string.format(str, unpack(args))
end

function SpaceTravelChoiceResultCtrl:SetupBase()
    self._ui.BasePanel:SetActive(true)
    
    local infos = {}

    if self._scoreChange ~= 0 then
        table.insert(infos, self:GetInfoString(SAFE_LOC("总分%+d"), self._scoreChange))
    end

    if self._foodChange ~= 0 or self._foodClientChange ~= 0 then
        if self._foodChange == self._foodClientChange then
            table.insert(infos, self:GetInfoString(SAFE_LOC("食物%+d"), self._foodClientChange))
        else
            if self._foodClientChange > 0 then
                table.insert(infos, self:GetInfoString(SAFE_LOC("食物%+d"), self._foodClientChange).."(已达上限)")
            elseif self._foodClientChange == 0 then
                table.insert(infos, self:GetInfoString(SAFE_LOC("食物%-d"), self._foodClientChange).."(空了)")
            else
                table.insert(infos, self:GetInfoString(SAFE_LOC("食物%d"), self._foodClientChange).."(空了)")
            end
        end
    end

    if self._foodMaxChange ~= 0 then
        table.insert(infos, self:GetInfoString(SAFE_LOC("食物上限%+d"), self._foodMaxChange))
    end

    if self._fuelChange ~= 0 or self._fuelClientChange ~= 0 then
        if self._fuelChange == self._fuelClientChange then
            table.insert(infos, self:GetInfoString(SAFE_LOC("燃料%+d"), self._fuelClientChange))
        else
            if self._fuelClientChange > 0 then
                table.insert(infos, self:GetInfoString(SAFE_LOC("燃料%+d"), self._fuelClientChange).."(已达上限)")
            elseif self._fuelClientChange == 0 then
                table.insert(infos, self:GetInfoString(SAFE_LOC("燃料%-d"), self._fuelClientChange).."(空了)")
            else
                table.insert(infos, self:GetInfoString(SAFE_LOC("燃料%d"), self._fuelClientChange).."(空了)")
            end
        end
    end

    if self._fuelMaxChange ~= 0 then
        table.insert(infos, self:GetInfoString(SAFE_LOC("燃料上限%+d"), self._fuelMaxChange))
    end

    if self._capacityMaxChange ~= 0 then
        table.insert(infos, self:GetInfoString(SAFE_LOC("负重上限%+d"), self._capacityMaxChange))
    end

    for idx = 1, #self._ui.BaseInfos do
        local label = self._ui.BaseInfos[idx].label
        if idx <= #infos then
            label.text = infos[idx]
        else
            label.text = ""
        end
    end

    infos = {}
    for k, v in pairs(self._friendlinessChange) do
        local campName = ConfigUtils.GetSpaceTravelFriendlinessName(k)
        table.insert(infos, self:GetInfoString(SAFE_LOC("%s%+d好感度"), campName, v))
    end

    for idx = 1, #self._ui.FriendlinessInfos do
        local label = self._ui.FriendlinessInfos[idx].label
        if idx <= #infos then
            label.text = infos[idx]
        else
            label.text = ""
        end
    end
end

function SpaceTravelChoiceResultCtrl:SetupDrop()
    self._ui.GoodsPanel:SetActive(true)

    local rewardDrops = self._parameter.goods or {}
    self._itemsToDiscard = {}
    for k, v in pairs(rewardDrops) do
        table.insert(self._itemsToDiscard, {id = k, num = v})
    end

    local seasonData = GameData.GetSpaceTravelSeasonData(self._seasonId)
    self._relicMax = seasonData.relicMax
    self._goodsMax = seasonData.goodsMax
    -- owned relic
    local relicList = seasonData.relic
    self._relicList = {}
    for idx = 1, #relicList do
        local itemId = relicList[idx]
        if idx <= self._relicMax then
            table.insert(self._relicList, itemId)
        else
            self:AddItemToDiscard(itemId, 1)
        end
    end
    -- owned goods
    local goodsList = seasonData.goods
    self._goodsList = {}
    for idx = 1, #goodsList do
        local goodsId = goodsList[idx].id
        local goodsNum = goodsList[idx].num
        if idx <= self._goodsMax then
            table.insert(self._goodsList, {id = goodsId, num = goodsNum})
        else
            self:AddItemToDiscard(goodsId, goodsNum)
        end
    end

    self:ConstructDiscardGrid()
    self:ConstructKeepRelicGrid()
    self:ConstructKeepGoodsGrid()
end

function SpaceTravelChoiceResultCtrl:NeedShowDrop()
    local seasonData = GameData.GetSpaceTravelSeasonData(self._seasonId)
    local relicMax = seasonData.relicMax
    if #seasonData.relic > relicMax then
        return true
    end

    local goodsMax = seasonData.goodsMax
    if #seasonData.goods > goodsMax then
        return true
    end

    local rewardDrops = self._parameter.goods or {}
    for k, v in pairs(rewardDrops) do
        return true
    end

    return false
end

function SpaceTravelChoiceResultCtrl:GetDiscardItemIdx(itemId)
    for idx = 1, #self._itemsToDiscard do
        if self._itemsToDiscard[idx].id == itemId then
            return idx
        end
    end

    return nil
end

function SpaceTravelChoiceResultCtrl:GetKeepGoodsIdx(itemId)
    for idx = 1, #self._goodsList do
        if self._goodsList[idx].id == itemId then
            return idx
        end
    end

    return nil
end

function SpaceTravelChoiceResultCtrl:GetKeepRelicIdx(itemId)
    return Helper.IndexOfArray(self._relicList, itemId)
end

function SpaceTravelChoiceResultCtrl:AddItemToDiscard(itemId, itemNum)
    local slot = self:GetDiscardItemIdx(itemId)
    if slot == nil then
        table.insert(self._itemsToDiscard, {id = itemId, num = 0})
        slot = #self._itemsToDiscard
    end

    self._itemsToDiscard[slot].num = self._itemsToDiscard[slot].num + itemNum
end

function SpaceTravelChoiceResultCtrl:DiscardItem(itemId, itemNum)
    local goodsSubType = ConfigUtils.GetSpaceTravelGoodsSubType(itemId)
    local isRelic = (goodsSubType == SpaceTravelGoodsSubType.Relic)
    if isRelic then
        assert(itemNum == 1, "the item number of relic should always be 1")
        local slot = self:GetKeepRelicIdx(itemId)
        assert(slot ~= nil, "can't find relic item: "..tostring(itemId))
        table.remove(self._relicList, slot)
        self:ConstructKeepRelicGrid()
    else
        local slot = self:GetKeepGoodsIdx(itemId)
        assert(slot ~= nil, "can't find goods item: "..tostring(itemId))
        local newNum = self._goodsList[slot].num - itemNum
        if newNum <= 0 then
            table.remove(self._goodsList, slot)
            self:ConstructKeepGoodsGrid()
        else
            self._goodsList[slot].num = newNum
            local goodsItem = self._ui.KeepGoodsGrid:GetChild(slot - 1)
            self:ConstructKeepGoodsItem(goodsItem, slot)
        end
    end

    local slot = self:GetDiscardItemIdx(itemId)
    if slot == nil then
        table.insert(self._itemsToDiscard, {id = itemId, num = 0})
        slot = #self._itemsToDiscard
    end

    self._itemsToDiscard[slot].num = self._itemsToDiscard[slot].num + itemNum
    local goodsItem = self._ui.DiscardGoodsGrid:GetChild(slot - 1)
    self:ConstructDiscardGoodsItem(goodsItem, slot)
end

function SpaceTravelChoiceResultCtrl:RestoreItem(itemId, itemNum)
    local goodsSubType = ConfigUtils.GetSpaceTravelGoodsSubType(itemId)
    local isRelic = (goodsSubType == SpaceTravelGoodsSubType.Relic)
    if isRelic then
        assert(itemNum == 1, "the item number of relic should always be 1")
    end

    if isRelic then
        assert(#self._relicList < self._relicMax, "relic item is already full")
        table.insert(self._relicList, itemId)

        local slot = #self._relicList
        local relicItem = self._ui.KeepRelicGrid:GetChild(slot - 1)
        self:CosntructKeepRelicItem(relicItem, slot)
    else
        local slot = self:GetKeepGoodsIdx(itemId)
        if slot == nil then
            assert(#self._goodsList < self._goodsMax, "gooods item is already full")
            table.insert(self._goodsList, {id = itemId, num = 0})
            slot = #self._goodsList    
        end

        self._goodsList[slot].num = self._goodsList[slot].num + itemNum
        local goodsItem = self._ui.KeepGoodsGrid:GetChild(slot - 1)
        self:ConstructKeepGoodsItem(goodsItem, slot)
    end

    local slot = self:GetDiscardItemIdx(itemId)
    local newNum = self._itemsToDiscard[slot].num - itemNum
    if newNum <= 0 then
        table.remove(self._itemsToDiscard, slot)
        self:ConstructDiscardGrid()
    else
        self._itemsToDiscard[slot].num = newNum
        local goodsItem = self._ui.DiscardGoodsGrid:GetChild(slot - 1)
        self:ConstructDiscardGoodsItem(goodsItem, slot)
    end
end

function SpaceTravelChoiceResultCtrl:ConstructDiscardGrid()
    if self._ui.DiscardGoodsGrid.childCount == 0 then
        for idx = 1, MAX_DISCARD_NUM do
            local itemObj = Helper.NewObject(self._ui.GoodsItemTemplate, self._ui.DiscardGoodsGrid)
            itemObj:SetActive(true)
            itemObj.name = tostring(idx)
            CtrlManager.AddClick(self, itemObj)
            CtrlManager.AddPress(self, itemObj)
        end

        self._ui.DiscardGoodsGrid:GetComponent("UIGrid"):Reposition()
    end

    for idx = 1, self._ui.DiscardGoodsGrid.childCount do
        local item = self._ui.DiscardGoodsGrid:GetChild(idx - 1)
        self:ConstructDiscardGoodsItem(item, idx)
    end
end

function SpaceTravelChoiceResultCtrl:ConstructKeepRelicGrid()
    if self._ui.KeepRelicGrid.childCount == 0 then
        for idx = 1, self._relicMax do
            local itemObj = Helper.NewObject(self._ui.GoodsItemTemplate, self._ui.KeepRelicGrid)
            itemObj:SetActive(true)
            itemObj.name = tostring(idx)
            CtrlManager.AddClick(self, itemObj)
            CtrlManager.AddPress(self, itemObj)
        end

        self._ui.KeepRelicGrid:GetComponent("UIGrid"):Reposition()
    end

    for idx = 1, self._ui.KeepRelicGrid.childCount do
        local item = self._ui.KeepRelicGrid:GetChild(idx - 1)
        self:CosntructKeepRelicItem(item, idx)
    end
end

function SpaceTravelChoiceResultCtrl:ConstructKeepGoodsGrid(item, idx)
    if self._ui.KeepGoodsGrid.childCount == 0 then
        for idx = 1, self._goodsMax do
            local itemObj = Helper.NewObject(self._ui.GoodsItemTemplate, self._ui.KeepGoodsGrid)
            itemObj:SetActive(true)
            itemObj.name = tostring(idx)
            CtrlManager.AddClick(self, itemObj)
            CtrlManager.AddPress(self, itemObj)
        end

        self._ui.KeepGoodsGrid:GetComponent("UIGrid"):Reposition()
    end

    for idx = 1, self._ui.KeepGoodsGrid.childCount do
        local item = self._ui.KeepGoodsGrid:GetChild(idx - 1)
        self:ConstructKeepGoodsItem(item, idx)
    end
end

function SpaceTravelChoiceResultCtrl:ConstructDiscardGoodsItem(item, idx)
    local hasItem = (idx <= #self._itemsToDiscard)

    local relicBG = item:Find("RelicBG").gameObject
    local goodsBG = item:Find("GoodsBG").gameObject
    local icon = item:Find("Icon"):GetComponent("UISprite")
    local label = item:Find("Num"):GetComponent("UILabel")

    icon.gameObject:SetActive(hasItem)

    if hasItem then
        local goodsId = self._itemsToDiscard[idx].id
        local goodsNum = self._itemsToDiscard[idx].num

        local goodsSubType = ConfigUtils.GetSpaceTravelGoodsSubType(goodsId)
        local isRelic = (goodsSubType == SpaceTravelGoodsSubType.Relic)

        relicBG:SetActive(isRelic)
        goodsBG:SetActive(not isRelic)

        UIHelper.SetItemIcon(self,icon, goodsId)
        label.text = "x"..tostring(goodsNum)
    else
        relicBG:SetActive(false)
        goodsBG:SetActive(false)
        label.text = ""
    end
end

function SpaceTravelChoiceResultCtrl:CosntructKeepRelicItem(item, idx)
    local hasItem = (idx <= #self._relicList)

    local relicBG = item:Find("RelicBG").gameObject
    local goodsBG = item:Find("GoodsBG").gameObject
    local icon = item:Find("Icon"):GetComponent("UISprite")
    local label = item:Find("Num"):GetComponent("UILabel")

    icon.gameObject:SetActive(hasItem)
    relicBG:SetActive(true)
    goodsBG:SetActive(false)
    label.text = ""

    if hasItem then
        local goodsId = self._relicList[idx]
        UIHelper.SetItemIcon(self,icon, goodsId)
    end
end

function SpaceTravelChoiceResultCtrl:ConstructKeepGoodsItem(item, idx)
    local hasItem = (idx <= #self._goodsList)

    local relicBG = item:Find("RelicBG").gameObject
    local goodsBG = item:Find("GoodsBG").gameObject
    local icon = item:Find("Icon"):GetComponent("UISprite")
    local label = item:Find("Num"):GetComponent("UILabel")

    icon.gameObject:SetActive(hasItem)
    relicBG:SetActive(false)
    goodsBG:SetActive(true)
    label.text = ""

    if hasItem then
        local goodsId = self._goodsList[idx].id
        local goodsNum = self._goodsList[idx].num
        UIHelper.SetItemIcon(self,icon, goodsId)
        label.text = "x"..tostring(goodsNum)
    end
end

function SpaceTravelChoiceResultCtrl:CanRestore(itemId)
    local goodsSubType = ConfigUtils.GetSpaceTravelGoodsSubType(itemId)
    local isRelic = (goodsSubType == SpaceTravelGoodsSubType.Relic)

    if isRelic then
        if #self._relicList >= self._relicMax then
            return false, SAFE_LOC("遗物已达上限")
        end
    else
        for idx = 1, #self._goodsList do
            if self._goodsList[idx].id == itemId then
                return true
            end
        end

        if #self._goodsList >= self._goodsMax then
            return false, SAFE_LOC("物品已达上限")
        end
    end

    return true
end

function SpaceTravelChoiceResultCtrl:CanDiscard(itemId)
    if #self._itemsToDiscard >= MAX_DISCARD_NUM then
        return false, SAFE_LOC("扔的东西太多了")
    end

    return true
end

function SpaceTravelChoiceResultCtrl:ShowHint(msg)
    self._ui.GoodsHintAnimator.gameObject:SetActive(true)
    self._ui.GoodsHintAnimator:Play("ItemHint", 0, 0)
    self._ui.GoodsHintLabel.text = msg
end

-- handle the escapse button
function SpaceTravelChoiceResultCtrl:HandleEscape()
    self:OnClicked(self._ui.Blocker)
end

-- can do jump or not
function SpaceTravelChoiceResultCtrl:CanJump()
    return false
end

-- on clicked
function SpaceTravelChoiceResultCtrl:OnClicked(go)

    if go == self._ui.Blocker then
        if self._currentState == ResultState.Base then
            local isValid = CtrlManager.CheckSpaceTravelSeasonValid(self._seasonId, true)
            if not isValid then
                return true
            end

            if not self:NeedShowDrop() then
                self:SyncBaseData()
                SoundSystem.PlayUICancelSound()
                CtrlManager.PopPanel()
            else
                SoundSystem.PlayUIClickSound()
                self._currentState = ResultState.Drop
                self._ui.BasePanel:SetActive(false)
                self:SetupDrop()
            end
        end
    elseif go.transform.parent == self._ui.DiscardGoodsGrid then
        local idx = tonumber(go.name)
        if idx > #self._itemsToDiscard then
            return true
        end

        local itemId = self._itemsToDiscard[idx].id
        local canDo, msg = self:CanRestore(itemId)
        if not canDo then
            self:ShowHint(msg)
            return true
        end

        SoundSystem.PlayUIClickSound()
        self:RestoreItem(itemId, 1)
    elseif go.transform.parent == self._ui.KeepRelicGrid then
        local idx = tonumber(go.name)
        if idx > #self._relicList then
            return true
        end

        local itemId = self._relicList[idx]
        local canDo, msg = self:CanDiscard(itemId)
        if not canDo then
            self:ShowHint(msg)
            return true
        end

        SoundSystem.PlayUIClickSound()
        self:DiscardItem(itemId, 1)
    elseif go.transform.parent == self._ui.KeepGoodsGrid then
        local idx = tonumber(go.name)
        if idx > #self._goodsList then
            return true
        end

        local itemId = self._goodsList[idx].id
        local canDo, msg = self:CanDiscard(itemId)
        if not canDo then
            self:ShowHint(msg)
            return true
        end

        SoundSystem.PlayUIClickSound()
        self:DiscardItem(itemId, 1)
    elseif go == self._ui.ButtonConfirm then
        local isValid = CtrlManager.CheckSpaceTravelSeasonValid(self._seasonId, true)
        if not isValid then
            return true
        end

        local numToDiscard = #self._itemsToDiscard
        if numToDiscard > 0 then
            local isOk = self:AutoRestoreItems()
            if isOk then
                SoundSystem.PlayUIClickSound()
                self:SyncBaseData()
                self:SyncGoodsData()
                CtrlManager.PopPanel()
            else
                SoundSystem.PlayWarningSound()
                self:ShowHint(SAFE_LOC("背包满了，不能全部拾取"))
            end
        else
            SoundSystem.PlayUIClickSound()
            self:SyncBaseData()
            self:SyncGoodsData()
            CtrlManager.PopPanel()
        end
    elseif go == self._ui.ButtonCancel then
        local isValid = CtrlManager.CheckSpaceTravelSeasonValid(self._seasonId, true)
        if not isValid then
            return true
        end
        
        local finalDrop = self:GetFinalDiscardData()
        if #finalDrop > 0 then
            SoundSystem.PlayUIClickSound()
            local seasonData = GameData.GetSpaceTravelSeasonData(self._seasonId)
            local scoreCapId = GameData.GetScoreCapOfSpaceTravelSeason(self._seasonId, seasonData.scoreCap)
            NetManager.Send('STDropGoods', {
                STSeasonID = self._seasonId, 
                STScoreCapID = scoreCapId, 
                GoodsList = finalDrop,
            }, SpaceTravelChoiceResultCtrl.OnHandleProto, self)
        else
            SoundSystem.PlayUIClickSound()
            self:SyncBaseData()
            self:SyncGoodsData()
            CtrlManager.PopPanel()
        end
    end

	return true
end

function SpaceTravelChoiceResultCtrl:AutoRestoreItems()
    local relicFull = false
    local goodsFull = false
    local currentSlot = 1

    while true do
        local goodsId = self._itemsToDiscard[currentSlot].id
        local goodsNum = self._itemsToDiscard[currentSlot].num
        local goodsSubType = ConfigUtils.GetSpaceTravelGoodsSubType(goodsId)
        local isRelic = (goodsSubType == SpaceTravelGoodsSubType.Relic)
        if self:CanRestore(goodsId) then
            local restoreNum = goodsNum
            if isRelic then
                restoreNum = 1
            end
            self:RestoreItem(goodsId, restoreNum)
        else
            currentSlot = currentSlot + 1
        end

        if #self._itemsToDiscard == 0 or currentSlot > #self._itemsToDiscard then
            break
        end
    end

    return #self._itemsToDiscard == 0
end

function SpaceTravelChoiceResultCtrl:GetFinalDiscardData()
    local ret = {}

    for k, v in pairs(self._itemsToDiscard) do
        table.insert(ret, {v.id, v.num})
    end

    return ret
end

function SpaceTravelChoiceResultCtrl:SyncBaseData()
    if self._capacityMaxChange ~= 0 then
        GameData.ModifySpaceTravelCapacityMax(self._seasonId, self._capacityMaxChange)
    end

    if self._foodMaxChange ~= 0 then
        GameData.ModifySpaceTravelFoodMax(self._seasonId, self._foodMaxChange)
    end

    if self._fuelMaxChange ~= 0 then
        GameData.ModifySpaceTravelFuelMax(self._seasonId, self._fuelMaxChange)
    end

    if self._foodChange ~= 0 then
        GameData.ModifySpaceTravelFood(self._seasonId, self._foodChange)
    end

    if self._fuelChange ~= 0 then
        GameData.ModifySpaceTravelFuel(self._seasonId, self._fuelChange)
    end

    if self._scoreChange ~= 0 then
        GameData.ModifySpaceTravelScore(self._seasonId, self._scoreChange)
    end

    for k, v in pairs(self._friendlinessChange) do
        GameData.ModifySpaceTravelFriendliness(self._seasonId, k, v)
    end
end

function SpaceTravelChoiceResultCtrl:SyncGoodsData()
    GameData.SetSpaceTravelSeasonGoods(self._seasonId, self._relicList, self._goodsList)
end

-- on pressed
function SpaceTravelChoiceResultCtrl:OnPressed(go, pressed, isLong)
    if pressed and isLong then
        if go.transform.parent == self._ui.DiscardGoodsGrid then
            local idx = tonumber(go.name)
            if idx <= #self._itemsToDiscard then
                local goodsId = self._itemsToDiscard[idx].id
                local canDo, msg = self:CanRestore(goodsId)
                if not canDo then
                    self:ShowHint(msg)
                    return
                end

                local goodsSubType = ConfigUtils.GetSpaceTravelGoodsSubType(goodsId)
                local goodsLimit = self._itemsToDiscard[idx].num
                if goodsSubType == SpaceTravelGoodsSubType.Relic then
                    goodsLimit = 1
                end
                SoundSystem.PlayUIClickSound()
                CtrlManager.OpenPanel(CtrlNames.SpaceTravelNumber, {
                    itemId = goodsId,
                    numLimit = goodsLimit,
                    callback = SpaceTravelChoiceResultCtrl.RestoreItem,
                    receiver = self,
                })
            end
        elseif go.transform.parent == self._ui.KeepRelicGrid then
            local idx = tonumber(go.name)
            if idx <= #self._relicList then
                local canDo, msg = self:CanDiscard(self._relicList[idx])
                if not canDo then
                    SoundSystem.PlayWarningSound()
                    self:ShowHint(msg)
                    return
                end

                SoundSystem.PlayUIClickSound()
                CtrlManager.OpenPanel(CtrlNames.SpaceTravelNumber, {
                    itemId = self._relicList[idx],
                    numLimit = 1,
                    callback = SpaceTravelChoiceResultCtrl.DiscardItem,
                    receiver = self,
                })
            end
        elseif go.transform.parent == self._ui.KeepGoodsGrid then
            local idx = tonumber(go.name)
            if idx <= #self._goodsList then
                local canDo, msg = self:CanDiscard(self._goodsList[idx].id)
                if not canDo then
                    SoundSystem.PlayWarningSound()
                    self:ShowHint(msg)
                    return
                end

                SoundSystem.PlayUIClickSound()
                CtrlManager.OpenPanel(CtrlNames.SpaceTravelNumber, {
                    itemId = self._goodsList[idx].id,
                    numLimit = self._goodsList[idx].num,
                    callback = SpaceTravelChoiceResultCtrl.DiscardItem,
                    receiver = self,
                })
            end
        end
    end
end

function SpaceTravelChoiceResultCtrl:OnHandleProto(proto, data, requestData)
    if proto == "STDropGoods" then
        self:SyncBaseData()
        self:SyncGoodsData()
        CtrlManager.PopPanel()
    end
end