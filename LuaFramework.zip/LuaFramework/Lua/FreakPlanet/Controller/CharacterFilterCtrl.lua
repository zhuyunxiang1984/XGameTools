require "FreakPlanet/View/CharacterFilterPanel"

local class = require "FreakPlanet/Utils/middleclass"
CharacterFilterCtrl  = class(CtrlNames.CharacterFilter, BaseCtrl)

local SELECTED_COLOR = Color.New(1, 206 / 255, 37 / 255, 1)
local UNSELECTED_COLOR = Color.New(44 / 255, 48 / 255, 70 / 255, 1)
local _searchName = nil
-- load the ui prefab
function CharacterFilterCtrl:LoadPanel()
	self:CreatePanel("CharacterFilter")
end

-- construct ui panel data
function CharacterFilterCtrl:ConstructUI(obj)
	self._ui = CharacterFilterPanel.Init(obj)
end

-- fill ui with the data
function CharacterFilterCtrl:SetupUI()
    self._filterName = nil
	self._filterElements = self._parameter.filterElements
    self._filterRarities = self._parameter.filterRarities
    self._filterTags = self._parameter.filterTags
    self._filterStages = self._parameter.filterStages
    self._filterSkills = self._parameter.filterSkills
    self._dirty = _searchName or false

    -- hide by default
    self._ui.SearchNameSafeInput:SetText("")
    self._ui.SkillPanel:SetActive(false)

    self:OnFilterElementChanged()
    self:OnFilterRarityChanged()
    self:OnFilterTagChanged()
    self:OnFilterStageChanged()
    self:OnFilterSkillChanged()

    self:RefreshMatchNum()

    for k, v in pairs(self._ui.ElementItems) do
        CtrlManager.AddClick(self, v.item)
    end

    for k, v in pairs(self._ui.RarityItems) do
        CtrlManager.AddClick(self, v.item)
    end

    for k, v in pairs(self._ui.TagItems) do
        CtrlManager.AddClick(self, v.item)
    end

    for k, v in pairs(self._ui.StageItems) do
        CtrlManager.AddClick(self, v.item)
    end

    for k, v in pairs(self._ui.SkillItems) do
        CtrlManager.AddClick(self, v.item)
    end

    CtrlManager.AddClick(self, self._ui.Blocker)
    CtrlManager.AddClick(self, self._ui.SkillBlocker)
    CtrlManager.AddClick(self, self._ui.ButtonReset)

    CtrlManager.AddClick(self, self._ui.ButtonSearch)

    CtrlManager.AddClick(self, self._ui.ButtonChallenge)
    CtrlManager.AddClick(self, self._ui.ButtonExplore)
    CtrlManager.AddClick(self, self._ui.ButtonWorkShop)
end

function CharacterFilterCtrl:IsElementSelected(elementId)
    if Helper.IsEmpty(self._filterElements) then
        return false
    end

    return self._filterElements[elementId] ~= nil
end

function CharacterFilterCtrl:IsRaritySelected(rarity)
    if Helper.IsEmpty(self._filterRarities) then
        return false
    end

    return self._filterRarities[rarity] ~= nil
end

function CharacterFilterCtrl:IsTagSelected(tagId)
    if Helper.IsEmpty(self._filterTags) then
        return false
    end

    return self._filterTags[tagId] ~= nil
end

function CharacterFilterCtrl:IsStageSelected(stage)
    if Helper.IsEmpty(self._filterStages) then
        return false
    end

    return self._filterStages[stage] ~= nil
end

function CharacterFilterCtrl:IsSkillSelected(skillName)
    if Helper.IsEmpty(self._filterSkills) then
        return false
    end

    return self._filterSkills[skillName] ~= nil
end

function CharacterFilterCtrl:OnFilterElementChanged()
    for elementId, v in pairs(self._ui.ElementItems) do
        local selected = self:IsElementSelected(elementId)
        v.selected:SetActive(selected)
        v.unselected:SetActive(not selected)
    end
end

function CharacterFilterCtrl:OnFilterRarityChanged()
    for rarity, v in pairs(self._ui.RarityItems) do
        local selected = self:IsRaritySelected(rarity)
        v.selected:SetActive(selected)
        v.unselected:SetActive(not selected)
    end
end

function CharacterFilterCtrl:OnFilterTagChanged()
    for tagId, v in pairs(self._ui.TagItems) do
        local selected = self:IsTagSelected(tagId)
        v.selected:SetActive(selected)
        v.unselected:SetActive(not selected)
    end
end

function CharacterFilterCtrl:OnFilterStageChanged()
    for stage, v in pairs(self._ui.StageItems) do
        local selected = self:IsStageSelected(stage)
        v.selected:SetActive(selected)
        v.unselected:SetActive(not selected)
    end
end

function CharacterFilterCtrl:OnFilterSkillChanged()
    local hasSkill = not Helper.IsEmpty(self._filterSkills)
    self._ui.ButtonFilterTable:SetActive(not hasSkill)

    local num = self._ui.SkillItemsRoot.childCount
    for idx = num, 1, -1 do
        local item = self._ui.SkillItemsRoot:GetChild(idx - 1)
        item.parent = self._ui.SkillItemPool
    end

    if hasSkill then
        for k, v in pairs(self._filterSkills) do
            local skillItem = nil
            if self._ui.SkillItemPool.childCount == 0 then
                local skillItemObj = Helper.NewObject(self._ui.SkillItemTemplate, self._ui.SkillItemsRoot)
                skillItem = skillItemObj.transform
                CtrlManager.AddClick(self, skillItemObj)
            else
                skillItem = self._ui.SkillItemPool:GetChild(0)
                skillItem.parent = self._ui.SkillItemsRoot
                skillItem.localScale = Vector3.one
                skillItem.localPosition = Vector3.zero
            end

            skillItem.gameObject:SetActive(true)
            skillItem.gameObject.name = k

            self:ConstructSkillItem(skillItem, k)
        end

        self._ui.SkillItemsRoot:GetComponent("UITable"):Reposition()
        self._ui.SkillItemsScrollView:ResetPosition()
    end
end

function CharacterFilterCtrl:ConstructSkillItem(item, skillName)
    local nameLabel = item:Find("Label"):GetComponent("UILabel")
    nameLabel.text = ConfigUtils.GetCharacterSkillFilterShowName(skillName)
end

function CharacterFilterCtrl:RefreshMatchNum()
    local callback = self._parameter.numCallback
    local receiver = self._parameter.receiver

    local num = callback(receiver, {
        filterElements = self._filterElements,
        filterRarities = self._filterRarities,
        filterTags = self._filterTags,
        filterStages = self._filterStages,
        filterSkills = self._filterSkills,
    })

    self._ui.MatchResult.text = string.format(SAFE_LOC("满足条件数量：%d"), num)
end

function CharacterFilterCtrl:RefreshSkillItems()
    for k, v in pairs(self._ui.SkillItems) do
        local selected = self:IsSkillSelected(k)
        if selected then
            v.sprite.color = SELECTED_COLOR
        else
            v.sprite.color = UNSELECTED_COLOR
        end
    end
end

function CharacterFilterCtrl:CheckFilter(itemId, filters)
    if filters == nil then
        filters = {}
        filters[itemId] = 1
    else
        if filters[itemId] == nil then
            filters[itemId] = 1
        else
            filters[itemId] = nil
            if Helper.IsEmpty(filters) then
                filters = nil
            end
        end
    end

    return filters
end

-- on clicked
function CharacterFilterCtrl:OnClicked(go)

    if go == self._ui.Blocker then
        SoundSystem.PlayUICancelSound()
        CtrlManager.PopPanel()
        if self._dirty then
            -- notify final filter
            local callback = self._parameter.resultCallback
            local receiver = self._parameter.receiver
            callback(receiver, {
                filterElements = self._filterElements,
                filterRarities = self._filterRarities,
                filterTags = self._filterTags,
                filterSkills = self._filterSkills,
                filterStages = self._filterStages,
                filterName = nil
            })
        end
    elseif go.transform.parent == self._ui.ElementItemsRoot then
        SoundSystem.PlayUIClickSound()
        local itemId = tonumber(go.name)
        self._filterElements = self:CheckFilter(itemId, self._filterElements)
        self:OnFilterElementChanged()
        self:RefreshMatchNum()
        self._dirty = true
    elseif go.transform.parent == self._ui.RarityItemsRoot then
        SoundSystem.PlayUIClickSound()
        local itemId = tonumber(go.name)
        self._filterRarities = self:CheckFilter(itemId, self._filterRarities)
        self:OnFilterRarityChanged()
        self:RefreshMatchNum()
        self._dirty = true
    elseif go.transform.parent == self._ui.TagItemsRoot then
        SoundSystem.PlayUIClickSound()
        local itemId = tonumber(go.name)
        self._filterTags = self:CheckFilter(itemId, self._filterTags)
        self:OnFilterTagChanged()
        self:RefreshMatchNum()
        self._dirty = true
    elseif go.transform.parent == self._ui.StageItemsRoot then
        SoundSystem.PlayUIClickSound()
        local itemId = tonumber(go.name)
        self._filterStages = self:CheckFilter(itemId, self._filterStages)
        self:OnFilterStageChanged()
        self:RefreshMatchNum()
        self._dirty = true
    elseif go == self._ui.ButtonReset then
        SoundSystem.PlayUIClickSound()
        self._filterElements = nil
        self._filterRarities = nil
        self._filterTags = nil
        self._filterSkills = nil
        self._filterStages = nil

        self._dirty = true
        self:OnFilterElementChanged()
        self:OnFilterRarityChanged()
        self:OnFilterTagChanged()
        self:OnFilterSkillChanged()
        self:OnFilterStageChanged()
        self:RefreshMatchNum()
    elseif go == self._ui.ButtonChallenge then
        SoundSystem.PlayUIClickSound()
        self:FilterCharacter(CharacterSelectMode.Challenge)
    elseif go == self._ui.ButtonExplore then
        SoundSystem.PlayUIClickSound()
        self:FilterCharacter(CharacterSelectMode.Explore)
    elseif go == self._ui.ButtonWorkShop then
        SoundSystem.PlayUIClickSound()
        self:FilterCharacter(CharacterSelectMode.WorkShop)
    elseif go == self._ui.SkillBlocker then
        SoundSystem.PlayUICancelSound()
        self._ui.SkillPanel:SetActive(false)
    elseif go == self._ui.ButtonSearch then

        local filterName = self._ui.SearchNameSafeInput:GetText()

        if Helper.IsEmptyOrNull(filterName) then
            SoundSystem.PlayWarningSound()
            CtrlManager.ShowMessageBox({message = SAFE_LOC("请输入名字"), single = true})
            return true
        end
        _searchName = filterName
        SoundSystem.PlayUIClickSound()
        CtrlManager.PopPanel()
        -- notify final filter
        local callback = self._parameter.resultCallback
        local receiver = self._parameter.receiver
        callback(receiver, {
            filterName = filterName,
        })
    else
        local name = go.name
        if self._ui.SkillItems[name] ~= nil then
            SoundSystem.PlayUIClickSound()
            self._filterSkills = self:CheckFilter(name, self._filterSkills)
            self:OnFilterSkillChanged()
            self:RefreshSkillItems()
            self:RefreshMatchNum()
            self._dirty = true
        end
    end

	return true
end

-- handle the escapse button
function CharacterFilterCtrl:HandleEscape()
    self:OnClicked(self._ui.Blocker)
end

function CharacterFilterCtrl:FilterCharacter(mode)
    self._ui.ExploreSkillRoot.gameObject:SetActive(mode == CharacterSelectMode.Explore)
    self._ui.ChallengeSkillRoot.gameObject:SetActive(mode == CharacterSelectMode.Challenge)
    self._ui.WorkShopSkillRoot.gameObject:SetActive(mode == CharacterSelectMode.WorkShop)
    self:RefreshSkillItems()
    self._ui.SkillPanel:SetActive(true)
end
