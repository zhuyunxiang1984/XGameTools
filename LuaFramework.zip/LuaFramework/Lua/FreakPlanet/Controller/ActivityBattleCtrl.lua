require "FreakPlanet/View/ActivityBattlePanel"

local class = require "FreakPlanet/Utils/middleclass"
ActivityBattleCtrl  = class(CtrlNames.ActivityBattle, BaseCtrl)

-- load the ui prefab
function ActivityBattleCtrl:LoadPanel()
	self:CreatePanel("ActivityBattle")
end

-- construct ui panel data
function ActivityBattleCtrl:ConstructUI(obj)
	self._ui = ActivityBattlePanel.Init(obj)
end

-- destroy implementation
function ActivityBattleCtrl:DestroyImpl()
    GameNotifier.RemoveListener(GameEvent.ActivityBattleChanged, ActivityBattleCtrl.OnActivityBattleChanged, self)
end

-- fill ui with the data
function ActivityBattleCtrl:SetupUI()
    self._activityThemeId = self._parameter.themeId
    self._activityEndTime = self._parameter.endTime
    self._battleList = ConfigUtils.GetActivityBattleList(self._activityThemeId)
    self._battleRecords = GameData.GetActivityBattleRecords(self._activityThemeId)
    self._currentBattleIndex = self:GetCurrentBattleIndex()
    self._ui.LeftTime.text = ""

    self:SetupBattles()
    self:ConstructCurrentBattleInfo()
    
    CtrlManager.AddClick(self, self._ui.Blocker)
    for k, v in pairs(self._ui.ActivityBattles) do
        CtrlManager.AddClick(self, v.item)
    end

    GameNotifier.AddListener(GameEvent.ActivityBattleChanged, ActivityBattleCtrl.OnActivityBattleChanged, self)
end

function ActivityBattleCtrl:GetCurrentBattleIndex()
    for idx = 1, #self._battleRecords do
        local winNum = self._battleRecords[idx].win or 0
        if winNum == 0 then
            return idx
        end
    end

    return #self._battleRecords + 1
end

function ActivityBattleCtrl:SetupBattles()
    for idx = 1, #self._ui.ActivityBattles do
        local hasBattle = (idx <= #self._battleList)
        self._ui.ActivityBattles[idx].item:SetActive(hasBattle)
        if hasBattle then
            local battleId = self._battleList[idx]
            local root = self._ui.ActivityBattles[idx].root
            local arenaObj = Helper.NewObject(self._ui.BattleItemTemplate, root)
            arenaObj:SetActive(true)
            arenaObj.name = tostring(battleId)
            local battleItem = arenaObj.transform
            self:ConstructBattleItem(battleItem, idx)
        end
    end
end

function ActivityBattleCtrl:UpdateImpl(deltaTime)
    local curTime = GameData.GetServerTime()
    local leftTime = math.max(0, self._activityEndTime - curTime)
    if leftTime == 0 then
        self._ui.LeftTime.text = SAFE_LOC("活动已结束")
    else
        self._ui.LeftTime.text = Helper.GetLongTimeString(leftTime)
    end
end

function ActivityBattleCtrl:ConstructBattleItem(item, idx)
    local unlocked = (idx <= self._currentBattleIndex)

    local lockedMark = item:Find("Locked").gameObject
    local unlockMark = item:Find("Unlock").gameObject

    unlockMark:SetActive(unlocked)
    lockedMark:SetActive(not unlocked)

    local currentMark = item:Find("Mark").gameObject
    currentMark:SetActive(idx == self._currentBattleIndex)
end

function ActivityBattleCtrl:OnActivityBattleChanged()
    self._battleRecords = GameData.GetActivityBattleRecords(self._activityThemeId)
    self._currentBattleIndex = self:GetCurrentBattleIndex()
    self:ConstructCurrentBattleInfo()
    
    for idx = 1, #self._ui.ActivityBattles do
        local hasBattle = (idx <= #self._battleList)
        if hasBattle then
            local battleId = self._battleList[idx]
            local root = self._ui.ActivityBattles[idx].root
            if root.childCount > 0 then
                local battleItem = root:GetChild(0)
                self:ConstructBattleItem(battleItem, idx)
            end
        end
    end
end

function ActivityBattleCtrl:ConstructCurrentBattleInfo()
    local showIndex = math.min(self._currentBattleIndex, #self._battleList)
    local battleId = self._battleList[showIndex]
    -- name
    self._ui.Name.text = ConfigUtils.GetActivityBattleName(battleId)
    -- story bg
    local storyIconName, storyIconAtlas, storyIconBundle = ConfigUtils.GetActivityBattleStoryBG(battleId)
    self._ui.StoryBG.sprite2D = self:DynamicLoadSprite(storyIconBundle, storyIconAtlas, storyIconName)
end

-- on clicked
function ActivityBattleCtrl:OnClicked(go)

    if go == self._ui.Blocker then
        SoundSystem.PlayUICancelSound()
        CtrlManager.PopPanel()
    elseif go.transform.parent == self._ui.ActivityBattleRoot then
        if not GameData.IsActivityThemeValid(self._activityThemeId) then
            CtrlManager.ShowMessageBox({message = SAFE_LOC("活动已结束"), single = true})
            return true
        end

        local battleIdx = tonumber(go.name)
        if battleIdx <= self._currentBattleIndex then
            SoundSystem.PlayUIClickSound()
            local battleId = self._battleList[battleIdx]
            CtrlManager.OpenPanel(CtrlNames.ActivityBattleDetail, {
                themeId = self._activityThemeId, 
                battleId = battleId, 
                battleIndex = battleIdx,
            })
        else
            SoundSystem.PlayWarningSound()
        end
    end

	return true
end
