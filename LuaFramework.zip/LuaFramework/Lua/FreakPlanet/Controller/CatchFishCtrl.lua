require "FreakPlanet/View/CatchFishPanel"

local class = require "FreakPlanet/Utils/middleclass"
CatchFishCtrl = class(CtrlNames.CatchFish, BaseCtrl)

-- load the ui prefab
function CatchFishCtrl:LoadPanel()
    self:CreatePanel("CatchFish")
end

local LOCKED_LINE_COLOR = Color.New(46 / 255, 111 / 255, 152 / 255, 1)
local UNLOCK_LINE_COLOR = Color.New(182 / 255, 229 / 255, 1, 1)
local GRID_COUNT = 3

-- construct ui panel data
function CatchFishCtrl:ConstructUI(obj)
    self._ui = CatchFishPanel.Init(obj)
end

-- fill ui with the data
function CatchFishCtrl:SetupUI()
    self._progressBar = {}
    self:SetupFishMap()
    NetManager.Send("FishEntry", {}, CatchFishCtrl.OnHandleProto, self)
end

-- on clicked
function CatchFishCtrl:OnClicked(go)
    local ui = self._ui
    if go == ui.Blocker then
        SoundSystem.PlayUICancelSound()
        CtrlManager.PopPanel()
    elseif go.transform.parent == ui.StageButtonRoot then
        local fishPoolId = tonumber(go.name)
        self:EnterCatchFishPool(fishPoolId)
    elseif go.transform.parent == ui.RewardUIGrid.transform then
        XDebug.Log("LZ", go.name)
        local rewardInfo = string.split(go.name, "_")
        local isPass = rewardInfo[1] == "passReward"
        self:ReceiveCatchFishLevelAward(isPass, tonumber(rewardInfo[2]))
    end
    return true
end

-- 点击关卡地图进入关卡详情界面
function CatchFishCtrl:EnterCatchFishPool(fishPoolId)
    if not GameDataCatchFish.IsChallengeFishPool(fishPoolId) then
        local maxUnlockLevel = GameDataCatchFish.GetMaxUnlockCatchFishLevel()
        if fishPoolId <= maxUnlockLevel then
            SoundSystem.PlayUIClickSound()
            CtrlManager.OpenPanel(CtrlNames.CatchFishStageDetail, { fishPoolId = fishPoolId })
        else
            SoundSystem.PlayWarningSound()
            CtrlManager.ShowMessageBox({ message = SAFE_LOC("需要先完成上一个关卡"), single = true })
        end
    else
        --CtrlManager.OpenPanel(CtrlNames.CatchFishStageDetail, { fishPoolId =  GameDataCatchFish.GetCatchFishChallengeLevel() })
        if GameDataCatchFish.PassAllCommonFishLevel() then
            if GameDataCatchFish.GetCatchFishTotalStar() >= GameDataCatchFish.GetCatchFishChallengeLevelNeedStar() then
                SoundSystem.PlayUIClickSound()
                CtrlManager.OpenPanel(CtrlNames.CatchFishStageDetail, { fishPoolId =  GameDataCatchFish.GetCatchFishChallengeLevel() })
            else
                SoundSystem.PlayWarningSound()
                CtrlManager.ShowMessageBox({ message = SAFE_LOC("当前星星不足，需要更多星星解锁奖励"), single = true })
            end
        else
            SoundSystem.PlayWarningSound()
            CtrlManager.ShowMessageBox({ message = SAFE_LOC("需要先完成上一个关卡"), single = true })
        end
    end
end

function CatchFishCtrl:SetupFishMap()
    local ui = self._ui
    CtrlManager.AddClick(self, ui.Blocker)
    CtrlManager.AddClick(self, ui.ChallengeButtons.node)
    local levelList = GameDataCatchFish.GetCatchFishLevelList()
    for idx = 1, #ui.StageButtons do
        local button = ui.StageButtons[idx].node
        CtrlManager.AddClick(self, button)
        button.name = tostring(levelList[idx])
    end

    local challengeButton = ui.ChallengeButtons.node
    challengeButton.name = GameDataCatchFish.GetCatchFishChallengeLevel()
end

function CatchFishCtrl:NotifyFocus()
    self:UpdateFishMapUI()
    self:UpdateCatchFishRewardUI()
end

function CatchFishCtrl:UpdateFishMapUI()
    local ui = self._ui
    ui.FishPoolContent:SetActive(true)
    self._unlockFishPoolCount = 0
    for idx = 1, #ui.StageButtons do
        local name = ui.StageButtons[idx].name
        name.text = tostring(idx)
        local buttonStar = ui.StageButtons[idx].star
        local fishPoolId = GameDataCatchFish.GetCatchFishPoolIdByIndex(idx)
        if GameDataCatchFish.UnlockCatchFishCommonLevel(fishPoolId) then
            self._unlockFishPoolCount = self._unlockFishPoolCount + 1
        end
        for i = 1, #buttonStar do
            local star = buttonStar[i].star
            local brightIcon = buttonStar[i].bright
            local grayIcon = buttonStar[i].gray
            if not GameDataCatchFish.UnlockCatchFishCommonLevel(fishPoolId) then
                brightIcon:SetActive(false)
                grayIcon:SetActive(true)
            else
                local isBright = GameDataCatchFish.GetCatchFishStar(fishPoolId) >= i
                brightIcon:SetActive(isBright)
                grayIcon:SetActive(not isBright)
            end
        end
    end
    self:MoveFishScrollToLockedPosition(self._unlockFishPoolCount)
    for idx = 1, #ui.StageLines do
        local line = ui.StageLines[idx]
        local fishPoolId = GameDataCatchFish.GetCatchFishPoolIdByIndex(idx)
        if GameDataCatchFish.UnlockCatchFishCommonLevel(fishPoolId + 1) then
            line.color = UNLOCK_LINE_COLOR
        else
            line.color = LOCKED_LINE_COLOR
        end
    end
    local limitLabel = ui.ChallengeButtons.limit
    limitLabel.text = string.format("%d/%d", GameDataCatchFish.GetCatchFishTotalStar(), GameDataCatchFish.GetCatchFishChallengeLevelNeedStar())

end

function CatchFishCtrl:UpdateCatchFishRewardUI()
    local curTotalStar = GameDataCatchFish.GetCatchFishTotalStar()
    self._ui.TotalStarNum.text = tostring(curTotalStar)
    local commonReward = GameDataCatchFish.GetAllCatchFishReward(false)
    local passReward = GameDataCatchFish.GetAllCatchFishReward(true)

    for idx = 1, #commonReward + #passReward do
        local isVip = (idx % 2 == 0)
        local rewardItem = self._ui.RewardUIGrid.transform:GetChild(idx - 1)
        local unlock = rewardItem.transform:Find("unlock").gameObject
        local lock = rewardItem.transform:Find("lock").gameObject
        local hint = rewardItem.transform:Find("Hint").gameObject

        local itemIndex = math.ceil(idx / 2)
        local rewardData = isVip and passReward[itemIndex] or commonReward[itemIndex]

        UIHelper.ConstructItemIconAndNum(self, rewardItem.transform, rewardData.id, rewardData.num)

        if curTotalStar >= rewardData.NeedStar then
            local getReward = GameDataCatchFish.IsGetCatchFishReward(isVip, itemIndex)
            local curActivityThemeId = GameData.GetCurrentActivityTheme()
            local hasVipPassport = GameData.HasActivityPassport(curActivityThemeId)
            self._hasVipPassport = hasVipPassport
            unlock:SetActive(getReward)
            local showHint = false
            local showLock = false
            if isVip then
                showHint = self._hasVipPassport and not getReward
                showLock = not self._hasVipPassport
            else
                showHint = not getReward
            end

            hint:SetActive(showHint)
            lock:SetActive(showLock)
        else
            unlock:SetActive(false)
            lock:SetActive(true)
            hint:SetActive(false)
        end
    end

    self:UpdateFishRewardProgress(GameDataCatchFish.GetCatchFishTotalStar())
end

function CatchFishCtrl:MoveFishScrollToLockedPosition(itemIndex)
    -- 不规则的关卡图,8,20写死
    if itemIndex < 8 then
        return
    else
        itemIndex = math.Clamp(itemIndex, 8, 20)
    end
    local scrollView = self._ui.FishPoolScrollView
    local corners = scrollView.panel.worldCorners
    local panelcenter = (corners[0] + corners[1] + corners[2] + corners[3]) / 4 -- 中心点
    local selectItem = self._ui.StageButtonRoot:GetChild(itemIndex)
    local scrollViewPanelTrans = scrollView.panel.transform
    local selectPos = scrollViewPanelTrans:InverseTransformPoint(selectItem.position)
    selectPos = Vector3.New(selectPos.x, selectPos.y, selectPos.z)
    local panelTopPosition = scrollViewPanelTrans:InverseTransformPoint(panelcenter)

    local localOffset = panelTopPosition - selectPos
    if not scrollView.canMoveHorizontally then
        localOffset.x = 0
    end
    if not scrollView.canMoveVertically then
        localOffset.y = 0
    end
    localOffset.z = 0
    scrollView:DisableSpring()
    scrollView:MoveRelative(Vector3.New(localOffset.x, localOffset.y, localOffset.z))
end

-- RewardScrollView 滑动到指定位置
function CatchFishCtrl:MoveRewardScrollToLockedPosition(itemIndex)
    itemIndex = math.Clamp(itemIndex, 1, #GameDataCatchFish.GetAllCatchFishReward(false) - GRID_COUNT)
    local scrollView = self._ui.RewardScrollView
    local corners = scrollView.panel.worldCorners
    local panelTop = (corners[0] + corners[1]) / 2
    local selectItem = self._ui.RewardUIGrid.transform:GetChild(itemIndex * 2 - 1)
    local scrollViewPanelTrans = scrollView.panel.transform
    local selectPos = scrollViewPanelTrans:InverseTransformPoint(selectItem.position)
    selectPos = Vector3.New(selectPos.x - 50, selectPos.y, selectPos.z)
    local panelTopPosition = scrollViewPanelTrans:InverseTransformPoint(panelTop)

    local localOffset = panelTopPosition - selectPos
    if not scrollView.canMoveHorizontally then
        localOffset.x = 0
    end
    if not scrollView.canMoveVertically then
        localOffset.y = 0
    end
    localOffset.z = 0
    scrollView:DisableSpring()
    scrollView:MoveRelative(Vector3.New(localOffset.x, -localOffset.y, localOffset.z))
end

function CatchFishCtrl:InitCatchFishReward()
    local curTotalStar = GameDataCatchFish.GetCatchFishTotalStar()
    self._ui.TotalStarNum.text = tostring(curTotalStar)
    local commonReward = GameDataCatchFish.GetAllCatchFishReward(false)
    local passReward = GameDataCatchFish.GetAllCatchFishReward(true)
    local UnlockNum = 0
    for idx = 1, #commonReward + #passReward do
        local isVip = (idx % 2 == 0)
        local rewardItem = Helper.NewObject(isVip and self._ui.PassRewardItemTemplate or self._ui.CommonRewardItemTemplate, self._ui.RewardUIGrid.transform)
        local unlock = rewardItem.transform:Find("unlock").gameObject
        local lock = rewardItem.transform:Find("lock").gameObject
        local hint = rewardItem.transform:Find("Hint").gameObject

        rewardItem:SetActive(true)
        local rewardData = nil
        local itemIndex = math.ceil(idx / 2)

        if isVip then
            rewardItem.name = string.format("passReward_%d", itemIndex)
            rewardData = passReward[itemIndex]
        else
            rewardItem.name = string.format("commonReward_%d", itemIndex)
            rewardData = commonReward[itemIndex]
        end
        UIHelper.ConstructItemIconAndNum(self, rewardItem.transform, rewardData.id, rewardData.num)
        if curTotalStar >= rewardData.NeedStar then
            local getReward = GameDataCatchFish.IsGetCatchFishReward(isVip, itemIndex)
            local curActivityThemeId = GameData.GetCurrentActivityTheme()
            local hasVipPassport = GameData.HasActivityPassport(curActivityThemeId)
            self._hasVipPassport = hasVipPassport
            unlock:SetActive(getReward)
            local showHint = false
            local showLock = false
            if isVip then
                showHint = self._hasVipPassport and not getReward
                showLock = not self._hasVipPassport
            else
                showHint = not getReward
            end

            hint:SetActive(showHint)
            lock:SetActive(showLock)
        else
            unlock:SetActive(false)
            lock:SetActive(true)
            hint:SetActive(false)
        end
        if curTotalStar >= rewardData.NeedStar and not isVip then
            UnlockNum = UnlockNum + 1
        end
        CtrlManager.AddClick(self, rewardItem)
    end
    self._ui.RewardUIGrid:Reposition()
    self._ui.RewardScrollView:ResetPosition()
    self:MoveRewardScrollToLockedPosition(UnlockNum)
    local columnNum = #commonReward

    local progressBar = Helper.NewObject(self._ui.progressBarTemplate, self._ui.RewardScrollView.transform)
    progressBar.name = "progressBar"
    --progressBar
    local lastRewardItem = self._ui.RewardUIGrid.transform:GetChild(self._ui.RewardUIGrid.transform.childCount - 1)
    local pos = self._ui.RewardScrollView.transform:InverseTransformPoint(lastRewardItem.position)
    local boxCollider = lastRewardItem:GetComponent("BoxCollider")
    local width = lastRewardItem.localPosition.x + boxCollider.size.x

    progressBar:GetComponent("UIWidget").width = width
    progressBar:SetActive(true)
    progressBar.transform.localPosition = Vector3.New(pos.x + boxCollider.size.x / 2 - width / 2, -190, 0)

    local starList = {}
    for idx = 1, columnNum do
        local rewardItem = self._ui.RewardUIGrid.transform:GetChild(idx * 2 - 1)
        local Star = Helper.NewObject(self._ui.progressStarTemplate, progressBar.transform)
        local item = self._ui.RewardUIGrid.transform:GetChild(idx * 2 - 1)
        local relatePos = progressBar.transform:InverseTransformPoint(rewardItem.position)
        Star.name = string.format("Star%d", idx)
        Star.transform.localPosition = Vector3.New(relatePos.x, 0, 0)
        Star:SetActive(true)
        table.insert(starList, Star)
    end
    local progressBarBg = progressBar.transform:Find("BG")
    local progressBarMask = progressBar.transform:Find("Mask")

    self._progressBar = { star = starList, progressBg = progressBarBg, mask = progressBarMask }
    self:UpdateFishRewardProgress(GameDataCatchFish.GetCatchFishTotalStar())
end

function CatchFishCtrl:UpdateFishRewardProgress(starNum)
    local starList = self._progressBar.star
    local progressBar = self._progressBar.progressBg:GetComponent("UI2DSprite")
    local totalStarNum = #starList

    local commonReward = GameDataCatchFish.GetAllCatchFishReward(false)
    for idx = 1, totalStarNum do
        local needStar = commonReward[idx].NeedStar
        local star = starList[idx]
        local starBg = star.transform:Find("BG")
        local starMask = star.transform:Find("Mask")

        local isShow = (needStar <= starNum)
        local starLabel = star.transform:Find("Num"):GetComponent("UILabel")

        starBg.gameObject:SetActive(isShow)
        starMask.gameObject:SetActive(not isShow)
        starLabel.text = tostring(needStar)

    end
    self:ConstructProgressBar(progressBar)
end

function CatchFishCtrl:ConstructProgressBar(progressBar)
    local index = 1
    local commonReward = GameDataCatchFish.GetAllCatchFishReward(false)
    local curStarNum = GameDataCatchFish.GetCatchFishTotalStar()
    local progressBarWidth = self._progressBar.progressBg.parent:GetComponent("UIWidget").width
    for idx = 1, #commonReward do
        if commonReward[idx].NeedStar <= curStarNum then
            index = index + 1
        end
    end

    local fillAmount = 0
    if index <= 1 then
        local curStar = self._progressBar.star[index]
        local RewardItem = self._ui.RewardUIGrid.transform:GetChild(0)
        local boxCollider = RewardItem:GetComponent("BoxCollider")
        local value = (boxCollider.size.x / 2) / commonReward[index].NeedStar
        local curProgressPos = curStar.transform.localPosition.x - value * (commonReward[index].NeedStar - curStarNum)
        fillAmount = 0.5 + (curProgressPos / (progressBarWidth / 2)) / 2
    elseif index <= #self._progressBar.star then
        local curStar = self._progressBar.star[index]
        local lastStar = self._progressBar.star[index - 1]
        local CurStarPos = curStar.transform.localPosition
        local LastStarPos = lastStar.transform.localPosition

        local value = (CurStarPos.x - LastStarPos.x) / (commonReward[index].NeedStar - commonReward[index - 1].NeedStar)
        local curProgressPos = CurStarPos.x - value * (commonReward[index].NeedStar - curStarNum)
        fillAmount = 0.5 + (curProgressPos / (progressBarWidth / 2)) / 2
    else
        fillAmount = 1
    end
    progressBar.fillAmount = fillAmount
end

function CatchFishCtrl:ReceiveCatchFishLevelAward(isPass, idx)
    local curTotalStar = GameDataCatchFish.GetCatchFishTotalStar()
    local commonReward = GameDataCatchFish.GetAllCatchFishReward(false)
    if curTotalStar >= commonReward[idx].NeedStar then
        if GameDataCatchFish.IsGetCatchFishReward(isPass, idx) then
            SoundSystem.PlayWarningSound()
            CtrlManager.ShowMessageBox({ message = SAFE_LOC("已领取!"), single = true })
        else
            if isPass and not self._hasVipPassport then
                SoundSystem.PlayWarningSound()
                --CtrlManager.ShowMessageBox({message = SAFE_LOC("购买好运霸符，即可获得奖励"), single = true})
                CtrlManager.ShowMessageBox({ message = SAFE_LOC("购买好运霸符，即可获得奖励"), single = false, onConfirm = function()
                    CtrlManager.OpenPanel(CtrlNames.ActivityBuyPassport)
                end, receiver = self, })
            else
                SoundSystem.PlayUIClickSound()
                NetManager.Send("FishGetReward", { ConfigIndex = idx, IsActivityPass = isPass },CatchFishCtrl.OnHandleProto, self)
            end
        end
    else
        SoundSystem.PlayWarningSound()
        CtrlManager.ShowMessageBox({ message = SAFE_LOC("当前星星不足，需要更多星星解锁奖励"), single = true })
    end
end

function CatchFishCtrl:OnHandleProto(proto, data, requestData)
    if proto == "FishEntry" then
        GameDataCatchFish.InitCatchFishLevelData(data)
        self:UpdateFishMapUI()
        self:InitCatchFishReward()
    elseif proto == "FishGetReward" then
        local goldNum = data.RemainGold
        local diamondNum = data.RemainDiamond

        local rewardIndex = data.ConfigIndex
        local isPass = data.IsActivityPass
        local rewardDataList = GameDataCatchFish.GetAllCatchFishReward(isPass)
        local rewardData = rewardDataList[rewardIndex]

        GameData.CollectItem(rewardData.id, rewardData.num, true)
        GameData.SetMoney(ItemType.Gold, goldNum)
        GameData.SetMoney(ItemType.Diamond, diamondNum)
        GameDataCatchFish.SetCatchFishReceivedRewardData(isPass, rewardIndex)
        GameData.CheckAndHintGoalsOfCurrentCountType()

        self:UpdateCatchFishRewardUI()
    end
end

