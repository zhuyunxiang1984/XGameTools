require "FreakPlanet/View/BulletinPanel"

local class = require "FreakPlanet/Utils/middleclass"
BulletinCtrl = class(CtrlNames.Bulletin, BaseCtrl)

local _bulletinData = nil
local _curSelectMenuIndex = 1
local _contentWidth = 400
local _hasBulletinTexture = false

local _MenuBtnOffSprite = { "NoticeDic_Fix_Off", "NoticeDic_Notice_Off", "NoticeDic_Planet_Off", "NoticeDic_Activity_Off", "NoticeDic_Reward_Off", "NoticeDic_RelatedPro_Off" }
local _MenuBtnOnSprite = { "NoticeDic_Fix_On", "NoticeDic_Notice_On", "NoticeDic_Planet_On", "NoticeDic_Activity_On", "NoticeDic_Reward_On", "NoticeDic_RelatedPro_On" }
-- load the ui prefab
function BulletinCtrl:LoadPanel()
    self:CreatePanel("Bulletin")
end

-- construct ui panel data
function BulletinCtrl:ConstructUI(obj)
    self._ui = BulletinPanel.Init(obj)
end

-- fill ui with the data
function BulletinCtrl:SetupUI()

    _bulletinData = GameData.GetBulletinData()
    _contentWidth = self._ui.ScrollView:GetComponent("UIPanel").width - 10

    self:ShowBulletinUI()

    local showSocial = Game.ShowSocial()
    self._ui.ButtonTap:SetActive(ChannelHelper.IsSDKHasMoment())
    self._ui.ButtonQQ:SetActive(showSocial)
    self._ui.ButtonWeibo:SetActive(showSocial)

    for k, v in pairs(self._ui.Menu) do
        CtrlManager.AddClick(self, v.item)
    end

    CtrlManager.AddClick(self, self._ui.Blocker)
    CtrlManager.AddClick(self, self._ui.ButtonQQ)
    CtrlManager.AddClick(self, self._ui.ButtonWeibo)
    CtrlManager.AddClick(self, self._ui.ButtonTap)

    GameNotifier.AddListener(GameEvent.BulletinStateChanged, BulletinCtrl.OnBulletinChanged, self)

end

function BulletinCtrl:DestroyImpl()
    GameNotifier.RemoveListener(GameEvent.BulletinStateChanged, BulletinCtrl.OnBulletinChanged, self)
end

-- on clicked
function BulletinCtrl:OnClicked(go)
    if go == self._ui.Blocker then
        SoundSystem.PlayUICancelSound()
        CtrlManager.PopPanel()
    elseif go == self._ui.ButtonQQ then
        local url = nil
        if Global.currentPlatform == GamePlatform.APPLE then
            url = self:SelectIphoneUrl()
        else
            url = self:SelectAndroidUrl()
        end

        if url ~= nil then
            SoundSystem.PlayUIClickSound()
            UnityEngine.Application.OpenURL(url)
        end
    elseif go == self._ui.ButtonWeibo then
        SoundSystem.PlayUIClickSound()
        UnityEngine.Application.OpenURL(WEIBO_URL)
    elseif go == self._ui.ButtonTap then
        SoundSystem.PlayUIClickSound()
        ChannelHelper.OpenMoment()
    elseif go.transform.parent == self._ui.MenuRoot then
        SoundSystem.PlayUIClickSound()
        local menuName = nil
        local idx = 1
        for k, v in pairs(self._ui.Menu) do
            if go ~= v.item then
                menuName = v.item.name
                idx = idx + 1
            else
                break
            end
        end
        _curSelectMenuIndex = idx
        self._ui.BulletinAnima:Play("Action", 0, 0)
        self:RefreshScrollViewUI()
        GameData.MarkBulletinRead(_bulletinData[_curSelectMenuIndex].type)
        self:RefreshMenu()
    end
    return true
end

--[[
    0 = 维护,
    1 = 公告,
    2 = 星球,
    3 = 活动,
    4 = 礼包,
    5 = 周边,
]]--

function BulletinCtrl:ShowBulletinUI()
    local ui = self._ui
    if Helper.IsEmpty(_bulletinData) then
        self._ui.BulletinTitle.text = SAFE_LOC("公告")
        ui.EmptyRoot:SetActive(true)
        ui.TextBG.gameObject:SetActive(false)
    else
        ui.EmptyRoot:SetActive(false)
        for i = 1, #self._ui.Menu do
            local isShow = i <= #_bulletinData
            self._ui.Menu[i].item:SetActive(isShow)
            if isShow then
                local data = _bulletinData[i]
                local isOn = (i == _curSelectMenuIndex)
                self._ui.Menu[i].item:GetComponent("UISprite").spriteName = _MenuBtnOffSprite[data.type + 1]

                self._ui.Menu[i].item:GetComponent("UIButton").disabledSprite = _MenuBtnOnSprite[data.type + 1]

                self._ui.Menu[i].item:GetComponent("UIButton").isEnabled = not isOn
                self._ui.Menu[i].title.text = data.title
                local hasNewBulletin = GameData.HasNewBulletin(data.type)
                self._ui.Menu[i].hit:SetActive(hasNewBulletin)
            end
        end

        self._ui.MenuUIGrid:Reposition()
        self._ui.BulletinTitle.text = _bulletinData[_curSelectMenuIndex].title
        self:RefreshScrollViewUI()
        self:SetTextureBGUI()

        GameData.MarkBulletinRead(_bulletinData[_curSelectMenuIndex].type)
    end
end

function BulletinCtrl:RefreshMenu()
    for i = 1, #self._ui.Menu do
        local isShow = i <= #_bulletinData
        if isShow then
            local data = _bulletinData[i]
            local isOn = (i == _curSelectMenuIndex)
            self._ui.Menu[i].item:GetComponent("UIButton").isEnabled = not isOn
            self._ui.Menu[i].title.text = data.title
            local hasNewBulletin = GameData.HasNewBulletin(data.type)
            self._ui.Menu[i].hit:SetActive(hasNewBulletin)
        end
    end
    self._ui.BulletinTitle.text = _bulletinData[_curSelectMenuIndex].title
    self:RefreshScrollViewUI()
    self:SetTextureBGUI()
end

function BulletinCtrl:ShowMenuButton(type)
    for _, data in pairs(_bulletinData) do
        if data.type == type then
            return true
        end
    end
    return false
end

function BulletinCtrl:RefreshScrollViewUI()
    self:ResetScrollViewUI()
    local data = _bulletinData[_curSelectMenuIndex]
    if data == nil then
        return false
    end
    local content = data.content

    local labelStart = 0
    local labelEnd = nil
    _hasBulletinTexture = false

    while labelStart ~= nil do
        labelStart = string.find(content, "%[sprite=")
        if labelStart ~= nil then
            labelEnd = string.find(content, "%]%[/sprite%]")
            local url = string.sub(content, labelStart + 8, labelEnd - 1)
            local text = string.sub(content, 1, labelStart - 1)
            if string.len(text) > 0 then
                local texObj = Helper.NewObject(self._ui.TextPrefab, self._ui.Content.transform, 1)
                texObj:GetComponent("UILabel").width = _contentWidth
                texObj:GetComponent("UILabel").text = text
                CtrlManager.AddClickWithFunc(self, texObj, self.OnTextClick)
            end

            local texture = GameData.GetBulletinTexture(url)
            if texture ~= nil then
                _hasBulletinTexture = true
                local textureObj = Helper.NewObject(self._ui.ImagePrefab, self._ui.Content.transform, 1)
                local textureSprite2D = textureObj:GetComponent("UI2DSprite")
                local w = texture.width
                local h = texture.height
                local realHeight = h / w * _contentWidth
                local pivot = Vector2.one * 0.5

                textureSprite2D.sprite2D = UnityEngine.Sprite.Create(texture, UnityEngine.Rect.New(0, 0, w, h), pivot)
                textureSprite2D.width = _contentWidth
                textureSprite2D.height = realHeight
            end

            content = string.sub(content, labelEnd + 10)
        end
    end

    content = string.gsub(content, "%[sprite=", "")
    content = string.gsub(content, "%]%[/sprite%]", "")

    if string.len(content) > 0 then
        local texObj = Helper.NewObject(self._ui.TextPrefab, self._ui.Content.transform, 1)
        texObj:GetComponent("UILabel").width = _contentWidth
        texObj:GetComponent("UILabel").text = content
        CtrlManager.AddClickWithFunc(self, texObj, self.OnTextClick)
    end
    if not _hasBulletinTexture then
        self._ui.ScrollView:GetComponent("UIPanel").baseClipRegion = Vector4.New(56, 58, 436, 456)
    else
        self._ui.ScrollView:GetComponent("UIPanel").baseClipRegion = Vector4.New(56, -91, 436, 754)
    end
    self._ui.Content:Reposition()
    self._ui.ScrollView:ResetPosition()
    return true
end

function BulletinCtrl.OnTextClick(button)
    local url = button:GetComponent("UILabel"):GetUrlAtPosition(UICamera.lastWorldPosition)
    if (url ~= nil) then
        SoundSystem.PlayUIClickSound()
        --UnityEngine.Application.OpenURL(url)
        WJWHelper.OpenWenJuanWangUrl(url)
    end
end

function BulletinCtrl:ResetScrollViewUI()
    for idx = 1, self._ui.Content.transform.childCount do
        local item = self._ui.Content.transform:GetChild(idx - 1)
        destroy(item.gameObject)
    end
end

function BulletinCtrl:OnBulletinChanged()
    self:RefreshMenu()
end

function BulletinCtrl:SetTextureBGUI()
    self._ui.TextBG.gameObject:SetActive(not _hasBulletinTexture)
    if not _hasBulletinTexture then
        if _curSelectMenuIndex == 1 then
            self._ui.TextBG.spriteName = "NoticePic_Fix_001"
        else
            self._ui.TextBG.spriteName = "NoticePic_Notice_001"
        end
    end
end

function BulletinCtrl:CheckQQGroups()
    if Helper.IsEmptyOrNull(Global.ExtraData) then
        return nil
    end

    local json = require "cjson"
    local data = json.decode(Global.ExtraData)
    return data.QQGroups
end

function BulletinCtrl:SelectIphoneUrl()
    local groups = self:CheckQQGroups()
    if Helper.IsEmptyOrNull(groups) then
        return nil
    end
    groups = Helper.StringSplit(groups, ";")
    if #groups == 0 then
        return nil
    end

    local idx = Helper.RandInt(1, #groups)
    local names = Helper.StringSplit(groups[idx], ",")
    if #names ~= 2 then
        return nil
    end

    local finalUrl = string.format("mqqapi://card/show_pslcard?src_type=internal&version=1&uin=%s&key=%s&card_type=group&source=external", names[1], names[2])
    return finalUrl
end

function BulletinCtrl:SelectAndroidUrl()
    local groups = self:CheckQQGroups()
    if Helper.IsEmptyOrNull(groups) then
        return nil
    end

    groups = Helper.StringSplit(groups, ";")
    if #groups == 0 then
        return nil
    end

    local prefixUrl = "mqqopensdkapi://bizAgent/qm/qr?url=http%3A%2F%2Fqm.qq.com%2Fcgi-bin%2Fqm%2Fqr%3Ffrom%3Dapp%26p%3Dandroid%26k%3D"
    local idx = Helper.RandInt(1, #groups)

    local finalUrl = prefixUrl .. groups[idx]
    return finalUrl
end
