require "FreakPlanet/View/SpaceTravelResultPanel"

local class = require "FreakPlanet/Utils/middleclass"
SpaceTravelResultCtrl  = class(CtrlNames.SpaceTravelResult, BaseCtrl)

-- load the ui prefab
function SpaceTravelResultCtrl:LoadPanel()
	self:CreatePanel("SpaceTravelResult")
end

-- construct ui panel data
function SpaceTravelResultCtrl:ConstructUI(obj)
	self._ui = SpaceTravelResultPanel.Init(obj)
end

-- fill ui with the data
function SpaceTravelResultCtrl:SetupUI()
    self._seasonId = self._parameter.seasonId
    self._seasonData = GameData.GetSpaceTravelSeasonData(self._seasonId)
    local seasonStatus = self._seasonData.status
    local isFirstTry = (self._seasonData.seasonRetry <= 1)
    self._ui.ResultPanel:SetActive(isFirstTry or seasonStatus == 0)
    self._ui.SelectionPanel:SetActive(not isFirstTry and seasonStatus == 1)
    if isFirstTry or seasonStatus == 0 then
        self:ConstructReusltDetail()
    end
    -- do settle
    if seasonStatus == 0 then
        self:DoSeasonSettle()
    else
        self:RefreshScore()
    end

    CtrlManager.AddClick(self, self._ui.ButtonConfirm)
    CtrlManager.AddClick(self, self._ui.ButtonUseThis)
    CtrlManager.AddClick(self, self._ui.ButtonUseLast)
end

function SpaceTravelResultCtrl:RefreshScore()
    self._ui.LastScore.text = tostring(self._seasonData.lastScore)
    self._ui.ThisScore.text = tostring(self._seasonData.score)
end

function SpaceTravelResultCtrl:GetResultIcon()
    local seasonData = GameData.GetSpaceTravelSeasonData(self._seasonId)
    local nodeStatus = seasonData.nodeStatus
    if nodeStatus == SpaceTravelNodeStatus.Completed then
        local nodeId = seasonData.node
        local worldIndex = seasonData.world
        local worldId = GameData.GetWorldOfSpaceTravelSeason(self._seasonId, worldIndex)
        local worlCount = GameData.GetSpaceTravelSeasonWorldCount(self._seasonId)
        local isLastWorld = (worldIndex >= worlCount)
        local isLastNode = ConfigUtils.IsLastNodeOfSpaceTravelWorld(worldId, nodeId)
        if isLastWorld and isLastNode then
            return "Win"
        end
    end

    if seasonData.food <= 0 or seasonData.fuel <= 0 then
        return "lose"
    end

    return "GiveUp"
end

function SpaceTravelResultCtrl:ConstructReusltDetail()
    self._ui.ResultIcon.spriteName = self:GetResultIcon()
    self:ShowDetailScore(nil)
end

function SpaceTravelResultCtrl:ShowDetailScore(data)
    self._ui.FinalScore.text = tostring(self._seasonData.score)
    if data ~= nil then
        local fuelScore = data.FuelScore or 0
        local foodScore = data.FoodScore or 0
        local labScore = data.LabScore or 0
        local goodsScore = data.GoodsScore or 0
        local travelScore = (self._seasonData.score - fuelScore - foodScore - labScore - goodsScore)
        self._ui.TravelScore.text = tostring(travelScore)
        self._ui.FuelScore.text = tostring(fuelScore)
        self._ui.FoodScore.text = tostring(foodScore)
        self._ui.LabScore.text = tostring(labScore)
        self._ui.GoodsScore.text = tostring(goodsScore)
    else
        self._ui.TravelScore.text = tostring(self._seasonData.score)
        self._ui.FuelScore.text = "0"
        self._ui.FoodScore.text = "0"
        self._ui.LabScore.text = "0"
        self._ui.GoodsScore.text = "0"
    end
end

function SpaceTravelResultCtrl:DoSeasonSettle()
    assert(self._seasonData.status == 0, "invalid season status: "..tostring(self._seasonData.status))
    local scoreCapId = GameData.GetScoreCapOfSpaceTravelSeason(self._seasonId, self._seasonData.scoreCap)
    NetManager.Send("STSeasonSettle", {
        STSeasonID = self._seasonId, 
        STScoreCapID = scoreCapId,
    }, SpaceTravelResultCtrl.OnHandleProto, self)
end

-- on clicked
function SpaceTravelResultCtrl:OnClicked(go)

    if go == self._ui.ButtonConfirm then
        SoundSystem.PlayUIClickSound()
        assert(self._seasonData.status == 1, "invalid season status: "..tostring(self._seasonData.status))
        if self._seasonData.seasonRetry > 1 then
            -- select result
            self._ui.ResultPanel:SetActive(false)
            self._ui.SelectionPanel:SetActive(true)
        else
            -- if is first try, no history data; finish directly
            NetManager.Send("STData", {}, SpaceTravelResultCtrl.OnHandleProto, self)
        end
    elseif go == self._ui.ButtonUseThis then
        SoundSystem.PlayUIClickSound()
        local scoreCapId = GameData.GetScoreCapOfSpaceTravelSeason(self._seasonId, self._seasonData.scoreCap)
        NetManager.Send("STSeasonResultSelect", {
            STSeasonID = self._seasonId, 
            STScoreCapID = scoreCapId,
            UseResult = true,
        }, SpaceTravelResultCtrl.OnHandleProto, self)
    elseif go == self._ui.ButtonUseLast then
        SoundSystem.PlayUIClickSound()
        local scoreCapId = GameData.GetScoreCapOfSpaceTravelSeason(self._seasonId, self._seasonData.scoreCap)
        NetManager.Send("STSeasonResultSelect", {
            STSeasonID = self._seasonId, 
            STScoreCapID = scoreCapId,
            UseResult = false,
        }, SpaceTravelResultCtrl.OnHandleProto, self)
    end

	return true
end

-- handle the escapse button
function SpaceTravelResultCtrl:HandleEscape()
    -- no escape
end

function SpaceTravelResultCtrl:CanJump()
    return false
end

function SpaceTravelResultCtrl:OnHandleProto(proto, data, requestData)
    if proto == "STSeasonSettle" then
        self._seasonData.status = 1
        GameData.SyncSpaceTravelSeasonBaseData(self._seasonId, data)
        self:ShowDetailScore(data)
        self:RefreshScore()
    elseif proto == "STSeasonResultSelect" then
        NetManager.Send("STData", {}, SpaceTravelResultCtrl.OnHandleProto, self)
    elseif proto == "STData" then
        GameData.InitSpaceTravelData(data)
        CtrlManager.PopToPlanet()
    end
end
