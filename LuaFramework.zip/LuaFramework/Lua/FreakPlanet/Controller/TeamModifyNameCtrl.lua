require "FreakPlanet/View/TeamModifyNamePanel"

local class = require "FreakPlanet/Utils/middleclass"
TeamModifyNameCtrl  = class(CtrlNames.TeamModifyName, BaseCtrl)

-- load the ui prefab
function TeamModifyNameCtrl:LoadPanel()
	self:CreatePanel("TeamModifyName")
end

-- construct ui panel data
function TeamModifyNameCtrl:ConstructUI(obj)
	self._ui = TeamModifyNamePanel.Init(obj)
end

-- fill ui with the data
function TeamModifyNameCtrl:SetupUI()
    self._ui.TeamNameSafeInput:SetText("")

    CtrlManager.AddClick(self, self._ui.Blocker)
    CtrlManager.AddClick(self, self._ui.ButtonConfirm)
end

function TeamModifyNameCtrl:CheckName()
    local originalName = self._parameter.name
    local teamName = self._ui.TeamNameSafeInput:GetText()

    if Helper.IsEmptyOrNull(teamName) then
        SoundSystem.PlayWarningSound()
        CtrlManager.ShowMessageBox({message = SAFE_LOC("队伍名字不能为空"), single = true})
        return false
    end

    -- still same, do nothing
    if originalName == teamName then
        SoundSystem.PlayUIClickSound()
        CtrlManager.PopPanel()
        return false
    end

    local nameLen = Helper.LenOfUtf8(teamName)
    if nameLen > 9 then
        SoundSystem.PlayWarningSound()
        CtrlManager.ShowMessageBox({message = SAFE_LOC("队伍名字长度最多不能超过9个字符"), single = true})
        return false
    end

    local filteredName = Helper.FilterSpecialChars(teamName)
    if filteredName ~= teamName then
        SoundSystem.PlayWarningSound()
        CtrlManager.ShowMessageBox({message = SAFE_LOC("队伍名字只能包含中文﹑英文字母和数字"), single = true})
        return false
    end

    return true
end

function TeamModifyNameCtrl:IsStillSameName()
    local originalName = self._parameter.name
    local newName = self._ui.TeamNameSafeInput:GetText()
    return originalName == newName
end

-- on clicked
function TeamModifyNameCtrl:OnClicked(go)

    if go == self._ui.Blocker then
        SoundSystem.PlayUICancelSound()
        CtrlManager.PopPanel()
    elseif go == self._ui.ButtonConfirm then
        local isValid = self:CheckName()
        if isValid then
            SoundSystem.PlayUIClickSound()
            CtrlManager.PopPanel()
            local teamName = self._ui.TeamNameSafeInput:GetText()
            local teamIdx = self._parameter.index
            local callback = self._parameter.callback
            local receiver = self._parameter.receiver
            callback(receiver, teamIdx, teamName)
        end
    end

	return true
end
