require "FreakPlanet/View/ClothesShopPanel"

local class = require "FreakPlanet/Utils/middleclass"
ClothesShopCtrl  = class(CtrlNames.ClothesShop, BaseCtrl)

--商品一行的最大个数
local MAX_COUNT_PER_SHELF = 4

-- load the ui prefab
function ClothesShopCtrl:LoadPanel()
	self:CreatePanel("ClothesShop")
end

-- construct ui panel data
function ClothesShopCtrl:ConstructUI(obj)
	self._ui = ClothesShopPanel.Init(obj)
end

-- fill ui with the data
function ClothesShopCtrl:SetupUI()
	local ui = self._ui

	--当前货架类型
	self.CurShelfId = 0
	--当前货架的主要货币
	self.CurShopCostItemId = -1

	--商品对象池
	self.ProductObjPool = {}

	--商品对象映射商品Id
	self.ProductObjToProductId = {}

	GameDataClothesShop.UpdateShopState()
	self:ShowShelf(GameDataClothesShop.ClothesShelfId)


	CtrlManager.AddClick(self, ui.btnClose)
	CtrlManager.AddClick(self, ui.btnClothesTab)
	CtrlManager.AddClick(self, ui.btnPresentTab)

	--
	self.OnClothesShopProductBoughtNumChanged = function(id, num)
		for k, v in pairs(self.ProductObjToProductId) do
			if v == id then
				self:UpdateUIShopProduct(k, v)
				break
			end
		end
	end
	--
	self.OnClothesShopStateUpdated = function()
		self:ShowShelf(GameDataClothesShop.ClothesShelfId, true)
	end
	--
	self.OnClothesShopPurchseCompleted = function()
		self:ShowShelf(self.CurShelfId, true)
	end

	GameNotifier.AddListener(GameEvent.ClothesShopProductBoughtNumChanged, self.OnClothesShopProductBoughtNumChanged)
	GameNotifier.AddListener(GameEvent.ClothesShopStateUpdated, self.OnClothesShopStateUpdated)
	GameNotifier.AddListener(GameEvent.ClothesShopPurchseCompleted, self.OnClothesShopPurchseCompleted)
end

function ClothesShopCtrl:DestroyImpl()
	GameNotifier.RemoveListener(GameEvent.ClothesShopProductBoughtNumChanged, self.OnClothesShopProductBoughtNumChanged)
	GameNotifier.RemoveListener(GameEvent.ClothesShopStateUpdated, self.OnClothesShopStateUpdated)
	GameNotifier.RemoveListener(GameEvent.ClothesShopPurchseCompleted, self.OnClothesShopPurchseCompleted)
end

function ClothesShopCtrl:UpdateImpl(deltaTime)
	if self.CurShelfId == GameDataClothesShop.PresentShelfId then
		self:UpdateUILeftTime()
	end
end

-- on clicked
function ClothesShopCtrl:OnClicked(go)
	local ui = self._ui

	if go == ui.btnClose then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
	elseif go == ui.btnClothesTab then
		SoundSystem.PlayUIClickSound()
		self:ShowShelf(GameDataClothesShop.ClothesShelfId)
	elseif go == ui.btnPresentTab then
		SoundSystem.PlayUIClickSound()
		self:ShowShelf(GameDataClothesShop.PresentShelfId)
	else
		for k,v in pairs(self.ProductObjToProductId) do
			if go == k then
				SoundSystem.PlayUIClickSound()
				self:OnClickProduct(v)
				break
			end
		end
	end

	return true
end

---------------------------------------------------------------------------

function ClothesShopCtrl:ShowShelf(shelfId, force)
	if self.CurShelfId == shelfId and not force then
		return
	end
	self.CurShelfId = shelfId
	local shelfInfo = ConfigUtils.GetClothesShopInfo(shelfId)
	self.ProductList = {}
	for i,v in ipairs(shelfInfo.ItemList) do
		table.insert(self.ProductList, v.Value)
	end

	--货币
	self.CurShopCostItemId = ConfigUtils.GetClothesShopCostItem(shelfId)
	--主货柜的货币,在活动期间,用活动商店的货币
	if shelfId == GameDataClothesShop.ClothesShelfId and GameDataClothesShop.ClothesShelfIdForActivity ~= -1 then
		self.CurShopCostItemId = ConfigUtils.GetClothesShopCostItem(GameDataClothesShop.ClothesShelfIdForActivity)
	end

	self:UpdateUIShopShelf(shelfId)
	self:UpdateUIShopTabs()
end

function ClothesShopCtrl:OnCreateShelfItem()
	local ui = self._ui
	return ui.ObjPool:GetOrCreateObj(ui.EnumPrefabType.Shelf)
end
function ClothesShopCtrl:OnUpdateShelfItem(itemObj, itemIndex, dataIndex)
	local ui = self._ui
	local shopId = self.CurShelfId
	local shelfInfo = ConfigUtils.GetClothesShopInfo(shopId)

	for i = 1, MAX_COUNT_PER_SHELF do
		local node = itemObj.transform:Find("Slot"..i)
		local productIndex = (dataIndex - 1) * MAX_COUNT_PER_SHELF + i
		local productId = self.ProductList[productIndex] or -1
		if productId > 0 then
			local productInfo = ConfigUtils.GetClothesShopProductInfo(productId)
			local productObj = self:UpdateProductObj(node, productInfo.Type)
			self:UpdateUIShopProduct(productObj, productId)
			self.ProductObjToProductId[productObj] = productId
		else
			self:UpdateProductObj(node, ui.EnumPrefabType.None)
		end
	end
end

function ClothesShopCtrl:GetPrefabTypeByProductType(productType)
	local ui = self._ui
	if productType == EnumClothesShopProductType.Skin then
		return ui.EnumPrefabType.Skin
	end
	if productType == EnumClothesShopProductType.Item then
		return ui.EnumPrefabType.Item
	end
	return ui.EnumPrefabType.None
end

function ClothesShopCtrl:OnClickProduct(productId)
	XDebug.Log('GGYY', "click " .. productId)
	local shopId = self.CurShelfId
	local productInfo = ConfigUtils.GetClothesShopProductInfo(productId)
	if productInfo.Type == EnumClothesShopProductType.Item then
		CtrlManager.OpenPanel(CtrlNames.ClothesShopItemDetail, {ShopId = shopId, ProductId = productId})
		return
	end
	if productInfo.Type == EnumClothesShopProductType.Skin then
		CtrlManager.OpenPanel(CtrlNames.ClothesShopSkinDetail, {ShopId = shopId, ProductId = productId})
		return
	end

end

---更新UI------------------------------------------------------------------------

function ClothesShopCtrl:UpdateUIShopShelf(shelfId)
	local ui = self._ui
	ui.ObjPool:RecycleAllObj()

	if shelfId == GameDataClothesShop.ClothesShelfId then
		--皮肤店排序(活动中>非活动 未拥有>已拥有)
		table.sort(self.ProductList, function(productId1, productId2)
			local itemId1 = ConfigUtils.GetClothesShopProductItem(productId1)
			local itemId2 = ConfigUtils.GetClothesShopProductItem(productId2)
			local n1, n2 = 0,0
			n1 = GameDataClothesShop.IsProductInActivity(productId1) and -1 or 1
			n2 = GameDataClothesShop.IsProductInActivity(productId2) and -1 or 1
			if n1 ~= n2 then
				return n1 < n2
			end
			n1 = GameData.IsSkinUnlocked(itemId1) and 1 or -1
			n2 = GameData.IsSkinUnlocked(itemId2) and 1 or -1
			if n1 ~= n2 then
				return n1 < n2
			end
			return productId1 < productId2
		end)
	end

	--货物列表
	ui.ScrollView:SetCallback(self, ClothesShopCtrl.OnCreateShelfItem, ClothesShopCtrl.OnUpdateShelfItem)
	ui.ScrollView:InitScrollView(math.ceil(#self.ProductList / MAX_COUNT_PER_SHELF))

	--标题
	if shelfId == GameDataClothesShop.PresentShelfId then
		ui.BasicTitle:SetActive(true)
		self:UpdateUILeftTime()
	else
		ui.BasicTitle:SetActive(false)
	end

	self:UpdateUICurrency()
end

function ClothesShopCtrl:UpdateUICurrency()
	local ui = self._ui
	local itemId = self.CurShopCostItemId
	if itemId == -1 then
		ui.objCurrency:SetActive(false)
	else
		ui.objCurrency:SetActive(true)
		UIHelper.SetItemIcon(self, ui.imgCostItemIcon, itemId)
		ui.txtCostItemAmount.text = GameData.GetItemNum(itemId)
	end
end

function ClothesShopCtrl:UpdateUILeftTime()
	local ui = self._ui
	if self.CurShelfId == GameDataClothesShop.PresentShelfId then
		local leftTime = GameDataClothesShop.GetShopLeftTime(GameDataClothesShop.PresentShelfId)
		ui.LefTime.text = "剩余时间:" .. Helper.GetLongTimeString(leftTime)
	end
end

function ClothesShopCtrl:UpdateProductObj(node, productType)
	local ui = self._ui
	local itemNode = nil
	local curType = ui.EnumPrefabType.None
	if node.childCount > 0 then
		itemNode = node:GetChild(0)
		curType = tonumber(itemNode.name)
	end
	local prefabType = self:GetPrefabTypeByProductType(productType)
	if curType == prefabType and itemNode then
		return itemNode.gameObject
	end
	if curType ~= ui.EnumPrefabType.None then
		ui.ObjPool:RecycleObj(itemNode.gameObject)
	end
	if prefabType ~= ui.EnumPrefabType.None then
		local obj = ui.ObjPool:GetOrCreateObj(prefabType, function(newObj)
			CtrlManager.AddClick(self, newObj)
		end)
		obj.name = tostring(prefabType)
		obj.transform:SetParent(node)
		obj.transform.localScale = Vector3.New(1, 1, 1)
		obj.transform.localPosition = Vector3.zero
		obj.transform.localRotation = Vector3.zero
		return obj
	end
	return nil
end

function ClothesShopCtrl:UpdateUIShopTabs()
	local ui = self._ui

	ui.SelectTab(ui.btnClothesTab, self.CurShelfId == GameDataClothesShop.ClothesShelfId)
	ui.SelectTab(ui.btnPresentTab, self.CurShelfId == GameDataClothesShop.PresentShelfId)
	if GameDataClothesShop.PresentShelfId == -1 then
		ui.objPresentLock:SetActive(true)
		ui.btnPresentTabCollider.enabled = false
	else
		ui.objPresentLock:SetActive(false)
		ui.btnPresentTabCollider.enabled = true
	end
end

function ClothesShopCtrl:UpdateUIShopProduct(productObj, productId)
	local productInfo = ConfigUtils.GetClothesShopProductInfo(productId)
	if productInfo.Type == EnumClothesShopProductType.Skin then
		self:UpdateUIShopProductSkin(productObj, productId, productInfo)
	elseif productInfo.Type == EnumClothesShopProductType.Item then
		self:UpdateUIShopProductItem(productObj, productId, productInfo)
	end
end

function ClothesShopCtrl:UpdateUIShopProductSkin(productObj, productId, productInfo)
	local ui = self._ui
	local view = ui.ViewManager:GetView(productObj, ui.EnumPrefabType.Skin)
	view.txtName.text = productInfo.Name
	local skinId, itemCount = ConfigUtils.GetClothesShopProductItem(productId)
	view.BG.spriteName = UIHelper.GetBorderAndBgByItemId(skinId)
	UIHelper.SetCharacterIconWithSkin(self, view.imgIcon, skinId)

	if GameDataClothesShop.IsProductInActivity(productId) then
		view.objInActivity:SetActive(true)
	else
		view.objInActivity:SetActive(false)
	end

	if GameData.IsSkinUnlocked(skinId) then
		view.objAlreadyHas:SetActive(true)
	else
		view.objAlreadyHas:SetActive(false)
	end

end

function ClothesShopCtrl:UpdateUIShopProductItem(productObj, productId, productInfo)
	local ui = self._ui
	local view = ui.ViewManager:GetView(productObj, ui.EnumPrefabType.Item)
	local shopId = self.CurShelfId
	if productInfo.Limit > 0 then
		view.txtNum.text = string.format("库存:%d", math.max(0, productInfo.Limit - GameDataClothesShop.GetProductBoughtNum(shopId, productId)))
		view.txtNum.gameObject:SetActive(true)
	else
		view.txtNum.gameObject:SetActive(false)
	end

	local itemId, itemCount = ConfigUtils.GetClothesShopProductItem(productId)
	UIHelper.SetItemIcon(self, view.imgIcon, itemId)


	local costDatas = GameDataClothesShop.GetProductCostDatas(shopId, productId)
	local costId, costCount = costDatas[1].CostId, costDatas[1].CostNum
	UIHelper.SetItemIcon(self, view.imgCostItemIcon, costId)
	view.txtPrice.text = tostring(costCount)

	view.objSoldout:SetActive(false)
	--view.imgIcon
end

----------------------------------------------------------------------------------------------
