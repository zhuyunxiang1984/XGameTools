require "FreakPlanet/View/SpaceTravelDealPanel"

local class = require "FreakPlanet/Utils/middleclass"
SpaceTravelDealCtrl  = class(CtrlNames.SpaceTravelDeal, BaseCtrl)

local MAX_DEAL_COUNT = 7
local MAX_RELIC_COUNT = 3
local MAX_SHOP_GOODS_COUNT = 12
local MAX_PLAYER_GOODS_COUNT = 16
local ITEM_SCALE = 1

-- load the ui prefab
function SpaceTravelDealCtrl:LoadPanel()
	self:CreatePanel("SpaceTravelDeal")
end

-- construct ui panel data
function SpaceTravelDealCtrl:ConstructUI(obj)
	self._ui = SpaceTravelDealPanel.Init(obj)
end

-- fill ui with the data
function SpaceTravelDealCtrl:SetupUI()
	self._seasonId = self._parameter.seasonId
    self._choiceId = self._parameter.choiceId
    self._dealId = self._parameter.dealId
    self._friendlinessId = ConfigUtils.GetSpaceTravelDealFriendlinessId(self._dealId)
    self._dealTagMap = ConfigUtils.GetSpaceTravelDealTagMap(self._dealId)
    self._dealMinProfit = ConfigUtils.GetSpaceTravelDealMinProfit(self._dealId)
    self._dealFriendlinessFactor, self._dealFriendlinessMinValue, self._dealFriendlinessMaxValue = ConfigUtils.GetSpaceTravelDealFriendliness(self._dealId)
    -- ui
    self._ui.DealTitle.text = ConfigUtils.GetSpaceTravelDealName(self._dealId)
    self._ui.DealName.text = ConfigUtils.GetSpaceTravelDealShopName(self._dealId)
    self._ui.DealIcon.spriteName = ConfigUtils.GetSpaceTravelDealShopIcon(self._dealId)
    self._ui.DealFriendlinessRoot:SetActive(self._friendlinessId ~= nil)
    self._ui.DealHintAnimator.gameObject:SetActive(false)

    local seasonData = GameData.GetSpaceTravelSeasonData(self._seasonId)
    local relicList = seasonData.relic
    local goodsList = seasonData.goods
    local saleList = ConfigUtils.GetSpaceTravelDealSaleList(self._dealId)

    self._relicList = {}
    for idx = 1, #relicList do
        self._relicList[idx] = {id = relicList[idx], original = 1, selected = 0}
    end

    self._goodsList = {}
    for idx = 1, #goodsList do
        local goodsId = goodsList[idx].id
        local goodsNum = goodsList[idx].num
        self._goodsList[idx] = {id = goodsId, original = goodsNum, selected = 0}
    end

    self._saleList = {}
    self._salePriceMap = {}
    for idx = 1, #saleList do
        local goodsId = saleList[idx].Value
        local goodsNum = saleList[idx].Num
        local goodsPrice = saleList[idx].Price

        self._salePriceMap[goodsId] = goodsPrice
        self._saleList[idx] = {id = goodsId, original = goodsNum, selected = 0}
    end

    self._itemsToBuy = {}
    self._itemsToSell = {}

    self:ConstructShopSaleItems()
    self:ConstructShopSelectedItems()
    self:ConstructPlayerRelicItems()
    self:ConstructPlayerGoodsItems()
    self:ConstructPlayerSelectedItems()
    self:RefreshShopResult()

    CtrlManager.AddClick(self, self._ui.ButtonConfirm)
    CtrlManager.AddClick(self, self._ui.ButtonCancel)
end

function SpaceTravelDealCtrl:ConstructShopSaleItems()
    if self._ui.ShopItemRoot.childCount == 0 then
        for idx = 1, MAX_SHOP_GOODS_COUNT do
            local itemObj = Helper.NewObject(self._ui.GoodsItemTemplate, self._ui.ShopItemRoot, ITEM_SCALE)
            itemObj:SetActive(true)
            itemObj.name = tostring(idx)
            CtrlManager.AddClick(self, itemObj)
            CtrlManager.AddPress(self, itemObj)
        end

        self._ui.ShopItemRoot:GetComponent("UITable"):Reposition()
    end

    for idx = 1, self._ui.ShopItemRoot.childCount do
        local item = self._ui.ShopItemRoot:GetChild(idx - 1)
        self:ConstructShopItem(item, idx)
    end
end

function SpaceTravelDealCtrl:ConstructShopItem(item, idx)
    local isValid = (idx <= #self._saleList)

    local icon = item:Find("Icon"):GetComponent("UISprite")
    local numLabel = item:Find("Num"):GetComponent("UILabel")
    local generalBG = item:Find("GeneralBG").gameObject
    local relicBG = item:Find("RelicBG").gameObject

    icon.gameObject:SetActive(isValid)

    if isValid then
        local itemId = self._saleList[idx].id
        local goodsSubType = ConfigUtils.GetSpaceTravelGoodsSubType(itemId)
        local isRelic = (goodsSubType == SpaceTravelGoodsSubType.Relic)

        local originalNum = self._saleList[idx].original
        local selectedNum = self._saleList[idx].selected

        UIHelper.SetItemIcon(self,icon, itemId)
        numLabel.text = "x"..tostring(originalNum - selectedNum)

        generalBG:SetActive(not isRelic)
        relicBG:SetActive(isRelic)
    else
        numLabel.text = ""
        generalBG:SetActive(true)
        relicBG:SetActive(false)
    end
end

function SpaceTravelDealCtrl:ConstructShopSelectedItems()
    if self._ui.ShopSelectedItemRoot.childCount == 0 then
        for idx = 1, MAX_DEAL_COUNT do
            local itemObj = Helper.NewObject(self._ui.GoodsItemTemplate, self._ui.ShopSelectedItemRoot, ITEM_SCALE)
            itemObj:SetActive(true)
            itemObj.name = tostring(idx)
            CtrlManager.AddClick(self, itemObj)
            CtrlManager.AddPress(self, itemObj)
        end

        self._ui.ShopSelectedItemRoot:GetComponent("UITable"):Reposition()
    end

    for idx = 1, MAX_DEAL_COUNT do
        local item = self._ui.ShopSelectedItemRoot:GetChild(idx - 1)
        self:ConstructShopSelectedItem(item, idx)
    end
end

function SpaceTravelDealCtrl:ConstructShopSelectedItem(item, idx)
    local isValid = (idx <= #self._itemsToBuy)
    local icon = item:Find("Icon"):GetComponent("UISprite")
    local numLabel = item:Find("Num"):GetComponent("UILabel")
    local generalBG = item:Find("GeneralBG").gameObject
    local relicBG = item:Find("RelicBG").gameObject

    icon.gameObject:SetActive(isValid)

    if isValid then
        local goodsId = self._itemsToBuy[idx].id
        local goodsNum = self._itemsToBuy[idx].num
        local goodsSubType = ConfigUtils.GetSpaceTravelGoodsSubType(goodsId)
        local isRelic = (goodsSubType == SpaceTravelGoodsSubType.Relic)
        UIHelper.SetItemIcon(self,icon, goodsId)
        if isRelic then
            numLabel.text = ""
        else
            numLabel.text = "x"..tostring(goodsNum)
        end

        generalBG:SetActive(not isRelic)
        relicBG:SetActive(isRelic)
    else
        numLabel.text = ""
        generalBG:SetActive(true)
        relicBG:SetActive(false)
    end
end

function SpaceTravelDealCtrl:ConstructPlayerRelicItems()
    if self._ui.PlayerRelicRoot.childCount == 0 then
        for idx = 1, MAX_RELIC_COUNT do
            local itemObj = Helper.NewObject(self._ui.GoodsItemTemplate, self._ui.PlayerRelicRoot, ITEM_SCALE)
            itemObj:SetActive(true)
            itemObj.name = tostring(idx)
            CtrlManager.AddClick(self, itemObj)
        end
        self._ui.PlayerRelicRoot:GetComponent("UITable"):Reposition()
    end

    for idx = 1, self._ui.PlayerRelicRoot.childCount do
        local item = self._ui.PlayerRelicRoot:GetChild(idx - 1)
        self:ConstructRelicItem(item, idx)
    end
end

function SpaceTravelDealCtrl:ConstructRelicItem(item, idx)
    local isValid = (idx <= #self._relicList)
    if isValid then
        local itemId = self._relicList[idx].id
        local originalNum = self._relicList[idx].original
        local selectedNum = self._relicList[idx].selected
        isValid = (originalNum > selectedNum)
    end

    local icon = item:Find("Icon"):GetComponent("UISprite")
    local numLabel = item:Find("Num"):GetComponent("UILabel")
    local generalBG = item:Find("GeneralBG").gameObject
    local relicBG = item:Find("RelicBG").gameObject

    icon.gameObject:SetActive(isValid)
    numLabel.text = ""
    generalBG:SetActive(false)
    relicBG:SetActive(true)

    if isValid then
        local itemId = self._relicList[idx].id
        UIHelper.SetItemIcon(self,icon, itemId)
    end
end

function SpaceTravelDealCtrl:ConstructPlayerGoodsItems()
    if self._ui.PlayerGoodsRoot.childCount == 0 then
        for idx = 1, MAX_PLAYER_GOODS_COUNT do
            local itemObj = Helper.NewObject(self._ui.GoodsItemTemplate, self._ui.PlayerGoodsRoot, ITEM_SCALE)
            itemObj:SetActive(true)
            itemObj.name = tostring(idx)
            CtrlManager.AddClick(self, itemObj)
            CtrlManager.AddPress(self, itemObj)
        end
        self._ui.PlayerGoodsRoot:GetComponent("UITable"):Reposition()
    end

    for idx = 1, self._ui.PlayerGoodsRoot.childCount do
        local item = self._ui.PlayerGoodsRoot:GetChild(idx - 1)
        self:ConstructGoodsItem(item, idx)
    end
end

function SpaceTravelDealCtrl:ConstructGoodsItem(item, idx)
    local isValid = (idx <= #self._goodsList)
    local icon = item:Find("Icon"):GetComponent("UISprite")
    local numLabel = item:Find("Num"):GetComponent("UILabel")
    local generalBG = item:Find("GeneralBG").gameObject
    local relicBG = item:Find("RelicBG").gameObject

    icon.gameObject:SetActive(isValid)
    generalBG:SetActive(true)
    relicBG:SetActive(false)

    if isValid then
        local itemId = self._goodsList[idx].id
        local originalNum = self._goodsList[idx].original
        local selectedNum = self._goodsList[idx].selected
        UIHelper.SetItemIcon(self,icon, itemId)
        numLabel.text = "x"..tostring(originalNum - selectedNum)
    else
        numLabel.text = ""
    end
end

function SpaceTravelDealCtrl:ConstructPlayerSelectedItems()
    if self._ui.PlayerSelectedItemRoot.childCount == 0 then
        for idx = 1, MAX_DEAL_COUNT do
            local itemObj = Helper.NewObject(self._ui.GoodsItemTemplate, self._ui.PlayerSelectedItemRoot, ITEM_SCALE)
            itemObj:SetActive(true)
            itemObj.name = tostring(idx)
            CtrlManager.AddClick(self, itemObj)
            CtrlManager.AddPress(self, itemObj)
        end

        self._ui.PlayerSelectedItemRoot:GetComponent("UITable"):Reposition()
    end

    for idx = 1, self._ui.PlayerSelectedItemRoot.childCount do
        local item = self._ui.PlayerSelectedItemRoot:GetChild(idx - 1)
        self:ConstructPlayerSelectedItem(item, idx)
    end
end

function SpaceTravelDealCtrl:ConstructPlayerSelectedItem(item, idx)
    local isValid = (idx <= #self._itemsToSell)
    local icon = item:Find("Icon"):GetComponent("UISprite")
    local numLabel = item:Find("Num"):GetComponent("UILabel")
    local generalBG = item:Find("GeneralBG").gameObject
    local relicBG = item:Find("RelicBG").gameObject

    icon.gameObject:SetActive(isValid)

    if isValid then
        local goodsId = self._itemsToSell[idx].id
        local goodsNum = self._itemsToSell[idx].num
        local goodsSubType = ConfigUtils.GetSpaceTravelGoodsSubType(goodsId)
        local isRelic = (goodsSubType == SpaceTravelGoodsSubType.Relic)
        UIHelper.SetItemIcon(self,icon, goodsId)
        if isRelic then
            numLabel.text = ""
        else
            numLabel.text = "x"..tostring(goodsNum)
        end
        generalBG:SetActive(not isRelic)
        relicBG:SetActive(isRelic)
    else
        numLabel.text = ""
        generalBG:SetActive(true)
        relicBG:SetActive(false)
    end
end

function SpaceTravelDealCtrl:BuyShopItemAt(idx, num)
    assert(idx <= #self._saleList, "sale item out of range: "..tostring(idx).."/"..tostring(#self._saleList))
    local itemId = self._saleList[idx].id
    local originalNum = self._saleList[idx].original
    local selectedNum = self._saleList[idx].selected

    if (num + selectedNum) > originalNum then
        return false, SAFE_LOC("物品不足")
    end

    local goodsSubType = ConfigUtils.GetSpaceTravelGoodsSubType(itemId)
    local isRelic = (goodsSubType == SpaceTravelGoodsSubType.Relic)
    if isRelic then
        assert(num == 1, "relic item should always be 1")
    end

    local slot = nil
    if isRelic then
        if #self._itemsToBuy < MAX_DEAL_COUNT then
            table.insert(self._itemsToBuy, {id = itemId, num = 0})
            slot = #self._itemsToBuy
        end
    else
        for idx = 1, #self._itemsToBuy do
            if self._itemsToBuy[idx].id == itemId then
                slot = idx
                break
            end
        end

        if slot == nil then
            if #self._itemsToBuy < MAX_DEAL_COUNT then
                table.insert(self._itemsToBuy, {id = itemId, num = 0})
                slot = #self._itemsToBuy
            end
        end
    end

    if slot ~= nil then
        self._saleList[idx].selected = selectedNum + num
        self._itemsToBuy[slot].num = self._itemsToBuy[slot].num + num
        local shopItem = self._ui.ShopItemRoot:GetChild(idx - 1)
        self:ConstructShopItem(shopItem, idx)
        local shopSelectedItem = self._ui.ShopSelectedItemRoot:GetChild(slot - 1)
        self:ConstructShopSelectedItem(shopSelectedItem, slot)
        self:RefreshShopResult()
        return true
    end

    return false, SAFE_LOC("买的东西太多了")
end

function SpaceTravelDealCtrl:CancelShopItemAt(idx, num)
    assert(idx <= #self._itemsToBuy, "selected item idx out of range: "..tostring(idx).."/"..tostring(#self._itemsToBuy))

    local goodsId = self._itemsToBuy[idx].id
    local goodsNum = self._itemsToBuy[idx].num
    assert(goodsNum >= num, "the number to cancel is out of range: "..tostring(idx))

    local goodsSubType = ConfigUtils.GetSpaceTravelGoodsSubType(goodsId)
    local isRelic = (goodsSubType == SpaceTravelGoodsSubType.Relic)
    if isRelic then
        assert(num == 1, "relic item should always be 1")
    end

    local curNum = goodsNum - num
    if curNum <= 0 then
        table.remove(self._itemsToBuy, idx)
        self:ConstructShopSelectedItems()
    else
        self._itemsToBuy[idx].num = curNum
        local shopSelectedItem = self._ui.ShopSelectedItemRoot:GetChild(idx - 1)
        self:ConstructShopSelectedItem(shopSelectedItem, idx)
    end

    local saleSlot = self:GetShopItemIdx(goodsId)
    assert(saleSlot ~= nil, "can't find shop item in sale list: "..tostring(goodsId))
    self._saleList[saleSlot].selected = self._saleList[saleSlot].selected - num
    local shopItem = self._ui.ShopItemRoot:GetChild(saleSlot - 1)
    self:ConstructShopItem(shopItem, saleSlot)
    self:RefreshShopResult()
end

function SpaceTravelDealCtrl:SellRelicItemAt(idx)
    if #self._itemsToSell >= MAX_DEAL_COUNT then
        return false, SAFE_LOC("卖的东西太多了")
    end

    assert(idx <= #self._relicList, "relic item idx out of range: "..tostring(idx).."/"..tostring(#self._relicList))
    local itemId = self._relicList[idx].id
    local originalNum = self._relicList[idx].original
    local selectedNum = self._relicList[idx].selected
    if selectedNum >= originalNum then
        return false, SAFE_LOC("物品不足")
    end

    table.insert(self._itemsToSell, {id = itemId, num = 1})
    self._relicList[idx].selected = self._relicList[idx].selected + 1
    
    local relicItem = self._ui.PlayerRelicRoot:GetChild(idx - 1)
    self:ConstructRelicItem(relicItem, idx)

    local slot = #self._itemsToSell
    local playerSelctedItem = self._ui.PlayerSelectedItemRoot:GetChild(slot - 1)
    self:ConstructPlayerSelectedItem(playerSelctedItem, slot)
    self:RefreshShopResult()
    return true
end

function SpaceTravelDealCtrl:SellGoodsItemAt(idx, num)
    assert(idx <= #self._goodsList, "goods item idx out of range: "..tostring(idx).."/"..tostring(#self._goodsList))

    local itemId = self._goodsList[idx].id
    local originalNum = self._goodsList[idx].original
    local selectedNum = self._goodsList[idx].selected
    if (selectedNum + num) > originalNum then
        return false, SAFE_LOC("物品不足")
    end

    local slot = self:GetPlayerSelectedItemIdx(itemId)
    if slot == nil and #self._itemsToSell < MAX_DEAL_COUNT then
        table.insert(self._itemsToSell, {id = itemId, num = 0})
        slot = #self._itemsToSell
    end

    if slot == nil then
        return false, SAFE_LOC("卖的东西太多了")
    end

    self._goodsList[idx].selected = self._goodsList[idx].selected + num
    self._itemsToSell[slot].num = self._itemsToSell[slot].num + num

    local goodsItem = self._ui.PlayerGoodsRoot:GetChild(idx - 1)
    self:ConstructGoodsItem(goodsItem, idx)

    local playerSelctedItem = self._ui.PlayerSelectedItemRoot:GetChild(slot - 1)
    self:ConstructPlayerSelectedItem(playerSelctedItem, slot)

    self:RefreshShopResult()

    return true
end

function SpaceTravelDealCtrl:CancelSellItemAt(idx, num)
    assert(idx <= #self._itemsToSell, "selected goods item idx out of range: "..tostring(idx).."/"..tostring(#self._itemsToSell))

    local itemId = self._itemsToSell[idx].id
    local itemNum = self._itemsToSell[idx].num
    local goodsSubType = ConfigUtils.GetSpaceTravelGoodsSubType(itemId)
    local isRelic = (goodsSubType == SpaceTravelGoodsSubType.Relic)
    if isRelic then
        assert(num == 1, "relic item should always be 1")
    end
    
    local curNum = itemNum - num
    assert(curNum >= 0, "goods number out of range: "..tostring(idx))
    if curNum <= 0 then
        table.remove(self._itemsToSell, idx)
        self:ConstructPlayerSelectedItems()
    else
        self._itemsToSell[idx].num = curNum
        local playerSelctedItem = self._ui.PlayerSelectedItemRoot:GetChild(idx - 1)
        self:ConstructPlayerSelectedItem(playerSelctedItem, idx)
    end

    local itemSlot = nil
    local matchList = {}
    if isRelic then
        matchList = self._relicList
        itemSlot = self:GetPlayerRelicIdx(itemId)
    else
        matchList = self._goodsList
        itemSlot = self:GetPlayerGoodsIdx(itemId)
    end

    assert(itemSlot ~= nil, "can't find goods or relic item in item list: "..tostring(itemId))
    matchList[itemSlot].selected = matchList[itemSlot].selected - num
    
    if isRelic then
        local relicItem = self._ui.PlayerRelicRoot:GetChild(itemSlot - 1)
        self:ConstructRelicItem(relicItem, itemSlot)
    else
        local goodsItem = self._ui.PlayerGoodsRoot:GetChild(itemSlot - 1)
        self:ConstructGoodsItem(goodsItem, itemSlot)
    end

    self:RefreshShopResult()
    return true
end

function SpaceTravelDealCtrl:RefreshShopResult()
    self._totalBuyPrice = 0
    self._totalCapacity = 0
    for k, v in pairs(self._itemsToBuy) do
        local itemId = v.id
        local itemNum = v.num
        local itemCapacity = ConfigUtils.GetSpaceTravelGoodsSupplyCapacity(itemId)

        local price = self._salePriceMap[itemId] or 0
        self._totalBuyPrice = self._totalBuyPrice + price * itemNum
        self._totalCapacity = self._totalCapacity + itemCapacity * itemNum
    end

    local sellPriceMap = {}
    for k, v in pairs(self._itemsToSell) do
        local itemId = v.id
        if sellPriceMap[itemId] == nil then
            local tagList = ConfigUtils.GetSpaceTravelGoodsTags(itemId)
            local itemAbs = 0
            local itemPercent = 0
            for idx = 1, #tagList do
                local tagId = tagList[idx]
                local tagData = self._dealTagMap[tagId]
                if tagData ~= nil then
                    itemAbs = itemAbs + tagData.abs
                    itemPercent = itemPercent + tagData.percent
                end
            end

            local price = ConfigUtils.GetSpaceTravelGoodsPrice(itemId)
            sellPriceMap[itemId] = math.floor((price + itemAbs) * (100 + itemPercent) / 100)
        end
    end

    self._totalSellPrice = 0
    for k, v in pairs(self._itemsToSell) do
        local itemId = v.id
        local itemNum = v.num

        local price = sellPriceMap[itemId] or 0
        self._totalSellPrice = self._totalSellPrice + price * itemNum
    end

    for k, v in pairs(self._relicList) do
        local itemId = v.id
        local leftNum = (v.original - v.selected)
        local itemCapacity = ConfigUtils.GetSpaceTravelGoodsSupplyCapacity(itemId)

        self._totalCapacity = self._totalCapacity + itemCapacity * leftNum
    end

    for k, v in pairs(self._goodsList) do
        local itemId = v.id
        local leftNum = (v.original - v.selected)
        local itemCapacity = ConfigUtils.GetSpaceTravelGoodsSupplyCapacity(itemId)

        self._totalCapacity = self._totalCapacity + itemCapacity * leftNum
    end

    local capacityMax = GameData.GetSpaceTravelItemNum(self._seasonId, ItemType.CapacityMax)
    self._ui.PlayerCapacity.text = string.format("负重 %d/%d", self._totalCapacity, capacityMax)

    local addFriendliness = 0
    local hasSelected = (#self._itemsToBuy > 0 or #self._itemsToSell > 0)
    if not hasSelected then
        local dialogList = ConfigUtils.GetSpaceTravelDealDialogs(self._dealId)
        if #dialogList >= 1 then
            local dialogIdx = Helper.RandInt(1, #dialogList)
            self._ui.DialogLabel.text = SAFE_LOC(dialogList[dialogIdx])
        else
            self._ui.DialogLabel.text = ""
        end
    else
        local priceDiff = (self._totalSellPrice - self._totalBuyPrice)
        local dialog = ConfigUtils.GetSpaceTravelDealHint(self._dealId, priceDiff)
        if dialog ~= nil then
            addFriendliness = (priceDiff / self._dealFriendlinessFactor)
            if addFriendliness > 0 then
                addFriendliness = math.min(addFriendliness, self._dealFriendlinessMaxValue)
                addFriendliness = math.floor(addFriendliness)
            else
                addFriendliness = math.max(addFriendliness, self._dealFriendlinessMinValue)
                addFriendliness = math.ceil(addFriendliness)
            end

            local replaceText = tostring(addFriendliness)
            if addFriendliness > 0 then
                replaceText = "+"..replaceText
            end

            self._ui.DialogLabel.text = Helper.StringFindAndReplace(dialog, "{Value}", replaceText)
        else
            self._ui.DialogLabel.text = ""
        end
    end

    if self._friendlinessId ~= nil then
        local curFriendliness = GameData.GetSpaceTravelItemNum(self._seasonId, self._friendlinessId)
        local maxFriendliness = ConfigUtils.GetSpaceTravelFriendlinessMax(self._friendlinessId)
        local progress = (curFriendliness / maxFriendliness)
        progress = math.max(0, progress)
        progress = math.min(1, progress)
        self._ui.DealFriendlinessProgress.fillAmount = progress
    end

    self._ui.ButtonConfirm:GetComponent("UIButton").isEnabled = hasSelected
end

function SpaceTravelDealCtrl:GetShopItemIdx(itemId)
    for idx = 1, #self._saleList do
        if self._saleList[idx].id == itemId then
            return idx
        end
    end

    return nil
end

function SpaceTravelDealCtrl:GetSelectedShopItemIdx(itemId)
    for idx = 1, #self._itemsToBuy do
        if self._itemsToBuy[idx].id == itemId then
            return idx
        end
    end

    return nil
end

function SpaceTravelDealCtrl:GetPlayerGoodsIdx(itemId)
    for idx = 1, #self._goodsList do
        if self._goodsList[idx].id == itemId then
            return idx
        end
    end

    return nil
end

function SpaceTravelDealCtrl:GetPlayerRelicIdx(itemId)
    for idx = 1, #self._relicList do
        if self._relicList[idx].id == itemId then
            return idx
        end
    end

    return nil
end

function SpaceTravelDealCtrl:GetPlayerSelectedItemIdx(itemId)
    for idx = 1, #self._itemsToSell do
        if self._itemsToSell[idx].id == itemId then
            return idx
        end
    end

    return nil
end

function SpaceTravelDealCtrl:BuyShopItem(itemId, itemNum)
    local shopIdx = self:GetShopItemIdx(itemId)
    self:BuyShopItemAt(shopIdx, itemNum)
end

function SpaceTravelDealCtrl:CancelShopItem(itemId, itemNum)
    local selectedShopIdx = self:GetSelectedShopItemIdx(itemId)
    self:CancelShopItemAt(selectedShopIdx, itemNum)
end

function SpaceTravelDealCtrl:SellGoodsItem(itemId, itemNum)
    local goodsIdx = self:GetPlayerGoodsIdx(itemId)
    self:SellGoodsItemAt(goodsIdx, itemNum)
end

function SpaceTravelDealCtrl:CancelSellItem(itemId, itemNum)
    local selectedSellIdx = self:GetPlayerSelectedItemIdx(itemId)
    self:CancelSellItemAt(selectedSellIdx, itemNum)
end

function SpaceTravelDealCtrl:ShowHint(msg)
    self._ui.DealHintAnimator.gameObject:SetActive(true)
    self._ui.DealHintAnimator:Play("ItemHint", 0, 0)
    self._ui.DealHintLabel.text = msg
end

function SpaceTravelDealCtrl:GetFinalItems()
    local sellItemMap = {}
    for k, v in pairs(self._itemsToSell) do
        local itemId = v.id
        local itemNum = v.num
        local preNum = sellItemMap[itemId] or 0
        sellItemMap[itemId] = preNum + itemNum
    end

    local buyItemMap = {}
    for k, v in pairs(self._itemsToBuy) do
        local itemId = v.id
        local itemNum = v.num
        local preNum = buyItemMap[itemId] or 0
        buyItemMap[itemId] = preNum + itemNum
    end

    local sellItemList = {}
    for k, v in pairs(sellItemMap) do
        table.insert(sellItemList, {k, v})
    end

    local buyItemList = {}
    for k, v in pairs(buyItemMap) do
        table.insert(buyItemList, {k, v})
    end

    if #sellItemList == 0 then
        sellItemList = nil
    end

    if #buyItemList == 0 then
        buyItemList = nil
    end

    return sellItemList, buyItemList
end

-- on clicked
function SpaceTravelDealCtrl:OnClicked(go)

    if go.transform.parent == self._ui.ShopItemRoot then
        local idx = tonumber(go.name)
        if idx > #self._saleList then
            return true
        end

        local result, msg = self:BuyShopItemAt(idx, 1)
        if result then
            SoundSystem.PlayUIClickSound()
        else
            SoundSystem.PlayWarningSound()
            self:ShowHint(msg)
        end
    elseif go.transform.parent == self._ui.ShopSelectedItemRoot then
        local idx = tonumber(go.name)
        if idx > #self._itemsToBuy then
            return true
        end

        SoundSystem.PlayUIClickSound()
        self:CancelShopItemAt(idx, 1)
    elseif go.transform.parent == self._ui.PlayerRelicRoot then
        local idx = tonumber(go.name)
        if idx > #self._relicList then
            return true
        end

        local result, msg = self:SellRelicItemAt(idx)
        if result then
            SoundSystem.PlayUIClickSound()
        else
            SoundSystem.PlayWarningSound()
            self:ShowHint(msg)
        end
    elseif go.transform.parent == self._ui.PlayerGoodsRoot then
        local idx = tonumber(go.name)
        if idx > #self._goodsList then
            return true
        end

        local result, msg = self:SellGoodsItemAt(idx, 1)
        if result then
            SoundSystem.PlayUIClickSound()
        else
            SoundSystem.PlayWarningSound()
            self:ShowHint(msg)
        end
    elseif go.transform.parent == self._ui.PlayerSelectedItemRoot then
        local idx = tonumber(go.name)
        if idx > #self._itemsToSell then
            return true
        end

        SoundSystem.PlayUIClickSound()
        self:CancelSellItemAt(idx, 1)
    elseif go == self._ui.ButtonConfirm then
        local isValid = CtrlManager.CheckSpaceTravelSeasonValid(self._seasonId, true)
        if not isValid then
            return true
        end

        if (self._totalSellPrice - self._totalBuyPrice) < self._dealMinProfit then
            SoundSystem.PlayWarningSound()
            CtrlManager.ShowMessageBox({message = "卖出的物品不够", single = true})
            return true
        end

        SoundSystem.PlayUIClickSound()
        local sellItems, buyItems = self:GetFinalItems()
        local seasonData = GameData.GetSpaceTravelSeasonData(self._seasonId)
        local scoreCapId = GameData.GetScoreCapOfSpaceTravelSeason(self._seasonId, seasonData.scoreCap)
        NetManager.Send('STChoiceDeal', {
            STSeasonID = self._seasonId, 
            STScoreCapID = scoreCapId, 
            BuyGoodsList = buyItems,
            SellGoodsList = sellItems,
        }, SpaceTravelDealCtrl.OnHandleProto, self)
    elseif go == self._ui.ButtonCancel then
        local isValid = CtrlManager.CheckSpaceTravelSeasonValid(self._seasonId, true)
        if not isValid then
            return true
        end
        
        SoundSystem.PlayUIClickSound()
        local seasonData = GameData.GetSpaceTravelSeasonData(self._seasonId)
        local scoreCapId = GameData.GetScoreCapOfSpaceTravelSeason(self._seasonId, seasonData.scoreCap)
        NetManager.Send('STChoiceCancel', {
            STSeasonID = self._seasonId, 
            STScoreCapID = scoreCapId,
            ChoiceId = self._choiceId,
        }, SpaceTravelDealCtrl.OnHandleProto, self)
    end

	return true
end

-- on pressed
function SpaceTravelDealCtrl:OnPressed(go, pressed, isLong)
    if pressed and isLong then
        if go.transform.parent == self._ui.ShopItemRoot then
            local idx = tonumber(go.name)
            if idx <= #self._saleList then
                local originalNum = self._saleList[idx].original
                local selectedNum = self._saleList[idx].selected
                if selectedNum < originalNum then
                    local itemId = self._saleList[idx].id
                    SoundSystem.PlayUIClickSound()
                    CtrlManager.OpenPanel(CtrlNames.SpaceTravelNumber, {
                        itemId = itemId,
                        numLimit = originalNum - selectedNum,
                        callback = SpaceTravelDealCtrl.BuyShopItem,
                        receiver = self,
                    })
                end
            end
        elseif go.transform.parent == self._ui.ShopSelectedItemRoot then
            local idx = tonumber(go.name)
            if idx <= #self._itemsToBuy then
                local itemId = self._itemsToBuy[idx].id
                local selectedNum = self._itemsToBuy[idx].num
                if selectedNum > 0 then
                    SoundSystem.PlayUIClickSound()
                    CtrlManager.OpenPanel(CtrlNames.SpaceTravelNumber, {
                        itemId = itemId,
                        numLimit = selectedNum,
                        callback = SpaceTravelDealCtrl.CancelShopItem,
                        receiver = self,
                    })
                end
            end
        elseif go.transform.parent == self._ui.PlayerGoodsRoot then
            local idx = tonumber(go.name)
            if idx <= #self._goodsList then
                local originalNum = self._goodsList[idx].original
                local selectedNum = self._goodsList[idx].selected
                if selectedNum < originalNum then
                    local itemId = self._goodsList[idx].id
                    SoundSystem.PlayUIClickSound()
                    CtrlManager.OpenPanel(CtrlNames.SpaceTravelNumber, {
                        itemId = itemId,
                        numLimit = originalNum - selectedNum,
                        callback = SpaceTravelDealCtrl.SellGoodsItem,
                        receiver = self,
                    })
                end
            end
        elseif go.transform.parent == self._ui.PlayerSelectedItemRoot then
            local idx = tonumber(go.name)
            if idx <= #self._itemsToSell then
                local itemId = self._itemsToSell[idx].id
                local selectedNum = self._itemsToSell[idx].num
                if selectedNum > 0 then
                    SoundSystem.PlayUIClickSound()
                    CtrlManager.OpenPanel(CtrlNames.SpaceTravelNumber, {
                        itemId = itemId,
                        numLimit = selectedNum,
                        callback = SpaceTravelDealCtrl.CancelSellItem,
                        receiver = self,
                    })
                end
            end
        end
    end
end

function SpaceTravelDealCtrl:OnHandleProto(proto, data, requestData)
    if proto == 'STChoiceDeal' then
        local seasonId = requestData.STSeasonID
        local curFriendliness = data.Friendliness or {}
        
        local costGoalData = {}
        local gainGoalData = {}

        local sellGoodsList = requestData.SellGoodsList or {}
        for k, v in pairs(sellGoodsList) do
            GameData.ConsumeSpaceTravelItem(seasonId, v[1], v[2])
            -- goal
            local e = GameData.SetupItemGoalData(v[1], v[2])
            table.insert(costGoalData, e)
        end
        -- sync status
        GameData.FinishChoiceForSpaceTravelSeason(seasonId, nil)

        local buyGoodsList = requestData.BuyGoodsList or {}
        local parameter = nil
        if #buyGoodsList > 0 then
            parameter = GameData.ConstructSpaceTravelChoiceResultParameter(seasonId, buyGoodsList, data)
            for k, v in pairs(buyGoodsList) do
                -- goal
                local e = GameData.SetupItemGoalData(v[1], v[2])
                table.insert(gainGoalData, e)
            end
        end
        -- career
        GameData.ModifySpaceTravelCareerData(SpaceTravelCareerType.DealCount, 1)
        -- goal
        GameData.DoSpaceTravelGoalSettle(seasonId, TriggerType.DealCost, costGoalData)
        GameData.DoSpaceTravelGoalSettle(seasonId, TriggerType.Deal, gainGoalData)

        local friendlinessChange = GameData.GetSpaceTravelFriendlinessChanges(seasonId, curFriendliness)
        if Helper.TableLength(friendlinessChange) > 0 then
            if parameter == nil then
                parameter = {seasonId = seasonId, finalFood = data.Food, finalFuel = data.Fuel, finalScore = data.Score}
            end
            parameter.friendliness = friendlinessChange
        end
        -- pop panel
        CtrlManager.PopPanel()
        if parameter ~= nil then
            CtrlManager.OpenPanel(CtrlNames.SpaceTravelChoiceResult, parameter)
        else
            GameData.SyncSpaceTravelSeasonBaseData(seasonId, data)
        end
    elseif proto == 'STChoiceCancel' then
        local seasonId = requestData.STSeasonID
        local choiceId = requestData.ChoiceId

        local dropList = GameData.SettleSpaceTravelChoiceCancel(seasonId, choiceId)
        local parameter = nil
        if #dropList > 0 then
            parameter = GameData.ConstructSpaceTravelChoiceResultParameter(seasonId, dropList, data)
        end
        -- pop panel
        CtrlManager.PopPanel()
        if parameter ~= nil then
            CtrlManager.OpenPanel(CtrlNames.SpaceTravelChoiceResult, parameter)
        else
            GameData.SyncSpaceTravelSeasonBaseData(seasonId, data)
        end
    end
end