require "FreakPlanet/View/NotifyPanel"

local class = require "FreakPlanet/Utils/middleclass"
NotifyCtrl  = class(CtrlNames.Notify, BaseCtrl)

local MoveState = {
	None = "None",
	MoveIn = "MoveIn",
	Hold = "Hold",
	MoveOut = "MoveOut",
	HoldWaitTutorial = "HoldWaitTutorial",
}

--------------------------------------------
-- const values
local MOVE_TIME = 0.2
local HOLD_TIME = 3.5
---------------------------------------------

-- load the ui prefab
function NotifyCtrl:LoadPanel()
	self:CreatePanel("Notify")
end

-- construct ui panel data
function NotifyCtrl:ConstructUI(obj)
	self._ui = NotifyPanel.Init(obj)
end

-- fill ui with the data
function NotifyCtrl:SetupUI()
	self._messageQueue = {}
	self._currentState = MoveState.None
	self._timeCounter = 0
	self._jumpParams = nil

	-- init data
	self._exploreData = GameData.GetExploreNotifyData()
	self._activityExploreData = GameData.GetActivityExploreNotifyData()

	CtrlManager.AddClick(self, self._ui.Collider)
	GameNotifier.AddListener(GameEvent.PlanetAreaExplore, NotifyCtrl.OnPlanetAreaExplore, self)
	GameNotifier.AddListener(GameEvent.PlanetAreaSpeedUp, NotifyCtrl.OnPlanetAreaSpeedUp, self)
	GameNotifier.AddListener(GameEvent.ActivityExplore, NotifyCtrl.OnActivityExplore, self)
	GameNotifier.AddListener(GameEvent.ActivityExploreSpeedUp, NotifyCtrl.OnActivityExploreSpeedUp, self)

	local pos = self._ui.Root.localPosition
	local markPos = self._ui.PositionMark.localPosition
	self._leftLimit = pos.x
	self._rightLimit = markPos.x
	pos.y = markPos.y
	self._ui.Root.localPosition = pos
	self._ui.Root.gameObject:SetActive(false)
	self._moveSpeed = math.abs(self._rightLimit - self._leftLimit) / MOVE_TIME
end

-- destructor 
function NotifyCtrl:DestroyImpl()
	GameNotifier.RemoveListener(GameEvent.PlanetAreaExplore, NotifyCtrl.OnPlanetAreaExplore, self)
	GameNotifier.RemoveListener(GameEvent.PlanetAreaSpeedUp, NotifyCtrl.OnPlanetAreaSpeedUp, self)
	GameNotifier.RemoveListener(GameEvent.ActivityExplore, NotifyCtrl.OnActivityExplore, self)
	GameNotifier.RemoveListener(GameEvent.ActivityExploreSpeedUp, NotifyCtrl.OnActivityExploreSpeedUp, self)
end

-- update per frame
function NotifyCtrl:UpdateImpl(deltaTime)
	if self._currentState == MoveState.MoveIn then
		-- move down
		local pos = self._ui.Root.localPosition
		pos.x = pos.x + deltaTime * self._moveSpeed
		pos.x = math.min(pos.x, self._rightLimit)
		self._ui.Root.localPosition = pos
		if pos.x >= self._rightLimit then
			local isTutorial = self._jumpParams.isTutorial or false
			if not isTutorial then
				self._timeCounter = HOLD_TIME
				self._currentState = MoveState.Hold
			else
				self._currentState = MoveState.HoldWaitTutorial
				self:ShowTutorial()
			end
		end
	elseif self._currentState == MoveState.Hold then
		-- hold state
		self._timeCounter = self._timeCounter - deltaTime
		if self._timeCounter <= 0.0 then
			self._timeCounter = 0
			self._currentState = MoveState.MoveOut
		end
	elseif self._currentState == MoveState.MoveOut then
		-- move up
		local pos = self._ui.Root.localPosition
		pos.x = pos.x - deltaTime * self._moveSpeed
		pos.x = math.max(pos.x, self._leftLimit)
		self._ui.Root.localPosition = pos
		if pos.x <= self._leftLimit then
			self:PeekMessage()
		end
	elseif self._currentState == MoveState.HoldWaitTutorial then
		-- do nothing
	end

	self:UpdateNotify()
end

function NotifyCtrl:UpdateNotify()
	local serverTime = GameData.GetServerTime()

	for idx = #self._exploreData, 1, -1 do
		if self._exploreData[idx].endTime <= serverTime then
			self:OnExploreFinished(self._exploreData[idx].areaId)
			table.remove(self._exploreData, idx)
		end
	end

	if self._activityExploreData ~= nil then
		if self._activityExploreData.endTime <= serverTime then
			self:OnExploreFinished(self._activityExploreData.themeId)
			self._activityExploreData = nil
		end
	end
end

-- on clicked
function NotifyCtrl:OnClicked(go)
	if go == self._ui.Collider then
		if self._currentState ~= MoveState.None and self._jumpParams ~= nil and CtrlManager.CanJump() then
			SoundSystem.PlayUIClickSound()
			local jumpValue = self._jumpParams.value
			local itemType = ConfigUtils.GetItemTypeFromId(jumpValue)
			if itemType == ItemType.PlanetArea then
				JumpManager.JumpToPlanetArea(jumpValue)
			elseif itemType == ItemType.Goal then
				JumpManager.JumpToGoal(jumpValue)
			elseif itemType == ItemType.ArenaTheme then
				JumpManager.JumpToArena()
			end
			self._jumpParams = nil
		end
	end

	return true
end

-- show notify
function NotifyCtrl:ShowNotify(msg, parameter)
	table.insert(self._messageQueue, {msg = msg, parameter = parameter})
	if self._currentState == MoveState.None then
		self:PeekMessage()
	end
end

-- peek next message to show
function NotifyCtrl:PeekMessage()
	if #self._messageQueue > 0 then
		--SoundSystem.PlayQuestCompleteSound()
		self._ui.Root.gameObject:SetActive(true)
		self._ui.Message.text = self._messageQueue[1].msg
		self._jumpParams = self._messageQueue[1].parameter
		self._currentState = MoveState.MoveIn
		table.remove(self._messageQueue, 1)
	else
		self._ui.Root.gameObject:SetActive(false)
		self._currentState = MoveState.None
		self._jumpParams = nil
	end
end

function NotifyCtrl:OnGoalConditionCompleted(goalId)
	local goalType = ConfigUtils.GetGoalType(goalId)
	if goalType == GoalType.Achievement then
		local str = "完成成就:[ff0000]"..ConfigUtils.GetGoalName(goalId).."[-]"
		self:ShowNotify(str, {value = goalId})
	elseif goalType == GoalType.Main or goalType == GoalType.Activity then
		local isTutorial = (
			goalId == TutorialConstData.ExploreGoal or 
			goalId == TutorialConstData.ChallengeGoal)
		local str = SAFE_LOC("loc_global_finish_mission")..":[ff0000]"..ConfigUtils.GetGoalName(goalId).."[-]"
		self:ShowNotify(str, {value = goalId, isTutorial = isTutorial})
	elseif goalType == GoalType.Newbie then
		local str = "完成新手:[ff0000]"..ConfigUtils.GetGoalName(goalId).."[-]"
		self:ShowNotify(str, {value = goalId})
	elseif goalType == GoalType.Weekly then
		local str = "完成每周任务:[ff0000]"..ConfigUtils.GetGoalName(goalId).."[-]"
		self:ShowNotify(str, {value = goalId})
	elseif goalType == GoalType.HomeAchievement then
		local str = "完成家园成就:[ff0000]"..ConfigUtils.GetGoalName(goalId).."[-]"
		self:ShowNotify(str, {value = goalId})
	end
end

function NotifyCtrl:OnExploreFinished(exploreId)
	local itemType = ConfigUtils.GetItemTypeFromId(exploreId)
	if itemType == ItemType.PlanetArea then
		local str = "[ff0000]"..ConfigUtils.GetAreaName(exploreId).."[-]"..SAFE_LOC("loc_global_finish_explore")
		self:ShowNotify(str, {value = exploreId})
	elseif itemType == ItemType.ArenaTheme then
		local activityExploreId = ConfigUtils.GetActivityThemeExplore(exploreId)
		local str = "[ff0000]"..ConfigUtils.GetActivityExploreName(activityExploreId).."[-]"..SAFE_LOC("loc_global_finish_explore")
		self:ShowNotify(str, {value = exploreId})
	end
end

function NotifyCtrl:OnPlanetAreaExplore(planetAreaId)
	self._exploreData = GameData.GetExploreNotifyData()
end

function NotifyCtrl:OnPlanetAreaSpeedUp(planetAreaId)
	self._exploreData = GameData.GetExploreNotifyData()
end

function NotifyCtrl:OnActivityExplore()
	self._activityExploreData = GameData.GetActivityExploreNotifyData()
end

function NotifyCtrl:OnActivityExploreSpeedUp()
	self._activityExploreData = GameData.GetActivityExploreNotifyData()
end
-----------------------------------------------------------------
-- tutorial
function NotifyCtrl:ShowTutorial()
	local tutorials = {}

	local position = self._ui.Camera:WorldToScreenPoint(self._ui.Collider.transform.position)
	tutorials[1] = {event = Tutorials.Tutorial_ExploreGoalNotify, position = position, sender = self}

	CtrlManager.ShowTutorials(tutorials)

	return true
end

function NotifyCtrl:OnTutorialClicked(tutorial)
	if tutorial == Tutorials.Tutorial_ExploreGoalNotify then
		self:OnClicked(self._ui.Collider)
		self._timeCounter = 0.1
		self._currentState = MoveState.Hold
	end
end