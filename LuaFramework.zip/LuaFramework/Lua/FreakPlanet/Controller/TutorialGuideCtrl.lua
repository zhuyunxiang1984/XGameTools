require "FreakPlanet/View/TutorialGuidePanel"

local class = require "FreakPlanet/Utils/middleclass"
TutorialGuideCtrl  = class(CtrlNames.TutorialGuide, BaseCtrl)

-- load the ui prefab
function TutorialGuideCtrl:LoadPanel()
	self:CreatePanel("TutorialGuide")
end

-- construct ui panel data
function TutorialGuideCtrl:ConstructUI(obj)
	self._ui = TutorialGuidePanel.Init(obj)
end

-- fill ui with the data
function TutorialGuideCtrl:SetupUI()
	self._ui.Panel:SetActive(false)
	CtrlManager.AddClick(self, self._ui.Mask.gameObject)
end

function TutorialGuideCtrl:Reset()
	local ui = self._ui
	for i = 1, ui.NodeRoot.childCount do
		local child = ui.NodeRoot:GetChild(i - 1)
		child.gameObject:SetActive(false)
	end
	ui.Picture2D.gameObject:SetActive(false)
	self:HideFinger()
	self:HideHintText()
	self:HideClickHint()
	self:HideMask()
	self:HideBlocker()
end

function TutorialGuideCtrl:ShowTutorials(events)
	self:Reset()
	self._tutorialEvents = events
	self._tutorialIdx = 1
	self:OnTutorialIndexChanged()
	self._ui.Panel:SetActive(true)
	self:ShowBlocker()
end

function TutorialGuideCtrl:OnTutorialIndexChanged()
	local eventName = self._tutorialEvents[self._tutorialIdx].event
	local tutorialInfo = TutorialConfig[eventName]
	XDebug.Log('GGYY', "enter tutorial " .. eventName)

	local selectedNode = nil
	local tutorialNode = tutorialInfo.Node
	for idx = 1, self._ui.NodeRoot.childCount do
		local item = self._ui.NodeRoot:GetChild(idx - 1).gameObject
		local show = (item.name == tutorialNode)
		item:SetActive(show)
		if show then
			selectedNode = item.transform
		end
	end

	if selectedNode ~= nil then
		local label = selectedNode:Find("Text/Label"):GetComponent("UILabel")
		local tutorialText = tutorialInfo.Text
		if tutorialText ~= nil then
			label.text = SAFE_LOC(tutorialText)
		end
	end

	local showHand = tutorialInfo.ShowHand or false
	self._ui.HintHand.gameObject:SetActive(showHand)

	local screenPosition = self._tutorialEvents[self._tutorialIdx].position
	if tutorialInfo.FingerX and tutorialInfo.FingerY then
		self:SetMaskLocalPos(tutorialInfo.FingerX, tutorialInfo.FingerY)

	else
		local pos = self._ui.Camera:ScreenToWorldPoint(screenPosition)
		pos.z = 0
		self:SetMaskPos(pos, tutorialInfo.OffsetX, tutorialInfo.OffsetY)
	end


	local configWidth = tutorialInfo.Width
	local configHeight = tutorialInfo.Height

	self._ui.Slice.width = configWidth
	self._ui.Slice.height = configHeight

	local fillWidth = self._ui.MaskIcon.FillWidth
	local fillHeight = self._ui.MaskIcon.FillHeight

	self._ui.Mask.localScale = Vector3.New(configWidth / fillWidth, configHeight / fillHeight, 1)

	if showHand then
		local p = self._ui.HintHand.localPosition
		p.x = configWidth / 2
		p.y = -configHeight / 2
		p.z = 0
		self._ui.HintHand.localPosition = p
	end
end

function TutorialGuideCtrl:SetMaskLocalPos(posx, posy)
	local trans1 = self._ui.Mask
	local trans2 = self._ui.Slice.transform

	trans1.gameObject:SetActive(true)
	trans2.gameObject:SetActive(true)

	local localPosition = trans1.localPosition
	localPosition.x = posx
	localPosition.y = posy
	trans1.localPosition = localPosition

	local localPosition = trans2.localPosition
	localPosition.x = posx
	localPosition.y = posy
	trans2.localPosition = localPosition
end

function TutorialGuideCtrl:SetMaskPos(pos, offsetx, offsety)
	local trans1 = self._ui.Mask
	local trans2 = self._ui.Slice.transform
	trans1.position = pos
	trans1.gameObject:SetActive(true)

	trans2.position = pos
	trans2.gameObject:SetActive(true)

	if offsetx then
		local localPosition = trans1.localPosition
		localPosition.x = localPosition.x + offsetx
		trans1.localPosition = localPosition

		local localPosition = trans2.localPosition
		localPosition.x = localPosition.x + offsetx
		trans2.localPosition = localPosition
	end
	if offsety then
		local localPosition = trans1.localPosition
		localPosition.y = localPosition.y + offsety
		trans1.localPosition = localPosition

		local localPosition = trans2.localPosition
		localPosition.y = localPosition.y + offsety
		trans2.localPosition = localPosition
	end
end

-- on clicked
function TutorialGuideCtrl:OnClicked(go)
	if go == self._ui.Mask.gameObject then
		self:HandleClick()
	end

	return true
end

function TutorialGuideCtrl:HandleClick()
	local tutorial = self._tutorialEvents[self._tutorialIdx]
	-- sync the tutorial data
	GameData.FinishTutorial(tutorial.event)
	self:OnTutorialFinish()
end

function TutorialGuideCtrl:OnTutorialFinish()
	local tutorial = self._tutorialEvents[self._tutorialIdx]
	if self._tutorialIdx >= #self._tutorialEvents then
		if TutorialConfig[tutorial.event].ClosePage then
			self._ui.Panel:SetActive(false)
		end
	end

	if tutorial.sender ~= nil then
		local clickHandled = tutorial.clickHandled or false
		if not clickHandled then
			tutorial.sender:OnTutorialClicked(tutorial.event)
			tutorial.clickHandled = true
		end
	else
		SoundSystem.PlayUIClickSound()
	end

	-- report tutorial event
	ChannelHelper.ReportToBokeAd(BokeAdEventType.TutorialEvent, {
		uid = GameData.GetDefaultAccountUserId(),
		tutorial = tutorial.event, 
		ts = os.time(),
	})

	if self._tutorialIdx < #self._tutorialEvents then
		self._tutorialIdx = self._tutorialIdx + 1
		self:OnTutorialIndexChanged()
	end
end

function TutorialGuideCtrl:ForceHide()
	self._tutorialEvents = {}
	self._ui.Panel:SetActive(false)
end

function TutorialGuideCtrl:IsOn()
	return self._ui ~= nil and self._ui.Panel.activeSelf
end

function TutorialGuideCtrl:OnHandleProto(proto, data, requestData)
	if proto == "SyncTutorial" then
		self:OnTutorialFinish()
	end
end

-------------------------------------------------------------------------
---
function TutorialGuideCtrl:GetUI()
	return self._ui
end
function TutorialGuideCtrl:IsShow()
	return self._ui and self._ui.Panel.activeSelf
end
function TutorialGuideCtrl:ShowPanel()
	self._ui.Panel:SetActive(true)
end
function TutorialGuideCtrl:HidePanel()
	self._ui.Panel:SetActive(false)
end
function TutorialGuideCtrl:ShowMask()
	self._ui.MaskBg:SetActive(true)
end
function TutorialGuideCtrl:HideMask()
	self._ui.MaskBg:SetActive(false)
end
function TutorialGuideCtrl:ShowBlocker()
	self._ui.Blocker:SetActive(true)
end
function TutorialGuideCtrl:HideBlocker()
	self._ui.Blocker:SetActive(false)
end
function TutorialGuideCtrl:ShowClickHint(x, y, w, h, showHand)
	local ui = self._ui
	ui.Slice.gameObject:SetActive(true)
	ui.Slice.width = w
	ui.Slice.height = h

	local fillWidth = ui.MaskIcon.FillWidth
	local fillHeight = ui.MaskIcon.FillHeight

	local scale = ui.Mask.localScale
	scale.x = w / fillWidth
	scale.y = h / fillHeight
	scale.z = 1
	ui.Mask.localScale = scale
	ui.Mask.gameObject:SetActive(true)
	if showHand then
		ui.HintHand.gameObject:SetActive(true)
		local p = ui.HintHand.localPosition
		p.x = w / 2
		p.y = -h / 2
		p.z = 0
		ui.HintHand.localPosition = p
	end
	if ui.MaskBg.activeSelf then
		self._IsMaskBgShowBefore = true
		self:HideMask()
	end
end
function TutorialGuideCtrl:HideClickHint()
	local ui = self._ui
	ui.Slice.gameObject:SetActive(false)
	ui.Mask.gameObject:SetActive(false)
	ui.HintHand.gameObject:SetActive(false)

	if self._IsMaskBgShowBefore then
		self:ShowMask()
		self._IsMaskBgShowBefore = false
	end
end

function TutorialGuideCtrl:ShowFinger(x, y)
	local ui = self._ui
	ui.Finger.gameObject:SetActive(true)
	local p = ui.Finger.localPosition
	p.x = x
	p.y = y
	p.z = 0
	ui.Finger.localPosition = p
end

function TutorialGuideCtrl:HideFinger()
	local ui = self._ui
	ui.Finger.gameObject:SetActive(false)
end

function TutorialGuideCtrl:ShowHintText(x, y, text)
	local ui = self._ui
	ui.HintText.gameObject:SetActive(true)
	ui.HintText:GetComponent("UILabel").text = text
	local p = ui.HintText.localPosition
	p.x = x
	p.y = y
	p.z = 0
	ui.HintText.localPosition = p
end

function TutorialGuideCtrl:HideHintText()
	local ui = self._ui
	ui.HintText.gameObject:SetActive(false)
end