require "FreakPlanet/View/ArenaMarketPanel"

local class = require "FreakPlanet/Utils/middleclass"
ArenaMarketCtrl  = class(CtrlNames.ArenaMarket, BaseCtrl)
--------------------------------------------------------------------
local function ArenaMarketSortFunc(idA, idB)
	if idA == nil or idB == nil then
		return false
	end

	local valueA = ConfigUtils.GetArenaShopSortId(idA)
	local valueB = ConfigUtils.GetArenaShopSortId(idB)

	return valueA < valueB
end
--------------------------------------------------------------------
-- load the ui prefab
function ArenaMarketCtrl:LoadPanel()
	self:CreatePanel("ArenaMarket")
end

-- construct ui panel data
function ArenaMarketCtrl:ConstructUI(obj)
	self._ui = ArenaMarketPanel.Init(obj)
end

-- fill ui with the data
function ArenaMarketCtrl:SetupUI()
	-- refresh first
	GameData.CheckArenaShopRefreshTime()
	-- get next fresh time
	self._arenaShopRefreshTime = GameData.GetArenaShopRefreshTime()
	self._costGoodsList = ConfigUtils.GetArenaShopCostGoodsList()
	-- cost goods
	for idx = 1, #self._ui.MarketCostItems do
		local hasCost = (idx <= #self._costGoodsList)
		self._ui.MarketCostItems[idx].item:SetActive(hasCost)
		if hasCost then
			UIHelper.SetItemIcon(self,self._ui.MarketCostItems[idx].icon, self._costGoodsList[idx])
		end
	end
	self:RefreshArenaCostGoodsNum()
	-- item list
	local characterList, basicList, limitedList = ConfigUtils.GetArenaShops()
	table.sort( basicList, ArenaMarketSortFunc )
	table.sort( limitedList, ArenaMarketSortFunc )

	for idx = 1, #characterList do
		local shopId = characterList[idx]
		local itemObj = Helper.NewObject(self._ui.CharacterItemTemplate, self._ui.CharacterRoot)
		itemObj:SetActive(true)
		itemObj.name = tostring(shopId)
		CtrlManager.AddClick(self, itemObj)
		self:ConstructShopItem(itemObj.transform, shopId)
	end

	for idx = 1, #basicList do
		local shopId = basicList[idx]
		local itemObj = Helper.NewObject(self._ui.MarketItemTemplate, self._ui.BasicRoot)
		itemObj:SetActive(true)
		itemObj.name = tostring(shopId)
		CtrlManager.AddClick(self, itemObj)
		self:ConstructShopItem(itemObj.transform, shopId)
	end

	for idx = 1, #limitedList do
		local shopId = limitedList[idx]
		local itemObj = Helper.NewObject(self._ui.MarketItemTemplate, self._ui.LimitedRoot)
		itemObj:SetActive(true)
		itemObj.name = tostring(shopId)
		CtrlManager.AddClick(self, itemObj)
		self:ConstructShopItem(itemObj.transform, shopId)
	end

	self._ui.CharacterRoot:GetComponent("UITable"):Reposition()
	self._ui.BasicRoot:GetComponent("UITable"):Reposition()
	self._ui.LimitedRoot:GetComponent("UITable"):Reposition()
	
	CtrlManager.AddClick(self, self._ui.ButtonClose)
end

function ArenaMarketCtrl:IsItemSoldOutOfShop(shopId)
	local items = ConfigUtils.GetArenaShopValidItems(shopId)
	for idx = 1, #items do
		local itemId = items[idx]
		local itemType = ConfigUtils.GetItemTypeFromId(itemId)
		local unlocked = GameData.IsItemUnlocked(itemId)
		if not unlocked or not ConfigUtils.IsUniqueItemType(itemType) then
			return false
		end
	end

	return true
end

function ArenaMarketCtrl:ConstructShopItem(item, shopId)
	local v = ConfigUtils.GetArenaShopInfo(shopId)
	-- cost
	local costNum = v.CostItem.Num
	local costValue = v.CostItem.Value
	local ownNum = GameData.GetItemNum(costValue)

	local shopType = v.Type
	local buyCount = GameData.GetBuyCountOfArenaShop(shopId)
	local limitNum = v.Limit
	local soldOut = (limitNum > 0 and buyCount >= limitNum)
	-- number is enough, check unique items
	if not soldOut then
		soldOut = self:IsItemSoldOutOfShop(shopId)
	end

	local soldMark = item:Find("SoldMark").gameObject
	soldMark:SetActive(soldOut)
	-- price num and icon
	local priceRoot = item:Find("Price")
	UIHelper.ConstructItemIconAndNum(self, priceRoot, costValue)
	local priceLabel = item:Find("Price/Cost"):GetComponent("UILabel")
	priceLabel.text = tostring(costNum)
	-- record the normal color
	if self._priceNormalColor == nil then
		self._priceNormalColor = priceLabel.color
	end
	-- color hint
	if not soldOut and costNum > ownNum then
		priceLabel.color = Color.red
	else
		priceLabel.color = self._priceNormalColor
	end

	local icon = item:Find("Item/Icon"):GetComponent("UISprite")
	local items = ConfigUtils.GetArenaShopValidItems(shopId)
	if shopType == ArenaShopType.Character then
		icon.spriteName = ConfigUtils.GetArenaShopIcon(shopId)
	elseif shopType == ArenaShopType.Normal then
		if #items > 0 then
			UIHelper.SetItemIcon(self,icon, items[1])
		end

		local numLabel = item:Find("Num"):GetComponent("UILabel")
		if limitNum > 0 then
			local leftNum = (limitNum - buyCount)
			numLabel.text = string.format(SAFE_LOC("库存%d"), leftNum)
		else
			numLabel.text = ""
		end
	else
		assert(false, "un-handled shop type: "..tostring(shopType).." of "..tostring(shopId))
	end
end

function ArenaMarketCtrl:RefreshArenaCostGoodsNum()
	local num = math.min(#self._ui.MarketCostItems, #self._costGoodsList)
	for idx = 1, num do
		local itemId = self._costGoodsList[idx]
		local itemNum = GameData.GetItemNum(itemId)
		local numLabel = self._ui.MarketCostItems[idx].num
		numLabel.text = "x"..tostring(itemNum)
	end
end

function ArenaMarketCtrl:OnBuyMarketItem(shopId)
	-- update ui
	for idx = 1, self._ui.CharacterRoot.childCount do
		local item = self._ui.CharacterRoot:GetChild(idx - 1)
		local shopId = tonumber(item.gameObject.name)
		self:ConstructShopItem(item, shopId)
	end

	for idx = 1, self._ui.LimitedRoot.childCount do
		local item = self._ui.LimitedRoot:GetChild(idx - 1)
		local shopId = tonumber(item.gameObject.name)
		self:ConstructShopItem(item, shopId)
	end

	for idx = 1, self._ui.BasicRoot.childCount do
		local item = self._ui.BasicRoot:GetChild(idx - 1)
		local shopId = tonumber(item.gameObject.name)
		self:ConstructShopItem(item, shopId)
	end

	self:RefreshArenaCostGoodsNum()
end

-- on clicked
function ArenaMarketCtrl:OnClicked(go)

	if go == self._ui.ButtonClose then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
	elseif go.transform.parent == self._ui.CharacterRoot or
		   go.transform.parent == self._ui.BasicRoot or 
		   go.transform.parent == self._ui.LimitedRoot then
		-- check refresh time
		local currentTime = GameData.GetServerTime()
		if currentTime >= self._arenaShopRefreshTime then
			SoundSystem.PlayWarningSound()
			CtrlManager.ShowMessageBox({message = SAFE_LOC("商店已刷新，请退出重进"), single = true})
			return true
		end
		-- shop
		local shopId = tonumber(go.name)
		local items = ConfigUtils.GetArenaShopValidItems(shopId)
		if #items > 0 then
			SoundSystem.PlayUIClickSound()
			CtrlManager.OpenPanel(CtrlNames.ArenaMarketDetail, {
				shopId = shopId,
				activity = false,
				endTime = self._arenaShopRefreshTime,
				callback = ArenaMarketCtrl.OnBuyMarketItem,
				receiver = self,
			})
		end
	end

	return true
end