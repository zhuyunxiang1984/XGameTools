require "FreakPlanet/View/MallPanel"

local class = require "FreakPlanet/Utils/middleclass"
MallCtrl  = class(CtrlNames.Mall, BaseCtrl)

local MAX_SCROLL_VIEW_COUNT = 2
local MAX_COLUMN_NUM = 4

-- load the ui prefab
function MallCtrl:LoadPanel()
	self:CreatePanel("Mall")
end

-- construct ui panel data
function MallCtrl:ConstructUI(obj)
	self._ui = MallPanel.Init(obj)
	self._MallModule = self._parameter.MallModule or EMallModuleNames.RecommendGift

	self._DiamondItemPool = {}
	self._CharacterItemPool = {}
	self._MonthCardItemPool = {}
	self._CommonItemPool = {}
	self._GoodsItemPool = {}

	self._RecommendIapList = {}
	self._WeeklyIapList = {}
	self._MonthlyIapList = {}

	self._CommonIapList = {}   -- 推荐礼包,每周礼包,每月礼包,角色礼包
	self._CharacterIapList = {}
	self._MonthCardIapList = {}
	self._DiamondIapList = {}

	self._CurSelectedCharacterIndex = 1
end

-- fill ui with the data
function MallCtrl:SetupUI()
	local ui = self._ui
	IAPManager.RestoreStore(true)
	self:EnableSecondUpdate()
	CtrlManager.AddClick(self, ui.Blocker)
	CtrlManager.AddClick(self, ui.pBtnNext)
	CtrlManager.AddClick(self, ui.pBtnPreview)

	GameNotifier.AddListener(GameEvent.IapPackageChanged, MallCtrl.OnPackageChanged, self)
	GameNotifier.AddListener(GameEvent.IapStateChanged, MallCtrl.OnIapStateChanged, self)
	GameNotifier.AddListener(GameEvent.IapCompleted, MallCtrl.OnIapCompleted, self)

	for name, module in pairs(ui.tUIModule) do
		CtrlManager.AddClick(self, module.item)
	end
	self:SetBannerTitle()
	self:RefreshPurchasingHint()
	self:ConstructModuleUI()
end

function MallCtrl:DestroyImpl()
	GameNotifier.RemoveListener(GameEvent.IapPackageChanged, MallCtrl.OnPackageChanged, self)
	GameNotifier.RemoveListener(GameEvent.IapStateChanged, MallCtrl.OnIapStateChanged, self)
	GameNotifier.RemoveListener(GameEvent.IapCompleted, MallCtrl.OnIapCompleted, self)
end

function MallCtrl:UpdateImplBySecond(deltaTime)
	if self._MallModule == EMallModuleNames.RecommendGift or self._MallModule == EMallModuleNames.MonthCardGift or self._MallModule == EMallModuleNames.WeeklyGift  then
		if self._CommonIapList then
			for idx = 1, #self._CommonIapList do
				local iapPurchaseStatus = GameData.GetIapPackagePurchaseStatus(self._CommonIapList[idx].id)
				if iapPurchaseStatus == EMallIapPurchaseStatus.PreSell or iapPurchaseStatus == EMallIapPurchaseStatus.CanBuy then
					if self._CommonIapList[idx].pTxtLimitTime then
						self:UpdateCountTime(self._CommonIapList[idx].pTxtLimitTime, self._CommonIapList[idx].startTime, self._CommonIapList[idx].endTime, self._CommonIapList[idx].sellTime)
					end
				end
			end
		end
	elseif self._MallModule == EMallModuleNames.CharacterGift then
		if self._CharacterIapList then
			for idx = 1, #self._CharacterIapList do
				local topIapInfo = self._CharacterIapList[idx].top
				local topIapPurchaseStatus = GameData.GetIapPackagePurchaseStatus(topIapInfo.id)
				if topIapPurchaseStatus == EMallIapPurchaseStatus.CanBuy or topIapPurchaseStatus == EMallIapPurchaseStatus.PreSell then
					self:UpdateCountTime(topIapInfo.LimitTime, topIapInfo.startTime, topIapInfo.endTime, topIapInfo.sellTime)
				end
				local bottomIapInfo = self._CharacterIapList[idx].bottom
				if bottomIapInfo then
					local bottomIapPurchaseStatus = GameData.GetIapPackagePurchaseStatus(bottomIapInfo.id)
					if bottomIapPurchaseStatus == EMallIapPurchaseStatus.CanBuy or bottomIapPurchaseStatus == EMallIapPurchaseStatus.PreSell then
						self:UpdateCountTime(bottomIapInfo.LimitTime, bottomIapInfo.startTime, bottomIapInfo.endTime, bottomIapInfo.sellTime)
					end
				end
			end
		end
	end
end

function MallCtrl:UpdateCountTime(limitTime, startTime, endTime, sellTime)
	if limitTime then
		sellTime = sellTime or startTime
		local curTime = GameData.GetServerTime()
		local bIsPreSell = sellTime > startTime
		if bIsPreSell then
			local leftSellTime = sellTime - curTime
			local leftEndTime = endTime - curTime
			if leftEndTime > 0 then
				if leftSellTime > 0 then
					limitTime.text = "预售 " .. Helper.GetLongTimeString(leftSellTime)
				else
					limitTime.text = "剩余 " .. Helper.GetLongTimeString(leftEndTime)
				end
			else
				limitTime.text = SAFE_LOC("礼包已结束")
				-- todo:礼包过期事件
				GameNotifier.Notify(GameEvent.IapPackageChanged)
			end
		else
			local leftEndTime = endTime - curTime
			if leftEndTime > 0 then
				limitTime.text = "剩余 " .. Helper.GetLongTimeString(leftEndTime)
			else
				limitTime.text = SAFE_LOC("礼包已结束")
				-- todo:礼包过期事件
				GameNotifier.Notify(GameEvent.IapPackageChanged)
			end
		end
	end
end

-- on clicked
function MallCtrl:OnClicked(go)
	local ui = self._ui
	if go == ui.Blocker then
		SoundSystem.PlayUIClickSound()
		CtrlManager.PopPanel()
	elseif go == ui.pBtnPreview then
		if self._CurSelectedCharacterIndex > 1 then
			self._CurSelectedCharacterIndex = self._CurSelectedCharacterIndex - 1
			self:RefreshHorizontalButtonRootUI()
			self:MoveCharacterScrollView(false)
		end
	elseif go == ui.pBtnNext then
		if self._CurSelectedCharacterIndex < #self._CharacterIapList then
			self._CurSelectedCharacterIndex = self._CurSelectedCharacterIndex + 1
			self:RefreshHorizontalButtonRootUI()
			self:MoveCharacterScrollView(true)
		end
	elseif go.transform.parent == ui.pUITableMenuTabs.transform then
		SoundSystem.PlayUIClickSound()
		local name = go.name
		if self._MallModule ~= name then
			self._MallModule = name
			self:ConstructModuleUI()

		end
	elseif go.transform.parent.parent.parent == ui.pUIGridDiamondContent.transform then
		local name = go.transform.parent.parent.name
		self:IapPurchase(tonumber(name), false)
	elseif go.transform.parent.parent == ui.pUIGridMonthCardContent.transform then
		local strName = go.transform.parent.name
		self:IapPurchase(tonumber(strName), false)
	elseif go.transform.parent.parent.parent.parent == ui.pUIGridCommonContent.transform then
		local UIGrid = go.transform.parent:GetComponent("UIGrid")
		if UIGrid then
			local id = tonumber(go.name)
			CtrlManager.ShowItemDetail({itemId = id, preview = true })
		else
			local strName = go.transform.parent.parent.parent.name
			self:IapPurchase(tonumber(strName), true)
		end
	elseif go.transform.parent.parent.parent.parent == ui.pUIGridCharacterContent.transform then
		local strName = go.transform.parent.parent.parent.name
		local characterIdList = Helper.StringSplit(strName)
		self:IapPurchase(tonumber(characterIdList[1]), true)
	elseif go.transform.parent.parent.parent.parent.parent == ui.pUIGridCharacterContent.transform then
		local strName = go.transform.parent.parent.parent.parent.name
		local characterIdList = Helper.StringSplit(strName)
		self:IapPurchase(tonumber(characterIdList[2]), true)

	end
	return true
end

function MallCtrl:ConstructModuleUI()
	self:UpdateScrollViewRoot(self._MallModule)
	if self._MallModule == EMallModuleNames.RecommendGift or self._MallModule == EMallModuleNames.WeeklyGift or self._MallModule == EMallModuleNames.MonthlyGift then
		self._ui.pObjHorizontalButtonRoot:SetActive(false)
		self:RefreshCommonIapUI()
	elseif self._MallModule == EMallModuleNames.CharacterGift then
		self:RefreshCharacterIapUI()
	elseif self._MallModule == EMallModuleNames.DiamondGift then
		self._ui.pObjHorizontalButtonRoot:SetActive(false)
		self:RefreshDiamondIapUI()
	elseif self._MallModule == EMallModuleNames.MonthCardGift then
		self._ui.pObjHorizontalButtonRoot:SetActive(false)
		self:RefreshMonthCardIapUI()
	end
	self:RefreshMenuSelectedTabs()
	self:RefreshMenuTabsRedDot()
end

function MallCtrl:UpdateScrollViewRoot(mallModule)
	self._ui.pScrollViewCommonRoot.gameObject:SetActive(mallModule == EMallModuleNames.RecommendGift or mallModule == EMallModuleNames.MonthlyGift or mallModule == EMallModuleNames.WeeklyGift)
	self._ui.pScrollViewCharacterRoot.gameObject:SetActive(mallModule == EMallModuleNames.CharacterGift)
	self._ui.pDiamondGiftRoot.gameObject:SetActive(mallModule == EMallModuleNames.DiamondGift)
	self._ui.pScrollViewMonthCardRoot.gameObject:SetActive(mallModule == EMallModuleNames.MonthCardGift)
end

function MallCtrl:RefreshCommonIapUI()
	self._CommonIapList = GameData.GetActiveIapPackageByType(self._MallModule)
	local iChildCount = self._ui.pUIGridCommonContent.transform.childCount

	for idx = iChildCount, 1, -1 do
		local pObjItem = self._ui.pUIGridCommonContent.transform:GetChild(idx - 1).gameObject
		self:RecycleCommonItem(pObjItem)
	end

	if #self._CommonIapList == 0 then
		self._ui.pObjEmpty:SetActive(true)
		return
	end
	self._ui.pObjEmpty:SetActive(false)
	table.sort(self._CommonIapList, MallCtrl.IapPackageSortFunc)

	for idx = 1, #self._CommonIapList do
		local pObjItem = self:GetOrCreateCommonItem()
		self:ConstructCommonItemUI(self._CommonIapList[idx], pObjItem)
	end

	self._ui.pUIGridCommonContent:Reposition()
	self._ui.pScrollViewCommonRoot.enabled = true
	self._ui.pScrollViewCommonRoot:ResetPosition()
	self._ui.pScrollViewCommonRoot.enabled = #self._CommonIapList > MAX_SCROLL_VIEW_COUNT

end

function MallCtrl:RefreshCharacterIapUI()
	self._CurSelectedCharacterIndex = 1
	self._CharacterIapList = self:SetActiveSortCharacterIap()
	self:RefreshHorizontalButtonRootUI()
	local iChildCount = self._ui.pUIGridCharacterContent.transform.childCount
	for idx = iChildCount, 1, -1 do
		local pObjItem = self._ui.pUIGridCharacterContent.transform:GetChild(idx - 1).gameObject
		self:RecycleCharacterItem(pObjItem)
	end

	if #self._CharacterIapList == 0 then
		self._ui.pObjEmpty:SetActive(true)
		return
	end
	self._ui.pObjEmpty:SetActive(false)
	self._ui.pObjHorizontalButtonRoot:SetActive(#self._CharacterIapList > 1)

	for idx = 1, #self._CharacterIapList do
		local pObjItem = self:GetOrCreateCharacterItem()
		self:ConstructCharacterItemUI(self._CharacterIapList[idx], pObjItem)
	end
	self._ui.pUIGridCharacterContent:Reposition()
	self._ui.pScrollViewCharacterRoot.enabled = true
	self._ui.pScrollViewCharacterRoot:ResetPosition()
	self._ui.pScrollViewCharacterRoot.enabled = #self._CharacterIapList > 1
end

function MallCtrl:RefreshMonthCardIapUI()
	self._MonthCardIapList = ConfigUtils.GetMonthCardIapList()
	table.sort(self._MonthCardIapList, MallCtrl.IapSortFunc)
	self._ui.pObjEmpty:SetActive(false)
	local iChildCount = self._ui.pUIGridMonthCardContent.transform.childCount
	for idx = iChildCount, 1, -1 do
		local pObjItem = self._ui.pUIGridMonthCardContent.transform:GetChild(idx - 1).gameObject
		self:RecycleMonthCardItem(pObjItem)
	end

	for idx = 1, #self._MonthCardIapList do
		local pObjItem = self:GetOrCreateMonthCardItem()
		self:ConstructMonthCardItemUI(idx, pObjItem)
	end

	self._ui.pUIGridMonthCardContent:Reposition()
	self._ui.pScrollViewMonthCardRoot:ResetPosition()
end

--- 玉璧礼包
function MallCtrl:RefreshDiamondIapUI()
	self._DiamondIapList = ConfigUtils.GetDiamondIapList()
	table.sort(self._DiamondIapList, MallCtrl.IapSortFunc)
	self._ui.pObjEmpty:SetActive(false)
	local iChildCount = self._ui.pUIGridDiamondContent.transform.childCount
	for idx = iChildCount, 1, -1 do
		local pObjItem = self._ui.pUIGridDiamondContent.transform:GetChild(idx - 1).gameObject
		self:RecycleDiamondItem(pObjItem)
	end

	for idx = 1, #self._DiamondIapList do
		local pObjItem = self:GetOrCreateDiamondItem()
		--pObjItem.name = tostring(idx)
		self:ConstructDiamondItemUI(self._DiamondIapList[idx], pObjItem)
	end

	self._ui.pUIGridDiamondContent:Reposition()
	self._ui.pScrollViewDiamond:ResetPosition()
end

function MallCtrl:ConstructMonthCardItemUI(iIdx, pObjItem)
	pObjItem.transform:SetParent(self._ui.pUIGridMonthCardContent.transform)
	pObjItem:SetActive(true)

	pObjItem.name = tostring(iIdx)

	local strIapName, strIapDesc, strIapButtonDesc, strIapIcon = ConfigUtils.GetIapInfo(self._MonthCardIapList[iIdx])

	local pSpriteIcon = pObjItem.transform:Find("icon"):GetComponent("UISprite")
	pSpriteIcon.spriteName = strIapIcon

	local pTxtDesc = pObjItem.transform:Find("Desc/desc"):GetComponent("UILabel")
	pTxtDesc.text = strIapDesc

	local pTxtPrice = pObjItem.transform:Find("BtnBg/price"):GetComponent("UILabel")
	pTxtPrice.text = strIapButtonDesc

	local ptxtTitle = pObjItem.transform:Find("tittleBg/tittle"):GetComponent("UILabel")
	ptxtTitle.text = strIapName

	local pTxtLeftTime = pObjItem.transform:Find("leftTime"):GetComponent("UILabel")
	local bIsMonthCard = ConfigUtils.IsMonthCardIap(self._MonthCardIapList[iIdx])

	if bIsMonthCard then
		if GameData.IsMonthCardBought(iIdx) then
			local iLeftDay = GameData.GetMonthCardLeftDays(iIdx)
			if iLeftDay > 0 then
				pTxtLeftTime.text = string.format(SAFE_LOC("剩余%d天"), iLeftDay)
			else
				pTxtLeftTime.text = SAFE_LOC("已过期")
			end

		else
			pTxtLeftTime.text = SAFE_LOC("新鲜的月卡")
		end
	else
		pTxtLeftTime.text = ""
	end

	local pTxtRateRoot = pObjItem.transform:Find("rate"):GetComponent("UILabel")
	local fIapRate = ConfigUtils.GetIapRate(self._MonthCardIapList[iIdx])
	-- rate
	local rateValue = Helper.Round(fIapRate / 100, 1)
	local i_rateValue = math.floor(rateValue)
	local f_rateValue = rateValue - i_rateValue
	local finalRateValue = i_rateValue
	if f_rateValue > 0 then
		finalRateValue = rateValue
	end
	pTxtRateRoot.gameObject:SetActive(finalRateValue > 1)
	if finalRateValue > 1 then
		pTxtRateRoot.text = tostring(finalRateValue) .. "倍超值"
	end

end

function MallCtrl:ConstructDiamondItemUI(iIapId, pObjItem)
	pObjItem.transform:SetParent(self._ui.pUIGridDiamondContent.transform)
	pObjItem:SetActive(true)

	pObjItem.name = tostring(iIapId)
	local strIapName, strIapDesc, strIapButtonDesc, strIapIcon = ConfigUtils.GetIapInfo(iIapId)
	local pObjDoubleMark = pObjItem.transform:Find("content/doublemark").gameObject
	local bShowDouble = ConfigUtils.IsDoubleIap(iIapId) and not GameData.IsIapCompleted(iIapId)
	pObjDoubleMark:SetActive(bShowDouble)

	local pSpriteIcon = pObjItem.transform:Find("content/icon"):GetComponent("UISprite")
	pSpriteIcon.spriteName = strIapIcon
	pSpriteIcon:MakePixelPerfect()

	local pTxtDesc = pObjItem.transform:Find("content/desc"):GetComponent("UILabel")
	pTxtDesc.text = strIapDesc

	local pTxtPrice = pObjItem.transform:Find("content/btn/price"):GetComponent("UILabel")
	pTxtPrice.text = strIapButtonDesc


end

function MallCtrl:ConstructCommonItemUI(info, pObjItem)
	pObjItem.transform:SetParent(self._ui.pUIGridCommonContent.transform)
	pObjItem:SetActive(true)

	pObjItem.name = tostring(info.id)

	local pSpriteIcon = pObjItem.transform:Find("content/goodpic/goodicon"):GetComponent("UISprite")
	pSpriteIcon.spriteName = info.icon
	pSpriteIcon:MakePixelPerfect()

	local pTxtPrice = pObjItem.transform:Find("content/goodpic/buyconfirm/price"):GetComponent("UILabel")
	pTxtPrice.text = info.buttonDesc

	local pTxtTitle = pObjItem.transform:Find("content/titleBG/title"):GetComponent("UILabel")
	pTxtTitle.text = info.name

	local pObjRateRoot = pObjItem.transform:Find("content/goodpic/Multiple").gameObject

	-- rate
	local rateValue = Helper.Round(info.rate / 100, 1)
	local i_rateValue = math.floor(rateValue)
	local f_rateValue = rateValue - i_rateValue
	local finalRateValue = i_rateValue
	if f_rateValue > 0 then
		finalRateValue = rateValue
	end
	pObjRateRoot:SetActive(finalRateValue > 1)
	if finalRateValue > 1 then
		local pTxtRateNum = pObjItem.transform:Find("content/goodpic/Multiple/num"):GetComponent("UILabel")
		pTxtRateNum.text = tostring(finalRateValue) .. "倍\n超值"
	end

	local pUIGrid = pObjItem.transform:Find("content/UIGrid"):GetComponent("UIGrid")
	local iChildCount = pUIGrid.transform.childCount

	local rewards = info.rewards
	for idx = iChildCount, 1, -1 do
		local pObjItem = pUIGrid.transform:GetChild(idx - 1).gameObject
		self:RecycleGoodsItem(pObjItem)
	end

	for idx = 1, #rewards do
		local pObjItem = self:GetOrCreateGoodsItem()
		self:ConstructGoodsItemUI(rewards[idx], pObjItem, pUIGrid.transform)
	end

	if #rewards <= MAX_COLUMN_NUM then
		pUIGrid.maxPerLine = MAX_COLUMN_NUM
		pUIGrid.cellWidth = 52
		pUIGrid.cellHeight = 52
	else
		local iNum = math.ceil(#rewards / 2)
		pUIGrid.maxPerLine = iNum
		pUIGrid.cellWidth = 55
		pUIGrid.cellHeight = 55
	end

	pUIGrid:Reposition()

	local pBtnBuy = pObjItem.transform:Find("content/goodpic/buyconfirm").gameObject

	local pObjLimitMark = pObjItem.transform:Find("content/goodpic/limited").gameObject

	local pBuyHint = pObjItem.transform:Find("content/goodpic/buyhint").gameObject
	local pTxtBuyHint = pObjItem.transform:Find("content/goodpic/buyhint/price"):GetComponent("UILabel")

	local iapPurchaseStatus = GameData.GetIapPackagePurchaseStatus(info.id)

	if iapPurchaseStatus == EMallIapPurchaseStatus.CanBuy then
		pBtnBuy:SetActive(true)
		pBuyHint:SetActive(false)
	elseif iapPurchaseStatus == EMallIapPurchaseStatus.HasBought or iapPurchaseStatus == EMallIapPurchaseStatus.HasBoughtInServer then
		pBtnBuy:SetActive(false)
		pBuyHint:SetActive(true)
		pTxtBuyHint.text = SAFE_LOC("已购买")
	elseif iapPurchaseStatus == EMallIapPurchaseStatus.PreSell then
		pBtnBuy:SetActive(false)
		pBuyHint:SetActive(true)
		pTxtBuyHint.text = info.buttonDesc
	end
	pObjLimitMark:SetActive(info.isLimit)

	local pTxtLimitTime = pObjItem.transform:Find("content/limitTime"):GetComponent("UILabel")
	info.pTxtLimitTime = pTxtLimitTime

	self:UpdateCountTime(pTxtLimitTime, info.startTime, info.endTime, info.sellTime)
end


function MallCtrl:ConstructGoodsItemUI(info, pObjItem, pTransParent)
	local pSpriteIcon = pObjItem.transform:Find("Icon"):GetComponent("UISprite")
	local pSpriteRarity = pObjItem.transform:Find("Rarity"):GetComponent("UISprite")
	local pTxtNum = pObjItem.transform:Find("Num"):GetComponent("UILabel")

	pObjItem.transform:SetParent(pTransParent)
	pObjItem:SetActive(true)

	pObjItem.name = tostring(info.id)
	UIHelper.SetItemIcon(self, pSpriteIcon, info.id)
	pTxtNum.text = "x" .. tostring(info.num)
end

function MallCtrl:RefreshHorizontalButtonRootUI()
	self._ui.pBtnPreview:SetActive(self._CurSelectedCharacterIndex > 1)
	self._ui.pBtnNext:SetActive(self._CurSelectedCharacterIndex < #self._CharacterIapList)
end

function MallCtrl:MoveCharacterScrollView(isNext)
	if self._MallModule == EMallModuleNames.CharacterGift then
		local scorllView = self._ui.pScrollViewCharacterRoot
		local pTransPanel = scorllView.panel.cachedTransform
		local targetPosition = nil
		if isNext then
			targetPosition = Vector3.New(pTransPanel.localPosition.x - 450, pTransPanel.localPosition.y, pTransPanel.localPosition.z)
		else
			targetPosition = Vector3.New(pTransPanel.localPosition.x + 450, pTransPanel.localPosition.y, pTransPanel.localPosition.z)
		end
		SpringPanel.Begin(scorllView.panel.cachedGameObject, targetPosition, 8)
	end
end


function MallCtrl:ConstructCharacterItemUI(info, pObjItem)
	pObjItem.transform:SetParent(self._ui.pUIGridCharacterContent.transform)
	pObjItem:SetActive(true)
	local strCharacterId = nil
	if info.bottom then
		strCharacterId = tostring(info.top.id) .. "_" .. tostring(info.bottom.id)
	else
		strCharacterId = tostring(info.top.id)
	end
	pObjItem.name = strCharacterId

    local curTime = GameData.GetServerTime()
	--- top
	local pObjTop = pObjItem.transform:Find("top").gameObject
	local pSpriteTopIcon = pObjItem.transform:Find("top/icon"):GetComponent("UISprite")
	local pTxtTopDesc = pObjItem.transform:Find("top/titleBG/desc"):GetComponent("UILabel")
	local pTxtTopTitle = pObjItem.transform:Find("top/titleBG/title"):GetComponent("UILabel")

	local pTxtTopLimitTime = pObjItem.transform:Find("top/limitTime"):GetComponent("UILabel")

	local pObjLock = pObjItem.transform:Find("top/btn/lock").gameObject
	local pTxtTopLockPrice = pObjItem.transform:Find("top/btn/lock/price"):GetComponent("UILabel")
	local pObjTopLockMark = pObjItem.transform:Find("top/btn/lock/lock").gameObject

	local pObjTopUnlock = pObjItem.transform:Find("top/btn/unlock").gameObject
	local pTxtTopUnlockPrice = pObjItem.transform:Find("top/btn/unlock/price"):GetComponent("UILabel")

    local topIapInfo = info.top
    pSpriteTopIcon.spriteName = topIapInfo.icon
	pSpriteTopIcon:MakePixelPerfect()
    pTxtTopDesc.text = topIapInfo.desc
    pTxtTopTitle.text = topIapInfo.name

    -- 已购买, 预售, 可购买
    local topIapPurchaseStatus = GameData.GetIapPackagePurchaseStatus(topIapInfo.id)
    if topIapPurchaseStatus == EMallIapPurchaseStatus.PreSell then
        pObjLock:SetActive(true)
        pTxtTopLockPrice.text = topIapInfo.buttonDesc
        pObjTopLockMark:SetActive(true)
        pObjTopUnlock:SetActive(false)
		self:UpdateCountTime(pTxtTopLimitTime, topIapInfo.startTime, topIapInfo.endTime, topIapInfo.sellTime)
    elseif topIapPurchaseStatus == EMallIapPurchaseStatus.HasBought then
        pObjLock:SetActive(true)
        pTxtTopLockPrice.text = SAFE_LOC("已购买")
        pObjTopLockMark:SetActive(false)
        pObjTopUnlock:SetActive(false)
        pTxtTopLimitTime.text = ""
    elseif topIapPurchaseStatus == EMallIapPurchaseStatus.CanBuy then
        pObjLock:SetActive(false)
        pObjTopUnlock:SetActive(true)
        pTxtTopUnlockPrice.text = topIapInfo.buttonDesc
		self:UpdateCountTime(pTxtTopLimitTime, topIapInfo.startTime, topIapInfo.endTime, topIapInfo.sellTime)
    end

	topIapInfo.LimitTime = pTxtTopLimitTime

    local bottomIapInfo = info.bottom
    if bottomIapInfo then
        local pSpriteBottomIcon = pObjItem.transform:Find("bottom/bottom/icon"):GetComponent("UISprite")
        local pTxtBottomDesc = pObjItem.transform:Find("bottom/bottom/titleBG/desc"):GetComponent("UILabel")
        local pTxtBottomTitle = pObjItem.transform:Find("bottom/bottom/titleBG/title"):GetComponent("UILabel")

        local pTxtBottomLimitTime = pObjItem.transform:Find("bottom/bottom/limitTime"):GetComponent("UILabel")

        local pObjBottomLock = pObjItem.transform:Find("bottom/bottom/btn/lock").gameObject
        local pTxtBottomLockPrice = pObjItem.transform:Find("bottom/bottom/btn/lock/price"):GetComponent("UILabel")
        local pObjBottomLockMark = pObjItem.transform:Find("bottom/bottom/btn/lock/lock").gameObject

        local pObjBottomUnlock = pObjItem.transform:Find("bottom/bottom/btn/unlock").gameObject
        local pTxtBottomUnlockPrice = pObjItem.transform:Find("bottom/bottom/btn/unlock/price"):GetComponent("UILabel")

        pSpriteBottomIcon.spriteName = bottomIapInfo.icon
		pSpriteBottomIcon:MakePixelPerfect()
        pTxtBottomDesc.text = bottomIapInfo.desc
        pTxtBottomTitle.text = bottomIapInfo.name

        local bottomIapPurchaseStatus = GameData.GetIapPackagePurchaseStatus(bottomIapInfo.id)

        if bottomIapPurchaseStatus == EMallIapPurchaseStatus.PreSell then
            pObjBottomLock:SetActive(true)
            pTxtBottomLockPrice.text = bottomIapInfo.buttonDesc
            pObjBottomLockMark:SetActive(true)
            pObjBottomUnlock:SetActive(false)
            pTxtBottomLimitTime.text = Helper.GetLongTimeString(bottomIapInfo.sellTime - curTime)
			self:UpdateCountTime(pTxtBottomLimitTime, bottomIapInfo.startTime, bottomIapInfo.endTime, bottomIapInfo.sellTime)
        elseif bottomIapPurchaseStatus == EMallIapPurchaseStatus.HasBought then
            pObjBottomLock:SetActive(true)
            pTxtBottomLockPrice.text = SAFE_LOC("已购买")
            pObjBottomLockMark:SetActive(false)
            pObjBottomUnlock:SetActive(false)
            pTxtBottomLimitTime.text = ""
        elseif bottomIapPurchaseStatus == EMallIapPurchaseStatus.CanBuy then
            pObjBottomLock:SetActive(false)
            pObjBottomUnlock:SetActive(true)
            pTxtBottomUnlockPrice.text = bottomIapInfo.buttonDesc
            pTxtBottomLimitTime.text = Helper.GetLongTimeString(bottomIapInfo.endTime - curTime)
			self:UpdateCountTime(pTxtBottomLimitTime, bottomIapInfo.startTime, bottomIapInfo.endTime, bottomIapInfo.sellTime)
        end
		bottomIapInfo.LimitTime = pTxtBottomLimitTime

    end

	--- Bottom
	local pObjBottom = pObjItem.transform:Find("bottom/bottom").gameObject

	local pObjBottomEmpty = pObjItem.transform:Find("bottom/Nothing").gameObject

	pObjBottom:SetActive(bottomIapInfo ~= nil)
	pObjBottomEmpty:SetActive(bottomIapInfo == nil)
end

function MallCtrl:IapPurchase(productId, isServer)
	if isServer then
		local completed = GameData.IsIapReallyCompleted(productId)
		if completed then
			SoundSystem.PlayWarningSound()
			CtrlManager.ShowAlert(SAFE_LOC("礼包已购买"))
			return true
		end
		local iapInfo = GameData.GetIapPackageInfo(productId)
		local iapInfoStatus = GameData.GetIapPackagePurchaseStatus(productId)
		if iapInfoStatus == EMallIapPurchaseStatus.HasBought or iapInfoStatus == EMallIapPurchaseStatus.HasBoughtInServer then
			SoundSystem.PlayWarningSound()
			CtrlManager.ShowAlert(SAFE_LOC("礼包已购买"))
			return true
		elseif iapInfoStatus == EMallIapPurchaseStatus.OutDate then
			SoundSystem.PlayWarningSound()
			CtrlManager.ShowAlert(SAFE_LOC("礼包已结束"))
			return true
		elseif iapInfoStatus == EMallIapPurchaseStatus.PreSell then
			SoundSystem.PlayWarningSound()
			CtrlManager.ShowAlert(SAFE_LOC("预售期中"))
			return true
		else
			local bCanBuy = IAPManager.CanBuy()
			if not bCanBuy then
				SoundSystem.PlayWarningSound()
				APManager.ShowIapResult(PaymentResult.IapInProcessing)
				return true
			end

			local price = iapInfo.price
			local isOK = GameData.CheckRealNameOfIap(price)
			if not isOK then
				SoundSystem.PlayWarningSound()
				return true
			end

			self:PreparePayment(productId)

		end

	else
		local originId = productId
		local productId = self._MonthCardIapList and self._MonthCardIapList[productId] or productId
		local bIsMonthCard = ConfigUtils.IsMonthCardIap(productId)
		if bIsMonthCard and GameData.GetMonthCardLeftDays(originId) > MonthCardPurchaseLimit then
			SoundSystem.PlayWarningSound()
			CtrlManager.ShowAlert(SAFE_LOC("loc_global_monthcard_not_reach_limit"))
			return true
		end

		local bCanBuy = IAPManager.CanBuy()
		if not bCanBuy then
			SoundSystem.PlayWarningSound()
			APManager.ShowIapResult(PaymentResult.IapInProcessing)
			return true
		end

		self:PreparePayment(productId)
	end

end

function MallCtrl:PreparePayment(productId)
	self._selectedProductId = productId
	if Global.ChannelId == GameChannels.APPSTORE then
		local existOrderId = GameData.GetIapFirstOrder(productId)
		if existOrderId == nil then
			SoundSystem.PlayUIClickSound()
			self:OnProceedApplePay()
		else
			CtrlManager.ShowMessageBox({
				message = SAFE_LOC("该商品有未完成订单，请稍后重新登录尝试获取收据凭证。继续购买可能会导致未完成订单丢失\n继续购买？"),
				single = false,
				onConfirm = MallCtrl.OnProceedApplePay,
				receiver = self,
			})
		end
	elseif Global.ChannelId == GameChannels.ANDROID_OPPO then
		SoundSystem.PlayUIClickSound()
		self:OnPaymentSelected(PaymentType.Oppo)
	elseif Global.ChannelId == GameChannels.ANDROID_VIVO then
		SoundSystem.PlayUIClickSound()
		self:OnPaymentSelected(PaymentType.Vivo)
	elseif Global.ChannelId == GameChannels.ANDROID_HUAWEI then
		SoundSystem.PlayUIClickSound()
		self:OnPaymentSelected(PaymentType.Huawei)
	elseif Global.ChannelId == GameChannels.ANDROID_UC then
		SoundSystem.PlayUIClickSound()
		self:OnPaymentSelected(PaymentType.Uc)
	elseif Global.ChannelId == GameChannels.ANDROID_MI then
		SoundSystem.PlayUIClickSound()
		self:OnPaymentSelected(PaymentType.Mi)
	elseif Global.ChannelId == GameChannels.ANDROID_BILIBILI then
		SoundSystem.PlayUIClickSound()
		self:OnPaymentSelected(PaymentType.Bilibili)
	elseif Global.ChannelId == GameChannels.ANDROID_TENCENT then
		SoundSystem.PlayUIClickSound()
		self:OnPaymentSelected(PaymentType.Tencent)
	elseif Global.ChannelId == GameChannels.ANDROID_MOMOYU then
		SoundSystem.PlayUIClickSound()
		self:OnPaymentSelected(PaymentType.MoMoYu)
	else
		SoundSystem.PlayUIClickSound()
		CtrlManager.OpenPanel(CtrlNames.IAPPaymentSelect, {callback = MallCtrl.OnPaymentSelected, receiver = self})
	end
end

function MallCtrl:OnProceedApplePay()
	self:OnPaymentSelected(PaymentType.Apple)
end

function MallCtrl:OnPaymentSelected(payment)
	IAPManager.Buy(self._selectedProductId, payment)
end

function MallCtrl:RefreshMenuSelectedTabs()
	for name, module in pairs(self._ui.tUIModule) do
		if name == EMallModuleNames.CharacterGift  then
			local bIsShow = GameData.HasActiveIap(name)
			module.item:SetActive(bIsShow)
		end
		local bIsSelected = self._MallModule == name
		local pObjSelect = module.select
		local pObjUnselect = module.unselect
		pObjSelect:SetActive(bIsSelected)
		pObjUnselect:SetActive(not bIsSelected)
	end
	self._ui.pUITableMenuTabs:Reposition()
end

--- 红点刷新
function MallCtrl:RefreshMenuTabsRedDot()
	for name, module in pairs(self._ui.tUIModule) do
		local bIsShow = GameData.HasActiveIap(name)
		local pObjHint = module.hint
		pObjHint:SetActive(bIsShow)
	end
end

function MallCtrl:SetBannerTitle()
	if Helper.IsEmptyOrNull(Global.ExtraData) then
		return
	end

	local json = require "cjson"
	local extraInfo = json.decode(Global.ExtraData)
	local title = SAFE_LOC("loc_global_package_title_desc")
	if extraInfo.PackageTitle ~= nil then
		title = extraInfo.PackageTitle
	end
	self._ui.pTxtBannerTips.text = title
end

function MallCtrl:OnPackageChanged()
	self:ConstructModuleUI()
end

function MallCtrl:OnIapStateChanged()
	self:RefreshPurchasingHint()
end

function MallCtrl:OnIapCompleted(iapId)
	self:ConstructModuleUI()
end

function MallCtrl:RefreshPurchasingHint()
	local isPurchasing = IAPManager.HasProcessingOrder()
	self._ui.pObjPurchingPanel:SetActive(isPurchasing)
end

-- 资源池
----------------------------------------------------

function MallCtrl:GetOrCreateDiamondItem()
	local obj = nil
	if #self._DiamondItemPool > 0 then
		obj = table.remove(self._DiamondItemPool,#self._DiamondItemPool)
	else
		obj = Helper.NewObject(self._ui.pObjDiamondItem, self._ui.pTransGiftPoolRoot)
		local pBtnBuy = obj.transform:Find("content/btn").gameObject
		CtrlManager.AddClick(self, pBtnBuy)
	end
	obj.transform.localScale = Vector3.one
	return obj
end

function MallCtrl:RecycleDiamondItem(pObj)
	pObj.transform:SetParent(self._ui.pTransGiftPoolRoot)
	table.insert(self._DiamondItemPool, pObj)
end

function MallCtrl:GetOrCreateCharacterItem()
	local obj = nil
	if #self._CharacterItemPool > 0 then
		obj = table.remove(self._CharacterItemPool,#self._CharacterItemPool)
	else
		obj = Helper.NewObject(self._ui.pObjCharacterItem, self._ui.pTransGiftPoolRoot)
        local pBtnTopBuy = obj.transform:Find("top/btn/unlock").gameObject
        local pBtnBottomBuy = obj.transform:Find("bottom/bottom/btn/unlock").gameObject
		CtrlManager.AddClick(self, pBtnTopBuy)
        CtrlManager.AddClick(self, pBtnBottomBuy)
	end
	obj.transform.localScale = Vector3.one
	return obj
end

function MallCtrl:RecycleCharacterItem(pObj)
	pObj.transform:SetParent(self._ui.pTransGiftPoolRoot)
	table.insert(self._CharacterItemPool, pObj)
end

function MallCtrl:GetOrCreateMonthCardItem()
	local obj = nil
	if #self._MonthCardItemPool > 0 then
		obj = table.remove(self._MonthCardItemPool,#self._MonthCardItemPool)
	else
		obj = Helper.NewObject(self._ui.pObjMonthCardItem, self._ui.pTransGiftPoolRoot)
		local pBtnBuy = obj.transform:Find("BtnBg").gameObject
		CtrlManager.AddClick(self, pBtnBuy)
	end

	return obj
end

function MallCtrl:RecycleMonthCardItem(pObj)
	pObj.transform:SetParent(self._ui.pTransGiftPoolRoot)
	table.insert(self._MonthCardItemPool, pObj)
end

function MallCtrl:GetOrCreateCommonItem()
	local obj = nil
	if #self._CommonItemPool > 0 then
		obj = table.remove(self._CommonItemPool,#self._CommonItemPool)
	else
		obj = Helper.NewObject(self._ui.pObjCommonItem, self._ui.pTransGiftPoolRoot)
		local pBtnBuy = obj.transform:Find("content/goodpic/buyconfirm").gameObject
		CtrlManager.AddClick(self, pBtnBuy)
	end
	obj.transform.localScale = Vector3.one
	return obj
end

function MallCtrl:RecycleCommonItem(pObj)
	pObj:SetActive(false)
	pObj.transform:SetParent(self._ui.pTransGiftPoolRoot)
	table.insert(self._CommonItemPool, pObj)
end

function MallCtrl:GetOrCreateGoodsItem()
	local obj = nil
	if #self._GoodsItemPool > 0 then
		obj = table.remove(self._GoodsItemPool,#self._GoodsItemPool)
	else
		obj = Helper.NewObject(self._ui.pObjGoodsItem, self._ui.pTransGiftPoolRoot)
		CtrlManager.AddClick(self, obj)
	end
	obj.transform.localScale = Vector3.one
	return obj
end

function MallCtrl:RecycleGoodsItem(pObj)
	pObj:SetActive(false)
	pObj.transform:SetParent(self._ui.pTransGiftPoolRoot)
	table.insert(self._GoodsItemPool, pObj)
end
----------------------------------------------------


function MallCtrl:CanBuyPackage(rewards)
	if GameData.HasPackageAnyOneReward(rewards) then
		return false
	end
	return true
end

function MallCtrl.IapSortFunc(idA, idB)
	if idA == nil or idB == nil then
		return false
	end

	local valueA = ConfigUtils.GetIapSortId(idA)
	local valueB = ConfigUtils.GetIapSortId(idB)

	return valueA < valueB
end

function MallCtrl.IapPackageSortFunc(infoA, infoB)
	if infoA == nil or infoB == nil then
		return false
	end

	local valueA = infoA.id
	local valueB = infoB.id

	return valueA < valueB
end

function MallCtrl:HasSameSortIap(tbl)
	local isSame = false
	local SameSortIapList = {}
    local sortList = {}
	for k, v in pairs(tbl) do
		for key, value in pairs(tbl) do
			if key ~= k then
				if v.sort == value.sort then
                    if not Helper.TableContains(sortList, v.sort) then
                        isSame = true
                        table.insert(SameSortIapList, {first = k, second = key})
                        table.insert(sortList, v.sort)
                    end
                    break
				end
			end
		end
	end

	return isSame, SameSortIapList
end

function MallCtrl:GetLeftActiveCharacterIap(sameSortIapList)
	local leftList = {}
	local characterTbl = GameData.GetActiveCharacterIapPackages()
	for k, v in pairs(characterTbl) do
		if not self:ContainSameSort(k, sameSortIapList) then
			table.insert(leftList, k)
		end
	end
	return leftList
end


function MallCtrl:SetActiveSortCharacterIap()
	local ret = {}
	local characterTbl = GameData.GetActiveCharacterIapPackages()
	local isSame, sameSortIapList = self:HasSameSortIap(characterTbl)
	local characterList = self:GetLeftActiveCharacterIap(sameSortIapList)
	for idx = 1, #sameSortIapList do
		local iTopIapId = sameSortIapList[idx].first
		local iBottomIapId = sameSortIapList[idx].second
		local topIapInfo = GameData.GetIapPackageInfo(iTopIapId)
		local bottomIapInfo = GameData.GetIapPackageInfo(iBottomIapId)
		table.insert(ret, {top = topIapInfo, bottom = bottomIapInfo})
	end
	local iLeftCharacterNum = math.ceil(#characterList / 2)
	for idx = 1, iLeftCharacterNum do
		local topIapInfo = nil
		local bottomIapInfo = nil
		local iTopIapId = characterList[2 * idx - 1]
		topIapInfo = GameData.GetIapPackageInfo(iTopIapId)
		if 2 * idx <= #characterList then
			local iBottomIapId = characterList[2 * idx]
			bottomIapInfo = GameData.GetIapPackageInfo(iBottomIapId)
		end
		table.insert(ret, {top = topIapInfo, bottom = bottomIapInfo})
	end
	return ret
end

function MallCtrl:ContainSameSort(iapId, list)
	for idx = 1, #list do
		for k, v in pairs(list[idx]) do
			if v == iapId then
				return true
			end
		end
	end
	return false
end