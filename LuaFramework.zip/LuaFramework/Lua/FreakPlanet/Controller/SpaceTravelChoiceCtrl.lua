require "FreakPlanet/View/SpaceTravelChoicePanel"

local class = require "FreakPlanet/Utils/middleclass"
SpaceTravelChoiceCtrl  = class(CtrlNames.SpaceTravelChoice, BaseCtrl)

local ChoiceState = {
    DoSelection = "DoSelection",
    DoShow = "DoShow",
}

-- load the ui prefab
function SpaceTravelChoiceCtrl:LoadPanel()
	self:CreatePanel("SpaceTravelChoice")
end

-- construct ui panel data
function SpaceTravelChoiceCtrl:ConstructUI(obj)
	self._ui = SpaceTravelChoicePanel.Init(obj)
end

-- fill ui with the data
function SpaceTravelChoiceCtrl:SetupUI()
	self._seasonId = self._parameter.seasonId
    local seasonData = GameData.GetSpaceTravelSeasonData(self._seasonId)
    self._choiceEvent = seasonData.choiceEvent
    self._choiceList = seasonData.choiceList
    self._currentState = ChoiceState.DoSelection
    self:SetupEventInfo()
    self:SetupChoiceGrid()
end

function SpaceTravelChoiceCtrl:SetupEventInfo()
    local friendlinessId = ConfigUtils.GetSpaceTravelEventFriendliness(self._choiceEvent)
    local isFriendlinessEvent = (friendlinessId ~= nil)
    self._ui.GeneralRoot:SetActive(not isFriendlinessEvent)
    self._ui.FriendlinessRoot:SetActive(isFriendlinessEvent)

    if isFriendlinessEvent then
        self._ui.FriendlinessEventName.text = ConfigUtils.GetSpaceTravelEventName(self._choiceEvent)
        self._ui.FriendlinessEventIcon.spriteName = ConfigUtils.GetSpaceTravelEventIcon(self._choiceEvent)
        self._ui.FriendlinessEventBG.spriteName = ConfigUtils.GetSpaceTravelEventBG(self._choiceEvent)
        self._ui.FriendlinessEventDesc.text = ConfigUtils.GetSpaceTravelEventDesc(self._choiceEvent)

        local friendlinessValue = GameData.GetSpaceTravelItemNum(self._seasonId, friendlinessId)
        self._ui.FriendlinessEventHint.text = ConfigUtils.GetSpaceTravelFriendlinessDesc(friendlinessId, friendlinessValue)
        self._eventDesc =  self._ui.FriendlinessEventDesc
    else
        self._ui.GeneralEventName.text = ConfigUtils.GetSpaceTravelEventName(self._choiceEvent)
        self._ui.GeneralEventIcon.spriteName = ConfigUtils.GetSpaceTravelEventIcon(self._choiceEvent)
        self._ui.GeneralEventBG.spriteName = ConfigUtils.GetSpaceTravelEventBG(self._choiceEvent)
        self._ui.GeneralEventDesc.text = ConfigUtils.GetSpaceTravelEventDesc(self._choiceEvent)
        self._eventDesc =  self._ui.GeneralEventDesc
    end
end

function SpaceTravelChoiceCtrl:SetupChoiceGrid()
    for idx = 1, #self._choiceList do
        local choiceItemObj = Helper.NewObject(self._ui.ChoiceItemTemplate, self._ui.ChoiceGrid)
        choiceItemObj:SetActive(true)
        choiceItemObj.name = tostring(idx)
        CtrlManager.AddClick(self, choiceItemObj)

        self:ConstructChoiceItem(choiceItemObj.transform, idx)
    end

    self._ui.ChoiceGrid:GetComponent("UITable"):Reposition()
end

function SpaceTravelChoiceCtrl:ConstructChoiceItem(item, idx)
    local choiceId = self._choiceList[idx]
    local name = ConfigUtils.GetSpaceTravelChoiceName(choiceId)
    local isMatch, choiceHint = self:IsChoiceMatchCondition(choiceId)
    if not isMatch then
        name = choiceHint
    end

    local nameLabel = item:Find("Name"):GetComponent("UILabel")
    nameLabel.text = name

    local button = item:GetComponent("UIButton")
    button.isEnabled = isMatch
end

function SpaceTravelChoiceCtrl:RefreshSelectionState(selectedIdx)
    for idx = 1, self._ui.ChoiceGrid.childCount do
        local item = self._ui.ChoiceGrid:GetChild(idx - 1)
        local button = item:GetComponent("UIButton")
        button.isEnabled = (idx == selectedIdx)
    end
end

function SpaceTravelChoiceCtrl:IsChoiceMatchCondition(choiceId)
    local needList = ConfigUtils.GetSpaceTravelChoiceNeedList(choiceId)
    for idx = 1, #needList do
        local needItemId = needList[idx].Value
        local needItemNum = needList[idx].Num
        local ownNum = GameData.GetSpaceTravelItemNum(self._seasonId, needItemId)
        if needItemNum > ownNum then
            return false, SAFE_LOC(needList[idx].Hint)
        end
    end

    return true
end

function SpaceTravelChoiceCtrl:PeekDialog()
    local quest = SAFE_LOC(self._dialogList[self._dialogIndex].Quest)
    local answer = SAFE_LOC(self._dialogList[self._dialogIndex].Answer)

    self._eventDesc.text = quest
    local choiceItem = self._ui.ChoiceGrid:GetChild(self._selectedChoiceIndex - 1)
    local choiceDesc = choiceItem:Find("Name"):GetComponent("UILabel")
    choiceDesc.text = answer
end

function SpaceTravelChoiceCtrl:CloseInternal()
    local seasonId = self._selectedSeasonId
    local choiceIndex = self._selectedChoiceIndex
    local choiceId = self._selectedChoiceId
    -- record current choice
    GameData.SelectChoiceForSpaceTravelSeason(seasonId, choiceIndex)

    local choiceType = ConfigUtils.GetSpaceTravelChoiceType(choiceId)
    if choiceType == SpaceTravelChoiceType.Deal then
        CtrlManager.PopPanel()
        local dealId = ConfigUtils.GetSpaceTravelChoiceDeal(choiceId)
        CtrlManager.OpenPanel(CtrlNames.SpaceTravelDeal, {seasonId = seasonId, dealId = dealId, choiceId = choiceId})
    elseif choiceType == SpaceTravelChoiceType.Discovery then
        CtrlManager.PopPanel()
        local discoveryId = ConfigUtils.GetSpaceTravelChoiceDiscovery(choiceId)
        CtrlManager.OpenPanel(CtrlNames.SpaceTravelDiscovery, {seasonId = seasonId, discoveryId = discoveryId, choiceId = choiceId})
    elseif choiceType == SpaceTravelChoiceType.Chat then
        CtrlManager.PopPanel()
        local chatId = ConfigUtils.GetSpaceTravelChoiceChat(choiceId)
        CtrlManager.OpenPanel(CtrlNames.SpaceTravelChatCharacter, {seasonId = seasonId, chatId = chatId, choiceId = choiceId})
    elseif choiceType == SpaceTravelChoiceType.Challenge then
        local challengeId = ConfigUtils.GetSpaceTravelChoiceChallenge(choiceId)
        CtrlManager.DoWaitTransition(CtrlNames.ExploreCharacter, self, SpaceTravelChoiceCtrl.CloseToChallenge, {
            challengeId = challengeId,
            choiceId = choiceId,
            seasonId = seasonId,
        })
    elseif choiceType == SpaceTravelChoiceType.Command or choiceType == SpaceTravelChoiceType.Goal then
        -- may be goal
        if choiceType == SpaceTravelChoiceType.Goal then
            local goalId = ConfigUtils.GetSpaceTravelChoiceGoal(choiceId)
            GameData.AddSpaceTravelGoal(seasonId, goalId)
        end
        -- cost
        local costList = ConfigUtils.GetSpaceTravelChoiceCostList(choiceId)
        for k, v in pairs(costList) do
            GameData.ConsumeSpaceTravelItem(seasonId, v.Value, v.Num)
        end
        -- gain
        local gainList = ConfigUtils.GetSpaceTravelChoiceGainList(choiceId)
        if #gainList > 0 then
            -- reward list configed in the file need to convert
            gainList = GameData.ConvertSpaceTravelRewardDataFormat(gainList)
            -- construct to needed format
            local parameter = GameData.ConstructSpaceTravelChoiceResultParameter(seasonId, gainList, self._resultBaseData)

            CtrlManager.PopPanel()
            CtrlManager.OpenPanel(CtrlNames.SpaceTravelChoiceResult, parameter)
        else
            GameData.SyncSpaceTravelSeasonBaseData(seasonId, self._resultBaseData)
            CtrlManager.PopPanel()
        end
    end
end

-- on clicked
function SpaceTravelChoiceCtrl:OnClicked(go)
    if go.transform.parent == self._ui.ChoiceGrid then
        local isValid = CtrlManager.CheckSpaceTravelSeasonValid(self._seasonId, true)
        if not isValid then
            return true
        end
        
        local choiceIndex = tonumber(go.name)
        if self._currentState == ChoiceState.DoSelection then
            local choiceId = self._choiceList[choiceIndex]
            local choiceType = ConfigUtils.GetSpaceTravelChoiceType(choiceId)
            if choiceType == SpaceTravelChoiceType.Goal then
                local goalId = ConfigUtils.GetSpaceTravelChoiceGoal(choiceId)
                if GameData.HasSpaceTravelGoal(self._seasonId, goalId) then
                    SoundSystem.PlayWarningSound()
                    CtrlManager.ShowMessageBox({message = SAFE_LOC("此任务已经在任务列表中"), single = true})
                    return true
                end
            end

            SoundSystem.PlayUIClickSound()
            local seasonData = GameData.GetSpaceTravelSeasonData(self._seasonId)
            local scoreCapId = GameData.GetScoreCapOfSpaceTravelSeason(self._seasonId, seasonData.scoreCap)
            NetManager.Send('STSelectChoice', {
                STSeasonID = self._seasonId, 
                STScoreCapID = scoreCapId, 
                ChoiceIndex = choiceIndex,
                ChoiceId = choiceId,
            }, SpaceTravelChoiceCtrl.OnHandleProto, self)
        elseif self._currentState == ChoiceState.DoShow and choiceIndex == self._selectedChoiceIndex then
            SoundSystem.PlayUIClickSound()
            if self._dialogIndex >= #self._dialogList then
                self:CloseInternal()
            else
                self._dialogIndex = self._dialogIndex + 1
                self:PeekDialog()
            end
        end
    end

	return true
end

-- handle the escapse button
function SpaceTravelChoiceCtrl:HandleEscape()
    -- do nothing
end

-- can do jump or not
function SpaceTravelChoiceCtrl:CanJump()
    return false
end

function SpaceTravelChoiceCtrl:CloseToChallenge(params)
    CtrlManager.PopPanel()
    CtrlManager.OpenPanel(CtrlNames.ExploreCharacter, params)
end

function SpaceTravelChoiceCtrl:OnHandleProto(proto, data, requestData)
    if proto == 'STSelectChoice' then
        local seasonId = requestData.STSeasonID
        local choiceIndex = requestData.ChoiceIndex
        local choiceId = requestData.ChoiceId
        -- refresh ui
        self._currentState = ChoiceState.DoShow
        self._selectedSeasonId = seasonId
        self._selectedChoiceIndex = choiceIndex
        self._selectedChoiceId = choiceId
        self._resultBaseData = data
        self:RefreshSelectionState(choiceIndex)
        -- settle goal data
        local goalData = GameData.SetupItemGoalData(choiceId, 1)
        GameData.DoSpaceTravelGoalSettle(seasonId, TriggerType.Choice, {goalData})

        self._dialogList = ConfigUtils.GetSpaceTravelChoiceDialogList(choiceId)
        if #self._dialogList == 0 then
            self:CloseInternal()
        else
            self._dialogIndex = 1
            self:PeekDialog()
        end
    end
end