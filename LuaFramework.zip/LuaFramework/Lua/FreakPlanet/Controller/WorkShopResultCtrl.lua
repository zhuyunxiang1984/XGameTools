require "FreakPlanet/View/WorkShopResultPanel"

local class = require "FreakPlanet/Utils/middleclass"
WorkShopResultCtrl  = class(CtrlNames.WorkShopResult, BaseCtrl)

-- load the ui prefab
function WorkShopResultCtrl:LoadPanel()
	self:CreatePanel("WorkShopResult")
end

-- construct ui panel data
function WorkShopResultCtrl:ConstructUI(obj)
	self._ui = WorkShopResultPanel.Init(obj)
end

-- fill ui with the data
function WorkShopResultCtrl:SetupUI()
	local isUpgradeSettle = self._parameter.upgrade or false
	local rewards = self._parameter.rewards or {}

	-- max drop item num = 12
	for idx = 1, 12 do
		local itemObj = Helper.NewObject(self._ui.RewardItemTemplate, self._ui.RewardRoot)
		itemObj.name = tostring(idx)
		itemObj:SetActive(true)

		local hasReward = (idx <= #rewards)
		local item = itemObj.transform
		if hasReward then
			local dropId = rewards[idx].Value
			local dropNum = rewards[idx].Num
			local baseNum = rewards[idx].BaseRewardNum or 0
			self:ConstructRewardItem(item, dropId, dropNum, baseNum)
		else
			self:ConstructRewardItem(item, nil, 0, 0)
		end
	end

	local grid = self._ui.RewardRoot:GetComponent("UIGrid")
	grid:Reposition()

	self._ui.UpgradeHint:SetActive(isUpgradeSettle)
	CtrlManager.AddClick(self, self._ui.Blocker)
end

function WorkShopResultCtrl:ConstructRewardItem(item, itemId, itemNum, baseNum)
	local root = item:Find("Root")
	root.gameObject:SetActive(itemId ~= nil)
	if itemId ~= nil then
		UIHelper.ConstructItemIconAndNum(self, root, itemId, itemNum)
	end
end

-- handle the escapse button
function WorkShopResultCtrl:HandleEscape()
	self:OnClicked(self._ui.Blocker)
end

-- can do jump or not
function WorkShopResultCtrl:CanJump()
	-- as we need to do goal settle, or goal data will miss
	return false
end

-- on clicked
function WorkShopResultCtrl:OnClicked(go)

	if go == self._ui.Blocker then
		SoundSystem.PlayUICancelSound()
		NavigationCtrl.EnableSuspend(false)

		local goalData = {}
		local rewards = self._parameter.rewards or {}
		for idx = 1, #rewards do
			local dropId = rewards[idx].Value
			local dropNum = rewards[idx].Num

			local e = GameData.SetupItemGoalData(dropId, dropNum)
			table.insert(goalData, e)
		end

		GameData.DoGoalSettle(TriggerType.WorkShop, goalData)
		GameData.CheckAndHintGoalsOfCurrentCountType()
		CtrlManager.PopPanel()
	end

	return true
end
