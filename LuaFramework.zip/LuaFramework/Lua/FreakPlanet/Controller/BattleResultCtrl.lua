require "FreakPlanet/View/BattleResultPanel"

local class = require "FreakPlanet/Utils/middleclass"
BattleResultCtrl  = class(CtrlNames.BattleResult, BaseCtrl)

-- load the ui prefab
function BattleResultCtrl:LoadPanel()
	self:CreatePanel("BattleResult")
end

-- construct ui panel data
function BattleResultCtrl:ConstructUI(obj)
	self._ui = BattleResultPanel.Init(obj)
end

-- fill ui with the data
function BattleResultCtrl:SetupUI()
	self._clickLocked = true
	GlobalScheduler:DoActionAfterTime(0.5, BattleResultCtrl.UnlockClick, self)

	-- general challenge
	self._challengeId = self._parameter.challengeId
	-- space travel challenge
	self._seasonId = self._parameter.seasonId
	self._choiceId = self._parameter.choiceId
	self._baseResult = self._parameter.baseResult
	-- arena battle
	self._arenaBattleId = self._parameter.arenaBattleId
	-- activity battle
	self._activityBattleId = self._parameter.activityBattleId
	-- only valid for area challenge
	self._challengeStar = self._parameter.challengeStar
	self._challengeRound = self._parameter.challengeRound
	self._starShowState = nil

	self._settleResult = self._parameter.settleResult
	if self._settleResult then
		SoundSystem.PlaySoundOfName(SoundNames.BattleWin)
		self:ConstructSuccess()
	else
		SoundSystem.PlaySoundOfName(SoundNames.BattleLose)
		if self._seasonId ~= nil then
			self:ConstructSpaceTravelFail()
		end
	end

	self._ui.ResultSuccess:SetActive(self._settleResult)
	self._ui.ResultFail:SetActive(not self._settleResult)
	self._ui.ResultSuccessFront:SetActive(self._settleResult)
	self._ui.GeneralFailRoot:SetActive(not self._settleResult and self._seasonId == nil)
	self._ui.SpaceTravelFailRoot:SetActive(not self._settleResult and self._seasonId ~= nil)
	CtrlManager.AddClick(self, self._ui.Blocker)
	CtrlManager.AddClick(self, self._ui.ButtonContinueSpaceTravel)
	CtrlManager.AddClick(self, self._ui.ButtonCancelSpaceTravel)
	CtrlManager.AddClick(self, self._ui.FullStarBlocker)

	--检测战斗结束是否有对话
	local speechId = self:GetSpeechToShow(self._settleResult)
	if speechId ~= nil then
		CtrlManager.LaunchPanel(CtrlNames.GoalDialog, {goalSpeechList = {speechId}})   -- depth = 57
	end
end

function BattleResultCtrl:GetSpeechToShow(success)
	if success then
		if self._challengeId ~= nil then
			return ConfigUtils.GetChallengeSuccessSpeech(self._challengeId)
		end
		if self._activityBattleId ~= nil then
			return ConfigUtils.GetActivityBattleSuccessSpeech(self._activityBattleId)
		end
	end
	return nil
end

function BattleResultCtrl:ShowFullStar()
	if self._challengeId == nil then
		return false
	end

	local areaId = ConfigUtils.GetAreaOfChallenge(self._challengeId)
	return ConfigUtils.IsValidItem(areaId)
end

function BattleResultCtrl:ShowStar(go)
	go:SetActive(true)
end

function BattleResultCtrl:ConstructFullStarInfo()
	local challengeId = self._challengeId
	local completed = GameData.IsChallengeCompleted(challengeId)
	local maxStar = 0
	local minRound = 0
	if completed then
		maxStar, minRound = GameData.GetUnlockedChallengeRecord(challengeId)
	end

	for idx = 1, self._ui.FullStarStarRoot.childCount do
		local element = self._ui.FullStarStarRoot:GetChild(idx - 1)
		local starUnlock = element:Find("Unlock").gameObject
		local starLock = element:Find("Lock").gameObject
		starUnlock:SetActive(false)
		starLock:SetActive(true)

		local starMatch = (idx <= self._challengeStar)
		if starMatch then
			if self._starShowState == nil then
				self._starShowState = SequenceState:new()
			end

			local starState = TimerState:new(0.1)
			starState:ActionOnExit(BattleResultCtrl.ShowStar, self, starUnlock)
			self._starShowState:Push(starState)
		end
	end

	self._ui.FullStarRoundNum.text = string.format("%d个回合放倒对手！", self._challengeRound)
	local deadNum = math.max(0, CHALLENGE_MAX_STAR - self._challengeStar)
	if deadNum == 0 then
		self._ui.FullStarDeadNum.text = SAFE_LOC("完胜")
	else
		self._ui.FullStarDeadNum.text = string.format("%d人倒地", deadNum)
	end
	self._ui.FullStarNewRoundRecord:SetActive(minRound == 0 or self._challengeRound < minRound)

	local rewarded = (maxStar >= CHALLENGE_MAX_STAR)
	self._ui.FullStarRewardRewarded:SetActive(rewarded)
	local hasReward = (maxStar < CHALLENGE_MAX_STAR and self._challengeStar >= CHALLENGE_MAX_STAR)
	self._ui.FullStarRewardFirstReward:SetActive(hasReward)
	local toReward = (maxStar < CHALLENGE_MAX_STAR and self._challengeStar < CHALLENGE_MAX_STAR)
	self._ui.FullStarRewardToReward:SetActive(toReward)

	local rewards = ConfigUtils.GetChallengeFullStarRewards(challengeId)
	if #rewards > 0 and not rewarded then
		local rewardNum = rewards[1].Num
		self._ui.FullStarRewardNum.text = "x"..tostring(rewardNum)
	else
		self._ui.FullStarRewardNum.text = ""
	end
end

function BattleResultCtrl:GetBattleResultInfo()
	if self._challengeId ~= nil then
		local desc = ConfigUtils.GetChallengeDesc(self._challengeId)
		local resultText = ConfigUtils.GetChallengeResultText(self._challengeId)
		local dialog = ConfigUtils.GetChallengeDialog(self._challengeId)
		local unlockItem = ConfigUtils.GetUnlockItemOfChallenge(self._challengeId)

		return desc, resultText, dialog, unlockItem
	elseif self._arenaBattleId ~= nil then
		local desc = ConfigUtils.GetArenaBattleDesc(self._arenaBattleId)
		local resultText = ConfigUtils.GetArenaBattleResultText(self._arenaBattleId)
		local dialog = ConfigUtils.GetArenaBattleDialog(self._arenaBattleId)
		local unlockItem = nil

		return desc, resultText, dialog, unlockItem
	elseif self._activityBattleId ~= nil then
		local desc = ConfigUtils.GetActivityBattleDesc(self._activityBattleId)
		local resultText = ConfigUtils.GetActivityBattleResultText(self._activityBattleId)
		local dialog = ConfigUtils.GetActivityBattleDialog(self._activityBattleId)
		local unlockItem = nil

		return desc, resultText, dialog, unlockItem
	end

	assert(false, "the battle result should be for challenge or arena battle")
end

function BattleResultCtrl:GetBattleLastEnemy()
	if self._challengeId ~= nil then
		return ConfigUtils.GetLastEnemyOfChallenge(self._challengeId)
	elseif self._arenaBattleId ~= nil then
		local difficulty = self._parameter.difficulty
		return ConfigUtils.GetArenaBattleLastEnmeyAt(self._arenaBattleId, difficulty)
	elseif self._activityBattleId ~= nil then
		return ConfigUtils.GetLastEnemyOfActivityBattle(self._activityBattleId)
	end

	assert(false, "the battle result should be for challenge or arena battle")
end

function BattleResultCtrl:ConstructSuccess()
	local desc, resultText, dialog, unlockItem = self:GetBattleResultInfo()
	local showFullStar = self:ShowFullStar()
	self._ui.FullStarRoot:SetActive(showFullStar)
	self._ui.ChallengeDescRoot:SetActive(not showFullStar)
	if showFullStar then
		self:ConstructFullStarInfo()
	else
		-- desc
		self._ui.ChallengeDesc.text = desc
	end
	-- result text
	self._ui.ChallengeResultText.text = resultText
	-- dialog
	self._ui.ChallengeDailogRoot:SetActive(dialog ~= nil)
	if dialog ~= nil then
		self._ui.ChallengeDailog.text = dialog
	end
	-- hide first
	self._ui.ChallengeUnlockEquipment.gameObject:SetActive(false)

	if unlockItem == nil then
		self:ConstructChallengeEnemy()
	else
		local itemType = ConfigUtils.GetItemTypeFromId(unlockItem)
		if itemType == ItemType.Equipment then
			self._ui.ChallengeUnlockEquipment.gameObject:SetActive(true)
			UIHelper.SetEquipmentIcon(self, self._ui.ChallengeUnlockEquipment, unlockItem, 1)
		elseif itemType == ItemType.Skin then
			self:ConstructChallengeSkin(unlockItem)
		else
			assert(false, "un-handled reward item: "..tostring(unlockItem))
		end
	end
end

function BattleResultCtrl:ConstructChallengeEnemy()
	local enemyId = self:GetBattleLastEnemy()
	-- avatar
	local prefabName, prefabBundle = ConfigUtils.GetEnemyPrefab(enemyId)
	local prefab = self:DynamicLoadAsset(prefabBundle, prefabName)
	local itemObj = Helper.NewObject(prefab, self._ui.ChallengeAvatarRoot)
	itemObj.name = tostring(enemyId)
	-- animation
	local skeletonAnimation = itemObj:GetComponent("SkeletonAnimation")
	Helper.PlayAnimation(skeletonAnimation, CharacterAnimations.Idle, true)
	-- skin
	local skinName = ConfigUtils.GetEnemySkinName(enemyId)
	if skinName ~= nil then
		Helper.SetSkin(skeletonAnimation, skinName)
	end
	-- mesh renderer
	local renderer = itemObj:GetComponent('MeshRenderer')
	renderer.sortingOrder = 1
end

function BattleResultCtrl:ConstructChallengeSkin(skinId)
	local characterId = ConfigUtils.GetCharacterOfSkin(skinId)
	-- avatar
	local prefabName, prefabBundle = ConfigUtils.GetCharacterPrefab(characterId)
	local prefab = self:DynamicLoadAsset(prefabBundle, prefabName)
	local itemObj = Helper.NewObject(prefab, self._ui.ChallengeAvatarRoot)
	itemObj.name = tostring(skinId)
	-- animation
	local skeletonAnimation = itemObj:GetComponent("SkeletonAnimation")
	Helper.PlayAnimation(skeletonAnimation, CharacterAnimations.Idle, true)
	-- skin
	local skinName = ConfigUtils.GetSkinNameInSpine(skinId)
	Helper.SetSkin(skeletonAnimation, skinName)
	-- mesh renderer
	local renderer = itemObj:GetComponent('MeshRenderer')
	renderer.sortingOrder = 1
end

function BattleResultCtrl:ConstructSpaceTravelFail()
	assert(self._seasonId ~= nil, "invalid season id")

	local seasonData = GameData.GetSpaceTravelSeasonData(self._seasonId)
	local leftRetry = seasonData.leftBattleRetry
	self._ui.ContinueSpaceTravelHint.text = string.format("再试一次\n剩余%d次", leftRetry)
	self._ui.CancelSpaceTravelHint.text = "我认输了"
end

-- update implementation
function BattleResultCtrl:UpdateImpl(deltaTime)
	if self._starShowState ~= nil then
		local finished = self._starShowState:Tick(deltaTime)
		if finished then
			self._starShowState = nil
		end
	end
end

function BattleResultCtrl:UnlockClick()
	self._clickLocked = false
end

-- handle the escapse button
function BattleResultCtrl:HandleEscape()
	self:OnClicked(self._ui.Blocker)
end

-- can do jump or not
function BattleResultCtrl:CanJump()
	-- as we need to do goal settle, or goal data will miss
	return false
end

function BattleResultCtrl:SettleSpaceTravelChallenge()
	GameData.FinishChallenge(self._challengeId, self._settleResult)
	local dropList = {}
	if self._settleResult then
		-- win settle
		dropList = GameData.SettleSpaceTravelChoiceResult(self._seasonId, self._choiceId, true)
	else
		-- cancel settle
		dropList = GameData.SettleSpaceTravelChoiceCancel(self._seasonId, self._choiceId)
	end

    local parameter = nil
    if #dropList > 0 then
        parameter = GameData.ConstructSpaceTravelChoiceResultParameter(self._seasonId, dropList, self._baseResult)
    end
    
    self:SpaceTravelExit(false)

    if parameter ~= nil then
        CtrlManager.OpenPanel(CtrlNames.SpaceTravelChoiceResult, parameter)
    else
    	GameData.SyncSpaceTravelSeasonBaseData(self._seasonId, self._baseResult)
    end
end

function BattleResultCtrl:SettleGeneralChallenge()
	GameData.FinishChallenge(self._challengeId, self._settleResult, self._challengeStar, self._challengeRound)
	-- exit directly
	self:Exit()
end

function BattleResultCtrl:SettleArenaBattle()
	if self._settleResult then
		local battleIndex = self._parameter.battleIndex
		local difficulty = self._parameter.difficulty
		GameData.SetArenaRecordAt(battleIndex, difficulty)
	end
	-- exit
	self:Exit()

	local showRewards = self._parameter.showRewards or {}
	if #showRewards > 0 then
		NewItemCtrl.ShowNewItemList(showRewards)
	end
end

function BattleResultCtrl:SettleActivityBattle()
	-- update battle list no matter win or lose
	local themeId = self._parameter.activityThemeId
	local battleList = self._parameter.activityBattleList
	GameData.SetActivityBattleDataOfTheme(themeId, battleList)
	-- exit
	self:Exit()

	local showRewards = self._parameter.showRewards or {}
	if #showRewards > 0 then
		NewItemCtrl.ShowNewItemList(showRewards)
	end
end

function BattleResultCtrl:Exit()
	-- check goal state of current type
	GameData.CheckAndHintGoalsOfCurrentCountType()
	-- battle result
	CtrlManager.PopPanel()
	-- battle panel
	CtrlManager.PopPanel()
	-- explore/arena character
	CtrlManager.PopPanel()
end

function BattleResultCtrl:SpaceTravelExit(keepCharacter)
	-- battle result
	CtrlManager.PopPanel()
	-- battle panel
	CtrlManager.PopPanel()
	-- explore/arena character
	if not keepCharacter then
		CtrlManager.PopPanel()
	end
end

-- on clicked
function BattleResultCtrl:OnClicked(go)
	if self._clickLocked then
		return
	end

	if go == self._ui.Blocker then
		-- if space travel failed, not two buttons can work
		if self._seasonId ~= nil and not self._settleResult then
			return true
		end

		if self._seasonId ~= nil then
			assert(self._settleResult, "for space travel only win can get here")
			local isValid = CtrlManager.CheckSpaceTravelSeasonValid(self._seasonId, true)
		    if not isValid then
		        return true
		    end

		    SoundSystem.PlayUICancelSound()
			self:SettleSpaceTravelChallenge()
		elseif self._challengeId ~= nil then
			SoundSystem.PlayUICancelSound()
			self:SettleGeneralChallenge()
		elseif self._arenaBattleId ~= nil then
			SoundSystem.PlayUICancelSound()
			self:SettleArenaBattle()
		elseif self._activityBattleId ~= nil then
			SoundSystem.PlayUICancelSound()
			self:SettleActivityBattle()
		else
			assert(false, "the battle result should be for challenge or arena battle")
		end
	elseif go == self._ui.ButtonContinueSpaceTravel then
		assert(not self._settleResult, "for space travel only fail can get here")
		local isValid = CtrlManager.CheckSpaceTravelSeasonValid(self._seasonId, true)
	    if not isValid then
	        return true
	    end

		local seasonData = GameData.GetSpaceTravelSeasonData(self._seasonId)
		if seasonData.leftBattleRetry <= 0 then
			SoundSystem.PlayWarningSound()
			CtrlManager.ShowMessageBox({message = SAFE_LOC("重试次数已用完"), single = true})
		else
			SoundSystem.PlayUIClickSound()
			self:SpaceTravelExit(true)
		end
	elseif go == self._ui.ButtonCancelSpaceTravel then
		assert(not self._settleResult, "for space travel only fail can get here")
		local isValid = CtrlManager.CheckSpaceTravelSeasonValid(self._seasonId, true)
	    if not isValid then
	        return true
	    end

		SoundSystem.PlayUIClickSound()
		local seasonData = GameData.GetSpaceTravelSeasonData(self._seasonId)
        local scoreCapId = GameData.GetScoreCapOfSpaceTravelSeason(self._seasonId, seasonData.scoreCap)
        NetManager.Send('STChoiceCancel', {
            STSeasonID = self._seasonId, 
            STScoreCapID = scoreCapId,
            ChoiceId = self._choiceId,
        }, BattleResultCtrl.OnHandleProto, self)
	elseif go == self._ui.FullStarBlocker then
		SoundSystem.PlayUIClickSound()
		self._ui.FullStarPanel:SetActive(false)
	end

	return true
end

function BattleResultCtrl:OnHandleProto(proto, data, requestData)
    if proto == "STChoiceCancel" then
    	self._baseResult = data
    	self:SettleSpaceTravelChallenge()
    end
end
