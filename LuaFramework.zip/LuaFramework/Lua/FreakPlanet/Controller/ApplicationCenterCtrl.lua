require "FreakPlanet/View/ApplicationCenterPanel"

local APP_WIDTH_COUNT = 3
local APP_HEIGHT_COUNT = 5

local _isRealNameNoticed = false

local class = require "FreakPlanet/Utils/middleclass"
ApplicationCenterCtrl = class(CtrlNames.ApplicationCenter, BaseCtrl)

local function AppSortFunc(idA, idB)
	if idA == nil or idB == nil then
		return false
	end

	local valueA = ConfigUtils.GetModuleUnlockAppSortId(idA)
	local valueB = ConfigUtils.GetModuleUnlockAppSortId(idB)

	return valueA > valueB
end

-- load the ui prefab
function ApplicationCenterCtrl:LoadPanel()
	self:CreatePanel("ApplicationCenter")
end

-- construct ui panel data
function ApplicationCenterCtrl:ConstructUI(obj)
	self._ui = ApplicationCenterPanel.Init(obj)
end

-- fill ui with the data
function ApplicationCenterCtrl:SetupUI()
	local ui = self._ui
	CtrlManager.AddClick(self, ui.m_pBlockObj)
	CtrlManager.AddClick(self, ui.m_pHomeBtn)

	GameNotifier.AddListener(GameEvent.BulletinStateChanged, ApplicationCenterCtrl.OnNoticeStateChanged, self)
	GameNotifier.AddListener(GameEvent.WeeklyReportStateChanged, ApplicationCenterCtrl.OnWeeklyReportStateChanged, self)
	GameNotifier.AddListener(GameEvent.MailStateChanged, ApplicationCenterCtrl.OnMailStateChanged, self)
	GameNotifier.AddListener(GameEvent.TimeLimitActivityChanged, ApplicationCenterCtrl.OnTimeLimitActivityChanged, self)
	GameNotifier.AddListener(GameEvent.SummonPoolChanged, ApplicationCenterCtrl.OnSummonPoolChanged, self)

	ui.m_pAppEntrancePanel:SetActive(true)
	self.m_bIsMain = true

	self._AppList = ConfigUtils.GetUnlockAppList()
	table.sort(self._AppList, AppSortFunc)
	for idx = 1, #self._AppList do
		local m_pObj = Helper.NewObject(ui.m_pMenuItemTemplate, ui.m_pAppMenuRoot.transform)
		m_pObj:SetActive(true)
		m_pObj.name = tostring(self._AppList[idx])
		CtrlManager.AddClick(self, m_pObj)
		self:ConstructAppItems(m_pObj, self._AppList[idx])
	end
	ui.m_pAppMenuRoot:Reposition()
end

function ApplicationCenterCtrl:DestroyImpl()
	GameNotifier.RemoveListener(GameEvent.BulletinStateChanged, ApplicationCenterCtrl.OnNoticeStateChanged, self)
	GameNotifier.RemoveListener(GameEvent.WeeklyReportStateChanged, ApplicationCenterCtrl.OnWeeklyReportStateChanged, self)
	GameNotifier.RemoveListener(GameEvent.MailStateChanged, ApplicationCenterCtrl.OnMailStateChanged, self)
	GameNotifier.RemoveListener(GameEvent.TimeLimitActivityChanged, ApplicationCenterCtrl.OnTimeLimitActivityChanged, self)
	GameNotifier.RemoveListener(GameEvent.SummonPoolChanged, ApplicationCenterCtrl.OnSummonPoolChanged, self)
end

function ApplicationCenterCtrl:NotifyFocus()
	--[[
	local m_iAppCount = GameDataSubApplication.GetShowAppCount()
	for idx = 1, self._ui.m_pAppMenuRoot.transform.childCount do
		if idx <= m_iAppCount then
			local m_pChildObj = self._ui.m_pAppMenuRoot.transform:GetChild(idx - 1)
			self:ConstructAppItems(m_pChildObj, idx)
		end
	end
	--]]
end

function ApplicationCenterCtrl:ConstructAppItems(item, moduleId)
	local pSpriteIcon = item.transform:Find("Icon"):GetComponent("UISprite")
	local pObjDot = item.transform:Find("Dot").gameObject
	local pTxtName = item.transform:Find("Name"):GetComponent("UILabel")

	pTxtName.text = ConfigUtils.GetModuleUnlockAppName(moduleId)
	local iconName, atlasName = ConfigUtils.GetModuleIcon(moduleId)
	self:SetIconWithAtlas(pSpriteIcon, iconName, atlasName)
	self:RefreshHint(pObjDot, moduleId)
end

-- on clicked
function ApplicationCenterCtrl:OnClicked(go)
	local ui = self._ui
	if go.transform.parent == ui.m_pAppMenuRoot.transform then
		local id = tonumber(go.name)
		if ConfigUtils.GetIsInternalModule(id) then
			self:LoadInterialApp(id)
		else
			self:JumpToPanel(id)
		end
	elseif go == ui.m_pBlockObj then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
	elseif go == ui.m_pHomeBtn then
		XDebug.Log("LZ", "HomeBtn")
		self:HomeReturn()
	end
	return true
end


---加载App内界面模块
---@param idx table
function ApplicationCenterCtrl:LoadInterialApp(idx)
	SoundSystem.PlayUIClickSound()
	self._ui.m_pMainRootTrans.gameObject:SetActive(false)
	self._ui.m_pSubRootTrans.gameObject:SetActive(true)
	self.m_bIsMain = false
	--[[
	local type = GameDataSubApplication.GetAppMenuType(idx)
	if type == GameDataSubApplication.EAppMenuType.FurnitureShop then
		self.AppHomeTradePanelLayout = AppHomeTradeLayout:new(self, "AppHomeTrade", self._ui.m_pSubRootTrans, function(obj)
			XDebug.Log("LZ", "obj:", obj.name)
		end)
		self:AddSubAppLayout(self.AppHomeTradePanelLayout)
		self.AppHomeTradePanelLayout:Show()
	end
	--]]
end

---加载普通界面模块
---@param idx table
function ApplicationCenterCtrl:JumpToPanel(id)
	local type = ConfigUtils.GetModuleUnlockName(id)
	SoundSystem.PlayUIClickSound()
	if type == ModuleNames.Setting then
		CtrlManager.DoWaitTransition(CtrlNames.GameOption, self, ApplicationCenterCtrl.GotoTarget, id)
	elseif type == ModuleNames.Notice then
		CtrlManager.DoWaitTransition(CtrlNames.Bulletin, self, ApplicationCenterCtrl.GotoTarget, id)
	elseif type == ModuleNames.Mail then
		CtrlManager.DoWaitTransition(CtrlNames.Mail, self, ApplicationCenterCtrl.GotoTarget, id)
	elseif type == ModuleNames.Newspaper then
		CtrlManager.DoWaitTransition(CtrlNames.WeeklyReport, self, ApplicationCenterCtrl.GotoTarget, id)
	elseif type == ModuleNames.Mission then
		CtrlManager.DoWaitTransition(CtrlNames.Goal, self, ApplicationCenterCtrl.GotoTarget, id)
	elseif type == ModuleNames.CharacterList then
		CtrlManager.DoWaitTransition(CtrlNames.CharacterList, self, ApplicationCenterCtrl.GotoTarget, id)
	elseif type == ModuleNames.Warehouse then
		CtrlManager.DoWaitTransition(CtrlNames.Warehouse, self, ApplicationCenterCtrl.GotoTarget, id)
	elseif type == ModuleNames.Gallery then
		CtrlManager.DoWaitTransition(CtrlNames.GalleryPlanet, self, ApplicationCenterCtrl.GotoTarget, id)
	elseif type == ModuleNames.Lab then
		CtrlManager.DoWaitTransition(CtrlNames.Laboratory, self, ApplicationCenterCtrl.GotoTarget, id)
	elseif type == ModuleNames.Weekly then
		CtrlManager.DoWaitTransition(CtrlNames.WeeklyGoal, self, ApplicationCenterCtrl.GotoTarget, id)
	elseif type == ModuleNames.HomeFurnitureShop then
		CtrlManager.DoWaitTransition(CtrlNames.FurnitureShop, self, ApplicationCenterCtrl.GotoTarget, id)
	elseif type == ModuleNames.HomeAchievement then
		CtrlManager.DoWaitTransition(CtrlNames.HomeAchievement, self, ApplicationCenterCtrl.GotoTarget, id)
	elseif type == ModuleNames.IAP then
		CtrlManager.DoWaitTransition(CtrlNames.Mall, self, ApplicationCenterCtrl.GotoTarget, id)
	elseif type == ModuleNames.Signin then
		CtrlManager.DoWaitTransition(CtrlNames.SignInReward, self, ApplicationCenterCtrl.GotoTarget, id)
	end
end

function ApplicationCenterCtrl:GotoTarget(id)
	SoundSystem.PlayUIClickSound()
	local type = ConfigUtils.GetModuleUnlockName(id)

	if type == ModuleNames.Setting then
		CtrlManager.OpenPanel(CtrlNames.GameOption)
	elseif type == ModuleNames.Notice then
		CtrlManager.OpenPanel(CtrlNames.Bulletin)
	elseif type == ModuleNames.Mail then
		CtrlManager.OpenPanel(CtrlNames.Mail)
	elseif type == ModuleNames.Newspaper then
		CtrlManager.OpenPanel(CtrlNames.WeeklyReport)
	elseif type == ModuleNames.Mission then
		CtrlManager.OpenPanel(CtrlNames.Goal)
	elseif type == ModuleNames.CharacterList then
		CtrlManager.OpenPanel(CtrlNames.CharacterList)
	elseif type == ModuleNames.Warehouse then
		CtrlManager.OpenPanel(CtrlNames.Warehouse)
	elseif type == ModuleNames.Gallery then
		CtrlManager.OpenPanel(CtrlNames.GalleryPlanet)
	elseif type == ModuleNames.Lab then
		CtrlManager.OpenPanel(CtrlNames.Laboratory)
	elseif type == ModuleNames.Weekly then
		CtrlManager.OpenPanel(CtrlNames.WeeklyGoal)
	elseif type == ModuleNames.HomeFurnitureShop then
		CtrlManager.OpenPanel(CtrlNames.FurnitureShop)
	elseif type == ModuleNames.HomeAchievement then
		CtrlManager.OpenPanel(CtrlNames.HomeAchievement)
	elseif type == ModuleNames.IAP then
		CtrlManager.OpenPanel(CtrlNames.Mall)
	elseif type == ModuleNames.Signin then
		CtrlManager.OpenPanel(CtrlNames.SignInReward)
	end
end

function ApplicationCenterCtrl:HomeReturn()
	if not self.m_bIsMain then
		self._ui.m_pMainRootTrans.gameObject:SetActive(true)
		self._ui.m_pSubRootTrans.gameObject:SetActive(false)
	end
	local m_tSubAppLayouts = self:GetSubAppLayout()
	for idx = 1, #m_tSubAppLayouts do
		local m_pSubLayout = m_tSubAppLayouts[idx]
		if m_pSubLayout then
			m_pSubLayout:Hide()
			self:RemoveSubAppLayout()
		end
	end
end

---菜单红点
function ApplicationCenterCtrl:RefreshHint(hint, id)
	local m_bIsUnlockedModule = false
	local m_bIsShowHint = false
	local type = ConfigUtils.GetModuleUnlockName(id)
	if type == ModuleNames.Settings then
		m_bIsShowHint = GameData.IsAccountNicknameBinded()
	elseif type == ModuleNames.Notice then
		m_bIsShowHint = GameData.ShowBulletinHit()
	elseif type == ModuleNames.Mail then
		m_bIsShowHint = GameData.HasNewMail()
	elseif type == ModuleNames.Newspaper then
		m_bIsShowHint = GameData.HasNewWeeklyReport()
	elseif type == ModuleNames.Mission then
		m_bIsUnlockedModule = GameData.IsModuleUnlocked(ModuleNames.Mission)
		m_bIsShowHint = m_bIsUnlockedModule and (GameData.HasCompletedGoalOfType(GoalType.Main) or GameData.IsItemNew(ModuleNames.Demand))
	elseif type == ModuleNames.CharacterList then
		m_bIsUnlockedModule = GameData.IsModuleUnlocked(ModuleNames.CharacterList)
		m_bIsShowHint = m_bIsUnlockedModule and (GameData.HasNewOfType(ItemType.Character) or GameData.HasMatchedCharacterToPromote())
	elseif type == ModuleNames.Warehouse then
		m_bIsUnlockedModule = GameData.IsModuleUnlocked(ModuleNames.Warehouse)
		m_bIsShowHint = m_bIsUnlockedModule and GameData.HasNewOfType(ItemType.Goods)
	elseif type == ModuleNames.Gallery then
		m_bIsShowHint = false
	elseif type == ModuleNames.Lab then
		m_bIsShowHint = GameData.IsModuleUnlocked(ModuleNames.Lab)
	elseif type == ModuleNames.Weekly then
		m_bIsShowHint = false
	elseif type == ModuleNames.HomeFurnitureShop then
		m_bIsShowHint = false
	elseif type == ModuleNames.HomeAchievement then
		m_bIsShowHint = false
	elseif type == ModuleNames.IAP then
		m_bIsShowHint = GameData.HasNewMail()
	elseif type == ModuleNames.Signin then
		m_bIsShowHint = GameData.HasSignInReward() or GameData.HasAnyMonthCardReward()
	end
	hint:SetActive(m_bIsShowHint)
end

---Notice
function ApplicationCenterCtrl:OnNoticeStateChanged()

end

---WeeklyReport
function ApplicationCenterCtrl:OnWeeklyReportStateChanged()

end

---Mail
function ApplicationCenterCtrl:OnMailStateChanged()

end

---周报
function ApplicationCenterCtrl:CheckWeeklyReport()
	if GameData.HasNewWeeklyReport() then
		CtrlManager.OpenPanel(CtrlNames.WeeklyReport)
		return true
	else
		return false
	end
end

---任务展示事件
function ApplicationCenterCtrl:OnTimeLimitActivityChanged()

end

---抽奖
function ApplicationCenterCtrl:OnSummonPoolChanged()

end



