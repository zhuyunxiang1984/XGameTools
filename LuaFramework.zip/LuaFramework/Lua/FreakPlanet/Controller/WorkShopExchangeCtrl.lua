require "FreakPlanet/View/WorkShopExchangePanel"

local class = require "FreakPlanet/Utils/middleclass"
WorkShopExchangeCtrl  = class(CtrlNames.WorkShopExchange, BaseCtrl)

-- load the ui prefab
function WorkShopExchangeCtrl:LoadPanel()
	self:CreatePanel("WorkShopExchange")
end

-- construct ui panel data
function WorkShopExchangeCtrl:ConstructUI(obj)
	self._ui = WorkShopExchangePanel.Init(obj)
end

function WorkShopExchangeCtrl:DestroyImpl()
	GameNotifier.RemoveListener(GameEvent.MoneyChanged, WorkShopExchangeCtrl.OnMoneyChanged, self)
end

-- fill ui with the data
function WorkShopExchangeCtrl:SetupUI()
	self._workShopId = self._parameter.workShopId
	self._ui.WorkShopName.text = ConfigUtils.GetWorkShopName(self._workShopId)

	local code = ConfigUtils.GetWorkShopExchangeCode(self._workShopId)
	for k, v in pairs(self._ui.WorkShops) do
		v:SetActive(code == k)
	end

	local maxWorkTime = GameData.GetWorkShopMaxWorkTime(self._workShopId)
	if GameData.IsFirstWorkShopSettle() then
		self._exchangeCost = 0
	else
		self._exchangeCost = ConfigUtils.GetWorkShopExchangeCost(maxWorkTime)
	end
	self._ui.ExchangeCostLabel.text = tostring(self._exchangeCost)
	self._ui.ExchangeDesc.text = ConfigUtils.GetWorkShopExchangeDesc(self._workShopId)

	local workShopDesc = SAFE_LOC("loc_workshopquickexchange_getreward")
	local workTimeText = Helper.GetLongTimeString(maxWorkTime)
	self._ui.WorkShopDesc.text = Helper.StringFindAndReplace(workShopDesc, "{Time}", workTimeText)

	self:RefreshExchangeCostColor()
	self:ConstructRewards()
	self:CheckTutorial()
	
	CtrlManager.AddClick(self, self._ui.Blocker)
	CtrlManager.AddClick(self, self._ui.ButtonConfirm)
	GameNotifier.AddListener(GameEvent.MoneyChanged, WorkShopExchangeCtrl.OnMoneyChanged, self)
end

function WorkShopExchangeCtrl:ConstructRewards()
	self._hasExchangeReward = false
	local rewards = GameData.GetDropDataOfWorkShop(self._workShopId)
	for idx = 1, #self._ui.Rewards do
		local hasReward = (idx <= #rewards)
		self._ui.Rewards[idx].item:SetActive(hasReward)
		if hasReward then
			local showReward = (rewards[idx].unlocked and rewards[idx].productionSpeed > 0)
			self._ui.Rewards[idx].iconRoot:SetActive(showReward)
			if showReward then
				UIHelper.ConstructItemIconAndNum(self, self._ui.Rewards[idx].root, rewards[idx].dropId)
			end

			if showReward then
				self._hasExchangeReward = true
			end
		end
	end
end

function WorkShopExchangeCtrl:RefreshExchangeCostColor()
	local diamond = GameData.GetMoney(ItemType.Diamond)
	if diamond >= self._exchangeCost then
		self._ui.ExchangeCostLabel.color = self._ui.ExchangeDiamondColor
	else
		self._ui.ExchangeCostLabel.color = Color.red
	end
end

function WorkShopExchangeCtrl:OnMoneyChanged(itemType)
	self:RefreshExchangeCostColor()
end

-- on clicked
function WorkShopExchangeCtrl:OnClicked(go)
	if go == self._ui.Blocker then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
	elseif go == self._ui.ButtonConfirm then		
		local diamond = GameData.GetMoney(ItemType.Diamond)
		if diamond < self._exchangeCost then
			SoundSystem.PlayWarningSound()
			CtrlManager.ShowMessageBox({message = SAFE_LOC("兑换玉璧不足"), single = true})
			return true
		end

		if not self._hasExchangeReward then
			SoundSystem.PlayWarningSound()
			CtrlManager.ShowMessageBox({message = SAFE_LOC("打工评级不够，不会产生任何奖励"), single = true})
			return true
		end

		SoundSystem.PlaySoundOfName(SoundNames.WorkshopOvertime)
		NetManager.Send("WorkShopBuy", {WorkShopId = self._workShopId}, WorkShopExchangeCtrl.OnHandleProto, self)
	end

	return true
end

function WorkShopExchangeCtrl:OnHandleProto(proto, data, requestData)
	if proto == "WorkShopBuy" then
		NavigationCtrl.EnableSuspend(true)
		local rewardList = data.RewardList or {}
		for idx = 1, #rewardList do
			local dropId = rewardList[idx].Value
			local dropNum = rewardList[idx].Num
			GameData.CollectItem(dropId, dropNum)
		end

		local diamondNum = data.RemainDiamond
		GameData.IncWorkShopSettle()
		GameData.SetMoney(ItemType.Diamond, diamondNum)
		-- close this panel
		CtrlManager.PopPanel()

		local workShopId = requestData.WorkShopId
		GameNotifier.Notify(GameEvent.WorkShopExchanged, workShopId, rewardList)
	end
end

--------------------------------------------------------
-- tutorial
function WorkShopExchangeCtrl:CheckTutorial()
	local tutorials = {}

	if GameData.IsFirstWorkShopSettle() then
		local position = self._ui.Camera:WorldToScreenPoint(self._ui.ButtonConfirm.transform.position)
		tutorials[1] = {event = Tutorials.Tutorial_WorkshopExchangeSpeedUp, position = position, sender = self}
	end

	if #tutorials > 0 then
		CtrlManager.ShowTutorials(tutorials)
	end

	return #tutorials > 0
end

function WorkShopExchangeCtrl:OnTutorialClicked(tutorial)
	if tutorial == Tutorials.Tutorial_WorkshopExchangeSpeedUp then
		SoundSystem.PlayUIClickSound()
		self:OnClicked(self._ui.ButtonConfirm)
	end
end
--------------------------------------------------------