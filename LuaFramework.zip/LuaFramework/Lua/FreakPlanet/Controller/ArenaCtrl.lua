require "FreakPlanet/View/ArenaPanel"
require "FreakPlanet/UI/HideSeek/require"

local X_MAX_VALUE = 1000
local X_MIN_VALUE = -1100
local MOVE_LIMIT = 10
local MOVE_DAMPING = 0.95
local DRAG_SPEED = 1000

local X_MAX_LIMIT = 600
local X_MIN_LIMIT = -2000

local class = require "FreakPlanet/Utils/middleclass"
ArenaCtrl  = class(CtrlNames.Arena, BaseCtrl)

-- load the ui prefab
function ArenaCtrl:LoadPanel()
    self:DynamicLoadBundle(Const.CatchFishAtlasBundleName)
	self:CreatePanel("Arena")
end

-- construct ui panel data
function ArenaCtrl:ConstructUI(obj)
	self._ui = ArenaPanel.Init(obj)
    self.HideSeekEntranceLayout = HideSeekEntranceLayout:new(self, self._ui.m_pHideSeekEntranceObj)
    self:AddLayout(self.HideSeekEntranceLayout)
end

-- notity it has been focused
function ArenaCtrl:NotifyFocus()
    self:RefreshHint()
    self:RefreshComment()
end

-- destructor
function ArenaCtrl:DestroyImpl()
    SoundSystem.PlayMusic()
    GameNotifier.RemoveListener(GameEvent.CharacterNodeVisibleChanged, ArenaCtrl.OnCharacterNodeVisibleChanged, self)
    GameNotifier.RemoveListener(GameEvent.ActivityExplore, ArenaCtrl.OnActivityExplore, self)
    GameNotifier.RemoveListener(GameEvent.ActivityExploreSpeedUp, ArenaCtrl.OnActivityExploreSpeedUp, self)
    GameNotifier.RemoveListener(GameEvent.ActivityExploreSettle, ArenaCtrl.OnActivityExploreSettle, self)
    GameNotifier.RemoveListener(GameEvent.IapCompleted, self.OnIapCompleted)
    GameNotifier.RemoveListener(GameEvent.HideSeekDataChanged, ArenaCtrl.ConstructHideSeekCollider, self)
    GameNotifier.RemoveListener(GameEvent.HideSeekActivityOver, ArenaCtrl.CloseAllHideSeekObjs, self)

    GameNotifier.RemoveListener(GameEvent.TouristChanged, ArenaCtrl.OnTouristChanged, self)

    self.HideSeekEntranceLayout:Hide()
    CtrlManager.ClosePanel(CtrlNames.HideSeek)
end

-- fill ui with the data
function ArenaCtrl:SetupUI()
    local ui = self._ui
    self._isDraging = false
    self._currentX = self._ui.SceneRoot.localPosition.x
    self._lastDiffX = 0
    self._dragSpeed = 0

    self._activeArenaConfigId = nil
    self._activeArenaEndTime = nil
    self._activityThemeId = nil
    self._activityThemeEndTime = nil
    self._exploringThemeId = nil
    self._exploringEndTime = nil

    local arenaUnlocked = GameData.IsModuleUnlocked(ModuleNames.Arena)
    --self._ui.ButtonMarket:SetActive(arenaUnlocked)
    if arenaUnlocked then
        local arenaConfigId, _, arenaEndTime = GameData.GetActivatedArenaConfigId()
        self._activeArenaConfigId = arenaConfigId
        self._activeArenaEndTime = arenaEndTime
    end

    if GameData.IsModuleUnlocked(ModuleNames.Activity) then
        self._activityThemeId, self._activityThemeEndTime = GameData.GetCurrentActivityTheme()
        self._exploringThemeId = GameData.GetUnsettledActivityTheme()
        if self._exploringThemeId ~= nil then
            local startTime, endTime = GameData.GetActivityExploreTime(self._exploringThemeId)
            self._exploringEndTime = endTime
        end
    end
    --播放音乐
    local finalBGM = SoundNames.ArenaMusic
    if self._activityThemeId then
        local bgmName = ConfigUtils.GetActivityThemeBGM(self._activityThemeId)
        if bgmName and SoundSystem.IsExistSoundClip(bgmName) then
            finalBGM = bgmName
        end
    end

    SoundSystem.PlayMusicByName(finalBGM)

    self:OpenActivitySignInPanel()
    self:CleanDialog()
    self:ConstructBuildings()
    self:ConstructCharacterNodes()
    self:RefreshHint()
    self:ConstructHideSeekCollider()
    self:RefreshHideSeekEntrance()
    self:RefreshComment()

    self._ui.ArenaLeftTime.text = ""
    self._ui.ActivityLeftTime.text = ""
    self._ui.ExploreLeftTime.text = ""
    self._ui.ExploreFinishHint:SetActive(false)
    self._ui.ButtonExploreSpeedUp:SetActive(self._exploringThemeId ~= nil)
    local showBus = (self._exploringThemeId == nil and self:HasActivityThemeCanExplore())
    self._ui.ButtonExplore:SetActive(showBus)
    self._ui.ExploreBus:SetActive(showBus)
    self._ui.ActivityHint:SetActive(self._activityThemeId ~= nil)
    if showBus then
        local lastThemeId = GameData.GetLastActivityExploreTheme()
        if lastThemeId ~= self._activityThemeId then
            self._ui.ExploreBusAnimator:Play("BusIn", 0, 0)
            GameData.SetLastActivityExploreTheme(self._activityThemeId)
        else
            self._ui.ExploreBusAnimator:Play("BusIdle", 0, 0)
        end
    end

    --
    self.OnIapCompleted = function(iapId)
        XDebug.Log('GGYY', "IAP购买完成 " .. iapId)
    end

    --
    ui.ButtonCatchFish:SetActive(GameData.GetCurrentActivityThemeGameModule() == EnumMiniGameModule.CatchFish)
    ui.btnActivityDailyReward:SetActive(GameData.IsValidActivitySignIn() and GameData.IsShowActivitySignIn())
    ui.btnActivityPassport:SetActive(GameData.HasActivitySignInPassCheck())


    CtrlManager.AddPress(self, self._ui.Blocker)
    CtrlManager.AddPress(self, self._ui.ButtonArena)
    --CtrlManager.AddPress(self, self._ui.ButtonMarket)
    CtrlManager.AddPress(self, self._ui.ButtonActivity)
    CtrlManager.AddPress(self, self._ui.ButtonExplore)
    CtrlManager.AddPress(self, self._ui.ButtonExploreSpeedUp)
    CtrlManager.AddPress(self, self._ui.ButtonCatchFish)
    CtrlManager.AddPress(self, self._ui.ButtonClothesShop)

    CtrlManager.AddClick(self, self._ui.ButtonClose)
    CtrlManager.AddClick(self, self._ui.Blocker)
    CtrlManager.AddClick(self, self._ui.ButtonArena)
    CtrlManager.AddClick(self, self._ui.pBtnMarket)
    CtrlManager.AddClick(self, self._ui.ButtonActivity)
    CtrlManager.AddClick(self, self._ui.ButtonExplore)
    CtrlManager.AddClick(self, self._ui.ButtonExploreSpeedUp)
    CtrlManager.AddClick(self, self._ui.ButtonCatchFish)
    CtrlManager.AddClick(self, self._ui.ButtonClothesShop)
    CtrlManager.AddClick(self, self._ui.btnActivityDailyReward)
    CtrlManager.AddClick(self, self._ui.btnActivityPassport)
    CtrlManager.AddClick(self, self._ui.pBtnHome)

    CtrlManager.AddClick(self, self._ui.m_pAppCenterBtn)
    CtrlManager.AddClick(self, self._ui.m_pPlanetBtn)

    CtrlManager.AddClick(self, self._ui.pBtnWorkShop)
    CtrlManager.AddClick(self, self._ui.pBtnSummon)
    CtrlManager.AddClick(self, self._ui.m_pTouristBtn)

    GameNotifier.AddListener(GameEvent.CharacterNodeVisibleChanged, ArenaCtrl.OnCharacterNodeVisibleChanged, self)
    GameNotifier.AddListener(GameEvent.ActivityExplore, ArenaCtrl.OnActivityExplore, self)
    GameNotifier.AddListener(GameEvent.ActivityExploreSpeedUp, ArenaCtrl.OnActivityExploreSpeedUp, self)
    GameNotifier.AddListener(GameEvent.ActivityExploreSettle, ArenaCtrl.OnActivityExploreSettle, self)
    GameNotifier.AddListener(GameEvent.IapCompleted, self.OnIapCompleted)
    GameNotifier.AddListener(GameEvent.HideSeekDataChanged, self.ConstructHideSeekCollider, self)
    GameNotifier.AddListener(GameEvent.HideSeekActivityOver, self.CloseAllHideSeekObjs, self)

    GameNotifier.AddListener(GameEvent.SummonPoolChanged, ArenaCtrl.OnSummonPoolChanged, self)
    GameNotifier.AddListener(GameEvent.TouristChanged, ArenaCtrl.OnTouristChanged, self)
end

function ArenaCtrl:ConstructBuildings()
    local themeId = self._activityThemeId
    if themeId == nil then
        themeId = ConfigUtils.GetDefaultActivityTheme()
    end

    local buildingMap = ConfigUtils.GetActivityThemeBuildings(themeId)
    for idx = 1, self._ui.BuildingRoot.childCount do
        local item = self._ui.BuildingRoot:GetChild(idx - 1)
        local pTransBuilding = item.transform:GetChild(0)
        if pTransBuilding then
            local pTransLock = pTransBuilding:Find("Lock")
            local pTransUnlock = pTransBuilding:Find("Unlock")

            local buildingName = item.gameObject.name
            local prefabName = buildingMap[buildingName]
            if pTransLock then
                pTransLock.gameObject:SetActive(prefabName == nil)
            end
            if pTransUnlock then
                pTransUnlock.gameObject:SetActive(prefabName ~= nil)
            end
        end

        --[[
        if prefabName ~= nil then
            local buildingPrefab = self:DynamicLoadAsset(Const.ArenaBuildingBundleName, prefabName)
            local buildingObj = Helper.NewObject(buildingPrefab, item)
            buildingObj.name = prefabName
            buildingObj:SetActive(true)
        end
        --]]
    end
end

function ArenaCtrl:ConstructCharacterNodes()
    for idx = 1, self._ui.CharacterRoot.childCount do
        local groupNode = self._ui.CharacterRoot:GetChild(idx - 1)
        for m = 1, groupNode.childCount do
            local nodeItem = groupNode:GetChild(m - 1).gameObject
            local nodeName = nodeItem.name
            local isVisible = NodeHelper.IsExileCharacterNodeVisible(nodeName)
            nodeItem:SetActive(isVisible)
        end
    end
end

function ArenaCtrl:OpenActivitySignInPanel()
    if GameData.CanOpenActivitySignInPanel() then
        CtrlManager.OpenPanel(CtrlNames.ActivitySignInReward)
    end
end

function ArenaCtrl:RefreshHint()
    local showHint = GameData.HasCompletedActivityGoal()
    self._ui.ActivityGoalHint:SetActive(showHint)
end

function ArenaCtrl:ConstructHideSeekCollider()
    local unlockActivity = GameData.UnlockHideSeekActivity()
    if unlockActivity then
        local IdList, nodeList = GameDataHideSeek.GetActiveHideSeekIdAndNode()
        XDebug.LogTable("LZ", "nodeList:", nodeList)
        for idx = 1, self._ui.RabbitRoot.childCount do
            local item = self._ui.RabbitRoot:GetChild(idx - 1)
            local nodeIndex = Helper.IndexOfArray(nodeList, item.name)

            if unlockActivity and nodeIndex then
                item.gameObject:SetActive(true)
                local id = IdList[nodeIndex]
                local ColliderItem = self._ui.HideSeekColliderRoot:Find(tostring(id))
                if not ColliderItem then
                    local newObj = Helper.NewObject(self._ui.HideSeekColliderTemplate, self._ui.HideSeekColliderRoot)
                    local position = self._ui.RabbitRoot:InverseTransformPoint(item.transform.position)
                    newObj.transform.localPosition = position
                    local originCollider = item:GetComponent("BoxCollider")
                    local colliderCenter = originCollider.center
                    local colliderSize = originCollider.size
                    local newObjCollider = newObj:GetComponent("BoxCollider")
                    newObjCollider.center = colliderCenter
                    newObjCollider.size = colliderSize
                    newObj.name = tostring(IdList[nodeIndex])
                    CtrlManager.AddClick(self, newObj)
                end

            else
                item.gameObject:SetActive(false)
            end
        end
        self:RefreshHideSeekUI()
    end
end

function ArenaCtrl:CloseAllHideSeekObjs()
    if self._ui.RabbitRoot then
        for idx = 1, self._ui.RabbitRoot.childCount do
            local item = self._ui.RabbitRoot:GetChild(idx - 1)
            item.gameObject:SetActive(false)
        end
    end

    if self._ui.HideSeekColliderRoot then
        for idx = 1, self._ui.HideSeekColliderRoot.childCount do
            local item = self._ui.HideSeekColliderRoot:GetChild(idx - 1)
            item.gameObject:SetActive(false)
        end
    end
    self:RefreshHideSeekEntrance()
end

function ArenaCtrl:RefreshHideSeekUI()
    if GameData.UnlockHideSeekActivity() then
        local IdList, nodeList = GameDataHideSeek.GetActiveHideSeekIdAndNode()
        for idx = 1, self._ui.RabbitRoot.childCount do
            local item = self._ui.RabbitRoot:GetChild(idx - 1)
            item.gameObject:SetActive(Helper.TableContains(nodeList, item.name))
        end

        for idx = 1, self._ui.HideSeekColliderRoot.childCount do
            local item = self._ui.HideSeekColliderRoot:GetChild(idx - 1)
            local contain = Helper.TableContains(IdList, item.name)
            item.gameObject:SetActive(contain)
            if contain then
                GameData.SetHideSeekRabbitDataWithNewTag(tonumber(item.name))
            end
        end
    end
end

-- update implementation
function ArenaCtrl:UpdateImpl(deltaTime)
    -- scene position
    self:UpdateScenePosition(deltaTime)
    -- update dialog
    if #self._dialogList > 0 then
        self._ui.DialogItem.localPosition = self._ui.DialogRoot:InverseTransformPoint(self._dialogList[1].root.position)
        local leftTime = self._dialogList[1].leftTime - deltaTime
        self._dialogList[1].leftTime = leftTime
        if leftTime <= 0 then
            table.remove(self._dialogList, 1)
            if #self._dialogList > 0 then
                self:PeekFirstDialog()
            else
                self:HideDialogItem()
            end
        end
    end
    -- refresh arena and activity left time
    self:RefreshLeftTime()
end

function ArenaCtrl:UpdateScenePosition(deltaTime)
    if self._isDraging then
        local newPosition = self:ScreenToWorld(Input.mousePosition)
        local dx = (newPosition.x - self._mouseWorldPosition.x)
        local diff = self._ui.SceneRoot.parent:InverseTransformPoint(Vector3.New(dx, 0, 0))
        self._currentX = self._currentX + diff.x
        self._mouseWorldPosition = newPosition
        self._lastDiffX = diff.x
        -- sync position
        self:SyncScenePosition()

        if not CtrlManager.IsValidInput() then
            self._isDraging = false
            self._lastDiffX = 0
            self._dragSpeed = 0
        end
    elseif math.abs(self._dragSpeed) > 0 then
        self._currentX = self._currentX + self._dragSpeed * deltaTime
        local reachLimit = false
        if self._currentX >= X_MAX_VALUE then
            self._currentX = X_MAX_VALUE
            reachLimit = true
        elseif self._currentX <= X_MIN_VALUE then
            self._currentX = X_MIN_VALUE
            reachLimit = true
        end
        -- sync position
        self:SyncScenePosition()

        if reachLimit then
            self._dragSpeed = 0
        else
            self._dragSpeed = self._dragSpeed * MOVE_DAMPING
            if math.abs(self._dragSpeed) <= 1 then
                self._dragSpeed = 0
            end
        end
    else
        if self._currentX > X_MAX_VALUE then
            local diff = (X_MAX_VALUE - self._currentX)
            if math.abs(diff) <= 1 then
                self._currentX = X_MAX_VALUE
            else
                self._currentX = self._currentX + diff * 8 * deltaTime
                self._currentX = math.max(self._currentX, X_MAX_VALUE)
            end
            -- sync position
            self:SyncScenePosition()
        elseif self._currentX < X_MIN_VALUE then
            local diff = (X_MIN_VALUE - self._currentX)
            if math.abs(diff) <= 1 then
                self._currentX = X_MIN_VALUE
            else
                self._currentX = self._currentX + diff * 8 * deltaTime
                self._currentX = math.min(self._currentX, X_MIN_VALUE)
            end
            -- sync position
            self:SyncScenePosition()
        end
    end
end

function ArenaCtrl:IsSceneInRange()
    return self._currentX >= X_MIN_VALUE and self._currentX <= X_MAX_VALUE
end

function ArenaCtrl:SyncScenePosition()
    local finalX = math.min(self._currentX, X_MAX_LIMIT)
    finalX = math.max(finalX, X_MIN_LIMIT)
    local pos = self._ui.SceneRoot.localPosition
    pos.x = finalX
    self._ui.SceneRoot.localPosition = pos
end

function ArenaCtrl:RefreshLeftTime()
    local curTime = GameData.GetServerTime()

    if self._activeArenaConfigId ~= nil then
        local leftTime = math.max(0, self._activeArenaEndTime - curTime)
        if leftTime == 0 then
            self._ui.ArenaLeftTime.text = SAFE_LOC("已结束")
        else
            self._ui.ArenaLeftTime.text = Helper.GetLongTimeString(leftTime)
        end
    end

    if self._activityThemeId ~= nil then
        local leftTime = math.max(0, self._activityThemeEndTime - curTime)
        if leftTime == 0 then
            self._ui.ActivityLeftTime.text = SAFE_LOC("已结束")
        else
            self._ui.ActivityLeftTime.text = Helper.GetLongTimeString(leftTime)
        end
    end

    if self._exploringThemeId ~= nil then
        local leftTime = math.max(0, self._exploringEndTime - curTime)
        if leftTime == 0 then
            self._ui.ExploreLeftTime.text = SAFE_LOC("本次探索已结束，列车即将到站，请点击站台迎接队员")
        else
            self._ui.ExploreLeftTime.text = string.format("列车正在探索中，剩余时间：%s", Helper.GetLongTimeString(leftTime))
        end
        -- hint
        self._ui.ExploreFinishHint:SetActive(leftTime == 0)
    end
end
---------------------------------------------------------------------------------------
function ArenaCtrl:OnCharacterNodeClicked(node)
    local dialogRoot = node:Find("DialogRoot")
    if dialogRoot == nil then
        return
    end

    self._dialogList = {}
    local childCount = dialogRoot.childCount

    local nodeName = node.gameObject.name
    local dialogList = ConfigUtils.GetExileCharacterNodeDialogList(nodeName) or {}
    local totalCount = #dialogList
    if totalCount >= 1 then
        local dialogIdx = Helper.RandInt(1, totalCount)
        local dialogs = dialogList[dialogIdx]
        for idx = 1, #dialogs do
            local text = dialogs[idx].Text
            local pos = dialogs[idx].Position
            if pos <= childCount then
                table.insert(self._dialogList, {
                    message = SAFE_LOC(text),
                    root = dialogRoot:GetChild(pos - 1),
                    leftTime = string.len(text) / self._ui.DialogTypeEffect.charsPerSecond + 0.5,
                })
            end
        end
    end

    self:PeekFirstDialog()
end

function ArenaCtrl:OnActivityExplore(themeId, endTime)
    self._exploringThemeId = themeId
    self._exploringEndTime = endTime

    self._ui.ExploreFinishHint:SetActive(false)
    self._ui.ButtonExploreSpeedUp:SetActive(true)
    self._ui.ButtonExplore:SetActive(false)
    self._ui.ExploreBusAnimator:Play("BusOut", 0, 0)
end

function ArenaCtrl:OnActivityExploreSpeedUp(themeId, endTime)
    self._exploringThemeId = themeId
    self._exploringEndTime = endTime
end

function ArenaCtrl:OnActivityExploreSettle()
    self._exploringThemeId = nil
    self._exploringEndTime = nil

    self._ui.ButtonExploreSpeedUp:SetActive(false)
    self._ui.ButtonExplore:SetActive(true)
    local showBus = self:HasActivityThemeCanExplore()
    self._ui.ExploreBus:SetActive(showBus)
    if showBus then
        self._ui.ExploreBusAnimator:Play("BusIn", 0, 0)
    end
end

function ArenaCtrl:HideDialogItem()
    self._ui.DialogItem.gameObject:SetActive(false)
end

function ArenaCtrl:CleanDialog()
    self._dialogList = {}
    self:HideDialogItem()
end

function ArenaCtrl:PeekFirstDialog()
    if #self._dialogList == 0 then
        return
    end

    self._ui.DialogTypeEffect:Finish()
    self._ui.DialogItem.gameObject:SetActive(true)
    self._ui.DialogLabel.text = self._dialogList[1].message
    local bgHeight = self._ui.DialogLabel.height + 30
    bgHeight = math.max(55, bgHeight)
    self._ui.DialogBG.height = bgHeight
    self._ui.DialogTypeEffect:ResetToBeginning()
end

function ArenaCtrl:OnCharacterNodeVisibleChanged(nodeName, visible)
    for idx = 1, self._ui.CharacterRoot.childCount do
        local groupRoot = self._ui.CharacterRoot:GetChild(idx - 1)
        local nodeItem = groupRoot:Find(nodeName)
        if nodeItem ~= nil then
            nodeItem.gameObject:SetActive(visible)
        end
    end
end

function ArenaCtrl:HasActivityThemeCanExplore()
    local currentTheme = GameData.GetCurrentActivityTheme()
    return currentTheme ~= nil and ConfigUtils.CanExploreInActivityTheme(currentTheme)
end
---------------------------------------------------------------------------------------

function ArenaCtrl:OnPressed(go, pressed, isLong)
    if pressed then
        if not self._isDraging then
            self._isDraging = true
            self._dragSpeed = 0
            self._mouseWorldPosition = self:ScreenToWorld(Input.mousePosition)
        end
    elseif not pressed and self._isDraging then
        self._isDraging = false
        if self:IsSceneInRange() and math.abs(self._lastDiffX) > MOVE_LIMIT then
            self._dragSpeed = Helper.GetSign(self._lastDiffX) * DRAG_SPEED
        end
    end
end

function ArenaCtrl:GotoExplore(themeId)
    local exploreId = ConfigUtils.GetActivityThemeExplore(themeId)
    CtrlManager.OpenPanel(CtrlNames.ExploreCharacter, {themeId = themeId, exploreId = exploreId})
end

-- on clicked
function ArenaCtrl:OnClicked(go)
    if go == self._ui.ButtonClose then
        SoundSystem.PlayUICancelSound()
        self:Close()
        CtrlManager.OpenPanel(CtrlNames.Home)
    elseif go == self._ui.Blocker then
        local pos = self:ScreenToWorld(Input.mousePosition)
        local hitResult = UnityEngine.Physics2D.Raycast(pos, Vector3.forward)
        if hitResult.collider ~= nil and hitResult.collider.transform.parent ~= nil and hitResult.collider.transform.parent.parent ~= nil then
            local parentName = hitResult.collider.transform.parent.parent.gameObject.name
            if parentName == "Character" then
                local node = hitResult.collider.transform
                self:OnCharacterNodeClicked(node)
            end
        end
    elseif go == self._ui.pBtnMarket then
        SoundSystem.PlayUIClickSound()
        local arenaUnlocked = GameData.IsModuleUnlocked(ModuleNames.Arena)
        if arenaUnlocked then
            CtrlManager.OpenPanel(CtrlNames.ArenaMarket)
        end
    elseif go == self._ui.ButtonArena then
        local unlocked = GameData.IsModuleUnlocked(ModuleNames.Arena)
        if unlocked then
            local arenaConfigId, _, arenaEndTime = GameData.GetActivatedArenaConfigId()
            if arenaConfigId ~= nil then
                SoundSystem.PlayUIClickSound()
                CtrlManager.OpenPanel(CtrlNames.ArenaEnemy)
            else
                SoundSystem.PlayWarningSound()
                CtrlManager.ShowMessageBox({message = SAFE_LOC("当前没有流亡街挑战!"), single = true})
            end

            if self._activeArenaConfigId ~= arenaConfigId then
                self._activeArenaConfigId = arenaConfigId
                self._activeArenaEndTime = arenaEndTime
            end
        else
            SoundSystem.PlayWarningSound()
            CtrlManager.ShowMessageBox({message = SAFE_LOC("loc_unlockmodule_arena_hint_001"), single = true})
        end
    elseif go == self._ui.ButtonActivity then
        local unlocked = GameData.IsModuleUnlocked(ModuleNames.Activity)
        if unlocked then
            SoundSystem.PlayUIClickSound()
            CtrlManager.OpenPanel(CtrlNames.Activity)
        end
    elseif go == self._ui.ButtonExplore then
        local unlocked = GameData.IsModuleUnlocked(ModuleNames.Activity)
        if unlocked then
            local exploringTheme = GameData.GetUnsettledActivityTheme()
            if exploringTheme == nil and self:HasActivityThemeCanExplore() then
                SoundSystem.PlayUIClickSound()
                local currentTheme = GameData.GetCurrentActivityTheme()
                CtrlManager.DoWaitTransition(CtrlNames.ExploreCharacter, self, ArenaCtrl.GotoExplore, currentTheme)
            end
        end
    elseif go == self._ui.ButtonCatchFish then
        SoundSystem.PlayUIClickSound()
        CtrlManager.OpenPanel(CtrlNames.CatchFish)
    elseif go == self._ui.ButtonExploreSpeedUp then
        local unlocked = GameData.IsModuleUnlocked(ModuleNames.Activity)
        if unlocked then
            local exploringTheme = GameData.GetUnsettledActivityTheme()
            if exploringTheme ~= nil then
                local leftTime = GameData.GetActivityExploreLeftTime(exploringTheme)
                if leftTime > 0 then
                    CtrlManager.OpenPanel(CtrlNames.ExploreSpeedUp, {themeId = exploringTheme})
                else
                    CtrlManager.OpenPanel(CtrlNames.ExploreResult, {themeId = exploringTheme})
                end
            end
        end
    elseif go == self._ui.ButtonClothesShop then
        SoundSystem.PlayUIClickSound()
        CtrlManager.OpenPanel(CtrlNames.ClothesShop)
   elseif go == self._ui.btnActivityDailyReward then
        SoundSystem.PlayUIClickSound()
        CtrlManager.OpenPanel(CtrlNames.ActivitySignInReward)
    elseif go == self._ui.btnActivityPassport then
        SoundSystem.PlayUIClickSound()
        CtrlManager.OpenPanel(CtrlNames.ActivityBuyPassport)
    elseif go.transform.parent == self._ui.HideSeekColliderRoot then
        local rabbitId = tonumber(go.name)
        if GameDataHideSeek.IsValidHideSeekRabbit(rabbitId) then
            local rabbitId = tonumber(go.name)
            self._CurRabbitId = rabbitId
            local speechId = GameDataHideSeek.GetCurHideSeekStorySpeechId()
            if speechId then
                CtrlManager.LaunchPanel(CtrlNames.GoalDialog, {goalSpeechList = {speechId}, callback = ArenaCtrl.OnDialogFinish, reciver = self})
            else
                self:OnDialogFinish()
            end
        end
    elseif go == self._ui.m_pAppCenterBtn then
        SoundSystem.PlayUIClickSound()
        CtrlManager.OpenPanel(CtrlNames.ApplicationCenter)
    elseif go == self._ui.m_pPlanetBtn then
        SoundSystem.PlayUIClickSound()
        CtrlManager.PopPanel()
        CtrlManager.OpenPanel(CtrlNames.Planet)
    elseif go == self._ui.pBtnHome then
        SoundSystem.PlayUIClickSound()
        CtrlManager.PopPanel()
    elseif go == self._ui.pBtnWorkShop then
        SoundSystem.PlayUIClickSound()
        --CtrlManager.PopPanel()
        CtrlManager.OpenPanel(CtrlNames.WorkShop)
    elseif go == self._ui.pBtnSummon then
        SoundSystem.PlayUIClickSound()
        --CtrlManager.PopPanel()
        CtrlManager.OpenPanel(CtrlNames.Summon)
    elseif go == self._ui.m_pTouristBtn then
        local hasTourist = GameData.HasValidTourist()
        if hasTourist then
            SoundSystem.PlayUIClickSound()
            local ctrlName = CtrlNames.Tourist
            CtrlManager.DoWaitTransition(ctrlName, self, ArenaCtrl.CloseToTarget, {ctrlName = ctrlName})
        end
    end

	return true
end

function ArenaCtrl:OnHandleProto(proto, data, requestData)
    if proto == "HideSeekFind" then
        local goldNum = data.RemainGold
        local diamondNum = data.RemainDiamond
        local rabbitId = data.RabbitId
        NavigationCtrl.EnableSuspend(true)
        GameData.SetHideSeekRabbitData(rabbitId)

        local selfReward = GameDataHideSeek.GetHideSeekObjectRewardList(rabbitId)
        -- 阶段奖励
        local isUnlock, stageReward = GameDataHideSeek.IsUnlockHideSeekRewardList(GameData.GetTotalHideSeekFindCount())
        local totalReward = {}
        for idx = 1, #selfReward do
            local id = selfReward[idx].Id
            local num = selfReward[idx].Num
            totalReward[id] = totalReward[id] or 0
            totalReward[id] = totalReward[id] + num
        end

        if isUnlock then
            for idx = 1, #stageReward do
                local id = stageReward[idx].Id
                local num = stageReward[idx].Num
                totalReward[id] = totalReward[id] or 0
                totalReward[id] = totalReward[id] + num
            end
        end
        XDebug.LogTable("LZ", "totalReward:", totalReward)
        for id, num in pairs(totalReward) do
            GameData.CollectItem(id, num, false)
        end

        GameData.SetMoney(ItemType.Gold, goldNum)
        GameData.SetMoney(ItemType.Diamond, diamondNum)
        GameData.CheckAndHintGoalsOfCurrentCountType()


        CtrlManager.OpenPanel(CtrlNames.HideSeekReward, { RabbitId = rabbitId, Reward = totalReward })
    end
end

function ArenaCtrl:OnDialogFinish()
    NetManager.Send("HideSeekFind", { RabbitId = self._CurRabbitId }, ArenaCtrl.OnHandleProto, self)
end

function ArenaCtrl:RefreshWorkShopHint()
    local m_bIsUnlocked = GameData.IsModuleUnlocked(ModuleNames.Summon)
    local m_bIsShowHint = GameData.HasEventPool()
end

function ArenaCtrl:RefreshSummonHint()
    local m_bIsUnlocked = GameData.IsModuleUnlocked(ModuleNames.WorkShop)
    local m_bIsShowHint = GameData.HasCompletedWorkShop()

end

function ArenaCtrl:OnSummonPoolChanged()
    self:RefreshSummonHint()
end

function ArenaCtrl:RefreshHideSeekEntrance()
    local isUnlock = GameDataHideSeek.IsUnlockHideSeekActivity()
    if isUnlock then
        self.HideSeekEntranceLayout:Show()
        CtrlManager.LaunchPanel(CtrlNames.HideSeek)
    else
        self.HideSeekEntranceLayout:Hide()
        CtrlManager.ClosePanel(CtrlNames.HideSeek)
    end
end

function ArenaCtrl:OnTouristChanged()
    self:CheckTourist()
end

function ArenaCtrl:CheckTourist()
    local unlocked  = GameData.IsModuleUnlocked(ModuleNames.Tourist)
    local preShow = self._ui.m_pTouristBtn.activeSelf
    self._ui.m_pTouristBtn:SetActive(unlocked)
    if unlocked and not preShow then
        self._ui.TouristAnimator:Play("In", 0, 0)
    end
end

function ArenaCtrl:CloseToTarget(params)
    CtrlManager.OpenPanel(params.ctrlName)
end

function ArenaCtrl:RefreshComment()

end