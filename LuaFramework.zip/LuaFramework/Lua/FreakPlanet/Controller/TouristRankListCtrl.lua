require "FreakPlanet/View/TouristRankListPanel"

local class = require "FreakPlanet/Utils/middleclass"
TouristRankListCtrl  = class(CtrlNames.TouristRankList, BaseCtrl)

-- load the ui prefab
function TouristRankListCtrl:LoadPanel()
	self:CreatePanel("TouristRankList")
end

-- construct ui panel data
function TouristRankListCtrl:ConstructUI(obj)
	self._ui = TouristRankListPanel.Init(obj)
end

-- fill ui with the data
function TouristRankListCtrl:SetupUI()
    local touristId = self._parameter.touristId
	NetManager.Send("ZooRankList", {TouristID = touristId}, TouristRankListCtrl.OnHandleProto, self)

    CtrlManager.AddClick(self, self._ui.Blocker)
end

function TouristRankListCtrl:SetupRankGrid(rankList)
    rankList = rankList or {}
    for idx = 1, #rankList do
        local itemObj = Helper.NewObject(self._ui.RankItemTemplate, self._ui.RankGrid)
        itemObj.name = tostring(idx)
        itemObj:SetActive(true)
        -- construct item
        self:ConstructRankItem(itemObj.transform, rankList[idx], idx)
    end

    self._ui.RankGrid:GetComponent("UIGrid"):Reposition()
end

function TouristRankListCtrl:ConstructRankItem(item, data, rank)
    local touristId = self._parameter.touristId
    local userName = data.Nickname
    if data.Userid == GameData.GetDefaultAccountUserId() then
        userName = GameData.GetDefaultNickName(true)
    end
    local rankTime = data.RankTime
    local commentName, commentInfo, commentDesc, commentIcon, commentAtlas, commentBundle = ConfigUtils.GetTouristComment(touristId, rank, data.Score)
    -- comment name
    local commentNameLabel = item:Find("CommentName"):GetComponent("UILabel")
    commentNameLabel.text = SAFE_LOC(commentName)
    -- comment info
    local commentInfoLabel = item:Find("CommentInfo"):GetComponent("UILabel")
    commentInfoLabel.text = SAFE_LOC(commentInfo)
    -- comment desc
    local commentDescLabel = item:Find("Comment"):GetComponent("UILabel")
    commentDescLabel.text = "[987A62FF]"..SAFE_LOC(commentDesc).."[-]  [DB4114FF]@"..tostring(userName).."[-]"
    -- comment time
    local commentTimeLabel = item:Find("CommentTime"):GetComponent("UILabel")
    rankTime = rankTime - GameData.GetTimeZoneOffset()
    commentTimeLabel.text = os.date("%Y-%m-%d", rankTime)
    -- comment icon
    local commentIconSprite = item:Find("CommentIcon"):GetComponent("UISprite")
    self:SetIconWithAtlas(commentIconSprite, commentIcon, commentAtlas)
    -- socre
    local scoreLabel = item:Find("Score"):GetComponent("UILabel")
    scoreLabel.text = tostring(data.Score)
    -- pet list
    local petList = data.PetList
    local petRoot = item:Find("PetTable")
    for idx = 1, petRoot.childCount do
        local hasPet = (idx <= #petList)
        local petItem = petRoot:GetChild(idx - 1)
        petItem.gameObject:SetActive(hasPet)
        if hasPet then
            CtrlManager.AddClick(self, petItem.gameObject)
            local petId = petList[idx][1]
            local petNum = petList[idx][2]
            petItem.gameObject.name = "Pet_"..tostring(petId)
            UIHelper.ConstructTouristRankPetItem(self, petItem, petId, petNum)
        end
    end
    petRoot:GetComponent("UITable"):Reposition()
end

-- on clicked
function TouristRankListCtrl:OnClicked(go)

    if go == self._ui.Blocker then
        SoundSystem.PlayUICancelSound()
        CtrlManager.PopPanel()
    elseif Helper.StartWith(go.name, "Pet_") then
        local names = Helper.StringSplit(go.name)
        assert(#names == 2, "invalid pet item name: "..go.name)
        local petId = tonumber(names[2])
        CtrlManager.ShowItemDetail({itemId = petId})
    end

	return true
end

function TouristRankListCtrl:OnHandleProto(proto, data, requestData)
    if proto == "ZooRankList" then
        self:SetupRankGrid(data.RankList)
    end
end