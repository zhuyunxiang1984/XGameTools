require "FreakPlanet/View/ExploreItemPanel"

local utf8 = require "FreakPlanet/Utils/Utf8"
local class = require "FreakPlanet/Utils/middleclass"
ExploreItemCtrl  = class(CtrlNames.ExploreItem, BaseCtrl)

local MIN_SHOW_ITEM_NUM = 15

local _goalMatchFunc = nil
local _goalExtraParam = nil
local _filterSkills = nil

ExploreItemSortMode = {
	Food = "Food",
	Catch = "Catch",
	Event = "Event",
}

----------------------------------------------------------------------
local function GoodsSortFunc(idA, idB)
	if idA == nil or idB == nil then
		return false
	end

	local matchA = _goalMatchFunc(idA, _goalExtraParam)
	local matchB = _goalMatchFunc(idB, _goalExtraParam)
	if matchA ~= matchB then
		return matchA
	end

	local markedA = GameData.IsItemMarked(idA)
	local markedB = GameData.IsItemMarked(idB)
	if markedA ~= markedB then
		return markedA
	end

	local valueA = ConfigUtils.GetGoodsStorageSortId(idA)
	local valueB = ConfigUtils.GetGoodsStorageSortId(idB)
	if valueA ~= valueB then
		return valueA < valueB
	end

	valueA = ConfigUtils.GetGoodsSortId(idA)
	valueB = ConfigUtils.GetGoodsSortId(idB)

	return valueA > valueB
end
----------------------------------------------------------------------
-- load the ui prefab
function ExploreItemCtrl:LoadPanel()
	self:CreatePanel("ExploreItem")
end

-- construct ui panel data
function ExploreItemCtrl:ConstructUI(obj)
	self._ui = ExploreItemPanel.Init(obj)
end

-- destroy implementation
function ExploreItemCtrl:DestroyImpl()
	self:RecordExploreItems(self._selectedItems)
	GameNotifier.RemoveListener(GameEvent.ItemNumChanged, ExploreItemCtrl.OnItemNumChanged, self)
	GameNotifier.RemoveListener(GameEvent.MarkStateChanged, ExploreItemCtrl.OnMarkStateChanged, self)
end

-- fill ui with the data
function ExploreItemCtrl:SetupUI()
	self._areaId = self._parameter.areaId                          -- 区域探索
	self._activityThemeId = self._parameter.themeId                -- 活动探索
	self._characterList = self._parameter.characters
	self._petId = self._parameter.petId
	self._globalBuffs = self._parameter.globalBuffs or {}
	self._goodsItemPrefab = self:LoadAsset("GoodsItem")
	self._petInited = false

	_goalExtraParam = nil
	if self._areaId ~= nil then
		_goalMatchFunc = JumpManager.MatchExploreCostGoal
		_goalExtraParam = self._areaId
	elseif self._activityThemeId ~= nil then
		_goalMatchFunc = JumpManager.MatchActivityExploreCostGoal
	end
	
	self._itemNumLimit = 0
	for idx = 1, #self._characterList do
		local characterId = self._characterList[idx]
		local stage = GameData.GetCharacterCurrentStage(characterId)
		self._itemNumLimit = self._itemNumLimit + stage
	end

	local showNum = math.max(self._itemNumLimit, MIN_SHOW_ITEM_NUM)
	self._selectedItems, self._selectedItemNumMap = self:GetSelectedExploreItems(showNum,self._itemNumLimit)

	for idx = 1, showNum do
		local itemObj = Helper.NewObject(self._ui.SelectedItemTemplate, self._ui.SelectedItemGrid)
		itemObj.name = tostring(idx)
		itemObj:SetActive(true)
		-- add click event
		CtrlManager.AddClick(self, itemObj)

		self:ConstructSelectedItem(itemObj.transform, idx)
	end

	local uiGrid = self._ui.SelectedItemGrid:GetComponent("UIGrid")
	uiGrid:Reposition()

	self._currentMode = ExploreItemSortMode.Food
	self:OnItemSortModeChanged()
	self:OnSelectedItemChanged(false)
	-- dialogs
	self:InitExploreDialogs()
	-- hide default
	self._ui.PetPanel:SetActive(false)
	for k, v in pairs(self._ui.DialogItems) do
		v.item:SetActive(false)
	end

	CtrlManager.AddClick(self, self._ui.ButtonGo)
	CtrlManager.AddClick(self, self._ui.ButtonPetHint)
	CtrlManager.AddClick(self, self._ui.ButtonFilter)
	CtrlManager.AddClick(self, self._ui.ButtonClose)
	CtrlManager.AddClick(self, self._ui.PetPanelBlocker)
	CtrlManager.AddClick(self, self._ui.ButtonFoodItem.gameObject)
	CtrlManager.AddClick(self, self._ui.ButtonCatchItem.gameObject)
	CtrlManager.AddClick(self, self._ui.ButtonEventItem.gameObject)
	CtrlManager.AddClick(self, self._ui.ButtonReset)
	GameNotifier.AddListener(GameEvent.ItemNumChanged, ExploreItemCtrl.OnItemNumChanged, self)
	GameNotifier.AddListener(GameEvent.MarkStateChanged, ExploreItemCtrl.OnMarkStateChanged, self)

	if self._areaId ~= nil then
		self:CheckTutorial()
	end
end

function ExploreItemCtrl:InitExploreDialogs()
	self._dialogList = {}
	local dialogs = ConfigUtils.GetExploreDialogList()
	for idx = 1, #dialogs do
		local dialogId = dialogs[idx]
		if self:IsDialogMatch(dialogId) then
			table.insert(self._dialogList, dialogId)
		end
	end

	self._nextDialogTime = self:GenerateNextDialogTime()
	self._dialogState = nil
	self:GenerateWorkDialogList()
end

function ExploreItemCtrl:GenerateWorkDialogList()
	self._workDialogList = {}
	Helper.CopyTable(self._workDialogList, self._dialogList)
end

function ExploreItemCtrl:IsDialogMatch(dialogId)
	local conditions = ConfigUtils.GetExploreDialogConditions(dialogId)
	if conditions == nil then
		return true
	end

	for idx = 1, #conditions do
		local matched = false
		local condition = conditions[idx]
		local conditionType = condition.Condition
		local conditionValue = condition.Value
		if conditionType == "CompleteGoal" then
			matched = self:IsCompleteGoalConditionMatch(conditionValue)
		elseif conditionType == "UncompleteGoal" then
			matched = self:IsUncompleteGoalConditionMatch(conditionValue)
		elseif conditionType == "ExploreBagNum" then
			matched = self:IsExploreBagNumConditionMatch(conditionValue)
		elseif conditionType == "StorgeGoodsTag" then
			matched = self:IsGoodsTagConditionMatch(conditionValue)
		elseif conditionType == "AreaId" then
			matched = self:IsAreaConditionMatch(conditionValue)
		else
			assert(false, "un-handled dialog condition type: "..tostring(conditionType))
		end

		if not matched then
			return false
		end
	end

	return true
end

function ExploreItemCtrl:IsCompleteGoalConditionMatch(values)
	if values == nil then
		return true
	end

	for k, v in pairs(values) do
		if not GameData.IsGoalFinished(v) then
			return false
		end
	end

	return true
end

function ExploreItemCtrl:IsUncompleteGoalConditionMatch(values)
	if values == nil then
		return true
	end

	for k, v in pairs(values) do
		if GameData.IsGoalFinished(v) then
			return false
		end
	end

	return true
end

function ExploreItemCtrl:IsExploreBagNumConditionMatch(values)
	if values == nil or #values == 0 then
		return true
	end

	if #values == 1 then
		return self._itemNumLimit >= values[1]
	else
		return self._itemNumLimit >= values[1] and self._itemNumLimit <= values[2]
	end
end

function ExploreItemCtrl:IsGoodsTagConditionMatch(values)
	if values == nil or #values == 0 then
		return true
	end

	local goodsList = GameData.GetUnlockedGoods()
	for idx = 1, #goodsList do
		local goodsId = goodsList[idx]
		if ConfigUtils.IsItemMatchTagList(goodsId, values) then
			local goodsNum = GameData.GetGoodsNum(goodsId)
			if goodsNum > 0 then
				return true
			end
		end
	end

	return false
end

function ExploreItemCtrl:IsAreaConditionMatch(values)
	if not ConfigUtils.IsValidItem(self._areaId) then
		return false
	end

	if values == nil or #values == 0 then
		return true
	end

	return Helper.TableContains(values, self._areaId)
end

-- update implementation
function ExploreItemCtrl:UpdateImpl(deltaTime)
	if #self._dialogList > 0 then
		if self._dialogState ~= nil then
	        local finished = self._dialogState:Tick(deltaTime)
	        if finished then
	            self._dialogState = nil
	            self._nextDialogTime = self:GenerateNextDialogTime()
	        end
	    else
	        self._nextDialogTime = self._nextDialogTime - deltaTime
	        if self._nextDialogTime <= 0 then
	            self._dialogState = self:GenerateDialogState()
	        end
	    end
	end
end

function ExploreItemCtrl:GenerateNextDialogTime()
	return Helper.RandFloat(ExploreDialogTime[1], ExploreDialogTime[2])
end

function ExploreItemCtrl:GenerateDialogState()
	if #self._workDialogList == 0 then
		self:GenerateWorkDialogList()
	end
	local selectedIdx = Helper.RandInt(1, #self._workDialogList)
	local headDialogId = self._workDialogList[selectedIdx]
	table.remove(self._workDialogList, selectedIdx)
	local dialogChainList = ConfigUtils.GetChainListOfExploreDialog(headDialogId)

	local state = SequenceState:new()
	for idx = 1, #dialogChainList do
		local dialogId = dialogChainList[idx]
		local position, text = ConfigUtils.GetExploreDialogInfo(dialogId)
		local dialogItem = self._ui.DialogItems[position].item
		local dialogLabel = self._ui.DialogItems[position].label
		local dialogTypewriter = self._ui.DialogItems[position].typewriter
		local duration = utf8.len(text) / dialogTypewriter.charsPerSecond + 1
		local showState = TimerState:new(duration)
		showState:ActionOnEnter(ExploreItemCtrl.ShowDialog, self, {item = dialogItem, label = dialogLabel, typewriter = dialogTypewriter, text = text})
		showState:ActionOnExit(ExploreItemCtrl.HideDialog, self, dialogItem)
		state:Push(showState)
	end

	return state
end

function ExploreItemCtrl:ShowDialog(params)
	params.item:SetActive(true)
	params.typewriter:Finish()
	params.label.text = params.text
	params.typewriter:ResetToBeginning()
end

function ExploreItemCtrl:HideDialog(item)
	item:SetActive(false)
end

function ExploreItemCtrl:OnItemSortModeChanged()
	-- reset filter skills when mode changed
	_filterSkills = nil

	self:SetupGoodsGrid()

	self._ui.ButtonFoodItem.isEnabled = (self._currentMode ~= ExploreItemSortMode.Food)
	self._ui.ButtonCatchItem.isEnabled = (self._currentMode ~= ExploreItemSortMode.Catch)
	self._ui.ButtonEventItem.isEnabled = (self._currentMode ~= ExploreItemSortMode.Event)

	self._ui.ButtonFilter:SetActive(self._currentMode == ExploreItemSortMode.Event)
end

function ExploreItemCtrl:GetItemListOfCurrentMode()
	if self._currentMode == ExploreItemSortMode.Food then
		return GameData.GetUnlockedGoodsOfType(GoodsSubType.Food)
	elseif self._currentMode == ExploreItemSortMode.Catch then
		return GameData.GetUnlockedGoodsOfType(GoodsSubType.CatchItem)
	elseif self._currentMode == ExploreItemSortMode.Event then
		return GameData.GetUnlockedGoodsOfType(GoodsSubType.EventItem)
	else
		assert(false, "un-handled sort mode: "..tostring(self._currentMode))
	end

	return {}
end

function ExploreItemCtrl:SetupGoodsGrid()
	-- recycle
	local childNum = self._ui.ItemGrid.childCount
	for idx = childNum, 1, -1 do
		local item = self._ui.ItemGrid:GetChild(idx - 1)
		item.parent = self._ui.ItemPool
	end

	local itemList = self:GetItemListOfCurrentMode()
	self._itemList = ExploreItemCtrl.DoItemFilter(itemList)

	table.sort(self._itemList, GoodsSortFunc)

	for idx = 1, #self._itemList do
		local itemId = self._itemList[idx]

		local item = nil
		if self._ui.ItemPool.childCount == 0 then
			local itemObj = Helper.NewObject(self._goodsItemPrefab, self._ui.ItemGrid)

			CtrlManager.AddClick(self, itemObj)
			CtrlManager.AddPress(self, itemObj)

			item = itemObj.transform
		else
			item = self._ui.ItemPool:GetChild(0)
			item.parent = self._ui.ItemGrid
			item.localPosition = Vector3.zero
			item.localScale = Vector3.one
		end

		item.gameObject:SetActive(true)
		item.gameObject.name = tostring(itemId)

		self:ConstructGridItem(item, itemId)			
	end

	self._ui.ItemGrid:GetComponent('UIGrid'):Reposition()
	self._ui.ItemScrollView.restrictWithinPanel = true
	self._ui.ItemScrollView:ResetPosition()
end

function ExploreItemCtrl:GetFirstAvailableIndex()
	for idx = 1, self._itemNumLimit do
		if self._selectedItems[idx] == INVALID_ID then
			return idx
		end
	end

	-- no available index
	return nil
end

function ExploreItemCtrl:IsItemSelected(itemId)
	local num = self._selectedItemNumMap[itemId] or 0
	return num > 0
end

function ExploreItemCtrl:ConstructGridItem(item, itemId)
	local subType = ConfigUtils.GetGoodsSubType(itemId)
	if item == nil then
		item = self._ui.ItemGrid:Find(tostring(itemId))
	end
	UIHelper.ConstructGoodsItem(self, item, itemId, false)
	-- goal
    local matchGoal = _goalMatchFunc(itemId, _goalExtraParam)
    local goalMark = item:Find("Mark/Goal").gameObject
    goalMark:SetActive(matchGoal)
	-- selected state
	self:RefreshGridItemSelectedState(item, itemId)
	-- number
	local numLabel = item:Find("Num"):GetComponent("UILabel")
	local ownNum = GameData.GetItemNum(itemId)
	if subType == GoodsSubType.EventItem then
		numLabel.text = SAFE_LOC("loc_setsupply_eventitem_is_free")
	else
		local selectedNum = self._selectedItemNumMap[itemId] or 0
		if selectedNum > 0 then
			numLabel.text = tostring(selectedNum).."/"..tostring(ownNum)
		else
			numLabel.text = tostring(ownNum)
		end
	end
	-- status mark
	local statusMark = item:Find("Mark/Status").gameObject
	statusMark:SetActive(ownNum == 0)
	if ownNum == 0 then
		local statusLabel = item:Find("Mark/Status/Label"):GetComponent("UILabel")
		if subType == GoodsSubType.EventItem then
			statusLabel.text = SAFE_LOC("loc_setsupply_eventitem_is_occupy")
		else
			statusLabel.text = SAFE_LOC("loc_setsupply_item_is_empty")
		end
	end
	-- marked
    local marked = GameData.IsItemMarked(itemId)
    local markedMark = item:Find("Mark/Marked").gameObject
    markedMark:SetActive(marked)
end

function ExploreItemCtrl:ConstructSelectedItem(item, idx)
	if item == nil then
		item = self._ui.SelectedItemGrid:Find(tostring(idx))
	end

	local showRoot = (idx <= self._itemNumLimit)
	local itemRoot = item:Find("Root")
	itemRoot.gameObject:SetActive(showRoot)
	if showRoot then
		local itemId = self._selectedItems[idx]
		local isValid = (itemId ~= INVALID_ID)
		local iconSprite = item:Find("Root/Icon"):GetComponent("UISprite")
		iconSprite.gameObject:SetActive(isValid)

		if isValid then
			UIHelper.SetItemIcon(self,iconSprite, itemId)
		end
	end
end

function ExploreItemCtrl:RefreshGridItemSelectedState(item, itemId)
	local selected = self:IsItemSelected(itemId)
	local selectedMark = item:Find("Mark/Select").gameObject
	selectedMark:SetActive(selected)
end

function ExploreItemCtrl:OnSelectedItemChanged(showHint)
	local exploreTimeSkills = GameData.GetGroupSkillMap(
		self._characterList, 
		self._petId, 
		{
			effectAttribute = EffectAttribute.ExploreTime,
			globalSkills = self._globalBuffs,
		}
	)

	local baseTime = 0
	for k, v in pairs(self._selectedItemNumMap) do
		if v > 0 then
			-- base time
			baseTime = baseTime + ConfigUtils.GetGoodsAddExploreTime(k) * v
			-- skill time
			local goodsSkills = ConfigUtils.GetGoodsSkillList(k)
			for idx = 1, #goodsSkills do
				local skillId = goodsSkills[idx].id
				local skillValue = goodsSkills[idx].value
				local effectAttribute = ConfigUtils.GetSkillEffectAttribute(skillId)
				if effectAttribute == EffectAttribute.ExploreTime then
					if exploreTimeSkills[k] == nil then
						exploreTimeSkills[k] = {}
					end

					table.insert(exploreTimeSkills[k], {id = skillId, value = skillValue * v})
				end
			end
		end
	end

	local addValue, addPercent = GameData.GetSkillTotalValue(exploreTimeSkills)
	addPercent = Helper.Round(addPercent, 2)
	
	local finalTime = Helper.RoundAndCeil((baseTime + addValue) * (1 + addPercent))
	finalTime = math.max(finalTime, 0)
	self._ui.InfoTime.text = self:GetFormatedTimeString("loc_global_exploretime_original", baseTime)
	if baseTime == finalTime then
		self._ui.InfoSkillTime.text = ""
	elseif baseTime > finalTime then
		local diff = (baseTime - finalTime)
		self._ui.InfoSkillTime.text = self:GetFormatedTimeString("loc_global_exploretime_skillReduce", diff)
	else
		local diff = (finalTime - baseTime)
		self._ui.InfoSkillTime.text = self:GetFormatedTimeString("loc_global_exploretime_skillIncrease", diff)
	end

	if showHint then
		self._ui.InfoAnimator:Play("TimeHint", 0, 0)
	end
end

function ExploreItemCtrl:SetupPetItems()
	if self._petInited then
		return
	end

	local petList = self._parameter.petList or {}
	for idx = 1, #petList do
		local petId = petList[idx]
		local petItemObj = Helper.NewObject(self._ui.PetItemTemplate, self._ui.PetItemRoot)
		petItemObj:SetActive(true)
		petItemObj.name = tostring(petId)

		local petItem = petItemObj.transform
		-- icon
		local icon = petItem:Find("Icon"):GetComponent("UISprite")
		UIHelper.SetCharacterIcon(self, icon, petId)
		if GameData.IsPetUnlocked(petId) then
			icon.color = Color.white
		else
			icon.color = LOCK_ICON_COLOR
		end
		-- element
		local elementIcon = petItem:Find("Element"):GetComponent("UISprite")
		elementIcon.spriteName = ConfigUtils.GetElementIconOfItem(petId, false)
		-- level
		local petNum = GameData.GetPetNum(petId)
		local petLevel, petCurrentLevelNum, petTotalLevelNum = ConfigUtils.GetPetLevelByNum(petId, petNum)

		local levelLabel = petItem:Find("Level"):GetComponent("UILabel")
    	local levelNumLabel = petItem:Find("LevelNum"):GetComponent("UILabel")
    	local progressBar = petItem:Find("Bar"):GetComponent("UISprite")
    	local catchNumLabel = petItem:Find("CatchNum"):GetComponent("UILabel")

	    local petPercent = 1
	    local petNumText = SAFE_LOC("loc_Max")
	    if petCurrentLevelNum ~= nil then
	        petNumText = tostring(petCurrentLevelNum).."/"..tostring(petTotalLevelNum)
	        petPercent = petCurrentLevelNum / petTotalLevelNum
	    end

	    levelLabel.text = string.format(SAFE_LOC('loc_SimpleLevel'), petLevel)
	    levelNumLabel.text = petNumText
	    progressBar.fillAmount = petPercent
    	catchNumLabel.text = tostring(petNum)

    	local catchItemList = ConfigUtils.GetPetCatchItemList(petId)
    	local catchItemRoot = petItem:Find("CatchItems")
    	for m = 1, catchItemRoot.childCount do
    		local hasCatchItem = (m <= #catchItemList)
    		local catchItem = catchItemRoot:GetChild(m - 1)
    		catchItem.gameObject:SetActive(hasCatchItem)
    		CtrlManager.AddClick(self, catchItem.gameObject)
    		if hasCatchItem then
				local catchItemId = catchItemList[m].Value
				catchItem.gameObject.name = tostring(catchItemId)
				-- icon
				local catchItemIcon = catchItem:GetComponent("UISprite")
				UIHelper.SetItemIcon(self,catchItemIcon, catchItemId)
				if GameData.IsGoodsUnlocked(catchItemId) then
					catchItemIcon.color = Color.white
				else
					catchItemIcon.color = LOCK_ICON_COLOR
				end
				-- chance
				local catchItemChanceLabel = catchItem:Find("Chance"):GetComponent("UILabel")
				catchItemChanceLabel.text = tostring(catchItemList[m].SuccessChance).."%"
    		end
    	end
	end

	-- pet empty hint
	self._ui.PetEmptyHint:SetActive(#petList == 0)

	self._ui.PetItemRoot:GetComponent("UITable"):Reposition()
	self._petInited = true
end

function ExploreItemCtrl:GetFormatedTimeString(loc, timeInSeconds)
	local text = SAFE_LOC(loc)
	local timeText = Helper.GetLongTimeString(timeInSeconds)
	text = Helper.StringFindAndReplace(text, "{Time}", timeText)
	return text
end

function ExploreItemCtrl:GetSelectedItems()
	local catchItemList = {}
	local foodList = {}

	for k, v in pairs(self._selectedItemNumMap) do
		if v > 0 then
			local subType = ConfigUtils.GetGoodsSubType(k)
			if subType == GoodsSubType.CatchItem or subType == GoodsSubType.EventItem then
				table.insert(catchItemList, {k, v})
			elseif subType == GoodsSubType.Food then
				table.insert(foodList, {k, v})
			else
				assert(false, "un-handled goods sub-type: "..tostring(subType))
			end
		end
	end

	if #catchItemList == 0 then
		catchItemList = nil
	end

	return catchItemList, foodList
end

function ExploreItemCtrl:OnExploreConfirm()
	local petId = self._petId
	if not ConfigUtils.IsValidItem(petId) then
		petId = INVALID_ID_0
	end

	local catchItemList, foodList = self:GetSelectedItems()
	if self._areaId ~= nil then
		NetManager.Send("Explore", {
			AreaId = self._areaId,
			CharList = self._characterList,
			PetId = petId,
			CatchItemList = catchItemList,
			FoodList = foodList,
			},
			ExploreItemCtrl.OnHandleProto, self
		)
	elseif self._activityThemeId ~= nil then
		local exploreId = ConfigUtils.GetActivityThemeExplore(self._activityThemeId)
		NetManager.Send("ActivityExplore", {
			ActivityThemeId = self._activityThemeId,
			ActivityExploreId = exploreId,
			CharList = self._characterList,
			PetId = petId,
			CatchItemList = catchItemList,
			FoodList = foodList,
			},
			ExploreItemCtrl.OnHandleProto, self
		)
	end
end

function ExploreItemCtrl:OnItemNumChanged(itemId, changeNum)
	if changeNum < 0 then
		local selectedNum = self._selectedItemNumMap[itemId] or 0
		local ownNum = GameData.GetItemNum(itemId)
		if selectedNum > ownNum then
			local numToRemove = (selectedNum - ownNum)
			for idx = #self._selectedItems, 1, -1 do
				if self._selectedItems[idx] == itemId then
					self._selectedItems[idx] = INVALID_ID
					self:ConstructSelectedItem(nil, idx)
					numToRemove = numToRemove - 1
					if numToRemove <= 0 then
						break
					end
				end
			end
			self._selectedItemNumMap[itemId] = ownNum
		end
	end

	local item = self._ui.ItemGrid:Find(itemId)
	if item ~= nil then
		self:ConstructGridItem(item, itemId)
	end
end

function ExploreItemCtrl:OnMarkStateChanged(itemId, marked)
	local itemType = ConfigUtils.GetItemTypeFromId(itemId)
	if itemType == ItemType.Goods then
		self:SetupGoodsGrid()
	end
end

-- handle the escapse button
function ExploreItemCtrl:HandleEscape()
	if self._ui.PetPanel.gameObject.activeSelf then
		self:OnClicked(self._ui.PetPanelBlocker)
	else
		self:OnClicked(self._ui.ButtonClose)
	end
end

-- on pressed
function ExploreItemCtrl:OnPressed(go, pressed, isLong)
	if pressed and isLong then
		if go.transform.parent == self._ui.ItemGrid then
			local itemId = tonumber(go.name)
			if self._currentMode == ExploreItemSortMode.Event then
				CtrlManager.ShowItemDetail({itemId = itemId, callback = ExploreItemCtrl.HandleSwitchItem, receiver = self})
			else
				CtrlManager.ShowItemDetail({itemId = itemId})
			end
		end
	end
end

function ExploreItemCtrl:HandleSwitchItem(itemId, isNext)
    local totalCount = #self._itemList
    local index = Helper.IndexOfArray(self._itemList, itemId)
    if isNext then
        index = index + 1
        if index > totalCount then
            index = 1
        end
    else
        index = index - 1
        if index < 1 then
            index = totalCount
        end
    end

    return self._itemList[index]
end

-- on clicked
function ExploreItemCtrl:OnClicked(go)

	if go == self._ui.ButtonClose then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
	elseif go == self._ui.ButtonFilter then
		SoundSystem.PlayUIClickSound()
		self:ShowFilterPanel()
	elseif go == self._ui.ButtonReset then
		SoundSystem.PlayUIClickSound()
		self:ResetSelectExploreItems()
	elseif go == self._ui.ButtonGo then
		local catchItemList, foodList = self:GetSelectedItems()
		if #foodList == 0 then
			SoundSystem.PlayWarningSound()
			CtrlManager.ShowMessageBox({message = SAFE_LOC("请选择探索食物"), single = true})
			return true
		end

		if self._activityThemeId ~= nil and not GameData.IsActivityThemeValid(self._activityThemeId) then
			SoundSystem.PlayWarningSound()
			CtrlManager.ShowMessageBox({message = SAFE_LOC("活动已结束"), single = true})
			return true
		end

		SoundSystem.PlayUIClickSound()
		self:OnExploreConfirm()
	elseif go.transform.parent == self._ui.SelectedItemGrid then
		local idx = tonumber(go.name)
		if idx > self._itemNumLimit then
			SoundSystem.PlayWarningSound()
			CtrlManager.ShowMessageBox({message = SAFE_LOC("loc_explore_package_lock_hint"), single = true})
			return true
		end

		local selecteItemId = self._selectedItems[idx]
		if selecteItemId ~= INVALID_ID then
			SoundSystem.PlayUIClickSound()
			self._selectedItems[idx] = INVALID_ID
			local preNum = self._selectedItemNumMap[selecteItemId] or 0
			assert(preNum > 0, "item is selected but number is not right: "..tostring(preNum))
			self._selectedItemNumMap[selecteItemId] = preNum - 1
			self:ConstructSelectedItem(go.transform, idx)
			local item = self._ui.ItemGrid:Find(selecteItemId)
			if item ~= nil then
				self:ConstructGridItem(item, selecteItemId)
			end
			self:OnSelectedItemChanged(true)
		else
			SoundSystem.PlayWarningSound()
		end
	elseif go.transform.parent == self._ui.ItemGrid then
		local idx = self:GetFirstAvailableIndex()
		if idx ~= nil then
			local itemId = tonumber(go.name)
			local preNum = self._selectedItemNumMap[itemId] or 0
			local ownNum = GameData.GetItemNum(itemId)
			if preNum < ownNum then
				SoundSystem.PlayUIClickSound()
				self._selectedItems[idx] = itemId
				self._selectedItemNumMap[itemId] = preNum + 1
				self:ConstructSelectedItem(nil, idx)
				self:ConstructGridItem(go.transform, itemId)
				self:OnSelectedItemChanged(true)
			else
				SoundSystem.PlayWarningSound()
				-- num not enough
			end
		else
			SoundSystem.PlayWarningSound()
		end
	elseif go == self._ui.ButtonFoodItem.gameObject then
		SoundSystem.PlaySwitchSound()
		self._currentMode = ExploreItemSortMode.Food
		self:OnItemSortModeChanged()
	elseif go == self._ui.ButtonEventItem.gameObject then
		SoundSystem.PlaySwitchSound()
		self._currentMode = ExploreItemSortMode.Event
		self:OnItemSortModeChanged()
	elseif go == self._ui.ButtonCatchItem.gameObject then
		SoundSystem.PlaySwitchSound()
		self._currentMode = ExploreItemSortMode.Catch
		self:OnItemSortModeChanged()
	elseif go == self._ui.ButtonPetHint then
		SoundSystem.PlayUIClickSound()
		self:SetupPetItems()
		self._ui.PetPanel:SetActive(true)
	elseif go == self._ui.PetPanelBlocker then
		SoundSystem.PlayUIClickSound()
		self._ui.PetPanel:SetActive(false)
	elseif go.transform.parent.gameObject.name == "CatchItems" then
		SoundSystem.PlayUIClickSound()
		local itemId = tonumber(go.name)
		CtrlManager.ShowItemDetail({itemId = itemId})
	end

	return true
end

--------------------------------------------------------
function ExploreItemCtrl:CloseToSpeedUp(params)
	local data = params.data
	local requestData = params.requestData
	local areaId = requestData.AreaId
	local themeId = requestData.ActivityThemeId

	if areaId ~= nil then
		CtrlManager.PopToPanel(CtrlNames.ExploreGuide)
	elseif themeId ~= nil then
		CtrlManager.PopToPanel(CtrlNames.Arena)
	end
	CtrlManager.OpenPanel(CtrlNames.ExploreSpeedUp, {areaId = areaId, themeId = themeId})

	-- catch item: consume first, if it is not corrupted after exploring, recycle it
	local catchItemList = requestData.CatchItemList or {}
	for idx = 1, #catchItemList do
		local itemId = catchItemList[idx][1]
		local itemNum = catchItemList[idx][2]

		GameData.ConsumeItem(itemId, itemNum)
	end
	-- food item: just consume
	local foodList = requestData.FoodList or {}
	for idx = 1, #foodList do
		local itemId = foodList[idx][1]
		local itemNum = foodList[idx][2]

		GameData.ConsumeItem(itemId, itemNum)
	end

	-- the food list: not pass from Explore proto, but pass from AreaList proto 
	data.FoodList = foodList
	if areaId ~= nil then
		GameData.StartExploreOfPlanetArea(areaId, data)
	elseif themeId ~= nil then
		GameData.StartActivityExplore(themeId, data)
	end
	GameData.Save()
	GameData.SyncTutorialData()
end

function ExploreItemCtrl:OnHandleProto(proto, data, requestData)
	if proto == "Explore" or proto == "ActivityExplore" then
		CtrlManager.DoWaitTransition(CtrlNames.ExploreSpeedUp, self, ExploreItemCtrl.CloseToSpeedUp, {data = data, requestData = requestData})

		if proto == "Explore" then
			--手动触发任务检测, 只为TriggerType.StartExplore服务
			GameData.TriggerStartExplore(requestData.AreaId)
			GameData.SyncTutorialData()
		end
	end
end
--------------------------------------------------------
function ExploreItemCtrl.DoItemFilter(itemList)
	local ret = {}

	for idx = 1, #itemList do
		local itemId = itemList[idx]
		local match = ExploreItemCtrl.IsItemMatchFilter(itemId, _filterSkills)
		if match then
			table.insert(ret, itemId)
		end
	end

	return ret
end

function ExploreItemCtrl.IsItemMatchFilter(goodsId, filterSkills)
	if filterSkills ~= nil then
		local hasMatched = false
		local skillList = ConfigUtils.GetGoodsSkillList(goodsId)
		for idx = 1, #skillList do
			local skillId = skillList[idx].id
			if ConfigUtils.IsSkillMatchFilterMap(filterSkills, skillId) then
				hasMatched = true
				break
			end
		end

		if not hasMatched then
			return false
		end
	end

	return true
end

function ExploreItemCtrl:ShowFilterPanel()
	local params = {
		filterSkills = nil,
		numCallback = ExploreItemCtrl.GetMatchNumByFilter,
		resultCallback = ExploreItemCtrl.OnGetFilterResult,
		receiver = self,
	}

	if _filterSkills ~= nil then
		params.filterSkills = Helper.CloneMap(_filterSkills)
	end

	CtrlManager.OpenPanel(CtrlNames.ExploreItemFilter, params)
end

function ExploreItemCtrl:GetMatchNumByFilter(data)
	local filterSkills = data.filterSkills

	local itemNum = 0
	local itemList = self:GetItemListOfCurrentMode()
	for idx = 1, #itemList do
		local itemId = itemList[idx]
		if ExploreItemCtrl.IsItemMatchFilter(itemId, filterSkills) then
			itemNum = itemNum + 1
		end
	end

	return itemNum
end

function ExploreItemCtrl:OnGetFilterResult(data)
	_filterSkills = nil

	if data.filterSkills ~= nil then
		_filterSkills = Helper.CloneMap(data.filterSkills)
	end
	
	self:SetupGoodsGrid()
end
--------------------------------------------------------
-- tutorial
function ExploreItemCtrl:GetTutorialGoodsItem()
	local item = self._ui.ItemGrid:Find(TutorialConstData.KouliangId)
	return item
end

function ExploreItemCtrl:CheckTutorial()
	local tutorials = {}

	if GameData.IsTutorialNotFinished(Tutorials.Tutorial_1_9) then
		local goodsItem = self:GetTutorialGoodsItem()
		local position = self._ui.Camera:WorldToScreenPoint(goodsItem.position)
		tutorials[1] = {event = Tutorials.Tutorial_1_8, position = position, sender = self}
		position = self._ui.Camera:WorldToScreenPoint(self._ui.InfoTutorialMark.position)
		tutorials[2] = {event = Tutorials.Tutorial_1_8_1, position = position, sender = self}
		position = self._ui.Camera:WorldToScreenPoint(self._ui.ButtonGo.transform:Find("TutorialMark").position)
		tutorials[3] = {event = Tutorials.Tutorial_1_9, position = position, sender = self}
	end

	if #tutorials > 0 then
		CtrlManager.ShowTutorials(tutorials)
	end

	return #tutorials > 0
end

function ExploreItemCtrl:OnTutorialClicked(tutorial)
	if tutorial == Tutorials.Tutorial_1_8 then
		local goodsItem = self:GetTutorialGoodsItem()
		self:OnClicked(goodsItem.gameObject)
	elseif tutorial == Tutorials.Tutorial_1_9 then
		self:OnClicked(self._ui.ButtonGo)
	else
		SoundSystem.PlayUIClickSound()
	end
end

function ExploreItemCtrl:GetSelectedExploreItems(showNum, numLimit)
	local itemList = {}
	local itemNumMap = {}
	for i = 1, showNum do
		local recordItemId = INVALID_ID
		if i <= numLimit then
			recordItemId = self:GetGameDataSelectedItems(i)
		end

		if ConfigUtils.IsValidItem(recordItemId) then
			local selectedNum = itemNumMap[recordItemId] or 0
			local ownNum = GameData.GetItemNum(recordItemId)
			if selectedNum >= ownNum then
				recordItemId = INVALID_ID
			end
		end

		if ConfigUtils.IsValidItem(recordItemId) then
			table.insert(itemList, recordItemId)
			local selectedNum = itemNumMap[recordItemId] or 0
			itemNumMap[recordItemId] = selectedNum + 1
		end
	end

	for i = #itemList + 1, showNum do
		table.insert(itemList, INVALID_ID)
	end

	return itemList, itemNumMap
end

function ExploreItemCtrl:RecordExploreItems(selectedItems)
	local t = {}
	for k,v in pairs(selectedItems) do
		if ConfigUtils.IsValidItem(v) then
			t[k] = v
		end
	end

	if self._areaId ~= nil then
		GameData.SetPlanetAreaExploreItems(self._areaId, t)
		GameData.Save()
	elseif self._activityThemeId ~= nil then
		GameData.SetPlanetAreaExploreItems(self._activityThemeId, t)
		GameData.Save()
	end
end

function ExploreItemCtrl:ResetSelectExploreItems()
	for i = 1, #self._selectedItems do
		local selectItemId = self._selectedItems[i]
		if ConfigUtils.IsValidItem(selectItemId) then
			self._selectedItems[i] = INVALID_ID
			self:ConstructSelectedItem(nil, i)
			self._selectedItemNumMap[selectItemId] = 0
			local item = self._ui.ItemGrid:Find(selectItemId)
			if item ~= nil then
				self:ConstructGridItem(item, selectItemId)
			end
		end
	end
	self:OnSelectedItemChanged(true)
end


function ExploreItemCtrl:GetGameDataSelectedItems(index)
	local selectedExploreItems = nil
	if self._areaId ~= nil then
		selectedExploreItems = GameData.GetPlanetAreaExploreItems(self._areaId)
	elseif self._activityThemeId ~= nil then
		selectedExploreItems = GameData.GetPlanetAreaExploreItems(self._activityThemeId)
	end

	if selectedExploreItems == nil then
		return INVALID_ID
	end

	local itemId = selectedExploreItems[index]
	if not ConfigUtils.IsValidItem(itemId) then
		return INVALID_ID
	end

	local unlocked = GameData.IsItemUnlocked(itemId)
	if not unlocked then
		return INVALID_ID
	end
	
	return itemId
end
--------------------------------------------------------
