require "FreakPlanet/View/MessageBoxPanel"

local class = require "FreakPlanet/Utils/middleclass"
MessageBoxCtrl  = class(CtrlNames.MessageBox, BaseCtrl)

-- load the ui prefab
function MessageBoxCtrl:LoadPanel()
	self:CreatePanel("MessageBox")
end

-- construct ui panel data
function MessageBoxCtrl:ConstructUI(obj)
	self._ui = MessageBoxPanel.Init(obj)
end

-- fill ui with the data
function MessageBoxCtrl:SetupUI()
	self._muteSound = self._parameter.muteSound or false
	self:ShowInternal()
	CtrlManager.AddClick(self, self._ui.SingleConfirmButton)
	CtrlManager.AddClick(self, self._ui.DoubleConfirmButton)
	CtrlManager.AddClick(self, self._ui.DoubleCancelButton)
end

function MessageBoxCtrl:Show(params)
	if self._ui == nil then
		return
	end
	
	self._parameter = params
	self:ShowInternal()
end

function MessageBoxCtrl:ShowInternal()
	self._ui.Panel:SetActive(true)

	self._ui.SingleRoot:SetActive(self._parameter.single)
	self._ui.DoubleRoot:SetActive(not self._parameter.single)
	self._ui.Message.text = self._parameter.message
end

-- on clicked
function MessageBoxCtrl:OnClicked(go)
	if go == self._ui.DoubleCancelButton then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
		self:Cancel()
	elseif go == self._ui.DoubleConfirmButton or 
		go == self._ui.SingleConfirmButton then
		if not self._muteSound then
			SoundSystem.PlayUIClickSound()
		end
		CtrlManager.PopPanel()
		self:Confirm()
	end

	return true
end

-- handle the escapse button
function MessageBoxCtrl:HandleEscape()
	if self._parameter.single then
		if self._parameter.onConfirm == nil then
			SoundSystem.PlayUICancelSound()
			CtrlManager.PopPanel()
		end
	else
		self:OnClicked(self._ui.DoubleCancelButton)
	end
end

-- can do jump or not
function MessageBoxCtrl:CanJump()
	-- if message box shows up, it means we have some message need you to confirm; force no jump
	return false
end


function MessageBoxCtrl:Cancel()
	if self._parameter.onCancel == nil then
		return
	end

	if self._parameter.receiver == nil then
		self._parameter.onCancel()
	else
		self._parameter.onCancel(self._parameter.receiver)
	end
end

function MessageBoxCtrl:Confirm()
	if self._parameter.onConfirm == nil then
		return
	end
	
	if self._parameter.receiver == nil then
		if self._parameter.data ~= nil then
			self._parameter.onConfirm(self._parameter.data)
		else
			self._parameter.onConfirm()
		end
	else
		if self._parameter.data ~= nil then
			self._parameter.onConfirm(self._parameter.receiver, self._parameter.data)
		else
			self._parameter.onConfirm(self._parameter.receiver)
		end
	end
end
