require "FreakPlanet/View/SpaceTravelRankPanel"

local class = require "FreakPlanet/Utils/middleclass"
SpaceTravelRankCtrl  = class(CtrlNames.SpaceTravelRank, BaseCtrl)

-- load the ui prefab
function SpaceTravelRankCtrl:LoadPanel()
	self:CreatePanel("SpaceTravelRank")
end

-- construct ui panel data
function SpaceTravelRankCtrl:ConstructUI(obj)
	self._ui = SpaceTravelRankPanel.Init(obj)
end

-- fill ui with the data
function SpaceTravelRankCtrl:SetupUI()
    local seasonId = self._parameter.seasonId
    local scoreCapRank = GameData.GetSpaceTravelScoreCapRank()
    local scoreCapId = GameData.GetScoreCapOfSpaceTravelSeason(seasonId, scoreCapRank)
    self._ui.Title.text = ConfigUtils.GetScoreCapInfo(scoreCapId)
    self._ui.RankGridWrap.OnItemUpdate = SpaceTravelRankCtrl.OnItemUpdateGlobal

    self._rankList = {}
    self:ConstructPlayerRank(nil, nil)
    self:RecycleRankItems()

    NetManager.Send("STRankList", {STSeasonID = seasonId}, SpaceTravelRankCtrl.OnHandleProto, self)

	CtrlManager.AddClick(self, self._ui.Blocker)
end

function SpaceTravelRankCtrl:RecycleRankItems()
    local num = self._ui.RankGrid.childCount
    for idx = num, 1, -1 do
        local item = self._ui.RankGrid:GetChild(idx - 1)
        item.parent = self._ui.RankItemPool
    end
end

function SpaceTravelRankCtrl:ConstructRankGrid()
    self:RecycleRankItems()

    local itemCount = self._ui.RankGridWrap.NeedCellCount
    itemCount = math.min(#self._rankList, itemCount)
    self._ui.RankGridWrap.MaxRow = math.ceil(#self._rankList / self._ui.RankGridWrap.ColumnLimit)

    for idx = 1, itemCount do
        local itemObj = Helper.NewObject(self._ui.RankItemTemplate, self._ui.RankGrid)
        itemObj:SetActive(true)
        itemObj.name = tostring(idx)

        local rankItem = itemObj.transform
        self:ConstructRankItem(rankItem, idx)
    end

    self._ui.RankGridWrap:SortBasedOnScrollMovement()
    self._ui.RankScrollView.restrictWithinPanel = true
    self._ui.RankScrollView.disableDragIfFits = (#self._rankList <= itemCount)
    self._ui.RankScrollView:ResetPosition()
end

function SpaceTravelRankCtrl:ConstructRankItem(item, rank)
    local userId = self._rankList[rank].userId
    local nickname = self._rankList[rank].nickname
    local score = self._rankList[rank].score

    local playerBG = item:Find("PlayerBG").gameObject
    playerBG:SetActive(userId == GameData.GetDefaultAccountUserId())

    local nameLabel = item:Find("Name"):GetComponent("UILabel")
    nameLabel.text = nickname

    local rankLabel = item:Find("Rank"):GetComponent("UILabel")
    rankLabel.text = tostring(rank)

    local resultLabel = item:Find("Result"):GetComponent("UILabel")
    resultLabel.text = tostring(score)

    local rankBGRoot = item:Find("RankBG")
    for idx = 1, rankBGRoot.childCount do
        local rankBG = rankBGRoot:GetChild(idx - 1).gameObject
        local rankMatch = (rank <= 3 and rank == idx) or (rank > 3 and idx > 3)
        rankBG:SetActive(rankMatch)
    end
end

function SpaceTravelRankCtrl:ConstructPlayerRank(rank, score)
    rank = rank or 0
    local hasData = (rank > 0)
    local nameLabel = self._ui.PlayerRankRoot:Find("Name"):GetComponent("UILabel")
    nameLabel.text = GameData.GetDefaultNickName(true)

    local rankLabel = self._ui.PlayerRankRoot:Find("Rank"):GetComponent("UILabel")
    if hasData then
        rankLabel.text = tostring(rank)
    else
        rankLabel.text = "???"
    end

    local resultLabel = self._ui.PlayerRankRoot:Find("Result"):GetComponent("UILabel")
    if hasData then
        resultLabel.text = tostring(score)
    else
        resultLabel.text = "???"
    end
end

function SpaceTravelRankCtrl:OnItemUpdate(itemObj, itemIndex, itemRealIndex)
    itemRealIndex = itemRealIndex + 1
    if itemRealIndex <= 0 or itemRealIndex > #self._rankList then
        itemObj:SetActive(false)
    else
        itemObj:SetActive(true)
        itemObj.name = tostring(itemRealIndex)
        local rankItem = itemObj.transform
        -- construct item
        self:ConstructRankItem(rankItem, itemRealIndex)
    end
end

function SpaceTravelRankCtrl.OnItemUpdateGlobal(itemObj, itemIndex, itemRealIndex)
    local ctrl = CtrlManager.GetCtrlByName(CtrlNames.SpaceTravelRank)
    if ctrl ~= nil then
        ctrl:OnItemUpdate(itemObj, itemIndex, itemRealIndex)
    end
end

-- on clicked
function SpaceTravelRankCtrl:OnClicked(go)

    if go == self._ui.Blocker then
        SoundSystem.PlayUICancelSound()
        CtrlManager.PopPanel()
    end

	return true
end

function SpaceTravelRankCtrl:OnHandleProto(proto, data, requestData)
    if proto == "STRankList" then
        self._rankList = {}
        local rankList = data.RankList or {}
        for idx = 1, #rankList do
            self._rankList[idx] = {
                userId = rankList[idx].Userid,
                nickname = rankList[idx].Nickname,
                score = rankList[idx].Score,
            }
        end

        self:ConstructPlayerRank(data.RankSelf, data.ScoreSelf)
        self:ConstructRankGrid()
    end
end
