require "FreakPlanet/View/SpaceTravelChatCharacterPanel"
require "FreakPlanet/Controller/CharacterSelectBaseCtrl"

local class = require "FreakPlanet/Utils/middleclass"
SpaceTravelChatCharacterCtrl  = class(CtrlNames.SpaceTravelChatCharacter, CharacterSelectBaseCtrl)

local _sortAbilityId = nil
local _sortAbilityList = nil
---------------------------------------------------------------------------
local function CharacterSortFunc(idA, idB)
    if idA == nil or idB == nil then
        return false
    end

    local markedA = GameData.IsItemMarked(idA)
    local markedB = GameData.IsItemMarked(idB)
    if markedA ~= markedB then
        return markedA
    end

    local selectableMap = CharacterSelectBaseCtrl.GetCharacterSelectableMap()
    if selectableMap ~= nil then
        local selectableA = selectableMap[idA]
        local selectableB = selectableMap[idB]

        if selectableA ~= selectableB then
            return selectableA
        end
    end

    local valueA = 0
    local valueB = 0

    if _sortAbilityId ~= nil then
        valueA = CharacterSelectBaseCtrl.GetAbilityValueOfCharacter(idA, _sortAbilityId)
        valueB = CharacterSelectBaseCtrl.GetAbilityValueOfCharacter(idB, _sortAbilityId)
    else
        valueA = CharacterSelectBaseCtrl.GetAbilitySumOfCharacter(idA, _sortAbilityList)
        valueB = CharacterSelectBaseCtrl.GetAbilitySumOfCharacter(idB, _sortAbilityList)
    end

    if valueA == valueB then
        valueA = GameData.GetCharacterLevel(idA)
        valueB = GameData.GetCharacterLevel(idB)
    end

    if valueA == valueB then
        valueA = ConfigUtils.GetCharacterRarity(idA)
        valueB = ConfigUtils.GetCharacterRarity(idB)
    end

    if valueA == valueB then
        valueA = ConfigUtils.GetCharacterSortId(idA)
        valueB = ConfigUtils.GetCharacterSortId(idB)
    end

    return valueA > valueB
end
---------------------------------------------------------------------------
-- load the ui prefab
function SpaceTravelChatCharacterCtrl:LoadPanel()
	self:CreatePanel("SpaceTravelChatCharacter")
end

-- construct ui panel data
function SpaceTravelChatCharacterCtrl:ConstructUI(obj)
	self._ui = SpaceTravelChatCharacterPanel.Init(obj)
end

-- destroy implementation
function SpaceTravelChatCharacterCtrl:DestroyImpl()
    GameNotifier.RemoveListener(GameEvent.CharacterSkinChanged, SpaceTravelChatCharacterCtrl.OnCharacterSkinChanged, self)
    GameNotifier.RemoveListener(GameEvent.CharacterStageChanged, SpaceTravelChatCharacterCtrl.OnCharacterStageChanged, self)
    GameNotifier.RemoveListener(GameEvent.CharacterLevelChanged, SpaceTravelChatCharacterCtrl.OnCharacterLevelChanged, self)
    GameNotifier.RemoveListener(GameEvent.CharacterEquipmentUpgraded, SpaceTravelChatCharacterCtrl.OnCharacterEquipmentUpgraded, self)
    GameNotifier.RemoveListener(GameEvent.MarkStateChanged, SpaceTravelChatCharacterCtrl.OnMarkStateChanged, self)
end

-- fill ui with the data
function SpaceTravelChatCharacterCtrl:SetupUI()
	_sortAbilityId = nil
    self._seasonId = self._parameter.seasonId
    self._choiceId = self._parameter.choiceId
    self._chatId = self._parameter.chatId
    self._ui.ItemGridWrap.OnItemUpdate = SpaceTravelChatCharacterCtrl.OnItemUpdateGlobal
    self._characterSelectMode = CharacterSelectMode.SpaceTravelChat
    _sortAbilityList = ConfigUtils.GetSpaceTravelChatNeedAbilityList(self._chatId)
    self._ui.ThemeLabel.text = ConfigUtils.GetSpaceTravelChatName(self._chatId)
    self._ui.ResultPanel:SetActive(false)
    self:SpawnEnemyAvatar()

    local numLimit = ConfigUtils.GetSpaceTravelChatCharacterLimit(self._chatId)
    self:InitializeShared(numLimit, CharacterSortFunc, nil)
    -- must be called before OnSortAbilityChanged
    self:OnSelectedCharacterChanged(false)
    self:OnSortAbilityChanged()

    for k, v in pairs(self._ui.ChatAbilities) do
        CtrlManager.AddClick(self, v.item)
    end

    CtrlManager.AddClick(self, self._ui.ButtonConfirm)
    CtrlManager.AddClick(self, self._ui.ButtonCancel)
    CtrlManager.AddClick(self, self._ui.ResultBlocker)
    GameNotifier.AddListener(GameEvent.CharacterSkinChanged, SpaceTravelChatCharacterCtrl.OnCharacterSkinChanged, self)
    GameNotifier.AddListener(GameEvent.CharacterStageChanged, SpaceTravelChatCharacterCtrl.OnCharacterStageChanged, self)
    GameNotifier.AddListener(GameEvent.CharacterLevelChanged, SpaceTravelChatCharacterCtrl.OnCharacterLevelChanged, self)
    GameNotifier.AddListener(GameEvent.CharacterEquipmentUpgraded, SpaceTravelChatCharacterCtrl.OnCharacterEquipmentUpgraded, self)
    GameNotifier.AddListener(GameEvent.MarkStateChanged, SpaceTravelChatCharacterCtrl.OnMarkStateChanged, self)
end

function SpaceTravelChatCharacterCtrl:GetInitialCharacters()
    return {}
end

function SpaceTravelChatCharacterCtrl:GetItemPrefabAndPool()
    return self._ui.CharacterItemTemplate, self._ui.CharacterItemPool
end

function SpaceTravelChatCharacterCtrl:InitializeExploreRules()
    self._exploreRules = ConfigUtils.GetSpaceTravelChatRules(self._chatId)

    local text = ""
    for idx = 1, #self._exploreRules do
        local rule = self._exploreRules[idx]
        local descText = tostring(idx).."."..UIHelper.GetExploreRuleShowText(rule, false)
        text = text..descText

        if idx < #self._exploreRules then
            text = text.."\n"
        end
    end

    local hasRule = (#self._exploreRules > 0)
    self._ui.RuleRoot:SetActive(hasRule)
    if hasRule then
        self._ui.RuleLabel.text = text
    end
end

function SpaceTravelChatCharacterCtrl:InitCharacterPositionHint()
    for idx = 1, #self._ui.CharacterPositionHint do
        local item = self._ui.CharacterPositionHint[idx].item
        local activeMark = self._ui.CharacterPositionHint[idx].mark
        item.gameObject:SetActive(idx <= self._numLimit)
    end
end

function SpaceTravelChatCharacterCtrl:OnSortAbilityChanged()
    self:RefreshCharacterList(CharacterSortFunc)
    self:SetupItemGrid()

    for idx = 1, #self._ui.ChatAbilities do
        local hasAbility = (idx <= #_sortAbilityList)
        if hasAbility and _sortAbilityList[idx] == _sortAbilityId then
            self._ui.ChatAbilities[idx].selected:SetActive(true)
        else
            self._ui.ChatAbilities[idx].selected:SetActive(false)
        end
    end
end

function SpaceTravelChatCharacterCtrl:SpawnEnemyAvatar()
    local enemyId = ConfigUtils.GetSpaceTravelChatEnemy(self._chatId)
    -- avatar
    local prefabName, prefabBundle = ConfigUtils.GetEnemyPrefab(enemyId)
    local prefab = self:DynamicLoadAsset(prefabBundle, prefabName)
    local itemObj = Helper.NewObject(prefab, self._ui.EnemyRoot, 50)
    itemObj.name = tostring(enemyId)
    -- animation
    local skeletonAnimation = itemObj:GetComponent("SkeletonAnimation")
    Helper.PlayAnimation(skeletonAnimation, CharacterAnimations.Idle, true)
    -- skin
    local skinName = ConfigUtils.GetEnemySkinName(enemyId)
    if skinName ~= nil then
        Helper.SetSkin(skeletonAnimation, skinName)
    end
end

function SpaceTravelChatCharacterCtrl:ConstructCharacterItem(item, itemId)
    local abilityList = _sortAbilityList
    if _sortAbilityId ~= nil then
        abilityList = {_sortAbilityId}
    end
    local abilityMap = CharacterSelectBaseCtrl.GetAbilityMapOfCharacter(itemId)
    UIHelper.ConstructWorkShopCharacterItem(self, item, itemId, abilityMap, abilityList)
    local selected = self:IsCharacterSelected(itemId)
    self:RefreshGridItemSelectedState(itemId, selected)
    self:RefreshCharacterStatus(item, itemId)
    -- marked
    local marked = GameData.IsItemMarked(itemId)
    local markedMark = item:Find("Mark/Marked").gameObject
    markedMark:SetActive(marked)
end

function SpaceTravelChatCharacterCtrl:RefreshCharacterAbilities()
    local selectedCharacters = self:GetSelectedCharacterList()
    local characterAbilityMaps = GameData.GetGroupAbilityMap(selectedCharacters, nil)

    local totalAbilityMap = {}
    for _, abilityMap in pairs(characterAbilityMaps) do
        for abilityId, abilityValue in pairs(abilityMap) do
            local preValue = totalAbilityMap[abilityId] or 0
            totalAbilityMap[abilityId] = preValue + abilityValue
        end
    end

    local chatResult, maxChatResult = ConfigUtils.GetSpaceTravelChatResult(self._chatId, totalAbilityMap)
    for idx = 1, #self._ui.ChatAbilities do
        local abilityId = chatResult.NeedAttribute[idx].Value
        local maxAbilityValue = maxChatResult.NeedAttribute[idx].Num
        local actualAbilityValue = totalAbilityMap[abilityId] or 0

        self._ui.ChatAbilities[idx].name.text = ConfigUtils.GetAbilityName(abilityId)
        self._ui.ChatAbilities[idx].icon.spriteName = ConfigUtils.GetAbilityIcon(abilityId)
        self._ui.ChatAbilities[idx].current.text = tostring(actualAbilityValue)
        self._ui.ChatAbilities[idx].target.text = tostring(maxAbilityValue)

        local progress = 1
        if maxAbilityValue > actualAbilityValue then
            progress = actualAbilityValue / maxAbilityValue
            progress = math.min(1, progress)
        end
        self._ui.ChatAbilities[idx].progress.fillAmount = progress
    end

    self._ui.ChatAbilityHint.text = tostring(chatResult.Success).."%"
end

function SpaceTravelChatCharacterCtrl.OnItemUpdateGlobal(itemObj, itemIndex, itemRealIndex)
    local ctrl = CtrlManager.GetCtrlByName(CtrlNames.SpaceTravelChatCharacter)
    if ctrl ~= nil then
        ctrl:OnItemUpdate(itemObj, itemIndex, itemRealIndex)
    end
end

function SpaceTravelChatCharacterCtrl:OnCancelSpaceTravelConfirm()
    local seasonData = GameData.GetSpaceTravelSeasonData(self._seasonId)
    local scoreCapId = GameData.GetScoreCapOfSpaceTravelSeason(self._seasonId, seasonData.scoreCap)
    NetManager.Send('STChoiceCancel', {
        STSeasonID = self._seasonId, 
        STScoreCapID = scoreCapId,
        ChoiceId = self._choiceId,
    }, SpaceTravelChatCharacterCtrl.OnHandleProto, self)
end

-- handle the escapse button
function SpaceTravelChatCharacterCtrl:HandleEscape()
    if self._ui.ResultPanel.activeSelf then
        self:OnClicked(self._ui.ResultPanel)
    else
        self:OnClicked(self._ui.ButtonCancel)
    end
end

function SpaceTravelChatCharacterCtrl:CanJump()
    return not self._ui.ResultPanel.activeSelf
end

-- on clicked
function SpaceTravelChatCharacterCtrl:OnClicked(go)
    if go.transform.parent == self._ui.ItemGrid then
        local itemId = tonumber(go.name)
        -- tag not fit
        local selectableMap = CharacterSelectBaseCtrl.GetCharacterSelectableMap()
        if not selectableMap[itemId] then
            SoundSystem.PlayWarningSound()
            return true
        end

        local isBusy = GameData.IsBusyCharacter(itemId, self._characterSelectMode)
        if not isBusy then
            local characterIdx = self:GetExploreCharacterIdx(itemId)
            if characterIdx == nil then
                if #self._selectedCharacters < self._numLimit then
                    SoundSystem.PlayUIClickSound()
                    self:AppendExploreCharacter(itemId)
                else
                    SoundSystem.PlayWarningSound()
                    self:NotifyCharacterFull()
                end
            else
                SoundSystem.PlayUIClickSound()
                self:RemoveExploreCharacterAt(characterIdx)
            end
        else
            SoundSystem.PlayWarningSound()
        end
    elseif go.transform.parent == self._ui.CharacterRoot then
        SoundSystem.PlayUIClickSound()
        local characterId = tonumber(go.name)
        local characterIdx = self:GetExploreCharacterIdx(characterId)
        assert(characterIdx ~= nil, "clicked character but not in explore character list: "..go.name)
        self:RemoveExploreCharacterAt(characterIdx)
    elseif go.transform.parent == self._ui.ChatAbilityRoot then
        SoundSystem.PlayUIClickSound()
        local names = Helper.StringSplit(go.name)
        assert(#names == 2, "invalid ability item name: "..tostring(go.name))
        local idx = tonumber(names[2])
        local abilityId = _sortAbilityList[idx]
        if abilityId == _sortAbilityId then
            _sortAbilityId = nil 
        else
            _sortAbilityId = abilityId
        end

        self:RecycleGridItems()
        self:OnSortAbilityChanged()
    elseif go == self._ui.ButtonConfirm then
        local isValid = CtrlManager.CheckSpaceTravelSeasonValid(self._seasonId, true)
        if not isValid then
            return true
        end

        SoundSystem.PlayUIClickSound()
        local characterList = self:GetSelectedCharacterList()
        local seasonData = GameData.GetSpaceTravelSeasonData(self._seasonId)
        local scoreCapId = GameData.GetScoreCapOfSpaceTravelSeason(self._seasonId, seasonData.scoreCap)
        NetManager.Send('STChoiceChat', {
            STSeasonID = self._seasonId, 
            STScoreCapID = scoreCapId, 
            CharacterList = characterList,
            ChoiceId = self._choiceId,
        }, SpaceTravelChatCharacterCtrl.OnHandleProto, self)
    elseif go == self._ui.ButtonCancel then
        local isValid = CtrlManager.CheckSpaceTravelSeasonValid(self._seasonId, true)
        if not isValid then
            return true
        end

        SoundSystem.PlayUIClickSound()
        CtrlManager.ShowMessageBox({message = SAFE_LOC("确认放弃谈判?"), single = false, onConfirm = SpaceTravelChatCharacterCtrl.OnCancelSpaceTravelConfirm, receiver = self})
    elseif go == self._ui.ResultBlocker then
        local seasonId = self._resultSeasonId
        local choiceId = self._resultChoiceId
        local isValid = CtrlManager.CheckSpaceTravelSeasonValid(seasonId, true)
        if not isValid then
            return true
        end
        -- career data
        if self._resultWin then
            -- career
            GameData.ModifySpaceTravelCareerData(SpaceTravelCareerType.ChatWinCount, 1)
            -- goal
            local goalData = GameData.SetupItemGoalData(choiceId, 1)
            GameData.DoSpaceTravelGoalSettle(seasonId, TriggerType.ChoiceWin, {goalData})
        end

        local dropList = GameData.SettleSpaceTravelChoiceResult(seasonId, choiceId, self._resultWin)
        local parameter = nil
        if #dropList > 0 then
            parameter = GameData.ConstructSpaceTravelChoiceResultParameter(seasonId, dropList, self._resultData)
        end
        -- pop panel
        CtrlManager.PopPanel()
        if parameter ~= nil then
            CtrlManager.OpenPanel(CtrlNames.SpaceTravelChoiceResult, parameter)
        else
            GameData.SyncSpaceTravelSeasonBaseData(seasonId, self._resultData)
        end
    end

    return true
end

-- on pressed
function SpaceTravelChatCharacterCtrl:OnPressed(go, pressed, isLong)
    if pressed and isLong then
        if go.transform.parent == self._ui.ItemGrid then
            SoundSystem.PlayUIClickSound()
            local itemId = tonumber(go.name)
            CtrlManager.OpenPanel(CtrlNames.CharacterQuickDetail, {characterId = itemId})
        elseif go.transform.parent == self._ui.CharacterRoot then
            local characterId = tonumber(go.name)
            self:StartDrag(characterId)
        end
    elseif not pressed and self._dragCharacterId ~= nil then
        self:EndDrag()
    end
end

function SpaceTravelChatCharacterCtrl:OnHandleProto(proto, data, requestData)
    if proto == 'STChoiceChat' then
        self._resultSeasonId = requestData.STSeasonID
        self._resultChoiceId = requestData.ChoiceId
        self._resultWin = (data.Win == 1)
        self._resultData = data
        self._ui.ResultWin:SetActive(self._resultWin)
        self._ui.ResultLose:SetActive(not self._resultWin)
        self._ui.ResultPanel:SetActive(true)
    elseif proto == 'STChoiceCancel' then
        local seasonId = requestData.STSeasonID
        local choiceId = requestData.ChoiceId

        local dropList = GameData.SettleSpaceTravelChoiceCancel(seasonId, choiceId)
        local parameter = nil
        if #dropList > 0 then
            parameter = GameData.ConstructSpaceTravelChoiceResultParameter(seasonId, dropList, data)
        end
        -- pop panel
        CtrlManager.PopPanel()
        if parameter ~= nil then
            CtrlManager.OpenPanel(CtrlNames.SpaceTravelChoiceResult, parameter)
        else
            GameData.SyncSpaceTravelSeasonBaseData(seasonId, data)
        end
    end
end