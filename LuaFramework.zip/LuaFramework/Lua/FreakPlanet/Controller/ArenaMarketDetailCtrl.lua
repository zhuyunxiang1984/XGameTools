require "FreakPlanet/View/ArenaMarketDetailPanel"

local class = require "FreakPlanet/Utils/middleclass"
ArenaMarketDetailCtrl  = class(CtrlNames.ArenaMarketDetail, BaseCtrl)

-- load the ui prefab
function ArenaMarketDetailCtrl:LoadPanel()
	self:CreatePanel("ArenaMarketDetail")
end

-- construct ui panel data
function ArenaMarketDetailCtrl:ConstructUI(obj)
	self._ui = ArenaMarketDetailPanel.Init(obj)
end

-- fill ui with the data
function ArenaMarketDetailCtrl:SetupUI()
    self._selectedShopId = self._parameter.shopId
    self._isActivity = self._parameter.activity or false
    self._endTime = self._parameter.endTime

    self._priceNormalColor = self._ui.NormalCostNum.color
    self._hintState = nil
    self._ui.LeftTime.text = ""

    -- hide by default
    self._ui.HintPanel:SetActive(false)

    self:SetupDetail()
	
    CtrlManager.AddClick(self, self._ui.Blocker)
    CtrlManager.AddClick(self, self._ui.ButtonCharacterConfirm)
    CtrlManager.AddClick(self, self._ui.ButtonNormalConfirm)
end

function ArenaMarketDetailCtrl:RecycleCharacterItem()
    for idx = self._ui.CharacterItemRoot.childCount, 1, -1 do
        local item = self._ui.CharacterItemRoot:GetChild(idx - 1)
        item.parent = self._ui.CharacterItemPool
    end
end

function ArenaMarketDetailCtrl:SetupDetail()
    self:RecycleCharacterItem()

    local shopId = self._selectedShopId
    local shopType = ConfigUtils.GetArenaShopType(shopId)
    self._ui.CharacterRoot:SetActive(shopType == ArenaShopType.Character)
    self._ui.NormalRoot:SetActive(shopType == ArenaShopType.Normal)

    local items = ConfigUtils.GetArenaShopValidItems(shopId)
    if shopType == ArenaShopType.Character then
        for idx = 1, #items do
            local characterId = items[idx]
            local characterItem = nil
            if self._ui.CharacterItemPool.childCount == 0 then
                local characterItemObj = Helper.NewObject(self._ui.CharacterItemTemplate, self._ui.CharacterItemRoot)
                characterItem = characterItemObj.transform
                CtrlManager.AddClick(self, characterItemObj)
            else
                characterItem = self._ui.CharacterItemPool:GetChild(0)
                characterItem.parent = self._ui.CharacterItemRoot
                characterItem.localPosition = Vector3.zero
                characterItem.localScale = Vector3.one
            end

            characterItem.gameObject:SetActive(true)
            characterItem.gameObject.name = tostring(characterId)

            local rarity = ConfigUtils.GetCharacterRarity(characterId)
            local bg = characterItem:Find("BG"):GetComponent("UISprite")
            bg.spriteName = string.format("icon_blindbox_rairty%d_2", rarity)

            local icon = characterItem:Find("Icon"):GetComponent("UISprite")
            UIHelper.SetCharacterIcon(self, icon, characterId)
        end
        self._ui.CharacterItemRoot:GetComponent("UIGrid"):Reposition()
        self._ui.CharacterGeneralBG:SetActive(not self._isActivity)
        self._ui.CharacterActivityBG:SetActive(self._isActivity)
    elseif shopType == ArenaShopType.Normal then
        local itemId = items[1]
        UIHelper.SetItemIcon(self,self._ui.NormalIcon, itemId)
        self._ui.NormalName.text = ConfigUtils.GeArenaShopName(shopId)
        self._ui.NormalDesc.text = ConfigUtils.GetGoodsDesc(itemId)
    else
        assert(false, "un-handled arena shop type: "..tostring(shopType))
    end

    self:RefreshCostGoods()
end

function ArenaMarketDetailCtrl:UpdateImpl(deltaTime)
    if self._hintState ~= nil then
        local finished = self._hintState:Tick(deltaTime)
        if finished then
            self._hintState = nil
        end
    end

    if self._isActivity then
        self:RefreshLeftTime()
    end
end

function ArenaMarketDetailCtrl:RefreshLeftTime()
    local currentTime = GameData.GetServerTime()
    local leftTime = math.max(0, self._endTime - currentTime)
    if leftTime == 0 then
        self._ui.LeftTime.text = SAFE_LOC("活动已结束")
    else
        self._ui.LeftTime.text = SAFE_LOC("剩余时间：")..Helper.GetLongTimeString(leftTime)
    end
end

function ArenaMarketDetailCtrl:IsItemSoldOutOfShop(shopId)
    local items = ConfigUtils.GetArenaShopValidItems(shopId)
    for idx = 1, #items do
        local itemId = items[idx]
        local itemType = ConfigUtils.GetItemTypeFromId(itemId)
        local unlocked = GameData.IsItemUnlocked(itemId)
        if not unlocked or not ConfigUtils.IsUniqueItemType(itemType) then
            return false
        end
    end

    return true
end

function ArenaMarketDetailCtrl:RefreshCostGoods()
    local v = ConfigUtils.GetArenaShopInfo(self._selectedShopId)
    -- shop type
    local shopType = v.Type
    -- cost
    local costNum = v.CostItem.Num
    local costValue = v.CostItem.Value
    local ownNum = GameData.GetItemNum(costValue)
    -- sold out or not
    local buyCount = GameData.GetBuyCountOfArenaShop(self._selectedShopId)
    local limitNum = v.Limit
    local soldOut = (limitNum > 0 and buyCount >= limitNum)
    -- number is enough, check unique items
    if not soldOut then
        soldOut = self:IsItemSoldOutOfShop(self._selectedShopId)
    end

    local costRoot = nil
    local costNumLabel = nil
    local confirmButton = nil
    local soldOutMark = nil
    if shopType == ArenaShopType.Character then
        costRoot = self._ui.CharacterCostRoot
        costNumLabel = self._ui.CharacterCostNum
        confirmButton = self._ui.ButtonCharacterConfirm
        soldOutMark = self._ui.CharacterSoldOut

        for idx = 1, self._ui.CharacterItemRoot.childCount do
            local characterItem = self._ui.CharacterItemRoot:GetChild(idx - 1)
            local characterId = tonumber(characterItem.gameObject.name)
            local unlocked = GameData.IsItemUnlocked(characterId)
            local characterIcon = characterItem:Find("Icon"):GetComponent("UISprite")
            if unlocked then
                characterIcon.color = Color.white
            else
                characterIcon.color = LOCK_ICON_COLOR
            end
        end
    elseif shopType == ArenaShopType.Normal then
        costRoot = self._ui.NormalCostRoot
        costNumLabel = self._ui.NormalCostNum
        confirmButton = self._ui.ButtonNormalConfirm
        soldOutMark = self._ui.NormalSoldOut
        -- left num
        if limitNum > 0 then
            local leftNum = (limitNum - buyCount)
            self._ui.NormalNum.text = string.format(SAFE_LOC("库存%d"), leftNum)
        else
            self._ui.NormalNum.text = ""
        end
    else
        assert(false, "un-handled arena shop type: "..tostring(shopType))
    end
    -- cost num and icon
    UIHelper.ConstructItemIconAndNum(self, costRoot, costValue)
    costNumLabel.text = "x"..tostring(costNum)
    if costNum > ownNum then
        costNumLabel.color = Color.red
    else
        costNumLabel.color = self._priceNormalColor
    end

    confirmButton:SetActive(not soldOut)
    costRoot.gameObject:SetActive(not soldOut)
    soldOutMark:SetActive(soldOut)

    -- own item
    UIHelper.ConstructItemIconAndNum(self, self._ui.OwnItemRoot, costValue)
    -- num label
    local numLabel = self._ui.OwnItemRoot:Find("Num"):GetComponent("UILabel")
    numLabel.text ="x"..tostring(ownNum)
end

-- handle the escapse button
function ArenaMarketDetailCtrl:HandleEscape()
    if not self._ui.HintPanel.activeSelf then
        self:OnClicked(self._ui.Blocker)
    end
end

function ArenaMarketDetailCtrl:OnHintFinished(parameter)
    local data = parameter.data
    local requestData = parameter.requestData

    local shopId = requestData.ArenaShopId
    -- record shop buy count
    GameData.AddBuyCountOfArenaShop(shopId, 1)
    -- consume item
    local costValue, costNum = ConfigUtils.GetArenaShopCost(shopId)
    GameData.ConsumeItem(costValue, costNum)
    -- collect item
    local rewardId = data.RewardValue
    local rewardNum = data.RewardNum
    GameData.CollectItem(rewardId, rewardNum, true)

    local goldNum = data.RemainGold
    local diamondNum = data.RemainDiamond
    GameData.SetMoney(ItemType.Gold, goldNum)
    GameData.SetMoney(ItemType.Diamond, diamondNum)
    -- refresh cost
    self:RefreshCostGoods()
    -- notify callback
    if self._parameter.callback ~= nil then
        self._parameter.callback(self._parameter.receiver, shopId)
    end

    self._ui.HintPanel:SetActive(false)
end

-- on clicked
function ArenaMarketDetailCtrl:OnClicked(go)
    if self._hintState ~= nil then
        return true
    end

    if go == self._ui.Blocker then
        SoundSystem.PlayUICancelSound()
        CtrlManager.PopPanel()
    elseif go.transform.parent == self._ui.CharacterItemRoot then
        SoundSystem.PlayUIClickSound()
        local characterId = tonumber(go.name)
        CtrlManager.ShowItemDetail({itemId = characterId})
    elseif go == self._ui.ButtonNormalConfirm or go == self._ui.ButtonCharacterConfirm then
        local currentTime = GameData.GetServerTime()
        if currentTime >= self._endTime then
            SoundSystem.PlayWarningSound()
            if self._isActivity then
                CtrlManager.ShowMessageBox({message = SAFE_LOC("活动已结束"), single = true})
            else
                CtrlManager.ShowMessageBox({message = SAFE_LOC("商店已刷新，请退出重进"), single = true})
            end
            return true
        end

        local costValue, costNum = ConfigUtils.GetArenaShopCost(self._selectedShopId)
        local ownNum = GameData.GetItemNum(costValue)
        if costNum > ownNum then
            CtrlManager.ShowMessageBox({message = SAFE_LOC("所需物品不足"), single = true})
            return true
        end

        SoundSystem.PlayUIClickSound()
        NetManager.Send("ArenaShopBuy", {ArenaShopId = self._selectedShopId}, ArenaMarketDetailCtrl.OnHandleProto, self)
    end

	return true
end


function ArenaMarketDetailCtrl:OnHandleProto(proto, data, requestData)
    if proto == "ArenaShopBuy" then
        local shopId = requestData.ArenaShopId
        local shopType = ConfigUtils.GetArenaShopType(shopId)
        local parameter = {data = data, requestData = requestData}
        if shopType == ArenaShopType.Character then
            self._ui.HintSprite.spriteName = ConfigUtils.GetArenaShopSprite(shopId)
            self._hintState = AnimatorState:new(self._ui.HintAnimator, "BlindboxOpen", nil, self._ui.HintPanel)
            self._hintState:ActionOnExit(ArenaMarketDetailCtrl.OnHintFinished, self, parameter)
        else
            self:OnHintFinished(parameter)
        end
    end
end