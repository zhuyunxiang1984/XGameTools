require "FreakPlanet/View/ExploreGuidePanel"

local class = require "FreakPlanet/Utils/middleclass"
ExploreGuideCtrl  = class(CtrlNames.ExploreGuide, BaseCtrl)

local AREA_BG_NORMAL_COLOR = Color.New(238 / 255, 214 / 255, 191 / 255, 1)
local AREA_BG_LOCK_COLOR = Color.New(90 / 255, 90 / 255, 90 / 255, 1)

local AREA_BG_LOCK_COLORS =
{
	[120005] = Color.New(142 / 255, 142 / 255, 142 / 255, 1)
}
local function GetBgLockColor(areaId)
	if not AREA_BG_LOCK_COLORS[areaId] then
		return AREA_BG_LOCK_COLOR
	end
	return AREA_BG_LOCK_COLORS[areaId]
end

----------------------------------------------------------
-- 挑战状态改变条件
  -- 任务完成：挑战可完成
  -- 挑战完成：触发下一个挑战
----------------------------------------------------------
local function EnemySortFunc(elementA, elementB)
	if elementA == nil or elementB == nil then
		return false
	end

	local unlockedA = elementA.unlocked
	local unlockedB = elementB.unlocked
	if unlockedA ~= unlockedB then
		return unlockedA
	end

	local valueA = elementA.power
	local valueB = elementB.power
	if valueA == valueB then
		valueA = elementA.level
		valueB = elementB.level
	end

	return valueA < valueB
end
----------------------------------------------------------
-- load the ui prefab
function ExploreGuideCtrl:LoadPanel()
	self:CreatePanel("ExploreGuide")
end

-- destructor
function ExploreGuideCtrl:DestroyImpl()
	GameNotifier.RemoveListener(GameEvent.PlanetAreaExplore, ExploreGuideCtrl.OnPlanetAreaExplore, self)
	GameNotifier.RemoveListener(GameEvent.PlanetAreaSettle, ExploreGuideCtrl.OnPlanetAreaSettle, self)
	GameNotifier.RemoveListener(GameEvent.AreaNodeAdded, ExploreGuideCtrl.OnAreaNodeAdded, self)
	GameNotifier.RemoveListener(GameEvent.ChallengeFinished, ExploreGuideCtrl.OnChallengeFinished, self)
	GameNotifier.RemoveListener(GameEvent.ExploreTeamUnlocked, ExploreGuideCtrl.OnExploreTeamUnlocked, self)
	GameNotifier.RemoveListener(GameEvent.GoalChanged, ExploreGuideCtrl.OnGoalChanged, self)

	if self._pageEffectHandle ~= nil then
		GlobalScheduler:Cancel(self._pageEffectHandle)
		self._pageEffectHandle = nil
	end
end

-- notity it has been focused
function ExploreGuideCtrl:NotifyFocus()
	-- has new visible node
	if Helper.TableLength(self._newVisibleNodes) > 0 then

		for idx = 1, self._areaRoot.childCount do
			local areaItem = self._areaRoot:GetChild(idx - 1)
			self:CheckAreaNewVisibleNode(areaItem)
		end

		self._newVisibleNodes = {}
	end

	self:CheckTutorial()
end

-- construct ui panel data
function ExploreGuideCtrl:ConstructUI(obj)
	self._ui = ExploreGuidePanel.Init(obj)
end

-- fill ui with the data
function ExploreGuideCtrl:SetupUI()
	self._planetList = GameData.GetUnlockPlanets()
	self._pageEffectState = nil
	self._pageEffectHandle = nil
	self:ConstructExploreTeam()

	local exploreId = self._parameter.exploreId
	self:DoJump(exploreId)
	
	CtrlManager.AddClick(self, self._ui.Blocker)
	CtrlManager.AddClick(self, self._ui.ButtonExplore)
	CtrlManager.AddClick(self, self._ui.ButtonSettle)
	CtrlManager.AddClick(self, self._ui.ButtonPrev)
	CtrlManager.AddClick(self, self._ui.ButtonNext)
	CtrlManager.AddPress(self, self._ui.Blocker)
	CtrlManager.AddClick(self, self._ui.ButtonChallenge)

	GameNotifier.AddListener(GameEvent.PlanetAreaExplore, ExploreGuideCtrl.OnPlanetAreaExplore, self)
	GameNotifier.AddListener(GameEvent.PlanetAreaSettle, ExploreGuideCtrl.OnPlanetAreaSettle, self)
	GameNotifier.AddListener(GameEvent.AreaNodeAdded, ExploreGuideCtrl.OnAreaNodeAdded, self)
	GameNotifier.AddListener(GameEvent.ChallengeFinished, ExploreGuideCtrl.OnChallengeFinished, self)
	GameNotifier.AddListener(GameEvent.ExploreTeamUnlocked, ExploreGuideCtrl.OnExploreTeamUnlocked, self)
	GameNotifier.AddListener(GameEvent.GoalChanged, ExploreGuideCtrl.OnGoalChanged, self)

	-- default state
	self._ui.PageEffectRoot:SetActive(false)

	for k, v in pairs(self._ui.AreaEnemyItems) do
		CtrlManager.AddClick(self, v.item)
	end

	for k, v in pairs(self._ui.AreaChallengeItems) do
		CtrlManager.AddClick(self, v.item)
	end

	for k, v in pairs(self._ui.ExploreTeamItems) do
		CtrlManager.AddClick(self, v.item)
	end

	self:CheckTutorial()
end

function ExploreGuideCtrl:DoJump(exploreId)
	assert(ConfigUtils.IsValidItem(exploreId), "invalid explore id: "..tostring(exploreId))

	local itemType = ConfigUtils.GetItemTypeFromId(exploreId)
	if itemType == ItemType.Planet then
		self._currentPlanteId = exploreId
		self._currentAreaId = nil
	elseif itemType == ItemType.PlanetArea then
		self._currentPlanteId = ConfigUtils.GetPlanetOfArea(exploreId)
		if GameData.IsPlanetAreaUnlocked(exploreId) then
			self._currentAreaId = exploreId
		else
			self._currentAreaId = nil
		end
	else
		assert(false, "un-handle explore item id: "..tostring(exploreId))
	end

	self:OnSelectedPlanetChanged()
	self:OnSelectedAreaChanged()
end

function ExploreGuideCtrl:ConstructExploreTeam()
	self._exploreTeams = GameData.GetExploreTeam()

	for idx = 1, #self._ui.ExploreTeamItems do
		local hasTeam = (idx <= #self._exploreTeams)
		self._ui.ExploreTeamItems[idx].item:SetActive(hasTeam)
		if hasTeam then
			local teamStatus = self._exploreTeams[idx].status
			self._ui.ExploreTeamItems[idx].lock:SetActive(teamStatus == ExploreTeamStatus.Lock)
			self._ui.ExploreTeamItems[idx].idle:SetActive(teamStatus == ExploreTeamStatus.Idle)
			self._ui.ExploreTeamItems[idx].exploring:SetActive(teamStatus == ExploreTeamStatus.Exploring)
			if teamStatus == ExploreTeamStatus.Exploring then
				local areaId = self._exploreTeams[idx].area
				local planetId = ConfigUtils.GetPlanetOfArea(areaId)
				self._ui.ExploreTeamItems[idx].icon.spriteName = ConfigUtils.GetPlanetIcon(planetId)
			end
			self._ui.ExploreTeamItems[idx].time.text = ""
		end
	end
end

function ExploreGuideCtrl:RecycleMap()
	local childCount = self._ui.MapRoot.childCount
	for idx = childCount, 1, -1 do
		local map = self._ui.MapRoot:GetChild(idx - 1)
		map.parent = self._ui.MapPool
	end
end

function ExploreGuideCtrl:OnSelectedPlanetChanged()
	self:RecycleMap()
	self._simulationStates = {}
	self._newVisibleNodes = {}
	self._planetIndex = Helper.IndexOfArray(self._planetList, self._currentPlanteId)
	assert(self._planetIndex ~= nil, "planet: "..tostring(self._currentPlanteId).." is not in the planet list")

	local mapItem = self._ui.MapPool:Find(self._currentPlanteId)
	local isNewAdd = false
	if mapItem == nil then
		local mapPrefabName = ConfigUtils.GetPlanetMapPrefab(self._currentPlanteId)
		local mapPrefab = self:DynamicLoadAsset(Const.MapBundleName, mapPrefabName)
		local mapObj = Helper.NewObject(mapPrefab, self._ui.MapRoot)
		mapObj.name = tostring(self._currentPlanteId)
		mapItem = mapObj.transform
		isNewAdd = true
	else
		mapItem.parent = self._ui.MapRoot
		mapItem.localPosition = Vector3.zero
		mapItem.localScale = Vector3.one
	end

	self._areaRoot = mapItem:Find("Areas")
	if isNewAdd then
		for idx = 1, self._areaRoot.childCount do
			local areaItem = self._areaRoot:GetChild(idx - 1)
			for m = 1, areaItem.childCount do
				local childItem = areaItem:GetChild(m - 1).gameObject
				if childItem.name == "Collider" or childItem.name == "BossRoot" then
					CtrlManager.AddClick(self, childItem)
				end
			end
		end
	end

	self:ConstructPlanetMap(mapItem)

	self._ui.ButtonNext:SetActive(self._planetIndex < #self._planetList)
	self._ui.ButtonPrev:SetActive(self._planetIndex > 1)
	-- notify current planet changed
	PlanetCtrl.MarkShowPlanetGlobal(self._currentPlanteId)
end

function ExploreGuideCtrl:ConstructPlanetMap(mapItem)
	for idx = 1, self._areaRoot.childCount do
		local areaItem = self._areaRoot:GetChild(idx - 1)
		self:ConstructPlanetArea(areaItem)
	end
end

function ExploreGuideCtrl:ConstructPlanetArea(areaItem)
	local areaId = tonumber(areaItem.gameObject.name)
	local unlocked = GameData.IsPlanetAreaUnlocked(areaId)

	local nameLabel = areaItem:Find("Name"):GetComponent("UILabel")
	local levelLabel = areaItem:Find("Level"):GetComponent("UILabel")
	local bg = areaItem:GetComponent("UISprite")
	if unlocked then
		bg.color = AREA_BG_NORMAL_COLOR
		nameLabel.text = ConfigUtils.GetAreaName(areaId)
		levelLabel.text = string.format(SAFE_LOC('loc_SimpleLevel'), ConfigUtils.GetAreaLevel(areaId))
	else
		bg.color = GetBgLockColor(self._currentPlanteId)
		nameLabel.text = ""
		levelLabel.text = ""
	end

	self:CheckAreaNodeVisible(areaItem, areaId)
	self:CheckAreaChallengeIcon(areaItem, areaId)

	local markRoot = areaItem:Find("Mark")

	local exploring = GameData.IsPlanetAreaExploring(areaId)
	self:ToggleAreaItemExploringState(areaItem, areaId, exploring)

	local isNewArea = GameData.IsItemNew(areaId)
	local newMark = markRoot:Find("New").gameObject
	newMark:SetActive(isNewArea)
	-- goal hint
	self:RefreshAreaItemGoalHint(areaItem, areaId)
	-- time limit hint
	self:RefreshTimeLimitHint(areaItem, areaId)
end

function ExploreGuideCtrl:RefreshAreaItemGoalHint(areaItem, areaId)
	local markRoot = areaItem:Find("Mark")
	local goalMark = markRoot:Find("Goal").gameObject
	local matchGoal = JumpManager.MatchPlanetAreaGoal(areaId)
	goalMark:SetActive(matchGoal)
	-- challenge hint
	local challengeHint = areaItem:Find("BossRoot/Hint").gameObject
	local activeChallengeId = GameData.GetActiveChallengeOfArea(areaId)
	local matchChallenge = false
	if activeChallengeId ~= nil then
		matchChallenge = JumpManager.MatchChallengeGoal(activeChallengeId)
	end
	challengeHint:SetActive(matchChallenge)
end

function ExploreGuideCtrl:RefreshTimeLimitHint(areaItem, areaId)
	local markRoot = areaItem:Find("Mark")
	local timeLimitHint = markRoot:Find("TimeLimit")
	if timeLimitHint ~= nil then
		-- no time limit in area any more
		timeLimitHint.gameObject:SetActive(false)
	end
end

function ExploreGuideCtrl:RefreshTeamIndex()
	for idx = 1, #self._exploreTeams do
		local teamStatus = self._exploreTeams[idx].status
		if teamStatus == ExploreTeamStatus.Exploring then
			local areaId = self._exploreTeams[idx].area
			local planetId = ConfigUtils.GetPlanetOfArea(areaId)
			if planetId == self._currentPlanteId then
				self:ToggleAreaItemExploringState(nil, areaId, true)
			end
		end
	end
end

function ExploreGuideCtrl:IsSelectedAreaIdle()
	if self._currentAreaId == nil then
		return false
	end

	return not GameData.IsPlanetAreaExploring(self._currentAreaId)
end

function ExploreGuideCtrl:OnSelectedAreaChanged()
	self:RefreshAreaDetail()
	self:ToggleAreaItemSelectedState(self._currentAreaId, true)
	self:ToggleAreaItemNewState(self._currentAreaId)
end

function ExploreGuideCtrl:RefreshAreaDetail()
	self._refreshExplore = false
	self._ui.SelectedAreaRoot:SetActive(self._currentAreaId ~= nil)
	self._ui.EmptyAreaRoot:SetActive(self._currentAreaId == nil)
	if self._currentAreaId ~= nil then
		local exploring = GameData.IsPlanetAreaExploring(self._currentAreaId)
		self._ui.AreaIdleRoot:SetActive(not exploring)
		self._ui.AreaExploringRoot:SetActive(exploring)
		if exploring then
			self:ConstructAreaExploreData()
		else
			self:ConstructAreaIdleData()
		end
		self:ConstructAreaEnemyList()
	end
end

function ExploreGuideCtrl:ConstructAreaExploreData()
	local characters = GameData.GetPlanetAreaExploreCharacters(self._currentAreaId)
	local pet = GameData.GetPlanetAreaExplorePet(self._currentAreaId)
	if ConfigUtils.IsValidItem(pet) then
		table.insert(characters, pet)
	end
	
	for idx = 1, #self._ui.AreaCharacterItems do
		local hasCharacter = (idx <= #characters)
		self._ui.AreaCharacterItems[idx].item:SetActive(hasCharacter)
		if hasCharacter then
			local icon = self._ui.AreaCharacterItems[idx].icon
			UIHelper.SetCharacterIcon(self, icon, characters[idx])
		end
	end

	self._refreshExplore = self:RefreshExploreLeftTime()
end

function ExploreGuideCtrl:RefreshExploreLeftTime()
	local leftTime = GameData.GetLeftTimeOfPlanetArea(self._currentAreaId)

	if leftTime > 0 then
		self._ui.AreaExploreLeftTime.text = Helper.FormatTime(leftTime)

		local cost = 0
		if not GameData.IsFirstExploreSettle() then
			cost = ConfigUtils.GetSpeedUpDiamondCost(leftTime)
		end
		local curDiamond = GameData.GetMoney(ItemType.Diamond)
		self._ui.AreaExploreSpeedUpCost.text = tostring(cost)
		if cost > curDiamond then
			self._ui.AreaExploreSpeedUpCost.color = Color.red
		else
			self._ui.AreaExploreSpeedUpCost.color = self._ui.AreaExploreSpeedUpNormalColor
		end
	else
		self._ui.AreaExploreLeftTime.text = SAFE_LOC("已完成")
	end

	self._ui.AreaExploreSpeedUpRoot:SetActive(leftTime > 0)
	self._ui.AreaExploreFinishRoot:SetActive(leftTime == 0)

	return leftTime > 0
end

function ExploreGuideCtrl:ConstructAreaIdleData()
	self:ConstructAreaChallengeList()
	self:RefreshExploreButtonState()
	self:RefreshExploreGoalHint()
end

function ExploreGuideCtrl:RefreshExploreButtonState()
	local teamEnough = GameData.HasAvailableExploreTeam()
	self._ui.TeamLimitHint:SetActive(not teamEnough)
	self._ui.ButtonExplore:SetActive(teamEnough)
end

function ExploreGuideCtrl:RefreshExploreGoalHint()
	local matchGoal = JumpManager.MatchPlanetAreaGoalOnlyExplore(self._currentAreaId)
	self._ui.ExploreGoalHint:SetActive(matchGoal)
end

function ExploreGuideCtrl:ConstructAreaChallengeList()
	local challengeList = ConfigUtils.GetAreaChallengeList(self._currentAreaId)
	local challengeIndex = GameData.GetActiveChallengeIndexOfArea(self._currentAreaId)
	for idx = 1, #self._ui.AreaChallengeItems do
		local hasChallenge = (idx <= #challengeList)
		self._ui.AreaChallengeItems[idx].item:SetActive(hasChallenge)
		if hasChallenge then
			local challengeId = challengeList[idx]
			local isCompleted = GameData.IsChallengeCompleted(challengeId)
			local lastEnemyId = ConfigUtils.GetLastEnemyOfChallenge(challengeId)
			-- icon
			local icon = self._ui.AreaChallengeItems[idx].icon
			UIHelper.SetCharacterIcon(self, icon, lastEnemyId)
			-- still locked
		    if isCompleted or challengeIndex == idx then
		    	icon.color = Color.white
		    else
		    	icon.color = LOCK_ICON_COLOR
		    end
			-- finished mark
			local finishedMark = self._ui.AreaChallengeItems[idx].finished
			finishedMark:SetActive(isCompleted)
			-- hint mark
			local hintMark = self._ui.AreaChallengeItems[idx].hint
			local showHint = (not isCompleted and challengeIndex == idx and GameData.IsChallengeConditionMatch(challengeId))
			hintMark:SetActive(showHint)
		end
	end
end

function ExploreGuideCtrl:ConstructAreaEnemyList()
	local enemyList = ConfigUtils.GetAreaEnemyList(self._currentAreaId)
	local endIdx = #enemyList
	for idx = 1, #enemyList do
		local needChallengeId = enemyList[idx].NeedChallenge
		if not ConfigUtils.IsValidItem(needChallengeId) or GameData.IsChallengeCompleted(needChallengeId) then
			endIdx = idx
			break
		end
	end

	self._areaEnemyList = {}
	local handledEnemies = {}
	for idx = endIdx, 1, -1 do
		local needChallengeId = enemyList[idx].NeedChallenge
		local unlocked = (not ConfigUtils.IsValidItem(needChallengeId) or GameData.IsChallengeCompleted(needChallengeId))
		local enemyListOfThisLevel = enemyList[idx].Enemy or {}
		for enemyIdx = 1, #enemyListOfThisLevel do
			local enemyId = enemyListOfThisLevel[enemyIdx].Value
            local enemyNeedChallenge = enemyListOfThisLevel[enemyIdx].NeedChallenge
            -- match to show
            local canShow = true
            -- enemy challenge match
            if canShow and enemyNeedChallenge ~= nil then
                canShow = GameData.IsChallengeCompleted(enemyNeedChallenge)
            end

			if canShow and handledEnemies[enemyId] == nil then
				local enemyLevel = enemyListOfThisLevel[enemyIdx].Level
				local enemyPower = enemyListOfThisLevel[enemyIdx].FightPower

				table.insert(self._areaEnemyList, {
					id = enemyId, 
					level = enemyLevel, 
					power = enemyPower, 
					unlocked = unlocked,
				})
				handledEnemies[enemyId] = 1
			end
		end
	end

	-- sort
	table.sort(self._areaEnemyList, EnemySortFunc)

	for idx = 1, #self._ui.AreaEnemyItems do
		local enemyItem = self._ui.AreaEnemyItems[idx].item
		local hasEnemy = (idx <= #self._areaEnemyList)
		enemyItem:SetActive(hasEnemy)
		if hasEnemy then
			local enemyId = self._areaEnemyList[idx].id
			local unlocked = self._areaEnemyList[idx].unlocked

			local icon = self._ui.AreaEnemyItems[idx].icon
			UIHelper.SetCharacterIcon(self, icon, enemyId)

			if unlocked then
				icon.color = Color.white
			else
				icon.color = LOCK_ICON_COLOR
			end
		end
	end
end

function ExploreGuideCtrl:GetExploreTeamIndex(areaId)
	for idx = 1, #self._exploreTeams do
		if self._exploreTeams[idx].area == areaId then
			return idx
		end
	end

	return nil
end

function ExploreGuideCtrl:ToggleAreaItemSelectedState(areaId, selected)
	if not ConfigUtils.IsValidItem(areaId) then
		return
	end

	local areaItem = self._areaRoot:Find(areaId)
	if areaItem ~= nil then
		local bg = areaItem:GetComponent("UISprite")
		if selected then
			bg.color = Color.white
		else
			bg.color = AREA_BG_NORMAL_COLOR
		end
	end
end

function ExploreGuideCtrl:ToggleAreaItemExploringState(areaItem, areaId, exploring)
	if not ConfigUtils.IsValidItem(areaId) then
		return
	end

	if areaItem == nil then
		areaItem = self._areaRoot:Find(areaId)
	end

	if areaItem ~= nil then
		local exploringMark = areaItem:Find("Mark/Exploring").gameObject
		exploringMark:SetActive(exploring)

		local teamIndex = self:GetExploreTeamIndex(areaId)
		if teamIndex ~= nil then
			local teamLabel = areaItem:Find("Mark/Exploring/Flag/Flag1/Label"):GetComponent("UILabel")
			teamLabel.text = tostring(teamIndex)
		end
	end
end

function ExploreGuideCtrl:ToggleAreaItemNewState(areaId)
	if not ConfigUtils.IsValidItem(areaId) then
		return
	end

	local areaItem = self._areaRoot:Find(areaId)
	if areaItem ~= nil then
		local newMark = areaItem:Find("Mark/New").gameObject
		newMark:SetActive(false)
	end
	GameData.CheckItem(areaId)
end

function ExploreGuideCtrl:CheckAreaNodeVisible(areaItem, areaId)
	local unlocked = GameData.IsPlanetAreaUnlocked(areaId)
	local nodeRoot = areaItem:Find("Nodes")
	local progressLabel = areaItem:Find("Progress"):GetComponent("UILabel")
	local totalWeight = 0
	local finishedWeight = 0

	for idx = 1, nodeRoot.childCount do
		local nodeItem = nodeRoot:GetChild(idx - 1).gameObject
		local nodeName = nodeItem.name
		local isVisible = NodeHelper.IsAreaNodeVisible(nodeName)
		local nodeWeight = ConfigUtils.GetAreaNodeWeight(nodeName)
		nodeItem:SetActive(isVisible)
		totalWeight = totalWeight + nodeWeight
		if isVisible then
			finishedWeight = finishedWeight + nodeWeight
		end

		if isVisible then
			local isNew = GameData.IsItemNew(nodeName)
			local state = nil
			local nodeChildCount = nodeItem.transform.childCount
			for childIdx = 1, nodeChildCount do
				local nodeChildItem = nodeItem.transform:GetChild(childIdx - 1)
				
				local nodeChildAnimator = nodeChildItem:GetComponent("Animator")
				if isNew and nodeChildAnimator ~= nil then
					nodeChildItem.gameObject:SetActive(false)
					if state == nil then
						state = SequenceState:new()
					end

					SoundSystem.PlaySoundOfName(SoundNames.MapNewNode)
					local childState = AnimatorState:new(nodeChildAnimator, "Props", nil, nodeChildItem.gameObject)
					state:Push(childState)
				else
					nodeChildItem.gameObject:SetActive(true)
				end
			end

			if state ~= nil then
				table.insert(self._simulationStates, state)
			end

			if isNew then
				GameData.CheckItem(nodeName)
			end
		end
	end

	if unlocked then
		local progress = 100
		if totalWeight > 0 then
			progress = math.floor(100 * finishedWeight / totalWeight)
		end
		progressLabel.text = tostring(progress).."%"
	else
		progressLabel.text = ""
	end
end

function ExploreGuideCtrl:CheckAreaNewVisibleNode(areaItem)
	local areaId = tonumber(areaItem.gameObject.name)
	local nodeRoot = areaItem:Find("Nodes")
	local progressLabel = areaItem:Find("Progress"):GetComponent("UILabel")
	local unlocked = GameData.IsPlanetAreaUnlocked(areaId)
	local totalWeight = 0
	local finishedWeight = 0

	for idx = 1, nodeRoot.childCount do
		local nodeItem = nodeRoot:GetChild(idx - 1).gameObject
		local nodeName = nodeItem.name
		local isVisible = NodeHelper.IsAreaNodeVisible(nodeName)
		local nodeWeight = ConfigUtils.GetAreaNodeWeight(nodeName)
		totalWeight = totalWeight + nodeWeight
		if isVisible then
			finishedWeight = finishedWeight + nodeWeight
		end

		if self._newVisibleNodes[nodeName] ~= nil and not nodeItem.activeSelf then
			nodeItem:SetActive(true)

			local state = nil
			local nodeChildCount = nodeItem.transform.childCount
			for childIdx = 1, nodeChildCount do
				local nodeChildItem = nodeItem.transform:GetChild(childIdx - 1)
				local nodeChildAnimator = nodeChildItem:GetComponent("Animator")
				nodeChildItem.gameObject:SetActive(nodeChildAnimator == nil)
				if nodeChildAnimator ~= nil then
					if state == nil then
						state = SequenceState:new()
					end

					SoundSystem.PlaySoundOfName(SoundNames.MapNewNode)
					local childState = AnimatorState:new(nodeChildAnimator, "Props", nil, nodeChildItem.gameObject)
					state:Push(childState)
				end
			end

			if state ~= nil then
				table.insert(self._simulationStates, state)
			end
			GameData.CheckItem(nodeName)
		end
	end

	if unlocked then
		local progress = 100
		if totalWeight > 0 then
			progress = math.floor(100 * finishedWeight / totalWeight)
		end
		progressLabel.text = tostring(progress).."%"
	else
		progressLabel.text = ""
	end
end

function ExploreGuideCtrl:CheckAreaChallengeIcon(areaItem, areaId)
	local unlocked = GameData.IsPlanetAreaUnlocked(areaId)
	local challengeRoot = areaItem:Find("BossRoot").gameObject
	local challengeIndex = GameData.GetActiveChallengeIndexOfArea(areaId)
	
	local showChallenge = (unlocked and challengeIndex ~= nil)
	challengeRoot:SetActive(showChallenge)
	if showChallenge then
		local challengeList = ConfigUtils.GetAreaChallengeList(areaId)
		local challengeId = challengeList[challengeIndex]
		local lastEnemyId = ConfigUtils.GetLastEnemyOfChallenge(challengeId)
		-- icon
		local challengeIcon = challengeRoot.transform:Find("Icon"):GetComponent("UISprite")
		UIHelper.SetCharacterIcon(self, challengeIcon, lastEnemyId)
		-- animator
		local challengeAnimator = challengeIcon.gameObject:GetComponent("Animator")
		local canChallenge = GameData.IsChallengeConditionMatch(challengeId)
		if canChallenge then
			challengeAnimator:Play("Challenge", 0, 0)
		else
			challengeAnimator:Play("Locked", 0, 0)
		end
	end
end

-- update implementation
function ExploreGuideCtrl:UpdateImpl(deltaTime)
	if self._refreshExplore then
		self._refreshExplore = self:RefreshExploreLeftTime()
	end

	for idx = 1, #self._ui.ExploreTeamItems do
		local hasTeam = (idx <= #self._exploreTeams)
		if hasTeam then
			local teamStatus = self._exploreTeams[idx].status
			if teamStatus == ExploreTeamStatus.Exploring then
				local areaId = self._exploreTeams[idx].area
				local leftTime = GameData.GetLeftTimeOfPlanetArea(areaId)
				if leftTime > 0 then
					self._ui.ExploreTeamItems[idx].time.text = Helper.FormatTime(leftTime)
				else
					self._ui.ExploreTeamItems[idx].time.text = SAFE_LOC("完成")
				end
			end
		end
	end

	local num = #self._simulationStates
	for idx = num, 1, -1 do
		local finished = self._simulationStates[idx]:Tick(deltaTime)
		if finished then
			table.remove(self._simulationStates, idx)
		end
	end

	if self._pageEffectState ~= nil then
		local finished = self._pageEffectState:Tick(deltaTime)
		if finished then
			self._pageEffectState = nil
		end
	end
end

function ExploreGuideCtrl:OnPlanetAreaExplore(planetAreaId)
	self:ConstructExploreTeam()
	self:RefreshTeamIndex()

	if planetAreaId == self._currentAreaId then
		self:RefreshAreaDetail()
	else
		if self:IsSelectedAreaIdle() then
			self:RefreshExploreButtonState()
		end
	end
end

function ExploreGuideCtrl:OnPlanetAreaSettle(planetAreaId)
	self:ConstructExploreTeam()
	self:RefreshTeamIndex()

	local planetId = ConfigUtils.GetPlanetOfArea(planetAreaId)
	if planetId == self._currentPlanteId then
		self:ToggleAreaItemExploringState(nil, planetAreaId, false)
	end

	if planetAreaId == self._currentAreaId then
		self:RefreshAreaDetail()
	else
		if self:IsSelectedAreaIdle() then
			self:RefreshExploreButtonState()
		end
	end
end

function ExploreGuideCtrl:OnGoalChanged(goalType)
	if goalType ~= GoalType.Main then
		return
	end

	for idx = 1, self._areaRoot.childCount do
		local areaItem = self._areaRoot:GetChild(idx - 1)
		local areaId = tonumber(areaItem.gameObject.name)
		self:CheckAreaChallengeIcon(areaItem, areaId)
		self:RefreshAreaItemGoalHint(areaItem, areaId)
	end

	if self:IsSelectedAreaIdle() then
		self:ConstructAreaChallengeList()
		self:RefreshExploreGoalHint()
	end
end

function ExploreGuideCtrl:OnChallengeFinished(challengeId, firstComplete)
	local areaId = ConfigUtils.GetAreaOfChallenge(challengeId)
	if not firstComplete or not ConfigUtils.IsValidItem(areaId) then
		return
	end

	-- challenge may unlock new enemy, even is not same with selected area
	self:ConstructAreaEnemyList()

	if self:IsSelectedAreaIdle() then
		self:RefreshExploreGoalHint()
	end

	local planetId = ConfigUtils.GetPlanetOfArea(areaId)
	if planetId ~= self._currentPlanteId then
		return
	end

	if areaId == self._currentAreaId and self:IsSelectedAreaIdle() then
		self:ConstructAreaChallengeList()
	end

	local areaItem = self._areaRoot:Find(areaId)
	if areaItem ~= nil then
		self:CheckAreaChallengeIcon(areaItem, areaId)
		self:RefreshAreaItemGoalHint(areaItem, areaId)
	end
end

function ExploreGuideCtrl:OnExploreTeamUnlocked()
	self:ConstructExploreTeam()

	if self:IsSelectedAreaIdle() then
		self:RefreshExploreButtonState()
	end
end

function ExploreGuideCtrl:OnAreaNodeAdded(nodeName)
	self._newVisibleNodes[nodeName] = 1
end

function ExploreGuideCtrl:CloseToExplore()
	CtrlManager.OpenPanel(CtrlNames.ExploreCharacter, {areaId = self._currentAreaId})
end

function ExploreGuideCtrl:SwitchPlanetTo(index)
	self._currentPlanteId = self._planetList[index]
	self._currentAreaId = nil
	self._pageEffectHandle = nil
	self:OnSelectedPlanetChanged()
	self:OnSelectedAreaChanged()
end

function ExploreGuideCtrl:OnPageAnimationFinished()
	self._ui.PageEffectRoot:SetActive(false)
end

function ExploreGuideCtrl:SwitchPlanet(isNext)
	local index = self._planetIndex
	if isNext then
		index = index + 1
	else
		index = index - 1
	end

	if index < 1 or index > #self._planetList then
		return false
	end

	if isNext then
		self._pageEffectState = AnimatorState:new(self._ui.PageEffectAnimator, "PageNext", nil, self._ui.PageEffectRoot)
		self._pageEffectState:ActionOnExit(ExploreGuideCtrl.OnPageAnimationFinished, self)
		self._pageEffectHandle = GlobalScheduler:DoActionAfterTime(12 / 60, ExploreGuideCtrl.SwitchPlanetTo, self, index)
	else
		self._pageEffectState = AnimatorState:new(self._ui.PageEffectAnimator, "PagePrev", nil, self._ui.PageEffectRoot)
		self._pageEffectState:ActionOnExit(ExploreGuideCtrl.OnPageAnimationFinished, self)
		self._pageEffectHandle = GlobalScheduler:DoActionAfterTime(5 / 60, ExploreGuideCtrl.SwitchPlanetTo, self, index)
	end
	
	return true
end

function ExploreGuideCtrl:OnPressed(go, pressed, isLong)
	if self._pageEffectState ~= nil then
		return
	end

	if pressed then
		self._touchPosition = Input.mousePosition
	elseif not pressed and self._touchPosition ~= nil then
		local curPosition = Input.mousePosition
		local diffX = curPosition.x - self._touchPosition.x
		if diffX > 50 then
			SoundSystem.PlayUIClickSound()
			self:SwitchPlanet(false)
		elseif diffX < -50 then
			SoundSystem.PlayUIClickSound()
			self:SwitchPlanet(true)
		end
	end
end

-- on clicked
function ExploreGuideCtrl:OnClicked(go)

	if go == self._ui.Blocker then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
	elseif go == self._ui.ButtonPrev then
		if self._pageEffectState ~= nil then
			return true
		end
		SoundSystem.PlayUIClickSound()
		self:SwitchPlanet(false)
	elseif go == self._ui.ButtonNext then
		if self._pageEffectState ~= nil then
			return true
		end
		SoundSystem.PlayUIClickSound()
		self:SwitchPlanet(true)
	elseif go == self._ui.ButtonChallenge then
		SoundSystem.PlayUIClickSound()
		CtrlManager.OpenPanel(CtrlNames.FullStarChallenge, {planetId = self._currentPlanteId})
	elseif go == self._ui.ButtonSettle then
		local leftTime = GameData.GetLeftTimeOfPlanetArea(self._currentAreaId)
		SoundSystem.PlayUIClickSound()
		if leftTime == 0 then
			CtrlManager.OpenPanel(CtrlNames.ExploreResult, {areaId = self._currentAreaId})
		else
			CtrlManager.OpenPanel(CtrlNames.ExploreSpeedUp, {areaId = self._currentAreaId})
		end
	elseif go == self._ui.ButtonExplore then
		SoundSystem.PlayUIClickSound()
		CtrlManager.DoWaitTransition(CtrlNames.ExploreCharacter, self, ExploreGuideCtrl.CloseToExplore)
	elseif go.transform.parent == self._ui.AreaEnemyRoot then
		SoundSystem.PlayUIClickSound()
		local names = Helper.StringSplit(go.name)
		assert(#names == 2, "invalid enemy item name: "..tostring(go.name))
		local enemyIndex = tonumber(names[2])
		local enemyId = self._areaEnemyList[enemyIndex].id
		local enemyLevel = self._areaEnemyList[enemyIndex].level
		CtrlManager.ShowItemDetail({itemId = enemyId, itemLevel = enemyLevel})
	elseif go.transform.parent == self._ui.AreaChallengeRoot then
		local names = Helper.StringSplit(go.name)
		assert(#names == 2, "invalid challenge item name: "..tostring(go.name))
		local challengeIndex = tonumber(names[2])
		local activeChallengeIndex = GameData.GetActiveChallengeIndexOfArea(self._currentAreaId)
		if challengeIndex == activeChallengeIndex then
			SoundSystem.PlayUIClickSound()
			local challengeId = GameData.GetActiveChallengeOfArea(self._currentAreaId)
			CtrlManager.OpenPanel(CtrlNames.ExploreChallenge, {challengeId = challengeId})
		end
	elseif go.transform.parent == self._ui.ExploreTeamRoot then
		local names = Helper.StringSplit(go.name)
		assert(#names == 2, "invalid explore team item name: "..tostring(go.name))
		local teamIndex = tonumber(names[2])
		local teamStatus = self._exploreTeams[teamIndex].status
		if teamStatus == ExploreTeamStatus.Exploring then
			SoundSystem.PlayUIClickSound()
			local areaId = self._exploreTeams[teamIndex].area
			local planetId = ConfigUtils.GetPlanetOfArea(areaId)
			local areaChanged = false
			if planetId ~= self._currentPlanteId then
				self._currentPlanteId = planetId
				self:OnSelectedPlanetChanged()
				areaChanged = true
			end

			if areaId ~= self._currentAreaId then
				self:ToggleAreaItemSelectedState(self._currentAreaId, false)
				self._currentAreaId = areaId
				areaChanged = true
			end

			if areaChanged then
				self:OnSelectedAreaChanged()
			end
		elseif teamStatus == ExploreTeamStatus.Lock then
			SoundSystem.PlayUIClickSound()
			CtrlManager.OpenPanel(CtrlNames.ExploreUnlockTeam)
		end
	elseif go.name == "Collider" then
		local areaId = tonumber(go.transform.parent.gameObject.name)
		if GameData.IsPlanetAreaUnlocked(areaId) then
			if self._currentAreaId ~= areaId then
				SoundSystem.PlayUIClickSound()
				self:ToggleAreaItemSelectedState(self._currentAreaId, false)
				self._currentAreaId = areaId
				self:OnSelectedAreaChanged()
			end
		end
	elseif go.name == "BossRoot" then
		local areaId = tonumber(go.transform.parent.gameObject.name)
		if GameData.IsPlanetAreaUnlocked(areaId) then
			SoundSystem.PlayUIClickSound()
			-- change selected area
			if self._currentAreaId ~= areaId then
				self:ToggleAreaItemSelectedState(self._currentAreaId, false)
				self._currentAreaId = areaId
				self:OnSelectedAreaChanged()
			end
			local challengeId = GameData.GetActiveChallengeOfArea(areaId)
			CtrlManager.OpenPanel(CtrlNames.ExploreChallenge, {challengeId = challengeId})
		end
	end

	return true
end
--------------------------------------------------------
-- tutorial
function ExploreGuideCtrl:GetFirstAreaItem()
	return self._areaRoot:Find(TutorialConstData.ExploreAreaId)
end

function ExploreGuideCtrl:GetFirstChallengeItem()
	local areaItem = self._areaRoot:Find(TutorialConstData.ChallengeAreaId)
	return areaItem:Find("BossRoot")
end

function ExploreGuideCtrl:CheckTutorial()
	local tutorials = {}

	if GameData.IsTutorialNotFinished(Tutorials.Tutorial_1_9) then
		local areaItem = self:GetFirstAreaItem()
		local position = self._ui.Camera:WorldToScreenPoint(areaItem:Find("Collider").position)
		tutorials[1] = {event = Tutorials.Tutorial_1_2_0, position = position, sender = self}
		position = self._ui.Camera:WorldToScreenPoint(self._ui.ButtonExplore.transform:Find("TutorialMark").position)
		tutorials[2] = {event = Tutorials.Tutorial_1_2, position = position, sender = self}
	elseif GameData.IsTutorialFinished(Tutorials.Tutorial_1_9) and GameData.IsTutorialNotFinished(Tutorials.Tutorial_1_12) then
		local index = 1
		if self._currentAreaId ~= TutorialConstData.ExploreAreaId then
			local areaItem = self:GetFirstAreaItem()
			local position = self._ui.Camera:WorldToScreenPoint(areaItem:Find("Collider").position)
			tutorials[index] = {event = Tutorials.Tutorial_1_2_0, position = position, sender = self}
			index = index + 1
		end

		local pos = self._ui.Camera:WorldToScreenPoint(self._ui.ButtonSettle.transform:Find("TutorialMark").position)
		tutorials[index] = {event = Tutorials.Tutorial_1_10, position = pos, sender = self}
	end

	if #tutorials > 0 then
		CtrlManager.ShowTutorials(tutorials)
	end

	return #tutorials > 0
end

function ExploreGuideCtrl:OnTutorialClicked(tutorial)
	if tutorial == Tutorials.Tutorial_1_2 then
		self:OnClicked(self._ui.ButtonExplore)
	elseif tutorial == Tutorials.Tutorial_1_2_0 then
		local areaItem = self:GetFirstAreaItem()
		local collider = areaItem:Find("Collider").gameObject
		self:OnClicked(collider)
	elseif tutorial == Tutorials.Tutorial_1_10 then
		self:OnClicked(self._ui.ButtonSettle)
	end
end
--------------------------------------------------------