require "FreakPlanet/View/ExploreCharacterPanel"
require "FreakPlanet/Controller/CharacterSelectBaseCtrl"

local class = require "FreakPlanet/Utils/middleclass"
ExploreCharacterCtrl  = class(CtrlNames.ExploreCharacter, CharacterSelectBaseCtrl)

-----------------------------------------
local ABILITY_SORT_COLOR = Color.New(218 / 255, 1, 1, 1)
local ABILITY_NORMAL_COLOR = Color.New(128 / 255, 1, 1, 1)
-----------------------------------------
local _sortPlanetAreaId = nil

local function CharacterSortFunc(idA, idB)
	if idA == nil or idB == nil then
		return false
	end

	local matchA = CharacterSelectBaseCtrl.IsCharacterGoalNeeded(idA)
    local matchB = CharacterSelectBaseCtrl.IsCharacterGoalNeeded(idB)
    if matchA ~= matchB then
        return matchA
    end

	local markedA = GameData.IsItemMarked(idA)
	local markedB = GameData.IsItemMarked(idB)
	if markedA ~= markedB then
		return markedA
	end

    local selectableMap = CharacterSelectBaseCtrl.GetCharacterSelectableMap()
	if selectableMap ~= nil then
		local selectableA = selectableMap[idA]
		local selectableB = selectableMap[idB]

		if selectableA ~= selectableB then
			return selectableA
		end
	end

    local needMap = CharacterSelectBaseCtrl.GetNeedCharacterMap()
    if needMap ~= nil then
        local isNeededA = needMap[idA]
        local isNeededB = needMap[idB]
        if isNeededA ~= isNeededB then
            return isNeededA
        end
    end

	local valueA = 0
    local valueB = 0

    local sortAbilityId, sortPower = CharacterSelectBaseCtrl.GetSortValue()
    if sortAbilityId ~= nil then
        valueA = CharacterSelectBaseCtrl.GetAbilityValueOfCharacter(idA, sortAbilityId)
        valueB = CharacterSelectBaseCtrl.GetAbilityValueOfCharacter(idB, sortAbilityId)
    elseif sortPower then
        valueA = CharacterSelectBaseCtrl.GetPowerValueOfCharacter(idA)
        valueB = CharacterSelectBaseCtrl.GetPowerValueOfCharacter(idB)
    end

    if valueA == valueB then
        valueA = ConfigUtils.GetCharacterRarity(idA)
        valueB = ConfigUtils.GetCharacterRarity(idB)
    end

    if valueA == valueB then
        valueA = GameData.GetCharacterLevel(idA)
        valueB = GameData.GetCharacterLevel(idB)
    end

    if valueA == valueB then
        valueA = ConfigUtils.GetCharacterSortId(idA)
        valueB = ConfigUtils.GetCharacterSortId(idB)
    end

	return valueA > valueB
end

local function PetSortFunc(idA, idB)
	if idA == nil or idB == nil then
		return false
	end

    local matchA = CharacterSelectBaseCtrl.IsPetGoalNeeded(idA)
    local matchB = CharacterSelectBaseCtrl.IsPetGoalNeeded(idB)
    if matchA ~= matchB then
        return matchA
    end

	local markedA = GameData.IsItemMarked(idA)
	local markedB = GameData.IsItemMarked(idB)
	if markedA ~= markedB then
		return markedA
	end

	local valueA = 0
    local valueB = 0

    local sortAbilityId, sortPower = CharacterSelectBaseCtrl.GetSortValue()
    if sortAbilityId ~= nil then
        valueA = CharacterSelectBaseCtrl.GetAbilityValueOfPet(idA, sortAbilityId)
        valueB = CharacterSelectBaseCtrl.GetAbilityValueOfPet(idB, sortAbilityId)
    elseif sortPower then
        valueA = CharacterSelectBaseCtrl.GetPowerValueOfPet(idA)
        valueB = CharacterSelectBaseCtrl.GetPowerValueOfPet(idB)
    end

    if valueA == valueB then
        valueA = ConfigUtils.GetPetRarity(idA)
        valueB = ConfigUtils.GetPetRarity(idB)
    end

    if valueA == valueB then
       valueA = GameData.GetPetLevel(idA)
       valueB = GameData.GetPetLevel(idB)
    end

    if valueA == valueB then
        valueA = ConfigUtils.GetPetSortId(idA)
        valueB = ConfigUtils.GetPetSortId(idB)
    end

    return valueA > valueB
end

local function EnemySortFunc(elementA, elementB)
	if elementA == nil or elementB == nil then
		return false
	end

	local unlockedA = elementA.unlocked
	local unlockedB = elementB.unlocked
	if unlockedA ~= unlockedB then
		return unlockedA
	end

	local valueA = elementA.power
	local valueB = elementB.power
	if valueA == valueB then
		valueA = elementA.level
		valueB = elementB.level
	end

	return valueA < valueB
end
-----------------------------------------

-- load the ui prefab
function ExploreCharacterCtrl:LoadPanel()
	self:CreatePanel("ExploreCharacter")
end

-- destroy implementation
function ExploreCharacterCtrl:DestroyImpl()
	GameNotifier.RemoveListener(GameEvent.CharacterSkinChanged, ExploreCharacterCtrl.OnCharacterSkinChanged, self)
    GameNotifier.RemoveListener(GameEvent.CharacterStageChanged, ExploreCharacterCtrl.OnCharacterStageChanged, self)
    GameNotifier.RemoveListener(GameEvent.CharacterLevelChanged, ExploreCharacterCtrl.OnCharacterLevelChanged, self)
    GameNotifier.RemoveListener(GameEvent.CharacterEquipmentUpgraded, ExploreCharacterCtrl.OnCharacterEquipmentUpgraded, self)
    GameNotifier.RemoveListener(GameEvent.MarkStateChanged, ExploreCharacterCtrl.OnMarkStateChanged, self)

    -- save team
    local characters = self:GetSelectedCharacterList()
    local petId = self._selectedPet
    if self._characterSelectMode == CharacterSelectMode.Explore then    
        GameData.SetPlanetAreaExploreCharacters(self._planetAreaId, characters)
        GameData.SetPlanetAreaExplorePet(self._planetAreaId, petId)
        GameData.Save()
    elseif self._characterSelectMode == CharacterSelectMode.Challenge then
        GameData.SetChallengeBattleTeam(self._challengeId, characters, petId)
        GameData.Save()
    elseif self._characterSelectMode == CharacterSelectMode.ActivityExplore then
        GameData.SetActivityExploreTeam(self._activityThemeId, characters, petId)
        GameData.Save()
    elseif self._characterSelectMode == CharacterSelectMode.ActivityBattle then
        GameData.SetActivityBattleTeam(self._activityBattleId, characters, petId)
        GameData.Save()
    end
end

-- construct ui panel data
function ExploreCharacterCtrl:ConstructUI(obj)
	self._ui = ExploreCharacterPanel.Init(obj)
end

-- fill ui with the data
function ExploreCharacterCtrl:SetupUI()
	-- parameters
	local areaId = self._parameter.areaId                                   -- 区域探索
	local challengeId = self._parameter.challengeId                         -- 普通/装备/皮肤/星际挑战
    local activityBattleId = self._parameter.battleId                       -- 活动挑战
    local activityExploreId = self._parameter.exploreId                     -- 活动探索
    -- only valid for space travel challenge
    self._seasonId = self._parameter.seasonId
    self._choiceId = self._parameter.choiceId
    -- only valid for activity explore or battle
    self._activityThemeId = self._parameter.themeId

    self:CheckSpaceTravelRetry()

	_sortPlanetAreaId = areaId
	self._planetAreaId = areaId
	self._challengeId = challengeId
    self._activityBattleId = activityBattleId
    self._activityExploreId = activityExploreId
	self._selectedPet = nil
    local startSceneName = nil
	local savedPet = nil
	if self._planetAreaId ~= nil then
		self._characterSelectMode = CharacterSelectMode.Explore
		savedPet = CharacterSelector.CheckSelectedPet(areaId)
        startSceneName = ConfigUtils.GetAreaStartScene(areaId)
    elseif self._activityBattleId ~= nil then
        self._characterSelectMode = CharacterSelectMode.ActivityBattle
        savedPet = CharacterSelector.GetActivityBattleSelectedPet(self._activityBattleId)
        startSceneName = ConfigUtils.GetActivityBattleStartScene(self._activityBattleId)
    elseif self._activityExploreId ~= nil then
        self._characterSelectMode = CharacterSelectMode.ActivityExplore
        savedPet = CharacterSelector.GetActivityExploreSelectedPet(self._activityThemeId)
        startSceneName = ConfigUtils.GetActivityExploreStartScene(self._activityExploreId)
	elseif self._challengeId ~= nil then
		self._characterSelectMode = CharacterSelectMode.Challenge
        savedPet = CharacterSelector.GetChallengeSelectedPet(challengeId)
        startSceneName = ConfigUtils.GetChallengeStartScene(challengeId)
    else
        assert(false, "un-handle situation in explore character")
	end

    if startSceneName ~= nil then
        local scenePrefab = self:DynamicLoadAsset(Const.StartSceneBundleName, startSceneName)
        local sceneObj = Helper.NewObject(scenePrefab, self._ui.SceneRoot)
        sceneObj.name = startSceneName
    end

	self._ui.ItemGridWrap.OnItemUpdate = ExploreCharacterCtrl.OnItemUpdateGlobal
	self._petItemPrefab = self:LoadAsset("PetItem")

    local showChallengeInfo = (self._challengeId ~= nil or self._activityBattleId ~= nil)
	self._ui.ChallengeInfoRoot.gameObject:SetActive(showChallengeInfo)
	self._ui.AreaInfoRoot.gameObject:SetActive(not showChallengeInfo)
	local numLimit = 0
    self._enemyIndexThatNeedElement = nil
	if self._challengeId ~= nil then
		-- num limit
		numLimit = ConfigUtils.GetChallengeNumCapacity(self._challengeId)
		-- name
		self._ui.ChallengeNameLabel.text = ConfigUtils.GetChallengeName(challengeId)
		-- boss enemy
		local lastEnemyId = ConfigUtils.GetLastEnemyOfChallenge(self._challengeId)
		UIHelper.SetCharacterIcon(self, self._ui.ChallengeEnemyIcon, lastEnemyId)
		self._ui.ChallengeEnemyNameLabel.text = ConfigUtils.GetEnemyName(lastEnemyId)
		self._ui.ChallengeEnemyElementIcon.spriteName = ConfigUtils.GetElementIconOfItem(lastEnemyId)
	elseif self._planetAreaId ~= nil then
		-- num limit
		numLimit = ConfigUtils.GetAreaNumCapacity(areaId)
		-- name
		self._ui.AreaNameLabel.text = ConfigUtils.GetAreaName(areaId)
		self:ConstructExploreEnemyList()
    elseif self._activityBattleId ~= nil then
        -- num limit
        numLimit = ConfigUtils.GetActivityBattleNumCapacity(self._activityBattleId)
        -- name
        self._ui.ChallengeNameLabel.text = ConfigUtils.GetActivityBattleName(self._activityBattleId)
        -- boss enemy
        local lastEnemyId = ConfigUtils.GetLastEnemyOfActivityBattle(self._activityBattleId)
        UIHelper.SetCharacterIcon(self, self._ui.ChallengeEnemyIcon, lastEnemyId)
        self._ui.ChallengeEnemyNameLabel.text = ConfigUtils.GetEnemyName(lastEnemyId)
        self._ui.ChallengeEnemyElementIcon.spriteName = ConfigUtils.GetElementIconOfItem(lastEnemyId)
    elseif self._activityThemeId ~= nil then
        -- num limit
        numLimit = ConfigUtils.GetActivityExploreNumCapacity(self._activityExploreId)
        -- name
        self._ui.AreaNameLabel.text = ConfigUtils.GetActivityExploreName(self._activityExploreId)
        self:ConstructExploreEnemyList()
	end

    -- shared data
	self:InitializeShared(numLimit, CharacterSortFunc, PetSortFunc)
	self:OnSelectionModeChanged()
	-- call it after all characters are initialized
	if savedPet ~= self._selectedPet then
		-- in this method it will also call OnSelectedCharacterChanged
		self:ChangeSelectPet(savedPet, false)
	else
		self:OnSelectedCharacterChanged(false)
	end

	for idx = 1, #self._ui.AreaEnemyItems do
		local enemyItem = self._ui.AreaEnemyItems[idx].item
		CtrlManager.AddClick(self, enemyItem)
	end

    -- sort
    self._sortOn = false
    self._ui.SortRoot:SetActive(false)
    for k, v in pairs(self._ui.SortAbilityItems) do
        CtrlManager.AddClick(self, v.item)
    end
    CtrlManager.AddClick(self, self._ui.ButtonSort)
    CtrlManager.AddClick(self, self._ui.SortPower)

    -- team button default states
    self._ui.ButtonTeamSort:SetActive(false)
    self._ui.ButtonTeamSortConfirm:SetActive(false)
    self._ui.ButtonTeamDelete:SetActive(false)
    self._ui.ButtonTeamDeleteConfirm:SetActive(false)

	CtrlManager.AddClick(self, self._ui.ButtonExplore)
	CtrlManager.AddClick(self, self._ui.ButtonClose)
	CtrlManager.AddClick(self, self._ui.ButtonCharacter.gameObject)
	CtrlManager.AddClick(self, self._ui.ButtonPet.gameObject)
	CtrlManager.AddClick(self, self._ui.ChallengeEnemyIcon.gameObject)
	CtrlManager.AddClick(self, self._ui.ButtonFilter)

    -- team
    CtrlManager.AddClick(self, self._ui.ButtonTeam.gameObject)
    CtrlManager.AddClick(self, self._ui.ButtonTeamSort)
    CtrlManager.AddClick(self, self._ui.ButtonTeamSortConfirm)
    CtrlManager.AddClick(self, self._ui.ButtonTeamDelete)
    CtrlManager.AddClick(self, self._ui.ButtonTeamDeleteConfirm)

    -- couple
    CtrlManager.AddClick(self, self._ui.ButtonCouple.gameObject)
	
	GameNotifier.AddListener(GameEvent.CharacterSkinChanged, ExploreCharacterCtrl.OnCharacterSkinChanged, self)
    GameNotifier.AddListener(GameEvent.CharacterStageChanged, ExploreCharacterCtrl.OnCharacterStageChanged, self)
    GameNotifier.AddListener(GameEvent.CharacterLevelChanged, ExploreCharacterCtrl.OnCharacterLevelChanged, self)
    GameNotifier.AddListener(GameEvent.CharacterEquipmentUpgraded, ExploreCharacterCtrl.OnCharacterEquipmentUpgraded, self)
	GameNotifier.AddListener(GameEvent.MarkStateChanged, ExploreCharacterCtrl.OnMarkStateChanged, self)

	local speechId = self:GetSpeechToShow()
    if speechId ~= nil then
        CtrlManager.LaunchPanel(CtrlNames.GoalDialog, {goalSpeechList = {speechId}})   -- depth = 57
    end

	self:CheckTutorial()
end

function ExploreCharacterCtrl:GetSpeechToShow()
    if self._challengeId ~= nil and not GameData.IsChallengeUnlocked(self._challengeId) then
        return ConfigUtils.GetChallengeAcceptSpeech(self._challengeId)
    end

    if self._activityBattleId ~= nil and not GameData.IsActivityBattleUnlocked(self._activityBattleId) then
        return ConfigUtils.GetActivityBattleAcceptSpeech(self._activityBattleId)
    end

    return nil
end

function ExploreCharacterCtrl:CheckCharacterMatchGoal(characterId)
    if _sortPlanetAreaId ~= nil then
        return JumpManager.MatchCharacterOfExploreGoal(characterId, _sortPlanetAreaId)
    elseif self._activityExploreId ~= nil then
        return JumpManager.MatchCharacterOfActivityExploreGoal(characterId)
    end

    return false
end

function ExploreCharacterCtrl:CheckPetMatchGoal(petId)
    if _sortPlanetAreaId ~= nil then
        return JumpManager.MatchPetOfExploreGoal(petId, _sortPlanetAreaId)
    elseif self._activityExploreId ~= nil then
        return JumpManager.MatchPetOfActivityExploreGoal(petId)
    end

    return false
end

function ExploreCharacterCtrl:ConstructExploreEnemyList()
    -- planet area and activity explore has enemy list
    if self._planetAreaId ~= nil then
	   self._areaEnemyList, self._enemyIndexThatNeedElement = ConfigUtils.GetAreaUnlockedEnemyList(self._planetAreaId)
    elseif self._activityExploreId ~= nil then
        self._areaEnemyList = ConfigUtils.GetActivityExploreUnlockedEnemyList(self._activityExploreId)
    end
	-- do sort
	table.sort(self._areaEnemyList, EnemySortFunc)

	for idx = 1, #self._ui.AreaEnemyItems do
		local enemyItem = self._ui.AreaEnemyItems[idx].item
		local hasEnemy = (idx <= #self._areaEnemyList)
		enemyItem:SetActive(hasEnemy)
		if hasEnemy then
			local enemyId = self._areaEnemyList[idx].id
			local unlocked = self._areaEnemyList[idx].unlocked
			local needPower = self._areaEnemyList[idx].power
            local elementCount = self._areaEnemyList[idx].elementCount

			local icon = self._ui.AreaEnemyItems[idx].icon
			UIHelper.SetCharacterIcon(self, icon, enemyId)

            local iconBG = self._ui.AreaEnemyItems[idx].iconBG
            iconBG.spriteName = UIHelper.GetBorderAndBgByItemId(enemyId)

			local lockedMark = self._ui.AreaEnemyItems[idx].locked
			lockedMark:SetActive(not unlocked)

			local elementRoot = self._ui.AreaEnemyItems[idx].elementRoot
            elementRoot:SetActive(unlocked)

            local elementItems = self._ui.AreaEnemyItems[idx].elementItems
            for elementIdx = 1, #elementItems do
                local elementItem = elementItems[elementIdx].item
                elementItem:SetActive(elementIdx <= elementCount)
            end

            if unlocked then
                elementRoot:GetComponent("UITable"):Reposition()
            end
            local hint = self._ui.AreaEnemyItems[idx].hint

			if unlocked then
				icon.color = Color.white
			else
				icon.color = LOCK_ICON_COLOR

                local powerLabel = self._ui.AreaEnemyItems[idx].power
				powerLabel.text = "????"
				powerLabel.color = Color.New(128 / 255, 128 / 255, 128 / 255, 1)
                hint:SetActive(false)
			end

			local matchGoal = JumpManager.MatchEnemyGoal(enemyId)
			local goalHint = self._ui.AreaEnemyItems[idx].goal
			goalHint:SetActive(matchGoal)
		end
	end
end

function ExploreCharacterCtrl:InitializeExploreRules()
	self._exploreRules = {}
	if self._challengeId ~= nil then
		self._exploreRules = ConfigUtils.GetChallengeExploreRules(self._challengeId)
    elseif self._activityBattleId ~= nil then
        self._exploreRules = ConfigUtils.GetActivityBattleRules(self._activityBattleId)
	end

	local text = ""
	for idx = 1, #self._exploreRules do
		local rule = self._exploreRules[idx]
		local descText = tostring(idx).."."..UIHelper.GetExploreRuleShowText(rule, false)
		text = text..descText

		if idx < #self._exploreRules then
			text = text.."\n"
		end
	end

	local hasRule = (#self._exploreRules > 0)
	self._ui.RuleRoot:SetActive(hasRule)
	if hasRule then
		self._ui.RuleLabel.text = text
	end
end

function ExploreCharacterCtrl:GetInitialCharacters()
	if self._characterSelectMode == CharacterSelectMode.Explore then
		return CharacterSelector.CheckSelectedCharacters(self._planetAreaId, self._numLimit)
    elseif self._characterSelectMode == CharacterSelectMode.ActivityExplore then
        return CharacterSelector.CheckActivityExploreSelectedCharacters(self._activityThemeId, self._numLimit)
    elseif self._characterSelectMode == CharacterSelectMode.ActivityBattle then
        return CharacterSelector.CheckActivityBattleSelectedCharacters(self._activityBattleId, self._numLimit)
	elseif self._characterSelectMode == CharacterSelectMode.Challenge then
		return CharacterSelector.CheckChallengeSelectedCharacters(self._challengeId, self._numLimit)
    else
        assert(false, "un-handled character select mode")
	end
end

function ExploreCharacterCtrl:GetInitialPet()
    local pet = nil
    if self._planetAreaId then
        pet = CharacterSelector.CheckSelectedPet(self._planetAreaId)
    elseif self._activityBattleId then
        pet = CharacterSelector.GetActivityBattleSelectedPet(self._activityBattleId)
    elseif self._activityExploreId then
        pet = CharacterSelector.GetActivityExploreSelectedPet(self._activityExploreId)
    elseif self._challengeId then
        pet = CharacterSelector.GetChallengeSelectedPet(self._challengeId)
    end
    return pet
end

function ExploreCharacterCtrl:GetAvatarItem(itemId)
	if itemId == self._selectedPet then
		return self._ui.PetRoot:Find(itemId)
	end

	return self._ui.CharacterRoot:Find(itemId)
end

function ExploreCharacterCtrl:CheckSpaceTravelRetry()
    if self._seasonId == nil then
        self._ui.ButtonExplore:SetActive(true)
        self._ui.SpaceTravelRetryHint:SetActive(false)
        return
    end

    local seasonData = GameData.GetSpaceTravelSeasonData(self._seasonId)
    local canExplore = (seasonData.choiceRetry == 0 or seasonData.leftBattleRetry > 0)
    self._ui.ButtonExplore:SetActive(canExplore)
    self._ui.SpaceTravelRetryHint:SetActive(not canExplore)
end

function ExploreCharacterCtrl:GetItemPrefabAndPool()
	if self._currentMode == ExploreSelectionMode.Character then
		return self._characterItemPrefab, self._ui.CharacterItemPool
	elseif self._currentMode == ExploreSelectionMode.Pet then
		return self._petItemPrefab, self._ui.PetItemPool
	else
		assert(false, "un-handled selection mode: "..tostring(self._currentMode))
	end
end

function ExploreCharacterCtrl:ConstructCharacterItem(item, characterId)
    local sortAbilityId, sortPower = CharacterSelectBaseCtrl.GetSortValue()
    local abilityMap = CharacterSelectBaseCtrl.GetAbilityMapOfCharacter(characterId)
	UIHelper.ConstructCharacterItem(self, item, characterId, abilityMap, sortAbilityId, sortPower)
	local selected = self:IsCharacterSelected(characterId)
	self:RefreshGridItemSelectedState(characterId, selected)
	self:RefreshCharacterStatus(item, characterId)
	-- goal
    local matchGoal = CharacterSelectBaseCtrl.IsCharacterGoalNeeded(characterId)
    local goalMark = item:Find("Mark/Goal").gameObject
    goalMark:SetActive(matchGoal)
    -- marked
    local marked = GameData.IsItemMarked(characterId)
    local markedMark = item:Find("Mark/Marked").gameObject
    markedMark:SetActive(marked)
end

function ExploreCharacterCtrl:ConstructPetItem(item, petId)
    local sortAbilityId, sortPower = CharacterSelectBaseCtrl.GetSortValue()
	UIHelper.ConstructPetItem(self, item, petId, sortAbilityId, sortPower)
	-- level
	local levelLabel = item:Find("Level"):GetComponent("UILabel")
	local petLevel = GameData.GetPetLevel(petId)
	levelLabel.text = string.format(SAFE_LOC("loc_SimpleLevel"), petLevel)
	-- selected
	local selected = (self._selectedPet == petId)
	self:RefreshGridItemSelectedState(petId, selected)
	self:RefreshPetStatus(petId)
	-- goal
	local matchGoal = CharacterSelectBaseCtrl.IsPetGoalNeeded(petId)
	local goalMark = item:Find("Mark/Goal").gameObject
    goalMark:SetActive(matchGoal)
    -- marked
    local marked = GameData.IsItemMarked(petId)
    local markedMark = item:Find("Mark/Marked").gameObject
    markedMark:SetActive(marked)
end

function ExploreCharacterCtrl.OnItemUpdateGlobal(itemObj, itemIndex, itemRealIndex)
	local ctrl = CtrlManager.GetCtrlByName(CtrlNames.ExploreCharacter)
	if ctrl ~= nil then
		ctrl:OnItemUpdate(itemObj, itemIndex, itemRealIndex)
	end
end

function ExploreCharacterCtrl:CalculateFightPower(characters, pet, globalBuffList)
    local characterAbilityMaps = GameData.GetGroupAbilityMap(characters, pet, globalBuffList)
    local fightPowerSkills = GameData.GetGroupSkillMap(
        characters, 
        pet, 
        {
            effectAttribute = EffectAttribute.FightPower,
            globalSkills = globalBuffList,
        }
    )


    local finalFightPowers = 0
    local selectedElementMap = {}
    for k, abilityMap in pairs(characterAbilityMaps) do
        local thisFightPower = ConfigUtils.GetPowerOfAbilityMap(abilityMap)
        local thisSkills = fightPowerSkills[k] or {}
        local thisSkillMap = {k = thisSkills}
        local addPercent = GameData.GetSkillAddPercentValue(thisSkillMap)
        thisFightPower = Helper.RoundAndCeil(thisFightPower * (1 + addPercent))
        thisFightPower = math.max(thisFightPower, 1)
        finalFightPowers = finalFightPowers + thisFightPower

        local elementId = ConfigUtils.GetElementOfItem(k)
        local preCount = selectedElementMap[elementId] or 0
        selectedElementMap[elementId] = preCount + 1
    end

    return finalFightPowers, selectedElementMap
end

function ExploreCharacterCtrl:RefreshCharacterAbilities()
	-- character and pet
	local selectedList = self:GetSelectedCharacterList()
    local globalBuffList = self:GetArenaAndCoupleSkills()
    local finalFightPowers, selectedElementMap = self:CalculateFightPower(selectedList, self._selectedPet, globalBuffList)
    
    self._fightPowers = finalFightPowers
	self._ui.CharacterPower.text = "战斗力 "..tostring(finalFightPowers)
    self._matchedEnemyList = {}

    -- area or activity explore show the enemy abilities
	if self._characterSelectMode == CharacterSelectMode.Explore or self._characterSelectMode == CharacterSelectMode.ActivityExplore then
		-- enemy power
		local enemyFightPowerSkills = GameData.GetGroupSkillMap(
			selectedList, 
			self._selectedPet, 
			{
				effectAttribute = EffectAttribute.EnemyFightPower, 
			}
		)

		for idx = 1, #self._ui.AreaEnemyItems do
			local hasEnemy = (idx <= #self._areaEnemyList)
			if hasEnemy then
				local unlocked = self._areaEnemyList[idx].unlocked
				if unlocked then
					local enemyId = self._areaEnemyList[idx].id
					local needPower = self._areaEnemyList[idx].power
					local skillAddPercet = GameData.GetEnemyFightPowerSkillValue(enemyFightPowerSkills, enemyId)
					needPower = Helper.RoundAndCeil(needPower * (1 + skillAddPercet))
					needPower = math.max(needPower, 1)

					local powerLabel = self._ui.AreaEnemyItems[idx].power
					powerLabel.text = tostring(needPower)

                    local needElementMap = self._areaEnemyList[idx].elementMap
                    local needElementCount = self._areaEnemyList[idx].elementCount

                    local elementResultList = {}
                    for elementId, elementNum in pairs(needElementMap) do
                        local selectedCount = selectedElementMap[elementId] or 0
                        for m = 1, elementNum do
                            table.insert(elementResultList, {id = elementId, match = (m <= selectedCount)})
                        end
                    end

                    local elementItems = self._ui.AreaEnemyItems[idx].elementItems
                    local allElementMatch = false
                    local matchCount = 0
                    for elementIdx = 1, needElementCount do
                        local elementIcon = elementItems[elementIdx].icon
                        local elementId = elementResultList[elementIdx].id
                        local elementMatch = elementResultList[elementIdx].match
                        local elementCode = ConfigUtils.GetElementCode(elementId)
                        if elementMatch then
                            matchCount = matchCount + 1
                            elementIcon.spriteName = elementCode.."_enable"
                        else
                            elementIcon.spriteName = elementCode.."_disable"
                        end
                    end
                    allElementMatch = matchCount == needElementCount
                    --XDebug.Log("LZ", "allElementMatch", allElementMatch)
                    local hint = self._ui.AreaEnemyItems[idx].hint
                    hint:SetActive(allElementMatch and self._fightPowers >= needPower)

                    if self._fightPowers < needPower then
                        powerLabel.color = Color.red
                    else
                        powerLabel.color = Color.New(109 / 255, 1, 1, 1)

                    end

                    if allElementMatch and self._fightPowers >= needPower then
                        table.insert(self._matchedEnemyList, enemyId)
                    end
				end
			end
		end
	end
end

function ExploreCharacterCtrl:ChangeSelectPet(newPetId, hintSkill)
	if self._selectedPet ~= nil then
		self:RefreshGridItemSelectedState(self._selectedPet, false)
		local item = self._ui.PetRoot:Find(self._selectedPet)
		if item ~= nil then
			item.parent = self._ui.PetPool
		end
	end

	self._selectedPet = newPetId

	if self._selectedPet ~= nil then
		self:RefreshGridItemSelectedState(self._selectedPet, true)
		local petItem = self._ui.PetPool:Find(self._selectedPet)
		if petItem == nil then
			petItem = self:CreateNewPetObj(self._selectedPet)
		else
			petItem.parent = self._ui.PetRoot
		end

		Helper.CheckDirection(petItem, 1)
		local skeletonAnimation = petItem:GetComponent("SkeletonAnimation")
		Helper.PlayAnimation(skeletonAnimation, CharacterAnimations.Idle, true)
	end

	self:OnSelectedCharacterChanged(hintSkill)
end

function ExploreCharacterCtrl:CreateNewPetObj(petId)
	local prefabName, prefabBundle = ConfigUtils.GetPetPrefab(petId)
	local prefab = self:DynamicLoadAsset(prefabBundle, prefabName)
	local petObj = Helper.NewObject(prefab, self._ui.PetRoot, 50)
	petObj.name = tostring(petId)
	petItem = petObj.transform

	NGUITools.AddRawWidget(petObj, 0)
	NGUITools.AddWidgetCollider(petObj)

	local collider = petObj:GetComponent("BoxCollider")
	collider.size = Vector3.New(1.2, 1.5, 0)
	collider.center = Vector3.New(0, 0.75, 0)

	CtrlManager.AddClick(self, petObj)

	return petItem
end

function ExploreCharacterCtrl:GetPetListOfExplore()
    local ret = {}

    if self._matchedEnemyList == nil then
        return ret
    end

    for idx = 1, #self._matchedEnemyList do
        local enemyId = self._matchedEnemyList[idx]
        local petId = ConfigUtils.GetPetOfEnemy(enemyId)
        ret[idx] = petId
    end

    return ret
end

function ExploreCharacterCtrl:OnCancelSpaceTravelConfirm()
    assert(self._seasonId ~= nil, "season id is invalid")
    -- check valid first
    local isValid = CtrlManager.CheckSpaceTravelSeasonValid(self._seasonId, true, true)
    if not isValid then
        return
    end
    -- do cancel
    local seasonData = GameData.GetSpaceTravelSeasonData(self._seasonId)
    local scoreCapId = GameData.GetScoreCapOfSpaceTravelSeason(self._seasonId, seasonData.scoreCap)
    NetManager.Send('STChoiceCancel', {
        STSeasonID = self._seasonId, 
        STScoreCapID = scoreCapId,
        ChoiceId = self._choiceId,
    }, ExploreCharacterCtrl.OnHandleProto, self)
end

function ExploreCharacterCtrl:RefreshSortState()
    local sortAbilityId, sortPower = CharacterSelectBaseCtrl.GetSortValue()

    for k, v in pairs(self._ui.SortAbilityItems) do
        local unselected = (sortAbilityId == nil or sortAbilityId ~= k)
        v.selected:SetActive(not unselected)
        v.unselected:SetActive(unselected)
    end

    self._ui.SortAbilityRoot:GetComponent("UITable"):Reposition()

    self._ui.SortPowerSelected:SetActive(sortPower)
    self._ui.SortPowerUnselected:SetActive(not sortPower)
end
--------------------------------------------------------
-- on clicked
function ExploreCharacterCtrl:OnClicked(go)
	if go == self._ui.ButtonClose then
		SoundSystem.PlayUICancelSound()
        if self._seasonId ~= nil then
            -- check valid first
            local isValid = CtrlManager.CheckSpaceTravelSeasonValid(self._seasonId, true)
            if not isValid then
                return true
            end

            CtrlManager.ShowMessageBox({message = SAFE_LOC("确认放弃挑战?"), single = false, onConfirm = ExploreCharacterCtrl.OnCancelSpaceTravelConfirm, receiver = self})
        else
		    CtrlManager:PopPanel()	-- explore character
        end
	elseif go == self._ui.ButtonExplore then
        if self._activityThemeId ~= nil and not GameData.IsActivityThemeValid(self._activityThemeId) then
            CtrlManager.ShowMessageBox({message = SAFE_LOC("活动已结束"), single = true})
            return true
        end

		local selectedRoleNum = self:GetSelectedCharacterNum()
		if selectedRoleNum == 0 then
			SoundSystem.PlayWarningSound()
			CtrlManager.ShowMessageBox({message = SAFE_LOC("请选择角色"), single = true})
			return true
		end

		local characterList = self:GetSelectedCharacterList()
		local matchRule, notMatchHint = ConfigUtils.CheckTeamExploreRules(self._exploreRules, characterList, self._fightPowers)
		if not matchRule then
			SoundSystem.PlayWarningSound()
			CtrlManager.ShowMessageBox({message = notMatchHint, single = true})
			return true
		end

		SoundSystem.PlayUIClickSound()
        self:MuteSound()
		local petId = self._selectedPet
        -- area or activity epxlore
		if self._planetAreaId ~= nil or self._activityExploreId ~= nil then
            local petListToCatch = self:GetPetListOfExplore()
            local globalBuffList = self:GetArenaAndCoupleSkills()
			CtrlManager.OpenPanel(CtrlNames.ExploreItem, {
				areaId = self._planetAreaId,
                themeId = self._activityThemeId,
				characters = characterList,
				petId = petId or INVALID_ID,
                petList = petListToCatch,
                globalBuffs = globalBuffList,
			})
		else
            local globalBuffList = self:GetArenaAndCoupleSkills()
            local verifyData = ConfigUtils.ConstructBattleVerityData(characterList, petId)

            if self._seasonId ~= nil then
                -- space travel challenge
                -- check valid first
                local isValid = CtrlManager.CheckSpaceTravelSeasonValid(self._seasonId, true)
                if not isValid then
                    return true
                end

                local seasonData = GameData.GetSpaceTravelSeasonData(self._seasonId)
                local scoreCapId = GameData.GetScoreCapOfSpaceTravelSeason(self._seasonId, seasonData.scoreCap)
                NetManager.Send("STChoiceChallenge", {
                    STSeasonID = self._seasonId, 
                    STScoreCapID = scoreCapId,
                    ChoiceId = self._choiceId,
                    ChallengeId = self._challengeId, 
                    CharacterList = characterList, 
                    PetId = petId or INVALID_ID,
                    GlobalBuffs = globalBuffList,
                    VerifyData = verifyData,
                }, ExploreCharacterCtrl.OnHandleProto, self)
            elseif self._challengeId ~= nil then
                -- challenge
    			NetManager.Send("Challenge", {
    				ChallengeId = self._challengeId, 
    				CharacterList = characterList, 
    				PetId = petId or INVALID_ID,
                    GlobalBuffs = globalBuffList,
                    VerifyData = verifyData,
    			}, ExploreCharacterCtrl.OnHandleProto, self)
            elseif self._activityBattleId ~= nil then
                -- activity battle
                NetManager.Send("ActivityBattle", {
                    ActivityThemeId = self._activityThemeId, 
                    ActivityBattleId = self._activityBattleId,
                    CharacterList = characterList, 
                    PetId = petId or INVALID_ID,
                    GlobalBuffs = globalBuffList,
                    VerifyData = verifyData,
                }, ExploreCharacterCtrl.OnHandleProto, self)
            end
		end
	elseif go.transform.parent == self._ui.ItemGrid then
		local itemId = tonumber(go.name)

		if self._currentMode == ExploreSelectionMode.Character then
			-- tag not fit
            local selectableMap = CharacterSelectBaseCtrl.GetCharacterSelectableMap()
			if not selectableMap[itemId] then
				SoundSystem.PlayWarningSound()
				return true
			end

            local isBusy, characterStatus = GameData.IsBusyCharacter(itemId, self._characterSelectMode)
			if not isBusy then
				local characterIdx = self:GetExploreCharacterIdx(itemId)
				if characterIdx == nil then
					if #self._selectedCharacters < self._numLimit then
						SoundSystem.PlayUIClickSound()
						self:AppendExploreCharacter(itemId)
					else
						SoundSystem.PlayWarningSound()
						self:NotifyCharacterFull()
					end
				else
					SoundSystem.PlayUIClickSound()
					self:RemoveExploreCharacterAt(characterIdx)
				end
			else
                if characterStatus == CharacterStatus.WorkShop then
                    SoundSystem.PlayUIClickSound()
                    CtrlManager.ShowMessageBox({message = SAFE_LOC("正在打工中\n是否强制换下?"), data = itemId, single = false, onConfirm = ExploreCharacterCtrl.OnReplaceWorkShopCharacter, receiver = self})
                else
				    SoundSystem.PlayWarningSound()
                end
			end
		elseif self._currentMode == ExploreSelectionMode.Pet then
			if self._selectedPet == itemId then
				SoundSystem.PlayUIClickSound()
				self:ChangeSelectPet(nil, true)
			else
                local isBusy = GameData.IsBusyPet(itemId, self._characterSelectMode)
				if not isBusy then
					SoundSystem.PlayUIClickSound()
					self:ChangeSelectPet(itemId, true)
					self._selectedPet = itemId
				else
					SoundSystem.PlayWarningSound()
				end
			end
		end
	elseif go.transform.parent == self._ui.CharacterRoot then
		SoundSystem.PlayUIClickSound()
		local characterId = tonumber(go.name)
		local characterIdx = self:GetExploreCharacterIdx(characterId)
		assert(characterIdx ~= nil, "clicked character but not in explore character list: "..go.name)
		self:RemoveExploreCharacterAt(characterIdx)
	elseif go.transform.parent == self._ui.PetRoot then
		SoundSystem.PlayUIClickSound()
		self:ChangeSelectPet(nil, true)
	elseif go == self._ui.ButtonCharacter.gameObject then
		SoundSystem.PlaySwitchSound()
        CharacterSelectBaseCtrl.ResetFilterName()
		self:RecycleGridItems()
		self._currentMode = ExploreSelectionMode.Character
		self:OnSelectionModeChanged()
	elseif go == self._ui.ButtonPet.gameObject then
		SoundSystem.PlaySwitchSound()
        CharacterSelectBaseCtrl.ResetFilterName()
		self:RecycleGridItems()
		self._currentMode = ExploreSelectionMode.Pet
		self:OnSelectionModeChanged()
    elseif go == self._ui.ButtonTeam.gameObject then
        SoundSystem.PlaySwitchSound()
        CharacterSelectBaseCtrl.ResetFilterName()
        self:RecycleGridItems()
        self._currentMode = ExploreSelectionMode.Team
        self:OnSelectionModeChanged()
        -- team mode no need sort
        if self._sortOn then
            self._sortOn = false
            self._ui.SortRoot:SetActive(false)
        end
    elseif go == self._ui.ButtonCouple.gameObject then
        SoundSystem.PlaySwitchSound()
        CharacterSelectBaseCtrl.ResetFilterName()
        self:RecycleGridItems()
        self._currentMode = ExploreSelectionMode.Couple
        self:OnSelectionModeChanged()
        -- team mode no need sort
        if self._sortOn then
            self._sortOn = false
            self._ui.SortRoot:SetActive(false)
        end
	elseif go == self._ui.ChallengeEnemyIcon.gameObject then
		if self._challengeId ~= nil then
			SoundSystem.PlayUIClickSound()
			local itemId, itemLevel = ConfigUtils.GetLastEnemyOfChallenge(self._challengeId)
			CtrlManager.ShowItemDetail({itemId = itemId, itemLevel = itemLevel})
        elseif self._activityBattleId ~= nil then
            SoundSystem.PlayUIClickSound()
            local itemId, itemLevel = ConfigUtils.GetLastEnemyOfActivityBattle(self._activityBattleId)
            CtrlManager.ShowItemDetail({itemId = itemId, itemLevel = itemLevel})
		end
	elseif Helper.StartWith(go.name, "Enemy_") then
		local names = Helper.StringSplit(go.name)
		assert(#names == 2, "invalid enemy item name: "..tostring(go.name))
		local idx = tonumber(names[2])
		local enemyId = self._areaEnemyList[idx].id
		local enemyLevel = self._areaEnemyList[idx].level
		SoundSystem.PlayUIClickSound()
		CtrlManager.ShowItemDetail({itemId = enemyId, itemLevel = enemyLevel})
	elseif go == self._ui.ButtonFilter then
        SoundSystem.PlayUIClickSound()
        self:ShowFilterPanel()
    elseif go == self._ui.ButtonSort then
        SoundSystem.PlayUIClickSound()
        self._sortOn = not self._sortOn
        self._ui.SortRoot:SetActive(self._sortOn)
        if self._sortOn then
            self:RefreshSortState()
        end
    elseif go.transform.parent == self._ui.SortAbilityRoot then
        SoundSystem.PlayUIClickSound()
        local newAbilityId = tonumber(go.name)
        local sortAbilityId, sortPower = CharacterSelectBaseCtrl.GetSortValue()
        if newAbilityId == sortAbilityId then
            sortAbilityId = nil
        else
            sortAbilityId = newAbilityId
        end
        sortPower = false
        CharacterSelectBaseCtrl.SetSortValue(sortAbilityId, sortPower)
        self:RecycleGridItems()
        self:OnSelectionModeChanged()
        self:RefreshSortState()
    elseif go == self._ui.SortPower then
        SoundSystem.PlayUIClickSound()
        local sortAbilityId, sortPower = CharacterSelectBaseCtrl.GetSortValue()
        sortAbilityId = nil
        sortPower = not sortPower
        CharacterSelectBaseCtrl.SetSortValue(sortAbilityId, sortPower)
        self:RecycleGridItems()
        self:OnSelectionModeChanged()
        self:RefreshSortState()
    elseif go == self._ui.ButtonTeamSort then
        if self._teamMode == TeamEditMode.Normal then
            SoundSystem.PlayUIClickSound()
            self:StartSortTeam()
        else
            SoundSystem.PlayWarningSound()
        end
    elseif go == self._ui.ButtonTeamDelete then
        if self._teamMode == TeamEditMode.Normal then
            SoundSystem.PlayUIClickSound()
            self:StartDeleteTeam()
        else
            SoundSystem.PlayWarningSound()
        end
    elseif go == self._ui.ButtonTeamSortConfirm then
        SoundSystem.PlayUIClickSound()
        self:BackToNormalTeam()
    elseif go == self._ui.ButtonTeamDeleteConfirm then
        SoundSystem.PlayUIClickSound()
        self:BackToNormalTeam()
    elseif go.transform.parent == self._ui.TeamGrid then
        if self._teamMode == TeamEditMode.Normal then
            local idx = tonumber(go.name)
            self:UseTeam(idx)
        end
    elseif go.transform.parent == self._ui.CoupleGrid then
        local coupleId = tonumber(go.name)
        self:UseCouple(coupleId)
    elseif go.name == "ButtonDelete" then
        SoundSystem.PlayUIClickSound()
        local idx = tonumber(go.transform.parent.gameObject.name)
        self:DeleteTeam(idx)
    elseif go.name == "ButtonRename" then
        local idx = tonumber(go.transform.parent.gameObject.name)
        self:RenameTeam(idx)
    elseif go.name == "ButtonMoveUp" then
        SoundSystem.PlayUIClickSound()
        local idx = tonumber(go.transform.parent.gameObject.name)
        self:MoveUpTeam(idx)
    elseif go.name == "ButtonMoveDown" then
        SoundSystem.PlayUIClickSound()
        local idx = tonumber(go.transform.parent.gameObject.name)
        self:MoveDownTeam(idx)
    elseif go.name == "ButtonSave" or go.name == "ButtonReplace" then
        SoundSystem.PlayUIClickSound()
        local idx = tonumber(go.transform.parent.gameObject.name)
        local characters = self:GetSelectedCharacterList()
        self:ReplaceTeam(idx, characters, self._selectedPet)
	end

	return true
end

-- on pressed
function ExploreCharacterCtrl:OnPressed(go, pressed, isLong)
	if pressed and isLong then
		if go.transform.parent == self._ui.ItemGrid then
			local itemId = tonumber(go.name)
			local itemType = ConfigUtils.GetItemTypeFromId(itemId)
			if itemType == ItemType.Character then
				SoundSystem.PlayUIClickSound()
				CtrlManager.OpenPanel(CtrlNames.CharacterQuickDetail, {characterId = itemId})
			elseif itemType == ItemType.Pet then
				SoundSystem.PlayUIClickSound()
				CtrlManager.ShowItemDetail({itemId = itemId, callback = ExploreCharacterCtrl.HandleSwitchItem, receiver = self})
			end
		elseif go.transform.parent == self._ui.CharacterRoot then
			local characterId = tonumber(go.name)
			self:StartDrag(characterId)
		end
	elseif not pressed and self._dragCharacterId ~= nil then
		self:EndDrag()
	end
end

function ExploreCharacterCtrl:HandleSwitchItem(itemId, isNext)
    local totalCount = #self._itemList
    local index = Helper.IndexOfArray(self._itemList, itemId)
    if isNext then
        index = index + 1
        if index > totalCount then
            index = 1
        end
    else
        index = index - 1
        if index < 1 then
            index = totalCount
        end
    end

    return self._itemList[index]
end

function ExploreCharacterCtrl:OnReplaceWorkShopCharacter(characterId)
    local busyCharacters = GameData.GetBusyCharacters()
    local data = busyCharacters[characterId]
    assert(data ~= nil and data.status == CharacterStatus.WorkShop, "character status is not corrent: "..tostring(characterId))
    local workShopId = data.value
    local characters = GameData.GetCharactersOfWorkShop(workShopId)
    local finalCharacterList = {}
    for idx = 1, #characters do
        if characters[idx] ~= characterId then
            table.insert(finalCharacterList, characters[idx])
        end
    end

    if #finalCharacterList == 0 then
        finalCharacterList = nil
    end

    NetManager.Send("WorkShopTeamSet", 
        {
            WorkShopId = workShopId, 
            CharacterList = finalCharacterList,
            Character = characterId,
        }, 
        ExploreCharacterCtrl.OnHandleProto, self
    )
end

function ExploreCharacterCtrl:OnHandleProto(proto, data, requestData)
	if proto == "Challenge" then
		local challengeId = requestData.ChallengeId
		local characterList = requestData.CharacterList
		local petId = requestData.PetId
        local globalBuffs = requestData.GlobalBuffs
		local challengeData = data.ChallengeData
		local seed = data.ServerTime
        
		CtrlManager.OpenPanel(CtrlNames.Battle, {
			challengeId = challengeId,
			characterList = characterList,
			petId = petId,
			challengeData = challengeData,
            globalBuffs = globalBuffs,
			seed = seed,
		})
    elseif proto == "ActivityBattle" then
        local themeId = requestData.ActivityThemeId
        local battleId = requestData.ActivityBattleId
        local characterList = requestData.CharacterList
        local petId = requestData.PetId
        local globalBuffs = requestData.GlobalBuffs
        local challengeData = data.ChallengeData
        local seed = data.ServerTime
        
        CtrlManager.OpenPanel(CtrlNames.Battle, {
            themeId = themeId,
            battleId = battleId,
            characterList = characterList,
            petId = petId,
            challengeData = challengeData,
            globalBuffs = globalBuffs,
            seed = seed,
        })
    elseif proto == "WorkShopTeamSet" then
        GameData.SetDataOfWorkShop(data.WorkShopStatus)
        GameData.MarkBusyCharacterDirty()
        GameData.CheckAndHintGoalsOfCurrentCountType()
        GameNotifier.Notify(GameEvent.WorkShopListChanged)

        local characterId = requestData.Character
        self:OnCharacterStatusChanged(characterId)
    elseif proto == "STChoiceChallenge" then
        local seasonId = requestData.STSeasonID
        local choiceId = requestData.ChoiceId
        local challengeId = requestData.ChallengeId
        local characterList = requestData.CharacterList
        local petId = requestData.PetId
        local globalBuffs = requestData.GlobalBuffs
        local challengeData = data.ChallengeData
        local seed = data.ServerTime

        CtrlManager.OpenPanel(CtrlNames.Battle, {
            seasonId = seasonId,
            choiceId = choiceId,
            challengeId = challengeId,
            characterList = characterList,
            petId = petId,
            challengeData = challengeData,
            globalBuffs = globalBuffs,
            seed = seed,
        })
    elseif proto == "STChoiceCancel" then
        local seasonId = requestData.STSeasonID
        local choiceId = requestData.ChoiceId

        local dropList = GameData.SettleSpaceTravelChoiceCancel(seasonId, choiceId)
        local parameter = nil
        if #dropList > 0 then
            parameter = GameData.ConstructSpaceTravelChoiceResultParameter(seasonId, dropList, data)
        end
        -- pop panel
        CtrlManager.PopPanel()
        if parameter ~= nil then
            CtrlManager.OpenPanel(CtrlNames.SpaceTravelChoiceResult, parameter)
        else
            -- sync base data
            GameData.SyncSpaceTravelSeasonBaseData(seasonId, data)
        end
	end
end
--------------------------------------------------------
-- skills
function ExploreCharacterCtrl:GetSkillListToScope()
	local ret = {}

    -- area or activity explore
	if self._planetAreaId ~= nil or self._activityExploreId ~= nil then
		-- explore global skills	
		local attributes = {}
		attributes[EffectAttribute.ExploreTime] = 1
		attributes[EffectAttribute.EnemyDropChance] = 1
		attributes[EffectAttribute.GoodsDropChance] = 1
		attributes[EffectAttribute.GoodsDropNumber] = 1
		attributes[EffectAttribute.EnemyFightPower] = 1
		attributes[EffectAttribute.PetCatchSuccessChance] = 1
		attributes[EffectAttribute.PetCatchDamageChance] = 1

		for idx = 1, #self._selectedCharacters do
			local characterId = self._selectedCharacters[idx].id
			local skillList = GameData.GetCharacterSkillList(characterId)
			for skillIdx = 1, #skillList do
				local skillId = skillList[skillIdx].id
				local skillValue = skillList[skillIdx].value
				local effectAttribute = ConfigUtils.GetSkillEffectAttribute(skillId)
				if attributes[effectAttribute] ~= nil then
					table.insert(ret, {id = skillId, value = skillValue, source = characterId})
				end
			end
		end

		if ConfigUtils.IsValidItem(self._selectedPet) then
			local skillList = GameData.GetPetSkillList(self._selectedPet)
			for skillIdx = 1, #skillList do
				local skillId = skillList[skillIdx].id
				local skillValue = skillList[skillIdx].value
				local effectAttribute = ConfigUtils.GetSkillEffectAttribute(skillId)
				if attributes[effectAttribute] ~= nil then
					table.insert(ret, {id = skillId, value = skillValue, source = self._selectedPet})
				end
			end
		end
	else
		-- challenge scope skills
	end

	return ret
end

function ExploreCharacterCtrl:HasPetPositionHint()
    if self._characterSelectMode == CharacterSelectMode.Explore or self._characterSelectMode == CharacterSelectMode.Challenge or self._characterSelectMode == CharacterSelectMode.ActivityBattle or self._characterSelectMode == CharacterSelectMode.ActivityExplore then
        return true
    else
        return false
    end
end

function ExploreCharacterCtrl:GetSelectedPet()
    if self:HasPetPositionHint() then
        return self._selectedPet
    else
        return nil
    end

end

function ExploreCharacterCtrl:GetSkillMapOfMembers()
	local attributes = {}
	attributes[EffectAttribute.Ability] = 1
	-- area or activity explore
    if self._planetAreaId ~= nil or self._activityExploreId ~= nil then
		-- explore skills	
		attributes[EffectAttribute.FightPower] = 1
	else
		-- challenge skills
		attributes[EffectAttribute.CritChance] = 1
		attributes[EffectAttribute.CritDamage] = 1
		attributes[EffectAttribute.DamageFromCritDamage] = 1
		attributes[EffectAttribute.ExtraAttack] = 1
		attributes[EffectAttribute.Dodge] = 1
        attributes[EffectAttribute.DodgeIgnore] = 1
		attributes[EffectAttribute.DamageToElement] = 1
		attributes[EffectAttribute.DamageFromElement] = 1
		attributes[EffectAttribute.EnemyAbility] = 1
        attributes[EffectAttribute.SpecificEnemyAbility] = 1
	end

	local characterList = {}
	for idx = 1, #self._selectedCharacters do
		characterList[idx] = self._selectedCharacters[idx].id
	end

	local ret = {}

	for idx = 1, #characterList do
		local characterId = characterList[idx]
		local skillList = GameData.GetCharacterSkillList(characterId)
		for skillIdx = 1, #skillList do
			local skillId = skillList[skillIdx].id
			local skillValue = skillList[skillIdx].value
			if self:ShouldShowMemberSkill(skillId, attributes) then
				local isMatch, matchCount = GameData.IsSkillConditionMatch(skillId, characterId, idx, characterList)
				if isMatch then
					local effectMembers = GameData.GetSkillEffectedMembers(skillId, characterId, idx, characterList)
					if ret[characterId] == nil then
						ret[characterId] = {}
					end
					table.insert(ret[characterId], {id = skillId, value = skillValue, target = effectMembers, matchCount = matchCount})
				end
			end
		end
	end

	if ConfigUtils.IsValidItem(self._selectedPet) then
		local skillList = GameData.GetPetSkillList(self._selectedPet)
		for skillIdx = 1, #skillList do
			local skillId = skillList[skillIdx].id
			local skillValue = skillList[skillIdx].value
			if self:ShouldShowMemberSkill(skillId, attributes) then
				local isMatch, matchCount = GameData.IsSkillConditionMatch(skillId, self._selectedPet, nil, characterList)
				if isMatch then
					local effectMembers = GameData.GetSkillEffectedMembers(skillId, self._selectedPet, nil, characterList)
					if ret[self._selectedPet] == nil then
						ret[self._selectedPet] = {}
					end
					table.insert(ret[self._selectedPet], {id = skillId, value = skillValue, target = effectMembers, matchCount = matchCount})
				end
			end
		end
	end

	return ret
end

function ExploreCharacterCtrl:FindAvatarItem(memberId)
	if memberId == nil then
		return nil
	end

	if memberId == self._selectedPet then
		local petItem = self._ui.PetRoot:Find(memberId)
        local petSkeletonAnimation = petItem:GetComponent("SkeletonAnimation")
        return petItem, petSkeletonAnimation
	end

	for idx = 1, #self._selectedCharacters do
		if self._selectedCharacters[idx].id == memberId then
			return self._selectedCharacters[idx].item, self._selectedCharacters[idx].skeletonAnimation
		end
	end

	return nil
end

function ExploreCharacterCtrl:IsMemberStillSelected(memberId)
	if memberId == nil then
		return false
	end

	if memberId == self._selectedPet then
		return true
	end

	for idx = 1, #self._selectedCharacters do
		if self._selectedCharacters[idx].id == memberId then
			return true
		end
	end

	return false
end

function ExploreCharacterCtrl:MatchableAbilityMap()
	local ret = {}

	ret[AbilityType.HP] = 1
	ret[AbilityType.ATK] = 1
	ret[AbilityType.DEF] = 1
	ret[AbilityType.LUK] = 1

	return ret
end
--------------------------------------------------------
function ExploreCharacterCtrl:GetCoupleKey()
    -- area or activity explore
    if self._planetAreaId ~= nil or self._activityExploreId ~= nil then
        return CoupleNodeKey.Explore
    else
        return CoupleNodeKey.Challenge
    end
end
--------------------------------------------------------
-- tutorial
function ExploreCharacterCtrl:GetFirstEnemyItem()
	return self._ui.AreaEnemyItems[1].item.transform
end

function ExploreCharacterCtrl:CheckTutorial()
	local tutorials = {}

	if GameData.IsTutorialNotFinished(Tutorials.Tutorial_1_9) then
		local enemyItem = self:GetFirstEnemyItem()
		local roleItem = self._ui.ItemGrid:Find(TutorialConstData.WuwuId)
		local position = self._ui.Camera:WorldToScreenPoint(roleItem.position)
		tutorials[1] = {event = Tutorials.Tutorial_1_3, position = position, sender = self}
		roleItem = self._ui.ItemGrid:Find(TutorialConstData.QiqiId)
		position = self._ui.Camera:WorldToScreenPoint(roleItem.position)
		tutorials[2] = {event = Tutorials.Tutorial_1_5, position = position, sender = self}
		position = self._ui.Camera:WorldToScreenPoint(self._ui.ExploreTutorialMark.position)
		tutorials[3] = {event = Tutorials.Tutorial_1_7, position = position, sender = self}
	elseif GameData.IsTutorialNotFinished(Tutorials.Tutorial_2_6) and GameData.IsGoalRunning(TutorialConstData.ChallengeGoal) then
		local roleItem = self._ui.ItemGrid:Find(TutorialConstData.WuwuId)
		local position = self._ui.Camera:WorldToScreenPoint(roleItem.position)
		tutorials[1] = {event = Tutorials.Tutorial_2_2, position = position, sender = self}
		roleItem = self._ui.ItemGrid:Find(TutorialConstData.QiqiId)
		position = self._ui.Camera:WorldToScreenPoint(roleItem.position)
		tutorials[2] = {event = Tutorials.Tutorial_2_4, position = position, sender = self}
		position = self._ui.Camera:WorldToScreenPoint(self._ui.ExploreTutorialMark.position)
		tutorials[3] = {event = Tutorials.Tutorial_2_6, position = position, sender = self}
    elseif self._enemyIndexThatNeedElement ~= nil and GameData.IsTutorialNotFinished(Tutorials.Tutorial_10_1) then
        local enemyItem = self._ui.AreaEnemyItems[self._enemyIndexThatNeedElement].item
        local position = self._ui.Camera:WorldToScreenPoint(enemyItem.transform.position)
        tutorials[1] = {event = Tutorials.Tutorial_10_1, position = position, sender = self}
        tutorials[2] = {event = Tutorials.Tutorial_10_2, position = position, sender = self}
        position = self._ui.Camera:WorldToScreenPoint(self._ui.ButtonPet.transform.position)
        tutorials[3] = {event = Tutorials.Tutorial_10_3, position = position, sender = self}
	end

	if #tutorials > 0 then
		CtrlManager.ShowTutorials(tutorials)
	end

	return #tutorials > 0
end

function ExploreCharacterCtrl:OnTutorialClicked(tutorial)
	if tutorial == Tutorials.Tutorial_1_3 or tutorial == Tutorials.Tutorial_2_2 then
		local roleItem = self._ui.ItemGrid:Find(TutorialConstData.WuwuId)
		self:OnClicked(roleItem.gameObject)
	elseif tutorial == Tutorials.Tutorial_1_5 or tutorial == Tutorials.Tutorial_2_4 then
		local roleItem = self._ui.ItemGrid:Find(TutorialConstData.QiqiId)
		self:OnClicked(roleItem.gameObject)
	elseif tutorial == Tutorials.Tutorial_1_7 or tutorial == Tutorials.Tutorial_2_6 then
		self:OnClicked(self._ui.ButtonExplore)
    elseif tutorial == Tutorials.Tutorial_10_3 then
        SoundSystem.PlayUIClickSound()
        GameData.SyncTutorialData()
	else
		SoundSystem.PlayUIClickSound()
	end
end
--------------------------------------------------------