require "FreakPlanet/View/ClothesShopSkinDetailPanel"

local class = require "FreakPlanet/Utils/middleclass"
ClothesShopSkinDetailCtrl  = class(CtrlNames.ClothesShopSkinDetail, BaseCtrl)

-- load the ui prefab
function ClothesShopSkinDetailCtrl:LoadPanel()
	self:CreatePanel("ClothesShopSkinDetail")
end

-- construct ui panel data
function ClothesShopSkinDetailCtrl:ConstructUI(obj)
	self._ui = ClothesShopSkinDetailPanel.Init(obj)
	self.ShopId = self._parameter.ShopId
	self.ProductId = self._parameter.ProductId
end

-- fill ui with the data
function ClothesShopSkinDetailCtrl:SetupUI()
	local ui = self._ui

	local ui = self._ui
	local productId = self.ProductId

	self.TimeLabels = {}

	local skinId = ConfigUtils.GetClothesShopProductItem(productId)
	local characterId = ConfigUtils.GetCharacterOfSkin(skinId)

	ui.txtName.text = ConfigUtils.GetSkinName(skinId)
	ui.txtCharacter.text = string.format("%s专属装备", ConfigUtils.GetCharacterName(characterId))
	ui.txtDesc.text = ConfigUtils.GetCharacterDesc(characterId)
	ui.txtSkillDesc.text = ConfigUtils.GetSkinSkillDesc(skinId)
	self:SetupAvatar(characterId, skinId, ui.AvatarNode)

	local isUnlock = GameData.IsSkinUnlocked(skinId)
	ui.txtDesc.text = ConfigUtils.GetSkinDesc(skinId, isUnlock)
	local isEquip = GameData.GetCharacterSkin(characterId) == skinId
	ui.objEquiped:SetActive(isEquip)

	if isUnlock then
		ui.ButtonLayout:SetActive(false)
	else
		ui.ButtonLayout:SetActive(true)
		self:UpdateUIBuyButtons()
	end

	CtrlManager.AddClick(self, ui.btnBlocker)
	CtrlManager.AddClick(self, ui.btnBuy1)
	CtrlManager.AddClick(self, ui.btnBuy2)
	CtrlManager.AddClick(self, ui.btnBuy3)

	GameNotifier.AddListener(GameEvent.ClothesShopStateUpdated, ClothesShopSkinDetailCtrl.UpdateUIBuyButtons, self)
end

function ClothesShopSkinDetailCtrl:DestroyImpl()
	GameNotifier.RemoveListener(GameEvent.ClothesShopStateUpdated, ClothesShopSkinDetailCtrl.UpdateUIBuyButtons, self)
end

--
function ClothesShopSkinDetailCtrl:UpdateImpl(deltaTime)

end

--
function ClothesShopSkinDetailCtrl:UpdateImplBySecond(deltaTime)
	self:UpdateUILeftTime()
end

-- on clicked
function ClothesShopSkinDetailCtrl:OnClicked(go)
	local ui = self._ui
	if go == ui.btnBlocker then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
	elseif go == ui.btnBuy1 then
		SoundSystem.PlayUIClickSound()
		self:OnClickBuyButton(1)
	elseif go == ui.btnBuy2 then
		SoundSystem.PlayUIClickSound()
		self:OnClickBuyButton(2)
	elseif go == ui.btnBuy3 then
		SoundSystem.PlayUIClickSound()
		self:OnClickBuyButton(3)
	end
	return true
end

function ClothesShopSkinDetailCtrl:SetupAvatar(characterId, skinId, attachNode)
	XDebug.Log('GGYY', "set up skin " .. tostring(skinId))
	local prefabName, prefabBundle = ConfigUtils.GetCharacterPrefab(characterId)
	local prefab = self:DynamicLoadAsset(prefabBundle, prefabName)
	local itemObj = Helper.NewObject(prefab, attachNode, 65)
	itemObj.name = tostring(characterId)
	local itemTrans = itemObj.transform
	-- change the sort order as in planet panel its top panel sort order is 5
	local renderer = itemObj:GetComponent('MeshRenderer')
	renderer.sortingOrder = 8

	local skeletonAnimation = itemObj:GetComponent('SkeletonAnimation')
	-- animation
	Helper.PlayAnimation(skeletonAnimation, CharacterAnimations.Idle, true)
	-- skin
	UIHelper.SetCharacterSkinWithSkin(skeletonAnimation, skinId)
end

function ClothesShopSkinDetailCtrl:OnClickBuyButton(index)
	XDebug.Log('GGYY', "press buy " .. index)
	local shopId = self.ShopId
	local productId = self.ProductId
	local costData = self.CostDatas[index]
	local costId, costNum = costData.CostId, costData.CostNum
	local ownNum = GameData.GetItemNum(costId)
	if ownNum < costNum then
		CtrlManager.ShowMessageBox({message = ConfigUtils.GetItemName(costId).."不足", single = true})
		return
	end
	local productInfo = ConfigUtils.GetClothesShopProductInfo(productId)
	CtrlManager.ShowMessageBox({message = string.format("是否确认购买%s", productInfo.Name), single = false, onConfirm = function()
		if GameDataClothesShop.IsProductInActivity(productId) then
			local data = GameDataClothesShop.GetProductForActivity(productId)
			GameDataClothesShop.RequestBuyProduct(data.ShopId, productId, costId, costNum)
		else
			GameDataClothesShop.RequestBuyProduct(shopId, productId, costId, costNum)
		end
		self:Close()
	end})
end

---更新UI--------------------------------------------------------------------------------------

function ClothesShopSkinDetailCtrl:UpdateUIBuyButtons()
	local ui = self._ui
	local shopId = self.ShopId
	local productId = self.ProductId

	self.CostDatas = GameDataClothesShop.GetProductCostDatas(self.ShopId, self.ProductId)
	ui.btnBuy1:SetActive(#self.CostDatas >= 1)
	ui.btnBuy2:SetActive(#self.CostDatas >= 2)
	ui.btnBuy3:SetActive(#self.CostDatas >= 3)
	self:UpdateUIBuyButton(ui.btnBuy1View, self.CostDatas[1])
	self:UpdateUIBuyButton(ui.btnBuy2View, self.CostDatas[2])
	self:UpdateUIBuyButton(ui.btnBuy3View, self.CostDatas[3])
	ui.ButtonLayoutTable:Reposition()
	self:UpdateUILeftTime()
end

function ClothesShopSkinDetailCtrl:UpdateUIBuyButton(btnBuyView, costData)
	if not costData then
		return
	end
	UIHelper.SetIconAndNumForBuyButton(self, btnBuyView.imgCostIcon, btnBuyView.txtCostNum, costData.CostId, costData.CostNum, GameData.GetItemNum(costData.CostId))

	if costData.ShopId > 0 then
		btnBuyView.Hint:SetActive(true)
		table.insert(self.TimeLabels, {btnBuyView.txtLabel, costData.ShopId})
	else
		btnBuyView.Hint:SetActive(false)
		for i,v in ipairs(self.TimeLabels) do
			if v[1] == btnBuyView.txtLabel then
				table.remove(self.TimeLabels, i)
				break
			end
		end
	end
end

function ClothesShopSkinDetailCtrl:UpdateUILeftTime()
	for i,v in ipairs(self.TimeLabels) do
		local leftTime = GameDataClothesShop.GetShopLeftTime(v[2])
		v[1].text = Helper.GetLongTimeString(leftTime)

	end
end