require "FreakPlanet/View/GoalPanel"

local class = require "FreakPlanet/Utils/middleclass"
GoalCtrl  = class(CtrlNames.Goal, BaseCtrl)

local MAIN_GOAL_COLOR = Color.New(255 / 255, 171 / 255, 96 / 255, 1)
local BRANCH_GOAL_COLOR = Color.New(214 / 255, 197 / 255, 181 / 255, 1)

GoalMode = {
	Goal = "Goal",
	Demand = "Demand",
}

--------------------------------------------------
local function IsTutorialGoal(goalId)
	for k, v in pairs(TutorialConstData) do
		if v == goalId then
			return true
		end
	end

	return false
end

local function GoalSortFunc(idA, idB)
	if idA == nil or idB == nil then
		return false
	end

	local tutorialGoalA = IsTutorialGoal(idA)
	local tutorialGoalB = IsTutorialGoal(idB)
	if tutorialGoalA ~= tutorialGoalB then
		return tutorialGoalA
	end

	local mainGoalA = ConfigUtils.IsMainGoal(idA)
	local mainGoalB = ConfigUtils.IsMainGoal(idB)
	if mainGoalA ~= mainGoalB then
		return mainGoalA
	end

	local stateA = GameData.GetGoalInfo(idA)
	local stateB = GameData.GetGoalInfo(idB)
	local valueA = (stateA == GoalState.Complete)
	local valueB = (stateB == GoalState.Complete)
	if valueA ~= valueB then
		return valueA
	end

	return idA < idB
end
--------------------------------------------------
-- load the ui prefab
function GoalCtrl:LoadPanel()
	self:CreatePanel("Goal")
end

-- construct ui panel data
function GoalCtrl:ConstructUI(obj)
	self._ui = GoalPanel.Init(obj)
end

-- notity it has been focused
function GoalCtrl:NotifyFocus()
	if self._currentMode == GoalMode.Goal then
		-- main goal data
		self:RefreshGoalData()
	elseif self._currentMode == GoalMode.Demand then
		-- number of need item may changed
		if self._customDemand or self._selectedDemandIndex ~= nil then
			self:OnSelectedDemandChanged()
		end
		self:RefreshAllDemandItemsHint()
	end

	self:RefreshTabButtons()
	self:RefreshTabHint()
	self:CheckTutorial()
end

-- destructor 
function GoalCtrl:DestroyImpl()	
	GameNotifier.RemoveListener(GameEvent.GoalChanged, GoalCtrl.OnGoalChanged, self)
	GameNotifier.RemoveListener(GameEvent.DemandChanged, GoalCtrl.OnDemandChanged, self)
end

-- fill ui with the data
function GoalCtrl:SetupUI()
	self._updateDemandItems = {}
	self._updateCustomDemandItem = nil
	self._ui.GoalItemGridWrap.OnItemUpdate = GoalCtrl.OnItemUpdateGlobal
	self._currentMode = self._parameter.mode or GoalMode.Goal
	local isValidMode = self:ValidMode(self._currentMode)
	if not isValidMode then
		self._currentMode = GoalMode.Goal
	end

	-- hide default
	self._ui.GoalRoot:SetActive(false)
	self._ui.DemandRoot:SetActive(false)

	self:OnGoalModeChanged()
	self:RefreshTabButtons()
	self:RefreshTabHint()

	CtrlManager.AddClick(self, self._ui.Blocker)
	CtrlManager.AddClick(self, self._ui.ButtonGoal.gameObject)
	CtrlManager.AddClick(self, self._ui.ButtonDemand.gameObject)

	CtrlManager.AddClick(self, self._ui.ButtonDemandSubmit)
	CtrlManager.AddClick(self, self._ui.ButtonDemandGo)
	CtrlManager.AddClick(self, self._ui.ButtonDemandCancel)
	CtrlManager.AddClick(self, self._ui.DemandSelectionCollider)
	CtrlManager.AddClick(self, self._ui.ButtonDemandCancelAll)
	CtrlManager.AddClick(self, self._ui.ButtonDemandLock)
	CtrlManager.AddClick(self, self._ui.CustomDemandItem)
	CtrlManager.AddClick(self, self._ui.ButtonCustom)
	CtrlManager.AddClick(self, self._ui.ButtonRecustom)

	-- events
	GameNotifier.AddListener(GameEvent.GoalChanged, GoalCtrl.OnGoalChanged, self)
	GameNotifier.AddListener(GameEvent.DemandChanged, GoalCtrl.OnDemandChanged, self)

	self:CheckTutorial()
end

function GoalCtrl:OnGoalModeChanged()
	self._selectedDemandIndex = nil
	self._customDemandSelected = false
	self._ui.GoalRoot:SetActive(self._currentMode == GoalMode.Goal)
	self._ui.DemandRoot:SetActive(self._currentMode == GoalMode.Demand)

	if self._currentMode == GoalMode.Goal then
		-- goal items
		self:SetupGoalItems()
	elseif self._currentMode == GoalMode.Demand then
		-- demand items
		self:SetupDemandItems()
		if #self._demandList > 0 then
			self._selectedDemandIndex = 1
		end
		self:OnSelectedDemandChanged()
	else
		assert(false, "un-handle goal mode: "..tostring(self._currentMode))
	end

	self._ui.ButtonGoal.isEnabled = (self._currentMode ~= GoalMode.Goal)
	self._ui.ButtonDemand.isEnabled = (self._currentMode ~= GoalMode.Demand)
end

function GoalCtrl:OnSelectedDemandChanged()
	local selectedDemandData = nil
	if self._customDemandSelected then
		selectedDemandData = self._customDemand
	elseif self._selectedDemandIndex ~= nil then
		selectedDemandData = self._demandList[self._selectedDemandIndex]
	end

	self._ui.DemandSelectionRoot:SetActive(selectedDemandData ~= nil)

	if selectedDemandData ~= nil then
		local demandId = selectedDemandData.id
		local needItemId, needItemNum = ConfigUtils.GetDemandNeedItem(demandId)
		local ownItemNum = GameData.GetItemNum(needItemId)
		local isItemEnough = (ownItemNum >= needItemNum)
		local numText = ""
		if isItemEnough then
			numText = "[FFFFFFFF]"..tostring(ownItemNum).."/"..tostring(needItemNum).."[-]"
		else
			numText = "[FF0000FF]"..tostring(ownItemNum).."[-][FFFFFFFF]/"..tostring(needItemNum).."[-]"
		end

		local activeTime = selectedDemandData.activateTime
		local curTime = GameData.GetServerTime()
		local isActivated = (curTime >= activeTime)
		local locked = selectedDemandData.locked

		UIHelper.ConstructItemIconAndNum(self, self._ui.DemandSelectionRoot.transform, needItemId)
		self._ui.DemandSelectionDesc.text = ConfigUtils.GetDemandDesc(demandId)
		self._ui.DemandSelectionNum.text = numText
		self._ui.ButtonDemandSubmit:SetActive(isActivated and isItemEnough)
		self._ui.ButtonDemandGo:SetActive(isActivated and not isItemEnough)
		-- custom demand not show these buttons
		self._ui.ButtonDemandCancel:SetActive(not self._customDemandSelected and isActivated)
		self._ui.DemandSelectionLocked:SetActive(not self._customDemandSelected and locked)
		self._ui.DemandSelectionUnlocked:SetActive(not self._customDemandSelected and not locked)
	end

	self:ToggleCurrentSelectedDemand(true)
end

function GoalCtrl:RefreshTabButtons()
	-- button demand
	local unlocked = GameData.IsModuleUnlocked(ModuleNames.Demand)
	self._ui.ButtonDemand.gameObject:SetActive(unlocked)
end

function GoalCtrl:RefreshTabHint()
	local hasCompletedGoal = GameData.HasCompletedGoalOfType(GoalType.Main)
	self._ui.GoalHint:SetActive(hasCompletedGoal)
	local isDemandNew = GameData.IsItemNew(ModuleNames.Demand)
	self._ui.DemandHint:SetActive(isDemandNew)
end

function GoalCtrl:SetupGoalItems()
	self:RecycleGoalItems()

	self._goalList = GameData.GetActiveGoalsOfType(GoalType.Main)
	table.sort(self._goalList, GoalSortFunc)

	local itemCount = self._ui.GoalItemGridWrap.NeedCellCount
    itemCount = math.min(#self._goalList, itemCount)
    self._ui.GoalItemGridWrap.MaxRow = math.ceil(#self._goalList / self._ui.GoalItemGridWrap.ColumnLimit)

	for idx = 1, itemCount do
		local goalId = self._goalList[idx]
		local goalItem = nil
		if self._ui.GoalItemPool.childCount == 0 then
			local goalItemObj = Helper.NewObject(self._ui.GoalItemTemplate, self._ui.GoalItemGrid)
			goalItem = goalItemObj.transform
			local buttonGo = goalItem:Find("ButtonGo").gameObject
			local buttonReward = goalItem:Find("ButtonReward").gameObject
			CtrlManager.AddClick(self, buttonGo)
			CtrlManager.AddClick(self, buttonReward)
		else
			goalItem = self._ui.GoalItemPool:GetChild(0)
			goalItem.parent = self._ui.GoalItemGrid
			goalItem.localScale = Vector3.one
		end
		
		goalItem.gameObject:SetActive(true)
		goalItem.gameObject.name = tostring(goalId)

		self:ConstructGoalItem(goalItem, goalId)
	end
	
	self._ui.GoalItemGridWrap:SortBasedOnScrollMovement()
    self._ui.GoalScrollView.restrictWithinPanel = true
    self._ui.GoalScrollView.disableDragIfFits = (#self._goalList <= itemCount)
    self._ui.GoalScrollView:ResetPosition()

	self._ui.GoalEmptyHint:SetActive(#self._goalList == 0)
end

function GoalCtrl:ConstructGoalItem(goalItem, goalId)
	local conditions = ConfigUtils.GetGoalConditions(goalId)
	assert(#conditions == 1, "goal should only have one condition: "..tostring(goalId))
	local goalState, goalNumber = GameData.GetGoalInfo(goalId)
	-- color
	local expandableBG = goalItem:Find("ExpandableBG"):GetComponent("UISprite")
	local isMain = ConfigUtils.IsMainGoal(goalId)
	if isMain then
		expandableBG.color = MAIN_GOAL_COLOR
	else
		expandableBG.color = BRANCH_GOAL_COLOR
	end
	-- title
	local goalTitle = goalItem:Find("GoalTitle"):GetComponent("UILabel")
	goalTitle.text = ConfigUtils.GetGoalName(goalId)
	-- rewards
	local rewards = ConfigUtils.GetGoalActualRewards(goalId)
	local rewardRoot = goalItem:Find("RewardBG")
	for idx = 1, rewardRoot.childCount do
		local rewardItem = rewardRoot:GetChild(idx - 1)
		local hasReward = (idx <= #rewards)
		rewardItem.gameObject:SetActive(hasReward)
		if hasReward then
			local rewardItemId = rewards[idx].Value
			local rewardItemNum = rewards[idx].Num
			-- content
			local rewardLabel = rewardItem:Find("Content"):GetComponent("UILabel")
			rewardLabel.text = UIHelper.ConstructGoalRewardContent(rewardItemId, rewardItemNum)
			-- icon
			UIHelper.ConstructItemIconAndNum(self, rewardItem, rewardItemId, rewardItemNum)
		end
	end
	-- unlock module
	local unlockModule = ConfigUtils.GetUnlockModuleByGoal(goalId)
	local unlockModuleRoot = goalItem:Find("UnlockModule")
	unlockModuleRoot.gameObject:SetActive(unlockModule ~= nil)
	if unlockModule ~= nil then
		local unlockModuleLabel = unlockModuleRoot:Find("Label"):GetComponent("UILabel")
		unlockModuleLabel.text = ConfigUtils.GetModuleUnlockText(unlockModule)
	end
	-- goal task
	local taskNameLabel = goalItem:Find("Task/Name"):GetComponent("UILabel")
	taskNameLabel.text = UIHelper.GetGoalFinalName(conditions[1])
	-- goal icon
	local taskRoot = goalItem:Find("Task")
	UIHelper.ConstructGoalIcon(self, taskRoot, goalId, conditions[1])
	-- goal data
	self:RefreshGoalItemData(goalItem, goalId)
end

function GoalCtrl:SetupDemandItems()
	self._updateDemandItems = {}
	self._updateCustomDemandItem = nil
	self._demandList, self._customDemand = GameData.GetDemandList()

	local demandGrid = self._ui.DemandItemGrid
	local existCount = demandGrid.childCount
	for idx = 1, #self._demandList do
		local item = nil
		if idx <= existCount then
			item = demandGrid:GetChild(idx - 1)
		else
			if self._ui.DemandItemPool.childCount == 0 then
				local itemObj = Helper.NewObject(self._ui.DemandItemTemplate, demandGrid)
				item = itemObj.transform
				CtrlManager.AddClick(self, itemObj)
			else
				item = self._ui.DemandItemPool:GetChild(0)
				item.parent = demandGrid
				item.localScale = Vector3.one
				item.localPosition = Vector3.zero
			end
		end

		item.gameObject:SetActive(true)
		item.name = tostring(idx)

		self:ConstructDemandItem(item, idx)
	end

	-- recycle the rest items
	existCount = demandGrid.childCount
	for idx = existCount, #self._demandList + 1, -1 do
		local item = demandGrid:GetChild(idx - 1)
		item.parent = self._ui.DemandItemPool
	end

	demandGrid:GetComponent("UIGrid"):Reposition()

	self:SetupCustomDemand()
end

function GoalCtrl:SetupCustomDemand()
	local unlocked = GameData.IsModuleUnlocked(ModuleNames.CustomDemand)
	local hasCustom = (self._customDemand ~= nil)

	self._ui.CustomDemandLockRoot:SetActive(not unlocked)
	self._ui.CustomDemandEmtpyRoot:SetActive(unlocked and not hasCustom)
	self._ui.CustomDemandNormalRoot:SetActive(unlocked and hasCustom)

	if unlocked then
		if hasCustom then
			self._updateCustomDemandItem = self:ConstructDemandItemWithData(self._ui.CustomDemandItem.transform, self._customDemand)
		end

		local leftCountLabel = nil
		if hasCustom then
			leftCountLabel = self._ui.CustomDemandNormalRoot.transform:Find("LeftCount"):GetComponent("UILabel")
		else
			leftCountLabel = self._ui.CustomDemandEmtpyRoot.transform:Find("LeftCount"):GetComponent("UILabel")
		end

		if leftCountLabel ~= nil then
			local customDemandInfo = GameData.GetCustomDemandInfo()
			local leftCount = customDemandInfo.leftCount
			leftCountLabel.text = string.format(SAFE_LOC("剩余提交次数：%d"), leftCount)
		end
	end
end

function GoalCtrl:ConstructDemandItem(item, demandIndex)
	local demandData = self._demandList[demandIndex]
	local toUpdate = self:ConstructDemandItemWithData(item, demandData)
	self._updateDemandItems[demandIndex] = toUpdate
end

function GoalCtrl:ConstructDemandItemWithData(item, demandData)
	local curTime = GameData.GetServerTime()
	local activeTime = demandData.activateTime
	local demandId = demandData.id

	local isActivated = (curTime >= activeTime)

	local detailRoot = item:Find("Detail").gameObject
	local cooldownRoot = item:Find("Cooldown").gameObject

	local nameLabel = item:Find("Detail/Name"):GetComponent("UILabel")
	nameLabel.text = ConfigUtils.GetDemandName(demandId)
	-- locked
	self:RefreshDemandLockState(item, demandData)
	-- num hint
	self:RefreshDemandItemHint(item, demandData)
	-- select state
	self:ToggleDemandItemSelected(item, false)

	local rewardRoot = item:Find("Detail/Rewards")
	local demandRewards = demandData.rewardList
	for idx = 1, rewardRoot.childCount do
		local hasReward = (idx <= #demandRewards)
		local rewardItem = rewardRoot:GetChild(idx - 1)
		rewardItem.gameObject:SetActive(hasReward)
		if hasReward then
			local rewardItemId = demandRewards[idx].id
			local rewardItemNum = demandRewards[idx].num

			UIHelper.ConstructItemIconAndNum(self, rewardItem, rewardItemId)

			local numberLabel = rewardItem:Find("Num"):GetComponent("UILabel")
			numberLabel.text = tostring(rewardItemNum)
		end
	end

	detailRoot:SetActive(isActivated)
	cooldownRoot:SetActive(not isActivated)

	local toUpdate = nil
	if not isActivated then
		local cooldownLabel = item:Find("Cooldown/Time"):GetComponent("UILabel")
		cooldownLabel.text = ""
		toUpdate = {detail = detailRoot, cooldown = cooldownRoot, cooldownLabel = cooldownLabel}
	end

	return toUpdate
end

function GoalCtrl:RefreshDemandLockState(item, demandData)
	local locked = demandData.locked
	local lockedMark = item:Find("Locked").gameObject
	lockedMark:SetActive(locked)
end

function GoalCtrl:ToggleDemandItemSelected(item, show)
	local selectedMark = item:Find("Select").gameObject
	selectedMark:SetActive(show)
end

function GoalCtrl:ToggleCurrentSelectedDemand(show)
	if self._currentMode ~= GoalMode.Demand then
		return
	end

	local item = nil
	if self._customDemandSelected then
		item = self._ui.CustomDemandItem.transform
	elseif self._selectedDemandIndex ~= nil then
		item = self._ui.DemandItemGrid:Find(self._selectedDemandIndex)
	end

	if item ~= nil then
		self:ToggleDemandItemSelected(item, show)
	end
end

function GoalCtrl:RefreshDemandCooldown(demandIndex)
	local demandData = self._demandList[demandIndex]
	local updateItem = self._updateDemandItems[demandIndex]
	return self:RefreshDemandCooldownInternal(demandData, updateItem)
end

function GoalCtrl:RefreshCustomDeamndCooldown()
	local demandData = self._customDemand
	local updateItem = self._updateCustomDemandItem
	return self:RefreshDemandCooldownInternal(demandData, updateItem)
end

function GoalCtrl:RefreshDemandCooldownInternal(demandData, updateItem)
	local curTime = GameData.GetServerTime()
	local activeTime = demandData.activateTime
	local leftTime = math.max(activeTime - curTime, 0)

	updateItem.cooldownLabel.text = Helper.FormatTime(leftTime)

	if leftTime == 0 then
		updateItem.detail:SetActive(true)
		updateItem.cooldown:SetActive(false)
	end

	return (leftTime == 0)
end

function GoalCtrl:RefreshGoalData()
	for idx = 1, self._ui.GoalItemGrid.childCount do
		local goalItem = self._ui.GoalItemGrid:GetChild(idx - 1)
		if goalItem.gameObject.activeSelf then
			local goalId = tonumber(goalItem.gameObject.name)
			self:RefreshGoalItemData(goalItem, goalId)
		end
	end
end

function GoalCtrl:RefreshGoalItemData(goalItem, goalId)
	local conditions = ConfigUtils.GetGoalConditions(goalId)
	local goalState, goalNumber = GameData.GetGoalInfo(goalId)

	local buttonGo = goalItem:Find("ButtonGo"):GetComponent("UIButton")
	local goHint = goalItem:Find("ButtonGo/Hint").gameObject
	local buttonReward = goalItem:Find("ButtonReward").gameObject
	local buttonRewardLabel = goalItem:Find("ButtonReward/Label"):GetComponent("UILabel")
	buttonGo.gameObject:SetActive(false)
	buttonReward:SetActive(goalState == GoalState.Complete)
	if goalState == GoalState.Complete then
		local isSubmitGoods = ConfigUtils.IsSubmitGoodsGoal(goalId)
		if isSubmitGoods then
			buttonRewardLabel.text = SAFE_LOC("loc_Submit")
		else
			buttonRewardLabel.text = SAFE_LOC("loc_Reward")
		end
	end

	if goalState == GoalState.Running then
		local hasGoto = self:HasGoto(goalId)
		buttonGo.gameObject:SetActive(hasGoto)
		goHint:SetActive(hasGoto and goalId == SPECIFIC_GOAL_ID)
	end

	local completeMark = goalItem:Find("Mark/Complete").gameObject
	completeMark:SetActive(goalState == GoalState.Complete)

	local taskNum = goalItem:Find("Task/Num"):GetComponent("UILabel")
	taskNum.text = UIHelper.GetGoalShowNum(conditions[1], goalNumber[1])
end

function GoalCtrl:HasGoto(goalId)
	local trigger = ConfigUtils.GetGoalTriggers(goalId)[1]
	if trigger == TriggerType.SubmitGoods then
		-- the first one
		local itemId = ConfigUtils.GetGoalConditions(goalId)[1].Value
		local sources = ConfigUtils.GetItemSource(itemId)
		if #sources == 0 then
			return false
		end
	end

	return true
end

function GoalCtrl:UpdateImpl(deltaTime)
	-- refresh general demands
	local toRemove = {}
	for k, v in pairs(self._updateDemandItems) do
		local cd = self:RefreshDemandCooldown(k)
		if cd then
			-- update button state
			if k == self._selectedDemandIndex then
				self:OnSelectedDemandChanged()
			end
			table.insert(toRemove, k)
		end
	end

	for idx = 1, #toRemove do
		self._updateDemandItems[toRemove[idx]] = nil
	end
	-- refresh custom demand
	if self._updateCustomDemandItem ~= nil then
		local finshed = self:RefreshCustomDeamndCooldown()
		if finshed then
			self._updateCustomDemandItem = nil
		end
	end
end

-- handle the escapse button
function GoalCtrl:HandleEscape()
	self:OnClicked(self._ui.Blocker)
end

function GoalCtrl:DoJump(goalMode)
	local isValid = self:ValidMode(goalMode)
	if not isValid then
		goalMode = GoalMode.Goal
	end
	
	if self._currentMode == goalMode then
		return
	end

	self._currentMode = goalMode
	self:OnGoalModeChanged()
	if goalMode == GoalMode.Demand then
		GameData.CheckItem(ModuleNames.Demand)
		self:RefreshTabHint()
	end
end

function GoalCtrl:CanCancelAllDemands()
	local curTime = GameData.GetServerTime()
	for idx = 1, #self._demandList do
		local activeTime = self._demandList[idx].activateTime
		local locked = self._demandList[idx].locked

		if curTime >= activeTime and not locked then
			return true
		end
	end

	return false
end

-- on clicked
function GoalCtrl:OnClicked(go)
	if go == self._ui.Blocker then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
	elseif go == self._ui.ButtonGoal.gameObject then
		SoundSystem.PlaySwitchSound()
		self._currentMode = GoalMode.Goal
		self:OnGoalModeChanged()
	elseif go == self._ui.ButtonDemand.gameObject then
		SoundSystem.PlaySwitchSound()
		self._currentMode = GoalMode.Demand
		self:OnGoalModeChanged()
		GameData.CheckItem(ModuleNames.Demand)
		self:RefreshTabHint()
	elseif go == self._ui.ButtonDemandSubmit then
		local demandData = self:GetSelectedDemandData()
		local demandId = demandData.id
		local needItemId, needItemNum = ConfigUtils.GetDemandNeedItem(demandId)
		local ownItemNum = GameData.GetItemNum(needItemId)
		if ownItemNum < needItemNum then
			SoundSystem.PlayWarningSound()
			CtrlManager.ShowMessageBox({message = SAFE_LOC("物品数量不足"), single = true})
			return true
		end

		if self._customDemandSelected then
			local customDemandInfo = GameData.GetCustomDemandInfo()
			if customDemandInfo.leftCount <= 0 then
				SoundSystem.PlayWarningSound()
				CtrlManager.ShowMessageBox({message = SAFE_LOC("提交次数已用完"), single = true})
				return true
			end
		end

		SoundSystem.PlayUIClickSound()
		local groupId = demandData.groupId
		NetManager.Send("DemandSubmit", {
			DemandGroupID = groupId,
			DemandId = demandId,
			DemandRewards = demandData.rewardList,
			IsCustom = self._customDemandSelected,
		}, GoalCtrl.OnHandleProto, self)
	elseif go == self._ui.ButtonDemandCancel then
		local demandData = self:GetSelectedDemandData()
		local locked = demandData.locked
		if locked then
			SoundSystem.PlayWarningSound()
			CtrlManager.ShowMessageBox({message = SAFE_LOC("请先解除锁定后再删除"), single = true})
			return true
		end

		SoundSystem.PlayUIClickSound()
		assert(not self._customDemandSelected, "custom demand can not cancel")
		local groupId = demandData.groupId
		NetManager.Send("DemandCancel", {
			DemandGroupID = groupId,
			IsCustom = false,
		}, GoalCtrl.OnHandleProto, self)
	elseif go == self._ui.ButtonDemandCancelAll then
		if not self:CanCancelAllDemands() then
			SoundSystem.PlayWarningSound()
			CtrlManager.ShowMessageBox({message = SAFE_LOC("当前没有可以删除的订单"), single = true})
			return true
		end

		SoundSystem.PlayUIClickSound()
		NetManager.Send("DemandCancel", {
			DemandGroupID = -1,
			IsCustom = false,
		}, GoalCtrl.OnHandleProto, self)
	elseif go == self._ui.ButtonDemandLock then
		SoundSystem.PlayUIClickSound()
		assert(not self._customDemandSelected, "custom demand can not lock")
		local demandData = self:GetSelectedDemandData()
		local groupId = demandData.groupId
		local locked = demandData.locked
		NetManager.Send("DemandLock", {
			DemandGroupID = groupId,
			DemandIndex = self._selectedDemandIndex,  
			Lock = not locked,
		}, GoalCtrl.OnHandleProto, self)
	elseif go == self._ui.ButtonDemandGo then
		local demandData = self:GetSelectedDemandData()
		local demandId = demandData.id
		local needItemId = ConfigUtils.GetDemandNeedItem(demandId)
		local ret = UIHelper.GetSourceCtrlByItemId(needItemId)
		if ret.code ~= RetCode.OK then
			SoundSystem.PlayWarningSound()
			local showMsg = UIHelper.GetReturnCodeShowText(ret.code)
			CtrlManager.ShowMessageBox({message = showMsg, single = true})
		else
			SoundSystem.PlayUIClickSound()
			JumpManager.JumpFromItemSource(ret)
		end
	elseif go.transform.parent == self._ui.DemandItemGrid then
		SoundSystem.PlayUIClickSound()
		local demandIndex = tonumber(go.name)
		if self._customDemandSelected or demandIndex ~= self._selectedDemandIndex then
			self:ToggleCurrentSelectedDemand(false)
			self._selectedDemandIndex = demandIndex
			self._customDemandSelected = false
			self:OnSelectedDemandChanged()
		end
	elseif go == self._ui.DemandSelectionCollider then
		local demandData = self:GetSelectedDemandData()
		if demandData ~= nil then
			SoundSystem.PlayUIClickSound()
			local demandId = demandData.id
			local needItemId = ConfigUtils.GetDemandNeedItem(demandId)
			CtrlManager.ShowItemDetail({itemId = needItemId})
		end
	elseif go == self._ui.CustomDemandItem then
		SoundSystem.PlayUIClickSound()
		if not self._customDemandSelected then
			self:ToggleCurrentSelectedDemand(false)
			self._selectedDemandIndex = nil
			self._customDemandSelected = true
			self:OnSelectedDemandChanged()
		end
	elseif go == self._ui.ButtonCustom or go == self._ui.ButtonRecustom then
		SoundSystem.PlayUIClickSound()
		CtrlManager.OpenPanel(CtrlNames.CustomDemand)
	elseif go.name == "ButtonGo" then
		local goalId = tonumber(go.transform.parent.gameObject.name)
		local code = JumpManager.JumpFromGoal(goalId)
		if code == RetCode.OK then
			SoundSystem.PlayUIClickSound()
		else
			SoundSystem.PlayWarningSound()
			local msg = UIHelper.GetReturnCodeShowText(code)
			CtrlManager.ShowMessageBox({message = msg, single = true})
		end
	elseif go.name == "ButtonReward" then
		SoundSystem.PlayUIClickSound()
		local goalId = tonumber(go.transform.parent.gameObject.name)
		local goalState = GameData.GetGoalInfo(goalId)
		local goalType = ConfigUtils.GetGoalType(goalId)
		assert(goalState == GoalState.Complete, "state of goal "..tostring(goalId).." is: "..tostring(goalState))
		NetManager.Send("GetGoalReward", {GoalId = goalId, GoalType = goalType}, GoalCtrl.OnHandleProto, self)
	end

	return true
end

function GoalCtrl:RecycleGoalItems()
	for idx = self._ui.GoalItemGrid.childCount, 1, -1 do
		local goalItem = self._ui.GoalItemGrid:GetChild(idx - 1)
		goalItem.parent = self._ui.GoalItemPool
	end
end

function GoalCtrl:RefreshAllDemandItemsHint()
	if self._currentMode ~= GoalMode.Demand then
		return
	end

	local demandGrid = self._ui.DemandItemGrid
	for idx = 1, demandGrid.childCount do
		local item = demandGrid:GetChild(idx - 1)
		local demandIndex = tonumber(item.gameObject.name)
		local demandData = self._demandList[demandIndex]
		self:RefreshDemandItemHint(item, demandData)
	end

	if self._customDemand ~= nil then
		self:RefreshDemandItemHint(self._ui.CustomDemandItem.transform, self._customDemand)
	end
end

function GoalCtrl:RefreshDemandItemHint(item, demandData)
	local demandId = demandData.id
	local needItemId, needItemNum = ConfigUtils.GetDemandNeedItem(demandId)
	local ownItemNum = GameData.GetItemNum(needItemId)
	local isItemEnough = (ownItemNum >= needItemNum)

	local hintMark = item:Find("Detail/Hint").gameObject
	hintMark:SetActive(isItemEnough)
end
--------------------------------------------------------
function GoalCtrl:OnHandleProto(proto, data, requestData)
	if proto == "GetGoalReward" then
		local goalId = requestData.GoalId
		NavigationCtrl.EnableSuspend(true)
		GameData.FinishGoal(goalId)
		local goldNum = data.RemainGold
		local diamondNum = data.RemainDiamond
		GameData.SetMoney(ItemType.Gold, goldNum)
		GameData.SetMoney(ItemType.Diamond, diamondNum)
		GameData.CheckAndHintGoalsOfCurrentCountType()
		GameData.SyncTutorialData()
	elseif proto == "DemandSubmit" then
		NavigationCtrl.EnableSuspend(true)
		local demandId = requestData.DemandId
		local rewards = requestData.DemandRewards
		-- demand cost
		local needItemId, needItemNum = ConfigUtils.GetDemandNeedItem(demandId)
		local costGoalData = GameData.SetupItemGoalData(needItemId, needItemNum)
		GameData.ConsumeItem(needItemId, needItemNum)
		-- rewards
		local showRewards = {}
		local rewardGoalData = {}
		for idx = 1, #rewards do
			local itemId = rewards[idx].id
			local itemNum = rewards[idx].num
			local unlocked = GameData.IsItemUnlocked(itemId)
			GameData.CollectItem(itemId, itemNum, false)
			showRewards[idx] = {value = itemId, num = itemNum, unlocked = unlocked}

			local e = GameData.SetupItemGoalData(itemId, itemNum)
			table.insert(rewardGoalData, e)
		end
		NewItemCtrl.ShowNewItemList(showRewards)

		local goldNum = data.RemainGold
		local diamondNum = data.RemainDiamond
		GameData.SetMoney(ItemType.Gold, goldNum)
		GameData.SetMoney(ItemType.Diamond, diamondNum)

		local completeDemandGoalData = GameData.SetupItemGoalDataWithType(ItemType.Demand, -1, 1)
		GameData.DoGoalSettle(TriggerType.DemandReward, rewardGoalData)
		GameData.DoGoalSettle(TriggerType.DemandCost, {costGoalData})
		GameData.DoGoalSettle(TriggerType.CompleteDemand, {completeDemandGoalData})

		-- here will notify DemandChanged
		GameData.RefreshDemandList(data)
		-- sync server time
        local serverTime = data.ServerTime or 0
        if serverTime > 0 then
            GameData.SetServerTime(serverTime)
        end
	elseif proto == "DemandCancel" then
		-- here will notify DemandChanged
		GameData.RefreshDemandList(data)
		-- sync server time
        local serverTime = data.ServerTime or 0
        if serverTime > 0 then
            GameData.SetServerTime(serverTime)
        end
	elseif proto == "DemandLock" then
		-- custom demand no lock, before send the proto, we checked it
		local demandIndex = requestData.DemandIndex
		local locked = requestData.Lock
		-- sync data
		self._demandList[demandIndex].locked = locked

		if self._currentMode == GoalMode.Demand then
			if not self._customDemandSelected and demandIndex == self._selectedDemandIndex then
				self._ui.DemandSelectionLocked:SetActive(locked)
				self._ui.DemandSelectionUnlocked:SetActive(not locked)
			end

			local demandItem = self._ui.DemandItemGrid:Find(demandIndex)
			if demandItem ~= nil then
				local demandData = self._demandList[demandIndex]
				self:RefreshDemandLockState(demandItem, demandData)
			end
		end
		-- sync server time
        local serverTime = data.ServerTime or 0
        if serverTime > 0 then
            GameData.SetServerTime(serverTime)
        end
	end
end

function GoalCtrl.OnItemUpdateGlobal(itemObj, itemIndex, itemRealIndex)
	local ctrl = CtrlManager.GetCtrlByName(CtrlNames.Goal)
    if ctrl ~= nil then
        ctrl:OnItemUpdate(itemObj, itemIndex, itemRealIndex)
    end
end

function GoalCtrl:OnItemUpdate(itemObj, itemIndex, itemRealIndex)
	if self._currentMode ~= GoalMode.Goal then
		return
	end

	itemRealIndex = itemRealIndex + 1
    if itemRealIndex <= 0 or itemRealIndex > #self._goalList then
        itemObj:SetActive(false)
    else
        itemObj:SetActive(true)
        local goalId = self._goalList[itemRealIndex]
        itemObj.name = tostring(goalId)
        local goalItem = itemObj.transform
        -- construct item
        self:ConstructGoalItem(goalItem, goalId)
    end
end

function GoalCtrl:OnGoalChanged(goalType)
	if goalType == GoalType.Main then
		-- re-construct goal items
		if self._currentMode == GoalMode.Goal then
			self:SetupGoalItems()
		end
	end

	self:RefreshTabHint()
end

function GoalCtrl:OnDemandChanged(selectCustom)
	if self._currentMode == GoalMode.Demand then
		self:SetupDemandItems()
		-- check current selection is valid or not
		if self._customDemandSelected and self._customDemand == nil then
			self._customDemandSelected = false
		end

		if selectCustom and not self._customDemandSelected and self._customDemand ~= nil then
			self._customDemandSelected = true
		end

		if not self._customDemandSelected then
			-- valid but exceed the range
			if self._selectedDemandIndex ~= nil and self._selectedDemandIndex > #self._demandList then
				self._selectedDemandIndex = nil
			end

			if self._selectedDemandIndex == nil and #self._demandList > 0 then
				self._selectedDemandIndex = 1
			end
		end

		self:OnSelectedDemandChanged()
	end

	self:RefreshTabHint()
end

function GoalCtrl:GetSelectedDemandData()
	if self._customDemandSelected then
		return self._customDemand
	end

	if self._selectedDemandIndex ~= nil then
		return self._demandList[self._selectedDemandIndex]
	end

	return nil
end
--------------------------------------------------------
-- tutorial
function GoalCtrl:ValidMode(goalMode)
	if goalMode == nil or GoalMode[goalMode] == nil then
		return false
	end

	if GameData.IsTutorialNotFinished(Tutorials.Tutorial_2_6) and GameData.IsGoalCompleted(TutorialConstData.ExploreGoal) then
		return (goalMode == GoalMode.Goal)
	elseif GameData.IsTutorialNotFinished(Tutorials.Tutorial_2_6) and GameData.IsGoalRunning(TutorialConstData.ChallengeGoal) then
		return (goalMode == GoalMode.Goal)
	elseif GameData.IsTutorialNotFinished(Tutorials.Tutorial_3_2) and GameData.IsGoalCompleted(TutorialConstData.ChallengeGoal) then
		return (goalMode == GoalMode.Goal)
	elseif GameData.IsTutorialNotFinished(Tutorials.Tutorial_5_6) and GameData.IsGoalRunning(TutorialConstData.DemandGoal) then
		return (goalMode == GoalMode.Goal)
	elseif GameData.IsTutorialNotFinished(Tutorials.Tutorial_6_3) and GameData.IsGoalRunning(TutorialConstData.EquipmentUpgradeGoal) then
		return (goalMode == GoalMode.Goal)
	elseif GameData.IsTutorialNotFinished(Tutorials.Tutorial_7_4) and GameData.IsGoalRunning(TutorialConstData.WorkShopUpgradeGoal) then
		return (goalMode == GoalMode.Goal)
	elseif GameData.IsTutorialNotFinished(Tutorials.Tutorial_8_2) and GameData.IsGoalRunning(TutorialConstData.SummonGoal) then
		return (goalMode == GoalMode.Goal)
	elseif GameData.IsTutorialNotFinished(Tutorials.Tutorial_9_3) and GameData.IsGoalRunning(TutorialConstData.CraftGoal) then
		return (goalMode == GoalMode.Goal)
	end

	return true
end

function GoalCtrl:CheckTutorial()
	local tutorials = {}

	if GameData.IsTutorialNotFinished(Tutorials.Tutorial_2_6) and GameData.IsGoalCompleted(TutorialConstData.ExploreGoal) then
		local goalItem = self._ui.GoalItemGrid:Find(TutorialConstData.ExploreGoal)
		local buttonReward = goalItem:Find("ButtonReward")
		local position = self._ui.Camera:WorldToScreenPoint(buttonReward.position)
		tutorials[1] = {event = Tutorials.Tutorial_ExploreGoalReward, position = position, sender = self}
	elseif GameData.IsTutorialNotFinished(Tutorials.Tutorial_2_6) and GameData.IsGoalRunning(TutorialConstData.ChallengeGoal) then
		local goalItem = self._ui.GoalItemGrid:Find(TutorialConstData.ChallengeGoal)
		local buttonGo = goalItem:Find("ButtonGo")
		local position = self._ui.Camera:WorldToScreenPoint(buttonGo.position)
		tutorials[1] = {event = Tutorials.Tutorial_ChallengeGoalGo, position = position, sender = self}
	elseif GameData.IsTutorialNotFinished(Tutorials.Tutorial_3_2) and GameData.IsGoalCompleted(TutorialConstData.ChallengeGoal) then
		local goalItem = self._ui.GoalItemGrid:Find(TutorialConstData.ChallengeGoal)
		local buttonReward = goalItem:Find("ButtonReward")
		local position = self._ui.Camera:WorldToScreenPoint(buttonReward.position)
		tutorials[1] = {event = Tutorials.Tutorial_ChallengeGoalReward, position = position, sender = self}
	elseif GameData.IsTutorialNotFinished(Tutorials.Tutorial_5_6) and GameData.IsGoalRunning(TutorialConstData.DemandGoal) then
		local position = self._ui.Camera:WorldToScreenPoint(self._ui.ButtonDemand.transform.position)
		table.insert(tutorials, {event = Tutorials.Tutorial_5_1, position = position, sender = self})
		position = self._ui.Camera:WorldToScreenPoint(self._ui.DemandItemGrid.position)
		table.insert(tutorials, {event = Tutorials.Tutorial_5_2, position = position, sender = self})
		position = self._ui.Camera:WorldToScreenPoint(self._ui.DemandTutorialMark.position)
		table.insert(tutorials, {event = Tutorials.Tutorial_5_3, position = position, sender = self})
		position = self._ui.Camera:WorldToScreenPoint(self._ui.ButtonDemandSubmit.transform.position)
		table.insert(tutorials, {event = Tutorials.Tutorial_5_6, position = position, sender = self})
	elseif GameData.IsTutorialNotFinished(Tutorials.Tutorial_6_3) and GameData.IsGoalRunning(TutorialConstData.EquipmentUpgradeGoal) then
		local goalItem = self._ui.GoalItemGrid:Find(TutorialConstData.EquipmentUpgradeGoal)
		local buttonGo = goalItem:Find("ButtonGo")
		local position = self._ui.Camera:WorldToScreenPoint(buttonGo.position)
		tutorials[1] = {event = Tutorials.Tutorial_EquipmentUpgradeGoalGo, position = position, sender = self}
	elseif GameData.IsTutorialNotFinished(Tutorials.Tutorial_7_4) and GameData.IsGoalRunning(TutorialConstData.WorkShopUpgradeGoal) then
		local goalItem = self._ui.GoalItemGrid:Find(TutorialConstData.WorkShopUpgradeGoal)
		local buttonGo = goalItem:Find("ButtonGo")
		local position = self._ui.Camera:WorldToScreenPoint(buttonGo.position)
		tutorials[1] = {event = Tutorials.Tutorial_WorkShopUpgradeGoalGo, position = position, sender = self}
	elseif GameData.IsTutorialNotFinished(Tutorials.Tutorial_8_2) and GameData.IsGoalRunning(TutorialConstData.SummonGoal) then
		local goalItem = self._ui.GoalItemGrid:Find(TutorialConstData.SummonGoal)
		local buttonGo = goalItem:Find("ButtonGo")
		local position = self._ui.Camera:WorldToScreenPoint(buttonGo.position)
		tutorials[1] = {event = Tutorials.Tutorial_SummonGoalGo, position = position, sender = self}
	elseif GameData.IsTutorialNotFinished(Tutorials.Tutorial_9_3) and GameData.IsGoalRunning(TutorialConstData.CraftGoal) then
		local goalItem = self._ui.GoalItemGrid:Find(TutorialConstData.CraftGoal)
		local buttonGo = goalItem:Find("ButtonGo")
		local position = self._ui.Camera:WorldToScreenPoint(buttonGo.position)
		tutorials[1] = {event = Tutorials.Tutorial_CraftGoalGo, position = position, sender = self}
	end

	if #tutorials > 0 then
		CtrlManager.ShowTutorials(tutorials)
	end

	return #tutorials > 0
end

function GoalCtrl:OnTutorialClicked(tutorial)
	if tutorial == Tutorials.Tutorial_ExploreGoalReward then
		local goalItem = self._ui.GoalItemGrid:Find(TutorialConstData.ExploreGoal)
		local buttonReward = goalItem:Find("ButtonReward").gameObject
		self:OnClicked(buttonReward)
	elseif tutorial == Tutorials.Tutorial_ChallengeGoalGo then
		local goalItem = self._ui.GoalItemGrid:Find(TutorialConstData.ChallengeGoal)
		local buttonGo = goalItem:Find("ButtonGo").gameObject
		self:OnClicked(buttonGo)
	elseif tutorial == Tutorials.Tutorial_ChallengeGoalReward then
		local goalItem = self._ui.GoalItemGrid:Find(TutorialConstData.ChallengeGoal)
		local buttonReward = goalItem:Find("ButtonReward").gameObject
		self:OnClicked(buttonReward)
	elseif tutorial == Tutorials.Tutorial_5_1 then
		self:OnClicked(self._ui.ButtonDemand.gameObject)
	elseif tutorial == Tutorials.Tutorial_5_2 then
		if self._ui.DemandItemGrid.childCount > 0 then
			local demandItem = self._ui.DemandItemGrid:GetChild(0)
			self:OnClicked(demandItem.gameObject)
		end
	elseif tutorial == Tutorials.Tutorial_5_6 then
		if self._selectedDemandIndex ~= nil then
			self:OnClicked(self._ui.ButtonDemandSubmit)
		end
	elseif tutorial == Tutorials.Tutorial_EquipmentUpgradeGoalGo then
		local goalItem = self._ui.GoalItemGrid:Find(TutorialConstData.EquipmentUpgradeGoal)
		local buttonGo = goalItem:Find("ButtonGo").gameObject
		self:OnClicked(buttonGo)
	elseif tutorial == Tutorials.Tutorial_WorkShopUpgradeGoalGo then
		local goalItem = self._ui.GoalItemGrid:Find(TutorialConstData.WorkShopUpgradeGoal)
		local buttonGo = goalItem:Find("ButtonGo").gameObject
		self:OnClicked(buttonGo)
	elseif tutorial == Tutorials.Tutorial_SummonGoalGo then
		local goalItem = self._ui.GoalItemGrid:Find(TutorialConstData.SummonGoal)
		local buttonGo = goalItem:Find("ButtonGo").gameObject
		self:OnClicked(buttonGo)
	elseif tutorial == Tutorials.Tutorial_CraftGoalGo then
		local goalItem = self._ui.GoalItemGrid:Find(TutorialConstData.CraftGoal)
		local buttonGo = goalItem:Find("ButtonGo").gameObject
		self:OnClicked(buttonGo)
	else
		SoundSystem.PlayUIClickSound()
	end
end
--------------------------------------------------------