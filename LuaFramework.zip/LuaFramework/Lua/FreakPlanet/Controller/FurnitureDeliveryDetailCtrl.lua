require "FreakPlanet/View/FurnitureDeliveryDetailPanel"

local class = require "FreakPlanet/Utils/middleclass"
FurnitureDeliveryDetailCtrl  = class(CtrlNames.FurnitureDeliveryDetail, BaseCtrl)

-- load the ui prefab
function FurnitureDeliveryDetailCtrl:LoadPanel()
	self:CreatePanel("FurnitureDeliveryDetail")
end

local function FurnitureSortFunc(idA, idB)
	if idA == nil or idB == nil then
		return false
	end

	local valueA = idA.deliverTime
	local valueB = idB.deliverTime

	return valueA < valueB
end

-- construct ui panel data
function FurnitureDeliveryDetailCtrl:ConstructUI(obj)
	self._ui = FurnitureDeliveryDetailPanel.Init(obj)
end

-- fill ui with the data
function FurnitureDeliveryDetailCtrl:SetupUI()
	local ui = self._ui
	self._DeliverFurnitureList = {}
	self._ChildrenItemList = {}
	self:EnableSecondUpdate()
	CtrlManager.AddClick(self, ui.Blocker)

	ui.ScrollView:SetCallback(self, FurnitureDeliveryDetailCtrl.OnCreateItem, FurnitureDeliveryDetailCtrl.OnUpdateItem)

	self:UpdateFurnitureList()

	local iChildrenCount = ui.pObjLayout.transform.childCount
	if iChildrenCount > 0 then
		for idx = 1, iChildrenCount do
			local trans = ui.pObjLayout.transform:GetChild(idx - 1)
			local deliverTime = trans:Find("Time"):GetComponent("UILabel")
			table.insert(self._ChildrenItemList, {item = trans.gameObject, deliverTime = deliverTime})
		end
	end


end

function FurnitureDeliveryDetailCtrl:OnCreateItem()
	local ui = self._ui
	return ui.ObjPool:GetOrCreateObj(ui.EnumPrefabType.FurnitureItem)
end

function FurnitureDeliveryDetailCtrl:OnUpdateItem(itemObj, itemIndex, dataIndex)
	local ui = self._ui
	XDebug.Log('LZ', "OnUpdateItem", itemIndex, dataIndex)
	if dataIndex > #self._DeliverFurnitureList then
		itemObj:SetActive(false)
		return
	end
	local iFurnitureId = self._DeliverFurnitureList[dataIndex].id
	local pItemView = ui.pViewManager:GetView(itemObj, ui.EnumPrefabType.FurnitureItem)
	pItemView.pTxtFurnitureName.text = ConfigUtils.GetHomeFurnitureName(iFurnitureId)
	UIHelper.SetItemIcon(self, pItemView.pSprIcon, iFurnitureId)
	local info = self:GetFurnitureDeliveryInfo(self._DeliverFurnitureList[dataIndex].deliverTime)
	pItemView.pTxtDeliverTime.text = info
	itemObj.name = tostring(dataIndex)
	itemObj:SetActive(true)
end

-- on clicked
function FurnitureDeliveryDetailCtrl:OnClicked(go)
	if go == self._ui.Blocker then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
	end
	return true
end

function FurnitureDeliveryDetailCtrl:UpdateFurnitureList()
	self._DeliverFurnitureList = GameData.GetFurnitureDeliveryData()
	table.sort(self._DeliverFurnitureList, FurnitureSortFunc)
	self._ui.ScrollView:InitScrollView(#self._DeliverFurnitureList)
end

function FurnitureDeliveryDetailCtrl:GetFurnitureDeliveryInfo(deliverTime)
	local info = nil
	local curTime = GameData.GetServerTime()
	if curTime >= deliverTime then
		info = SAFE_LOC("已送达")
	else
		info = string.format("%s后送达", Helper.GetLongTimeString(deliverTime - curTime))
	end
	return info
end

function FurnitureDeliveryDetailCtrl:UpdateImplBySecond(deltaTime)
	for idx = 1, #self._ChildrenItemList do
		local name = self._ChildrenItemList[idx].item.name
		local index = tonumber(name)
		local info = self:GetFurnitureDeliveryInfo(self._DeliverFurnitureList[index].deliverTime)
		self._ChildrenItemList[idx].deliverTime.text = info
	end
end