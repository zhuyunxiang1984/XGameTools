---
--- Created by lizheng.
--- DateTime: 2021-07-12 18:06:33
---

require "FreakPlanet/View/CatchFishStagePreparePanel"
require "FreakPlanet/Controller/CharacterSelectBaseCtrl"

local class = require "FreakPlanet/Utils/middleclass"
CatchFishStagePrepareCtrl = class(CtrlNames.CatchFishStagePrepare, CharacterSelectBaseCtrl)

local POSITION_MOVE_DURATION = 0.5
local PROGRESS_MOVE_DURATION = 0.7

local RANK_NOT_MATCH_COLOR = Color.New(105 / 255,68 / 255, 56 / 255, 1)
local RANK_MATCH_COLOR = Color.New(1, 149 / 255, 0, 1)

local RANKELEMENT_WIDTH = 113

-- load the ui prefab
function CatchFishStagePrepareCtrl:LoadPanel()
	self:CreatePanel("CatchFishStagePrepare")
end

-- construct ui panel data
function CatchFishStagePrepareCtrl:ConstructUI(obj)
	self._ui = CatchFishStagePreparePanel.Init(obj)
end

local _sortAbilityList = nil

local function CharacterSortFunc(idA, idB)
	if idA == nil or idB == nil then
		return false
	end

	local markedA = GameData.IsItemMarked(idA)
	local markedB = GameData.IsItemMarked(idB)
	if markedA ~= markedB then
		return markedA
	end

	local selectableMap = CharacterSelectBaseCtrl.GetCharacterSelectableMap()
	if selectableMap ~= nil then
		local selectableA = selectableMap[idA]
		local selectableB = selectableMap[idB]
		if selectableA ~= selectableB then
			return selectableA
		end
	end

	local valueA = 0
	local valueB = 0

	local sortAbilityId = CharacterSelectBaseCtrl.GetSortValue()
	if sortAbilityId ~= nil then
		valueA = CharacterSelectBaseCtrl.GetAbilityValueOfCharacter(idA, sortAbilityId)
		valueB = CharacterSelectBaseCtrl.GetAbilityValueOfCharacter(idB, sortAbilityId)
	else
		valueA = CharacterSelectBaseCtrl.GetAbilitySumOfCharacter(idA, _sortAbilityList)
		valueB = CharacterSelectBaseCtrl.GetAbilitySumOfCharacter(idB, _sortAbilityList)
	end

	if valueA == valueB then
		valueA = GameData.GetCharacterLevel(idA)
		valueB = GameData.GetCharacterLevel(idB)
	end

	if valueA == valueB then
		valueA = ConfigUtils.GetCharacterRarity(idA)
		valueB = ConfigUtils.GetCharacterRarity(idB)
	end

	if valueA == valueB then
		valueA = ConfigUtils.GetCharacterSortId(idA)
		valueB = ConfigUtils.GetCharacterSortId(idB)
	end

	return valueA > valueB
end

-- fill ui with the data
function CatchFishStagePrepareCtrl:SetupUI()
	local ui = self._ui
	self._fishPoolId = self._parameter.FishPoolId
	local fishPoolInfo = GameDataCatchFish.GetFishPoolInfo(self._fishPoolId)
	ui.StageTitle.text = fishPoolInfo.Name
	self._currentEnergy = 0
	ui.TeamLimitInfo.text = GameDataCatchFish.GetFishPoolBuffDec(self._fishPoolId)
	ui.ItemGridWrap.OnItemUpdate = CatchFishStagePrepareCtrl.OnItemUpdateGlobal
	self._characterSelectMode = CharacterSelectMode.CatchFish
	_sortAbilityList = GameDataCatchFish.GetFishPoolNeedAbilityList(self._fishPoolId)

	-- rankData
	local rankList = GameDataCatchFish.GetFishPoolRankList(self._fishPoolId)
	self._maxRank = #rankList
	self._rankElementCount = #rankList - 1
	--self._rankElementWidth = self._ui.WorkShopAbilities[1].rankBar.width / self._rankElementCount
	self._rankElementWidth = RANKELEMENT_WIDTH
	for idx = 1, #self._ui.WorkShopAbilities do
		self._ui.WorkShopAbilities[idx].rankBar.width = self._rankElementWidth * self._rankElementCount
		-- hintBar
		self._ui.WorkShopAbilities[idx].hintBar.width = self._rankElementWidth * self._rankElementCount
		self._ui.WorkShopAbilities[idx].bgBar.width = self._rankElementWidth * self._rankElementCount
	end
	self:SetupNeedAbilities()
	local numLimit = GameDataCatchFish.GetCatchFishNumCapacity(self._fishPoolId)
	self:InitializeShared(numLimit, CharacterSortFunc, nil)
	self:RecordOriginalCharacters()
	self:OnSelectionModeChanged()
	self:OnSelectedCharacterChanged(false)
	self:RefreshSortState()


	CtrlManager.AddClick(self, ui.Blocker)
	CtrlManager.AddClick(self, ui.ButtonClose)
	CtrlManager.AddClick(self, ui.ButtonGo)
	CtrlManager.AddClick(self, ui.ButtonFilter)
	CtrlManager.AddClick(self, ui.ButtonCharacter.gameObject)
	CtrlManager.AddClick(self, ui.ButtonTeam.gameObject)
	CtrlManager.AddClick(self, ui.ButtonCouple.gameObject)
	-- team
	CtrlManager.AddClick(self, self._ui.ButtonTeamSort)
	CtrlManager.AddClick(self, self._ui.ButtonTeamSortConfirm)
	CtrlManager.AddClick(self, self._ui.ButtonTeamDelete)
	CtrlManager.AddClick(self, self._ui.ButtonTeamDeleteConfirm)

	-- team button default states
	ui.ButtonTeamSort:SetActive(false)
	ui.ButtonTeamSortConfirm:SetActive(false)
	ui.ButtonTeamDelete:SetActive(false)
	ui.ButtonTeamDeleteConfirm:SetActive(false)

	GameNotifier.AddListener(GameEvent.WorkShopLevelChanged, CatchFishStagePrepareCtrl.OnWorkShopLevelChanged, self)
	GameNotifier.AddListener(GameEvent.CharacterSkinChanged, CatchFishStagePrepareCtrl.OnCharacterSkinChanged, self)
	GameNotifier.AddListener(GameEvent.CharacterStageChanged, CatchFishStagePrepareCtrl.OnCharacterStageChanged, self)
	GameNotifier.AddListener(GameEvent.CharacterLevelChanged, CatchFishStagePrepareCtrl.OnCharacterLevelChanged, self)
	GameNotifier.AddListener(GameEvent.CharacterEquipmentUpgraded, CatchFishStagePrepareCtrl.OnCharacterEquipmentUpgraded, self)
	GameNotifier.AddListener(GameEvent.MarkStateChanged, CatchFishStagePrepareCtrl.OnMarkStateChanged, self)
end

-- destroy implementation
function CatchFishStagePrepareCtrl:DestroyImpl()
	GameNotifier.RemoveListener(GameEvent.WorkShopLevelChanged, CatchFishStagePrepareCtrl.OnWorkShopLevelChanged, self)
	GameNotifier.RemoveListener(GameEvent.CharacterSkinChanged, CatchFishStagePrepareCtrl.OnCharacterSkinChanged, self)
	GameNotifier.RemoveListener(GameEvent.CharacterStageChanged, CatchFishStagePrepareCtrl.OnCharacterStageChanged, self)
	GameNotifier.RemoveListener(GameEvent.CharacterLevelChanged, CatchFishStagePrepareCtrl.OnCharacterLevelChanged, self)
	GameNotifier.RemoveListener(GameEvent.CharacterEquipmentUpgraded, CatchFishStagePrepareCtrl.OnCharacterEquipmentUpgraded, self)
	GameNotifier.RemoveListener(GameEvent.MarkStateChanged, CatchFishStagePrepareCtrl.OnMarkStateChanged, self)
end

function CatchFishStagePrepareCtrl:SetupNeedAbilities()
	local rankList = GameDataCatchFish.GetFishPoolRankList(self._fishPoolId)
	--log(Helper.Format(_sortAbilityList))
	XDebug.LogTable("LZ","_sortAbilityList", _sortAbilityList)
	for idx = 1, #self._ui.WorkShopAbilities do
		local abilityId = _sortAbilityList[idx]
		self._ui.WorkShopAbilities[idx].name.text = ConfigUtils.GetAbilityName(abilityId)
		self._ui.WorkShopAbilities[idx].icon.spriteName = ConfigUtils.GetAbilityIcon(abilityId)

		local elementRoot = self._ui.WorkShopAbilities[idx].rankElementRoot
		for m = 1, self._rankElementCount do
			local elementObj = Helper.NewObject(self._ui.AbilityRankElementTemplate, elementRoot)
			elementObj.name = tostring(m)
			elementObj:SetActive(true)
			-- the target value of this rank equals to the next rank value
			local nextRank = m + 1
			local rankInfo = rankList[nextRank]

			local elementTitle = elementObj.transform:Find("Right/Title"):GetComponent("UILabel")
			elementTitle.text = tostring(rankInfo.ExtraPoint)

			local elementValue = elementObj.transform:Find("Right/Value"):GetComponent("UILabel")
			elementValue.text = tostring(rankInfo.NeedAttribute[idx].Num)

			local elementRightMark = elementObj.transform:Find("Right")
			local pos = elementRightMark.localPosition
			pos.x = self._rankElementWidth
			elementRightMark.localPosition = pos

			pos = elementObj.transform.localPosition
			pos.x = (m - 1) * self._rankElementWidth
			elementObj.transform.localPosition = pos
		end

		CtrlManager.AddClick(self, self._ui.WorkShopAbilities[idx].item)
	end
end

function CatchFishStagePrepareCtrl:UpdateImpl(deltaTime)
	CatchFishStagePrepareCtrl.super.UpdateImpl(self, deltaTime)
	if self._rankPosition ~= nil and self._rankPosition.dirty then
		for k, v in pairs(self._ui.WorkShopAbilities) do
			local rankRoot = v.rankRoot
			local pos = rankRoot.localPosition
			local speed = self._rankPosition.speed
			local finished, newX = self:DoLerp(self._rankPosition.target, pos.x, speed, deltaTime)
			pos.x = newX
			rankRoot.localPosition = pos
			self._rankPosition.dirty = not finished
		end
	end

	if self._rankAbilityValues ~= nil then
		local allFinalFinished = true

		for idx = 1, #self._rankAbilityValues do
			if self._rankAbilityValues[idx].finalDirty then
				local currentFinal = self._rankAbilityValues[idx].currentFinal
				local targetFinal = self._rankAbilityValues[idx].targetFinal
				local speed = self._rankAbilityValues[idx].finalSpeed
				local finalFinished, newFinal = self:DoLerp(targetFinal, currentFinal, speed, deltaTime)
				self._rankAbilityValues[idx].currentFinal = newFinal
				self._ui.WorkShopAbilities[idx].rankBar.fillAmount = newFinal
				self._rankAbilityValues[idx].finalDirty = not finalFinished
			end

			if self._rankAbilityValues[idx].realDirty then
				local currentReal = self._rankAbilityValues[idx].currentReal
				local targetReal = self._rankAbilityValues[idx].targetReal
				local speed = self._rankAbilityValues[idx].realSpeed
				local realFinished, newReal = self:DoLerp(targetReal, currentReal, speed, deltaTime)
				self._rankAbilityValues[idx].currentReal = newReal
				self._ui.WorkShopAbilities[idx].hintBar.fillAmount = newReal
				self._rankAbilityValues[idx].realDirty = not realFinished
			end

			if self._rankAbilityValues[idx].finalDirty then
				allFinalFinished = false
			end
		end

		if allFinalFinished and self._lastRank ~= self._currentRank then
			self:RefreshRankElementStatus()
			self:RefreshCurrentEnergy()
		end
	end
end

function CatchFishStagePrepareCtrl:DoLerp(targetValue, currentValue, speed, deltaTime)
	local diff = (targetValue - currentValue)
	local sign = Helper.GetSign(diff)
	if sign == 0 then
		return true, currentValue
	end

	local finished = false
	local newValue = sign * speed * deltaTime + currentValue
	if sign > 0 and newValue > targetValue then
		newValue = targetValue
		finished = true
	end

	if sign < 0 and newValue < targetValue then
		newValue = targetValue
		finished = true
	end

	return finished, newValue
end

function CatchFishStagePrepareCtrl:RefreshCharacterAbilities()
	local globalBuffList = self:GetArenaAndCoupleSkills()
	local selectedCharacters = self:GetSelectedCharacterList()
	local characterAbilityMaps = GameData.GetGroupAbilityMap(selectedCharacters, nil, globalBuffList)

	self._totalAbilityMap = {}
	for _, abilityMap in pairs(characterAbilityMaps) do
		for abilityId, abilityValue in pairs(abilityMap) do
			local preValue = self._totalAbilityMap[abilityId] or 0
			self._totalAbilityMap[abilityId] = preValue + abilityValue
		end
	end

	local isFirstEnter = (self._rankAbilityValues == nil)

	if self._rankAbilityValues == nil then
		self._rankAbilityValues = {}
	end

	if self._rankPosition == nil then
		self._rankPosition = {}
	end

	self._currentRank = GameDataCatchFish.GetFishPoolRankByAbilityMap(self._fishPoolId, self._totalAbilityMap)
	local startRankToShow = self:GetStartRankToShow()
	local targetPosition = self._ui.RankOriginPosition - (startRankToShow - 1) * self._rankElementWidth

	for idx = 1, #self._ui.WorkShopAbilities do
		local abilityId = _sortAbilityList[idx]
		local abilityValue = self._totalAbilityMap[abilityId] or 0
		self._ui.WorkShopAbilities[idx].currentValue.text = tostring(abilityValue)
		local finalPercent, realPercent = self:GetShowProgressOfAbility(idx, abilityValue)

		local rankRoot = self._ui.WorkShopAbilities[idx].rankRoot
		local rankRootPos = rankRoot.localPosition

		-- move target
		if isFirstEnter then
			rankRootPos.x = targetPosition
			rankRoot.localPosition = rankRootPos

			self._ui.WorkShopAbilities[idx].rankBar.fillAmount = finalPercent
			self._ui.WorkShopAbilities[idx].hintBar.fillAmount = realPercent
			self._rankAbilityValues[idx] = {
				currentFinal = finalPercent,
				targetFinal = finalPercent,
				finalDirty = false,
				currentReal = realPercent,
				targetReal = realPercent,
				realDirty = false,
			}
			self._rankPosition = {
				target = targetPosition,
				speed = 0,
				dirty = false
			}

			self:RefreshCurrentEnergy()
		else
			local currentFinal = self._rankAbilityValues[idx].currentFinal
			local currentReal = self._rankAbilityValues[idx].currentReal
			self._rankAbilityValues[idx].targetFinal = finalPercent
			self._rankAbilityValues[idx].finalDirty = true
			self._rankAbilityValues[idx].finalSpeed = math.abs(finalPercent - currentFinal) / PROGRESS_MOVE_DURATION
			self._rankAbilityValues[idx].targetReal = realPercent
			self._rankAbilityValues[idx].realDirty = true
			self._rankAbilityValues[idx].realSpeed = math.abs(realPercent - currentReal) / PROGRESS_MOVE_DURATION
			self._rankPosition.target = targetPosition
			self._rankPosition.dirty = true
			self._rankPosition.speed = math.abs(rankRootPos.x - targetPosition) / POSITION_MOVE_DURATION
		end
	end

	-- do refresh here
	if isFirstEnter then
		self:RefreshRankElementStatus()
	end

end

function CatchFishStagePrepareCtrl:RefreshRankElementStatus()
	if self._rankAbilityValues == nil then
		return
	end

	for idx = 1, #self._ui.WorkShopAbilities do
		local elementRoot = self._ui.WorkShopAbilities[idx].rankElementRoot
		for rank = 1, elementRoot.childCount do
			local elementItem = elementRoot:GetChild(rank - 1)
			local titleLabel = elementItem:Find("Right/Title"):GetComponent("UILabel")
			if rank < self._currentRank then
				titleLabel.color = RANK_MATCH_COLOR
			else
				titleLabel.color = RANK_NOT_MATCH_COLOR
			end

		end
	end
end

function CatchFishStagePrepareCtrl:GetStartRankToShow()
	local rank = self._currentRank - 1
	rank = math.max(rank, 1)
	-- the max element to show is 3
	rank = math.min(self._maxRank - 3, rank)

	return rank
end

function CatchFishStagePrepareCtrl:RefreshCurrentEnergy()
	local rankList = GameDataCatchFish.GetFishPoolRankList(self._fishPoolId)
	local rankInfo = rankList[self._currentRank]
	local totalEnergy = rankInfo.ExtraPoint + GameDataCatchFish.GetCatchFishInitEnergy(self._fishPoolId)
	self._currentEnergy = totalEnergy
	self._ui.CurFishEnergy.text = tostring(totalEnergy)
end

function CatchFishStagePrepareCtrl:GetShowProgressOfAbility(abilityIdx, abilityValue)
	local finalPercent = self:GetAbilityRankProgressWithinTopRank(self._currentRank, abilityIdx, abilityValue)

	local realRank = GameDataCatchFish.GetWorkShopRealRankOfAbility(self._fishPoolId, abilityIdx, abilityValue)
	local realPercent = self:GetAbilityRankProgress(realRank, abilityIdx, abilityValue)
	return finalPercent, realPercent
end

function CatchFishStagePrepareCtrl:GetAbilityRankProgressWithinTopRank(rank, abilityIdx, abilityValue)
	local nextRank = rank + 1
	if nextRank > self._maxRank then
		return (rank - 1) / self._rankElementCount
	end

	nextRank = math.min(nextRank, self._maxRank)
	if rank >= nextRank then
		return 1
	end

	local rankList = GameDataCatchFish.GetFishPoolRankList(self._fishPoolId)
	local rankInfo = rankList[rank]
	local nextRankInfo = rankList[nextRank]
	local startValue = rankInfo.NeedAttribute[abilityIdx].Num
	local endValue = nextRankInfo.NeedAttribute[abilityIdx].Num
	abilityValue = math.min(abilityValue, endValue)
	abilityValue = math.max(abilityValue, startValue)

	local percent = (abilityValue - startValue) / (endValue - startValue)
	percent = (percent + rank - 1) / self._rankElementCount
	return percent
end

function CatchFishStagePrepareCtrl:GetAbilityRankProgress(rank, abilityIdx, abilityValue)
	local nextRank = rank + 1
	nextRank = math.min(nextRank, self._maxRank)
	if rank >= nextRank then
		return 1
	end

	local rankList = GameDataCatchFish.GetFishPoolRankList(self._fishPoolId)
	local rankInfo = rankList[rank]
	local nextRankInfo = rankList[nextRank]
	local startValue = rankInfo.NeedAttribute[abilityIdx].Num
	local endValue = nextRankInfo.NeedAttribute[abilityIdx].Num
	abilityValue = math.min(abilityValue, endValue)
	abilityValue = math.max(abilityValue, startValue)

	local percent = (abilityValue - startValue) / (endValue - startValue)
	percent = (percent + rank - 1) / self._rankElementCount
	return percent
end

function CatchFishStagePrepareCtrl:RefreshSortState()
	local sortAbilityId = CharacterSelectBaseCtrl.GetSortValue()
	for idx = 1, #self._ui.WorkShopAbilities do
		local hasAbility = (idx <= #_sortAbilityList)
		if hasAbility and _sortAbilityList[idx] == sortAbilityId then
			self._ui.WorkShopAbilities[idx].selected:SetActive(true)
		else
			self._ui.WorkShopAbilities[idx].selected:SetActive(false)
		end
	end
end

function CatchFishStagePrepareCtrl:RecordOriginalCharacters()
	self._originalCharacters = {}
	for idx = 1, #self._selectedCharacters do
		self._originalCharacters[idx] = self._selectedCharacters[idx].id
	end
end

function CatchFishStagePrepareCtrl:GetInitialCharacters()
	return GameData.GetCatchFishCharacters(self._fishPoolId)
end

function CatchFishStagePrepareCtrl:SaveSelectedCharacters(characterList)
	GameData.SetCatchFishCharacters(self._fishPoolId, characterList)
end


function CatchFishStagePrepareCtrl:RefreshSortState()
	local sortAbilityId = CharacterSelectBaseCtrl.GetSortValue()
	for idx = 1, #self._ui.WorkShopAbilities do
		local hasAbility = (idx <= #_sortAbilityList)
		if hasAbility and _sortAbilityList[idx] == sortAbilityId then
			self._ui.WorkShopAbilities[idx].selected:SetActive(true)
		else
			self._ui.WorkShopAbilities[idx].selected:SetActive(false)
		end
	end
end

function CatchFishStagePrepareCtrl:GetItemPrefabAndPool()
	return self._ui.CharacterItemTemplate, self._ui.CharacterItemPool
end

-- on clicked
function CatchFishStagePrepareCtrl:OnClicked(go)
	local ui = self._ui
	if go == ui.ButtonGo then
		SoundSystem.PlayUIClickSound()
		self:OnCharacterConfirm()

	elseif go == ui.ButtonClose then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
	elseif go.transform.parent == ui.ItemGrid then
		local roleId = tonumber(go.name)
		local characterIdx = self:GetExploreCharacterIdx(roleId)
		if characterIdx ~= nil then
			SoundSystem.PlayUIClickSound()
			self:RemoveExploreCharacterAt(characterIdx)
		else
			--local originalSelected = self:IsOriginalSelected(roleId)
			--if not originalSelected then
			--SoundSystem.PlayWarningSound()
			--return true
			--end
			if #self._selectedCharacters >= self._numLimit then
				SoundSystem.PlayWarningSound()
				self:NotifyCharacterFull()
				return true
			end
			local selectableMap = CharacterSelectBaseCtrl.GetCharacterSelectableMap()
			if not selectableMap[roleId] then
				SoundSystem.PlayWarningSound()
				return true
			end

			SoundSystem.PlayUIClickSound()
			self:AppendExploreCharacter(roleId)
		end
	elseif go.transform.parent == self._ui.CharacterRoot then
		SoundSystem.PlayUIClickSound()
		local characterId = tonumber(go.name)
		local characterIdx = self:GetExploreCharacterIdx(characterId)
		assert(characterIdx ~= nil, "clicked character but not in explore character list: "..go.name)
		self:RemoveExploreCharacterAt(characterIdx)
	elseif go.transform.parent == ui.WorkShopAbilityRoot then
		SoundSystem.PlayUIClickSound()
		local names = Helper.StringSplit(go.name)
		assert(#names == 2, "invalid ability item name: "..tostring(go.name))
		local idx = tonumber(names[2])
		local abilityId = _sortAbilityList[idx]
		local preAbilityId, preSortPower = CharacterSelectBaseCtrl.GetSortValue()
		if abilityId == preAbilityId then
			abilityId = nil
		end
		CharacterSelectBaseCtrl.SetSortValue(abilityId, preSortPower)
		-- only in character mode need to refresh the character items
		if self._currentMode == ExploreSelectionMode.Character then
			self:RecycleGridItems()
			self:OnSelectionModeChanged()
		end
		self:RefreshSortState()
	elseif go == ui.ButtonFilter then
		SoundSystem.PlayUIClickSound()
		self:ShowFilterPanel()
	elseif go == ui.ButtonCharacter.gameObject then
		SoundSystem.PlaySwitchSound()
		CharacterSelectBaseCtrl.ResetFilterName()
		self:RecycleGridItems()
		self._currentMode = ExploreSelectionMode.Character
		self:OnSelectionModeChanged()
	elseif go == ui.ButtonCouple.gameObject then
		SoundSystem.PlaySwitchSound()
		CharacterSelectBaseCtrl.ResetFilterName()
		self:RecycleGridItems()
		self._currentMode = ExploreSelectionMode.Couple
		self:OnSelectionModeChanged()
	elseif go.transform.parent == ui.CoupleGrid then
		local coupleId = tonumber(go.name)
		self:UseCouple(coupleId)
	end
		
	return true
end

function CatchFishStagePrepareCtrl:OnPressed(go, pressed, isLong)
	if pressed and isLong then
		if go.transform.parent == self._ui.ItemGrid then
			SoundSystem.PlayUIClickSound()
			local itemId = tonumber(go.name)
			CtrlManager.OpenPanel(CtrlNames.CharacterQuickDetail, {characterId = itemId})
		elseif go.transform.parent == self._ui.CharacterRoot then
			local characterId = tonumber(go.name)
			self:StartDrag(characterId)
		end
	elseif not pressed and self._dragCharacterId ~= nil then
		self:EndDrag()
	end
end

function CatchFishStagePrepareCtrl:OnCharacterConfirm()
	local characterList = self:GetSelectedCharacterList()
	if #characterList == 0 then
		characterList = nil
	end
	self:SaveSelectedCharacters(characterList)

	if GameDataCatchFish.HasPaidTicketsOfCatchFish(self._fishPoolId) then
		GameDataCatchFish.SetMaxPoint(self._currentEnergy)
		CtrlManager.PopPanel()
		CtrlManager.OpenPanel(CtrlNames.CatchFishMain, { StageId = self._fishPoolId })
	else
		NetManager.Send("FishLevelUnlock", { LevelId = self._fishPoolId }, CatchFishStagePrepareCtrl.OnHandleProto, self)
	end

end

function CatchFishStagePrepareCtrl:ConstructCharacterItem(item, itemId)
	local abilityList = _sortAbilityList
	local sortAbilityId = CharacterSelectBaseCtrl.GetSortValue()
	if sortAbilityId ~= nil then
		abilityList = { sortAbilityId }
	end
	local abilityMap = CharacterSelectBaseCtrl.GetAbilityMapOfCharacter(itemId)
	UIHelper.ConstructWorkShopCharacterItem(self, item, itemId, abilityMap, abilityList)
	local selected = self:IsCharacterSelected(itemId)
	self:RefreshGridItemSelectedState(itemId, selected)
	self:RefreshCharacterStatus(item, itemId)
	-- marked
	local marked = GameData.IsItemMarked(itemId)
	local markedMark = item:Find("Mark/Marked").gameObject
	markedMark:SetActive(marked)
end

function CatchFishStagePrepareCtrl:CanSelectCharacter(itemId)
	return true
end

function CatchFishStagePrepareCtrl:GetCoupleKey()
	return CoupleNodeKey.WorkShop
end

function CatchFishStagePrepareCtrl:MatchableAbilityMap()
	local ret = {}

	ret[AbilityType.CRA] = 1
	ret[AbilityType.AFF] = 1
	ret[AbilityType.STR] = 1
	ret[AbilityType.INT] = 1

	return ret
end


-- skills
function CatchFishStagePrepareCtrl:GetSkillListToScope()
	local ret = {}

	local attributes = {}
	--attributes[EffectAttribute.WorkShopMaxWorkTime] = 1
	--attributes[EffectAttribute.WorkShopGoodsNumber] = 1

	for idx = 1, #self._selectedCharacters do
		local characterId = self._selectedCharacters[idx].id
		local skillList = GameData.GetCharacterSkillList(characterId)
		for skillIdx = 1, #skillList do
			local skillId = skillList[skillIdx].id
			local skillValue = skillList[skillIdx].value
			local effectAttribute = ConfigUtils.GetSkillEffectAttribute(skillId)
			if attributes[effectAttribute] ~= nil then
				table.insert(ret, {id = skillId, value = skillValue, source = characterId})
			end
		end
	end

	return ret
end

function CatchFishStagePrepareCtrl:GetSkillMapOfMembers()
	local attributes = {}
	attributes[EffectAttribute.Ability] = 1

	local characterList = {}
	for idx = 1, #self._selectedCharacters do
		characterList[idx] = self._selectedCharacters[idx].id
	end

	local ret = {}

	for idx = 1, #characterList do
		local characterId = characterList[idx]
		local skillList = GameData.GetCharacterSkillList(characterId)
		for skillIdx = 1, #skillList do
			local skillId = skillList[skillIdx].id
			local skillValue = skillList[skillIdx].value
			if self:ShouldShowMemberSkill(skillId, attributes) then
				local isMatch, matchCount = GameData.IsSkillConditionMatch(skillId, characterId, idx, characterList)
				if isMatch then
					local effectMembers = GameData.GetSkillEffectedMembers(skillId, characterId, idx, characterList)
					if ret[characterId] == nil then
						ret[characterId] = {}
					end
					table.insert(ret[characterId], {id = skillId, value = skillValue, target = effectMembers, matchCount = matchCount})
				end
			end
		end
	end

	return ret
end


function CatchFishStagePrepareCtrl:IsOriginalSelected(characterId)
	for idx = 1, #self._originalCharacters do
		if self._originalCharacters[idx] == characterId then
			return true
		end
	end
	return false
end

function CatchFishStagePrepareCtrl.OnItemUpdateGlobal(itemObj, itemIndex, itemRealIndex)
	local ctrl = CtrlManager.GetCtrlByName(CtrlNames.CatchFishStagePrepare)
	if ctrl ~= nil then
		ctrl:OnItemUpdate(itemObj, itemIndex, itemRealIndex)
	end
end

function CatchFishStagePrepareCtrl:OnHandleProto(proto, data, requestData)
	if proto == "FishLevelUnlock" then
		local goldNum = data.RemainGold
		local diamondNum = data.RemainDiamond

		local fishPoolInfo = GameDataCatchFish.GetFishPoolInfo(self._fishPoolId)
		local curActivityThemeId = GameData.GetCurrentActivityTheme()
		local CostItem = GameData.HasActivityPassport(curActivityThemeId) and fishPoolInfo.PassCheckCostItem or fishPoolInfo.CostItem
		GameData.ConsumeItem(CostItem.Id, CostItem.Num)

		GameData.SetMoney(ItemType.Gold, goldNum)
		GameData.SetMoney(ItemType.Diamond, diamondNum)

		GameData.CheckAndHintGoalsOfCurrentCountType()
		GameDataCatchFish.PaidTicketsOfCatchFish(self._fishPoolId)
		GameDataCatchFish.SetMaxPoint(self._currentEnergy)
		CtrlManager.PopPanel()
		CtrlManager.OpenPanel(CtrlNames.CatchFishMain, { StageId = self._fishPoolId })
	end
end