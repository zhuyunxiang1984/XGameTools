require "FreakPlanet/View/HomeCleanPanel"

local class = require "FreakPlanet/Utils/middleclass"
HomeCleanCtrl  = class(CtrlNames.HomeClean, BaseCtrl)

-- load the ui prefab
function HomeCleanCtrl:LoadPanel()
    self:CreatePanel("HomeClean")
end

-- construct ui panel data
function HomeCleanCtrl:ConstructUI(obj)
	self._ui = HomeCleanPanel.Init(obj)
    self.m_iObstacleId = self._parameter.obstacleId
end

-- fill ui with the data
function HomeCleanCtrl:SetupUI()
    local ui = self._ui
    
    local iObstacleId = self.m_iObstacleId
    local listCostItems = ConfigUtils.GetHomeObstacleCostList(iObstacleId)
    local listGainItems = ConfigUtils.GetHomeObstacleGainList(iObstacleId)

    self:InitItems(ui.tableCostItems, ui.objHomeCostItems, listCostItems)
    self:InitItems(ui.tableGainItems, ui.objHomeGainItems, listGainItems)
    

    CtrlManager.AddClick(self, ui.Blocker)
    CtrlManager.AddClick(self, ui.btnCancel)
    CtrlManager.AddClick(self, ui.btnConfirm)
end

-- on clicked
function HomeCleanCtrl:OnClicked(go)
    local ui = self._ui
    if go == ui.Blocker then
        SoundSystem.PlayUIClickSound()
        self:Close()
    elseif go == ui.btnConfirm then
        SoundSystem.PlayUIClickSound()
        self:OnClickConfirm()
    elseif go == ui.btnCancel then
        SoundSystem.PlayUIClickSound()
        self:Close()
    end
	return true
end

---
function HomeCleanCtrl:InitItems(tableNode, listItems, listDatas)
    for i = 1, #listItems do
        local go =  listItems[i]
        if i <= #listDatas then
            self:UpdateItem(go, listDatas[i])
            go:SetActive(true)
        else
            go:SetActive(false)
        end
    end
    tableNode:Reposition()
end 
function HomeCleanCtrl:UpdateItem(item, data)
    local view = self._ui.pViewManager:GetView(item, 1)
    UIHelper.SetItemIcon(self, view.sprIcon, data.Id)
    view.txtNum.text = "x" .. data.Num
end 

---
function HomeCleanCtrl:OnClickConfirm()
    ProtocolManager.CleanHomeObstacle(self.m_iObstacleId)
    self:Close()
end 