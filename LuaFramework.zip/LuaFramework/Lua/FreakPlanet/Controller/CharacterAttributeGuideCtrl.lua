require "FreakPlanet/View/CharacterAttributeGuidePanel"

local class = require "FreakPlanet/Utils/middleclass"
CharacterAttributeGuideCtrl  = class(CtrlNames.CharacterAttributeGuide, BaseCtrl)

-- load the ui prefab
function CharacterAttributeGuideCtrl:LoadPanel()
	self:CreatePanel("CharacterAttributeGuide")
end

-- construct ui panel data
function CharacterAttributeGuideCtrl:ConstructUI(obj)
	self._ui = CharacterAttributeGuidePanel.Init(obj)
end

-- fill ui with the data
function CharacterAttributeGuideCtrl:SetupUI()
	CtrlManager.AddClick(self, self._ui.Blocker)
end

-- on clicked
function CharacterAttributeGuideCtrl:OnClicked(go)
	if go == self._ui.Blocker then
        SoundSystem.PlayUICancelSound()
        CtrlManager.PopPanel()
	end

	return true
end

