require "FreakPlanet/View/AccountPasswordResetPanel"

local class = require "FreakPlanet/Utils/middleclass"
AccountPasswordResetCtrl  = class(CtrlNames.AccountPasswordReset, BaseCtrl)

-- load the ui prefab
function AccountPasswordResetCtrl:LoadPanel()
	self:CreatePanel("AccountPasswordReset")
end

-- construct ui panel data
function AccountPasswordResetCtrl:ConstructUI(obj)
	self._ui = AccountPasswordResetPanel.Init(obj)
end

-- fill ui with the data
function AccountPasswordResetCtrl:SetupUI()
	self._vcodeTimestamp = nil
	self._ui.ButtonVCode.isEnabled = true
	self._ui.VCodeLeftTime.text = ""

	CtrlManager.AddClick(self, self._ui.Blocker)
	CtrlManager.AddClick(self, self._ui.ButtonConfirm)
	CtrlManager.AddClick(self, self._ui.ButtonVCode.gameObject)
end

-- update per frame
function AccountPasswordResetCtrl:UpdateImpl(deltaTime)
	if self._vcodeTimestamp ~= nil then
		local curTime = os.time()
		local diffTime = curTime - self._vcodeTimestamp
		if diffTime < VCODE_COOLDOWN then
			local leftTime = VCODE_COOLDOWN - diffTime
			self._ui.VCodeLeftTime.text = Helper.GetShortTimeString(leftTime)
		else
			self._ui.ButtonVCode.isEnabled = true
			self._ui.VCodeLeftTime.text = ""
			self._vcodeTimestamp = nil
		end
	end
end

function AccountPasswordResetCtrl:CheckInput(checkVCode)
	local account = self._ui.NickNameSafeInput:GetText()
	if Helper.IsEmptyOrNull(account) then
		SoundSystem.PlayWarningSound()
		CtrlManager.ShowMessageBox({message = SAFE_LOC("loc_global_id_empty"), single = true})
		return false
	end

	local newPassword = self._ui.NewPassword.value
	if Helper.IsEmptyOrNull(newPassword) then
		SoundSystem.PlayWarningSound()
		CtrlManager.ShowMessageBox({message = SAFE_LOC("loc_global_new_password_empty"), single = true})
		return false
	end

	local confirmPassword = self._ui.ConfirmPassword.value
	if newPassword ~= confirmPassword then
		SoundSystem.PlayWarningSound()
		CtrlManager.ShowMessageBox({message = SAFE_LOC("loc_global_password_no_match"), single = true})
		return false
	end

	local phone = self._ui.Phone.value
	if Helper.IsEmptyOrNull(phone) then
		SoundSystem.PlayWarningSound()
		CtrlManager.ShowMessageBox({message = SAFE_LOC("loc_global_cellphone_empty"), single = true})
		return false
	end

	local phoneState = Helper.CheckPhone(phone)
    if phoneState ~= PhoneError.None then
        local msg = Helper.GetPhoneErrorText(phoneState)
        CtrlManager.ShowMessageBox({message = msg, single = true})
        return false
    end

	if checkVCode then
		local vcode = self._ui.VCode.value
		if Helper.IsEmptyOrNull(vcode) then
			SoundSystem.PlayWarningSound()
			CtrlManager.ShowMessageBox({message = SAFE_LOC("loc_global_cellphone_code_empty"), single = true})
			return false
		end
	end

	return true
end

-- on clicked
function AccountPasswordResetCtrl:OnClicked(go)
	if go == self._ui.Blocker then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
	elseif go == self._ui.ButtonConfirm then
		local valid = self:CheckInput(true)
		if valid then
			SoundSystem.PlayUIClickSound()
			NetManager.Send("ResetPassword", {
				Nickname = self._ui.NickNameSafeInput:GetText(),
				NewPassword = Helper.CheckMd5(self._ui.NewPassword.value),
				Phone = self._ui.Phone.value,
				SMSCode = self._ui.VCode.value},
				AccountPasswordResetCtrl.OnHandleProto, 
				self)
		end
	elseif go == self._ui.ButtonVCode.gameObject then
		local valid = self:CheckInput(false)
		if valid then
			SoundSystem.PlayUIClickSound()
			NetManager.Send("ResetPasswordSmsCode", {
				Nickname = self._ui.NickNameSafeInput:GetText(),
				NewPassword = Helper.CheckMd5(self._ui.NewPassword.value),
				Phone = self._ui.Phone.value},
				AccountPasswordResetCtrl.OnHandleProto, 
				self)
		end
	end

	return true
end

function AccountPasswordResetCtrl:OnHandleProto(proto, data, requestData)
	if proto == "ResetPassword" then
		local nickname = requestData.Nickname
		local password = requestData.NewPassword

		GameData.ModifyAccountPassword(nickname, password)
		GameData.Save()

		CtrlManager.PopPanel()
		CtrlManager.ShowMessageBox({message = SAFE_LOC("loc_global_password_change_succeed"), single = true})
	elseif proto == "ResetPasswordSmsCode" then
		self._ui.ButtonVCode.isEnabled = false
		self._vcodeTimestamp = os.time()
		self._ui.VCodeLeftTime.text = ""
		CtrlManager.ShowMessageBox({message = SAFE_LOC("loc_global_cellphone_code_sent"), single = true})
	end
end
