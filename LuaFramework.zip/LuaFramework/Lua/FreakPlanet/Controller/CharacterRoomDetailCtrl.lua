require "FreakPlanet/View/CharacterRoomDetailPanel"

local class = require "FreakPlanet/Utils/middleclass"
CharacterRoomDetailCtrl  = class(CtrlNames.CharacterRoomDetail, BaseCtrl)

-- load the ui prefab
function CharacterRoomDetailCtrl:LoadPanel()
	self:CreatePanel("CharacterRoomDetail")
end

-- construct ui panel data
function CharacterRoomDetailCtrl:ConstructUI(obj)
	self._ui = CharacterRoomDetailPanel.Init(obj)
end

-- fill ui with the data
function CharacterRoomDetailCtrl:SetupUI()
    self:SetupItemGrid()
    CtrlManager.AddClick(self, self._ui.Blocker)
end

function CharacterRoomDetailCtrl:SetupItemGrid()
    local characterId = self._parameter.character
    local roomName = ConfigUtils.GetCharacterRoom(characterId)
    local roomPieces = ConfigUtils.GetRoomPieces(roomName)
    local roomSkillUnlocked = true
    for k, roomPieceId in pairs(roomPieces) do
        local itemObj = Helper.NewObject(self._ui.ItemTemplate, self._ui.ItemGrid)
        itemObj.name = tostring(roomPieceId)
        itemObj:SetActive(true)
        CtrlManager.AddClick(self, itemObj)
        local unlocked = self:ConstructItem(itemObj.transform, roomPieceId)
        if not unlocked then
            roomSkillUnlocked = false
        end
    end

    self._ui.ItemGrid:GetComponent("UIGrid"):Reposition()

    local roomSkillDesc = ConfigUtils.GetRoomSkillDesc(roomName)
    self._ui.SkillRoot:SetActive(roomSkillDesc ~= nil)
    if roomSkillDesc ~= nil then
        if roomSkillUnlocked then
            self._ui.SkillDesc.text = "[42261EFF]"..roomSkillDesc.."[-] [7BFF47FF]"..SAFE_LOC("loc_Activated").."[-]"
        else
            self._ui.SkillDesc.text = "[9F8A83FF]"..roomSkillDesc.."[-] [FF0000FF]"..SAFE_LOC("loc_NotActivated").."[-]"
        end
    end
end

function CharacterRoomDetailCtrl:ConstructItem(item, itemId)
    -- name
    local nameLabel = item:Find("Name"):GetComponent("UILabel")
    nameLabel.text = ConfigUtils.GetRoomPieceName(itemId)
    -- icon
    local icon = item:Find("Icon"):GetComponent("UISprite")
    icon.spriteName = ConfigUtils.GetRoomPieceIcon(itemId)
    -- unlock
    local unlocked = GameData.IsRoomPieceUnlocked(itemId)
    local lockMark = item:Find("Lock").gameObject
    local unlockMark = item:Find("Unlock").gameObject
    lockMark:SetActive(not unlocked)
    unlockMark:SetActive(unlocked)

    if unlocked then
        icon.color = Color.white
    else
        icon.color = LOCK_ICON_COLOR
    end

    return unlocked
end

-- on clicked
function CharacterRoomDetailCtrl:OnClicked(go)

    if go == self._ui.Blocker then
        SoundSystem.PlayUICancelSound()
        CtrlManager.PopPanel()
    elseif go.transform.parent == self._ui.ItemGrid then
        SoundSystem.PlayUIClickSound()
        local itemId = tonumber(go.name)
        CtrlManager.ShowItemDetail({itemId = itemId})
    end

	return true
end
