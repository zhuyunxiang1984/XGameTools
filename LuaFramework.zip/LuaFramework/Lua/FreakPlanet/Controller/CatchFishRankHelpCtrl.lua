require "FreakPlanet/View/CatchFishRankHelpPanel"

local class = require "FreakPlanet/Utils/middleclass"
CatchFishRankHelpCtrl  = class(CtrlNames.CatchFishRankHelp, BaseCtrl)

-- load the ui prefab
function CatchFishRankHelpCtrl:LoadPanel()
	self:CreatePanel("CatchFishRankHelp")
end

-- construct ui panel data
function CatchFishRankHelpCtrl:ConstructUI(obj)
	self._ui = CatchFishRankHelpPanel.Init(obj)
end

-- fill ui with the data
function CatchFishRankHelpCtrl:SetupUI()
	CtrlManager.AddClick(self, self._ui.Blocker)
end

-- on clicked
function CatchFishRankHelpCtrl:OnClicked(go)
	if go == self._ui.Blocker then
		SoundSystem.PlayUICancelSound()
		self:Close()
	end
	return true
end
