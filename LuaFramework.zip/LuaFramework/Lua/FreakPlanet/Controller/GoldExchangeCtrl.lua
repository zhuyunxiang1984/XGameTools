require "FreakPlanet/View/GoldExchangePanel"

local class = require "FreakPlanet/Utils/middleclass"
GoldExchangeCtrl  = class(CtrlNames.GoldExchange, BaseCtrl)

-- load the ui prefab
function GoldExchangeCtrl:LoadPanel()
	self:CreatePanel("GoldExchange")
end

-- construct ui panel data
function GoldExchangeCtrl:ConstructUI(obj)
	self._ui = GoldExchangePanel.Init(obj)
end

-- fill ui with the data
function GoldExchangeCtrl:SetupUI()
    self._ui.OneDiamondNum.text = tostring(DiamondToGold.Diamond)
    self._ui.OneGoldNum.text = tostring(DiamondToGold.Gold)

    self._ui.TenDiamondNum.text = tostring(DiamondToGold.Diamond * DiamondToGold.FastExchangeCount)
    self._ui.TenGoldNum.text = tostring(DiamondToGold.Gold * DiamondToGold.FastExchangeCount)

    self._ui.ExchangeOneLabel.text = DiamondToGold.ExchangeDesc
    self._ui.ExchangeTenLabel.text = DiamondToGold.FastExchangeDesc
	
    CtrlManager.AddClick(self, self._ui.Blocker)
    CtrlManager.AddClick(self, self._ui.ButtonExchangeOne)
    CtrlManager.AddClick(self, self._ui.ButtonExchangeTen)
end

function GoldExchangeCtrl:ConfirmExchangeOne()
    NetManager.Send("ExchangeGold", {ExchangeMul = 1}, GoldExchangeCtrl.OnHandleProto, self)
end

function GoldExchangeCtrl:ConfirmExchangeTen()
    NetManager.Send("ExchangeGold", {ExchangeMul = DiamondToGold.FastExchangeCount}, GoldExchangeCtrl.OnHandleProto, self)
end

-- on clicked
function GoldExchangeCtrl:OnClicked(go)

    if go == self._ui.Blocker then
        SoundSystem.PlayUICancelSound()
        CtrlManager.PopPanel()
    elseif go == self._ui.ButtonExchangeOne then
        local curValue = GameData.GetMoney(ItemType.Diamond)
        if curValue < DiamondToGold.Diamond then
            SoundSystem.PlayWarningSound()
            CtrlManager.ShowMessageBox({message = SAFE_LOC("loc_DiamondNotEnough"), single = true})
            return true
        end

        SoundSystem.PlayUIClickSound()
        CtrlManager.ShowMessageBox({message = SAFE_LOC("确认兑换?"), single = false, onConfirm = GoldExchangeCtrl.ConfirmExchangeOne, receiver = self})
    elseif go == self._ui.ButtonExchangeTen then
        local curValue = GameData.GetMoney(ItemType.Diamond)
        if curValue < (DiamondToGold.Diamond * DiamondToGold.FastExchangeCount) then
            SoundSystem.PlayWarningSound()
            CtrlManager.ShowMessageBox({message = SAFE_LOC("loc_DiamondNotEnough"), single = true})
            return true
        end

        SoundSystem.PlayUIClickSound()
        CtrlManager.ShowMessageBox({message = SAFE_LOC("确认兑换?"), single = false, onConfirm = GoldExchangeCtrl.ConfirmExchangeTen, receiver = self})
    end

	return true
end

function GoldExchangeCtrl:OnHandleProto(proto, data, requestData)
    if proto == "ExchangeGold" then
        local goldNum = data.RemainGold
        local diamondNum = data.RemainDiamond
        GameData.SetMoney(ItemType.Gold, goldNum)
        GameData.SetMoney(ItemType.Diamond, diamondNum)
    end
end
