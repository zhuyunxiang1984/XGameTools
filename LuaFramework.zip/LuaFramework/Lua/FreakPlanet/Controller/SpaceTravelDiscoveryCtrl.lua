require "FreakPlanet/View/SpaceTravelDiscoveryPanel"

local class = require "FreakPlanet/Utils/middleclass"
SpaceTravelDiscoveryCtrl  = class(CtrlNames.SpaceTravelDiscovery, BaseCtrl)

local MAX_GOODS_COUNT = 16

-- load the ui prefab
function SpaceTravelDiscoveryCtrl:LoadPanel()
	self:CreatePanel("SpaceTravelDiscovery")
end

-- construct ui panel data
function SpaceTravelDiscoveryCtrl:ConstructUI(obj)
	self._ui = SpaceTravelDiscoveryPanel.Init(obj)
end

-- fill ui with the data
function SpaceTravelDiscoveryCtrl:SetupUI()
	self._seasonId = self._parameter.seasonId
    self._choiceId = self._parameter.choiceId
    self._discoveryId = self._parameter.discoveryId
    self._goodsNumLimit = ConfigUtils.GetSpaceTravelDiscoveryGoodsNumLimit(self._discoveryId)

    self._ui.Title.text = ConfigUtils.GetSpaceTravelDiscoveryName(self._discoveryId)
    self._ui.Desc.text = ConfigUtils.GetSpaceTravelDiscoveryDesc(self._discoveryId)
    self._ui.DiscoveryBG.spriteName = ConfigUtils.GetSpaceTravelDiscoveryBG(self._discoveryId)
    self._ui.GoodsHintRoot:SetActive(false)

    local seasonData = GameData.GetSpaceTravelSeasonData(self._seasonId)
    local goodsList = seasonData.goods
    self._goodsList = {}
    for idx = 1, #goodsList do
        local goodsId = goodsList[idx].id
        local goodsNum = goodsList[idx].num
        self._goodsList[idx] = {id = goodsId, original = goodsNum, selected = 0}
    end

    self._selectedItems = {}

    self:ConstructGoodsItems()
    self:ConstructSelectedItems()
    self:OnSelectedItemChanged()

    for k, v in pairs(self._ui.SelectedItems) do
        CtrlManager.AddClick(self, v.item)
    end

    CtrlManager.AddClick(self, self._ui.ButtonConfirm)
    CtrlManager.AddClick(self, self._ui.ButtonCancel)
end

function SpaceTravelDiscoveryCtrl:OnSelectedItemChanged()
    local curNum = self:CurrentSelectedGoodsNum()
    self._ui.SelectedItemTitle.text = string.format(SAFE_LOC("探索工具%d/%d"), curNum, self._goodsNumLimit)
end

function SpaceTravelDiscoveryCtrl:ConstructGoodsItems()
    if self._ui.GoodsRoot.childCount == 0 then
        for idx = 1, MAX_GOODS_COUNT do
            local itemObj = Helper.NewObject(self._ui.GoodsItemTemplate, self._ui.GoodsRoot)
            itemObj:SetActive(true)
            itemObj.name = tostring(idx)
            CtrlManager.AddClick(self, itemObj)
        end
        self._ui.GoodsRoot:GetComponent("UITable"):Reposition()
    end

    for idx = 1, self._ui.GoodsRoot.childCount do
        local item = self._ui.GoodsRoot:GetChild(idx - 1)
        self:ConstructGoodsItem(item, idx)
    end
end

function SpaceTravelDiscoveryCtrl:ConstructGoodsItem(item, idx)
    local isValid = (idx <= #self._goodsList)
    local icon = item:Find("Icon"):GetComponent("UISprite")
    local numLabel = item:Find("Num"):GetComponent("UILabel")
    icon.gameObject:SetActive(isValid)
    if isValid then
        local itemId = self._goodsList[idx].id
        local originalNum = self._goodsList[idx].original
        local selectedNum = self._goodsList[idx].selected
        UIHelper.SetItemIcon(self,icon, itemId)
        numLabel.text = "x"..tostring(originalNum - selectedNum)
    else
        numLabel.text = ""
    end
end

function SpaceTravelDiscoveryCtrl:ConstructSelectedItems()
    for k, _ in pairs(self._ui.SelectedItems) do
        self:ConstructSelectedItem(k)
    end
end

function SpaceTravelDiscoveryCtrl:ConstructSelectedItem(itemId)
    local selectedNum = self._selectedItems[itemId] or 0
    local v = self._ui.SelectedItems[itemId]
    if v == nil then
        return
    end

    local isValid = (selectedNum > 0)
    v.root:SetActive(isValid)
    if isValid then
        UIHelper.SetItemIcon(self,v.icon, itemId)
        v.num.text = "x"..tostring(selectedNum)
    end
end

function SpaceTravelDiscoveryCtrl:CurrentSelectedGoodsNum()
    local num = 0

    for k, v in pairs(self._selectedItems) do
        num = num + v
    end

    return num
end

function SpaceTravelDiscoveryCtrl:SelectGoodsItemAt(idx)
    -- invalid goods
    if idx > #self._goodsList then
        return false
    end
    -- can't selected
    local itemId = self._goodsList[idx].id
    if self._ui.SelectedItems[itemId] == nil then
        return false, SAFE_LOC("不是工具，不能使用")
    end
    -- check num limit
    local curSelectedNum = self:CurrentSelectedGoodsNum()
    if curSelectedNum >= self._goodsNumLimit then
        return false, SAFE_LOC("已达上限")
    end
    -- number not enough
    local originalNum = self._goodsList[idx].original
    local selectedNum = self._goodsList[idx].selected
    if selectedNum >= originalNum then
        return false, SAFE_LOC("物品不足")
    end

    local preNum = self._selectedItems[itemId] or 0
    self._selectedItems[itemId] = preNum + 1
    self._goodsList[idx].selected = self._goodsList[idx].selected + 1

    local goodsItem = self._ui.GoodsRoot:GetChild(idx - 1)
    self:ConstructGoodsItem(goodsItem, idx)
    self:ConstructSelectedItem(itemId)
    self:OnSelectedItemChanged()

    return true
end

function SpaceTravelDiscoveryCtrl:CancelSelectedItem(itemId)
    local selectedNum = self._selectedItems[itemId] or 0
    if selectedNum == 0 then
        return false
    end

    self._selectedItems[itemId] = selectedNum - 1
    self:ConstructSelectedItem(itemId)

    local itemSlot = nil
    for idx = 1, #self._goodsList do
        if self._goodsList[idx].id == itemId then
            itemSlot = idx
            break
        end
    end

    assert(itemSlot ~= nil, "can't find goods or relic item in item list: "..tostring(itemId))
    self._goodsList[itemSlot].selected = self._goodsList[itemSlot].selected - 1
    
    local goodsItem = self._ui.GoodsRoot:GetChild(itemSlot - 1)
    self:ConstructGoodsItem(goodsItem, itemSlot)
    self:OnSelectedItemChanged()

    return true
end

function SpaceTravelDiscoveryCtrl:GetFinalItems()
    local itemList = {}
    for k, v in pairs(self._selectedItems) do
        if v > 0 then
            table.insert(itemList, {k, v})
        end
    end

    if #itemList == 0 then
        return nil
    else
        return itemList
    end
end

function SpaceTravelDiscoveryCtrl:ShowHint(msg)
    if not self._ui.GoodsHintRoot.activeSelf then
        self._ui.GoodsHintRoot:SetActive(true)
    end
    self._ui.GoodsHintLabel.text = msg
    self._ui.GoodsHintAnimator:Play("Hint", 0, 0)
end

-- on clicked
function SpaceTravelDiscoveryCtrl:OnClicked(go)

    if go.transform.parent == self._ui.GoodsRoot then
        local idx = tonumber(go.name)
        local result, message = self:SelectGoodsItemAt(idx)
        if result then
            SoundSystem.PlayUIClickSound()
        else
            if message ~= nil then
                SoundSystem.PlayWarningSound()
                self:ShowHint(message)
            end
        end
    elseif go.transform.parent == self._ui.SelectedItemRoot then
        local itemId = tonumber(go.name)
        local result = self:CancelSelectedItem(itemId)
        if result then
            SoundSystem.PlayUIClickSound()
        end
    elseif go == self._ui.ButtonConfirm then
        local isValid = CtrlManager.CheckSpaceTravelSeasonValid(self._seasonId, true)
        if not isValid then
            return true
        end

        SoundSystem.PlayUIClickSound()
        local selectedItems = self:GetFinalItems()
        local seasonData = GameData.GetSpaceTravelSeasonData(self._seasonId)
        local scoreCapId = GameData.GetScoreCapOfSpaceTravelSeason(self._seasonId, seasonData.scoreCap)
        NetManager.Send('STChoiceDiscovery', {
            STSeasonID = self._seasonId, 
            STScoreCapID = scoreCapId, 
            SellGoodsList = selectedItems,
        }, SpaceTravelDiscoveryCtrl.OnHandleProto, self)
    elseif go == self._ui.ButtonCancel then
        local isValid = CtrlManager.CheckSpaceTravelSeasonValid(self._seasonId, true)
        if not isValid then
            return true
        end
        
        SoundSystem.PlayUIClickSound()
        local seasonData = GameData.GetSpaceTravelSeasonData(self._seasonId)
        local scoreCapId = GameData.GetScoreCapOfSpaceTravelSeason(self._seasonId, seasonData.scoreCap)
        NetManager.Send('STChoiceCancel', {
            STSeasonID = self._seasonId, 
            STScoreCapID = scoreCapId,
            ChoiceId = self._choiceId,
        }, SpaceTravelDiscoveryCtrl.OnHandleProto, self)
    end

	return true
end

function SpaceTravelDiscoveryCtrl:OnHandleProto(proto, data, requestData)
    if proto == 'STChoiceDiscovery' then
        local seasonId = requestData.STSeasonID
        local goodsList = requestData.SellGoodsList or {}
        local costGoalData = {}
        local gainGoalData = {}
        for k, v in pairs(goodsList) do
            GameData.ConsumeSpaceTravelItem(seasonId, v[1], v[2])
            -- goal
            local e = GameData.SetupItemGoalData(v[1], v[2])
            table.insert(costGoalData, e)
        end
        -- sync status
        GameData.FinishChoiceForSpaceTravelSeason(seasonId, nil)
        local gainGoodsList = data.BuyGoodsList or {}
        local gainCareerPrice = 0
        local parameter = nil
        if #gainGoodsList > 0 then
            parameter = GameData.ConstructSpaceTravelChoiceResultParameter(seasonId, gainGoodsList, data)
            -- career price
            for k, v in pairs(gainGoodsList) do
                gainCareerPrice = gainCareerPrice + ConfigUtils.GetSpaceTravelGoodsPrice(v[1]) * v[2]
                -- goal
                local e = GameData.SetupItemGoalData(v[1], v[2])
                table.insert(gainGoalData, e)
            end
        end
        -- career
        GameData.ModifySpaceTravelCareerData(SpaceTravelCareerType.DiscoveryPrice, gainCareerPrice)
        -- goal
        GameData.DoSpaceTravelGoalSettle(seasonId, TriggerType.DiscoveryCost, costGoalData)
        GameData.DoSpaceTravelGoalSettle(seasonId, TriggerType.Discovery, gainGoalData)
        -- pop panel
        CtrlManager.PopPanel()
        if parameter ~= nil then
            CtrlManager.OpenPanel(CtrlNames.SpaceTravelChoiceResult, parameter)
        else
            GameData.SyncSpaceTravelSeasonBaseData(seasonId, data)
        end

    elseif proto == 'STChoiceCancel' then
        local seasonId = requestData.STSeasonID
        local choiceId = requestData.ChoiceId

        local dropList = GameData.SettleSpaceTravelChoiceCancel(seasonId, choiceId)
        local parameter = nil
        if #dropList > 0 then
            parameter = GameData.ConstructSpaceTravelChoiceResultParameter(seasonId, dropList, data)
        end
        -- pop panel
        CtrlManager.PopPanel()
        if parameter ~= nil then
            CtrlManager.OpenPanel(CtrlNames.SpaceTravelChoiceResult, parameter)
        else
            GameData.SyncSpaceTravelSeasonBaseData(seasonId, data)
        end
    end
end
