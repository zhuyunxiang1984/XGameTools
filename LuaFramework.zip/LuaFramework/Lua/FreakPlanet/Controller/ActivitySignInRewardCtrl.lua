---
--- Created by lizheng.
--- DateTime: 2021-07-20 11:39:38
---

require "FreakPlanet/View/ActivitySignInRewardPanel"

local class = require "FreakPlanet/Utils/middleclass"
ActivitySignInRewardCtrl  = class(CtrlNames.ActivitySignInReward, BaseCtrl)

local DAYS_PER_GROUP = 8
local GRAY_COLOR = Color.New(126 / 255, 126 / 255, 126 / 255, 1)
local NORMAL_COLOR = Color.New(1, 1, 1, 1)

local PURPLE_SPRITE = "GoldFish_SingIn_Base1"
local GRAY_SPRITE = "GoldFish_SingIn_Base3"
local YELLOW_SPRITE = "GoldFish_SingIn_Base2"

local NORMAL_PANEL_POSITION = Vector3.New(0, 0, 0)
local SPECIAL_PANEL_POSITION = Vector3.New(0, -96, 0)

local NORMAL_BGKUANG_POSITION = Vector3.New(0, -401, 0)
local SPECIAL_BGKUANG_POSITION = Vector3.New(0, -283, 0)

local NORMAL_BGKUANG_SIZE_Y = 540
local SPECIAL_BGKUANG_SIZE_Y= 304

local NORMAL_PURCHASE_POSITION = Vector3.New(0, -361, 0)
local SPECIAL_PURCHASE_POSITION = Vector3.New(0, -207, 0)

-- load the ui prefab
function ActivitySignInRewardCtrl:LoadPanel()
	self:CreatePanel("ActivitySignInReward")
end

-- construct ui panel data
function ActivitySignInRewardCtrl:ConstructUI(obj)
	self._ui = ActivitySignInRewardPanel.Init(obj)
end

-- fill ui with the data
function ActivitySignInRewardCtrl:SetupUI()
	local ui = self._ui
	self._signInGroup = GameData.GetActivitySignInGroup(DAYS_PER_GROUP) - 1
	self._currentDay = GameData.GetActivitySignInDays()
	local dayStr = SAFE_LOC("loc_global_x_day")
	ui.SignInDays.text = string.format(dayStr, self._currentDay)
	self:SetupRewardItems()
	CtrlManager.AddClick(self, ui.Blocker)
	CtrlManager.AddClick(self, ui.ButtonPurchase)
	CtrlManager.AddClick(self, ui.ButtonGet)
	GameNotifier.AddListener(GameEvent.CatchFish_PurchasPassportSuccess, ActivitySignInRewardCtrl.OnPurchaseChanged, self)
end

function ActivitySignInRewardCtrl:ConstructRewardItems(rewardItem, dayIndex)
	local rewardId, rewardNum = GameData.GetActivitySignInReward(dayIndex)
	UIHelper.ConstructItemIconAndNum(self, rewardItem, rewardId, rewardNum)

	local dayLabel = rewardItem:Find("Days/Day"):GetComponent("UILabel")
	if dayIndex == self._currentDay then
		dayLabel.text = SAFE_LOC("loc_global_today")
	else
		local str = SAFE_LOC("loc_global_x_day")
		dayLabel.text = string.format(str, dayIndex)
	end
	local mark = rewardItem:Find("Mark").gameObject
	mark:SetActive(GameData.HasYetActivitySignInReward(dayIndex))

	local bg = rewardItem:Find("Round/BG"):GetComponent("UISprite")
	if dayIndex < self._currentDay then
		local str = SAFE_LOC("loc_global_x_day")
		dayLabel.text = string.format(str, dayIndex)
		UIHelper.SetGrayUISpriteOrLabel(rewardItem, GRAY_COLOR)
		bg.spriteName = GRAY_SPRITE
	elseif dayIndex == self._currentDay then
		dayLabel.text = SAFE_LOC("loc_global_today")
		UIHelper.SetGrayUISpriteOrLabel(rewardItem, NORMAL_COLOR)
		bg.spriteName = YELLOW_SPRITE
	else
		local str = SAFE_LOC("loc_global_x_day")
		dayLabel.text = string.format(str, dayIndex)
		UIHelper.SetGrayUISpriteOrLabel(rewardItem, NORMAL_COLOR)
		bg.spriteName = GRAY_SPRITE
	end
end

--- 获取当前需要展示的天数
function ActivitySignInRewardCtrl:GetPreDays()
	local signInRewardList = GameData.GetCurrentActivitySignInList()
	local totalDays = #signInRewardList
	local leftDays = totalDays - self._signInGroup * DAYS_PER_GROUP
	return leftDays >= DAYS_PER_GROUP and DAYS_PER_GROUP or leftDays
end

function ActivitySignInRewardCtrl:SetupRewardItems()
	local preDays = self:GetPreDays()
	for idx = 1, preDays do
		local dayIndex = self._signInGroup * DAYS_PER_GROUP + idx
		local rewardItemObj = Helper.NewObject(self._ui.RewardItemTemplate, self._ui.RewardRoot)
		rewardItemObj.name = tostring(dayIndex)
		rewardItemObj:SetActive(true)
		CtrlManager.AddClick(self, rewardItemObj)
		self:ConstructRewardItems(rewardItemObj.transform, dayIndex)
	end
	self._ui.RewardRoot:GetComponent("UIGrid"):Reposition()
	self._ui.ButtonGet:SetActive(GameData.CanActivitySignIn(self._currentDay))

	local HasActivitySignInPassCheck = GameData.HasActivitySignInPassCheck()
	self._ui.ExtraPass:SetActive(HasActivitySignInPassCheck)
	self._ui.Cat:SetActive(HasActivitySignInPassCheck)

	if HasActivitySignInPassCheck then
		self._ui.SignInPanel.localPosition = NORMAL_PANEL_POSITION
		self._ui.SignInBGKuang.localPosition = NORMAL_BGKUANG_POSITION
		self._ui.SignInBGKuang:GetComponent("UISprite").height = NORMAL_BGKUANG_SIZE_Y
		self._ui.ButtonGet.transform.localPosition = NORMAL_PURCHASE_POSITION

		self._ui.ExtraPass:SetActive(true)
		local extraActivityRewards = GameData.GetCurrentActivityExtraDailyReward()
		local curActivityThemeId = GameData.GetCurrentActivityTheme()
		local isActivityPassportAvaliable = GameData.HasActivityPassport(curActivityThemeId)
		for idx = 1, #self._ui.ExtraPassItem do
			local passItem = self._ui.ExtraPassItem[idx]
			local extraRewardData = extraActivityRewards[idx]
			local num = isActivityPassportAvaliable and extraRewardData.Num or extraRewardData.Num * GameData.GetActivitySignInDays()
			UIHelper.ConstructItemIconAndNum(self, passItem.item, extraRewardData.Value, num)
			passItem.lock:SetActive(not isActivityPassportAvaliable)
			passItem.bg.spriteName = isActivityPassportAvaliable and YELLOW_SPRITE or PURPLE_SPRITE
		end
		self._ui.ExtraPassTitle.text = isActivityPassportAvaliable and SAFE_LOC("转运中") or SAFE_LOC("获取")

	else
		self._ui.ExtraPass:SetActive(false)
		self._ui.SignInPanel.localPosition = SPECIAL_PANEL_POSITION
		self._ui.SignInBGKuang.localPosition = SPECIAL_BGKUANG_POSITION
		self._ui.SignInBGKuang:GetComponent("UISprite").height = SPECIAL_BGKUANG_SIZE_Y
		self._ui.ButtonGet.transform.localPosition = SPECIAL_PURCHASE_POSITION
	end
end

-- on clicked
function ActivitySignInRewardCtrl:OnClicked(go)
	if go == self._ui.Blocker then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
	elseif go == self._ui.ButtonGet then
		if GameData.CanActivitySignIn(self._currentDay) then
			SoundSystem.PlayUIClickSound()
			NetManager.Send("ActivitySignIn", {}, ActivitySignInRewardCtrl.OnHandleProto, self)
		else
			SoundSystem.PlayUICancelSound()
		end
	elseif go.transform.parent == self._ui.RewardRoot then
		local dayIndex = tonumber(go.name)
		if GameData.CanActivitySignIn(dayIndex) then
			SoundSystem.PlayUIClickSound()
			NetManager.Send("ActivitySignIn", {}, ActivitySignInRewardCtrl.OnHandleProto, self)
		else
			SoundSystem.PlayWarningSound()
		end
	elseif go == self._ui.ButtonPurchase then
		SoundSystem.PlayUIClickSound()
		local curActivityThemeId = GameData.GetCurrentActivityTheme()
		local isActivityPassportAvaliable = GameData.HasActivityPassport(curActivityThemeId)
		if not isActivityPassportAvaliable then
			XDebug.Log("LZ", "Passport Avaliable!!!")
			CtrlManager.OpenPanel(CtrlNames.ActivityBuyPassport)
		end
	end
	return true
end

function ActivitySignInRewardCtrl:OnHandleProto(proto, data, requestData)
	if proto == "ActivitySignIn" then
		local goldNum = data.RemainGold
		local diamondNum = data.RemainDiamond

		GameData.MarkActivitySignIn()
		local rewardList = data.RewardList
		local rewardNum = #rewardList
		for idx = 1, rewardNum do
			GameData.CollectItem(rewardList[idx].ItemId, data.RewardList[idx].Num, true)
		end
		
		GameData.SetMoney(ItemType.Gold, goldNum)
		GameData.SetMoney(ItemType.Diamond, diamondNum)
		GameData.CheckAndHintGoalsOfCurrentCountType()
		self:ToggleStateOfRewardItem(self._currentDay)
	end
end

function ActivitySignInRewardCtrl:ToggleStateOfRewardItem(dayIndex)
	local item = self._ui.RewardRoot:Find(tostring(dayIndex))
	self._currentDay = GameData.GetActivitySignInDays()
	if item ~= nil then
		self:ConstructRewardItems(item, self._currentDay)
	end
	self._ui.ButtonGet:SetActive(GameData.CanActivitySignIn(self._currentDay))
end

function ActivitySignInRewardCtrl:DestroyImpl()
	GameNotifier.RemoveListener(GameEvent.CatchFish_PurchasPassportSuccess, ActivitySignInRewardCtrl.OnPurchaseChanged, self)
end

function ActivitySignInRewardCtrl:OnPurchaseChanged()
	self:RefreshExtraRewardUI()
end

function ActivitySignInRewardCtrl:RefreshExtraRewardUI()
	local HasActivitySignInPassCheck = GameData.HasActivitySignInPassCheck()
	self._ui.ExtraPass:SetActive(HasActivitySignInPassCheck)
	self._ui.Cat:SetActive(HasActivitySignInPassCheck)

	if HasActivitySignInPassCheck then
		self._ui.SignInPanel.localPosition = NORMAL_PANEL_POSITION
		self._ui.SignInBGKuang.localPosition = NORMAL_BGKUANG_POSITION
		self._ui.SignInBGKuang:GetComponent("UISprite").height = NORMAL_BGKUANG_SIZE_Y
		self._ui.ButtonGet.transform.localPosition = NORMAL_PURCHASE_POSITION

		self._ui.ExtraPass:SetActive(true)
		local extraActivityRewards = GameData.GetCurrentActivityExtraDailyReward()
		local curActivityThemeId = GameData.GetCurrentActivityTheme()
		local isActivityPassportAvaliable = GameData.HasActivityPassport(curActivityThemeId)
		for idx = 1, #self._ui.ExtraPassItem do
			local passItem = self._ui.ExtraPassItem[idx]
			local extraRewardData = extraActivityRewards[idx]
			local num = isActivityPassportAvaliable and extraRewardData.Num or extraRewardData.Num * GameData.GetActivitySignInDays()
			UIHelper.ConstructItemIconAndNum(self, passItem.item, extraRewardData.Value, num)
			passItem.lock:SetActive(not isActivityPassportAvaliable)
			passItem.bg.spriteName = isActivityPassportAvaliable and YELLOW_SPRITE or PURPLE_SPRITE
		end
		self._ui.ExtraPassTitle.text = isActivityPassportAvaliable and SAFE_LOC("转运中") or SAFE_LOC("获取")

	else
		self._ui.ExtraPass:SetActive(false)
		self._ui.SignInPanel.localPosition = SPECIAL_PANEL_POSITION
		self._ui.SignInBGKuang.localPosition = SPECIAL_BGKUANG_POSITION
		self._ui.SignInBGKuang:GetComponent("UISprite").height = SPECIAL_BGKUANG_SIZE_Y
		self._ui.ButtonGet.transform.localPosition = SPECIAL_PURCHASE_POSITION
	end
end