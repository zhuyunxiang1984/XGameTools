require "FreakPlanet/View/CharacterSkinPanel"

local class = require "FreakPlanet/Utils/middleclass"
CharacterSkinCtrl  = class(CtrlNames.CharacterSkin, BaseCtrl)
----------------------------------------------------------
-- load the ui prefab
function CharacterSkinCtrl:LoadPanel()
	self:CreatePanel("CharacterSkin")
end

-- construct ui panel data
function CharacterSkinCtrl:ConstructUI(obj)
	self._ui = CharacterSkinPanel.Init(obj)
end

-- notity it has been focused
function CharacterSkinCtrl:NotifyFocus()
    self:RefreshChallengeCost()
end

-- fill ui with the data
function CharacterSkinCtrl:SetupUI()
	self._characterId = self._parameter.characterId
	self._currentSkinId = self._parameter.skinId
    self._enableChallenge = self._parameter.enableChallenge

	self._skinList = ConfigUtils.GetCharacterSkinList(self._characterId)
	self:OnSkinSlotChanged()

	--[[
	for idx = 1, #self._ui.SkinSlots do
		CtrlManager.AddClick(self, self._ui.SkinSlots[idx].item)
	end
	--]]

	for idx = 1, #self._ui.ChallengeCostItems do
		CtrlManager.AddClick(self, self._ui.ChallengeCostItems[idx].item)
	end

	CtrlManager.AddClick(self, self._ui.Blocker)
	CtrlManager.AddClick(self, self._ui.ButtonChallenge)
	CtrlManager.AddClick(self, self._ui.ButtonUse)
	CtrlManager.AddClick(self, self._ui.ButtonUnuse)
    CtrlManager.AddClick(self, self._ui.ButtonReplay)
	CtrlManager.AddClick(self, self._ui.ButtonGotoShop)

	CtrlManager.AddClick(self, self._ui.ButtonPreview)
	CtrlManager.AddClick(self, self._ui.ButtonNext)
end

function CharacterSkinCtrl:OnSkinSlotChanged()
	local currentSkinId = GameData.GetCharacterSkin(self._characterId)
	local unlockChallenge = ConfigUtils.GetSkinUnlockChallenge(self._currentSkinId)
	local skinUnlocked = GameData.IsSkinUnlocked(self._currentSkinId)
	local isCurrentSkin = (currentSkinId == self._currentSkinId)
    if unlockChallenge ~= nil then
        self._challengeSpeechId = ConfigUtils.GetChallengeAcceptSpeech(unlockChallenge)
    else
        self._challengeSpeechId = nil
    end

    self._challengeCost = {}
    if self._enableChallenge and unlockChallenge and not skinUnlocked and not GameData.IsChallengeUnlocked(unlockChallenge) then
        self._challengeCost = ConfigUtils.GetChallengeUnlockCost(unlockChallenge)
    end
    -- set cost icon
    for idx = 1, #self._ui.ChallengeCostItems do
        local hasItem = (idx <= #self._challengeCost)
        self._ui.ChallengeCostItems[idx].item:SetActive(hasItem)
        if hasItem then
            local itemId = self._challengeCost[idx].Value
            local itemUnlocked = GameData.IsItemUnlocked(itemId)
            -- icon
            local icon = UIHelper.ConstructItemIconAndNum(self, self._ui.ChallengeCostItems[idx].root, itemId, nil)
            if itemUnlocked then
                icon.color = Color.white
            else
                icon.color = LOCK_ICON_COLOR
            end
        end
    end
    -- set cost num
    self:RefreshChallengeCost()

	UIHelper.SetCharacterIconWithSkin(self, self._ui.SkinIcon, self._currentSkinId)
	if skinUnlocked then
		self._ui.SkinIcon.color = Color.white
	else
		self._ui.SkinIcon.color = Color.black
	end
	self._ui.SkinName.text = ConfigUtils.GetSkinName(self._currentSkinId)
	self._ui.SkinDesc.text = ConfigUtils.GetSkinDesc(self._currentSkinId, skinUnlocked)
	self._ui.SkinSkill.text = ConfigUtils.GetSkinSkillDesc(self._currentSkinId)
	self._ui.SkinUsedMark:SetActive(isCurrentSkin)
	--
	self._ui.ButtonChallenge:SetActive(self._enableChallenge and not skinUnlocked and unlockChallenge ~= nil)
	self._ui.ButtonGotoShop:SetActive(self._enableChallenge and not skinUnlocked and unlockChallenge == nil and self:IsSellInStore(skinId))
	self._ui.ButtonUse:SetActive(skinUnlocked and not isCurrentSkin)
	self._ui.ButtonUnuse:SetActive(skinUnlocked and isCurrentSkin)
    self._ui.ButtonReplay:SetActive(skinUnlocked and self._challengeSpeechId ~= nil)

	self:RefreshArrowUI()
end

function CharacterSkinCtrl:IsSellInStore(itemId)
	return GameDataClothesShop.IsSellInStore(itemId)
end


function CharacterSkinCtrl:RefreshChallengeCost()
    self._challengeCostEnough = true
    for idx = 1, #self._ui.ChallengeCostItems do
        local hasItem = (idx <= #self._challengeCost)
        if hasItem then
            local itemId = self._challengeCost[idx].Value
            local needNum = self._challengeCost[idx].Num
            local currentNum = GameData.GetItemNum(itemId)
            -- num
            local numLabel = self._ui.ChallengeCostItems[idx].num
            numLabel.text = tostring(currentNum).."/"..tostring(needNum)
            if currentNum < needNum then
                numLabel.color = Color.red
                self._challengeCostEnough = false
            else
                numLabel.color = Color.black
            end
        end
    end
end

function CharacterSkinCtrl:CloseToChallenge()
	local challengeId = ConfigUtils.GetSkinUnlockChallenge(self._currentSkinId)
	CtrlManager.PopPanel()
	CtrlManager.OpenPanel(CtrlNames.ExploreCharacter, {challengeId = challengeId})
end

-- on clicked
function CharacterSkinCtrl:OnClicked(go)
	if go == self._ui.Blocker then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
	elseif go == self._ui.ButtonChallenge then
		local challengeId = ConfigUtils.GetSkinUnlockChallenge(self._currentSkinId)
		local challengeUnlocked = GameData.IsChallengeUnlocked(challengeId)
		if not challengeUnlocked and not self._challengeCostEnough then
			SoundSystem.PlayWarningSound()
			CtrlManager.ShowMessageBox({message = SAFE_LOC("挑战物品不足"), single = true})
			return true
		end
		SoundSystem.PlayUIClickSound()
		CtrlManager.DoWaitTransition(CtrlNames.ExploreCharacter, self, CharacterSkinCtrl.CloseToChallenge)
	elseif go == self._ui.ButtonGotoShop then
		SoundSystem.PlayUIClickSound()
		CtrlManager.DoWaitTransition(CtrlNames.ClothesShop, self, function()
			CtrlManager.PopPanel()
			CtrlManager.OpenPanel(CtrlNames.ClothesShop)
		end)
	elseif go == self._ui.ButtonUse then
		SoundSystem.PlayUIClickSound()
		NetManager.Send("AlterSkin", {Char = self._characterId, Skin = self._currentSkinId}, CharacterSkinCtrl.OnHandleProto, self)
	elseif go == self._ui.ButtonUnuse then
		SoundSystem.PlayUIClickSound()
		NetManager.Send("AlterSkin", {Char = self._characterId, Skin = INVALID_ID_0}, CharacterSkinCtrl.OnHandleProto, self)
    elseif go == self._ui.ButtonReplay then
        SoundSystem.PlayUIClickSound()
        -- depth = 57
        CtrlManager.LaunchPanel(CtrlNames.GoalDialog, {goalSpeechList = {self._challengeSpeechId}})
    elseif go.transform.parent == self._ui.ChallengeCostRoot then
    	SoundSystem.PlayUIClickSound()
    	local names = Helper.StringSplit(go.name)
        assert(#names == 2, "invalid equipment item name: "..tostring(go.name))
        local itemIdx = tonumber(names[2])
        local unlockChallenge = ConfigUtils.GetSkinUnlockChallenge(self._currentSkinId)
		local challengeCost = ConfigUtils.GetChallengeUnlockCost(unlockChallenge)
        local itemId = challengeCost[itemIdx].Value
        CtrlManager.ShowItemDetail({itemId = itemId})
	elseif go == self._ui.ButtonPreview then
		self:SwitchSkinUI(false)
	elseif go == self._ui.ButtonNext then
		self:SwitchSkinUI(true)
	end
	return true
end

function CharacterSkinCtrl:SwitchSkinUI(isNext)
	local slot = Helper.IndexOfArray(self._skinList, self._currentSkinId)
	if slot then
		if isNext then
			if slot ~= #self._skinList then
				slot = slot + 1
			end
		else
			if slot ~= 1 then
				slot = slot - 1
			end
		end
		self._currentSkinId = self._skinList[slot]
		self:OnSkinSlotChanged()
		self:RefreshArrowUI()
	end
end

function CharacterSkinCtrl:RefreshArrowUI()
	local slot = Helper.IndexOfArray(self._skinList, self._currentSkinId)
	if slot then
		self._ui.ButtonPreview:SetActive(slot ~= 1)
		self._ui.ButtonNext:SetActive(slot ~= #self._skinList)
		self._ui.skinSlot.gameObject:SetActive(true)
		self._ui.skinSlot.text = string.format("%d/%d",slot, #self._skinList)
	else
		self._ui.skinSlot.gameObject:SetActive(false)
	end
end

function CharacterSkinCtrl:OnHandleProto(proto, data, requestData)
	if proto == "AlterSkin" then
		local characterId = requestData.Char
		local skinId = requestData.Skin
		GameData.SetCharacterSkin(characterId, skinId)
		GameData.CheckAndHintGoalsOfCurrentCountType()
		CtrlManager.PopPanel()
	end
end
