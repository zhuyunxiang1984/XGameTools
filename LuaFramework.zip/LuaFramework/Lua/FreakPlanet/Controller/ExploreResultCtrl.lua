require "FreakPlanet/View/ExploreResultPanel"

local class = require "FreakPlanet/Utils/middleclass"
ExploreResultCtrl  = class(CtrlNames.ExploreResult, BaseCtrl)

PROGRESS_SPEED = 1.5
AREA_LIMIT = 2

local ResultState = {
    Event = "Event",
    Drop = "Drop",
    Pet = "Pet",
}

-- load the ui prefab
function ExploreResultCtrl:LoadPanel()
	self:CreatePanel("ExploreResult")
end

-- construct ui panel data
function ExploreResultCtrl:ConstructUI(obj)
	self._ui = ExploreResultPanel.Init(obj)
end

-- fill ui with the data
function ExploreResultCtrl:SetupUI()
    self._planetAreaId = self._parameter.areaId
    self._activityThemeId = self._parameter.themeId
    if self._planetAreaId ~= nil then
        self._exploreCostTime, self._eventList, self._dropList, self._catchPetList, self._enemyList = GameData.GetPlanetAreaExploreResult(self._planetAreaId)
    elseif self._activityThemeId ~= nil then
        self._exploreCostTime, self._eventList, self._dropList, self._catchPetList, self._enemyList = GameData.GetActivityExploreResult(self._activityThemeId)
    end

    if #self._eventList > 0 then
        self._currentState = ResultState.Event
    else
        self._currentState = ResultState.Drop
    end
    -- just in case
    self._ui.NewPetPanel.gameObject:SetActive(false)
    self:OnCurrentStateChanged()

	CtrlManager.AddClick(self, self._ui.EventBlocker)
    CtrlManager.AddClick(self, self._ui.DropBlocker)
    CtrlManager.AddClick(self, self._ui.PetBlocker)
    CtrlManager.AddClick(self, self._ui.NewPetBlocker)

    if self._planetAreaId ~= nil then
        self:CheckTutorial()
    end
end

function ExploreResultCtrl:OnCurrentStateChanged()
    self._ui.EventPanel.gameObject:SetActive(self._currentState == ResultState.Event)
    self._ui.DropPanel.gameObject:SetActive(self._currentState == ResultState.Drop)
    self._ui.PetPanel.gameObject:SetActive(self._currentState == ResultState.Pet)

    if self._currentState == ResultState.Event then
        self:ShowEventPanel()
    elseif self._currentState == ResultState.Drop then
        self:ShowDropPanel()
    elseif self._currentState == ResultState.Pet then
        self:ShowPetPanel()
    else
        assert(false, "un-handled state: "..tostring(self._currentState))
    end
end

function ExploreResultCtrl:ShowEventPanel()
    SoundSystem.PlaySoundOfName(SoundNames.ExploreResultEvent)
    if self._planetAreaId ~= nil then
        self._eventUnlockNumOfThisExplore, self._eventTotalNumOfThisExplore = GameData.GetEventUnlockOfArea(self._planetAreaId)
    elseif self._activityThemeId ~= nil then
        self._eventUnlockNumOfThisExplore, self._eventTotalNumOfThisExplore = GameData.GetEventUnlockOfActivityExplore(self._activityThemeId)
    end
    self._eventIdx = 1
    self:OnEventIndexChanged()
end

function ExploreResultCtrl:ShowDropPanel()
    self._ui.ExploreTime.text = SAFE_LOC("探索时间：")..Helper.GetLongTimeString(self._exploreCostTime)

    -- always show 9 drop items
    local itemCount = 9
	for idx = 1, itemCount do
		local go = Helper.NewObject(self._ui.DropItemTemplate, self._ui.DropRoot)
		go:SetActive(true)
        go.name = tostring(idx)
		-- construct item
		self:ConstructDropItem(go.transform, idx)
	end

    for idx = 1, #self._enemyList do
        local go = Helper.NewObject(self._ui.EnemyItemTemplate, self._ui.ExploreRoot)
        go:SetActive(true)
        go.name = tostring(idx)
        -- construct item
        self:ConstructEnemyItem(go.transform, idx)
    end

	self._ui.DropRoot:GetComponent("UIGrid"):Reposition()
    self._ui.ExploreRoot:GetComponent("UIGrid"):Reposition()
    self._ui.DropAnimator:Play("Victory", 0)
end

function ExploreResultCtrl:ShowPetPanel()
    local catchPets = {}
    local noUseCatchItem = {}
    local hasCatchedPet = false
    local hasSpecialPet = false

    self._newPetList = {}
    local handledNewPet = {}
    local noCatchPet = true

    for idx = 1, #self._catchPetList do
        local catchItemId = self._catchPetList[idx].itemId
        local catchItemStatus = self._catchPetList[idx].itemStatus
        local petId = self._catchPetList[idx].petId
        local petState = self._catchPetList[idx].petState
        local hasPet = ConfigUtils.IsValidItem(petId)
            
        if catchItemStatus == 0 then
            local preNum = noUseCatchItem[catchItemId] or 0
            noUseCatchItem[catchItemId] = preNum + 1
        elseif hasPet then
            if catchPets[petId] == nil then
                catchPets[petId] = {num = 0, success = {}, fail = {}}
            end

            if petState == 1 then
                catchPets[petId].num = catchPets[petId].num + 1
                local preNum = catchPets[petId].success[catchItemId] or 0
                catchPets[petId].success[catchItemId] = preNum + 1

                hasCatchedPet = true
                local petRarity = ConfigUtils.GetPetRarity(petId)
                if petRarity >= 3 then
                    hasSpecialPet = true
                end

                if handledNewPet[petId] == nil and not GameData.IsPetUnlocked(petId) then
                    table.insert(self._newPetList, {petId = petId, catchItemId = catchItemId})
                    handledNewPet[petId] = 1
                end
            else
                local preNum = catchPets[petId].fail[catchItemId] or 0
                catchPets[petId].fail[catchItemId] = preNum + 1
            end

            noCatchPet = false
        end
    end

    self._ui.PetNoCatch:SetActive(noCatchPet)
    if noCatchPet then
        self._ui.PetPanelTitle.text = SAFE_LOC("没抓到")
    else
        self._ui.PetPanelTitle.text = SAFE_LOC("抓到了吗")
    end

    for petId, v in pairs(catchPets) do
        local petItemObj = Helper.NewObject(self._ui.PetItemTemplate, self._ui.PetRoot)
        petItemObj.name = tostring(petId)
        petItemObj:SetActive(true)

        local petItem = petItemObj.transform
        self:ConstructPetItem(petItem, petId, v)
    end

    local noUseCatchItemNum = 0
    local MIN_NO_USE_CATCH_ITEM_NUM = 5
    for catchItemId, v in pairs(noUseCatchItem) do
        local catchItemObj = Helper.NewObject(self._ui.CatchItemTemplate, self._ui.CatchItemRoot)
        catchItemObj.name = tostring(catchItemId)
        catchItemObj:SetActive(true)

        local catchItem = catchItemObj.transform
        -- icon
        local catchItemIcon = catchItem:Find("Icon"):GetComponent("UISprite")
        UIHelper.SetItemIcon(self,catchItemIcon, catchItemId)
        -- num
        local numLabel = catchItem:Find("Num"):GetComponent("UILabel")
        numLabel.text = "x"..tostring(v)
        noUseCatchItemNum = noUseCatchItemNum + 1
    end

    for idx = noUseCatchItemNum + 1, MIN_NO_USE_CATCH_ITEM_NUM do
        local catchItemObj = Helper.NewObject(self._ui.CatchItemTemplate, self._ui.CatchItemRoot)
        catchItemObj.name = tostring(-1)
        catchItemObj:SetActive(true)

        local catchItem = catchItemObj.transform
        for m = 1, catchItem.childCount do
            catchItem:GetChild(m - 1).gameObject:SetActive(false)
        end
    end

    local petTable = self._ui.PetRoot:GetComponent("UIGrid")
    petTable:Reposition()
    local catchItemTable = self._ui.CatchItemRoot:GetComponent("UITable")
    catchItemTable:Reposition()
    self._ui.CatchItemScrollView:ResetPosition()
    self._ui.CatchItemScrollView.disableDragIfFits = (noUseCatchItemNum <= MIN_NO_USE_CATCH_ITEM_NUM)

    -- sound
    local soundName = SoundNames.ExploreResultNoPet
    if hasCatchedPet then
        if hasSpecialPet then
            soundName = SoundNames.ExploreResultPetSpecial
        else
            soundName = SoundNames.ExploreResultPetNormal
        end
    end
    SoundSystem.PlaySoundOfName(soundName)

    if #self._newPetList > 0 then
        self:ShowNewPet()
    end
end

function ExploreResultCtrl:ShowNewPet()
    if not self._ui.NewPetPanel.gameObject.activeSelf then
        self._ui.NewPetPanel.gameObject:SetActive(true)
    end

    -- recycle
    for idx = self._ui.NewPetRoot.childCount, 1, -1 do
        local item = self._ui.NewPetRoot:GetChild(idx - 1)
        item.parent = self._ui.NewPetPool
    end

    local petId = self._newPetList[1].petId
    local catchItemId = self._newPetList[1].catchItemId
    table.remove(self._newPetList, 1)

    local catchItemPrefabName = ConfigUtils.GetGoodsTamePrefab(catchItemId)
    local catchItem = self._ui.NewPetPool:Find(catchItemPrefabName)
    if catchItem == nil then
        local catchItemPrefab = self._ui.NewPetTemplateRoot:Find(catchItemPrefabName)
        assert(catchItemPrefab ~= nil, "can't find catch item prefab of name: "..tostring(catchItemPrefabName).."; catch item: "..tostring(catchItemId))
        local catchItemObj = Helper.NewObject(catchItemPrefab.gameObject, self._ui.NewPetRoot)
        catchItemObj:SetActive(true)
        catchItem = catchItemObj.transform
    else
        catchItem.parent = self._ui.NewPetRoot
        catchItem.localPosition = Vector3.zero
        catchItem.localScale = Vector3.one
    end

    -- pet icon
    local petIcon = catchItem:Find("Root/Icon"):GetComponent("UISprite")
    UIHelper.SetCharacterIcon(self, petIcon, petId)

    -- animator
    local animator = catchItem:Find("Root"):GetComponent("Animator")
    animator:Play("Success", 0, 0)
end

function ExploreResultCtrl:OnEventIndexChanged()
    local eventId = self._eventList[self._eventIdx]
    self._ui.EventName.text = ConfigUtils.GetEventName(eventId)
    self._ui.EventDesc.text = ConfigUtils.GetEventDesc(eventId)

    local iconName, iconAtlas, iconBundle = ConfigUtils.GetEventIcon(eventId)
    self._ui.EventIcon.sprite2D = self:DynamicLoadSprite(iconBundle, iconAtlas, iconName)

    local eventRewards = ConfigUtils.GetEventReward(eventId)
    self._ui.EventRewardRoot.gameObject:SetActive(#eventRewards > 0)
    if #eventRewards > 0 then
        local rewardId = eventRewards[1].Value
        local rewardNum = eventRewards[1].Num

        UIHelper.ConstructItemIconAndNum(self, self._ui.EventRewardRoot, rewardId, nil)

        local label = self._ui.EventRewardRoot:Find("Label"):GetComponent("UILabel")
        label.text = "事件奖励："..ConfigUtils.GetItemName(rewardId).."x"..tostring(rewardNum)
    end

    local currentUnlockNum = self._eventUnlockNumOfThisExplore + self._eventIdx
    self._ui.EventProgressLabel.text = "本地区事件"..tostring(currentUnlockNum).."/"..tostring(self._eventTotalNumOfThisExplore)
end

function ExploreResultCtrl:ConstructDropItem(item, idx)
    local hasDrop = (idx <= #self._dropList)
    local root = item:Find("Root")
    root.gameObject:SetActive(hasDrop)
    if hasDrop then
        local dropId = self._dropList[idx].id
        local dropNum = self._dropList[idx].num
        UIHelper.ConstructItemIconAndNum(self, root, dropId, dropNum)

        local isNew = not GameData.IsItemUnlocked(dropId)
        local isEvent = self._dropList[idx].isEvent or false

        local newMark = root:Find("Mark/New").gameObject
        newMark:SetActive(not isEvent and isNew)

        local eventMark = root:Find("Mark/Event").gameObject
        eventMark:SetActive(isEvent)
    end
end

function ExploreResultCtrl:ConstructEnemyItem(item, idx)
    local enemyId = self._enemyList[idx].id
    local win = self._enemyList[idx].win
    local num = self._enemyList[idx].num

    local icon = item:Find("Icon"):GetComponent("UISprite")
    UIHelper.SetCharacterIcon(self, icon, enemyId)

    local winRoot = item:Find("Win").gameObject
    local loseRoot = item:Find("Lose").gameObject

    winRoot:SetActive(win)
    loseRoot:SetActive(not win)

    if win then
        local numLabel = item:Find("Win/Num"):GetComponent("UILabel")
        numLabel.text = string.format("胜利%d次", num)
    else
        local numLabel = item:Find("Lose/Num"):GetComponent("UILabel")
        numLabel.text = string.format("失败%d次", num)
    end
end

function ExploreResultCtrl:ConstructPetItem(petItem, petId, data)
    local curNum = GameData.GetPetNum(petId)
    local catchNum = data.num
    local petNum = curNum + catchNum
    -- icon
    local icon = petItem:Find("Icon"):GetComponent("UISprite")
    UIHelper.SetCharacterIcon(self, icon, petId)
    -- level
    local levelLabel = petItem:Find("Level"):GetComponent("UILabel")
    local numLabel = petItem:Find("Num"):GetComponent("UILabel")
    local progressBar = petItem:Find("Bar"):GetComponent("UISprite")
    local catchNumLabel = petItem:Find("CatchNum"):GetComponent("UILabel")
    catchNumLabel.text = "x"..tostring(catchNum)

    local petLevel, petCurrentLevelNum, petTotalLevelNum = ConfigUtils.GetPetLevelByNum(petId, petNum)
    local petPercent = 1
    local petNumText = SAFE_LOC("loc_Max")
    if petCurrentLevelNum ~= nil then
        petNumText = tostring(petCurrentLevelNum).."/"..tostring(petTotalLevelNum)
        petPercent = petCurrentLevelNum / petTotalLevelNum
    end

    levelLabel.text = string.format(SAFE_LOC('loc_SimpleLevel'), petLevel)
    numLabel.text = petNumText
    progressBar.fillAmount = petPercent

    local catchItemList = {}
    -- success
    for k, v in pairs(data.success) do
        table.insert(catchItemList, {id = k, num = v, success = true})
    end
    -- fail
    for k, v in pairs(data.fail) do
        table.insert(catchItemList, {id = k, num = v, success = false})
    end

    local catchItemRoot = petItem:Find("CatchItems")
    for idx = 1, catchItemRoot.childCount do
        local hasCatchItem = (idx <= #catchItemList)
        local catchItem = catchItemRoot:GetChild(idx - 1)
        catchItem.gameObject:SetActive(hasCatchItem)
        if hasCatchItem then
            -- icon
            local catchItemIcon = catchItem:Find("Icon"):GetComponent("UISprite")
            UIHelper.SetItemIcon(self,catchItemIcon, catchItemList[idx].id)
            -- num
            local catchNumLabel = catchItem:Find("Num"):GetComponent("UILabel")
            catchNumLabel.text = "x"..tostring(catchItemList[idx].num)
            -- fail mark
            local catchFailMark = catchItem:Find("Fail").gameObject
            catchFailMark:SetActive(not catchItemList[idx].success)
        end
    end
end

-- handle the escapse button
function ExploreResultCtrl:HandleEscape()
    if self._currentState == ResultState.Event then
        self:OnClicked(self._ui.EventBlocker)
    elseif self._currentState == ResultState.Drop then
        self:OnClicked(self._ui.DropBlocker)
    elseif self._currentState == ResultState.Pet then
        if self._ui.NewPetPanel.gameObject.activeSelf then
            self:OnClicked(self._ui.NewPetBlocker)
        else
            self:OnClicked(self._ui.PetBlocker)
        end
    end
end

-- can do jump or not
function ExploreResultCtrl:CanJump()
    -- as we need to do goal settle, or goal data will miss
    return false
end

function ExploreResultCtrl:CheckShowReview()
    if Game.CanReview() and Helper.TableContains(self._eventList, ReviewEventId) then
        CtrlManager.OpenPanel(CtrlNames.ReviewConfirm)
    end
end

-- on clicked
function ExploreResultCtrl:OnClicked(go)
    if go == self._ui.EventBlocker then
        SoundSystem.PlayUIClickSound()
        self._eventIdx = self._eventIdx + 1
        if self._eventIdx > #self._eventList then
            self:CheckShowReview()
            self._currentState = ResultState.Drop
            self:OnCurrentStateChanged()
        else
            self:OnEventIndexChanged()
        end
	elseif go == self._ui.DropBlocker then
        SoundSystem.PlayUIClickSound()
        if #self._catchPetList > 0 then
            self._currentState = ResultState.Pet
            self:OnCurrentStateChanged()
        else
            self:SendSettle()
        end
    elseif go == self._ui.PetBlocker then
        SoundSystem.PlayUIClickSound()
        self:SendSettle()
    elseif go == self._ui.NewPetBlocker then
        SoundSystem.PlayUIClickSound()
        if #self._newPetList > 0 then
            self:ShowNewPet()
        else
            self._ui.NewPetPanel.gameObject:SetActive(false)
        end
	end

	return true
end

function ExploreResultCtrl:SendSettle()
    if self._planetAreaId ~= nil then
        NetManager.Send("ExploreSettle", {AreaId = self._planetAreaId}, ExploreResultCtrl.OnHandleProto, self)
    elseif self._activityThemeId ~= nil then
        local exploreId = ConfigUtils.GetActivityThemeExplore(self._activityThemeId)
        NetManager.Send("ActivityExploreSettle", {
            ActivityThemeId = self._activityThemeId,
            ActivityExploreId = exploreId,
        }, ExploreResultCtrl.OnHandleProto, self)
    end
end
--------------------------------------------------------

function ExploreResultCtrl:OnHandleProto(proto, data, requestData)
    if proto == "ExploreSettle" then
        local areaId = requestData.AreaId
        GameData.FinishExploreOfPlanetArea(areaId)
        GameData.IncExploreSettle()
        local goldNum = data.RemainGold
        local diamondNum = data.RemainDiamond
        GameData.SetMoney(ItemType.Gold, goldNum)
        GameData.SetMoney(ItemType.Diamond, diamondNum)
        GameData.SyncTutorialData()
        -- in the finish function has called: GameData.CheckAndHintGoalsOfCurrentCountType()
        CtrlManager.PopPanel()
    elseif proto == "ActivityExploreSettle" then
        local themeId = requestData.ActivityThemeId
        GameData.FinishExploreOfActivityExplore(themeId)
        local goldNum = data.RemainGold
        local diamondNum = data.RemainDiamond
        GameData.SetMoney(ItemType.Gold, goldNum)
        GameData.SetMoney(ItemType.Diamond, diamondNum)
        -- in the finish function has called: GameData.CheckAndHintGoalsOfCurrentCountType()
        CtrlManager.PopPanel()
	end
end

--------------------------------------------------------
-- tutorial
function ExploreResultCtrl:CheckTutorial()
	local tutorials = {}

    if GameData.IsTutorialNotFinished(Tutorials.Tutorial_1_12) then
        local position = self._ui.Camera:WorldToScreenPoint(self._ui.PositionMark.position)
        tutorials[1] = {event = Tutorials.Tutorial_1_12, position = position, sender = self}
    end

    if #tutorials > 0 then
        CtrlManager.ShowTutorials(tutorials)
    end

    return #tutorials > 0
end

function ExploreResultCtrl:OnTutorialClicked(tutorial)
    if tutorial == Tutorials.Tutorial_1_12 then
        self:OnClicked(self._ui.DropBlocker)
    end
end