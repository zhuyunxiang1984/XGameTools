require "FreakPlanet/View/AccountPasswordModifyPanel"

local class = require "FreakPlanet/Utils/middleclass"
AccountPasswordModifyCtrl  = class(CtrlNames.AccountPasswordModify, BaseCtrl)

-- load the ui prefab
function AccountPasswordModifyCtrl:LoadPanel()
	self:CreatePanel("AccountPasswordModify")
end

-- construct ui panel data
function AccountPasswordModifyCtrl:ConstructUI(obj)
	self._ui = AccountPasswordModifyPanel.Init(obj)
end

-- fill ui with the data
function AccountPasswordModifyCtrl:SetupUI()
	self._ui.ResultHint.text = ""

	CtrlManager.AddClick(self, self._ui.Blocker)
	CtrlManager.AddClick(self, self._ui.ButtonConfirm)
end

function AccountPasswordModifyCtrl:CheckInput()
	local account = self._ui.NickNameSafeInput:GetText()
	if Helper.IsEmptyOrNull(account) then
		SoundSystem.PlayWarningSound()
		CtrlManager.ShowMessageBox({message = SAFE_LOC("loc_global_id_empty"), single = true})
		return false
	end

	local password = self._ui.Password.value
	if Helper.IsEmptyOrNull(password) then
		SoundSystem.PlayWarningSound()
		CtrlManager.ShowMessageBox({message = SAFE_LOC("loc_global_initial_password_empty"), single = true})
		return false
	end

	local newPassword = self._ui.NewPassword.value
	if Helper.IsEmptyOrNull(newPassword) then
		SoundSystem.PlayWarningSound()
		CtrlManager.ShowMessageBox({message = SAFE_LOC("loc_global_new_password_empty"), single = true})
		return false
	end

	local passwordLen = Helper.LenOfUtf8(newPassword)
	if passwordLen < 6 or passwordLen > 18 then
		SoundSystem.PlayWarningSound()
		CtrlManager.ShowMessageBox({message = SAFE_LOC("loc_global_password_rule1"), single = true})
		return false
	end

	local passwordMatch = Helper.ContainsBothLetterAndNumber(newPassword)
	if not passwordMatch then
		SoundSystem.PlayWarningSound()
		CtrlManager.ShowMessageBox({message = SAFE_LOC("loc_global_password_rule2"), single = true})
		return false
	end

	local confirmPassword = self._ui.ConfirmPassword.value
	if newPassword ~= confirmPassword then
		SoundSystem.PlayWarningSound()
		CtrlManager.ShowMessageBox({message = SAFE_LOC("loc_global_password_no_match"), single = true})
		return false
	end

	return true
end

-- on clicked
function AccountPasswordModifyCtrl:OnClicked(go)
	if go == self._ui.Blocker then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
	elseif go == self._ui.ButtonConfirm then
		local valid = self:CheckInput()
		if not valid then
			return true
		end

		SoundSystem.PlayUIClickSound()
		NetManager.Send("AlterPassword", {
			Nickname = self._ui.NickNameSafeInput:GetText(),
			Password = Helper.CheckMd5(self._ui.Password.value),
			NewPassword = Helper.CheckMd5(self._ui.NewPassword.value)
		}, 
		AccountPasswordModifyCtrl.OnHandleProto, 
		self)
	end

	return true
end

function AccountPasswordModifyCtrl:OnHandleProto(proto, data, requestData)
	if proto == "AlterPassword" then
		local nickname = requestData.Nickname
		local password = requestData.NewPassword

		GameData.ModifyAccountPassword(nickname, password)
		GameData.Save()

		CtrlManager.PopPanel()
		CtrlManager.ShowMessageBox({message = SAFE_LOC("loc_global_password_change_succeed"), single = true})
	end
end
