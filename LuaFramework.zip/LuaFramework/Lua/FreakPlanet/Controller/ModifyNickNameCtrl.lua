require "FreakPlanet/View/ModifyNickNamePanel"

local class = require "FreakPlanet/Utils/middleclass"
ModifyNickNameCtrl = class(CtrlNames.ModifyNickName, BaseCtrl)

-- load the ui prefab
function ModifyNickNameCtrl:LoadPanel()
    self:CreatePanel("ModifyNickName")
end

-- construct ui panel data
function ModifyNickNameCtrl:ConstructUI(obj)
    self._ui = ModifyNickNamePanel.Init(obj)
end

-- fill ui with the data
function ModifyNickNameCtrl:SetupUI()
    self._ui.ConsumeLabel.text = tostring(ConfigUtils.GetModifyNickNameCost())
    local curDiamondNum = GameData.GetMoney(ItemType.Diamond)
    local consumeDiamondNum = ConfigUtils.GetModifyNickNameCost()
    if curDiamondNum < consumeDiamondNum then
        self._ui.ConsumeLabel.color = Color.red
    else
        self._ui.ConsumeLabel.color = Color.white
    end
    CtrlManager.AddClick(self, self._ui.Blocker)
    CtrlManager.AddClick(self, self._ui.ButtonConfirm)
    GameNotifier.AddListener(GameEvent.MoneyChanged, ModifyNickNameCtrl.OnMoneyChanged, self)

end

function ModifyNickNameCtrl:DestroyImpl()
    GameNotifier.RemoveListener(GameEvent.MoneyChanged, ModifyNickNameCtrl.OnMoneyChanged, self)
end
-- on clicked
function ModifyNickNameCtrl:OnClicked(go)
    if go == self._ui.Blocker then
        SoundSystem.PlayUICancelSound()
        CtrlManager.PopPanel()
    elseif go == self._ui.ButtonConfirm then
        local valid = self:CheckInput()
        if not valid then
            return true
        end
        local curDiamondNum = GameData.GetMoney(ItemType.Diamond)
        local consumeDiamondNum = ConfigUtils.GetModifyNickNameCost()--GetModifyNickNameCost
        --log("curDiamondNum:"..tostring(curDiamondNum).." consumeDiamondNum:"..tostring(consumeDiamondNum))
        if curDiamondNum < consumeDiamondNum then
            SoundSystem.PlayWarningSound()
            CtrlManager.ShowMessageBox({ message = SAFE_LOC("loc_DiamondNotEnough"), single = true })

            return true
        end

        SoundSystem.PlayUIClickSound()
        CtrlManager.ShowMessageBox({
            message = SAFE_LOC("确定支付100玉璧修改昵称？"),
            single = false,
            onConfirm = ModifyNickNameCtrl.OnModifyConfirm,
            receiver = self,
        })

    end

    return true
end

function ModifyNickNameCtrl:CheckInput()
    local account = self._ui.NickNameSafeInput:GetText()
    if Helper.IsEmptyOrNull(account) then
        SoundSystem.PlayWarningSound()
        CtrlManager.ShowMessageBox({ message = SAFE_LOC("loc_global_id_empty"), single = true })
        return false
    end

    local accountLen = Helper.LenOfUtf8(account)
    if accountLen < 1 or accountLen > 10 then
        SoundSystem.PlayWarningSound()
        CtrlManager.ShowMessageBox({message = SAFE_LOC("loc_global_nickname_modify1"), single = true})
        return false
    end

    local accountFiltered = Helper.FilterSpecialChars(account)
    if accountFiltered ~= account then
        SoundSystem.PlayWarningSound()
        CtrlManager.ShowMessageBox({ message = SAFE_LOC("loc_global_nickname_modify2"), single = true })
        return false
    end
    return true
end

function ModifyNickNameCtrl:OnHandleProto(proto, data, requestData)
    if proto == "ChangeNickname" then
        local nickname = requestData.Nickname
        GameData.ModifyNickName(nickname)

        local diamondNum = data.RemainDiamond
        GameData.SetMoney(ItemType.Diamond, diamondNum)
        GameData.Save()

        NavigationCtrl.RefreshAccountInfo()
        CtrlManager.PopPanel()
        CtrlManager.ShowMessageBox({ message = SAFE_LOC("loc_hint_account_rename_success"), single = true })
    end
end

function ModifyNickNameCtrl:OnMoneyChanged(itemType)
    --log("itemType:"..itemType)
    local curDiamondNum = GameData.GetMoney(ItemType.Diamond)
    local consumeDiamondNum = ConfigUtils.GetModifyNickNameCost()
    if curDiamondNum < consumeDiamondNum then
        self._ui.ConsumeLabel.color = Color.red
    else
        self._ui.ConsumeLabel.color = Color.white
    end
end

function ModifyNickNameCtrl:OnModifyConfirm()
    NetManager.Send("ChangeNickname", {
        Nickname = self._ui.NickNameSafeInput:GetText(),
    }, ModifyNickNameCtrl.OnHandleProto, self)
end
