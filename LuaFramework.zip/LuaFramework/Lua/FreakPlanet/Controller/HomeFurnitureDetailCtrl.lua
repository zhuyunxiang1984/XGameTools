require "FreakPlanet/View/HomeFurnitureDetailPanel"

local class = require "FreakPlanet/Utils/middleclass"
HomeFurnitureDetailCtrl  = class(CtrlNames.HomeFurnitureDetail, BaseCtrl)

-- load the ui prefab
function HomeFurnitureDetailCtrl:LoadPanel()
    self:CreatePanel("HomeFurnitureDetail")
end

-- construct ui panel data
function HomeFurnitureDetailCtrl:ConstructUI(obj)
	self._ui = HomeFurnitureDetailPanel.Init(obj)
end

-- fill ui with the data
function HomeFurnitureDetailCtrl:SetupUI()
	local ui = self._ui
    local iFurnitureId = self._parameter.furnitureId
    
    UIHelper.SetItemIcon(self, ui.sprItemIcon, iFurnitureId)

    local iCategory = ConfigUtils.GetHomeFurnitureCategory(iFurnitureId)
    local atlas, icon = ConfigUtils.GetHomeFurnitureCategoryIcon(iCategory)
    self:SetIconWithAtlas(ui.sprTypeIcon, icon, atlas)
    ui.txtNum.text = "∞";
    ui.txtName.text = ConfigUtils.GetHomeFurnitureName(iFurnitureId)
    --

    self:SetSourceLabel(1, "家具城")
    self:SetSourceLabel(2, "洗脚城")
    self:SetSourceLabel(3, "")
    self:SetSourceLabel(4, "")
    self:SetSourceLabel(5, "")
    self:SetSourceLabel(6, "")

    CtrlManager.AddClick(self, ui.Blocker)
end

-- on clicked
function HomeFurnitureDetailCtrl:OnClicked(go)
    local ui = self._ui
    if go == ui.Blocker then
        self:Close()
    end
	return true
end

function HomeFurnitureDetailCtrl:SetSourceLabel(index, text)
    local ui = self._ui
    local objLabel = ui["objSourceLabel" .. index]
    if not objLabel then
        return
    end
    if text and #text > 0 then
        objLabel:SetActive(true)
        objLabel.transform:Find("txtText"):GetComponent("UILabel").text = text
    else
        objLabel:SetActive(false)
    end
    
end 