require "FreakPlanet/View/SpaceTravelShipPanel"

local class = require "FreakPlanet/Utils/middleclass"
SpaceTravelShipCtrl  = class(CtrlNames.SpaceTravelShip, BaseCtrl)

local EXCHANGE_GOLD_COLOR = Color.New(248 / 255, 194 / 255, 110 / 255, 1)
local TOTAL_GOLD_COLOR = Color.New(147 / 255, 102 / 255, 102 / 255, 1) 

-- load the ui prefab
function SpaceTravelShipCtrl:LoadPanel()
	self:CreatePanel("SpaceTravelShip")
end

-- construct ui panel data
function SpaceTravelShipCtrl:ConstructUI(obj)
	self._ui = SpaceTravelShipPanel.Init(obj)
end

function SpaceTravelShipCtrl:DestroyImpl()
    GameNotifier.RemoveListener(GameEvent.MoneyChanged, SpaceTravelShipCtrl.OnMoneyChanged, self)
end

-- fill ui with the data
function SpaceTravelShipCtrl:SetupUI()
    self._seasonId = self._parameter.season
    self._scoreCapId = self._parameter.scoreCap
    self._needGold = ConfigUtils.GetScoreCapNeedGold(self._scoreCapId)
    self._seasonEndTime = GameData.GetSpaceTravelSeasonRegisterEndTime(self._seasonId)
    self._needRefreshTime = true

	self._shipList = ConfigUtils.GetSpaceTravelShipList()
    self:InitExchangeData()

    self._currentShipIdx = 1
    self:OnSelectedShipChanged()
    self:RefreshGoldCost()
    self:RefreshLeftTime()

    for k, v in pairs(self._ui.ExchangePackages) do
        CtrlManager.AddClick(self, v.item)
    end

    CtrlManager.AddClick(self, self._ui.Blocker)
    CtrlManager.AddClick(self, self._ui.ButtonNext)
    CtrlManager.AddClick(self, self._ui.ButtonPrev)
    CtrlManager.AddClick(self, self._ui.ButtonConfirm)
    CtrlManager.AddClick(self, self._ui.ShipLockCostRoot)

    GameNotifier.AddListener(GameEvent.MoneyChanged, SpaceTravelShipCtrl.OnMoneyChanged, self)
end

-- update implementation
function SpaceTravelShipCtrl:UpdateImpl(deltaTime)
    self:RefreshLeftTime()
end

function SpaceTravelShipCtrl:RefreshLeftTime()
    if not self._needRefreshTime then
        return
    end

    local curTime = GameData.GetServerTime()
    local leftTime = math.max(0, self._seasonEndTime - curTime)
    if leftTime > 0 then
        self._ui.SpaceTravelLeftTime.text = SAFE_LOC("报名剩余时间：")..Helper.GetLongTimeString(leftTime)
    else
        self._ui.SpaceTravelLeftTime.text = SAFE_LOC("报名已结束")
    end
    self._needRefreshTime = (leftTime > 0)
end

function SpaceTravelShipCtrl:InitExchangeData()
    self._exchangePackages = ConfigUtils.GetScoreCapExchangePackages(self._scoreCapId)
    self._exchangePackageFlags = {}
    for idx = 1, #self._ui.ExchangePackages do
        local hasPackage = (idx <= #self._exchangePackages)
        local packageItem = self._ui.ExchangePackages[idx].item
        packageItem:SetActive(hasPackage)
        if hasPackage then
            local exchangeItems = self._ui.ExchangePackages[idx].exchanges
            for m = 1, #exchangeItems do
                local hasItem = (m <= #self._exchangePackages[idx].ItemList)
                local exchangeItem = exchangeItems[m].item
                exchangeItem:SetActive(hasItem)
                if hasItem then
                    local e = self._exchangePackages[idx].ItemList[m]
                    local exchangeItemRoot = exchangeItems[m].root
                    UIHelper.ConstructItemIconAndNum(self, exchangeItemRoot, e.Value, e.Num)
                end
            end

            -- not selected
            self._exchangePackageFlags[idx] = false

            local exchangeCost = self._exchangePackages[idx].Cost
            self._ui.ExchangePackages[idx].cost.text = tostring(exchangeCost)
            -- hide as not selected
            self._ui.ExchangePackages[idx].mark:SetActive(false)
        end
    end
end

function SpaceTravelShipCtrl:OnSelectedShipChanged()
    self:RecycleShipAvatar()
    local shipId = self._shipList[self._currentShipIdx]
    local unlocked = GameData.IsSpaceTravelShipUnlocked(shipId)
    local prefabName, prefabBundle = ConfigUtils.GetSpaceShipPrefab(shipId)
    local shipItem = self._ui.ShipPool:Find(prefabName)
    if shipItem == nil then
        local shipPrefab = self:DynamicLoadAsset(prefabBundle, prefabName)
        local shipObj = Helper.NewObject(shipPrefab, self._ui.ShipAvatar, 80)
        shipObj.name = prefabName
        shipItem = shipObj.transform
    else
        shipItem.parent = self._ui.ShipAvatar
        shipItem.localPosition = Vector3.zero
    end

    shipItem.gameObject:SetActive(true)
    -- skill
    self._ui.SkillDesc.text = ConfigUtils.GetSpaceShipSkillDesc(shipId)
    -- attribute
    self:ConstructShipAttributes()

    self._ui.DisableMark:SetActive(not unlocked)
    self._ui.ButtonConfirm:SetActive(unlocked)
    self._ui.ExchangeRoot:SetActive(unlocked)
    self._ui.ShipLockRoot:SetActive(not unlocked)

    if not unlocked then
        self:ConstructLockShipInfo(shipId)
    end
end

function SpaceTravelShipCtrl:ConstructLockShipInfo(shipId)
    self._unlockCostEnough = true
    self._unlockConditionEnough = true

    local needScoreCap, needCareerData, needFriendliness, needCost = ConfigUtils.GetSpaceTravelShipUnlockCondition(shipId)
    local unlockDesc = ""

    if needScoreCap ~= nil then
        local text = SAFE_LOC(needScoreCap.Desc)
        local scoreCapNum = needScoreCap.Num
        local currentCapNum = GameData.GetSpaceTravelScoreCapRank()
        if currentCapNum >= scoreCapNum then
            unlockDesc = unlockDesc..string.format(text, currentCapNum).."\n"
        else
            unlockDesc = unlockDesc..string.format(text, currentCapNum).."\n"
            self._unlockConditionEnough = false
        end
    end

    needCareerData = needCareerData or {}
    for k, v in pairs(needCareerData) do
        local careerId = v.Value
        local careerNum = v.Num
        local text = SAFE_LOC(v.Desc)
        local curCareerNum = GameData.GetSpaceTravelCareerValue(careerId)
        if curCareerNum >= careerNum then
            unlockDesc = unlockDesc..string.format(text, curCareerNum).."\n"
        else
            unlockDesc = unlockDesc..string.format(text, curCareerNum).."\n"
            self._unlockConditionEnough = false
        end
    end

    needFriendliness = needFriendliness or {}
    for k, v in pairs(needFriendliness) do
        local friendlinessId = v.Value
        local friendlinessNum = v.Num
        local text = SAFE_LOC(v.Desc)
        local curFriendlinessNum = GameData.GetSpaceTravelFriendliness(friendlinessId)
        if curFriendlinessNum >= friendlinessNum then
            unlockDesc = unlockDesc..string.format(text, curFriendlinessNum).."\n"
        else
            unlockDesc = unlockDesc..string.format(text, curFriendlinessNum).."\n"
            self._unlockConditionEnough = false
        end
    end

    -- desc
    unlockDesc = string.gsub(unlockDesc, "[ \t\n\r]+$", "")
    self._ui.ShipLockDesc.text = unlockDesc

    needCost = needCost or {}
    self._ui.ShipLockCostRoot:SetActive(#needCost > 0)
    if #needCost > 0 then
        local costType = needCost[1].Value
        local costNum = needCost[1].Num
        local currentNum = GameData.GetMoney(costType)
        self._ui.ShipLockCostNum.text = tostring(costNum)
        if currentNum >= costNum then
            self._ui.ShipLockCostNum.color = Color.white
        else 
            self._ui.ShipLockCostNum.color = Color.red
            self._unlockCostEnough = false
        end
    end
end

function SpaceTravelShipCtrl:RefreshGoldCost()
    local ownGold = GameData.GetMoney(ItemType.Gold)
    self._ui.TotalGoldCost.text = "x"..tostring(self._needGold)
    if self._needGold > ownGold then
        self._ui.TotalGoldCost.color = Color.red
    else
        self._ui.TotalGoldCost.color = TOTAL_GOLD_COLOR
    end

    for idx = 1, #self._exchangePackages do
        local goldCost = self._exchangePackages[idx].Cost
        if goldCost > ownGold then
            self._ui.ExchangePackages[idx].cost.color = Color.red
        else
            self._ui.ExchangePackages[idx].cost.color = EXCHANGE_GOLD_COLOR
        end
    end
end

function SpaceTravelShipCtrl:ConstructShipAttributes()
    local shipId = self._shipList[self._currentShipIdx]
    local attributes = ConfigUtils.GetSpaceShipAttributes(shipId)

    for idx = 1, #self._ui.AttributeItems do
        local hasAttribute = (idx <= #attributes)
        self._ui.AttributeItems[idx].item:SetActive(hasAttribute)
        if hasAttribute then
            local descLabel = self._ui.AttributeItems[idx].label
            local initialNum = attributes[idx].initial
            local maxNum = attributes[idx].max
            descLabel.text = string.format("%d(上限%d)", initialNum, maxNum)
        end
    end
end

function SpaceTravelShipCtrl:RecycleShipAvatar()
    local num = self._ui.ShipAvatar.childCount
    for idx = num, 1, -1 do
        local item = self._ui.ShipAvatar:GetChild(idx - 1)
        item.parent = self._ui.ShipPool
    end
end

function SpaceTravelShipCtrl:ToggleExchangePackage(slot)
    local preSelected = self._exchangePackageFlags[slot]
    local selected = not preSelected
    self._exchangePackageFlags[slot] = selected
    self._ui.ExchangePackages[slot].mark:SetActive(selected)
    local goldCost = self._exchangePackages[slot].Cost

    if preSelected then
        self._needGold = self._needGold - goldCost
    else
        self._needGold = self._needGold + goldCost
    end

    self:RefreshGoldCost()
end

function SpaceTravelShipCtrl:GetExchangeList()
    local ret = {}

    for idx = 1, #self._exchangePackageFlags do
        if self._exchangePackageFlags[idx] then
            table.insert(ret, idx)
        end
    end

    if #ret > 0 then
        return ret
    end

    return nil
end

function SpaceTravelShipCtrl:OnMoneyChanged(itemType)
    if itemType == ItemType.Gold then
        self:RefreshGoldCost()
    end
end

function SpaceTravelShipCtrl:CloseToSpaceTravel(seasonId)
    CtrlManager.PopToPlanet()
    CtrlManager.OpenPanel(CtrlNames.SpaceTravel, {season = seasonId})
    CtrlManager.OpenPanel(CtrlNames.SpaceTravelMain, {season = seasonId})
end

function SpaceTravelShipCtrl:OnSpaceTravelOpen(params)
    local host = CtrlManager.GetCtrlByName(CtrlNames.SpaceTravel)
    local ctrl = CtrlManager.GetCtrlByName(CtrlNames.SpaceTravelMain)
    ctrl:StartCheck(host)
end

-- on clicked
function SpaceTravelShipCtrl:OnClicked(go)

    if go == self._ui.Blocker then
        SoundSystem.PlayUICancelSound()
        CtrlManager.PopPanel()
    elseif go == self._ui.ButtonNext then
        SoundSystem.PlayUIClickSound()
        self._currentShipIdx = self._currentShipIdx + 1
        if self._currentShipIdx > #self._shipList then
            self._currentShipIdx = 1
        end
        self:OnSelectedShipChanged()
    elseif go == self._ui.ButtonPrev then
        SoundSystem.PlayUIClickSound()
        self._currentShipIdx = self._currentShipIdx - 1
        if self._currentShipIdx < 1 then
            self._currentShipIdx = #self._shipList
        end
        self:OnSelectedShipChanged()
    elseif go == self._ui.ButtonConfirm then
        local curTime = GameData.GetServerTime()
        if curTime >= self._seasonEndTime then
            SoundSystem.PlayWarningSound()
            CtrlManager.ShowMessageBox({message = SAFE_LOC("星际航行报名已结束"), single = true})
            return true
        end

        local ownGold = GameData.GetMoney(ItemType.Gold)
        if self._needGold > ownGold then
            SoundSystem.PlayWarningSound()
            CtrlManager.ShowMessageBox({message = SAFE_LOC("loc_GoldNotEnough"), single = true})
        else
            SoundSystem.PlayUIClickSound()
            local shipId = self._shipList[self._currentShipIdx]
            local exchangeList = self:GetExchangeList()
            NetManager.Send("STSignup", {
                STSeasonID = self._seasonId, 
                STScoreCapID = self._scoreCapId,
                ExchangeList = exchangeList,
                Ship = shipId,
            }, SpaceTravelShipCtrl.OnHandleProto, self)
        end
    elseif go.transform.parent == self._ui.ExchangePackageRoot then
        local names = Helper.StringSplit(go.name)
        assert(#names == 2, "invalid exchange package item name: "..tostring(go.name))
        SoundSystem.PlayUIClickSound()
        local slot = tonumber(names[2])
        self:ToggleExchangePackage(slot)
    elseif go == self._ui.ShipLockCostRoot then
        if not self._unlockConditionEnough then
            SoundSystem.PlayWarningSound()
            CtrlManager.ShowMessageBox({message = SAFE_LOC("解锁条件不满足"), single = true})
            return true
        end

        if not self._unlockCostEnough then
            SoundSystem.PlayWarningSound()
            CtrlManager.ShowMessageBox({message = SAFE_LOC("解锁玉璧不足"), single = true})
            return true
        end

        SoundSystem.PlayUIClickSound()
        local shipId = self._shipList[self._currentShipIdx]
        NetManager.Send("STShipUnlock", {
            Ship = shipId,
        }, SpaceTravelShipCtrl.OnHandleProto, self)
    end

	return true
end

function SpaceTravelShipCtrl:OnHandleProto(proto, data, requestData)
    if proto == "STSignup" then
        -- new season data
        local seasonId = requestData.STSeasonID
        local firstTry = GameData.SetSpaceTravelSeasonData(seasonId, data.STSeasonData)
        if firstTry then
            -- season count
            GameData.ModifySpaceTravelCareerData(SpaceTravelCareerType.SeasonCount, 1)
        end
        -- gold num
        local goldNum = data.LeftGold
        GameData.SetMoney(ItemType.Gold, goldNum)
        -- enter
        CtrlManager.DoWaitTransition(CtrlNames.SpaceTravelMain, self, SpaceTravelShipCtrl.CloseToSpaceTravel, seasonId, SpaceTravelShipCtrl.OnSpaceTravelOpen)
    elseif proto == "STShipUnlock" then
        local shipId = requestData.Ship
        local goldNum = data.RemainGold
        local diamondNum = data.RemainDiamond
        GameData.SetMoney(ItemType.Gold, goldNum)
        GameData.SetMoney(ItemType.Diamond, diamondNum)
        GameData.UnlockSpaceTravelShip(shipId)
        self:OnSelectedShipChanged()
    end
end