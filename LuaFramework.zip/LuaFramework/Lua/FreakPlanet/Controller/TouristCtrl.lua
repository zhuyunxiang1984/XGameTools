require "FreakPlanet/View/TouristPanel"

local class = require "FreakPlanet/Utils/middleclass"
TouristCtrl  = class(CtrlNames.Tourist, BaseCtrl)
--------------------------------------------------------
local function PetSortFunc(idA, idB)
    if idA == nil or idB == nil then
        return false
    end

    local markedA = GameData.IsItemMarked(idA)
    local markedB = GameData.IsItemMarked(idB)
    if markedA ~= markedB then
        return markedA
    end

    local valueA = GameData.GetPetLevel(idA)
    local valueB = GameData.GetPetLevel(idB)

    if valueA == valueB then
        valueA = ConfigUtils.GetPetRarity(idA)
        valueB = ConfigUtils.GetPetRarity(idB)
    end

    if valueA == valueB then
        valueA = ConfigUtils.GetPetSortId(idA)
        valueB = ConfigUtils.GetPetSortId(idB)
    end

    return valueA > valueB
end
--------------------------------------------------------
-- load the ui prefab
function TouristCtrl:LoadPanel()
    -- bg references a sprite in the bundle, call it before load panel
    self:DynamicLoadBundle(Const.EventBGBundleName)

	self:CreatePanel("Tourist")
end

-- construct ui panel data
function TouristCtrl:ConstructUI(obj)
	self._ui = TouristPanel.Init(obj)
end

-- destroy implementation
function TouristCtrl:DestroyImpl()
    GameNotifier.RemoveListener(GameEvent.MarkStateChanged, TouristCtrl.OnMarkStateChanged, self)
end

-- fill ui with the data
function TouristCtrl:SetupUI()
    self._petItemPrefab = self:LoadAsset("PetItem")
    self._ui.PetItemGridWrap.OnItemUpdate = TouristCtrl.OnItemUpdateGlobal
    self._selectedPets = {}
    self._visitingState = nil
    self._requirementState = nil
    for idx = 1, #self._ui.PetAvatarItems do
        self._selectedPets[idx] = INVALID_ID
    end

    for idx = 1, #self._ui.PetAvatarItems do
        self:ConstructSelectedPet(idx)
    end

    self._touristId, self._touristEndTime = GameData.GetTouristId()
    self._ui.TouristRequirementAnimator.gameObject:SetActive(true)
    self._ui.TouristRequirementAnimator:Play("Idle", 0, 0)
    self._ui.TouristRequirement.text = ConfigUtils.GetTouristDesc(self._touristId)

    self:SetupPetGrid()
    self:RefreshLeftTime()
	
    CtrlManager.AddClick(self, self._ui.ButtonConfirm)
    CtrlManager.AddClick(self, self._ui.ButtonClose)
    CtrlManager.AddClick(self, self._ui.ButtonRank)
    GameNotifier.AddListener(GameEvent.MarkStateChanged, TouristCtrl.OnMarkStateChanged, self)

    for k, v in pairs(self._ui.PetAvatarItems) do
        CtrlManager.AddClick(self, v.item)
    end

    self:CheckTutorial()
end

function TouristCtrl:SetupPetGrid()
    self:RecycleGridItems()
    self._itemList = GameData.GetUnlockPetList()
    table.sort(self._itemList, PetSortFunc)

    local itemCount = self._ui.PetItemGridWrap.NeedCellCount
    itemCount = math.min(#self._itemList, itemCount)
    self._ui.PetItemGridWrap.MaxRow = math.ceil(#self._itemList / self._ui.PetItemGridWrap.ColumnLimit)
    self._ui.NoPetHint:SetActive(#self._itemList == 0)

    for idx = 1, itemCount do
        local itemId = self._itemList[idx]
        if self._ui.PetItemPool.childCount == 0 then
            local itemObj = Helper.NewObject(self._petItemPrefab, self._ui.PetItemGrid)
            CtrlManager.AddClick(self, itemObj)
            CtrlManager.AddPress(self, itemObj)
            item = itemObj.transform
        else
            item = self._ui.PetItemPool:GetChild(0)
            item.parent = self._ui.PetItemGrid
        end

        item.gameObject:SetActive(true)
        item.gameObject.name = tostring(itemId)

        -- construct item
        self:ConstructPetItem(item, itemId)
    end

    self._ui.PetItemGridWrap:SortBasedOnScrollMovement()
    self._ui.PetScrollView:ResetPosition()
    self._ui.PetScrollView.disableDragIfFits = (#self._itemList <= itemCount)
    self._ui.PetScrollView.restrictWithinPanel = true
end

-- update implementation
function TouristCtrl:UpdateImpl(deltaTime)
    if self._visitingState ~= nil then
        local finished = self._visitingState:Tick(deltaTime)
        if finished then
            self._visitingState = nil
        end
    end

    if self._requirementState ~= nil then
        local finished = self._requirementState:Tick(deltaTime)
        if finished then
            self._ui.TouristRequirementAnimator.gameObject:SetActive(false)
            self._requirementState = nil
        end
    end

    self:RefreshLeftTime()
end

function TouristCtrl:RefreshLeftTime()
    local curTime = GameData.GetServerTime()
    local leftTime = math.max(0, self._touristEndTime - curTime)
    if leftTime == 0 then
        self._ui.TouristLeftTime.text = SAFE_LOC("观光团已结束")
    else
        self._ui.TouristLeftTime.text = Helper.GetLongTimeString(leftTime)
    end
end

function TouristCtrl:RecycleGridItems()
    local num = self._ui.PetItemGrid.childCount
    for idx = num, 1, -1 do
        local item = self._ui.PetItemGrid:GetChild(idx - 1)
        item.parent = self._ui.PetItemPool
    end
end

function TouristCtrl:ConstructPetItem(item, petId)
    UIHelper.ConstructPetItem(self, item, petId)
    -- level
    local levelLabel = item:Find("Level"):GetComponent("UILabel")
    local petLevel = GameData.GetPetLevel(petId)
    levelLabel.text = string.format(SAFE_LOC("loc_SimpleLevel"), petLevel)
    -- selected
    self:RefreshGridItemSelectedState(item, petId)
    -- marked
    local marked = GameData.IsItemMarked(petId)
    local markedMark = item:Find("Mark/Marked").gameObject
    markedMark:SetActive(marked)
end

function TouristCtrl:RefreshGridItemSelectedState(item, petId)
    if item == nil then
        item = self._ui.PetItemGrid:Find(petId)
    end

    if item ~= nil then
        local selected = self:IsPetSelected(petId)
        local selectedMark = item:Find("Mark/Select").gameObject
        selectedMark:SetActive(selected)
    end
end

function TouristCtrl:ConstructSelectedPet(idx)
    local petId = self._selectedPets[idx]
    -- empty mark
    self._ui.PetAvatarItems[idx].empty:SetActive(petId == INVALID_ID)

    -- recycle avatar
    local avatarRoot = self._ui.PetAvatarItems[idx].root
    if avatarRoot.childCount > 0 then
        local avatar = avatarRoot:GetChild(0)
        avatar.parent = self._ui.PetAvatarPool
    end

    if petId ~= INVALID_ID then
        -- avatar
        local prefabName, prefabBundle = ConfigUtils.GetPetPrefab(petId)
        local prefab = self:DynamicLoadAsset(prefabBundle, prefabName)
        local itemObj = Helper.NewObject(prefab, avatarRoot, 30)
        itemObj.name = tostring(petId)
        -- animation
        local skeletonAnimation = itemObj:GetComponent("SkeletonAnimation")
        Helper.PlayAnimation(skeletonAnimation, CharacterAnimations.Idle, true)
        -- renderer
        local renderer = itemObj:GetComponent('MeshRenderer')
        renderer.sortingOrder = 1
    end
end

function TouristCtrl.OnItemUpdateGlobal(itemObj, itemIndex, itemRealIndex)
    local ctrl = CtrlManager.GetCtrlByName(CtrlNames.Tourist)
    if ctrl ~= nil then
        ctrl:OnItemUpdate(itemObj, itemIndex, itemRealIndex)
    end
end

function TouristCtrl:OnItemUpdate(itemObj, itemIndex, itemRealIndex)
    itemRealIndex = itemRealIndex + 1
    if itemRealIndex <= 0 or itemRealIndex > #self._itemList then
        itemObj:SetActive(false)
    else
        itemObj:SetActive(true)
        local itemId = self._itemList[itemRealIndex]
        itemObj.name = itemId
        local item = itemObj.transform
        -- construct item
        self:ConstructPetItem(item, itemId)
    end
end

function TouristCtrl:OnMarkStateChanged(itemId)
    local itemType = ConfigUtils.GetItemTypeFromId(itemId)
    if itemType == ItemType.Pet then
        self:SetupPetGrid()
    end
end

function TouristCtrl:GetIndexOfSelectedPet(petId)
    for idx = 1, #self._selectedPets do
        if self._selectedPets[idx] == petId then
            return idx
        end
    end

    return nil
end

function TouristCtrl:IsPetSelected(petId)
    return self:GetIndexOfSelectedPet(petId) ~= nil
end

function TouristCtrl:GetFirstAvailableIndex()
    for idx = 1, #self._selectedPets do
        if self._selectedPets[idx] == INVALID_ID then
            return idx
        end
    end

    return nil
end

function TouristCtrl:SetSelectedPet(index, petId)
    local prePetId = self._selectedPets[index]    
    self._selectedPets[index] = petId
    self:ConstructSelectedPet(index)

    if prePetId ~= INVALID_ID then
        self:RefreshGridItemSelectedState(nil, prePetId)
    end

    if petId ~= INVALID_ID then
        self:RefreshGridItemSelectedState(nil, petId)
    end
end

function TouristCtrl:GetSelectedPets()
    local ret = {}

    for idx = 1, #self._selectedPets do
        if self._selectedPets[idx] ~= INVALID_ID then
            table.insert(ret, self._selectedPets[idx])
        end
    end

    return ret
end

function TouristCtrl:SyncProto(data)
    NetManager.Send("ZooOpen", data, TouristCtrl.OnHandleProto, self)
end

-- handle the escapse button
function TouristCtrl:HandleEscape()
    self:OnClicked(self._ui.ButtonClose)
end

-- can do jump or not
function TouristCtrl:CanJump()
    return self._visitingState == nil and self._requirementState == nil
end

-- on pressed
function TouristCtrl:OnPressed(go, pressed, isLong)
    if pressed and isLong then
        if go.transform.parent == self._ui.PetItemGrid then
            SoundSystem.PlayUIClickSound()
            local petId = tonumber(go.name)
            CtrlManager.ShowItemDetail({itemId = petId})
        end
    end
end

-- on clicked
function TouristCtrl:OnClicked(go)
    if self._visitingState ~= nil or self._requirementState ~= nil then
        return true
    end

    if go == self._ui.ButtonClose then
        SoundSystem.PlayUICancelSound()
        CtrlManager.PopPanel()
    elseif go == self._ui.ButtonConfirm then
        local pets = self:GetSelectedPets()
        if #pets == 0 then
            SoundSystem.PlayWarningSound()
            CtrlManager.ShowMessageBox({message = SAFE_LOC("请选择宠物小分队"), single = true})
            return true
        end

        local curTouristId = GameData.GetTouristId()
        local curTime = GameData.GetServerTime()
        if curTouristId ~= self._touristId or curTime >= self._touristEndTime then
            SoundSystem.PlayWarningSound()
            CtrlManager.ShowMessageBox({message = SAFE_LOC("观光团已结束"), single = true})
            return true
        end

        SoundSystem.PlaySoundOfName(SoundNames.TouristStart)
        self._visitingState = AnimatorState:new(self._ui.GuestAnimator, "Guest", nil, self._ui.GuestAnimator.gameObject)
        local data = {TouristID = self._touristId, PetList = pets}
        self._visitingState:ActionOnExit(TouristCtrl.SyncProto, self, data)
        self._requirementState = AnimatorState:new(self._ui.TouristRequirementAnimator, "Disappear")
    elseif go.transform.parent == self._ui.PetItemGrid then
        SoundSystem.PlayUIClickSound()
        local petId = tonumber(go.name)
        local index = self:GetIndexOfSelectedPet(petId)
        if index == nil then
            local availableIndex = self:GetFirstAvailableIndex()
            if availableIndex ~= nil then
                self:SetSelectedPet(availableIndex, petId)
            end
        else
            self:SetSelectedPet(index, INVALID_ID)
        end
    elseif go.transform.parent == self._ui.PetAvatarRoot then
        SoundSystem.PlayUIClickSound()
        local names = Helper.StringSplit(go.name)
        assert(#names == 2, "invalid pet avatar item name: "..tostring(go.name))
        local index = tonumber(names[2])
        local petId = self._selectedPets[index]
        if petId ~= INVALID_ID then
            self:SetSelectedPet(index, INVALID_ID)
        end
    elseif go == self._ui.ButtonRank then
        SoundSystem.PlayUIClickSound()
        CtrlManager.OpenPanel(CtrlNames.TouristRankList, {touristId = self._touristId})
    end

	return true
end

function TouristCtrl:OnHandleProto(proto, data, requestData)
    if proto == "ZooOpen" then
        CtrlManager.OpenPanel(CtrlNames.TouristResult, {touristId = requestData.TouristID, result = data})
    end
end

-------------------------------------------------------------------------------------
function TouristCtrl:CheckTutorial()
    local tutorials = {}

    if GameData.IsItemNew(ModuleNames.Tourist) then
        GameData.CheckItem(ModuleNames.Tourist)
        local position = self._ui.Camera:WorldToScreenPoint(self._ui.TouristTutorialMark.position)
        tutorials[1] = {event = Tutorials.Tutorial_Tourist_2, position = position, sender = self}
        position = self._ui.Camera:WorldToScreenPoint(self._ui.TouristBorderBG.position)
        tutorials[2] = {event = Tutorials.Tutorial_Tourist_3, position = position, sender = self}
        position = self._ui.Camera:WorldToScreenPoint(self._ui.TouristLeftTime.transform.position)
        tutorials[3] = {event = Tutorials.Tutorial_Tourist_4, position = position, sender = self}
        position = self._ui.Camera:WorldToScreenPoint(self._ui.ButtonRank.transform.position)
        tutorials[4] = {event = Tutorials.Tutorial_Tourist_5, position = position, sender = self}
    end

    if #tutorials > 0 then
        CtrlManager.ShowTutorials(tutorials)
    end

    return #tutorials > 0
end

function TouristCtrl:OnTutorialClicked(tutorial)
    SoundSystem.PlayUIClickSound()
    GameData.SyncTutorialData()
end