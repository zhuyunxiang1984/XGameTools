require "FreakPlanet/View/AccountLoginPanel"

local class = require "FreakPlanet/Utils/middleclass"
AccountLoginCtrl  = class(CtrlNames.AccountLogin, BaseCtrl)

-- load the ui prefab
function AccountLoginCtrl:LoadPanel()
	self:CreatePanel("AccountLogin")
end

-- construct ui panel data
function AccountLoginCtrl:ConstructUI(obj)
	self._ui = AccountLoginPanel.Init(obj)
end

-- fill ui with the data
function AccountLoginCtrl:SetupUI()

	CtrlManager.AddClick(self, self._ui.Blocker)
	CtrlManager.AddClick(self, self._ui.ButtonConfirm)
	CtrlManager.AddClick(self, self._ui.ButtonService)
	CtrlManager.AddClick(self, self._ui.ButtonModifyPassword)
	CtrlManager.AddClick(self, self._ui.ButtonResetPassword)
	-- 有的渠道不允许出现客服按钮
	self._ui.ButtonService:SetActive(Game.ShowService())
	self._ui.Table:Reposition()
end

-- on clicked
function AccountLoginCtrl:OnClicked(go)
	if go == self._ui.Blocker then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
	elseif go == self._ui.ButtonConfirm then
		--mark for ggyy
		--local newAccount = self._ui.NickName.value
		local newAccount = self._ui.NickNameSafeInput:GetText()
		if Helper.IsEmptyOrNull(newAccount) then
			SoundSystem.PlayWarningSound()
			CtrlManager.ShowMessageBox({message = SAFE_LOC("loc_global_id_empty"), single = true})
			return true
		end

		local password = self._ui.Password.value
		if Helper.IsEmptyOrNull(password) then
			SoundSystem.PlayWarningSound()
			CtrlManager.ShowMessageBox({message = SAFE_LOC("loc_global_password_empty"), single = true})
			return true
		end

		SoundSystem.PlayUIClickSound()
		CtrlManager.PopPanel() -- close self
		if self._parameter.loginCallback ~= nil then
			if self._parameter.receiver ~= nil then
				self._parameter.loginCallback(self._parameter.receiver, newAccount, password)
			else
				self._parameter.loginCallback(newAccount, password)
			end
		end
	elseif go == self._ui.ButtonService then
		SoundSystem.PlayUIClickSound()
		Game.OpenService()
	elseif go == self._ui.ButtonModifyPassword then
		SoundSystem.PlayUIClickSound()
		CtrlManager.OpenPanel(CtrlNames.AccountPasswordModify)
	elseif go == self._ui.ButtonResetPassword then
		SoundSystem.PlayUIClickSound()
		CtrlManager.OpenPanel(CtrlNames.AccountPasswordReset)
	end

	return true
end
