require "FreakPlanet/View/CharacterQuickDetailPanel"

local class = require "FreakPlanet/Utils/middleclass"
CharacterQuickDetailCtrl  = class(CtrlNames.CharacterQuickDetail, BaseCtrl)

-- load the ui prefab
function CharacterQuickDetailCtrl:LoadPanel()
	self:CreatePanel("CharacterQuickDetail")
end

local MAXSHOWCOUNT = 3
-- construct ui panel data
function CharacterQuickDetailCtrl:ConstructUI(obj)
	self._ui = CharacterQuickDetailPanel.Init(obj)
end

-- notity it has been focused
function CharacterQuickDetailCtrl:NotifyFocus()
    if self._dirty then
        self:ConstructCharacterLevel()
        self:ConstructSkills()
        self:ConstructEquipments()
        self._dirty = false
    end
end

-- destructor
function CharacterQuickDetailCtrl:DestroyImpl()
	GameNotifier.RemoveListener(GameEvent.CharacterSkinChanged, CharacterQuickDetailCtrl.OnCharacterSkinChanged, self)
    GameNotifier.RemoveListener(GameEvent.CharacterStageChanged, CharacterQuickDetailCtrl.OnCharacterStageChanged, self)
    GameNotifier.RemoveListener(GameEvent.CharacterLevelChanged, CharacterQuickDetailCtrl.OnCharacterLevelChanged, self)
    GameNotifier.RemoveListener(GameEvent.CharacterEquipmentUpgraded, CharacterQuickDetailCtrl.OnCharacterEquipmentUpgraded, self)
end

-- fill ui with the data
function CharacterQuickDetailCtrl:SetupUI()
	self._characterId = self._parameter.characterId
	self._dirty = false
	self._SkinItemPool = {}

	self:ConstructBaseInfo()
	self:ConstructCharacterAvatar()
	self:ConstructCharacterLevel()
	self:ConstructSkills()
	self:ConstructEquipments()
	self:ConstructSkinsUI()

	-- hide default
	self._ui.CharacterAbilityHintRoot:SetActive(false)
	
	CtrlManager.AddClick(self, self._ui.Blocker)
	CtrlManager.AddClick(self, self._ui.ButtonUpgrade)
	CtrlManager.AddClick(self, self._ui.CharacterMark.gameObject)

	GameNotifier.AddListener(GameEvent.CharacterSkinChanged, CharacterQuickDetailCtrl.OnCharacterSkinChanged, self)
	GameNotifier.AddListener(GameEvent.CharacterStageChanged, CharacterQuickDetailCtrl.OnCharacterStageChanged, self)
    GameNotifier.AddListener(GameEvent.CharacterLevelChanged, CharacterQuickDetailCtrl.OnCharacterLevelChanged, self)
    GameNotifier.AddListener(GameEvent.CharacterEquipmentUpgraded, CharacterQuickDetailCtrl.OnCharacterEquipmentUpgraded, self)

	-- ability
	for k, v in pairs(self._ui.CharacterAbilites) do
		CtrlManager.AddPress(self, v.item)
	end
	-- equipment
	for k, v in pairs(self._ui.CharacterEquipments) do
		CtrlManager.AddClick(self, v.item)
	end

end

function CharacterQuickDetailCtrl:ConstructBaseInfo()
	local characterId = self._characterId
	-- name
	self._ui.CharacterName.text = ConfigUtils.GetCharacterName(characterId)
	-- element
	local elementId = ConfigUtils.GetCharacterElement(characterId)
	local style = ConfigUtils.GetCharacterStyle(characterId)
	self._ui.CharacterElement.spriteName = ConfigUtils.GetElementIconWithStyle(elementId)
	self._ui.CharacterStyle.spriteName = ConfigUtils.GetStyleIcon(style)
	self._ui.CharacterStyle.color = ConfigUtils.GetStyleIconColor(elementId)
	-- marked
	local marked = GameData.IsItemMarked(characterId)
	self:RefreshMarkState(self._ui.CharacterMark, marked)
    -- border
    self._ui.CharacterBorder.spriteName = UIHelper.GetItemDetailBorder(characterId)
end

function CharacterQuickDetailCtrl:ConstructCharacterAvatar()
	-- remove previous avatar
	for idx = self._ui.CharacterAvatar.childCount, 1, -1 do
		local obj = self._ui.CharacterAvatar:GetChild(idx - 1).gameObject
		destroy(obj)
	end

	local characterId = self._characterId
	-- avatar
	local prefabName, prefabBundle = ConfigUtils.GetCharacterPrefab(characterId)
	local prefab = self:DynamicLoadAsset(prefabBundle, prefabName)
	local itemObj = Helper.NewObject(prefab, self._ui.CharacterAvatar, 80)
	itemObj.name = tostring(characterId)
	-- skin
	local usedSkinId = GameData.GetCharacterSkin(characterId)
	local skeletonAnimation = itemObj:GetComponent("SkeletonAnimation")
	Helper.PlayAnimation(skeletonAnimation, CharacterAnimations.Idle, true)
	UIHelper.SetCharacterSkinWithSkin(skeletonAnimation, usedSkinId)
end

function CharacterQuickDetailCtrl:ConstructCharacterLevel()
	local characterId = self._characterId
	local curStage = GameData.GetCharacterCurrentStage(characterId)
	local curLevel = GameData.GetCharacterLevel(characterId)
	local maxStage = ConfigUtils.GetCharacterStageLimit(characterId)
	local maxLevel = ConfigUtils.GetCharacterMaxLevel(characterId)
	-- level
	self._ui.CharacterLevel.text = string.format(SAFE_LOC('loc_SimpleLevel'), curLevel)
	self._ui.CharacterFullLevelMark:SetActive(curLevel >= maxLevel)
	self._ui.ButtonUpgrade:SetActive(curLevel < maxLevel)
	-- stage
	for idx = 1, #self._ui.CharacterStages do
		local hasStage = (idx <= maxStage)
		self._ui.CharacterStages[idx].item:SetActive(hasStage)
		if hasStage then
			if curStage < idx then
				self._ui.CharacterStages[idx].icon.color = Color.black
			else
				self._ui.CharacterStages[idx].icon.color = Color.white
			end
		end
	end
	-- ability
	self._abilityList = GameData.GetCharacterAbilityList(characterId)
	for idx = 1, #self._ui.CharacterAbilites do
		local valueLabel = self._ui.CharacterAbilites[idx].value
		local icon = self._ui.CharacterAbilites[idx].icon

		local abilityId = self._abilityList[idx].id
		local abilityValue = self._abilityList[idx].value

		valueLabel.text = tostring(abilityValue)
		icon.spriteName = ConfigUtils.GetAbilityIcon(abilityId)
	end
end

function CharacterQuickDetailCtrl:ConstructSkills()
    local characterId = self._characterId
    local hasSkill = ConfigUtils.IsCharacterHasSkill(characterId)
    self._ui.CharacterSkillRoot:SetActive(hasSkill)

    if hasSkill then
    	local curStage = GameData.GetCharacterCurrentStage(characterId)
    	local stageLimit = ConfigUtils.GetCharacterStageLimit(characterId)
        local activatedSkillDesc = ConfigUtils.GetCharacterSkillDescAt(characterId, curStage)
        local skillActivated = (activatedSkillDesc ~= nil)

        if skillActivated then
            local skillText = "[A796FFFF]"..activatedSkillDesc.."[-] [48FF00FF]"..SAFE_LOC("loc_Activated").."[-]"
            self._ui.CharacterSkillDesc.text = skillText
            if curStage < stageLimit then
            	self._ui.CharacterSkillTips.text = SAFE_LOC("loc_CharacterStageUp_2")
            else
            	self._ui.CharacterSkillTips.text = SAFE_LOC("loc_CharacterStageUp_3")
            end
        else
            local nextActivatedSkillDesc = ConfigUtils.GetCharacterNextSkillDescAt(characterId, curStage)
            local skillText = "[7E65A1FF]"..nextActivatedSkillDesc.."[-] [FF0000FF]"..SAFE_LOC("loc_NotActivated").."[-]"
            self._ui.CharacterSkillDesc.text = skillText
            self._ui.CharacterSkillTips.text = SAFE_LOC("loc_CharacterStageUp_1")
        end
    end
end

function CharacterQuickDetailCtrl:ConstructEquipments()
	local characterId = self._characterId
	local equipmentList = ConfigUtils.GetCharacterEquipmentList(characterId)
    for idx = 1, #self._ui.CharacterEquipments do
        local hasEquipment = (idx <= #equipmentList)
        self._ui.CharacterEquipments[idx].item:SetActive(hasEquipment)

        if hasEquipment then
            local equipmentId = equipmentList[idx]
            local unlockChallenge = ConfigUtils.GetEquipmentUnlockChallenge(equipmentId)
            local equipmentUnlocked = unlockChallenge == nil or GameData.IsChallengeCompleted(unlockChallenge)
            local equipmentLevel = GameData.GetCharacterEquipmentLevel(characterId, idx)
            -- icon
            UIHelper.SetEquipmentIcon(self, self._ui.CharacterEquipments[idx].icon, equipmentId, equipmentLevel)
            -- level and color
            if equipmentUnlocked then
            	self._ui.CharacterEquipments[idx].icon.color = Color.white
            	self._ui.CharacterEquipments[idx].level.text = string.format(SAFE_LOC('loc_SimpleLevel'), equipmentLevel)
            else
            	self._ui.CharacterEquipments[idx].icon.color = LOCK_ICON_COLOR
            	self._ui.CharacterEquipments[idx].level.text = ""
            end
        end
    end
end

function CharacterQuickDetailCtrl:RefreshMarkState(sprite, marked)
	if marked then
		sprite.spriteName = "HintIcon"
	else
		sprite.spriteName = "HintIcon2"
	end
end

function CharacterQuickDetailCtrl:OnCharacterStageChanged(characterId)
    if characterId == self._characterId then
        self._dirty = true
    end
end

function CharacterQuickDetailCtrl:OnCharacterLevelChanged(characterId)
    if characterId == self._characterId then
        self._dirty = true
    end
end

function CharacterQuickDetailCtrl:OnCharacterEquipmentUpgraded(characterId)
    if characterId == self._characterId then
        self._dirty = true
    end
end

function CharacterQuickDetailCtrl:OnCharacterSkinChanged(characterId)
	if characterId == self._characterId then
        self:ConstructCharacterAvatar()
        self:ConstructSkinsUI()
        self:ConstructCharacterLevel()
    end
end

-- on pressed
function CharacterQuickDetailCtrl:OnPressed(go, pressed, isLong)
	if go.transform.parent == self._ui.CharacterAbilityRoot then
		if pressed then
			local names = Helper.StringSplit(go.name)
			assert(#names == 2, "invalid ability item name: "..tostring(go.name))
			local idx = tonumber(names[2])
			local abilityId = self._abilityList[idx].id
			self._ui.CharacterAbilityHintLabel.text = ConfigUtils.GetAbilityDesc(abilityId)
			local pos = self._ui.CharacterAbilityHintRoot.transform.parent:InverseTransformPoint(go.transform.position)
			self._ui.CharacterAbilityHintRoot.transform.localPosition = pos
			self._ui.CharacterAbilityHintRoot:SetActive(true)
		elseif not pressed then
			self._ui.CharacterAbilityHintRoot:SetActive(false)
		end
	end
end

-- on clicked
function CharacterQuickDetailCtrl:OnClicked(go)
	if go == self._ui.Blocker then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
	elseif go == self._ui.ButtonUpgrade then
		SoundSystem.PlayUIClickSound()
 		CtrlManager.OpenPanel(CtrlNames.CharacterUpgrade, {characterId = self._characterId})
 	elseif go == self._ui.CharacterMark.gameObject then
 		SoundSystem.PlayUIClickSound()
 		local marked = GameData.ToggleItemMark(self._characterId)
		self:RefreshMarkState(self._ui.CharacterMark, marked)
	elseif go.transform.parent == self._ui.CharacterEquipmentRoot then
		SoundSystem.PlayUIClickSound()
		local names = Helper.StringSplit(go.name)
		assert(#names == 2, "invalid ability item name: "..tostring(go.name))
		local idx = tonumber(names[2])
		CtrlManager.OpenPanel(CtrlNames.CharacterEquipment, {characterId = self._characterId, slot = idx, enableChallenge = false})
	elseif go.transform.parent == self._ui.SkinGrid.transform then
		local skinId = tonumber(go.name)
		CtrlManager.OpenPanel(CtrlNames.CharacterSkin, {characterId = self._characterId, skinId = skinId, enableChallenge = false})
	end

	return true
end

function CharacterQuickDetailCtrl:GetOrCreatSkinItem()
	local obj = nil
	if #self._SkinItemPool >0 then
		obj = self._SkinItemPool[#self._SkinItemPool]
		table.remove(self._SkinItemPool, #self._SkinItemPool)
	else
		obj = Helper.NewObject(self._ui.SkinItemTemplate, self._ui.SkinItemPool)
		CtrlManager.AddClick(self, obj)
	end
	return obj
end

function CharacterQuickDetailCtrl:RecycleSkinItem()
	for idx = self._ui.SkinGrid.transform.childCount, 1, -1 do
		local item = self._ui.SkinGrid.transform:GetChild(idx - 1)
		item.gameObject:SetActive(false)
		item:SetParent(self._ui.SkinPool)
		table.insert(self._SkinItemPool, item.gameObject)
	end
end

function CharacterQuickDetailCtrl:ConstructSkinsUI()
	self._skinList = ConfigUtils.GetCharacterSkinList(self._characterId)
	local usedSkinId = GameData.GetCharacterSkin(self._characterId)
	self:RecycleSkinItem()
	for idx = 1, #self._skinList do
		local skinItem = self:GetOrCreatSkinItem()
		local skinId = self._skinList[idx]
		skinItem.transform:SetParent(self._ui.SkinGrid.transform)
		skinItem:SetActive(true)

		skinItem.transform.localScale = Vector3.New(1, 1, 1)
		skinItem.name = tostring(skinId)

		local icon = skinItem.transform:Find("Icon"):GetComponent("UISprite")
		local lock = skinItem.transform:Find("Lock").gameObject
		local used = skinItem.transform:Find("Used").gameObject
		local use = skinItem.transform:Find("Use").gameObject

		local skinUnlocked = GameData.IsSkinUnlocked(skinId)

		UIHelper.SetCharacterIconWithSkin(self, icon, skinId)
		lock:SetActive(not skinUnlocked)
		used:SetActive(skinUnlocked and skinId == usedSkinId)
		use:SetActive(skinUnlocked and skinId ~= usedSkinId)

		if not skinUnlocked then
			icon.color = LOCK_ICON_COLOR
		else
			icon.color = Color.white
		end
	end
	self._ui.SkinGrid:Reposition()
	self._ui.SkinScrollView:ResetPosition()

	local slot = Helper.IndexOfArray(self._skinList, usedSkinId)
	if slot then
		self:MoveSkinScrollView(slot)
	end

end

function CharacterQuickDetailCtrl:MoveSkinScrollView(itemIndex)
	if itemIndex <= 4 then
		return
	end

	itemIndex = math.Clamp(itemIndex, 5, #self._skinList - MAXSHOWCOUNT)
	local scrollView = self._ui.SkinScrollView
	local corners = scrollView.panel.worldCorners
	local panelTop = (corners[0] + corners[1]) / 2
	local item = self._ui.SkinGrid.transform:GetChild(itemIndex - 1)

	local scrollViewPanelTrans = scrollView.panel.transform
	local selectPos = scrollViewPanelTrans:InverseTransformPoint(item.position)
	selectPos = Vector3.New(selectPos.x - 45, selectPos.y, selectPos.z)
	local panelTopPosition = scrollViewPanelTrans:InverseTransformPoint(panelTop)

	local localOffset = panelTopPosition - selectPos
	if not scrollView.canMoveHorizontally then
		localOffset.x = 0
	end
	if not scrollView.canMoveVertically then
		localOffset.y = 0
	end
	localOffset.z = 0
	scrollView:DisableSpring()
	scrollView:MoveRelative(Vector3.New(localOffset.x, -localOffset.y, localOffset.z))
end

