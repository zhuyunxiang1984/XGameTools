require "FreakPlanet/View/SummonExchangePanel"

local class = require "FreakPlanet/Utils/middleclass"
SummonExchangeCtrl  = class(CtrlNames.SummonExchange, BaseCtrl)

-- load the ui prefab
function SummonExchangeCtrl:LoadPanel()
	self:CreatePanel("SummonExchange")
end

-- construct ui panel data
function SummonExchangeCtrl:ConstructUI(obj)
	self._ui = SummonExchangePanel.Init(obj)
end

-- fill ui with the data
function SummonExchangeCtrl:SetupUI()
	local characterId = self._parameter.characterId
	local exchangeCost = ConfigUtils.GetCharacterExchangeCost(characterId)
	local exchangeItemId = exchangeCost.Value
    local exchangeItemNum = exchangeCost.Num
    local ownNum = GameData.GetItemNum(exchangeItemId)

    self._ui.CostNum.text = tostring(exchangeItemNum)
    self._ui.OwnNum.text = tostring(ownNum)

    self._ui.ButtonConfirm:SetActive(ownNum >= exchangeItemNum)
    self._ui.Hint:SetActive(ownNum < exchangeItemNum)

    if ownNum < exchangeItemNum then
    	self._ui.OwnNum.color = Color.red
    else
    	self._ui.OwnNum.color = self._ui.OwnNormalColor
    end

	self._ui.CostLabel.text = string.format(LANGUAGE("summon_exchange_text1"), ConfigUtils.GetItemName(characterId))

	CtrlManager.AddClick(self, self._ui.Blocker)
	CtrlManager.AddClick(self, self._ui.ButtonConfirm)
end

-- on clicked
function SummonExchangeCtrl:OnClicked(go)

	if go == self._ui.Blocker then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
	elseif go == self._ui.ButtonConfirm then
		SoundSystem.PlayUIClickSound()
		local characterId = self._parameter.characterId
		NetManager.Send("ExchangeChar", {Char = characterId}, SummonExchangeCtrl.OnHandleProto, self)
	end

	return true
end

function SummonExchangeCtrl:OnHandleProto(proto, data, requestData)
    if proto == 'ExchangeChar' then
        local characterId = requestData.Char
        local exchangeCost = ConfigUtils.GetCharacterExchangeCost(characterId)
        local exchangeItemId = exchangeCost.Value
    	local exchangeItemNum = exchangeCost.Num

    	GameData.ConsumeItem(exchangeItemId, exchangeItemNum)
    	GameData.CheckAndHintGoalsOfCurrentCountType()
    	-- clost this panel first
    	CtrlManager.PopPanel()
    	-- show new item
    	GameData.CollectItem(characterId, 1, true)
    end
end
