require "FreakPlanet/View/TouristResultPanel"

local class = require "FreakPlanet/Utils/middleclass"
TouristResultCtrl  = class(CtrlNames.TouristResult, BaseCtrl)

-- load the ui prefab
function TouristResultCtrl:LoadPanel()
	self:CreatePanel("TouristResult")
end

-- construct ui panel data
function TouristResultCtrl:ConstructUI(obj)
	self._ui = TouristResultPanel.Init(obj)
end

-- fill ui with the data
function TouristResultCtrl:SetupUI()
    local touristId = self._parameter.touristId
    local data = self._parameter.result
    local score = data.SumScore or 0
    local rank, rankData = ConfigUtils.GetRankOfTourist(touristId, score)
    -- rank hint
    self._ui.RankScore.text = ConfigUtils.GetTouristResultPrefix(touristId).." "..tostring(score)
    self._ui.RankDesc.text = SAFE_LOC(rankData.ResultText)
    -- reward list
    local rewardList = data.RewardList
    for idx = 1, #self._ui.RewardItems do
        local hasReward = (idx <= #rewardList)
        self._ui.RewardItems[idx].item:SetActive(hasReward)
        if hasReward then
            local itemId = rewardList[idx].Value
            local itemNum = rewardList[idx].Num

            UIHelper.ConstructItemIconAndNum(self, self._ui.RewardItems[idx].root, itemId, itemNum)
        end
    end
    self._ui.RewardRoot:GetComponent("UITable"):Reposition()

    -- sound
    local sounds = {
        SoundNames.TouristRank1,
        SoundNames.TouristRank2,
        SoundNames.TouristRank3,
        SoundNames.TouristRank4,
        SoundNames.TouristRank5,
    }
    SoundSystem.PlaySoundOfName(sounds[rank])
    -- rank
    self._ui.ResultBrilliant:SetActive(rank == 1)
    self._ui.ResultGreat:SetActive(rank == 2)
    self._ui.ResultGood:SetActive(rank == 3)
    self._ui.ResultMiddling:SetActive(rank == 4)
    self._ui.ResultBad:SetActive(rank >= 5)
    
    CtrlManager.AddClick(self, self._ui.Blocker)
    CtrlManager.AddClick(self, self._ui.ButtonRank)
end

function TouristResultCtrl:DoSettle()
    local data = self._parameter.result
    -- refresh new tourist data
    GameData.InitTouristData(data.ZooObj)

    local rewardList = data.RewardList or {}
    for idx = 1, #rewardList do
        local itemId = rewardList[idx].Value
        local itemNum = rewardList[idx].Num

        GameData.CollectItem(itemId, itemNum, false)
    end

    local goldNum = data.RemainGold
    local diamondNum = data.RemainDiamond
    GameData.SetMoney(ItemType.Gold, goldNum)
    GameData.SetMoney(ItemType.Diamond, diamondNum)
end

-- handle the escapse button
function TouristResultCtrl:HandleEscape()
    self:OnClicked(self._ui.Blocker)
end

-- can do jump or not
function TouristResultCtrl:CanJump()
    return false
end

-- on clicked
function TouristResultCtrl:OnClicked(go)
	
    if go == self._ui.Blocker then
        SoundSystem.PlayUICancelSound()
        self:DoSettle()
        -- tourist result
        CtrlManager.PopPanel()
        -- tourist
        CtrlManager.PopPanel()
    elseif go == self._ui.ButtonRank then
        SoundSystem.PlayUIClickSound()
        local touristId = self._parameter.touristId
        CtrlManager.OpenPanel(CtrlNames.TouristRankList, {touristId = touristId})
    end

    return true
end
