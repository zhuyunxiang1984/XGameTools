require 'FreakPlanet/View/LaboratoryPanel'

local class = require 'FreakPlanet/Utils/middleclass'
LaboratoryCtrl = class(CtrlNames.Laboratory, BaseCtrl)
---------------------------------------------------
local function RecipeSortFunc(idA, idB)
    if idA == nil or idB == nil then
        return false
    end

    local matchA = JumpManager.MatchCraftGoal(idA)
    local matchB = JumpManager.MatchCraftGoal(idB)
    if matchA ~= matchB then
        return matchA
    end

    local valueA = ConfigUtils.GetLabRecipeSortId(idA)
    local valueB = ConfigUtils.GetLabRecipeSortId(idB)

    return valueA < valueB
end
---------------------------------------------------
-- load the ui prefab
function LaboratoryCtrl:LoadPanel()
    self:CreatePanel('Laboratory')
end

-- construct ui panel data
function LaboratoryCtrl:ConstructUI(obj)
    self._ui = LaboratoryPanel.Init(obj)
end

-- fill ui with the data
function LaboratoryCtrl:SetupUI()

    self._SelectedLabRecipeType = self._parameter.LabRecipeType or LabRecipeType.Normal

    CtrlManager.AddClick(self, self._ui.ButtonClose)
    CtrlManager.AddClick(self, self._ui.ButtonConfirm.gameObject)
    CtrlManager.AddClick(self, self._ui.ButtonMinus)
    CtrlManager.AddClick(self, self._ui.ButtonPlus)
    CtrlManager.AddClick(self, self._ui.ButtonMax)

    CtrlManager.AddClick(self, self._ui.pBtnExchange)

    CtrlManager.AddPress(self, self._ui.ButtonMinus)
    CtrlManager.AddPress(self, self._ui.ButtonPlus)


    for k, v in pairs(self._ui.ConsumeGoods) do
        CtrlManager.AddClick(self, v.item)
    end

    self._craftState = nil
    self._craftResult = nil

    local recipeId = self._parameter.targetRecipeId
    self._selectedRecipe = nil
    if ConfigUtils.IsValidItem(recipeId) then
        self._selectedRecipe = recipeId
    end

    self:UpdateLabRecipeList(self._SelectedLabRecipeType)
    self:UpdateLabRecipeAnimalUI()
    self:OnSelectedRecipeChanged()
    --self:SetupNormalRecipeGrid()
    self:UpdateLabRecipeScrollViewUI(self._SelectedLabRecipeType)

    self._ui.RecipeGridWrap.OnItemUpdate = LaboratoryCtrl.OnItemUpdateGlobal
    self._ui.HomeFurnitureRecipeGridWrap.OnItemUpdate = LaboratoryCtrl.OnItemUpdateGlobal
    self._ui.HintItem:SetActive(false)

    self:CheckTutorial()
end

function LaboratoryCtrl:UpdateLabRecipeList(type)
    self._recipeList = GameData.GetUnlockedLabRecipesByType(type)
    -- sort once
    table.sort(self._recipeList, RecipeSortFunc)

    if self._selectedRecipe ~= nil and not Helper.TableContains(self._recipeList, self._selectedRecipe) then
        table.insert(self._recipeList, 1, self._selectedRecipe)
    end
end

function LaboratoryCtrl:UpdateLabRecipeScrollViewUI(type)
    if type == LabRecipeType.Normal then
        self._ui.pObjNormalRecipeRoot:SetActive(true)
        self._ui.pObjHomeFurnitureRecipeRoot:SetActive(false)
        self:SetupNormalRecipeGrid()
    elseif type == LabRecipeType.HomeFurniture then
        self._ui.pObjNormalRecipeRoot:SetActive(false)
        self._ui.pObjHomeFurnitureRecipeRoot:SetActive(true)
        self:SetupHomeFurnitureRecipeGrid()
    end
end

function LaboratoryCtrl:OnSelectedRecipeChanged()
    -- reset default state
    for idx = 1, #self._ui.ConsumeGoods do
        local item = self._ui.ConsumeGoods[idx].item
        item:SetActive(false)
    end

    local isValid = ConfigUtils.IsValidItem(self._selectedRecipe)
    self._ui.SelectedRecipeIcon.gameObject:SetActive(isValid)
    self._ui.SelectedRecipeNum.text = ""
    self._currentNum = 1
    if isValid then
        UIHelper.SetItemIcon(self,self._ui.SelectedRecipeIcon, self._selectedRecipe)
        self:OnSelectedRecipeNumChanged() 
    end

    local showButtons = isValid and GameData.IsLabRecipeUnlocked(self._selectedRecipe)
    self._ui.ButtonMinus:SetActive(showButtons)
    self._ui.ButtonPlus:SetActive(showButtons)
    self._ui.ButtonMax:SetActive(showButtons)
end

function LaboratoryCtrl:OnSelectedRecipeNumChanged()
    self._ui.SelectedRecipeNum.text = "x"..tostring(self._currentNum)

    local sources = ConfigUtils.GetCraftSourceOfLabRecipe(self._selectedRecipe)
    for idx = 1, #self._ui.ConsumeGoods do
        local item = self._ui.ConsumeGoods[idx].item
        local hasSource = (idx <= #sources)
        item:SetActive(hasSource)

        if hasSource then
            local icon = self._ui.ConsumeGoods[idx].icon
            local numLabel = self._ui.ConsumeGoods[idx].num
            --local needNumLabel = self._ui.ConsumeGoods[idx].needNum

            local goodsId = sources[idx].id
            local needNum = sources[idx].num * self._currentNum
            local ownNum = GameData.GetItemNum(goodsId)

            UIHelper.SetItemIcon(self,icon, goodsId)

            local type = ConfigUtils.GetItemTypeFromId(goodsId)
            if type == ItemType.Diamond or type == ItemType.Gold then
                if needNum > ownNum then
                    numLabel.text = string.format("[ff0000]%d[-]", needNum)
                else
                    numLabel.text = string.format("[6DFFFF]%d[-]", needNum)
                end
            else
                if needNum > ownNum then
                    numLabel.text = string.format("[ff0000]%d[-][6DFFFF]/%d[-]", needNum, ownNum)
                else
                    numLabel.text = string.format("[6DFFFF]%d/%d[-]", needNum, ownNum)
                end
            end

        end
    end
end

function LaboratoryCtrl:SetupNormalRecipeGrid()
    local childCount = self._ui.RecipeGrid.childCount
    for idx = childCount, 1, -1 do
        local pObjItem = self._ui.RecipeGrid:GetChild(idx - 1).gameObject
        self._ui.ObjPool:RecycleObj(pObjItem)
    end

    local itemCount = self._ui.RecipeGridWrap.NeedCellCount
    itemCount = math.min(#self._recipeList, itemCount)
    self._ui.RecipeGridWrap.MaxRow = math.ceil(#self._recipeList / self._ui.RecipeGridWrap.ColumnLimit)

    for idx = 1, itemCount do
        local itemId = self._recipeList[idx]
        local pObjItem = self._ui.ObjPool:GetOrCreateObj(self._ui.EnumPrefabType.RecipeItem, function(pObj)
            CtrlManager.AddClick(self, pObj)
        end)
        pObjItem.transform:SetParent(self._ui.RecipeGrid)
        pObjItem:SetActive(true)
        pObjItem.transform.localScale = Vector3.one
        pObjItem.transform.localPosition = Vector3.zero
        pObjItem.name = tostring(itemId)
        self:ConsturctRecipeItem(pObjItem, itemId)
    end

    self._ui.RecipeGridWrap:SortBasedOnScrollMovement()
    self._ui.RecipeScrollView:ResetPosition()
    self._ui.RecipeScrollView.disableDragIfFits = (#self._recipeList <= itemCount)
    self._ui.RecipeScrollView.restrictWithinPanel = true
end

function LaboratoryCtrl:SetupHomeFurnitureRecipeGrid()
    local childCount = self._ui.pTransHomeFurnitureRecipe.childCount
    for idx = childCount, 1, -1 do
        local pObjItem = self._ui.pTransHomeFurnitureRecipe:GetChild(idx - 1).gameObject
        self._ui.ObjPool:RecycleObj(pObjItem)
    end

    local itemCount = self._ui.HomeFurnitureRecipeGridWrap.NeedCellCount
    itemCount = math.min(#self._recipeList, itemCount)
    self._ui.HomeFurnitureRecipeGridWrap.MaxRow = math.ceil(#self._recipeList / self._ui.HomeFurnitureRecipeGridWrap.ColumnLimit)

    for idx = 1, itemCount do
        local itemId = self._recipeList[idx]

        local pObjItem = self._ui.ObjPool:GetOrCreateObj(self._ui.EnumPrefabType.RecipeItem, function(pObj)
            CtrlManager.AddClick(self, pObj)
        end)
        pObjItem.transform:SetParent(self._ui.pTransHomeFurnitureRecipe)
        pObjItem:SetActive(true)
        pObjItem.transform.localScale = Vector3.one
        pObjItem.transform.localPosition = Vector3.zero
        pObjItem.name = tostring(itemId)
        self:ConsturctRecipeItem(pObjItem, itemId)

    end

    self._ui.HomeFurnitureRecipeGridWrap:SortBasedOnScrollMovement()
    self._ui.pScrollViewHomeFurnitureRecipe:ResetPosition()
    self._ui.pScrollViewHomeFurnitureRecipe.disableDragIfFits = (#self._recipeList <= itemCount)
    self._ui.pScrollViewHomeFurnitureRecipe.restrictWithinPanel = true
end

function LaboratoryCtrl:ConsturctRecipeItem(item, itemId)
    -- base info
    local nameLabel = item.transform:Find("Name"):GetComponent("UILabel")
    nameLabel.text = ConfigUtils.GetLabRecipeName(itemId)

    local icon = item.transform:Find("Icon"):GetComponent("UISprite")
    UIHelper.SetItemIcon(self,icon, itemId)

    -- num
    self:RefreshRecipeItemNum(item, itemId)

    -- selected
    local selected = (itemId == self._selectedRecipe)
    self:ToggleSelectedMark(item, selected)

    -- locked
    local lockMark = item.transform:Find("Lock").gameObject
    local unlocked = GameData.IsLabRecipeUnlocked(itemId)
    lockMark:SetActive(not unlocked)

    -- goal
    local goalMark = item.transform:Find("Goal").gameObject
    local goalMatch = JumpManager.MatchCraftGoal(itemId)
    goalMark:SetActive(goalMatch)
end

function LaboratoryCtrl:RefreshRecipeItemNum(item, itemId)
    local numLabel = item.transform:Find("Num"):GetComponent("UILabel")
    local craftResultItemId = ConfigUtils.GetLabRecipeCraftResult(itemId)
    local craftResultItemNum = GameData.GetItemNum(craftResultItemId)
    numLabel.text = "x"..tostring(craftResultItemNum)
end

function LaboratoryCtrl:RefreshAllRecipeItemsNum()
    if self._SelectedLabRecipeType == LabRecipeType.Normal then
        local num = self._ui.RecipeGrid.childCount
        for idx = 1, num do
            local item = self._ui.RecipeGrid:GetChild(idx - 1)
            if item.gameObject.activeSelf then
                local itemId = tonumber(item.gameObject.name)
                self:RefreshRecipeItemNum(item, itemId)
            end
        end
    else
        local num = self._ui.pTransHomeFurnitureRecipe.childCount
        for idx = 1, num do
            local item = self._ui.pTransHomeFurnitureRecipe:GetChild(idx - 1)
            if item.gameObject.activeSelf then
                local itemId = tonumber(item.gameObject.name)
                self:RefreshRecipeItemNum(item, itemId)
            end
        end
    end

end

function LaboratoryCtrl:ToggleSelectedMark(item, selected)
    local selectedMark = item.transform:Find("Select").gameObject
    selectedMark:SetActive(selected)
end

function LaboratoryCtrl:ToggleSelectedMarkById(itemId, selected)
    if itemId == nil then
        return
    end
    local item = nil
    local labRecipeType = ConfigUtils.GetLabRecipeType(itemId)
    if labRecipeType == LabRecipeType.Normal then
        item = self._ui.RecipeGrid:Find(itemId)
    elseif labRecipeType == LabRecipeType.HomeFurniture then
        item = self._ui.pTransHomeFurnitureRecipe:Find(itemId)
    end

    if item ~= nil then
        self:ToggleSelectedMark(item, selected)
    end
end

function LaboratoryCtrl.OnItemUpdateGlobal(itemObj, itemIndex, itemRealIndex)
    local ctrl = CtrlManager.GetCtrlByName(CtrlNames.Laboratory)
    if ctrl ~= nil then
        ctrl:OnItemUpdate(itemObj, itemIndex, itemRealIndex)
    end
end

function LaboratoryCtrl:OnItemUpdate(itemObj, itemIndex, itemRealIndex)
    itemRealIndex = itemRealIndex + 1
    if itemRealIndex <= 0 or itemRealIndex > #self._recipeList then
        itemObj:SetActive(false)
    else
        itemObj:SetActive(true)
        local recipeId = self._recipeList[itemRealIndex]
        itemObj.name = tostring(recipeId)
        self:ConsturctRecipeItem(itemObj, recipeId)
    end
end

function LaboratoryCtrl:DoJump(labRecipeId)
	if not ConfigUtils.IsValidItem(labRecipeId) or labRecipeId == self._selectedRecipe then
		return
	end

    self:ToggleSelectedMarkById(self._selectedRecipe, false)
    self._selectedRecipe = labRecipeId
    -- recipe list changed
    if not Helper.TableContains(self._recipeList, labRecipeId) then
	   table.insert(self._recipeList, 1, self._selectedRecipe)
       self:SetupNormalRecipeGrid()
    end

    self:OnSelectedRecipeChanged()
    self:ToggleSelectedMarkById(self._selectedRecipe, true)
end

-- update per frame
function LaboratoryCtrl:UpdateImpl(deltaTime)
    if self._craftState ~= nil then
        local finished = self._craftState:Tick(deltaTime)
        if finished then
            self._craftState = nil
        end
    end

    if  self._isPressing then
        local step = math.ceil(self._maxNumWhenPress / 5)
        step = math.max(step, 10)
        self._pressingTime = self._pressingTime + deltaTime
        self._floatNum = self._floatNum + deltaTime * step * math.ceil(self._pressingTime) * self._pressingSign
        self._currentNum = math.floor(self._floatNum)
        if self._pressingSign > 0 then
            self._currentNum = math.min(self._currentNum, self._maxNumWhenPress)
            self._currentNum = math.max(1, self._currentNum)
        else
            self._currentNum = math.max(1, self._currentNum)
        end
        self:OnSelectedRecipeNumChanged()
    end
end

function LaboratoryCtrl:IsGoodsEnough(craftNum)
    local sources = ConfigUtils.GetCraftSourceOfLabRecipe(self._selectedRecipe)
    for idx = 1, #sources do
        local goodsId = sources[idx].id
        local needNum = sources[idx].num * craftNum
        local ownNum = GameData.GetItemNum(goodsId)
        if needNum > ownNum then
            return false
        end
    end

    return true
end

function LaboratoryCtrl:GetMaxNumCanCraft()
    local numbers = {}
    local sources = ConfigUtils.GetCraftSourceOfLabRecipe(self._selectedRecipe)
    for idx = 1, #sources do
        local goodsId = sources[idx].id
        local needNum = sources[idx].num
        local ownNum = GameData.GetItemNum(goodsId)
        numbers[idx] = math.floor(ownNum / needNum)
    end

    return math.min(unpack(numbers))
end

-- handle the escapse button
function LaboratoryCtrl:HandleEscape()
    self:OnClicked(self._ui.ButtonClose)
end

-- can do jump or not
function LaboratoryCtrl:CanJump()
    return self._craftResult == nil
end

function LaboratoryCtrl:UpdateLabRecipeAnimalUI()
    self._ui.pObjCat:SetActive(self._SelectedLabRecipeType == LabRecipeType.Normal)
    self._ui.pObjMouse:SetActive(self._SelectedLabRecipeType == LabRecipeType.HomeFurniture)
end

-- on pressed
function LaboratoryCtrl:OnPressed(go, pressed, isLong)
    if pressed and isLong then
        if go == self._ui.ButtonPlus or go == self._ui.ButtonMinus then
            self._isPressing = true
            self._pressingTime = 0
            self._floatNum = self._currentNum
            self._maxNumWhenPress = self:GetMaxNumCanCraft()
            if go == self._ui.ButtonPlus then
                self._pressingSign = 1
            else
                self._pressingSign = -1
            end
        end
    elseif not pressed and self._isPressing then
        self._isPressing = false
    end
end

-- on clicked
function LaboratoryCtrl:OnClicked(go)
    if self._craftResult ~= nil then
        return true
    end

    if go == self._ui.ButtonClose then
        SoundSystem.PlayUICancelSound()
        CtrlManager.PopPanel()
    elseif go == self._ui.ButtonConfirm.gameObject then
        if not ConfigUtils.IsValidItem(self._selectedRecipe) or self._currentNum < 1 then
            SoundSystem.PlayWarningSound()
            CtrlManager.ShowMessageBox({message = SAFE_LOC("请先选择需要合成的物品"), single = true})
            return true
        end

        if not GameData.IsLabRecipeUnlocked(self._selectedRecipe) then
            SoundSystem.PlayWarningSound()
            CtrlManager.ShowMessageBox({message = SAFE_LOC("合成配方还未解锁"), single = true})
            return true
        end

         if not self:IsGoodsEnough(self._currentNum) then
            SoundSystem.PlayWarningSound()
            CtrlManager.ShowMessageBox({message = SAFE_LOC("合成所需物品不足"), single = true})
            return true
        end

        SoundSystem.PlaySoundOfName(SoundNames.Craft)
        NetManager.Send('Craft', {LabRecipeId = self._selectedRecipe, CraftNum = self._currentNum}, LaboratoryCtrl.OnHandleProto, self)
    elseif go.transform.parent == self._ui.RecipeGrid or go.transform.parent == self._ui.pTransHomeFurnitureRecipe then
        local recipeId = tonumber(go.name)
        if recipeId ~= self._selectedRecipe then
            SoundSystem.PlayUIClickSound()
            self:ToggleSelectedMarkById(self._selectedRecipe, false)
            self._selectedRecipe = recipeId
            self:OnSelectedRecipeChanged()
            self:ToggleSelectedMarkById(self._selectedRecipe, true) 
        end
    elseif go == self._ui.ButtonPlus then
        local newNum = self._currentNum + 1
        if self:IsGoodsEnough(newNum) then
            SoundSystem.PlayUIClickSound()
            self._currentNum = newNum
            self:OnSelectedRecipeNumChanged()
        else
            SoundSystem.PlayWarningSound()
            self._ui.HintItem:SetActive(true)
            self._ui.HintAnimator:Play("ItemHint", 0, 0)
            self._ui.HintLabel.text = SAFE_LOC("合成物品不足")
        end
    elseif go == self._ui.ButtonMinus then
        -- decrease number
        if self._currentNum > 1 then
            SoundSystem.PlayUIClickSound()
            self._currentNum = self._currentNum - 1
            self:OnSelectedRecipeNumChanged()
        else
            SoundSystem.PlayWarningSound()
        end
    elseif go == self._ui.ButtonMax then
        local maxNum = self:GetMaxNumCanCraft()
        if maxNum > self._currentNum then
            SoundSystem.PlayUIClickSound()
            self._currentNum = maxNum
            self:OnSelectedRecipeNumChanged()
        else
            SoundSystem.PlayWarningSound()
            self._ui.HintItem:SetActive(true)
            self._ui.HintAnimator:Play("ItemHint", 0, 0)
            self._ui.HintLabel.text = SAFE_LOC("数量已最大")
        end
    elseif Helper.StartWith(go.name, 'ConsumeGoods_') then
        local names = Helper.StringSplit(go.name)
        assert(#names == 2, "invalid consume goods item name: "..go.name)
        local idx = tonumber(names[2])
        local sources = ConfigUtils.GetCraftSourceOfLabRecipe(self._selectedRecipe)
        local itemId = sources[idx].id
        CtrlManager.ShowItemDetail({itemId = itemId})
    elseif go == self._ui.pBtnExchange then
        if self._SelectedLabRecipeType ~= LabRecipeType.HomeFurniture then
            self._SelectedLabRecipeType = LabRecipeType.HomeFurniture
        elseif self._SelectedLabRecipeType ~= LabRecipeType.Normal then
            self._SelectedLabRecipeType = LabRecipeType.Normal
        end
        self._selectedRecipe = nil
        self._currentNum = 1
        self:UpdateLabRecipeList(self._SelectedLabRecipeType)
        self:UpdateLabRecipeScrollViewUI(self._SelectedLabRecipeType)
        self:UpdateLabRecipeAnimalUI()
        self:OnSelectedRecipeChanged()
    end

    return true
end

function LaboratoryCtrl:OnHandleProto(proto, data, requestData)
    if proto == 'Craft' then
        self._craftResult = {}
        self._craftResult.recipeId = requestData.LabRecipeId
        self._craftResult.recipeNum = requestData.CraftNum

        local resultGoods = {}
        for idx = 1, #data.EarnGoods do
            local itemId = data.EarnGoods[idx][1]
            local itemNum = data.EarnGoods[idx][2]
            local unlocked = GameData.IsItemUnlocked(itemId)
            resultGoods[idx] = {value = itemId, num = itemNum, unlocked = unlocked}
        end

        self._craftResult.resultGoods = resultGoods

        self._craftState = AnimatorState:new(self._ui.Item_Animator, "Show_MadeNormal", "Show_Idle", nil)
        self._craftState:ActionOnExit(LaboratoryCtrl.OnCraftFinished, self)
    end
end

function LaboratoryCtrl:OnCraftFinished()
    local costGoods = {}
    local recipeId = self._craftResult.recipeId
    local recipeNum = self._craftResult.recipeNum
    local sources = ConfigUtils.GetCraftSourceOfLabRecipe(recipeId)
    for idx = 1, #sources do
        local goodsId = sources[idx].id
        local costNum = sources[idx].num * recipeNum
        local preNum = costGoods[goodsId] or 0
        costGoods[goodsId] = preNum + costNum
    end

    NewItemCtrl.ShowNewItemList(self._craftResult.resultGoods)
    GameData.DoCraft(self._craftResult.resultGoods, costGoods)
    GameData.SyncTutorialData()

    self._currentNum = 1
    self:OnSelectedRecipeNumChanged()
    self:RefreshAllRecipeItemsNum()
    self._craftResult = nil
end
--------------------------------------------------------
-- tutorial
function LaboratoryCtrl:CheckTutorial()
    local tutorials = {}

    if GameData.IsTutorialNotFinished(Tutorials.Tutorial_9_3) and GameData.IsGoalRunning(TutorialConstData.CraftGoal) then
        local gridItem = self._ui.RecipeGrid:GetChild(0)
        local position = self._ui.Camera:WorldToScreenPoint(gridItem.position)
        tutorials[1] = {event = Tutorials.Tutorial_9_1, position = position, sender = self}
        position = self._ui.Camera:WorldToScreenPoint(self._ui.ButtonPlus.transform.position)
        tutorials[2] = {event = Tutorials.Tutorial_9_2, position = position, sender = self}
        position = self._ui.Camera:WorldToScreenPoint(self._ui.ButtonConfirm.transform:Find("TutorialMark").position)
        tutorials[3] = {event = Tutorials.Tutorial_9_3, position = position, sender = self}
    end

    if #tutorials > 0 then
        CtrlManager.ShowTutorials(tutorials)
    end

    return #tutorials > 0
end

function LaboratoryCtrl:OnTutorialClicked(tutorial)
    if tutorial == Tutorials.Tutorial_9_1 then
        local gridItem = self._ui.RecipeGrid:GetChild(0)
        self:OnClicked(gridItem.gameObject)
    elseif tutorial == Tutorials.Tutorial_9_2 then
        self:OnClicked(self._ui.ButtonPlus)
    elseif tutorial == Tutorials.Tutorial_9_3 then
        self:OnClicked(self._ui.ButtonConfirm.gameObject)
    else
        SoundSystem.PlayUIClickSound()
    end
end
--------------------------------------------------------