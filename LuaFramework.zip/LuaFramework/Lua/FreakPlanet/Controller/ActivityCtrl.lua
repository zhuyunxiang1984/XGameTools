require "FreakPlanet/View/ActivityPanel"

local class = require "FreakPlanet/Utils/middleclass"
ActivityCtrl  = class(CtrlNames.Activity, BaseCtrl)

-- load the ui prefab
function ActivityCtrl:LoadPanel()
    self:CreatePanel("Activity")
end

-- construct ui panel data
function ActivityCtrl:ConstructUI(obj)
    self._ui = ActivityPanel.Init(obj)
end

-- notity it has been focused
function ActivityCtrl:NotifyFocus()
    self:RefreshGoalHint()
    self:RefreshButtonState()
end

-- destructor
function ActivityCtrl:DestroyImpl()
    GameNotifier.RemoveListener(GameEvent.CharacterNodeVisibleChanged, ActivityCtrl.OnCharacterNodeVisibleChanged, self)
end

-- fill ui with the data
function ActivityCtrl:SetupUI()
    self._currentThemeId, self._currentThemeEndTime = GameData.GetCurrentActivityTheme()    
    self._themeList = GameData.GetActivityThemeListToShow()
    if #self._themeList > 0 then
        self._themeIdx = 1
        self._ui.DoorAnimator:Play("Door_Open", 0)
    else
        self._themeIdx = nil
        self._ui.DoorAnimator:Play("Door_Close", 0)
    end

    for k, themeId in pairs(self._themeList) do
        local bundleName = ConfigUtils.GetActivityThemeTextureBundle(themeId)
        if bundleName ~= nil then
            self:DynamicLoadBundle(bundleName)
        end
    end

    self._doorState = nil
    self._ui.EmptyMark:SetActive(#self._themeList == 0)
    self:OnSelectedThemeChanged()
    self:RefreshGoalHint()
    self:RefreshButtonState()

    CtrlManager.AddClick(self, self._ui.Blocker)
    CtrlManager.AddClick(self, self._ui.Border)
    CtrlManager.AddClick(self, self._ui.ButtonNext)
    CtrlManager.AddClick(self, self._ui.ButtonPrev)

    CtrlManager.AddClick(self, self._ui.ButtonPackage)
    CtrlManager.AddClick(self, self._ui.ButtonGoal)
    CtrlManager.AddClick(self, self._ui.ButtonBattle)
    CtrlManager.AddClick(self, self._ui.ButtonBox)

    GameNotifier.AddListener(GameEvent.CharacterNodeVisibleChanged, ActivityCtrl.OnCharacterNodeVisibleChanged, self)
end

function ActivityCtrl:RecycleThemeAvatar()
    local num = self._ui.ActivityRoot.childCount
    for idx = num, 1, -1 do
        local item = self._ui.ActivityRoot:GetChild(idx - 1)
        item.parent = self._ui.ActivityPool
    end
end

function ActivityCtrl:OnSelectedThemeChanged()
    self:CleanDialog()
    self:RecycleThemeAvatar()

    if self._themeIdx ~= nil then
        local themeId = self._themeList[self._themeIdx]
        self._ui.ActivityName.text = ConfigUtils.GetActivityThemeName(themeId)
        local prefabName, prefabBundle = ConfigUtils.GetActivityThemePrefab(themeId)
        local activityItem = self._ui.ActivityPool:Find(prefabName)
        if activityItem == nil then
            local themePrefab = self:DynamicLoadAsset(prefabBundle, prefabName)
            local prefabObj = Helper.NewObject(themePrefab, self._ui.ActivityRoot)
            prefabObj:SetActive(true)
            prefabObj.name = prefabName
            activityItem = prefabObj.transform
        else
            activityItem.parent = self._ui.ActivityRoot
            activityItem.localScale = Vector3.one
            activityItem.localPosition = Vector3.zero
        end
        -- character node
        self:ConstructCharacterNode(activityItem)
    else
        self._ui.ActivityName.text = ""
    end

    local showButton = (#self._themeList > 1)
    self._ui.ButtonNext:SetActive(showButton)
    self._ui.ButtonPrev:SetActive(showButton)
end

function ActivityCtrl:ConstructCharacterNode(item)
    local characterNodeRoot = item:Find("Group")
    for idx = 1, characterNodeRoot.childCount do
        local groupNode = characterNodeRoot:GetChild(idx - 1)
        for childIdx = 1, groupNode.childCount do
            local nodeItem = groupNode:GetChild(childIdx - 1).gameObject
            local nodeName = nodeItem.name
            local isVisible = NodeHelper.IsCharacterNodeVisibleConditionMatch(nodeName, true)
            nodeItem:SetActive(isVisible)
        end
    end
end

function ActivityCtrl:OnCharacterNodeVisibleChanged(nodeName, visible)
    local activityItem = self._ui.ActivityRoot:GetChild(0)
    self:ConstructCharacterNode(activityItem)
end

function ActivityCtrl:GenerateDoorState(isNext)
    local state = SequenceState:new()

    local closeState = AnimatorState:new(self._ui.DoorAnimator, "Door_Close", nil, self._ui.DoorAnimator.gameObject)
    closeState:ActionOnExit(ActivityCtrl.OnDoorOpen, self, isNext)
    state:Push(closeState)

    local openState = AnimatorState:new(self._ui.DoorAnimator, "Door_Open", nil)
    state:Push(openState)

    return state
end

function ActivityCtrl:OnDoorOpen(isNext)
    if isNext then
        self._themeIdx = self._themeIdx + 1
        if self._themeIdx > #self._themeList then
            self._themeIdx = 1
        end
    else
        self._themeIdx = self._themeIdx - 1
        if self._themeIdx < 1 then
            self._themeIdx = #self._themeList
        end
    end

    self:OnSelectedThemeChanged()
end

function ActivityCtrl:UpdateImpl(deltaTime)
    if self._doorState ~= nil then
        local finished = self._doorState:Tick(deltaTime)
        if finished then
            self._doorState = nil
        end
    end
    -- update dialog
    self:UpdateDialog(deltaTime)
end

function ActivityCtrl:RefreshGoalHint()
    local showHint = GameData.HasCompletedActivityGoal()
    self._ui.GoalHint:SetActive(showHint)
end

function ActivityCtrl:RefreshButtonState()
    local hasPackage = GameData.HasActiveActivityPackage()
    local hasBattle = self:HasValidActivityBattle()
    local hasBox = self:HasValidActivityArenaShop()
    local hasGoal = GameData.HasTimeLimitActivity()
    self._ui.ButtonPackage:SetActive(hasPackage)
    self._ui.ButtonBattle:SetActive(hasBattle)
    self._ui.ButtonBox:SetActive(hasBox)
    self._ui.ButtonGoal:SetActive(hasGoal)
    self._ui.ButtonTable:Reposition()
end

function ActivityCtrl:HasValidActivityBattle()
    local themeId = self._currentThemeId
    if not GameData.IsActivityThemeValid(themeId) then
        return false
    end
    
    return ConfigUtils.CanBattleInActivityTheme(themeId)
end

function ActivityCtrl:GetActivityArenaShop()
    local themeId = self._currentThemeId
    local activityArenaShopId = nil
    if GameData.IsActivityThemeValid(themeId) then
        activityArenaShopId = ConfigUtils.GetActivityArenaShop(themeId)
    end

    return activityArenaShopId
end

function ActivityCtrl:HasValidActivityArenaShop()
    local arenaShopId = self:GetActivityArenaShop()
    return arenaShopId ~= nil
end

-- on clicked
function ActivityCtrl:OnClicked(go)
      if go == self._ui.Blocker then
          SoundSystem.PlayUICancelSound()
          CtrlManager.PopPanel()
      elseif go == self._ui.Border then
          local pos = self:ScreenToWorld(Input.mousePosition)
          local hitResult = UnityEngine.Physics2D.Raycast(pos, Vector3.forward)
          if hitResult.collider ~= nil and hitResult.collider.transform.parent ~= nil and hitResult.collider.transform.parent.parent ~= nil then
              local parentName = hitResult.collider.transform.parent.parent.gameObject.name
              if parentName == "Group" then
                  local node = hitResult.collider.transform
                  self:OnGroupNodeClicked(node)
              end
          end
      elseif go == self._ui.ButtonPackage then
          if GameData.HasActiveActivityPackage() then
              SoundSystem.PlayUIClickSound()
              CtrlManager.OpenPanel(CtrlNames.ActivityPackage)
          else
              SoundSystem.PlayWarningSound()
              CtrlManager.ShowMessageBox({message = SAFE_LOC("当前没有活动礼包"), single = true})
          end
      elseif go == self._ui.ButtonGoal then
          if GameData.HasTimeLimitActivity() then
              SoundSystem.PlayUIClickSound()
              CtrlManager.OpenPanel(CtrlNames.ActivityGoal)
          else
              SoundSystem.PlayWarningSound()
              CtrlManager.ShowMessageBox({message = SAFE_LOC("当前没有活动任务"), single = true})
          end
      elseif go == self._ui.ButtonBattle then
          if self:HasValidActivityBattle() then
              SoundSystem.PlayUIClickSound()
              CtrlManager.OpenPanel(CtrlNames.ActivityBattle, {themeId = self._currentThemeId, endTime = self._currentThemeEndTime})
          else
              SoundSystem.PlayWarningSound()
              CtrlManager.ShowMessageBox({message = SAFE_LOC("当前没有活动挑战"), single = true})
          end
      elseif go == self._ui.ButtonBox then
          local activityArenaShopId = self:GetActivityArenaShop()
          if activityArenaShopId ~= nil then
              SoundSystem.PlayUIClickSound()
              CtrlManager.OpenPanel(CtrlNames.ArenaMarketDetail, {
                  shopId = activityArenaShopId,
                  activity = true,
                  endTime = self._currentThemeEndTime,
              })
          else
              SoundSystem.PlayWarningSound()
              CtrlManager.ShowMessageBox({message = SAFE_LOC("当前没有活动盲盒"), single = true})
          end
      elseif go == self._ui.ButtonNext then
          SoundSystem.PlayUIClickSound()
          self._doorState = self:GenerateDoorState(true)
      elseif go == self._ui.ButtonPrev then
          SoundSystem.PlayUIClickSound()
          self._doorState = self:GenerateDoorState(false)
      end

      return true
end

-------------------------------------------------------------------------------------
-- Dialog
function ActivityCtrl:UpdateDialog(deltaTime)
    -- update dialog
    if #self._dialogList > 0 then
        self._ui.DialogItem.localPosition = self._ui.DialogRoot:InverseTransformPoint(self._dialogList[1].root.position)
        local leftTime = self._dialogList[1].leftTime - deltaTime
        self._dialogList[1].leftTime = leftTime
        if leftTime <= 0 then
            table.remove(self._dialogList, 1)
            if #self._dialogList > 0 then
                self:PeekFirstDialog()
            else
                self:HideDialogItem()
            end
        end
    end
end

function ActivityCtrl:HideDialogItem()
    self._ui.DialogItem.gameObject:SetActive(false)
end

function ActivityCtrl:CleanDialog()
    self._dialogList = {}
    self:HideDialogItem()
end

function ActivityCtrl:PeekFirstDialog()
    if #self._dialogList == 0 then
        return
    end

    self._ui.DialogTypeEffect:Finish()
    self._ui.DialogItem.gameObject:SetActive(true)
    self._ui.DialogLabel.text = self._dialogList[1].message
    local bgHeight = self._ui.DialogLabel.height + 20
    bgHeight = math.max(72, bgHeight)
    self._ui.DialogBG.height = bgHeight
    self._ui.DialogTypeEffect:ResetToBeginning()
end

function ActivityCtrl:OnGroupNodeClicked(node)
    local dialogRoot = node:Find("DialogRoot")
    if dialogRoot == nil then
        return
    end

    self._dialogList = {}
    local childCount = dialogRoot.childCount

    local nodeName = node.gameObject.name
    local dialogList = ConfigUtils.GetExileCharacterNodeDialogList(nodeName) or {}
    local totalCount = #dialogList
    if totalCount >= 1 then
        local dialogIdx = Helper.RandInt(1, totalCount)
        local dialogs = dialogList[dialogIdx]
        for idx = 1, #dialogs do
            local text = dialogs[idx].Text
            local pos = dialogs[idx].Position
            if pos <= childCount then
                table.insert(self._dialogList, {
                    message = SAFE_LOC(text),
                    root = dialogRoot:GetChild(pos - 1),
                    leftTime = string.len(text) / self._ui.DialogTypeEffect.charsPerSecond + 0.5,
                })
            end
        end
    end

    self:PeekFirstDialog()
end
-------------------------------------------------------------------------------------