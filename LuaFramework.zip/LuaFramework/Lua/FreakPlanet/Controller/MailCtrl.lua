require "FreakPlanet/View/MailPanel"

local class = require "FreakPlanet/Utils/middleclass"
MailCtrl  = class(CtrlNames.Mail, BaseCtrl)
---------------------------------------------------------
local function MailSortFunc(idA, idB)
	if idA == nil or idB == nil then
		return false
	end

	local _, _, mailReadA, mailRewardedA, mailRewardListA = GameData.GetMailData(idA)
	local _, _, mailReadB, mailRewardedB, mailRewardListB = GameData.GetMailData(idB)

	if mailReadA ~= mailReadB then
		return not mailReadA
	end

	local hasRewardA = (#mailRewardListA > 0 and not mailRewardedA)
	local hasRewardB = (#mailRewardListB > 0 and not mailRewardedB)

	if hasRewardA ~= hasRewardB then
		return hasRewardA
	end

	local valueA = GameData.GetMailTime(idA)
	local valueB = GameData.GetMailTime(idB)

	return valueA > valueB
end
---------------------------------------------------------
-- load the ui prefab
function MailCtrl:LoadPanel()
	self:CreatePanel("Mail")
end

-- construct ui panel data
function MailCtrl:ConstructUI(obj)
	self._ui = MailPanel.Init(obj)
end

-- destroy implementation
function MailCtrl:DestroyImpl()
	GameNotifier.RemoveListener(GameEvent.MailStateChanged, MailCtrl.OnMailChanged, self)
end

-- fill ui with the data
function MailCtrl:SetupUI()
	self:OnMailChanged()

	CtrlManager.AddClick(self, self._ui.Blocker)
	CtrlManager.AddClick(self, self._ui.Content.gameObject)
	CtrlManager.AddClick(self, self._ui.ButtonNext)
	CtrlManager.AddClick(self, self._ui.ButtonPrevious)
	CtrlManager.AddClick(self, self._ui.ButtonReward)

	GameNotifier.AddListener(GameEvent.MailStateChanged, MailCtrl.OnMailChanged, self)
end

function MailCtrl:OnMailChanged()
	self._mailList = GameData.GetValidMailList()

	if #self._mailList > 0 then
		table.sort(self._mailList, MailSortFunc)
		self._mailIndex = 1
	else
		self._mailIndex = -1
	end

	self:OnMailIndexChanged()
end

function MailCtrl:OnMailIndexChanged()
	-- restore drop item
	local count = self._ui.DropRoot.childCount
	for idx = count, 1, -1 do
		local item = self._ui.DropRoot:GetChild(idx - 1)
		item.parent = self._ui.DropPool
	end

	local currentTime = GameData.GetServerTime()

	if self._mailIndex > 0 then
		local mailId = self._mailList[self._mailIndex]
		local mailTitle, mailContent, mailRead, mailRewarded, mailRewardList = GameData.GetMailData(mailId)
		
		local mailExpireTime = GameData.GetMailExpireTime(mailId)
		local leftTime = math.max(mailExpireTime - currentTime, 0)
		if leftTime > 0 then
			local hintText = SAFE_LOC("loc_global_mailIsOverdue")
			local timeText = Helper.GetLongTimeString(leftTime)
			self._ui.TimeHint.text = Helper.StringFindAndReplace(hintText, "{Time}", timeText)
		else
			self._ui.TimeHint.text = SAFE_LOC("邮件已过期")
		end

		self._ui.Title.text = mailTitle
		self._ui.Content.text = mailContent

		local hasReward = #mailRewardList > 0
		self._ui.ButtonReward:SetActive(hasReward and not mailRewarded)
		self._ui.RewaredMark:SetActive(hasReward and mailRewarded)

		for idx = 1, #mailRewardList do
			local dropId = mailRewardList[idx].id
			local dropNum = mailRewardList[idx].num

			local item = nil
			if self._ui.DropPool.childCount == 0 then
				local itemObj = Helper.NewObject(self._ui.DropItemTemplate, self._ui.DropRoot)
				item = itemObj.transform
			else
				item = self._ui.DropPool:GetChild(0)
				item.parent = self._ui.DropRoot
				item.localPosition = Vector3.zero
				item.localScale = Vector3.one
			end

			item.gameObject:SetActive(true)
			item.gameObject.name = tostring(dropId)

			UIHelper.ConstructItemIconAndNum(self, item, dropId, dropNum)
		end

		self._ui.DropRoot:GetComponent("UITable"):Reposition()
		self._ui.ScrollView:ResetPosition()

		self._ui.ButtonNext:SetActive(self._mailIndex < #self._mailList)
		self._ui.ButtonPrevious:SetActive(self._mailIndex > 1)
		-- not read and not expire
		if not mailRead and leftTime > 0 then
			NetManager.Send("MailRead", {MailId = mailId}, MailCtrl.OnHandleProto, self)
		end
	else
		self._ui.Title.text = ""
		self._ui.TimeHint.text = ""
		self._ui.Content.text = SAFE_LOC("loc_global_no_mail")
		self._ui.ButtonReward:SetActive(false)
		self._ui.RewaredMark:SetActive(false)
		self._ui.ButtonNext:SetActive(false)
		self._ui.ButtonPrevious:SetActive(false)
	end
end

function MailCtrl.CanGetReward()
	local needCheck = false
	if not Helper.IsEmptyOrNull(Global.ExtraData) then
		local json = require "cjson"
    	local extraInfo = json.decode(Global.ExtraData)
		if extraInfo.MailForbidden == "1" then
			needCheck = true
		end
	end

	if not needCheck then
		return true
	end

	if not GameData.EnableRealName() then
		return true
	end

	if GameData.GetSumPay() > 0 then
		return true
	end

	if GameData.IsAccountVerified() then
		return true
	end

	return false
end

-- on clicked
function MailCtrl:OnClicked(go)
	if go == self._ui.Blocker then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
	elseif go == self._ui.ButtonReward then
		local mailId = self._mailList[self._mailIndex]
		local mailExpireTime = GameData.GetMailExpireTime(mailId)
		local currentTime = GameData.GetServerTime()
		if currentTime >= mailExpireTime then
			SoundSystem.PlayWarningSound()
			CtrlManager.ShowMessageBox({message = SAFE_LOC("邮件已过期"), single = true})
			return true
		end

		if not MailCtrl.CanGetReward() then
			SoundSystem.PlayWarningSound()
			CtrlManager.ShowMessageBox({message = SAFE_LOC("需要进行实名认证才能领取奖励\n请前往设置 - 实名认证"), single = true})
			return true
		end

		SoundSystem.PlayUIClickSound()
		NetManager.Send("MailReward", {MailId = mailId}, MailCtrl.OnHandleProto, self)
	elseif go == self._ui.ButtonPrevious then
		SoundSystem.PlayUIClickSound()
		self._mailIndex = self._mailIndex - 1
		self:OnMailIndexChanged()
	elseif go == self._ui.ButtonNext then
		SoundSystem.PlayUIClickSound()
		self._mailIndex = self._mailIndex + 1
		self:OnMailIndexChanged()
	elseif go == self._ui.Content.gameObject then
		local url = self._ui.Content:GetUrlAtPosition(UICamera.lastWorldPosition)
		if url ~= nil then
			SoundSystem.PlayUIClickSound()
			--UnityEngine.Application.OpenURL(url)
			WJWHelper.OpenWenJuanWangUrl(url)
		end
	end

	return true
end

function MailCtrl:OnHandleProto(proto, data, requestData)
	if proto == "MailRead" then
		local mailId = requestData.MailId
		GameData.ReadMail(mailId)
	elseif proto == "MailReward" then
		local mailId = requestData.MailId
		-- get reward
		GameData.GetRewardOfMail(mailId)
		local goldNum = data.RemainGold
		local diamondNum = data.RemainDiamond
		GameData.SetMoney(ItemType.Gold, goldNum)
		GameData.SetMoney(ItemType.Diamond, diamondNum)
		GameData.CheckAndHintGoalsOfCurrentCountType()

		if mailId == self._mailList[self._mailIndex] then
			self._ui.ButtonReward:SetActive(false)
			self._ui.RewaredMark:SetActive(true)
		end
	end
end