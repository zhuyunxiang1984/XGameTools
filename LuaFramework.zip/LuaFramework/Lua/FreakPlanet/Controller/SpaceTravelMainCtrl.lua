require "FreakPlanet/View/SpaceTravelMainPanel"

local class = require "FreakPlanet/Utils/middleclass"
SpaceTravelMainCtrl  = class(CtrlNames.SpaceTravelMain, BaseCtrl)

local DANGER_RATIO = 5

-- load the ui prefab
function SpaceTravelMainCtrl:LoadPanel()
	self:CreatePanel("SpaceTravelMain")
end

-- construct ui panel data
function SpaceTravelMainCtrl:ConstructUI(obj)
	self._ui = SpaceTravelMainPanel.Init(obj)
end

-- destroy implementation
function SpaceTravelMainCtrl:DestroyImpl()
    GameNotifier.RemoveListener(GameEvent.SpaceTravelGoodsChanged, SpaceTravelMainCtrl.OnSpaceTravelGoodsChanged, self)
    GameNotifier.RemoveListener(GameEvent.SpaceTravelFoodChanged, SpaceTravelMainCtrl.OnSpaceTravelFoodChanged, self)
    GameNotifier.RemoveListener(GameEvent.SpaceTravelFuelChanged, SpaceTravelMainCtrl.OnSpaceTravelFuelChanged, self)
    GameNotifier.RemoveListener(GameEvent.SpaceTravelScoreChanged, SpaceTravelMainCtrl.OnSpaceTravelScoreChanged, self)
    GameNotifier.RemoveListener(GameEvent.SpaceTravelCapacityChanged, SpaceTravelMainCtrl.OnSpaceTravelCapacityChanged, self)
    -- do clear
    self._diceEffectState = nil
    self._cutsceneState = nil
    if self._waitForwardResultHandle ~= nil then
        GlobalScheduler:Cancel(self._waitForwardResultHandle)
        self._waitForwardResultHandle = nil
    end
end

-- notity it has been focused
function SpaceTravelMainCtrl:NotifyFocus()
    self:CheckSeasonStatus()
    self:RefreshGoalHint()
end

-- fill ui with the data
function SpaceTravelMainCtrl:SetupUI()
    self._isDraging = false
    self._dragPosition = nil
    self._scoreHidden = false
    self._seasonId = self._parameter.season
    self._seasonData = GameData.GetSpaceTravelSeasonData(self._seasonId)
    self._diceEffectState = nil
    self._cutsceneState = nil
    self._waitForwardResultHandle = nil
    self._foodDanger = false
    self._fuelDanger = false
    ----------------------------------------------
    self._seasonEndTime = GameData.GetSpaceTravelSeasonEndTime(self._seasonId)
    self._needRefreshTime = true
    self:RefreshLeftTime()
    -- must call before construct base data, as it needs fuel cost per dice
    self:RefreshDiceFuelCost()

    self:SetDiceIcon()
    self:ConstructBaseData()
    self:ConstructGoods()
    self:ConstructRelic()
    self:SpawnShip()
    self:RefreshGoalHint()

    for k, v in pairs(self._ui.RelicItems) do
        CtrlManager.AddClick(self, v.item)
    end

    -- hide default
    self._ui.HelpPanel:SetActive(false)
    self._ui.CutscenePanel:SetActive(false)
    self._ui.DiceEffectAnimator.gameObject:SetActive(false)
    self._ui.FoodHintAnimator.gameObject:SetActive(false)
    self._ui.FuelHintAnimator.gameObject:SetActive(false)
    self._ui.ScoreHintAnimator.gameObject:SetActive(false)
    self._ui.CapacityHintAnimator.gameObject:SetActive(false)
    self._ui.SelectionPanel:SetActive(false)
	
    CtrlManager.AddClick(self, self._ui.ButtonQuit)
    CtrlManager.AddClick(self, self._ui.ButtonGiveUp)
    CtrlManager.AddClick(self, self._ui.ButtonHelp)
    CtrlManager.AddClick(self, self._ui.ButtonDice)
    CtrlManager.AddClick(self, self._ui.ButtonLab)
    CtrlManager.AddClick(self, self._ui.ButtonGoal)
    CtrlManager.AddClick(self, self._ui.ButtonSelectionLeft)
    CtrlManager.AddClick(self, self._ui.ButtonSelectionRight)
    CtrlManager.AddClick(self, self._ui.HelpBlocker)
    CtrlManager.AddPress(self, self._ui.Blocker)
    CtrlManager.AddPress(self, self._ui.SelectionBlocker)
    
    GameNotifier.AddListener(GameEvent.SpaceTravelGoodsChanged, SpaceTravelMainCtrl.OnSpaceTravelGoodsChanged, self)
    GameNotifier.AddListener(GameEvent.SpaceTravelFoodChanged, SpaceTravelMainCtrl.OnSpaceTravelFoodChanged, self)
    GameNotifier.AddListener(GameEvent.SpaceTravelFuelChanged, SpaceTravelMainCtrl.OnSpaceTravelFuelChanged, self)
    GameNotifier.AddListener(GameEvent.SpaceTravelScoreChanged, SpaceTravelMainCtrl.OnSpaceTravelScoreChanged, self)
    GameNotifier.AddListener(GameEvent.SpaceTravelCapacityChanged, SpaceTravelMainCtrl.OnSpaceTravelCapacityChanged, self)
end

function SpaceTravelMainCtrl:StartCheck(host)
    assert(self._ui ~= nil, "make sure space travel main panel is ok")
    self._host = host
    self:CheckSeasonStatus()
end

function SpaceTravelMainCtrl:SetStatusText(msg)
    self._ui.StatusLabel.text = msg
end

function SpaceTravelMainCtrl:HideScore()
    self._ui.ScoreNum.text = ""
    self._scoreHidden = true
end

function SpaceTravelMainCtrl:CheckSeasonStatus()
    local isValid = CtrlManager.CheckSpaceTravelSeasonValid(self._seasonId, true, true)
    if not isValid then
        self:SetStatusText("星际航行结束")
        return
    end

    local isOver = (self._seasonData.food <= 0 or self._seasonData.fuel <= 0 or self._seasonData.status == 1)
    if not isOver then
        local nodeStatus = self._seasonData.nodeStatus
        if nodeStatus == SpaceTravelNodeStatus.Completed then
            local nodeId = self._seasonData.node
            local worldIndex = self._seasonData.world
            local worldId = GameData.GetWorldOfSpaceTravelSeason(self._seasonId, worldIndex)
            local worlCount = GameData.GetSpaceTravelSeasonWorldCount(self._seasonId)
            local isLastWorld = (worldIndex >= worlCount)
            local isLastNode = ConfigUtils.IsLastNodeOfSpaceTravelWorld(worldId, nodeId)
            if isLastNode then
                if isLastWorld then
                    isOver = true
                else
                    self:GoToNextWorld()
                end
            end
        end
    end

    if isOver then
        CtrlManager.OpenPanel(CtrlNames.SpaceTravelResult, {seasonId = self._seasonId})
        self:SetStatusText("星际航行结束")
        self:HideScore()
    else
        self:CheckDiceStatus()
    end
end

function SpaceTravelMainCtrl:CheckDiceStatus()
    local nodeStatus = self._seasonData.nodeStatus
    if nodeStatus == SpaceTravelNodeStatus.Move then
        local forwardStep = self._seasonData.forwardStep
        self._host:MoveStep(forwardStep, self)
    elseif nodeStatus == SpaceTravelNodeStatus.SelectChoice then
        CtrlManager.OpenPanel(CtrlNames.SpaceTravelChoice, {seasonId = self._seasonId})
    elseif nodeStatus == SpaceTravelNodeStatus.FinishChoice then
        local choiceId = self._seasonData.choiceList[self._seasonData.choiceIdx]
        local choiceType = ConfigUtils.GetSpaceTravelChoiceType(choiceId)
        if choiceType == SpaceTravelChoiceType.Deal then
            local dealId = ConfigUtils.GetSpaceTravelChoiceDeal(choiceId)
            CtrlManager.OpenPanel(CtrlNames.SpaceTravelDeal, {seasonId = self._seasonId, dealId = dealId, choiceId = choiceId})
        elseif choiceType == SpaceTravelChoiceType.Discovery then
            local discoveryId = ConfigUtils.GetSpaceTravelChoiceDiscovery(choiceId)
            CtrlManager.OpenPanel(CtrlNames.SpaceTravelDiscovery, {seasonId = self._seasonId, discoveryId = discoveryId, choiceId = choiceId})
        elseif choiceType == SpaceTravelChoiceType.Chat then
            local chatId = ConfigUtils.GetSpaceTravelChoiceChat(choiceId)
            CtrlManager.OpenPanel(CtrlNames.SpaceTravelChatCharacter, {seasonId = self._seasonId, chatId = chatId, choiceId = choiceId})
        elseif choiceType == SpaceTravelChoiceType.Challenge then
            local challengeId = ConfigUtils.GetSpaceTravelChoiceChallenge(choiceId)
            CtrlManager.OpenPanel(CtrlNames.ExploreCharacter, {
                challengeId = challengeId,
                choiceId = choiceId,
                seasonId = self._seasonId,
            })
        end
    end

    if nodeStatus == SpaceTravelNodeStatus.Idle or nodeStatus == SpaceTravelNodeStatus.Completed then
        self:SetStatusText("投骰子")
    elseif nodeStatus == SpaceTravelNodeStatus.FinishChoice then
        self:SetStatusText("完成选项")
    end
end

function SpaceTravelMainCtrl:SpawnShip()
    local num = self._ui.CutsceneShipRoot.childCount
    if num > 0 then
        return
    end

    local seasonData = GameData.GetSpaceTravelSeasonData(self._seasonId)
    local prefabName, prefabBundle = ConfigUtils.GetSpaceShipPrefab(seasonData.ship)
    local shipPrefab = self:DynamicLoadAsset(prefabBundle, prefabName)
    local shipObj = Helper.NewObject(shipPrefab, self._ui.CutsceneShipRoot, 50)
    shipObj:SetActive(true)
    shipObj.name = prefabName
end

function SpaceTravelMainCtrl:ConstructBaseData()
    self:ConstructFood()
    self:ConstructFuel()
    self:ConstructScore()
    self:ConstructCapacity()
end

function SpaceTravelMainCtrl:ConstructFood()
    local curFood = self._seasonData.food
    local maxFood = self._seasonData.foodMax

    local foodPercent = curFood / maxFood
    self._ui.FoodNum.text = tostring(curFood).."/"..tostring(maxFood)
    self._ui.FoodProgress.fillAmount = foodPercent
    self._foodDanger = (curFood <= DANGER_RATIO * self._fuelCostPerDice)
    self._ui.FoodDangerMask:SetActive(self._foodDanger)
    self._ui.DangerHint:SetActive(self._foodDanger or self._fuelDanger)
end

function SpaceTravelMainCtrl:ConstructFuel()
    local curFuel = self._seasonData.fuel
    local maxFuel = self._seasonData.fuelMax

    local fuelPercent = curFuel / maxFuel
    self._ui.FuelNum.text = tostring(curFuel).."/"..tostring(maxFuel)
    self._ui.FuelProgress.fillAmount = fuelPercent
    self._fuelDanger = (curFuel <= DANGER_RATIO * self._fuelCostPerDice)
    self._ui.FuelDangerMask:SetActive(self._fuelDanger)
    self._ui.DangerHint:SetActive(self._foodDanger or self._fuelDanger)
end

function SpaceTravelMainCtrl:ConstructScore()
    local curScore = self._seasonData.score
    self._ui.ScoreNum.text = tostring(curScore)
end

function SpaceTravelMainCtrl:ConstructCapacity()
    local curCapacity = self._seasonData.capacity
    local maxCapacity = self._seasonData.capacityMax
    self._ui.CapacityNum.text = tostring(curCapacity).."/"..tostring(maxCapacity)
    if curCapacity >= maxCapacity then
        self._ui.CapacityNum.color = Color.red
    else
        self._ui.CapacityNum.color = Color.white
    end
end

function SpaceTravelMainCtrl:ConstructGoods()
    local curNum = self._ui.GoodsGrid.childCount
    for idx = curNum + 1, self._seasonData.goodsMax do
        local goodsObj = Helper.NewObject(self._ui.GoodsItemTemplate, self._ui.GoodsGrid)
        goodsObj:SetActive(true)
        goodsObj.name = tostring(idx)
        CtrlManager.AddClick(self, goodsObj)
    end

    for idx = 1, self._seasonData.goodsMax do
        local item = self._ui.GoodsGrid:GetChild(idx - 1)
        self:ConstructGoodsItem(item, idx)
    end

    self._ui.GoodsGrid:GetComponent("UIGrid"):Reposition()
end

function SpaceTravelMainCtrl:ConstructGoodsItem(item, slot)
    local goodsList = self._seasonData.goods
    local hasGoods = (slot <= #goodsList)
    local root = item:Find("Root").gameObject
    root:SetActive(hasGoods)
    if hasGoods then
        local goodsId = goodsList[slot].id
        local goodsNum = goodsList[slot].num

        local icon = item:Find("Root/Icon"):GetComponent("UISprite")
        local numLabel = item:Find("Root/Num"):GetComponent("UILabel")

        UIHelper.SetItemIcon(self,icon, goodsId)
        numLabel.text = "x"..tostring(goodsNum)
    end
end

function SpaceTravelMainCtrl:ConstructRelic()
    local relicList = self._seasonData.relic
    for idx = 1, #self._ui.RelicItems do
        local hasRelicSlot = (idx <= self._seasonData.relicMax)
        self._ui.RelicItems[idx].item:SetActive(hasRelicSlot)
        if hasRelicSlot then
            local hasRelicItem = (idx <= #relicList)
            self._ui.RelicItems[idx].icon.gameObject:SetActive(hasRelicItem)
            if hasRelicItem then
                UIHelper.SetItemIcon(self,self._ui.RelicItems[idx].icon, relicList[idx])
            end
        end
    end
end

-- update implementation
function SpaceTravelMainCtrl:UpdateImpl(deltaTime)
    if self._isDraging then
        local newPosition = self:ScreenToWorld(Input.mousePosition)
        local diff = newPosition - self._mouseWorldPosition
        GameNotifier.Notify(GameEvent.MoveSpaceTravelCamera, diff * 10)
        self._mouseWorldPosition = newPosition
    end

    if self._diceEffectState ~= nil then
        local finished = self._diceEffectState:Tick(deltaTime)
        if finished then
            self._diceEffectState = nil
        end
    end

    if self._cutsceneState ~= nil then
        local finished = self._cutsceneState:Tick(deltaTime)
        if finished then
            self._cutsceneState = nil
        end
    end
    -- left time
    self:RefreshLeftTime()
end

function SpaceTravelMainCtrl:SetDiceIcon()
    local step = self._seasonData.forwardStep
    if step == nil or step == 0 then
        step = 6
    end

    self._ui.DiceIcon.spriteName = "Dice"..tostring(step)
end

function SpaceTravelMainCtrl:GoToNextWorld()
    GameData.SwitchWorld(self._seasonId)
    self._host:SwitchWorld(self._seasonId)
    -- in case it is open
    self._ui.HelpPanel:SetActive(false)
    self._cutsceneState = AnimatorState:new(self._ui.CutsceneAnimator, "Cutscene", nil, self._ui.CutscenePanel)
    self._cutsceneState:ActionOnExit(SpaceTravelMainCtrl.OnCutsceneFinished, self)
    self:RefreshDiceFuelCost()
    -- as fuel cost per dice changed, the danger state maybe changed
    self:ConstructFood()
    self:ConstructFuel()
end

function SpaceTravelMainCtrl:OnDiceEffectFinished(forwardStep)
    self:SetDiceIcon()
    self._ui.DiceEffectAnimator.gameObject:SetActive(false)
    -- check valid first
    local isValid = CtrlManager.CheckSpaceTravelSeasonValid(self._seasonId, true, true)
    if not isValid then
        return
    end
    -- check next action
    self:CheckDiceStatus()
    -- goal
    local goalData = GameData.SetupItemGoalData(ItemType.DicePoint, 1, forwardStep)
    GameData.DoSpaceTravelGoalSettle(self._seasonId, TriggerType.UseDice, {goalData})
    -- ui
    self:RefreshGoalHint()
end

function SpaceTravelMainCtrl:OnCutsceneFinished()
    self._ui.CutscenePanel:SetActive(false)
end

-- handle the escapse button
function SpaceTravelMainCtrl:HandleEscape()
    if self._ui.HelpPanel.activeSelf then
        self:OnClicked(self._ui.HelpBlocker)
    else
        self:OnClicked(self._ui.ButtonQuit)
    end
end

function SpaceTravelMainCtrl:OnSpaceTravelGoodsChanged(goodsId)
    -- all changed: goods and relic
    if goodsId == nil then
        self:ConstructRelic()
        self:ConstructGoods()
        return
    end

    local subType = ConfigUtils.GetSpaceTravelGoodsSubType(goodsId)
    if subType == SpaceTravelGoodsSubType.Relic then
        self:ConstructRelic()
    else
        for idx = 1, self._seasonData.goodsMax do
            local goodsItem = self._ui.GoodsGrid:GetChild(idx - 1)
            self:ConstructGoodsItem(goodsItem, idx)
        end
    end
end

function SpaceTravelMainCtrl:OnSpaceTravelFoodChanged(changeValue, isMax)
    self:ConstructFood()
    if changeValue ~= 0 then
        self:HintChangeNum(self._ui.FoodHintAnimator, self._ui.FoodHintLabel, changeValue, isMax)
    end
end

function SpaceTravelMainCtrl:OnSpaceTravelFuelChanged(changeValue, isMax)
    self:ConstructFuel()
    if changeValue ~= 0 then
        self:HintChangeNum(self._ui.FuelHintAnimator, self._ui.FuelHintLabel, changeValue, isMax)
    end
end

function SpaceTravelMainCtrl:OnSpaceTravelScoreChanged(changeValue)
    if self._scoreHidden then
        return
    end

    self:ConstructScore()
    if changeValue ~= 0 then
        self:HintChangeNum(self._ui.ScoreHintAnimator, self._ui.ScoreHintLabel, changeValue, false)
    end
end

function SpaceTravelMainCtrl:OnSpaceTravelCapacityChanged(changeValue, isMax)
    self:ConstructCapacity()
    if changeValue ~= 0 then
        self:HintChangeNum(self._ui.CapacityHintAnimator, self._ui.CapacityHintLabel, changeValue, isMax)
    end
end

function SpaceTravelMainCtrl:HintChangeNum(animator, label, changeValue, isMax)
    if not animator.gameObject.activeSelf then
        animator.gameObject:SetActive(true)
    end

    local prefix = ""
    if isMax then
        prefix = "上限 "
    end
    if changeValue > 0 then
        label.text = prefix.."+"..tostring(changeValue)
    else
        label.text = prefix..tostring(changeValue)
    end

    animator:Play("ItemHint", 0, 0)
end

function SpaceTravelMainCtrl:RefreshDiceFuelCost()
    local seasonData = GameData.GetSpaceTravelSeasonData(self._seasonId)
    local worldId = GameData.GetWorldOfSpaceTravelSeason(self._seasonId, seasonData.world)
    local shipId = seasonData.ship

    local fuelCostPerRound = ConfigUtils.GetSpaceTravelWorldFuelCostPerRound(worldId)
    local shipPercent = ConfigUtils.GetSpaceShipFuleCostPercentPerRound(shipId)

    local finalFuelCost = math.floor(fuelCostPerRound * shipPercent / 100)
    self._ui.DiceFuelCost.text = "-"..tostring(finalFuelCost)
    self._fuelCostPerDice = finalFuelCost
end

function SpaceTravelMainCtrl:RefreshLeftTime()
    if not self._needRefreshTime then
        return
    end

    local curTime = GameData.GetServerTime()
    local leftTime = math.max(0, self._seasonEndTime - curTime)
    if leftTime > 0 then
        self._ui.LeftTime.text = SAFE_LOC("距离结束：")..Helper.GetLongTimeString(leftTime)
    else
        self._ui.LeftTime.text = SAFE_LOC("已结束")
    end
    self._needRefreshTime = (leftTime > 0)
end
--------------------------------------------------------------------------------
function SpaceTravelMainCtrl:ChooseLeftOrRightNode(screenPos)
    -- in case it is open
    self._ui.HelpPanel:SetActive(false)
    self._ui.SelectionPanel:SetActive(true)
    self:SyncSelectionRootPosition(screenPos)
end

function SpaceTravelMainCtrl:SyncSelectionRootPosition(screenPos)
    if not self._ui.SelectionPanel.activeSelf then
        return
    end

    local newPos = self:ScreenToWorld(screenPos)
    local pos = self._ui.SelectionRoot.position
    pos.x = newPos.x
    pos.y = newPos.y
    self._ui.SelectionRoot.position = pos
end

function SpaceTravelMainCtrl:OnNodeMoveFinished(movedNodeList)
    -- check valid first
    local isValid = CtrlManager.CheckSpaceTravelSeasonValid(self._seasonId, true, true)
    if not isValid then
        return
    end
    -- do forward
    local seasonData = GameData.GetSpaceTravelSeasonData(self._seasonId)
    local scoreCapId = GameData.GetScoreCapOfSpaceTravelSeason(self._seasonId, seasonData.scoreCap)
    NetManager.Send("STForward", {
        STSeasonID = self._seasonId, 
        STScoreCapID = scoreCapId,
        NodeList = movedNodeList,
    }, SpaceTravelMainCtrl.OnHandleProto, self)
end

function SpaceTravelMainCtrl:OnMoveProgressChanged(leftStep)
    if leftStep > 0 then
        self:SetStatusText("飞船移动中\n剩余："..tostring(leftStep))
    else
        self:SetStatusText("飞船移动结束")
    end
end

function SpaceTravelMainCtrl:CanDoAction()
    local nodeStatus = GameData.GetNodeStatusOfSpaceTravelSeason(self._seasonId)
    return nodeStatus == SpaceTravelNodeStatus.Idle or nodeStatus == SpaceTravelNodeStatus.Completed
end

function SpaceTravelMainCtrl:RefreshGoalHint()
    local showHint = GameData.HasCompletedSpaceTravelGoal(self._seasonId) or GameData.HasNewSpaceTravelGoal()
    self._ui.GoalHint:SetActive(showHint)
end

function SpaceTravelMainCtrl:OnGiveUpConfirmed()
    local isValid = CtrlManager.CheckSpaceTravelSeasonValid(self._seasonId, true, true)
    if not isValid then
        return
    end

    self:HideScore()
    CtrlManager.OpenPanel(CtrlNames.SpaceTravelResult, {seasonId = self._seasonId})
end
--------------------------------------------------------------------------------
-- on clicked
function SpaceTravelMainCtrl:OnClicked(go)
    if self._diceEffectState ~= nil or self._cutsceneState ~= nil or self._waitForwardResultHandle ~= nil then
        return
    end

    if go == self._ui.ButtonQuit then
        if not self:CanDoAction() then
            SoundSystem.PlayWarningSound()
            return true
        end
        
        SoundSystem.PlayUICancelSound()
        -- space travel main panel
        CtrlManager.PopPanel()
        -- space travel panel
        CtrlManager.PopPanel()
    elseif go == self._ui.ButtonHelp then
        if not self:CanDoAction() then
            SoundSystem.PlayWarningSound()
            return true
        end
        
        SoundSystem.PlayUIClickSound()
        self._ui.HelpPanel:SetActive(true)
    elseif go == self._ui.HelpBlocker then
        SoundSystem.PlayUIClickSound()
        self._ui.HelpPanel:SetActive(false)
    elseif go == self._ui.ButtonGiveUp then
        local isValid = CtrlManager.CheckSpaceTravelSeasonValid(self._seasonId, true)
        if not isValid then
            return true
        end

        if not self:CanDoAction() then
            SoundSystem.PlayWarningSound()
            return true
        end

        SoundSystem.PlayUIClickSound()
        CtrlManager.ShowMessageBox({message = SAFE_LOC("确认放弃本次航行？"), single = false, onConfirm = SpaceTravelMainCtrl.OnGiveUpConfirmed, receiver = self})  
    elseif go == self._ui.ButtonDice then
        local isValid = CtrlManager.CheckSpaceTravelSeasonValid(self._seasonId, true)
        if not isValid then
            return true
        end

        if not self:CanDoAction() then
            SoundSystem.PlayWarningSound()
            return true
        end

        SoundSystem.PlayUIClickSound()
        local seasonData = GameData.GetSpaceTravelSeasonData(self._seasonId)
        local scoreCapId = GameData.GetScoreCapOfSpaceTravelSeason(self._seasonId, seasonData.scoreCap)
        NetManager.Send('STUseDice', {
            STSeasonID = self._seasonId, 
            STScoreCapID = scoreCapId, 
            UseItem = 0,
        }, SpaceTravelMainCtrl.OnHandleProto, self)
    elseif go == self._ui.ButtonLab then
        if not self:CanDoAction() then
            SoundSystem.PlayWarningSound()
            return true
        end

        SoundSystem.PlayUIClickSound()
        CtrlManager.OpenPanel(CtrlNames.SpaceTravelLaboratory, {seasonId = self._seasonId})
    elseif go == self._ui.ButtonGoal then
        if not self:CanDoAction() then
            SoundSystem.PlayWarningSound()
            return true
        end

        SoundSystem.PlayUIClickSound()
        CtrlManager.OpenPanel(CtrlNames.SpaceTravelGoal, {seasonId = self._seasonId})
    elseif go.transform.parent == self._ui.GoodsGrid then
        local slot = tonumber(go.name)
        local goodsList = self._seasonData.goods
        local hasGoods = (slot <= #goodsList)

        if not hasGoods then
            return true
        end

        if not self:CanDoAction() then
            SoundSystem.PlayWarningSound()
            return true
        end

        SoundSystem.PlayUIClickSound()
        local goodsId = goodsList[slot].id
        CtrlManager.OpenPanel(CtrlNames.SpaceTravelGoodsAction, {seasonId = self._seasonId, goodsId = goodsId})
    elseif go.transform.parent == self._ui.RelicRoot then
        SoundSystem.PlayUIClickSound()
        local names = Helper.StringSplit(go.name)
        assert(#names == 2, "invalid relic item name: "..tostring(go.name))
        local slot = tonumber(names[2])
        local relicList = self._seasonData.relic
        local hasRelic = (slot <= #relicList)
        if not hasRelic then
            return true
        end

        if not self:CanDoAction() then
            SoundSystem.PlayWarningSound()
            return true
        end

        SoundSystem.PlayUIClickSound()
        local goodsId = relicList[slot]
        CtrlManager.OpenPanel(CtrlNames.SpaceTravelGoodsAction, {seasonId = self._seasonId, goodsId = goodsId})
    elseif go == self._ui.ButtonSelectionLeft then
        SoundSystem.PlayUIClickSound()
        self._ui.SelectionPanel:SetActive(false)
        self._host:OnBranchNodeChoosen(true)
    elseif go == self._ui.ButtonSelectionRight then
        SoundSystem.PlayUIClickSound()
        self._ui.SelectionPanel:SetActive(false)
        self._host:OnBranchNodeChoosen(false)
    end

	return true
end

function SpaceTravelMainCtrl:CanDrag()
    if self._ui.SelectionPanel.activeSelf then
        return true
    end

    local nodeStatus = self._seasonData.nodeStatus
    if nodeStatus == SpaceTravelNodeStatus.Idle or nodeStatus == SpaceTravelNodeStatus.Completed then
        return true
    end

    return false
end

function SpaceTravelMainCtrl:OnPressed(go, pressed, isLong)
    if self._diceEffectState ~= nil or self._cutsceneState ~= nil or self._waitForwardResultHandle ~= nil or not self:CanDrag() then
        return
    end

    if pressed then
        self._isDraging = true
        self._mouseWorldPosition = self:ScreenToWorld(Input.mousePosition)
    elseif not pressed and self._isDraging then
        self._isDraging = false
    end
end

function SpaceTravelMainCtrl:OnForwardResultFinished()
    self._waitForwardResultHandle = nil
    -- check valid first
    local isValid = CtrlManager.CheckSpaceTravelSeasonValid(self._seasonId, true)
    if not isValid then
        return
    end
    self:CheckDiceStatus()
end

function SpaceTravelMainCtrl:OnHandleProto(proto, data, requestData)
    if proto == 'STUseDice' then
        local seasonId = requestData.STSeasonID
        local forwardStep = data.ForwardStep
        GameData.SetDiceResultForSpaceTravelSeason(seasonId, forwardStep)
        GameData.SyncSpaceTravelSeasonBaseData(seasonId, data)
        self._diceEffectState = AnimatorState:new(self._ui.DiceEffectAnimator, "DiceEffect", nil, self._ui.DiceEffectAnimator.gameObject)
        self._diceEffectState:ActionOnExit(SpaceTravelMainCtrl.OnDiceEffectFinished, self, forwardStep)
    elseif proto == 'STForward' then
        local seasonId = requestData.STSeasonID
        local movedNodeList = requestData.NodeList
        local choiceEvent = data.EventID
        local choiceList = data.ChoiceList or {}
        -- steped
        GameData.StepNodeForSpaceTravelSeason(seasonId, movedNodeList[#movedNodeList], choiceEvent, choiceList)
        GameData.SyncSpaceTravelSeasonBaseData(seasonId, data)
        -- goal
        local goalData = GameData.SetupItemGoalData(ItemType.Node, #movedNodeList)
        GameData.DoSpaceTravelGoalSettle(seasonId, TriggerType.Forward, {goalData})
        -- delay to show choice selection panel
        self._waitForwardResultHandle = GlobalScheduler:DoActionAfterTime(1, SpaceTravelMainCtrl.OnForwardResultFinished, self)
    end
end