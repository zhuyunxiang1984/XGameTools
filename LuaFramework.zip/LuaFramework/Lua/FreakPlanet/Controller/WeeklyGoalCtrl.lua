require "FreakPlanet/View/WeeklyGoalPanel"

local class = require "FreakPlanet/Utils/middleclass"
WeeklyGoalCtrl = class(CtrlNames.WeeklyGoal, BaseCtrl)

local function GoalSortFunc(idA, idB)
    if idA == nil or idB == nil then
        return false
    end

    local bIsUnlockA = GameData.IsUnlockAllPreGoal(idA)
    local bIsUnlockB = GameData.IsUnlockAllPreGoal(idB)

    if bIsUnlockA ~= bIsUnlockB then
        return bIsUnlockA
    end

    local getAwardA = GameData.IsWeekGoalGetReward(idA)
    local getAwardB = GameData.IsWeekGoalGetReward(idB)

    if getAwardA ~= getAwardB then
        return getAwardB
    end

    local stateA = GameData.GetGoalInfo(idA)
    local stateB = GameData.GetGoalInfo(idB)

    local valueA = (stateA == GoalState.Complete)
    local valueB = (stateB == GoalState.Complete)
    if valueA ~= valueB then
        return valueA
    end

    return idA < idB
end

function WeeklyGoalCtrl:LoadPanel()
    self:CreatePanel("WeeklyGoal")
end

-- construct ui panel data
function WeeklyGoalCtrl:ConstructUI(obj)
    self._ui = WeeklyGoalPanel.Init(obj)
end

-- fill ui with the data
function WeeklyGoalCtrl:SetupUI()
    local ui = self._ui
    self._WeeklyGoalList = nil
    self._MoneyBoxRewardList = nil

    CtrlManager.AddClick(self, ui.Blocker)
    CtrlManager.AddClick(self, ui.pBtnReturn)
    CtrlManager.AddClick(self, ui.pBtnHelp)
    CtrlManager.AddClick(self, ui.pBtnMonthCardBuy)
    CtrlManager.AddClick(self, ui.pObjGetReward)
    CtrlManager.AddClick(self, ui.pObjHelpBlocker)

    GameNotifier.AddListener(GameEvent.GoalChanged, WeeklyGoalCtrl.OnGoalChanged, self)

    self:EnableSecondUpdate()
    self:UpdateGoalsUI()
    self:SetupPiggyBankUI()
end

function WeeklyGoalCtrl:DestroyImpl()
    GameNotifier.RemoveListener(GameEvent.GoalChanged, WeeklyGoalCtrl.OnGoalChanged, self)
end

function WeeklyGoalCtrl:SetupGoalUI()
    self._WeeklyGoalList = GameData.GetActiveGoalsOfType(GoalType.Weekly)
    table.sort(self._WeeklyGoalList, GoalSortFunc)

    local iChildCount = self._ui.pUIGridGoal.transform.childCount

    for idx = iChildCount, 1, -1 do
        local pObj = self._ui.pUIGridGoal.transform:GetChild(idx - 1).gameObject
        pObj:SetActive(false)
        self._ui.ObjPool:RecycleObj(pObj)
    end

    for idx = 1, #self._WeeklyGoalList do
        local iGoalId = self._WeeklyGoalList[idx]
        local bIsUnlock, iPreGoalId = GameData.IsUnlockAllPreGoal(iGoalId)
        local pObjGoalItem = nil
        if bIsUnlock then
             pObjGoalItem = self._ui.ObjPool:GetOrCreateObj(self._ui.EnumPrefabType.GoalItem, function(pObj)
                local pBtnGetAward = pObj.transform:Find("btn/GetAward").gameObject
                local pBtnGoto = pObj.transform:Find("btn/Goto").gameObject
                CtrlManager.AddClick(self, pBtnGetAward)
                CtrlManager.AddClick(self, pBtnGoto)
            end)

            self:ConstructGoalItemUI(pObjGoalItem, iGoalId)
        else
            pObjGoalItem = self._ui.ObjPool:GetOrCreateObj(self._ui.EnumPrefabType.LockGoalItem)
            local pTxtDec = pObjGoalItem.transform:Find("desc"):GetComponent("UILabel")
            pTxtDec.text = string.format("完成【%s】后解锁!", ConfigUtils.GetGoalName(iPreGoalId))
        end
        pObjGoalItem.transform:SetParent(self._ui.pUIGridGoal.transform)
        pObjGoalItem:SetActive(true)
        pObjGoalItem.transform.localScale = Vector3.one
        pObjGoalItem.name = tostring(iGoalId)
    end

    self._ui.pUIGridGoal:Reposition()
    self._ui.pScrollViewGoal:ResetPosition()
end

function WeeklyGoalCtrl:UpdateGoalsUI()
    self._ThisWeekEndTime = self:GetThisWeekEndTime()
    self:UpdateLeftThisWeekEndTime()
    NetManager.Send("GoalList", {GoalType = GoalType.Weekly}, WeeklyGoalCtrl.OnHandleProto, self)
end

function WeeklyGoalCtrl:SetupPiggyBankUI()
    self._MoneyBoxRewardList = GameData.GetActiveWeeklyMoneyBoxReward()
    local bIsValid = GameData.IsValidPeriodOfMonthCard2()
    if bIsValid then
        local bCanGetReward = self._MoneyBoxRewardList and #self._MoneyBoxRewardList > 0
        self._ui.pBtnMonthCardBuy:SetActive(false)
        self._ui.pObjGetReward:SetActive(bCanGetReward)
        self._ui.pObjYetReward:SetActive(not bCanGetReward)
    else
        self._ui.pBtnMonthCardBuy:SetActive(true)
        self._ui.pObjGetReward:SetActive(false)
        self._ui.pObjGetReward:SetActive(false)
    end

    local rewardData = WeeklyGoal.ExtraReward
    for idx = 1, #self._ui.PiggyReward do
        local pSpriteIcons = self._ui.PiggyReward[idx].icons
        local pTxtNum = self._ui.PiggyReward[idx].num

        local itemId = rewardData[idx].Id
        local iMaxNum = rewardData[idx].Max

        local iNum = self:GetMoneyBoxRewardNum(self._MoneyBoxRewardList, itemId)
        iNum = math.Clamp(iNum, 0, iMaxNum)
        UIHelper.SetItemIcon(self, pSpriteIcons, itemId)
        pTxtNum.text = string.format("%d/%d", iNum, iMaxNum)
    end
end

function WeeklyGoalCtrl:GetMoneyBoxRewardNum(moneyBoxRewardList, itemId)
    moneyBoxRewardList = moneyBoxRewardList or {}
    for idx = 1, #moneyBoxRewardList do
        if moneyBoxRewardList[idx].Id == itemId then
            return moneyBoxRewardList[idx].Num
        end
    end
    return 0
end

function WeeklyGoalCtrl:ConstructGoalItemUI(item, goalId)
    local pSpriteIcon = item.transform:Find("IconBg/icon"):GetComponent("UISprite")
    local pTxtTitle = item.transform:Find("title"):GetComponent("UILabel")
    local pTxtDesc = item.transform:Find("desc"):GetComponent("UILabel")
    local pTxtNum = item.transform:Find("num"):GetComponent("UILabel")
    local pUIGridRewardRoot = item.transform:Find("RewardRoot"):GetComponent("UIGrid")
    local pBtnGetReward = item.transform:Find("btn/GetAward").gameObject
    local pBtnGoto = item.transform:Find("btn/Goto").gameObject
    local pBtnYetReward = item.transform:Find("btn/YetRewad").gameObject

    pTxtTitle.text = ConfigUtils.GetGoalName(goalId)
    pSpriteIcon.spriteName = ConfigUtils.GetWeeklyGoalIcon(goalId)

    local condition = ConfigUtils.GetGoalConditions(goalId)
    assert(#condition == 1, "goal should only have one condition: "..tostring(goalId))
    local triggers = ConfigUtils.GetGoalTriggers(goalId)
    assert(#triggers == 1, "goal should only have one condition: "..tostring(goalId))

    pTxtDesc.text = UIHelper.GetGoalFinalName(condition[1])

    local goalState, goalNum = GameData.GetGoalInfo(goalId)
    local getAwardState = GameData.IsWeekGoalGetReward(goalId)

    pBtnGoto:SetActive(goalState == GoalState.Running)
    pBtnGetReward:SetActive(goalState == GoalState.Complete and not getAwardState)
    pBtnYetReward:SetActive(goalState == GoalState.Complete and getAwardState)

    pTxtNum.text = UIHelper.GetGoalShowNum(condition[1], goalNum[1], triggers)

    local rewards = ConfigUtils.GetGoalActualRewards(goalId)
    local iRewardChildCount = pUIGridRewardRoot.transform.childCount

    for idx = iRewardChildCount, 1, -1 do
        local pObj = pUIGridRewardRoot.transform:GetChild(idx - 1).gameObject
        pObj:SetActive(false)
        self._ui.ObjPool:RecycleObj(pObj)
    end

    for idx = 1, #rewards do
        local pObjRewardItem = self._ui.ObjPool:GetOrCreateObj(self._ui.EnumPrefabType.RewardItem)
        pObjRewardItem.transform:SetParent(pUIGridRewardRoot.transform)
        pObjRewardItem:SetActive(true)
        pObjRewardItem.name = tostring(rewards[idx].Value)
        pObjRewardItem.transform.localScale = Vector3.one
        UIHelper.ConstructItemIconAndNum(self, pObjRewardItem.transform, rewards[idx].Value, rewards[idx].Num)
    end
    pUIGridRewardRoot:Reposition()
end

-- on clicked
function WeeklyGoalCtrl:OnClicked(go)
    local ui = self._ui
    if go == ui.Blocker or go == ui.pBtnReturn then
        SoundSystem.PlayUICancelSound()
        CtrlManager.PopPanel()
    elseif go == ui.pBtnHelp then
        ui.pObjHelpPanel:SetActive(true)
    elseif go == ui.pBtnMonthCardBuy then
        CtrlManager.OpenPanel(CtrlNames.Mall, {MallModule = EMallModuleNames.MonthCardGift})
    elseif go == ui.pObjGetReward then
        --CtrlManager.OpenPanel(CtrlNames.Mall, {MallModule = EMallModuleNames.MonthCardGift})
        if not Helper.IsEmpty(self._MoneyBoxRewardList) then
            NetManager.Send("MoneyBoxReward", {}, WeeklyGoalCtrl.OnHandleProto, self)
        end
    elseif go == ui.pObjHelpBlocker then
        ui.pObjHelpPanel:SetActive(false)
    elseif go.transform.parent.parent.parent == ui.pUIGridGoal.transform then
        SoundSystem.PlayUIClickSound()
        local pTransRoot = go.transform.parent.parent
        local iGoalId = tonumber(pTransRoot.name)
        local goalState = GameData.GetGoalInfo(iGoalId)
        local goalType = ConfigUtils.GetGoalType(iGoalId)
        if go.name == "Goto" then
            assert(goalState == GoalState.Running, "state of goal "..tostring(iGoalId).." is: "..tostring(goalState))
        else
            assert(goalState == GoalState.Complete, "state of goal "..tostring(iGoalId).." is: "..tostring(goalState))
            NetManager.Send("GetGoalReward", {GoalId = iGoalId, GoalType = goalType}, WeeklyGoalCtrl.OnHandleProto, self)
        end
    end
    return true
end

function WeeklyGoalCtrl:OnHandleProto(proto, data, requestData)
    if proto == "GetGoalReward" then
        local iGoalId = requestData.GoalId
        GameData.FinishGoal(iGoalId)
        NavigationCtrl.EnableSuspend(true)
        local goldNum = data.RemainGold
        local diamondNum = data.RemainDiamond
        GameData.SetMoney(ItemType.Gold, goldNum)
        GameData.SetMoney(ItemType.Diamond, diamondNum)
        local moneyBoxInfo = data.MoneyBoxInfo
        GameData.SetWeeklyMoneyBoxReward(moneyBoxInfo)
        self:SetupPiggyBankUI()
        GameData.CheckAndHintGoalsOfCurrentCountType()
    elseif proto == "GoalList" then
        local requestGoalType = requestData.GoalType
        GameData.RemoveGoalsOfType(requestGoalType)
        local goalList = data.WeeklyGoalList or {}
        GameData.AddGoals(goalList)
        self:SetupGoalUI()
    elseif proto == "MoneyBoxReward" then
        local rewardList = data.RewardList
        GameData.SetWeeklyMoneyBoxReward(rewardList)

        for idx = 1, #rewardList do
            local itemId = rewardList[idx][1]
            local itemNum = rewardList[idx][2]
            GameData.CollectItem(itemId, itemNum, true)
        end
        self:SetupPiggyBankUI()
    end
end

--- 获取当前一周的最后一天的结束时间
function WeeklyGoalCtrl:GetThisWeekEndTime()
    local endTime = nil
    local curTime = GameData.GetServerTime()
    local timeTable = Helper.FormatTimeStamp2Date(curTime)
    -- lua 中周日为一周的第一天, 游戏中以周日为一周的最后一天
    if timeTable.week == 0 then
        endTime = os.time({year = timeTable.year, month = timeTable.month, day = timeTable.day, hour = 23, min = 59, sec = 59})
    else
        local iLeftTime = 7 - timeTable.week
        endTime = os.time({year = timeTable.year, month = timeTable.month, day = timeTable.day + iLeftTime, hour = 23, min = 59, sec = 59})
    end
    return endTime
end

function WeeklyGoalCtrl:UpdateImplBySecond(deltaTime)
    local curTime = GameData.GetServerTime()
    local iLeftTime = self._ThisWeekEndTime - curTime
    if iLeftTime > 0 then
        self._ui.pTxtLeftTime.text = string.format("本周倒计时:%s", Helper.GetLongTimeString(iLeftTime))
    else
        -- 新的一周,刷新
        self._ThisWeekEndTime = self:GetThisWeekEndTime()
        self:UpdateLeftThisWeekEndTime()
        GameData.ResetWeeklyGoals()
        self:SetupGoalUI()
    end
end

function WeeklyGoalCtrl:UpdateLeftThisWeekEndTime()
    local curTime = GameData.GetServerTime()
    self._ui.pTxtLeftTime.text = string.format("本周倒计时:%s", Helper.GetLongTimeString(self._ThisWeekEndTime - curTime))
end

function WeeklyGoalCtrl:OnGoalChanged(goalType)
    if goalType == GoalType.Weekly then
        self:UpdateGoalsUI()
    end
end
