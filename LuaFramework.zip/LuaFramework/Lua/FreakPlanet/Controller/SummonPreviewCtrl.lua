require "FreakPlanet/View/SummonPreviewPanel"

local class = require "FreakPlanet/Utils/middleclass"
SummonPreviewCtrl  = class(CtrlNames.SummonPreview, BaseCtrl)

local _sortItemTypes = {
	{Key = "Character", Type = ItemType.Character, Name = "loc_Character"}, 
	{Key = "Pet", Type = ItemType.Pet, Name = "宠物"},
	{Key = "Object", Type = ItemType.Goods, SubType = GoodsSubType.Object, Name = "loc_Goods"},
	{Key = "Chip", Type = ItemType.Goods, SubType = GoodsSubType.Chip, Name = "loc_Chip"},
	{Key = "CatchItem", Type = ItemType.Goods, SubType = GoodsSubType.CatchItem, Name = "抓捕道具"},
	{Key = "Food", Type = ItemType.Goods, SubType = GoodsSubType.Food, Name = "食物"},
	{Key = "RoomPiece", Type = ItemType.RoomPiece, Name = "神秘房间"},
}
------------------------------------------------------------
local function SummonGroupSortFunc(elementA, elementB)
	if elementA == nil or elementB == nil then
		return false
	end

	return elementA.sortId < elementB.sortId
end
------------------------------------------------------------
-- load the ui prefab
function SummonPreviewCtrl:LoadPanel()
	self:CreatePanel("SummonPreview")
end

-- construct ui panel data
function SummonPreviewCtrl:ConstructUI(obj)
	self._ui = SummonPreviewPanel.Init(obj)
end

-- destructor 
function SummonPreviewCtrl:DestroyImpl()
	GameNotifier.RemoveListener(GameEvent.ItemNumChanged, SummonPreviewCtrl.OnItemNumChanged, self)
end

function SummonPreviewCtrl:GetMatchedSortGroupIndex(itemId)
	local itemType = ConfigUtils.GetItemTypeFromId(itemId)

	for idx = 1, #_sortItemTypes do
		if itemType == _sortItemTypes[idx].Type then
			if _sortItemTypes[idx].SubType ~= nil then
				local subType = ConfigUtils.GetGoodsSubType(itemId)
				if subType == _sortItemTypes[idx].SubType then
					return idx
				end
			else
				return idx
			end
		end
	end

	assert(false, "un-handled item id: "..tostring(itemId).." for item type: "..tostring(itemType))
end

-- fill ui with the data
function SummonPreviewCtrl:SetupUI()
	self:GatherSummonGroupItems()
	self:ShowSummonItems()
	self:RefreshSummonCollectionRatio()

	CtrlManager.AddClick(self, self._ui.Blocker)
	GameNotifier.AddListener(GameEvent.ItemNumChanged, SummonPreviewCtrl.OnItemNumChanged, self)
end

function SummonPreviewCtrl:GatherSummonGroupItems()
	local summonId = self._parameter.summonId
	local summonItems = ConfigUtils.GetSummonItems(summonId)
	self._previewGroupItems = {}

	local groupIndices = {}
	for idx = 1, #summonItems do
		local itemId = summonItems[idx]
		local sortIndex = self:GetMatchedSortGroupIndex(itemId)
		local groupKey = _sortItemTypes[sortIndex].Key
		local groupName = _sortItemTypes[sortIndex].Name

		local groupIndex = groupIndices[groupKey]
		if groupIndex == nil then
			groupIndex =  #self._previewGroupItems + 1
			self._previewGroupItems[groupIndex] = {key = groupKey, name = groupName, dropList = {}, sortId = sortIndex}
			groupIndices[groupKey] = groupIndex
		end

		table.insert(self._previewGroupItems[groupIndex].dropList, itemId)
	end
	-- do group sort
	table.sort(self._previewGroupItems, SummonGroupSortFunc)

	-- do drop list sort
	for k, v in pairs(self._previewGroupItems) do
		table.sort(v.dropList, SummonCtrl.SummonItemSortFunc)
	end
end

function SummonPreviewCtrl:ShowSummonItems()
	local offset = 330
	for idx = 1, #self._previewGroupItems do
		local displayName = self._previewGroupItems[idx].name
		local key = self._previewGroupItems[idx].key
		local poolItems = self._previewGroupItems[idx].dropList
		local listItemObj = Helper.NewObject(self._ui.ListItemTemplate, self._ui.ScrollView)
		local listItem = listItemObj.transform

		listItem.gameObject:SetActive(true)
		listItem.gameObject.name = key
		listItem.localPosition = Vector3.New(0, offset, 0)
		listItem:Find("Header/Desc"):GetComponent("UILabel").text = SAFE_LOC(displayName)

		local grid = listItem:Find("Grid")
		for itemIdx = 1, #poolItems do
			local itemId = poolItems[itemIdx]
			local summonItemObj = Helper.NewObject(self._ui.SummonItemTemplate, grid)
			CtrlManager.AddClick(self, summonItemObj)
			local summonItem = summonItemObj.transform
	
			summonItem.gameObject:SetActive(true)
			summonItem.gameObject.name = tostring(itemId)
			self:ConstructSummonItem(summonItem, itemId)
		end

		local uiGrid = grid:GetComponent('UIGrid')
		uiGrid:Reposition()
		uiGrid.repositionNow = true

		local itemOffset = grid.localPosition.y
		if grid.childCount > 0 then
			itemOffset = itemOffset + grid:GetChild(grid.childCount - 1).localPosition.y
		end
		itemOffset = itemOffset - 140
		offset = offset + itemOffset
	end

	self._ui.ScrollView:GetComponent("UIScrollView"):ResetPosition()
end

function SummonPreviewCtrl:ConstructSummonItem(item, itemId)
	local unlocked = GameData.IsItemUnlocked(itemId)
	local bgName, borderName = UIHelper.GetBorderAndBgByItemId(itemId)
	-- name
	local nameLabel = item:Find("Name"):GetComponent("UILabel")
	nameLabel.text = ConfigUtils.GetItemName(itemId)
	-- bg
	local bg = item:Find("BG"):GetComponent("UISprite")
    bg.spriteName = bgName
    -- border
    local border = item:Find("Border"):GetComponent("UISprite")
    border.spriteName = borderName
    -- hint
	local hintMark = item:Find("Hint").gameObject
	hintMark:SetActive(unlocked)

	local itemNum = GameData.GetItemNum(itemId)
	local icon = UIHelper.ConstructItemIconAndNum(self, item, itemId, itemNum)
	if icon ~= nil then
		if unlocked then
			icon.color = Color.white
		else
			icon.color = LOCK_ICON_COLOR
		end
	end
end

function SummonPreviewCtrl:OnItemNumChanged(itemId, changeNum)
	for idx = 1, self._ui.ScrollView.childCount do
		local listItem = self._ui.ScrollView:GetChild(idx - 1)
		local itemGrid = listItem:Find("Grid")
		if itemGrid ~= nil then
			local item = itemGrid:Find(itemId)
			if item ~= nil then
				self:ConstructSummonItem(item, itemId)
			end
		end
	end

	self:RefreshSummonCollectionRatio()
end

-- refresh collection
function SummonPreviewCtrl:RefreshSummonCollectionRatio()
	local summonId = self._parameter.summonId
    local summonItems = ConfigUtils.GetSummonItems(summonId)

    local unlockNum = 0
    local totalNum = 0
    for idx = 1, #summonItems do
        totalNum = totalNum + 1
        if GameData.IsItemUnlocked(summonItems[idx]) then
            unlockNum = unlockNum + 1
        end
    end

    self._ui.SummonCollection.text = string.format("%d/%d", unlockNum, totalNum)
end

-- on clicked
function SummonPreviewCtrl:OnClicked(go)
	if go == self._ui.Blocker then
		SoundSystem.PlayUICancelSound()
		CtrlManager.PopPanel()
	else
		SoundSystem.PlayUIClickSound()
		local itemId = tonumber(go.name)
		CtrlManager.ShowItemDetail({itemId = itemId})
	end

	return true
end
