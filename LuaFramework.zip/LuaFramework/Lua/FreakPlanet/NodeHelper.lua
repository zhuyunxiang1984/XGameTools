NodeHelper = {}

local this = NodeHelper

local _areaNodes = nil
local _planetNodes = nil
local _characterNodes = nil
local _exileCharacterNodes = nil

function NodeHelper.Init()
    _areaNodes = {}
    for nodeName, v in pairs(MapAvatarConfig) do
        _areaNodes[nodeName] = this.IsAreaNodeVisibleConditionMatch(nodeName)
    end

    _planetNodes = {}
    for nodeName, v in pairs(PlanetAvatarConfig) do
        _planetNodes[nodeName] = this.IsPlanetNodeVisibleConditionMatch(nodeName)
    end

    _characterNodes = {}
    for nodeName, v in pairs(PlanetCharacterConfig) do
        _characterNodes[nodeName] = this.IsCharacterNodeVisibleConditionMatch(nodeName, false)
    end

    _exileCharacterNodes = {}
    for nodeName, v in pairs(ExileStreetCharacterConfig) do
        _exileCharacterNodes[nodeName] = this.IsCharacterNodeVisibleConditionMatch(nodeName, true)
    end
end

function NodeHelper.OnGoalClosed()
    -- now only main goal handled
    this.CheckAreaNodes()
    this.CheckPlanetNodes()
end

function NodeHelper.OnChallengeFinished()
    this.CheckAreaNodes()
    this.CheckPlanetNodes()
end

function NodeHelper.OnAreaSettled()
    this.CheckAreaNodes()
    this.CheckPlanetNodes()
end

function NodeHelper.OnCharacterUnlocked()
    this.CheckCharacterNodes()
end

function NodeHelper.CheckAreaNodes()
    for k, v in pairs(_areaNodes) do
        if not v then
            local visible = this.IsAreaNodeVisibleConditionMatch(k)
            if visible then
                _areaNodes[k] = visible
                GameData.AddNewCheck(k)
                GameData.Save()
                GameNotifier.Notify(GameEvent.AreaNodeAdded, k)
            end
        end
    end
end

function NodeHelper.CheckPlanetNodes()
    for k, v in pairs(_planetNodes) do
        if not v then
            local visible = this.IsPlanetNodeVisibleConditionMatch(k)
            if visible then
                _planetNodes[k] = visible
                GameNotifier.Notify(GameEvent.PlanetNodeAdded, k)
            end
        end
    end
end

function NodeHelper.CheckCharacterNodes()
    for k, v in pairs(_characterNodes) do
        local newValue = this.IsCharacterNodeVisibleConditionMatch(k, false)
        if newValue ~= v then
            _characterNodes[k] = newValue
            GameNotifier.Notify(GameEvent.CharacterNodeVisibleChanged, k, newValue)
        end
    end

    for k, v in pairs(_exileCharacterNodes) do
        local newValue = this.IsCharacterNodeVisibleConditionMatch(k, true)
        if newValue ~= v then
            _exileCharacterNodes[k] = newValue
            GameNotifier.Notify(GameEvent.CharacterNodeVisibleChanged, k, newValue)
        end
    end
end

function NodeHelper.IsAreaNodeVisible(nodeName)
    return _areaNodes[nodeName] or false
end

function NodeHelper.IsPlanetNodeVisible(nodeName)
    return _planetNodes[nodeName] or false
end

function NodeHelper.IsCharacterNodeVisible(nodeName)
    return _characterNodes[nodeName] or false
end

function NodeHelper.IsExileCharacterNodeVisible(nodeName)
    return _exileCharacterNodes[nodeName] or false
end

function NodeHelper.IsAreaNodeVisibleConditionMatch(nodeName)
    local goalList, challengeList, exploreData = ConfigUtils.GetAreaNodeVisibleConditions(nodeName)
    return this.IsNodeVisibleConditionMatch(goalList, challengeList, exploreData)
end

function NodeHelper.IsPlanetNodeVisibleConditionMatch(nodeName)
    local goalList, challengeList, exploreData = ConfigUtils.GetPlanetNodeVisibleConditions(nodeName)
    return this.IsNodeVisibleConditionMatch(goalList, challengeList, exploreData)
end

function NodeHelper.IsCharacterNodeVisibleConditionMatch(nodeName, isExile)
    isExile = isExile or false
    local unlockCharacterList = nil
    local lockCharacterList = nil
    if isExile then
        unlockCharacterList, lockCharacterList = ConfigUtils.GetExileCharacterNodeVisibleConditions(nodeName)
    else
        unlockCharacterList, lockCharacterList = ConfigUtils.GetCharacterNodeVisibleConditions(nodeName)
    end
    unlockCharacterList = unlockCharacterList or {}
    lockCharacterList = lockCharacterList or {}

    for idx = 1, #unlockCharacterList do
        local characterId = unlockCharacterList[idx]
        if not GameData.IsCharacterUnlocked(characterId) then
            return false
        end
    end

    for idx = 1, #lockCharacterList do
        local characterId = lockCharacterList[idx]
        if GameData.IsCharacterUnlocked(characterId) then
            return false
        end
    end

    return true
end

function NodeHelper.IsNodeVisibleConditionMatch(goalList, challengeList, exploreData)
    goalList = goalList or {}
    challengeList = challengeList or {}

    for idx = 1, #goalList do
        local goalId = goalList[idx]
        if not GameData.IsGoalFinished(goalId) then
            return false
        end
    end

    for idx = 1, #challengeList do
        local challengeId = challengeList[idx]
        if not GameData.IsChallengeCompleted(challengeId) then
            return false
        end
    end

    if exploreData ~= nil then
        if ConfigUtils.IsValidItem(exploreData.Value) then
            local exploreValue = exploreData.Value
            local needTime = exploreData.ExploreTime
            local currentTime = 0
            local valueType = ConfigUtils.GetItemTypeFromId(exploreValue)
            if valueType == ItemType.Planet then
                currentTime = GameData.GetTotalExploreTimeOfPlanet(exploreValue)
            elseif valueType == ItemType.PlanetArea then
                currentTime = GameData.GetTotalExploreTimeOfPlanetArea(exploreValue)
            else
                assert(false, "un-handled explore value: "..tostring(exploreValue))
            end

            if currentTime < needTime then
                return false
            end
        end
    end

    return true
end