require "FreakPlanet/Design/MiscConfig"
require "FreakPlanet/Design/AbilityConfig"
require "FreakPlanet/Design/ElementConfig"
require "FreakPlanet/Design/EnemyConfig"
require "FreakPlanet/Design/PetConfig"
require "FreakPlanet/Design/PetLevelUpConfig"
require "FreakPlanet/Design/GoodsConfig"
require "FreakPlanet/Design/EquipmentConfig"
require "FreakPlanet/Design/EquipmentInfoConfig"
require "FreakPlanet/Design/EquipmentUpgradeConfig"
require "FreakPlanet/Design/PlanetConfig"
require "FreakPlanet/Design/AreaConfig"
require "FreakPlanet/Design/CharacterConfig"
require "FreakPlanet/Design/GoalConfig"
require "FreakPlanet/Design/StorySpeechConfig"
require "FreakPlanet/Design/TutorialConfig"
require "FreakPlanet/Design/TutorialExConfig"
require "FreakPlanet/Design/ModulesUnlockConfig"
require "FreakPlanet/Design/SummonConfig"
require "FreakPlanet/Design/WorkShopConfig"
require "FreakPlanet/Design/NpcConfig"
require "FreakPlanet/Design/ChallengeConfig"
require "FreakPlanet/Design/WorkShopSpeechConfig"
require "FreakPlanet/Design/EventConfig"
require "FreakPlanet/Design/PostcardConfig"

require "FreakPlanet/Design/SkinConfig"
require "FreakPlanet/Design/ArenaConfig"
require "FreakPlanet/Design/ArenaBattleConfig"
require "FreakPlanet/Design/ArenaShopConfig"

require "FreakPlanet/Design/ActivityBattleConfig"
require "FreakPlanet/Design/ActivityExploreConfig"
require "FreakPlanet/Design/ActivityThemeConfig"

require "FreakPlanet/Design/DemandConfig"
require "FreakPlanet/Design/DemandGroupConfig"
require "FreakPlanet/Design/TouristConfig"

require "FreakPlanet/Design/SkillConfig"
require "FreakPlanet/Design/LevelUpConfig"
require "FreakPlanet/Design/LabRecipeConfig"
require "FreakPlanet/Design/DailyLoginConfig"

require "FreakPlanet/Design/IAPConfig"
require "FreakPlanet/Design/IAPPackageConfig"
require "FreakPlanet/Design/IAPCustomPackageConfig"

require "FreakPlanet/Design/TagConfig"
require "FreakPlanet/Design/TokenConfig"
require "FreakPlanet/AnimationSetting"

require "FreakPlanet/Design/MapAvatarConfig"
require "FreakPlanet/Design/PlanetAvatarConfig"
require "FreakPlanet/Design/PlanetCharacterConfig"
require "FreakPlanet/Design/ExileStreetCharacterConfig"

require "FreakPlanet/Design/RoomConfig"
require "FreakPlanet/Design/RoomPieceConfig"
require "FreakPlanet/Design/CoupleConfig"

require "FreakPlanet/Design/GalleryConfig"

require "FreakPlanet/Design/SpaceTravelFriendlinessConfig"
require "FreakPlanet/Design/SpaceTravelChatConfig"
require "FreakPlanet/Design/SpaceTravelChoiceConfig"
require "FreakPlanet/Design/SpaceTravelDealConfig"
require "FreakPlanet/Design/SpaceTravelEventConfig"
require "FreakPlanet/Design/SpaceTravelEventPoolConfig"
require "FreakPlanet/Design/SpaceTravelDiscoveryConfig"
require "FreakPlanet/Design/SpaceTravelGoodsConfig"
require "FreakPlanet/Design/SpaceTravelLabConfig"
require "FreakPlanet/Design/SpaceTravelMapConfig"
require "FreakPlanet/Design/SpaceTravelScoreCapConfig"
require "FreakPlanet/Design/SpaceTravelShipConfig"
require "FreakPlanet/Design/SpaceTravelGoalConfig"

require "FreakPlanet/Design/NewbieConfig"
require "FreakPlanet/Design/ExploreBagSpeechConfig"

require "FreakPlanet/Design/CharacterSkillFilterConfig"
require "FreakPlanet/Design/CustomDemandSpeechConfig"
require "FreakPlanet/Design/BGMConfig"


--CatchFish
require "FreakPlanet/Design/CatchFish_CommonConfig"
require "FreakPlanet/Design/CatchFish_CatchConfig"
require "FreakPlanet/Design/CatchFish_FishConfig"
require "FreakPlanet/Design/CatchFish_FishPoolConfig"
require "FreakPlanet/Design/MiniGameStarRewardConfig"

-- ActivitySignIn
require "FreakPlanet/Design/ActivityDailyLoginConfig"

-- 服装店配置
require "FreakPlanet/Design/ClothesShopConfig"
require "FreakPlanet/Design/ClothesShopItemConfig"

-- the last one
require "FreakPlanet/Design/SaveDataConfig"

-- 捉迷藏
require "FreakPlanet/Design/HideSeekConfig"
require "FreakPlanet/Design/HideSeekObjectConfig"

-- 内置app
require "FreakPlanet/Design/ApplicationMenuConfig"

-- 家园
require "FreakPlanet/Design/HomeFurnitureConfig"
require "FreakPlanet/Design/HomeFurnitureGashaponConfig"
require "FreakPlanet/Design/HomeItemPrefabConfig"
require "FreakPlanet/Design/HomeWorldPlaneConfig"
require "FreakPlanet/Design/HomeObstacleConfig"
require "FreakPlanet/Design/HomeObstacleAreaConfig"
require "FreakPlanet/Design/HomeObstacleAreaPrefabConfig"


ConfigUtils = {}
local this = ConfigUtils

PlanetAreaStatus = {
	Locked = "Locked",         -- still locked
	Idle = "Idle",             -- unlocked but not exploring
	Exploring = "Exploring",   -- unlocked and is exploring
}

EnumPostcardType = {
	Achievement = 0,
	Activity = 1,
}

ALL_ABILITY_NAME = "loc_exploring_all_attribute"
ALL_ABILITY_ICON = "all_r2"
ALL_CHANCE = 100

--------------------------------------------------------------
---通用道具配置 icon node showNum
local _dicGeneralItemConfig =
{
	[ItemType.Gold] 			= { icon = "icon_money"		, node = "General"		, showNum = true },
	[ItemType.Diamond] 			= { icon = "icon_yuanbao"	, node = "General"		, showNum = true },
	[ItemType.Token] 			= { icon = nil				, node = "General"		, showNum = true },
	[ItemType.Time] 			= { icon = "MissionIconTime", node = "General"		, showNum = true },
	[ItemType.Character] 		= { icon = nil				, node = "Character"	, showNum = false },
	[ItemType.Enemy] 			= { icon = nil				, node = "Character"	, showNum = false },
	[ItemType.Pet] 				= { icon = nil				, node = "Character"	, showNum = false },
	[ItemType.Skin] 			= { icon = nil				, node = "CharacterSkin", showNum = false },
	[ItemType.Goods] 			= { icon = nil				, node = "Goods"		, showNum = true },
	[ItemType.Equipment] 		= { icon = nil				, node = "Equipment" 	, showNum = true },
	[ItemType.Planet] 			= { icon = nil				, node = "Planet" 	 	, showNum = false },
	[ItemType.LabRecipe] 		= { icon = nil				, node = "Goods" 	 	, showNum = false },
	[ItemType.WorkShop] 		= { icon = nil				, node = "WorkShop"  	, showNum = false },
	[ItemType.PlanetArea] 		= { icon = nil				, node = "Area"			, showNum = false },
	[ItemType.RoomPiece] 		= { icon = nil				, node = "RoomPiece" 	, showNum = false },
	[ItemType.CatchFishPoint] 	= { icon = "GoldFish_Energy", node = "General" 		, showNum = true },
	[ItemType.ActivityPassport] = { icon = "icon_goodluck"	, node = "General" 		, showNum = true },
	[ItemType.Postcard] 		= { icon = nil				, node = "Postcard" 	, showNum = false },
}

function ConfigUtils.GetGeneralItemIcon(itemType)
	assert(_dicGeneralItemConfig[itemType] ~= nil, "GetGeneralItemIcon un-handled item type: "..tostring(itemType))
	return _dicGeneralItemConfig[itemType].icon
end
function ConfigUtils.GetGeneralItemNode(itemType)
	assert(_dicGeneralItemConfig[itemType] ~= nil, "GetGeneralItemNode un-handled item type: "..tostring(itemType))
	return _dicGeneralItemConfig[itemType].node
end
function ConfigUtils.IsGeneralItemShowNum(itemType)
	assert(_dicGeneralItemConfig[itemType] ~= nil, "IsGeneralItemShowNum un-handled item type: "..tostring(itemType))
	return _dicGeneralItemConfig[itemType].showNum
end
function ConfigUtils.GetGeneralItem(itemType)
	assert(_dicGeneralItemConfig[itemType] ~= nil, "GetGeneralItem un-handled item type: "..tostring(itemType))
	return _dicGeneralItemConfig[itemType]
end

--------------------------------------------------------------
-- common
function ConfigUtils.IsValidItem(id)
	return id ~= nil and id ~= INVALID_ID and id ~= INVALID_ID_0
end

function ConfigUtils.GetItemTypeFromId(id)
	if id < 10 or (id > 100 and id <= 999) then
		return id
	else
		local typeNum = math.floor(id / 10000)
		return typeNum
	end
end

function ConfigUtils.GetItemName(id)
	local itemType = this.GetItemTypeFromId(id)
	return this.GetItemNameByType(itemType, id)
end

function ConfigUtils.GetItemDesc(id)
	local itemType = this.GetItemTypeFromId(id)
	return this.GetItemDescByType(itemType, id)
end


function ConfigUtils.GetItemRarity(id)
	local itemType = this.GetItemTypeFromId(id)
	local rarity = 1

	if itemType == ItemType.Goods then
		rarity = this.GetGoodsRarity(id)
	elseif itemType == ItemType.Equipment then
		rarity = this.GetEquipmentRarity(id)
	elseif itemType == ItemType.Character then
		rarity = this.GetCharacterRarity(id)
	elseif itemType == ItemType.Pet then
		rarity = this.GetPetRarity(id)
	elseif itemType == ItemType.Enemy then
		rarity = this.GetEnemyRarity(id)
	elseif itemType == ItemType.RoomPiece then
		rarity = this.GetRoomPieceRarity(id)
	end

	return rarity
end

function ConfigUtils.GetItemGallery(id)
	local itemType = this.GetItemTypeFromId(id)
	
	if itemType == ItemType.Character then
		return this.GetCharacterGallery(id)
	elseif itemType == ItemType.Pet then
		return this.GetPetGallery(id)
	end

	return nil
end

function ConfigUtils.GetItemNameByType(itemType, itemId)
	if itemType == ItemType.Gold then
		return SAFE_LOC("loc_global_coin_name")
	elseif itemType == ItemType.Diamond then
		return SAFE_LOC("loc_global_diamond_name")
	elseif itemType == ItemType.Token then
		return ConfigUtils.GetTokenName(itemId)
	elseif itemType == ItemType.Goods then
		return ConfigUtils.GetGoodsName(itemId)
	elseif itemType == ItemType.Equipment then
		return ConfigUtils.GetEquipmentName(itemId)
	elseif itemType == ItemType.Character then
		return ConfigUtils.GetCharacterName(itemId)
	elseif itemType == ItemType.Skin then
		return ConfigUtils.GetSkinName(itemId)
	elseif itemType == ItemType.Planet then
		return ConfigUtils.GetPlanetName(itemId)
	elseif itemType == ItemType.LabRecipe then
		return ConfigUtils.GetLabRecipeName(itemId)
	elseif itemType == ItemType.Ability then
		return ConfigUtils.GetAbilityName(itemId)
	elseif itemType == ItemType.PlanetArea then
		return ConfigUtils.GetAreaName(itemId)
	elseif itemType == ItemType.Enemy then
		return ConfigUtils.GetEnemyName(itemId)
	elseif itemType == ItemType.Pet then
		return ConfigUtils.GetPetName(itemId)
	elseif itemType == ItemType.Challenge then
		return ConfigUtils.GetChallengeName(itemId)
	elseif itemType == ItemType.WorkShop then
		return ConfigUtils.GetWorkShopName(itemId)
	elseif itemType == ItemType.RoomPiece then
		return ConfigUtils.GetRoomPieceName(itemId)
	elseif itemType == ItemType.Fuel then
		return SAFE_LOC("燃料")
	elseif itemType == ItemType.FuelMax then
		return SAFE_LOC("燃料上限")
	elseif itemType == ItemType.Food then
		return SAFE_LOC("食物")
	elseif itemType == ItemType.FoodMax then
		return SAFE_LOC("食物上限")
	elseif itemType == ItemType.CapacityMax then
		return SAFE_LOC("负重上限")
	elseif itemType == ItemType.SpaceTravelScore then
		return SAFE_LOC("分数")
	elseif itemType == ItemType.SpaceTravelFriendliness then
		return ConfigUtils.GetSpaceTravelFriendlinessName(itemId)
	elseif itemType == ItemType.SpaceTravelGoods then
		return ConfigUtils.GetSpaceTravelGoodsName(itemId)
	else
		assert(false, "GetItemNameByType un-handled item type: "..tostring(itemType))
	end
end

function ConfigUtils.GetItemDescByType(itemType, itemId)
	if itemType == ItemType.Gold then
		return SAFE_LOC("loc_global_coin_des")
	elseif itemType == ItemType.Diamond then
		return SAFE_LOC("loc_global_diamond_des")
	elseif itemType == ItemType.Token then
		return ConfigUtils.GetTokenDesc(itemId)
	elseif itemType == ItemType.Goods then
		return ConfigUtils.GetGoodsDesc(itemId)
	elseif itemType == ItemType.Equipment then
		return ConfigUtils.GetEquipmentDesc(itemId)
	elseif itemType == ItemType.Character then
		return ConfigUtils.GetCharacterDesc(itemId)
	elseif itemType == ItemType.Skin then
		return ConfigUtils.GetSkinDesc(itemId)
	elseif itemType == ItemType.Planet then
		return ConfigUtils.GetPlanetDesc(itemId)
	elseif itemType == ItemType.LabRecipe then
		return ConfigUtils.GetLabRecipeDesc(itemId)
	elseif itemType == ItemType.Ability then
		return ConfigUtils.GetAbilityDesc(itemId)
	elseif itemType == ItemType.PlanetArea then
		return ConfigUtils.GetAreaDesc(itemId)
	elseif itemType == ItemType.Enemy then
		return ConfigUtils.GetEnemyDesc(itemId)
	elseif itemType == ItemType.Pet then
		return ConfigUtils.GetPetDesc(itemId)
	elseif itemType == ItemType.Challenge then
		return ConfigUtils.GetChallengeDesc(itemId)
	elseif itemType == ItemType.WorkShop then
		return ConfigUtils.GetWorkShopDesc(itemId)
	elseif itemType == ItemType.RoomPiece then
		return ConfigUtils.GetRoomPieceDesc(itemId)
	elseif itemType == ItemType.Fuel then
		return SAFE_LOC("燃料")
	elseif itemType == ItemType.FuelMax then
		return SAFE_LOC("燃料上限")
	elseif itemType == ItemType.Food then
		return SAFE_LOC("食物")
	elseif itemType == ItemType.FoodMax then
		return SAFE_LOC("食物上限")
	elseif itemType == ItemType.CapacityMax then
		return SAFE_LOC("负重上限")
	elseif itemType == ItemType.SpaceTravelScore then
		return SAFE_LOC("分数")
	elseif itemType == ItemType.SpaceTravelFriendliness then
		return ConfigUtils.GetSpaceTravelFriendlinessDesc(itemId)
	elseif itemType == ItemType.SpaceTravelGoods then
		return ConfigUtils.GetSpaceTravelGoodsDesc(itemId)
	else
		assert(false, "GetItemDescByType un-handled item type: "..tostring(itemType))
	end
end

function ConfigUtils.IsUniqueItemType(itemType)
	if itemType == ItemType.Character or
		itemType == ItemType.Planet or
		itemType == ItemType.LabRecipe or
		itemType == ItemType.Event or
		itemType == ItemType.WorkShop or
		itemType == ItemType.Challenge or
		itemType == ItemType.Equipment or
		itemType == ItemType.Skin or
		itemType == ItemType.RoomPiece then
		return true
	end

	return false
end

function ConfigUtils.GetItemSource(itemId)
	local ret = {}

	if itemId ~= INVALID_ID then
		local itemType = this.GetItemTypeFromId(itemId)
		local source = nil
		if itemType == ItemType.Goods then
			source = GoodsConfig[itemId].From
		elseif itemType == ItemType.Character then
			source = CharacterConfig[itemId].From
		elseif itemType == ItemType.Pet then
			local summonPools = {}
			Helper.CopyTable(summonPools, PetConfig[itemId].Summon or {})
			if #summonPools > 0 then
				source = {}
				source[1] = {SourceType = SourceType.Summon, Value = summonPools}
			else
				source = nil
			end
		end

		-- craft
		if itemType == ItemType.Goods then
			local labRecipe = GoodsConfig[itemId].Recipe
			if labRecipe ~= nil then
				table.insert(ret, {source = SourceType.Craft, value = labRecipe})
			end
		end

		source = source or {}
		for idx = 1, #source do
			if source[idx].Value == nil then
				table.insert(ret, {source = source[idx].SourceType})
			else
				local values = source[idx].Value or {}
				for valueIdx = 1, #values do
					table.insert(ret, {source = source[idx].SourceType, value = values[valueIdx]})
				end
			end
		end

	end

	return ret
end

function ConfigUtils.GetItemTags(itemId)
	local ret = {}

	if itemId ~= INVALID_ID then
		local itemType = this.GetItemTypeFromId(itemId)
		local tags = nil
		if itemType == ItemType.Character then
			tags = CharacterConfig[itemId].Tags
		elseif itemType == ItemType.Pet then
			tags = PetConfig[itemId].Tags
		elseif itemType == ItemType.Enemy then
			tags = EnemyConfig[itemId].Tags
		elseif itemType == ItemType.SpaceTravelGoods then
			tags = SpaceTravelGoodsConfig[itemId].Tags
		elseif itemType == ItemType.LabRecipe then
			tags = LabRecipeConfig[itemId].Tags
		elseif itemType == ItemType.SpaceTravelChoice then
			tags = SpaceTravelChoiceConfig[itemId].Tags
		elseif itemType == ItemType.Goods then
			tags = GoodsConfig[itemId].Tags
		elseif itemType == ItemType.HomeFurniture then
			tags = HomeFurnitureConfig[itemId].TagList
		elseif itemType == ItemType.HomeObstacle then
			tags = HomeObstacleConfig[itemId].TagList
		elseif itemType == ItemType.HomeFurnitureGashapon then
			tags = HomeFurnitureGashapon[itemId].TagList
		end
		tags = tags or {}
		for idx = 1, #tags do
			table.insert(ret, tags[idx])
		end
	end

	return ret
end

function ConfigUtils.GetItemTagMap(itemId)
	local ret = {}

	local tagList = this.GetItemTags(itemId)
	for k, v in pairs(tagList) do
		ret[v] = 1
	end

	return ret
end

function ConfigUtils.GetSpeedUpDiamondCost(leftTime)
	if leftTime == 0 then
		return 0
	end

	local value = 0
	local factor = SkipCost.PayPerday / SkipCost.GameTime
	if leftTime <= 60 then
		value = leftTime * factor * SkipCost.CountDownM
	elseif leftTime <= 3600 then
		value = (leftTime - 60) * factor * SkipCost.CountDownH + 60 * factor * SkipCost.CountDownM
	elseif leftTime <= 86400 then
		value = (leftTime - 3600) * factor * SkipCost.CountDownD + 3600 * factor * SkipCost.CountDownH
	else
		value = (leftTime - 86400) * factor * SkipCost.CountDownW + 86400 * factor * SkipCost.CountDownD
	end

	value = math.ceil(value)
	value = math.max(1, value)

	return value
end

function ConfigUtils.GetWorkShopExchangeCost(maxWorkTime)
	if maxWorkTime <= 0 then
		return 0
	end

	local value = 0
	local factor = WorkShopQuickExchangeCost.PayPerday / WorkShopQuickExchangeCost.GameTime
	if maxWorkTime <= 60 then
		value = maxWorkTime * factor * WorkShopQuickExchangeCost.CountDownM
	elseif maxWorkTime <= 3600 then
		value = (maxWorkTime - 60) * factor * WorkShopQuickExchangeCost.CountDownH + 60 * factor * WorkShopQuickExchangeCost.CountDownM
	elseif maxWorkTime <= 86400 then
		value = (maxWorkTime - 3600) * factor * WorkShopQuickExchangeCost.CountDownD + 3600 * factor * WorkShopQuickExchangeCost.CountDownH
	else
		value = (maxWorkTime - 86400) * factor * WorkShopQuickExchangeCost.CountDownW + 86400 * factor * WorkShopQuickExchangeCost.CountDownD
	end

	value = math.ceil(value)
	value = math.max(1, value)

	return value
end

function ConfigUtils.CheckNumLimit(numLimit)
	numLimit = math.max(numLimit, 1)
	numLimit = math.min(numLimit, EXPLORE_NUM_LIMIT)
	return numLimit
end

function ConfigUtils.GetElementOfItem(itemId)
	local itemType = ConfigUtils.GetItemTypeFromId(itemId)
	if itemType == ItemType.Character then
		return this.GetCharacterElement(itemId), true
	elseif itemType == ItemType.Enemy then
		return this.GetEnemyElement(itemId), false
	elseif itemType == ItemType.Pet then
		return this.GetPetElement(itemId), false
	else
		assert(false, "un-handled item: "..tostring(itemId))
	end
end

function ConfigUtils.GetStyleOfItem(itemId)
	local itemType = ConfigUtils.GetItemTypeFromId(itemId)
	if itemType == ItemType.Character then
		return this.GetCharacterStyle(itemId)
	elseif itemType == ItemType.Enemy then
		return this.GetEnemyStyle(itemId)
	elseif itemType == ItemType.Pet then
		return this.GetPetStyle(itemId)
	else
		assert(false, "un-handled item: "..tostring(itemId))
	end
end

function ConfigUtils.GeBattleResourceOfItem(itemId)
	local itemType = ConfigUtils.GetItemTypeFromId(itemId)
	if itemType == ItemType.Skin then
		return this.GetSkinBattleResource(itemId)
	elseif itemType == ItemType.Pet then
		return this.GetPetBattleResource(itemId)
	elseif itemType == ItemType.Enemy then
		return this.GetEnemyBattleResource(itemId)
	else
		assert(false, "un-handled item: "..tostring(itemId))
	end
end

function ConfigUtils.GetElementIconOfItem(itemId, hasStyle)
	local elementId = this.GetElementOfItem(itemId)
	hasStyle = hasStyle or false
	if hasStyle then
		return ConfigUtils.GetElementIconWithStyle(elementId)
	else
		return ConfigUtils.GetElementIconNoStyle(elementId)
	end
end

function ConfigUtils.GetAttackTypeOfItem(itemId)
	local itemType = ConfigUtils.GetItemTypeFromId(itemId)
	local attackType = nil
	if itemType == ItemType.Character then
		local config = CharacterConfig[itemId]
		attackType = config.AttackType
	elseif itemType == ItemType.Enemy then
		local config = EnemyConfig[itemId]
		attackType = config.AttackType
	elseif itemType == ItemType.Pet then
		local config = PetConfig[itemId]
		attackType = config.AttackType
	else
		assert(false, "un-handled item: "..tostring(itemId))
	end

	return attackType
end

function ConfigUtils.IsMeleeItem(itemId)
	local attackType = ConfigUtils.GetAttackTypeOfItem(itemId)
	return attackType == AttackType.Melee
end

function ConfigUtils.GetItemAvatarScale(itemId)
	local itemType = ConfigUtils.GetItemTypeFromId(itemId)
	if itemType == ItemType.Character then
		local config = CharacterConfig[itemId]
		return config.PrefabScale
	elseif itemType == ItemType.Enemy then
		local config = EnemyConfig[itemId]
		return config.PrefabScale
	elseif itemType == ItemType.Pet then
		local config = PetConfig[itemId]
		return config.PrefabScale
	else
		assert(false, "un-handled item: "..tostring(itemId))
	end
end

function ConfigUtils.GetStyleIcon(style)
	return style
end

-- style icon color to match element icon
function ConfigUtils.GetStyleIconColor(elementId)
	if elementId == ElementType.Water then
		return Color.New(79 / 255, 244 / 255, 254 / 255, 1)
	elseif elementId == ElementType.Fire then
		return Color.New(252 / 255, 167 / 255, 48 / 255, 1)
	elseif elementId == ElementType.Wind then
		return Color.New(58 / 255, 1, 191 / 255, 1)
	elseif elementId == ElementType.Light then
		return Color.New(1, 239 / 255, 103 / 255, 1)
	elseif elementId == ElementType.Dark then
		return Color.New(183 / 255, 125 /255, 1, 1)
	else
		assert(false, "un-handled element id: "..tostring(elementId))
	end
end

-- hit sound of element
function ConfigUtils.GetElementHitSound(elementId)
	if elementId == ElementType.Water then
		return SoundNames.HitSoundWater
	elseif elementId == ElementType.Fire then
		return SoundNames.HitSoundFire
	elseif elementId == ElementType.Wind then
		return SoundNames.HitSoundWind
	elseif elementId == ElementType.Light then
		return SoundNames.HitSoundLight
	elseif elementId == ElementType.Dark then
		return SoundNames.HitSoundDark
	else
		assert(false, "un-handled element id: "..tostring(elementId))
	end
end

-- attack sound of element
function ConfigUtils.GetElementAttackSound(elementId, attackType)
	if elementId == ElementType.Water then
		if attackType == AttackType.Melee then
			return SoundNames.AttackSoundMeleeWater
		else
			return SoundNames.AttackSoundRangeWater
		end
	elseif elementId == ElementType.Fire then
		if attackType == AttackType.Melee then
			return SoundNames.AttackSoundMeleeFire
		else
			return SoundNames.AttackSoundRangeFire
		end
	elseif elementId == ElementType.Wind then
		if attackType == AttackType.Melee then
			return SoundNames.AttackSoundMeleeWind
		else
			return SoundNames.AttackSoundRangeWind
		end
	elseif elementId == ElementType.Light then
		if attackType == AttackType.Melee then
			return SoundNames.AttackSoundMeleeLight
		else
			return SoundNames.AttackSoundRangeLight
		end
	elseif elementId == ElementType.Dark then
		if attackType == AttackType.Melee then
			return SoundNames.AttackSoundMeleeDark
		else
			return SoundNames.AttackSoundRangeDark
		end
	else
		assert(false, "un-handled element id: "..tostring(elementId))
	end
end
--------------------------------------------------------------
-- planet
function ConfigUtils.IsValidPlanet(planetId)
	if planetId == nil or planetId == INVALID_ID then
		return false
	end

	local config = PlanetConfig[planetId]
	return config ~= nil
end

function ConfigUtils.GetPlanetSortId(planetId)
	local config = PlanetConfig[planetId]
	assert(config ~= nil, "invalid planet id: "..tostring(planetId))
	return config.Id
end

function ConfigUtils.GetPlanetName(planetId)
	local config = PlanetConfig[planetId]
	assert(config ~= nil, "invalid planet id: "..tostring(planetId))
	return SAFE_LOC(config.Name)
end

function ConfigUtils.GetPlanetIcon(planetId)
	local config = PlanetConfig[planetId]
	assert(config ~= nil, "invalid planet id: "..tostring(planetId))
	return config.Icon, "PlanetIcon"
end

function ConfigUtils.GetPlanetPrefab(planetId)
	local config = PlanetConfig[planetId]
	assert(config ~= nil, "invalid planet id: "..tostring(planetId))
	return config.PrefabName
end

function ConfigUtils.GetPlanetMapPrefab(planetId)
	local config = PlanetConfig[planetId]
	assert(config ~= nil, "invalid planet id: "..tostring(planetId))
	return config.MapPrefabName
end

function ConfigUtils.GetPlanetAreaList(planetId)
	local config = PlanetConfig[planetId]
	assert(config ~= nil, "invalid planet id: "..tostring(planetId))

	local ret = {}

	local areaList = config.AreaList or {}
	Helper.CopyTable(ret, areaList)

	return ret
end

function ConfigUtils.GetPlanetIdBySummonId(summonId)
	for k, v in pairs(PlanetConfig) do
		if v.SummonPool[1] == summonId or v.SummonPool[2] == summonId then
			return k
		end
	end
	return nil
end

function ConfigUtils.GetSummonPositionBySummonId(summonId)
	for k, v in pairs(PlanetConfig) do
		if v.SummonPool[1] == summonId then
			return 1
		elseif v.SummonPool[2] == summonId then
			return 2
		end
	end
	return 1
end

function ConfigUtils.GetPlanetSummonPool(planetId, position)
	local config = PlanetConfig[planetId]
	assert(config ~= nil, "invalid planet id: "..tostring(planetId))

	assert(position == 1 or position == 2, "invalid planet id: "..tostring(planetId) .. " with position: " .. tostring(position))
	return config.SummonPool[position]
end

function ConfigUtils.GetPlanetSummonSpeechRandom(planetId)
	local config = PlanetConfig[planetId]
	assert(config ~= nil, "invalid planet id: "..tostring(planetId))

	local idx = Helper.RandInt(1, #config.SummonSpeech)
	return config.SummonSpeech[idx]
end

function ConfigUtils.GetPlanetList()
	local ret = {}

	for k, v in pairs(PlanetConfig) do
		table.insert(ret, k)
	end

	return ret
end
---------------------------------------------------------------------
-- planet area
function ConfigUtils.GetAreaSortId(areaId)
	local config = AreaConfig[areaId]
	assert(config ~= nil, "invalid planet area id: "..tostring(areaId))

	return config.Id
end

function ConfigUtils.GetAreaName(areaId)
	local config = AreaConfig[areaId]
	assert(config ~= nil, "invalid planet area id: "..tostring(areaId))

	return SAFE_LOC(config.Name)
end

function ConfigUtils.GetAreaLevel(areaId)
	local config = AreaConfig[areaId]
	assert(config ~= nil, "invalid planet area id: "..tostring(areaId))

	return config.Level
end

function ConfigUtils.GetPlanetOfArea(areaId)
	local config = AreaConfig[areaId]
	assert(config ~= nil, "invalid planet area id: "..tostring(areaId))

	return config.Planet
end

function ConfigUtils.GetAreaNumCapacity(areaId)
	local config = AreaConfig[areaId]
	assert(config ~= nil, "invalid planet area id: "..tostring(areaId))

	return this.CheckNumLimit(config.NumCap)
end

function ConfigUtils.GetAreaIcon(areaId)
	local config = AreaConfig[areaId]
	assert(config ~= nil, "invalid planet area id: "..tostring(areaId))

	return config.LevelIcon, "EvenBGIcon"
end

function ConfigUtils.GetAreaBG(areaId)
	local config = AreaConfig[areaId]
	assert(config ~= nil, "invalid planet area id: "..tostring(areaId))

	return config.LevelBG, config.LevelAtlas, config.LevelBundle
end

function ConfigUtils.GetAreaChallengeList(areaId)
	local config = AreaConfig[areaId]
	assert(config ~= nil, "invalid planet area id: "..tostring(areaId))

	local ret = {}
	local challengeList = config.Challenge or {}
	Helper.CopyTable(ret, challengeList)

	return ret
end

function ConfigUtils.GetAreaEnemyList(areaId)
	local config = AreaConfig[areaId]
	assert(config ~= nil, "invalid planet area id: "..tostring(areaId))

	return config.LevelEnemy or {}
end

function ConfigUtils.GetAreaEventList(areaId)
	local config = AreaConfig[areaId]
	assert(config ~= nil, "invalid planet area id: "..tostring(areaId))

	return config.EventList or {}
end

function ConfigUtils.GetAreaStartScene(areaId)
	local config = AreaConfig[areaId]
	assert(config ~= nil, "invalid planet area id: "..tostring(areaId))

	return config.StartScene
end
---------------------------------------------------------------------
function ConfigUtils.GetChallengeName(challengeId)
	local config = ChallengeConfig[challengeId]
	assert(config ~= nil, "invalid challenge id: "..tostring(challengeId))

	return SAFE_LOC(config.Name)
end

function ConfigUtils.GetChallengeDesc(challengeId)
	local config = ChallengeConfig[challengeId]
	assert(config ~= nil, "invalid challenge id: "..tostring(challengeId))

	if config.Desc == nil then
		return ""
	end

	return SAFE_LOC(config.Desc)
end

function ConfigUtils.GetChallengeResultText(challengeId)
	local config = ChallengeConfig[challengeId]
	assert(config ~= nil, "invalid challenge id: "..tostring(challengeId))

	return SAFE_LOC(config.ResultText)
end

function ConfigUtils.GetChallengeDialog(challengeId)
	local config = ChallengeConfig[challengeId]
	assert(config ~= nil, "invalid challenge id: "..tostring(challengeId))

	if config.Dialog ~= nil then
		return SAFE_LOC(config.Dialog)
	end

	return nil
end

function ConfigUtils.GetAreaOfChallenge(challengeId)
	local config = ChallengeConfig[challengeId]
	assert(config ~= nil, "invalid challenge id: "..tostring(challengeId))

	return config.Area
end

function ConfigUtils.GetCharacterOfChallenge(challengeId)
	local config = ChallengeConfig[challengeId]
	assert(config ~= nil, "invalid challenge id: "..tostring(challengeId))

	return config.Character
end

function ConfigUtils.GetUnlockItemOfChallenge(challengeId)
	local config = ChallengeConfig[challengeId]
	assert(config ~= nil, "invalid challenge id: "..tostring(challengeId))

	return config.RewardUnlock
end

function ConfigUtils.GetChallengeNumCapacity(challengeId)
	local config = ChallengeConfig[challengeId]
	assert(config ~= nil, "invalid challenge id: "..tostring(challengeId))

	return config.NumCap
end

function ConfigUtils.GetChallengeExploreRules(challengeId)
	local config = ChallengeConfig[challengeId]
	assert(config ~= nil, "invalid challenge id: "..tostring(challengeId))

	return config.TeamCondition or {}
end

function ConfigUtils.GetChallengeEnemyList(challengeId)
	local config = ChallengeConfig[challengeId]
	assert(config ~= nil, "invalid challenge id: "..tostring(challengeId))

	local ret = {}

	local enemyList = config.Enemy or {}
	for idx = 1, #enemyList do
		ret[idx] = {id = enemyList[idx].Value, level = enemyList[idx].Level}
	end

	return ret
end

function ConfigUtils.GetLastEnemyOfChallenge(challengeId)
	local config = ChallengeConfig[challengeId]
	assert(config ~= nil, "invalid challenge id: "..tostring(challengeId))

	local enemyList = config.Enemy
	local num = #enemyList
	return enemyList[num].Value, enemyList[num].Level
end

function ConfigUtils.GetPreConditionOfChallenge(challengeId)
	local config = ChallengeConfig[challengeId]
	assert(config ~= nil, "invalid challenge id: "..tostring(challengeId))

	return config.PreCondition
end

function ConfigUtils.GetChallengeUnlockCost(challengeId)
	local config = ChallengeConfig[challengeId]
	assert(config ~= nil, "invalid challenge id: "..tostring(challengeId))

	return config.UnlockCostList or {}
end

function ConfigUtils.GetChallengeAcceptSpeech(challengeId)
	local config = ChallengeConfig[challengeId]
	assert(config ~= nil, "invalid challenge id: "..tostring(challengeId))
	return config.AcceptSpeech
end

function ConfigUtils.GetChallengeSuccessSpeech(challengeId)
	local config = ChallengeConfig[challengeId]
	assert(config ~= nil, "invalid challenge id: "..tostring(challengeId))
	return config.SuccessSpeech
end

function ConfigUtils.GetChallengeBG(challengeId)
	local config = ChallengeConfig[challengeId]
	assert(config ~= nil, "invalid challenge id: "..tostring(challengeId))

	return config.LevelBG, config.LevelAtlas, config.LevelBundle
end

function ConfigUtils.GetChallengeStartScene(challengeId)
	local config = ChallengeConfig[challengeId]
	assert(config ~= nil, "invalid challenge id: "..tostring(challengeId))

	return config.StartScene
end

function ConfigUtils.GetChallengeFullStarRewards(challengeId)
	local config = ChallengeConfig[challengeId]
	assert(config ~= nil, "invalid challenge id: "..tostring(challengeId))

	return config.FullStarReward or {}
end
---------------------------------------------------------------------
function ConfigUtils.GetEnemyName(enemyId)
	local config = EnemyConfig[enemyId]
	assert(config ~= nil, "invalid enemy id: "..tostring(enemyId))

	return SAFE_LOC(config.Name)
end

function ConfigUtils.GetEnemyIcon(enemyId)
	local config = EnemyConfig[enemyId]
	assert(config ~= nil, "invalid enemy id: "..tostring(enemyId))

	return config.IconName, config.IconAtlas, config.IconBundle
end

function ConfigUtils.GetEnemyDesc(enemyId)
	local config = EnemyConfig[enemyId]
	assert(config ~= nil, "invalid enemy id: "..tostring(enemyId))

	return SAFE_LOC(config.Desc)
end

function ConfigUtils.GetEnemySkinName(enemyId)
	local config = EnemyConfig[enemyId]
	assert(config ~= nil, "invalid enemy id: "..tostring(enemyId))

	return config.SkinName
end

function ConfigUtils.GetEnemyResultTextAndDialog(enemyId)
	local config = EnemyConfig[enemyId]
	assert(config ~= nil, "invalid enemy id: "..tostring(enemyId))

	return SAFE_LOC(config.ResultText), SAFE_LOC(config.Dialog)
end

function ConfigUtils.GetEnemyRarity(enemyId)
	local config = EnemyConfig[enemyId]
	assert(config ~= nil, "invalid enemy id: "..tostring(enemyId))

	return config.Rarity
end

function ConfigUtils.GetEnemyPrefab(enemyId)
	local config = EnemyConfig[enemyId]
	assert(config ~= nil, "invalid enemy id: "..tostring(enemyId))

	return config.PrefabName, config.PrefabBundle
end

function ConfigUtils.IsEnemyHasDrop(enemyId)
	local dropList = this.GetEnemyDropList(enemyId)
	return #dropList > 0
end

function ConfigUtils.GetEnemySkillDesc(enemyId)
	local config = EnemyConfig[enemyId]
	assert(config ~= nil, "invalid enemy id: "..tostring(enemyId))

	if config.SkillList == nil then
		return nil
	end

	local skills = config.SkillList.Skill or {}
	if #skills == 0 then
		return nil
	end

	local skillDesc = SAFE_LOC(config.SkillList.Desc)
	for idx = 1, #skills do
		local toReplace = string.format("{Value%d}", idx)
		skillDesc = Helper.StringFindAndReplace(skillDesc, toReplace, tostring(skills[idx].Value))
	end

	return skillDesc
end

function ConfigUtils.GetEnemySkillList(enemyId)
	local config = EnemyConfig[enemyId]
	assert(config ~= nil, "invalid enemy id: "..tostring(enemyId))

	local ret = {}

	if config.SkillList ~= nil then
		local skills = config.SkillList.Skill or {}
		for idx = 1, #skills do
			ret[idx] = {id = skills[idx].Id, value = skills[idx].Value}
		end
	end

	return ret
end

function ConfigUtils.GetEnemyBattleResource(enemyId)
	local config = EnemyConfig[enemyId]
	assert(config ~= nil, "invalid enemy id: "..tostring(enemyId))
	return config.BattleResource
end

function ConfigUtils.GetEnemyDropList(enemyId)
	local config = EnemyConfig[enemyId]
	assert(config ~= nil, "invalid enemy id: "..tostring(enemyId))

	local ret = {}

	local handledDrops = {}
	local drops = config.Drop or {}
	for idx = 1, #drops do
		local dropId = drops[idx].Value
		if handledDrops[dropId] == nil then
			table.insert(ret, dropId)
			handledDrops[dropId] = 1
		end 
	end

	return ret
end

function ConfigUtils.GetEnemyElement(enemyId)
	local config = EnemyConfig[enemyId]
	assert(config ~= nil, "invalid enemy id: "..tostring(enemyId))

	return config.Element
end

function ConfigUtils.GetEnemyStyle(enemyId)
	local config = EnemyConfig[enemyId]
	assert(config ~= nil, "invalid enemy id: "..tostring(enemyId))

	return config.Style
end

function ConfigUtils.GetPlanetAreaOfEnemy(enemyId)
	local config = EnemyConfig[enemyId]
	assert(config ~= nil, "invalid enemy id: "..tostring(enemyId))

	return config.Area or {}
end

function ConfigUtils.IsEnemyFromArea(enemyId, areaId)
	local config = EnemyConfig[enemyId]
	assert(config ~= nil, "invalid enemy id: "..tostring(enemyId))

	local areas = config.Area or {}
	for idx = 1, #areas do
		if areas[idx] == areaId then
			return true
		end
	end

	return false
end

function ConfigUtils.GetEnemyAbilityList(enemyId, level)
	local config = EnemyConfig[enemyId]
	assert(config ~= nil, "invalid enemy id: "..tostring(enemyId))

	local baseAbilityList = config.Ability or {}

	local ret = {}
	for idx = 1, #baseAbilityList do
		local abilityId = baseAbilityList[idx].Value
		local levelAddValue = (level - 1) * baseAbilityList[idx].Gain
		local finalValue = Helper.RoundAndCeil(baseAbilityList[idx].Base + levelAddValue)
		ret[idx] = {id = abilityId, value = finalValue}
	end

	return ret
end

function ConfigUtils.GetEnemyAbilityMap(enemyId, level)
	local config = EnemyConfig[enemyId]
	assert(config ~= nil, "invalid enemy id: "..tostring(enemyId))

	local baseAbilityList = config.Ability or {}

	local ret = {}
	for idx = 1, #baseAbilityList do
		local abilityId = baseAbilityList[idx].Value
		local levelAddValue = (level - 1) * baseAbilityList[idx].Gain
		local finalValue = Helper.RoundAndCeil(baseAbilityList[idx].Base + levelAddValue)
		ret[abilityId] = finalValue
	end

	return ret
end

function ConfigUtils.GetEnemyFightPower(enemyId, level)
	local abilityMap = this.GetEnemyAbilityMap(enemyId, level)
	return this.GetPowerOfAbilityMap(abilityMap)
end

function ConfigUtils.GetEnemyAttackAnimationName(enemyId)
	local config = EnemyConfig[enemyId]
	assert(config ~= nil, "invalid enemy id: "..tostring(enemyId))

	local names = config.AttackAnimation
	if #names == 1 then
		return names[1]
	end

	local randInt = Helper.RandInt(1, #names)
	return names[randInt]
end

function ConfigUtils.GetEnemyAppearConditions(enemyId)
	local config = EnemyConfig[enemyId]
	assert(config ~= nil, "invalid enemy id: "..tostring(enemyId))

	return config.AppearCondition or {}
end

function ConfigUtils.GetEnemyAttackText(enemyId)
	local config = EnemyConfig[enemyId]
	assert(config ~= nil, "invalid enemy id: "..tostring(enemyId))
	return config.AttackText
end

function ConfigUtils.GetHpBarHeightWithEnemy(enemyId)
	local config = EnemyConfig[enemyId]
	assert(config ~= nil, "invalid enemy id: "..tostring(enemyId))
	return config.HPBarHeight
end

function ConfigUtils.GetPetOfEnemy(enemyId)
	local config = EnemyConfig[enemyId]
	assert(config ~= nil, "invalid enemy id: "..tostring(enemyId))
	return config.PetID
end
--------------------------------------------------------------------
function ConfigUtils.GetPetSortId(petId)
	local config = PetConfig[petId]
	assert(config ~= nil, "invalid pet id: "..tostring(petId))

	return config.Id
end

function ConfigUtils.GetZooPetInfo(petId)
	local config = PetConfig[petId]
	assert(config ~= nil, "invalid pet id: "..tostring(petId))

	return {speed = config.ZooSpeed, scale = config.ZooScale, animScale = config.ZooAnimationScale}
end

function ConfigUtils.GetPetName(petId)
	local config = PetConfig[petId]
	assert(config ~= nil, "invalid pet id: "..tostring(petId))

	return SAFE_LOC(config.Name)
end

function ConfigUtils.GetPetDesc(petId)
	local config = PetConfig[petId]
	assert(config ~= nil, "invalid pet id: "..tostring(petId))

	return SAFE_LOC(config.Desc)
end

function ConfigUtils.GetPetRarity(petId)
	local config = PetConfig[petId]
	assert(config ~= nil, "invalid pet id: "..tostring(petId))

	return config.Rarity
end

function ConfigUtils.GetPetElement(petId)
	local config = PetConfig[petId]
	assert(config ~= nil, "invalid pet id: "..tostring(petId))

	return config.Element
end

function ConfigUtils.GetPetStyle(petId)
	local config = PetConfig[petId]
	assert(config ~= nil, "invalid pet id: "..tostring(petId))

	return config.Style
end

function ConfigUtils.GetPetIcon(petId)
	local config = PetConfig[petId]
	assert(config ~= nil, "invalid pet id: "..tostring(petId))

	return config.IconName, config.IconAtlas, config.IconBundle
end

function ConfigUtils.GetPetPrefab(petId)
	local config = PetConfig[petId]
	assert(config ~= nil, "invalid pet id: "..tostring(petId))

	return config.PrefabName, config.PrefabBundle
end

function ConfigUtils.GetPetActivedSkillsAt(petId, level)
	local config = PetConfig[petId]
	assert(config ~= nil, "invalid pet id: "..tostring(petId))

	local skillList = config.SkillList or {}
	return this.GetActivedSkillsAt(skillList, level)
end

function ConfigUtils.GetPetSkillDescAt(petId, level)
	local config = PetConfig[petId]
	assert(config ~= nil, "invalid pet id: "..tostring(petId))

	local skillList = config.SkillList or {}
	return this.GetSkillDescAt(skillList, level)
end

function ConfigUtils.GetPetNextSkillDescAt(petId, level)
	local config = PetConfig[petId]
	assert(config ~= nil, "invalid pet id: "..tostring(petId))

	local skillList = config.SkillList or {}
	return this.GetNextSkillDescAt(skillList, level)
end

function ConfigUtils.IsPetHasSkill(petId)
	local config = PetConfig[petId]
	assert(config ~= nil, "invalid pet id: "..tostring(petId))

	return config.SkillList ~= nil and #config.SkillList > 0
end

function ConfigUtils.GetPetLevelByNum(petId, num)
	local config = PetConfig[petId]
	assert(config ~= nil, "invalid pet id: "..tostring(petId))

	local levelUpId = config.LevelUp
	local levels = PetLevelUpConfig[levelUpId].LevelUp

	-- full level
	if num > levels[#levels] then
		return #levels + 1
	end

	for idx = 1, #levels do
		if num <= levels[idx] then
			local level = idx
			local levelNum = levels[idx]
			local progressNum = num
			if idx > 1 then
				levelNum = levelNum - levels[idx - 1]
				progressNum = progressNum - levels[idx - 1]
			end

			return level, progressNum, levelNum + 1
		end
	end

	assert(false, "should not get here: "..tostring(petId).."; "..tostring(num))
end

function ConfigUtils.GetPetBaseAbilityList(petId)
	local config = PetConfig[petId]
	assert(config ~= nil, "invalid pet id: "..tostring(petId))
	return config.Ability
end

function ConfigUtils.IsMeleePet(petId)
	local elementList = this.GetPetElementList(petId)
	return Helper.TableContains(elementList, ElementType.Melee)
end

function ConfigUtils.GetPlanetAreaOfPet(petId)
	local config = PetConfig[petId]
	assert(config ~= nil, "invalid pet id: "..tostring(petId))

	return config.Area or {}
end

function ConfigUtils.IsPetFromArea(petId, areaId)
	local config = PetConfig[petId]
	assert(config ~= nil, "invalid pet id: "..tostring(petId))

	local areas = config.Area or {}
	for idx = 1, #areas do
		if areas[idx] == areaId then
			return true
		end
	end

	return false
end

function ConfigUtils.GetPetGallery(petId)
	local config = PetConfig[petId]
	assert(config ~= nil, "invalid pet id: "..tostring(petId))

	return config.Gallery
end

function ConfigUtils.GetPetPlanet(petId)
	local gallery = this.GetPetGallery(petId)
	return ConfigUtils.GetGalleryPlanet(gallery)
end

function ConfigUtils.GetPetCatchItemList(petId)
	local config = PetConfig[petId]
	assert(config ~= nil, "invalid pet id: "..tostring(petId))

	return config.CatchItemList or {}
end

function ConfigUtils.GetPetAttackText(petId)
	local config = PetConfig[petId]
	assert(config ~= nil, "invalid pet id: "..tostring(petId))
	return config.AttackText
end

function ConfigUtils.GetPetBattleResource(petId)
	local config = PetConfig[petId]
	assert(config ~= nil, "invalid pet id: "..tostring(petId))
	return config.BattleResource
end
---------------------------------------------------------------------

function ConfigUtils.PlanetSortFunc(idA, idB)
	if idA == nil or idB == nil then
		return false
	end

	local sortIdA = this.GetPlanetSortId(idA)
	local sortIdB = this.GetPlanetSortId(idB)

	return sortIdA < sortIdB
end

--------------------------------------------------------------
function ConfigUtils.GetCharactersOfGallery(galleryId)
	local ret = {}
	for k, v in pairs(CharacterConfig) do
		if v.Gallery == galleryId then
			table.insert(ret, k)
		end
	end

	return ret
end

function ConfigUtils.GetPetsOfGallery(galleryId)
	local ret = {}
	for k, v in pairs(PetConfig) do
		if this.GetPetGallery(k) == galleryId then
			table.insert(ret, k)
		end
	end

	return ret
end

--------------------------------------------------------------
-- character
function ConfigUtils.IsValidCharacter(characterId)
	if characterId == nil or characterId == INVALID_ID or characterId == 0 then
		return false
	end

	return CharacterConfig[characterId] ~= nil
end

function ConfigUtils.GetCharacterSortId(characterId)
	local config = CharacterConfig[characterId]
	assert(config ~= nil, "invalid character id: "..tostring(characterId))
	return config.Id
end

function ConfigUtils.GetCharacterRarity(characterId)
	local config = CharacterConfig[characterId]
	assert(config ~= nil, "invalid character id: "..tostring(characterId))
	return config.Rarity
end

function ConfigUtils.GetCharacterPrefab(characterId)
	local config = CharacterConfig[characterId]
	assert(config ~= nil, "invalid character id: "..tostring(characterId))
	return config.PrefabName, config.PrefabBundle
end

function ConfigUtils.GetCharacterName(characterId)
	local config = CharacterConfig[characterId]
	assert(config ~= nil, "invalid character id: "..tostring(characterId))
	return SAFE_LOC(config.Name)
end

function ConfigUtils.GetCharacterStageLimit(characterId)
	local config = CharacterConfig[characterId]
	assert(config ~= nil, "invalid character id: "..tostring(characterId))

	return #config.LevelCap
end

function ConfigUtils.GetCharacterMaxLevel(characterId)
	local config = CharacterConfig[characterId]
	assert(config ~= nil, "invalid character id: "..tostring(characterId))

	local maxStage = #config.LevelCap
	return config.LevelCap[maxStage].Level
end

function ConfigUtils.GetCharacterLevelLimitAtStage(characterId, stage)
	local config = CharacterConfig[characterId]
	assert(config ~= nil, "invalid character id: "..tostring(characterId))

	return config.LevelCap[stage].Level
end

function ConfigUtils.GetCharacterUpStageCost(characterId, stage)
	local config = CharacterConfig[characterId]
	assert(config ~= nil, "invalid character id: "..tostring(characterId))

	local goodsId = config.LevelCap[stage].Value
	local goodsNum = config.LevelCap[stage].Num

	return goodsId, goodsNum
end

function ConfigUtils.GetCharacterDesc(characterId)
	local config = CharacterConfig[characterId]
	assert(config ~= nil, "invalid character id: "..tostring(characterId))
	return SAFE_LOC(config.Desc)
end

function ConfigUtils.GetCharacterElement(characterId)
	local config = CharacterConfig[characterId]
	assert(config ~= nil, "invalid character id: "..tostring(characterId))

	return config.Element
end

function ConfigUtils.GetCharacterStyle(characterId)
	local config = CharacterConfig[characterId]
	assert(config ~= nil, "invalid character id: "..tostring(characterId))

	return config.Style
end

function ConfigUtils.GetCharacterGallery(characterId)
	local config = CharacterConfig[characterId]
	assert(config ~= nil, "invalid character id: "..tostring(characterId))

	return config.Gallery
end

function ConfigUtils.GetCharacterLevelUpId(characterId)
	local config = CharacterConfig[characterId]
	assert(config ~= nil, "invalid character id: "..tostring(characterId))

	return config.LevelUp
end

---获取角色的基础能力(8个)
---@param characterId 角色ID
function ConfigUtils.GetCharacterBaseAbilityList(characterId)
	local config = CharacterConfig[characterId]
	assert(config ~= nil, "invalid character id: "..tostring(characterId))
	return config.Ability
end

function ConfigUtils.GetCharacterBaseAbilityMap(characterId)
	local ret = {}

	local roleSkills = this.GetCharacterBaseAbilityList(characterId)
	for k, v in pairs(roleSkills) do
		ret[v.Value] = v.Base
	end

	return ret
end

function ConfigUtils.GetCharacterEquipmentList(characterId)
	local config = CharacterConfig[characterId]
	assert(config ~= nil, "invalid character id: "..tostring(characterId))

	return config.EquipmentList or {}
end

function ConfigUtils.GetCharacterSkinList(characterId)
	local config = CharacterConfig[characterId]
	assert(config ~= nil, "invalid character id: "..tostring(characterId))

	return config.SkinList or {}
end

function ConfigUtils.CharacterSkinSortFunc(idA, idB)
	if idA == nil or idB == nil then
		return false
	end
	local unlockedA = GameData.IsSkinUnlocked(idA)
	local unlockedB = GameData.IsSkinUnlocked(idB)
	if unlockedA ~= unlockedB then
		return unlockedA
	end
	return idA < idB
end

function ConfigUtils.GetSortedCharacterSkinList(characterId)
	local skinList = this.GetCharacterSkinList(characterId)
	table.sort(skinList, this.CharacterSkinSortFunc)
	return skinList
end

--获取角色所有的皮肤外观
function ConfigUtils.GetCharacterAppearanceList(characterId)
	local config = CharacterConfig[characterId]
	assert(config ~= nil, "invalid character id: "..tostring(characterId))

	local result = {}
	for _,v in ipairs(config.LevelCap) do
		if not table.Contains(result, v.Skin) then
			table.insert(result, v.Skin)
		end
	end
	for _,v in ipairs(config.SkinList) do
		table.insert(result, v)
	end
	return result
end

function ConfigUtils.GetCharacterSkillList(characterId)
	local config = CharacterConfig[characterId]
	assert(config ~= nil, "invalid character id: "..tostring(characterId))

	return config.SkillList or {}
end

function ConfigUtils.GetCharacterActivedSkillsAt(characterId, stage)
	local config = CharacterConfig[characterId]
	assert(config ~= nil, "invalid character id: "..tostring(characterId))

	local skillList = config.SkillList or {}
	return this.GetActivedSkillsAt(skillList, stage)
end

function ConfigUtils.GetCharacterSkillDescAt(characterId, stage)
	local config = CharacterConfig[characterId]
	assert(config ~= nil, "invalid character id: "..tostring(characterId))

	local skillList = config.SkillList or {}
	return this.GetSkillDescAt(skillList, stage)
end

function ConfigUtils.GetCharacterNextSkillDescAt(characterId, stage)
	local config = CharacterConfig[characterId]
	assert(config ~= nil, "invalid character id: "..tostring(characterId))

	local skillList = config.SkillList or {}
	return this.GetNextSkillDescAt(skillList, stage)
end

function ConfigUtils.IsCharacterHasSkill(characterId)
	local config = CharacterConfig[characterId]
	assert(config ~= nil, "invalid character id: "..tostring(characterId))

	return config.SkillList ~= nil and #config.SkillList > 0
end

function ConfigUtils.GetCharacterAttackText(characterId)
	local config = CharacterConfig[characterId]
	assert(config ~= nil, "invalid character id: "..tostring(characterId))
	return config.AttackText
end

function ConfigUtils.GetAllCharacters()
	local ret = {}

	for k, v in pairs(CharacterConfig) do
		table.insert(ret, k)
	end

	return ret
end

function ConfigUtils.GetDefaultSkinOfCharacter(characterId, stage)
	local config = CharacterConfig[characterId]
	assert(config ~= nil, "invalid character id: "..tostring(characterId))
	return config.LevelCap[stage].Skin
end

function ConfigUtils.GetCharacterExchangeCost(characterId)
	local config = CharacterConfig[characterId]
	assert(config ~= nil, "invalid character id: "..tostring(characterId))

	return config.Exchange
end

function ConfigUtils.GetCharacterRoom(characterId)
	local config = CharacterConfig[characterId]
	assert(config ~= nil, "invalid character id: "..tostring(characterId))

	return config.RoomPrefab
end

function ConfigUtils.ViewCharacterRoom(characterId)
	local config = CharacterConfig[characterId]
	assert(config ~= nil, "invalid character id: "..tostring(characterId))

	return config.RoomPieceView or false
end
--------------------------------------------------------------
-- room
function ConfigUtils.GetRoomPieces(roomName)
	local config = RoomConfig[roomName]
	assert(config ~= nil, "invalid room prefab name: "..tostring(roomName))

	return config.PieceList or {}
end

function ConfigUtils.GetRoomSkillList(roomName)
	local config = RoomConfig[roomName]
	assert(config ~= nil, "invalid room prefab name: "..tostring(roomName))

	local ret = {}

	if config.SkillList ~= nil then
		local skills = config.SkillList.Skill or {}
		for idx = 1, #skills do
			table.insert(ret, {id = skills[idx].Id, value = skills[idx].Value})
		end
	end

	return ret
end

function ConfigUtils.GetRoomSkillDesc(roomName)
	local config = RoomConfig[roomName]
	assert(config ~= nil, "invalid room prefab name: "..tostring(roomName))

	if config.SkillList == nil then
		return nil
	end

	local skills = config.SkillList.Skill or {}
	if #skills == 0 then
		return nil
	end

	local skillDesc = SAFE_LOC(config.SkillList.Desc)
	for idx = 1, #skills do
		local toReplace = string.format("{Value%d}", idx)
		skillDesc = Helper.StringFindAndReplace(skillDesc, toReplace, tostring(skills[idx].Value))
	end

	return skillDesc
end

function ConfigUtils.GetRoomPieceSortId(roomPieceId)
	local config = RoomPieceConfig[roomPieceId]
	assert(config ~= nil, "invalid room piece id: "..tostring(roomPieceId))

	return config.Id
end

function ConfigUtils.GetRoomPieceName(roomPieceId)
	local config = RoomPieceConfig[roomPieceId]
	assert(config ~= nil, "invalid room piece id: "..tostring(roomPieceId))

	return SAFE_LOC(config.Name)
end

function ConfigUtils.GetCharacterOfRoomPiece(roomPieceId)
	local config = RoomPieceConfig[roomPieceId]
	assert(config ~= nil, "invalid room piece id: "..tostring(roomPieceId))

	return config.Character
end

function ConfigUtils.GetRoomPieceDesc(roomPieceId)
	local config = RoomPieceConfig[roomPieceId]
	assert(config ~= nil, "invalid room piece id: "..tostring(roomPieceId))

	return SAFE_LOC(config.Desc)
end

function ConfigUtils.GetRoomPieceIcon(roomPieceId)
	local config = RoomPieceConfig[roomPieceId]
	assert(config ~= nil, "invalid room piece id: "..tostring(roomPieceId))

	return config.Icon, "FurnitureIcon"
end

function ConfigUtils.GetRoomPieceRarity(roomPieceId)
	local config = RoomPieceConfig[roomPieceId]
	assert(config ~= nil, "invalid room piece id: "..tostring(roomPieceId))

	return config.Rarity
end

function ConfigUtils.GetRoomPieceNode(roomPieceId)
	local config = RoomPieceConfig[roomPieceId]
	assert(config ~= nil, "invalid room piece id: "..tostring(roomPieceId))

	return config.Node
end

function ConfigUtils.GetDefaultRoomName()
	return "Room"
end

function ConfigUtils.GetRoomPiecesOfGallery(galleryId)
	local ret = {}

	for k, v in pairs(RoomPieceConfig) do
		if v.Gallery == galleryId then
			table.insert(ret, k)
		end
	end

	return ret
end

function ConfigUtils.GetRoomPiecesAbility(roomPieceId)
	local config = RoomPieceConfig[roomPieceId]
	assert(config ~= nil, "invalid room piece id: "..tostring(roomPieceId))

	return config.Ability or {}
end
--------------------------------------------------------------
function ConfigUtils.GetActivedSkillsAt(skillList, stage)
	skillList = skillList or {}

	local selectedIdx = nil
	local selectedStage = nil

	for idx = 1, #skillList do
		local thisStage = skillList[idx].Stage
		if thisStage <= stage then
			if selectedStage == nil or selectedStage < thisStage then
				selectedIdx = idx
				selectedStage = thisStage
			end
		end
	end

	local ret = {}
	if selectedIdx ~= nil then
		local skills = skillList[selectedIdx].Skill or {}
		for idx = 1, #skills do
			table.insert(ret, {id = skills[idx].Id, value = skills[idx].Value})
		end
	end

	return ret
end

function ConfigUtils.GetSkillDescAt(skillList, stage)
	skillList = skillList or {}

	local selectedIdx = nil
	local selectedStage = nil

	for idx = 1, #skillList do
		local thisStage = skillList[idx].Stage
		if thisStage <= stage then
			if selectedStage == nil or selectedStage < thisStage then
				selectedIdx = idx
				selectedStage = thisStage
			end
		end
	end

	if selectedIdx ~= nil then
		local skillListDesc = SAFE_LOC(skillList[selectedIdx].Desc)
		local valueList = {}
		local skills = skillList[selectedIdx].Skill or {}
		for idx = 1, #skills do
			local absValue = math.abs(skills[idx].Value)
			local toReplace = string.format("{Value%d}", idx)
			skillListDesc = Helper.StringFindAndReplace(skillListDesc, toReplace, tostring(absValue))

			toReplace = string.format("{Value%dDivide}", idx)
			absValue = absValue / 100
        	absValue = Helper.Round(absValue, 2)
			skillListDesc = Helper.StringFindAndReplace(skillListDesc, toReplace, tostring(absValue))
		end

		return skillListDesc
	end

	return nil
end

function ConfigUtils.GetNextSkillDescAt(skillList, stage)
	skillList = skillList or {}

	local selectedIdx = nil
	local selectedStage = nil

	for idx = 1, #skillList do
		local thisStage = skillList[idx].Stage
		if thisStage > stage then
			if selectedStage == nil or selectedStage > thisStage then
				selectedIdx = idx
				selectedStage = thisStage
			end
		end
	end

	if selectedIdx ~= nil then
		local skillListDesc = SAFE_LOC(skillList[selectedIdx].Desc)
		local valueList = {}
		local skills = skillList[selectedIdx].Skill or {}
		for idx = 1, #skills do
			local absValue = math.abs(skills[idx].Value)
			local toReplace = string.format("{Value%d}", idx)
			skillListDesc = Helper.StringFindAndReplace(skillListDesc, toReplace, tostring(absValue))

			toReplace = string.format("{Value%dDivide}", idx)
			absValue = absValue / 100
        	absValue = Helper.Round(absValue, 2)
			skillListDesc = Helper.StringFindAndReplace(skillListDesc, toReplace, tostring(absValue))
		end

		return skillListDesc
	end

	return nil
end
--------------------------------------------------------------
function ConfigUtils.ElementSortFunc(idA, idB)
	if idA == nil or idB == nil then
		return false
	end

	local valueA = ElementConfig[idA].Id
	local valueB = ElementConfig[idB].Id

	return valueA < valueB
end

function ConfigUtils.GetElementSortId(elementId)
	local config = ElementConfig[elementId]
	assert(config ~= nil, "invalid element id: "..tostring(elementId))

	return config.Id
end

function ConfigUtils.GetElementCode(elementId)
	local config = ElementConfig[elementId]
	assert(config ~= nil, "invalid element id: "..tostring(elementId))

	return config.Code
end

function ConfigUtils.GetElementIconWithStyle(elementId)
	local config = ElementConfig[elementId]
	assert(config ~= nil, "invalid element id: "..tostring(elementId))

	return config.Code
end

function ConfigUtils.GetActiveElementIcon(elementId, enable)
	enable = enable or true
	local config = ElementConfig[elementId]
	assert(config ~= nil, "invalid element id: "..tostring(elementId))

	return enable and config.Code .. "_enable" or config.Code .. "_disable"
end

function ConfigUtils.GetElementIconNoStyle(elementId)
	local config = ElementConfig[elementId]
	assert(config ~= nil, "invalid element id: "..tostring(elementId))

	return config.Code.."Icon"
end

function ConfigUtils.GetElementFactor(sourceElement, targetElement)
	local config = ElementConfig[sourceElement]
	assert(config ~= nil, "invalid source element id: "..tostring(sourceElement))

	local vsElements = config.VS or {}
	for vsIdx = 1, #vsElements do
		if vsElements[vsIdx].Value == targetElement then
			return vsElements[vsIdx].Num
		end
	end

	return 1
end

function ConfigUtils.GetAgainstElementOfElement(elementId)
	local config = ElementConfig[elementId]
	assert(config ~= nil, "invalid source element id: "..tostring(elementId))

	local vsElements = config.VS or {}
	local maxNum = nil
	local againstElementId = nil

	for vsIdx = 1, #vsElements do
		if maxNum == nil or vsElements[vsIdx].Num > maxNum then
			maxNum = vsElements[vsIdx].Num
			againstElementId = vsElements[vsIdx].Value
		end
	end

	assert(againstElementId ~= nil, "not found against element for: "..tostring(elementId))
	return againstElementId
end

function ConfigUtils.RandNewElement()
	local elements = {}
	for k, v in pairs(ElementConfig) do
		table.insert(elements, k)
	end

	local idx = Helper.RandInt(1, #elements)
	return elements[idx]
end
--------------------------------------------------------------
-- skill
function ConfigUtils.GetSkillSortId(skillId)
	local config = SkillConfig[skillId]
	assert(config ~= nil, "invalid skill id: "..tostring(skillId))
	return config.Id
end

function ConfigUtils.GetSkillName(skillId)
	local config = SkillConfig[skillId]
	assert(config ~= nil, "invalid skill id: "..tostring(skillId))
	return SAFE_LOC(config.Name)
end

function ConfigUtils.GetSkillDesc(skillId)
	local config = SkillConfig[skillId]
	assert(config ~= nil, "invalid skill id: "..tostring(skillId))
	return SAFE_LOC(config.Desc)
end

function ConfigUtils.IsSkillHasDialog(skillId)
	local config = SkillConfig[skillId]
	assert(config ~= nil, "invalid skill id: "..tostring(skillId))
	return config.Dialog ~= nil
end

function ConfigUtils.GetSkillDialog(skillId)
	local config = SkillConfig[skillId]
	assert(config ~= nil, "invalid skill id: "..tostring(skillId))
	return SAFE_LOC(config.Dialog)
end

function ConfigUtils.GetSkillEffectModule(skillId)
	local config = SkillConfig[skillId]
	assert(config ~= nil, "invalid skill id: "..tostring(skillId))
	return config.EffectModule
end

function ConfigUtils.GetSkillEffectCondition(skillId)
	local config = SkillConfig[skillId]
	assert(config ~= nil, "invalid skill id: "..tostring(skillId))
	return config.EffectCondition
end

function ConfigUtils.GetSkillEffectRange(skillId)
	local config = SkillConfig[skillId]
	assert(config ~= nil, "invalid skill id: "..tostring(skillId))
	return config.EffectRange
end

function ConfigUtils.GetSkillEffectParameter(skillId)
	local config = SkillConfig[skillId]
	assert(config ~= nil, "invalid skill id: "..tostring(skillId))
	return config.Effect
end

function ConfigUtils.GetSkillEffectAttribute(skillId)
	local config = SkillConfig[skillId]
	assert(config ~= nil, "invalid skill id: "..tostring(skillId))
	return config.Effect.EffectAttribute
end

function ConfigUtils.GetSkillEffectValue(skillId)
	local config = SkillConfig[skillId]
	assert(config ~= nil, "invalid skill id: "..tostring(skillId))
	return config.Effect.EffectValue
end

function ConfigUtils.GetSkillEffectBattleParameter(skillId)
	local config = SkillConfig[skillId]
	assert(config ~= nil, "invalid skill id: "..tostring(skillId))
	return config.BattleParameter
end

function ConfigUtils.IsSkillMultiCount(skillId)
	local config = SkillConfig[skillId]
	assert(config ~= nil, "invalid skill id: "..tostring(skillId))
	return config.MultiCount or false
end

function ConfigUtils.IsBattleRoundSkill(skillId)
	local config = SkillConfig[skillId]
	assert(config ~= nil, "invalid skill id: "..tostring(skillId))

	if config.BattleParameter ~= nil then
		if config.BattleParameter.StartRound ~= nil or 
		 	config.BattleParameter.IntervalRound ~= nil or 
		 	config.BattleParameter.Limited ~= nil then
			return true
		end
	end

	return false
end

function ConfigUtils.GetSkillEffectCalculateType(skillId)
	local config = SkillConfig[skillId]
	assert(config ~= nil, "invalid skill id: "..tostring(skillId))
	return config.Effect.CalculateType
end

function ConfigUtils.GetSkillEffectPrefab(skillId)
	local config = SkillConfig[skillId]
	assert(config ~= nil, "invalid skill id: "..tostring(skillId))
	return config.EffectPrefab
end
--------------------------------------------------------------
-- lab recipe
function ConfigUtils.GetLabRecipeSortId(recipeId)
	local config = LabRecipeConfig[recipeId]
	assert(config ~= nil, "invalid recipe id: "..tostring(recipeId))
	return config.SortId or 0
end

function ConfigUtils.GetCraftSourceOfLabRecipe(recipeId)
	local config = LabRecipeConfig[recipeId]
	assert(config ~= nil, "invalid recipe id: "..tostring(recipeId))
	
	local ret = {}
	for idx = 1, #config.CraftSource do
		local sourceId = config.CraftSource[idx].Value
		local sourceNum = config.CraftSource[idx].Num
		table.insert(ret, {id = sourceId, num = sourceNum})
	end
	return ret
end

function ConfigUtils.GetCraftSourceListOfLabRecipe(recipeId)
	local config = LabRecipeConfig[recipeId]
	assert(config ~= nil, "invalid recipe id: "..tostring(recipeId))

	local ret = {}
	for idx = 1, #config.CraftSource do
		local sourceId = config.CraftSource[idx].Value
		table.insert(ret, sourceId)
	end
	return ret
end

function ConfigUtils.GetLabRecipeName(recipeId)
	local config = LabRecipeConfig[recipeId]
	assert(config ~= nil, "invalid recipe id: "..tostring(recipeId))
	return SAFE_LOC(config.Name)
end

function ConfigUtils.GetLabRecipeIcon(recipeId)
	local config = LabRecipeConfig[recipeId]
	assert(config ~= nil, "invalid recipe id: "..tostring(recipeId))
	return config.Icon, config.IconAtlas, config.Bundle
end

function ConfigUtils.GetLabRecipeDesc(recipeId)
	local config = LabRecipeConfig[recipeId]
	assert(config ~= nil, "invalid recipe id: "..tostring(recipeId))
	return SAFE_LOC(config.Desc)
end

function ConfigUtils.GetLabRecipeCraftResult(recipeId)
	local config = LabRecipeConfig[recipeId]
	assert(config ~= nil, "invalid recipe id: "..tostring(recipeId))

	return config.CraftResult[1].Value
end

function ConfigUtils.IsNormalLabRecipe(recipeId)
	local config = LabRecipeConfig[recipeId]
	assert(config ~= nil, "invalid recipe id: "..tostring(recipeId))

	return config.Type == LabRecipeType.Normal
end

function ConfigUtils.GetLabRecipeType(recipeId)
	local config = LabRecipeConfig[recipeId]
	assert(config ~= nil, "invalid recipe id: "..tostring(recipeId))

	return config.Type
end

function ConfigUtils.GetLabRecipeSubType(recipeId)
	local config = LabRecipeConfig[recipeId]
	assert(config ~= nil, "invalid recipe id: "..tostring(recipeId))

	return config.SubType
end
--------------------------------------------------------------
-- goods
function ConfigUtils.GetGoodsSortId(goodsId)
	local config = GoodsConfig[goodsId]
	assert(config ~= nil, "invalid goods id: "..tostring(goodsId))
	return config.Id
end

function ConfigUtils.GetGoodsStorageSortId(goodsId)
	local config = GoodsConfig[goodsId]
	assert(config ~= nil, "invalid goods id: "..tostring(goodsId))
	return config.StorgeSortId or 0
end

function ConfigUtils.GetGoodsName(goodsId)
	local config = GoodsConfig[goodsId]
	assert(config ~= nil, "invalid goods id: "..tostring(goodsId))
	return SAFE_LOC(config.Name)
end

function ConfigUtils.GetGoodsDesc(goodsId)
	local config = GoodsConfig[goodsId]
	assert(config ~= nil, "invalid goods id: "..tostring(goodsId))
	return SAFE_LOC(config.Desc)
end

function ConfigUtils.GetGoodsIcon(goodsId)
	local config = GoodsConfig[goodsId]
	assert(config ~= nil, "invalid goods id: "..tostring(goodsId))
	return config.Icon, config.IconAtlas
end

function ConfigUtils.GetGoodsTypeIcon(goodsId)
	local config = GoodsConfig[goodsId]
	assert(config ~= nil, "invalid goods id: "..tostring(goodsId))
	return config.TypeIcon
end

function ConfigUtils.GetGoodsRarity(goodsId)
	local config = GoodsConfig[goodsId]
	assert(config ~= nil, "invalid goods id: "..tostring(goodsId))
	return config.Rarity
end

function ConfigUtils.GetGoodsSeniorLevel(goodsId)
	local config = GoodsConfig[goodsId]
	assert(config ~= nil, "invalid goods id: "..tostring(goodsId))
	return config.SeniorLevel
end

function ConfigUtils.GetGoodsSubType(goodsId)
	local config = GoodsConfig[goodsId]
	assert(config ~= nil, "invalid goods id: "..tostring(goodsId))

	return config.SubType
end

function ConfigUtils.GetGoodsLabRecipe(goodsId)
	local config = GoodsConfig[goodsId]
	assert(config ~= nil, "invalid goods id: "..tostring(goodsId))

	return config.Recipe
end

function ConfigUtils.GetGoodsCraftSource(goodsId)
	local config = GoodsConfig[goodsId]
	assert(config ~= nil, "invalid goods id: "..tostring(goodsId))

	return this.GetCraftSourceOfLabRecipe(config.Recipe)
end

function ConfigUtils.GetGoodsCraftSourceList(goodsId)
	local config = GoodsConfig[goodsId]
	assert(config ~= nil, "invalid goods id: "..tostring(goodsId))

	local ret = {}
	local recipeId = config.Recipe
	if recipeId ~= nil then
		ret = this.GetCraftSourceListOfLabRecipe(recipeId)
	end

	return ret
end

function ConfigUtils.GetAllCraftGoods()
	local ret = {}
	for goodsId, goodsInfo in pairs(GoodsConfig) do
		if goodsInfo.Recipe ~= nil then
			table.insert(ret, goodsId)
		end
	end

	return ret
end

function ConfigUtils.GetGoodsTamePrefab(goodsId)
    local config = GoodsConfig[goodsId]
    assert(config ~= nil, "invalid goods id: "..tostring(goodsId))
    return config.TamePrefab
end

function ConfigUtils.GetGoodsAddExploreTime(goodsId)
	local config = GoodsConfig[goodsId]
    assert(config ~= nil, "invalid goods id: "..tostring(goodsId))
    return config.ExploreTime or 0
end

function ConfigUtils.GetGoodsNameBG(goodsId)
	local subType = this.GetGoodsSubType(goodsId)
	if subType == GoodsSubType.CatchItem or subType == GoodsSubType.EventItem then
		return "ScreenLabel02"
	end

	return "ScreenLabel01"
end

function ConfigUtils.GetGoodsSkillList(goodsId)
	local config = GoodsConfig[goodsId]
    assert(config ~= nil, "invalid goods id: "..tostring(goodsId))

    local skills = config.Skill or {}
    local ret = {}
    for idx = 1, #skills do
    	local skillId = skills[idx].Id
    	local skillValue = skills[idx].Value

    	ret[idx] = {id = skillId, value = skillValue}
    end

    return ret
end

function ConfigUtils.GetGoodsOnlyOne(goodsId)
	local config = GoodsConfig[goodsId]
	assert(config ~= nil, "invalid goods id: "..tostring(goodsId))
	return config.OnlyOne
end

function ConfigUtils.IsGoodsFromArea(goodsId, planetAreaId)
	local config = GoodsConfig[goodsId]
    assert(config ~= nil, "invalid goods id: "..tostring(goodsId))

    local sources = config.From or {}
    for idx = 1, #sources do
    	if sources[idx].SourceType == SourceType.Explore then
    		local sourceAreas = sources[idx].Value or {}
    		if Helper.TableContains(sourceAreas, planetAreaId) then
    			return true
    		end
    	end
    end

    return false
end

-- SubType.Object and SubType.EventItem can be galleryed
function ConfigUtils.GetGalleryGoodsOfGallery(galleryId)
	local ret = {}

	for k, v in pairs(GoodsConfig) do
		if v.Gallery == galleryId and (v.SubType == GoodsSubType.Object or v.SubType == GoodsSubType.EventItem) then
			table.insert(ret, k)
		end
	end

	return ret
end
--------------------------------------------------------------
-- equipment
function ConfigUtils.GetEquipmentMaxLevel(equipId)
	local config = EquipmentConfig[equipId]
	assert(config ~= nil, "invalid equipment id: "..tostring(equipId))

	return #config.LevelList
end

function ConfigUtils.GetCharacterOfEquipment(equipId)
	local config = EquipmentConfig[equipId]
	assert(config ~= nil, "invalid equipment id: "..tostring(equipId))

	return config.Character
end

function ConfigUtils.GetEquipmentUnlockChallenge(equipId)
	local config = EquipmentConfig[equipId]
	assert(config ~= nil, "invalid equipment id: "..tostring(equipId))

	return config.NeedChallenge
end

function ConfigUtils.GetEquipmentInfoId(equipId, level)
	local config = EquipmentConfig[equipId]
	assert(config ~= nil, "invalid equipment id: "..tostring(equipId))
	return config.LevelList[level].Info
end

function ConfigUtils.GetEquipmentName(equipId, level)
	level = level or 1
	local infoId = this.GetEquipmentInfoId(equipId, level)
	local config = EquipmentInfoConfig[infoId]
	assert(config ~= nil, "invalid equipment info id: "..tostring(infoId).." from equipment: "..tostring(equipId))
	return SAFE_LOC(config.Name)
end

function ConfigUtils.GetEquipmentDesc(equipId, level)
	level = level or 1
	local infoId = this.GetEquipmentInfoId(equipId, level)
	local config = EquipmentInfoConfig[infoId]
	assert(config ~= nil, "invalid equipment info id: "..tostring(infoId).." from equipment: "..tostring(equipId))
	return SAFE_LOC(config.Desc)
end

function ConfigUtils.GetEquipmentRarity(equipId, level)
	level = level or 1
	local infoId = this.GetEquipmentInfoId(equipId, level)
	local config = EquipmentInfoConfig[infoId]
	assert(config ~= nil, "invalid equipment info id: "..tostring(infoId).." from equipment: "..tostring(equipId))
	return config.Rarity
end

function ConfigUtils.GetEquipmentIcon(equipId, level)
	level = level or 1
	local infoId = this.GetEquipmentInfoId(equipId, level)
	local config = EquipmentInfoConfig[infoId]
	assert(config ~= nil, "invalid equipment info id: "..tostring(infoId).." from equipment: "..tostring(equipId))
	return config.Icon, config.IconAtlas, config.IconBundle
end

---获得装备上的8个能力加成
---@param equipments 装备列表
function ConfigUtils.GetEquipmentAbilityMap(equipments)
	local ret = {}

	-- make sure all the equipments are unlocked
	equipments = equipments or {}

	for idx = 1, #equipments do
		local equipmentId = equipments[idx].id
		if this.IsValidItem(equipmentId) then
			local equipmentLevel = equipments[idx].level
			local config = EquipmentConfig[equipmentId]
			assert(config ~= nil, "invalid equipment id: "..tostring(equipmentId))

			local abilities = config.LevelList[equipmentLevel].Ability or {}

			for abilityIdx = 1, #abilities do
				local abilityId = abilities[abilityIdx].Value
				local addValue = abilities[abilityIdx].Num

				local preValue = ret[abilityId] or 0
				ret[abilityId] = preValue + addValue
			end
		end
	end

	return ret
end

function ConfigUtils.GetEquipmentSkillList(equipments)
	local ret = {}

	-- make sure all the equipments are unlocked
	equipments = equipments or {}

	for idx = 1, #equipments do
		local equipmentId = equipments[idx].id
		if this.IsValidItem(equipmentId) then
			local equipmentLevel = equipments[idx].level
			local config = EquipmentConfig[equipmentId]
			assert(config ~= nil, "invalid equipment id: "..tostring(equipmentId))

			local skills = config.LevelList[equipmentLevel].SkillList or {}

			for skillIdx = 1, #skills do
				table.insert(ret, {id = skills[skillIdx].Id, value = skills[skillIdx].Value})
			end
		end
	end

	return ret
end

function ConfigUtils.GetEquipmentUpgradeCost(equipId, equipmentLevel)
	local equipConfig = EquipmentConfig[equipId]
	assert(equipConfig ~= nil, "invalid equipment id: "..tostring(equipId))
	local upgradeId = equipConfig.UpgradeId

	local config = EquipmentUpgradeConfig[upgradeId]
	assert(config ~= nil, "invalid equipment upgrade id: "..tostring(upgradeId).."; from equipment: "..tostring(equipId))
	return config.LevelList[equipmentLevel].UpgradeCostList
end

function ConfigUtils.GetEquipmentAbilityAndSkillList(equipId)
	local config = EquipmentConfig[equipId]
	assert(config ~= nil, "invalid equipment id: "..tostring(equipId))

	local levelList = config.LevelList
	local map = {}
	local ret = {}
	for idx = 1, #levelList do
		local abilityList = levelList[idx].Ability
		for abilityIdx = 1, #abilityList do
			local abilityId = abilityList[abilityIdx].Value
			-- initial value
			local abilityValue = abilityList[abilityIdx].Num
			if map[abilityId] == nil then
				table.insert(ret, {id = abilityId, value = abilityValue, unlock = idx})
				map[abilityId] = 1
			end
		end
		
		local skillList = levelList[idx].SkillList or {}
		for skillIdx = 1, #skillList do
			local skillId = skillList[skillIdx].Id
			-- initial value
			local skillValue = skillList[skillIdx].Value
			if map[skillId] == nil then
				table.insert(ret, {id = skillId, value = skillValue, unlock = idx})
				map[skillId] = 1
			end
		end
	end

	return ret
end

function ConfigUtils.GetEquipmentAbilityValueAtLevel(equipId, level, abilityId)
	local config = EquipmentConfig[equipId]
	assert(config ~= nil, "invalid equipment id: "..tostring(equipId))
	local abilityList = config.LevelList[level].Ability
	for abilityIdx = 1, #abilityList do
		if abilityId == abilityList[abilityIdx].Value then
			return abilityList[abilityIdx].Num
		end
	end

	return 0
end

function ConfigUtils.GetEquipmentSkillValueAtLevel(equipId, level, skillId)
	local config = EquipmentConfig[equipId]
	assert(config ~= nil, "invalid equipment id: "..tostring(equipId))
	local skillList = config.LevelList[level].SkillList or {}
	for idx = 1, #skillList do
		if skillId == skillList[idx].Id then
			return skillList[idx].Value
		end
	end

	return 0
end
--------------------------------------------------------------
-- ability
function ConfigUtils.GetAbilityName(abilityId)
	local config = AbilityConfig[abilityId]
	assert(config ~= nil, "invalid ability id: "..tostring(abilityId))
	return SAFE_LOC(config.Name)
end

function ConfigUtils.GetAbilityDesc(abilityId)
	local config = AbilityConfig[abilityId]
	assert(config ~= nil, "invalid ability id: "..tostring(abilityId))
	return SAFE_LOC(config.Desc)
end

function ConfigUtils.GetAbilityIcon(abilityId)
	local config = AbilityConfig[abilityId]
	assert(config ~= nil, "invalid ability id: "..tostring(abilityId))
	return config.Icon
end

function ConfigUtils.GetAbilityBattlePrefab(abilityId)
	local config = AbilityConfig[abilityId]
	assert(config ~= nil, "invalid ability id: "..tostring(abilityId))
	return config.BattlePrefab
end

function ConfigUtils.GetAbilityPowerFactor(abilityId)
	local config = AbilityConfig[abilityId]
	assert(config ~= nil, "invalid ability id: "..tostring(abilityId))
	return config.FightPower
end
--------------------------------------------------------------
-- skin
function ConfigUtils.GetSkinUnlockChallenge(skinId)
	local config = SkinConfig[skinId]
	assert(config ~= nil, "no config for skin: "..tostring(skinId))
	return config.NeedChallenge
end

function ConfigUtils.GetSkinName(skinId)
	local config = SkinConfig[skinId]
	assert(config ~= nil, "no config for skin: "..tostring(skinId))
	return SAFE_LOC(config.Name)
end

function ConfigUtils.GetCharacterOfSkin(skinId)
	local config = SkinConfig[skinId]
	assert(config ~= nil, "no config for skin: "..tostring(skinId))
	return config.Character
end

function ConfigUtils.GetSkinNameInSpine(skinId)
	local config = SkinConfig[skinId]
	assert(config ~= nil, "no config for skin: "..tostring(skinId))
	return config.SkinName
end

function ConfigUtils.GetSkinCharacterIcon(skinId)
	local config = SkinConfig[skinId]
	assert(config ~= nil, "no config for skin: "..tostring(skinId))
	return config.Icon, config.IconAtlas, config.IconBundle
end

function ConfigUtils.GetSkinDesc(skinId, unlocked)
	local config = SkinConfig[skinId]
	assert(config ~= nil, "no config for skin: "..tostring(skinId))

	if unlocked then
		return SAFE_LOC(config.UnlockDesc)
	end
	
	return SAFE_LOC(config.LockDesc)
end

function ConfigUtils.GetSkinRarity(skinId)
	local config = SkinConfig[skinId]
	assert(config ~= nil, "no config for skin: "..tostring(skinId))
	return config.Rarity or 1
end

function ConfigUtils.IsDefaultSkin(skinId)
	local config = SkinConfig[skinId]
	assert(config ~= nil, "no config for skin: "..tostring(skinId))
	return config.Default or false
end

function ConfigUtils.GetSkinSkillDesc(skinId)
	local config = SkinConfig[skinId]
	assert(config ~= nil, "no config for skin: "..tostring(skinId))

	if config.SkillList ~= nil then
		local skillListDesc = SAFE_LOC(config.SkillList.Desc)
		local skills = config.SkillList.Skill or {}
		for idx = 1, #skills do
			local absValue = math.abs(skills[idx].Value)
			local toReplace = string.format("{Value%d}", idx)
			skillListDesc = Helper.StringFindAndReplace(skillListDesc, toReplace, tostring(absValue))

			toReplace = string.format("{Value%dDivide}", idx)
			absValue = absValue / 100
        	absValue = Helper.Round(absValue, 2)
			skillListDesc = Helper.StringFindAndReplace(skillListDesc, toReplace, tostring(absValue))
		end

		return skillListDesc
	end

	return ""
end

function ConfigUtils.GetSkinSkill(skinId)
	local config = SkinConfig[skinId]
	assert(config ~= nil, "no config for skin: "..tostring(skinId))
	
	local ret = {}

	if config.SkillList ~= nil then
		local skillList = config.SkillList.Skill or {}
		for idx = 1, #skillList do
			table.insert(ret, {id = skillList[idx].Id, value = skillList[idx].Value})
		end
	end

	return ret
end

function ConfigUtils.GetSkinsOfCharacter(characterId)
	local ret = {}

	for k, v in pairs(SkinConfig) do
		if v.Character == characterId then
			if not this.IsDefaultSkin(k) then
				table.insert(ret, k)
			end
		end
	end

	return ret
end

function ConfigUtils.IsCharacterHasSkin(characterId)
	for k, v in pairs(SkinConfig) do
		if v.Character == characterId then
			if not this.IsDefaultSkin(k) then
				return true
			end
		end
	end

	return false
end

function ConfigUtils.GetHpBarHeightWithSkin(skinId)
	local config = SkinConfig[skinId]
	assert(config ~= nil, "no config for skin: "..tostring(skinId))
	return config.HPBarHeight
end

function ConfigUtils.GetSkinBattleResource(skinId)
	local config = SkinConfig[skinId]
	assert(config ~= nil, "no config for skin: "..tostring(skinId))
	return config.BattleResource
end

function ConfigUtils.GetSkinAppearanceCost(skinId)
	local config = SkinConfig[skinId]
	assert(config ~= nil, "no config for skin: "..tostring(skinId))
	if not config.AppearanceCost then
		return 0, 0
	end
	return config.AppearanceCost.Id, config.AppearanceCost.Num
end

--------------------------------------------------------------
-- goal
function ConfigUtils.GetGoalConfig(goalId)
	local config = nil
	if this.IsSpaceTravelGoal(goalId) then
		config = SpaceTravelGoalConfig[goalId]
	else
		config = GoalConfig[goalId]
	end
	assert(config ~= nil, "invalid goal id: "..tostring(goalId))

	return config
end

function ConfigUtils.GetGoalType(goalId)
	local config = this.GetGoalConfig(goalId)
	return config.GoalType
end

function ConfigUtils.GetGoalName(goalId)
	local config = this.GetGoalConfig(goalId)
	return SAFE_LOC(config.Name)
end

function ConfigUtils.GetGoalTriggers(goalId)
	local config = this.GetGoalConfig(goalId)
	return config.GoalTrigger
end

function ConfigUtils.GetGoalConditions(goalId)
	local config = this.GetGoalConfig(goalId)
	return config.GoalCondition
end

function ConfigUtils.GetGoalReward(goalId)
	local config = this.GetGoalConfig(goalId)
	return config.Reward or {}
end

function ConfigUtils.GetPreGoalList(goalId)
	local config = this.GetGoalConfig(goalId)
	local preCondition = config.PreCondition or {}
	return preCondition.PreGoal or {}
end

function ConfigUtils.GetWeeklyGoalIcon(goalId)
	local config = this.GetGoalConfig(goalId)
	return config.Icon
end


function ConfigUtils.IsSubmitGoodsGoal(goalId)
	local config = this.GetGoalConfig(goalId)
	return Helper.TableContains(config.GoalTrigger, TriggerType.SubmitGoods)
end

function ConfigUtils.IsGoalOfCurrentCountType(goalId)
	local config = this.GetGoalConfig(goalId)
	local countType = config.GoalCondition[1].CountType
	return (countType == GoalCountType.Current)
end

function ConfigUtils.IsMainGoal(goalId)
	local config = GoalConfig[goalId]
	assert(config ~= nil, "no config for mission: "..tostring(goalId))
	return config.ShowFirst or false
end

function ConfigUtils.IsActivityGoal(goalId)
	local config = GoalConfig[goalId]
	assert(config ~= nil, "no config for mission: "..tostring(goalId))
	return config.GoalType == GoalType.Activity
end

function ConfigUtils.GetGoalPoolId(goalId)
	local config = GoalConfig[goalId]
	assert(config ~= nil, "no config for mission: "..tostring(goalId))
	return config.PoolId
end

function ConfigUtils.GetPostcardOfAchievementGoal(goalId)
	local config = GoalConfig[goalId]
	assert(config ~= nil, "no config for mission: "..tostring(goalId))
	assert(config.GoalType == GoalType.Achievement, "not achievement mission: "..tostring(goalId))

	return config.Postcard
end

function ConfigUtils.GetGalleryOfAchievementGoal(goalId)
	local postcard = this.GetPostcardOfAchievementGoal(goalId)
	assert(postcard ~= nil, "postcard of achievement goal can't be empty: "..tostring(goalId))
	return this.GetGalleryOfPostcard(postcard)
end

function ConfigUtils.IsSpaceTravelGoal(goalId)
	local itemType = this.GetItemTypeFromId(goalId)
	return itemType == ItemType.SpaceTravelGoal
end

function ConfigUtils.GetNewbieIdOfGoal(goalId)
	local config = GoalConfig[goalId]
	assert(config ~= nil, "no config for mission: "..tostring(goalId))

	return config.NewbieId
end
--------------------------------------------------------------
-- mission dialog
function ConfigUtils.GetGoalActiveDialog(goalId)
	local config = GoalConfig[goalId]
	assert(config ~= nil, "no config for mission: "..tostring(goalId))
	return config.ActiveDialog
end

function ConfigUtils.GetGoalFinishDialog(goalId)
	local config = GoalConfig[goalId]
	assert(config ~= nil, "no config for mission: "..tostring(goalId))
	return config.CompleteSpeech
end

function ConfigUtils.GetNextGoalDialog(goalDialogId)
	local config = StorySpeechConfig[goalDialogId]
	assert(config ~= nil, "no config for goal dialog: "..tostring(goalDialogId))
	return config.NextID
end

function ConfigUtils.GetGoalDialogShowInfo(goalDialogId)
	local config = StorySpeechConfig[goalDialogId]
	assert(config ~= nil, "no config for goal dialog: "..tostring(goalDialogId))

	local characterId = config.CharacterId
	local isLeft = (config.LeftIcon ~= nil)
	local characterName = nil
	local iconName = nil
	local iconAtlas = nil
	local iconBundle = nil
	if not ConfigUtils.IsValidItem(characterId) then
		if isLeft then
			iconName = config.LeftIcon
		else
			iconName = config.RightIcon
		end

		characterName = SAFE_LOC(config.CharName)
		iconAtlas = config.IconAtlas
		iconBundle = config.IconBundle
	else
		characterName = ConfigUtils.GetCharacterName(characterId)
		local skinId = ConfigUtils.GetDefaultSkinOfCharacter(characterId, 1)
		iconName, iconAtlas, iconBundle = ConfigUtils.GetSkinCharacterIcon(skinId)
	end

	return characterName, config.Text, isLeft, iconName, iconAtlas, iconBundle
end
--------------------------------------------------------------
function ConfigUtils.GetWorkShopSortId(workShopId)
	local config = WorkShopConfig[workShopId]
	assert(config ~= nil, "invalid work shop id: "..tostring(workShopId))
	return config.Id
end

function ConfigUtils.GetWorkShopName(workShopId)
	local config = WorkShopConfig[workShopId]
	assert(config ~= nil, "invalid work shop id: "..tostring(workShopId))
	return SAFE_LOC(config.Name)
end

function ConfigUtils.GetWorkShopExchangeDesc(workShopId)
	local config = WorkShopConfig[workShopId]
	assert(config ~= nil, "invalid work shop id: "..tostring(workShopId))
	return SAFE_LOC(config.QuickExchangeConfirmText)
end

function ConfigUtils.GetWorkShopExchangeCode(workShopId)
	local config = WorkShopConfig[workShopId]
	assert(config ~= nil, "invalid work shop id: "..tostring(workShopId))
	return config.QuickExchangeCode
end

function ConfigUtils.GetWorkShopIcon(workShopId)
	local config = WorkShopConfig[workShopId]
	assert(config ~= nil, "invalid work shop id: "..tostring(workShopId))
	return config.Icon, "WorkShop"
end


function ConfigUtils.GetWorkShopBossIcon(workShopId)
	local config = WorkShopConfig[workShopId]
	assert(config ~= nil, "invalid work shop id: "..tostring(workShopId))
	return config.BossIcon
end

function ConfigUtils.GetWorkShopPicture(workShopId)
	local config = WorkShopConfig[workShopId]
	assert(config ~= nil, "invalid work shop id: "..tostring(workShopId))
	return config.Picture
end

function ConfigUtils.GetWorkShopIconBG(workShopId)
	local config = WorkShopConfig[workShopId]
	assert(config ~= nil, "invalid work shop id: "..tostring(workShopId))
	return config.IconBG, config.Desk
end

function ConfigUtils.GetWorkShopBG(workShopId)
	local config = WorkShopConfig[workShopId]
	assert(config ~= nil, "invalid work shop id: "..tostring(workShopId))
	return config.BG
end

function ConfigUtils.GetWorkShopMaxLevel(workShopId)
	local config = WorkShopConfig[workShopId]
	assert(config ~= nil, "invalid work shop id: "..tostring(workShopId))

	return #config.LevelList
end

function ConfigUtils.GetWorkShopNumCapacity(workShopId, level)
	local config = WorkShopConfig[workShopId]
	assert(config ~= nil, "invalid work shop id: "..tostring(workShopId))

	return config.LevelList[level].NumCap
end

function ConfigUtils.GetWorkShopTopRank(workShopId, level)
	local config = WorkShopConfig[workShopId]
	assert(config ~= nil, "invalid work shop id: "..tostring(workShopId))

	return config.LevelList[level].TopRank
end

function ConfigUtils.GetWorkShopRankByAbilityMap(workShopId, level, abilityMap)
	local topRank = this.GetWorkShopTopRank(workShopId, level)
	local rankList = this.GetWorkShopRankList(workShopId)
	topRank = math.min(topRank, #rankList)
	
	for idx = topRank, 1, -1 do
		local rankInfo = rankList[idx]
		local needAttribute = rankInfo.NeedAttribute
		local match = true
		for abilityIdx = 1, #needAttribute do
			local abilityId = needAttribute[abilityIdx].Value
			local needAbilityValue = needAttribute[abilityIdx].Num
			local currentAbilityValue = abilityMap[abilityId] or 0
			if currentAbilityValue < needAbilityValue then
				match = false
				break
			end
		end

		if match then
			return idx
		end
	end

	assert(false, "should not get here, work shop: "..tostring(workShopId).."; level: "..tostring(level))
end

function ConfigUtils.GetWorkShopRealRankOfAbility(workShopId, abilityIdx, abilityValue)
	local rankList = this.GetWorkShopRankList(workShopId)
	local maxRank = #rankList
	
	for idx = maxRank, 1, -1 do
		local rankInfo = rankList[idx]
		local needAttribute = rankInfo.NeedAttribute
		local needAbilityValue = needAttribute[abilityIdx].Num
		if abilityValue >= needAbilityValue then
			return idx
		end
	end

	assert(false, "should not get here, work shop: "..tostring(workShopId))
end

function ConfigUtils.GetWorkShopRankList(workShopId)
	local config = WorkShopConfig[workShopId]
	assert(config ~= nil, "invalid work shop id: "..tostring(workShopId))

	return config.RankList
end

function ConfigUtils.GetWorkShopRewards(workShopId)
	local config = WorkShopConfig[workShopId]
	assert(config ~= nil, "invalid work shop id: "..tostring(workShopId))

	return config.RewardList
end

function ConfigUtils.GetWorkShopNewRewardsAtLevel(workShopId, level)
	local config = WorkShopConfig[workShopId]
	assert(config ~= nil, "invalid work shop id: "..tostring(workShopId))

	local ret = {}
	local rewardList = config.RewardList
	for idx = 1, #rewardList do
		if rewardList[idx].NeedLevel == level then
			table.insert(ret, rewardList[idx].Value)
		end
	end

	return ret
end

function ConfigUtils.IsItemFromWorkShop(workShopId, itemId)
	local config = WorkShopConfig[workShopId]
	assert(config ~= nil, "invalid work shop id: "..tostring(workShopId))

	local rewardList = config.RewardList
	for idx = 1, #rewardList do
		if itemId == rewardList[idx].Value then
			return true
		end
	end

	return false
end

function ConfigUtils.GetWorkShopUpgradeItems(workShopId, level)
	local config = WorkShopConfig[workShopId]
	assert(config ~= nil, "invalid work shop id: "..tostring(workShopId))

	return config.LevelList[level].UpgradeItemList or {}
end

function ConfigUtils.GetWorkShopMaxWorkTime(workShopId, level)
	local config = WorkShopConfig[workShopId]
	assert(config ~= nil, "invalid work shop id: "..tostring(workShopId))

	return config.LevelList[level].MaxWorkTime
end

function ConfigUtils.GetWorkShopList()
	local ret = {}

	for k, v in pairs(WorkShopConfig) do
		table.insert(ret, k)
	end

	return ret
end

function ConfigUtils.GetWorkShopDialogList(workShopId, characterNum)
	local config = WorkShopConfig[workShopId]
	assert(config ~= nil, "invalid work shop id: "..tostring(workShopId))

	return config.DialogList[characterNum]
end

function ConfigUtils.GetWorkShopNeedAbilityList(workShopId)
	local config = WorkShopConfig[workShopId]
	assert(config ~= nil, "invalid work shop id: "..tostring(workShopId))

	local ret = {}
	local rankList = config.RankList
	local needAttributes = rankList[1].NeedAttribute or {}

	for idx = 1, #needAttributes do
		ret[idx] = needAttributes[idx].Value
	end

	return ret
end
--------------------------------------------------------------
-- npc
function ConfigUtils.GetNpcList()
	local ret = {}

	for k, v in pairs(NpcConfig) do
		table.insert(ret, k)
	end

	return ret
end

function ConfigUtils.GetNpcSkin(npcId)
	local config = NpcConfig[npcId]
	assert(config ~= nil, "invalid npc id: "..tostring(npcId))

	return config.SkinName
end
--------------------------------------------------------------
-- token
function ConfigUtils.GetTokenName(tokenId)
	local config = TokenConfig[tokenId]
	assert(config ~= nil, "invalid token id: "..tostring(tokenId))

	return SAFE_LOC(config.Name)
end

function ConfigUtils.GetTokenDesc(tokenId)
	local config = TokenConfig[tokenId]
	assert(config ~= nil, "invalid token id: "..tostring(tokenId))

	return SAFE_LOC(config.Desc)
end

function ConfigUtils.GetTokenIcon(tokenId)
	local config = TokenConfig[tokenId]
	assert(config ~= nil, "invalid token id: "..tostring(tokenId))

	return config.Icon, "UIGeneral"
end

function ConfigUtils.GetTokenSummonPool(tokenId)
	local config = TokenConfig[tokenId]
	assert(config ~= nil, "invalid token id: "..tostring(tokenId))

	return config.SummonPool
end
--------------------------------------------------------------
-- summon
function ConfigUtils.GetSummonSortId(summonId)
	local config = SummonConfig[summonId]
	assert(config ~= nil, "invalid summon id: "..tostring(summonId))
	return config.Id
end

function ConfigUtils.GetSummonName(summonId)
	local config = SummonConfig[summonId]
	assert(config ~= nil, "invalid summon id: "..tostring(summonId))
	return SAFE_LOC(config.Name)
end

function ConfigUtils.IsEventSummon(summonId)
	local config = SummonConfig[summonId]
	assert(config ~= nil, "invalid summon id: "..tostring(summonId))
	return config.IsEvent or false
end

function ConfigUtils.GetSingleSummonCost(summonId)
	local config = SummonConfig[summonId]
	assert(config ~= nil, "invalid summon id: "..tostring(summonId))
	return config.SingleCost.Cost, config.SingleCost.NeedCount
end

function ConfigUtils.GetMultipleSummonCost(summonId)
	local config = SummonConfig[summonId]
	assert(config ~= nil, "invalid summon id: "..tostring(summonId))
	return config.MultipleCost.Cost, config.MultipleCost.NeedCount
end

function ConfigUtils.GetSingleSummonTokenCost(summonId)
	local config = SummonConfig[summonId]
	assert(config ~= nil, "invalid summon id: "..tostring(summonId))
	return config.SingleCost.TokenCost, config.SingleCost.NeedTokenCount
end

function ConfigUtils.GetMultipleSummonTokenCost(summonId)
	local config = SummonConfig[summonId]
	assert(config ~= nil, "invalid summon id: "..tostring(summonId))
	return config.MultipleCost.TokenCost, config.MultipleCost.NeedTokenCount
end

---获得抽奖奖池的物品(不重复)
---@param summonId 奖池ID
function ConfigUtils.GetSummonItems(summonId)
	local config = SummonConfig[summonId]
	assert(config ~= nil, "invalid summon id: "..tostring(summonId))

	local dropList = {}
	local itemMap = {}

	for k, v in pairs(config.PoolList) do
		local groupItems = v.GroupContent or {}
		for m = 1, #groupItems do
			local itemId = groupItems[m].Value
			if itemMap[itemId] == nil then
				table.insert(dropList, itemId)
				itemMap[itemId] = 1
			end
		end
	end

	return dropList
end

function ConfigUtils.GetNonEventSummonList()
	local data = {}

	for k, v in pairs(SummonConfig) do
		if not v.IsEvent then
			table.insert(data, {id = k})
		end
	end

	return data
end

function ConfigUtils.GetSummonIcon(summonId)
	local config = SummonConfig[summonId]
	assert(config ~= nil, "invalid summon id: "..tostring(summonId))
	return config.IconName
end

function ConfigUtils.GetSummonPrefab(summonId)
	local config = SummonConfig[summonId]
	assert(config ~= nil, "invalid summon id: "..tostring(summonId))
	return config.PrefabName
end

function ConfigUtils.GetSummonSlot(summonId)
	local config = SummonConfig[summonId]
	assert(config ~= nil, "invalid summon id: "..tostring(summonId))
	return config.PrefabSlot
end

---清空奖池给与的角色
---@param summonId 奖池ID
function ConfigUtils.GetSummonGiveCharacter(summonId)
	local config = SummonConfig[summonId]
	assert(config ~= nil, "invalid summon id: "..tostring(summonId))
	return config.GiveCharacter
end

--- 是否需要凑齐角色和家具才给与池地角色
--- 普通奖池要求角色，宠物，家具及道具都拥有才能领取池底角色，活动奖池玩家凑齐了池里的角色和家具就可以领取池底角色
---@param summonId 奖池ID
function ConfigUtils.IsSummonRewardCharacterAndRoomPieceOnly(summonId)
	local config = SummonConfig[summonId]
	assert(config ~= nil, "invalid summon id: "..tostring(summonId))
	return config.GiveCharacterByCharacterAndFurniture or false
end
-----------------------------------------------------------------
-- arena
function ConfigUtils.GetBattleListOfArena(arenaId)
	local config = ArenaConfig[arenaId]
	assert(config ~= nil, "invalid arena id: "..tostring(arenaId))

	return config.ArenaBattleList or {}
end

function ConfigUtils.GetArenaDesc(arenaId)
	local config = ArenaConfig[arenaId]
	assert(config ~= nil, "invalid arena id: "..tostring(arenaId))

	return SAFE_LOC(config.Desc)
end

function ConfigUtils.GetArenaBuffDesc(arenaId)
	local config = ArenaConfig[arenaId]
	assert(config ~= nil, "invalid arena id: "..tostring(arenaId))

	if config.BuffList ~= nil and config.BuffList.Desc ~= nil then
		local buffDesc = SAFE_LOC(config.BuffList.Desc)
		local buffs = config.BuffList.Buff
		for idx = 1, #buffs do
			local toReplace = string.format("{Value%d}", idx)
			buffDesc = Helper.StringFindAndReplace(buffDesc, toReplace, tostring(buffs[idx].Value))
		end

		return buffDesc
	end

	return nil
end

function ConfigUtils.GetArenaBuffList(arenaId)
	local config = ArenaConfig[arenaId]
	assert(config ~= nil, "invalid arena id: "..tostring(arenaId))

	if config.BuffList == nil then
		return {}
	end

	return config.BuffList.Buff or {}
end
-----------------------------------------------------------------
-- arena battle
function ConfigUtils.GetArenaBattleName(arenaBattleId)
	local config = ArenaBattleConfig[arenaBattleId]
	assert(config ~= nil, "invalid arena battle id: "..tostring(arenaBattleId))

	return SAFE_LOC(config.Name)
end

function ConfigUtils.GetArenaBattleIntroduction(arenaBattleId)
	local config = ArenaBattleConfig[arenaBattleId]
	assert(config ~= nil, "invalid arena battle id: "..tostring(arenaBattleId))

	return SAFE_LOC(config.IntroduceText)
end

function ConfigUtils.GetArenaBattleBG(arenaBattleId)
	local config = ArenaBattleConfig[arenaBattleId]
	assert(config ~= nil, "invalid arena battle id: "..tostring(arenaBattleId))

	return config.LevelBG, config.LevelAtlas, config.LevelBundle
end

function ConfigUtils.IsBossArenaBattle(arenaBattleId)
	local config = ArenaBattleConfig[arenaBattleId]
	assert(config ~= nil, "invalid arena battle id: "..tostring(arenaBattleId))

	return config.Boss
end

function ConfigUtils.GetArenaBattleNumCapacity(arenaBattleId)
	local config = ArenaBattleConfig[arenaBattleId]
	assert(config ~= nil, "invalid arena battle id: "..tostring(arenaBattleId))

	return config.NumCap
end

function ConfigUtils.GetArenaBattleDifficultyData(arenaBattleId)
	local config = ArenaBattleConfig[arenaBattleId]
	assert(config ~= nil, "invalid arena battle id: "..tostring(arenaBattleId))

	return config.Difficulty
end

function ConfigUtils.GetArenaBattleEnmeyListAt(arenaBattleId, difficulty)
	local config = ArenaBattleConfig[arenaBattleId]
	assert(config ~= nil, "invalid arena battle id: "..tostring(arenaBattleId))

	local ret = {}
	local enemyList = config.Difficulty[difficulty].Enemy or {}
	for idx = 1, #enemyList do
		ret[idx] = {id = enemyList[idx].Value, level = enemyList[idx].Level}
	end

	return ret
end

function ConfigUtils.GetArenaBattleLastEnmeyAt(arenaBattleId, difficulty)
	local config = ArenaBattleConfig[arenaBattleId]
	assert(config ~= nil, "invalid arena battle id: "..tostring(arenaBattleId))

	local enemyList = config.Difficulty[difficulty].Enemy
	local idx = #enemyList
	return enemyList[idx].Value, enemyList[idx].Level
end

function ConfigUtils.GetArenaBattleDesc(arenaBattleId)
	local config = ArenaBattleConfig[arenaBattleId]
	assert(config ~= nil, "invalid arena battle id: "..tostring(arenaBattleId))

	return SAFE_LOC(config.Desc)
end

function ConfigUtils.GetArenaBattleResultText(arenaBattleId)
	local config = ArenaBattleConfig[arenaBattleId]
	assert(config ~= nil, "invalid arena battle id: "..tostring(arenaBattleId))

	return SAFE_LOC(config.ResultText)
end

function ConfigUtils.GetArenaBattleDialog(arenaBattleId)
	local config = ArenaBattleConfig[arenaBattleId]
	assert(config ~= nil, "invalid arena battle id: "..tostring(arenaBattleId))

	return SAFE_LOC(config.Dialog)
end
-----------------------------------------------------------------
function ConfigUtils.GetArenaShopSortId(arenaShopId)
	local config = ArenaShopConfig[arenaShopId]
	assert(config ~= nil, "invalid arena shop id: "..tostring(arenaShopId))

	return config.Id
end

function ConfigUtils.GetArenaShopType(arenaShopId)
	local config = ArenaShopConfig[arenaShopId]
	assert(config ~= nil, "invalid arena shop id: "..tostring(arenaShopId))

	return config.Type
end

function ConfigUtils.GeArenaShopName(arenaShopId)
	local config = ArenaShopConfig[arenaShopId]
	assert(config ~= nil, "invalid arena shop id: "..tostring(arenaShopId))

	return SAFE_LOC(config.Name)
end

function ConfigUtils.GetArenaShopCost(arenaShopId)
	local config = ArenaShopConfig[arenaShopId]
	assert(config ~= nil, "invalid arena shop id: "..tostring(arenaShopId))

	return config.CostItem.Value, config.CostItem.Num
end

function ConfigUtils.GetArenaShopIcon(arenaShopId)
	local config = ArenaShopConfig[arenaShopId]
	assert(config ~= nil, "invalid arena shop id: "..tostring(arenaShopId))

	return config.Icon
end

function ConfigUtils.GetArenaShopSprite(arenaShopId)
	local config = ArenaShopConfig[arenaShopId]
	assert(config ~= nil, "invalid arena shop id: "..tostring(arenaShopId))

	return config.BlindBoxSprite
end

function ConfigUtils.GetArenaShopInfo(arenaShopId)
	local config = ArenaShopConfig[arenaShopId]
	assert(config ~= nil, "invalid arena shop id: "..tostring(arenaShopId))

	return config
end

function ConfigUtils.GetArenaShopValidItems(arenaShopId)
	local config = ArenaShopConfig[arenaShopId]
	assert(config ~= nil, "invalid arena shop id: "..tostring(arenaShopId))

	local ret = {}
	local itemList = config.ItemList or {}
	for idx = 1, #itemList do
		if itemList[idx].Active and itemList[idx].Num > 0 and itemList[idx].Weight > 0 then
			table.insert(ret, itemList[idx].Value)
		end
	end

	return ret
end

function ConfigUtils.GetArenaShops()
	local characterShops = {}
	local basicShops = {}
	local limitedShops = {}

	for k, v in pairs(ArenaShopConfig) do
		if v.Active and v.PoolId == nil then
			local shopType = v.Type
			if shopType == ArenaShopType.Character then
				table.insert(characterShops, k)
			else
				if v.WeeklyRefresh then
					table.insert(limitedShops, k)
				else
					table.insert(basicShops,k)
				end
			end
		end
	end

	return characterShops, basicShops, limitedShops
end

function ConfigUtils.GetArenaShopCostGoodsList()
	local ret = {}
	local goodsMap = {}
	for k, v in pairs(ArenaShopConfig) do
		local itemId = v.CostItem.Value
		local itemType = ConfigUtils.GetItemTypeFromId(itemId)
		if itemType == ItemType.Goods and goodsMap[itemId] == nil then
			goodsMap[itemId] = 1
			table.insert(ret, itemId)
		end
	end

	return ret
end

function ConfigUtils.GetActivityArenaShop(themeId)
	for k, v in pairs(ArenaShopConfig) do
		if v.Active and v.PoolId == themeId then
			return k
		end
	end

	return nil
end
-----------------------------------------------------------------
function ConfigUtils.GetDefaultActivityTheme()
	return ActivityThemeID.Id001
end

function ConfigUtils.GetActivityThemeBuildings(themeId)
	local config = ActivityThemeConfig[themeId]
	assert(config ~= nil, "invalid activity theme id: "..tostring(themeId))

	local ret = {}

	local buildingList = config.BuildingList or {}
	for k, v in pairs(buildingList) do
		local position = v.Pos
		ret[position] = v.Prefab
	end

	return ret
end

function ConfigUtils.GetActivityThemeSortId(themeId)
	local config = ActivityThemeConfig[themeId]
	assert(config ~= nil, "invalid activity theme id: "..tostring(themeId))

	return config.Id
end

function ConfigUtils.GetActivityThemeExplore(themeId)
	local config = ActivityThemeConfig[themeId]
	assert(config ~= nil, "invalid activity theme id: "..tostring(themeId))

	return config.Explore
end

function ConfigUtils.GetActivityThemePrefab(themeId)
	local config = ActivityThemeConfig[themeId]
	assert(config ~= nil, "invalid activity theme id: "..tostring(themeId))

	return config.ThemeRoomPrefab, config.ThemeRoomBundle
end

function ConfigUtils.GetActivityThemeTextureBundle(themeId)
	local config = ActivityThemeConfig[themeId]
	assert(config ~= nil, "invalid activity theme id: "..tostring(themeId))

	return config.TextureBundle
end

function ConfigUtils.GetActivityThemeCharacters(themeId)
	local config = ActivityThemeConfig[themeId]
	assert(config ~= nil, "invalid activity theme id: "..tostring(themeId))

	return config.ThemeRoomCharacter or {}
end

function ConfigUtils.GetActivityThemeName(themeId)
	local config = ActivityThemeConfig[themeId]
	assert(config ~= nil, "invalid activity theme id: "..tostring(themeId))

	return config.Name
end

function ConfigUtils.GetActivityThemeBattleTitle(themeId)
	local config = ActivityThemeConfig[themeId]
	assert(config ~= nil, "invalid activity theme id: "..tostring(themeId))

	return SAFE_LOC(config.BattleTitle)
end

function ConfigUtils.GetActivityThemeGameModule(themeId)
	local config = ActivityThemeConfig[themeId]
	assert(config ~= nil, "invalid activity theme id: "..tostring(themeId))

	return config.ActivityGameModule or EnumMiniGameModule.None
end

-- 活动签到是否可用
function ConfigUtils.IsValidActivitySignIn(themeId)
	local config = ActivityThemeConfig[themeId]
	assert(config ~= nil, "invalid activity theme id: "..tostring(themeId))
	return config.ActivityDailyLoginList ~= nil
end

function ConfigUtils.GetActivityThemeBGM(themeId)
	local config = ActivityThemeConfig[themeId]
	assert(config ~= nil, "invalid activity theme id: "..tostring(themeId))

	return config.ActivityBGM
end

function ConfigUtils.IsValidActivityTheme(themeId)
	if not ConfigUtils.IsValidItem(themeId) then
		return false
	end

	return ActivityThemeConfig[themeId] ~= nil
end

function ConfigUtils.GetActivityBattleList(themeId)
	local config = ActivityThemeConfig[themeId]
	assert(config ~= nil, "invalid activity theme id: "..tostring(themeId))

	return config.BattleList or {}
end

function ConfigUtils.CanExploreInActivityTheme(themeId)
	local exploreId = ConfigUtils.GetActivityThemeExplore(themeId)
	return ConfigUtils.IsValidItem(exploreId)
end

function ConfigUtils.CanBattleInActivityTheme(themeId)
	local battleList = ConfigUtils.GetActivityBattleList(themeId)
	return #battleList > 0
end

function ConfigUtils.GetActivityThemeList(strategy)
	local ret = {}

	for k, v in pairs(ActivityThemeConfig) do
		local themePrefab = v.ThemeRoomPrefab
		if themePrefab ~= nil and (strategy == nil or strategy(k) == true) then
			table.insert(ret, k)
		end 
	end

	return ret
end
-----------------------------------------------------------------
function ConfigUtils.GetActivityExploreName(exploreId)
	local config = ActivityExploreConfig[exploreId]
	assert(config ~= nil, "invalid activity explore id: "..tostring(exploreId))

	return SAFE_LOC(config.Name)
end

function ConfigUtils.GetActivityExploreStartScene(exploreId)
	local config = ActivityExploreConfig[exploreId]
	assert(config ~= nil, "invalid activity explore id: "..tostring(exploreId))

	return config.StartScene
end

function ConfigUtils.GetActivityExploreNumCapacity(exploreId)
	local config = ActivityExploreConfig[exploreId]
	assert(config ~= nil, "invalid activity explore id: "..tostring(exploreId))

	return config.NumCap
end

function ConfigUtils.GetActivityExploreEnemyList(exploreId)
	local config = ActivityExploreConfig[exploreId]
	assert(config ~= nil, "invalid activity explore id: "..tostring(exploreId))

	return config.LevelEnemy or {}
end

function ConfigUtils.GetActivityExploreBG(exploreId)
	local config = ActivityExploreConfig[exploreId]
	assert(config ~= nil, "invalid activity explore id: "..tostring(exploreId))

	return config.LevelBG, config.LevelAtlas, config.LevelBundle
end

function ConfigUtils.GetActivityExploreEventList(exploreId)
	local config = ActivityExploreConfig[exploreId]
	assert(config ~= nil, "invalid activity explore id: "..tostring(exploreId))

	return config.EventList or {}
end
-----------------------------------------------------------------
function ConfigUtils.GetActivityBattleName(battleId)
	local config = ActivityBattleConfig[battleId]
	assert(config ~= nil, "invalid activity battle id: "..tostring(battleId))

	return SAFE_LOC(config.Name)
end

function ConfigUtils.GetActivityBattleIntroduction(battleId)
	local config = ActivityBattleConfig[battleId]
	assert(config ~= nil, "invalid activity battle id: "..tostring(battleId))

	return SAFE_LOC(config.IntroduceText)
end

function ConfigUtils.GetActivityBattleDesc(battleId)
	local config = ActivityBattleConfig[battleId]
	assert(config ~= nil, "invalid activity battle id: "..tostring(battleId))

	return SAFE_LOC(config.Desc)
end

function ConfigUtils.GetActivityBattleStoryBG(battleId)
	local config = ActivityBattleConfig[battleId]
	assert(config ~= nil, "invalid activity battle id: "..tostring(battleId))

	return config.StoryBG, config.StoryAtlas, config.StoryBundle
end

function ConfigUtils.GetActivityBattleResultText(battleId)
	local config = ActivityBattleConfig[battleId]
	assert(config ~= nil, "invalid activity battle id: "..tostring(battleId))

	return SAFE_LOC(config.ResultText)
end

function ConfigUtils.GetActivityBattleDialog(battleId)
	local config = ActivityBattleConfig[battleId]
	assert(config ~= nil, "invalid activity battle id: "..tostring(battleId))

	if config.Dialog ~= nil then
		return SAFE_LOC(config.Dialog)
	end

	return nil
end

function ConfigUtils.GetActivityBattleNumCapacity(battleId)
	local config = ActivityBattleConfig[battleId]
	assert(config ~= nil, "invalid activity battle id: "..tostring(battleId))

	return config.NumCap
end

function ConfigUtils.GetActivityBattleRepeatLimit(battleId)
	local config = ActivityBattleConfig[battleId]
	assert(config ~= nil, "invalid activity battle id: "..tostring(battleId))

	return config.Limit
end

function ConfigUtils.GetActivityBattleRules(battleId)
	local config = ActivityBattleConfig[battleId]
	assert(config ~= nil, "invalid activity battle id: "..tostring(battleId))

	return config.TeamCondition or {}
end

function ConfigUtils.GetActivityBattleEnemyList(battleId)
	local config = ActivityBattleConfig[battleId]
	assert(config ~= nil, "invalid activity battle id: "..tostring(battleId))

	local ret = {}

	local enemyList = config.Enemy or {}
	for idx = 1, #enemyList do
		ret[idx] = {id = enemyList[idx].Value, level = enemyList[idx].Level}
	end

	return ret
end

function ConfigUtils.GetLastEnemyOfActivityBattle(battleId)
	local config = ActivityBattleConfig[battleId]
	assert(config ~= nil, "invalid activity battle id: "..tostring(battleId))

	local enemyList = config.Enemy
	local num = #enemyList
	return enemyList[num].Value, enemyList[num].Level
end

function ConfigUtils.GetActivityBattleSupportLevel(battleId)
	local config = ActivityBattleConfig[battleId]
	assert(config ~= nil, "invalid activity battle id: "..tostring(battleId))

	return config.SupportLevel or 0
end

function ConfigUtils.GetActivityBattleUnlockCost(battleId)
	local config = ActivityBattleConfig[battleId]
	assert(config ~= nil, "invalid activity battle id: "..tostring(battleId))

	return config.UnlockCostList or {}
end

function ConfigUtils.GetActivityBattleRepeatCost(battleId)
	local config = ActivityBattleConfig[battleId]
	assert(config ~= nil, "invalid activity battle id: "..tostring(battleId))

	return config.RepeatCostList or {}
end

function ConfigUtils.GetActivityBattleUnlockReward(battleId)
	local config = ActivityBattleConfig[battleId]
	assert(config ~= nil, "invalid activity battle id: "..tostring(battleId))

	return config.Reward or {}
end

function ConfigUtils.GetActivityBattleRepeatReward(battleId)
	local config = ActivityBattleConfig[battleId]
	assert(config ~= nil, "invalid activity battle id: "..tostring(battleId))

	return config.RepeatReward or {}
end

function ConfigUtils.GetActivityBattleBG(battleId)
	local config = ActivityBattleConfig[battleId]
	assert(config ~= nil, "invalid activity battle id: "..tostring(battleId))

	return config.LevelBG, config.LevelAtlas, config.LevelBundle
end

function ConfigUtils.GetActivityBattleStartScene(battleId)
	local config = ActivityBattleConfig[battleId]
	assert(config ~= nil, "invalid activity battle id: "..tostring(battleId))

	return config.StartScene
end

function ConfigUtils.GetActivityBattleAcceptSpeech(battleId)
	local config = ActivityBattleConfig[battleId]
	assert(config ~= nil, "invalid activity battle id: "..tostring(battleId))

	return config.AcceptSpeech
end
function ConfigUtils.GetActivityBattleSuccessSpeech(battleId)
	local config = ActivityBattleConfig[battleId]
	assert(config ~= nil, "invalid activity battle id: "..tostring(battleId))

	return config.SuccessSpeech
end
-----------------------------------------------------------------
-- work shop speech
function ConfigUtils.GetWorkShopSpeechPosition(speechId)
	local config = WorkShopSpeechConfig[speechId]
	assert(config ~= nil, "invalid summon speech id: "..tostring(speechId))
	return config.Position
end

function ConfigUtils.GetWorkShopSpeechText(speechId)
	local config = WorkShopSpeechConfig[speechId]
	assert(config ~= nil, "invalid summon speech id: "..tostring(speechId))
	return SAFE_LOC(config.Text)
end

function ConfigUtils.GetChainListOfWorkShopSpeech(speechId)
	local ret = {}

	local nextSpeech = speechId
	while nextSpeech ~= nil do
		table.insert(ret, nextSpeech)
		nextSpeech = WorkShopSpeechConfig[nextSpeech].NextID
	end

	return ret
end
-----------------------------------------------------------------
-- event
function ConfigUtils.GetEventSortId(eventId)
	local config = EventConfig[eventId]
	assert(config ~= nil, "invalid event id: "..tostring(eventId))

	return config.Id
end

function ConfigUtils.GetEventName(eventId)
	local config = EventConfig[eventId]
	assert(config ~= nil, "invalid event id: "..tostring(eventId))

	return SAFE_LOC(config.Name)
end

function ConfigUtils.GetEventDesc(eventId)
	local config = EventConfig[eventId]
	assert(config ~= nil, "invalid event id: "..tostring(eventId))

	return SAFE_LOC(config.Desc)
end

function ConfigUtils.GetEventLockDesc(eventId)
	local config = EventConfig[eventId]
	assert(config ~= nil, "invalid event id: "..tostring(eventId))

	return SAFE_LOC(config.LockDesc)
end

function ConfigUtils.GetUnlockAreaOfEvent(eventId)
	local config = EventConfig[eventId]
	assert(config ~= nil, "invalid event id: "..tostring(eventId))

	return config.Area
end

function ConfigUtils.GetEventIcon(eventId)
	local config = EventConfig[eventId]
	assert(config ~= nil, "invalid event id: "..tostring(eventId))

	return config.Icon, config.Atlas, config.Bundle
end

function ConfigUtils.GetEventReward(eventId)
	local config = EventConfig[eventId]
	assert(config ~= nil, "invalid event id: "..tostring(eventId))

	return config.Reward or {}
end

function ConfigUtils.GetEventList(galleryId)
	local ret = {}

	for k, v in pairs(EventConfig) do
		if galleryId == v.Gallery then
			table.insert(ret, k)
		end
	end

	return ret
end
-----------------------------------------------------------------
-- postcard
function ConfigUtils.GetPostcardSortId(cardId)
	local config = PostcardConfig[cardId]
	assert(config ~= nil, "invalid postcard id: "..tostring(cardId))

	return config.Id
end

function ConfigUtils.GetPostcardName(cardId)
	local config = PostcardConfig[cardId]
	assert(config ~= nil, "invalid postcard id: "..tostring(cardId))

	return SAFE_LOC(config.Name)
end

function ConfigUtils.GetPostcardDesc(cardId)
	local config = PostcardConfig[cardId]
	assert(config ~= nil, "invalid postcard id: "..tostring(cardId))

	return SAFE_LOC(config.Desc)
end

function ConfigUtils.GetPostcardIcon(cardId)
	local config = PostcardConfig[cardId]
	assert(config ~= nil, "invalid postcard id: "..tostring(cardId))

	return config.Icon, config.IconAtlas, config.IconBundle
end

function ConfigUtils.GetPostcardSignature(cardId)
	local config = PostcardConfig[cardId]
	assert(config ~= nil, "invalid postcard id: "..tostring(cardId))

	return SAFE_LOC(config.Signature)
end

function ConfigUtils.GetGoalOfPostcard(cardId)
	local config = PostcardConfig[cardId]
	assert(config ~= nil, "invalid postcard id: "..tostring(cardId))

	return config.GoalId
end

function ConfigUtils.GetGalleryOfPostcard(cardId)
	local config = PostcardConfig[cardId]
	assert(config ~= nil, "invalid postcard id: "..tostring(cardId))

	return config.Gallery
end

function ConfigUtils.GetPostcardList(galleryId)
	local ret = {}

	for k, v in pairs(PostcardConfig) do
		if galleryId == v.Gallery then
			table.insert(ret, k)
		end
	end

	return ret
end

---获取明星片类型
---@param cardId id
---@return 类型 -1,成就; 2,活动
function ConfigUtils.GetPostcardType(cardId)
	local config = PostcardConfig[cardId]
	assert(config ~= nil, "invalid postcard id: "..tostring(cardId))
	return config.Type
end
-----------------------------------------------------------------
function ConfigUtils.GetCoupleSortId(coupleId)
	local config = CoupleConfig[coupleId]
	assert(config ~= nil, "invalid couple id: "..tostring(coupleId))

	return config.Id
end

function ConfigUtils.GetCoupleName(coupleId)
	local config = CoupleConfig[coupleId]
	assert(config ~= nil, "invalid couple id: "..tostring(coupleId))
	return SAFE_LOC(config.Name)
end

function ConfigUtils.GetCoupleDesc(coupleId)
	local config = CoupleConfig[coupleId]
	assert(config ~= nil, "invalid couple id: "..tostring(coupleId))
	return SAFE_LOC(config.Desc)
end

function ConfigUtils.GetCouplePrefabName(coupleId)
	local config = CoupleConfig[coupleId]
	assert(config ~= nil, "invalid couple id: "..tostring(coupleId))

	return config.PrefabName, config.PrefabBundle
end

function ConfigUtils.GetCoupleNodes(coupleId)
	local config = CoupleConfig[coupleId]
	assert(config ~= nil, "invalid couple id: "..tostring(coupleId))

	return config.TypeNode or {}
end

function ConfigUtils.GetCoupleSkillDesc(coupleId)
	local config = CoupleConfig[coupleId]
	assert(config ~= nil, "invalid couple id: "..tostring(coupleId))

	if config.SkillList == nil or config.SkillList.Desc == nil then
		return ""
	end

	local skillListDesc = SAFE_LOC(config.SkillList.Desc)
	local skills = config.SkillList.Skill or {}
	for idx = 1, #skills do
		local absValue = math.abs(skills[idx].Value)
		local toReplace = string.format("{Value%d}", idx)
		skillListDesc = Helper.StringFindAndReplace(skillListDesc, toReplace, tostring(absValue))

		toReplace = string.format("{Value%dDivide}", idx)
		absValue = absValue / 100
        absValue = Helper.Round(absValue, 2)
		skillListDesc = Helper.StringFindAndReplace(skillListDesc, toReplace, tostring(absValue))
	end

	return skillListDesc
end

function ConfigUtils.GetCoupleSkillList(coupleId)
	local config = CoupleConfig[coupleId]
	assert(config ~= nil, "invalid couple id: "..tostring(coupleId))

	if config.SkillList == nil then
		return {}
	end

	return config.SkillList.Skill or {}
end

function ConfigUtils.GetCoupleConditions(coupleId)
	local config = CoupleConfig[coupleId]
	assert(config ~= nil, "invalid couple id: "..tostring(coupleId))

	return config.CharacterList or {}
end

function ConfigUtils.GetMatchedCoupleList(nodeKey)
	local ret = {}

	for k, v in pairs(CoupleConfig) do
		if nodeKey ~= nil and v.TypeNode ~= nil and v.TypeNode[nodeKey] ~= nil then
			table.insert(ret, k)
		end
	end

	return ret
end

function ConfigUtils.GetCouplesOfGallery(galleryId)
	local ret = {}

	for k, v in pairs(CoupleConfig) do
		if galleryId == nil or v.Gallery == galleryId then
			table.insert(ret, k)
		end
	end

	return ret
end
-----------------------------------------------------------------
function ConfigUtils.GetDemandGroupSortId(groupId)
	local config = DemandGroupConfig[groupId]
	assert(config ~= nil, "invalid demand group id: "..tostring(groupId))

	return config.Id
end

function ConfigUtils.GetDemandName(demandId)
	local config = DemandConfig[demandId]
	assert(config ~= nil, "invalid demand id: "..tostring(demandId))

	return SAFE_LOC(config.Name)
end

function ConfigUtils.GetDemandDesc(demandId)
	local config = DemandConfig[demandId]
	assert(config ~= nil, "invalid demand id: "..tostring(demandId))

	return SAFE_LOC(config.Desc)
end

function ConfigUtils.GetDemandNeedItem(demandId)
	local config = DemandConfig[demandId]
	assert(config ~= nil, "invalid demand id: "..tostring(demandId))

	return config.Value, config.Num
end
-----------------------------------------------------------------
function ConfigUtils.GetTouristDesc(touristId)
	local config = TouristConfig[touristId]
	assert(config ~= nil, "invalid tourist id: "..tostring(touristId))

	return SAFE_LOC(config.Desc)
end

function ConfigUtils.GetTouristResultPrefix(touristId)
	local config = TouristConfig[touristId]
	assert(config ~= nil, "invalid tourist id: "..tostring(touristId))

	return SAFE_LOC(config.ResultText)
end

function ConfigUtils.GetRankOfTourist(touristId, score)
	local config = TouristConfig[touristId]
	assert(config ~= nil, "invalid tourist id: "..tostring(touristId))

	local rank = #config.RewardList
	for idx = 1, #config.RewardList do
		if score >= config.RewardList[idx].Score then
			rank = idx
			break
		end
	end

	return rank, config.RewardList[rank]
end

function ConfigUtils.GetTouristComment(touristId, rank, score)
	local config = TouristConfig[touristId]
	assert(config ~= nil, "invalid tourist id: "..tostring(touristId))

	local rankList = config.RankTextList[rank]

	local descList = rankList.DescList
	local desc = descList[#descList].Desc
	for idx = 1, #descList do
		if score >= descList[idx].NeedScore then
			desc = descList[idx].Desc
			break
		end
	end

	return rankList.CommentatorName, rankList.CommentatorInfo, desc, rankList.Icon, rankList.Atlas, rankList.Bundle
end
--------------------------------------------------------------
-- level-up cost
function ConfigUtils.GetLevelUpCostByLevel(characterId, from, to)
	to = to or from + 1

	local levelUpId = ConfigUtils.GetCharacterLevelUpId(characterId)
	local upCost = LevelUpConfig[levelUpId].LevelUpCost

	local cost = 0
	for level = from, to - 1 do
		cost = cost + upCost[level]
	end
	
	return cost
end
--------------------------------------------------------------
-- tutorial
function ConfigUtils.GetTutorialInfo(tutorialId)
	if type(tutorialId) == "string" then
		local config = TutorialConfig[tutorialId]
		if not config then
			assert(config ~= nil, "invalid tutorial id: ".. tostring(tutorialId))
		end
		return config.Branch, config.Step
	else
		local config = TutorialExConfig[tutorialId]
		if not config then
			assert(config ~= nil, "invalid tutorial extra id: ".. tostring(tutorialId))
		end
		return tutorialId, 1
	end
	return nil
end
-- tutorial ex
function ConfigUtils.GetTutorialExInfo(tutorialId)
	local config = TutorialExConfig[tutorialId]
	if not config then
		XDebug.Error("invalid tutorialex id: "..tostring(tutorialId))
		return nil
	end
	return config[tutorialId]
end
--------------------------------------------------------------
-- module
function ConfigUtils.GetModuleUnlockGoal(moduleName)
	for k, v in pairs(ModulesUnlockConfig) do
		if v.Name == moduleName then
			return v.Unlock
		end
	end

	return nil
end

function ConfigUtils.GetUnlockModuleByGoal(goalId)
	for k, v in pairs(ModulesUnlockConfig) do
		if v.Unlock == goalId and v.ShowUnlock then
			return k
		end
	end

	return nil
end

function ConfigUtils.GetModuleUnlockText(moduleId)
	local config = ModulesUnlockConfig[moduleId]
	assert(config ~= nil, "invalid module id: "..tostring(moduleId))
	return SAFE_LOC(config.Text)
end

function ConfigUtils.GetModuleIcon(moduleId)
	local config = ModulesUnlockConfig[moduleId]
	assert(config ~= nil, "invalid module id: "..tostring(moduleId))
	return config.Icon, config.IconAtlas
end

function ConfigUtils.GetIsInternalModule(moduleId)
	local config = ModulesUnlockConfig[moduleId]
	assert(config ~= nil, "invalid module id: "..tostring(moduleId))
	return config.IsInternal >= 1
end

function ConfigUtils.GetModuleUnlockAppName(moduleId)
	local config = ModulesUnlockConfig[moduleId]
	assert(config ~= nil, "invalid module id: "..tostring(moduleId))
	return SAFE_LOC(config.AppName)
end

function ConfigUtils.GetUnlockAppList()
	local list = {}
	for k, v in pairs(ModulesUnlockConfig) do
		if v.IsApp then
			local isUnlock = GameData.IsModuleUnlocked(v.Name)
			if isUnlock then
				table.insert(list, k)
			end
		end
	end
	return list
end

function ConfigUtils.GetModuleUnlockAppSortId(moduleId)
	local config = ModulesUnlockConfig[moduleId]
	assert(config ~= nil, "invalid module id: "..tostring(moduleId))
	return config.SortId or 0
end

function ConfigUtils.GetModuleUnlockName(moduleId)
	local config = ModulesUnlockConfig[moduleId]
	assert(config ~= nil, "invalid module id: "..tostring(moduleId))
	return config.Name
end
--------------------------------------------------------------
function ConfigUtils.GetSignInReward(day)
	assert(day <= #DailyLoginConfig, "exceed the max days: "..tostring(day).."/"..tostring(#DailyLoginConfig))

	if day > #DailyLoginConfig then
		return nil
	end

	return DailyLoginConfig[day].Value, DailyLoginConfig[day].Min, DailyLoginConfig[day].Max, DailyLoginConfig[day].IconBG
end
--------------------------------------------------------------
function ConfigUtils.GetCurrentChannelStoreKey()
	local storeKey = nil

	if Global.ChannelId == GameChannels.APPSTORE then
		storeKey = "ios"
	elseif Global.ChannelId == GameChannels.ANDROID_TENCENT then
		storeKey = "tencent"
	end

	return storeKey
end

--IAP商店显示的IAP列表
function ConfigUtils.GetIapList()
	local ret = {}

	for k, v in pairs(IAPConfig) do
		if v.Type == IAPType.Normal or v.Type == IAPType.MonthCard then
			table.insert(ret, k)
		end
	end
	
	return ret
end

--- 玉璧商城内购列表
function ConfigUtils.GetDiamondIapList()
	local ret = {}
	for k, v in pairs(IAPConfig) do
		if v.Type == IAPType.Normal then
			table.insert(ret, k)
		end
	end
	return ret
end

function ConfigUtils.GetMonthCardIapList()
	local ret = {}
	for k, v in pairs(IAPConfig) do
		if v.Type == IAPType.MonthCard then
			table.insert(ret, k)
		end
	end
	return ret
end

function ConfigUtils.GetIapSortId(iapId)
	local config = IAPConfig[iapId]
	assert(config ~= nil, "invalid iap id: "..tostring(iapId))

	return config.Id
end

function ConfigUtils.GetIapStoreId(iapId)
	local config = IAPConfig[iapId]
	assert(config ~= nil, "invalid iap id: "..tostring(iapId))

	local storeKey = this.GetCurrentChannelStoreKey()
	return config.StoreId[storeKey]
end

function ConfigUtils.GetIapInfo(iapId)
	local config = IAPConfig[iapId]
	assert(config ~= nil, "invalid iap id: "..tostring(iapId))

	return SAFE_LOC(config.Name), SAFE_LOC(config.Desc), SAFE_LOC(config.ButtonDesc), config.Icon
end

function ConfigUtils.GetIapType(iapId)
	local config = IAPConfig[iapId]
	assert(config ~= nil, "invalid iap id: "..tostring(iapId))
	return config.Type
end

function ConfigUtils.GetIapName(iapId)
	local config = IAPConfig[iapId]
	assert(config ~= nil, "invalid iap id: "..tostring(iapId))

	return SAFE_LOC(config.Name)
end

function ConfigUtils.GetIapPrice(iapId)
	local config = IAPConfig[iapId]
	assert(config ~= nil, "invalid iap id: "..tostring(iapId))

	return config.Price
end

function ConfigUtils.GetIapRate(iapId)
	local config = IAPConfig[iapId]
	assert(config ~= nil, "invalid iap id: "..tostring(iapId))

	return config.Rate or 0
end

function ConfigUtils.GetIapRewardDiamond(iapId)
	local config = IAPConfig[iapId]
	assert(config ~= nil, "invalid iap id: "..tostring(iapId))
	for i,v in ipairs(config.Rewards) do
		if v.Value == ItemType.Diamond then
			return v.Num
		end
	end
	return 0
end

function ConfigUtils.IsDoubleIap(iapId)
	local config = IAPConfig[iapId]
	assert(config ~= nil, "invalid iap id: "..tostring(iapId))

	return config.IsDouble or false
end

function ConfigUtils.GetStartTimeOfDoubleIap(iapId)
	local config = IAPConfig[iapId]
	assert(config ~= nil, "invalid iap id: "..tostring(iapId))

	return config.StartupDoubleTime or 0
end

function ConfigUtils.GetIapRewards(iapId)
	local config = IAPConfig[iapId]
	assert(config ~= nil, "invalid iap id: "..tostring(iapId))

	return config.Rewards or {}
end

function ConfigUtils.GetIapInternalId(iapId)
	local config = IAPConfig[iapId]
	assert(config ~= nil, "invalid iap id: "..tostring(iapId))

	return config.Id or 0
end

function ConfigUtils.IsPackageIap(iapId)
	local itemType = ConfigUtils.GetItemTypeFromId(iapId)
	return itemType == ItemType.IAPPackage or itemType == ItemType.CustomPackage
end

function ConfigUtils.IsPassportIap(iapId)
	local itemType = ConfigUtils.GetItemTypeFromId(iapId)
	if itemType ~= ItemType.IAP then
		return false
	end
	local config = IAPConfig[iapId]
	return config and config.Type == IAPType.ActivityPassport
end

function ConfigUtils.GetPassportIapActivityId(iapId)
	local config = IAPConfig[iapId]
	assert(config ~= nil, "invalid iap id: "..tostring(iapId))
	return config.ActivityThemeId or 0
end

--[[
function ConfigUtils.IsActivityPackageIap(iapId)
	local itemType = ConfigUtils.GetItemTypeFromId(iapId)
	return itemType == ItemType.ActivityPackage
end--]]

function ConfigUtils.GetIapStoreToProductMap()
	local ret = {}

	local storeKey = this.GetCurrentChannelStoreKey()
	for k, v in pairs(IAPConfig) do
		if storeKey == nil or v.StoreId[storeKey] == nil then
			ret[k] = k
		else
			local storeId = v.StoreId[storeKey]
			ret[storeId] = k
		end
	end

	return ret
end

function ConfigUtils.GetPackageIapStoreId(price)
	local storeKey = this.GetCurrentChannelStoreKey()
	for k, v in pairs(IAPPackageConfig) do
		if v.Price == price then
			local defaultRet = tostring(k)
			if storeKey == nil then
				return defaultRet
			else
				local stores = v.StoreId
				return stores[storeKey] or defaultRet
			end
		end
	end

	assert(false, "not found iap package for price: "..tostring(price).." and iap id: "..tostring(iapId))
end

function ConfigUtils.IsMonthCardIap(iapId)
	local config = IAPConfig[iapId]
	assert(config ~= nil, "invalid iap id: "..tostring(iapId))

	local rewards = config.Rewards or {}
	for k, v in pairs(rewards) do
		if v.Value == ItemType.Card or v.Value == ItemType.Card2 then
			return true
		end
	end

	return false
end
--------------------------------------------------------------
function ConfigUtils.GetCustomPackagePrice(packageId)
	local config = IAPCustomPackageConfig[packageId]
	assert(config ~= nil, "invalid custom package id: "..tostring(packageId))

	return config.Price
end

function ConfigUtils.GetCustomPackageStoreId(packageId)
	local price = this.GetCustomPackagePrice(packageId)
	return this.GetPackageIapStoreId(price)
end

function ConfigUtils.GetCustomPackageInfo(packageId)
	local config = IAPCustomPackageConfig[packageId]
	assert(config ~= nil, "invalid custom package id: "..tostring(packageId))

	return SAFE_LOC(config.Name), SAFE_LOC(config.Desc), SAFE_LOC(config.ButtonDesc), config.PackageRate, config.Icon
end


function ConfigUtils.GetCustomPackageRewards(packageId)
	local config = IAPCustomPackageConfig[packageId]
	assert(config ~= nil, "invalid custom package id: "..tostring(packageId))

	local ret = {}

	local rewards = config.Reward or {}
	for idx = 1, #rewards do
		ret[idx] = {id = rewards[idx].Value, num = rewards[idx].Num}
	end

	return ret
end
--------------------------------------------------------------
function ConfigUtils.GetScoreCapInfo(scoreCapId)
	local config = SpaceTravelScoreCapConfig[scoreCapId]
	assert(config ~= nil, "invalid score cap id: "..tostring(scoreCapId))

	return SAFE_LOC(config.Name), SAFE_LOC(config.Desc), config.Icon
end

function ConfigUtils.GetScoreCapNeedGold(scoreCapId)
	local config = SpaceTravelScoreCapConfig[scoreCapId]
	assert(config ~= nil, "invalid score cap id: "..tostring(scoreCapId))

	return config.RegisterGold
end

function ConfigUtils.GetScoreCapExchangePackages(scoreCapId)
	local config = SpaceTravelScoreCapConfig[scoreCapId]
	assert(config ~= nil, "invalid score cap id: "..tostring(scoreCapId))

	return config.Exchange
end
--------------------------------------------------------------
-- space ship
function ConfigUtils.GetSpaceShipSortId(shipId)
	local config = SpaceTravelShipConfig[shipId]
	assert(config ~= nil, "invalid space ship id: "..tostring(shipId))
	return config.Id
end

function ConfigUtils.GetSpaceShipName(shipId)
	local config = SpaceTravelShipConfig[shipId]
	assert(config ~= nil, "invalid space ship id: "..tostring(shipId))
	return SAFE_LOC(config.Name)
end

function ConfigUtils.GetSpaceShipDesc(shipId)
	local config = SpaceTravelShipConfig[shipId]
	assert(config ~= nil, "invalid space ship id: "..tostring(shipId))
	return SAFE_LOC(config.Desc)
end

function ConfigUtils.GetSpaceShipStorageSlot(shipId)
	local config = SpaceTravelShipConfig[shipId]
	assert(config ~= nil, "invalid space ship id: "..tostring(shipId))
	return config.StorageSlotMax
end

function ConfigUtils.GetSpaceShipBattleRetry(shipId)
	local config = SpaceTravelShipConfig[shipId]
	assert(config ~= nil, "invalid space ship id: "..tostring(shipId))
	return config.BattleRetry
end

function ConfigUtils.GetSpaceShipLabraroty(shipId)
	local config = SpaceTravelShipConfig[shipId]
	assert(config ~= nil, "invalid space ship id: "..tostring(shipId))
	return config.LabId
end

function ConfigUtils.GetSpaceShipRelicSlot(shipId)
	local config = SpaceTravelShipConfig[shipId]
	assert(config ~= nil, "invalid space ship id: "..tostring(shipId))
	return config.RelicSlotMax
end

function ConfigUtils.GetSpaceShipFuleCostPercentPerRound(shipId)
	local config = SpaceTravelShipConfig[shipId]
	assert(config ~= nil, "invalid space ship id: "..tostring(shipId))
	return config.RoundFuelCostPercent
end

function ConfigUtils.GetSpaceShipSkillDesc(shipId)
	local config = SpaceTravelShipConfig[shipId]
	assert(config ~= nil, "invalid space ship id: "..tostring(shipId))
	return SAFE_LOC(config.SkillDesc)
end

function ConfigUtils.GetSpaceShipIcon(shipId)
	local config = SpaceTravelShipConfig[shipId]
	assert(config ~= nil, "invalid space ship id: "..tostring(shipId))
	return config.Icon, config.IconAtlas
end

function ConfigUtils.GetSpaceShipPrefab(shipId)
	local config = SpaceTravelShipConfig[shipId]
	assert(config ~= nil, "invalid space ship id: "..tostring(shipId))
	return config.PrefabName, config.PrefabBundle
end

function ConfigUtils.GetSpaceShipAttributes(shipId)
	local ret = {}

	local config = SpaceTravelShipConfig[shipId]
	assert(config ~= nil, "invalid space ship id: "..tostring(shipId))

	local initialCapacity = 0
	local initialSlot = #config.InitialGoodsList 
	for idx = 1, initialSlot do
		local goodsId = config.InitialGoodsList [idx].Value
		local goodsNum = config.InitialGoodsList [idx].Num
		initialCapacity = initialCapacity + this.GetSpaceTravelGoodsSupplyCapacity(goodsId) * goodsNum
	end

	ret[1] = {initial = config.FoodInit, max = config.FoodMax}
	ret[2] = {initial = config.FuelInit, max = config.FuelMax}
	ret[3] = {initial = initialCapacity, max = config.CapacityMax}
	ret[4] = {initial = initialSlot, max = config.StorageSlotMax}

	return ret
end

function ConfigUtils.GetSpaceTravelShipUnlockCondition(shipId)
	local config = SpaceTravelShipConfig[shipId]
	assert(config ~= nil, "invalid space ship id: "..tostring(shipId))

	local condition = config.UnlockCondition or {}
	return condition.NeedScoreCap, condition.NeedCareerData, condition.NeedCampFriendliness, condition.UnlockCostList
end

function ConfigUtils.GetSpaceTravelShipList()
	local ret = {}

	for k, v in pairs(SpaceTravelShipConfig) do
		table.insert(ret, k)
	end

	return ret
end
--------------------------------------------------------------
function ConfigUtils.GetSpaceTravelGoodsSupplyCapacity(goodsId)
	local config = SpaceTravelGoodsConfig[goodsId]
	assert(config ~= nil, "invalid space travel goods id: "..tostring(goodsId))

	return config.Capacity
end

function ConfigUtils.GetSpaceTravelGoodsIcon(goodsId)
	local config = SpaceTravelGoodsConfig[goodsId]
	assert(config ~= nil, "invalid space travel goods id: "..tostring(goodsId))

	return config.Icon, config.IconAtlas
end

function ConfigUtils.GetSpaceTravelGoodsSubType(goodsId)
	local config = SpaceTravelGoodsConfig[goodsId]
	assert(config ~= nil, "invalid space travel goods id: "..tostring(goodsId))

	return config.SubType
end

function ConfigUtils.GetSpaceTravelGoodsName(goodsId)
	local config = SpaceTravelGoodsConfig[goodsId]
	assert(config ~= nil, "invalid space travel goods id: "..tostring(goodsId))

	return SAFE_LOC(config.Name)
end

function ConfigUtils.GetSpaceTravelGoodsDesc(goodsId)
	local config = SpaceTravelGoodsConfig[goodsId]
	assert(config ~= nil, "invalid space travel goods id: "..tostring(goodsId))

	return SAFE_LOC(config.Desc)
end

function ConfigUtils.GetSpaceTravelGoodsSupplyNum(goodsId)
	local config = SpaceTravelGoodsConfig[goodsId]
	assert(config ~= nil, "invalid space travel goods id: "..tostring(goodsId))

	return config.Num
end

function ConfigUtils.GetSpaceTravelGoodsPrice(goodsId)
	local config = SpaceTravelGoodsConfig[goodsId]
	assert(config ~= nil, "invalid space travel goods id: "..tostring(goodsId))

	return config.Price or 0
end

function ConfigUtils.GetSpaceTravelGoodsTags(goodsId)
	local config = SpaceTravelGoodsConfig[goodsId]
	assert(config ~= nil, "invalid space travel goods id: "..tostring(goodsId))

	return config.Tags or {}
end

function ConfigUtils.IsSpaceTravelGoodsUsable(goodsId)
	local subType = this.GetSpaceTravelGoodsSubType(goodsId)
	return subType ~= SpaceTravelGoodsSubType.Object and 
			subType ~= SpaceTravelGoodsSubType.Relic and 
			subType ~= SpaceTravelGoodsSubType.Artwork
end
--------------------------------------------------------------
function ConfigUtils.GetSpaceTravelLabMaxLevel(labId)
	local config = SpaceTravelLabConfig[labId]
	assert(config ~= nil, "invalid space travel lab id: "..tostring(labId))

	local levelList = config.LevelList or {}
	return #levelList
end

function ConfigUtils.GetSpaceTravelLabBG(labId, level)
	local config = SpaceTravelLabConfig[labId]
	assert(config ~= nil, "invalid space travel lab id: "..tostring(labId))

	local levelList = config.LevelList or {}
	return levelList[level].IconBG
end

function ConfigUtils.GetSpaceTravelLabRecipesAtLevel(labId, level, subType)
	local config = SpaceTravelLabConfig[labId]
	assert(config ~= nil, "invalid space travel lab id: "..tostring(labId))

	local ret = {}
	local levelList = config.LevelList or {}
	if level <= #levelList then
		local recipeList = levelList[level].RecipeList or {}
		for idx = 1, #recipeList do
			local recipeId = recipeList[idx]
			if subType == nil or subType == ConfigUtils.GetLabRecipeSubType(recipeId) then
				table.insert(ret, recipeId)
			end
		end
	end

	return ret
end

function ConfigUtils.GetSpaceTravelLabUnlockRecipesAtLevel(labId, level)
	local ret = {}

	local recipeListA = this.GetSpaceTravelLabRecipesAtLevel(labId, level)
	local recipeListB = this.GetSpaceTravelLabRecipesAtLevel(labId, level + 1)
	for idx = 1, #recipeListB do
		local recipeId = recipeListB[idx]
		if not Helper.TableContains(recipeListA, recipeId) then
			table.insert(ret, recipeId)
		end
	end

	return ret
end

function ConfigUtils.GetSpaceTravelUpgradeItemsAtLevel(labId, level)
	local config = SpaceTravelLabConfig[labId]
	assert(config ~= nil, "invalid space travel lab id: "..tostring(labId))

	local levelList = config.LevelList or {}
	if level <= #levelList then
		return levelList[level].UpgradeItemList
	end

	return {}
end
--------------------------------------------------------------
function ConfigUtils.GetFirstNodeOfSpaceTravelWorld(worldId)
	local config = SpaceTravelMapConfig[worldId]
	assert(config ~= nil, "invalid space travel world id: "..tostring(worldId))

	return config.FirstNode
end

function ConfigUtils.GetSpaceTravelWorldFuelCostPerRound(worldId)
	local config = SpaceTravelMapConfig[worldId]
	assert(config ~= nil, "invalid space travel world id: "..tostring(worldId))

	return config.RoundFuelCost
end

function ConfigUtils.GetSpaceTravelNodeSeed(worldId, nodeId)
	local nodeConfig = this.GetSpaceTravelNodeConfig(worldId, nodeId)
	return nodeConfig.Seed
end

function ConfigUtils.IsLastNodeOfSpaceTravelWorld(worldId, nodeId)
	if not this.IsValidItem(nodeId) then
		return false
	end

	local nodeConfig = this.GetSpaceTravelNodeConfig(worldId, nodeId)
	local childList = nodeConfig.ChildIdList or {}
	return #childList == 0
end

function ConfigUtils.GetSpaceTravelNodePathPointName(worldId, nodeId)
	if not this.IsValidItem(nodeId) then
		return ""
	end

	local nodeConfig = this.GetSpaceTravelNodeConfig(worldId, nodeId)
	local eventPoolId = nodeConfig.EventPool
	local eventPoolConfig = SpaceTravelEventPoolConfig[eventPoolId]
	assert(eventPoolConfig ~= nil, "invalid event pool config id: "..tostring(eventPoolId))
	return eventPoolConfig.PrefabName, eventPoolConfig.EffectPrefab
end

function ConfigUtils.GetSpaceTravelNodeConfig(worldId, nodeId)
	local config = SpaceTravelMapConfig[worldId]
	assert(config ~= nil, "invalid space travel world id: "..tostring(worldId))

	local nodeConfig = config.Nodes[nodeId]
	assert(nodeConfig ~= nil, "invalid space travel node id: "..tostring(nodeId).." at world: "..tostring(worldId))

	return nodeConfig
end

function ConfigUtils.GetSpaceTravelNodeChildList(worldId, nodeId)
	local nodeConfig = this.GetSpaceTravelNodeConfig(worldId, nodeId)
	local childList = nodeConfig.ChildIdList or {}
	return childList
end

function ConfigUtils.IsSpaceTravelRootPathNode(worldId, nodeId)
	local pathStart = this.GetSpaceTravelMapPathStart(worldId, nodeId)
	return pathStart == this.GetFirstNodeOfSpaceTravelWorld(worldId)
end

function ConfigUtils.IsSpaceTravelWorldLastNode(worldId, nodeId)
	local nodeConfig = this.GetSpaceTravelNodeConfig(worldId, nodeId)
	local childList = nodeConfig.ChildIdList or {}
	return #childList  == 0
end

function ConfigUtils.GetSpaceTravelMapPathStart(worldId, nodeId)
	local nodeConfig = this.GetSpaceTravelNodeConfig(worldId, nodeId)
	return nodeConfig.BranchRoot
end

function ConfigUtils.GetSpaceTravelMapPathEnd(worldId, nodeId)
	local config = SpaceTravelMapConfig[worldId]
	assert(config ~= nil, "invalid space travel world id: "..tostring(worldId))

	local curNodeId = nodeId
	local childList = config.Nodes[curNodeId].ChildIdList or {}
	while #childList == 1 do
		curNodeId = childList[1]
		childList = config.Nodes[curNodeId].ChildIdList or {}
	end

	return curNodeId
end

function ConfigUtils.GetSpaceTravelMapNodePath(worldId, nodeId)
	local config = SpaceTravelMapConfig[worldId]
	assert(config ~= nil, "invalid space travel world id: "..tostring(worldId))

	local curNode = this.GetSpaceTravelMapPathStart(worldId, nodeId)
	local pathEnd = this.GetSpaceTravelMapPathEnd(worldId, nodeId)

	local ret = {}

	while curNode ~= pathEnd do
		table.insert(ret, curNode)
		local nodeConfig = config.Nodes[curNode]
		curNode = nodeConfig.ChildIdList[1]
	end

	table.insert(ret, pathEnd)

	return ret
end

-- should have 2 paths or have none
function ConfigUtils.GetSpaceTravelChildNodePaths(worldId, nodeId)
	local pathEnd = this.GetSpaceTravelMapPathEnd(worldId, nodeId)
	local nodeConfig = this.GetSpaceTravelNodeConfig(worldId, pathEnd)
	local childList = nodeConfig.ChildIdList or {}

	local pathLeft = {}
	local pathRight = {}

	if #childList == 2 then
		pathLeft = this.GetSpaceTravelMapNodePath(worldId, childList[1])
		pathRight = this.GetSpaceTravelMapNodePath(worldId, childList[2])
	end

	return pathLeft, pathRight
end
--------------------------------------------------------------
function ConfigUtils.GetSpaceTravelChoiceName(choiceId)
	local config = SpaceTravelChoiceConfig[choiceId]
	assert(config ~= nil, "invalid space travel choice id: "..tostring(choiceId))

	return SAFE_LOC(config.Name)
end

function ConfigUtils.GetSpaceTravelChoiceType(choiceId)
	local config = SpaceTravelChoiceConfig[choiceId]
	assert(config ~= nil, "invalid space travel choice id: "..tostring(choiceId))

	return config.Type
end

function ConfigUtils.GetSpaceTravelChoiceNeedList(choiceId)
	local config = SpaceTravelChoiceConfig[choiceId]
	assert(config ~= nil, "invalid space travel choice id: "..tostring(choiceId))

	return config.NeedList or {}
end

function ConfigUtils.GetSpaceTravelChoiceDeal(choiceId)
	local config = SpaceTravelChoiceConfig[choiceId]
	assert(config ~= nil, "invalid space travel choice id: "..tostring(choiceId))

	return config.DealId
end

function ConfigUtils.GetSpaceTravelChoiceDiscovery(choiceId)
	local config = SpaceTravelChoiceConfig[choiceId]
	assert(config ~= nil, "invalid space travel choice id: "..tostring(choiceId))

	return config.DiscoveryId
end

function ConfigUtils.GetSpaceTravelChoiceChat(choiceId)
	local config = SpaceTravelChoiceConfig[choiceId]
	assert(config ~= nil, "invalid space travel choice id: "..tostring(choiceId))

	return config.ChatId
end

function ConfigUtils.GetSpaceTravelChoiceChallenge(choiceId)
	local config = SpaceTravelChoiceConfig[choiceId]
	assert(config ~= nil, "invalid space travel choice id: "..tostring(choiceId))

	return config.ChallengeId
end

function ConfigUtils.GetSpaceTravelChoiceGoal(choiceId)
	local config = SpaceTravelChoiceConfig[choiceId]
	assert(config ~= nil, "invalid space travel choice id: "..tostring(choiceId))

	return config.GoalId
end

function ConfigUtils.GetSpaceTravelChoiceCostList(choiceId)
	local config = SpaceTravelChoiceConfig[choiceId]
	assert(config ~= nil, "invalid space travel choice id: "..tostring(choiceId))

	return config.CostList or {}
end

function ConfigUtils.GetSpaceTravelChoiceGainList(choiceId)
	local config = SpaceTravelChoiceConfig[choiceId]
	assert(config ~= nil, "invalid space travel choice id: "..tostring(choiceId))

	return config.GainList or {}
end

function ConfigUtils.GetSpaceTravelChoiceResult(choiceId, win)
	local config = SpaceTravelChoiceConfig[choiceId]
	assert(config ~= nil, "invalid space travel choice id: "..tostring(choiceId))

	if win then
		return config.Win or {}
	else
		return config.Lose or {}
	end
end

function ConfigUtils.GetSpaceTravelChoiceCancelResult(choiceId)
	local config = SpaceTravelChoiceConfig[choiceId]
	assert(config ~= nil, "invalid space travel choice id: "..tostring(choiceId))

	return config.Retreat or {}
end

function ConfigUtils.GetSpaceTravelChoiceDialogList(choiceId)
	local config = SpaceTravelChoiceConfig[choiceId]
	assert(config ~= nil, "invalid space travel choice id: "..tostring(choiceId))

	return config.Dialog or {}
end
--------------------------------------------------------------
function ConfigUtils.GetSpaceTravelEventName(eventId)
	local config = SpaceTravelEventConfig[eventId]
	assert(config ~= nil, "invalid space travel event id: "..tostring(eventId))

	return SAFE_LOC(config.Name)
end

function ConfigUtils.GetSpaceTravelEventDesc(eventId)
	local config = SpaceTravelEventConfig[eventId]
	assert(config ~= nil, "invalid space travel event id: "..tostring(eventId))

	return SAFE_LOC(config.Desc)
end

function ConfigUtils.GetSpaceTravelEventIcon(eventId)
	local config = SpaceTravelEventConfig[eventId]
	assert(config ~= nil, "invalid space travel event id: "..tostring(eventId))

	return config.Icon
end

function ConfigUtils.GetSpaceTravelEventBG(eventId)
	local config = SpaceTravelEventConfig[eventId]
	assert(config ~= nil, "invalid space travel event id: "..tostring(eventId))

	return config.IconBG
end

function ConfigUtils.GetSpaceTravelEventFriendliness(eventId)
	local config = SpaceTravelEventConfig[eventId]
	assert(config ~= nil, "invalid space travel event id: "..tostring(eventId))

	return config.FriendlinessId
end
--------------------------------------------------------------
function ConfigUtils.GetSpaceTravelFriendlinessMax(friendlinessId)
	local config = SpaceTravelFriendlinessConfig[friendlinessId]
	assert(config ~= nil, "invalid space travel friendliness id: "..tostring(friendlinessId))

	return config.FriendlinessMax
end

function ConfigUtils.GetSpaceTravelFriendlinessName(friendlinessId)
	local config = SpaceTravelFriendlinessConfig[friendlinessId]
	assert(config ~= nil, "invalid space travel friendliness id: "..tostring(friendlinessId))

	return SAFE_LOC(config.Name)
end

function ConfigUtils.GetSpaceTravelFriendlinessIcon(friendlinessId)
	local config = SpaceTravelFriendlinessConfig[friendlinessId]
	assert(config ~= nil, "invalid space travel friendliness id: "..tostring(friendlinessId))

	return config.Icon
end

function ConfigUtils.GetSpaceTravelFriendlinessDesc(friendlinessId, value)
	local config = SpaceTravelFriendlinessConfig[friendlinessId]
	assert(config ~= nil, "invalid space travel friendliness id: "..tostring(friendlinessId))

	local descList = config.DescList or {}
	for idx = 1, #descList do
		if value >= descList[idx].Value then
			return SAFE_LOC(descList[idx].Desc)
		end
	end

	if #descList == 0 then
		return ""
	else
		return SAFE_LOC(descList[#descList].Desc)
	end
end

function ConfigUtils.GetSpaceTravelFriendlinessList()
	local ret = {}

	for k, v in pairs(SpaceTravelFriendlinessConfig) do
		table.insert(ret, k)
	end

	local sortFunc = function(idA, idB)
		if idA == nil or idB == nil then
			return false
		end

		local valueA = SpaceTravelFriendlinessConfig[idA].Id
		local valueB = SpaceTravelFriendlinessConfig[idB].Id
		return valueA < valueB
	end

	table.sort(ret, sortFunc)

	return ret
end
--------------------------------------------------------------
function ConfigUtils.GetSpaceTravelDealName(dealId)
	local config = SpaceTravelDealConfig[dealId]
	assert(config ~= nil, "invalid space travel deal id: "..tostring(dealId))

	return SAFE_LOC(config.Name)
end

function ConfigUtils.GetSpaceTravelDealFriendlinessId(dealId)
	local config = SpaceTravelDealConfig[dealId]
	assert(config ~= nil, "invalid space travel deal config: "..tostring(dealId))

	return config.FriendlinessId
end

function ConfigUtils.GetSpaceTravelDealShopName(dealId)
	local config = SpaceTravelDealConfig[dealId]
	assert(config ~= nil, "invalid space travel deal config: "..tostring(dealId))

	return SAFE_LOC(config.ShopName)
end

function ConfigUtils.GetSpaceTravelDealShopIcon(dealId)
	local config = SpaceTravelDealConfig[dealId]
	assert(config ~= nil, "invalid space travel deal config: "..tostring(dealId))

	return config.ShopIcon
end

function ConfigUtils.GetSpaceTravelDealSaleList(dealId)
	local config = SpaceTravelDealConfig[dealId]
	assert(config ~= nil, "invalid space travel deal config: "..tostring(dealId))

	return config.SaleList or {}
end

function ConfigUtils.GetSpaceTravelDealDialogs(dealId)
	local config = SpaceTravelDealConfig[dealId]
	assert(config ~= nil, "invalid space travel deal id: "..tostring(dealId))

	return config.Dialog or {}
end

function ConfigUtils.GetSpaceTravelDealHint(dealId, price)
	local config = SpaceTravelDealConfig[dealId]
	assert(config ~= nil, "invalid space travel deal id: "..tostring(dealId))

	local hintList = config.DealDialog or {}
	if #hintList == 0 then
		return nil
	end

	local slot = nil
	for idx = 1, #hintList do
		if price >= hintList[idx].NeedPrice then
			slot = idx
			break
		end
	end

	if slot == nil then
		slot = #hintList
	end

	return SAFE_LOC(hintList[slot].Dialog)
end

function ConfigUtils.GetSpaceTravelDealTagMap(dealId)
	local config = SpaceTravelDealConfig[dealId]
	assert(config ~= nil, "invalid space travel deal id: "..tostring(dealId))

	local tagList = config.TagList or {}
	local ret = {}

	for k, v in pairs(tagList) do
		local tagId = v.TagId
		ret[tagId] = {abs = v.Abs, percent = v.Percent}
	end

	return ret
end

function ConfigUtils.GetSpaceTravelDealMinProfit(dealId)
	local config = SpaceTravelDealConfig[dealId]
	assert(config ~= nil, "invalid space travel deal id: "..tostring(dealId))

	return config.ProfitMin
end

function ConfigUtils.GetSpaceTravelDealFriendliness(dealId)
	local config = SpaceTravelDealConfig[dealId]
	assert(config ~= nil, "invalid space travel deal id: "..tostring(dealId))

	return config.FriendlinessAddValue, config.FriendlinessChange[1], config.FriendlinessChange[2]
end
--------------------------------------------------------------
function ConfigUtils.GetSpaceTravelDiscoveryName(discoveryId)
	local config = SpaceTravelDiscoveryConfig[discoveryId]
	assert(config ~= nil, "invalid space travel discovery id: "..tostring(discoveryId))

	return SAFE_LOC(config.Name)
end

function ConfigUtils.GetSpaceTravelDiscoveryDesc(discoveryId)
	local config = SpaceTravelDiscoveryConfig[discoveryId]
	assert(config ~= nil, "invalid space travel discovery id: "..tostring(discoveryId))

	return SAFE_LOC(config.Desc)
end

function ConfigUtils.GetSpaceTravelDiscoveryGoodsNumLimit(discoveryId)
	local config = SpaceTravelDiscoveryConfig[discoveryId]
	assert(config ~= nil, "invalid space travel discovery id: "..tostring(discoveryId))

	return config.CarryGoodsNum
end

function ConfigUtils.GetSpaceTravelDiscoveryBG(discoveryId)
	local config = SpaceTravelDiscoveryConfig[discoveryId]
	assert(config ~= nil, "invalid space travel discovery id: "..tostring(discoveryId))

	return config.IconBG
end
--------------------------------------------------------------
function ConfigUtils.GetSpaceTravelChatName(chatId)
	local config = SpaceTravelChatConfig[chatId]
	assert(config ~= nil, "invalid space travel chat id: "..tostring(chatId))

	return SAFE_LOC(config.Name)
end

function ConfigUtils.GetSpaceTravelChatEnemy(chatId)
	local config = SpaceTravelChatConfig[chatId]
	assert(config ~= nil, "invalid space travel chat id: "..tostring(chatId))

	return config.Enemy
end

function ConfigUtils.GetSpaceTravelChatNeedAbilityList(chatId)
	local config = SpaceTravelChatConfig[chatId]
	assert(config ~= nil, "invalid space travel chat id: "..tostring(chatId))

	local ret = {}
	local abilityList = config.ChatList[1].NeedAttribute or {}
	for idx = 1, #abilityList do
		ret[idx] = abilityList[idx].Value
	end

	return ret
end

function ConfigUtils.GetSpaceTravelChatRules(chatId)
	local config = SpaceTravelChatConfig[chatId]
	assert(config ~= nil, "invalid space travel chat id: "..tostring(chatId))

	return config.TeamCondition or {}
end

function ConfigUtils.GetSpaceTravelChatCharacterLimit(chatId)
	local config = SpaceTravelChatConfig[chatId]
	assert(config ~= nil, "invalid space travel chat id: "..tostring(chatId))

	return config.NumCap
end

function ConfigUtils.GetSpaceTravelChatResult(chatId, abilityMap)
	local config = SpaceTravelChatConfig[chatId]
	assert(config ~= nil, "invalid space travel chat id: "..tostring(chatId))

	local chatList = config.ChatList or {}
	local slot = nil
	for idx = 1, #chatList do
		local needAbilityList = chatList[idx].NeedAttribute or {}
		local match = true
		for abilityIdx = 1, #needAbilityList do
			local abilityId = needAbilityList[abilityIdx].Value
			local abilityValue = needAbilityList[abilityIdx].Num
			local curValue = abilityMap[abilityId] or 0
			if curValue < abilityValue then
				match = false
				break
			end
		end

		if match then
			slot = idx
			break
		end
	end

	-- use the last one
	if slot == nil and #chatList > 0 then
		slot = #chatList
	end

	assert(slot ~= nil, "can't find chat result for: "..tostring(chatId))
	return chatList[slot], chatList[1]
end
--------------------------------------------------------------
function ConfigUtils.GetGalleryList()
	local ret = {}

	for k, v in pairs(GalleryConfig) do
		table.insert(ret, k)
	end

	return ret
end

function ConfigUtils.GetGallerySortId(galleryId)
	local config = GalleryConfig[galleryId]
	assert(config ~= nil, "invalid gallery id: "..tostring(galleryId))

	return config.Id
end

function ConfigUtils.GetGalleryPlanet(galleryId)
	local config = GalleryConfig[galleryId]
	assert(config ~= nil, "invalid gallery id: "..tostring(galleryId))

	return config.Unlock
end

function ConfigUtils.GetGalleryName(galleryId)
	local config = GalleryConfig[galleryId]
	assert(config ~= nil, "invalid gallery id: "..tostring(galleryId))

	return SAFE_LOC(config.Name)
end

function ConfigUtils.GetGalleryIcon(galleryId)
	local config = GalleryConfig[galleryId]
	assert(config ~= nil, "invalid gallery id: "..tostring(galleryId))

	return config.Icon
end

function ConfigUtils.GetGalleryPageText(galleryId)
	local config = GalleryConfig[galleryId]
	assert(config ~= nil, "invalid gallery id: "..tostring(galleryId))

	return SAFE_LOC(config.PageText)
end

function ConfigUtils.GetGalleryDetailIcon(galleryId)
	local config = GalleryConfig[galleryId]
	assert(config ~= nil, "invalid gallery id: "..tostring(galleryId))

	return config.CharacterIcon, config.PetIcon, config.EventIcon
end
--------------------------------------------------------------
function ConfigUtils.GetNewbiewList()
	local ret = {}

	for k, v in pairs(NewbieConfig) do
		table.insert(ret, k)
	end

	local func = function(idA, idB)
		if idA == nil or idB == nil then
			return false
		end

		local valueA = this.GetNewbieId(idA)
		local valueB = this.GetNewbieId(idB)

		return valueA < valueB
	end

	table.sort(ret, func)

	return ret
end

function ConfigUtils.GetNewbieId(newbieId)
	local config = NewbieConfig[newbieId]
	assert(config ~= nil, "invalid newbie id: "..tostring(newbieId))

	return config.Id
end

function ConfigUtils.GetNewbieName(newbieId)
	local config = NewbieConfig[newbieId]
	assert(config ~= nil, "invalid newbie id: "..tostring(newbieId))

	return SAFE_LOC(config.Name)
end

function ConfigUtils.GetNewbieDesc(newbieId)
	local config = NewbieConfig[newbieId]
	assert(config ~= nil, "invalid newbie id: "..tostring(newbieId))

	return SAFE_LOC(config.Desc)
end

function ConfigUtils.GetNewbieHintNode(newbieId)
	local config = NewbieConfig[newbieId]
	assert(config ~= nil, "invalid newbie id: "..tostring(newbieId))

	return config.Node
end

function ConfigUtils.GetNewbieGoalList(newbieId)
	local config = NewbieConfig[newbieId]
	assert(config ~= nil, "invalid newbie id: "..tostring(newbieId))

	return config.GoalList or {}
end
--------------------------------------------------------------
function ConfigUtils.GetCharacterSkillFilterShowName(skillName)
	local config = CharacterSkillFilterConfig[skillName]
	assert(config ~= nil, "invalid skill filter name: "..tostring(skillName))

	return SAFE_LOC(config.Name)
end

function ConfigUtils.IsSkillMatchFilterMap(skillNames, skillId)
	for k, v in pairs(skillNames) do
		if ConfigUtils.IsSkillMatchFilter(k, skillId) then
			return true
		end
	end

	return false
end

function ConfigUtils.IsSkillMatchFilter(skillName, skillId)
	local config = CharacterSkillFilterConfig[skillName]
	assert(config ~= nil, "invalid skill filter name: "..tostring(skillName))

	local skillEffectAttribute = ConfigUtils.GetSkillEffectAttribute(skillId)
	local skillEffectValue = ConfigUtils.GetSkillEffectValue(skillId)

	local attributes = config.EffectAttributes or {}
	if not Helper.TableContains(attributes, skillEffectAttribute) then
		return false
	end

	-- speical cases
	if skillName == "WorkShopGoodsNumber" then
		return skillEffectValue ~= ItemType.Gold
	elseif skillName == "WorkShopGoldNumber" then
		return skillEffectValue == ItemType.Gold
	elseif skillName == "ExploreAbility" or skillName == "ChallengeAbility" or skillName == "WorkShopAbility" then
		if not ConfigUtils.IsValidItem(skillEffectValue) then
			return true
		end

		if skillName == "WorkShopAbility" then
			return ConfigUtils.IsWorkShopAbility(skillEffectValue)
		else
			return not ConfigUtils.IsWorkShopAbility(skillEffectValue)
		end
	else
		return true
	end
end

function ConfigUtils.IsWorkShopAbility(abilityId)
	return abilityId == AbilityType.CRA or abilityId == AbilityType.AFF or abilityId == AbilityType.STR or abilityId == AbilityType.INT
end
--------------------------------------------------------------
function ConfigUtils.GetTagName(tagId)
	local config = TagConfig[tagId]
	assert(config ~= nil, "invalid tag id: "..tostring(tagId))

	return SAFE_LOC(config.TAG)
end
--------------------------------------------------------------
function ConfigUtils.IsAreaNode(nodeName)
	return MapAvatarConfig[nodeName] ~= nil
end

function ConfigUtils.IsPlanetNode(nodeName)
	return PlanetAvatarConfig[nodeName] ~= nil
end

function ConfigUtils.GetAreaNodeVisibleConditions(areaNodeName)
	local config = MapAvatarConfig[areaNodeName]
	if config == nil or config.PreCondition == nil then
		return nil
	end

	return config.PreCondition.PreGoalList, config.PreCondition.PreChallengeList, config.PreCondition.ExploreRequire
end

function ConfigUtils.GetAreaNodeWeight(areaNodeName)
	local config = MapAvatarConfig[areaNodeName]
	if config == nil then
		return 0
	end

	return config.Weight or 0
end

function ConfigUtils.GetPlanetNodeVisibleConditions(planetNodeName)
	local config = PlanetAvatarConfig[planetNodeName]
	if config == nil or config.PreCondition == nil then
		return nil
	end

	return config.PreCondition.PreGoalList, config.PreCondition.PreChallengeList, config.PreCondition.ExploreRequire
end

function ConfigUtils.GetCharacterNodeVisibleConditions(characterNodeName)
	local config = PlanetCharacterConfig[characterNodeName]
	if config == nil or config.PreCondition == nil then
		return nil
	end

	return config.PreCondition.UnlockCharacterList, config.PreCondition.LockCharacterList
end

function ConfigUtils.GetCharacterNodeDialogList(characterNodeName)
	local config = PlanetCharacterConfig[characterNodeName]
	if config == nil or config.DialogList == nil then
		return nil
	end

	return config.DialogList
end
--------------------------------------------------------------
function ConfigUtils.GetExileCharacterNodeDialogList(characterNodeName)
	local config = ExileStreetCharacterConfig[characterNodeName]
	if config == nil or config.DialogList == nil then
		return nil
	end

	return config.DialogList
end

function ConfigUtils.GetExileCharacterNodeVisibleConditions(characterNodeName)
	local config = ExileStreetCharacterConfig[characterNodeName]
	if config == nil or config.PreCondition == nil then
		return nil
	end

	return config.PreCondition.UnlockCharacterList, config.PreCondition.LockCharacterList
end
--------------------------------------------------------------
function ConfigUtils.GetExploreDialogList()
	local ret = {}
	for k, v in pairs(ExploreBagSpeechConfig) do
		local isFirst = v.IsFirst or false
		if isFirst then
			table.insert(ret, k)
		end
	end

	return ret
end

function ConfigUtils.GetExploreDialogConditions(dialogId)
	local config = ExploreBagSpeechConfig[dialogId]
	assert(config ~= nil, "invalid explore dialog id: "..tostring(dialogId))

	return config.ConditionList
end

function ConfigUtils.GetExploreDialogInfo(dialogId)
	local config = ExploreBagSpeechConfig[dialogId]
	assert(config ~= nil, "invalid explore dialog id: "..tostring(dialogId))

	return config.Position, SAFE_LOC(config.Text)
end

function ConfigUtils.GetChainListOfExploreDialog(dialogId)
	local ret = {}

	local nextDialog = dialogId
	while nextDialog ~= nil do
		table.insert(ret, nextDialog)
		nextDialog = ExploreBagSpeechConfig[nextDialog].NextID
	end

	return ret
end
--------------------------------------------------------------
function ConfigUtils.GetCustomDemandSpeechOfInit()
	local config = CustomDemandSpeechConfig["Init"]
	local chatList = config.ChatList or {}

	local count = #chatList
	if count == 0 then
		return nil
	end

	local idx = Helper.RandInt(1, count)
	return SAFE_LOC(chatList[idx].Text)
end

function ConfigUtils.GetCustomDemandSpeechOfKey(itemId, key)
	local config = CustomDemandSpeechConfig[key]
	assert(config ~= nil, "invalid custom demand speech key: "..tostring(key))

	local chatList = config.ChatList or {}
	local matchedChats = {}
	local invalidChats = {}
	for idx = 1, #chatList do
		if not ConfigUtils.IsValidItem(chatList[idx].GoodsId) then
			table.insert(invalidChats, chatList[idx].Text)
		elseif chatList[idx].GoodsId == itemId then
			table.insert(matchedChats, chatList[idx].Text)
		end
	end

	local count = #matchedChats
	if count > 0 then
		local idx = Helper.RandInt(1, count)
		return SAFE_LOC(matchedChats[idx])
	end

	local invalidCount = #invalidChats
	if invalidCount > 0 then
		local idx = Helper.RandInt(1, invalidCount)
		return SAFE_LOC(invalidChats[idx])
	end

	return nil
end

function ConfigUtils.GetModifyNickNameCost()
	return AccountRenameDiamond
end
--------------------------------------------------------------
-- BGM
function ConfigUtils.GetDefaultBGMKey()
	local bgmConfig = this.GetBgmConfig()
	return bgmConfig[1].key
end

function ConfigUtils.GetBgmName(key)
	local bgmMusic = this.GetBgmConfig()
	for i = 1, #bgmMusic do
		if bgmMusic[i].key == key then
			return bgmMusic[i].Name
		end
	end
	return nil
end

function ConfigUtils.GetBgmConfig()
	local ret = Helper.CloneMap(BGMConfig)
	local result = {}
	for k, v in pairs(ret) do
		table.insert(result, { Id = v.Id, key = k, Name = v.Name })
	end
	table.sort(result, function(idA, idB)
		if idA == nil or idB == nil then
			return false
		end
		return idA.Id < idB.Id
	end)
	return result
end

function ConfigUtils.GetNextBgm(curMusic, ordered, isNext)
	local bgmMusic = this.GetBgmConfig()
	local CurIdx = 1
	for i = 1, #bgmMusic do
		if bgmMusic[i].key == curMusic then
			CurIdx = i
			break
		end
	end

	if ordered then
		if isNext then
			if CurIdx < #bgmMusic then
				CurIdx = CurIdx + 1
			else
				CurIdx = 1
			end
		else
			if CurIdx > 1 then
				CurIdx = CurIdx - 1

			else
				CurIdx = #bgmMusic
			end
		end

	else
		local selectIdx = CurIdx
		while (selectIdx == CurIdx)
		do
			CurIdx = Helper.RandInt(1, #bgmMusic)
		end
	end
	log("music:" .. bgmMusic[CurIdx].key)
	return bgmMusic[CurIdx].key
end

--------------------------------------------------------------
function ConfigUtils.IsItemMatchFilter(itemId, filterName, filterElements, filterRarities, filterTags, filterStages, filterSkills)
	if filterName ~= nil then
		local itemName = this.GetItemName(itemId)
		return string.match(itemName, filterName) ~= nil
	end

	if filterElements ~= nil then
		local elementId = this.GetElementOfItem(itemId)
		if filterElements[elementId] == nil then
			return false
		end
	end

	if filterRarities ~= nil then
		local rarity = this.GetItemRarity(itemId)
		if filterRarities[rarity] == nil then
			return false
		end
	end

	if filterTags ~= nil then
		local hasMatched = false
		local tagMap = this.GetItemTagMap(itemId)
		for tagId, _ in pairs(filterTags) do
			if tagMap[tagId] ~= nil then
				hasMatched = true
				break
			end
		end

		if not hasMatched then
			return false
		end
	end

	if filterStages ~= nil then
		local itemType = this.GetItemTypeFromId(itemId)
		-- pet has no stage
		if itemType == ItemType.Character then
			local stage = GameData.GetCharacterCurrentStage(itemId)
			if filterStages[stage] == nil then
				return false
			end
		end
	end

	if filterSkills ~= nil then
		local hasMatched = false
		local skillList = this.GetItemSkillList(itemId)
		for idx = 1, #skillList do
			local skillId = skillList[idx].id
			if this.IsSkillMatchFilterMap(filterSkills, skillId) then
				hasMatched = true
				break
			end
		end

		if not hasMatched then
			return false
		end
	end

	return true
end

function ConfigUtils.GetItemSkillList(itemId)
	local itemType = this.GetItemTypeFromId(itemId)
	if itemType == ItemType.Character then
		return GameData.GetCharacterSkillList(itemId)
	elseif itemType == ItemType.Pet then
		return GameData.GetPetSkillList(itemId)
	end

	return {}
end

--------------------------------------------------------------
function ConfigUtils.GetActivitySignInReward(id)
	local config = ActivityDailyLoginConfig[id]
	assert(config ~= nil, "invalid ActivityDailyLoginConfig id:" .. tostring(id))
	return config.Value, config.Num
end
--------------------------------------------------------------

---服装店配置-----------------------------------------------------------

--获取商店配置
function ConfigUtils.GetClothesShopInfo(shopId)
	if not ClothesShopConfig[shopId] then
		XDebug.Error("服装店配置不存在 " .. tostring(shopId))
		return nil
	end
	return ClothesShopConfig[shopId]
end

--获取商品
function ConfigUtils.GetClothesShopProduct(shopId, productIndex)
	local shopInfo = this.GetClothesShopInfo(shopId)
	local itemInfo = shopInfo.ItemList[productIndex]
	if not itemInfo then
		return -1
	end
	return itemInfo.Value
end

--获取商店的第一个商品的消耗道具Id
function ConfigUtils.GetClothesShopCostItem(shopId)
	local shopInfo = this.GetClothesShopInfo(shopId)
	local itemInfo = shopInfo.ItemList[1]
	if not itemInfo or not itemInfo.CostItem then
		return -1
	end
	return itemInfo.CostItem.Id
end

--获取商店内的商品价格
function ConfigUtils.GetProductCostInShop(shopId, productId)
	local shopInfo = this.GetClothesShopInfo(shopId)
	for i,v in ipairs(shopInfo.ItemList) do
		if v.Value == productId then
			if v.CostItem then
				return v.CostItem.Id, v.CostItem.Num
			end
			break
		end
	end
	return -1, -1
end

--商店内是否有
function ConfigUtils.IsClothesShopContainItemId(shopId, itemId)
	local shopInfo = this.GetClothesShopInfo(shopId)
	for i, product in ipairs(shopInfo.ItemList) do
		local productInfo = this.GetClothesShopProductInfo(product.Value)
		if productInfo then
			for _,item in ipairs(productInfo.ItemList) do
				if item.Value == itemId then
					return true
				end
			end
		end
	end
	return false
end

--获取商品配置
function ConfigUtils.GetClothesShopProductInfo(productId)
	if not ClothesShopItemConfig[productId] then
		XDebug.Error("服装店商品配置不存在 " .. tostring(productId))
		return nil
	end
	return ClothesShopItemConfig[productId]
end

--获取奖励数量
function ConfigUtils.GetClothesShopProductItemCount(productId)
	local productInfo = this.GetClothesShopProductInfo(productId)
	return #productInfo.ItemList
end
--获取奖励
function ConfigUtils.GetClothesShopProductItem(productId, index)
	index = index or 1
	local productInfo = this.GetClothesShopProductInfo(productId)
	local temp = productInfo.ItemList[index]
	if not temp then
		return 0, 0
	end
	return temp.Value, temp.Num
end

--获取价格数量
function ConfigUtils.GetClothesShopProductCostCount(productId)
	local productInfo = this.GetClothesShopProductInfo(productId)
	return #productInfo.CostItem
end
--获取价格
function ConfigUtils.GetClothesShopProductCost(productId, index)
	index = index or 1
	local productInfo = this.GetClothesShopProductInfo(productId)
	local temp = productInfo.CostItem[index]
	if not temp then
		return 0, 0
	end
	return temp.Value, temp.Num
end

---捞金鱼配置-----------------------------------------------------------

--获取关卡类型
function ConfigUtils.GetCatchFishStageType(stageId)
	local config = CatchFish_FishPoolConfig[stageId]
	assert(config ~= nil, "invalid CatchFish_FishPoolConfig id:" .. tostring(stageId))
	return config.Type
end

--获取关卡是否会自动补充鱼
function ConfigUtils.GetCatchFishStageSuppleFish(stageId)
	local config = CatchFish_FishPoolConfig[stageId]
	assert(config ~= nil, "invalid CatchFish_FishPoolConfig id:" .. tostring(stageId))
	return config.SuppleFish
end

--获取金鱼模型
function ConfigUtils.GetCatchFishFishPrefabName(id)
	local config = CatchFish_FishConfig[id]
	assert(config ~= nil, "invalid CatchFish_FishConfig id:" .. tostring(id))
	return config.Prefab
end

--获取捕捞方式
function ConfigUtils.GetCatchFishCatchType(id)
	local config = CatchFish_CatchConfig[id]
	assert(config ~= nil, "invalid CatchFish_CatchConfig id:" .. tostring(id))
	return config.Type
end


function ConfigUtils.GetCatchFishIcon(id)
	local config = CatchFish_FishConfig[id]
	assert(config ~= nil, "invalid CatchFish_CatchConfig id:" .. tostring(id))
	return config.Icon
end

function ConfigUtils.GetCatchFishType(id)
	local config = CatchFish_FishConfig[id]
	assert(config ~= nil, "invalid CatchFish_CatchConfig id:" .. tostring(id))
	return config.Type
end

--获取能量购买次数上限
function ConfigUtils.GetCatchFishBuyEnergyMaxCount()
	return #CatchFish_CommonConfig.ExchangePoint
end
--获取能量购买的配置
function ConfigUtils.GetCatchFishBuyEnergyInfo(index)
	return CatchFish_CommonConfig.ExchangePoint[index]
end

--获取老板对白动作
function ConfigUtils.GetBossDialogAnim(index)
	local config = CatchFish_CommonConfig.BossDialog[index]
	assert(config ~= nil, "invalid CatchFish_CommonConfig.BossDialog index:" .. tostring(index))
	return config[2]
end
--获取老板对白特效
function ConfigUtils.GetBossDialogEff(index)
	local config = CatchFish_CommonConfig.BossDialog[index]
	assert(config ~= nil, "invalid CatchFish_CommonConfig.BossDialog index:" .. tostring(index))
	return config[3]
end

--获取老板对白索引
function ConfigUtils.GetBossDialogIndexByScore(score)
	for i = #CatchFish_CommonConfig.BossDialog, 1, -1 do
		local v = CatchFish_CommonConfig.BossDialog[i]
		local needScore = v[1]
		if score >= needScore then
			return i
		end
	end
	return -1
end

---家园相关配置表--------------------------------------------------
---家具数据
function ConfigUtils.GetHomeFurnitureConfig(id)
	local config = HomeFurnitureConfig[id]
	assert(config ~= nil, "invalid omeFurnitureConfig id:" .. tostring(id))
	return config
end

function ConfigUtils.GetHomeFurnitureIcon(id)
	local config = HomeFurnitureConfig[id]
	assert(config ~= nil, "invalid Furniture id: "..tostring(id))
	return config.Icon, config.IconAtlas
end

function ConfigUtils.GetHomeFurnitureName(id)
	local config = HomeFurnitureConfig[id]
	assert(config ~= nil, "invalid Furniture id: "..tostring(id))
	return config.Name
end
function ConfigUtils.GetHomeFurnitureDesc(id)
    local config = HomeFurnitureConfig[id]
    assert(config ~= nil, "invalid Furniture id: "..tostring(id))
    return config.Desc or "我没有描述~"
end
function ConfigUtils.GetHomeFurniturePrefab(id)
    local config = HomeFurnitureConfig[id]
    assert(config ~= nil, "invalid Furniture id: "..tostring(id))
    return config.Prefab
end
function ConfigUtils.GetHomeFurnitureSettleLayer(id)
    local config = HomeFurnitureConfig[id]
    assert(config ~= nil, "invalid Furniture id: "..tostring(id))
    return config.Layer or 1
end
function ConfigUtils.GetHomeFurnitureCategory(id)
    local config = HomeFurnitureConfig[id]
    assert(config ~= nil, "invalid Furniture id: "..tostring(id))
    return config.Category
end

function ConfigUtils.GetHomeFurnitureRarity(id)
	local config = HomeFurnitureConfig[id]
	assert(config ~= nil, "invalid Furniture id: "..tostring(id))
	return config.Rarity
end
---
function ConfigUtils.GetHomeFurnitureGashaponConfig(id)
	local config = HomeFurnitureGashaponConfig[id]
	assert(config ~= nil, "invalid HomeFurnitureConfig id:" .. tostring(id))
	return config
end

---家园障碍配置
function ConfigUtils.GetHomeObstacleConfig(id)
    local config = HomeObstacleConfig[id]
    assert(config ~= nil, "invalid HomeObstacleConfig id:" .. tostring(id))
    return config
end
function ConfigUtils.GetHomeObstaclePreNodeConfig(id)
    local config = HomeObstacleConfig[id]
    assert(config ~= nil, "invalid GetHomeObstaclePreNodeConfig id:" .. tostring(id))
    return config.PreNode or {}
end
function ConfigUtils.GetHomeObstacleCostList(id)
    local config = HomeObstacleConfig[id]
    assert(config ~= nil, "invalid GetHomeObstacleCostList id:" .. tostring(id))
    return config.CostList or {}
end
function ConfigUtils.GetHomeObstacleGainList(id)
    local config = HomeObstacleConfig[id]
    assert(config ~= nil, "invalid GetHomeObstacleGainList id:" .. tostring(id))
    return config.RewardList or {}
end

---家园障碍区域配置
function ConfigUtils.GetHomeObstacleAreaConfig(strArea)
    local config = HomeObstacleAreaConfig[strArea]
    assert(config ~= nil, "invalid HomeObstacleAreaConfig id:" .. strArea)
    return config
end

---家园障碍区域prefab配置
function ConfigUtils.GetHomeObstacleAreaPrefabConfig(strArea)
    local config = HomeObstacleAreaPrefabConfig[strArea]
    assert(config ~= nil, "invalid HomeObstacleAreaPrefabConfig id:" .. strArea)
    return config
end
function ConfigUtils.GetHomeObstacleGroupPrefabConfig(strArea, strGroup)
    local config = this.GetHomeObstacleAreaPrefabConfig(strArea)
    if not config.ObstacleGroups then
        return nil
    end
    assert(config.ObstacleGroups[strGroup] ~= nil, "invalid GetHomeObstacleGroupPrefabConfig id:" .. strArea .. " " .. strGroup)
    return config.ObstacleGroups[strGroup]
end
function ConfigUtils.GetHomeObstaclePrefabConfig(strArea, strGroup, strObstacle)
    local config = this.GetHomeObstacleGroupPrefabConfig(strArea, strGroup)
    if not config.Obstacles then
        return nil
    end
    return config.Obstacles[strObstacle]
end



----
---获取家具类型图标
function ConfigUtils.GetHomeFurnitureCategoryIcon(iCategory)
    local atlasName = "HomeArrangement"
    local sprite = ""
    if iCategory == EnumHomeFurnitureCategory.None then
        sprite = "ArrangeHomeFurniture_iconAll"
    elseif iCategory == EnumHomeFurnitureCategory.Cabinet then
        sprite =  "ArrangeHomeFurniture_iconcabinet"
    elseif iCategory == EnumHomeFurnitureCategory.Table then
        sprite =  "ArrangeHomeFurniture_iconTable"
    elseif iCategory == EnumHomeFurnitureCategory.Chair then
        sprite =  "ArrangeHomeFurniture_iconchair"
    elseif iCategory == EnumHomeFurnitureCategory.Orn then
        sprite =  "ArrangeHomeFurniture_iconOrn"
    elseif iCategory == EnumHomeFurnitureCategory.Other then
        sprite =  "ArrangeHomeFurniture_iconother"
    elseif iCategory == EnumHomeFurnitureCategory.Ele then
        sprite =  "ArrangeHomeFurniture_iconele"
    elseif iCategory == EnumHomeFurnitureCategory.Whanging then
        sprite =  "ArrangeHomeFurniture_iconWhanging"
    elseif iCategory == EnumHomeFurnitureCategory.Rug then
        sprite =  "ArrangeHomeFurniture_iconrug"
    elseif iCategory == EnumHomeFurnitureCategory.Plant then
        sprite =  "ArrangeHomeFurniture_iconPlant"
    elseif iCategory == EnumHomeFurnitureCategory.Wall then
        sprite =  "ArrangeHomeFurniture_iconWall"
    elseif iCategory == EnumHomeFurnitureCategory.Floor then
        sprite =  "ArrangeHomeFurniture_iconfloor"
    end
    return atlasName, sprite
end
---获取家具类型名字
function ConfigUtils.GetHomeFurnitureCategoryName(iCategory)
    if iCategory == EnumHomeFurnitureCategory.None then
        return "全部"
    end
    if iCategory == EnumHomeFurnitureCategory.Cabinet then
        return "柜子"
    end
    if iCategory == EnumHomeFurnitureCategory.Table then
        return "桌子"
    end
    if iCategory == EnumHomeFurnitureCategory.Chair then
        return "椅子"
    end
    if iCategory == EnumHomeFurnitureCategory.Orn then
        return "摆件"
    end
    if iCategory == EnumHomeFurnitureCategory.Other then
        return "装饰"
    end
    if iCategory == EnumHomeFurnitureCategory.Ele then
        return "电器"
    end
    if iCategory == EnumHomeFurnitureCategory.Whanging then
        return "壁挂"
    end
    if iCategory == EnumHomeFurnitureCategory.Rug then
        return "地毯"
    end
    if iCategory == EnumHomeFurnitureCategory.Plant then
        return "植物"
    end
    if iCategory == EnumHomeFurnitureCategory.Wall then
        return "壁纸"
    end
    if iCategory == EnumHomeFurnitureCategory.Floor then
        return "地板"
    end
    return "NoName"
end



function ConfigUtils.GetHomeFurnitureGashaponRankInfos(list, rank)
	local rankList = {}
	for idx = 1, #list do
		if list[idx].Rank == rank then
			table.insert(rankList, list[idx])
		end
	end
	return rankList
end

--- 抽奖花费消耗
function ConfigUtils.GetHomeFurnitureGashaponCost(id)
	local config = this.GetHomeFurnitureGashaponConfig(id)
	return config.CostList
end

---获取飞船平面配置
function ConfigUtils.GetHomeWorldPlaneConfig(id)
	local config = HomeWorldPlaneConfig[id]
	assert(config ~= nil, "invalid HomeWorldPlaneConfig id:" .. tostring(id))
	return config
end

---获取家具预设配置
function ConfigUtils.GetHomeItemPrefabConfig(prefabName)
	local config = HomeItemPrefabConfig[prefabName]
	assert(config ~= nil, "invalid HomeItemPrefabConfig id:" .. tostring(prefabName))
	return config
end

function ConfigUtils.GetHomeItemPrefabPlanesConfig(prefabName)
	local config = this.GetHomeItemPrefabConfig(prefabName)
	assert(config ~= nil, "invalid HomeItemPrefabConfig id:" .. tostring(prefabName))
	return config
end


-----------------------------------------------------

---未成年作息表----------------------------------------

--是否在合法时段
function ConfigUtils.IsInUnderAgeAvailableHour(hour, min)
	local beginHour = UnderAgeAvailableDay.HoursOfDayBegin[1]
	local beginMin 	= UnderAgeAvailableDay.HoursOfDayBegin[2]
	local endHour 	= UnderAgeAvailableDay.HoursOfDayEnd[1]
	local endMin 	= UnderAgeAvailableDay.HoursOfDayEnd[2]
	if hour < beginHour or (hour == beginHour and min < beginMin) then
		return false
	end
	if hour > endHour or (hour == endHour and min >= endMin) then
		return false
	end
	return true
end

--是否在合法星期
function ConfigUtils.IsInUnderAgeAvailableWeekday(weekday)
	for _,v in ipairs(UnderAgeAvailableDay.DaysOfWeek) do
		if v == weekday then
			return true
		end
	end
	return false
end

--日期是否在白名单
function ConfigUtils.IsInUnderAgeAvailableWhiteList(year, month, day)
	local data = UnderAgeAvailableDay.WhiteList
	if not data[year] then
		return false
	end
	if not data[year][month] then
		return false
	end
	if #data[year][month] < 1 then
		return false
	end
	if data[year][month][1] == 0 then
		return true
	end
	for i,v in ipairs(data[year][month]) do
		if v == day then
			return true
		end
	end
	return false
end

--日期是否在黑名单
function ConfigUtils.IsInUnderAgeAvailableBlackList(year, month, day)
	local data = UnderAgeAvailableDay.BlackList
	if not data[year] then
		return false
	end
	if not data[year][month] then
		return false
	end
	if #data[year][month] < 1 then
		return false
	end
	if data[year][month][1] == 0 then
		return true
	end
	for i,v in ipairs(data[year][month]) do
		if v == day then
			return true
		end
	end
	return false
end


--获取不夜城换购角色座次列表
function ConfigUtils.GetSummonExchangeList()
	return SummonExchange
end