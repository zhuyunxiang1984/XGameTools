local json = require "cjson"

GamePlatform = {
	ANDROID = "android",
	APPLE = "ios",
}

GameChannels = {
	APPSTORE = 1,
	ANDROID_POOK = 2,
	ANDROID_TAPTAP = 3,
	ANDROID_HYKB = 4,
	ANDROID_4399 = 5,
	ANDROID_OPPO = 6,
	ANDROID_VIVO = 7,
	ANDROID_HUAWEI = 8,
	ANDROID_UC = 9,
	ANDROID_MI = 10,
	ANDROID_BILIBILI = 11,
	ANDROID_TENCENT = 12,
	ANDROID_BIBI = 13,
	ANDROID_MEITU = 14,
	ANDROID_NETEASE_CLOUD = 15,
	ANDROID_TENCENT_CLOUD = 16,
	ANDROID_CHUANGZHI_CLOUD = 17,
	ANDROID_MOMOYU = 18,
	ANDROID_7723 = 19,
}

PaymentType = {
	None = 0,
	Apple = 14,        -- appstore
	Zhifubao = 63,     -- 支付宝
	Weixin = 39,       -- 微信
	Oppo = 80022,      -- oppo
	Vivo = 80212,      -- vivo
	Huawei = 80215,    -- 华为
	Uc = 80126,        -- 九游UC
	Mi = 80061,        -- 小米
	Bilibili = 80169,  -- Bilibili
	Tencent = 80115,   -- 应用宝
	MoMoYu = 80245,    --摸摸鱼
}

PaymentResult = {
	Success = 9000,
	Cancel = 6001,
	NetworkError = 6002,
	Checking = 8000,
	PurchasingUnavailable = 9900,
	ProductUnavailable = 10000,
	RequestProductFail = 10001,
	PaymentInUpgrade = 10004,
	ExistingPurchasePending = 40000,
	PurchaseAfterAuth = 40010,
	CheckOrderTimeout = 9800,
	WaitingSdkTimeout = 15000,
	LostOrder = 9700,
	LostIapId = 9701,
	SubmitReceiptError = 9600,
	CreateOrderError = 9601,
	IapInProcessing = 9602,
	RepeatRequest = 5000,
	AuthSuccess = 9200,
	AccountInvalid = 30008,
	Failed = -1,
	AuthFailed = -2,
}

ChannelHelper = {}

ChannelAccountState = {
	None = "None",
	WaitingToken = "WaitingToken",
	WaitingUid = "WaitingUid",
}

local this = ChannelHelper
local _channelAccountState = nil
--渠道数据是否成年(默认为成年,信任渠道的检测结果)
local _IsAdult = true

function ChannelHelper.Init()
	this.ResetAccountState()
end

function ChannelHelper.StartWaitToken()
	_channelAccountState = ChannelAccountState.WaitingToken
end

function ChannelHelper.CanWaitToken()
	return _channelAccountState ~= ChannelAccountState.WaitingUid
end

function ChannelHelper.ResetAccountState()
	_channelAccountState = ChannelAccountState.None
end

function ChannelHelper.UseSdkExit()
	if Global.ChannelId == GameChannels.ANDROID_OPPO or
	   Global.ChannelId == GameChannels.ANDROID_VIVO or
	   Global.ChannelId == GameChannels.ANDROID_UC or 
	   Global.ChannelId == GameChannels.ANDROID_MI or 
	   Global.ChannelId == GameChannels.ANDROID_BILIBILI then
		return true
	end

	return false
end

function ChannelHelper.IsAdult()
	return _IsAdult
end

function ChannelHelper.SendDataToLua(jsonData)
	local data = json.decode(jsonData)
	if Global.ChannelId == GameChannels.ANDROID_TENCENT then
		if data.loginLimit == 1 then
			_IsAdult = false
		else
			_IsAdult = true
		end
	end
end

function ChannelHelper.LoginExtendDataResultFromSdk()
	-- do nothing for now
	if Global.ChannelId == GameChannels.ANDROID_HUAWEI then
		local channelExtendData = json.decode(ScriptBridge.ChannelExtendData)
		if channelExtendData.isAdult == 1 then
			_IsAdult = true
		else
			_IsAdult = false
		end
	elseif Global.ChannelId == GameChannels.ANDROID_MOMOYU then
		local channelExtendData = json.decode(ScriptBridge.ChannelExtendData)
		if channelExtendData.isAdult == true then
			_IsAdult = true
		else
			_IsAdult = false
		end
	elseif Global.ChannelId == GameChannels.ANDROID_OPPO then
		local channelExtendData = json.decode(ScriptBridge.ChannelExtendData)
		if channelExtendData.playerAge then
			XDebug.Log("LZ", channelExtendData.playerAge)
			_IsAdult = channelExtendData.playerAge >= RealNameData.UnderAge1
		end
	elseif Global.ChannelId == GameChannels.ANDROID_VIVO then
		local channelExtendData = json.decode(ScriptBridge.ChannelExtendData)
		if channelExtendData.age then
			XDebug.Log("LZ", channelExtendData.age)
			_IsAdult = channelExtendData.age >= RealNameData.UnderAge1
		end
	end
end

function ChannelHelper.LoginTokenResultFromSdk()
	if _channelAccountState == ChannelAccountState.WaitingToken then
		this.StartCheckToken()
		_channelAccountState = ChannelAccountState.WaitingUid
	end
end

function ChannelHelper.StartCheckToken()
	if not ScriptBridge.HasChannelToken() then
		CtrlManager.ShowMessageBox({message = "当前登录账号为空\n需要重新登录", single = true, onConfirm = Game.Restart})
		return false
	end

	local json = require "cjson"
	local msgType = 65280

	if Global.ChannelId == GameChannels.ANDROID_OPPO then
		local channelExtendData = json.decode(ScriptBridge.ChannelExtendData)
		local extendInfo = {}
		extendInfo["appname"] = UnityEngine.Application.identifier
		extendInfo["ssoid"] = channelExtendData.ssoid
		extendInfo["country"] = "iopen"
		NetManager.Send("TokenCheck3rd", {MsgType = msgType, Channelid = 50, Token = ScriptBridge.ChannelToken, Extend = json.encode(extendInfo)}, ChannelHelper.OnHandleProto)
	elseif Global.ChannelId == GameChannels.ANDROID_VIVO then
		NetManager.Send("TokenCheck3rd", {MsgType = msgType, Channelid = 87, Token = ScriptBridge.ChannelToken, Extend = ""}, ChannelHelper.OnHandleProto)
	elseif Global.ChannelId == GameChannels.ANDROID_HUAWEI then
		local channelExtendData = json.decode(ScriptBridge.ChannelExtendData)
		local extendInfo = {}
		extendInfo["appname"] = UnityEngine.Application.identifier
		extendInfo["ts"] = channelExtendData.ts
		extendInfo["playerId"] = channelExtendData.playerId
		extendInfo["playerLevel"] = channelExtendData.playerLevel
		NetManager.Send("TokenCheck3rd", {MsgType = msgType, Channelid = 83, Token = ScriptBridge.ChannelToken, Extend = json.encode(extendInfo)}, ChannelHelper.OnHandleProto)
	elseif Global.ChannelId == GameChannels.ANDROID_UC then
		local extendInfo = {}
		extendInfo["appname"] = UnityEngine.Application.identifier
		NetManager.Send("TokenCheck3rd", {MsgType = msgType, Channelid = 59, Token = ScriptBridge.ChannelToken, Extend = json.encode(extendInfo)}, ChannelHelper.OnHandleProto)
	elseif Global.ChannelId == GameChannels.ANDROID_MI then
		local channelExtendData = json.decode(ScriptBridge.ChannelExtendData)
		local extendInfo = {}
		extendInfo["appname"] = UnityEngine.Application.identifier
		extendInfo["userId"] = channelExtendData.uid
		NetManager.Send("TokenCheck3rd", {MsgType = msgType, Channelid = 131, Token = ScriptBridge.ChannelToken, Extend = json.encode(extendInfo)}, ChannelHelper.OnHandleProto)
	elseif Global.ChannelId == GameChannels.ANDROID_BILIBILI then
		local channelExtendData = json.decode(ScriptBridge.ChannelExtendData)
		local extendInfo = {}
		extendInfo["appname"] = UnityEngine.Application.identifier
		extendInfo["uid"] = channelExtendData.uid
		NetManager.Send("TokenCheck3rd", {MsgType = msgType, Channelid = 88, Token = ScriptBridge.ChannelToken, Extend = json.encode(extendInfo)}, ChannelHelper.OnHandleProto)
	elseif Global.ChannelId == GameChannels.ANDROID_TENCENT then
		local channelExtendData = json.decode(ScriptBridge.ChannelExtendData)
		local extendInfo = {}
		extendInfo["appname"] = UnityEngine.Application.identifier
		extendInfo["openid"] = channelExtendData.userId
		if channelExtendData.platform == 1 then
			-- QQ
			NetManager.Send("TokenCheck3rd", {MsgType = msgType, Channelid = 57, Token = ScriptBridge.ChannelToken, Extend = json.encode(extendInfo)}, ChannelHelper.OnHandleProto)
		else
			-- 微信
			NetManager.Send("TokenCheck3rd", {MsgType = msgType, Channelid = 58, Token = ScriptBridge.ChannelToken, Extend = json.encode(extendInfo)}, ChannelHelper.OnHandleProto)
		end
		-- record in local
		GameData.SetTencentLastLoginPlatform(channelExtendData.platform)
	elseif Global.ChannelId == GameChannels.ANDROID_MOMOYU then
		local channelExtendData = json.decode(ScriptBridge.ChannelExtendData)
		local extendInfo = {}
		extendInfo["appname"] = UnityEngine.Application.identifier
		extendInfo["open_id"] = channelExtendData.open_id
		NetManager.Send("TokenCheck3rd", {MsgType = msgType, Channelid = 154, Token = ScriptBridge.ChannelToken, Extend = json.encode(extendInfo)}, ChannelHelper.OnHandleProto)
	end

	return true
end

function ChannelHelper.LogoutFromSdk(result)
	if Game.HasAccount() then
		CtrlManager.ShowMessageBox({message = "渠道账号已登出\n请重新登录", single = true, onConfirm = Game.Restart})
	end
end

function ChannelHelper.ExitGameFromSdk(result)
	Game.Quit()
end

function ChannelHelper.CreateRoleToSdk(userId, nickname)
	local json = require "cjson"

	if Global.ChannelId == GameChannels.ANDROID_BILIBILI then
		local roleInfo = {}
		roleInfo["roleId"] = tostring(userId)
		roleInfo["roleName"] = nickname
		ScriptBridge.CreateRole(json.encode(roleInfo))
	end
end

function ChannelHelper.ReportRestartToSdk()
	ScriptBridge.ResetChannelData()
	if Global.ChannelId == GameChannels.ANDROID_BILIBILI then
		ScriptBridge.ReportRestart()
	elseif Global.ChannelId == GameChannels.ANDROID_TENCENT then
		GameData.SetTencentLastLoginPlatform(nil)
		ScriptBridge.ReportRestart()
	end
end

function ChannelHelper.UploadRoleToSdk()
	local json = require "cjson"

	if Global.ChannelId == GameChannels.ANDROID_VIVO then
		local roleInfo = {}
		roleInfo["roleId"] = tostring(GameData.GetDefaultAccountUserId())
		roleInfo["roleLevel"] = "1"
		roleInfo["roleName"] = GameData.GetDefaultNickName()
		roleInfo["serverId"] = "1"
		roleInfo["serverName"] = "正式服"
		ScriptBridge.UploadRoleInfo(json.encode(roleInfo))
	elseif Global.ChannelId == GameChannels.ANDROID_BILIBILI then
		local roleInfo = {}
		roleInfo["roleId"] = tostring(GameData.GetDefaultAccountUserId())
		roleInfo["roleName"] = GameData.GetDefaultNickName()
		roleInfo["serverId"] = "3592"
		roleInfo["serverName"] = "bilibili区"
		ScriptBridge.UploadRoleInfo(json.encode(roleInfo))
	elseif Global.ChannelId == GameChannels.ANDROID_TENCENT then
		ScriptBridge.ReportAccountLogin()
	end
end

function ChannelHelper.OnHandleProto(proto, data, requestData)
	if proto == "TokenCheck3rd" then
		local json = require "cjson"
		local ret = json.decode(data.Data)
		if ret.ret ~= "S" then
			CtrlManager.ShowMessageBox({message = "账号验证失败\n请重新登录", single = true, onConfirm = Game.Restart})
			return
		end

		-- channel uid
		if Global.ChannelId == GameChannels.ANDROID_MI then
			ScriptBridge.ChannelUid = ret.data.uid
		else
			ScriptBridge.ChannelUid = ret.data
		end
		NetManager.Send("AccountCheck3rd", {Channelid = Global.ChannelId, ChannelUid = ScriptBridge.ChannelUid}, ChannelHelper.OnHandleProto)
	elseif proto == "AccountCheck3rd" then
		local existed = data.AccountExist
		GameNotifier.Notify(GameEvent.ChannelTokenChecked, existed)
	end
end
-------------------------------------------------------------------------------------------
-- 买量
BokeAdEventType = {
	Register = 1,
	Login = 2,
	Purchase = 3,
	CustomEvent = 4,
	EffectiveUserEvent = 5,
	TutorialEvent = 6,
	PanelEvent = 7,
}

function ChannelHelper.NeedReportToBokeAd()
	return Global.HasBokeSdk()
end

function ChannelHelper.ReportToBokeAd(eventType, eventData)
	if not this.NeedReportToBokeAd() then
		return
	end

	local json = require "cjson"
	ScriptBridge.ReportEvent(eventType, json.encode(eventData))
end

------------------------------------------------
--是否有社区功能
function ChannelHelper.IsSDKHasMoment()
	if not FrameworkAdapter.IsSupport(ScriptBridge, "OpenMoment") then
		return false
	end
	XDebug.Log("LZ", "ChannelId:", Global.ChannelId)
	return Global.ChannelId == GameChannels.ANDROID_TAPTAP
end

--打开社区
function ChannelHelper.OpenMoment()
	if not this.IsSDKHasMoment() then
		return
	end
	ScriptBridge.OpenMoment()
end
--关闭社区
function ChannelHelper.CloseMoment()
	if not this.IsSDKHasMoment() then
		return
	end
	ScriptBridge.CloseMoment()
end

--开启Geetest验证
function ChannelHelper.StartGeetest(callback)
	if this.OnGeetestVerifyCallback then
		XDebug.Log('GGYY', "already StartGeetest")
		return
	end
	this.OnGeetestVerifyCallback = callback
	this.GeetestData = {}
	ScriptBridge.StartGeetest()
end

--GeetestAPI1回调
function ChannelHelper.OnGeetestAPI1Complete(result)
	XDebug.Log('GGYY', "OnGeetestAPI1Complete", result)
	local jsonObj = json.decode(result)
	this.GeetestData.Challenge = jsonObj["challenge"]
end

--Geetest回调
function ChannelHelper.OnGeetestAPI2Complete(result)
	XDebug.Log('GGYY', "OnGeetestAPI2Complete", result)
	if string.len(result) < 1 then
		if this.OnGeetestVerifyCallback then
			this.OnGeetestVerifyCallback(false)
			this.OnGeetestVerifyCallback = nil
		end
		return
	end
	local jsonObj = json.decode(result)

	this.GeetestData.ModelProbability 	 = jsonObj["model_probability"]
	this.GeetestData.WebSimulator 		 = jsonObj["web_simulator"]
	this.GeetestData.Duration 			 = jsonObj["duration"]

	local status = jsonObj["result"]
	if this.OnGeetestVerifyCallback then
		if status == "success" then
			this.OnGeetestVerifyCallback(true)
		else
			this.OnGeetestVerifyCallback(false)
		end
		this.OnGeetestVerifyCallback = nil
	end
end