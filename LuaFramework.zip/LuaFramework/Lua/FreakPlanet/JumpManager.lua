JumpManager = {}

local this = JumpManager

local _jumpParam = nil
local _ctrlHintParameter = {}
local _hintGoalId = nil

local _hintExplorePlanetGoalId = nil
local _hintExplorePlanetId = nil
----------------------------------------------------
function JumpManager.Init()
	_jumpParam = nil
	_ctrlHintParameter = {}
	_hintGoalId = nil
	_hintExplorePlanetGoalId = nil
	_hintExplorePlanetId = nil
end

function JumpManager.JumpToPlanetArea(planetAreaId)
	this.CleanHintGoal(true)
	local ctrlName = CtrlNames.ExploreGuide
	if CtrlManager.IsCtrlOpen(ctrlName) then
		CtrlManager.PopToPanel(ctrlName)
		local ctrl = CtrlManager.GetCtrlByName(ctrlName)
		ctrl:DoJump(planetAreaId)
		return
	end

	CtrlManager.PopToPlanet()
	local ctrl = CtrlManager.GetCtrlByName(CtrlNames.Planet)
	ctrl:JumpTo({ctrlName = ctrlName, ctrlParameter = planetAreaId})
end

function JumpManager.JumpToGoal(goalId)
	local goalType = ConfigUtils.GetGoalType(goalId)
	if goalType == GoalType.Achievement then
		local postcardId = ConfigUtils.GetPostcardOfAchievementGoal(goalId)
		this.JumpToPostcard(postcardId)
		return
	elseif goalType == GoalType.Newbie then
		this.JumpToNewbie(goalId)
		return
	elseif goalType == GoalType.Activity then
		this.JumpToActivity(goalId)
		return
	end

	this.CleanHintGoal(true)
	-- if open no transition
	local ctrlName = CtrlNames.Goal
	if CtrlManager.IsCtrlOpen(ctrlName) then
		CtrlManager.PopToPanel(ctrlName)
		local ctrl = CtrlManager.GetCtrlByName(ctrlName)
		ctrl:DoJump()
		return
	end

	_jumpParam = {ctrlName = ctrlName}
	-- when do wait transition, it muse be load new panel
	CtrlManager.DoWaitTransition(ctrlName, nil, this.JumpImpl)
end

function JumpManager.JumpToPostcard(postcardId)
	-- still locked
	if not GameData.IsModuleUnlocked(ModuleNames.Gallery) then
        return
    end

    this.CleanHintGoal(true)
    -- still open
    local ctrlName = CtrlNames.GalleryDiary
    if CtrlManager.IsCtrlOpen(ctrlName) then
    	return
    end
    
	_jumpParam = {ctrlName = ctrlName, ctrlParameter = postcardId}
	-- when do wait transition, it muse be load new panel
	CtrlManager.DoWaitTransition(ctrlName, nil, this.JumpImpl)
end

function JumpManager.JumpToNewbie(goalId)
	-- still locked
	if not GameData.IsModuleUnlocked(ModuleNames.Newbie) then
        return
    end

	this.CleanHintGoal(true)
	-- still open
    local ctrlName = CtrlNames.Newbie
    if CtrlManager.IsCtrlOpen(ctrlName) then
    	return
    end

	_jumpParam = {ctrlName = ctrlName, ctrlParameter = goalId}
	-- when do wait transition, it muse be load new panel
	CtrlManager.DoWaitTransition(ctrlName, nil, this.JumpImpl)
end

function JumpManager.JumpToActivity(goalId)
	-- still locked
	if not GameData.IsModuleUnlocked(ModuleNames.Activity) then
        return
    end

	this.CleanHintGoal(true)
	-- still open
    local ctrlName = CtrlNames.ActivityGoal
    if CtrlManager.IsCtrlOpen(ctrlName) then
    	CtrlManager.PopToPanel(ctrlName)
    	return
    end

    local hasGoal = GameData.HasTimeLimitActivity()
    ctrlName = CtrlNames.Activity
    if CtrlManager.IsCtrlOpen(ctrlName) then
    	CtrlManager.PopToPanel(ctrlName)
    	if hasGoal then
    		CtrlManager.OpenPanel(CtrlNames.ActivityGoal)
    	end
    	return
    end

    ctrlName = CtrlNames.Arena
    if CtrlManager.IsCtrlOpen(ctrlName) then
    	CtrlManager.PopToPanel(ctrlName)
    	CtrlManager.OpenPanel(CtrlNames.Activity)
    	if hasGoal then
    		CtrlManager.OpenPanel(CtrlNames.ActivityGoal)
    	end
    	return
    end

    _jumpParam = {ctrlName = ctrlName, ctrlParameter = goalId}
	-- when do wait transition, it muse be load new panel
	CtrlManager.DoWaitTransition(ctrlName, nil, this.JumpImpl)
end

function JumpManager.JumpFromGoal(goalId)
	this.CleanHintGoal(true)
	local ret = UIHelper.GetSourceCtrlByGoalId(goalId)
	if ret.code == RetCode.OK then
		if ret.ctrlName == CtrlNames.Planet then
			CtrlManager.PopToPlanet()
			local ctrl = CtrlManager.GetCtrlByName(CtrlNames.Planet)
			ctrl:JumpTo(ret)
			this.MarkExplorePlanetGoal(goalId, ret.ctrlParameter)
		else
			if CtrlManager.IsCtrlOpen(ret.ctrlName) then
				CtrlManager.PopToPanel(ret.ctrlName)
				local ctrl = CtrlManager.GetCtrlByName(ret.ctrlName)
				ctrl:DoJump(ret.ctrlParameter)
			else
				_jumpParam = ret
				_jumpParam.goalId = goalId
				CtrlManager.DoWaitTransition(ret.ctrlName, nil, this.JumpImpl)
			end
		end
	end

	return ret.code
end

function JumpManager.CloseToActivityExplore(themeId)
	CtrlManager.PopToPanel(CtrlNames.Arena)
	local exploreId = ConfigUtils.GetActivityThemeExplore(themeId)
    CtrlManager.OpenPanel(CtrlNames.ExploreCharacter, {themeId = themeId, exploreId = exploreId})
end

function JumpManager.JumpFromActivityGoal(goalId)
	local triggers = ConfigUtils.GetGoalTriggers(goalId)
	local conditions = ConfigUtils.GetGoalConditions(goalId)
	local isCollectPet = (Helper.TableContains(triggers, TriggerType.CollectItem) and conditions[1].Type == ItemType.Pet)
	if Helper.TableContains(triggers, TriggerType.ActivityExplore) or Helper.TableContains(triggers, TriggerType.ActivityExploreCost) or isCollectPet then
		this.CleanHintGoal(true)
		_hintGoalId = goalId
		if GameData.GetUnsettledActivityTheme() == nil then
			local currentTheme = GameData.GetCurrentActivityTheme()
			if currentTheme ~= nil and ConfigUtils.CanExploreInActivityTheme(currentTheme) then
				CtrlManager.DoWaitTransition(CtrlNames.ExploreCharacter, nil, JumpManager.CloseToActivityExplore, currentTheme)
    		end
    	else
    		CtrlManager.PopToPanel(CtrlNames.Arena)
		end
		return RetCode.OK
	elseif Helper.TableContains(triggers, TriggerType.ActivityBattle) then
		local themeId, themeEndTime = GameData.GetCurrentActivityTheme()
		if themeId ~= nil and ConfigUtils.CanBattleInActivityTheme(themeId) then
			this.CleanHintGoal(true)
			CtrlManager.PopPanel()
			_hintGoalId = goalId
			CtrlManager.OpenPanel(CtrlNames.ActivityBattle, {themeId = themeId, endTime = themeEndTime})
			return RetCode.OK
		else
			return RetCode.ActivityBattleInvalid
		end
	else
		return this.JumpFromGoal(goalId)
	end
end

function JumpManager.JumpToArena()
	this.CleanHintGoal(true)
	local ctrlName = CtrlNames.Arena
	if CtrlManager.IsCtrlOpen(ctrlName) then
		CtrlManager.PopToPanel(ctrlName)
		return
	end

	CtrlManager.PopToPlanet()
	local ctrl = CtrlManager.GetCtrlByName(CtrlNames.Planet)
	ctrl:JumpTo({ctrlName = ctrlName})
end

function JumpManager.JumpFromItemSource(ret)
	this.CleanHintGoal(true)
	-- if open no transition
	local ctrlName = ret.ctrlName
	if CtrlManager.IsCtrlOpen(ctrlName) then
		CtrlManager.PopToPanel(ctrlName)
		local ctrl = CtrlManager.GetCtrlByName(ctrlName)
		ctrl:DoJump(ret.ctrlParameter)
		return true
	end

	_jumpParam = ret
	CtrlManager.DoWaitTransition(ctrlName, nil, this.JumpImpl)
	return true
end

function JumpManager.CloseToExploreCharacter(areaId)
	CtrlManager.OpenPanel(CtrlNames.ExploreCharacter, {areaId = areaId})
end

function JumpManager.JumpImpl()
	assert(_jumpParam ~= nil, "no jump parameter")
	local ctrlName = _jumpParam.ctrlName

	-- if CtrlNames.Laboratory, no need close the panels
	if ctrlName == CtrlNames.Laboratory then
		local ctrlParameter = _jumpParam.ctrlParameter
		if not ConfigUtils.IsValidItem(ctrlParameter) then
			ctrlParameter = nil
		end
		CtrlManager.OpenPanel(CtrlNames.Laboratory, {targetRecipeId = ctrlParameter})
	else
		CtrlManager.PopToPlanet()
		-- jump
		local ctrl = CtrlManager.GetCtrlByName(CtrlNames.Planet)
		ctrl:JumpTo(_jumpParam)
	end

	local ctrl = CtrlManager.GetCtrlByName(ctrlName)
	if ctrlName ~= CtrlNames.Planet and ctrl ~= nil then
		-- hint parameter
		local hintParameter = _jumpParam.hintParameter
		if hintParameter ~= nil then
			_ctrlHintParameter[ctrlName] = hintParameter
		end
		-- hint goal
		_hintGoalId = _jumpParam.goalId
	end

	-- clean the jump data
	_jumpParam = nil
	-- jump goal changed
	this.MarkJumpGoalChanged()
end
----------------------------------------------------
function JumpManager.CanJumpToPlanetArea(areaId)
	if GameData.IsPlanetAreaExploring(areaId) then
		return false
	end

	if not GameData.HasAvailableExploreTeam() then
		return false
	end

	return true
end
----------------------------------------------------
function JumpManager.Closing(ctrl)
	local ctrlName = ctrl:CtrlName()
	_ctrlHintParameter[ctrlName] = nil
end

function JumpManager.MarkJumpGoalChanged()
	GameNotifier.Notify(GameEvent.JumpGoalChanged)
end

function JumpManager.GetHintParameter(ctrlName)
	return _ctrlHintParameter[ctrlName]
end

function JumpManager.CleanHintGoal(cleanPlanetGoal)
	_hintGoalId = nil

	cleanPlanetGoal = cleanPlanetGoal or false
	if cleanPlanetGoal then
		this.CleanHintExplorePlanetGoal()
	end

	this.MarkJumpGoalChanged()
end

function JumpManager.MarkExplorePlanetGoal(goalId, planetId)
	this.CleanHintExplorePlanetGoal()
	if ConfigUtils.IsValidItem(planetId) then
		_hintExplorePlanetGoalId = goalId
		_hintExplorePlanetId = planetId
	end

	this.MarkJumpGoalChanged()
end

function JumpManager.CheckToCleanExplorePlanetGoal(planetId)
	if planetId ~= _hintExplorePlanetId then
		this.CleanHintExplorePlanetGoal()
		this.MarkJumpGoalChanged()
	end
end

function JumpManager.CleanHintExplorePlanetGoal()
	_hintExplorePlanetGoalId = nil
	_hintExplorePlanetId = nil
end

function JumpManager.GetHintGoals()
	local ret = {}

	if _hintGoalId ~= nil then
		table.insert(ret, _hintGoalId)
	end

	if _hintExplorePlanetGoalId ~= nil then
		table.insert(ret, _hintExplorePlanetGoalId)
	end

	if #ret == 0 then
		local mainGoalId = GameData.GetFirstRunningMainGoal()
		if mainGoalId ~= nil then
			table.insert(ret, mainGoalId)
		end
	end

	return ret
end

function JumpManager.IsItemMeetGoalConditions(itemId, goalId)
	local input = GameData.SetupItemGoalData(itemId, 1)
	local conditions = ConfigUtils.GetGoalConditions(goalId)

	for idx = 1, #conditions do
		if GameData.IsGoalConditionMatched(conditions[idx], input, true) then
			return true
		end
	end

	return false
end

function JumpManager.IsItemMeetGoalStrictConditions(itemId, goalId)
	local itemType = ConfigUtils.GetItemTypeFromId(itemId)
	local conditions = ConfigUtils.GetGoalConditions(goalId)

	for idx = 1, #conditions do
		if itemType == conditions[idx].Type and conditions[idx].Value == itemId then
			return true
		end
	end

	return false
end

function JumpManager.IsBattleMeetGoalConditions(battleIdx, goalId)
	local conditions = ConfigUtils.GetGoalConditions(goalId)
	for idx = 1, #conditions do
		if (conditions[idx].Type == ItemType.ArenaBattle or conditions[idx].Type == ItemType.ActivityBattle) and conditions[idx].Value == battleIdx then
			return true
		end
	end
	return false
end

function JumpManager.IsPlanetAreaMeetGoalConditions(planetAreaId, goalId)
	if not GameData.IsPlanetAreaUnlocked(planetAreaId) then
		return false
	end

	local conditions = ConfigUtils.GetGoalConditions(goalId)
	for idx = 1, #conditions do
		if conditions[idx].Value == planetAreaId or conditions[idx].Area == planetAreaId then
			return true
		end

		-- make sure area is not specified
		if not ConfigUtils.IsValidItem(conditions[idx].Area) then
			if conditions[idx].Type == ItemType.Challenge then
				if ConfigUtils.IsValidItem(conditions[idx].Value) then
					local thisAreaId = ConfigUtils.GetAreaOfChallenge(conditions[idx].Value)
					if thisAreaId == planetAreaId then
						return true
					end
				end
			elseif conditions[idx].Type == ItemType.Enemy then
				if ConfigUtils.IsValidItem(conditions[idx].Value) then
					local isSourceArea = ConfigUtils.IsEnemyFromArea(conditions[idx].Value, planetAreaId)
					if isSourceArea then
						return true
					end
				end
			elseif conditions[idx].Type == ItemType.Pet then
				if ConfigUtils.IsValidItem(conditions[idx].Value) then
					local isSourceArea = ConfigUtils.IsPetFromArea(conditions[idx].Value, planetAreaId)
					if isSourceArea then
						return true
					end
				end
			elseif conditions[idx].Type == ItemType.Goods then
				if ConfigUtils.IsValidItem(conditions[idx].Value) then
					local isSourceArea = ConfigUtils.IsGoodsFromArea(conditions[idx].Value, planetAreaId)
					if isSourceArea then
						return true
					end
				end
			end
		end
	end

	return false
end

function JumpManager.IsAreaMeetExploreGoalCondition(condition, planetAreaId)
	local planetId = ConfigUtils.GetPlanetOfArea(planetAreaId)
	local itemId = condition.Value
	local itemType = condition.Type
	if itemType == ItemType.Planet then
		if itemId == -1 or itemId == planetId then
			return true
		end
	elseif itemType == ItemType.PlanetArea then
		if itemId == -1 or itemId == planetAreaId then
			return true
		end
	elseif itemType == ItemType.Time then
		if itemId == planetAreaId or itemId == planetId then
			return true
		end
	elseif itemType == ItemType.Enemy then
		if ConfigUtils.IsValidItem(itemId) then
			local isSourceArea = ConfigUtils.IsEnemyFromArea(itemId, planetAreaId)
			if isSourceArea then
				return true
			end
		else
			return true
		end
	elseif itemType == ItemType.Goods then
		if ConfigUtils.IsValidItem(itemId) then
			local isSourceArea = ConfigUtils.IsGoodsFromArea(itemId, planetAreaId)
			if isSourceArea then
				return true
			end
		else
			return true
		end
	end

	return false
end

function JumpManager.IsCharacterMeetExploreGoalConditions(characterId, planetAreaId, goalId)
	local conditions = ConfigUtils.GetGoalConditions(goalId)

	for idx = 1, #conditions do
		local needCharacters = {}
		if conditions[idx].Character ~= nil then
			for cidx = 1, #conditions[idx].Character do
				local cid = conditions[idx].Character[cidx]
				needCharacters[cid] = 1
			end
		end
		
		if conditions[idx].Skin ~= nil then
			for skinIdx = 1, #conditions[idx].Skin do
				local skinId = conditions[idx].Skin[skinIdx]
				local cid = ConfigUtils.GetCharacterOfSkin(skinId)
				needCharacters[cid] = 1
			end
		end

		if conditions[idx].TagList ~= nil then
			if ConfigUtils.IsItemMatchTagList(characterId, conditions[idx].TagList) then
				needCharacters[characterId] = 1
			end
		end

		if needCharacters[characterId] ~= nil then
			if this.IsAreaMeetExploreGoalCondition(conditions[idx], planetAreaId) then
				return true
			end
		end 
	end

	return false
end

function JumpManager.IsCharacterMeetActivityExploreGoalConditions(characterId, goalId)
	local conditions = ConfigUtils.GetGoalConditions(goalId)

	for idx = 1, #conditions do
		local needCharacters = {}
		if conditions[idx].Character ~= nil then
			for cidx = 1, #conditions[idx].Character do
				local cid = conditions[idx].Character[cidx]
				needCharacters[cid] = 1
			end
		end
		
		if conditions[idx].Skin ~= nil then
			for skinIdx = 1, #conditions[idx].Skin do
				local skinId = conditions[idx].Skin[skinIdx]
				local cid = ConfigUtils.GetCharacterOfSkin(skinId)
				needCharacters[cid] = 1
			end
		end

		if conditions[idx].TagList ~= nil then
			if ConfigUtils.IsItemMatchTagList(characterId, conditions[idx].TagList) then
				needCharacters[characterId] = 1
			end
		end

		if needCharacters[characterId] ~= nil then
			return true
		end 
	end

	return false
end

function JumpManager.IsCharacterMeetGoalConditions(characterId, goalId)
	local conditions = ConfigUtils.GetGoalConditions(goalId)

	for idx = 1, #conditions do
		local needCharacters = conditions[idx].Character or {}
		if Helper.TableContains(needCharacters, characterId) then
			return true
		end

		local itemId = conditions[idx].Value
		local itemType = conditions[idx].Type
		if itemType == ItemType.Character then
			if itemId == characterId then
				return true
			end
		elseif itemType == ItemType.Equipment then
			if ConfigUtils.IsValidItem(itemId) then
				local equipmentList = ConfigUtils.GetCharacterEquipmentList(characterId)
				if Helper.TableContains(equipmentList, itemId) then
					return  true
				end
			end
		elseif itemType == ItemType.Challenge then
			if ConfigUtils.IsValidItem(itemId) then
				local challengeCharacter = ConfigUtils.GetCharacterOfChallenge(itemId)
				if challengeCharacter == characterId then
					return true
				end
			end
		elseif itemType == ItemType.Skin then
			if ConfigUtils.IsValidItem(itemId) then
				local ownerCharacter = ConfigUtils.GetCharacterOfSkin(itemId)
				if ownerCharacter == characterId then
					return true
				end
			end
		end
	end

	return false
end

function JumpManager.IsRecipeMeetCraftConditions(recipeId, goalId)
	local conditions = ConfigUtils.GetGoalConditions(goalId)

	for idx = 1, #conditions do
		local itemId = conditions[idx].Value
		if ConfigUtils.IsValidItem(itemId) then
			local needRecipeId = ConfigUtils.GetGoodsLabRecipe(itemId)
			if needRecipeId == recipeId then
				return true
			end
		end
	end

	return false
end

function JumpManager.IsRecipeMeetCraftUseConditions(recipeId, goalId)
	local conditions = ConfigUtils.GetGoalConditions(goalId)

	for idx = 1, #conditions do
		local itemId = conditions[idx].Value
		if ConfigUtils.IsValidItem(itemId) then
			local craftSourceList = ConfigUtils.GetCraftSourceListOfLabRecipe(recipeId)
			if Helper.TableContains(craftSourceList, itemId) then
				return true
			end
		end
	end

	return false
end

function JumpManager.IsEquipmentMeetChallenge(equipId, goalId)
	if GameData.IsEquipmentUnlocked(equipId) then
		return false
	end

	local conditions = ConfigUtils.GetGoalConditions(goalId)
	for idx = 1, #conditions do
		local itemId = conditions[idx].Value
		local itemType = conditions[idx].Type
		if itemType == ItemType.Challenge then
			if ConfigUtils.IsValidItem(itemId) then
				local unlockChallenge = ConfigUtils.GetEquipmentUnlockChallenge(equipId)
				if unlockChallenge == itemId then
					return true
				end
			end
		end
	end

	return false
end

function JumpManager.IsEnemyMeetGoal(enemyId, goalId)
	local conditions = ConfigUtils.GetGoalConditions(goalId)
	for idx = 1, #conditions do
		local itemId = conditions[idx].Value
		local itemType = conditions[idx].Type
		if itemType == ItemType.Enemy then
			if ConfigUtils.IsValidItem(itemId) then
				if itemId == enemyId then
					return true
				end
			end
		elseif itemType == ItemType.Goods then
			if ConfigUtils.IsValidItem(itemId) then
				local dropList = ConfigUtils.GetEnemyDropList(enemyId)
				if Helper.TableContains(dropList, itemId) then
					return true
				end
			end
		elseif itemType == ItemType.Pet then
			local petId = ConfigUtils.GetPetOfEnemy(enemyId)
			if petId == itemId then
				return true
			end
		end
	end

	return false
end

function JumpManager.IsSkinMeetGoal(skinId, goalId)
	if GameData.IsSkinUnlocked(skinId) then
		return false
	end

	local conditions = ConfigUtils.GetGoalConditions(goalId)
	for idx = 1, #conditions do
		local itemId = conditions[idx].Value
		local itemType = conditions[idx].Type
		if itemType == ItemType.Challenge then
			if ConfigUtils.IsValidItem(itemId) then
				local unlockChallenge = ConfigUtils.GetSkinUnlockChallenge(skinId)
				if unlockChallenge == itemId then
					return true
				end
			end
		elseif itemType == ItemType.Skin then
			if ConfigUtils.IsValidItem(itemId) then
				if skinId == itemId then
					return true
				end
			end
		end
	end

	return false
end

function JumpManager.IsWorkShopMeetConditions(workShopId, goalId)
	if not GameData.IsWorkShopUnlocked(workShopId) then
		return false
	end

	local conditions = ConfigUtils.GetGoalConditions(goalId)
	for idx = 1, #conditions do
		local itemId = conditions[idx].Value
		local itemType = conditions[idx].Type
		if itemType == ItemType.Goods then
			if ConfigUtils.IsValidItem(itemId) and ConfigUtils.IsItemFromWorkShop(workShopId, itemId) then
				return true
			end
		end
	end

	return false
end

function JumpManager.IsPetMeetGoalConditions(petId, planetAreaId, goalId)
	local conditions = ConfigUtils.GetGoalConditions(goalId)
	for idx = 1, #conditions do
		local isAreaMatch = this.IsAreaMeetExploreGoalCondition(conditions[idx], planetAreaId)
		if isAreaMatch then
			local needPetId = conditions[idx].Pet
			if ConfigUtils.IsValidItem(needPetId) and needPetId == petId then
				return true
			end

			local characterNum = conditions[idx].CharacterNum or 0
			if conditions[idx].TagList ~= nil and characterNum > 0 then
				if ConfigUtils.IsItemMatchTagList(petId, conditions[idx].TagList) then
					return true
				end
			end
		end
	end

	return false
end

function JumpManager.IsPetMeetActivityGoalConditions(petId, goalId)
	local conditions = ConfigUtils.GetGoalConditions(goalId)
	for idx = 1, #conditions do
		-- needed pet
		local needPetId = conditions[idx].Pet
		if ConfigUtils.IsValidItem(needPetId) and needPetId == petId then
			return true
		end

		local characterNum = conditions[idx].CharacterNum or 0
		if conditions[idx].TagList ~= nil and characterNum > 0 then
			if ConfigUtils.IsItemMatchTagList(petId, conditions[idx].TagList) then
				return true
			end
		end
	end

	return false
end

function JumpManager.IsItemMeetExploreCostGoalConditions(itemId, areaId, goalId)
	local conditions = ConfigUtils.GetGoalConditions(goalId)
	for idx = 1, #conditions do
		-- needed pet
		local needAreaId = conditions[idx].Area
		if not ConfigUtils.IsValidItem(needAreaId) or needAreaId == areaId then
			if conditions[idx].Value == itemId then
				return true
			end
		end
	end

	return false
end

function JumpManager.MatchGoalOfTriggerType(itemId, triggerType, cmpFunc)
	local hintGoals = this.GetHintGoals()
	cmpFunc = cmpFunc or this.IsItemMeetGoalConditions

	for idx = 1, #hintGoals do
		local goalId = hintGoals[idx]
		local triggers = ConfigUtils.GetGoalTriggers(goalId)
		if Helper.TableContains(triggers, triggerType) then 
			local match = cmpFunc(itemId, goalId)
			if match then
				return true
			end
		end
	end

	return false
end

function JumpManager.MatchCraftGoal(recipeId)
	local hintGoals = this.GetHintGoals()

	for idx = 1, #hintGoals do
		local goalId = hintGoals[idx]
		local triggers = ConfigUtils.GetGoalTriggers(goalId)
		local triggerType = triggers[1]
		if triggerType == TriggerType.Craft then 
			local match = this.IsRecipeMeetCraftConditions(recipeId, goalId)
			if match then
				return true
			end
		elseif triggerType == TriggerType.CraftUse then
			local match = this.IsRecipeMeetCraftUseConditions(recipeId, goalId)
			if match then
				return true
			end
		end
	end

	return false
end

function JumpManager.MatchChallengeGoal(itemId)
	return this.MatchGoalOfTriggerType(itemId, TriggerType.Challenge, this.IsItemMeetGoalStrictConditions)
end

function JumpManager.MatchPetOfExploreGoal(petId, planetAreaId)
	if not ConfigUtils.IsValidItem(planetAreaId) then
		return false
	end
	
	local hintGoals = this.GetHintGoals()

	for idx = 1, #hintGoals do
		local goalId = hintGoals[idx]
		local triggers = ConfigUtils.GetGoalTriggers(goalId)
		local triggerType = triggers[1]
		if triggerType == TriggerType.Explore then 
			local match = this.IsPetMeetGoalConditions(petId, planetAreaId, goalId)
			if match then
				return true
			end
		end
	end

	return false
end

function JumpManager.MatchPetOfActivityExploreGoal(petId)
	local hintGoals = this.GetHintGoals()

	for idx = 1, #hintGoals do
		local goalId = hintGoals[idx]
		local triggers = ConfigUtils.GetGoalTriggers(goalId)
		local triggerType = triggers[1]
		if triggerType == TriggerType.ActivityExplore then 
			local match = this.IsPetMeetActivityGoalConditions(petId, goalId)
			if match then
				return true
			end
		end
	end

	return false
end

function JumpManager.MatchCharacterInCharacterList(characterId)
	local hintGoals = this.GetHintGoals()
	for idx = 1, #hintGoals do
		local goalId = hintGoals[idx]
		local triggers = ConfigUtils.GetGoalTriggers(goalId)
		local triggerType = triggers[1]
		if triggerType == TriggerType.UnlockSkill or triggerType == TriggerType.UsingCostume then
			local matched = this.IsItemMeetGoalStrictConditions(characterId, goalId)
			if matched then
				return true
			end
		elseif triggerType == TriggerType.CollectItem or triggerType == TriggerType.CharacterChallenge or triggerType == TriggerType.UpgradeEquipment then
			local matched = this.IsCharacterMeetGoalConditions(characterId, goalId)
			if matched then
				return true
			end
		end
	end

	return false
end

function JumpManager.MatchCharacterOfExploreGoal(characterId, planetAreaId)
	local hintGoals = this.GetHintGoals()
	for idx = 1, #hintGoals do
		local goalId = hintGoals[idx]
		local triggers = ConfigUtils.GetGoalTriggers(goalId)
		local triggerType = triggers[1]
		if triggerType == TriggerType.Explore then 
			local match = this.IsCharacterMeetExploreGoalConditions(characterId, planetAreaId, goalId)
			if match then
				return true
			end
		end
	end

	return false
end

function JumpManager.MatchCharacterOfActivityExploreGoal(characterId)
	local hintGoals = this.GetHintGoals()
	for idx = 1, #hintGoals do
		local goalId = hintGoals[idx]
		local triggers = ConfigUtils.GetGoalTriggers(goalId)
		local triggerType = triggers[1]
		if triggerType == TriggerType.ActivityExplore then 
			local match = this.IsCharacterMeetActivityExploreGoalConditions(characterId, goalId)
			if match then
				return true
			end
		end
	end

	return false
end

function JumpManager.MatchCharacterOfUpgradeGoal(characterId)
	local hintGoals = this.GetHintGoals()
	for idx = 1, #hintGoals do
		local goalId = hintGoals[idx]
		local triggers = ConfigUtils.GetGoalTriggers(goalId)
		local triggerType = triggers[1]
		if triggerType == TriggerType.UnlockSkill or triggerType == TriggerType.CollectItem then
			local matched = this.IsItemMeetGoalStrictConditions(characterId, goalId)
			if matched then
				return true
			end
		end
	end

	return false
end

function JumpManager.MatchEquipmentGoal(equipmentId)
	local hintGoals = this.GetHintGoals()
	for idx = 1, #hintGoals do
		local goalId = hintGoals[idx]
		local triggers = ConfigUtils.GetGoalTriggers(goalId)
		local triggerType = triggers[1]
		if triggerType == TriggerType.UpgradeEquipment or triggerType == TriggerType.CollectItem then
			local matched = this.IsItemMeetGoalStrictConditions(equipmentId, goalId)
			if matched then
				return true
			end
		elseif triggerType == TriggerType.CharacterChallenge then
			local matched = this.IsEquipmentMeetChallenge(equipmentId, goalId)
			if matched then
				return true
			end
		end
	end

	return false
end

function JumpManager.MatchSkinGoal(skinId)
	local hintGoals = this.GetHintGoals()
	for idx = 1, #hintGoals do
		local goalId = hintGoals[idx]
		local triggers = ConfigUtils.GetGoalTriggers(goalId)
		local triggerType = triggers[1]
		if triggerType == TriggerType.CollectItem or triggerType == TriggerType.CharacterChallenge then
			local matched = this.IsSkinMeetGoal(skinId, goalId)
			if matched then
				return true
			end
		end
	end

	return false
end

function JumpManager.MatchExploreCostGoal(goodsId, areaId)
	local hintGoals = this.GetHintGoals()
	for idx = 1, #hintGoals do
		local goalId = hintGoals[idx]
		local triggers = ConfigUtils.GetGoalTriggers(goalId)
		local triggerType = triggers[1]
		if triggerType == TriggerType.ExploreCost then
			local matched = this.IsItemMeetExploreCostGoalConditions(goodsId, areaId, goalId)
			if matched then
				return true
			end
		end
	end

	return false
end

function JumpManager.MatchActivityExploreCostGoal(goodsId)
	return this.MatchGoalOfTriggerType(goodsId, TriggerType.ActivityExploreCost, this.IsItemMeetGoalStrictConditions)
end

function JumpManager.MatchWorkShopGoal(workShopId)
	local hintGoals = this.GetHintGoals()
	for idx = 1, #hintGoals do
		local goalId = hintGoals[idx]
		local triggers = ConfigUtils.GetGoalTriggers(goalId)
		local triggerType = triggers[1]
		if triggerType == TriggerType.CollectItem then
			local matched = this.IsItemMeetGoalStrictConditions(workShopId, goalId)
			if matched then
				return true
			end
		elseif triggerType == TriggerType.WorkShop then
			local matched = this.IsWorkShopMeetConditions(workShopId, goalId)
			if matched then
				return true
			end
		end
	end

	return false
end

function JumpManager.MatchEnemyGoal(enemyId)
	local hintGoals = this.GetHintGoals()
	for idx = 1, #hintGoals do
		local goalId = hintGoals[idx]
		local triggers = ConfigUtils.GetGoalTriggers(goalId)
		local triggerType = triggers[1]
		if triggerType == TriggerType.Explore or triggerType == TriggerType.ActivityExplore or triggerType == TriggerType.CollectItem or triggerType == TriggerType.SubmitGoods then
			local matched = this.IsEnemyMeetGoal(enemyId, goalId)
			if matched then
				return true
			end
		end
	end

	return false
end

function JumpManager.MatchArenaGoal(battleIdx)
	local matched = this.MatchGoalOfTriggerType(battleIdx, TriggerType.Arena, this.IsBattleMeetGoalConditions)
	return matched
end

function JumpManager.MatchPlanetAreaGoal(planetAreaId)
	local hintGoals = this.GetHintGoals()
	for idx = 1, #hintGoals do
		local goalId = hintGoals[idx]
		local triggers = ConfigUtils.GetGoalTriggers(goalId)
		local triggerType = triggers[1]
		if triggerType == TriggerType.Explore or triggerType == TriggerType.Challenge or triggerType == TriggerType.CollectItem then
			local matched = this.IsPlanetAreaMeetGoalConditions(planetAreaId, goalId)
			if matched then
				return true
			end
		end
	end

	return false
end

function JumpManager.MatchPlanetAreaGoalOnlyExplore(planetAreaId)
	local hintGoals = this.GetHintGoals()
	for idx = 1, #hintGoals do
		local goalId = hintGoals[idx]
		local triggers = ConfigUtils.GetGoalTriggers(goalId)
		local triggerType = triggers[1]
		if triggerType == TriggerType.Explore or triggerType == TriggerType.CollectItem then
			local matched = this.IsPlanetAreaMeetGoalConditions(planetAreaId, goalId)
			if matched then
				return true
			end
		end
	end

	return false
end