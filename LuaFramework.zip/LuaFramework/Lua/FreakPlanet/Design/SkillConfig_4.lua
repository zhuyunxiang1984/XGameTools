
SkillConfig[SkillID.Id5001] =
{
	Id = 5001,
	Name = "生命+",
	Desc = "生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5002] =
{
	Id = 5002,
	Name = "攻击+",
	Desc = "攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5003] =
{
	Id = 5003,
	Name = "忍耐+",
	Desc = "忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5004] =
{
	Id = 5004,
	Name = "暴击+",
	Desc = "暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5005] =
{
	Id = 5005,
	Name = "恢复",
	Desc = "每回合回血 {Value}%，最多5次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id5006] =
{
	Id = 5006,
	Name = "战吼",
	Desc = "每回合攻击 +{Value}%，最多5次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id5007] =
{
	Id = 5007,
	Name = "鼓舞",
	Desc = "每回合忍耐 +{Value}，最多5次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id5008] =
{
	Id = 5008,
	Name = "指导",
	Desc = "每回合暴击 +{Value}，最多5次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id5009] =
{
	Id = 5009,
	Name = "延迟大恢复",
	Desc = "每3回合回血 {Value}%，最多5次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id5010] =
{
	Id = 5010,
	Name = "延迟大战吼",
	Desc = "每3回合攻击 +{Value}%，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id5011] =
{
	Id = 5011,
	Name = "延迟大鼓舞",
	Desc = "每3回合忍耐 +{Value}，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id5012] =
{
	Id = 5012,
	Name = "延迟大指导",
	Desc = "每3回合暴击 +{Value}，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id5013] =
{
	Id = 5013,
	Name = "超级恢复",
	Desc = "5回合后，回血 {Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 1,
		Limited = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id5014] =
{
	Id = 5014,
	Name = "超级战吼",
	Desc = "5回合后，攻击 +{Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 1,
		Limited = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id5015] =
{
	Id = 5015,
	Name = "超级鼓舞",
	Desc = "5回合后，忍耐 +{Value}",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 1,
		Limited = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id5016] =
{
	Id = 5016,
	Name = "暴击升华",
	Desc = "5回合后，暴击 +{Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 1,
		Limited = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id5017] =
{
	Id = 5017,
	Name = "危险治疗",
	Desc = "每回合有50%概率自身回血 {Value}%，最多5次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5018] =
{
	Id = 5018,
	Name = "每回合治疗",
	Desc = "每回合，回血自身攻击{Value}%的生命值",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RecoveryWithAtk",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5019] =
{
	Id = 5019,
	Name = "每2回合治疗",
	Desc = "每2回合，回血自身攻击{Value}%的生命值",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 2,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RecoveryWithAtk",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5020] =
{
	Id = 5020,
	Name = "每3回合治疗",
	Desc = "每3回合，回血自身攻击{Value}%的生命值",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RecoveryWithAtk",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5021] =
{
	Id = 5021,
	Name = "每5回合治疗",
	Desc = "每5回合，回血自身攻击{Value}%的生命值",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 5,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RecoveryWithAtk",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5022] =
{
	Id = 5022,
	Name = "每6回合治疗",
	Desc = "每6回合，回血自身攻击{Value}%的生命值",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 6,
		IntervalRound = 6,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RecoveryWithAtk",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5023] =
{
	Id = 5023,
	Name = "初级连击",
	Desc = "有{Value}%概率额外攻击1次",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExtraAttack",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id5024] =
{
	Id = 5024,
	Name = "中级连击",
	Desc = "有{Value}%概率额外攻击2次",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExtraAttack",
		EffectValue = 2,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5025] =
{
	Id = 5025,
	Name = "高级连击",
	Desc = "有{Value}%概率额外攻击3次",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExtraAttack",
		EffectValue = 3,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5026] =
{
	Id = 5026,
	Name = "敌人闪避术",
	Desc = "{Value}%概率闪避攻击",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Dodge",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5027] =
{
	Id = 5027,
	Name = "敌人必中术",
	Desc = "{Value}%概率无视敌人闪避",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DodgeIgnore",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5028] =
{
	Id = 5028,
	Name = "水元素打击",
	Desc = "对水元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5029] =
{
	Id = 5029,
	Name = "火元素打击",
	Desc = "对火元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5030] =
{
	Id = 5030,
	Name = "木元素打击",
	Desc = "对风元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210003,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5031] =
{
	Id = 5031,
	Name = "光元素打击",
	Desc = "对光元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5032] =
{
	Id = 5032,
	Name = "暗元素打击",
	Desc = "对暗元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5033] =
{
	Id = 5033,
	Name = "水元素免伤",
	Desc = "受水元素敌人伤害 {Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageFromElement",
		EffectValue = 210001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5034] =
{
	Id = 5034,
	Name = "火元素免伤",
	Desc = "受火元素敌人伤害 {Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageFromElement",
		EffectValue = 210002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5035] =
{
	Id = 5035,
	Name = "木元素免伤",
	Desc = "受风元素敌人伤害 {Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageFromElement",
		EffectValue = 210003,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5036] =
{
	Id = 5036,
	Name = "光元素免伤",
	Desc = "受光元素敌人伤害 {Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageFromElement",
		EffectValue = 210004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5037] =
{
	Id = 5037,
	Name = "暗元素免伤",
	Desc = "受暗元素敌人伤害 {Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageFromElement",
		EffectValue = 210005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5038] =
{
	Id = 5038,
	Name = "暴击伤害+",
	Desc = "暴击伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CritDamage",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5039] =
{
	Id = 5039,
	Name = "受到暴伤+",
	Desc = "受到的暴击伤害 {Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageFromCritDamage",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5040] =
{
	Id = 5040,
	Name = "每回合打击队伍前2个队员",
	Desc = "每回合对前2个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 2,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5041] =
{
	Id = 5041,
	Name = "每回合打击队伍前3个队员",
	Desc = "每回合对前3个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 3,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5042] =
{
	Id = 5042,
	Name = "每回合打击队伍前4个队员",
	Desc = "每回合对前4个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 4,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5043] =
{
	Id = 5043,
	Name = "每回合打击队伍后1个队员",
	Desc = "每回合对末位队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5044] =
{
	Id = 5044,
	Name = "每回合打击队伍后2个队员",
	Desc = "每回合对后2个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -2,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5045] =
{
	Id = 5045,
	Name = "每回合打击队伍后3个队员",
	Desc = "每回合对后3个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -3,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5046] =
{
	Id = 5046,
	Name = "每回合打击队伍后4个队员",
	Desc = "每回合对后4个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -4,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5047] =
{
	Id = 5047,
	Name = "每回合打击队伍所有队员",
	Desc = "每回合对所有队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 7,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5048] =
{
	Id = 5048,
	Name = "每2回合打击队伍前2个队员",
	Desc = "每2回合对前2个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 2,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 2,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5049] =
{
	Id = 5049,
	Name = "每2回合打击队伍前3个队员",
	Desc = "每2回合对前3个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 2,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 3,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5050] =
{
	Id = 5050,
	Name = "每2回合打击队伍前4个队员",
	Desc = "每2回合对前4个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 2,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 4,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5051] =
{
	Id = 5051,
	Name = "每2回合打击队伍后1个队员",
	Desc = "每2回合对末位队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 2,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5052] =
{
	Id = 5052,
	Name = "每2回合打击队伍后2个队员",
	Desc = "每2回合对后2个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 2,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -2,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5053] =
{
	Id = 5053,
	Name = "每2回合打击队伍后3个队员",
	Desc = "每2回合对后3个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 2,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -3,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5054] =
{
	Id = 5054,
	Name = "每2回合打击队伍后4个队员",
	Desc = "每2回合对后4个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 2,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -4,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5055] =
{
	Id = 5055,
	Name = "每2回合打击队伍所有队员",
	Desc = "每2回合对所有队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 2,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 7,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5056] =
{
	Id = 5056,
	Name = "每3回合打击队伍前2个队员",
	Desc = "每3回合对前2个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 2,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5057] =
{
	Id = 5057,
	Name = "每3回合打击队伍前3个队员",
	Desc = "每3回合对前3个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 3,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5058] =
{
	Id = 5058,
	Name = "每3回合打击队伍前4个队员",
	Desc = "每3回合对前4个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 4,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5059] =
{
	Id = 5059,
	Name = "每3回合打击队伍后1个队员",
	Desc = "每3回合对末位队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5060] =
{
	Id = 5060,
	Name = "每3回合打击队伍后2个队员",
	Desc = "每3回合对后2个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -2,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5061] =
{
	Id = 5061,
	Name = "每3回合打击队伍后3个队员",
	Desc = "每3回合对后3个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -3,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5062] =
{
	Id = 5062,
	Name = "每3回合打击队伍后4个队员",
	Desc = "每3回合对后4个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -4,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5063] =
{
	Id = 5063,
	Name = "每3回合打击队伍所有队员",
	Desc = "每3回合对所有队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 7,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5064] =
{
	Id = 5064,
	Name = "每5回合打击队伍前2个队员",
	Desc = "每5回合对前2个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 5,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 2,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5065] =
{
	Id = 5065,
	Name = "每5回合打击队伍前3个队员",
	Desc = "每5回合对前3个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 5,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 3,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5066] =
{
	Id = 5066,
	Name = "每5回合打击队伍前4个队员",
	Desc = "每5回合对前4个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 5,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 4,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5067] =
{
	Id = 5067,
	Name = "每5回合打击队伍后1个队员",
	Desc = "每5回合对末位队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 5,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5068] =
{
	Id = 5068,
	Name = "每5回合打击队伍后2个队员",
	Desc = "每5回合对后2个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 5,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -2,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5069] =
{
	Id = 5069,
	Name = "每5回合打击队伍后3个队员",
	Desc = "每5回合对后3个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 5,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -3,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5070] =
{
	Id = 5070,
	Name = "每5回合打击队伍后4个队员",
	Desc = "每5回合对后4个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 5,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -4,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5071] =
{
	Id = 5071,
	Name = "每5回合打击队伍所有队员",
	Desc = "每5回合对所有队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 5,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 7,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5072] =
{
	Id = 5072,
	Name = "每6回合打击队伍前2个队员",
	Desc = "每6回合对前2个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 6,
		IntervalRound = 6,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 2,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5073] =
{
	Id = 5073,
	Name = "每6回合打击队伍前3个队员",
	Desc = "每6回合对前3个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 6,
		IntervalRound = 6,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 3,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5074] =
{
	Id = 5074,
	Name = "每6回合打击队伍前4个队员",
	Desc = "每6回合对前4个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 6,
		IntervalRound = 6,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 4,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5075] =
{
	Id = 5075,
	Name = "每6回合打击队伍后1个队员",
	Desc = "每6回合对末位队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 6,
		IntervalRound = 6,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5076] =
{
	Id = 5076,
	Name = "每6回合打击队伍后2个队员",
	Desc = "每6回合对后2个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 6,
		IntervalRound = 6,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -2,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5077] =
{
	Id = 5077,
	Name = "每6回合打击队伍后3个队员",
	Desc = "每6回合对后3个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 6,
		IntervalRound = 6,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -3,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5078] =
{
	Id = 5078,
	Name = "每6回合打击队伍后4个队员",
	Desc = "每6回合对后4个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 6,
		IntervalRound = 6,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -4,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5079] =
{
	Id = 5079,
	Name = "每6回合打击队伍所有队员",
	Desc = "每6回合对所有队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 6,
		IntervalRound = 6,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 7,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5080] =
{
	Id = 5080,
	Name = "每回合50%打击队伍前2个队员",
	Desc = "每回合有50%概率对前2个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 2,
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5081] =
{
	Id = 5081,
	Name = "每回合50%打击队伍前3个队员",
	Desc = "每回合有50%概率对前3个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 3,
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5082] =
{
	Id = 5082,
	Name = "每回合50%打击队伍前4个队员",
	Desc = "每回合有50%概率对前4个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 4,
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5083] =
{
	Id = 5083,
	Name = "每回合50%打击队伍后1个队员",
	Desc = "每回合有50%概率对末位队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -1,
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5084] =
{
	Id = 5084,
	Name = "每回合50%打击队伍后2个队员",
	Desc = "每回合有50%概率对后2个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -2,
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5085] =
{
	Id = 5085,
	Name = "每回合50%打击队伍后3个队员",
	Desc = "每回合有50%概率对后3个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -3,
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5086] =
{
	Id = 5086,
	Name = "每回合50%打击队伍后4个队员",
	Desc = "每回合有50%概率对后4个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -4,
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5087] =
{
	Id = 5087,
	Name = "每回合50%打击队伍所有队员",
	Desc = "每回合有50%概率对所有队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 7,
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5088] =
{
	Id = 5088,
	Name = "每2回合50%打击队伍前2个队员",
	Desc = "每2回合有50%概率对前2个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 2,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 2,
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5089] =
{
	Id = 5089,
	Name = "每2回合50%打击队伍前3个队员",
	Desc = "每2回合有50%概率对前3个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 2,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 3,
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5090] =
{
	Id = 5090,
	Name = "每2回合50%打击队伍前4个队员",
	Desc = "每2回合有50%概率对前4个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 2,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 4,
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5091] =
{
	Id = 5091,
	Name = "每2回合50%打击队伍后1个队员",
	Desc = "每2回合有50%概率对末位队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 2,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -1,
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5092] =
{
	Id = 5092,
	Name = "每2回合50%打击队伍后2个队员",
	Desc = "每2回合有50%概率对后2个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 2,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -2,
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5093] =
{
	Id = 5093,
	Name = "每2回合50%打击队伍后3个队员",
	Desc = "每2回合有50%概率对后3个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 2,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -3,
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5094] =
{
	Id = 5094,
	Name = "每2回合50%打击队伍后4个队员",
	Desc = "每2回合有50%概率对后4个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 2,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -4,
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5095] =
{
	Id = 5095,
	Name = "每2回合50%打击队伍所有队员",
	Desc = "每2回合有50%概率对所有队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 2,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 7,
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5096] =
{
	Id = 5096,
	Name = "每3回合50%打击队伍前2个队员",
	Desc = "每3回合有50%概率对前2个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 2,
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5097] =
{
	Id = 5097,
	Name = "每3回合50%打击队伍前3个队员",
	Desc = "每3回合有50%概率对前3个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 3,
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5098] =
{
	Id = 5098,
	Name = "每3回合50%打击队伍前4个队员",
	Desc = "每3回合有50%概率对前4个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 4,
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5099] =
{
	Id = 5099,
	Name = "每3回合50%打击队伍后1个队员",
	Desc = "每3回合有50%概率对末位队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -1,
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5100] =
{
	Id = 5100,
	Name = "每3回合50%打击队伍后2个队员",
	Desc = "每3回合有50%概率对后2个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -2,
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5101] =
{
	Id = 5101,
	Name = "每3回合50%打击队伍后3个队员",
	Desc = "每3回合有50%概率对后3个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -3,
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5102] =
{
	Id = 5102,
	Name = "每3回合50%打击队伍后4个队员",
	Desc = "每3回合有50%概率对后4个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -4,
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5103] =
{
	Id = 5103,
	Name = "每3回合50%打击队伍所有队员",
	Desc = "每3回合有50%概率对所有队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 7,
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5104] =
{
	Id = 5104,
	Name = "每5回合50%打击队伍前2个队员",
	Desc = "每5回合有50%概率对前2个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 5,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 2,
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5105] =
{
	Id = 5105,
	Name = "每5回合50%打击队伍前3个队员",
	Desc = "每5回合有50%概率对前3个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 5,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 3,
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5106] =
{
	Id = 5106,
	Name = "每5回合50%打击队伍前4个队员",
	Desc = "每5回合有50%概率对前4个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 5,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 4,
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5107] =
{
	Id = 5107,
	Name = "每5回合50%打击队伍后1个队员",
	Desc = "每5回合有50%概率对末位队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 5,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -1,
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5108] =
{
	Id = 5108,
	Name = "每5回合50%打击队伍后2个队员",
	Desc = "每5回合有50%概率对后2个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 5,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -2,
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5109] =
{
	Id = 5109,
	Name = "每5回合50%打击队伍后3个队员",
	Desc = "每5回合有50%概率对后3个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 5,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -3,
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5110] =
{
	Id = 5110,
	Name = "每5回合50%打击队伍后4个队员",
	Desc = "每5回合有50%概率对后4个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 5,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -4,
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5111] =
{
	Id = 5111,
	Name = "每5回合50%打击队伍所有队员",
	Desc = "每5回合有50%概率对所有队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 5,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 7,
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5112] =
{
	Id = 5112,
	Name = "每6回合50%打击队伍前2个队员",
	Desc = "每6回合有50%概率对前2个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 6,
		IntervalRound = 6,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 2,
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5113] =
{
	Id = 5113,
	Name = "每6回合50%打击队伍前3个队员",
	Desc = "每6回合有50%概率对前3个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 6,
		IntervalRound = 6,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 3,
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5114] =
{
	Id = 5114,
	Name = "每6回合50%打击队伍前4个队员",
	Desc = "每6回合有50%概率对前4个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 6,
		IntervalRound = 6,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 4,
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5115] =
{
	Id = 5115,
	Name = "每6回合50%打击队伍后1个队员",
	Desc = "每6回合有50%概率对末位队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 6,
		IntervalRound = 6,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -1,
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5116] =
{
	Id = 5116,
	Name = "每6回合50%打击队伍后2个队员",
	Desc = "每6回合有50%概率对后2个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 6,
		IntervalRound = 6,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -2,
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5117] =
{
	Id = 5117,
	Name = "每6回合50%打击队伍后3个队员",
	Desc = "每6回合有50%概率对后3个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 6,
		IntervalRound = 6,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -3,
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5118] =
{
	Id = 5118,
	Name = "每6回合50%打击队伍后4个队员",
	Desc = "每6回合有50%概率对后4个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 6,
		IntervalRound = 6,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -4,
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5119] =
{
	Id = 5119,
	Name = "每6回合50%打击队伍所有队员",
	Desc = "每6回合有50%概率对所有队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 6,
		IntervalRound = 6,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 7,
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5120] =
{
	Id = 5120,
	Name = "每回合25%打击队伍前2个队员",
	Desc = "每回合有25%概率对前2个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 2,
		Chance = 25,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5121] =
{
	Id = 5121,
	Name = "每回合25%打击队伍前3个队员",
	Desc = "或对前3个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 3,
		Chance = 25,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5122] =
{
	Id = 5122,
	Name = "每回合25%打击队伍前4个队员",
	Desc = "或对前4个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 4,
		Chance = 25,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5123] =
{
	Id = 5123,
	Name = "每回合25%打击队伍后1个队员",
	Desc = "或对末位队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -1,
		Chance = 25,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5124] =
{
	Id = 5124,
	Name = "每回合25%打击队伍后2个队员",
	Desc = "或对后2个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -2,
		Chance = 25,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5125] =
{
	Id = 5125,
	Name = "每回合25%打击队伍后3个队员",
	Desc = "或对后3个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -3,
		Chance = 25,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5126] =
{
	Id = 5126,
	Name = "每回合25%打击队伍后4个队员",
	Desc = "或对后4个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -4,
		Chance = 25,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5127] =
{
	Id = 5127,
	Name = "每回合25%打击队伍所有队员",
	Desc = "或对所有队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 7,
		Chance = 25,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5128] =
{
	Id = 5128,
	Name = "每2回合，本回合暴率",
	Desc = "每2回合，本回合暴率 +{Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 2,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CritChanceOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5129] =
{
	Id = 5129,
	Name = "每2回合，本回合暴击伤害",
	Desc = "每2回合，本回合暴击伤害 +{Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 2,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CritDamageOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5130] =
{
	Id = 5130,
	Name = "每2回合，本回合受到暴击伤害",
	Desc = "每2回合，本回合受到暴击伤害{Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 2,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageFromCritDamageOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5131] =
{
	Id = 5131,
	Name = "每2回合，本回合概率额外攻击1次",
	Desc = "每2回合，本回合{Value}%概率额外攻击1次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 2,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExtraAttackOnce",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5132] =
{
	Id = 5132,
	Name = "每2回合，本回合概率额外攻击2次",
	Desc = "每2回合，本回合{Value}%概率额外攻击2次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 2,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExtraAttackOnce",
		EffectValue = 2,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5133] =
{
	Id = 5133,
	Name = "每2回合，本回合闪避率",
	Desc = "每2回合，{Value}%概率闪避攻击",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 2,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DodgeOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5134] =
{
	Id = 5134,
	Name = "每2回合，本回合概率无视目标闪避",
	Desc = "每2回合，{Value}%概率无视敌人闪避",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 2,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DodgeIgnoreOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5135] =
{
	Id = 5135,
	Name = "每3回合，本回合暴率",
	Desc = "每3回合，本回合暴率 +{Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CritChanceOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5136] =
{
	Id = 5136,
	Name = "每3回合，本回合暴击伤害",
	Desc = "每3回合，本回合暴击伤害 +{Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CritDamageOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5137] =
{
	Id = 5137,
	Name = "每3回合，本回合受到暴击伤害",
	Desc = "每3回合，本回合受到暴击伤害{Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageFromCritDamageOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5138] =
{
	Id = 5138,
	Name = "每3回合，本回合概率额外攻击1次",
	Desc = "每3回合，本回合{Value}%概率额外攻击1次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExtraAttackOnce",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5139] =
{
	Id = 5139,
	Name = "每3回合，本回合概率额外攻击2次",
	Desc = "每3回合，本回合{Value}%概率额外攻击2次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExtraAttackOnce",
		EffectValue = 2,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5140] =
{
	Id = 5140,
	Name = "每3回合，本回合闪避率",
	Desc = "每3回合，{Value}%概率闪避攻击",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DodgeOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5141] =
{
	Id = 5141,
	Name = "每3回合，本回合概率无视目标闪避",
	Desc = "每3回合，{Value}%概率无视敌人闪避",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DodgeIgnoreOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5142] =
{
	Id = 5142,
	Name = "每5回合，本回合暴率",
	Desc = "每5回合，本回合暴率 +{Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 4,
		IntervalRound = 5,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CritChanceOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5143] =
{
	Id = 5143,
	Name = "每5回合，本回合暴击伤害",
	Desc = "每5回合，本回合暴击伤害 +{Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 4,
		IntervalRound = 5,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CritDamageOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5144] =
{
	Id = 5144,
	Name = "每5回合，本回合受到暴击伤害",
	Desc = "每5回合，本回合受到暴击伤害{Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 4,
		IntervalRound = 5,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageFromCritDamageOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5145] =
{
	Id = 5145,
	Name = "每5回合，本回合概率额外攻击1次",
	Desc = "每5回合，本回合{Value}%概率额外攻击1次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 4,
		IntervalRound = 5,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExtraAttackOnce",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5146] =
{
	Id = 5146,
	Name = "每5回合，本回合概率额外攻击2次",
	Desc = "每5回合，本回合{Value}%概率额外攻击2次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 4,
		IntervalRound = 5,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExtraAttackOnce",
		EffectValue = 2,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5147] =
{
	Id = 5147,
	Name = "每5回合，本回合闪避率",
	Desc = "每5回合，{Value}%概率闪避攻击",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 4,
		IntervalRound = 5,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DodgeOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5148] =
{
	Id = 5148,
	Name = "每5回合，本回合概率无视目标闪避",
	Desc = "每5回合，{Value}%概率无视敌人闪避",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 4,
		IntervalRound = 5,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DodgeIgnoreOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5149] =
{
	Id = 5149,
	Name = "每6回合，本回合暴率",
	Desc = "每6回合，本回合暴率 +{Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 6,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CritChanceOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5150] =
{
	Id = 5150,
	Name = "每6回合，本回合暴击伤害",
	Desc = "每6回合，本回合暴击伤害 +{Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 6,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CritDamageOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5151] =
{
	Id = 5151,
	Name = "每6回合，本回合受到暴击伤害",
	Desc = "每6回合，本回合受到暴击伤害{Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 6,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageFromCritDamageOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5152] =
{
	Id = 5152,
	Name = "每6回合，本回合概率额外攻击1次",
	Desc = "每6回合，本回合{Value}%概率额外攻击1次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 6,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExtraAttackOnce",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5153] =
{
	Id = 5153,
	Name = "每6回合，本回合概率额外攻击2次",
	Desc = "每6回合，本回合{Value}%概率额外攻击2次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 6,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExtraAttackOnce",
		EffectValue = 2,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5154] =
{
	Id = 5154,
	Name = "每6回合，本回合闪避率",
	Desc = "每6回合，{Value}%概率闪避攻击",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 6,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DodgeOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5155] =
{
	Id = 5155,
	Name = "每6回合，本回合概率无视目标闪避",
	Desc = "每6回合，{Value}%概率无视敌人闪避",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 6,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DodgeIgnoreOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5156] =
{
	Id = 5156,
	Name = "5回合后将自身属性变为水元素",
	Desc = "5回合后，自身属性变为水元素",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 1,
		Limited = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ChangeElement",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5157] =
{
	Id = 5157,
	Name = "5回合后将自身属性变为火元素",
	Desc = "5回合后，自身属性变为火元素",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 1,
		Limited = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ChangeElement",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5158] =
{
	Id = 5158,
	Name = "5回合后将自身属性变为风元素",
	Desc = "5回合后，自身属性变为风元素",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 1,
		Limited = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ChangeElement",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5159] =
{
	Id = 5159,
	Name = "5回合后将自身属性变为光元素",
	Desc = "5回合后，自身属性变为光元素",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 1,
		Limited = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ChangeElement",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5160] =
{
	Id = 5160,
	Name = "5回合后将自身属性变为暗元素",
	Desc = "5回合后，自身属性变为暗元素",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 1,
		Limited = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ChangeElement",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5161] =
{
	Id = 5161,
	Name = "5回合后将自身元素变为随机元素",
	Desc = "5回合后，自身元素变为随机元素",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 1,
		Limited = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ChangeElement",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5162] =
{
	Id = 5162,
	Name = "每回合将自身元素变为随机元素",
	Desc = "每回合将自身元素变为随机元素",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ChangeElement",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5163] =
{
	Id = 5163,
	Name = "每3回合将自身元素变为随机元素",
	Desc = "每3回合将自身元素变为随机元素",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ChangeElement",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5164] =
{
	Id = 5164,
	Name = "超级恢复",
	Desc = "5回合后，回血 {Value}%",
	Dialog = "为了王子殿下！",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 1,
		Limited = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5165] =
{
	Id = 5165,
	Name = "可上场人数减少",
	Desc = "可上场队员数量 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5166] =
{
	Id = 5166,
	Name = "每3回合，有33%回血",
	Desc = "每3回合，有33%概率回血自身攻击{Value}%的生命值",
	Dialog = "味道真不错！",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RecoveryWithAtk",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5167] =
{
	Id = 5167,
	Name = "每3回合治疗",
	Desc = "每3回合，回血自身攻击{Value}%的生命值",
	Dialog = "呼，我又重新感到了活力。",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RecoveryWithAtk",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5168] =
{
	Id = 5168,
	Name = "无视敌人忍耐攻击%",
	Desc = "攻击时无视敌人{Value}%忍耐",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DefendIgnoreOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5169] =
{
	Id = 5169,
	Name = "无视敌人忍耐攻击",
	Desc = "攻击时无视敌人{Value}忍耐",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DefendIgnoreOnce",
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5170] =
{
	Id = 5170,
	Name = "根据受击次数攻击+%",
	Desc = "回合中，每次受击，攻击 +{Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "AttributeWithHurt",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5171] =
{
	Id = 5171,
	Name = "根据受击次数忍耐+",
	Desc = "回合中，每次受击，忍耐 +{Value}",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "AttributeWithHurt",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5172] =
{
	Id = 5172,
	Name = "根据受击次数暴击+",
	Desc = "回合中，每次受击，暴击 +{Value}",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "AttributeWithHurt",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5173] =
{
	Id = 5173,
	Name = "降低等级减少效果%",
	Desc = "降低{Value}%等级减少效果",
	EffectModule = EffectModule.Battle,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyLevelIgnore",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5174] =
{
	Id = 5174,
	Name = "降低等级减少效果",
	Desc = "降低{Value}等级减少效果",
	EffectModule = EffectModule.Battle,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyLevelIgnore",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5175] =
{
	Id = 5175,
	Name = "2~3回合打击队伍前2个队员",
	Desc = "2~3回合对前2个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 1,
		Limited = 2,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 2,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5176] =
{
	Id = 5176,
	Name = "4~5回合打击队伍前3个队员",
	Desc = "4~5回合对前3个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 4,
		IntervalRound = 1,
		Limited = 2,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 3,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5177] =
{
	Id = 5177,
	Name = "6回合后打击队伍所有队员",
	Desc = "6回合后对前4个队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 6,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 4,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5178] =
{
	Id = 5178,
	Name = "战吼",
	Desc = "每2回合攻击 +{Value}%，最多5次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 2,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id5179] =
{
	Id = 5179,
	Name = "奇数回合50%打击队伍后1个队员",
	Desc = "奇数回合有50%概率对末位队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 2,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -1,
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5180] =
{
	Id = 5180,
	Name = "4回合后单次受到暴伤-%",
	Desc = "第4回合起，受到暴击伤害{Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageFromCritDamageOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id5181] =
{
	Id = 5181,
	Name = "每回合恢复",
	Desc = "每回合，回血{Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5182] =
{
	Id = 5182,
	Name = "每2回合恢复",
	Desc = "每2回合，回血{Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 2,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5183] =
{
	Id = 5183,
	Name = "每3回合恢复",
	Desc = "每3回合，回血{Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5184] =
{
	Id = 5184,
	Name = "每5回合恢复",
	Desc = "每5回合，回血{Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 5,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5185] =
{
	Id = 5185,
	Name = "每6回合恢复",
	Desc = "每6回合，回血{Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 6,
		IntervalRound = 6,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5186] =
{
	Id = 5186,
	Name = "根据受击次数回血%",
	Desc = "回合中，每次受击，回血{Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RecoveryWithHurt",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5187] =
{
	Id = 5187,
	Name = "每回合，削弱敌人恢复效果%",
	Desc = "每回合，降低敌人{Value}%回血效果",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ReduceRecoveryOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5188] =
{
	Id = 5188,
	Name = "每回合，削弱敌人攻击增强效果%",
	Desc = "每回合，降低敌人{Value}%攻击增强效果",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ReduceAbilityOnce",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5189] =
{
	Id = 5189,
	Name = "每回合，削弱敌人忍耐增强效果%",
	Desc = "每回合，降低敌人{Value}%忍耐增强效果",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ReduceAbilityOnce",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5190] =
{
	Id = 5190,
	Name = "每回合，削弱敌人暴击增强效果%",
	Desc = "每回合，降低敌人{Value}%暴击增强效果",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ReduceAbilityOnce",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5191] =
{
	Id = 5191,
	Name = "每2回合，削弱敌人恢复效果%",
	Desc = "每2回合，降低敌人{Value}%回血效果",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 2,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ReduceRecoveryOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5192] =
{
	Id = 5192,
	Name = "每2回合，削弱敌人攻击增强效果%",
	Desc = "每2回合，降低敌人{Value}%攻击增强效果",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 2,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ReduceAbilityOnce",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5193] =
{
	Id = 5193,
	Name = "每2回合，削弱敌人忍耐增强效果%",
	Desc = "每2回合，降低敌人{Value}%忍耐增强效果",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 2,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ReduceAbilityOnce",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5194] =
{
	Id = 5194,
	Name = "每2回合，削弱敌人暴击增强效果%",
	Desc = "每2回合，降低敌人{Value}%暴击增强效果",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 2,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ReduceAbilityOnce",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5195] =
{
	Id = 5195,
	Name = "每3回合，削弱敌人恢复效果%",
	Desc = "每3回合，降低敌人{Value}%回血效果",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ReduceRecoveryOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5196] =
{
	Id = 5196,
	Name = "每3回合，削弱敌人攻击增强效果%",
	Desc = "每3回合，降低敌人{Value}%攻击增强效果",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ReduceAbilityOnce",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5197] =
{
	Id = 5197,
	Name = "每3回合，削弱敌人忍耐增强效果%",
	Desc = "每3回合，降低敌人{Value}%忍耐增强效果",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ReduceAbilityOnce",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5198] =
{
	Id = 5198,
	Name = "每3回合，削弱敌人暴击增强效果%",
	Desc = "每3回合，降低敌人{Value}%暴击增强效果",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ReduceAbilityOnce",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5199] =
{
	Id = 5199,
	Name = "每4回合，削弱敌人恢复效果%",
	Desc = "每4回合，降低敌人{Value}%回血效果",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 4,
		IntervalRound = 4,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ReduceRecoveryOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5200] =
{
	Id = 5200,
	Name = "每4回合，削弱敌人攻击增强效果%",
	Desc = "每4回合，降低敌人{Value}%攻击增强效果",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 4,
		IntervalRound = 4,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ReduceAbilityOnce",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5201] =
{
	Id = 5201,
	Name = "每4回合，削弱敌人忍耐增强效果%",
	Desc = "每4回合，降低敌人{Value}%忍耐增强效果",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 4,
		IntervalRound = 4,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ReduceAbilityOnce",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5202] =
{
	Id = 5202,
	Name = "每4回合，削弱敌人暴击增强效果%",
	Desc = "每4回合，降低敌人{Value}%暴击增强效果",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 4,
		IntervalRound = 4,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ReduceAbilityOnce",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5203] =
{
	Id = 5203,
	Name = "每5回合，削弱敌人恢复效果%",
	Desc = "每5回合，降低敌人{Value}%回血效果",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 5,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ReduceRecoveryOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5204] =
{
	Id = 5204,
	Name = "每5回合，削弱敌人攻击增强效果%",
	Desc = "每5回合，降低敌人{Value}%攻击增强效果",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 5,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ReduceAbilityOnce",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5205] =
{
	Id = 5205,
	Name = "每5回合，削弱敌人忍耐增强效果%",
	Desc = "每5回合，降低敌人{Value}%忍耐增强效果",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 5,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ReduceAbilityOnce",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5206] =
{
	Id = 5206,
	Name = "每5回合，削弱敌人暴击增强效果%",
	Desc = "每5回合，降低敌人{Value}%暴击增强效果",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 5,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ReduceAbilityOnce",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5207] =
{
	Id = 5207,
	Name = "奇数回合，削弱敌人恢复效果%",
	Desc = "奇数回合，降低敌人{Value}%回血效果",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 2,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ReduceRecoveryOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5208] =
{
	Id = 5208,
	Name = "奇数回合，削弱敌人攻击增强效果%",
	Desc = "奇数回合，降低敌人{Value}%攻击增强效果",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 2,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ReduceAbilityOnce",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5209] =
{
	Id = 5209,
	Name = "奇数回合，削弱敌人忍耐增强效果%",
	Desc = "奇数回合，降低敌人{Value}%忍耐增强效果",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 2,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ReduceAbilityOnce",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5210] =
{
	Id = 5210,
	Name = "奇数回合，削弱敌人暴击增强效果%",
	Desc = "奇数回合，降低敌人{Value}%暴击增强效果",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 2,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ReduceAbilityOnce",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5211] =
{
	Id = 5211,
	Name = "第1回合，打击所有队员%",
	Desc = "第1回合，对全部队员造成{Value}%伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 7,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5212] =
{
	Id = 5212,
	Name = "第2回合，打击所有队员%",
	Desc = "第2回合，对全部队员造成 {Value}%伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 1,
		Limited = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 7,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5213] =
{
	Id = 5213,
	Name = "3回合后，每回合打击所有队员%",
	Desc = "回合3开始，每回合对全部队员造成 {Value}%伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 7,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5214] =
{
	Id = 5214,
	Name = "根据攻击力回血",
	Desc = "每回合，恢复攻击{Value}%生命",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RecoveryWithAtk",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5215] =
{
	Id = 5215,
	Name = "根据受击次数忍耐",
	Desc = "回合中，每次受击，忍耐 {Value}",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "AttributeWithHurt",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5216] =
{
	Id = 5216,
	Name = "攻击附加损失生命%",
	Desc = "回合2开始，每回合造成失去生命{Value}%的额外伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "HpAttackOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5217] =
{
	Id = 5217,
	Name = "水元素增伤",
	Desc = "受水元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageFromElement",
		EffectValue = 210001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5218] =
{
	Id = 5218,
	Name = "火元素增伤",
	Desc = "受火元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageFromElement",
		EffectValue = 210002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5219] =
{
	Id = 5219,
	Name = "木元素增伤",
	Desc = "受风元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageFromElement",
		EffectValue = 210003,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5220] =
{
	Id = 5220,
	Name = "光元素增伤",
	Desc = "受光元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageFromElement",
		EffectValue = 210004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5221] =
{
	Id = 5221,
	Name = "暗元素增伤",
	Desc = "受暗元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageFromElement",
		EffectValue = 210005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5222] =
{
	Id = 5222,
	Name = "奇数回合攻击后三名队员",
	Desc = "奇数回合，攻击后三名队员",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 2,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = -3,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5223] =
{
	Id = 5223,
	Name = "偶数回合攻击前三名队员",
	Desc = "偶数回合，攻击前三名队员",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 2,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 3,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5224] =
{
	Id = 5224,
	Name = "3回合后将自身属性变为暗元素",
	Desc = "3回合后，自身属性变为暗元素",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 1,
		Limited = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ChangeElement",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5225] =
{
	Id = 5225,
	Name = "奇数回合攻击第二、第三名队员",
	Desc = "奇数回合有50%概率对末位队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 2,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 2,
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id5226] =
{
	Id = 5226,
	Name = "每4回合打击队伍所有队员",
	Desc = "每4回合对所有队员造成{Value}%攻击伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 4,
		IntervalRound = 4,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RangeAttack",
		EffectValue = 7,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
