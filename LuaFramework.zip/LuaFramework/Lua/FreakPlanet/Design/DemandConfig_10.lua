
DemandConfig[DemandID.Id1001] =
{
	Id = 1001,
	Name = "音乐会准备",
	Desc = "音乐会即将开始，需要准备一些架子鼓。",
	Value = 321854,
	Active = false,
	Weight = 51090,
	PreGoal = 
	{
		301966,
		301730,
	},
	GoodsId = 10101854,
	Priority = 1855310,
	Num = 14,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 393101,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 13,
				},
				{
					Value = 1,
					Num = 56141,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 4,
				},
				{
					Value = 1,
					Num = 47501,
				},
			},
		},
	},
	DemandID = 411001,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id1002] =
{
	Id = 1002,
	Name = "舞台感",
	Desc = "啊，我也好渴望大家的欢呼，哪怕尖叫也行。",
	Value = 321813,
	Active = true,
	Weight = 84500,
	PreGoal = 
	{
		301725,
	},
	GoodsId = 10201813,
	Priority = 1814301,
	Num = 36,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 100739,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 856,
				},
				{
					Value = 1,
					Num = 15139,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 856,
				},
				{
					Value = 1,
					Num = 15139,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 171,
				},
				{
					Value = 1,
					Num = 15239,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 171,
				},
				{
					Value = 1,
					Num = 15239,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 34,
				},
				{
					Value = 1,
					Num = 15739,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 34,
				},
				{
					Value = 1,
					Num = 15739,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 6,
				},
				{
					Value = 1,
					Num = 25739,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 6,
				},
				{
					Value = 1,
					Num = 25739,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 604,
				},
				{
					Value = 320051,
					Num = 403,
				},
			},
		},
	},
	DemandID = 411002,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id1003] =
{
	Id = 1003,
	Name = "水军大队",
	Desc = "旗下艺人人气太低了，请帮忙营造气氛！",
	Value = 321813,
	Active = false,
	Weight = 85150,
	PreGoal = 
	{
		301725,
		301730,
	},
	GoodsId = 10201813,
	Priority = 1814302,
	Num = 44,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 123126,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 209,
				},
				{
					Value = 1,
					Num = 18626,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 209,
				},
				{
					Value = 1,
					Num = 18626,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 41,
				},
				{
					Value = 1,
					Num = 20626,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 41,
				},
				{
					Value = 1,
					Num = 20626,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 8,
				},
				{
					Value = 1,
					Num = 23126,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 8,
				},
				{
					Value = 1,
					Num = 23126,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 738,
				},
				{
					Value = 320051,
					Num = 493,
				},
			},
		},
	},
	DemandID = 411003,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id1004] =
{
	Id = 1004,
	Name = "舞台感",
	Desc = "啊，我也好渴望大家的欢呼，哪怕尖叫也行。",
	Value = 321813,
	Active = false,
	Weight = 85150,
	PreGoal = 
	{
		301725,
		301730,
	},
	GoodsId = 10201813,
	Priority = 1814303,
	Num = 50,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 139916,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 237,
				},
				{
					Value = 1,
					Num = 21416,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 237,
				},
				{
					Value = 1,
					Num = 21416,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 47,
				},
				{
					Value = 1,
					Num = 22416,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 47,
				},
				{
					Value = 1,
					Num = 22416,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 9,
				},
				{
					Value = 1,
					Num = 27416,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 9,
				},
				{
					Value = 1,
					Num = 27416,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 839,
				},
				{
					Value = 320051,
					Num = 560,
				},
			},
		},
	},
	DemandID = 411004,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id1005] =
{
	Id = 1005,
	Name = "水军大队",
	Desc = "旗下艺人人气太低了，请帮忙营造气氛！",
	Value = 321813,
	Active = false,
	Weight = 85150,
	PreGoal = 
	{
		301725,
		301730,
	},
	GoodsId = 10201813,
	Priority = 1814304,
	Num = 57,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 159504,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 271,
				},
				{
					Value = 1,
					Num = 24004,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 271,
				},
				{
					Value = 1,
					Num = 24004,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 54,
				},
				{
					Value = 1,
					Num = 24504,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 54,
				},
				{
					Value = 1,
					Num = 24504,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 10,
				},
				{
					Value = 1,
					Num = 34504,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 10,
				},
				{
					Value = 1,
					Num = 34504,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 957,
				},
				{
					Value = 320051,
					Num = 638,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 191,
				},
				{
					Value = 320052,
					Num = 128,
				},
			},
		},
	},
	DemandID = 411005,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id1006] =
{
	Id = 1006,
	Name = "舞台感",
	Desc = "啊，我也好渴望大家的欢呼，哪怕尖叫也行。",
	Value = 321813,
	Active = false,
	Weight = 85150,
	PreGoal = 
	{
		301725,
		301730,
	},
	GoodsId = 10201813,
	Priority = 1814305,
	Num = 64,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 179092,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 304,
				},
				{
					Value = 1,
					Num = 27092,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 304,
				},
				{
					Value = 1,
					Num = 27092,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 60,
				},
				{
					Value = 1,
					Num = 29092,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 60,
				},
				{
					Value = 1,
					Num = 29092,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 12,
				},
				{
					Value = 1,
					Num = 29092,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 12,
				},
				{
					Value = 1,
					Num = 29092,
				},
			},
		},
	},
	DemandID = 411006,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id1007] =
{
	Id = 1007,
	Name = "水军大队",
	Desc = "旗下艺人人气太低了，请帮忙营造气氛！",
	Value = 321813,
	Active = false,
	Weight = 85150,
	PreGoal = 
	{
		301725,
		301730,
	},
	GoodsId = 10201813,
	Priority = 1814306,
	Num = 70,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 195882,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 333,
				},
				{
					Value = 1,
					Num = 29382,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 333,
				},
				{
					Value = 1,
					Num = 29382,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 66,
				},
				{
					Value = 1,
					Num = 30882,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 66,
				},
				{
					Value = 1,
					Num = 30882,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 13,
				},
				{
					Value = 1,
					Num = 33382,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 13,
				},
				{
					Value = 1,
					Num = 33382,
				},
			},
		},
	},
	DemandID = 411007,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id1008] =
{
	Id = 1008,
	Name = "舞台感",
	Desc = "啊，我也好渴望大家的欢呼，哪怕尖叫也行。",
	Value = 321813,
	Active = false,
	Weight = 85150,
	PreGoal = 
	{
		301725,
		301730,
	},
	GoodsId = 10201813,
	Priority = 1814307,
	Num = 78,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 218268,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 371,
				},
				{
					Value = 1,
					Num = 32768,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 371,
				},
				{
					Value = 1,
					Num = 32768,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 74,
				},
				{
					Value = 1,
					Num = 33268,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 74,
				},
				{
					Value = 1,
					Num = 33268,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 14,
				},
				{
					Value = 1,
					Num = 43268,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 14,
				},
				{
					Value = 1,
					Num = 43268,
				},
			},
		},
	},
	DemandID = 411008,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id1009] =
{
	Id = 1009,
	Name = "水军大队",
	Desc = "旗下艺人人气太低了，请帮忙营造气氛！",
	Value = 321813,
	Active = false,
	Weight = 85150,
	PreGoal = 
	{
		301725,
		301730,
	},
	GoodsId = 10201813,
	Priority = 1814308,
	Num = 85,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 237857,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 404,
				},
				{
					Value = 1,
					Num = 35857,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 404,
				},
				{
					Value = 1,
					Num = 35857,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 80,
				},
				{
					Value = 1,
					Num = 37857,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 80,
				},
				{
					Value = 1,
					Num = 37857,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 16,
				},
				{
					Value = 1,
					Num = 37857,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 16,
				},
				{
					Value = 1,
					Num = 37857,
				},
			},
		},
	},
	DemandID = 411009,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id1010] =
{
	Id = 1010,
	Name = "舞台感",
	Desc = "啊，我也好渴望大家的欢呼，哪怕尖叫也行。",
	Value = 321813,
	Active = false,
	Weight = 85150,
	PreGoal = 
	{
		301725,
		301730,
	},
	GoodsId = 10201813,
	Priority = 1814309,
	Num = 92,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 257445,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 437,
				},
				{
					Value = 1,
					Num = 38945,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 437,
				},
				{
					Value = 1,
					Num = 38945,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 87,
				},
				{
					Value = 1,
					Num = 39945,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 87,
				},
				{
					Value = 1,
					Num = 39945,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 17,
				},
				{
					Value = 1,
					Num = 44945,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 17,
				},
				{
					Value = 1,
					Num = 44945,
				},
			},
		},
	},
	DemandID = 411010,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id1011] =
{
	Id = 1011,
	Name = "水军大队",
	Desc = "旗下艺人人气太低了，请帮忙营造气氛！",
	Value = 321813,
	Active = false,
	Weight = 85150,
	PreGoal = 
	{
		301725,
		301730,
	},
	GoodsId = 10201813,
	Priority = 1814310,
	Num = 36,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 100739,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 856,
				},
				{
					Value = 1,
					Num = 15139,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 856,
				},
				{
					Value = 1,
					Num = 15139,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 171,
				},
				{
					Value = 1,
					Num = 15239,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 171,
				},
				{
					Value = 1,
					Num = 15239,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 34,
				},
				{
					Value = 1,
					Num = 15739,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 34,
				},
				{
					Value = 1,
					Num = 15739,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 6,
				},
				{
					Value = 1,
					Num = 25739,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 6,
				},
				{
					Value = 1,
					Num = 25739,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 604,
				},
				{
					Value = 320051,
					Num = 403,
				},
			},
		},
	},
	DemandID = 411011,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id1012] =
{
	Id = 1012,
	Name = "公主浴",
	Desc = "最近赚了点钱，也想试下传说的泡泡浴呢！",
	Value = 321814,
	Active = true,
	Weight = 85805,
	PreGoal = 
	{
		301949,
		301730,
	},
	GoodsId = 10301814,
	Priority = 1815311,
	Num = 35,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 102557,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 871,
				},
				{
					Value = 1,
					Num = 15457,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 871,
				},
				{
					Value = 1,
					Num = 15457,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 174,
				},
				{
					Value = 1,
					Num = 15557,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 174,
				},
				{
					Value = 1,
					Num = 15557,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 34,
				},
				{
					Value = 1,
					Num = 17557,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 34,
				},
				{
					Value = 1,
					Num = 17557,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 6,
				},
				{
					Value = 1,
					Num = 27557,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 6,
				},
				{
					Value = 1,
					Num = 27557,
				},
			},
		},
	},
	DemandID = 411012,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id1013] =
{
	Id = 1013,
	Name = "梦幻舞台",
	Desc = "说到梦幻的舞台氛围，干冰和气泡一定不能少！",
	Value = 321814,
	Active = false,
	Weight = 85805,
	PreGoal = 
	{
		301949,
		301730,
	},
	GoodsId = 10301814,
	Priority = 1815312,
	Num = 40,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 117208,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 996,
				},
				{
					Value = 1,
					Num = 17608,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 996,
				},
				{
					Value = 1,
					Num = 17608,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 199,
				},
				{
					Value = 1,
					Num = 17708,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 199,
				},
				{
					Value = 1,
					Num = 17708,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 39,
				},
				{
					Value = 1,
					Num = 19708,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 39,
				},
				{
					Value = 1,
					Num = 19708,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 7,
				},
				{
					Value = 1,
					Num = 29708,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 7,
				},
				{
					Value = 1,
					Num = 29708,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 703,
				},
				{
					Value = 320051,
					Num = 469,
				},
			},
		},
	},
	DemandID = 411013,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id1014] =
{
	Id = 1014,
	Name = "公主浴",
	Desc = "最近赚了点钱，也想试下传说的泡泡浴呢！",
	Value = 321814,
	Active = false,
	Weight = 85805,
	PreGoal = 
	{
		301949,
		301730,
	},
	GoodsId = 10301814,
	Priority = 1815313,
	Num = 46,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 134789,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 229,
				},
				{
					Value = 1,
					Num = 20289,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 229,
				},
				{
					Value = 1,
					Num = 20289,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 45,
				},
				{
					Value = 1,
					Num = 22289,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 45,
				},
				{
					Value = 1,
					Num = 22289,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 9,
				},
				{
					Value = 1,
					Num = 22289,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 9,
				},
				{
					Value = 1,
					Num = 22289,
				},
			},
		},
	},
	DemandID = 411014,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id1015] =
{
	Id = 1015,
	Name = "梦幻舞台",
	Desc = "说到梦幻的舞台氛围，干冰和气泡一定不能少！",
	Value = 321814,
	Active = false,
	Weight = 85805,
	PreGoal = 
	{
		301949,
		301730,
	},
	GoodsId = 10301814,
	Priority = 1815314,
	Num = 52,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 152370,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 259,
				},
				{
					Value = 1,
					Num = 22870,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 259,
				},
				{
					Value = 1,
					Num = 22870,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 51,
				},
				{
					Value = 1,
					Num = 24870,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 51,
				},
				{
					Value = 1,
					Num = 24870,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 10,
				},
				{
					Value = 1,
					Num = 27370,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 10,
				},
				{
					Value = 1,
					Num = 27370,
				},
			},
		},
	},
	DemandID = 411015,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id1016] =
{
	Id = 1016,
	Name = "公主浴",
	Desc = "最近赚了点钱，也想试下传说的泡泡浴呢！",
	Value = 321814,
	Active = false,
	Weight = 85805,
	PreGoal = 
	{
		301949,
		301730,
	},
	GoodsId = 10301814,
	Priority = 1815315,
	Num = 57,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 167021,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 283,
				},
				{
					Value = 1,
					Num = 25521,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 283,
				},
				{
					Value = 1,
					Num = 25521,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 56,
				},
				{
					Value = 1,
					Num = 27021,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 56,
				},
				{
					Value = 1,
					Num = 27021,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 11,
				},
				{
					Value = 1,
					Num = 29521,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 11,
				},
				{
					Value = 1,
					Num = 29521,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 200,
				},
				{
					Value = 320052,
					Num = 134,
				},
			},
		},
	},
	DemandID = 411016,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id1017] =
{
	Id = 1017,
	Name = "梦幻舞台",
	Desc = "说到梦幻的舞台氛围，干冰和气泡一定不能少！",
	Value = 321814,
	Active = false,
	Weight = 85805,
	PreGoal = 
	{
		301949,
		301730,
	},
	GoodsId = 10301814,
	Priority = 1815316,
	Num = 63,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 184602,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 313,
				},
				{
					Value = 1,
					Num = 28102,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 313,
				},
				{
					Value = 1,
					Num = 28102,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 62,
				},
				{
					Value = 1,
					Num = 29602,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 62,
				},
				{
					Value = 1,
					Num = 29602,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 12,
				},
				{
					Value = 1,
					Num = 34602,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 12,
				},
				{
					Value = 1,
					Num = 34602,
				},
			},
		},
	},
	DemandID = 411017,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id1018] =
{
	Id = 1018,
	Name = "公主浴",
	Desc = "最近赚了点钱，也想试下传说的泡泡浴呢！",
	Value = 321814,
	Active = false,
	Weight = 85805,
	PreGoal = 
	{
		301949,
		301730,
	},
	GoodsId = 10301814,
	Priority = 1815317,
	Num = 69,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 202183,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 343,
				},
				{
					Value = 1,
					Num = 30683,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 343,
				},
				{
					Value = 1,
					Num = 30683,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 68,
				},
				{
					Value = 1,
					Num = 32183,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 68,
				},
				{
					Value = 1,
					Num = 32183,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 13,
				},
				{
					Value = 1,
					Num = 39683,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 13,
				},
				{
					Value = 1,
					Num = 39683,
				},
			},
		},
	},
	DemandID = 411018,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id1019] =
{
	Id = 1019,
	Name = "梦幻舞台",
	Desc = "说到梦幻的舞台氛围，干冰和气泡一定不能少！",
	Value = 321814,
	Active = false,
	Weight = 85805,
	PreGoal = 
	{
		301949,
		301730,
	},
	GoodsId = 10301814,
	Priority = 1815318,
	Num = 74,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 216834,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 368,
				},
				{
					Value = 1,
					Num = 32834,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 368,
				},
				{
					Value = 1,
					Num = 32834,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 73,
				},
				{
					Value = 1,
					Num = 34334,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 73,
				},
				{
					Value = 1,
					Num = 34334,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 14,
				},
				{
					Value = 1,
					Num = 41834,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 14,
				},
				{
					Value = 1,
					Num = 41834,
				},
			},
		},
	},
	DemandID = 411019,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id1020] =
{
	Id = 1020,
	Name = "公主浴",
	Desc = "最近赚了点钱，也想试下传说的泡泡浴呢！",
	Value = 321814,
	Active = false,
	Weight = 85805,
	PreGoal = 
	{
		301949,
		301730,
	},
	GoodsId = 10301814,
	Priority = 1815319,
	Num = 74,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 216834,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 368,
				},
				{
					Value = 1,
					Num = 32834,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 368,
				},
				{
					Value = 1,
					Num = 32834,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 73,
				},
				{
					Value = 1,
					Num = 34334,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 73,
				},
				{
					Value = 1,
					Num = 34334,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 14,
				},
				{
					Value = 1,
					Num = 41834,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 14,
				},
				{
					Value = 1,
					Num = 41834,
				},
			},
		},
	},
	DemandID = 411020,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id1021] =
{
	Id = 1021,
	Name = "梦幻舞台",
	Desc = "说到梦幻的舞台氛围，干冰和气泡一定不能少！",
	Value = 321814,
	Active = false,
	Weight = 85805,
	PreGoal = 
	{
		301949,
		301730,
	},
	GoodsId = 10301814,
	Priority = 1815320,
	Num = 74,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 216834,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 368,
				},
				{
					Value = 1,
					Num = 32834,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 368,
				},
				{
					Value = 1,
					Num = 32834,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 73,
				},
				{
					Value = 1,
					Num = 34334,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 73,
				},
				{
					Value = 1,
					Num = 34334,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 14,
				},
				{
					Value = 1,
					Num = 41834,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 14,
				},
				{
					Value = 1,
					Num = 41834,
				},
			},
		},
	},
	DemandID = 411021,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id2006] =
{
	Id = 2006,
	Name = "口粮回购",
	Desc = "猫之星向所有冒险者征集小血瓶，价格方面是绝不会亏待各位的~",
	Value = 320401,
	Active = false,
	Weight = 0,
	GoodsId = 130401,
	Num = 1,
	DemandID = 412006,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2007] =
{
	Id = 2007,
	Name = "口粮回购",
	Desc = "猫之星向所有冒险者征集小血瓶，价格方面是绝不会亏待各位的~",
	Value = 320401,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		300018,
	},
	CloseGoal = 
	{
		308001,
	},
	GoodsId = 160401,
	Num = 9,
	DemandID = 412007,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2008] =
{
	Id = 2008,
	Name = "口粮回购",
	Desc = "猫之星向所有冒险者征集小血瓶，价格方面是绝不会亏待各位的~",
	Value = 320401,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308003,
	},
	CloseGoal = 
	{
		308004,
	},
	GoodsId = 190401,
	Num = 85,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 931,
				},
			},
		},
	},
	DemandID = 412008,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2012] =
{
	Id = 2012,
	Name = "新兵的礼物",
	Desc = "给新兵的礼物选什么好呢？",
	Value = 320402,
	Active = true,
	Weight = 12,
	PreGoal = 
	{
		300005,
	},
	CloseGoal = 
	{
		300043,
	},
	GoodsId = 130402,
	Num = 3,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 592,
				},
			},
		},
	},
	DemandID = 412012,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2013] =
{
	Id = 2013,
	Name = "新兵的礼物",
	Desc = "给新兵的礼物选什么好呢？",
	Value = 320402,
	Active = true,
	Weight = 279,
	PreGoal = 
	{
		308001,
	},
	CloseGoal = 
	{
		308002,
	},
	GoodsId = 160402,
	Num = 37,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 7303,
				},
			},
		},
	},
	DemandID = 412013,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2014] =
{
	Id = 2014,
	Name = "新兵的礼物",
	Desc = "给新兵的礼物选什么好呢？",
	Value = 320402,
	Active = true,
	Weight = 855,
	PreGoal = 
	{
		308004,
	},
	CloseGoal = 
	{
		308005,
	},
	GoodsId = 190402,
	Num = 123,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 24280,
				},
			},
		},
	},
	DemandID = 412014,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2022] =
{
	Id = 2022,
	Name = "订购大血瓶",
	Desc = "希望有更多大血瓶",
	Value = 320403,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308001,
		300051,
	},
	CloseGoal = 
	{
		300080,
	},
	GoodsId = 130403,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 1184,
				},
			},
		},
	},
	DemandID = 412022,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2023] =
{
	Id = 2023,
	Name = "订购大血瓶",
	Desc = "希望有更多大血瓶",
	Value = 320403,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308001,
		300087,
	},
	CloseGoal = 
	{
		300421,
	},
	GoodsId = 160403,
	Num = 3,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 3553,
				},
			},
		},
	},
	DemandID = 412023,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2024] =
{
	Id = 2024,
	Name = "订购大血瓶",
	Desc = "希望有更多大血瓶",
	Value = 320403,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308001,
		300439,
	},
	CloseGoal = 
	{
		300482,
	},
	GoodsId = 190403,
	Num = 4,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 4737,
				},
			},
		},
	},
	DemandID = 412024,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2032] =
{
	Id = 2032,
	Name = "订购特大血瓶",
	Desc = "希望有更多特大血瓶",
	Value = 320404,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308003,
		300087,
	},
	CloseGoal = 
	{
		300417,
	},
	GoodsId = 130404,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 4737,
				},
			},
		},
	},
	DemandID = 412032,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2033] =
{
	Id = 2033,
	Name = "订购特大血瓶",
	Desc = "希望有更多特大血瓶",
	Value = 320404,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308003,
		300424,
	},
	CloseGoal = 
	{
		300458,
	},
	GoodsId = 160404,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 4737,
				},
			},
		},
	},
	DemandID = 412033,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2034] =
{
	Id = 2034,
	Name = "订购特大血瓶",
	Desc = "希望有更多特大血瓶",
	Value = 320404,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308003,
		300478,
	},
	CloseGoal = 
	{
		300827,
	},
	GoodsId = 190404,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 4737,
				},
			},
		},
	},
	DemandID = 412034,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2042] =
{
	Id = 2042,
	Name = "订购鸡腿",
	Desc = "希望有更多鸡腿",
	Value = 320406,
	Active = false,
	Weight = 0,
	GoodsId = 130406,
	Num = 3,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 1480,
				},
			},
		},
	},
	DemandID = 412042,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2043] =
{
	Id = 2043,
	Name = "订购鸡腿",
	Desc = "希望有更多鸡腿",
	Value = 320406,
	Active = true,
	Weight = 392,
	PreGoal = 
	{
		308053,
	},
	CloseGoal = 
	{
		308054,
	},
	GoodsId = 160406,
	Num = 15,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 7402,
				},
			},
		},
	},
	DemandID = 412043,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2044] =
{
	Id = 2044,
	Name = "订购鸡腿",
	Desc = "希望有更多鸡腿",
	Value = 320406,
	Active = true,
	Weight = 1764,
	PreGoal = 
	{
		308056,
	},
	CloseGoal = 
	{
		308057,
	},
	GoodsId = 190406,
	Num = 45,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 22207,
				},
			},
		},
	},
	DemandID = 412044,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2052] =
{
	Id = 2052,
	Name = "订购纷享桶",
	Desc = "希望有更多纷享桶",
	Value = 320407,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308053,
		300069,
	},
	CloseGoal = 
	{
		300102,
	},
	GoodsId = 130407,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 1974,
				},
			},
		},
	},
	DemandID = 412052,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2053] =
{
	Id = 2053,
	Name = "订购纷享桶",
	Desc = "希望有更多纷享桶",
	Value = 320407,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308053,
		300406,
	},
	CloseGoal = 
	{
		300439,
	},
	GoodsId = 160407,
	Num = 3,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5922,
				},
			},
		},
	},
	DemandID = 412053,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2054] =
{
	Id = 2054,
	Name = "订购纷享桶",
	Desc = "希望有更多纷享桶",
	Value = 320407,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308053,
		300458,
	},
	CloseGoal = 
	{
		300804,
	},
	GoodsId = 190407,
	Num = 3,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5922,
				},
			},
		},
	},
	DemandID = 412054,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2062] =
{
	Id = 2062,
	Name = "订购全家桶",
	Desc = "希望有更多全家桶",
	Value = 320408,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308055,
		300439,
	},
	CloseGoal = 
	{
		300470,
	},
	GoodsId = 130408,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 9870,
				},
			},
		},
	},
	DemandID = 412062,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2063] =
{
	Id = 2063,
	Name = "订购全家桶",
	Desc = "希望有更多全家桶",
	Value = 320408,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308055,
		300478,
	},
	CloseGoal = 
	{
		300819,
	},
	GoodsId = 160408,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 9870,
				},
			},
		},
	},
	DemandID = 412063,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2064] =
{
	Id = 2064,
	Name = "订购全家桶",
	Desc = "希望有更多全家桶",
	Value = 320408,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308055,
		300840,
	},
	CloseGoal = 
	{
		300884,
	},
	GoodsId = 190408,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 9870,
				},
			},
		},
	},
	DemandID = 412064,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2072] =
{
	Id = 2072,
	Name = "美食爱好者",
	Desc = "看到小猫们在吃，也想尝试一下。",
	Value = 320410,
	Active = false,
	Weight = 0,
	GoodsId = 130410,
	Num = 6,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5922,
				},
			},
		},
	},
	DemandID = 412072,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2073] =
{
	Id = 2073,
	Name = "美食爱好者",
	Desc = "看到小猫们在吃，也想尝试一下。",
	Value = 320410,
	Active = true,
	Weight = 1824,
	PreGoal = 
	{
		308103,
	},
	CloseGoal = 
	{
		308104,
	},
	GoodsId = 160410,
	Num = 9,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 8883,
				},
			},
		},
	},
	DemandID = 412073,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2074] =
{
	Id = 2074,
	Name = "美食爱好者",
	Desc = "看到小猫们在吃，也想尝试一下。",
	Value = 320410,
	Active = true,
	Weight = 3658,
	PreGoal = 
	{
		308106,
	},
	CloseGoal = 
	{
		308107,
	},
	GoodsId = 190410,
	Num = 33,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 32571,
				},
			},
		},
	},
	DemandID = 412074,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2082] =
{
	Id = 2082,
	Name = "0",
	Desc = "0",
	Value = 320411,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308103,
		300458,
	},
	CloseGoal = 
	{
		300490,
	},
	GoodsId = 130411,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5922,
				},
			},
		},
	},
	DemandID = 412082,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2083] =
{
	Id = 2083,
	Name = "0",
	Desc = "0",
	Value = 320411,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308103,
		300499,
	},
	CloseGoal = 
	{
		300840,
	},
	GoodsId = 160411,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5922,
				},
			},
		},
	},
	DemandID = 412083,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2084] =
{
	Id = 2084,
	Name = "0",
	Desc = "0",
	Value = 320411,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308103,
		300860,
	},
	CloseGoal = 
	{
		300904,
	},
	GoodsId = 190411,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5922,
				},
			},
		},
	},
	DemandID = 412084,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2092] =
{
	Id = 2092,
	Name = "0",
	Desc = "0",
	Value = 320412,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308105,
		300823,
	},
	CloseGoal = 
	{
		300856,
	},
	GoodsId = 130412,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 23688,
				},
			},
		},
	},
	DemandID = 412092,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2093] =
{
	Id = 2093,
	Name = "0",
	Desc = "0",
	Value = 320412,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308105,
		300864,
	},
	CloseGoal = 
	{
		300900,
	},
	GoodsId = 160412,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 23688,
				},
			},
		},
	},
	DemandID = 412093,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2094] =
{
	Id = 2094,
	Name = "0",
	Desc = "0",
	Value = 320412,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308105,
		301224,
	},
	CloseGoal = 
	{
		301268,
	},
	GoodsId = 190412,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 23688,
				},
			},
		},
	},
	DemandID = 412094,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2102] =
{
	Id = 2102,
	Name = "订购陷阱",
	Desc = "需要大量陷阱",
	Value = 320301,
	Active = false,
	Weight = 0,
	GoodsId = 130301,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 422,
				},
			},
		},
	},
	DemandID = 412102,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2103] =
{
	Id = 2103,
	Name = "订购陷阱",
	Desc = "需要大量陷阱",
	Value = 320301,
	Active = true,
	Weight = 225,
	PreGoal = 
	{
		308001,
	},
	CloseGoal = 
	{
		308002,
	},
	GoodsId = 160301,
	Num = 4,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 1689,
				},
			},
		},
	},
	DemandID = 412103,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2104] =
{
	Id = 2104,
	Name = "订购陷阱",
	Desc = "需要大量陷阱",
	Value = 320301,
	Active = true,
	Weight = 741,
	PreGoal = 
	{
		308004,
	},
	CloseGoal = 
	{
		308005,
	},
	GoodsId = 190301,
	Num = 18,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 7602,
				},
			},
		},
	},
	DemandID = 412104,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2112] =
{
	Id = 2112,
	Name = "0",
	Desc = "0",
	Value = 320302,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308002,
		300062,
	},
	CloseGoal = 
	{
		300091,
	},
	GoodsId = 130302,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5215,
				},
			},
		},
	},
	DemandID = 412112,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2113] =
{
	Id = 2113,
	Name = "0",
	Desc = "0",
	Value = 320302,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308002,
		300102,
	},
	CloseGoal = 
	{
		300431,
	},
	GoodsId = 160302,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5215,
				},
			},
		},
	},
	DemandID = 412113,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2114] =
{
	Id = 2114,
	Name = "0",
	Desc = "0",
	Value = 320302,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308002,
		300450,
	},
	CloseGoal = 
	{
		300494,
	},
	GoodsId = 190302,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5215,
				},
			},
		},
	},
	DemandID = 412114,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2122] =
{
	Id = 2122,
	Name = "0",
	Desc = "0",
	Value = 320303,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308004,
		300087,
	},
	CloseGoal = 
	{
		300417,
	},
	GoodsId = 130303,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 27489,
				},
			},
		},
	},
	DemandID = 412122,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2123] =
{
	Id = 2123,
	Name = "0",
	Desc = "0",
	Value = 320303,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308004,
		300424,
	},
	CloseGoal = 
	{
		300458,
	},
	GoodsId = 160303,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 27489,
				},
			},
		},
	},
	DemandID = 412123,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2124] =
{
	Id = 2124,
	Name = "0",
	Desc = "0",
	Value = 320303,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308004,
		300478,
	},
	CloseGoal = 
	{
		300827,
	},
	GoodsId = 190303,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 27489,
				},
			},
		},
	},
	DemandID = 412124,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2132] =
{
	Id = 2132,
	Name = "订购空瓶",
	Desc = "需要大量空瓶",
	Value = 320305,
	Active = false,
	Weight = 0,
	GoodsId = 130305,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 422,
				},
			},
		},
	},
	DemandID = 412132,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2133] =
{
	Id = 2133,
	Name = "订购空瓶",
	Desc = "需要大量空瓶",
	Value = 320305,
	Active = true,
	Weight = 420,
	PreGoal = 
	{
		308053,
	},
	CloseGoal = 
	{
		308054,
	},
	GoodsId = 160305,
	Num = 4,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 1689,
				},
			},
		},
	},
	DemandID = 412133,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2134] =
{
	Id = 2134,
	Name = "订购空瓶",
	Desc = "需要大量空瓶",
	Value = 320305,
	Active = true,
	Weight = 1848,
	PreGoal = 
	{
		308056,
	},
	CloseGoal = 
	{
		308057,
	},
	GoodsId = 190305,
	Num = 18,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 7602,
				},
			},
		},
	},
	DemandID = 412134,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2142] =
{
	Id = 2142,
	Name = "0",
	Desc = "0",
	Value = 320306,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308054,
		300428,
	},
	CloseGoal = 
	{
		300458,
	},
	GoodsId = 130306,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5215,
				},
			},
		},
	},
	DemandID = 412142,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2143] =
{
	Id = 2143,
	Name = "0",
	Desc = "0",
	Value = 320306,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308054,
		300466,
	},
	CloseGoal = 
	{
		300804,
	},
	GoodsId = 160306,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5215,
				},
			},
		},
	},
	DemandID = 412143,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2144] =
{
	Id = 2144,
	Name = "0",
	Desc = "0",
	Value = 320306,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308054,
		300827,
	},
	CloseGoal = 
	{
		300872,
	},
	GoodsId = 190306,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5215,
				},
			},
		},
	},
	DemandID = 412144,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2152] =
{
	Id = 2152,
	Name = "0",
	Desc = "0",
	Value = 320307,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308056,
		300474,
	},
	CloseGoal = 
	{
		300810,
	},
	GoodsId = 130307,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 27489,
				},
			},
		},
	},
	DemandID = 412152,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2153] =
{
	Id = 2153,
	Name = "0",
	Desc = "0",
	Value = 320307,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308056,
		300819,
	},
	CloseGoal = 
	{
		300856,
	},
	GoodsId = 160307,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 27489,
				},
			},
		},
	},
	DemandID = 412153,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2154] =
{
	Id = 2154,
	Name = "0",
	Desc = "0",
	Value = 320307,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308056,
		300876,
	},
	CloseGoal = 
	{
		301224,
	},
	GoodsId = 190307,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 27489,
				},
			},
		},
	},
	DemandID = 412154,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2162] =
{
	Id = 2162,
	Name = "订购纸袋",
	Desc = "需要大量纸袋",
	Value = 320309,
	Active = false,
	Weight = 0,
	GoodsId = 130309,
	Num = 3,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 1267,
				},
			},
		},
	},
	DemandID = 412162,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2163] =
{
	Id = 2163,
	Name = "订购纸袋",
	Desc = "需要大量纸袋",
	Value = 320309,
	Active = true,
	Weight = 2052,
	PreGoal = 
	{
		308103,
	},
	CloseGoal = 
	{
		308104,
	},
	GoodsId = 160309,
	Num = 4,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 1689,
				},
			},
		},
	},
	DemandID = 412163,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2164] =
{
	Id = 2164,
	Name = "订购纸袋",
	Desc = "需要大量纸袋",
	Value = 320309,
	Active = true,
	Weight = 4012,
	PreGoal = 
	{
		308106,
	},
	CloseGoal = 
	{
		308107,
	},
	GoodsId = 190309,
	Num = 18,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 7602,
				},
			},
		},
	},
	DemandID = 412164,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2172] =
{
	Id = 2172,
	Name = "0",
	Desc = "0",
	Value = 320310,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308104,
		300810,
	},
	CloseGoal = 
	{
		300844,
	},
	GoodsId = 130310,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5215,
				},
			},
		},
	},
	DemandID = 412172,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2173] =
{
	Id = 2173,
	Name = "0",
	Desc = "0",
	Value = 320310,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308104,
		300852,
	},
	CloseGoal = 
	{
		300888,
	},
	GoodsId = 160310,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5215,
				},
			},
		},
	},
	DemandID = 412173,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2174] =
{
	Id = 2174,
	Name = "0",
	Desc = "0",
	Value = 320310,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308104,
		301204,
	},
	CloseGoal = 
	{
		301256,
	},
	GoodsId = 190310,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5215,
				},
			},
		},
	},
	DemandID = 412174,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2182] =
{
	Id = 2182,
	Name = "0",
	Desc = "0",
	Value = 320311,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308106,
		300848,
	},
	CloseGoal = 
	{
		300880,
	},
	GoodsId = 130311,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 33411,
				},
			},
		},
	},
	DemandID = 412182,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2183] =
{
	Id = 2183,
	Name = "0",
	Desc = "0",
	Value = 320311,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308106,
		300888,
	},
	CloseGoal = 
	{
		301228,
	},
	GoodsId = 160311,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 33411,
				},
			},
		},
	},
	DemandID = 412183,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2184] =
{
	Id = 2184,
	Name = "0",
	Desc = "0",
	Value = 320311,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308106,
		301248,
	},
	CloseGoal = 
	{
		301292,
	},
	GoodsId = 190311,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 33411,
				},
			},
		},
	},
	DemandID = 412184,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2192] =
{
	Id = 2192,
	Name = "订购工具箱",
	Desc = "需要大量工具箱",
	Value = 320313,
	Active = false,
	Weight = 0,
	GoodsId = 130313,
	Num = 4,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 1689,
				},
			},
		},
	},
	DemandID = 412192,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2193] =
{
	Id = 2193,
	Name = "订购工具箱",
	Desc = "需要大量工具箱",
	Value = 320313,
	Active = true,
	Weight = 4032,
	PreGoal = 
	{
		308153,
	},
	CloseGoal = 
	{
		308154,
	},
	GoodsId = 160313,
	Num = 4,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 1689,
				},
			},
		},
	},
	DemandID = 412193,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2194] =
{
	Id = 2194,
	Name = "订购工具箱",
	Desc = "需要大量工具箱",
	Value = 320313,
	Active = true,
	Weight = 6622,
	PreGoal = 
	{
		308156,
	},
	CloseGoal = 
	{
		308157,
	},
	GoodsId = 190313,
	Num = 18,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 7602,
				},
			},
		},
	},
	DemandID = 412194,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2202] =
{
	Id = 2202,
	Name = "0",
	Desc = "0",
	Value = 320314,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308155,
		300868,
	},
	CloseGoal = 
	{
		300900,
	},
	GoodsId = 130314,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 11767,
				},
			},
		},
	},
	DemandID = 412202,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2203] =
{
	Id = 2203,
	Name = "0",
	Desc = "0",
	Value = 320314,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308155,
		301204,
	},
	CloseGoal = 
	{
		301248,
	},
	GoodsId = 160314,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 11767,
				},
			},
		},
	},
	DemandID = 412203,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2204] =
{
	Id = 2204,
	Name = "0",
	Desc = "0",
	Value = 320314,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308155,
		301268,
	},
	CloseGoal = 
	{
		301314,
	},
	GoodsId = 190314,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 11767,
				},
			},
		},
	},
	DemandID = 412204,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2212] =
{
	Id = 2212,
	Name = "0",
	Desc = "0",
	Value = 320315,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308157,
		301236,
	},
	CloseGoal = 
	{
		301268,
	},
	GoodsId = 130315,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 66801,
				},
			},
		},
	},
	DemandID = 412212,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2213] =
{
	Id = 2213,
	Name = "0",
	Desc = "0",
	Value = 320315,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308157,
		301276,
	},
	CloseGoal = 
	{
		301314,
	},
	GoodsId = 160315,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 66801,
				},
			},
		},
	},
	DemandID = 412213,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2214] =
{
	Id = 2214,
	Name = "0",
	Desc = "0",
	Value = 320315,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308157,
		301615,
	},
	CloseGoal = 
	{
		301670,
	},
	GoodsId = 190315,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 66801,
				},
			},
		},
	},
	DemandID = 412214,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2222] =
{
	Id = 2222,
	Name = "订购纸板箱",
	Desc = "需要大量纸板箱",
	Value = 320317,
	Active = false,
	Weight = 0,
	GoodsId = 130317,
	Num = 4,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 1689,
				},
			},
		},
	},
	DemandID = 412222,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2223] =
{
	Id = 2223,
	Name = "订购纸板箱",
	Desc = "需要大量纸板箱",
	Value = 320317,
	Active = true,
	Weight = 3905,
	PreGoal = 
	{
		308152,
	},
	CloseGoal = 
	{
		308154,
	},
	GoodsId = 160317,
	Num = 4,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 1689,
				},
			},
		},
	},
	DemandID = 412223,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2224] =
{
	Id = 2224,
	Name = "订购纸板箱",
	Desc = "需要大量纸板箱",
	Value = 320317,
	Active = true,
	Weight = 6545,
	PreGoal = 
	{
		308156,
	},
	CloseGoal = 
	{
		308157,
	},
	GoodsId = 190317,
	Num = 18,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 7602,
				},
			},
		},
	},
	DemandID = 412224,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2232] =
{
	Id = 2232,
	Name = "0",
	Desc = "0",
	Value = 320318,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308154,
		300856,
	},
	CloseGoal = 
	{
		300888,
	},
	GoodsId = 130318,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 11767,
				},
			},
		},
	},
	DemandID = 412232,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2233] =
{
	Id = 2233,
	Name = "0",
	Desc = "0",
	Value = 320318,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308154,
		300896,
	},
	CloseGoal = 
	{
		301236,
	},
	GoodsId = 160318,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 11767,
				},
			},
		},
	},
	DemandID = 412233,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2234] =
{
	Id = 2234,
	Name = "0",
	Desc = "0",
	Value = 320318,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308154,
		301256,
	},
	CloseGoal = 
	{
		301301,
	},
	GoodsId = 190318,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 11767,
				},
			},
		},
	},
	DemandID = 412234,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2242] =
{
	Id = 2242,
	Name = "0",
	Desc = "0",
	Value = 320319,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308156,
		301224,
	},
	CloseGoal = 
	{
		301256,
	},
	GoodsId = 130319,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 66801,
				},
			},
		},
	},
	DemandID = 412242,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2243] =
{
	Id = 2243,
	Name = "0",
	Desc = "0",
	Value = 320319,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308156,
		301264,
	},
	CloseGoal = 
	{
		301301,
	},
	GoodsId = 160319,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 66801,
				},
			},
		},
	},
	DemandID = 412243,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2244] =
{
	Id = 2244,
	Name = "0",
	Desc = "0",
	Value = 320319,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308156,
		301322,
	},
	CloseGoal = 
	{
		301655,
	},
	GoodsId = 190319,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 66801,
				},
			},
		},
	},
	DemandID = 412244,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2252] =
{
	Id = 2252,
	Name = "浪漫的哨声",
	Desc = "树叶能吹出美丽的哨声？想要些呢~",
	Value = 321001,
	Active = true,
	Weight = 60,
	PreGoal = 
	{
		300004,
		300020,
	},
	CloseGoal = 
	{
		300055,
	},
	GoodsId = 131001,
	Num = 18,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 197,
				},
			},
		},
	},
	DemandID = 412252,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2253] =
{
	Id = 2253,
	Name = "浪漫的哨声",
	Desc = "树叶能吹出美丽的哨声？想要些呢~",
	Value = 321001,
	Active = true,
	Weight = 160,
	PreGoal = 
	{
		300004,
		300062,
	},
	CloseGoal = 
	{
		300096,
	},
	GoodsId = 161001,
	Num = 90,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 986,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 8,
				},
				{
					Value = 1,
					Num = 186,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 1,
				},
				{
					Value = 1,
					Num = 486,
				},
			},
		},
	},
	DemandID = 412253,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2254] =
{
	Id = 2254,
	Name = "浪漫的哨声",
	Desc = "树叶能吹出美丽的哨声？想要些呢~",
	Value = 321001,
	Active = true,
	Weight = 300,
	PreGoal = 
	{
		300004,
		300413,
	},
	CloseGoal = 
	{
		300454,
	},
	GoodsId = 191001,
	Num = 300,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 3288,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 27,
				},
				{
					Value = 1,
					Num = 588,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 5,
				},
				{
					Value = 1,
					Num = 788,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 1,
				},
				{
					Value = 1,
					Num = 788,
				},
			},
		},
	},
	DemandID = 412254,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2262] =
{
	Id = 2262,
	Name = "练习空手道",
	Desc = "这次要一下子劈断好几块木头!",
	Value = 321002,
	Active = true,
	Weight = 225,
	PreGoal = 
	{
		300017,
		300035,
	},
	CloseGoal = 
	{
		300066,
	},
	GoodsId = 131002,
	Num = 7,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 543,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 3,
				},
				{
					Value = 320051,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412262,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
