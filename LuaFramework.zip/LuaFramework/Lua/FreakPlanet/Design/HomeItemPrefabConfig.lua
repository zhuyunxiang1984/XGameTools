---------------------
---这个lua为自动导出配置
---------------------



HomeItemPrefabConfig = {}

HomeItemPrefabConfig["FAT_BiGua001"] = 
{
	FromType = 1,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["FAT_BiGua002"] = 
{
	FromType = 1,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["FAT_BiGua003"] = 
{
	FromType = 1,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["FAT_BiGua004"] = 
{
	FromType = 1,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["FAT_BiGua005"] = 
{
	FromType = 1,
	ColCount = 5,
	RowCount = 3,
}
HomeItemPrefabConfig["FAT_BiGua006"] = 
{
	FromType = 1,
	ColCount = 12,
	RowCount = 6,
}
HomeItemPrefabConfig["FAT_BiGua007"] = 
{
	FromType = 1,
	ColCount = 8,
	RowCount = 4,
}
HomeItemPrefabConfig["FAT_DianQi001"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 5,
}
HomeItemPrefabConfig["FAT_DianQi002"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["FAT_DianQi003"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 11,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = 0.16, y = 4.23},
			Offsets = 
			{
				{ x = 0, y = -1.86, z = 0.12 },
				{ x = 0, y = -1.8, z = -0.21 },
				{ x = 0, y = 1.2, z = 0 },
				{ x = 0, y = 1.14, z = 0 },
			},
			ColCount = 4,
			RowCount = 11,
		},
	},
}
HomeItemPrefabConfig["FAT_DianQi004"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 4,
}
HomeItemPrefabConfig["FAT_DianQi005"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 5,
}
HomeItemPrefabConfig["FAT_DianQi006"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 6,
}
HomeItemPrefabConfig["FAT_DianQi007"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["FAT_DianQi008"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 7,
}
HomeItemPrefabConfig["FAT_DianQi009"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["FAT_DianZi001"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["FAT_GuiZi001"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 5,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = 0.09, y = 1.26},
			Offsets = 
			{
				{ x = 0, y = 1.26, z = 0 },
			},
			ColCount = 5,
			RowCount = 5,
		},
	},
}
HomeItemPrefabConfig["FAT_GuiZi002"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 8,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = -0.14, y = 1.19},
			Offsets = 
			{
				{ x = -0.18, y = 1.05, z = -0.29 },
				{ x = -0.37, y = 0.72, z = 0.12 },
				{ x = 0, y = 0.75, z = -0.8 },
				{ x = 0, y = 0.81, z = 0.78 },
			},
			ColCount = 4,
			RowCount = 6,
		},
	},
}
HomeItemPrefabConfig["FAT_GuiZi003"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 5,
}
HomeItemPrefabConfig["FAT_GuiZi004"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 15,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = 0.16, y = 1.6},
			Offsets = 
			{
				{ x = 0, y = 1.18, z = 1.08 },
				{ x = 0, y = 1.13, z = -1.17 },
				{ x = 0, y = 1.18, z = 1.2 },
				{ x = 0, y = 1.38, z = -1.4 },
			},
			ColCount = 3,
			RowCount = 8,
		},
	},
}
HomeItemPrefabConfig["FAT_GuiZi005"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 8,
}
HomeItemPrefabConfig["FAT_GuiZi006"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 5,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = 0.06, y = 1.68},
			Offsets = 
			{
				{ x = 0, y = 1.82, z = 0 },
			},
			ColCount = 5,
			RowCount = 5,
		},
	},
}
HomeItemPrefabConfig["FAT_GuiZi007"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 13,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = 0.14, y = 1.7},
			Offsets = 
			{
				{ x = 0, y = 1.59, z = 0 },
			},
			ColCount = 5,
			RowCount = 13,
		},
	},
}
HomeItemPrefabConfig["FAT_GuiZi008"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 8,
}
HomeItemPrefabConfig["FAT_TanZi001"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 9,
}
HomeItemPrefabConfig["FAT_TanZi002"] = 
{
	FromType = 0,
	ColCount = 34,
	RowCount = 34,
}
HomeItemPrefabConfig["FAT_TanZi003"] = 
{
	FromType = 0,
	ColCount = 25,
	RowCount = 25,
}
HomeItemPrefabConfig["FAT_TanZi004"] = 
{
	FromType = 0,
	ColCount = 22,
	RowCount = 30,
}
HomeItemPrefabConfig["FAT_TanZi005"] = 
{
	FromType = 0,
	ColCount = 15,
	RowCount = 18,
}
HomeItemPrefabConfig["FAT_TanZi006"] = 
{
	FromType = 0,
	ColCount = 25,
	RowCount = 30,
}
HomeItemPrefabConfig["FAT_TanZi007"] = 
{
	FromType = 0,
	ColCount = 26,
	RowCount = 26,
}
HomeItemPrefabConfig["FAT_TanZi008"] = 
{
	FromType = 0,
	ColCount = 25,
	RowCount = 33,
}
HomeItemPrefabConfig["FAT_TanZi009"] = 
{
	FromType = 0,
	ColCount = 8,
	RowCount = 11,
}
HomeItemPrefabConfig["FAT_YiZi001"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["FAT_YiZi002"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["FAT_YiZi003"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["FAT_YiZi004"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 6,
}
HomeItemPrefabConfig["FAT_YiZi005"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["FAT_YiZi006"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["FAT_YiZi007"] = 
{
	FromType = 0,
	ColCount = 8,
	RowCount = 8,
}
HomeItemPrefabConfig["FAT_YiZi008"] = 
{
	FromType = 0,
	ColCount = 8,
	RowCount = 8,
}
HomeItemPrefabConfig["FAT_YiZi009"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["FAT_YiZi010"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 5,
}
HomeItemPrefabConfig["FAT_ZhuangShi001"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["FAT_ZhuangShi002"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["FAT_ZhuangShi003"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["FAT_ZhuangShi004"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["FAT_ZhuangShi005"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["FAT_ZhuangShi006"] = 
{
	FromType = 0,
	ColCount = 0,
	RowCount = 0,
}
HomeItemPrefabConfig["FAT_ZhuangShi007"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["FAT_ZhuangShi008"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["FAT_ZhuangShi009"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["FAT_ZhuangShi010"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["FAT_ZhuangShi011"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 5,
}
HomeItemPrefabConfig["FAT_ZhuangShi012"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 3,
}
HomeItemPrefabConfig["FAT_ZhuangShi013"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["FAT_ZhuangShi014"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["FAT_ZhuangShi015"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 5,
}
HomeItemPrefabConfig["FAT_ZhuangShi016"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 7,
}
HomeItemPrefabConfig["FAT_ZhuangShi017"] = 
{
	FromType = 0,
	ColCount = 7,
	RowCount = 19,
}
HomeItemPrefabConfig["FAT_ZhuangShi018"] = 
{
	FromType = 0,
	ColCount = 7,
	RowCount = 10,
}
HomeItemPrefabConfig["FAT_ZhuangShi019"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["FAT_ZhuangShi020"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["FAT_ZhuangShi021"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 5,
}
HomeItemPrefabConfig["FAT_ZhuangShi022"] = 
{
	FromType = 0,
	ColCount = 1,
	RowCount = 12,
}
HomeItemPrefabConfig["FAT_ZhuangShi023"] = 
{
	FromType = 0,
	ColCount = 1,
	RowCount = 12,
}
HomeItemPrefabConfig["FAT_ZhuangShi024"] = 
{
	FromType = 0,
	ColCount = 1,
	RowCount = 6,
}
HomeItemPrefabConfig["FAT_ZhuangShi026"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["FAT_ZhuangShi027"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 6,
}
HomeItemPrefabConfig["FAT_ZhuangShi028"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 5,
}
HomeItemPrefabConfig["FAT_ZhuangShi029"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 5,
}
HomeItemPrefabConfig["FAT_ZhuangShi030"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["FAT_ZhuangShi031"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 5,
}
HomeItemPrefabConfig["FAT_ZhuangShi032"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 5,
}
HomeItemPrefabConfig["FAT_ZhuangShi033"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["FAT_ZhuangShi034"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 4,
}
HomeItemPrefabConfig["FAT_ZhuangShi035"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 3,
}
HomeItemPrefabConfig["FAT_ZhuangShi036"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["FAT_ZhuangShi037"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 2,
}
HomeItemPrefabConfig["FAT_ZhuangShi038"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 4,
}
HomeItemPrefabConfig["FAT_ZhuangShi039"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 4,
}
HomeItemPrefabConfig["FAT_ZhuangShi040"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 3,
}
HomeItemPrefabConfig["FAT_ZhuangShi041"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 3,
}
HomeItemPrefabConfig["FAT_ZhuangShi042"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["FAT_ZhuangShi043"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 12,
}
HomeItemPrefabConfig["FAT_ZhuangShi044"] = 
{
	FromType = 0,
	ColCount = 10,
	RowCount = 10,
}
HomeItemPrefabConfig["FAT_ZhuangShi045"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["FAT_ZhuangShi046"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["FAT_ZhuangShi047"] = 
{
	FromType = 0,
	ColCount = 12,
	RowCount = 2,
}
HomeItemPrefabConfig["FAT_ZhuangShi048"] = 
{
	FromType = 0,
	ColCount = 7,
	RowCount = 7,
}
HomeItemPrefabConfig["FAT_ZhuangShi049"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["FAT_ZhuangShi050"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 5,
}
HomeItemPrefabConfig["FAT_ZhuangShi051"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["FAT_ZhuangShi052"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["FAT_ZhuangShi053"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["FAT_ZhuangShi054"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["FAT_ZhuangShi055"] = 
{
	FromType = 0,
	ColCount = 8,
	RowCount = 8,
}
HomeItemPrefabConfig["FAT_ZhuangShi057"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["FAT_ZhuangShi058"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["FAT_ZhuoZi001"] = 
{
	FromType = 0,
	ColCount = 8,
	RowCount = 14,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = -0.09, y = 1.09},
			Offsets = 
			{
				{ x = 0, y = 1.18, z = 0 },
			},
			ColCount = 8,
			RowCount = 13,
		},
	},
}
HomeItemPrefabConfig["FAT_ZhuoZi002"] = 
{
	FromType = 0,
	ColCount = 8,
	RowCount = 8,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = -0.05, y = 1.42},
			Offsets = 
			{
				{ x = 0, y = 1.19, z = 0 },
			},
			ColCount = 5,
			RowCount = 5,
		},
	},
}
HomeItemPrefabConfig["FAT_ZhuoZi003"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 9,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = -0.03999999, y = 0.96},
			Offsets = 
			{
				{ x = 0, y = 0.97, z = 0 },
			},
			ColCount = 6,
			RowCount = 8,
		},
	},
}
HomeItemPrefabConfig["FAT_ZhuoZi004"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 17,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = -0.09000002, y = 1.44},
			Offsets = 
			{
				{ x = 0, y = 1.35, z = 2.21 },
			},
			ColCount = 5,
			RowCount = 9,
		},
	},
}
HomeItemPrefabConfig["FAT_ZhuoZi005"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 9,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = 0.04999998, y = 1.09},
			Offsets = 
			{
				{ x = 0, y = 1.08, z = 0 },
			},
			ColCount = 3,
			RowCount = 9,
		},
	},
}
HomeItemPrefabConfig["FAT_ZhuoZi006"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 16,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = 0.05000001, y = 1.28},
			Offsets = 
			{
				{ x = 0, y = 1.47, z = 0 },
			},
			ColCount = 5,
			RowCount = 16,
		},
	},
}
HomeItemPrefabConfig["FAT_ZhuoZi007"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 6,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = 0.06, y = 1.01},
			Offsets = 
			{
				{ x = 0, y = 0.99, z = 0 },
			},
			ColCount = 6,
			RowCount = 6,
		},
	},
}
HomeItemPrefabConfig["FAT_ZhuoZi008"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 8,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = 0.07999998, y = 1.28},
			Offsets = 
			{
				{ x = 0, y = 1.09, z = 0 },
			},
			ColCount = 5,
			RowCount = 8,
		},
	},
}
HomeItemPrefabConfig["Default_BiGua001"] = 
{
	FromType = 1,
	ColCount = 12,
	RowCount = 6,
}
HomeItemPrefabConfig["Default_BiGua002"] = 
{
	FromType = 1,
	ColCount = 6,
	RowCount = 4,
}
HomeItemPrefabConfig["Default_BiGua003"] = 
{
	FromType = 1,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["Default_BiGua004"] = 
{
	FromType = 1,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["Default_BiGua005"] = 
{
	FromType = 1,
	ColCount = 6,
	RowCount = 4,
}
HomeItemPrefabConfig["Default_BiGua006"] = 
{
	FromType = 1,
	ColCount = 10,
	RowCount = 6,
}
HomeItemPrefabConfig["Default_BiGua007"] = 
{
	FromType = 1,
	ColCount = 6,
	RowCount = 6,
}
HomeItemPrefabConfig["Default_BingXiang001"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 8,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = -0.06, y = 3.55},
			Offsets = 
			{
				{ x = 0, y = 3.28, z = 0 },
			},
			ColCount = 6,
			RowCount = 6,
		},
	},
}
HomeItemPrefabConfig["Default_DianNao001"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 6,
}
HomeItemPrefabConfig["Default_DianQi001"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["Default_DianShi001"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 7,
}
HomeItemPrefabConfig["Default_DianZi001"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 5,
}
HomeItemPrefabConfig["Default_DianZi002"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 6,
}
HomeItemPrefabConfig["Default_DianZi003"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 6,
}
HomeItemPrefabConfig["Default_DianZi004"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 6,
}
HomeItemPrefabConfig["Default_DiaoXiang001"] = 
{
	FromType = 0,
	ColCount = 7,
	RowCount = 7,
}
HomeItemPrefabConfig["Default_GuiZi001"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 8,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = 0.03, y = 3.76},
			Offsets = 
			{
				{ x = 0, y = 3.64, z = 0 },
			},
			ColCount = 4,
			RowCount = 8,
		},
	},
}
HomeItemPrefabConfig["Default_Guo001"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 4,
}
HomeItemPrefabConfig["Default_HeiBan001"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 14,
}
HomeItemPrefabConfig["Default_Hua001"] = 
{
	FromType = 0,
	ColCount = 0,
	RowCount = 0,
}
HomeItemPrefabConfig["Default_JianPan001"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 4,
}
HomeItemPrefabConfig["Default_LanGan002"] = 
{
	FromType = 0,
	ColCount = 12,
	RowCount = 2,
}
HomeItemPrefabConfig["Default_PS5001"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 4,
}
HomeItemPrefabConfig["Default_ShaFa001"] = 
{
	FromType = 0,
	ColCount = 8,
	RowCount = 8,
}
HomeItemPrefabConfig["Default_ShaFa002"] = 
{
	FromType = 0,
	ColCount = 8,
	RowCount = 8,
}
HomeItemPrefabConfig["Default_ShaFa003"] = 
{
	FromType = 0,
	ColCount = 8,
	RowCount = 8,
}
HomeItemPrefabConfig["Default_ShiGuang001"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["Default_ShiGuang002"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["Default_ShiGuang003"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 2,
}
HomeItemPrefabConfig["Default_ShiGuang004"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 8,
}
HomeItemPrefabConfig["Default_ShiWu001"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["Default_ShiWu002"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["Default_ShuBiao001"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["Default_TanZi001"] = 
{
	FromType = 0,
	ColCount = 32,
	RowCount = 36,
}
HomeItemPrefabConfig["Default_TanZi002"] = 
{
	FromType = 0,
	ColCount = 16,
	RowCount = 20,
}
HomeItemPrefabConfig["Default_TanZi003"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 6,
}
HomeItemPrefabConfig["Default_TanZi004"] = 
{
	FromType = 0,
	ColCount = 10,
	RowCount = 12,
}
HomeItemPrefabConfig["Default_TanZi005"] = 
{
	FromType = 0,
	ColCount = 10,
	RowCount = 14,
}
HomeItemPrefabConfig["Default_TanZi006"] = 
{
	FromType = 0,
	ColCount = 26,
	RowCount = 26,
}
HomeItemPrefabConfig["Default_TanZi007"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 12,
}
HomeItemPrefabConfig["Default_WangYuanJing001"] = 
{
	FromType = 0,
	ColCount = 8,
	RowCount = 8,
}
HomeItemPrefabConfig["Default_WanOu001"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 5,
}
HomeItemPrefabConfig["Default_XiangZi001"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 4,
}
HomeItemPrefabConfig["Default_XiangZi002"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 4,
}
HomeItemPrefabConfig["Default_YinXiang001"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 8,
}
HomeItemPrefabConfig["Default_YinXiang002"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 2,
}
HomeItemPrefabConfig["Default_YinXiang003"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["Default_YinXiang005"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["Default_YiZi001"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["Default_YiZi002"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 5,
}
HomeItemPrefabConfig["Default_YiZi003"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 5,
}
HomeItemPrefabConfig["Default_YiZi004"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["Default_YiZi005"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["Default_YiZi006"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["Default_YiZi007"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["Default_YouXiJi001"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 9,
}
HomeItemPrefabConfig["Default_ZhiWu001"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["Default_ZhiWu002"] = 
{
	FromType = 0,
	ColCount = 11,
	RowCount = 6,
}
HomeItemPrefabConfig["Default_ZhiWu003"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["Default_ZhiWu004"] = 
{
	FromType = 0,
	ColCount = 8,
	RowCount = 8,
}
HomeItemPrefabConfig["Default_Zhiwu005"] = 
{
	FromType = 0,
	ColCount = 8,
	RowCount = 8,
}
HomeItemPrefabConfig["Default_Zhiwu006"] = 
{
	FromType = 0,
	ColCount = 7,
	RowCount = 14,
}
HomeItemPrefabConfig["Default_Zhiwu007"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["Default_ZhiWu008"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["Default_ZhiWu009"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["Default_ZhiWu010"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["Default_ZhiWu011"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["Default_ZhuangShi001"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 3,
}
HomeItemPrefabConfig["Default_ZhuangShi002"] = 
{
	FromType = 0,
	ColCount = 8,
	RowCount = 8,
}
HomeItemPrefabConfig["Default_ZhuangShi003"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 2,
}
HomeItemPrefabConfig["Default_ZhuangShi004"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["Default_ZhuangShi005"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["Default_ZhuangShi006"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["Default_ZhuangShi007"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["Default_ZhuangShi008"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["Default_ZhuangShi010"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["Default_ZhuangShi011"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["Default_ZhuangShi012"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["Default_ZhuangShi014"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["Default_ZhuangShi016"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["Default_ZhuangShi017"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["Default_ZhuangShi018"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["Default_ZhuangShi019"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["Default_ZhuangShi020"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 8,
}
HomeItemPrefabConfig["Default_ZhuangShi021"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["Default_ZhuangShi022"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["Default_ZhuangShi023"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 4,
}
HomeItemPrefabConfig["Default_ZhuangShi024"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["Default_ZhuangShi025"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["Default_ZhuangShi026"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["Default_ZhuangShi027"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["Default_ZhuangShi028"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["Default_ZhuangShi030"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 8,
}
HomeItemPrefabConfig["Default_ZhuJi001"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 5,
}
HomeItemPrefabConfig["Default_ZhuoZi001"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 10,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = 0.04, y = 1.04},
			Offsets = 
			{
				{ x = 0, y = 1.08, z = 0 },
			},
			ColCount = 4,
			RowCount = 10,
		},
	},
}
HomeItemPrefabConfig["Default_ZhuoZi002"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 14,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = 0.1, y = 1.22},
			Offsets = 
			{
				{ x = 0, y = 1.2, z = 0 },
			},
			ColCount = 6,
			RowCount = 14,
		},
	},
}
HomeItemPrefabConfig["Default_ZhuoZi003"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 20,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = -0.06, y = 1.76},
			Offsets = 
			{
				{ x = 0, y = 1.5, z = 0 },
			},
			ColCount = 6,
			RowCount = 20,
		},
	},
}
HomeItemPrefabConfig["Default_ZhuoZi005"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 17,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = -0.21, y = 1.44},
			Offsets = 
			{
				{ x = 0, y = 1.35, z = 0 },
			},
			ColCount = 6,
			RowCount = 17,
		},
	},
}
HomeItemPrefabConfig["Default_ZhuoZi006"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 13,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = 0, y = 1.18},
			Offsets = 
			{
				{ x = 0, y = 1.14, z = 0 },
			},
			ColCount = 5,
			RowCount = 13,
		},
	},
}
HomeItemPrefabConfig["Default_ZhuoZi007"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 12,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = 0.1, y = 1.221},
			Offsets = 
			{
				{ x = 0, y = 1.14, z = 0 },
			},
			ColCount = 5,
			RowCount = 11,
		},
	},
}
HomeItemPrefabConfig["Default_ZhuoZi008"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 17,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = 0.06, y = 1.57},
			Offsets = 
			{
				{ x = 0, y = 1.44, z = 0 },
			},
			ColCount = 6,
			RowCount = 16,
		},
	},
}
HomeItemPrefabConfig["Default_ZhuoZi009"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 13,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = 0, y = 1.22},
			Offsets = 
			{
				{ x = 0, y = 1.14, z = 0 },
			},
			ColCount = 5,
			RowCount = 12,
		},
	},
}
HomeItemPrefabConfig["Default_ZhuoZi010"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 16,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = -0.02999997, y = 1.54},
			Offsets = 
			{
				{ x = 0, y = 1.74, z = 1.59 },
				{ x = 0, y = 1.74, z = 2.2 },
				{ x = 0, y = 1.48, z = 2.1 },
				{ x = 0, y = 1.5, z = 1.7 },
			},
			ColCount = 6,
			RowCount = 10,
		},
	},
}
HomeItemPrefabConfig["Default_ZhuoZi011"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 12,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = -0.22, y = 1.2},
			Offsets = 
			{
				{ x = 0, y = 1.7, z = 0 },
			},
			ColCount = 6,
			RowCount = 12,
		},
	},
}
HomeItemPrefabConfig["Default_ZhuoZi013"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 8,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = -0.16, y = 1.04},
			Offsets = 
			{
				{ x = 0, y = 0.66, z = 0 },
			},
			ColCount = 4,
			RowCount = 8,
		},
	},
}
HomeItemPrefabConfig["Default2_BingXiang001"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 8,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = -0.04, y = 3.72},
			Offsets = 
			{
				{ x = -0.06, y = 3.18, z = 0 },
				{ x = -0.18, y = 3.18, z = 0 },
				{ x = 0, y = 3.24, z = 0 },
				{ x = 0, y = 3.28, z = 0 },
			},
			ColCount = 6,
			RowCount = 6,
		},
	},
}
HomeItemPrefabConfig["Default2_DianNao001"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 6,
}
HomeItemPrefabConfig["Default2_DianQi001"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["Default2_DianShi001"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 7,
}
HomeItemPrefabConfig["Default2_DianZi001"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 5,
}
HomeItemPrefabConfig["Default2_DianZi002"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["Default2_DianZi003"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 6,
}
HomeItemPrefabConfig["Default2_DianZi004"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 5,
}
HomeItemPrefabConfig["Default2_GuiZi001"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 8,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = -0.18, y = 3.66},
			Offsets = 
			{
				{ x = 0, y = 3.66, z = 0 },
			},
			ColCount = 4,
			RowCount = 8,
		},
	},
}
HomeItemPrefabConfig["Default2_Guo001"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 4,
}
HomeItemPrefabConfig["Default2_HeiBan001"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 14,
}
HomeItemPrefabConfig["Default2_JianPan001"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 4,
}
HomeItemPrefabConfig["Default2_LanGan002"] = 
{
	FromType = 0,
	ColCount = 12,
	RowCount = 2,
}
HomeItemPrefabConfig["Default2_ShaFa001"] = 
{
	FromType = 0,
	ColCount = 8,
	RowCount = 8,
}
HomeItemPrefabConfig["Default2_ShaFa002"] = 
{
	FromType = 0,
	ColCount = 8,
	RowCount = 8,
}
HomeItemPrefabConfig["Default2_ShaFa003"] = 
{
	FromType = 0,
	ColCount = 8,
	RowCount = 8,
}
HomeItemPrefabConfig["Default2_ShuBiao001"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["Default2_TanZi002"] = 
{
	FromType = 0,
	ColCount = 8,
	RowCount = 10,
}
HomeItemPrefabConfig["Default2_TanZi004"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 6,
}
HomeItemPrefabConfig["Default2_TanZi005"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 5,
}
HomeItemPrefabConfig["Default2_TanZi007"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 6,
}
HomeItemPrefabConfig["Default2_YinXiang001"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 8,
}
HomeItemPrefabConfig["Default2_YinXiang002"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 2,
}
HomeItemPrefabConfig["Default2_YinXiang003"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["Default2_YiZi001"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["Default2_YiZi002"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 5,
}
HomeItemPrefabConfig["Default2_YiZi003"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 5,
}
HomeItemPrefabConfig["Default2_YiZi004"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["Default2_YiZi005"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["Default2_YiZi006"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["Default2_YiZi007"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["Default2_ZhiWu002"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 12,
}
HomeItemPrefabConfig["Default2_Zhiwu006"] = 
{
	FromType = 0,
	ColCount = 7,
	RowCount = 15,
}
HomeItemPrefabConfig["Default2_ZhiWu008"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["Default2_ZhuangShi001"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 3,
}
HomeItemPrefabConfig["Default2_ZhuangShi012"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["Default2_ZhuangShi014"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["Default2_ZhuangShi017"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["Default2_ZhuangShi025"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["Default2_ZhuoZi001"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 10,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = 0.1, y = 1.04},
			Offsets = 
			{
				{ x = 0, y = 1.22, z = 0 },
			},
			ColCount = 4,
			RowCount = 10,
		},
	},
}
HomeItemPrefabConfig["Default2_ZhuoZi002"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 13,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = 0.08, y = 1.24},
			Offsets = 
			{
				{ x = 0, y = 1.1, z = 0 },
			},
			ColCount = 5,
			RowCount = 13,
		},
	},
}
HomeItemPrefabConfig["Default2_ZhuoZi003"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 20,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = 0.04, y = 1.68},
			Offsets = 
			{
				{ x = 0, y = 1.38, z = 0 },
			},
			ColCount = 6,
			RowCount = 20,
		},
	},
}
HomeItemPrefabConfig["Default2_ZhuoZi005"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 17,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = -0.18, y = 1.46},
			Offsets = 
			{
				{ x = 0, y = 1.28, z = 0 },
			},
			ColCount = 6,
			RowCount = 17,
		},
	},
}
HomeItemPrefabConfig["Default2_ZhuoZi006"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 13,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = -0.04, y = 1.14},
			Offsets = 
			{
				{ x = 0, y = 1.18, z = 0 },
			},
			ColCount = 5,
			RowCount = 13,
		},
	},
}
HomeItemPrefabConfig["Default2_ZhuoZi007"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 12,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = -0.08, y = 1.18},
			Offsets = 
			{
				{ x = 0, y = 1.22, z = 0 },
			},
			ColCount = 5,
			RowCount = 11,
		},
	},
}
HomeItemPrefabConfig["Default2_ZhuoZi008"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 17,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = 0.18, y = 1.58},
			Offsets = 
			{
				{ x = 0, y = 1.22, z = 0 },
			},
			ColCount = 5,
			RowCount = 16,
		},
	},
}
HomeItemPrefabConfig["Default2_ZhuoZi009"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 12,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = 0.14, y = 1.28},
			Offsets = 
			{
				{ x = 0, y = 1, z = 0 },
			},
			ColCount = 5,
			RowCount = 12,
		},
	},
}
HomeItemPrefabConfig["Default2_ZhuoZi010"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 16,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = 0.04, y = 1.66},
			Offsets = 
			{
				{ x = 0, y = 1.4, z = 1.8 },
			},
			ColCount = 6,
			RowCount = 10,
		},
	},
}
HomeItemPrefabConfig["Default2_ZhuoZi011"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 12,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = 0, y = 1.48},
			Offsets = 
			{
				{ x = 0, y = 1.38, z = 0 },
			},
			ColCount = 6,
			RowCount = 12,
		},
	},
}
HomeItemPrefabConfig["Default2_ZhuoZi013"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 8,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = 0, y = 1.04},
			Offsets = 
			{
				{ x = 0, y = 0.73, z = 0 },
			},
			ColCount = 4,
			RowCount = 8,
		},
	},
}
HomeItemPrefabConfig["Default3_BingXiang001"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 8,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = -0.01, y = 3.48},
			Offsets = 
			{
				{ x = 0, y = 3.5, z = 0 },
				{ x = 0, y = 3.5, z = 0 },
				{ x = 0, y = 3.5, z = 0 },
				{ x = 0, y = 3.5, z = 0 },
			},
			ColCount = 6,
			RowCount = 6,
		},
	},
}
HomeItemPrefabConfig["Default3_DianNao001"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 5,
}
HomeItemPrefabConfig["Default3_DianQi001"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["Default3_DianShi001"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 7,
}
HomeItemPrefabConfig["Default3_DianZi001"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 5,
}
HomeItemPrefabConfig["Default3_DianZi003"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 6,
}
HomeItemPrefabConfig["Default3_DianZi004"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 6,
}
HomeItemPrefabConfig["Default3_GuiZi001"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 8,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = 0.03, y = 3.76},
			Offsets = 
			{
				{ x = 0, y = 3.64, z = 0 },
			},
			ColCount = 4,
			RowCount = 8,
		},
	},
}
HomeItemPrefabConfig["Default3_Guo001"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 4,
}
HomeItemPrefabConfig["Default3_HeiBan001"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 14,
}
HomeItemPrefabConfig["Default3_JianPan001"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 4,
}
HomeItemPrefabConfig["Default3_ShaFa001"] = 
{
	FromType = 0,
	ColCount = 8,
	RowCount = 8,
}
HomeItemPrefabConfig["Default3_ShaFa002"] = 
{
	FromType = 0,
	ColCount = 8,
	RowCount = 8,
}
HomeItemPrefabConfig["Default3_ShaFa003"] = 
{
	FromType = 0,
	ColCount = 8,
	RowCount = 8,
}
HomeItemPrefabConfig["Default3_ShuBiao001"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["Default3_TanZi002"] = 
{
	FromType = 0,
	ColCount = 14,
	RowCount = 20,
}
HomeItemPrefabConfig["Default3_TanZi004"] = 
{
	FromType = 0,
	ColCount = 8,
	RowCount = 10,
}
HomeItemPrefabConfig["Default3_TanZi005"] = 
{
	FromType = 0,
	ColCount = 10,
	RowCount = 14,
}
HomeItemPrefabConfig["Default3_TanZi007"] = 
{
	FromType = 0,
	ColCount = 7,
	RowCount = 13,
}
HomeItemPrefabConfig["Default3_YinXiang001"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 7,
}
HomeItemPrefabConfig["Default3_YinXiang002"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 2,
}
HomeItemPrefabConfig["Default3_YinXiang003"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["Default3_YiZi001"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["Default3_YiZi002"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 6,
}
HomeItemPrefabConfig["Default3_YiZi003"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 6,
}
HomeItemPrefabConfig["Default3_YiZi004"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["Default3_YiZi005"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["Default3_YiZi006"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["Default3_YiZi007"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["Default3_Zhiwu006"] = 
{
	FromType = 0,
	ColCount = 7,
	RowCount = 15,
}
HomeItemPrefabConfig["Default3_ZhiWu008"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["Default3_ZhuangShi001"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["Default3_ZhuangShi012"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["Default3_ZhuangShi014"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["Default3_ZhuangShi017"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["Default3_ZhuangShi025"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["Default3_ZhuoZi001"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 10,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = 0.04, y = 1.04},
			Offsets = 
			{
				{ x = -0.12, y = 1, z = 0.1 },
				{ x = -0.12, y = 1, z = -0.1 },
				{ x = 0.12, y = 1, z = -0.1 },
				{ x = 0.12, y = 1, z = 0.1 },
			},
			ColCount = 3,
			RowCount = 9,
		},
	},
}
HomeItemPrefabConfig["Default3_ZhuoZi002"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 14,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = 0.1, y = 1.22},
			Offsets = 
			{
				{ x = -0.1, y = 1.2, z = 0.1 },
				{ x = -0.1, y = 1.2, z = -0.1 },
				{ x = 0.1, y = 1.2, z = -0.1 },
				{ x = 0.1, y = 1.2, z = 0.1 },
			},
			ColCount = 5,
			RowCount = 13,
		},
	},
}
HomeItemPrefabConfig["Default3_ZhuoZi003"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 20,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = -0.06, y = 1.76},
			Offsets = 
			{
				{ x = 0, y = 1.5, z = 0 },
			},
			ColCount = 6,
			RowCount = 20,
		},
	},
}
HomeItemPrefabConfig["Default3_ZhuoZi005"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 17,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = -0.02, y = 1.38},
			Offsets = 
			{
				{ x = -1, y = 0.4, z = 0.9 },
				{ x = -1, y = 0.4, z = -0.9 },
				{ x = 1, y = 0.4, z = -0.9 },
				{ x = 1, y = 0.4, z = 0.9 },
			},
			ColCount = 5,
			RowCount = 17,
		},
	},
}
HomeItemPrefabConfig["Default3_ZhuoZi006"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 13,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = 0, y = 1.31},
			Offsets = 
			{
				{ x = 0, y = 1.14, z = 0 },
			},
			ColCount = 5,
			RowCount = 13,
		},
	},
}
HomeItemPrefabConfig["Default3_ZhuoZi007"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 11,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = -0.09, y = 1.211},
			Offsets = 
			{
				{ x = 0, y = 1.14, z = 0 },
			},
			ColCount = 5,
			RowCount = 11,
		},
	},
}
HomeItemPrefabConfig["Default3_ZhuoZi008"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 17,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = -0.00999999, y = 1.49},
			Offsets = 
			{
				{ x = 0, y = 1.32, z = 0 },
			},
			ColCount = 5,
			RowCount = 16,
		},
	},
}
HomeItemPrefabConfig["Default3_ZhuoZi009"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 13,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = 0, y = 1.18},
			Offsets = 
			{
				{ x = 0, y = 1.2, z = 0 },
			},
			ColCount = 5,
			RowCount = 12,
		},
	},
}
HomeItemPrefabConfig["Default3_ZhuoZi010"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 16,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = 0.06, y = 1.43},
			Offsets = 
			{
				{ x = 0.5, y = 2, z = 1.4 },
				{ x = 0.5, y = 2, z = 2.1 },
				{ x = -0.5, y = 2, z = 2.3 },
				{ x = -0.5, y = 2, z = 1.4 },
			},
			ColCount = 6,
			RowCount = 10,
		},
	},
}
HomeItemPrefabConfig["Default3_ZhuoZi011"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 12,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = -0.28, y = 1.44},
			Offsets = 
			{
				{ x = 0.24, y = 1.8, z = 0 },
				{ x = 0.24, y = 1.8, z = 0 },
				{ x = -0.24, y = 1.8, z = 0 },
				{ x = -0.24, y = 1.8, z = 0 },
			},
			ColCount = 5,
			RowCount = 12,
		},
	},
}
HomeItemPrefabConfig["Default4_BingXiang001"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 6,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = 0.16, y = 3.24},
			Offsets = 
			{
				{ x = 0, y = 3.32, z = 0 },
			},
			ColCount = 6,
			RowCount = 6,
		},
	},
}
HomeItemPrefabConfig["Default4_DianNao001"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 6,
}
HomeItemPrefabConfig["Default4_DianQi001"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["Default4_DianShi001"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 8,
}
HomeItemPrefabConfig["Default4_DianZi001"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 5,
}
HomeItemPrefabConfig["Default4_DianZi002"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 6,
}
HomeItemPrefabConfig["Default4_DianZi003"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 6,
}
HomeItemPrefabConfig["Default4_DianZi004"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 6,
}
HomeItemPrefabConfig["Default4_GuiZi001"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 8,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = 0, y = 3.78},
			Offsets = 
			{
				{ x = 0, y = 3.58, z = 0 },
			},
			ColCount = 4,
			RowCount = 8,
		},
	},
}
HomeItemPrefabConfig["Default4_Guo001"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 4,
}
HomeItemPrefabConfig["Default4_HeiBan001"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 14,
}
HomeItemPrefabConfig["Default4_JianPan001"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 4,
}
HomeItemPrefabConfig["Default4_LanGan002"] = 
{
	FromType = 0,
	ColCount = 12,
	RowCount = 2,
}
HomeItemPrefabConfig["Default4_ShaFa001"] = 
{
	FromType = 0,
	ColCount = 8,
	RowCount = 8,
}
HomeItemPrefabConfig["Default4_ShaFa002"] = 
{
	FromType = 0,
	ColCount = 8,
	RowCount = 8,
}
HomeItemPrefabConfig["Default4_ShaFa003"] = 
{
	FromType = 0,
	ColCount = 8,
	RowCount = 8,
}
HomeItemPrefabConfig["Default4_ShuBiao001"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["Default4_TanZi002"] = 
{
	FromType = 0,
	ColCount = 16,
	RowCount = 20,
}
HomeItemPrefabConfig["Default4_TanZi007"] = 
{
	FromType = 0,
	ColCount = 8,
	RowCount = 14,
}
HomeItemPrefabConfig["Default4_YinXiang001"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 8,
}
HomeItemPrefabConfig["Default4_YinXiang003"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["Default4_YinXiang005"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["Default4_YiZi001"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["Default4_YiZi002"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 6,
}
HomeItemPrefabConfig["Default4_YiZi003"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 6,
}
HomeItemPrefabConfig["Default4_YiZi004"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["Default4_YiZi005"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["Default4_YiZi006"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["Default4_YiZi007"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["Default4_ZhiWu002"] = 
{
	FromType = 0,
	ColCount = 12,
	RowCount = 6,
}
HomeItemPrefabConfig["Default4_Zhiwu006"] = 
{
	FromType = 0,
	ColCount = 8,
	RowCount = 16,
}
HomeItemPrefabConfig["Default4_ZhiWu008"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["Default4_ZhuangShi001"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["Default4_ZhuangShi012"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["Default4_ZhuangShi014"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["Default4_ZhuangShi017"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["Default4_ZhuangShi025"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["Default4_ZhuoZi001"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 10,
	Planes = 
	{
		{
			NodeName = "rendre1",
			NodeOffset = {x = 0, y = 0},
			Offsets = 
			{
				{ x = 0, y = 2.16, z = 0 },
			},
			ColCount = 4,
			RowCount = 10,
		},
	},
}
HomeItemPrefabConfig["Default4_ZhuoZi002"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 13,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = -0.04, y = 1.18},
			Offsets = 
			{
				{ x = 0, y = 1.2, z = 0 },
			},
			ColCount = 5,
			RowCount = 13,
		},
	},
}
HomeItemPrefabConfig["Default4_ZhuoZi003"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 20,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = 0, y = 1.76},
			Offsets = 
			{
				{ x = 0, y = 1.3, z = 0 },
			},
			ColCount = 6,
			RowCount = 20,
		},
	},
}
HomeItemPrefabConfig["Default4_ZhuoZi005"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 17,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = -0.22, y = 1.46},
			Offsets = 
			{
				{ x = 0, y = 1.32, z = 0 },
			},
			ColCount = 6,
			RowCount = 17,
		},
	},
}
HomeItemPrefabConfig["Default4_ZhuoZi006"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 12,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = 0.28, y = 1.4},
			Offsets = 
			{
				{ x = 0, y = 1.2, z = 0 },
			},
			ColCount = 5,
			RowCount = 12,
		},
	},
}
HomeItemPrefabConfig["Default4_ZhuoZi007"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 11,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = -0.04, y = 1.28},
			Offsets = 
			{
				{ x = 0, y = 1.26, z = 0 },
			},
			ColCount = 5,
			RowCount = 11,
		},
	},
}
HomeItemPrefabConfig["Default4_ZhuoZi008"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 17,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = 0.16, y = 1.58},
			Offsets = 
			{
				{ x = 0, y = 1.32, z = 0 },
			},
			ColCount = 5,
			RowCount = 16,
		},
	},
}
HomeItemPrefabConfig["Default4_ZhuoZi009"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 13,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = -0.02999991, y = 1.24},
			Offsets = 
			{
				{ x = 0, y = 1.14, z = 0 },
			},
			ColCount = 5,
			RowCount = 12,
		},
	},
}
HomeItemPrefabConfig["Default4_ZhuoZi010"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 16,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = 0, y = 1.6},
			Offsets = 
			{
				{ x = 0, y = 1.48, z = 1.96 },
				{ x = 0, y = 1.48, z = 2.02 },
			},
			ColCount = 6,
			RowCount = 10,
		},
	},
}
HomeItemPrefabConfig["Default4_zhuozi011"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 12,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = -0.03, y = 1.56},
			Offsets = 
			{
				{ x = 0, y = 1.34, z = 0 },
			},
			ColCount = 6,
			RowCount = 12,
		},
	},
}
HomeItemPrefabConfig["Default4_ZhuoZi013"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 8,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = -0.16, y = 0.95},
			Offsets = 
			{
				{ x = 0, y = 0.66, z = 0 },
			},
			ColCount = 4,
			RowCount = 7,
		},
	},
}
HomeItemPrefabConfig["RPG_BiGua001"] = 
{
	FromType = 1,
	ColCount = 10,
	RowCount = 13,
}
HomeItemPrefabConfig["RPG_BiGua002"] = 
{
	FromType = 1,
	ColCount = 6,
	RowCount = 8,
}
HomeItemPrefabConfig["RPG_BiGua003"] = 
{
	FromType = 1,
	ColCount = 8,
	RowCount = 5,
}
HomeItemPrefabConfig["RPG_BiGua004"] = 
{
	FromType = 1,
	ColCount = 8,
	RowCount = 5,
}
HomeItemPrefabConfig["RPG_BiGua005"] = 
{
	FromType = 1,
	ColCount = 8,
	RowCount = 6,
}
HomeItemPrefabConfig["RPG_DianZi001"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 5,
}
HomeItemPrefabConfig["RPG_GuiZi001"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 11,
}
HomeItemPrefabConfig["RPG_GuiZi002"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 11,
}
HomeItemPrefabConfig["RPG_GuiZi003"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 17,
}
HomeItemPrefabConfig["RPG_GuiZi004"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 6,
}
HomeItemPrefabConfig["RPG_GuiZi005"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 10,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = -0.16, y = 1.15},
			Offsets = 
			{
				{ x = 0, y = 1.19, z = 0 },
			},
			ColCount = 3,
			RowCount = 10,
		},
	},
}
HomeItemPrefabConfig["RPG_GuiZi006"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 11,
}
HomeItemPrefabConfig["RPG_GuiZi007"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 12,
}
HomeItemPrefabConfig["RPG_GuiZi008"] = 
{
	FromType = 0,
	ColCount = 7,
	RowCount = 9,
}
HomeItemPrefabConfig["RPG_Tanzi001"] = 
{
	FromType = 0,
	ColCount = 24,
	RowCount = 32,
}
HomeItemPrefabConfig["RPG_TanZi002"] = 
{
	FromType = 0,
	ColCount = 21,
	RowCount = 32,
}
HomeItemPrefabConfig["RPG_TanZi004"] = 
{
	FromType = 0,
	ColCount = 22,
	RowCount = 24,
}
HomeItemPrefabConfig["RPG_TanZi005"] = 
{
	FromType = 0,
	ColCount = 30,
	RowCount = 38,
}
HomeItemPrefabConfig["RPG_YiZi001"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 9,
}
HomeItemPrefabConfig["RPG_YiZi002"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 14,
}
HomeItemPrefabConfig["RPG_YiZi003"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["RPG_YiZi004"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 5,
}
HomeItemPrefabConfig["RPG_YiZi005"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["RPG_YiZi006"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["RPG_YiZi007"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 6,
}
HomeItemPrefabConfig["RPG_YiZi008"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 7,
}
HomeItemPrefabConfig["RPG_YiZi009"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["RPG_YiZi010"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["RPG_ZhuangShi001"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 7,
}
HomeItemPrefabConfig["RPG_ZhuangShi002"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 6,
}
HomeItemPrefabConfig["RPG_ZhuangShi003"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 4,
}
HomeItemPrefabConfig["RPG_ZhuangShi004"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 5,
}
HomeItemPrefabConfig["RPG_ZhuangShi006"] = 
{
	FromType = 0,
	ColCount = 8,
	RowCount = 13,
}
HomeItemPrefabConfig["RPG_ZhuangShi007"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["RPG_ZhuangShi008"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["RPG_ZhuangShi009"] = 
{
	FromType = 0,
	ColCount = 7,
	RowCount = 10,
}
HomeItemPrefabConfig["RPG_ZhuangShi010"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 5,
}
HomeItemPrefabConfig["RPG_ZhuangShi011"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["RPG_ZhuangShi012"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 15,
}
HomeItemPrefabConfig["RPG_ZhuangShi013"] = 
{
	FromType = 0,
	ColCount = 1,
	RowCount = 14,
}
HomeItemPrefabConfig["RPG_ZhuangShi014"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["RPG_ZhuangShi015"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["RPG_ZhuangShi016"] = 
{
	FromType = 0,
	ColCount = 10,
	RowCount = 8,
}
HomeItemPrefabConfig["RPG_ZhuangShi017"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 5,
}
HomeItemPrefabConfig["RPG_ZhuangShi018"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["RPG_ZhuangShi019"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["RPG_ZhuangShi020"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 7,
}
HomeItemPrefabConfig["RPG_ZhuangShi021"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["RPG_ZhuangShi022"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["RPG_ZhuangShi023"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 10,
}
HomeItemPrefabConfig["RPG_ZhuangShi024"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["RPG_ZhuangShi025"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 5,
}
HomeItemPrefabConfig["RPG_ZhuangShi026"] = 
{
	FromType = 0,
	ColCount = 14,
	RowCount = 1,
}
HomeItemPrefabConfig["RPG_ZhuangShi027"] = 
{
	FromType = 0,
	ColCount = 14,
	RowCount = 1,
}
HomeItemPrefabConfig["RPG_ZhuangShi028"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["RPG_ZhuangShi030"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 3,
}
HomeItemPrefabConfig["RPG_ZhuangShi031"] = 
{
	FromType = 0,
	ColCount = 1,
	RowCount = 1,
}
HomeItemPrefabConfig["RPG_ZhuangShi032"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 6,
}
HomeItemPrefabConfig["RPG_ZhuangShi033"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["RPG_ZhuangShi034"] = 
{
	FromType = 0,
	ColCount = 8,
	RowCount = 7,
}
HomeItemPrefabConfig["RPG_ZhuangShi035"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 5,
}
HomeItemPrefabConfig["RPG_ZhuangShi036"] = 
{
	FromType = 0,
	ColCount = 11,
	RowCount = 10,
}
HomeItemPrefabConfig["RPG_ZhuangShi038"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["RPG_ZhuangShi039"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 5,
}
HomeItemPrefabConfig["RPG_ZhuangShi040"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["RPG_ZhuangShi041"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["RPG_ZhuangShi042"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["RPG_ZhuangShi043"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["RPG_ZhuangShi044"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["RPG_ZhuangShi045"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["RPG_ZhuangShi046"] = 
{
	FromType = 0,
	ColCount = 7,
	RowCount = 9,
}
HomeItemPrefabConfig["RPG_ZhuangShi047"] = 
{
	FromType = 0,
	ColCount = 5,
	RowCount = 5,
}
HomeItemPrefabConfig["RPG_ZhuangShi048"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 6,
}
HomeItemPrefabConfig["RPG_ZhuangShi049"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["RPG_ZhuangShi050"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["RPG_ZhuangShi051"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["RPG_ZhuangShi052"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["RPG_ZhuangShi053"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["RPG_ZhuangShi055"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 7,
}
HomeItemPrefabConfig["RPG_ZhuangShi056"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["RPG_ZhuangShi057"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["RPG_ZhuangShi058"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["RPG_ZhuangShi059"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 3,
}
HomeItemPrefabConfig["RPG_ZhuangShi060"] = 
{
	FromType = 0,
	ColCount = 2,
	RowCount = 2,
}
HomeItemPrefabConfig["RPG_ZhuangShi061"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 5,
}
HomeItemPrefabConfig["RPG_ZhuangShi062"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["RPG_ZhuangShi063"] = 
{
	FromType = 0,
	ColCount = 3,
	RowCount = 3,
}
HomeItemPrefabConfig["RPG_ZhuangShi064"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 5,
}
HomeItemPrefabConfig["RPG_ZhuangShi065"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["RPG_ZhuangShi066"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["RPG_ZhuangShi067"] = 
{
	FromType = 0,
	ColCount = 4,
	RowCount = 4,
}
HomeItemPrefabConfig["RPG_ZhuoZi001"] = 
{
	FromType = 0,
	ColCount = 8,
	RowCount = 12,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = 0.27, y = 1.35},
			Offsets = 
			{
				{ x = 0, y = 1.2, z = 0 },
			},
			ColCount = 8,
			RowCount = 12,
		},
	},
}
HomeItemPrefabConfig["RPG_ZhuoZi002"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 17,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = -0.05000001, y = 1.75},
			Offsets = 
			{
				{ x = 0, y = 1.64, z = 0 },
			},
			ColCount = 6,
			RowCount = 17,
		},
	},
}
HomeItemPrefabConfig["RPG_ZhuoZi003"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 18,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = -0.14, y = 1.62},
			Offsets = 
			{
				{ x = 0, y = 1.64, z = 0 },
			},
			ColCount = 6,
			RowCount = 17,
		},
	},
}
HomeItemPrefabConfig["RPG_ZhuoZi004"] = 
{
	FromType = 0,
	ColCount = 6,
	RowCount = 9,
	Planes = 
	{
		{
			NodeName = "render1",
			NodeOffset = {x = -0.76, y = 2.2},
			Offsets = 
			{
				{ x = 0, y = -2.39, z = 1.23 },
				{ x = 1.02, y = -1.02, z = -0.09 },
				{ x = 0, y = 1.5, z = 0 },
				{ x = 0, y = 1.38, z = 0 },
			},
			ColCount = 3,
			RowCount = 8,
		},
	},
}
