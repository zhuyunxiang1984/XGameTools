
SkillConfig[SkillID.Id2001] =
{
	Id = 2001,
	Name = "探索金币+",
	Desc = "探索金币数量 +{Value}%",
	Dialog = "o(￣▽￣)ｄ",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2002] =
{
	Id = 2002,
	Name = "探索金币+",
	Desc = "探索金币数量 +{Value}%",
	Dialog = "o(￣▽￣)ｄ",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2003] =
{
	Id = 2003,
	Name = "探索金币+",
	Desc = "探索金币数量 +{Value}%",
	Dialog = "o(￣▽￣)ｄ",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2004] =
{
	Id = 2004,
	Name = "探索金币+",
	Desc = "探索金币数量 +{Value}%",
	Dialog = "o(￣▽￣)ｄ",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2005] =
{
	Id = 2005,
	Name = "全队生命+",
	Desc = "全队生命 +{Value}%",
	Dialog = "↖(^ω^)↗",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2006] =
{
	Id = 2006,
	Name = "风元素队员生命+",
	Desc = "风元素队员生命 +{Value}%",
	Dialog = "(＾－＾)V",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210003,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2007] =
{
	Id = 2007,
	Name = "探索获得木材",
	Desc = "探索中获得木材，每小时{ValueDivide}个",
	Dialog = "┗|｀O′|┛ 嗷~~",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2008] =
{
	Id = 2008,
	Name = "风元素队员攻击+",
	Desc = "风元素队员攻击 +{Value}%",
	Dialog = "(￣_,￣ )",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210003,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2009] =
{
	Id = 2009,
	Name = "水元素队员攻击+",
	Desc = "水元素队员攻击 +{Value}%",
	Dialog = "(U・x・U)嗷！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210001,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2010] =
{
	Id = 2010,
	Name = "暗元素打击",
	Desc = "对暗元素敌人伤害 +{Value}%",
	Dialog = "(U・x・U)嗷！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2011] =
{
	Id = 2011,
	Name = "躲避强敌",
	Desc = "打不过的怪物出现概率 -{Value}%",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Chance = 100,
		CompareFightPower = 1,
		EnemyWeightCondition = {
			CompareWin = 2,
		},
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2012] =
{
	Id = 2012,
	Name = "探索获得矿石",
	Desc = "探索中获得矿石，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2013] =
{
	Id = 2013,
	Name = "全队恢复",
	Desc = "每回合全队回血 {Value}%，最多5次",
	Dialog = "┗|｀O′|┛ 嗷~~",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2014] =
{
	Id = 2014,
	Name = "探索获得地图",
	Desc = "探索中获得地图，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321005,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2015] =
{
	Id = 2015,
	Name = "暗元素队员战力+",
	Desc = "探索中，暗元素队员战力 +{Value}%",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210005,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2016] =
{
	Id = 2016,
	Name = "道具掉落率+",
	Desc = "道具掉落率 +{Value}%",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropChance",
		Tag = 
		{
			564305,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2017] =
{
	Id = 2017,
	Name = "探索获得粘液",
	Desc = "探索中获得粘液，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321006,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2018] =
{
	Id = 2018,
	Name = "压制敌人战力",
	Desc = "敌人战力 -{Value}%",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyFightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2019] =
{
	Id = 2019,
	Name = "探索获得钢刺",
	Desc = "探索中获得钢刺，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321007,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2020] =
{
	Id = 2020,
	Name = "全队忍耐+",
	Desc = "全队忍耐 +{Value}",
	Dialog = "X﹏X",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2021] =
{
	Id = 2021,
	Name = "探索获得沙堆",
	Desc = "探索中获得沙堆，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321008,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2022] =
{
	Id = 2022,
	Name = "光元素队员攻击+",
	Desc = "光元素队员攻击 +{Value}%",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210004,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2023] =
{
	Id = 2023,
	Name = "火元素队员攻击+",
	Desc = "火元素队员攻击 +{Value}%",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210002,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2024] =
{
	Id = 2024,
	Name = "探索获得炭石",
	Desc = "探索中获得炭石，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321009,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2025] =
{
	Id = 2025,
	Name = "道具掉落率+",
	Desc = "道具掉落率 +{Value}%",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropChance",
		Tag = 
		{
			564305,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2026] =
{
	Id = 2026,
	Name = "探索获得火焰结晶",
	Desc = "探索中获得火焰结晶，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321010,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2027] =
{
	Id = 2027,
	Name = "暴率+",
	Desc = "暴率 +{Value}%",
	Dialog = "w(ﾟДﾟ)w",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CritChance",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2028] =
{
	Id = 2028,
	Name = "暴击伤害+",
	Desc = "暴击伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CritDamage",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2029] =
{
	Id = 2029,
	Name = "水元素敌人战力+",
	Desc = "水元素敌人战力 -{Value}%",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyFightPower",
		Element = 210001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2030] =
{
	Id = 2030,
	Name = "全队攻击+",
	Desc = "全队攻击 +{Value}%",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2031] =
{
	Id = 2031,
	Name = "发现菜鸡",
	Desc = "打得过的敌人出现概率 +{Value}%",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Chance = 100,
		CompareFightPower = 2,
		EnemyWeightCondition = {
			CompareWin = 1,
		},
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2032] =
{
	Id = 2032,
	Name = "全队生命+",
	Desc = "全队生命 +{Value}%",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2033] =
{
	Id = 2033,
	Name = "火元素队员暴击+",
	Desc = "火元素队员暴击 +{Value}",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210002,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2034] =
{
	Id = 2034,
	Name = "探索获得豆沙",
	Desc = "探索中获得豆沙，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321201,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2035] =
{
	Id = 2035,
	Name = "水元素队员战力+",
	Desc = "探索中，水元素队员战力 +{Value}%",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210001,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2036] =
{
	Id = 2036,
	Name = "暗元素队员战力+",
	Desc = "探索中，暗元素队员战力 +{Value}%",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210005,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2037] =
{
	Id = 2037,
	Name = "光元素队员战力+",
	Desc = "探索中，光元素队员战力 +{Value}%",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210004,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2038] =
{
	Id = 2038,
	Name = "全队大恢复",
	Desc = "每3回合全队回血 {Value}%，最多5次",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2039] =
{
	Id = 2039,
	Name = "探索获得牛奶",
	Desc = "探索中获得牛奶，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321203,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2040] =
{
	Id = 2040,
	Name = "全队恢复",
	Desc = "每回合全队回血 {Value}%，最多5次",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2041] =
{
	Id = 2041,
	Name = "探索获得高标蛋",
	Desc = "探索中获得高标蛋，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321204,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2042] =
{
	Id = 2042,
	Name = "道具掉落率+",
	Desc = "道具掉落率 +{Value}%",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropChance",
		Tag = 
		{
			564305,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2043] =
{
	Id = 2043,
	Name = "探索获得鱼肉",
	Desc = "探索中获得鱼肉，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321205,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2044] =
{
	Id = 2044,
	Name = "道具掉落率+",
	Desc = "道具掉落率 +{Value}%",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropChance",
		Tag = 
		{
			564305,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2045] =
{
	Id = 2045,
	Name = "光元素队员忍耐+",
	Desc = "光元素队员忍耐 +{Value}",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210004,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2046] =
{
	Id = 2046,
	Name = "探索获得米饭",
	Desc = "探索中获得米饭，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321206,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2047] =
{
	Id = 2047,
	Name = "光元素敌人战力+",
	Desc = "光元素敌人战力 -{Value}%",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyFightPower",
		Element = 210004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2048] =
{
	Id = 2048,
	Name = "探索获得料酒",
	Desc = "探索中获得料酒，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321207,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2049] =
{
	Id = 2049,
	Name = "火的招来",
	Desc = "火元素敌人出现概率 +{Value}%",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Element = 210002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2050] =
{
	Id = 2050,
	Name = "暗元素敌人战力+",
	Desc = "暗元素敌人战力 -{Value}%",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyFightPower",
		Element = 210005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2051] =
{
	Id = 2051,
	Name = "暗的招来",
	Desc = "暗元素敌人出现概率 +{Value}%",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Element = 210005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2052] =
{
	Id = 2052,
	Name = "探索获得海苔",
	Desc = "探索中获得海苔，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321208,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2053] =
{
	Id = 2053,
	Name = "探索获得五花肉",
	Desc = "探索中获得五花肉，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321209,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2054] =
{
	Id = 2054,
	Name = "全队生命+",
	Desc = "全队生命 +{Value}%",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2055] =
{
	Id = 2055,
	Name = "探索获得芝士",
	Desc = "探索中获得芝士，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321210,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2056] =
{
	Id = 2056,
	Name = "全队恢复",
	Desc = "每回合全队回血 {Value}%，最多5次",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2057] =
{
	Id = 2057,
	Name = "水元素队员忍耐+",
	Desc = "水元素队员忍耐 +{Value}",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210001,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2058] =
{
	Id = 2058,
	Name = "水元素队员暴击+",
	Desc = "水元素队员暴击 +{Value}",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210001,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2059] =
{
	Id = 2059,
	Name = "探索获得入场券",
	Desc = "探索中获得入场券，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321401,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2060] =
{
	Id = 2060,
	Name = "躲避强敌",
	Desc = "打不过的怪物出现概率 -{Value}%",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Chance = 100,
		CompareFightPower = 1,
		EnemyWeightCondition = {
			CompareWin = 2,
		},
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2061] =
{
	Id = 2061,
	Name = "探索获得考古刷",
	Desc = "探索中获得考古刷，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321402,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2062] =
{
	Id = 2062,
	Name = "压制敌人战力",
	Desc = "敌人战力 -{Value}%",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyFightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2063] =
{
	Id = 2063,
	Name = "水元素敌人捕捉率+",
	Desc = "水元素敌人捕捉成功率 +{Value}%",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Element = 210001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2064] =
{
	Id = 2064,
	Name = "探索获得焚香",
	Desc = "探索中获得焚香，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321403,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2065] =
{
	Id = 2065,
	Name = "探索金币+",
	Desc = "探索金币数量 +{Value}%",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2066] =
{
	Id = 2066,
	Name = "水的招来",
	Desc = "水元素敌人出现概率 +{Value}%",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Element = 210001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2067] =
{
	Id = 2067,
	Name = "全队攻击+",
	Desc = "全队攻击 +{Value}%",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2068] =
{
	Id = 2068,
	Name = "探索获得碎瓷片",
	Desc = "探索中获得碎瓷片，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321404,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2069] =
{
	Id = 2069,
	Name = "光的招来",
	Desc = "光元素敌人出现概率 +{Value}%",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Element = 210004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2070] =
{
	Id = 2070,
	Name = "探索获得绿蛋壳",
	Desc = "探索中获得绿蛋壳，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321405,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2071] =
{
	Id = 2071,
	Name = "探索时间-",
	Desc = "探索等待时间 -{Value}%",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.ExploreTime,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreTime",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2072] =
{
	Id = 2072,
	Name = "暗元素队员生命+",
	Desc = "暗元素队员生命 +{Value}%",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210005,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2073] =
{
	Id = 2073,
	Name = "探索获得监控录像",
	Desc = "探索中获得监控录像，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321406,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2074] =
{
	Id = 2074,
	Name = "头目招来",
	Desc = "紫色及以上品质敌人出现概率 +{Value}%",
	Dialog = "(—`´—)",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Rarity = 3,
		RarityOp = 0,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2075] =
{
	Id = 2075,
	Name = "全队忍耐+",
	Desc = "全队忍耐 +{Value}",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2076] =
{
	Id = 2076,
	Name = "道具掉落率+",
	Desc = "道具掉落率 +{Value}%",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropChance",
		Tag = 
		{
			564305,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2077] =
{
	Id = 2077,
	Name = "火元素敌人战力+",
	Desc = "火元素敌人战力 -{Value}%",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyFightPower",
		Element = 210002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2078] =
{
	Id = 2078,
	Name = "水元素队员忍耐+",
	Desc = "水元素队员忍耐 +{Value}",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210001,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2079] =
{
	Id = 2079,
	Name = "探索获得青面具",
	Desc = "探索中获得青面具，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321409,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2080] =
{
	Id = 2080,
	Name = "火元素敌人捕捉率+",
	Desc = "火元素敌人捕捉成功率 +{Value}%",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Element = 210002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2081] =
{
	Id = 2081,
	Name = "探索获得龙角",
	Desc = "探索中获得龙角，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321410,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2082] =
{
	Id = 2082,
	Name = "风元素打击",
	Desc = "对风元素敌人伤害 +{Value}%",
	Dialog = "w(ﾟДﾟ)w",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210003,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2083] =
{
	Id = 2083,
	Name = "探索获得箭头",
	Desc = "探索中获得箭头，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321411,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2084] =
{
	Id = 2084,
	Name = "首位闪避术",
	Desc = "第一个队员{Value}%概率闪避攻击",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.FixPosition,
		PositionValue = 
		{
			1,
		},
	},
	Effect = {
		EffectAttribute = "Dodge",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2085] =
{
	Id = 2085,
	Name = "道具掉落率+",
	Desc = "道具掉落率 +{Value}%",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropChance",
		Tag = 
		{
			564305,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2086] =
{
	Id = 2086,
	Name = "末位必中术",
	Desc = "最后一个队员{Value}%概率无视敌人闪避",
	Dialog = "o( =•ω•= )m",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.FixPosition,
		PositionValue = 
		{
			-1,
		},
	},
	Effect = {
		EffectAttribute = "DodgeIgnore",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2087] =
{
	Id = 2087,
	Name = "末位连击1次",
	Desc = "最后一个队员{Value}%概率连击1次",
	Dialog = "≡ω≡",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.FixPosition,
		PositionValue = 
		{
			-1,
		},
	},
	Effect = {
		EffectAttribute = "ExtraAttack",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2088] =
{
	Id = 2088,
	Name = "探索获得暗恋",
	Desc = "探索中获得暗恋，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321601,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2089] =
{
	Id = 2089,
	Name = "风元素敌人战力+",
	Desc = "风元素敌人战力 -{Value}%",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyFightPower",
		Element = 210003,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2090] =
{
	Id = 2090,
	Name = "火元素队员战力+",
	Desc = "探索中，火元素队员战力 +{Value}%",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210002,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2091] =
{
	Id = 2091,
	Name = "探索获得新闻",
	Desc = "探索中获得新闻，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321602,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2092] =
{
	Id = 2092,
	Name = "暗元素队员暴击+",
	Desc = "暗元素队员暴击 +{Value}",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210005,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2093] =
{
	Id = 2093,
	Name = "光元素队员暴击+",
	Desc = "光元素队员暴击 +{Value}",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210004,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2094] =
{
	Id = 2094,
	Name = "探索获得羽毛",
	Desc = "探索中获得羽毛，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321603,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2095] =
{
	Id = 2095,
	Name = "全队暴击+",
	Desc = "全队暴击 +{Value}",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2096] =
{
	Id = 2096,
	Name = "探索获得钥匙",
	Desc = "探索中获得钥匙，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321604,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2097] =
{
	Id = 2097,
	Name = "光元素敌人捕捉率+",
	Desc = "光元素敌人捕捉成功率 +{Value}%",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Element = 210004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2098] =
{
	Id = 2098,
	Name = "道具掉落率+",
	Desc = "道具掉落率 +{Value}%",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropChance",
		Tag = 
		{
			564305,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2099] =
{
	Id = 2099,
	Name = "探索获得脚印",
	Desc = "探索中获得脚印，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321605,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2100] =
{
	Id = 2100,
	Name = "全队忍耐+",
	Desc = "全队忍耐 +{Value}",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2101] =
{
	Id = 2101,
	Name = "火元素打击",
	Desc = "对火元素敌人伤害 +{Value}%",
	Dialog = "┗|｀O′|┛ 嗷~~",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2102] =
{
	Id = 2102,
	Name = "探索获得烟头",
	Desc = "探索中获得烟头，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321606,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2103] =
{
	Id = 2103,
	Name = "暗元素敌人捕捉率+",
	Desc = "暗元素敌人捕捉成功率 +{Value}%",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Element = 210005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2104] =
{
	Id = 2104,
	Name = "火元素队员生命+",
	Desc = "火元素队员生命 +{Value}%",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210002,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2105] =
{
	Id = 2105,
	Name = "全队暴击+",
	Desc = "全队暴击 +{Value}",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2106] =
{
	Id = 2106,
	Name = "头目招来",
	Desc = "紫色及以上品质敌人出现概率 +{Value}%",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Rarity = 3,
		RarityOp = 0,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2107] =
{
	Id = 2107,
	Name = "探索获得指纹",
	Desc = "探索中获得指纹，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321607,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2108] =
{
	Id = 2108,
	Name = "光元素打击",
	Desc = "对光元素敌人伤害 +{Value}%",
	Dialog = "凸(艹皿艹 )",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2109] =
{
	Id = 2109,
	Name = "探索获得墨水",
	Desc = "探索中获得墨水，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321608,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2110] =
{
	Id = 2110,
	Name = "暗元素队员攻击+",
	Desc = "暗元素队员攻击 +{Value}%",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210005,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2111] =
{
	Id = 2111,
	Name = "探索获得皮鞭",
	Desc = "探索中获得皮鞭，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321609,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2112] =
{
	Id = 2112,
	Name = "探索时间-",
	Desc = "探索等待时间 -{Value}%",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.ExploreTime,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreTime",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2113] =
{
	Id = 2113,
	Name = "探索获得黄瓜马赛克",
	Desc = "探索中获得黄瓜马赛克，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321610,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2114] =
{
	Id = 2114,
	Name = "风元素敌人捕捉率+",
	Desc = "风元素敌人捕捉成功率 +{Value}%",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Element = 210003,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2115] =
{
	Id = 2115,
	Name = "探索获得灵感",
	Desc = "探索中获得灵感，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321611,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2116] =
{
	Id = 2116,
	Name = "探索时间-",
	Desc = "探索等待时间 -{Value}%",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.ExploreTime,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreTime",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2117] =
{
	Id = 2117,
	Name = "光元素队员生命+",
	Desc = "光元素队员生命 +{Value}%",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210004,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2118] =
{
	Id = 2118,
	Name = "探索获得营养液",
	Desc = "探索中获得营养液，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321612,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2119] =
{
	Id = 2119,
	Name = "全队大恢复",
	Desc = "每3回合全队回血 {Value}%，最多5次",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2120] =
{
	Id = 2120,
	Name = "暗元素队员攻击+",
	Desc = "暗元素队员攻击 +{Value}%",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210005,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2121] =
{
	Id = 2121,
	Name = "全队恢复",
	Desc = "每回合全队回血 {Value}%，最多5次",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2122] =
{
	Id = 2122,
	Name = "火元素队员攻击+",
	Desc = "火元素队员攻击 +{Value}%",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210002,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2123] =
{
	Id = 2123,
	Name = "光元素队员攻击+",
	Desc = "光元素队员攻击 +{Value}%",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210004,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2124] =
{
	Id = 2124,
	Name = "暗元素队员攻击+",
	Desc = "暗元素队员攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210005,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2125] =
{
	Id = 2125,
	Name = "水元素队员暴击+",
	Desc = "水元素队员暴击 +{Value}",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210001,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2126] =
{
	Id = 2126,
	Name = "火元素队员暴击+",
	Desc = "火元素队员暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210002,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2127] =
{
	Id = 2127,
	Name = "躲避强敌",
	Desc = "打不过的怪物出现概率 -{Value}%",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Chance = 100,
		CompareFightPower = 1,
		EnemyWeightCondition = {
			CompareWin = 2,
		},
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2128] =
{
	Id = 2128,
	Name = "火元素敌人战力+",
	Desc = "火元素敌人战力 -{Value}%",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyFightPower",
		Element = 210002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2129] =
{
	Id = 2129,
	Name = "水元素敌人战力+",
	Desc = "水元素敌人战力 -{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyFightPower",
		Element = 210001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2130] =
{
	Id = 2130,
	Name = "火元素队员战力+",
	Desc = "探索中，火元素队员战力 +{Value}%",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210002,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2131] =
{
	Id = 2131,
	Name = "光元素队员战力+",
	Desc = "探索中，光元素队员战力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210004,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2132] =
{
	Id = 2132,
	Name = "光元素敌人捕捉率+",
	Desc = "光元素敌人捕捉成功率 +{Value}%",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Element = 210004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2133] =
{
	Id = 2133,
	Name = "探索金币+",
	Desc = "探索金币数量 +{Value}%",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2134] =
{
	Id = 2134,
	Name = "道具掉落率+",
	Desc = "道具掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropChance",
		Tag = 
		{
			564305,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2135] =
{
	Id = 2135,
	Name = "光元素敌人捕捉率+",
	Desc = "光元素敌人捕捉成功率 +{Value}%",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Element = 210004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2136] =
{
	Id = 2136,
	Name = "道具掉落率+",
	Desc = "道具掉落率 +{Value}%",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropChance",
		Tag = 
		{
			564305,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2137] =
{
	Id = 2137,
	Name = "全队战力+",
	Desc = "探索中，全队战力 +{Value}%",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2138] =
{
	Id = 2138,
	Name = "探索金币+",
	Desc = "探索金币数量 +{Value}%",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2139] =
{
	Id = 2139,
	Name = "探索获得珊瑚",
	Desc = "探索中获得珊瑚，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321802,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2140] =
{
	Id = 2140,
	Name = "水元素队员生命+",
	Desc = "水元素队员生命 +{Value}",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210001,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2141] =
{
	Id = 2141,
	Name = "探索获得黑珍珠",
	Desc = "探索中获得黑珍珠，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321803,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2142] =
{
	Id = 2142,
	Name = "暗元素敌人捕捉率+",
	Desc = "暗元素敌人捕捉成功率 +{Value}%",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Element = 210005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2143] =
{
	Id = 2143,
	Name = "探索获得怪物触手",
	Desc = "探索中获得怪物触手，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321804,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2144] =
{
	Id = 2144,
	Name = "连击2次",
	Desc = "有{Value}%概率额外攻击2次",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExtraAttack",
		EffectValue = 2,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2145] =
{
	Id = 2145,
	Name = "探索获得海草",
	Desc = "探索中获得海草，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321801,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2146] =
{
	Id = 2146,
	Name = "探索获得应援毛巾",
	Desc = "探索中获得应援毛巾，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321805,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2147] =
{
	Id = 2147,
	Name = "风元素打击",
	Desc = "对风元素敌人伤害 +{Value}%",
	Dialog = "凸(艹皿艹 )",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210003,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2148] =
{
	Id = 2148,
	Name = "探索获得礁石",
	Desc = "探索中获得礁石，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321806,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2149] =
{
	Id = 2149,
	Name = "全队忍耐+",
	Desc = "全队忍耐 +{Value}",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2150] =
{
	Id = 2150,
	Name = "探索时间-",
	Desc = "探索等待时间 -{Value}%",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.ExploreTime,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreTime",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2151] =
{
	Id = 2151,
	Name = "探索获得鱼鳞",
	Desc = "探索中获得鱼鳞，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321807,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2152] =
{
	Id = 2152,
	Name = "探索时间-",
	Desc = "探索等待时间 -{Value}%",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.ExploreTime,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreTime",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2153] =
{
	Id = 2153,
	Name = "探索金币+",
	Desc = "探索金币数量 +{Value}%",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2154] =
{
	Id = 2154,
	Name = "探索获得防水相机",
	Desc = "探索中获得防水相机，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321808,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2155] =
{
	Id = 2155,
	Name = "道具掉落率+",
	Desc = "道具掉落率 +{Value}%",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropChance",
		Tag = 
		{
			564305,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2156] =
{
	Id = 2156,
	Name = "探索获得摇滚耳机",
	Desc = "探索中获得摇滚耳机，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321809,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2157] =
{
	Id = 2157,
	Name = "探索时间-",
	Desc = "探索等待时间 -{Value}%",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.ExploreTime,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreTime",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2158] =
{
	Id = 2158,
	Name = "探索获得队员服",
	Desc = "探索中获得队员服，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321810,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2159] =
{
	Id = 2159,
	Name = "全队生命+",
	Desc = "全队生命 +{Value}",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2160] =
{
	Id = 2160,
	Name = "探索金币+",
	Desc = "探索金币数量 +{Value}%",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2161] =
{
	Id = 2161,
	Name = "探索获得强力海绵",
	Desc = "探索中获得强力海绵，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321811,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2162] =
{
	Id = 2162,
	Name = "火元素队员攻击+",
	Desc = "火元素队员攻击 +{Value}",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210002,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2163] =
{
	Id = 2163,
	Name = "探索获得应援棒",
	Desc = "探索中获得应援棒，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321812,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2164] =
{
	Id = 2164,
	Name = "躲避强敌",
	Desc = "打不过的怪物出现概率 -{Value}%",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Chance = 100,
		CompareFightPower = 1,
		EnemyWeightCondition = {
			CompareWin = 2,
		},
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2165] =
{
	Id = 2165,
	Name = "探索获得尖叫",
	Desc = "探索中获得尖叫，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321813,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2166] =
{
	Id = 2166,
	Name = "概率无视敌人闪避",
	Desc = "{Value}%概率无视敌人的闪避",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DodgeIgnore",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2167] =
{
	Id = 2167,
	Name = "无视敌人忍耐攻击%",
	Desc = "1回合后攻击时无视敌人{Value}%忍耐",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DefendIgnoreOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2168] =
{
	Id = 2168,
	Name = "探索金币+",
	Desc = "探索金币数量 +{Value}%",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2169] =
{
	Id = 2169,
	Name = "探索获得深海泡沫",
	Desc = "探索中获得深海泡沫，每小时{ValueDivide}个",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 321814,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2170] =
{
	Id = 2170,
	Name = "4回合后，每回合全队恢复",
	Desc = "4回合后，每回合全队回血 {Value}%，最多5次",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 4,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2171] =
{
	Id = 2171,
	Name = "道具掉落率+",
	Desc = "道具掉落率 +{Value}%",
	Dialog = "(๑•̀ㅂ•́)و✧",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropChance",
		Tag = 
		{
			564305,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2172] =
{
	Id = 2172,
	Name = "每回合暗元素队员攻击+",
	Desc = "每回合暗元素队员攻击 +{Value}%，最多5次",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210005,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2173] =
{
	Id = 2173,
	Name = "第3回合前3队员单次闪避",
	Desc = "第3回合，前3队员{Value}%闪避",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 1,
		Limited = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.FixPosition,
		PositionValue = 
		{
			1,2,3,
		},
	},
	Effect = {
		EffectAttribute = "DodgeOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2174] =
{
	Id = 2174,
	Name = "全队生命+",
	Desc = "全队生命 +{Value}",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2175] =
{
	Id = 2175,
	Name = "压制敌人攻击",
	Desc = "敌人攻击 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2176] =
{
	Id = 2176,
	Name = "探索金币+",
	Desc = "探索金币数量 +{Value}%",
	Dialog = "o(￣▽￣)ｄ",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2177] =
{
	Id = 2177,
	Name = "探索金币+",
	Desc = "探索金币数量 +{Value}%",
	Dialog = "o(￣▽￣)ｄ",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2178] =
{
	Id = 2178,
	Name = "火元素打击",
	Desc = "对火元素敌人伤害 +{Value}%",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2179] =
{
	Id = 2179,
	Name = "全队攻击+",
	Desc = "全队攻击 +{Value}%",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2180] =
{
	Id = 2180,
	Name = "每回合全队攻击+",
	Desc = "每回合全队攻击 +{Value}%，最多3次",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2181] =
{
	Id = 2181,
	Name = "每3回合全队单次受到暴击伤害+",
	Desc = "全队受到暴击伤害 -{Value}%",
	Dialog = "o(￣▽￣)ｄ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "DamageFromCritDamage",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2182] =
{
	Id = 2182,
	Name = "3回合后全队恢复",
	Desc = "3回合后，每回合全队回血 {Value}%，最多5次",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2183] =
{
	Id = 2183,
	Name = "探索金币+",
	Desc = "探索金币数量 +{Value}%",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2184] =
{
	Id = 2184,
	Name = "风元素队员暴击+",
	Desc = "风元素队员暴击 +{Value}",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210003,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2185] =
{
	Id = 2185,
	Name = "光元素队员忍耐+",
	Desc = "光元素队员忍耐 +{Value}",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210004,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2186] =
{
	Id = 2186,
	Name = "暗元素队员忍耐+",
	Desc = "暗元素队员忍耐 +{Value}",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210005,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2187] =
{
	Id = 2187,
	Name = "水元素队员攻击+",
	Desc = "水元素队员攻击 +{Value}%",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210001,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2188] =
{
	Id = 2188,
	Name = "全队生命+",
	Desc = "全队生命 +{Value}%",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2189] =
{
	Id = 2189,
	Name = "每回合，风元素队员攻击+",
	Desc = "每回合，风元素队员攻击 +{Value}%",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210003,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2190] =
{
	Id = 2190,
	Name = "每回合，光元素队员恢复",
	Desc = "每回合，光元素队员回血{Value}%",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 2,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210004,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2191] =
{
	Id = 2191,
	Name = "每回合，暗元素队员恢复",
	Desc = "每回合，暗元素队员回血{Value}",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 2,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210005,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2192] =
{
	Id = 2192,
	Name = "压制敌人等级",
	Desc = "敌人等级 -{Value}",
	Dialog = "酒壮怂人胆！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyLevel",
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2193] =
{
	Id = 2193,
	Name = "全队必中+",
	Desc = "全队{Value}%概率无视敌人闪避",
	Dialog = "o(￣▽￣)ｄ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "DodgeIgnore",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2194] =
{
	Id = 2194,
	Name = "探索金币+",
	Desc = "探索金币数量 +{Value}%",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2195] =
{
	Id = 2195,
	Name = "风元素队员忍耐+",
	Desc = "风元素队员忍耐 +{Value}",
	Dialog = "o(￣▽￣)ｄ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210003,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2196] =
{
	Id = 2196,
	Name = "回合2，全队恢复",
	Desc = "每2回合，全队回血{Value}",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 2,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2197] =
{
	Id = 2197,
	Name = "敌人忍耐-",
	Desc = "敌人忍耐 -{Value}",
	Dialog = "嗯，针不错！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2198] =
{
	Id = 2198,
	Name = "全队暴击+",
	Desc = "全队暴击 +{Value}",
	Dialog = "o(￣▽￣)ｄ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2199] =
{
	Id = 2199,
	Name = "每个暗元素队员使攻击+",
	Desc = "每个暗元素队员使攻击 +{Value}%",
	Dialog = "o(￣▽￣)ｄ",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210005,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2200] =
{
	Id = 2200,
	Name = "火元素队员攻击+",
	Desc = "火元素队员攻击 +{Value}%",
	Dialog = "o(￣▽￣)ｄ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210002,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2201] =
{
	Id = 2201,
	Name = "敌人忍耐-",
	Desc = "敌人忍耐 +{Value}",
	Dialog = "╰(*°▽°*)╯",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2202] =
{
	Id = 2202,
	Name = "全队忍耐+",
	Desc = "全队忍耐 +{Value}",
	Dialog = "（づ￣3￣）づ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2203] =
{
	Id = 2203,
	Name = "每回合恢复",
	Desc = "每回合，全队回血{Value}%，最多5次",
	Dialog = "o(￣▽￣)ｄ",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id2204] =
{
	Id = 2204,
	Name = "概率无视敌人闪避",
	Desc = "{Value}%概率无视敌人闪避",
	Dialog = "o(￣▽￣)ｄ",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DodgeIgnore",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
