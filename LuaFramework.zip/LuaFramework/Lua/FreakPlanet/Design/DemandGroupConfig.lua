DemandGroupConfig ={};
DemandGroupID = 
{
	Id001 = 420001,
	Id002 = 420002,
	Id003 = 420003,
	Id004 = 420004,
	Id005 = 420005,
	Id006 = 420006,
	Id007 = 420007,
	Id008 = 420008,
	Id009 = 420009,
	Id010 = 420010,
	Id011 = 420011,
	Id012 = 420012,
	Id013 = 420013,
	Id014 = 420014,
	Id015 = 420015,
	Id016 = 420016,
	Id017 = 420017,
	Id018 = 420018,
}
DemandGroupConfig[DemandGroupID.Id001] =
{
	Id = 1,
	IsActivity = false,
}
DemandGroupConfig[DemandGroupID.Id002] =
{
	Id = 2,
	IsActivity = false,
	PreCondition = {
		PreGoal = 
		{
			300010,
		},
	},
}
DemandGroupConfig[DemandGroupID.Id003] =
{
	Id = 3,
	IsActivity = false,
	PreCondition = {
		PreGoal = 
		{
			300017,
		},
	},
}
DemandGroupConfig[DemandGroupID.Id004] =
{
	Id = 4,
	IsActivity = false,
	PreCondition = {
		PreGoal = 
		{
			300030,
		},
	},
}
DemandGroupConfig[DemandGroupID.Id005] =
{
	Id = 5,
	IsActivity = false,
	PreCondition = {
		PreGoal = 
		{
			300046,
		},
	},
}
DemandGroupConfig[DemandGroupID.Id006] =
{
	Id = 6,
	IsActivity = false,
	PreCondition = {
		PreGoal = 
		{
			300058,
		},
	},
}
DemandGroupConfig[DemandGroupID.Id007] =
{
	Id = 7,
	IsActivity = false,
	PreCondition = {
		PreGoal = 
		{
			300072,
		},
	},
}
DemandGroupConfig[DemandGroupID.Id008] =
{
	Id = 8,
	IsActivity = false,
	PreCondition = {
		PreGoal = 
		{
			300087,
		},
	},
}
DemandGroupConfig[DemandGroupID.Id009] =
{
	Id = 9,
	IsActivity = false,
	PreCondition = {
		PreGoal = 
		{
			300406,
		},
	},
}
DemandGroupConfig[DemandGroupID.Id010] =
{
	Id = 10,
	IsActivity = true,
	PreCondition = {
		PreGoal = 
		{
			300040,
		},
	},
}
DemandGroupConfig[DemandGroupID.Id011] =
{
	Id = 11,
	IsActivity = true,
	PreCondition = {
		PreGoal = 
		{
			300040,
		},
	},
}
DemandGroupConfig[DemandGroupID.Id012] =
{
	Id = 12,
	IsActivity = true,
	PreCondition = {
		PreGoal = 
		{
			300040,
		},
	},
}
DemandGroupConfig[DemandGroupID.Id013] =
{
	Id = 13,
	IsActivity = true,
	PreCondition = {
		PreGoal = 
		{
			300040,
		},
	},
}
DemandGroupConfig[DemandGroupID.Id014] =
{
	Id = 14,
	IsActivity = true,
	PreCondition = {
		PreGoal = 
		{
			300040,
		},
	},
}
DemandGroupConfig[DemandGroupID.Id015] =
{
	Id = 15,
	IsActivity = true,
	PreCondition = {
		PreGoal = 
		{
			300040,
		},
	},
}
DemandGroupConfig[DemandGroupID.Id016] =
{
	Id = 16,
	IsActivity = true,
	PreCondition = {
		PreGoal = 
		{
			300040,
		},
	},
}
DemandGroupConfig[DemandGroupID.Id017] =
{
	Id = 17,
	IsActivity = true,
	PreCondition = {
		PreGoal = 
		{
			300040,
		},
	},
}
DemandGroupConfig[DemandGroupID.Id018] =
{
	Id = 18,
	IsActivity = true,
	PreCondition = {
		PreGoal = 
		{
			300040,
		},
	},
}

