
EquipmentConfig[EquipmentID.Id513] =
{
	Character = 220505,
	Rarity = 3,
	NeedChallenge = 145203,
	UpgradeId = 930031,
	LevelList = {
		{
			Level = 1,
			Info = 920436,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
			},
		},
		{
			Level = 2,
			Info = 920436,
			Ability = {
				{
					Value = 200001,
					Num = 180,
				},
			},
		},
		{
			Level = 3,
			Info = 920436,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
			},
		},
		{
			Level = 4,
			Info = 920436,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
			},
		},
		{
			Level = 5,
			Info = 920436,
			Ability = {
				{
					Value = 200001,
					Num = 396,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920436,
			Ability = {
				{
					Value = 200001,
					Num = 468,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920436,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920436,
			Ability = {
				{
					Value = 200001,
					Num = 612,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
		},
		{
			Level = 9,
			Info = 920436,
			Ability = {
				{
					Value = 200001,
					Num = 684,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
		},
		{
			Level = 10,
			Info = 920436,
			Ability = {
				{
					Value = 200001,
					Num = 756,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id514] =
{
	Character = 220506,
	Rarity = 2,
	UpgradeId = 930005,
	LevelList = {
		{
			Level = 1,
			Info = 920437,
			Ability = {
				{
					Value = 200002,
					Num = 36,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920437,
			Ability = {
				{
					Value = 200002,
					Num = 72,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920437,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920437,
			Ability = {
				{
					Value = 200002,
					Num = 144,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920437,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920437,
			Ability = {
				{
					Value = 200002,
					Num = 216,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920437,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200005,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920437,
			Ability = {
				{
					Value = 200002,
					Num = 288,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920437,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920437,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id515] =
{
	Character = 220506,
	Rarity = 2,
	NeedChallenge = 145204,
	UpgradeId = 930006,
	LevelList = {
		{
			Level = 1,
			Info = 920438,
			Ability = {
				{
					Value = 200002,
					Num = 36,
				},
				{
					Value = 200008,
					Num = 3,
				},
			},
		},
		{
			Level = 2,
			Info = 920438,
			Ability = {
				{
					Value = 200002,
					Num = 72,
				},
				{
					Value = 200008,
					Num = 6,
				},
			},
		},
		{
			Level = 3,
			Info = 920438,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 4,
			Info = 920438,
			Ability = {
				{
					Value = 200002,
					Num = 144,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 5,
			Info = 920438,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
				{
					Value = 200008,
					Num = 15,
				},
			},
		},
		{
			Level = 6,
			Info = 920438,
			Ability = {
				{
					Value = 200002,
					Num = 216,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 7,
			Info = 920438,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200008,
					Num = 21,
				},
			},
		},
		{
			Level = 8,
			Info = 920438,
			Ability = {
				{
					Value = 200002,
					Num = 288,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920438,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920438,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id516] =
{
	Character = 220507,
	Rarity = 2,
	UpgradeId = 930025,
	LevelList = {
		{
			Level = 1,
			Info = 920439,
			Ability = {
				{
					Value = 200001,
					Num = 45,
				},
				{
					Value = 200008,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920439,
			Ability = {
				{
					Value = 200001,
					Num = 90,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920439,
			Ability = {
				{
					Value = 200001,
					Num = 135,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920439,
			Ability = {
				{
					Value = 200001,
					Num = 180,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920439,
			Ability = {
				{
					Value = 200001,
					Num = 225,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920439,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920439,
			Ability = {
				{
					Value = 200001,
					Num = 315,
				},
				{
					Value = 200008,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920439,
			Ability = {
				{
					Value = 200001,
					Num = 360,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920439,
			Ability = {
				{
					Value = 200001,
					Num = 405,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920439,
			Ability = {
				{
					Value = 200001,
					Num = 450,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id517] =
{
	Character = 220507,
	Rarity = 2,
	NeedChallenge = 145205,
	UpgradeId = 930026,
	LevelList = {
		{
			Level = 1,
			Info = 920440,
			Ability = {
				{
					Value = 200001,
					Num = 45,
				},
				{
					Value = 200005,
					Num = 3,
				},
			},
		},
		{
			Level = 2,
			Info = 920440,
			Ability = {
				{
					Value = 200001,
					Num = 90,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 3,
			Info = 920440,
			Ability = {
				{
					Value = 200001,
					Num = 135,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 4,
			Info = 920440,
			Ability = {
				{
					Value = 200001,
					Num = 180,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 5,
			Info = 920440,
			Ability = {
				{
					Value = 200001,
					Num = 225,
				},
				{
					Value = 200005,
					Num = 15,
				},
			},
		},
		{
			Level = 6,
			Info = 920440,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 7,
			Info = 920440,
			Ability = {
				{
					Value = 200001,
					Num = 315,
				},
				{
					Value = 200005,
					Num = 21,
				},
			},
		},
		{
			Level = 8,
			Info = 920440,
			Ability = {
				{
					Value = 200001,
					Num = 360,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
			SkillList = {
				{
					Id = 100565,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920440,
			Ability = {
				{
					Value = 200001,
					Num = 405,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
			SkillList = {
				{
					Id = 100565,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920440,
			Ability = {
				{
					Value = 200001,
					Num = 450,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100565,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id518] =
{
	Character = 220508,
	Rarity = 2,
	UpgradeId = 930025,
	LevelList = {
		{
			Level = 1,
			Info = 920441,
			Ability = {
				{
					Value = 200001,
					Num = 42,
				},
				{
					Value = 200008,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920441,
			Ability = {
				{
					Value = 200001,
					Num = 84,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920441,
			Ability = {
				{
					Value = 200001,
					Num = 126,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920441,
			Ability = {
				{
					Value = 200001,
					Num = 168,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920441,
			Ability = {
				{
					Value = 200001,
					Num = 210,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920441,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920441,
			Ability = {
				{
					Value = 200001,
					Num = 294,
				},
				{
					Value = 200008,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920441,
			Ability = {
				{
					Value = 200001,
					Num = 336,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920441,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920441,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id519] =
{
	Character = 220508,
	Rarity = 2,
	NeedChallenge = 145206,
	UpgradeId = 930026,
	LevelList = {
		{
			Level = 1,
			Info = 920442,
			Ability = {
				{
					Value = 200001,
					Num = 42,
				},
				{
					Value = 200007,
					Num = 3,
				},
			},
		},
		{
			Level = 2,
			Info = 920442,
			Ability = {
				{
					Value = 200001,
					Num = 84,
				},
				{
					Value = 200007,
					Num = 6,
				},
			},
		},
		{
			Level = 3,
			Info = 920442,
			Ability = {
				{
					Value = 200001,
					Num = 126,
				},
				{
					Value = 200007,
					Num = 9,
				},
			},
		},
		{
			Level = 4,
			Info = 920442,
			Ability = {
				{
					Value = 200001,
					Num = 168,
				},
				{
					Value = 200007,
					Num = 12,
				},
			},
		},
		{
			Level = 5,
			Info = 920442,
			Ability = {
				{
					Value = 200001,
					Num = 210,
				},
				{
					Value = 200007,
					Num = 15,
				},
			},
		},
		{
			Level = 6,
			Info = 920442,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 7,
			Info = 920442,
			Ability = {
				{
					Value = 200001,
					Num = 294,
				},
				{
					Value = 200007,
					Num = 21,
				},
			},
		},
		{
			Level = 8,
			Info = 920442,
			Ability = {
				{
					Value = 200001,
					Num = 336,
				},
				{
					Value = 200007,
					Num = 24,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920442,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200007,
					Num = 27,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920442,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
				{
					Value = 200007,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id520] =
{
	Character = 220509,
	Rarity = 2,
	UpgradeId = 930005,
	LevelList = {
		{
			Level = 1,
			Info = 920443,
			Ability = {
				{
					Value = 200002,
					Num = 39,
				},
				{
					Value = 200008,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920443,
			Ability = {
				{
					Value = 200002,
					Num = 78,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920443,
			Ability = {
				{
					Value = 200002,
					Num = 117,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920443,
			Ability = {
				{
					Value = 200002,
					Num = 156,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920443,
			Ability = {
				{
					Value = 200002,
					Num = 195,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920443,
			Ability = {
				{
					Value = 200002,
					Num = 234,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920443,
			Ability = {
				{
					Value = 200002,
					Num = 273,
				},
				{
					Value = 200008,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920443,
			Ability = {
				{
					Value = 200002,
					Num = 312,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920443,
			Ability = {
				{
					Value = 200002,
					Num = 351,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920443,
			Ability = {
				{
					Value = 200002,
					Num = 390,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id521] =
{
	Character = 220509,
	Rarity = 2,
	NeedChallenge = 145207,
	UpgradeId = 930006,
	LevelList = {
		{
			Level = 1,
			Info = 920444,
			Ability = {
				{
					Value = 200002,
					Num = 39,
				},
				{
					Value = 200005,
					Num = 3,
				},
			},
		},
		{
			Level = 2,
			Info = 920444,
			Ability = {
				{
					Value = 200002,
					Num = 78,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 3,
			Info = 920444,
			Ability = {
				{
					Value = 200002,
					Num = 117,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 4,
			Info = 920444,
			Ability = {
				{
					Value = 200002,
					Num = 156,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 5,
			Info = 920444,
			Ability = {
				{
					Value = 200002,
					Num = 195,
				},
				{
					Value = 200005,
					Num = 15,
				},
			},
		},
		{
			Level = 6,
			Info = 920444,
			Ability = {
				{
					Value = 200002,
					Num = 234,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 7,
			Info = 920444,
			Ability = {
				{
					Value = 200002,
					Num = 273,
				},
				{
					Value = 200005,
					Num = 21,
				},
			},
		},
		{
			Level = 8,
			Info = 920444,
			Ability = {
				{
					Value = 200002,
					Num = 312,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920444,
			Ability = {
				{
					Value = 200002,
					Num = 351,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920444,
			Ability = {
				{
					Value = 200002,
					Num = 390,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id522] =
{
	Character = 220510,
	Rarity = 2,
	UpgradeId = 930005,
	LevelList = {
		{
			Level = 1,
			Info = 920445,
			Ability = {
				{
					Value = 200002,
					Num = 48,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920445,
			Ability = {
				{
					Value = 200002,
					Num = 96,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920445,
			Ability = {
				{
					Value = 200002,
					Num = 144,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920445,
			Ability = {
				{
					Value = 200002,
					Num = 192,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920445,
			Ability = {
				{
					Value = 200002,
					Num = 240,
				},
				{
					Value = 200008,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920445,
			Ability = {
				{
					Value = 200002,
					Num = 288,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920445,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
				{
					Value = 200008,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920445,
			Ability = {
				{
					Value = 200002,
					Num = 384,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920445,
			Ability = {
				{
					Value = 200002,
					Num = 432,
				},
				{
					Value = 200008,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920445,
			Ability = {
				{
					Value = 200002,
					Num = 480,
				},
				{
					Value = 200008,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id523] =
{
	Character = 220510,
	Rarity = 2,
	NeedChallenge = 145208,
	UpgradeId = 930006,
	LevelList = {
		{
			Level = 1,
			Info = 920446,
			Ability = {
				{
					Value = 200002,
					Num = 48,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920446,
			Ability = {
				{
					Value = 200002,
					Num = 96,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920446,
			Ability = {
				{
					Value = 200002,
					Num = 144,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920446,
			Ability = {
				{
					Value = 200002,
					Num = 192,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920446,
			Ability = {
				{
					Value = 200002,
					Num = 240,
				},
				{
					Value = 200008,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920446,
			Ability = {
				{
					Value = 200002,
					Num = 288,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920446,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
				{
					Value = 200008,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920446,
			Ability = {
				{
					Value = 200002,
					Num = 384,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100555,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920446,
			Ability = {
				{
					Value = 200002,
					Num = 432,
				},
				{
					Value = 200008,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100555,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920446,
			Ability = {
				{
					Value = 200002,
					Num = 480,
				},
				{
					Value = 200008,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100555,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id524] =
{
	Character = 220511,
	Rarity = 2,
	UpgradeId = 930005,
	LevelList = {
		{
			Level = 1,
			Info = 920447,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920447,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920447,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920447,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920447,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200008,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920447,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920447,
			Ability = {
				{
					Value = 200002,
					Num = 294,
				},
				{
					Value = 200008,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920447,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920447,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200008,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920447,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200008,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id525] =
{
	Character = 220511,
	Rarity = 2,
	NeedChallenge = 145209,
	UpgradeId = 930006,
	LevelList = {
		{
			Level = 1,
			Info = 920448,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920448,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920448,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920448,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920448,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200008,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920448,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920448,
			Ability = {
				{
					Value = 200002,
					Num = 294,
				},
				{
					Value = 200008,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920448,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100552,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920448,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200008,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100552,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920448,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200008,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100552,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id526] =
{
	Character = 220512,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920449,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200006,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920449,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920449,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200006,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920449,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920449,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200006,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920449,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920449,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200006,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920449,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200006,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920449,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200006,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920449,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200006,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id527] =
{
	Character = 220512,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920450,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920450,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920450,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920450,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920450,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920450,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920450,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200005,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920450,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100565,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920450,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100565,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920450,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100565,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id528] =
{
	Character = 220512,
	Rarity = 3,
	NeedChallenge = 145210,
	UpgradeId = 930031,
	LevelList = {
		{
			Level = 1,
			Info = 920451,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
			},
		},
		{
			Level = 2,
			Info = 920451,
			Ability = {
				{
					Value = 200001,
					Num = 180,
				},
			},
		},
		{
			Level = 3,
			Info = 920451,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
			},
		},
		{
			Level = 4,
			Info = 920451,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
			},
		},
		{
			Level = 5,
			Info = 920451,
			Ability = {
				{
					Value = 200001,
					Num = 396,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920451,
			Ability = {
				{
					Value = 200001,
					Num = 468,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920451,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920451,
			Ability = {
				{
					Value = 200001,
					Num = 612,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
		},
		{
			Level = 9,
			Info = 920451,
			Ability = {
				{
					Value = 200001,
					Num = 684,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
		},
		{
			Level = 10,
			Info = 920451,
			Ability = {
				{
					Value = 200001,
					Num = 756,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id529] =
{
	Character = 220513,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920452,
			Ability = {
				{
					Value = 200001,
					Num = 57,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920452,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920452,
			Ability = {
				{
					Value = 200001,
					Num = 171,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920452,
			Ability = {
				{
					Value = 200001,
					Num = 228,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920452,
			Ability = {
				{
					Value = 200001,
					Num = 285,
				},
				{
					Value = 200008,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920452,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920452,
			Ability = {
				{
					Value = 200001,
					Num = 399,
				},
				{
					Value = 200008,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920452,
			Ability = {
				{
					Value = 200001,
					Num = 456,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920452,
			Ability = {
				{
					Value = 200001,
					Num = 513,
				},
				{
					Value = 200008,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920452,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200008,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id530] =
{
	Character = 220513,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920453,
			Ability = {
				{
					Value = 200001,
					Num = 57,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920453,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920453,
			Ability = {
				{
					Value = 200001,
					Num = 171,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920453,
			Ability = {
				{
					Value = 200001,
					Num = 228,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920453,
			Ability = {
				{
					Value = 200001,
					Num = 285,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920453,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920453,
			Ability = {
				{
					Value = 200001,
					Num = 399,
				},
				{
					Value = 200005,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920453,
			Ability = {
				{
					Value = 200001,
					Num = 456,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920453,
			Ability = {
				{
					Value = 200001,
					Num = 513,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920453,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id531] =
{
	Character = 220513,
	Rarity = 3,
	NeedChallenge = 145211,
	UpgradeId = 930031,
	LevelList = {
		{
			Level = 1,
			Info = 920454,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
			},
		},
		{
			Level = 2,
			Info = 920454,
			Ability = {
				{
					Value = 200001,
					Num = 190,
				},
			},
		},
		{
			Level = 3,
			Info = 920454,
			Ability = {
				{
					Value = 200001,
					Num = 266,
				},
			},
		},
		{
			Level = 4,
			Info = 920454,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
			},
		},
		{
			Level = 5,
			Info = 920454,
			Ability = {
				{
					Value = 200001,
					Num = 418,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920454,
			Ability = {
				{
					Value = 200001,
					Num = 494,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920454,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920454,
			Ability = {
				{
					Value = 200001,
					Num = 646,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
		},
		{
			Level = 9,
			Info = 920454,
			Ability = {
				{
					Value = 200001,
					Num = 722,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
		},
		{
			Level = 10,
			Info = 920454,
			Ability = {
				{
					Value = 200001,
					Num = 798,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id532] =
{
	Character = 220514,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920455,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200007,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920455,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920455,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200007,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920455,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920455,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200007,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920455,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920455,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200007,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920455,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200007,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920455,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200007,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920455,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200007,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id533] =
{
	Character = 220514,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920456,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200008,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920456,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920456,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920456,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920456,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920456,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920456,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200008,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920456,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920456,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920456,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id534] =
{
	Character = 220514,
	Rarity = 3,
	NeedChallenge = 145212,
	UpgradeId = 930031,
	LevelList = {
		{
			Level = 1,
			Info = 920457,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
			},
		},
		{
			Level = 2,
			Info = 920457,
			Ability = {
				{
					Value = 200001,
					Num = 180,
				},
			},
		},
		{
			Level = 3,
			Info = 920457,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
			},
		},
		{
			Level = 4,
			Info = 920457,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
			},
		},
		{
			Level = 5,
			Info = 920457,
			Ability = {
				{
					Value = 200001,
					Num = 396,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920457,
			Ability = {
				{
					Value = 200001,
					Num = 468,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920457,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920457,
			Ability = {
				{
					Value = 200001,
					Num = 612,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
		},
		{
			Level = 9,
			Info = 920457,
			Ability = {
				{
					Value = 200001,
					Num = 684,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
		},
		{
			Level = 10,
			Info = 920457,
			Ability = {
				{
					Value = 200001,
					Num = 756,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id535] =
{
	Character = 220515,
	Rarity = 3,
	UpgradeId = 930009,
	LevelList = {
		{
			Level = 1,
			Info = 920458,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920458,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920458,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920458,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920458,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920458,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920458,
			Ability = {
				{
					Value = 200002,
					Num = 294,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920458,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920458,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920458,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id536] =
{
	Character = 220515,
	Rarity = 3,
	UpgradeId = 930010,
	LevelList = {
		{
			Level = 1,
			Info = 920459,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200008,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920459,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920459,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920459,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920459,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920459,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920459,
			Ability = {
				{
					Value = 200002,
					Num = 294,
				},
				{
					Value = 200008,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920459,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100552,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920459,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100552,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920459,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100552,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id537] =
{
	Character = 220515,
	Rarity = 3,
	NeedChallenge = 145213,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920460,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
			},
		},
		{
			Level = 2,
			Info = 920460,
			Ability = {
				{
					Value = 200002,
					Num = 140,
				},
			},
		},
		{
			Level = 3,
			Info = 920460,
			Ability = {
				{
					Value = 200002,
					Num = 196,
				},
			},
		},
		{
			Level = 4,
			Info = 920460,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
		},
		{
			Level = 5,
			Info = 920460,
			Ability = {
				{
					Value = 200002,
					Num = 308,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920460,
			Ability = {
				{
					Value = 200002,
					Num = 364,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920460,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920460,
			Ability = {
				{
					Value = 200002,
					Num = 476,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
		},
		{
			Level = 9,
			Info = 920460,
			Ability = {
				{
					Value = 200002,
					Num = 532,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
		},
		{
			Level = 10,
			Info = 920460,
			Ability = {
				{
					Value = 200002,
					Num = 588,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id538] =
{
	Character = 220516,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920461,
			Ability = {
				{
					Value = 200001,
					Num = 60,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920461,
			Ability = {
				{
					Value = 200001,
					Num = 120,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920461,
			Ability = {
				{
					Value = 200001,
					Num = 180,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920461,
			Ability = {
				{
					Value = 200001,
					Num = 240,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920461,
			Ability = {
				{
					Value = 200001,
					Num = 300,
				},
				{
					Value = 200008,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920461,
			Ability = {
				{
					Value = 200001,
					Num = 360,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920461,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
				{
					Value = 200008,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920461,
			Ability = {
				{
					Value = 200001,
					Num = 480,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920461,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200008,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920461,
			Ability = {
				{
					Value = 200001,
					Num = 600,
				},
				{
					Value = 200008,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id539] =
{
	Character = 220516,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920462,
			Ability = {
				{
					Value = 200001,
					Num = 60,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920462,
			Ability = {
				{
					Value = 200001,
					Num = 120,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920462,
			Ability = {
				{
					Value = 200001,
					Num = 180,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920462,
			Ability = {
				{
					Value = 200001,
					Num = 240,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920462,
			Ability = {
				{
					Value = 200001,
					Num = 300,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920462,
			Ability = {
				{
					Value = 200001,
					Num = 360,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920462,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
				{
					Value = 200005,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920462,
			Ability = {
				{
					Value = 200001,
					Num = 480,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920462,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920462,
			Ability = {
				{
					Value = 200001,
					Num = 600,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id540] =
{
	Character = 220516,
	Rarity = 3,
	NeedChallenge = 145214,
	UpgradeId = 930031,
	LevelList = {
		{
			Level = 1,
			Info = 920463,
			Ability = {
				{
					Value = 200001,
					Num = 120,
				},
			},
		},
		{
			Level = 2,
			Info = 920463,
			Ability = {
				{
					Value = 200001,
					Num = 200,
				},
			},
		},
		{
			Level = 3,
			Info = 920463,
			Ability = {
				{
					Value = 200001,
					Num = 280,
				},
			},
		},
		{
			Level = 4,
			Info = 920463,
			Ability = {
				{
					Value = 200001,
					Num = 360,
				},
			},
		},
		{
			Level = 5,
			Info = 920463,
			Ability = {
				{
					Value = 200001,
					Num = 440,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920463,
			Ability = {
				{
					Value = 200001,
					Num = 520,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920463,
			Ability = {
				{
					Value = 200001,
					Num = 600,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920463,
			Ability = {
				{
					Value = 200001,
					Num = 680,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
		},
		{
			Level = 9,
			Info = 920463,
			Ability = {
				{
					Value = 200001,
					Num = 760,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
		},
		{
			Level = 10,
			Info = 920463,
			Ability = {
				{
					Value = 200001,
					Num = 840,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id541] =
{
	Character = 220517,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920464,
			Ability = {
				{
					Value = 200001,
					Num = 57,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920464,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920464,
			Ability = {
				{
					Value = 200001,
					Num = 171,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920464,
			Ability = {
				{
					Value = 200001,
					Num = 228,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920464,
			Ability = {
				{
					Value = 200001,
					Num = 285,
				},
				{
					Value = 200008,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920464,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920464,
			Ability = {
				{
					Value = 200001,
					Num = 399,
				},
				{
					Value = 200008,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920464,
			Ability = {
				{
					Value = 200001,
					Num = 456,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920464,
			Ability = {
				{
					Value = 200001,
					Num = 513,
				},
				{
					Value = 200008,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920464,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200008,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id542] =
{
	Character = 220517,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920465,
			Ability = {
				{
					Value = 200001,
					Num = 57,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920465,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920465,
			Ability = {
				{
					Value = 200001,
					Num = 171,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920465,
			Ability = {
				{
					Value = 200001,
					Num = 228,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920465,
			Ability = {
				{
					Value = 200001,
					Num = 285,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920465,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920465,
			Ability = {
				{
					Value = 200001,
					Num = 399,
				},
				{
					Value = 200005,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920465,
			Ability = {
				{
					Value = 200001,
					Num = 456,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920465,
			Ability = {
				{
					Value = 200001,
					Num = 513,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920465,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
	},
}
