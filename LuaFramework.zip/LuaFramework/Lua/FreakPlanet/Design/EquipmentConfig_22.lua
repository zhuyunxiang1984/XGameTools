
EquipmentConfig[EquipmentID.Id663] =
{
	Character = 223122,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920697,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200006,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920697,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920697,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200006,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920697,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920697,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200006,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920697,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920697,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200006,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920697,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200006,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100780,
					Value = 19,
				},
			},
		},
		{
			Level = 9,
			Info = 920697,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200006,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100780,
					Value = 19,
				},
			},
		},
		{
			Level = 10,
			Info = 920697,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200006,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100780,
					Value = 19,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id664] =
{
	Character = 223122,
	Rarity = 3,
	UpgradeId = 930010,
	LevelList = {
		{
			Level = 1,
			Info = 920698,
			Ability = {
				{
					Value = 200002,
					Num = 45,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920698,
			Ability = {
				{
					Value = 200002,
					Num = 90,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920698,
			Ability = {
				{
					Value = 200002,
					Num = 135,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920698,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920698,
			Ability = {
				{
					Value = 200002,
					Num = 225,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920698,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920698,
			Ability = {
				{
					Value = 200002,
					Num = 315,
				},
				{
					Value = 200005,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920698,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 7,
				},
			},
		},
		{
			Level = 9,
			Info = 920698,
			Ability = {
				{
					Value = 200002,
					Num = 405,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 7,
				},
			},
		},
		{
			Level = 10,
			Info = 920698,
			Ability = {
				{
					Value = 200002,
					Num = 450,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 7,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id665] =
{
	Character = 223122,
	Rarity = 3,
	NeedChallenge = 145259,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920699,
			Ability = {
				{
					Value = 200002,
					Num = 90,
				},
			},
		},
		{
			Level = 2,
			Info = 920699,
			Ability = {
				{
					Value = 200002,
					Num = 150,
				},
			},
		},
		{
			Level = 3,
			Info = 920699,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
			},
		},
		{
			Level = 4,
			Info = 920699,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
			},
		},
		{
			Level = 5,
			Info = 920699,
			Ability = {
				{
					Value = 200002,
					Num = 330,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920699,
			Ability = {
				{
					Value = 200002,
					Num = 390,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920699,
			Ability = {
				{
					Value = 200002,
					Num = 450,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920699,
			Ability = {
				{
					Value = 200002,
					Num = 510,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100502,
					Value = 3,
				},
			},
		},
		{
			Level = 9,
			Info = 920699,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100502,
					Value = 3,
				},
			},
		},
		{
			Level = 10,
			Info = 920699,
			Ability = {
				{
					Value = 200002,
					Num = 630,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100502,
					Value = 3,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id666] =
{
	Character = 223123,
	Rarity = 3,
	UpgradeId = 930009,
	LevelList = {
		{
			Level = 1,
			Info = 920700,
			Ability = {
				{
					Value = 200002,
					Num = 51,
				},
				{
					Value = 200008,
					Num = 15,
				},
			},
		},
		{
			Level = 2,
			Info = 920700,
			Ability = {
				{
					Value = 200002,
					Num = 102,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
		},
		{
			Level = 3,
			Info = 920700,
			Ability = {
				{
					Value = 200002,
					Num = 153,
				},
				{
					Value = 200008,
					Num = 45,
				},
			},
		},
		{
			Level = 4,
			Info = 920700,
			Ability = {
				{
					Value = 200002,
					Num = 204,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
		},
		{
			Level = 5,
			Info = 920700,
			Ability = {
				{
					Value = 200002,
					Num = 255,
				},
				{
					Value = 200008,
					Num = 75,
				},
			},
		},
		{
			Level = 6,
			Info = 920700,
			Ability = {
				{
					Value = 200002,
					Num = 306,
				},
				{
					Value = 200008,
					Num = 90,
				},
			},
		},
		{
			Level = 7,
			Info = 920700,
			Ability = {
				{
					Value = 200002,
					Num = 357,
				},
				{
					Value = 200008,
					Num = 105,
				},
			},
		},
		{
			Level = 8,
			Info = 920700,
			Ability = {
				{
					Value = 200002,
					Num = 408,
				},
				{
					Value = 200008,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 101701,
					Value = 216,
				},
			},
		},
		{
			Level = 9,
			Info = 920700,
			Ability = {
				{
					Value = 200002,
					Num = 459,
				},
				{
					Value = 200008,
					Num = 135,
				},
			},
			SkillList = {
				{
					Id = 101701,
					Value = 216,
				},
			},
		},
		{
			Level = 10,
			Info = 920700,
			Ability = {
				{
					Value = 200002,
					Num = 510,
				},
				{
					Value = 200008,
					Num = 150,
				},
			},
			SkillList = {
				{
					Id = 101701,
					Value = 216,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id667] =
{
	Character = 223123,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920701,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920701,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920701,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920701,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920701,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920701,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920701,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200005,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920701,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200005,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 7,
				},
			},
		},
		{
			Level = 9,
			Info = 920701,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200005,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 7,
				},
			},
		},
		{
			Level = 10,
			Info = 920701,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200005,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 7,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id668] =
{
	Character = 223123,
	Rarity = 3,
	NeedChallenge = 145260,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920702,
			Ability = {
				{
					Value = 200002,
					Num = 102,
				},
			},
		},
		{
			Level = 2,
			Info = 920702,
			Ability = {
				{
					Value = 200002,
					Num = 170,
				},
			},
		},
		{
			Level = 3,
			Info = 920702,
			Ability = {
				{
					Value = 200002,
					Num = 238,
				},
			},
		},
		{
			Level = 4,
			Info = 920702,
			Ability = {
				{
					Value = 200002,
					Num = 306,
				},
			},
		},
		{
			Level = 5,
			Info = 920702,
			Ability = {
				{
					Value = 200002,
					Num = 374,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920702,
			Ability = {
				{
					Value = 200002,
					Num = 442,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920702,
			Ability = {
				{
					Value = 200002,
					Num = 510,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920702,
			Ability = {
				{
					Value = 200002,
					Num = 578,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101745,
					Value = 60,
				},
			},
		},
		{
			Level = 9,
			Info = 920702,
			Ability = {
				{
					Value = 200002,
					Num = 646,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101745,
					Value = 60,
				},
			},
		},
		{
			Level = 10,
			Info = 920702,
			Ability = {
				{
					Value = 200002,
					Num = 714,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101745,
					Value = 60,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id669] =
{
	Character = 223124,
	Rarity = 5,
	UpgradeId = 930017,
	LevelList = {
		{
			Level = 1,
			Info = 920703,
			Ability = {
				{
					Value = 200002,
					Num = 78,
				},
				{
					Value = 200008,
					Num = 15,
				},
			},
		},
		{
			Level = 2,
			Info = 920703,
			Ability = {
				{
					Value = 200002,
					Num = 156,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
		},
		{
			Level = 3,
			Info = 920703,
			Ability = {
				{
					Value = 200002,
					Num = 234,
				},
				{
					Value = 200008,
					Num = 45,
				},
			},
		},
		{
			Level = 4,
			Info = 920703,
			Ability = {
				{
					Value = 200002,
					Num = 312,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
		},
		{
			Level = 5,
			Info = 920703,
			Ability = {
				{
					Value = 200002,
					Num = 390,
				},
				{
					Value = 200008,
					Num = 75,
				},
			},
		},
		{
			Level = 6,
			Info = 920703,
			Ability = {
				{
					Value = 200002,
					Num = 468,
				},
				{
					Value = 200008,
					Num = 90,
				},
			},
		},
		{
			Level = 7,
			Info = 920703,
			Ability = {
				{
					Value = 200002,
					Num = 546,
				},
				{
					Value = 200008,
					Num = 105,
				},
			},
		},
		{
			Level = 8,
			Info = 920703,
			Ability = {
				{
					Value = 200002,
					Num = 624,
				},
				{
					Value = 200008,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920703,
			Ability = {
				{
					Value = 200002,
					Num = 702,
				},
				{
					Value = 200008,
					Num = 135,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920703,
			Ability = {
				{
					Value = 200002,
					Num = 780,
				},
				{
					Value = 200008,
					Num = 150,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id670] =
{
	Character = 223124,
	Rarity = 5,
	UpgradeId = 930038,
	LevelList = {
		{
			Level = 1,
			Info = 920704,
			Ability = {
				{
					Value = 200001,
					Num = 84,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920704,
			Ability = {
				{
					Value = 200001,
					Num = 168,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920704,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920704,
			Ability = {
				{
					Value = 200001,
					Num = 336,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920704,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920704,
			Ability = {
				{
					Value = 200001,
					Num = 504,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920704,
			Ability = {
				{
					Value = 200001,
					Num = 588,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920704,
			Ability = {
				{
					Value = 200001,
					Num = 672,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 7,
				},
			},
		},
		{
			Level = 9,
			Info = 920704,
			Ability = {
				{
					Value = 200001,
					Num = 756,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 7,
				},
			},
		},
		{
			Level = 10,
			Info = 920704,
			Ability = {
				{
					Value = 200001,
					Num = 840,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 7,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id671] =
{
	Character = 223124,
	Rarity = 5,
	NeedChallenge = 145263,
	UpgradeId = 930019,
	LevelList = {
		{
			Level = 1,
			Info = 920705,
			Ability = {
				{
					Value = 200002,
					Num = 156,
				},
			},
		},
		{
			Level = 2,
			Info = 920705,
			Ability = {
				{
					Value = 200002,
					Num = 260,
				},
			},
		},
		{
			Level = 3,
			Info = 920705,
			Ability = {
				{
					Value = 200002,
					Num = 364,
				},
			},
		},
		{
			Level = 4,
			Info = 920705,
			Ability = {
				{
					Value = 200002,
					Num = 468,
				},
			},
		},
		{
			Level = 5,
			Info = 920705,
			Ability = {
				{
					Value = 200002,
					Num = 572,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920705,
			Ability = {
				{
					Value = 200002,
					Num = 676,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920705,
			Ability = {
				{
					Value = 200002,
					Num = 780,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920705,
			Ability = {
				{
					Value = 200002,
					Num = 884,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101717,
					Value = 45,
				},
			},
		},
		{
			Level = 9,
			Info = 920705,
			Ability = {
				{
					Value = 200002,
					Num = 988,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101717,
					Value = 45,
				},
			},
		},
		{
			Level = 10,
			Info = 920705,
			Ability = {
				{
					Value = 200002,
					Num = 1092,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101717,
					Value = 45,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id672] =
{
	Character = 223124,
	Rarity = 5,
	NeedChallenge = 145264,
	UpgradeId = 930020,
	LevelList = {
		{
			Level = 1,
			Info = 920706,
			Ability = {
				{
					Value = 200002,
					Num = 234,
				},
			},
		},
		{
			Level = 2,
			Info = 920706,
			Ability = {
				{
					Value = 200002,
					Num = 364,
				},
			},
		},
		{
			Level = 3,
			Info = 920706,
			Ability = {
				{
					Value = 200002,
					Num = 494,
				},
			},
		},
		{
			Level = 4,
			Info = 920706,
			Ability = {
				{
					Value = 200002,
					Num = 624,
				},
			},
		},
		{
			Level = 5,
			Info = 920706,
			Ability = {
				{
					Value = 200002,
					Num = 754,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920706,
			Ability = {
				{
					Value = 200002,
					Num = 884,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920706,
			Ability = {
				{
					Value = 200002,
					Num = 1014,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920706,
			Ability = {
				{
					Value = 200002,
					Num = 1144,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101731,
					Value = 1080,
				},
			},
		},
		{
			Level = 9,
			Info = 920706,
			Ability = {
				{
					Value = 200002,
					Num = 1274,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101731,
					Value = 1080,
				},
			},
		},
		{
			Level = 10,
			Info = 920706,
			Ability = {
				{
					Value = 200002,
					Num = 1404,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101731,
					Value = 1080,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id673] =
{
	Character = 223125,
	Rarity = 4,
	UpgradeId = 930033,
	LevelList = {
		{
			Level = 1,
			Info = 920707,
			Ability = {
				{
					Value = 200001,
					Num = 78,
				},
				{
					Value = 200007,
					Num = 15,
				},
			},
		},
		{
			Level = 2,
			Info = 920707,
			Ability = {
				{
					Value = 200001,
					Num = 156,
				},
				{
					Value = 200007,
					Num = 30,
				},
			},
		},
		{
			Level = 3,
			Info = 920707,
			Ability = {
				{
					Value = 200001,
					Num = 234,
				},
				{
					Value = 200007,
					Num = 45,
				},
			},
		},
		{
			Level = 4,
			Info = 920707,
			Ability = {
				{
					Value = 200001,
					Num = 312,
				},
				{
					Value = 200007,
					Num = 60,
				},
			},
		},
		{
			Level = 5,
			Info = 920707,
			Ability = {
				{
					Value = 200001,
					Num = 390,
				},
				{
					Value = 200007,
					Num = 75,
				},
			},
		},
		{
			Level = 6,
			Info = 920707,
			Ability = {
				{
					Value = 200001,
					Num = 468,
				},
				{
					Value = 200007,
					Num = 90,
				},
			},
		},
		{
			Level = 7,
			Info = 920707,
			Ability = {
				{
					Value = 200001,
					Num = 546,
				},
				{
					Value = 200007,
					Num = 105,
				},
			},
		},
		{
			Level = 8,
			Info = 920707,
			Ability = {
				{
					Value = 200001,
					Num = 624,
				},
				{
					Value = 200007,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920707,
			Ability = {
				{
					Value = 200001,
					Num = 702,
				},
				{
					Value = 200007,
					Num = 135,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920707,
			Ability = {
				{
					Value = 200001,
					Num = 780,
				},
				{
					Value = 200007,
					Num = 150,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id674] =
{
	Character = 223125,
	Rarity = 4,
	UpgradeId = 930034,
	LevelList = {
		{
			Level = 1,
			Info = 920708,
			Ability = {
				{
					Value = 200001,
					Num = 78,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920708,
			Ability = {
				{
					Value = 200001,
					Num = 156,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920708,
			Ability = {
				{
					Value = 200001,
					Num = 234,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920708,
			Ability = {
				{
					Value = 200001,
					Num = 312,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920708,
			Ability = {
				{
					Value = 200001,
					Num = 390,
				},
				{
					Value = 200008,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920708,
			Ability = {
				{
					Value = 200001,
					Num = 468,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920708,
			Ability = {
				{
					Value = 200001,
					Num = 546,
				},
				{
					Value = 200008,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920708,
			Ability = {
				{
					Value = 200001,
					Num = 624,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -50,
				},
			},
		},
		{
			Level = 9,
			Info = 920708,
			Ability = {
				{
					Value = 200001,
					Num = 702,
				},
				{
					Value = 200008,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -50,
				},
			},
		},
		{
			Level = 10,
			Info = 920708,
			Ability = {
				{
					Value = 200001,
					Num = 780,
				},
				{
					Value = 200008,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -50,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id675] =
{
	Character = 223125,
	Rarity = 4,
	NeedChallenge = 145265,
	UpgradeId = 930035,
	LevelList = {
		{
			Level = 1,
			Info = 920709,
			Ability = {
				{
					Value = 200001,
					Num = 156,
				},
			},
		},
		{
			Level = 2,
			Info = 920709,
			Ability = {
				{
					Value = 200001,
					Num = 260,
				},
			},
		},
		{
			Level = 3,
			Info = 920709,
			Ability = {
				{
					Value = 200001,
					Num = 364,
				},
			},
		},
		{
			Level = 4,
			Info = 920709,
			Ability = {
				{
					Value = 200001,
					Num = 468,
				},
			},
		},
		{
			Level = 5,
			Info = 920709,
			Ability = {
				{
					Value = 200001,
					Num = 572,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920709,
			Ability = {
				{
					Value = 200001,
					Num = 676,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920709,
			Ability = {
				{
					Value = 200001,
					Num = 780,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920709,
			Ability = {
				{
					Value = 200001,
					Num = 884,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101701,
					Value = 252,
				},
			},
		},
		{
			Level = 9,
			Info = 920709,
			Ability = {
				{
					Value = 200001,
					Num = 988,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101701,
					Value = 252,
				},
			},
		},
		{
			Level = 10,
			Info = 920709,
			Ability = {
				{
					Value = 200001,
					Num = 1092,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101701,
					Value = 252,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id676] =
{
	Character = 223126,
	Rarity = 4,
	UpgradeId = 930033,
	LevelList = {
		{
			Level = 1,
			Info = 920710,
			Ability = {
				{
					Value = 200001,
					Num = 75,
				},
				{
					Value = 200006,
					Num = 15,
				},
			},
		},
		{
			Level = 2,
			Info = 920710,
			Ability = {
				{
					Value = 200001,
					Num = 150,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
		},
		{
			Level = 3,
			Info = 920710,
			Ability = {
				{
					Value = 200001,
					Num = 225,
				},
				{
					Value = 200006,
					Num = 45,
				},
			},
		},
		{
			Level = 4,
			Info = 920710,
			Ability = {
				{
					Value = 200001,
					Num = 300,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
		},
		{
			Level = 5,
			Info = 920710,
			Ability = {
				{
					Value = 200001,
					Num = 375,
				},
				{
					Value = 200006,
					Num = 75,
				},
			},
		},
		{
			Level = 6,
			Info = 920710,
			Ability = {
				{
					Value = 200001,
					Num = 450,
				},
				{
					Value = 200006,
					Num = 90,
				},
			},
		},
		{
			Level = 7,
			Info = 920710,
			Ability = {
				{
					Value = 200001,
					Num = 525,
				},
				{
					Value = 200006,
					Num = 105,
				},
			},
		},
		{
			Level = 8,
			Info = 920710,
			Ability = {
				{
					Value = 200001,
					Num = 600,
				},
				{
					Value = 200006,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920710,
			Ability = {
				{
					Value = 200001,
					Num = 675,
				},
				{
					Value = 200006,
					Num = 135,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920710,
			Ability = {
				{
					Value = 200001,
					Num = 750,
				},
				{
					Value = 200006,
					Num = 150,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id677] =
{
	Character = 223126,
	Rarity = 4,
	UpgradeId = 930034,
	LevelList = {
		{
			Level = 1,
			Info = 920711,
			Ability = {
				{
					Value = 200001,
					Num = 75,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920711,
			Ability = {
				{
					Value = 200001,
					Num = 150,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920711,
			Ability = {
				{
					Value = 200001,
					Num = 225,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920711,
			Ability = {
				{
					Value = 200001,
					Num = 300,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920711,
			Ability = {
				{
					Value = 200001,
					Num = 375,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920711,
			Ability = {
				{
					Value = 200001,
					Num = 450,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920711,
			Ability = {
				{
					Value = 200001,
					Num = 525,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920711,
			Ability = {
				{
					Value = 200001,
					Num = 600,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100565,
					Value = -50,
				},
			},
		},
		{
			Level = 9,
			Info = 920711,
			Ability = {
				{
					Value = 200001,
					Num = 675,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100565,
					Value = -50,
				},
			},
		},
		{
			Level = 10,
			Info = 920711,
			Ability = {
				{
					Value = 200001,
					Num = 750,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100565,
					Value = -50,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id678] =
{
	Character = 223126,
	Rarity = 4,
	NeedChallenge = 145266,
	UpgradeId = 930035,
	LevelList = {
		{
			Level = 1,
			Info = 920712,
			Ability = {
				{
					Value = 200001,
					Num = 150,
				},
			},
		},
		{
			Level = 2,
			Info = 920712,
			Ability = {
				{
					Value = 200001,
					Num = 250,
				},
			},
		},
		{
			Level = 3,
			Info = 920712,
			Ability = {
				{
					Value = 200001,
					Num = 350,
				},
			},
		},
		{
			Level = 4,
			Info = 920712,
			Ability = {
				{
					Value = 200001,
					Num = 450,
				},
			},
		},
		{
			Level = 5,
			Info = 920712,
			Ability = {
				{
					Value = 200001,
					Num = 550,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920712,
			Ability = {
				{
					Value = 200001,
					Num = 650,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920712,
			Ability = {
				{
					Value = 200001,
					Num = 750,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920712,
			Ability = {
				{
					Value = 200001,
					Num = 850,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101503,
					Value = -22,
				},
			},
		},
		{
			Level = 9,
			Info = 920712,
			Ability = {
				{
					Value = 200001,
					Num = 950,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101503,
					Value = -22,
				},
			},
		},
		{
			Level = 10,
			Info = 920712,
			Ability = {
				{
					Value = 200001,
					Num = 1050,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101503,
					Value = -22,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id679] =
{
	Character = 223127,
	Rarity = 3,
	UpgradeId = 930009,
	LevelList = {
		{
			Level = 1,
			Info = 920713,
			Ability = {
				{
					Value = 200002,
					Num = 45,
				},
				{
					Value = 200007,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920713,
			Ability = {
				{
					Value = 200002,
					Num = 90,
				},
				{
					Value = 200007,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920713,
			Ability = {
				{
					Value = 200002,
					Num = 135,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920713,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
				{
					Value = 200007,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920713,
			Ability = {
				{
					Value = 200002,
					Num = 225,
				},
				{
					Value = 200007,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920713,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
				{
					Value = 200007,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920713,
			Ability = {
				{
					Value = 200002,
					Num = 315,
				},
				{
					Value = 200007,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920713,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
				{
					Value = 200007,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920713,
			Ability = {
				{
					Value = 200002,
					Num = 405,
				},
				{
					Value = 200007,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920713,
			Ability = {
				{
					Value = 200002,
					Num = 450,
				},
				{
					Value = 200007,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id680] =
{
	Character = 223127,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920714,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920714,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920714,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920714,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920714,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920714,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920714,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200005,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920714,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 101761,
					Value = 75,
				},
			},
		},
		{
			Level = 9,
			Info = 920714,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 101761,
					Value = 75,
				},
			},
		},
		{
			Level = 10,
			Info = 920714,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 101761,
					Value = 75,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id681] =
{
	Character = 223127,
	Rarity = 3,
	NeedChallenge = 145267,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920715,
			Ability = {
				{
					Value = 200002,
					Num = 90,
				},
			},
		},
		{
			Level = 2,
			Info = 920715,
			Ability = {
				{
					Value = 200002,
					Num = 150,
				},
			},
		},
		{
			Level = 3,
			Info = 920715,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
			},
		},
		{
			Level = 4,
			Info = 920715,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
			},
		},
		{
			Level = 5,
			Info = 920715,
			Ability = {
				{
					Value = 200002,
					Num = 330,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920715,
			Ability = {
				{
					Value = 200002,
					Num = 390,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920715,
			Ability = {
				{
					Value = 200002,
					Num = 450,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920715,
			Ability = {
				{
					Value = 200002,
					Num = 510,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100605,
					Value = 36,
				},
			},
		},
		{
			Level = 9,
			Info = 920715,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100605,
					Value = 36,
				},
			},
		},
		{
			Level = 10,
			Info = 920715,
			Ability = {
				{
					Value = 200002,
					Num = 630,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100605,
					Value = 36,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id682] =
{
	Character = 223128,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920716,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 2,
			Info = 920716,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 3,
			Info = 920716,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
		},
		{
			Level = 4,
			Info = 920716,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200007,
					Num = 72,
				},
			},
		},
		{
			Level = 5,
			Info = 920716,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200007,
					Num = 90,
				},
			},
		},
		{
			Level = 6,
			Info = 920716,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200007,
					Num = 108,
				},
			},
		},
		{
			Level = 7,
			Info = 920716,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200007,
					Num = 126,
				},
			},
		},
		{
			Level = 8,
			Info = 920716,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200007,
					Num = 144,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -50,
				},
			},
		},
		{
			Level = 9,
			Info = 920716,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200007,
					Num = 162,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -50,
				},
			},
		},
		{
			Level = 10,
			Info = 920716,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200007,
					Num = 180,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -50,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id683] =
{
	Character = 223128,
	Rarity = 3,
	UpgradeId = 930010,
	LevelList = {
		{
			Level = 1,
			Info = 920717,
			Ability = {
				{
					Value = 200002,
					Num = 45,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 2,
			Info = 920717,
			Ability = {
				{
					Value = 200002,
					Num = 90,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 3,
			Info = 920717,
			Ability = {
				{
					Value = 200002,
					Num = 135,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
		},
		{
			Level = 4,
			Info = 920717,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
				{
					Value = 200007,
					Num = 72,
				},
			},
		},
		{
			Level = 5,
			Info = 920717,
			Ability = {
				{
					Value = 200002,
					Num = 225,
				},
				{
					Value = 200007,
					Num = 90,
				},
			},
		},
		{
			Level = 6,
			Info = 920717,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
				{
					Value = 200007,
					Num = 108,
				},
			},
		},
		{
			Level = 7,
			Info = 920717,
			Ability = {
				{
					Value = 200002,
					Num = 315,
				},
				{
					Value = 200007,
					Num = 126,
				},
			},
		},
		{
			Level = 8,
			Info = 920717,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
				{
					Value = 200007,
					Num = 144,
				},
			},
			SkillList = {
				{
					Id = 101703,
					Value = 240,
				},
			},
		},
		{
			Level = 9,
			Info = 920717,
			Ability = {
				{
					Value = 200002,
					Num = 405,
				},
				{
					Value = 200007,
					Num = 162,
				},
			},
			SkillList = {
				{
					Id = 101703,
					Value = 240,
				},
			},
		},
		{
			Level = 10,
			Info = 920717,
			Ability = {
				{
					Value = 200002,
					Num = 450,
				},
				{
					Value = 200007,
					Num = 180,
				},
			},
			SkillList = {
				{
					Id = 101703,
					Value = 240,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id684] =
{
	Character = 223128,
	Rarity = 3,
	NeedChallenge = 145268,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920718,
			Ability = {
				{
					Value = 200002,
					Num = 90,
				},
			},
		},
		{
			Level = 2,
			Info = 920718,
			Ability = {
				{
					Value = 200002,
					Num = 150,
				},
			},
		},
		{
			Level = 3,
			Info = 920718,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
			},
		},
		{
			Level = 4,
			Info = 920718,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
			},
		},
		{
			Level = 5,
			Info = 920718,
			Ability = {
				{
					Value = 200002,
					Num = 330,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920718,
			Ability = {
				{
					Value = 200002,
					Num = 390,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920718,
			Ability = {
				{
					Value = 200002,
					Num = 450,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920718,
			Ability = {
				{
					Value = 200002,
					Num = 510,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100554,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920718,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100554,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920718,
			Ability = {
				{
					Value = 200002,
					Num = 630,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100554,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id685] =
{
	Character = 223129,
	Rarity = 3,
	UpgradeId = 930009,
	LevelList = {
		{
			Level = 1,
			Info = 920719,
			Ability = {
				{
					Value = 200002,
					Num = 48,
				},
				{
					Value = 200005,
					Num = 15,
				},
			},
		},
		{
			Level = 2,
			Info = 920719,
			Ability = {
				{
					Value = 200002,
					Num = 96,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
		},
		{
			Level = 3,
			Info = 920719,
			Ability = {
				{
					Value = 200002,
					Num = 144,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
		},
		{
			Level = 4,
			Info = 920719,
			Ability = {
				{
					Value = 200002,
					Num = 192,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
		},
		{
			Level = 5,
			Info = 920719,
			Ability = {
				{
					Value = 200002,
					Num = 240,
				},
				{
					Value = 200005,
					Num = 75,
				},
			},
		},
		{
			Level = 6,
			Info = 920719,
			Ability = {
				{
					Value = 200002,
					Num = 288,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
		},
		{
			Level = 7,
			Info = 920719,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
				{
					Value = 200005,
					Num = 105,
				},
			},
		},
		{
			Level = 8,
			Info = 920719,
			Ability = {
				{
					Value = 200002,
					Num = 384,
				},
				{
					Value = 200005,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100552,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920719,
			Ability = {
				{
					Value = 200002,
					Num = 432,
				},
				{
					Value = 200005,
					Num = 135,
				},
			},
			SkillList = {
				{
					Id = 100552,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920719,
			Ability = {
				{
					Value = 200002,
					Num = 480,
				},
				{
					Value = 200005,
					Num = 150,
				},
			},
			SkillList = {
				{
					Id = 100552,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id686] =
{
	Character = 223129,
	Rarity = 3,
	UpgradeId = 930010,
	LevelList = {
		{
			Level = 1,
			Info = 920720,
			Ability = {
				{
					Value = 200002,
					Num = 48,
				},
				{
					Value = 200005,
					Num = 15,
				},
			},
		},
		{
			Level = 2,
			Info = 920720,
			Ability = {
				{
					Value = 200002,
					Num = 96,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
		},
		{
			Level = 3,
			Info = 920720,
			Ability = {
				{
					Value = 200002,
					Num = 144,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
		},
		{
			Level = 4,
			Info = 920720,
			Ability = {
				{
					Value = 200002,
					Num = 192,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
		},
		{
			Level = 5,
			Info = 920720,
			Ability = {
				{
					Value = 200002,
					Num = 240,
				},
				{
					Value = 200005,
					Num = 75,
				},
			},
		},
		{
			Level = 6,
			Info = 920720,
			Ability = {
				{
					Value = 200002,
					Num = 288,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
		},
		{
			Level = 7,
			Info = 920720,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
				{
					Value = 200005,
					Num = 105,
				},
			},
		},
		{
			Level = 8,
			Info = 920720,
			Ability = {
				{
					Value = 200002,
					Num = 384,
				},
				{
					Value = 200005,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 100,
				},
			},
		},
		{
			Level = 9,
			Info = 920720,
			Ability = {
				{
					Value = 200002,
					Num = 432,
				},
				{
					Value = 200005,
					Num = 135,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 100,
				},
			},
		},
		{
			Level = 10,
			Info = 920720,
			Ability = {
				{
					Value = 200002,
					Num = 480,
				},
				{
					Value = 200005,
					Num = 150,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 100,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id687] =
{
	Character = 223129,
	Rarity = 3,
	NeedChallenge = 145269,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920721,
			Ability = {
				{
					Value = 200002,
					Num = 96,
				},
			},
		},
		{
			Level = 2,
			Info = 920721,
			Ability = {
				{
					Value = 200002,
					Num = 160,
				},
			},
		},
		{
			Level = 3,
			Info = 920721,
			Ability = {
				{
					Value = 200002,
					Num = 224,
				},
			},
		},
		{
			Level = 4,
			Info = 920721,
			Ability = {
				{
					Value = 200002,
					Num = 288,
				},
			},
		},
		{
			Level = 5,
			Info = 920721,
			Ability = {
				{
					Value = 200002,
					Num = 352,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920721,
			Ability = {
				{
					Value = 200002,
					Num = 416,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920721,
			Ability = {
				{
					Value = 200002,
					Num = 480,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920721,
			Ability = {
				{
					Value = 200002,
					Num = 544,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101731,
					Value = 720,
				},
			},
		},
		{
			Level = 9,
			Info = 920721,
			Ability = {
				{
					Value = 200002,
					Num = 608,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101731,
					Value = 720,
				},
			},
		},
		{
			Level = 10,
			Info = 920721,
			Ability = {
				{
					Value = 200002,
					Num = 672,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101731,
					Value = 720,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id688] =
{
	Character = 223130,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920722,
			Ability = {
				{
					Value = 200001,
					Num = 60,
				},
				{
					Value = 200006,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920722,
			Ability = {
				{
					Value = 200001,
					Num = 120,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920722,
			Ability = {
				{
					Value = 200001,
					Num = 180,
				},
				{
					Value = 200006,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920722,
			Ability = {
				{
					Value = 200001,
					Num = 240,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920722,
			Ability = {
				{
					Value = 200001,
					Num = 300,
				},
				{
					Value = 200006,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920722,
			Ability = {
				{
					Value = 200001,
					Num = 360,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920722,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
				{
					Value = 200006,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920722,
			Ability = {
				{
					Value = 200001,
					Num = 480,
				},
				{
					Value = 200006,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100656,
					Value = 10,
				},
			},
		},
		{
			Level = 9,
			Info = 920722,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200006,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100656,
					Value = 10,
				},
			},
		},
		{
			Level = 10,
			Info = 920722,
			Ability = {
				{
					Value = 200001,
					Num = 600,
				},
				{
					Value = 200006,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100656,
					Value = 10,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id689] =
{
	Character = 223130,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920723,
			Ability = {
				{
					Value = 200001,
					Num = 60,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920723,
			Ability = {
				{
					Value = 200001,
					Num = 120,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920723,
			Ability = {
				{
					Value = 200001,
					Num = 180,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920723,
			Ability = {
				{
					Value = 200001,
					Num = 240,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920723,
			Ability = {
				{
					Value = 200001,
					Num = 300,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920723,
			Ability = {
				{
					Value = 200001,
					Num = 360,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920723,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
				{
					Value = 200005,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920723,
			Ability = {
				{
					Value = 200001,
					Num = 480,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100657,
					Value = 10,
				},
			},
		},
		{
			Level = 9,
			Info = 920723,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100657,
					Value = 10,
				},
			},
		},
		{
			Level = 10,
			Info = 920723,
			Ability = {
				{
					Value = 200001,
					Num = 600,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100657,
					Value = 10,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id690] =
{
	Character = 223130,
	Rarity = 3,
	NeedChallenge = 145270,
	UpgradeId = 930031,
	LevelList = {
		{
			Level = 1,
			Info = 920724,
			Ability = {
				{
					Value = 200001,
					Num = 120,
				},
			},
		},
		{
			Level = 2,
			Info = 920724,
			Ability = {
				{
					Value = 200001,
					Num = 200,
				},
			},
		},
		{
			Level = 3,
			Info = 920724,
			Ability = {
				{
					Value = 200001,
					Num = 280,
				},
			},
		},
		{
			Level = 4,
			Info = 920724,
			Ability = {
				{
					Value = 200001,
					Num = 360,
				},
			},
		},
		{
			Level = 5,
			Info = 920724,
			Ability = {
				{
					Value = 200001,
					Num = 440,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920724,
			Ability = {
				{
					Value = 200001,
					Num = 520,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920724,
			Ability = {
				{
					Value = 200001,
					Num = 600,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920724,
			Ability = {
				{
					Value = 200001,
					Num = 680,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101902,
					Value = 12,
				},
			},
		},
		{
			Level = 9,
			Info = 920724,
			Ability = {
				{
					Value = 200001,
					Num = 760,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101902,
					Value = 12,
				},
			},
		},
		{
			Level = 10,
			Info = 920724,
			Ability = {
				{
					Value = 200001,
					Num = 840,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101902,
					Value = 12,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id691] =
{
	Character = 223131,
	Rarity = 4,
	UpgradeId = 930033,
	LevelList = {
		{
			Level = 1,
			Info = 920725,
			Ability = {
				{
					Value = 200001,
					Num = 78,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920725,
			Ability = {
				{
					Value = 200001,
					Num = 156,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920725,
			Ability = {
				{
					Value = 200001,
					Num = 234,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920725,
			Ability = {
				{
					Value = 200001,
					Num = 312,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920725,
			Ability = {
				{
					Value = 200001,
					Num = 390,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920725,
			Ability = {
				{
					Value = 200001,
					Num = 468,
				},
				{
					Value = 200006,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920725,
			Ability = {
				{
					Value = 200001,
					Num = 546,
				},
				{
					Value = 200006,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920725,
			Ability = {
				{
					Value = 200001,
					Num = 624,
				},
				{
					Value = 200006,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 101701,
					Value = 252,
				},
			},
		},
		{
			Level = 9,
			Info = 920725,
			Ability = {
				{
					Value = 200001,
					Num = 702,
				},
				{
					Value = 200006,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 101701,
					Value = 252,
				},
			},
		},
		{
			Level = 10,
			Info = 920725,
			Ability = {
				{
					Value = 200001,
					Num = 780,
				},
				{
					Value = 200006,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 101701,
					Value = 252,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id692] =
{
	Character = 223131,
	Rarity = 4,
	UpgradeId = 930014,
	LevelList = {
		{
			Level = 1,
			Info = 920726,
			Ability = {
				{
					Value = 200002,
					Num = 54,
				},
				{
					Value = 200007,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920726,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920726,
			Ability = {
				{
					Value = 200002,
					Num = 162,
				},
				{
					Value = 200007,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920726,
			Ability = {
				{
					Value = 200002,
					Num = 216,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920726,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
				{
					Value = 200007,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920726,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920726,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200007,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920726,
			Ability = {
				{
					Value = 200002,
					Num = 432,
				},
				{
					Value = 200007,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 101525,
					Value = -12,
				},
			},
		},
		{
			Level = 9,
			Info = 920726,
			Ability = {
				{
					Value = 200002,
					Num = 486,
				},
				{
					Value = 200007,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 101525,
					Value = -12,
				},
			},
		},
		{
			Level = 10,
			Info = 920726,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200007,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 101525,
					Value = -12,
				},
			},
		},
	},
}
