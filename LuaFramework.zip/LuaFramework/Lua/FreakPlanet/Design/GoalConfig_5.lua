
GoalConfig[GoalID.Id1601] =
{
	Id = 1601,
	Name = "主线437 - 意外降落",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130201,
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]呜呜[-]、[62E7E7]漆漆[-]探索海洋星[FDDE40]坠落点[-]23小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 82800,
			Character = 
			{
				220001,
				220002,
			},
			Value = 130201,
		},
	},
	CompleteSpeech = 30160101,
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1602] =
{
	Id = 1602,
	Name = "主线438 - 冒险的旅费10",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130201,
		PreGoal = 
		{
			301601,
		},
	},
	GoalTrigger = 
	{
		TriggerType.DemandReward,
	},
	GoalCondition = 
	{
		{
			Name = "完成[62E7E7]委托[-]获得[FDDE40]金币[-]550000个",
			Type = ItemType.Gold,
			CountType = GoalCountType.StartNow,
			Num = 550000,
			Value = 1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1603] =
{
	Id = 1603,
	Name = "主线439 - 防潮工作",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130201,
		PreGoal = 
		{
			301602,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ExploreCost,
	},
	GoalCondition = 
	{
		{
			Name = "探索[62E7E7]坠落点[-]消耗[FDDE40]豪华便当[-]2个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 2,
			Value = 320412,
			Area = 130201,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1604] =
{
	Id = 1604,
	Name = "主线440 - 成群的海草",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130201,
		PreGoal = 
		{
			301603,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]绿草草[-]400个，建议探索23小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 400,
			Value = 242119,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1605] =
{
	Id = 1605,
	Name = "主线441 - 绿草草的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130201,
		PreGoal = 
		{
			301604,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败坠落点的[FDDE40]绿草草[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140801,
		},
	},
	CompleteSpeech = 30160501,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1606] =
{
	Id = 1606,
	Name = "主线442 - 捕捉绿草草",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130201,
		PreGoal = 
		{
			301605,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]绿草草[-]20个",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 250119,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1607] =
{
	Id = 1607,
	Name = "主线443 - 深入探索",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130201,
		PreGoal = 
		{
			301606,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "携带[62E7E7]绿草草[-]探索海洋星[FDDE40]坠落点[-]30小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 108000,
			Pet = 250119,
			Value = 130201,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1608] =
{
	Id = 1608,
	Name = "主线444 - 水元素小队",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130201,
		PreGoal = 
		{
			301607,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]50级[-][62E7E7]水元素[-][FDDE40]角色[-]5个",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 5,
			Value = -1,
			Level = 50,
			Element = 210001,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1609] =
{
	Id = 1609,
	Name = "主线445 - 奇异的歌声",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130201,
		PreGoal = 
		{
			301608,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]4个[-][62E7E7]水元素[-]队员(或宠物)的队伍探索海洋星[FDDE40]坠落点[-]30小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 108000,
			TagList = 
			{
				561202,
			},
			CharacterNum = 4,
			Value = 130201,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1610] =
{
	Id = 1610,
	Name = "主线446 - 海豚凛的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130201,
		PreGoal = 
		{
			301609,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败坠落点的[FDDE40]海豚凛[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140802,
		},
	},
	CompleteSpeech = 30161001,
	Reward = {
		{
			Value = 130202,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1611] =
{
	Id = 1611,
	Name = "主线447 - 收集海草",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130202,
		PreGoal = 
		{
			301610,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中获得[FDDE40]海草[-]400个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 400,
			Value = 321801,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1612] =
{
	Id = 1612,
	Name = "主线448 - 充足电量",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130202,
		PreGoal = 
		{
			301611,
		},
	},
	GoalTrigger = 
	{
		TriggerType.DemandReward,
	},
	GoalCondition = 
	{
		{
			Name = "完成[62E7E7]委托[-]获得[62E7E7]电池类的[-]道具20个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 20,
			TagList = 
			{
				564303,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1613] =
{
	Id = 1613,
	Name = "主线449 - 向海洋前进！",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130202,
		PreGoal = 
		{
			301612,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]30级[-][FDDE40]海豚凛[-]",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220401,
			Level = 30,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1614] =
{
	Id = 1614,
	Name = "主线450 - 免费试妆？",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130202,
		PreGoal = 
		{
			301613,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]5个[-][62E7E7]女性[-]队员(或宠物)的队伍探索海洋星[FDDE40]音乐广场[-]30小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 108000,
			TagList = 
			{
				561703,
			},
			CharacterNum = 5,
			Value = 130202,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1615] =
{
	Id = 1615,
	Name = "主线451 - 珊瑚红的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130202,
		PreGoal = 
		{
			301614,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败音乐广场的[FDDE40]珊瑚红[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140803,
		},
	},
	CompleteSpeech = 30161501,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1616] =
{
	Id = 1616,
	Name = "主线452 - 珊瑚海",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130202,
		PreGoal = 
		{
			301615,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]珊瑚红[-]240个，建议探索30小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 240,
			Value = 242121,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1617] =
{
	Id = 1617,
	Name = "主线453 - 强化装备12",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130202,
		PreGoal = 
		{
			301616,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]10级[-][FDDE40]装备[-]50个",
			Type = ItemType.Equipment,
			CountType = GoalCountType.Current,
			Num = 50,
			Value = -1,
			Level = 10,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1618] =
{
	Id = 1618,
	Name = "主线454 - 海豚凛的歌词本",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130202,
		PreGoal = 
		{
			301617,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]5级[-][FDDE40]歌词本[-](海豚凛装备)",
			Type = ItemType.Equipment,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 340380,
			Level = 5,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1619] =
{
	Id = 1619,
	Name = "主线455 - 又一次免费试妆？",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130202,
		PreGoal = 
		{
			301618,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]5个[-][62E7E7]女性[-]队员(或宠物)的队伍探索海洋星[FDDE40]音乐广场[-]36小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 129600,
			TagList = 
			{
				561703,
			},
			CharacterNum = 5,
			Value = 130202,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1620] =
{
	Id = 1620,
	Name = "主线456 - 梅子紫的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130202,
		PreGoal = 
		{
			301619,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败音乐广场的[FDDE40]梅子紫[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140804,
		},
	},
	Reward = {
		{
			Value = 130203,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1621] =
{
	Id = 1621,
	Name = "主线457 - 海底的活字典",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130203,
		PreGoal = 
		{
			301620,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]梅子紫[-]20个(需要警察局的纸袋)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 250121,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1622] =
{
	Id = 1622,
	Name = "主线458 - 歌声回绕的广场",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130203,
		PreGoal = 
		{
			301621,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]5级[-][FDDE40]麦克风[-](海豚凛装备)",
			Type = ItemType.Equipment,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 340381,
			Level = 5,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1623] =
{
	Id = 1623,
	Name = "主线459 - 收集珊瑚",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130203,
		PreGoal = 
		{
			301622,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "携带[62E7E7]梅子紫[-]在探索中获得[FDDE40]珊瑚[-]180个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 180,
			Pet = 250121,
			Value = 321802,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1624] =
{
	Id = 1624,
	Name = "主线460 - 寻找万事通",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130203,
		PreGoal = 
		{
			301623,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]3个[-][62E7E7]冒险星[-]队员(或宠物)的队伍探索海洋星[FDDE40]浅海沙滩[-]30小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 108000,
			TagList = 
			{
				560103,
			},
			CharacterNum = 3,
			Value = 130203,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1625] =
{
	Id = 1625,
	Name = "主线461 - 红贝壳的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130203,
		PreGoal = 
		{
			301624,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败浅海沙滩的[FDDE40]红贝壳[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140805,
		},
	},
	CompleteSpeech = 30162501,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1626] =
{
	Id = 1626,
	Name = "主线462 - 击败红贝壳",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130203,
		PreGoal = 
		{
			301625,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]红贝壳[-]160个，建议探索31小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 160,
			Value = 242122,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1627] =
{
	Id = 1627,
	Name = "主线463 - 提交海洋星素材",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130203,
		PreGoal = 
		{
			301626,
		},
	},
	GoalTrigger = 
	{
		TriggerType.DemandCost,
	},
	GoalCondition = 
	{
		{
			Name = "在委托中提交[62E7E7]海洋星[-]道具240个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 240,
			TagList = 
			{
				560107,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1628] =
{
	Id = 1628,
	Name = "主线464 - 捕捉红贝壳",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130203,
		PreGoal = 
		{
			301627,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]红贝壳[-]20个(需要警察局的纸袋)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 250122,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1629] =
{
	Id = 1629,
	Name = "主线465 - 红贝壳的探索",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130203,
		PreGoal = 
		{
			301628,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "携带[62E7E7]红贝壳[-]探索海洋星[FDDE40]浅海沙滩[-]30小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 108000,
			Pet = 250122,
			Value = 130203,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1630] =
{
	Id = 1630,
	Name = "主线466 - 黄贝壳的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130203,
		PreGoal = 
		{
			301629,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败浅海沙滩的[FDDE40]黄贝壳[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140806,
		},
	},
	CompleteSpeech = 30163001,
	Reward = {
		{
			Value = 130205,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1631] =
{
	Id = 1631,
	Name = "主线467 - 新的团员",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130205,
		PreGoal = 
		{
			301630,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]海豚凛[-]探索海洋星[FDDE40]回溯镇[-]30小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 108000,
			Character = 
			{
				220401,
			},
			Value = 130205,
		},
	},
	CompleteSpeech = 30163101,
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1632] =
{
	Id = 1632,
	Name = "主线468 - 寻找听众",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130205,
		PreGoal = 
		{
			301631,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]梅子紫[-]250个，建议探索31小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 250,
			Value = 242120,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1633] =
{
	Id = 1633,
	Name = "主线469 - 强制征集听众",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130205,
		PreGoal = 
		{
			301632,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]黄贝壳[-]15个",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 15,
			Value = 250123,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1634] =
{
	Id = 1634,
	Name = "主线470 - 出逃的“少女”",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130205,
		PreGoal = 
		{
			301633,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "携带[62E7E7]黄贝壳[-]在探索中获得[FDDE40]黑珍珠[-]130个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 130,
			Pet = 250123,
			Value = 321803,
		},
	},
	CompleteSpeech = 30163401,
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1635] =
{
	Id = 1635,
	Name = "主线471 - 红草草的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130205,
		PreGoal = 
		{
			301634,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败回溯镇的[FDDE40]红草草[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140810,
		},
	},
	CompleteSpeech = 30163501,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1636] =
{
	Id = 1636,
	Name = "主线472 - 红草草与绿草草",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130205,
		PreGoal = 
		{
			301635,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "携带[62E7E7]绿草草[-]在探索中击败[FDDE40]红草草[-]360个，建议探索32小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 360,
			Pet = 250119,
			Value = 242126,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1637] =
{
	Id = 1637,
	Name = "主线473 - 不一样的海草",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130205,
		PreGoal = 
		{
			301636,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中获得[FDDE40]海草[-]350个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 350,
			Value = 321801,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1638] =
{
	Id = 1638,
	Name = "主线474 - 扣押红草草",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130205,
		PreGoal = 
		{
			301637,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]红草草[-]20个(需要道具店的陷阱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 250126,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1639] =
{
	Id = 1639,
	Name = "主线475 - 奇怪的地区",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130205,
		PreGoal = 
		{
			301638,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]猎人[-]、[62E7E7]海豚凛[-]探索海洋星[FDDE40]回溯镇[-]32小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 115200,
			Character = 
			{
				220005,
				220401,
			},
			Value = 130205,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1640] =
{
	Id = 1640,
	Name = "主线476 - 海参的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130205,
		PreGoal = 
		{
			301639,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败回溯镇的[FDDE40]海参[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140811,
		},
	},
	CompleteSpeech = 30164001,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1641] =
{
	Id = 1641,
	Name = "主线477 - 喷水的怪物",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130205,
		PreGoal = 
		{
			301640,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]海参[-]130个，建议探索32小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 130,
			Value = 242127,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1642] =
{
	Id = 1642,
	Name = "主线478 - 研究喷水结构",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130205,
		PreGoal = 
		{
			301641,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]海参[-]20个(需要道具店的陷阱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 250127,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1643] =
{
	Id = 1643,
	Name = "主线479 - 抵抗热浪",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130205,
		PreGoal = 
		{
			301642,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]50级[-][62E7E7]火元素[-][FDDE40]角色[-]5个",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 5,
			Value = -1,
			Level = 50,
			Element = 210002,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1644] =
{
	Id = 1644,
	Name = "主线480 - 海底的火山",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130205,
		PreGoal = 
		{
			301643,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]3个[-][62E7E7]火元素[-]队员(或宠物)的队伍探索海洋星[FDDE40]回溯镇[-]32小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 115200,
			TagList = 
			{
				561203,
			},
			CharacterNum = 3,
			Value = 130205,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1645] =
{
	Id = 1645,
	Name = "主线481 - 火山海参的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130205,
		PreGoal = 
		{
			301644,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败回溯镇的[FDDE40]火山海参[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140812,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1646] =
{
	Id = 1646,
	Name = "主线482 - 回溯的热潮",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130205,
		PreGoal = 
		{
			301645,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]火山海参[-]38个，建议探索33小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 38,
			Value = 242128,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1647] =
{
	Id = 1647,
	Name = "主线483 - 回收毛巾",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130205,
		PreGoal = 
		{
			301646,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中获得[FDDE40]应援毛巾[-]200个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 200,
			Value = 321805,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1648] =
{
	Id = 1648,
	Name = "主线484 - 应援团的捐赠",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130205,
		PreGoal = 
		{
			301647,
		},
	},
	GoalTrigger = 
	{
		TriggerType.DemandCost,
	},
	GoalCondition = 
	{
		{
			Name = "在委托中提交[FDDE40]应援毛巾[-]130个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 130,
			Value = 321805,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1649] =
{
	Id = 1649,
	Name = "主线485 - 无人的演唱会",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130205,
		PreGoal = 
		{
			301648,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]海豚凛[-]探索海洋星[FDDE40]回溯镇[-]32小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 115200,
			Character = 
			{
				220401,
			},
			Value = 130205,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1650] =
{
	Id = 1650,
	Name = "主线486 - 乌贼墨的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130205,
		PreGoal = 
		{
			301649,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败回溯镇的[FDDE40]乌贼墨[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140813,
		},
	},
	CompleteSpeech = 30165001,
	Reward = {
		{
			Value = 130206,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1651] =
{
	Id = 1651,
	Name = "主线487 - 清理海草",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130206,
		PreGoal = 
		{
			301650,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "探索[62E7E7]礁石区[-]击败[FDDE40]绿草草[-]400个，建议探索36小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 400,
			Value = 242119,
			Area = 130206,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1652] =
{
	Id = 1652,
	Name = "主线488 - 可爱的乌贼小姐",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130206,
		PreGoal = 
		{
			301651,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]40级[-][FDDE40]乌贼墨[-]",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220402,
			Level = 40,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1653] =
{
	Id = 1653,
	Name = "主线489 - 逃生必备",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130206,
		PreGoal = 
		{
			301652,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]5级[-][FDDE40]墨色水枪[-](乌贼墨装备)",
			Type = ItemType.Equipment,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 340421,
			Level = 5,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1654] =
{
	Id = 1654,
	Name = "主线490 - 探索礁石区",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130206,
		PreGoal = 
		{
			301653,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]乌贼墨[-]探索海洋星[FDDE40]礁石区[-]36小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 129600,
			Character = 
			{
				220402,
			},
			Value = 130206,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1655] =
{
	Id = 1655,
	Name = "主线491 - 绿礁保安的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130206,
		PreGoal = 
		{
			301654,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败礁石区的[FDDE40]绿礁保安[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140814,
		},
	},
	CompleteSpeech = 30165501,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1656] =
{
	Id = 1656,
	Name = "主线492 - 被包围了？！",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130206,
		PreGoal = 
		{
			301655,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]绿礁保安[-]145个，建议探索36小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 145,
			Value = 242129,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1657] =
{
	Id = 1657,
	Name = "主线493 - “挟持”保安",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130206,
		PreGoal = 
		{
			301656,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]绿礁保安[-]20个(需要事务所的工具箱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 250129,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1658] =
{
	Id = 1658,
	Name = "主线494 - 礁石保安的武器",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130206,
		PreGoal = 
		{
			301657,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中获得[FDDE40]礁石[-]130个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 130,
			Value = 321806,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1659] =
{
	Id = 1659,
	Name = "主线495 - 深入礁石区",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130206,
		PreGoal = 
		{
			301658,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "携带[62E7E7]绿礁保安[-]探索海洋星[FDDE40]礁石区[-]36小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 129600,
			Pet = 250129,
			Value = 130206,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1660] =
{
	Id = 1660,
	Name = "主线496 - 蓝礁保安的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130206,
		PreGoal = 
		{
			301659,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败礁石区的[FDDE40]蓝礁保安[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140815,
		},
	},
	CompleteSpeech = 30166001,
	Reward = {
		{
			Value = 130207,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1661] =
{
	Id = 1661,
	Name = "主线497 - 不安分的触手",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130207,
		PreGoal = 
		{
			301660,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]鱿鱼[-]300个，建议探索37小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 300,
			Value = 242124,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1662] =
{
	Id = 1662,
	Name = "主线498 - 确保音质的装备",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130207,
		PreGoal = 
		{
			301661,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]8级[-][FDDE40]歌词本[-](海豚凛装备)",
			Type = ItemType.Equipment,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 340380,
			Level = 8,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1663] =
{
	Id = 1663,
	Name = "主线499 - 破浪而行",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130207,
		PreGoal = 
		{
			301662,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]50级[-][62E7E7]风元素[-][FDDE40]角色[-]5个",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 5,
			Value = -1,
			Level = 50,
			Element = 210003,
		},
	},
	CompleteSpeech = 30166301,
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1664] =
{
	Id = 1664,
	Name = "主线500 - 前往的士站",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130207,
		PreGoal = 
		{
			301663,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]2个[-][62E7E7]风元素[-]队员(或宠物)的队伍探索海洋星[FDDE40]星光小道[-]36小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 129600,
			TagList = 
			{
				561204,
			},
			CharacterNum = 2,
			Value = 130207,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1665] =
{
	Id = 1665,
	Name = "主线501 - 比目司机的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130207,
		PreGoal = 
		{
			301664,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败星光小道的[FDDE40]比目司机[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140816,
		},
	},
	CompleteSpeech = 30166501,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1666] =
{
	Id = 1666,
	Name = "主线502 - 教训黑车帮1",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130207,
		PreGoal = 
		{
			301665,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]比目司机[-]195个，建议探索37小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 195,
			Value = 242131,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1667] =
{
	Id = 1667,
	Name = "主线503 - 逮捕黑司机",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130207,
		PreGoal = 
		{
			301666,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]比目司机[-]20个(需要警察局的纸袋)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 250131,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1668] =
{
	Id = 1668,
	Name = "主线504 - 研究鱼鳞",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130207,
		PreGoal = 
		{
			301667,
		},
	},
	GoalTrigger = 
	{
		TriggerType.DemandCost,
	},
	GoalCondition = 
	{
		{
			Name = "在委托中提交[FDDE40]鱼鳞[-]180个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 180,
			Value = 321807,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1669] =
{
	Id = 1669,
	Name = "主线505 - 拼车出行",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130207,
		PreGoal = 
		{
			301668,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "携带[62E7E7]比目司机[-]探索海洋星[FDDE40]星光小道[-]36小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 129600,
			Pet = 250131,
			Value = 130207,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1670] =
{
	Id = 1670,
	Name = "主线506 - 小丑司机的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130207,
		PreGoal = 
		{
			301669,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败星光小道的[FDDE40]小丑司机[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140817,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1671] =
{
	Id = 1671,
	Name = "主线507 - 诡异的路线",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130207,
		PreGoal = 
		{
			301670,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]小丑司机[-]50个，建议探索37小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 50,
			Value = 242132,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1672] =
{
	Id = 1672,
	Name = "主线508 - 绕路的秘密",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130207,
		PreGoal = 
		{
			301671,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]小丑司机[-]12个(需要警察局的纸袋)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 12,
			Value = 250132,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1673] =
{
	Id = 1673,
	Name = "主线509 - 冒险的旅费11",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130207,
		PreGoal = 
		{
			301672,
		},
	},
	GoalTrigger = 
	{
		TriggerType.DemandReward,
	},
	GoalCondition = 
	{
		{
			Name = "完成[62E7E7]委托[-]获得[FDDE40]金币[-]700000个",
			Type = ItemType.Gold,
			CountType = GoalCountType.StartNow,
			Num = 700000,
			Value = 1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1674] =
{
	Id = 1674,
	Name = "主线510 - 直达目的地",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130207,
		PreGoal = 
		{
			301673,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "携带[62E7E7]小丑司机[-]探索海洋星[FDDE40]星光小道[-]36小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 129600,
			Pet = 250132,
			Value = 130207,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1675] =
{
	Id = 1675,
	Name = "主线511 - 神仙司机的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130207,
		PreGoal = 
		{
			301674,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败星光小道的[FDDE40]神仙司机[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140818,
		},
	},
	Reward = {
		{
			Value = 130209,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1676] =
{
	Id = 1676,
	Name = "主线512 - 教训黑车帮2",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130209,
		PreGoal = 
		{
			301675,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]比目司机[-]290个，建议探索36小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 290,
			Value = 242131,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1677] =
{
	Id = 1677,
	Name = "主线513 - 强化装备13",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130209,
		PreGoal = 
		{
			301676,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]10级[-][FDDE40]装备[-]60个",
			Type = ItemType.Equipment,
			CountType = GoalCountType.Current,
			Num = 60,
			Value = -1,
			Level = 10,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1678] =
{
	Id = 1678,
	Name = "主线514 - 伪装搬家队",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130209,
		PreGoal = 
		{
			301677,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Craft,
	},
	GoalCondition = 
	{
		{
			Name = "在实验室合成获得[FDDE40]加固纸板箱[-]8个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 8,
			Value = 320319,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1679] =
{
	Id = 1679,
	Name = "主线515 - 寻找莱斯莉",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130209,
		PreGoal = 
		{
			301678,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]海豚凛[-]探索海洋星[FDDE40]演播厅[-]36小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 129600,
			Character = 
			{
				220401,
			},
			Value = 130209,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1680] =
{
	Id = 1680,
	Name = "主线516 - 海蛇的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130209,
		PreGoal = 
		{
			301679,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败演播厅的[FDDE40]海蛇[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140822,
		},
	},
	CompleteSpeech = 30168001,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1681] =
{
	Id = 1681,
	Name = "主线517 - 剧毒之舞",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130209,
		PreGoal = 
		{
			301680,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]海蛇[-]200个，建议探索38小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 200,
			Value = 242137,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1682] =
{
	Id = 1682,
	Name = "主线518 - 最佳伴舞",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130209,
		PreGoal = 
		{
			301681,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]海蛇[-]20个(需要超市的空瓶)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 250137,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1683] =
{
	Id = 1683,
	Name = "主线519 - 摇滚风暴",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130209,
		PreGoal = 
		{
			301682,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中获得[FDDE40]摇滚耳机[-]180个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 180,
			Value = 321809,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1684] =
{
	Id = 1684,
	Name = "主线520 - 演播厅的闪电",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130209,
		PreGoal = 
		{
			301683,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "携带[62E7E7]海蛇[-]探索海洋星[FDDE40]演播厅[-]36小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 129600,
			Pet = 250137,
			Value = 130209,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1685] =
{
	Id = 1685,
	Name = "主线521 - 闪电海蛇的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130209,
		PreGoal = 
		{
			301684,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败演播厅的[FDDE40]闪电海蛇[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140823,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1686] =
{
	Id = 1686,
	Name = "主线522 - 摇滚专家",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130209,
		PreGoal = 
		{
			301685,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]闪电海蛇[-]20个，建议探索39小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 20,
			Value = 242138,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1687] =
{
	Id = 1687,
	Name = "主线523 - 捕捉闪电！",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130209,
		PreGoal = 
		{
			301686,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Craft,
	},
	GoalCondition = 
	{
		{
			Name = "在实验室合成获得[FDDE40]精灵瓶[-]10个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 10,
			Value = 320307,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1688] =
{
	Id = 1688,
	Name = "主线524 - 演唱会的新成员",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130209,
		PreGoal = 
		{
			301687,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]闪电海蛇[-]10个(需要超市的空瓶)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 10,
			Value = 250138,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1689] =
{
	Id = 1689,
	Name = "主线525 - 强烈的电流！",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130209,
		PreGoal = 
		{
			301688,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "携带[62E7E7]闪电海蛇[-]探索海洋星[FDDE40]演播厅[-]36小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 129600,
			Pet = 250138,
			Value = 130209,
		},
	},
	CompleteSpeech = 30168901,
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1690] =
{
	Id = 1690,
	Name = "主线526 - 电鳗伊俄的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130209,
		PreGoal = 
		{
			301689,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败演播厅的[FDDE40]电鳗伊俄[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140824,
		},
	},
	CompleteSpeech = 30169001,
	Reward = {
		{
			Value = 130211,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1691] =
{
	Id = 1691,
	Name = "主线527 - 顽强的生物",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130211,
		PreGoal = 
		{
			301690,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]水熊虫[-]200个，建议探索42小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 200,
			Value = 242141,
		},
	},
	CompleteSpeech = 30169101,
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1692] =
{
	Id = 1692,
	Name = "主线528 - 升级电鳗伊俄",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130211,
		PreGoal = 
		{
			301691,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]40级[-][FDDE40]电鳗伊俄[-]",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220403,
			Level = 40,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1693] =
{
	Id = 1693,
	Name = "主线529 - 深入暗海",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130211,
		PreGoal = 
		{
			301692,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]3阶[-][62E7E7]暗元素[-][FDDE40]角色[-]5个",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 5,
			Value = -1,
			Stage = 3,
			Element = 210005,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1694] =
{
	Id = 1694,
	Name = "主线530 - 光与暗的舞台",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130211,
		PreGoal = 
		{
			301693,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]电鳗伊俄[-]探索海洋星[FDDE40]大舞台[-]36小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 129600,
			Character = 
			{
				220403,
			},
			Value = 130211,
		},
	},
	CompleteSpeech = 30169401,
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1695] =
{
	Id = 1695,
	Name = "主线531 - 水熊虫的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130211,
		PreGoal = 
		{
			301694,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败大舞台的[FDDE40]水熊虫[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140827,
		},
	},
	CompleteSpeech = 30169501,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1696] =
{
	Id = 1696,
	Name = "主线532 - 海中的蒲公英",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130211,
		PreGoal = 
		{
			301695,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]蓝记水母[-]200个，建议探索42小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 200,
			Value = 242134,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1697] =
{
	Id = 1697,
	Name = "主线533 - 研究水熊虫",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130211,
		PreGoal = 
		{
			301696,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]水熊虫[-]20个(需要超市的空瓶)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 250141,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1698] =
{
	Id = 1698,
	Name = "主线534 - 事务所打工4",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130211,
		PreGoal = 
		{
			301697,
		},
	},
	GoalTrigger = 
	{
		TriggerType.WorkShopRank,
	},
	GoalCondition = 
	{
		{
			Name = "在[FDDE40]事务所[-]打工获得[FDDE40]S[-]或更高评价",
			Type = ItemType.WorkShop,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 160004,
			Rank = 21,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1699] =
{
	Id = 1699,
	Name = "主线535 - 蟹经理的手下",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130211,
		PreGoal = 
		{
			301698,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "携带[62E7E7]水熊虫[-]探索海洋星[FDDE40]大舞台[-]36小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 129600,
			Pet = 250141,
			Value = 130211,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1700] =
{
	Id = 1700,
	Name = "主线536 - 绿绵宝宝的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130211,
		PreGoal = 
		{
			301699,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败大舞台的[FDDE40]绿绵宝宝[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140828,
		},
	},
	CompleteSpeech = 30170001,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1701] =
{
	Id = 1701,
	Name = "主线537 - 击败绿绵宝宝",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130211,
		PreGoal = 
		{
			301700,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]绿绵宝宝[-]150个，建议探索41小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 150,
			Value = 242142,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1702] =
{
	Id = 1702,
	Name = "主线538 - 收集导电素材",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130211,
		PreGoal = 
		{
			301701,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中获得[FDDE40]强力海绵[-]100个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 100,
			Value = 321811,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1703] =
{
	Id = 1703,
	Name = "主线539 - 大号发电机",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130211,
		PreGoal = 
		{
			301702,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]5级[-][FDDE40]发电机[-](电鳗伊俄装备)",
			Type = ItemType.Equipment,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 340433,
			Level = 5,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1704] =
{
	Id = 1704,
	Name = "主线540 - 闪耀的大舞台",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130211,
		PreGoal = 
		{
			301703,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]海豚凛[-]、[62E7E7]乌贼墨[-]探索海洋星[FDDE40]大舞台[-]48小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 172800,
			Character = 
			{
				220401,
				220402,
			},
			Value = 130211,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1705] =
{
	Id = 1705,
	Name = "主线541 - 红绵宝宝的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130211,
		PreGoal = 
		{
			301704,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败大舞台的[FDDE40]红绵宝宝[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140829,
		},
	},
	Reward = {
		{
			Value = 130212,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1706] =
{
	Id = 1706,
	Name = "主线542 - 又绕路了！",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130212,
		PreGoal = 
		{
			301705,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "探索[62E7E7]高音剧场[-]击败[FDDE40]小丑司机[-]75个，建议探索42小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 75,
			Value = 242132,
			Area = 130212,
		},
	},
	CompleteSpeech = 30170601,
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1707] =
{
	Id = 1707,
	Name = "主线543 - 海绵的原理",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130212,
		PreGoal = 
		{
			301706,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]红绵宝宝[-]20个(需要警察局的纸袋)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 250143,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1708] =
{
	Id = 1708,
	Name = "主线544 - 探索高音剧场",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130212,
		PreGoal = 
		{
			301707,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "携带[62E7E7]红绵宝宝[-]探索海洋星[FDDE40]高音剧场[-]36小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 129600,
			Pet = 250143,
			Value = 130212,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1709] =
{
	Id = 1709,
	Name = "主线545 - 免费饮料",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130212,
		PreGoal = 
		{
			301708,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]8级[-][FDDE40]海事可乐[-](乌贼墨装备)",
			Type = ItemType.Equipment,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 340420,
			Level = 8,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1710] =
{
	Id = 1710,
	Name = "主线546 - 蓝海葵的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130212,
		PreGoal = 
		{
			301709,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败高音剧场的[FDDE40]蓝海葵[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140830,
		},
	},
	CompleteSpeech = 30171001,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1711] =
{
	Id = 1711,
	Name = "主线547 - 恶劣的经纪人",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130212,
		PreGoal = 
		{
			301710,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]蓝海葵[-]145个，建议探索42小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 145,
			Value = 242145,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1712] =
{
	Id = 1712,
	Name = "主线548 - 逮捕无证经纪人",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130212,
		PreGoal = 
		{
			301711,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]蓝海葵[-]15个(需要事务所的纸板箱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 15,
			Value = 250145,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1713] =
{
	Id = 1713,
	Name = "主线549 - 冒险家的日常",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130212,
		PreGoal = 
		{
			301712,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CompleteDemand,
	},
	GoalCondition = 
	{
		{
			Name = "完成[62E7E7]任意[-][FDDE40]委托[-]15次",
			Type = ItemType.Demand,
			CountType = GoalCountType.StartNow,
			Num = 15,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1714] =
{
	Id = 1714,
	Name = "主线550 - 深入高音剧场",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130212,
		PreGoal = 
		{
			301713,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "携带[62E7E7]蓝海葵[-]探索海洋星[FDDE40]高音剧场[-]36小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 129600,
			Pet = 250145,
			Value = 130212,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1715] =
{
	Id = 1715,
	Name = "主线551 - 红海葵的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130212,
		PreGoal = 
		{
			301714,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败高音剧场的[FDDE40]红海葵[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140831,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1716] =
{
	Id = 1716,
	Name = "主线552 - 击败红海葵",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130212,
		PreGoal = 
		{
			301715,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]红海葵[-]120个，建议探索43小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 120,
			Value = 242144,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1717] =
{
	Id = 1717,
	Name = "主线553 - 荧光飞舞",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130212,
		PreGoal = 
		{
			301716,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中获得[FDDE40]应援棒[-]150个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 150,
			Value = 321812,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1718] =
{
	Id = 1718,
	Name = "主线554 - 应援团大礼包",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130212,
		PreGoal = 
		{
			301717,
		},
	},
	GoalTrigger = 
	{
		TriggerType.DemandCost,
	},
	GoalCondition = 
	{
		{
			Name = "在委托中提交[62E7E7]应援类[-]道具233个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 233,
			TagList = 
			{
				564502,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1719] =
{
	Id = 1719,
	Name = "主线555 - 外星的偶像？",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130212,
		PreGoal = 
		{
			301718,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]4个[-][62E7E7]海洋星[-]队员(或宠物)的队伍探索海洋星[FDDE40]高音剧场[-]36小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 129600,
			TagList = 
			{
				560107,
			},
			CharacterNum = 4,
			Value = 130212,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1720] =
{
	Id = 1720,
	Name = "主线556 - 鲎椰子的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130212,
		PreGoal = 
		{
			301719,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败高音剧场的[FDDE40]鲎椰子[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140832,
		},
	},
	CompleteSpeech = 30172001,
	Reward = {
		{
			Value = 130213,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1721] =
{
	Id = 1721,
	Name = "主线557 - 击败海星星",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130213,
		PreGoal = 
		{
			301720,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]海星星[-]220个，建议探索42小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 220,
			Value = 242139,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1722] =
{
	Id = 1722,
	Name = "主线558 - 升级鲎椰子",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130213,
		PreGoal = 
		{
			301721,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]40级[-][FDDE40]鲎椰子[-]",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220404,
			Level = 40,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1723] =
{
	Id = 1723,
	Name = "主线559 - 成长的海豚凛",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130213,
		PreGoal = 
		{
			301722,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]50级[-][FDDE40]海豚凛[-]",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220401,
			Level = 50,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1724] =
{
	Id = 1724,
	Name = "主线560 - 前往经理室",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130213,
		PreGoal = 
		{
			301723,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]海豚凛[-]、[62E7E7]鲎椰子[-]探索海洋星[FDDE40]海底世界[-]36小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 129600,
			Character = 
			{
				220401,
				220404,
			},
			Value = 130213,
		},
	},
	CompleteSpeech = 30172401,
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1725] =
{
	Id = 1725,
	Name = "主线561 - 蟹经理的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130213,
		PreGoal = 
		{
			301724,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败海底世界的[FDDE40]蟹经理[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140833,
		},
	},
	CompleteSpeech = 30172501,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1726] =
{
	Id = 1726,
	Name = "主线562 - 可恶的蟹经理",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130213,
		PreGoal = 
		{
			301725,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]蟹经理[-]60个，建议探索44小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 60,
			Value = 242146,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1727] =
{
	Id = 1727,
	Name = "主线563 - 惊声尖叫",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130213,
		PreGoal = 
		{
			301726,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中获得[FDDE40]尖叫[-]200个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 200,
			Value = 321813,
		},
	},
	CompleteSpeech = 30172701,
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1728] =
{
	Id = 1728,
	Name = "主线564 - 逮捕蟹经理",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130213,
		PreGoal = 
		{
			301727,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]蟹经理[-]20个(需要事务所的工具箱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 250146,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1729] =
{
	Id = 1729,
	Name = "主线565 - 勇闯董事局",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130213,
		PreGoal = 
		{
			301728,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]海豚凛[-]探索海洋星[FDDE40]海底世界[-]40小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 144000,
			Character = 
			{
				220401,
			},
			Value = 130213,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1730] =
{
	Id = 1730,
	Name = "主线566 - 蟹董事的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130213,
		PreGoal = 
		{
			301729,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败海底世界的[FDDE40]蟹董事[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140834,
		},
	},
	CompleteSpeech = 30173001,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1901] =
{
	Id = 1901,
	Name = "解锁：休息厅",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130202,
		PreGoal = 
		{
			301620,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "提交[FDDE40]海草[-]40个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 40,
			Value = 321801,
		},
	},
	Reward = {
		{
			Value = 130204,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1902] =
{
	Id = 1902,
	Name = "支线-突破珊瑚墙",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130204,
		PreGoal = 
		{
			301901,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "探索[62E7E7]休息厅[-]击败[FDDE40]珊瑚红[-]500个，建议探索34小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 500,
			Value = 242121,
			Area = 130204,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1903] =
{
	Id = 1903,
	Name = "支线-铬人的珊瑚",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130204,
		PreGoal = 
		{
			301902,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]珊瑚红[-]25个(需要警察局的纸袋)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 25,
			Value = 250120,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1904] =
{
	Id = 1904,
	Name = "支线-休息厅的饰品",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130204,
		PreGoal = 
		{
			301903,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中获得[FDDE40]珊瑚[-]300个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 300,
			Value = 321802,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1905] =
{
	Id = 1905,
	Name = "支线-深海怪兽？",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130204,
		PreGoal = 
		{
			301904,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "携带[62E7E7]珊瑚红[-]探索海洋星[FDDE40]休息厅[-]36小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 129600,
			Pet = 250120,
			Value = 130204,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1906] =
{
	Id = 1906,
	Name = "支线-鱿鱼的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130204,
		PreGoal = 
		{
			301905,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败休息厅的[FDDE40]鱿鱼[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140807,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1907] =
{
	Id = 1907,
	Name = "支线-缠绕飞船的凶手",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130204,
		PreGoal = 
		{
			301906,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]鱿鱼[-]250个，建议探索34小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 250,
			Value = 242124,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1908] =
{
	Id = 1908,
	Name = "支线-捕捉怪物？",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130204,
		PreGoal = 
		{
			301907,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]鱿鱼[-]20个(需要道具店的陷阱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 250124,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1909] =
{
	Id = 1909,
	Name = "支线-修复发动机",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130204,
		PreGoal = 
		{
			301908,
		},
	},
	GoalTrigger = 
	{
		TriggerType.DemandReward,
	},
	GoalCondition = 
	{
		{
			Name = "完成委托获得[FDDE40]固化零件A[-]30个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 30,
			Value = 320054,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1910] =
{
	Id = 1910,
	Name = "支线-触手网",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130204,
		PreGoal = 
		{
			301909,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "携带[62E7E7]鱿鱼[-]探索海洋星[FDDE40]休息厅[-]36小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 129600,
			Pet = 250124,
			Value = 130204,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1911] =
{
	Id = 1911,
	Name = "支线-章鱼的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130204,
		PreGoal = 
		{
			301910,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败休息厅的[FDDE40]章鱼[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140808,
		},
	},
	CompleteSpeech = 30191101,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1912] =
{
	Id = 1912,
	Name = "支线-海怪来了！",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130204,
		PreGoal = 
		{
			301911,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]章鱼[-]20个，建议探索39小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 20,
			Value = 242125,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1913] =
{
	Id = 1913,
	Name = "支线-怪物的武器",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130204,
		PreGoal = 
		{
			301912,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中获得[FDDE40]怪物触手[-]200个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 200,
			Value = 321804,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1914] =
{
	Id = 1914,
	Name = "支线-研究海怪",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130204,
		PreGoal = 
		{
			301913,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]章鱼[-]10个(需要道具店的陷阱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 10,
			Value = 250125,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1915] =
{
	Id = 1915,
	Name = "支线-会生气的鱼？",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130204,
		PreGoal = 
		{
			301914,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "携带[62E7E7]章鱼[-]探索海洋星[FDDE40]休息厅[-]48小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 172800,
			Pet = 250125,
			Value = 130204,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1916] =
{
	Id = 1916,
	Name = "支线-刺豚茉白的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130204,
		PreGoal = 
		{
			301915,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败休息厅的[FDDE40]刺豚茉白[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140809,
		},
	},
	CompleteSpeech = 30191601,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1917] =
{
	Id = 1917,
	Name = "解锁：深海区",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130206,
		PreGoal = 
		{
			301660,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "提交[FDDE40]礁石[-]40个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 40,
			Value = 321806,
		},
	},
	Reward = {
		{
			Value = 130208,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1918] =
{
	Id = 1918,
	Name = "支线-深海的风景",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130208,
		PreGoal = 
		{
			301917,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "探索[62E7E7]深海区[-]击败[FDDE40]海参[-]180个，建议探索34小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 180,
			Value = 242127,
			Area = 130208,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1919] =
{
	Id = 1919,
	Name = "支线-海底的保安",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130208,
		PreGoal = 
		{
			301918,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "探索[62E7E7]深海区[-]击败[FDDE40]绿礁保安[-]180个，建议探索34小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 180,
			Value = 242129,
			Area = 130208,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1920] =
{
	Id = 1920,
	Name = "支线-任意高级委托",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130208,
		PreGoal = 
		{
			301919,
		},
	},
	GoalTrigger = 
	{
		TriggerType.DemandCost,
	},
	GoalCondition = 
	{
		{
			Name = "在委托中提交[62E7E7]合成的[-]道具50个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 50,
			TagList = 
			{
				560005,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1921] =
{
	Id = 1921,
	Name = "支线-海底的狗仔队",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130208,
		PreGoal = 
		{
			301920,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]5个[-][62E7E7]非海洋星[-]队员(或宠物)的队伍探索海洋星[FDDE40]深海区[-]36小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 129600,
			TagList = 
			{
				560207,
			},
			CharacterNum = 5,
			Value = 130208,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1922] =
{
	Id = 1922,
	Name = "支线-蓝记水母的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130208,
		PreGoal = 
		{
			301921,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败深海区的[FDDE40]蓝记水母[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140819,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1923] =
{
	Id = 1923,
	Name = "支线-甩不掉的记者1",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130208,
		PreGoal = 
		{
			301922,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]蓝记水母[-]140个，建议探索39小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 140,
			Value = 242134,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1924] =
{
	Id = 1924,
	Name = "支线-逮捕偷拍者1",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130208,
		PreGoal = 
		{
			301923,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]蓝记水母[-]20个(需要超市的空瓶)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 250134,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1925] =
{
	Id = 1925,
	Name = "支线-生气的鱼类",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130208,
		PreGoal = 
		{
			301924,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]40级[-][FDDE40]刺豚茉白[-]",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220405,
			Level = 40,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1926] =
{
	Id = 1926,
	Name = "支线-探索深海区",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130208,
		PreGoal = 
		{
			301925,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]刺豚茉白[-]探索海洋星[FDDE40]深海区[-]36小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 129600,
			Character = 
			{
				220405,
			},
			Value = 130208,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1927] =
{
	Id = 1927,
	Name = "支线-紫记水母的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130208,
		PreGoal = 
		{
			301926,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败深海区的[FDDE40]紫记水母[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140820,
		},
	},
	CompleteSpeech = 30192701,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1928] =
{
	Id = 1928,
	Name = "支线-甩不掉的记者2",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130208,
		PreGoal = 
		{
			301927,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]紫记水母[-]42个，建议探索40小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 42,
			Value = 242135,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1929] =
{
	Id = 1929,
	Name = "支线-缴获偷拍工具",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130208,
		PreGoal = 
		{
			301928,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中获得[FDDE40]防水相机[-]150个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 150,
			Value = 321808,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1930] =
{
	Id = 1930,
	Name = "支线-深入深海区",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130208,
		PreGoal = 
		{
			301929,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "携带[62E7E7]蓝记水母[-]探索海洋星[FDDE40]深海区[-]36小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 129600,
			Pet = 250134,
			Value = 130208,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1931] =
{
	Id = 1931,
	Name = "支线-逮捕偷拍者2",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130208,
		PreGoal = 
		{
			301930,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]紫记水母[-]20个(需要超市的空瓶)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 250135,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1932] =
{
	Id = 1932,
	Name = "支线-黄记水母的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130208,
		PreGoal = 
		{
			301931,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败深海区的[FDDE40]黄记水母[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140821,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1933] =
{
	Id = 1933,
	Name = "解锁：面试舞台",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130207,
		PreGoal = 
		{
			301675,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "提交[FDDE40]鱼鳞[-]40个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 40,
			Value = 321807,
		},
	},
	Reward = {
		{
			Value = 130210,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1934] =
{
	Id = 1934,
	Name = "支线-狂热的面试者",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130210,
		PreGoal = 
		{
			301933,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "探索[62E7E7]面试舞台[-]击败[FDDE40]海蛇[-]200个，建议探索42小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 200,
			Value = 242137,
			Area = 130210,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1935] =
{
	Id = 1935,
	Name = "支线-偷偷混入的记者",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130210,
		PreGoal = 
		{
			301934,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "探索[62E7E7]面试舞台[-]击败[FDDE40]蓝记水母[-]200个，建议探索42小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 200,
			Value = 242134,
			Area = 130210,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1936] =
{
	Id = 1936,
	Name = "支线-记者头目",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130210,
		PreGoal = 
		{
			301935,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]黄记水母[-]10个(需要超市的空瓶)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 10,
			Value = 250136,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1937] =
{
	Id = 1937,
	Name = "支线-探索面试舞台",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130210,
		PreGoal = 
		{
			301936,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "携带[62E7E7]黄记水母[-]探索海洋星[FDDE40]面试舞台[-]36小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 129600,
			Pet = 250136,
			Value = 130210,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1938] =
{
	Id = 1938,
	Name = "支线-海星星的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130210,
		PreGoal = 
		{
			301937,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败面试舞台的[FDDE40]海星星[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140825,
		},
	},
	CompleteSpeech = 30193801,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1939] =
{
	Id = 1939,
	Name = "支线-寻找面试场地",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130210,
		PreGoal = 
		{
			301938,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "探索[62E7E7]面试舞台[-]击败[FDDE40]海星星[-]150个，建议探索41小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 150,
			Value = 242139,
			Area = 130210,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1940] =
{
	Id = 1940,
	Name = "支线-失窃的队员服",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130210,
		PreGoal = 
		{
			301939,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中获得[FDDE40]队员服[-]150个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 150,
			Value = 321810,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1941] =
{
	Id = 1941,
	Name = "支线-偷衣服的小偷",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130210,
		PreGoal = 
		{
			301940,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]海星星[-]20个(需要道具店的陷阱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 250139,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1942] =
{
	Id = 1942,
	Name = "支线-正式面试",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130210,
		PreGoal = 
		{
			301941,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "携带[62E7E7]海星星[-]探索海洋星[FDDE40]面试舞台[-]36小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 129600,
			Pet = 250139,
			Value = 130210,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1943] =
{
	Id = 1943,
	Name = "支线-皇冠星探的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130210,
		PreGoal = 
		{
			301942,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败面试舞台的[FDDE40]皇冠星探[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140826,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1944] =
{
	Id = 1944,
	Name = "解锁：大漩涡",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130213,
		PreGoal = 
		{
			301730,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有[62E7E7]海洋星[-][FDDE40]角色[-]15个",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 15,
			TagList = 
			{
				560107,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 130214,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1945] =
{
	Id = 1945,
	Name = "支线-无处不在的蟹经理",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130214,
		PreGoal = 
		{
			301944,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "探索[62E7E7]大漩涡[-]击败[FDDE40]蟹经理[-]100个，建议探索39小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 100,
			Value = 242146,
			Area = 130214,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1946] =
{
	Id = 1946,
	Name = "支线-蜕变的海豚凛",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130214,
		PreGoal = 
		{
			301945,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "解锁[FDDE40]粉红海豚[-](海豚凛皮肤)",
			Type = ItemType.Skin,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 232163,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1947] =
{
	Id = 1947,
	Name = "支线-深入大漩涡",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130214,
		PreGoal = 
		{
			301946,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "穿着[62E7E7]粉红海豚[-](海豚凛皮肤)探索海洋星[FDDE40]大漩涡[-]48小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 172800,
			Skin = 
			{
				232163,
			},
			Value = 130214,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1948] =
{
	Id = 1948,
	Name = "支线-收服蟹董事",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130214,
		PreGoal = 
		{
			301947,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]蟹董事[-]10个(需要事务所的工具箱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 10,
			Value = 250147,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1949] =
{
	Id = 1949,
	Name = "支线-绵羊海兔的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130214,
		PreGoal = 
		{
			301948,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败大漩涡的[FDDE40]绵羊海兔[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140835,
		},
	},
	CompleteSpeech = 30194901,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1950] =
{
	Id = 1950,
	Name = "支线-倒卖纪念品的奸商",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130214,
		PreGoal = 
		{
			301949,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]绵羊海兔[-]180个，建议探索41小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 180,
			Value = 242148,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1951] =
{
	Id = 1951,
	Name = "支线-刺破泡沫",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130214,
		PreGoal = 
		{
			301950,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中获得[FDDE40]深海泡沫[-]180个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 180,
			Value = 321814,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1952] =
{
	Id = 1952,
	Name = "支线-制作纪念品",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130214,
		PreGoal = 
		{
			301951,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Craft,
	},
	GoalCondition = 
	{
		{
			Name = "在实验室合成获得[FDDE40]典藏签名照[-]30个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 30,
			Value = 321853,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1953] =
{
	Id = 1953,
	Name = "支线-深海的漩涡1",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130214,
		PreGoal = 
		{
			301952,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "穿着[62E7E7]粉红海豚[-](海豚凛皮肤)探索海洋星[FDDE40]大漩涡[-]48小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 172800,
			Skin = 
			{
				232163,
			},
			Value = 130214,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1954] =
{
	Id = 1954,
	Name = "支线-粉红海兔的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130214,
		PreGoal = 
		{
			301953,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败大漩涡的[FDDE40]粉红海兔[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140836,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1955] =
{
	Id = 1955,
	Name = "支线-倒卖握手券的奸商",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130214,
		PreGoal = 
		{
			301954,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]粉红海兔[-]50个，建议探索41小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 50,
			Value = 242149,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1956] =
{
	Id = 1956,
	Name = "支线-收容奸商1",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130214,
		PreGoal = 
		{
			301955,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]绵羊海兔[-]20个(需要事务所的纸板箱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 250148,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1957] =
{
	Id = 1957,
	Name = "支线-快速充电计划",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130214,
		PreGoal = 
		{
			301956,
		},
	},
	GoalTrigger = 
	{
		TriggerType.DemandReward,
	},
	GoalCondition = 
	{
		{
			Name = "完成委托获得[FDDE40]超能电池[-]20个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 20,
			Value = 320003,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1958] =
{
	Id = 1958,
	Name = "支线-深海的漩涡2",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130214,
		PreGoal = 
		{
			301957,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "穿着[62E7E7]粉红海豚[-](海豚凛皮肤)探索海洋星[FDDE40]大漩涡[-]48小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 172800,
			Skin = 
			{
				232163,
			},
			Value = 130214,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1959] =
{
	Id = 1959,
	Name = "支线-蓝海兔的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130214,
		PreGoal = 
		{
			301958,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败大漩涡的[FDDE40]蓝海兔[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140837,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1960] =
{
	Id = 1960,
	Name = "支线-倒卖典藏卡的奸商",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130214,
		PreGoal = 
		{
			301959,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]蓝海兔[-]20个，建议探索53小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 20,
			Value = 242150,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1961] =
{
	Id = 1961,
	Name = "支线-海洋星高级委托",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130214,
		PreGoal = 
		{
			301960,
		},
	},
	GoalTrigger = 
	{
		TriggerType.DemandCost,
	},
	GoalCondition = 
	{
		{
			Name = "在委托中提交[62E7E7]合成的[-]、[62E7E7]海洋星[-]道具50个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 50,
			TagList = 
			{
				560005,
				560107,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1962] =
{
	Id = 1962,
	Name = "支线-收容奸商2",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130214,
		PreGoal = 
		{
			301961,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]蓝海兔[-]20个(需要事务所的纸板箱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 250150,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1963] =
{
	Id = 1963,
	Name = "支线-深海的漩涡3",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130214,
		PreGoal = 
		{
			301962,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]5个[-][62E7E7]海洋星[-]队员(或宠物)的队伍探索海洋星[FDDE40]大漩涡[-]48小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 172800,
			TagList = 
			{
				560107,
			},
			CharacterNum = 5,
			Value = 130214,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1964] =
{
	Id = 1964,
	Name = "支线-鱼不翻的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130214,
		PreGoal = 
		{
			301963,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败大漩涡的[FDDE40]鱼不翻[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140838,
		},
	},
	CompleteSpeech = 30196401,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1965] =
{
	Id = 1965,
	Name = "新配方：正式队服",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130210,
		PreGoal = 
		{
			301938,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "提交[FDDE40]队员服[-]20个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 321810,
		},
	},
	Reward = {
		{
			Value = 360401,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1966] =
{
	Id = 1966,
	Name = "新配方：架子鼓",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130213,
		PreGoal = 
		{
			301725,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "提交[FDDE40]尖叫[-]20个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 321813,
		},
	},
	Reward = {
		{
			Value = 360404,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1967] =
{
	Id = 1967,
	Name = "新配方：璀璨珍珠",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130211,
		PreGoal = 
		{
			301700,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "提交[FDDE40]强力海绵[-]20个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 321811,
		},
	},
	Reward = {
		{
			Value = 360402,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1968] =
{
	Id = 1968,
	Name = "新配方：典藏签名照",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130212,
		PreGoal = 
		{
			301710,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "提交[FDDE40]应援棒[-]20个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 321812,
		},
	},
	Reward = {
		{
			Value = 360403,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1969] =
{
	Id = 1969,
	Name = "地图打卡：珊瑚丛",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130202,
		PreGoal = 
		{
			301620,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "虽然不在本地区，不过隔壁就有黄贝壳了~\n累计捕捉宠物[FDDE40]黄贝壳[-]25个(需要警察局的纸袋)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 25,
			Value = 250123,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 20,
		},
		{
			Value = 320054,
			Num = 20,
		},
		{
			Value = 1,
			Num = 75600,
		},
	},
}
GoalConfig[GoalID.Id1970] =
{
	Id = 1970,
	Name = "地图打卡：舞台灯柱",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130203,
		PreGoal = 
		{
			301630,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "如果不快点调试的话，就赶不上音乐会了！\n拥有至少[62E7E7]5级[-][FDDE40]特制玻璃杯[-](海豚凛装备)",
			Type = ItemType.Equipment,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 340382,
			Level = 5,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 30,
		},
		{
			Value = 320054,
			Num = 30,
		},
		{
			Value = 1,
			Num = 104000,
		},
	},
}
GoalConfig[GoalID.Id1971] =
{
	Id = 1971,
	Name = "地图打卡：华丽衣架",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130204,
		PreGoal = 
		{
			301916,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "看到水族箱里游来游去的生物，格外地愉快喵~\n累计拥有[62E7E7]水元素[-][FDDE40]宠物[-]23种",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 23,
			TagList = 
			{
				561202,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 40,
		},
		{
			Value = 320054,
			Num = 40,
		},
		{
			Value = 1,
			Num = 117400,
		},
	},
}
GoalConfig[GoalID.Id1972] =
{
	Id = 1972,
	Name = "地图打卡：大漩涡",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130205,
		PreGoal = 
		{
			301650,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "听说每隔几天，回溯镇就会有大漩涡出现。\n[62E7E7]一次性[-]探索海洋星[FDDE40]回溯镇[-]48小时",
			Type = ItemType.Time,
			CountType = GoalCountType.OneShot,
			Num = 172800,
			Value = 130205,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 50,
		},
		{
			Value = 320054,
			Num = 50,
		},
		{
			Value = 1,
			Num = 100300,
		},
	},
}
GoalConfig[GoalID.Id1973] =
{
	Id = 1973,
	Name = "地图打卡：大礁石区",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130206,
		PreGoal = 
		{
			301660,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "礁石保安一定知道哪里可以打开灯光台的喵~\n累计捕捉宠物[FDDE40]蓝礁保安[-]40个(需要事务所的工具箱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 40,
			Value = 250130,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 60,
		},
		{
			Value = 320054,
			Num = 60,
		},
		{
			Value = 1,
			Num = 101200,
		},
	},
}
GoalConfig[GoalID.Id1974] =
{
	Id = 1974,
	Name = "地图打卡：贝壳舞台",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130207,
		PreGoal = 
		{
			301675,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "急需从深海区捕捉水母，用于建设水母箱\n累计拥有[62E7E7]水母类的[-][FDDE40]宠物[-]3种",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 3,
			TagList = 
			{
				561362,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 70,
		},
		{
			Value = 320054,
			Num = 70,
		},
		{
			Value = 1,
			Num = 131500,
		},
	},
}
GoalConfig[GoalID.Id1975] =
{
	Id = 1975,
	Name = "地图打卡：海带丛",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130208,
		PreGoal = 
		{
			301932,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "加入了黄色的灯光后，舞台变得华丽起来了。\n累计捕捉宠物[FDDE40]黄记水母[-]30个(需要超市的空瓶)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 30,
			Value = 250136,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 80,
		},
		{
			Value = 320054,
			Num = 80,
		},
		{
			Value = 1,
			Num = 146600,
		},
	},
}
GoalConfig[GoalID.Id1976] =
{
	Id = 1976,
	Name = "地图打卡：沉船",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130209,
		PreGoal = 
		{
			301690,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "通电后，全身镜重新焕发了活力喵~\n在探索中击败[FDDE40]闪电海蛇[-]25个，建议探索49小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 25,
			Value = 242138,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 90,
		},
		{
			Value = 320054,
			Num = 90,
		},
		{
			Value = 1,
			Num = 145600,
		},
	},
}
GoalConfig[GoalID.Id1977] =
{
	Id = 1977,
	Name = "地图打卡：音响",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130210,
		PreGoal = 
		{
			301943,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Craft,
	},
	GoalCondition = 
	{
		{
			Name = "如果是华丽的偶像服装的话，这个应该可以吧？\n在实验室合成获得[FDDE40]正式队服[-]30个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 30,
			Value = 321851,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 100,
		},
		{
			Value = 320054,
			Num = 100,
		},
		{
			Value = 1,
			Num = 147800,
		},
	},
}
GoalConfig[GoalID.Id1978] =
{
	Id = 1978,
	Name = "地图打卡：海之鼓",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130211,
		PreGoal = 
		{
			301705,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Craft,
	},
	GoalCondition = 
	{
		{
			Name = "听工人们说，好的珍珠必须是百里挑一的。\n在实验室合成获得[FDDE40]璀璨珍珠[-]30个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 30,
			Value = 321852,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 110,
		},
		{
			Value = 320054,
			Num = 110,
		},
		{
			Value = 1,
			Num = 124900,
		},
	},
}
GoalConfig[GoalID.Id1979] =
{
	Id = 1979,
	Name = "地图打卡：舞台射灯",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130212,
		PreGoal = 
		{
			301720,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "哇~好大的珊瑚，真是壮观喵~\n累计捕捉宠物[FDDE40]珊瑚红[-]100个(需要警察局的纸袋)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 100,
			Value = 250120,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 120,
		},
		{
			Value = 320054,
			Num = 120,
		},
		{
			Value = 1,
			Num = 107700,
		},
	},
}
GoalConfig[GoalID.Id1980] =
{
	Id = 1980,
	Name = "地图打卡：深海射灯",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130213,
		PreGoal = 
		{
			301730,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "听说蟹董事有一艘私人潜水艇，随时准备跑路。\n探索[62E7E7]海底世界[-]击败[FDDE40]蟹董事[-]30个，建议探索74小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 30,
			Value = 242147,
			Area = 130213,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 120,
		},
		{
			Value = 320054,
			Num = 120,
		},
		{
			Value = 1,
			Num = 163200,
		},
	},
}
GoalConfig[GoalID.Id1981] =
{
	Id = 1981,
	Name = "地图打卡：星之环",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130214,
		PreGoal = 
		{
			301964,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "哇，漆漆你看！星星连成一串了喵~\n拥有[FDDE40]深海泡沫[-]300个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 300,
			Value = 321814,
		},
	},
	Reward = {
		{
			Value = 320615,
			Num = 1,
		},
		{
			Value = 1,
			Num = 164700,
		},
	},
}
GoalConfig[GoalID.Id2001] =
{
	Id = 2001,
	Name = "主线1000 - 警戒草的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130251,
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败着陆点的[FDDE40]警戒草[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141001,
		},
	},
	CompleteSpeech = 30200101,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id2002] =
{
	Id = 2002,
	Name = "主线1001 - 蠕虫骑手的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130251,
		PreGoal = 
		{
			302001,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败着陆点的[FDDE40]蠕虫骑手[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141002,
		},
	},
	CompleteSpeech = 30200201,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id2003] =
{
	Id = 2003,
	Name = "主线1002 - 紫弦月的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130251,
		PreGoal = 
		{
			302002,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败着陆点的[FDDE40]紫弦月[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141003,
		},
	},
	CompleteSpeech = 30200301,
	Reward = {
		{
			Value = 130252,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id2004] =
{
	Id = 2004,
	Name = "主线1003 - 独角仙的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130252,
		PreGoal = 
		{
			302003,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败黄金之砂的[FDDE40]独角仙[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141004,
		},
	},
	CompleteSpeech = 30200401,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id2005] =
{
	Id = 2005,
	Name = "主线1004 - 沙漠掠匪的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130252,
		PreGoal = 
		{
			302004,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败黄金之砂的[FDDE40]沙漠掠匪[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141005,
		},
	},
	CompleteSpeech = 30200501,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id2006] =
{
	Id = 2006,
	Name = "主线1005 - 红蝎的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130252,
		PreGoal = 
		{
			302005,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败黄金之砂的[FDDE40]红蝎[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141006,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id2007] =
{
	Id = 2007,
	Name = "主线1006 - 黑蝎的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130252,
		PreGoal = 
		{
			302006,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败黄金之砂的[FDDE40]黑蝎[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141007,
		},
	},
	Reward = {
		{
			Value = 130253,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id2008] =
{
	Id = 2008,
	Name = "主线1007 - 囚人的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130253,
		PreGoal = 
		{
			302007,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败地幔堡垒的[FDDE40]囚人[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141008,
		},
	},
	CompleteSpeech = 30200801,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id2009] =
{
	Id = 2009,
	Name = "主线1008 - 警卫的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130253,
		PreGoal = 
		{
			302008,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败地幔堡垒的[FDDE40]警卫[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141009,
		},
	},
	CompleteSpeech = 30200901,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id2010] =
{
	Id = 2010,
	Name = "主线1009 - 琉璃兜的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130253,
		PreGoal = 
		{
			302009,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败地幔堡垒的[FDDE40]琉璃兜[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141010,
		},
	},
	CompleteSpeech = 30201001,
	Reward = {
		{
			Value = 130254,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id2011] =
{
	Id = 2011,
	Name = "主线1010 - 机械引擎的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130254,
		PreGoal = 
		{
			302010,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败试验场的[FDDE40]机械引擎[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141011,
		},
	},
	CompleteSpeech = 30201101,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id2012] =
{
	Id = 2012,
	Name = "主线1011 - 报废的机器头部的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130254,
		PreGoal = 
		{
			302011,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败试验场的[FDDE40]报废的机器头部[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141012,
		},
	},
	CompleteSpeech = 30201201,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id2013] =
{
	Id = 2013,
	Name = "主线1012 - 老旧机器人的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130254,
		PreGoal = 
		{
			302012,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败试验场的[FDDE40]老旧机器人[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141013,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id2014] =
{
	Id = 2014,
	Name = "主线1013 - 珍珠吊兰的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130254,
		PreGoal = 
		{
			302013,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败试验场的[FDDE40]珍珠吊兰[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141014,
		},
	},
	CompleteSpeech = 30201401,
	Reward = {
		{
			Value = 130255,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id2015] =
{
	Id = 2015,
	Name = "主线1014 - 砂鱼的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130255,
		PreGoal = 
		{
			302014,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败流沙之河的[FDDE40]砂鱼[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141015,
		},
	},
	CompleteSpeech = 30201501,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id2016] =
{
	Id = 2016,
	Name = "主线1015 - 黄砂鱼的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130255,
		PreGoal = 
		{
			302015,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败流沙之河的[FDDE40]黄砂鱼[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141016,
		},
	},
	CompleteSpeech = 30201601,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id2017] =
{
	Id = 2017,
	Name = "主线1016 - 陆鳄的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130255,
		PreGoal = 
		{
			302016,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败流沙之河的[FDDE40]陆鳄[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141017,
		},
	},
	CompleteSpeech = 30201701,
	Reward = {
		{
			Value = 130256,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id2018] =
{
	Id = 2018,
	Name = "主线1017 - 喷壶虫的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130256,
		PreGoal = 
		{
			302017,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败绿洲寨的[FDDE40]喷壶虫[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141018,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id2019] =
{
	Id = 2019,
	Name = "主线1018 - 黄蜂的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130256,
		PreGoal = 
		{
			302018,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败绿洲寨的[FDDE40]黄蜂[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141019,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id2020] =
{
	Id = 2020,
	Name = "主线1019 - 蜂后的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130256,
		PreGoal = 
		{
			302019,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败绿洲寨的[FDDE40]蜂后[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141020,
		},
	},
	CompleteSpeech = 30202001,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id2021] =
{
	Id = 2021,
	Name = "主线1020 - 地城守卫的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130256,
		PreGoal = 
		{
			302020,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败绿洲寨的[FDDE40]地城守卫[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141021,
		},
	},
	Reward = {
		{
			Value = 130257,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id2022] =
{
	Id = 2022,
	Name = "主线1021 - 矿山暴徒的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130257,
		PreGoal = 
		{
			302021,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败矿场的[FDDE40]矿山暴徒[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141022,
		},
	},
	CompleteSpeech = 30202201,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id2023] =
{
	Id = 2023,
	Name = "主线1022 - 暴徒头目的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130257,
		PreGoal = 
		{
			302022,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败矿场的[FDDE40]暴徒头目[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141023,
		},
	},
	CompleteSpeech = 30202301,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id2024] =
{
	Id = 2024,
	Name = "主线1023 - 矿甲虫的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130257,
		PreGoal = 
		{
			302023,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败矿场的[FDDE40]矿甲虫[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141024,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id2025] =
{
	Id = 2025,
	Name = "主线1024 - 金甲虫的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130257,
		PreGoal = 
		{
			302024,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败矿场的[FDDE40]金甲虫[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141025,
		},
	},
	CompleteSpeech = 30202501,
	Reward = {
		{
			Value = 130258,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id2026] =
{
	Id = 2026,
	Name = "主线1025 - 鼹鼠帮的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130258,
		PreGoal = 
		{
			302025,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败无法地带的[FDDE40]鼹鼠帮[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141026,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id2027] =
{
	Id = 2027,
	Name = "主线1026 - 鼹鼠头头的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130258,
		PreGoal = 
		{
			302026,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败无法地带的[FDDE40]鼹鼠头头[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141027,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id2028] =
{
	Id = 2028,
	Name = "主线1027 - 蠕虫特工的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130258,
		PreGoal = 
		{
			302027,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败无法地带的[FDDE40]蠕虫特工[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141028,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id2029] =
{
	Id = 2029,
	Name = "主线1028 - 谜之机械的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130258,
		PreGoal = 
		{
			302028,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败无法地带的[FDDE40]谜之机械[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141029,
		},
	},
	CompleteSpeech = 30202901,
	Reward = {
		{
			Value = 130259,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id2030] =
{
	Id = 2030,
	Name = "主线1029 - 机械臂的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130259,
		PreGoal = 
		{
			302029,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败机械车间的[FDDE40]机械臂[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141030,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id2031] =
{
	Id = 2031,
	Name = "主线1030 - 机器员工的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130259,
		PreGoal = 
		{
			302030,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败机械车间的[FDDE40]机器员工[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141031,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id2032] =
{
	Id = 2032,
	Name = "主线1031 - 机器工头的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130259,
		PreGoal = 
		{
			302031,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败机械车间的[FDDE40]机器工头[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141032,
		},
	},
	CompleteSpeech = 30203201,
	Reward = {
		{
			Value = 130261,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id2033] =
{
	Id = 2033,
	Name = "主线1032 - 报警机器人的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130261,
		PreGoal = 
		{
			302032,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败地心城的[FDDE40]报警机器人[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141037,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id2034] =
{
	Id = 2034,
	Name = "主线1033 - 王都警卫的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130261,
		PreGoal = 
		{
			302033,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败地心城的[FDDE40]王都警卫[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141038,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id2035] =
{
	Id = 2035,
	Name = "主线1034 - 王都队长的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130261,
		PreGoal = 
		{
			302034,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败地心城的[FDDE40]王都队长[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141039,
		},
	},
	CompleteSpeech = 30203501,
	Reward = {
		{
			Value = 130262,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id2036] =
{
	Id = 2036,
	Name = "主线1035 - 左旗护卫的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130262,
		PreGoal = 
		{
			302035,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败城堡殿堂的[FDDE40]左旗护卫[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141040,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id2037] =
{
	Id = 2037,
	Name = "主线1036 - 爱之蔓的初次挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130262,
		PreGoal = 
		{
			302036,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败城堡殿堂的[FDDE40]爱之蔓[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141041,
		},
	},
	CompleteSpeech = 30203701,
	Reward = {
		{
			Value = 130263,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id2038] =
{
	Id = 2038,
	Name = "主线1037 - 守门机器人的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130263,
		PreGoal = 
		{
			302037,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败巴别之路的[FDDE40]守门机器人[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141042,
		},
	},
	CompleteSpeech = 30203801,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id2039] =
{
	Id = 2039,
	Name = "主线1038 - 武装鼹鼠的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130263,
		PreGoal = 
		{
			302038,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败巴别之路的[FDDE40]武装鼹鼠[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141043,
		},
	},
	CompleteSpeech = 30203901,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id2040] =
{
	Id = 2040,
	Name = "主线1039 - 毒蝎的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130263,
		PreGoal = 
		{
			302039,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败巴别之路的[FDDE40]毒蝎[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141044,
		},
	},
	CompleteSpeech = 30204001,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id2041] =
{
	Id = 2041,
	Name = "主线1040 - 爱之蔓的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130263,
		PreGoal = 
		{
			302040,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败巴别之路的[FDDE40]爱之蔓[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141045,
		},
	},
	CompleteSpeech = 30204101,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id2301] =
{
	Id = 2301,
	Name = "解锁：星核",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130259,
		PreGoal = 
		{
			302032,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "听说这家咖啡馆是本地居民经常去的~\n累计拥有[62E7E7]海洋星[-][FDDE40]宠物[-]2种",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 2,
			TagList = 
			{
				560107,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 130260,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id2302] =
{
	Id = 2302,
	Name = "支线-失控的零件的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130260,
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败星核的[FDDE40]失控的零件[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141033,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id2303] =
{
	Id = 2303,
	Name = "支线-纯净能量体的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130260,
		PreGoal = 
		{
			302302,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败星核的[FDDE40]纯净能量体[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141034,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id2304] =
{
	Id = 2304,
	Name = "支线-人工智能G-0X的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130260,
		PreGoal = 
		{
			302303,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败星核的[FDDE40]人工智能G-0X[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141035,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id2305] =
{
	Id = 2305,
	Name = "支线-高砂之翁的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130260,
		PreGoal = 
		{
			302304,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败星核的[FDDE40]高砂之翁[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 141036,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id2306] =
{
	Id = 2306,
	Name = "地图打卡：沙漠地区1",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130252,
		PreGoal = 
		{
			302007,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "过马路时请注意安全，切勿嬉闹。\n提交[FDDE40]箭头[-]30个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 30,
			Value = 321411,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 20,
		},
		{
			Value = 320054,
			Num = 20,
		},
		{
			Value = 1,
			Num = 73200,
		},
	},
}
GoalConfig[GoalID.Id2307] =
{
	Id = 2307,
	Name = "地图打卡：沙漠地区2",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130253,
		PreGoal = 
		{
			302010,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "游荡的猫咪占领了咖啡店的招牌…\n累计拥有[62E7E7]纸张类的[-][FDDE40]宠物[-]3种",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 3,
			TagList = 
			{
				561343,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 30,
		},
		{
			Value = 320054,
			Num = 30,
		},
		{
			Value = 1,
			Num = 86300,
		},
	},
}
GoalConfig[GoalID.Id2308] =
{
	Id = 2308,
	Name = "地图打卡：沙漠地区3",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130254,
		PreGoal = 
		{
			302014,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "有什么需要寄去问候的对象吗？\n累计拥有[62E7E7]纸张类的[-][FDDE40]宠物[-]3种",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 3,
			TagList = 
			{
				561343,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 40,
		},
		{
			Value = 320054,
			Num = 40,
		},
		{
			Value = 1,
			Num = 88200,
		},
	},
}
GoalConfig[GoalID.Id2309] =
{
	Id = 2309,
	Name = "地图打卡：沙漠地区4",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130255,
		PreGoal = 
		{
			302017,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "在这华丽的光辉之下，冷清街道温暖了起来。\n累计拥有[62E7E7]纸张类的[-][FDDE40]宠物[-]3种",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 3,
			TagList = 
			{
				561343,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 50,
		},
		{
			Value = 320054,
			Num = 50,
		},
		{
			Value = 1,
			Num = 95000,
		},
	},
}
GoalConfig[GoalID.Id2310] =
{
	Id = 2310,
	Name = "地图打卡：沙漠地区5",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130256,
		PreGoal = 
		{
			302021,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "想去事发地点的话需要问一下本地的黑猫。\n累计拥有[62E7E7]纸张类的[-][FDDE40]宠物[-]3种",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 3,
			TagList = 
			{
				561343,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 60,
		},
		{
			Value = 320054,
			Num = 60,
		},
		{
			Value = 1,
			Num = 98100,
		},
	},
}
GoalConfig[GoalID.Id2311] =
{
	Id = 2311,
	Name = "地图打卡：沙漠地区6",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130257,
		PreGoal = 
		{
			302025,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "先生，别抽烟了，可以先带我去登记吗？\n累计拥有[62E7E7]纸张类的[-][FDDE40]宠物[-]3种",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 3,
			TagList = 
			{
				561343,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 70,
		},
		{
			Value = 320054,
			Num = 70,
		},
		{
			Value = 1,
			Num = 126100,
		},
	},
}
GoalConfig[GoalID.Id2312] =
{
	Id = 2312,
	Name = "地图打卡：沙漠地区7",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130258,
		PreGoal = 
		{
			302029,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "破坏所有警报就可以安心查看证物柜了~\n累计拥有[62E7E7]纸张类的[-][FDDE40]宠物[-]3种",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 3,
			TagList = 
			{
				561343,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 80,
		},
		{
			Value = 320054,
			Num = 80,
		},
		{
			Value = 1,
			Num = 138700,
		},
	},
}
GoalConfig[GoalID.Id2313] =
{
	Id = 2313,
	Name = "地图打卡：沙漠地区8",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130259,
		PreGoal = 
		{
			302032,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "审讯员说，关键口供要用红墨水圈出来。\n累计拥有[62E7E7]纸张类的[-][FDDE40]宠物[-]3种",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 3,
			TagList = 
			{
				561343,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 90,
		},
		{
			Value = 320054,
			Num = 90,
		},
		{
			Value = 1,
			Num = 111300,
		},
	},
}
GoalConfig[GoalID.Id2314] =
{
	Id = 2314,
	Name = "地图打卡：沙漠地区9",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130260,
		PreGoal = 
		{
			302305,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "有些失物在此多年，已经把这里当成了家。\n累计拥有[62E7E7]纸张类的[-][FDDE40]宠物[-]3种",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 3,
			TagList = 
			{
				561343,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 100,
		},
		{
			Value = 320054,
			Num = 100,
		},
		{
			Value = 1,
			Num = 142500,
		},
	},
}
GoalConfig[GoalID.Id2315] =
{
	Id = 2315,
	Name = "地图打卡：沙漠地区10",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130261,
		PreGoal = 
		{
			302035,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "没有书本的书架是没有灵魂的！\n累计拥有[62E7E7]纸张类的[-][FDDE40]宠物[-]3种",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 3,
			TagList = 
			{
				561343,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 110,
		},
		{
			Value = 320054,
			Num = 110,
		},
		{
			Value = 1,
			Num = 158200,
		},
	},
}
GoalConfig[GoalID.Id2316] =
{
	Id = 2316,
	Name = "地图打卡：沙漠地区11",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130262,
		PreGoal = 
		{
			302037,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "听说要很有耐心才能找到那个传说中的电话亭！\n累计拥有[62E7E7]纸张类的[-][FDDE40]宠物[-]3种",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 3,
			TagList = 
			{
				561343,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 120,
		},
		{
			Value = 320054,
			Num = 120,
		},
		{
			Value = 1,
			Num = 114000,
		},
	},
}
GoalConfig[GoalID.Id2317] =
{
	Id = 2317,
	Name = "地图打卡：沙漠地区12",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130263,
		PreGoal = 
		{
			302041,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "听说要很有耐心才能找到那个传说中的电话亭！\n累计拥有[62E7E7]纸张类的[-][FDDE40]宠物[-]3种",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 3,
			TagList = 
			{
				561343,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 120,
		},
		{
			Value = 320054,
			Num = 120,
		},
		{
			Value = 1,
			Num = 163900,
		},
	},
}
