
GoalConfig[GoalID.Id7001] =
{
	Id = 7001,
	Name = "冒险节准备工作",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 3,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			300040,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "这么严肃的活动，门票竟然是鸡腿？\n提交[FDDE40]鸡腿[-]10个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 10,
			Value = 320406,
		},
	},
	CompleteSpeech = 30700101,
	Reward = {
		{
			Value = 2,
			Num = 50,
		},
	},
}
GoalConfig[GoalID.Id7002] =
{
	Id = 7002,
	Name = "史莱姆的性别？！",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 3,
	PreCondition = {
		PreArea = 130006,
		PreGoal = 
		{
			307001,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "如果是去宝箱谷的话，说不定就能抓到这个！\n累计捕捉宠物[FDDE40]粉色史莱姆[-]20个",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 250510,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 50,
		},
	},
}
GoalConfig[GoalID.Id7003] =
{
	Id = 7003,
	Name = "吃人的宝箱？",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 3,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307002,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityBattle,
	},
	GoalCondition = 
	{
		{
			Name = "虽然名字叫宝箱谷，不过那里都是宝箱怪！\n完成[62E7E7]节日主题故事[-][FDDE40]第3章[-]",
			Type = ItemType.ActivityBattle,
			CountType = GoalCountType.Current,
			Num = 3,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 80,
		},
	},
}
GoalConfig[GoalID.Id7004] =
{
	Id = 7004,
	Name = "宝箱里的惊喜",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 3,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307003,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityExplore,
	},
	GoalCondition = 
	{
		{
			Name = "那些家伙整天伪装成宝箱偷袭冒险家！\n派遣含有[62E7E7]3[-][62E7E7]冒险星[-]队员(或宠物)的队伍搭乘[62E7E7]流亡街电车[-]出发探索击败[FDDE40]木制宝箱怪[-]60个",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 60,
			TagList = 
			{
				560103,
			},
			CharacterNum = 3,
			Value = 243001,
		},
	},
	CompleteSpeech = 30700401,
	Reward = {
		{
			Value = 2,
			Num = 80,
		},
	},
}
GoalConfig[GoalID.Id7005] =
{
	Id = 7005,
	Name = "古老的地图",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 3,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307004,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "作为冒险协会，必须没收这种伪劣藏宝图！\n提交[FDDE40]藏宝图-左[-]20个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 327301,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 120,
		},
	},
}
GoalConfig[GoalID.Id7006] =
{
	Id = 7006,
	Name = "不要打开！",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 3,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307005,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityBattle,
	},
	GoalCondition = 
	{
		{
			Name = "小心，不要轻敌！\n完成[62E7E7]节日主题故事[-][FDDE40]第7章[-]",
			Type = ItemType.ActivityBattle,
			CountType = GoalCountType.Current,
			Num = 7,
			Value = -1,
		},
	},
	CompleteSpeech = 30700601,
	Reward = {
		{
			Value = 2,
			Num = 120,
		},
	},
}
GoalConfig[GoalID.Id7007] =
{
	Id = 7007,
	Name = "研究宝箱",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 3,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307006,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "就趁着这次机会，研究一下这些怪物吧！\n累计捕捉宠物[FDDE40]稀有宝箱怪[-]8个",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 8,
			Value = 250502,
		},
	},
	CompleteSpeech = 30700701,
	Reward = {
		{
			Value = 2,
			Num = 150,
		},
	},
}
GoalConfig[GoalID.Id7008] =
{
	Id = 7008,
	Name = "另一半地图",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 3,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307007,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "既然到了这一步，必须彻底没收劣质地图！\n提交[FDDE40]藏宝图-右[-]20个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 327302,
		},
	},
	CompleteSpeech = 30700801,
	Reward = {
		{
			Value = 2,
			Num = 150,
		},
	},
}
GoalConfig[GoalID.Id7009] =
{
	Id = 7009,
	Name = "深入宝箱谷",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 3,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307008,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityExplore,
	},
	GoalCondition = 
	{
		{
			Name = "这个看起来像恶魔的家伙，应该很强吧？\n派遣含有[62E7E7]5个[-][62E7E7]冒险星[-]队员(或宠物)的队伍搭乘[FDDE40]流亡街电车[-]出发探索24小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 86400,
			TagList = 
			{
				560103,
			},
			CharacterNum = 5,
			Value = -1,
		},
	},
	CompleteSpeech = 30700901,
	Reward = {
		{
			Value = 2,
			Num = 180,
		},
	},
}
GoalConfig[GoalID.Id7010] =
{
	Id = 7010,
	Name = "古老的仪式",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 3,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307009,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityChallenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败[FDDE40]术士[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 147007,
		},
	},
	CompleteSpeech = 30701001,
	Reward = {
		{
			Value = 223007,
			Num = 1,
		},
		{
			Value = 2,
			Num = 100,
		},
	},
}
GoalConfig[GoalID.Id7021] =
{
	Id = 7021,
	Name = "喜迎春节1",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 2,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			300040,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityExplore,
	},
	GoalCondition = 
	{
		{
			Name = "咦？怎么有辆巴士停在这里？\n搭乘[FDDE40]流亡街电车[-]出发探索4小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 14400,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 327306,
			Num = 300,
		},
		{
			Value = 330003,
			Num = 1,
		},
	},
}
GoalConfig[GoalID.Id7022] =
{
	Id = 7022,
	Name = "喜迎春节2",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 2,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307021,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "有了这些就能开启春节的故事挑战了！\n拥有[FDDE40]小元宝[-]30个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 30,
			Value = 327304,
		},
	},
	Reward = {
		{
			Value = 327306,
			Num = 300,
		},
		{
			Value = 330003,
			Num = 1,
		},
	},
}
GoalConfig[GoalID.Id7023] =
{
	Id = 7023,
	Name = "喜迎春节3",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 2,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307022,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityBattle,
	},
	GoalCondition = 
	{
		{
			Name = "正式踏上剑士的新年之旅！\n完成[62E7E7]节日主题故事[-][FDDE40]第1章[-]",
			Type = ItemType.ActivityBattle,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 327306,
			Num = 300,
		},
		{
			Value = 330003,
			Num = 1,
		},
	},
}
GoalConfig[GoalID.Id7024] =
{
	Id = 7024,
	Name = "喜迎春节4",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 2,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307023,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityExplore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]剑士[-]搭乘[FDDE40]流亡街电车[-]出发探索4小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 14400,
			Character = 
			{
				220003,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 327306,
			Num = 300,
		},
		{
			Value = 330003,
			Num = 1,
		},
	},
}
GoalConfig[GoalID.Id7025] =
{
	Id = 7025,
	Name = "喜迎春节5",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 2,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307024,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]橘大大[-]5个(需要道具店的陷阱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 5,
			Value = 250504,
		},
	},
	Reward = {
		{
			Value = 327306,
			Num = 300,
		},
		{
			Value = 330003,
			Num = 1,
		},
	},
}
GoalConfig[GoalID.Id7026] =
{
	Id = 7026,
	Name = "喜迎春节6",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 2,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307025,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityBattle,
	},
	GoalCondition = 
	{
		{
			Name = "看来步行街的敌人要通过挑战来解锁呢！\n完成[62E7E7]节日主题故事[-][FDDE40]第3章[-]",
			Type = ItemType.ActivityBattle,
			CountType = GoalCountType.Current,
			Num = 3,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
	},
}
GoalConfig[GoalID.Id7027] =
{
	Id = 7027,
	Name = "喜迎春节7",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 2,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307026,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]阿吉[-]5个(需要道具店的陷阱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 5,
			Value = 250505,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
	},
}
GoalConfig[GoalID.Id7028] =
{
	Id = 7028,
	Name = "喜迎春节8",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 2,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307027,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityBattle,
	},
	GoalCondition = 
	{
		{
			Name = "完成[62E7E7]节日主题故事[-][FDDE40]第6章[-]",
			Type = ItemType.ActivityBattle,
			CountType = GoalCountType.Current,
			Num = 6,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
	},
}
GoalConfig[GoalID.Id7029] =
{
	Id = 7029,
	Name = "喜迎春节9",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 2,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307028,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityExplore,
	},
	GoalCondition = 
	{
		{
			Name = "“那个，可以陪我一起去瞎转转吗？”\n派遣[62E7E7]剑士[-]、[62E7E7]魔法师[-]搭乘[FDDE40]流亡街电车[-]出发探索10小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 36000,
			Character = 
			{
				220003,
				220010,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
	},
}
GoalConfig[GoalID.Id7030] =
{
	Id = 7030,
	Name = "喜迎春节10",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 2,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307029,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityBattle,
	},
	GoalCondition = 
	{
		{
			Name = "完成[62E7E7]节日主题故事[-][FDDE40]第10章[-]",
			Type = ItemType.ActivityBattle,
			CountType = GoalCountType.Current,
			Num = 10,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
	},
}
GoalConfig[GoalID.Id7031] =
{
	Id = 7031,
	Name = "喜迎春节11",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 2,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307030,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]寒梅梅[-]5个(需要超市的空瓶)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 5,
			Value = 250506,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 3,
		},
	},
}
GoalConfig[GoalID.Id7032] =
{
	Id = 7032,
	Name = "喜迎春节12",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 2,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307031,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityBattle,
	},
	GoalCondition = 
	{
		{
			Name = "完成[62E7E7]节日主题故事[-][FDDE40]第15章[-]",
			Type = ItemType.ActivityBattle,
			CountType = GoalCountType.Current,
			Num = 15,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 3,
		},
	},
}
GoalConfig[GoalID.Id7041] =
{
	Id = 7041,
	Name = "奇怪的邀请函",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 4,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			300040,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityExplore,
	},
	GoalCondition = 
	{
		{
			Name = "搭乘[FDDE40]流亡街电车[-]出发探索4小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 14400,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 50,
		},
	},
}
GoalConfig[GoalID.Id7042] =
{
	Id = 7042,
	Name = "啊，整个人麻了！",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 4,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307041,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]麻醉花椒[-]20个",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 250512,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 50,
		},
	},
}
GoalConfig[GoalID.Id7043] =
{
	Id = 7043,
	Name = "小吃街的怪人",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 4,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307042,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityBattle,
	},
	GoalCondition = 
	{
		{
			Name = "完成[62E7E7]节日主题故事[-][FDDE40]第3章[-]",
			Type = ItemType.ActivityBattle,
			CountType = GoalCountType.Current,
			Num = 3,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 50,
		},
	},
}
GoalConfig[GoalID.Id7044] =
{
	Id = 7044,
	Name = "美食的对决",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 4,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307043,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityExplore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]1个[-][62E7E7]美食星[-]队员(或宠物)的队伍搭乘[FDDE40]流亡街电车[-]出发探索10小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 36000,
			TagList = 
			{
				560104,
			},
			CharacterNum = 1,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
}
GoalConfig[GoalID.Id7045] =
{
	Id = 7045,
	Name = "美食星“非法”移民",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 4,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307044,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]臭小白[-]20个",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 250513,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
}
GoalConfig[GoalID.Id7046] =
{
	Id = 7046,
	Name = "特殊的酱汁",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 4,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307045,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "提交[FDDE40]秘制酱汁[-]20个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 327307,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
}
GoalConfig[GoalID.Id7047] =
{
	Id = 7047,
	Name = "你敢吃吗？",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 4,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307046,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityBattle,
	},
	GoalCondition = 
	{
		{
			Name = "完成[62E7E7]节日主题故事[-][FDDE40]第7章[-]",
			Type = ItemType.ActivityBattle,
			CountType = GoalCountType.Current,
			Num = 7,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 150,
		},
	},
}
GoalConfig[GoalID.Id7048] =
{
	Id = 7048,
	Name = "鱼与派的完美结合？",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 4,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307047,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]仰望星空[-]8个",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 8,
			Value = 250515,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 150,
		},
	},
}
GoalConfig[GoalID.Id7049] =
{
	Id = 7049,
	Name = "神秘的食谱",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 4,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307048,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "提交[FDDE40]料理秘籍[-]20个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 327308,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 150,
		},
	},
}
GoalConfig[GoalID.Id7050] =
{
	Id = 7050,
	Name = "最后的味觉冲刺",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 4,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307049,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityExplore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]5个[-][62E7E7]美食星[-]队员(或宠物)的队伍搭乘[FDDE40]流亡街电车[-]出发探索24小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 86400,
			TagList = 
			{
				560104,
			},
			CharacterNum = 5,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 180,
		},
	},
}
GoalConfig[GoalID.Id7051] =
{
	Id = 7051,
	Name = "龙舟公园调研工作",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 5,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			300040,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityExplore,
	},
	GoalCondition = 
	{
		{
			Name = "搭乘[FDDE40]流亡街电车[-]出发探索4小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 14400,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 327311,
			Num = 300,
		},
		{
			Value = 2,
			Num = 50,
		},
	},
}
GoalConfig[GoalID.Id7052] =
{
	Id = 7052,
	Name = "清凉爽口的点心",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 5,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307051,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]绿豆正方糕[-]15个",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 15,
			Value = 250517,
		},
	},
	Reward = {
		{
			Value = 327311,
			Num = 300,
		},
		{
			Value = 2,
			Num = 50,
		},
	},
}
GoalConfig[GoalID.Id7053] =
{
	Id = 7053,
	Name = "骨头兵的特训",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 5,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307052,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]20级[-][FDDE40]骨头兵[-]",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220006,
			Level = 20,
		},
	},
	Reward = {
		{
			Value = 327311,
			Num = 300,
		},
		{
			Value = 2,
			Num = 50,
		},
	},
}
GoalConfig[GoalID.Id7054] =
{
	Id = 7054,
	Name = "骨头兵，向前冲！",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 5,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307053,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityExplore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]骨头兵[-]搭乘[FDDE40]流亡街电车[-]出发探索10小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 36000,
			Character = 
			{
				220006,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 327311,
			Num = 300,
		},
		{
			Value = 2,
			Num = 100,
		},
	},
}
GoalConfig[GoalID.Id7055] =
{
	Id = 7055,
	Name = "甜粽总动员",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 5,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307054,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]顶个枣粽[-]20个",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 250518,
		},
	},
	Reward = {
		{
			Value = 327311,
			Num = 300,
		},
		{
			Value = 2,
			Num = 100,
		},
	},
}
GoalConfig[GoalID.Id7056] =
{
	Id = 7056,
	Name = "驱散瘴气",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 5,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307055,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "提交[FDDE40]艾草[-]20个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 327309,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
}
GoalConfig[GoalID.Id7057] =
{
	Id = 7057,
	Name = "龙舟大战",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 5,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307056,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityBattle,
	},
	GoalCondition = 
	{
		{
			Name = "完成[62E7E7]节日主题故事[-][FDDE40]第7章[-]",
			Type = ItemType.ActivityBattle,
			CountType = GoalCountType.Current,
			Num = 7,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 150,
		},
	},
}
GoalConfig[GoalID.Id7058] =
{
	Id = 7058,
	Name = "禁止私贩酒类",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 5,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307057,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]熊老九[-]8个",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 8,
			Value = 250520,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 150,
		},
	},
}
GoalConfig[GoalID.Id7059] =
{
	Id = 7059,
	Name = "一捆麻绳",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 5,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307058,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "提交[FDDE40]伸缩绳[-]20个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 327310,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 150,
		},
	},
}
GoalConfig[GoalID.Id7060] =
{
	Id = 7060,
	Name = "龙舟大赛",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 5,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307059,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityExplore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]骨头兵[-]、[62E7E7]小魔王[-]搭乘[FDDE40]流亡街电车[-]出发探索24小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 86400,
			Character = 
			{
				220006,
				220009,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 180,
		},
	},
}
GoalConfig[GoalID.Id7061] =
{
	Id = 7061,
	Name = "耶！夏日庙会开始啦",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 6,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			300040,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityExplore,
	},
	GoalCondition = 
	{
		{
			Name = "搭乘[FDDE40]流亡街电车[-]出发探索4小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 14400,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 50,
		},
	},
}
GoalConfig[GoalID.Id7062] =
{
	Id = 7062,
	Name = "扑灵扑灵的丝线",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 6,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307061,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityExplore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中获得[FDDE40]白丝[-]10个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 10,
			Value = 327312,
		},
	},
	Reward = {
		{
			Value = 223130,
			Num = 1,
		},
		{
			Value = 2,
			Num = 50,
		},
	},
}
GoalConfig[GoalID.Id7063] =
{
	Id = 7063,
	Name = "喜鹊我们可以当朋友嘛",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 6,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307062,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]皮卡皮卡[-]10个",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 10,
			Value = 250522,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 75,
		},
	},
}
GoalConfig[GoalID.Id7064] =
{
	Id = 7064,
	Name = "热闹的庙会",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 6,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307063,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityExplore,
	},
	GoalCondition = 
	{
		{
			Name = "搭乘[FDDE40]流亡街电车[-]出发探索6小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 21600,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 75,
		},
	},
}
GoalConfig[GoalID.Id7065] =
{
	Id = 7065,
	Name = "庙会要去捞金鱼",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 6,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307064,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityBattle,
	},
	GoalCondition = 
	{
		{
			Name = "完成[62E7E7]节日主题故事[-][FDDE40]第3章[-]",
			Type = ItemType.ActivityBattle,
			CountType = GoalCountType.Current,
			Num = 3,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
}
GoalConfig[GoalID.Id7066] =
{
	Id = 7066,
	Name = "炸毛的布料",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 6,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307065,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]布茎云[-]20个",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 250523,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
}
GoalConfig[GoalID.Id7067] =
{
	Id = 7067,
	Name = "月下奇遇",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 6,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307066,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityBattle,
	},
	GoalCondition = 
	{
		{
			Name = "完成[62E7E7]节日主题故事[-][FDDE40]第7章[-]",
			Type = ItemType.ActivityBattle,
			CountType = GoalCountType.Current,
			Num = 7,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 125,
		},
	},
}
GoalConfig[GoalID.Id7068] =
{
	Id = 7068,
	Name = "不戳不戳针不戳",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 6,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307067,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityExplore,
	},
	GoalCondition = 
	{
		{
			Name = "搭乘[62E7E7]流亡街电车[-]出发探索击败[FDDE40]针不戳[-]20个",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 20,
			Value = 243025,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 150,
		},
	},
}
GoalConfig[GoalID.Id7069] =
{
	Id = 7069,
	Name = "好闻的香料",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 6,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307068,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有[FDDE40]香壳[-]20个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 327313,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 175,
		},
	},
}
GoalConfig[GoalID.Id7070] =
{
	Id = 7070,
	Name = "快看~是烟花",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 6,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307069,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityExplore,
	},
	GoalCondition = 
	{
		{
			Name = "搭乘[FDDE40]流亡街电车[-]出发探索36小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 129600,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 200,
		},
	},
}
GoalConfig[GoalID.Id7071] =
{
	Id = 7071,
	Name = "天凉了，可以泡温泉了",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 7,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			300040,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityExplore,
	},
	GoalCondition = 
	{
		{
			Name = "搭乘[FDDE40]流亡街电车[-]出发探索4小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 14400,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 50,
		},
	},
}
GoalConfig[GoalID.Id7072] =
{
	Id = 7072,
	Name = "怎么到处都要门票啊",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 7,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307071,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityExplore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中获得[FDDE40]渣渣灰[-]15个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 15,
			Value = 327318,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 50,
		},
	},
}
GoalConfig[GoalID.Id7073] =
{
	Id = 7073,
	Name = "温泉蛋，要一次吃个够！",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 7,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307072,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]温泉冷蛋[-]20个",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 250529,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 75,
		},
	},
}
GoalConfig[GoalID.Id7074] =
{
	Id = 7074,
	Name = "泡澡澡洗白白",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 7,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307073,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityExplore,
	},
	GoalCondition = 
	{
		{
			Name = "搭乘[62E7E7]流亡街电车[-]出发探索击败[FDDE40]刘磺先生[-]25个",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 25,
			Value = 243028,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 75,
		},
	},
}
GoalConfig[GoalID.Id7075] =
{
	Id = 7075,
	Name = "出发！探索雪山",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 7,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307074,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityExplore,
	},
	GoalCondition = 
	{
		{
			Name = "搭乘[FDDE40]流亡街电车[-]出发探索6小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 21600,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
}
GoalConfig[GoalID.Id7076] =
{
	Id = 7076,
	Name = "先泡一个药剂温泉吧",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 7,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307075,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityExplore,
	},
	GoalCondition = 
	{
		{
			Name = "搭乘[62E7E7]流亡街电车[-]出发探索击败[FDDE40]药剂包[-]20个",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 20,
			Value = 243029,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
}
GoalConfig[GoalID.Id7077] =
{
	Id = 7077,
	Name = "雪地中的脚印",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 7,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307076,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityBattle,
	},
	GoalCondition = 
	{
		{
			Name = "完成[62E7E7]节日主题故事[-][FDDE40]第7章[-]",
			Type = ItemType.ActivityBattle,
			CountType = GoalCountType.Current,
			Num = 7,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 125,
		},
	},
}
GoalConfig[GoalID.Id7078] =
{
	Id = 7078,
	Name = "清理掉落的碎冰冰",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 7,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307077,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityExplore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中获得[FDDE40]碎冰冰[-]20个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 20,
			Value = 327319,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 150,
		},
	},
}
GoalConfig[GoalID.Id7079] =
{
	Id = 7079,
	Name = "汪汪？哪里来的声音",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 7,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307078,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]猎犬旺旺[-]15个",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 15,
			Value = 250531,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 175,
		},
	},
}
GoalConfig[GoalID.Id7080] =
{
	Id = 7080,
	Name = "真相大白",
	GoalType = GoalType.Activity,
	ShowFirst = false,
	PoolId = 7,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			307079,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityExplore,
	},
	GoalCondition = 
	{
		{
			Name = "搭乘[FDDE40]流亡街电车[-]出发探索36小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 129600,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 200,
		},
	},
}
