
DemandConfig[DemandID.Id101] =
{
	Id = 101,
	Name = "0",
	Desc = "0",
	Value = 320412,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308105,
		301248,
	},
	GoodsId = 1100412,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 23688,
				},
			},
		},
	},
	DemandID = 410101,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id102] =
{
	Id = 102,
	Name = "订购陷阱",
	Desc = "需要大量陷阱",
	Value = 320301,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308001,
		300035,
	},
	CloseGoal = 
	{
		300062,
	},
	GoodsId = 1210301,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 422,
				},
			},
		},
	},
	DemandID = 410102,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id103] =
{
	Id = 103,
	Name = "0",
	Desc = "0",
	Value = 320301,
	Active = false,
	Weight = 0,
	GoodsId = 1220301,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 422,
				},
			},
		},
	},
	DemandID = 410103,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id104] =
{
	Id = 104,
	Name = "0",
	Desc = "0",
	Value = 320301,
	Active = false,
	Weight = 0,
	GoodsId = 1230301,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 422,
				},
			},
		},
	},
	DemandID = 410104,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id105] =
{
	Id = 105,
	Name = "订购陷阱",
	Desc = "需要大量陷阱",
	Value = 320301,
	Active = false,
	Weight = 0,
	GoodsId = 1240301,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 422,
				},
			},
		},
	},
	DemandID = 410105,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id106] =
{
	Id = 106,
	Name = "0",
	Desc = "0",
	Value = 320301,
	Active = false,
	Weight = 0,
	GoodsId = 1250301,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 422,
				},
			},
		},
	},
	DemandID = 410106,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id107] =
{
	Id = 107,
	Name = "订购陷阱",
	Desc = "需要大量陷阱",
	Value = 320301,
	Active = true,
	Weight = 225,
	PreGoal = 
	{
		308001,
	},
	CloseGoal = 
	{
		308002,
	},
	GoodsId = 1260301,
	Num = 3,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 1267,
				},
			},
		},
	},
	DemandID = 410107,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id108] =
{
	Id = 108,
	Name = "订购陷阱",
	Desc = "需要大量陷阱",
	Value = 320301,
	Active = true,
	Weight = 348,
	PreGoal = 
	{
		308002,
	},
	CloseGoal = 
	{
		308003,
	},
	GoodsId = 1270301,
	Num = 5,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 2111,
				},
			},
		},
	},
	DemandID = 410108,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id109] =
{
	Id = 109,
	Name = "订购陷阱",
	Desc = "需要大量陷阱",
	Value = 320301,
	Active = true,
	Weight = 646,
	PreGoal = 
	{
		308003,
	},
	CloseGoal = 
	{
		308004,
	},
	GoodsId = 1280301,
	Num = 8,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 3378,
				},
			},
		},
	},
	DemandID = 410109,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id110] =
{
	Id = 110,
	Name = "订购陷阱",
	Desc = "需要大量陷阱",
	Value = 320301,
	Active = true,
	Weight = 741,
	PreGoal = 
	{
		308004,
	},
	CloseGoal = 
	{
		308005,
	},
	GoodsId = 1290301,
	Num = 12,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5068,
				},
			},
		},
	},
	DemandID = 410110,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id111] =
{
	Id = 111,
	Name = "订购陷阱",
	Desc = "需要大量陷阱",
	Value = 320301,
	Active = true,
	Weight = 1035,
	PreGoal = 
	{
		308005,
	},
	GoodsId = 1300301,
	Num = 18,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 7602,
				},
			},
		},
	},
	DemandID = 410111,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id112] =
{
	Id = 112,
	Name = "0",
	Desc = "0",
	Value = 320302,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308002,
		300046,
	},
	CloseGoal = 
	{
		300072,
	},
	GoodsId = 1310302,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5215,
				},
			},
		},
	},
	DemandID = 410112,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id113] =
{
	Id = 113,
	Name = "0",
	Desc = "0",
	Value = 320302,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308002,
		300055,
	},
	CloseGoal = 
	{
		300080,
	},
	GoodsId = 1320302,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5215,
				},
			},
		},
	},
	DemandID = 410113,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id114] =
{
	Id = 114,
	Name = "0",
	Desc = "0",
	Value = 320302,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308002,
		300062,
	},
	CloseGoal = 
	{
		300091,
	},
	GoodsId = 1330302,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5215,
				},
			},
		},
	},
	DemandID = 410114,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id115] =
{
	Id = 115,
	Name = "0",
	Desc = "0",
	Value = 320302,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308002,
		300072,
	},
	CloseGoal = 
	{
		300403,
	},
	GoodsId = 1340302,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5215,
				},
			},
		},
	},
	DemandID = 410115,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id116] =
{
	Id = 116,
	Name = "0",
	Desc = "0",
	Value = 320302,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308002,
		300084,
	},
	CloseGoal = 
	{
		300417,
	},
	GoodsId = 1350302,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5215,
				},
			},
		},
	},
	DemandID = 410116,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id117] =
{
	Id = 117,
	Name = "0",
	Desc = "0",
	Value = 320302,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308002,
		300102,
	},
	CloseGoal = 
	{
		300431,
	},
	GoodsId = 1360302,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5215,
				},
			},
		},
	},
	DemandID = 410117,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id118] =
{
	Id = 118,
	Name = "0",
	Desc = "0",
	Value = 320302,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308002,
		300413,
	},
	CloseGoal = 
	{
		300450,
	},
	GoodsId = 1300302,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5215,
				},
			},
		},
	},
	DemandID = 410118,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id119] =
{
	Id = 119,
	Name = "0",
	Desc = "0",
	Value = 320302,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308002,
		300431,
	},
	CloseGoal = 
	{
		300470,
	},
	GoodsId = 1300302,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5215,
				},
			},
		},
	},
	DemandID = 410119,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id120] =
{
	Id = 120,
	Name = "0",
	Desc = "0",
	Value = 320302,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308002,
		300450,
	},
	CloseGoal = 
	{
		300494,
	},
	GoodsId = 1300302,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5215,
				},
			},
		},
	},
	DemandID = 410120,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id121] =
{
	Id = 121,
	Name = "0",
	Desc = "0",
	Value = 320302,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308002,
		300474,
	},
	GoodsId = 1300302,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5215,
				},
			},
		},
	},
	DemandID = 410121,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id122] =
{
	Id = 122,
	Name = "0",
	Desc = "0",
	Value = 320303,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308004,
		300072,
	},
	CloseGoal = 
	{
		300102,
	},
	GoodsId = 1410303,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 27489,
				},
			},
		},
	},
	DemandID = 410122,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id123] =
{
	Id = 123,
	Name = "0",
	Desc = "0",
	Value = 320303,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308004,
		300080,
	},
	CloseGoal = 
	{
		300406,
	},
	GoodsId = 1420303,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 27489,
				},
			},
		},
	},
	DemandID = 410123,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id124] =
{
	Id = 124,
	Name = "0",
	Desc = "0",
	Value = 320303,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308004,
		300087,
	},
	CloseGoal = 
	{
		300417,
	},
	GoodsId = 1430303,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 27489,
				},
			},
		},
	},
	DemandID = 410124,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id125] =
{
	Id = 125,
	Name = "0",
	Desc = "0",
	Value = 320303,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308004,
		300102,
	},
	CloseGoal = 
	{
		300428,
	},
	GoodsId = 1440303,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 27489,
				},
			},
		},
	},
	DemandID = 410125,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id126] =
{
	Id = 126,
	Name = "0",
	Desc = "0",
	Value = 320303,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308004,
		300410,
	},
	CloseGoal = 
	{
		300443,
	},
	GoodsId = 1400303,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 27489,
				},
			},
		},
	},
	DemandID = 410126,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id127] =
{
	Id = 127,
	Name = "0",
	Desc = "0",
	Value = 320303,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308004,
		300424,
	},
	CloseGoal = 
	{
		300458,
	},
	GoodsId = 1400303,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 27489,
				},
			},
		},
	},
	DemandID = 410127,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id128] =
{
	Id = 128,
	Name = "0",
	Desc = "0",
	Value = 320303,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308004,
		300439,
	},
	CloseGoal = 
	{
		300478,
	},
	GoodsId = 1400303,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 27489,
				},
			},
		},
	},
	DemandID = 410128,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id129] =
{
	Id = 129,
	Name = "0",
	Desc = "0",
	Value = 320303,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308004,
		300458,
	},
	CloseGoal = 
	{
		300499,
	},
	GoodsId = 1400303,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 27489,
				},
			},
		},
	},
	DemandID = 410129,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id130] =
{
	Id = 130,
	Name = "0",
	Desc = "0",
	Value = 320303,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308004,
		300478,
	},
	CloseGoal = 
	{
		300827,
	},
	GoodsId = 1400303,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 27489,
				},
			},
		},
	},
	DemandID = 410130,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id131] =
{
	Id = 131,
	Name = "0",
	Desc = "0",
	Value = 320303,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308004,
		300804,
	},
	GoodsId = 1400303,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 27489,
				},
			},
		},
	},
	DemandID = 410131,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id132] =
{
	Id = 132,
	Name = "订购空瓶",
	Desc = "需要大量空瓶",
	Value = 320305,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308053,
		300055,
	},
	CloseGoal = 
	{
		300080,
	},
	GoodsId = 1510305,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 422,
				},
			},
		},
	},
	DemandID = 410132,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id133] =
{
	Id = 133,
	Name = "0",
	Desc = "0",
	Value = 320305,
	Active = false,
	Weight = 0,
	GoodsId = 1520305,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 422,
				},
			},
		},
	},
	DemandID = 410133,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id134] =
{
	Id = 134,
	Name = "0",
	Desc = "0",
	Value = 320305,
	Active = false,
	Weight = 0,
	GoodsId = 1530305,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 422,
				},
			},
		},
	},
	DemandID = 410134,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id135] =
{
	Id = 135,
	Name = "订购空瓶",
	Desc = "需要大量空瓶",
	Value = 320305,
	Active = false,
	Weight = 0,
	GoodsId = 1540305,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 422,
				},
			},
		},
	},
	DemandID = 410135,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id136] =
{
	Id = 136,
	Name = "0",
	Desc = "0",
	Value = 320305,
	Active = false,
	Weight = 0,
	GoodsId = 1550305,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 422,
				},
			},
		},
	},
	DemandID = 410136,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id137] =
{
	Id = 137,
	Name = "订购空瓶",
	Desc = "需要大量空瓶",
	Value = 320305,
	Active = true,
	Weight = 420,
	PreGoal = 
	{
		308053,
	},
	CloseGoal = 
	{
		308054,
	},
	GoodsId = 1560305,
	Num = 3,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 1267,
				},
			},
		},
	},
	DemandID = 410137,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id138] =
{
	Id = 138,
	Name = "订购空瓶",
	Desc = "需要大量空瓶",
	Value = 320305,
	Active = true,
	Weight = 1020,
	PreGoal = 
	{
		308054,
	},
	CloseGoal = 
	{
		308055,
	},
	GoodsId = 1570305,
	Num = 5,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 2111,
				},
			},
		},
	},
	DemandID = 410138,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id139] =
{
	Id = 139,
	Name = "订购空瓶",
	Desc = "需要大量空瓶",
	Value = 320305,
	Active = true,
	Weight = 1287,
	PreGoal = 
	{
		308055,
	},
	CloseGoal = 
	{
		308056,
	},
	GoodsId = 1580305,
	Num = 8,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 3378,
				},
			},
		},
	},
	DemandID = 410139,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id140] =
{
	Id = 140,
	Name = "订购空瓶",
	Desc = "需要大量空瓶",
	Value = 320305,
	Active = true,
	Weight = 1848,
	PreGoal = 
	{
		308056,
	},
	CloseGoal = 
	{
		308057,
	},
	GoodsId = 1590305,
	Num = 12,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5068,
				},
			},
		},
	},
	DemandID = 410140,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id141] =
{
	Id = 141,
	Name = "订购空瓶",
	Desc = "需要大量空瓶",
	Value = 320305,
	Active = true,
	Weight = 2250,
	PreGoal = 
	{
		308057,
	},
	GoodsId = 1600305,
	Num = 18,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 7602,
				},
			},
		},
	},
	DemandID = 410141,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id142] =
{
	Id = 142,
	Name = "0",
	Desc = "0",
	Value = 320306,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308054,
		300413,
	},
	CloseGoal = 
	{
		300439,
	},
	GoodsId = 1600306,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5215,
				},
			},
		},
	},
	DemandID = 410142,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id143] =
{
	Id = 143,
	Name = "0",
	Desc = "0",
	Value = 320306,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308054,
		300421,
	},
	CloseGoal = 
	{
		300446,
	},
	GoodsId = 1600306,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5215,
				},
			},
		},
	},
	DemandID = 410143,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id144] =
{
	Id = 144,
	Name = "0",
	Desc = "0",
	Value = 320306,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308054,
		300428,
	},
	CloseGoal = 
	{
		300458,
	},
	GoodsId = 1600306,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5215,
				},
			},
		},
	},
	DemandID = 410144,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id145] =
{
	Id = 145,
	Name = "0",
	Desc = "0",
	Value = 320306,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308054,
		300439,
	},
	CloseGoal = 
	{
		300470,
	},
	GoodsId = 1600306,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5215,
				},
			},
		},
	},
	DemandID = 410145,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id146] =
{
	Id = 146,
	Name = "0",
	Desc = "0",
	Value = 320306,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308054,
		300450,
	},
	CloseGoal = 
	{
		300486,
	},
	GoodsId = 1600306,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5215,
				},
			},
		},
	},
	DemandID = 410146,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id147] =
{
	Id = 147,
	Name = "0",
	Desc = "0",
	Value = 320306,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308054,
		300466,
	},
	CloseGoal = 
	{
		300804,
	},
	GoodsId = 1600306,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5215,
				},
			},
		},
	},
	DemandID = 410147,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id148] =
{
	Id = 148,
	Name = "0",
	Desc = "0",
	Value = 320306,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308054,
		300482,
	},
	CloseGoal = 
	{
		300827,
	},
	GoodsId = 1600306,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5215,
				},
			},
		},
	},
	DemandID = 410148,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id149] =
{
	Id = 149,
	Name = "0",
	Desc = "0",
	Value = 320306,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308054,
		300804,
	},
	CloseGoal = 
	{
		300848,
	},
	GoodsId = 1600306,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5215,
				},
			},
		},
	},
	DemandID = 410149,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id150] =
{
	Id = 150,
	Name = "0",
	Desc = "0",
	Value = 320306,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308054,
		300827,
	},
	CloseGoal = 
	{
		300872,
	},
	GoodsId = 1600306,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5215,
				},
			},
		},
	},
	DemandID = 410150,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id151] =
{
	Id = 151,
	Name = "0",
	Desc = "0",
	Value = 320306,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308054,
		300852,
	},
	GoodsId = 1600306,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5215,
				},
			},
		},
	},
	DemandID = 410151,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id152] =
{
	Id = 152,
	Name = "0",
	Desc = "0",
	Value = 320307,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308056,
		300458,
	},
	CloseGoal = 
	{
		300486,
	},
	GoodsId = 1700307,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 27489,
				},
			},
		},
	},
	DemandID = 410152,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id153] =
{
	Id = 153,
	Name = "0",
	Desc = "0",
	Value = 320307,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308056,
		300466,
	},
	CloseGoal = 
	{
		300494,
	},
	GoodsId = 1700307,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 27489,
				},
			},
		},
	},
	DemandID = 410153,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id154] =
{
	Id = 154,
	Name = "0",
	Desc = "0",
	Value = 320307,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308056,
		300474,
	},
	CloseGoal = 
	{
		300810,
	},
	GoodsId = 1700307,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 27489,
				},
			},
		},
	},
	DemandID = 410154,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id155] =
{
	Id = 155,
	Name = "0",
	Desc = "0",
	Value = 320307,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308056,
		300486,
	},
	CloseGoal = 
	{
		300823,
	},
	GoodsId = 1700307,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 27489,
				},
			},
		},
	},
	DemandID = 410155,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id156] =
{
	Id = 156,
	Name = "0",
	Desc = "0",
	Value = 320307,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308056,
		300499,
	},
	CloseGoal = 
	{
		300840,
	},
	GoodsId = 1700307,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 27489,
				},
			},
		},
	},
	DemandID = 410156,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id157] =
{
	Id = 157,
	Name = "0",
	Desc = "0",
	Value = 320307,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308056,
		300819,
	},
	CloseGoal = 
	{
		300856,
	},
	GoodsId = 1700307,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 27489,
				},
			},
		},
	},
	DemandID = 410157,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id158] =
{
	Id = 158,
	Name = "0",
	Desc = "0",
	Value = 320307,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308056,
		300836,
	},
	CloseGoal = 
	{
		300876,
	},
	GoodsId = 1700307,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 27489,
				},
			},
		},
	},
	DemandID = 410158,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id159] =
{
	Id = 159,
	Name = "0",
	Desc = "0",
	Value = 320307,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308056,
		300856,
	},
	CloseGoal = 
	{
		300896,
	},
	GoodsId = 1700307,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 27489,
				},
			},
		},
	},
	DemandID = 410159,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id160] =
{
	Id = 160,
	Name = "0",
	Desc = "0",
	Value = 320307,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308056,
		300876,
	},
	CloseGoal = 
	{
		301224,
	},
	GoodsId = 1700307,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 27489,
				},
			},
		},
	},
	DemandID = 410160,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id161] =
{
	Id = 161,
	Name = "0",
	Desc = "0",
	Value = 320307,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308056,
		300900,
	},
	GoodsId = 1700307,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 27489,
				},
			},
		},
	},
	DemandID = 410161,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id162] =
{
	Id = 162,
	Name = "订购纸袋",
	Desc = "需要大量纸袋",
	Value = 320309,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308103,
		300443,
	},
	CloseGoal = 
	{
		300470,
	},
	GoodsId = 1800309,
	Num = 2,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 844,
				},
			},
		},
	},
	DemandID = 410162,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id163] =
{
	Id = 163,
	Name = "0",
	Desc = "0",
	Value = 320309,
	Active = false,
	Weight = 0,
	GoodsId = 1820309,
	Num = 2,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 844,
				},
			},
		},
	},
	DemandID = 410163,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id164] =
{
	Id = 164,
	Name = "0",
	Desc = "0",
	Value = 320309,
	Active = false,
	Weight = 0,
	GoodsId = 1830309,
	Num = 2,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 844,
				},
			},
		},
	},
	DemandID = 410164,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id165] =
{
	Id = 165,
	Name = "订购纸袋",
	Desc = "需要大量纸袋",
	Value = 320309,
	Active = false,
	Weight = 0,
	GoodsId = 1840309,
	Num = 2,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 844,
				},
			},
		},
	},
	DemandID = 410165,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id166] =
{
	Id = 166,
	Name = "0",
	Desc = "0",
	Value = 320309,
	Active = false,
	Weight = 0,
	GoodsId = 1850309,
	Num = 2,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 844,
				},
			},
		},
	},
	DemandID = 410166,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id167] =
{
	Id = 167,
	Name = "订购纸袋",
	Desc = "需要大量纸袋",
	Value = 320309,
	Active = true,
	Weight = 2052,
	PreGoal = 
	{
		308103,
	},
	CloseGoal = 
	{
		308104,
	},
	GoodsId = 1860309,
	Num = 3,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 1267,
				},
			},
		},
	},
	DemandID = 410167,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id168] =
{
	Id = 168,
	Name = "订购纸袋",
	Desc = "需要大量纸袋",
	Value = 320309,
	Active = true,
	Weight = 2900,
	PreGoal = 
	{
		308104,
	},
	CloseGoal = 
	{
		308105,
	},
	GoodsId = 1870309,
	Num = 5,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 2111,
				},
			},
		},
	},
	DemandID = 410168,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id169] =
{
	Id = 169,
	Name = "订购纸袋",
	Desc = "需要大量纸袋",
	Value = 320309,
	Active = true,
	Weight = 3339,
	PreGoal = 
	{
		308105,
	},
	CloseGoal = 
	{
		308106,
	},
	GoodsId = 1880309,
	Num = 8,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 3378,
				},
			},
		},
	},
	DemandID = 410169,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id170] =
{
	Id = 170,
	Name = "订购纸袋",
	Desc = "需要大量纸袋",
	Value = 320309,
	Active = true,
	Weight = 4012,
	PreGoal = 
	{
		308106,
	},
	CloseGoal = 
	{
		308107,
	},
	GoodsId = 1890309,
	Num = 12,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5068,
				},
			},
		},
	},
	DemandID = 410170,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id171] =
{
	Id = 171,
	Name = "订购纸袋",
	Desc = "需要大量纸袋",
	Value = 320309,
	Active = true,
	Weight = 5328,
	PreGoal = 
	{
		308107,
	},
	GoodsId = 1900309,
	Num = 18,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 7602,
				},
			},
		},
	},
	DemandID = 410171,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id172] =
{
	Id = 172,
	Name = "0",
	Desc = "0",
	Value = 320310,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308104,
		300490,
	},
	CloseGoal = 
	{
		300823,
	},
	GoodsId = 1900310,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5215,
				},
			},
		},
	},
	DemandID = 410172,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id173] =
{
	Id = 173,
	Name = "0",
	Desc = "0",
	Value = 320310,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308104,
		300499,
	},
	CloseGoal = 
	{
		300832,
	},
	GoodsId = 1900310,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5215,
				},
			},
		},
	},
	DemandID = 410173,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id174] =
{
	Id = 174,
	Name = "0",
	Desc = "0",
	Value = 320310,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308104,
		300810,
	},
	CloseGoal = 
	{
		300844,
	},
	GoodsId = 1900310,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5215,
				},
			},
		},
	},
	DemandID = 410174,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id175] =
{
	Id = 175,
	Name = "0",
	Desc = "0",
	Value = 320310,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308104,
		300823,
	},
	CloseGoal = 
	{
		300856,
	},
	GoodsId = 1900310,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5215,
				},
			},
		},
	},
	DemandID = 410175,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id176] =
{
	Id = 176,
	Name = "0",
	Desc = "0",
	Value = 320310,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308104,
		300836,
	},
	CloseGoal = 
	{
		300872,
	},
	GoodsId = 1900310,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5215,
				},
			},
		},
	},
	DemandID = 410176,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id177] =
{
	Id = 177,
	Name = "0",
	Desc = "0",
	Value = 320310,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308104,
		300852,
	},
	CloseGoal = 
	{
		300888,
	},
	GoodsId = 1900310,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5215,
				},
			},
		},
	},
	DemandID = 410177,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id178] =
{
	Id = 178,
	Name = "0",
	Desc = "0",
	Value = 320310,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308104,
		300868,
	},
	CloseGoal = 
	{
		301204,
	},
	GoodsId = 1900310,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5215,
				},
			},
		},
	},
	DemandID = 410178,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id179] =
{
	Id = 179,
	Name = "0",
	Desc = "0",
	Value = 320310,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308104,
		300888,
	},
	CloseGoal = 
	{
		301232,
	},
	GoodsId = 1900310,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5215,
				},
			},
		},
	},
	DemandID = 410179,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id180] =
{
	Id = 180,
	Name = "0",
	Desc = "0",
	Value = 320310,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308104,
		301204,
	},
	CloseGoal = 
	{
		301256,
	},
	GoodsId = 1900310,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5215,
				},
			},
		},
	},
	DemandID = 410180,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id181] =
{
	Id = 181,
	Name = "0",
	Desc = "0",
	Value = 320310,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308104,
		301236,
	},
	GoodsId = 1900310,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5215,
				},
			},
		},
	},
	DemandID = 410181,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id182] =
{
	Id = 182,
	Name = "0",
	Desc = "0",
	Value = 320311,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308106,
		300832,
	},
	CloseGoal = 
	{
		300860,
	},
	GoodsId = 2000311,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 33411,
				},
			},
		},
	},
	DemandID = 410182,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id183] =
{
	Id = 183,
	Name = "0",
	Desc = "0",
	Value = 320311,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308106,
		300840,
	},
	CloseGoal = 
	{
		300868,
	},
	GoodsId = 2000311,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 33411,
				},
			},
		},
	},
	DemandID = 410183,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id184] =
{
	Id = 184,
	Name = "0",
	Desc = "0",
	Value = 320311,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308106,
		300848,
	},
	CloseGoal = 
	{
		300880,
	},
	GoodsId = 2000311,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 33411,
				},
			},
		},
	},
	DemandID = 410184,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id185] =
{
	Id = 185,
	Name = "0",
	Desc = "0",
	Value = 320311,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308106,
		300860,
	},
	CloseGoal = 
	{
		300892,
	},
	GoodsId = 2000311,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 33411,
				},
			},
		},
	},
	DemandID = 410185,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id186] =
{
	Id = 186,
	Name = "0",
	Desc = "0",
	Value = 320311,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308106,
		300872,
	},
	CloseGoal = 
	{
		301204,
	},
	GoodsId = 2000311,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 33411,
				},
			},
		},
	},
	DemandID = 410186,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id187] =
{
	Id = 187,
	Name = "0",
	Desc = "0",
	Value = 320311,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308106,
		300888,
	},
	CloseGoal = 
	{
		301228,
	},
	GoodsId = 2000311,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 33411,
				},
			},
		},
	},
	DemandID = 410187,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id188] =
{
	Id = 188,
	Name = "0",
	Desc = "0",
	Value = 320311,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308106,
		300904,
	},
	CloseGoal = 
	{
		301248,
	},
	GoodsId = 2000311,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 33411,
				},
			},
		},
	},
	DemandID = 410188,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id189] =
{
	Id = 189,
	Name = "0",
	Desc = "0",
	Value = 320311,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308106,
		301228,
	},
	CloseGoal = 
	{
		301268,
	},
	GoodsId = 2000311,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 33411,
				},
			},
		},
	},
	DemandID = 410189,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id190] =
{
	Id = 190,
	Name = "0",
	Desc = "0",
	Value = 320311,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308106,
		301248,
	},
	CloseGoal = 
	{
		301292,
	},
	GoodsId = 2000311,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 33411,
				},
			},
		},
	},
	DemandID = 410190,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id191] =
{
	Id = 191,
	Name = "0",
	Desc = "0",
	Value = 320311,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308106,
		301272,
	},
	GoodsId = 2000311,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 33411,
				},
			},
		},
	},
	DemandID = 410191,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id192] =
{
	Id = 192,
	Name = "订购工具箱",
	Desc = "需要大量工具箱",
	Value = 320313,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308153,
		300819,
	},
	CloseGoal = 
	{
		300848,
	},
	GoodsId = 2100313,
	Num = 3,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 1267,
				},
			},
		},
	},
	DemandID = 410192,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id193] =
{
	Id = 193,
	Name = "0",
	Desc = "0",
	Value = 320313,
	Active = false,
	Weight = 0,
	GoodsId = 2120313,
	Num = 3,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 1267,
				},
			},
		},
	},
	DemandID = 410193,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id194] =
{
	Id = 194,
	Name = "0",
	Desc = "0",
	Value = 320313,
	Active = false,
	Weight = 0,
	GoodsId = 2130313,
	Num = 3,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 1267,
				},
			},
		},
	},
	DemandID = 410194,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id195] =
{
	Id = 195,
	Name = "订购工具箱",
	Desc = "需要大量工具箱",
	Value = 320313,
	Active = false,
	Weight = 0,
	GoodsId = 2140313,
	Num = 3,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 1267,
				},
			},
		},
	},
	DemandID = 410195,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id196] =
{
	Id = 196,
	Name = "0",
	Desc = "0",
	Value = 320313,
	Active = false,
	Weight = 0,
	GoodsId = 2150313,
	Num = 3,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 1267,
				},
			},
		},
	},
	DemandID = 410196,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id197] =
{
	Id = 197,
	Name = "订购工具箱",
	Desc = "需要大量工具箱",
	Value = 320313,
	Active = true,
	Weight = 4032,
	PreGoal = 
	{
		308153,
	},
	CloseGoal = 
	{
		308154,
	},
	GoodsId = 2160313,
	Num = 3,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 1267,
				},
			},
		},
	},
	DemandID = 410197,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id198] =
{
	Id = 198,
	Name = "订购工具箱",
	Desc = "需要大量工具箱",
	Value = 320313,
	Active = true,
	Weight = 4636,
	PreGoal = 
	{
		308154,
	},
	CloseGoal = 
	{
		308155,
	},
	GoodsId = 2170313,
	Num = 5,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 2111,
				},
			},
		},
	},
	DemandID = 410198,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id199] =
{
	Id = 199,
	Name = "订购工具箱",
	Desc = "需要大量工具箱",
	Value = 320313,
	Active = true,
	Weight = 5184,
	PreGoal = 
	{
		308155,
	},
	CloseGoal = 
	{
		308156,
	},
	GoodsId = 2180313,
	Num = 8,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 3378,
				},
			},
		},
	},
	DemandID = 410199,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id200] =
{
	Id = 200,
	Name = "订购工具箱",
	Desc = "需要大量工具箱",
	Value = 320313,
	Active = true,
	Weight = 6622,
	PreGoal = 
	{
		308156,
	},
	CloseGoal = 
	{
		308157,
	},
	GoodsId = 2190313,
	Num = 12,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5068,
				},
			},
		},
	},
	DemandID = 410200,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
