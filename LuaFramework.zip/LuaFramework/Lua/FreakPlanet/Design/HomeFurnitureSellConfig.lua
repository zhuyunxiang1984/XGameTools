HomeFurnitureSellConfig ={};
HomeFurnitureSellID = 
{
	Id001 = 1220001,
	Id002 = 1220002,
	Id003 = 1220003,
	Id004 = 1220004,
	Id005 = 1220005,
	Id006 = 1220006,
}
HomeFurnitureSellConfig[HomeFurnitureSellID.Id001] =
{
	Id = 1,
	ConditionList = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 1,
			NumMin = 0,
			NumMax = 9999999,
		},
	},
	SellList = {
		{
			Weight = 100,
			HomeFurnitureList = {
				{
					Id = 1210001,
					Num = 1,
					Weight = 100,
				},
				{
					Id = 1210002,
					Num = 1,
					Weight = 100,
				},
				{
					Id = 1210003,
					Num = 1,
					Weight = 100,
				},
			},
			ConditionList = {
				{
					Condition = PackageCondition.LoginDays,
					NumMin = 1,
					NumMax = 30,
				},
			},
		},
	},
}
HomeFurnitureSellConfig[HomeFurnitureSellID.Id002] =
{
	Id = 2,
	ConditionList = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 2,
			NumMin = 0,
			NumMax = 9999999,
		},
	},
	SellList = {
		{
			Weight = 100,
			HomeFurnitureList = {
				{
					Id = 1210001,
					Num = 1,
					Weight = 100,
				},
				{
					Id = 1210002,
					Num = 1,
					Weight = 100,
				},
				{
					Id = 1210003,
					Num = 1,
					Weight = 100,
				},
			},
			ConditionList = {
				{
					Condition = PackageCondition.OwnAssets,
					Value = 2,
					NumMin = 5,
					NumMax = 99999999,
				},
			},
		},
	},
}
HomeFurnitureSellConfig[HomeFurnitureSellID.Id003] =
{
	Id = 3,
	ConditionList = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 2,
			NumMin = 0,
			NumMax = 9999999,
		},
	},
	SellList = {
		{
			Weight = 100,
			HomeFurnitureList = {
				{
					Id = 1210001,
					Num = 1,
					Weight = 100,
				},
				{
					Id = 1210002,
					Num = 1,
					Weight = 100,
				},
				{
					Id = 1210003,
					Num = 1,
					Weight = 100,
				},
			},
		},
	},
}
HomeFurnitureSellConfig[HomeFurnitureSellID.Id004] =
{
	Id = 4,
	ConditionList = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 2,
			NumMin = 0,
			NumMax = 9999999,
		},
	},
	SellList = {
		{
			Weight = 100,
			HomeFurnitureList = {
				{
					Id = 1210004,
					Num = 1,
					Weight = 100,
				},
				{
					Id = 1210005,
					Num = 1,
					Weight = 100,
				},
			},
		},
	},
}
HomeFurnitureSellConfig[HomeFurnitureSellID.Id005] =
{
	Id = 5,
	ConditionList = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 2,
			NumMin = 0,
			NumMax = 9999999,
		},
	},
	SellList = {
		{
			Weight = 100,
			HomeFurnitureList = {
				{
					Id = 1210006,
					Num = 1,
					Weight = 100,
				},
			},
		},
	},
}
HomeFurnitureSellConfig[HomeFurnitureSellID.Id006] =
{
	Id = 6,
	ConditionList = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 2,
			NumMin = 0,
			NumMax = 9999999,
		},
	},
	SellList = {
		{
			Weight = 100,
			HomeFurnitureList = {
				{
					Id = 1210007,
					Num = 1,
					Weight = 100,
				},
			},
		},
	},
}

