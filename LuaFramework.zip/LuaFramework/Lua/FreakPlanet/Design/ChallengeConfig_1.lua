
ChallengeConfig[ChallengeID.Id001] =
{
	Id = 1,
	Name = "挑战史莱姆代表",
	Area = 130002,
	PreCondition = {
		PreGoal = 
		{
			300001,
		},
	},
	Desc = "体内带有大量绿色素的小精灵，喜欢捡冒险者丢掉的东西，被它碰到的东西就会被染成绿色，不要丢下帽子。",
	ResultText = "打败了初始城镇的史莱姆代表",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 2,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	Enemy = {
		{
			Value = 240001,
			Level = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id002] =
{
	Id = 2,
	Name = "挑战野花丛",
	Area = 130002,
	PreCondition = {
		PreGoal = 
		{
			300003,
		},
	},
	Desc = "潜伏在路边的小花丛，以绊倒路人取乐，让对方只能忍气吞声。\n拜托，你不会是想对一朵花发火吧？",
	ResultText = "初始城镇出现了花丛",
	Dialog = "只是路过也要被打的吗？",
	NumCap = 2,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	Enemy = {
		{
			Value = 240002,
			Level = 3,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id003] =
{
	Id = 3,
	Name = "挑战花球老大",
	Area = 130002,
	PreCondition = {
		PreGoal = 
		{
			300007,
		},
	},
	AcceptSpeech = 14000301,
	Desc = "活泼好动的小花球，有时候会溜进人类的城镇里探险。不喜欢自己的名字，正在努力减肥，希望能被人叫做小花干。",
	ResultText = "初始城镇出现了小花球",
	Dialog = "居然两个打一个…好气噢…",
	NumCap = 2,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	Enemy = {
		{
			Value = 240003,
			Level = 5,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id004] =
{
	Id = 4,
	Name = "挑战剑士",
	Area = 130002,
	PreCondition = {
		PreGoal = 
		{
			300012,
		},
	},
	AcceptSpeech = 14000401,
	Desc = "自称为冒险星的主角，身负打败魔王以及为世界带来和平的重任。虽然帮助村民不求回报，但缺物资时，会以正义之名进入NPC家中取走合用的财物。",
	ResultText = "剑士加入了队伍",
	Dialog = "能打败我的，就是我的朋友！",
	NumCap = 2,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220001,
				220002,
			},
			Desc = "队伍中必须有呜呜或漆漆",
			Hint = "队伍中必须有呜呜或漆漆",
		},
	},
	Enemy = {
		{
			Value = 240004,
			Level = 6,
		},
	},
	Reward = {
		{
			Value = 220003,
			Num = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id005] =
{
	Id = 5,
	Name = "挑战精英大树怪",
	Area = 130003,
	PreCondition = {
		PreGoal = 
		{
			300016,
		},
	},
	AcceptSpeech = 14000501,
	Desc = "憨直的大树怪，结出的果实美味可口，听说还帮助科学家发现了万有引力。",
	ResultText = "村口树林出现了大树怪",
	Dialog = "唔，属性完全被克制了！",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220003,
			},
			Desc = "队伍中必须有剑士",
			Hint = "队伍中必须有剑士",
		},
	},
	Enemy = {
		{
			Value = 240005,
			Level = 8,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id006] =
{
	Id = 6,
	Name = "挑战树桩猴老大",
	Area = 130003,
	PreCondition = {
		PreGoal = 
		{
			300019,
		},
	},
	AcceptSpeech = 14000601,
	Desc = "生命力旺盛的树桩猴，扎在土里能长成大树，但是非常好动，根本坐不住，经常把自己连根拔起。",
	ResultText = "村口树林出现了树桩猴",
	Dialog = "想不到手快也没用了…",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220003,
			},
			Desc = "队伍中必须有剑士",
			Hint = "队伍中必须有剑士",
		},
	},
	Enemy = {
		{
			Value = 240006,
			Level = 10,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id007] =
{
	Id = 7,
	Name = "挑战弓箭手",
	Area = 130003,
	PreCondition = {
		PreGoal = 
		{
			300022,
		},
	},
	AcceptSpeech = 14000701,
	Desc = "精灵国的美丽公主，目前正独自外出历练。拥有举世无双的射术，但遇到可怕的怪物便会立刻陷入战斗不能状态。",
	ResultText = "弓箭手加入了队伍",
	Dialog = "真是爽快的一战！",
	NumCap = 3,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG01",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdAnd",
			Value = 
			{
				220003,
				220001,
				220002,
			},
			Desc = "队伍中必须有剑士,呜呜,漆漆",
			Hint = "队伍中必须有剑士,呜呜,漆漆",
		},
	},
	Enemy = {
		{
			Value = 240007,
			Level = 12,
		},
	},
	Reward = {
		{
			Value = 220004,
			Num = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id008] =
{
	Id = 8,
	Name = "挑战野狼队长",
	Area = 130004,
	PreCondition = {
		PreGoal = 
		{
			300029,
		},
	},
	AcceptSpeech = 14000801,
	Desc = "经常成群袭击路人的野兽，非常凶猛，可以用骨头引开它的注意力。",
	ResultText = "溪谷出现了野狼",
	Dialog = "汪汪汪！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG02",
	StartScene = "RPG_StartScene",
	Enemy = {
		{
			Value = 240008,
			Level = 14,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id009] =
{
	Id = 9,
	Name = "挑战白狼头领",
	Area = 130004,
	PreCondition = {
		PreGoal = 
		{
			300034,
		},
	},
	AcceptSpeech = 14000901,
	Desc = "狼群的领袖，与众不同的颜色给人以强烈的压迫感。比较挑食，只接受带肉的骨头。",
	ResultText = "溪谷出现了白狼",
	Dialog = "嗷呜…",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG02",
	StartScene = "RPG_StartScene",
	Enemy = {
		{
			Value = 240009,
			Level = 17,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id010] =
{
	Id = 10,
	Name = "挑战猎人",
	Area = 130004,
	PreCondition = {
		PreGoal = 
		{
			300039,
		},
	},
	AcceptSpeech = 14001001,
	Desc = "胆小又不认路的猎人，天生体弱多病。妈妈非常宠他，但爸爸却很严厉。被爸爸强制送往冒险夏令营后，独自在野外修炼。",
	ResultText = "猎人加入了队伍",
	Dialog = "哎哎…好危险啊…",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG02",
	StartScene = "RPG_StartScene",
	Enemy = {
		{
			Value = 240010,
			Level = 19,
		},
	},
	Reward = {
		{
			Value = 220005,
			Num = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id011] =
{
	Id = 11,
	Name = "挑战史莱姆代表",
	Area = 130005,
	PreCondition = {
		PreGoal = 
		{
			300042,
		},
	},
	AcceptSpeech = 14001101,
	Desc = "体内带有大量蓝色素的小精灵，喜欢捡冒险者丢掉的东西，被它碰到的东西就会被染成蓝色。",
	ResultText = "打败了魔法平原的史莱姆代表",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG02",
	StartScene = "RPG_StartScene",
	Enemy = {
		{
			Value = 240011,
			Level = 15,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id012] =
{
	Id = 12,
	Name = "挑战精英祭祀石",
	Area = 130005,
	PreCondition = {
		PreGoal = 
		{
			300045,
		},
	},
	AcceptSpeech = 14001201,
	Desc = "古代神庙祭祀用的大石头，能够驱邪，家里如果闹鬼，可以搬一块回家。",
	ResultText = "魔法平原出现了祭祀石",
	Dialog = "…",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG02",
	StartScene = "RPG_StartScene",
	Enemy = {
		{
			Value = 240012,
			Level = 18,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id013] =
{
	Id = 13,
	Name = "挑战石怪老大",
	Area = 130005,
	PreCondition = {
		PreGoal = 
		{
			300050,
		},
	},
	AcceptSpeech = 14001301,
	Desc = "出没在山地的石怪，喜欢躲在暗处听冒险者讲传奇故事，被发现的话就会害羞得装成石头。",
	ResultText = "魔法平原出现了小石怪",
	Dialog = "看来我们分不出胜负，再见！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG02",
	StartScene = "RPG_StartScene",
	Enemy = {
		{
			Value = 240013,
			Level = 20,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id014] =
{
	Id = 14,
	Name = "挑战平原守护者",
	Area = 130005,
	PreCondition = {
		PreGoal = 
		{
			300054,
		},
	},
	AcceptSpeech = 14001401,
	Desc = "平原的守护者，对其他生物很不友好。其实是个慢性子，说话结巴，最大的梦想是有人能听完它的自我介绍。",
	ResultText = "魔法平原出现了石巨人",
	Dialog = "哎哟，血没回上来…",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG02",
	StartScene = "RPG_StartScene",
	Enemy = {
		{
			Value = 240014,
			Level = 23,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id015] =
{
	Id = 15,
	Name = "挑战小土包代表",
	Area = 130006,
	PreCondition = {
		PreGoal = 
		{
			300057,
		},
	},
	AcceptSpeech = 14001501,
	Desc = "最恨人说烂泥扶不上墙，一旦听到就会发飙。",
	ResultText = "古代遗迹出现了小土包",
	Dialog = "再说一次，我不是烂泥！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG02",
	StartScene = "RPG_StartScene",
	Enemy = {
		{
			Value = 240015,
			Level = 26,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id016] =
{
	Id = 16,
	Name = "挑战地缚灵头目",
	Area = 130006,
	PreCondition = {
		PreGoal = 
		{
			300061,
		},
	},
	AcceptSpeech = 14001601,
	Desc = "出没在遗迹附近的精灵，以死去之人残存的气息为食，如果惹到了它，它会偷偷跟在你后面，找机会绊你一跤。",
	ResultText = "古代遗迹出现了地缚灵",
	Dialog = "好想出去晒晒太阳啊——",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG02",
	StartScene = "RPG_StartScene",
	Enemy = {
		{
			Value = 240016,
			Level = 29,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id017] =
{
	Id = 17,
	Name = "挑战骨头兵",
	Area = 130006,
	PreCondition = {
		PreGoal = 
		{
			300065,
		},
	},
	AcceptSpeech = 14001701,
	Desc = "魔王有限公司临时雇员，即使被拆散了也能很快拼回去，是地城副本中很重要的成员。\n不过偶尔会发生重新拼装时，多出一些骨头的问题。",
	ResultText = "骨头兵加入了队伍",
	Dialog = "多谢英雄饶小的一命！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG02",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdAnd",
			Value = 
			{
				220003,
			},
			Desc = "队伍中必须有剑士",
			Hint = "队伍中必须有剑士",
		},
	},
	Enemy = {
		{
			Value = 240017,
			Level = 30,
		},
	},
	Reward = {
		{
			Value = 220006,
			Num = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id018] =
{
	Id = 18,
	Name = "挑战史莱姆代表",
	Area = 130007,
	PreCondition = {
		PreGoal = 
		{
			300068,
		},
	},
	AcceptSpeech = 14001801,
	Desc = "体内带有大量紫色素的小精灵，喜欢捡冒险者丢掉的东西，被它碰到的东西就会被染成紫色。",
	ResultText = "打败了大沼泽的史莱姆代表",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG03",
	StartScene = "RPG_StartScene",
	Enemy = {
		{
			Value = 240018,
			Level = 28,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id019] =
{
	Id = 19,
	Name = "挑战超深沼泽地",
	Area = 130007,
	PreCondition = {
		PreGoal = 
		{
			300071,
		},
	},
	AcceptSpeech = 14001901,
	Desc = "躲在沼泽地区不起眼的怪物，只顾看攻略没看路的冒险者踩上去后会被快速吞没。",
	ResultText = "大沼泽出现了沼泽地",
	Dialog = "来啊，快来跳泥坑呀~",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG03",
	StartScene = "RPG_StartScene",
	Enemy = {
		{
			Value = 240019,
			Level = 32,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id020] =
{
	Id = 20,
	Name = "挑战泥怪头领",
	Area = 130007,
	PreCondition = {
		PreGoal = 
		{
			300074,
		},
	},
	AcceptSpeech = 14002001,
	Desc = "拥有很强粘性的魔物，即使是凶猛的野兽，如果被它困住，最后也难逃厄运。",
	ResultText = "大沼泽出现了泥怪",
	Dialog = "呕…太脏了！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG03",
	StartScene = "RPG_StartScene",
	Enemy = {
		{
			Value = 240020,
			Level = 36,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id021] =
{
	Id = 21,
	Name = "挑战树精头领",
	Area = 130007,
	PreCondition = {
		PreGoal = 
		{
			300079,
		},
	},
	AcceptSpeech = 14002101,
	Desc = "吸取树木精华为生的精灵，说不清是植物还是精灵，负责净化沼泽地区的空气质量。",
	ResultText = "大沼泽出现了沼泽树精",
	Dialog = "不准滥砍滥伐！也不准砍我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG03",
	StartScene = "RPG_StartScene",
	Enemy = {
		{
			Value = 240021,
			Level = 40,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id022] =
{
	Id = 22,
	Name = "挑战指路NPC",
	Area = 130007,
	PreCondition = {
		PreGoal = 
		{
			300083,
		},
	},
	AcceptSpeech = 14002201,
	Desc = "热心的冒险星原住民，和宠物猪一起居住在沼泽深处。专门给来自世界各地的冒险者指路。说话时会用最近学会的口音，以至于大部分人都听不懂他的话。",
	ResultText = "指路NPC加入了队伍",
	Dialog = "前面拐9个弯，就是目的地！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG03",
	StartScene = "RPG_StartScene",
	Enemy = {
		{
			Value = 240022,
			Level = 42,
		},
	},
	Reward = {
		{
			Value = 220007,
			Num = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id023] =
{
	Id = 23,
	Name = "挑战刺毛怪小队长",
	Area = 130008,
	PreCondition = {
		PreGoal = 
		{
			300303,
		},
	},
	Desc = "在任何地区都能悠闲漫步的魔物。遇到危险时，就会竖起身上的钢针进行抵御。",
	ResultText = "深坑谷出现了刺毛怪",
	Dialog = "我的刺都弯了！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG03",
	StartScene = "RPG_StartScene",
	Enemy = {
		{
			Value = 240023,
			Level = 37,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id024] =
{
	Id = 24,
	Name = "挑战刺毛怪大王",
	Area = 130008,
	PreCondition = {
		PreGoal = 
		{
			300308,
		},
	},
	Desc = "年龄超过两百岁的超级刺毛怪，身上的钢针带有令人麻痹的毒液，是令人无法靠近的存在。",
	ResultText = "深坑谷出现了钢铁刺毛怪",
	Dialog = "快拿仙人掌来给我疗伤！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG03",
	StartScene = "RPG_StartScene",
	Enemy = {
		{
			Value = 240024,
			Level = 41,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id025] =
{
	Id = 25,
	Name = "挑战史莱姆代表",
	Area = 130009,
	PreCondition = {
		PreGoal = 
		{
			300311,
		},
	},
	Desc = "体内带有大量红色素的小精灵，喜欢捡冒险者丢掉的东西，被它碰到的东西就会被染成红色，但如果碰到蓝色史莱姆就会染成紫色。",
	ResultText = "魔王火山出现了红色史莱姆",
	Dialog = "打败一个我，还有千万个我。",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG05",
	StartScene = "RPG_StartScene",
	Enemy = {
		{
			Value = 240025,
			Level = 36,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id026] =
{
	Id = 26,
	Name = "挑战岩浆喷泉",
	Area = 130009,
	PreCondition = {
		PreGoal = 
		{
			300314,
		},
	},
	Desc = "无论快乐或悲伤，都会通过喷发岩浆来宣泄情绪。",
	ResultText = "魔王火山出现了火喷泉",
	Dialog = "一定是我喷的不够才失败了。",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG05",
	StartScene = "RPG_StartScene",
	Enemy = {
		{
			Value = 240026,
			Level = 42,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id027] =
{
	Id = 27,
	Name = "挑战火山王",
	Area = 130009,
	PreCondition = {
		PreGoal = 
		{
			300317,
		},
	},
	Desc = "只想做一个安静美男子的景观类魔物，火山口的熔岩刘海经常引来300%的回头率。",
	ResultText = "魔王火山出现了小火山",
	Dialog = "让火焰…净化一切…",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG05",
	StartScene = "RPG_StartScene",
	Enemy = {
		{
			Value = 240027,
			Level = 45,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id028] =
{
	Id = 28,
	Name = "挑战铁匠",
	Area = 130009,
	PreCondition = {
		PreGoal = 
		{
			300321,
		},
	},
	AcceptSpeech = 14002801,
	Desc = "冒险星人气NPC，提供装备买卖、修理、强化等服务，是勇者不可或缺的好帮手。\n“哎呀，手一滑装备爆炸了，阁下运气不太好噢~”",
	ResultText = "铁匠加入了队伍",
	Dialog = "别打了…免费+10行么？",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG05",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdOr",
			Value = 
			{
				220003,
				220004,
				220010,
			},
			Desc = "队伍中必须有剑士或弓箭手或魔法师",
			Hint = "队伍中必须有剑士或弓箭手或魔法师",
		},
	},
	Enemy = {
		{
			Value = 240028,
			Level = 47,
		},
	},
	Reward = {
		{
			Value = 220008,
			Num = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id029] =
{
	Id = 29,
	Name = "挑战小火球代表",
	Area = 130010,
	PreCondition = {
		PreGoal = 
		{
			300086,
		},
	},
	AcceptSpeech = 14002901,
	Desc = "数据证明，百分之九十九的冒险家无法分清不同的小火球。\n它从岩浆里跳了起来，它掉了下去。\n它的兄弟从岩浆里跳了起来。",
	ResultText = "魔王城堡出现了小火球",
	Dialog = "烫烫烫！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG04",
	StartScene = "RPG_StartScene",
	Enemy = {
		{
			Value = 240029,
			Level = 44,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id030] =
{
	Id = 30,
	Name = "挑战熔岩猪头领",
	Area = 130010,
	PreCondition = {
		PreGoal = 
		{
			300090,
		},
	},
	AcceptSpeech = 14003001,
	Desc = "被魔王收养的宠物猪，在高热的情况下会发出肉香，用来诱惑来到火山地区的冒险家分泌口水，使其加速脱水而失去战斗能力。",
	ResultText = "魔王城堡出现了熔岩猪",
	Dialog = "打归打，流口水几个意思？",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG04",
	StartScene = "RPG_StartScene",
	Enemy = {
		{
			Value = 240030,
			Level = 48,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id031] =
{
	Id = 31,
	Name = "挑战火山巨蟹头领",
	Area = 130010,
	PreCondition = {
		PreGoal = 
		{
			300095,
		},
	},
	AcceptSpeech = 14003101,
	Desc = "挥舞着两只强力巨钳的高级魔物，不过更出名的是其鲜美的肉质，是美食家们梦寐以求的高级海鲜。常与熔岩猪一起出马，加速冒险家的脱水危机。",
	ResultText = "魔王城堡出现了火山巨蟹",
	Dialog = "那个…刀叉收一下…",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG04",
	StartScene = "RPG_StartScene",
	Enemy = {
		{
			Value = 240031,
			Level = 54,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id032] =
{
	Id = 32,
	Name = "挑战小魔王",
	Area = 130010,
	PreCondition = {
		PreGoal = 
		{
			300101,
		},
	},
	AcceptSpeech = 14003201,
	Desc = "魔王公司负责人，坐镇魔王城堡。对于管理员工和设计副本很有两把刷子。最喜欢在顶楼办公室的超大落地窗前，思考下个月怎么再干掉一百个勇者。",
	ResultText = "小魔王加入了队伍",
	Dialog = "难道…这就是友情的力量？",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG04",
	StartScene = "RPG_StartScene",
	TeamCondition = {
		{
			Condition = "TeamCharacterIdAnd",
			Value = 
			{
				220003,
			},
			Desc = "队伍中必须有剑士",
			Hint = "队伍中必须有剑士",
		},
	},
	Enemy = {
		{
			Value = 240032,
			Level = 56,
		},
	},
	Reward = {
		{
			Value = 220009,
			Num = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id033] =
{
	Id = 33,
	Name = "挑战火精灵王",
	Area = 130011,
	PreCondition = {
		PreGoal = 
		{
			300325,
		},
	},
	Desc = "以矿石为食的精灵，体内有大量燃烧结晶。吃矿石的时候喜欢放凉再吃，它怕烫。",
	ResultText = "藏宝库出现了火精灵",
	Dialog = "其实我不是这里的Boss…",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG05",
	StartScene = "RPG_StartScene",
	Enemy = {
		{
			Value = 240033,
			Level = 72,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id034] =
{
	Id = 34,
	Name = "挑战火焰巨人王",
	Area = 130011,
	PreCondition = {
		PreGoal = 
		{
			300329,
		},
	},
	Desc = "火山的可怕魔物，喷吐的烈焰可以融化矿石，是魔王城堡当之无愧的强者。",
	ResultText = "藏宝库出现了火焰巨人",
	Dialog = "哇啊！！！！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "RPGBG05",
	StartScene = "RPG_StartScene",
	Enemy = {
		{
			Value = 240034,
			Level = 80,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id201] =
{
	Id = 201,
	Name = "挑战草莓推销员",
	Area = 130051,
	PreCondition = {
		PreGoal = 
		{
			300402,
		},
	},
	AcceptSpeech = 14020101,
	Desc = "味道酸甜清爽的草莓，经常作为甜点的装饰品出现。因为大部分冒险家不想弄一手黏黏的汁水，所以某些程度上也是个棘手的敌人。",
	ResultText = "打败了着陆点的草莓推销员",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "FATBG02",
	StartScene = "FAT_StartScene",
	Enemy = {
		{
			Value = 240035,
			Level = 50,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id202] =
{
	Id = 202,
	Name = "挑战鱼头老板",
	Area = 130052,
	PreCondition = {
		PreGoal = 
		{
			300405,
		},
	},
	AcceptSpeech = 14020201,
	Desc = "非常可口的甜点，整份很难吃完，所以头部会切下来单卖。但总有客人抱怨头部的馅料太少了。",
	ResultText = "鲷鱼镇出现了阿头",
	Dialog = "谁见到我的裤子了！？",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "FATBG04",
	StartScene = "FAT_StartScene",
	Enemy = {
		{
			Value = 240036,
			Level = 54,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id203] =
{
	Id = 203,
	Name = "挑战鱼尾老板",
	Area = 130052,
	PreCondition = {
		PreGoal = 
		{
			300409,
		},
	},
	AcceptSpeech = 14020301,
	Desc = "非常可口的甜点，整份很难吃完，所以尾巴会切下来单卖。但总有客人抱怨尾部的馅料太少了。",
	ResultText = "鲷鱼镇出现了阿尾",
	Dialog = "谁见到我的上衣了！？",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "FATBG04",
	StartScene = "FAT_StartScene",
	Enemy = {
		{
			Value = 240037,
			Level = 58,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id204] =
{
	Id = 204,
	Name = "挑战超浓克林姆",
	Area = 130053,
	PreCondition = {
		PreGoal = 
		{
			300703,
		},
	},
	Desc = "香草味的冰淇淋，加入了牛奶和香草粉制作而成，即使化开来味道也依然很好。性格热情开朗，一直渴望着一份火热的爱情。",
	ResultText = "冰淇淋港出现了克林姆",
	Dialog = "啊——我要化了！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "FATBG03",
	StartScene = "FAT_StartScene",
	Enemy = {
		{
			Value = 240038,
			Level = 64,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id205] =
{
	Id = 205,
	Name = "挑战超浓茶克林姆",
	Area = 130053,
	PreCondition = {
		PreGoal = 
		{
			300707,
		},
	},
	Desc = "抹茶味的冰淇淋，加入了牛奶和抹茶粉制作而成，即使化开来味道也依然很好。性格温文尔雅，最喜欢的是原谅别人。",
	ResultText = "冰淇淋港出现了茶克林姆",
	Dialog = "呜呜呜…绿茶到底怎么了…",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "FATBG03",
	StartScene = "FAT_StartScene",
	Enemy = {
		{
			Value = 240039,
			Level = 69,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id206] =
{
	Id = 206,
	Name = "挑战超浓巧克林姆",
	Area = 130053,
	PreCondition = {
		PreGoal = 
		{
			300711,
		},
	},
	Desc = "巧克力味的冰淇淋，加入了牛奶和可可粉制作而成，即使化开来味道也依然很好。性格冷酷孤僻，最讨厌傻白甜。",
	ResultText = "冰淇淋港出现了巧克林姆",
	Dialog = "我是冰淇淋！不要瞎想！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "FATBG03",
	StartScene = "FAT_StartScene",
	Enemy = {
		{
			Value = 240040,
			Level = 74,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id207] =
{
	Id = 207,
	Name = "挑战奶茶王子",
	Area = 130053,
	PreCondition = {
		PreGoal = 
		{
			300715,
		},
	},
	Desc = "超人气王子，王子影业董事长。自导自演了超过200部电影作品，IMBD最高评分4.6分（百分制），不过依然对演艺事业充满热情。",
	ResultText = "奶茶王子加入了队伍",
	Dialog = "这届观众不太行。",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "FATBG03",
	StartScene = "FAT_StartScene",
	Enemy = {
		{
			Value = 240041,
			Level = 80,
		},
	},
	Reward = {
		{
			Value = 220101,
			Num = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id208] =
{
	Id = 208,
	Name = "挑战水果糖新秀",
	Area = 130054,
	PreCondition = {
		PreGoal = 
		{
			300412,
		},
	},
	AcceptSpeech = 14020801,
	Desc = "用可食薄膜包裹的硬糖，含在嘴里可以长时间感受到酸酸甜甜的果味。对喜欢咬碎吃糖的人总是很鄙夷。",
	ResultText = "糖果镇出现了水果小糖",
	Dialog = "要多吃水果哦。",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "FATBG03",
	StartScene = "FAT_StartScene",
	Enemy = {
		{
			Value = 240042,
			Level = 56,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id209] =
{
	Id = 209,
	Name = "挑战奶糖新秀",
	Area = 130054,
	PreCondition = {
		PreGoal = 
		{
			300416,
		},
	},
	AcceptSpeech = 14020901,
	Desc = "用可食薄膜包裹的奶糖，有非常浓郁的奶香，不过含糖量非常高。自称含奶量高达百分之八十，其实是骗人的。",
	ResultText = "糖果镇出现了奶小糖",
	Dialog = "要多喝牛奶哦。",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "FATBG03",
	StartScene = "FAT_StartScene",
	Enemy = {
		{
			Value = 240043,
			Level = 62,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id210] =
{
	Id = 210,
	Name = "挑战小红",
	Area = 130054,
	PreCondition = {
		PreGoal = 
		{
			300420,
		},
	},
	Desc = "苹果味糖豆，最自豪的事是曾在公主庆典上，扮演超大冰淇淋雕像上的苹果。",
	ResultText = "小红加入了队伍",
	Dialog = "打妖怪！救公主！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "FATBG03",
	StartScene = "FAT_StartScene",
	Enemy = {
		{
			Value = 240044,
			Level = 64,
		},
	},
	Reward = {
		{
			Value = 220105,
			Num = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id211] =
{
	Id = 211,
	Name = "挑战冠军芒果滋",
	Area = 130055,
	PreCondition = {
		PreGoal = 
		{
			300423,
		},
	},
	AcceptSpeech = 14021101,
	Desc = "浇上了调味芒果浓浆的甜甜圈，撒有饼干脆片，咬下去的第一口就会在嘴里绽放出恶魔般的甜度。",
	ResultText = "甜食工厂出现了芒果滋",
	Dialog = "热量…太高了…",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "FATBG01",
	StartScene = "FAT_StartScene",
	Enemy = {
		{
			Value = 240045,
			Level = 68,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id212] =
{
	Id = 212,
	Name = "挑战冠军多拿滋",
	Area = 130055,
	PreCondition = {
		PreGoal = 
		{
			300427,
		},
	},
	Desc = "非常甜腻的甜甜圈，撒有饼干脆片。瞧不起芒果滋，认为借用果味力量的甜腻是异端，糖浆才是最正宗的力量。",
	ResultText = "甜食工厂出现了多拿滋",
	Dialog = "热量…太高了…",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "FATBG01",
	StartScene = "FAT_StartScene",
	Enemy = {
		{
			Value = 240046,
			Level = 72,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id213] =
{
	Id = 213,
	Name = "挑战超Q布丁呆",
	Area = 130055,
	PreCondition = {
		PreGoal = 
		{
			300430,
		},
	},
	AcceptSpeech = 14021301,
	Desc = "撒上了特制焦糖的布丁，走过的地方都会有布丁的香气。在此地居住的居民需要常备胰岛素。",
	ResultText = "甜食工厂出现了布丁呆",
	Dialog = "弹弹弹，弹走鱼尾纹~",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "FATBG01",
	StartScene = "FAT_StartScene",
	Enemy = {
		{
			Value = 240047,
			Level = 78,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id214] =
{
	Id = 214,
	Name = "挑战汽水王子",
	Area = 130055,
	PreCondition = {
		PreGoal = 
		{
			300435,
		},
	},
	AcceptSpeech = 14021401,
	Desc = "超人气王子，王子传媒董事长。代言了超过100种饮料产品，每张海报都有强大的修图团队精心处理，力求在所有人面前保持完美形象，但有时会不小心把背景修歪。",
	ResultText = "汽水王子加入了队伍",
	Dialog = "…不甘心。",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "FATBG01",
	StartScene = "FAT_StartScene",
	Enemy = {
		{
			Value = 240048,
			Level = 84,
		},
		{
			Value = 240049,
			Level = 84,
		},
	},
	Reward = {
		{
			Value = 220102,
			Num = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id215] =
{
	Id = 215,
	Name = "挑战梨几推销员",
	Area = 130056,
	PreCondition = {
		PreGoal = 
		{
			300718,
		},
	},
	Desc = "口感爽脆的梨几，身上长着大量雀斑，但是水分充足，十分解渴。有人听到它的名字后会误认成肉类魔物。",
	ResultText = "风味镇出现了梨几",
	Dialog = " 谁叫孔融！？",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "FATBG02",
	StartScene = "FAT_StartScene",
	Enemy = {
		{
			Value = 240050,
			Level = 78,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id216] =
{
	Id = 216,
	Name = "挑战黑脸鱼子母舰",
	Area = 130056,
	PreCondition = {
		PreGoal = 
		{
			300721,
		},
	},
	Desc = "分量十足的主食，用海苔包裹了全身，头上顶着新鲜饱满的鱼子，那也是它的假发。",
	ResultText = "风味镇出现了黑脸鱼子军舰",
	Dialog = "小心点！鱼子你可赔不起！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "FATBG02",
	StartScene = "FAT_StartScene",
	Enemy = {
		{
			Value = 240051,
			Level = 88,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id217] =
{
	Id = 217,
	Name = "挑战超烫塔可桑",
	Area = 130056,
	PreCondition = {
		PreGoal = 
		{
			300725,
		},
	},
	Desc = "每个塔可桑中都包裹了一块鲜美的鱿鱼块，拥有海洋的气味，对于喜欢鱿鱼的人来说是莫大的惊喜，但对于海鲜过敏的人来说则是噩梦。",
	ResultText = "风味镇出现了塔可桑",
	Dialog = "有本事你把我吃掉！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "FATBG02",
	StartScene = "FAT_StartScene",
	Enemy = {
		{
			Value = 240052,
			Level = 94,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id218] =
{
	Id = 218,
	Name = "挑战小黄",
	Area = 130056,
	PreCondition = {
		PreGoal = 
		{
			300729,
		},
	},
	Desc = "柠檬味糖豆，最自豪的事是公主昏倒时，从头上挤出了柠檬汁，酸醒了公主。",
	ResultText = "小黄加入了队伍",
	Dialog = "我的弟弟们会打败你的！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "FATBG02",
	StartScene = "FAT_StartScene",
	Enemy = {
		{
			Value = 240053,
			Level = 96,
		},
	},
	Reward = {
		{
			Value = 220107,
			Num = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id219] =
{
	Id = 219,
	Name = "挑战桃几推销员",
	Area = 130057,
	PreCondition = {
		PreGoal = 
		{
			300438,
		},
	},
	AcceptSpeech = 14021901,
	Desc = "水分充足的蜜桃，虽然身上长着细细的绒毛，但是依然十分讨人喜爱。外表看上去软软的，其实内在是个硬汉。",
	ResultText = "打败了饭团镇的桃几推销员",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "FATBG02",
	StartScene = "FAT_StartScene",
	Enemy = {
		{
			Value = 240054,
			Level = 70,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id220] =
{
	Id = 220,
	Name = "挑战和音饭团",
	Area = 130057,
	PreCondition = {
		PreGoal = 
		{
			300442,
		},
	},
	AcceptSpeech = 14022001,
	Desc = "分量充足的主食，采用白米制作，且撒上了黑芝麻丰富口感，需要配合芥末食用。\n嘿，那是抹茶酱！",
	ResultText = "饭团镇出现了饭团",
	Dialog = "哟西！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "FATBG02",
	StartScene = "FAT_StartScene",
	Enemy = {
		{
			Value = 240055,
			Level = 80,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id221] =
{
	Id = 221,
	Name = "挑战和音黑米团",
	Area = 130057,
	PreCondition = {
		PreGoal = 
		{
			300445,
		},
	},
	Desc = "分量充足的主食，采用血糯米制作，口感非常筋道。\n不，不是巧克力味的，别想了。",
	ResultText = "饭团镇出现了黑米团",
	Dialog = "巴嘎！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "FATBG02",
	StartScene = "FAT_StartScene",
	Enemy = {
		{
			Value = 240056,
			Level = 84,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id222] =
{
	Id = 222,
	Name = "挑战和音泡菜团",
	Area = 130057,
	PreCondition = {
		PreGoal = 
		{
			300449,
		},
	},
	Desc = "分量充足的主食，对于想要吃清淡食物的食客具有开胃效果。\n明明是辣的，怎么会清淡呢？",
	ResultText = "饭团镇出现了泡菜团",
	Dialog = "思密达！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "FATBG02",
	StartScene = "FAT_StartScene",
	Enemy = {
		{
			Value = 240057,
			Level = 88,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id223] =
{
	Id = 223,
	Name = "挑战小橙",
	Area = 130057,
	PreCondition = {
		PreGoal = 
		{
			300453,
		},
	},
	Desc = "橙子味糖豆，最自豪的事是被公主抱起来时，夸奖说味道闻起来很清爽。",
	ResultText = "小橙加入了队伍",
	Dialog = "我只是辅助！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "FATBG02",
	StartScene = "FAT_StartScene",
	Enemy = {
		{
			Value = 240058,
			Level = 90,
		},
	},
	Reward = {
		{
			Value = 220106,
			Num = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id224] =
{
	Id = 224,
	Name = "挑战超Q夹心肉球",
	Area = 130058,
	PreCondition = {
		PreGoal = 
		{
			300457,
		},
	},
	AcceptSpeech = 14022401,
	Desc = "不添加任何面粉的纯肉丸子，内部有特制的肉馅作为馅料，温度很高，很容易烫伤食客们。对此它毫无自觉，总是劝大家趁热吃。",
	ResultText = "煮物镇出现了夹心肉球",
	Dialog = "露馅了！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "FATBG04",
	StartScene = "FAT_StartScene",
	Enemy = {
		{
			Value = 240059,
			Level = 86,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id225] =
{
	Id = 225,
	Name = "挑战超烫铛噗灵",
	Area = 130058,
	PreCondition = {
		PreGoal = 
		{
			300461,
		},
	},
	AcceptSpeech = 14022501,
	Desc = "薄薄的皮料包裹着各种食材的主食，搭配调料后，会在嘴中爆发出难以言喻的美味。\n经过星际翻译法的协调，现在统一规定叫饺子。",
	ResultText = "煮物镇出现了铛噗灵",
	Dialog = "好吃不过饺子！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "FATBG04",
	StartScene = "FAT_StartScene",
	Enemy = {
		{
			Value = 240060,
			Level = 92,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id226] =
{
	Id = 226,
	Name = "挑战可乐王子",
	Area = 130058,
	PreCondition = {
		PreGoal = 
		{
			300465,
		},
	},
	AcceptSpeech = 14022601,
	Desc = "超人气王子，王子唱片董事长。每年都会开办36场演唱会，出18张专辑。不过唱片销量要靠常年打折外加赠送超值礼品才能维持。",
	ResultText = "可乐王子加入了队伍",
	Dialog = "什么！你说我的歌是抄的！？",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "FATBG04",
	StartScene = "FAT_StartScene",
	Enemy = {
		{
			Value = 240061,
			Level = 98,
		},
		{
			Value = 240062,
			Level = 98,
		},
	},
	Reward = {
		{
			Value = 220103,
			Num = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id227] =
{
	Id = 227,
	Name = "挑战金牌玉子龟龟",
	Area = 130059,
	PreCondition = {
		PreGoal = 
		{
			300469,
		},
	},
	AcceptSpeech = 14022701,
	Desc = "使用顶级匠人烹制的超美味蛋料理作为食材的寿司精灵，日常散步时经常让路人产生吃它的冲动。\n龟龟，这不就是鸡蛋吗？",
	ResultText = "寿司镇出现了玉子龟龟",
	Dialog = "我的龟龟！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "FATBG04",
	StartScene = "FAT_StartScene",
	Enemy = {
		{
			Value = 240063,
			Level = 94,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id228] =
{
	Id = 228,
	Name = "挑战金牌寿司龟龟",
	Area = 130059,
	PreCondition = {
		PreGoal = 
		{
			300473,
		},
	},
	Desc = "采用了最高级的鱼背肉部位作为食材的寿司精灵，日常散步时经常让路人产生吃它的冲动。\n龟龟，这不就是米饭吗？",
	ResultText = "寿司镇出现了寿司龟龟",
	Dialog = "我的龟龟！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "FATBG04",
	StartScene = "FAT_StartScene",
	Enemy = {
		{
			Value = 240064,
			Level = 98,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id229] =
{
	Id = 229,
	Name = "挑战金牌甜虾龟龟",
	Area = 130059,
	PreCondition = {
		PreGoal = 
		{
			300477,
		},
	},
	Desc = "采用了鲜甜肥美的深海大虾作为食材的寿司，日常散步时经常让路人产生吃它的冲动。\n龟龟，这哪大了？",
	ResultText = "寿司镇出现了甜虾龟龟",
	Dialog = "我的龟龟！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "FATBG04",
	StartScene = "FAT_StartScene",
	Enemy = {
		{
			Value = 240065,
			Level = 102,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id230] =
{
	Id = 230,
	Name = "挑战小绿",
	Area = 130059,
	PreCondition = {
		PreGoal = 
		{
			300481,
		},
	},
	Desc = "奇异果味糖豆，最自豪的事是被公主抱起来时，夸奖颜色看起来很健康。",
	ResultText = "小绿加入了队伍",
	Dialog = "你们要带我去找公主吗？",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "FATBG04",
	StartScene = "FAT_StartScene",
	Enemy = {
		{
			Value = 240066,
			Level = 104,
		},
	},
	Reward = {
		{
			Value = 220108,
			Num = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id231] =
{
	Id = 231,
	Name = "挑战苹狗推销员",
	Area = 130060,
	PreCondition = {
		PreGoal = 
		{
			300485,
		},
	},
	AcceptSpeech = 14023101,
	Desc = "营养丰富的苹狗，身体是健康的红色。最大的梦想是进化成传说中的物种——芒狗。",
	ResultText = "打败了烤肉镇的苹狗推销员",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "FATBG02",
	StartScene = "FAT_StartScene",
	Enemy = {
		{
			Value = 240067,
			Level = 96,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id232] =
{
	Id = 232,
	Name = "挑战冠军培根",
	Area = 130060,
	PreCondition = {
		PreGoal = 
		{
			300489,
		},
	},
	AcceptSpeech = 14023201,
	Desc = "星际著名的哲学家、科学家，在诸多学科都有很大贡献，为星际居民所敬仰……然而这跟我培根有什么关系呢？",
	ResultText = "烤肉镇出现了培根",
	Dialog = "吃早餐了吗？",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "FATBG02",
	StartScene = "FAT_StartScene",
	Enemy = {
		{
			Value = 240068,
			Level = 102,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id233] =
{
	Id = 233,
	Name = "挑战冠军火腿猪",
	Area = 130060,
	PreCondition = {
		PreGoal = 
		{
			300493,
		},
	},
	AcceptSpeech = 14023301,
	Desc = "美食星特有的豚类，会定时产出美味的腌制火腿，很受烤肉店欢迎，至于产出过程……",
	ResultText = "烤肉镇出现了火腿猪",
	Dialog = "吃晚餐了吗?",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "FATBG02",
	StartScene = "FAT_StartScene",
	Enemy = {
		{
			Value = 240069,
			Level = 106,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id234] =
{
	Id = 234,
	Name = "挑战啤酒王子",
	Area = 130060,
	PreCondition = {
		PreGoal = 
		{
			300498,
		},
	},
	AcceptSpeech = 14023401,
	Desc = "超人气王子，王子乐团总指挥。每次音乐演奏会都会独自负责弦乐、管乐、打击乐三个部分，奔放的演出方式经常让观众怀疑表演者是不是喝醉了。",
	ResultText = "啤酒王子加入了队伍",
	Dialog = "不是说不打脸吗？",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "FATBG02",
	StartScene = "FAT_StartScene",
	Enemy = {
		{
			Value = 240070,
			Level = 112,
		},
		{
			Value = 240071,
			Level = 112,
		},
	},
	Reward = {
		{
			Value = 220104,
			Num = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id235] =
{
	Id = 235,
	Name = "挑战招牌芝士软泥",
	Area = 130061,
	PreCondition = {
		PreGoal = 
		{
			300734,
		},
	},
	Desc = "用精品土豆研磨而成的细滑豆泥，拌入芝士后味道将更加浓郁。\n没加泥。",
	ResultText = "香浓镇出现了芝士软泥",
	Dialog = "芝士就是力量！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "FATBG03",
	StartScene = "FAT_StartScene",
	Enemy = {
		{
			Value = 240072,
			Level = 138,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id236] =
{
	Id = 236,
	Name = "挑战金牌比撒",
	Area = 130061,
	PreCondition = {
		PreGoal = 
		{
			300738,
		},
	},
	Desc = "包裹了香浓芝士的披萨，表面挂着各种食材，无论是作为点心或是正餐都是很棒的选择。\n没在骂人。",
	ResultText = "香浓镇出现了比撒",
	Dialog = "要不要先买两箱啤酒备着？",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "FATBG03",
	StartScene = "FAT_StartScene",
	Enemy = {
		{
			Value = 240073,
			Level = 146,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id401] =
{
	Id = 401,
	Name = "挑战左半碗代表",
	Area = 130101,
	PreCondition = {
		PreGoal = 
		{
			300803,
		},
	},
	AcceptSpeech = 14040101,
	Desc = "活跃在博物馆各大角落的碎瓷，出自某朝左姓大官家中，大官家道中落后也遭遇事故碎成两半，目前流落民间，以左为姓。",
	ResultText = "打败了着陆点的左半碗代表",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG01",
	StartScene = "MUS_StartScene",
	Enemy = {
		{
			Value = 240074,
			Level = 100,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id402] =
{
	Id = 402,
	Name = "挑战入口队长",
	Area = 130102,
	PreCondition = {
		PreGoal = 
		{
			300806,
		},
	},
	AcceptSpeech = 14040201,
	Desc = "指引游客进入博物馆的工作人员，如果游客固执地想从入口出去，它会很认真地阻止对方。",
	ResultText = "入口大厅出现了入口",
	Dialog = "买票了吗？",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG01",
	StartScene = "MUS_StartScene",
	Enemy = {
		{
			Value = 240075,
			Level = 104,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id403] =
{
	Id = 403,
	Name = "挑战红外线探测",
	Area = 130102,
	PreCondition = {
		PreGoal = 
		{
			300809,
		},
	},
	AcceptSpeech = 14040301,
	Desc = "躲在暗处监视走道情况的机械设备，如果有人入侵会用红外线照对方眼睛。",
	ResultText = "入口大厅出现了红外线探测",
	Dialog = "警报！警报！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG01",
	StartScene = "MUS_StartScene",
	Enemy = {
		{
			Value = 240076,
			Level = 108,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id404] =
{
	Id = 404,
	Name = "挑战保安",
	Area = 130102,
	PreCondition = {
		PreGoal = 
		{
			300813,
		},
	},
	AcceptSpeech = 14040401,
	Desc = "博物馆星新任保安，人生处于低谷时来到博物馆散心，无意间拿起保安招聘启事后便被馆长强行留了下来。",
	ResultText = "保安加入了队伍",
	Dialog = "馆长！！我顶不住啦！！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG01",
	StartScene = "MUS_StartScene",
	Enemy = {
		{
			Value = 240077,
			Level = 114,
		},
	},
	Reward = {
		{
			Value = 220201,
			Num = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id405] =
{
	Id = 405,
	Name = "挑战太古围观陶",
	Area = 130103,
	PreCondition = {
		PreGoal = 
		{
			300818,
		},
	},
	Desc = "整天无所事事的文物，到处瞎逛看热闹，爱占小便宜，喜欢碰瓷，因为瓷没它硬。",
	ResultText = "中心广场出现了围观陶",
	Dialog = "我裂了！你赔！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG02",
	StartScene = "MUS_StartScene",
	Enemy = {
		{
			Value = 240078,
			Level = 112,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id406] =
{
	Id = 406,
	Name = "挑战陶老大",
	Area = 130103,
	PreCondition = {
		PreGoal = 
		{
			300822,
		},
	},
	AcceptSpeech = 14040601,
	Desc = "神秘的古代陶土工艺品，脸上写着难以言喻的表情，不太受人欢迎。",
	ResultText = "中心广场出现了陶面人",
	Dialog = "看我脸色行事！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG02",
	StartScene = "MUS_StartScene",
	Enemy = {
		{
			Value = 240079,
			Level = 114,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id407] =
{
	Id = 407,
	Name = "挑战浣熊小弟",
	Area = 130103,
	PreCondition = {
		PreGoal = 
		{
			300826,
		},
	},
	AcceptSpeech = 14040701,
	Desc = "总是跟着两个哥哥去参观博物馆的小浣熊，但每次都会因为没买票被拦在门外。他对此很气愤，因为自己并没有钱买票。",
	ResultText = "浣熊小弟加入了队伍",
	Dialog = "叽叽！哥哥！有人欺负我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG02",
	StartScene = "MUS_StartScene",
	Enemy = {
		{
			Value = 240080,
			Level = 120,
		},
	},
	Reward = {
		{
			Value = 220205,
			Num = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id408] =
{
	Id = 408,
	Name = "挑战王朝编钟",
	Area = 130104,
	PreCondition = {
		PreGoal = 
		{
			300831,
		},
	},
	Desc = "古代的乐器，能够敲击出悠扬空灵的声响，喜欢说大话，经常炫耀自己见多识广，对此大家总是表示“你就编吧”。",
	ResultText = "文物厅出现了编钟",
	Dialog = "咚…",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG02",
	StartScene = "MUS_StartScene",
	Enemy = {
		{
			Value = 240081,
			Level = 115,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id409] =
{
	Id = 409,
	Name = "挑战太古兽面鼎",
	Area = 130104,
	PreCondition = {
		PreGoal = 
		{
			300835,
		},
	},
	Desc = "在古代祭祀典礼上经常出现的器皿，用来插仪式用的焚香，因为样貌有些吓人，有时会吓到前来祭祀的人。",
	ResultText = "文物厅出现了兽面鼎",
	Dialog = "巴噶哇噶！瓦拉瓦啦！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG02",
	StartScene = "MUS_StartScene",
	Enemy = {
		{
			Value = 240082,
			Level = 119,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id410] =
{
	Id = 410,
	Name = "挑战远古猪罐",
	Area = 130104,
	PreCondition = {
		PreGoal = 
		{
			300839,
		},
	},
	AcceptSpeech = 14041001,
	Desc = "从遗迹里挖出来的猪形瓷罐，上方的小孔刚好够塞进去一枚铜币，但里面却是空的。",
	ResultText = "文物厅出现了猪罐",
	Dialog = "我的…私房钱——！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG02",
	StartScene = "MUS_StartScene",
	Enemy = {
		{
			Value = 240083,
			Level = 123,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id411] =
{
	Id = 411,
	Name = "挑战左半瓷代表",
	Area = 130105,
	PreCondition = {
		PreGoal = 
		{
			301104,
		},
	},
	Desc = "活跃在博物馆各大角落的碎瓷片，过去是在皇宫里当差的，碎了以后就回到了民间，因为碎裂的关系已经认不出右半瓷了。",
	ResultText = "修复室出现了左半瓷",
	Dialog = "我不太平衡…",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG02",
	StartScene = "MUS_StartScene",
	Enemy = {
		{
			Value = 240084,
			Level = 147,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id412] =
{
	Id = 412,
	Name = "挑战右半瓷代表",
	Area = 130105,
	PreCondition = {
		PreGoal = 
		{
			301108,
		},
	},
	Desc = "活跃在博物馆各大角落的碎瓷片，过去是在皇宫里当差的，碎了以后就回到了民间，还记得左半瓷但是老是装不认识。",
	ResultText = "修复室出现了右半瓷",
	Dialog = "我不太平衡…",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG02",
	StartScene = "MUS_StartScene",
	Enemy = {
		{
			Value = 240085,
			Level = 149,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id413] =
{
	Id = 413,
	Name = "挑战碰瓷王",
	Area = 130105,
	PreCondition = {
		PreGoal = 
		{
			301112,
		},
	},
	Desc = "毫无节操的前文物，会在游客密集的地方突然躺倒，向附近的游客索要巨额赔偿。天敌是围观陶，因为碰不过。",
	ResultText = "修复室出现了碰碰瓷",
	Dialog = "我摔倒了！要亲亲才能起来！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG02",
	StartScene = "MUS_StartScene",
	Enemy = {
		{
			Value = 240086,
			Level = 152,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id414] =
{
	Id = 414,
	Name = "挑战警戒线队长",
	Area = 130105,
	PreCondition = {
		PreGoal = 
		{
			301116,
		},
	},
	Desc = "经常被无视的保安设备，有人想穿过去时，它就会一直盯着对方。",
	ResultText = "修复室出现了警戒线",
	Dialog = "警报！警报！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG02",
	StartScene = "MUS_StartScene",
	Enemy = {
		{
			Value = 240087,
			Level = 155,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id415] =
{
	Id = 415,
	Name = "挑战木乃伊",
	Area = 130105,
	PreCondition = {
		PreGoal = 
		{
			301120,
		},
	},
	Desc = "睡了上千年的木乃伊，已经忘了自己原本的身份。虽然外表看起来可怕，但是性格温和，很快和博物馆里的其他居民打成了一片。",
	ResultText = "木乃伊加入了队伍",
	Dialog = "要不是我被自己绊了一跤…",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG02",
	StartScene = "MUS_StartScene",
	Enemy = {
		{
			Value = 240088,
			Level = 129,
		},
	},
	Reward = {
		{
			Value = 220217,
			Num = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id416] =
{
	Id = 416,
	Name = "挑战精英雨林龙",
	Area = 130106,
	PreCondition = {
		PreGoal = 
		{
			300843,
		},
	},
	Desc = "第二世代时生活在雨林地区的双足龙，走起来速度十分惊人，但是因为名字而不能奔跑。",
	ResultText = "生态园出现了雨林快走龙",
	Dialog = "溜了溜了~",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "MUS_StartScene",
	Enemy = {
		{
			Value = 240089,
			Level = 126,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id417] =
{
	Id = 417,
	Name = "挑战精英沙漠龙",
	Area = 130106,
	PreCondition = {
		PreGoal = 
		{
			300847,
		},
	},
	Desc = "虽然和雨林快走龙很像，却是来自第三世代的生物。叫这个名字并不是因为走得快，而是为了纪念它在危难之中保护了自己的朋友沙漠。\n沙漠快走！！！！",
	ResultText = "生态园出现了沙漠快走龙",
	Dialog = "溜了溜了~",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "MUS_StartScene",
	Enemy = {
		{
			Value = 240090,
			Level = 130,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id418] =
{
	Id = 418,
	Name = "挑战上古恐龙化石",
	Area = 130106,
	PreCondition = {
		PreGoal = 
		{
			300851,
		},
	},
	AcceptSpeech = 14041801,
	Desc = "通过基因技术复活的恐龙化石，复活后却成了博物馆有名的捣蛋鬼。\n你不能因为自己没有蛋就捣别人的啊。",
	ResultText = "生态园出现了恐龙化石",
	Dialog = "今年到底是哪年？",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "MUS_StartScene",
	Enemy = {
		{
			Value = 240091,
			Level = 134,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id419] =
{
	Id = 419,
	Name = "挑战摄像头队长",
	Area = 130107,
	PreCondition = {
		PreGoal = 
		{
			301125,
		},
	},
	Desc = "配合保安负责安保工作的机械设备，只记录画面，不记录声音，因此他们又在旁边配了一台录音机。",
	ResultText = "监控室出现了摄像头",
	Dialog = "我看到你了…",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "MUS_StartScene",
	Enemy = {
		{
			Value = 240093,
			Level = 160,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id420] =
{
	Id = 420,
	Name = "挑战高清摄像头队长",
	Area = 130107,
	PreCondition = {
		PreGoal = 
		{
			301129,
		},
	},
	Desc = "能够把路人脸上的毛孔都拍得一清二楚的高级摄像头，可他们又忘了加麦克风。",
	ResultText = "监控室出现了高清摄像头",
	Dialog = "我看到4K的你了…",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "MUS_StartScene",
	Enemy = {
		{
			Value = 240094,
			Level = 165,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id421] =
{
	Id = 421,
	Name = "挑战侦探小姐",
	Area = 130107,
	PreCondition = {
		PreGoal = 
		{
			301133,
		},
	},
	Desc = "活跃在博物馆星的人气角色，擅长速写，仅凭描述就能画出嫌疑人。听说最近常用摄像机对着星空。莫非发现了怪盗的踪迹吗？",
	ResultText = "侦探小姐加入了队伍",
	Dialog = "真相我早已了然于胸！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "MUS_StartScene",
	Enemy = {
		{
			Value = 240095,
			Level = 129,
		},
	},
	Reward = {
		{
			Value = 220202,
			Num = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id422] =
{
	Id = 422,
	Name = "挑战右半碗代表",
	Area = 130108,
	PreCondition = {
		PreGoal = 
		{
			300855,
		},
	},
	Desc = "活跃在博物馆各大角落的碎瓷，出自某朝右姓豪族家中，大官家道中落后也遭遇事故碎成两半，目前流落民间，以右为姓。",
	ResultText = "打败了古文明厅的右半碗代表",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "MUS_StartScene",
	Enemy = {
		{
			Value = 240092,
			Level = 130,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id423] =
{
	Id = 423,
	Name = "挑战祭司鸮卣",
	Area = 130108,
	PreCondition = {
		PreGoal = 
		{
			300859,
		},
	},
	Desc = "大型青铜鼎，上面贴着古代大法师施咒的封条，里面可能藏着不得了的妖怪。\n你才是号卤！",
	ResultText = "古文明厅出现了鸮卣",
	Dialog = "封条要破了！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "MUS_StartScene",
	Enemy = {
		{
			Value = 240096,
			Level = 136,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id424] =
{
	Id = 424,
	Name = "挑战祭典金鸮卣",
	Area = 130108,
	PreCondition = {
		PreGoal = 
		{
			300863,
		},
	},
	AcceptSpeech = 14042401,
	Desc = "使用贵重的黄金制成的大鼎，只是靠近都能感到鼎内散发出不祥的气息。\n你才是金鸟回！",
	ResultText = "古文明厅出现了金鸮卣",
	Dialog = "别乱碰！我可是很贵的！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "MUS_StartScene",
	Enemy = {
		{
			Value = 240097,
			Level = 140,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id425] =
{
	Id = 425,
	Name = "挑战浣熊二哥",
	Area = 130108,
	PreCondition = {
		PreGoal = 
		{
			300867,
		},
	},
	AcceptSpeech = 14042501,
	Desc = "喜欢跟着哥哥去参观博物馆的小浣熊，但每次都会因为没买票被拦在门外。他对此很气愤，因为自己并没有一米二，根本不需要买票",
	ResultText = "浣熊二哥加入了队伍",
	Dialog = "叽叽！大哥！有人欺负我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "MUS_StartScene",
	Enemy = {
		{
			Value = 240098,
			Level = 148,
		},
	},
	Reward = {
		{
			Value = 220204,
			Num = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id426] =
{
	Id = 426,
	Name = "挑战完整鱼化石",
	Area = 130109,
	PreCondition = {
		PreGoal = 
		{
			300871,
		},
	},
	Desc = "来自海洋的古代鱼化石，关于上面的鱼是什么品种生物学家们至今也没有定论，所以仍然不知道到底能不能吃。",
	ResultText = "化石厅出现了鱼化石",
	Dialog = "啵~（气泡音）",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG04",
	StartScene = "MUS_StartScene",
	Enemy = {
		{
			Value = 240099,
			Level = 145,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id427] =
{
	Id = 427,
	Name = "挑战完整乌龟化石",
	Area = 130109,
	PreCondition = {
		PreGoal = 
		{
			300875,
		},
	},
	AcceptSpeech = 14042701,
	Desc = "来自海洋的古代乌龟化石，关于它的真实年龄，科学家们至今也没有定论。",
	ResultText = "化石厅出现了乌龟化石",
	Dialog = "这么大岁数了还要被人揍…",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG04",
	StartScene = "MUS_StartScene",
	Enemy = {
		{
			Value = 240100,
			Level = 149,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id428] =
{
	Id = 428,
	Name = "挑战猪蹄古董",
	Area = 130109,
	PreCondition = {
		PreGoal = 
		{
			300879,
		},
	},
	Desc = "好几千年以前的一只猪蹄，被考古学家找到的时候，皮肤还有弹性，可是保存技术有限，没多久就氧化了。\n因社交能力出众，目前担任博物馆宣传部长。",
	ResultText = "猪蹄古董加入了队伍",
	Dialog = "可以和美丽的小姐一队了~",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG04",
	StartScene = "MUS_StartScene",
	Enemy = {
		{
			Value = 240101,
			Level = 158,
		},
	},
	Reward = {
		{
			Value = 220219,
			Num = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id429] =
{
	Id = 429,
	Name = "挑战太古碧鱬",
	Area = 130110,
	PreCondition = {
		PreGoal = 
		{
			300883,
		},
	},
	Desc = "古代艺术家按照某种古生物的外形制作的泥塑，听老一辈说，这种生物有时候会被误认为是美人鱼，看见的人会连续一周发生与水有关的灾祸。",
	ResultText = "泥塑厅出现了碧鱬",
	Dialog = "陆上生物真可怕！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG04",
	StartScene = "MUS_StartScene",
	Enemy = {
		{
			Value = 240102,
			Level = 148,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id430] =
{
	Id = 430,
	Name = "挑战太古赤鱬",
	Area = 130110,
	PreCondition = {
		PreGoal = 
		{
			300887,
		},
	},
	AcceptSpeech = 14043001,
	Desc = "古代艺术家按照某种古生物的外形制作的泥塑，听老一辈说，这种生物是生活在极深的海底的，看见的人一旦出海就会遇到风暴。",
	ResultText = "泥塑厅出现了赤鱬",
	Dialog = "陆上生物真可怕！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG04",
	StartScene = "MUS_StartScene",
	Enemy = {
		{
			Value = 240103,
			Level = 152,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id431] =
{
	Id = 431,
	Name = "挑战精英寒带龙",
	Area = 130111,
	PreCondition = {
		PreGoal = 
		{
			300891,
		},
	},
	Desc = "拥有厚实的皮层，不畏严寒的杂食性恐龙，愤怒时会喷吐寒流冻结目标。胃寒，不能喝冷饮。",
	ResultText = "恐龙馆出现了寒带一角龙",
	Dialog = "有点冷…",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG04",
	StartScene = "MUS_StartScene",
	Enemy = {
		{
			Value = 240104,
			Level = 160,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id432] =
{
	Id = 432,
	Name = "挑战精英热带龙",
	Area = 130111,
	PreCondition = {
		PreGoal = 
		{
			300895,
		},
	},
	AcceptSpeech = 14043201,
	Desc = "拥有厚实的皮层，不畏高温的肉食性恐龙，愤怒时会喷吐岩浆融化目标。上火，不能吃辣的。",
	ResultText = "恐龙馆出现了热带一角龙",
	Dialog = "热死了！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG04",
	StartScene = "MUS_StartScene",
	Enemy = {
		{
			Value = 240105,
			Level = 166,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id433] =
{
	Id = 433,
	Name = "挑战浣熊大哥",
	Area = 130111,
	PreCondition = {
		PreGoal = 
		{
			300899,
		},
	},
	AcceptSpeech = 14043301,
	Desc = "特别喜欢参观博物馆的小浣熊，但每次都会因为没买票被拦在门外。他对此很气愤，因为自己有学生证，根本不需要买票。",
	ResultText = "浣熊大哥加入了队伍",
	Dialog = "弟弟们，大哥也被欺负了…",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG04",
	StartScene = "MUS_StartScene",
	Enemy = {
		{
			Value = 240106,
			Level = 174,
		},
	},
	Reward = {
		{
			Value = 220203,
			Num = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id434] =
{
	Id = 434,
	Name = "挑战出口队长",
	Area = 130112,
	PreCondition = {
		PreGoal = 
		{
			300903,
		},
	},
	AcceptSpeech = 14043401,
	Desc = "指引游客离开博物馆的工作人员，什么叫安全呢？就是这个怪比较菜，新手也能打过。",
	ResultText = "出口出现了安全出口",
	Dialog = "不准从这里进去！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG01",
	StartScene = "MUS_StartScene",
	Enemy = {
		{
			Value = 240107,
			Level = 164,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id435] =
{
	Id = 435,
	Name = "挑战快陶鸭！",
	Area = 130112,
	PreCondition = {
		PreGoal = 
		{
			301137,
		},
	},
	Desc = "速度超快的陶土鸭，只要发现情况不妙，就会立刻逃跑，非常难捕捉。",
	ResultText = "出口出现了快陶鸭",
	Dialog = "别打了鸭！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG01",
	StartScene = "MUS_StartScene",
	Enemy = {
		{
			Value = 240108,
			Level = 172,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id436] =
{
	Id = 436,
	Name = "挑战独耳画像",
	Area = 130112,
	PreCondition = {
		PreGoal = 
		{
			301141,
		},
	},
	Desc = "来自博物馆星的独耳画家，是用充满生命力的创作激情点燃了一整个时代的优秀画家。笔下的每一件事物都仿佛被注入了生命一般。",
	ResultText = "独耳画像加入了队伍",
	Dialog = "请带我去太空吧。",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG01",
	StartScene = "MUS_StartScene",
	Enemy = {
		{
			Value = 240109,
			Level = 182,
		},
	},
	Reward = {
		{
			Value = 220224,
			Num = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id601] =
{
	Id = 601,
	Name = "挑战流浪三花猫",
	Area = 130151,
	PreCondition = {
		PreGoal = 
		{
			301203,
		},
	},
	AcceptSpeech = 14060101,
	Desc = "活跃在悬疑星的花猫，喜欢在安全的地方散步，如果路上发生状况，就会蹲在一边舔着舌头看热闹。\n它的舌头并没有三种花色。",
	ResultText = "打败了着陆点的流浪三花猫",
	Dialog = "喵！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG01",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240110,
			Level = 165,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id602] =
{
	Id = 602,
	Name = "挑战告白情书",
	Area = 130152,
	PreCondition = {
		PreGoal = 
		{
			301207,
		},
	},
	AcceptSpeech = 14060201,
	Desc = "为人们传递情意的信件，读的时候会起一身的鸡皮疙瘩，因此很棘手。",
	ResultText = "甜心街出现了情书",
	Dialog = "太肉麻了！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG01",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240111,
			Level = 168,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id603] =
{
	Id = 603,
	Name = "挑战粉红女士",
	Area = 130152,
	PreCondition = {
		PreGoal = 
		{
			301211,
		},
	},
	AcceptSpeech = 14060301,
	Desc = "喜欢下午和好朋友一起去逛街的帽子小姐，经常会卷入案件中。",
	ResultText = "甜心街出现了粉红帽",
	Dialog = "什么？我又是目击证人？",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG01",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240112,
			Level = 172,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id604] =
{
	Id = 604,
	Name = "挑战网红邮筒",
	Area = 130152,
	PreCondition = {
		PreGoal = 
		{
			301215,
		},
	},
	AcceptSpeech = 14060401,
	Desc = "帮助附近居民寄出邮件的重要设施，最讨厌被人骂邮筒腰。",
	ResultText = "甜心街出现了邮筒",
	Dialog = "你涉嫌破坏公物！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG01",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240113,
			Level = 172,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id605] =
{
	Id = 605,
	Name = "挑战报童",
	Area = 130152,
	PreCondition = {
		PreGoal = 
		{
			301219,
		},
	},
	AcceptSpeech = 14060501,
	Desc = "在悬疑星各大街道活动的报童，拥有大量未经证实的惊天消息。比如动物园老虎逃出笼子，且27人已遇害。\n事实是房东太太的猫散步时，被27人围着撸。",
	ResultText = "报童加入了队伍",
	Dialog = "别抓我！我什么都没看见！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG01",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240114,
			Level = 180,
		},
	},
	Reward = {
		{
			Value = 220301,
			Num = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id606] =
{
	Id = 606,
	Name = "挑战重磅新闻",
	Area = 130153,
	PreCondition = {
		PreGoal = 
		{
			301504,
		},
	},
	Desc = "常驻咖啡馆的报纸先生，会把今天的新闻登在身上，让别人阅读。\n有没有人提醒一下，他拿反了。",
	ResultText = "咖啡馆出现了报纸",
	Dialog = "头条：外星人当街殴打路人",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG01",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240115,
			Level = 190,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id607] =
{
	Id = 607,
	Name = "挑战帽子绅士",
	Area = 130153,
	PreCondition = {
		PreGoal = 
		{
			301508,
		},
	},
	Desc = "喜欢下午独自一人去咖啡店的帽子先生，非常绅士，会替女性遮挡阳光。",
	ResultText = "咖啡馆出现了礼帽",
	Dialog = "我是绅士…我不能动手…",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG01",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240116,
			Level = 194,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id608] =
{
	Id = 608,
	Name = "挑战阿加莎",
	Area = 130153,
	PreCondition = {
		PreGoal = 
		{
			301512,
		},
	},
	Desc = "悬疑星当红的推理女王，严谨的侦探小说家，每天都在构思新点子。如果想到新颖的作案手法，会自己先尝试一下。",
	ResultText = "阿加莎加入了队伍",
	Dialog = "好，这下就是完美犯罪了！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG01",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240117,
			Level = 201,
		},
	},
	Reward = {
		{
			Value = 220302,
			Num = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id609] =
{
	Id = 609,
	Name = "挑战进口羽毛笔",
	Area = 130154,
	PreCondition = {
		PreGoal = 
		{
			301223,
		},
	},
	AcceptSpeech = 14060901,
	Desc = "羽毛笔很喜欢现在的工作，在从鸟身上掉下来之前，它并没有想到自己的人生还能有第二春。",
	ResultText = "邮局出现了羽毛笔",
	Dialog = "没墨了！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG02",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240118,
			Level = 175,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id610] =
{
	Id = 610,
	Name = "挑战纪念邮票",
	Area = 130154,
	PreCondition = {
		PreGoal = 
		{
			301227,
		},
	},
	AcceptSpeech = 14061001,
	Desc = "性格强硬，坚持把每一个舔它的人都以性骚扰的罪名告上了法庭。",
	ResultText = "邮局出现了邮票",
	Dialog = "纪念版邮票看一下吗？",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG02",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240119,
			Level = 180,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id611] =
{
	Id = 611,
	Name = "挑战精致信封",
	Area = 130154,
	PreCondition = {
		PreGoal = 
		{
			301231,
		},
	},
	AcceptSpeech = 14061101,
	Desc = "性格有些古怪，经常自言自语，会被周围的人所害怕。\n哦，想出来吗？哈哈！真可惜啊，你是绝对不可能突破我的封锁的！信！",
	ResultText = "邮局出现了信封",
	Dialog = "地址在哪来着…？",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG02",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240120,
			Level = 180,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id612] =
{
	Id = 612,
	Name = "挑战侦探助理",
	Area = 130154,
	PreCondition = {
		PreGoal = 
		{
			301235,
		},
	},
	AcceptSpeech = 14061201,
	Desc = "大侦探不可或缺的好伙伴，总是能够在合适的时机提出观众心中的疑问，让大侦探顺理成章地讲解案情。会在事件发生第一时间询问大侦探的看法。",
	ResultText = "侦探助理加入了队伍",
	Dialog = "要不然，漫画大家一起看吧。",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG02",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240121,
			Level = 188,
		},
	},
	Reward = {
		{
			Value = 220320,
			Num = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id613] =
{
	Id = 613,
	Name = "挑战可疑门牌",
	Area = 130155,
	PreCondition = {
		PreGoal = 
		{
			301239,
		},
	},
	AcceptSpeech = 14061301,
	Desc = "经常溜到案件现场看热闹的门牌先生，有时候会发表自己的高见,由于顶着自己的住址而总是会泄露个人信息。",
	ResultText = "冷清街出现了门牌",
	Dialog = "你家不在这！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG03",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240122,
			Level = 185,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id614] =
{
	Id = 614,
	Name = "挑战可疑路障",
	Area = 130155,
	PreCondition = {
		PreGoal = 
		{
			301243,
		},
	},
	AcceptSpeech = 14061401,
	Desc = "经常被放置在工地使用的黄黑警用路障，因为颜色本身就比较脏的关系，所以很耐脏。",
	ResultText = "冷清街出现了工地路障",
	Dialog = "前方修路请绕行！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG03",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240123,
			Level = 190,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id615] =
{
	Id = 615,
	Name = "挑战流浪白猫",
	Area = 130155,
	PreCondition = {
		PreGoal = 
		{
			301247,
		},
	},
	AcceptSpeech = 14061501,
	Desc = "行动非常敏捷的白色猫咪，经常在悬疑星各大咖啡馆出没，偶尔也会出现在无人的街道上。",
	ResultText = "冷清街出现了白猫",
	Dialog = "喵~",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG03",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240124,
			Level = 195,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id616] =
{
	Id = 616,
	Name = "挑战可疑煤气灯",
	Area = 130155,
	PreCondition = {
		PreGoal = 
		{
			301251,
		},
	},
	AcceptSpeech = 14061601,
	Desc = "安装在大街上提供行人照明的设施，性格火爆，一点就炸。\n然后就没有然后了。",
	ResultText = "冷清街出现了煤气灯",
	Dialog = "小心火烛——",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG03",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240125,
			Level = 200,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id617] =
{
	Id = 617,
	Name = "挑战窨井守卫者",
	Area = 130156,
	PreCondition = {
		PreGoal = 
		{
			301517,
		},
	},
	Desc = "勤恳踏实的底层员工，最大的梦想是有朝一日不被人踩在脸上。",
	ResultText = "现场出现了窨井盖",
	Dialog = "你以后走路小心点！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG03",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240126,
			Level = 205,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id618] =
{
	Id = 618,
	Name = "挑战路障队长",
	Area = 130156,
	PreCondition = {
		PreGoal = 
		{
			301521,
		},
	},
	Desc = "警方设置在禁行区的路障，有时会被不知从何处来的僵尸偷走。",
	ResultText = "现场出现了警用路障",
	Dialog = "此路不通！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG03",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240127,
			Level = 205,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id619] =
{
	Id = 619,
	Name = "挑战消防队长",
	Area = 130156,
	PreCondition = {
		PreGoal = 
		{
			301525,
		},
	},
	Desc = "只要简单操作就能为外接设备持续供水的设施，是街道消防必不可少的好伙伴。",
	ResultText = "现场出现了消防栓",
	Dialog = "你涉嫌破坏公物！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG03",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240128,
			Level = 205,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id620] =
{
	Id = 620,
	Name = "挑战死者",
	Area = 130156,
	PreCondition = {
		PreGoal = 
		{
			301529,
		},
	},
	Desc = "往往第一个被排除嫌疑的角色，但是世事无绝对。如果所有出场的嫌疑人都遇害了，那么一定要再重新检查一遍死者。",
	ResultText = "死者加入了队伍",
	Dialog = "我觉得我还能再抢救一下…",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG03",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240129,
			Level = 218,
		},
	},
	Reward = {
		{
			Value = 220303,
			Num = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id621] =
{
	Id = 621,
	Name = "挑战超硬烟灰缸",
	Area = 130157,
	PreCondition = {
		PreGoal = 
		{
			301255,
		},
	},
	AcceptSpeech = 14062101,
	Desc = "城市的治安有多大压力，烟灰缸中就有多少烟头。在这座城市的警局中，烟灰缸也用自己的方式维持着治安。",
	ResultText = "警局出现了烟灰缸",
	Dialog = "下次我一定打爆你的头！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG03",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240130,
			Level = 208,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id622] =
{
	Id = 622,
	Name = "挑战超合金手铐",
	Area = 130157,
	PreCondition = {
		PreGoal = 
		{
			301259,
		},
	},
	AcceptSpeech = 14062201,
	Desc = "对于一名罪犯来说，手腕粗得铐不住是一件很丢脸的事。",
	ResultText = "警局出现了手铐",
	Dialog = "敢打我！？都拷上！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG03",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240131,
			Level = 208,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id623] =
{
	Id = 623,
	Name = "挑战手工打火机",
	Area = 130157,
	PreCondition = {
		PreGoal = 
		{
			301263,
		},
	},
	Desc = "成功取代了火柴的新型点火装置，是烟草爱好者必不可少的道具。经常被设计成各种形状，枪械、钟表、乐器，还有香烟。",
	ResultText = "警局出现了打火机",
	Dialog = "你会用打火机吗！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG03",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240132,
			Level = 208,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id624] =
{
	Id = 624,
	Name = "挑战蓝衣小学生",
	Area = 130157,
	PreCondition = {
		PreGoal = 
		{
			301267,
		},
	},
	AcceptSpeech = 14062401,
	Desc = "蓝星著名的高中生侦探的远房表弟，本来是初中生，因意外变成小学生。这个意外听上去是那么得不可思议，但不知为何大家都是以一幅理解的表情表示释然。",
	ResultText = "蓝衣小学生加入了队伍",
	Dialog = "真相，只有一个！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG03",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240133,
			Level = 216,
		},
	},
	Reward = {
		{
			Value = 220322,
			Num = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id625] =
{
	Id = 625,
	Name = "挑战超清相片",
	Area = 130158,
	PreCondition = {
		PreGoal = 
		{
			301271,
		},
	},
	AcceptSpeech = 14062501,
	Desc = "只是用来记录某一时刻湖面的相片，在悬疑星却往往能将深藏多年的某段关系揭示出来。",
	ResultText = "证物仓库出现了相片",
	Dialog = "为什么指望一张照片说话？",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG04",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240134,
			Level = 210,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id626] =
{
	Id = 626,
	Name = "挑战超分贝报警器",
	Area = 130158,
	PreCondition = {
		PreGoal = 
		{
			301275,
		},
	},
	Desc = "警笛鸣起时，治安官们将迅速通过拥挤路段，直达罪案发生的所在，而鸣响的正义之音也将使罪恶无所遁形。",
	ResultText = "证物仓库出现了报警器",
	Dialog = "啊啊啊啊啊啊啊——！！！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG04",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240135,
			Level = 218,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id627] =
{
	Id = 627,
	Name = "挑战死者手机",
	Area = 130158,
	PreCondition = {
		PreGoal = 
		{
			301279,
		},
	},
	Desc = "犯罪现场遗留下来的手机，被害人还来不及翻开盖子就遇害了。这个教训告诉我们要买智能机。",
	ResultText = "证物仓库出现了证物手机",
	Dialog = "别打了，我立刻解锁。",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG04",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240136,
			Level = 226,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id628] =
{
	Id = 628,
	Name = "挑战天价勒索信",
	Area = 130158,
	PreCondition = {
		PreGoal = 
		{
			301283,
		},
	},
	AcceptSpeech = 14062801,
	Desc = "当这封充满恶意的信件出现在家里时，往往说明你珍爱的某件东西可能落到别人手中。",
	ResultText = "证物仓库出现了勒索信",
	Dialog = "快给钱，不然就不让你揍了！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG04",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240137,
			Level = 240,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id629] =
{
	Id = 629,
	Name = "挑战进口蓝墨水",
	Area = 130159,
	PreCondition = {
		PreGoal = 
		{
			301287,
		},
	},
	AcceptSpeech = 14062901,
	Desc = "使用贝壳和藻类制成的蓝色液体，通常用来记录信息类的文字，对海鲜过敏的人请务必谨慎使用。",
	ResultText = "审讯大厅出现了蓝墨水",
	Dialog = "这个洗不掉的！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG04",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240138,
			Level = 235,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id630] =
{
	Id = 630,
	Name = "挑战进口红墨水",
	Area = 130159,
	PreCondition = {
		PreGoal = 
		{
			301291,
		},
	},
	Desc = "使用花卉和矿石制成的红色液体，通常用来书写警示类的文字，有时会在杀手游戏中被当作鲜血道具使用。",
	ResultText = "审讯大厅出现了红墨水",
	Dialog = "这个洗不掉的！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG04",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240139,
			Level = 240,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id631] =
{
	Id = 631,
	Name = "挑战证人",
	Area = 130159,
	PreCondition = {
		PreGoal = 
		{
			301296,
		},
	},
	AcceptSpeech = 14063101,
	Desc = "热衷于推理的居民，梦想成为侦探，拥有过目不忘的本领。不过每次应询去警局录口供时，都会从警察嘴里套出案情，想要自己破案。",
	ResultText = "证人加入了队伍",
	Dialog = "你打了我，我来作证！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG04",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240140,
			Level = 248,
		},
	},
	Reward = {
		{
			Value = 220304,
			Num = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id632] =
{
	Id = 632,
	Name = "挑战可疑手铐",
	Area = 130160,
	PreCondition = {
		PreGoal = 
		{
			301534,
		},
	},
	Desc = "本来是逮捕罪犯的工具，但是它却经常出现在莫名其妙的地方……\n我们这是全年龄向游戏。",
	ResultText = "失物招领局出现了豹纹手铐",
	Dialog = "敢打我！？都拷上！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG02",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240141,
			Level = 250,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id633] =
{
	Id = 633,
	Name = "挑战可疑行李车",
	Area = 130160,
	PreCondition = {
		PreGoal = 
		{
			301538,
		},
	},
	Desc = "旅店运送行李的工具，这辆车本身并不是行李。",
	ResultText = "失物招领局出现了行李车",
	Dialog = "这里没有值钱的东西！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG02",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240142,
			Level = 255,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id634] =
{
	Id = 634,
	Name = "挑战精装水果笔记",
	Area = 130161,
	PreCondition = {
		PreGoal = 
		{
			301300,
		},
	},
	AcceptSpeech = 14063401,
	Desc = "记录着大量水果资料的笔记本，不知道打算用来做什么用。",
	ResultText = "编辑部出现了水果笔记",
	Dialog = "苹果一斤一块啦~",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG04",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240143,
			Level = 242,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id635] =
{
	Id = 635,
	Name = "挑战精装蔬菜笔记",
	Area = 130161,
	PreCondition = {
		PreGoal = 
		{
			301305,
		},
	},
	Desc = "记录着大量蔬菜资料的笔记本，不知道打算用来做什么用。",
	ResultText = "编辑部出现了蔬菜笔记",
	Dialog = "黄瓜一斤一块啦~",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG04",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240144,
			Level = 248,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id636] =
{
	Id = 636,
	Name = "挑战编辑长",
	Area = 130161,
	PreCondition = {
		PreGoal = 
		{
			301309,
		},
	},
	AcceptSpeech = 14063601,
	Desc = "认真负责的编辑长，为了不辜负读者，每天都在兢兢业业地工作。每5分钟都会联系约稿作家，防止对方放水。",
	ResultText = "编辑长加入了队伍",
	Dialog = "这一期真的出不出来了…",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG04",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240145,
			Level = 256,
		},
	},
	Reward = {
		{
			Value = 220309,
			Num = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id637] =
{
	Id = 637,
	Name = "挑战高倍放大镜",
	Area = 130162,
	PreCondition = {
		PreGoal = 
		{
			301313,
		},
	},
	AcceptSpeech = 14063701,
	Desc = "侦探们的好朋友，有时候没什么用，但是拿出来会让人觉得很有侦探的派头。",
	ResultText = "侦探街出现了放大镜",
	Dialog = "这还看不清？",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG02",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240146,
			Level = 250,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id638] =
{
	Id = 638,
	Name = "挑战祖传怀表",
	Area = 130162,
	PreCondition = {
		PreGoal = 
		{
			301317,
		},
	},
	Desc = "很有绅士风度的怀表，对时间的准头很讲究，具有催眠效果，可以让老板觉得自己没有迟到。",
	ResultText = "侦探街出现了怀表",
	Dialog = "时间啊停止吧！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG02",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240147,
			Level = 254,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id639] =
{
	Id = 639,
	Name = "挑战祖传烟斗",
	Area = 130162,
	PreCondition = {
		PreGoal = 
		{
			301321,
		},
	},
	Desc = "很喜欢和路人聊天攀谈的烟斗，如果聊天对象是侦探们的话，会开心得冒起烟来。",
	ResultText = "侦探街出现了烟斗",
	Dialog = "咳咳咳咳…吸烟有害健康…",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG02",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240148,
			Level = 258,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id640] =
{
	Id = 640,
	Name = "挑战凶手",
	Area = 130162,
	PreCondition = {
		PreGoal = 
		{
			301326,
		},
	},
	AcceptSpeech = 14064001,
	Desc = "令人闻风丧胆的凶手，没人知道ta的身份。只要ta出现，大家就会放弃抵抗落荒而逃，然后露出破绽，被他轻易击杀。",
	ResultText = "凶手加入了队伍",
	Dialog = "嘿嘿嘿嘿嘿！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG02",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240149,
			Level = 264,
		},
	},
	Reward = {
		{
			Value = 220305,
			Num = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id641] =
{
	Id = 641,
	Name = "挑战现场血迹",
	Area = 130163,
	PreCondition = {
		PreGoal = 
		{
			301542,
		},
	},
	AcceptSpeech = 14064101,
	Desc = "生物身体中必不可少的关键液体，不过有些生物个体看到它时会不自觉地晕倒。",
	ResultText = "实验室出现了血迹",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG04",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240150,
			Level = 275,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id642] =
{
	Id = 642,
	Name = "挑战恐怖黑猫",
	Area = 130163,
	PreCondition = {
		PreGoal = 
		{
			301546,
		},
	},
	Desc = "神秘的黑色猫咪，经常出现在事故现场，会不会是死神的凡间化身呢？",
	ResultText = "实验室出现了黑猫",
	Dialog = "喵…",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG04",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240151,
			Level = 285,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id643] =
{
	Id = 643,
	Name = "挑战最强大脑",
	Area = 130163,
	PreCondition = {
		PreGoal = 
		{
			301550,
		},
	},
	Desc = "实验室特别存保存下来的生物大脑，其中存储着大量重要的信息。",
	ResultText = "实验室出现了瓶中脑",
	Dialog = "我承认你是最聪明的！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG04",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240152,
			Level = 299,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id644] =
{
	Id = 644,
	Name = "挑战迈克罗夫特",
	Area = 130163,
	PreCondition = {
		PreGoal = 
		{
			301551,
		},
	},
	AcceptSpeech = 14064401,
	Desc = "可能是这个世界上智商最高的人，对推理没有什么兴趣。时间都花在了保护爱闯祸的弟弟身上。",
	ResultText = "迈克罗夫特加入了队伍",
	Dialog = "智慧在某些时候不如武力…",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SUSBG04",
	StartScene = "SUS_StartScene",
	Enemy = {
		{
			Value = 240153,
			Level = 299,
		},
	},
	Reward = {
		{
			Value = 220323,
			Num = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id801] =
{
	Id = 801,
	Name = "挑战绿草草",
	Area = 130201,
	PreCondition = {
		PreGoal = 
		{
			301604,
		},
	},
	AcceptSpeech = 14080101,
	Desc = "完全没有一点主见的绿色海草，别人说什么就是什么，因此常常被其他鱼吐槽“绿草草，随风倒”。",
	ResultText = "打败了坠落点的绿草草",
	Dialog = "嗷……是那边吧？",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SEABG01",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240154,
			Level = 268,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id802] =
{
	Id = 802,
	Name = "挑战海豚凛",
	Area = 130201,
	PreCondition = {
		PreGoal = 
		{
			301609,
		},
	},
	AcceptSpeech = 14080201,
	Desc = "具有超高的唱歌天赋，温驯海族，能唱出直击心灵的歌曲，希望能凭借努力成为闪闪发光的偶像。然而，偶像的道路并不会一帆风顺……",
	ResultText = "海豚凛加入了队伍",
	Dialog = "唔，好疼！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SEABG01",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240155,
			Level = 280,
		},
	},
	Reward = {
		{
			Value = 220401,
			Num = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id803] =
{
	Id = 803,
	Name = "挑战珊瑚红",
	Area = 130202,
	PreCondition = {
		PreGoal = 
		{
			301614,
		},
	},
	AcceptSpeech = 14080301,
	Desc = "海底自助化妆师，只要摸摸TA的头，TA就会突然窜出来，并迅速完成一套珊瑚红系的完美妆容，一次只要100海洋币。",
	ResultText = "音乐广场出现了珊瑚红",
	Dialog = "提供红色妆容，一次100",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SEABG02",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240157,
			Level = 276,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id804] =
{
	Id = 804,
	Name = "挑战梅子紫",
	Area = 130202,
	PreCondition = {
		PreGoal = 
		{
			301619,
		},
	},
	Desc = "海底自助化妆师，珊瑚红的同事，不过TA带来的是梅子紫系的全套妆容，一次150海洋币。",
	ResultText = "音乐广场出现了梅子紫",
	Dialog = "提供紫色妆容，一次150",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SEABG02",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240156,
			Level = 280,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id805] =
{
	Id = 805,
	Name = "挑战红贝壳",
	Area = 130203,
	PreCondition = {
		PreGoal = 
		{
			301624,
		},
	},
	AcceptSpeech = 14080501,
	Desc = "据说是海底世界的百事通，被评价为“海里的全知道，海外的知道一半”，不过，这真的是客观评价吗？",
	ResultText = "浅海沙滩出现了红贝壳",
	Dialog = "我什么什么~我什么都知道",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SEABG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240158,
			Level = 284,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id806] =
{
	Id = 806,
	Name = "挑战黄贝壳",
	Area = 130203,
	PreCondition = {
		PreGoal = 
		{
			301629,
		},
	},
	AcceptSpeech = 14080601,
	Desc = "红贝壳的好友，当红贝壳的坑蒙拐骗被拆穿时，TA就负责出来收拾残局。",
	ResultText = "浅海沙滩出现了黄贝壳",
	Dialog = "说我坑蒙拐骗？有证据吗！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SEABG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240159,
			Level = 288,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id807] =
{
	Id = 807,
	Name = "挑战鱿鱼",
	Area = 130204,
	PreCondition = {
		PreGoal = 
		{
			301905,
		},
	},
	Desc = "具有八条长腿，能狠狠吸住休息厅的地毯，谁都不能把TA拖走。",
	ResultText = "休息厅出现了鱿鱼",
	Dialog = "我不走……放开我……",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SEABG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240160,
			Level = 292,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id808] =
{
	Id = 808,
	Name = "挑战章鱼",
	Area = 130204,
	PreCondition = {
		PreGoal = 
		{
			301910,
		},
	},
	AcceptSpeech = 14080801,
	Desc = "精通伪装，不仅可以伪装自己的形态，还能把别人的声音模仿得惟妙惟肖。",
	ResultText = "休息厅出现了章鱼",
	Dialog = "哎呀，被发现了！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SEABG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240161,
			Level = 312,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id809] =
{
	Id = 809,
	Name = "挑战刺豚茉白",
	Area = 130204,
	PreCondition = {
		PreGoal = 
		{
			301915,
		},
	},
	AcceptSpeech = 14080901,
	Desc = "过去是深潜FoRever成员，温驯海族，不开心的时候会无法控制地在腮帮子里吹气，整个身体也会变得膨胀。因此，现在还在努力学习如何控制情绪中。",
	ResultText = "刺豚茉白加入了队伍",
	Dialog = "我开始生气了！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SEABG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240162,
			Level = 324,
		},
	},
	Reward = {
		{
			Value = 220405,
			Num = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id810] =
{
	Id = 810,
	Name = "挑战红草草",
	Area = 130205,
	PreCondition = {
		PreGoal = 
		{
			301634,
		},
	},
	AcceptSpeech = 14081001,
	Desc = "一颗毫无主见的红色海草，随波飘摇，虽然没有依据，但很多人坚信TA和绿草草是一家人。",
	ResultText = "回溯镇出现了红草草",
	Dialog = "应该去哪边呢？好纠结啊……",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SEABG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240163,
			Level = 292,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id811] =
{
	Id = 811,
	Name = "挑战海参",
	Area = 130205,
	PreCondition = {
		PreGoal = 
		{
			301639,
		},
	},
	AcceptSpeech = 14081101,
	Desc = "热爱和同伴玩喷水游戏，但总是会喷出一些奇怪的东西。",
	ResultText = "回溯镇出现了海参",
	Dialog = "biu~biubiu~",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SEABG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240164,
			Level = 296,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id812] =
{
	Id = 812,
	Name = "挑战火山海参",
	Area = 130205,
	PreCondition = {
		PreGoal = 
		{
			301644,
		},
	},
	Desc = "是海参中的奇异物种，紧张或过于兴奋时会喷射出岩浆，一到冬天，许多鱼都会慕名过来取暖。",
	ResultText = "回溯镇出现了火山海参",
	Dialog = "biu~啊，好烫！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SEABG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240165,
			Level = 300,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id813] =
{
	Id = 813,
	Name = "挑战乌贼墨",
	Area = 130205,
	PreCondition = {
		PreGoal = 
		{
			301649,
		},
	},
	AcceptSpeech = 14081301,
	Desc = "Aquarius中的一员，凶猛海族，拥有制造墨色雾气舞台效果的绝技，因此收获了众多粉丝的喜爱。热爱吃瓜，对于鱼乐圈的八卦了如指掌。",
	ResultText = "乌贼墨加入了队伍",
	Dialog = "可恶，墨汁喷完了吗……",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SEABG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240166,
			Level = 312,
		},
	},
	Reward = {
		{
			Value = 220402,
			Num = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id814] =
{
	Id = 814,
	Name = "挑战绿礁保安",
	Area = 130206,
	PreCondition = {
		PreGoal = 
		{
			301654,
		},
	},
	AcceptSpeech = 14081401,
	Desc = "穿着绿色制服的保安，保卫礁石区一方平安，会对危害公共安全的危险分子，会毫不留情发射藤壶。",
	ResultText = "礁石区出现了绿礁保安",
	Dialog = "向危险分子，开炮！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SEABG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240167,
			Level = 304,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id815] =
{
	Id = 815,
	Name = "挑战蓝礁保安",
	Area = 130206,
	PreCondition = {
		PreGoal = 
		{
			301659,
		},
	},
	AcceptSpeech = 14081501,
	Desc = "穿着蓝色制服的保安，比起发射远程武器，更喜欢用喇叭大喊大叫，用声波击退敌人。",
	ResultText = "礁石区出现了蓝礁保安",
	Dialog = "危险分子，速速走开！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SEABG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240168,
			Level = 308,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id816] =
{
	Id = 816,
	Name = "挑战比目司机",
	Area = 130207,
	PreCondition = {
		PreGoal = 
		{
			301664,
		},
	},
	AcceptSpeech = 14081601,
	Desc = "常年行驶在星光小道的司机，因为两只眼睛都长在左边，所以只能看到左边的路。",
	ResultText = "星光小道出现了比目司机",
	Dialog = "您好，您想去哪边？",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SEABG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240169,
			Level = 312,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id817] =
{
	Id = 817,
	Name = "挑战小丑司机",
	Area = 130207,
	PreCondition = {
		PreGoal = 
		{
			301669,
		},
	},
	Desc = "星光小道的司机，有时候无法控制自己的行动，会下意识把乘客带去海葵的区域。",
	ResultText = "星光小道出现了小丑司机",
	Dialog = "啊，您是想去海葵那里吗？",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SEABG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240170,
			Level = 316,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id818] =
{
	Id = 818,
	Name = "挑战神仙司机",
	Area = 130207,
	PreCondition = {
		PreGoal = 
		{
			301674,
		},
	},
	Desc = "星光小道的神仙司机，能把准确地把乘客带去目的地，但是要坐上TA的车，并不是一件容易的事。",
	ResultText = "星光小道出现了神仙司机",
	Dialog = "愚蠢的家伙，离开我的车！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SEABG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240171,
			Level = 320,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id819] =
{
	Id = 819,
	Name = "挑战蓝记水母",
	Area = 130208,
	PreCondition = {
		PreGoal = 
		{
			301921,
		},
	},
	Desc = "鱼乐日报记者，又名皮埃斯，擅长图片编辑，有伪造图片被艺人告上法庭的经历。",
	ResultText = "深海区出现了蓝记水母",
	Dialog = "你们，还我照片！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SEABG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240172,
			Level = 306,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id820] =
{
	Id = 820,
	Name = "挑战紫记水母",
	Area = 130208,
	PreCondition = {
		PreGoal = 
		{
			301926,
		},
	},
	AcceptSpeech = 14082001,
	Desc = "鱼乐日报记者，公认的标题党，因为标题过于猎奇，在读者中已经失去了可信度。",
	ResultText = "深海区出现了紫记水母",
	Dialog = "震惊！外星人竟做出这种事！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SEABG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240173,
			Level = 321,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id821] =
{
	Id = 821,
	Name = "挑战黄记水母",
	Area = 130208,
	PreCondition = {
		PreGoal = 
		{
			301931,
		},
	},
	Desc = "鱼乐日报记者，常用黄色的纸笔，写下带颜色的文章，迄今为止已收到了2356份律师函。",
	ResultText = "深海区出现了黄记水母",
	Dialog = "不要把我抓起来，呜呜呜。",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SEABG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240174,
			Level = 336,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id822] =
{
	Id = 822,
	Name = "挑战海蛇",
	Area = 130209,
	PreCondition = {
		PreGoal = 
		{
			301679,
		},
	},
	AcceptSpeech = 14082201,
	Desc = "地下乐队的组织者，死亡重金属爱好者，据说曾是海蛇莱斯莉的队友。",
	ResultText = "演播厅出现了海蛇",
	Dialog = "嗖嗖嗖！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SEABG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240175,
			Level = 324,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id823] =
{
	Id = 823,
	Name = "挑战闪电海蛇",
	Area = 130209,
	PreCondition = {
		PreGoal = 
		{
			301684,
		},
	},
	Desc = "曾是海蛇莱斯莉的队友，产出了许多重金属风格的demo，最近在尝试新的音乐风格。",
	ResultText = "演播厅出现了闪电海蛇",
	Dialog = "听完demo，稳了！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SEABG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240176,
			Level = 328,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id824] =
{
	Id = 824,
	Name = "挑战电鳗伊俄",
	Area = 130209,
	PreCondition = {
		PreGoal = 
		{
			301689,
		},
	},
	AcceptSpeech = 14082401,
	Desc = "solo出道的摇滚歌手，凶猛海族，迄今为止已经开了很多场演唱会。在台上嗨到极致的时候会放电，经常吓到工作人员。",
	ResultText = "电鳗伊俄加入了队伍",
	Dialog = "竟然有人的电力比我还足？",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SEABG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240177,
			Level = 340,
		},
	},
	Reward = {
		{
			Value = 220403,
			Num = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id825] =
{
	Id = 825,
	Name = "挑战海星星",
	Area = 130210,
	PreCondition = {
		PreGoal = 
		{
			301937,
		},
	},
	AcceptSpeech = 14082501,
	Desc = "天鱼公司的初级经纪，主要负责面试艺人，在工作中兢兢业业，希望通过自己的努力升职加薪。",
	ResultText = "面试舞台出现了海星星",
	Dialog = "我不会给你发offer的！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SEABG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240178,
			Level = 340,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id826] =
{
	Id = 826,
	Name = "挑战皇冠星探",
	Area = 130210,
	PreCondition = {
		PreGoal = 
		{
			301942,
		},
	},
	AcceptSpeech = 14082601,
	Desc = "天鱼公司的高级经纪，业务能力了得，就连公司boss帝王蟹老板也非常尊敬TA。",
	ResultText = "面试舞台出现了皇冠星探",
	Dialog = "老板，您看TA怎么样？",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SEABG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240179,
			Level = 344,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id827] =
{
	Id = 827,
	Name = "挑战水熊虫",
	Area = 130211,
	PreCondition = {
		PreGoal = 
		{
			301694,
		},
	},
	AcceptSpeech = 14082701,
	Desc = "海底世界的厕所管理员，对于那些想进入未成年厕所的家伙，一定要仔细检查TA们的身体。",
	ResultText = "打败了大舞台的水熊虫",
	Dialog = "不行，不准进去——",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SEABG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240180,
			Level = 332,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id828] =
{
	Id = 828,
	Name = "挑战绿绵宝宝",
	Area = 130211,
	PreCondition = {
		PreGoal = 
		{
			301699,
		},
	},
	AcceptSpeech = 14082801,
	Desc = "蟹老板雇来抹黑海豚凛的水军，给钱就办事，非常好说话。",
	ResultText = "大舞台出现了绿绵宝宝",
	Dialog = "你这个价格，让我很难办啊。",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SEABG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240181,
			Level = 336,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id829] =
{
	Id = 829,
	Name = "挑战红绵宝宝",
	Area = 130211,
	PreCondition = {
		PreGoal = 
		{
			301704,
		},
	},
	Desc = "蟹老板雇来抹黑海豚凛的水军，什么？除了现场闹事，还要去其他地方散播要钱？可以，但得加钱。",
	ResultText = "大舞台出现了红绵宝宝",
	Dialog = "打舒服了？我有辛苦费吗？",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SEABG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240182,
			Level = 340,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id830] =
{
	Id = 830,
	Name = "挑战蓝海葵",
	Area = 130212,
	PreCondition = {
		PreGoal = 
		{
			301709,
		},
	},
	AcceptSpeech = 14083001,
	Desc = "天鱼公司的星探之一，除了小丑鱼，不会考虑和其他种族的任何艺人签约，因此业绩一直平平。",
	ResultText = "高音剧场出现了蓝海葵",
	Dialog = "hello，合同签吗？",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SEABG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240184,
			Level = 344,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id831] =
{
	Id = 831,
	Name = "挑战红海葵",
	Area = 130212,
	PreCondition = {
		PreGoal = 
		{
			301714,
		},
	},
	Desc = "天鱼公司的星探之一，曾哄骗许多艺人签下不公平合同，在鱼乐圈中臭名昭著，但总会骗到一些初入圈子的小白。",
	ResultText = "高音剧场出现了红海葵",
	Dialog = "我的小艺人呢？",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SEABG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240183,
			Level = 348,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id832] =
{
	Id = 832,
	Name = "挑战鲎椰子",
	Area = 130212,
	PreCondition = {
		PreGoal = 
		{
			301719,
		},
	},
	AcceptSpeech = 14083201,
	Desc = "来自偏远贫穷的小村落，温驯海族，自称是全村的希望，有些胆小自卑，因此并不被经纪公司看好，但TA的天真和努力，打动了许多粉丝。",
	ResultText = "鲎椰子加入了队伍",
	Dialog = "不要打我……呜呜……",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SEABG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240185,
			Level = 360,
		},
	},
	Reward = {
		{
			Value = 220404,
			Num = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id833] =
{
	Id = 833,
	Name = "挑战蟹经理",
	Area = 130213,
	PreCondition = {
		PreGoal = 
		{
			301724,
		},
	},
	AcceptSpeech = 14083301,
	Desc = "天鱼公司总经理，唯董事长马首是瞻。",
	ResultText = "海底世界出现了蟹经理",
	Dialog = "老板，有人打我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SEABG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240186,
			Level = 352,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id834] =
{
	Id = 834,
	Name = "挑战蟹董事",
	Area = 130213,
	PreCondition = {
		PreGoal = 
		{
			301729,
		},
	},
	AcceptSpeech = 14083401,
	Desc = "天鱼公司董事长，被别人称为蟹老板，然而TA对此表示非常不满，并要求大家称呼自己为“帝王蟹董事”。",
	ResultText = "海底世界出现了蟹董事",
	Dialog = "可恶啊，愚蠢的人民！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SEABG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240187,
			Level = 360,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id835] =
{
	Id = 835,
	Name = "挑战绵羊海兔",
	Area = 130214,
	PreCondition = {
		PreGoal = 
		{
			301948,
		},
	},
	AcceptSpeech = 14083501,
	Desc = "绿色的海兔，每天除了吃喝玩乐，就是吃喝玩乐。",
	ResultText = "大漩涡出现了绵羊海兔",
	Dialog = "咕……咕咕。",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SEABG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240188,
			Level = 364,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id836] =
{
	Id = 836,
	Name = "挑战粉红海兔",
	Area = 130214,
	PreCondition = {
		PreGoal = 
		{
			301953,
		},
	},
	Desc = "粉红色的海兔，玩“叠罗汉”的时候，最喜欢在中间的位置。",
	ResultText = "大漩涡出现了粉红海兔",
	Dialog = "咕唧……咕唧……",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SEABG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240189,
			Level = 368,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id837] =
{
	Id = 837,
	Name = "挑战蓝海兔",
	Area = 130214,
	PreCondition = {
		PreGoal = 
		{
			301958,
		},
	},
	Desc = "蓝色海兔，生命中只有吃饭、睡觉、叠兔兔。",
	ResultText = "大漩涡出现了蓝海兔",
	Dialog = "我生气了！咕唧！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SEABG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240190,
			Level = 372,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id838] =
{
	Id = 838,
	Name = "挑战鱼不翻",
	Area = 130214,
	PreCondition = {
		PreGoal = 
		{
			301963,
		},
	},
	AcceptSpeech = 14083801,
	Desc = "偶像团体鱼妄想中的一员，温驯海族，口号是“翻车鱼的演出永不翻车！”。明明是个木讷的人，但有时又让人觉得聪明机警。",
	ResultText = "鱼不翻加入了队伍",
	Dialog = "啊哦——翻、车、了——",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "SEABG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240191,
			Level = 392,
		},
	},
	Reward = {
		{
			Value = 220406,
			Num = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1001] =
{
	Id = 1001,
	Name = "挑战警戒草",
	Area = 130251,
	AcceptSpeech = 14100101,
	Desc = "虽然看上去是个很狂热的粉丝，但其实是墙头草，每过一段时间就会换个人单推。",
	ResultText = "着陆点出现了警戒草",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG01",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240192,
			Level = 236,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1002] =
{
	Id = 1002,
	Name = "挑战蠕虫骑手",
	Area = 130251,
	PreCondition = {
		PreGoal = 
		{
			302001,
		},
	},
	AcceptSpeech = 14100201,
	Desc = "星球知名狗仔记者，依靠完美伪装多次拍摄到名人出轨照片并爆出，因此臭名昭著，经常出没于海草密集区。",
	ResultText = "着陆点出现了蠕虫骑手",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG01",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240193,
			Level = 252,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1003] =
{
	Id = 1003,
	Name = "挑战紫弦月",
	Area = 130251,
	PreCondition = {
		PreGoal = 
		{
			302002,
		},
	},
	AcceptSpeech = 14100301,
	Desc = "海洋星的超人气美少女新人偶像，长相可爱，歌声动听，一经出道便引发粉丝的沸腾，被认为是Sharkalaka的下一任候选人。但本人性格有些天然，对于成为偶像这件事并没有什么自觉，有些害怕Sharkalaka的C位虎鲸。",
	ResultText = "紫弦月加入了队伍",
	Dialog = "0",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG01",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240194,
			Level = 244,
		},
	},
	Reward = {
		{
			Value = 220501,
			Num = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1004] =
{
	Id = 1004,
	Name = "挑战独角仙",
	Area = 130252,
	PreCondition = {
		PreGoal = 
		{
			302003,
		},
	},
	AcceptSpeech = 14100401,
	Desc = "星球知名狗仔记者，依靠完美伪装多次拍摄到名人出轨照片并爆出，因此臭名昭著，经常出没于海草密集区。",
	ResultText = "黄金之砂出现了独角仙",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG02",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240195,
			Level = 248,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1005] =
{
	Id = 1005,
	Name = "挑战沙漠掠匪",
	Area = 130252,
	PreCondition = {
		PreGoal = 
		{
			302004,
		},
	},
	AcceptSpeech = 14100501,
	Desc = "热衷偶像的狂热粉丝，最疯狂时，每天都会守在偶像宿舍附近，一旦发现偶像就会冲上去强吻，遭到通缉后逃窜到大漩涡地区。",
	ResultText = "黄金之砂出现了沙漠掠匪",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG02",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240196,
			Level = 252,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1006] =
{
	Id = 1006,
	Name = "挑战红蝎",
	Area = 130252,
	PreCondition = {
		PreGoal = 
		{
			302005,
		},
	},
	Desc = "热衷偶像的狂热粉丝，最疯狂时，每天都会守在偶像宿舍附近，一旦发现偶像就会冲上去强吻，遭到通缉后逃窜到大漩涡地区。",
	ResultText = "黄金之砂出现了红蝎",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG02",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240197,
			Level = 252,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1007] =
{
	Id = 1007,
	Name = "挑战黑蝎",
	Area = 130252,
	PreCondition = {
		PreGoal = 
		{
			302006,
		},
	},
	Desc = "星球知名狗仔记者，依靠完美伪装多次拍摄到偶像地下恋情的照片并爆出，因此臭名昭著，经常出没于蓝藻密集区。",
	ResultText = "黄金之砂出现了黑蝎",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG02",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240198,
			Level = 252,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1008] =
{
	Id = 1008,
	Name = "挑战囚人",
	Area = 130253,
	PreCondition = {
		PreGoal = 
		{
			302007,
		},
	},
	AcceptSpeech = 14100801,
	Desc = "海豚乙女的狂热粉丝，自认为是海豚的三千辈后代，有族谱为证，并能清楚地指认出是哪一位祖先被海豚误食。",
	ResultText = "地幔堡垒出现了囚人",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240199,
			Level = 256,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1009] =
{
	Id = 1009,
	Name = "挑战警卫",
	Area = 130253,
	PreCondition = {
		PreGoal = 
		{
			302008,
		},
	},
	AcceptSpeech = 14100901,
	Desc = "Aquarius的狂热粉丝，自认为是水瓶座的化身，有出生年月为证，并发誓要找一个水瓶座的女朋友。",
	ResultText = "地幔堡垒出现了警卫",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240200,
			Level = 260,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1010] =
{
	Id = 1010,
	Name = "挑战琉璃兜",
	Area = 130253,
	PreCondition = {
		PreGoal = 
		{
			302009,
		},
	},
	AcceptSpeech = 14101001,
	Desc = "虎鲸的头号狂热粉丝，为了追星进入了偶像公司。成功成为Sharkalaka的队员候选之后，依伶一如既往地保持着对虎鲸的崇拜，并对任何想要和她争抢这个位置的人怀有强烈敌意。",
	ResultText = "琉璃兜加入了队伍",
	Dialog = "0",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240201,
			Level = 268,
		},
	},
	Reward = {
		{
			Value = 220502,
			Num = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1011] =
{
	Id = 1011,
	Name = "挑战机械引擎",
	Area = 130254,
	PreCondition = {
		PreGoal = 
		{
			302010,
		},
	},
	AcceptSpeech = 14101101,
	Desc = "狂热得有些扭曲的粉丝，喜欢潜入到休息室进行偷窥，因脸皮有厚重的贝壳保护而无所畏惧。",
	ResultText = "试验场出现了机械引擎",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240202,
			Level = 276,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1012] =
{
	Id = 1012,
	Name = "挑战报废的机器头部",
	Area = 130254,
	PreCondition = {
		PreGoal = 
		{
			302011,
		},
	},
	AcceptSpeech = 14101201,
	Desc = "热衷偶像的狂热粉丝，最疯狂时，每天都会守在偶像宿舍附近，一旦发现偶像就会冲上去强吻，遭到通缉后逃窜到大漩涡地区。",
	ResultText = "试验场出现了报废的机器头部",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240203,
			Level = 280,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1013] =
{
	Id = 1013,
	Name = "挑战老旧机器人",
	Area = 130254,
	PreCondition = {
		PreGoal = 
		{
			302012,
		},
	},
	Desc = "专注于挖掘偶像黑料的黑粉，喜欢潜入到休息室进行偷窥，因为三观歪成圆圈而无所畏惧。",
	ResultText = "试验场出现了老旧机器人",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240204,
			Level = 280,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1014] =
{
	Id = 1014,
	Name = "挑战珍珠吊兰",
	Area = 130254,
	PreCondition = {
		PreGoal = 
		{
			302013,
		},
	},
	AcceptSpeech = 14101401,
	Desc = "海洋星偶像团体海豚乙女的成员，擅长婉转动听的乡村小调。实为来自乡下的居民，为了实现成为偶像的梦想背井离乡，性格质朴，和同团的映冬关系非常好。",
	ResultText = "珍珠吊兰加入了队伍",
	Dialog = "0",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240205,
			Level = 288,
		},
	},
	Reward = {
		{
			Value = 220503,
			Num = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1015] =
{
	Id = 1015,
	Name = "挑战砂鱼",
	Area = 130255,
	PreCondition = {
		PreGoal = 
		{
			302014,
		},
	},
	AcceptSpeech = 14101501,
	Desc = "出身贫寒却疯狂地迷恋偶像，为追星散尽家财，最后不得不偷窃贝壳卖钱，最近为躲避高利贷追杀正藏身于大漩涡地区。",
	ResultText = "流沙之河出现了砂鱼",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240206,
			Level = 268,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1016] =
{
	Id = 1016,
	Name = "挑战黄砂鱼",
	Area = 130255,
	PreCondition = {
		PreGoal = 
		{
			302015,
		},
	},
	AcceptSpeech = 14101601,
	Desc = "热衷偶像的狂热粉丝，最疯狂时，每天都会守在偶像宿舍附近，一旦发现偶像就会冲上去强吻，遭到通缉后逃窜到大漩涡地区。",
	ResultText = "流沙之河出现了黄砂鱼",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240207,
			Level = 272,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1017] =
{
	Id = 1017,
	Name = "挑战陆鳄",
	Area = 130255,
	PreCondition = {
		PreGoal = 
		{
			302016,
		},
	},
	AcceptSpeech = 14101701,
	Desc = "曾参加过星光小道的海选，距离成为偶像只有一步之遥的时候因为在演出前吃大蒜而被刷掉，从此扭曲了精神，对偶像怀恨在心。",
	ResultText = "流沙之河出现了陆鳄",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240208,
			Level = 252,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1018] =
{
	Id = 1018,
	Name = "挑战喷壶虫",
	Area = 130256,
	PreCondition = {
		PreGoal = 
		{
			302017,
		},
	},
	AcceptSpeech = 14101801,
	Desc = "生活在礁石区的小混混，梦想是成为人人害怕的大坏蛋，成天潜伏在沙土下面，有人路过就会突然窜出来吓人一跳，不过对方开骂就会立刻道歉。",
	ResultText = "绿洲寨出现了喷壶虫",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240209,
			Level = 276,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1019] =
{
	Id = 1019,
	Name = "挑战黄蜂",
	Area = 130256,
	PreCondition = {
		PreGoal = 
		{
			302018,
		},
	},
	Desc = "热衷偶像的狂热粉丝，最疯狂时，每天都会守在偶像宿舍附近，一旦发现偶像就会冲上去强吻，遭到通缉后逃窜到大漩涡地区。",
	ResultText = "绿洲寨出现了黄蜂",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240210,
			Level = 252,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1020] =
{
	Id = 1020,
	Name = "挑战蜂后",
	Area = 130256,
	PreCondition = {
		PreGoal = 
		{
			302019,
		},
	},
	Desc = "热衷偶像的狂热粉丝，最疯狂时，每天都会守在偶像宿舍附近，一旦发现偶像就会冲上去强吻，遭到通缉后逃窜到大漩涡地区。",
	ResultText = "绿洲寨出现了蜂后",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240211,
			Level = 252,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1021] =
{
	Id = 1021,
	Name = "挑战地城守卫",
	Area = 130256,
	PreCondition = {
		PreGoal = 
		{
			302020,
		},
	},
	Desc = "礁石区的小混混头目，从小就开始混社会，见惯大风大浪，背后还有战斗留下的疤痕，其实是小时候和小朋友抢棒棒糖时留下的。",
	ResultText = "绿洲寨出现了地城守卫",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240212,
			Level = 280,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1022] =
{
	Id = 1022,
	Name = "挑战矿山暴徒",
	Area = 130257,
	PreCondition = {
		PreGoal = 
		{
			302021,
		},
	},
	AcceptSpeech = 14102201,
	Desc = "生活在礁石区的小混混，梦想是成为人人害怕的大坏蛋，成天潜伏在沙土下面，有人路过就会突然窜出来吓人一跳，不过对方开骂就会立刻道歉。",
	ResultText = "矿场出现了矿山暴徒",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240213,
			Level = 300,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1023] =
{
	Id = 1023,
	Name = "挑战暴徒头目",
	Area = 130257,
	PreCondition = {
		PreGoal = 
		{
			302022,
		},
	},
	AcceptSpeech = 14102301,
	Desc = "热衷偶像的狂热粉丝，最疯狂时，每天都会守在偶像宿舍附近，一旦发现偶像就会冲上去强吻，遭到通缉后逃窜到大漩涡地区。",
	ResultText = "矿场出现了暴徒头目",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240214,
			Level = 304,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1024] =
{
	Id = 1024,
	Name = "挑战矿甲虫",
	Area = 130257,
	PreCondition = {
		PreGoal = 
		{
			302023,
		},
	},
	AcceptSpeech = 14102401,
	Desc = "热衷偶像的狂热粉丝，最疯狂时，每天都会守在偶像宿舍附近，一旦发现偶像就会冲上去强吻，遭到通缉后逃窜到大漩涡地区。",
	ResultText = "矿场出现了矿甲虫",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240215,
			Level = 304,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1025] =
{
	Id = 1025,
	Name = "挑战金甲虫",
	Area = 130257,
	PreCondition = {
		PreGoal = 
		{
			302024,
		},
	},
	Desc = "礁石区的小混混头目，从小就开始混社会，见惯大风大浪，背后还有战斗留下的疤痕，其实是小时候和小朋友抢棒棒糖时留下的。",
	ResultText = "矿场出现了金甲虫",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240216,
			Level = 280,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1026] =
{
	Id = 1026,
	Name = "挑战鼹鼠帮",
	Area = 130258,
	PreCondition = {
		PreGoal = 
		{
			302025,
		},
	},
	AcceptSpeech = 14102601,
	Desc = "生活在礁石区的小混混，梦想是成为人人害怕的大坏蛋，成天潜伏在沙土下面，有人路过就会突然窜出来吓人一跳，不过对方开骂就会立刻道歉。",
	ResultText = "无法地带出现了鼹鼠帮",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240217,
			Level = 284,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1027] =
{
	Id = 1027,
	Name = "挑战鼹鼠头头",
	Area = 130258,
	PreCondition = {
		PreGoal = 
		{
			302026,
		},
	},
	Desc = "热衷偶像的狂热粉丝，最疯狂时，每天都会守在偶像宿舍附近，一旦发现偶像就会冲上去强吻，遭到通缉后逃窜到大漩涡地区。",
	ResultText = "无法地带出现了鼹鼠头头",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240218,
			Level = 288,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1028] =
{
	Id = 1028,
	Name = "挑战蠕虫特工",
	Area = 130258,
	PreCondition = {
		PreGoal = 
		{
			302027,
		},
	},
	Desc = "热衷偶像的狂热粉丝，最疯狂时，每天都会守在偶像宿舍附近，一旦发现偶像就会冲上去强吻，遭到通缉后逃窜到大漩涡地区。",
	ResultText = "无法地带出现了蠕虫特工",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240219,
			Level = 292,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1029] =
{
	Id = 1029,
	Name = "挑战谜之机械",
	Area = 130258,
	PreCondition = {
		PreGoal = 
		{
			302028,
		},
	},
	AcceptSpeech = 14102901,
	Desc = "礁石区的小混混头目，从小就开始混社会，见惯大风大浪，背后还有战斗留下的疤痕，其实是小时候和小朋友抢棒棒糖时留下的。",
	ResultText = "无法地带出现了谜之机械",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240220,
			Level = 280,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1030] =
{
	Id = 1030,
	Name = "挑战机械臂",
	Area = 130259,
	PreCondition = {
		PreGoal = 
		{
			302029,
		},
	},
	AcceptSpeech = 14103001,
	Desc = "对待每件事情都非常认真的偏执型海洋生物，平时会不停地打扫自己的螺壳，看演出时，会努力说服附近的观众挥舞荧光棒时和它的频率保持一致。",
	ResultText = "机械车间出现了机械臂",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240221,
			Level = 300,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1031] =
{
	Id = 1031,
	Name = "挑战机器员工",
	Area = 130259,
	PreCondition = {
		PreGoal = 
		{
			302030,
		},
	},
	Desc = "热衷偶像的狂热粉丝，最疯狂时，每天都会守在偶像宿舍附近，一旦发现偶像就会冲上去强吻，遭到通缉后逃窜到大漩涡地区。",
	ResultText = "机械车间出现了机器员工",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240222,
			Level = 304,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1032] =
{
	Id = 1032,
	Name = "挑战机器工头",
	Area = 130259,
	PreCondition = {
		PreGoal = 
		{
			302031,
		},
	},
	Desc = "斤斤计较的小气鬼，最喜欢AA制，哪怕是一分钱都要分个清楚，讨厌被别人占便宜。",
	ResultText = "机械车间出现了机器工头",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240223,
			Level = 308,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1033] =
{
	Id = 1033,
	Name = "挑战失控的零件",
	Area = 130260,
	Desc = "Aquarius的粉丝头，经常组织粉丝们打榜冲票，在大选期间会展现出领导人一般的组织力和行动力。",
	ResultText = "星核出现了失控的零件",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240224,
			Level = 312,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1034] =
{
	Id = 1034,
	Name = "挑战纯净能量体",
	Area = 130260,
	PreCondition = {
		PreGoal = 
		{
			302302,
		},
	},
	Desc = "因为喜欢的偶像团体在数据榜上被超越而心怀怨念，久而久之成为了Sharkalaka的黑粉，专注于造谣，认为自己在做正确的事情。",
	ResultText = "星核出现了纯净能量体",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240225,
			Level = 304,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1035] =
{
	Id = 1035,
	Name = "挑战人工智能G-0X",
	Area = 130260,
	PreCondition = {
		PreGoal = 
		{
			302303,
		},
	},
	Desc = "Sharkalaka的粉丝，牙牙的个人粉。声称是牙牙最大的支持者，收集了她的各种偷拍照片，并从网上下载了每一张专辑的盗版资源。",
	ResultText = "星核出现了人工智能G-0X",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240226,
			Level = 304,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1036] =
{
	Id = 1036,
	Name = "挑战高砂之翁",
	Area = 130260,
	PreCondition = {
		PreGoal = 
		{
			302304,
		},
	},
	Desc = "贝壳街tea time成员，非常擅长乐器，演唱至高潮时会把头上的海螺拿下来即兴solo。",
	ResultText = "高砂之翁加入了队伍",
	Dialog = "0",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240227,
			Level = 344,
		},
	},
	Reward = {
		{
			Value = 220505,
			Num = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1037] =
{
	Id = 1037,
	Name = "挑战报警机器人",
	Area = 130261,
	PreCondition = {
		PreGoal = 
		{
			302032,
		},
	},
	AcceptSpeech = 14103701,
	Desc = "广泛分部于各大海域的鱼类，对环境适应力很强，咸水或淡水下都能生活，主要喜好是时事评论，每天醒来第一件事就是看当天热搜，然后在评论区陈述己见。",
	ResultText = "地心城出现了报警机器人",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240228,
			Level = 316,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1038] =
{
	Id = 1038,
	Name = "挑战王都警卫",
	Area = 130261,
	PreCondition = {
		PreGoal = 
		{
			302033,
		},
	},
	Desc = "脸颊上长有白色斑纹的可爱小鱼，童年时期常被星探发现进入偶像培训班，不过往往因天赋问题只能成为后台工作人员。把全部希望寄托于偶像，当偶像做出了不符合自己想法的事，他就会大呼上当而一转变成黑粉。",
	ResultText = "地心城出现了王都警卫",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240229,
			Level = 320,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1039] =
{
	Id = 1039,
	Name = "挑战王都队长",
	Area = 130261,
	PreCondition = {
		PreGoal = 
		{
			302034,
		},
	},
	Desc = "从小就接受专业的偶像训练，有着良好的嗓音条件和外表，被无数人称赞是天生的苗子，在这一届星光小道举办之前就已经被内定为优胜者。",
	ResultText = "地心城出现了王都队长",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240230,
			Level = 324,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1040] =
{
	Id = 1040,
	Name = "挑战左旗护卫",
	Area = 130262,
	PreCondition = {
		PreGoal = 
		{
			302035,
		},
	},
	AcceptSpeech = 14104001,
	Desc = "闪亮海星经纪公司干部，原本只是一个普通的员工，因为挖掘了牙牙而在公司内地位飙升，不过最近公司不景气正面临着失业的危机。",
	ResultText = "城堡殿堂出现了左旗护卫",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240231,
			Level = 328,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1041] =
{
	Id = 1041,
	Name = "挑战爱之蔓",
	Area = 130262,
	PreCondition = {
		PreGoal = 
		{
			302036,
		},
	},
	Desc = "闪亮海星经纪公司的参谋，负责旗下艺人的公关问题，擅长使用各种社交媒体，用转移矛盾的方式引导舆论。",
	ResultText = "城堡殿堂出现了右旗护卫",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240232,
			Level = 252,
		},
		{
			Value = 240233,
			Level = 252,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1042] =
{
	Id = 1042,
	Name = "挑战守门机器人",
	Area = 130263,
	PreCondition = {
		PreGoal = 
		{
			302037,
		},
	},
	AcceptSpeech = 14104201,
	Desc = "海洋星罪犯，为了逃避抓捕而藏在了海底，会对来抓他的人喷墨。自认为逃跑技术天下无敌，其实是因为他的涉案金额没达到立案标准。",
	ResultText = "巴别之路出现了守门机器人",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240234,
			Level = 360,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1043] =
{
	Id = 1043,
	Name = "挑战武装鼹鼠",
	Area = 130263,
	PreCondition = {
		PreGoal = 
		{
			302038,
		},
	},
	AcceptSpeech = 14104301,
	Desc = "脸颊上长有白色斑纹的可爱小鱼，童年时期常被星探发现进入偶像培训班，不过往往因天赋问题只能成为后台工作人员。把全部希望寄托于偶像，当偶像做出了不符合自己想法的事，他就会大呼上当而一转变成黑粉。",
	ResultText = "巴别之路出现了武装鼹鼠",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240235,
			Level = 364,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1044] =
{
	Id = 1044,
	Name = "挑战毒蝎",
	Area = 130263,
	PreCondition = {
		PreGoal = 
		{
			302039,
		},
	},
	AcceptSpeech = 14104401,
	Desc = "隐藏在星球底部的传说中的生物，攻击性极强，会对着靠近他的人伸出触手，但其实只是因为他看不见。",
	ResultText = "巴别之路出现了毒蝎",
	Dialog = "打败一个我，还有千万个我！",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240236,
			Level = 364,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
ChallengeConfig[ChallengeID.Id1045] =
{
	Id = 1045,
	Name = "挑战爱之蔓",
	Area = 130263,
	PreCondition = {
		PreGoal = 
		{
			302040,
		},
	},
	AcceptSpeech = 14104501,
	Desc = "贝壳街tea time成员，当聚光灯打下来的时候就把自己的珍珠亮出来，总是闪瞎台下观众的眼睛。",
	ResultText = "爱之蔓加入了队伍",
	Dialog = "0",
	NumCap = 5,
	LevelBundle = "packed_eventbg",
	LevelAtlas = "EventBG",
	LevelBG = "MUSBG03",
	StartScene = "SEA_StartScene",
	Enemy = {
		{
			Value = 240237,
			Level = 368,
		},
	},
	Reward = {
		{
			Value = 220504,
			Num = 1,
		},
	},
	FullStarReward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
