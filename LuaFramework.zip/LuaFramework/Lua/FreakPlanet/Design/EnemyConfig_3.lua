
EnemyConfig[EnemyID.Id4001] =
{
	Id = 4001,
	Name = "最弱测试",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "体内带有大量绿色素的小精灵，喜欢捡冒险者丢掉的东西，被它碰到的东西就会被染成绿色，不要丢下帽子。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_green",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_green",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 75, Gain = 15},
		{Value = 200002, Base = 18, Gain = 4},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4002] =
{
	Id = 4002,
	Name = "最弱测试",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "体内带有大量绿色素的小精灵，喜欢捡冒险者丢掉的东西，被它碰到的东西就会被染成绿色，不要丢下帽子。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_green",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_green",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 75, Gain = 15},
		{Value = 200002, Base = 18, Gain = 4},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4003] =
{
	Id = 4003,
	Name = "最弱测试",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "体内带有大量绿色素的小精灵，喜欢捡冒险者丢掉的东西，被它碰到的东西就会被染成绿色，不要丢下帽子。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_green",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_green",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 75, Gain = 15},
		{Value = 200002, Base = 18, Gain = 4},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4004] =
{
	Id = 4004,
	Name = "最强挑战",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "火山的可怕魔物，喷吐的烈焰可以融化矿石，是魔王城堡当之无愧的强者。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_GiantFire",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_GiantFire",
	PrefabScale = 50,
	HPBarHeight = 114,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 188, Gain = 38},
		{Value = 200002, Base = 18, Gain = 4},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4005] =
{
	Id = 4005,
	Name = "公主的爱人",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "魔王公司董事长，有着非凡的气势，任何魔族都不敢接受他的直视。目前已将副本交给小魔王处理，自己则专心设计彩蛋。当勇者发现彩蛋时，他就会出现。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_11_damowang",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_11_damowang",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1130, Gain = 226},
		{Value = 200002, Base = 20, Gain = 4},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4006] =
{
	Id = 4006,
	Name = "会闪避的苹狗",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "营养丰富的苹狗，身体是健康的红色。最大的梦想是进化成传说中的物种——芒狗。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_Apple",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_Apple",
	PrefabScale = 50,
	HPBarHeight = 97,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 165, Gain = 33},
		{Value = 200002, Base = 4, Gain = 1},
		{Value = 200003, Base = 0, Gain = 0},
		{Value = 200004, Base = 0, Gain = 0},
	},
	Drop = {
	},
	SkillList = {
		Desc = "80%概率闪避攻击",
		Skill = {
			{
				Id = 105026,
				Value = 80,
			},
		},
	},
	Tags = {
		564557,
	},
}
EnemyConfig[EnemyID.Id4007] =
{
	Id = 4007,
	Name = "鹿角魔",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：把鼻涕抹在公共场所，弄得粘乎乎的。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_xiaoshuyang",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_xiaoshuyang",
	PrefabScale = 50,
	HPBarHeight = 85,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1130, Gain = 226},
		{Value = 200002, Base = 20, Gain = 4},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4008] =
{
	Id = 4008,
	Name = "骷髅杰克",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "魔王有限公司临时雇员，即使被拆散了也能很快拼回去，是地城副本中很重要的成员。\n不过偶尔会发生重新拼装时，多出一些骨头的问题。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_30_kulou",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_30_kulou",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 414, Gain = 83},
		{Value = 200002, Base = 18, Gain = 4},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4009] =
{
	Id = 4009,
	Name = "骷髅约翰",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "魔王有限公司临时雇员，即使被拆散了也能很快拼回去，是地城副本中很重要的成员。\n不过偶尔会发生重新拼装时，多出一些骨头的问题。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_30_kulou",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_30_kulou",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 414, Gain = 83},
		{Value = 200002, Base = 18, Gain = 4},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4010] =
{
	Id = 4010,
	Name = "骷髅汤姆",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "魔王有限公司临时雇员，即使被拆散了也能很快拼回去，是地城副本中很重要的成员。\n不过偶尔会发生重新拼装时，多出一些骨头的问题。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_30_kulou",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_30_kulou",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 414, Gain = 83},
		{Value = 200002, Base = 18, Gain = 4},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4011] =
{
	Id = 4011,
	Name = "带路NPC",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "指路NPC的工作成天风吹日晒，获得勇者赠送的狼头帽子，冬暖夏凉",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_10_buluolaoda_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_10_buluolaoda",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1217, Gain = 244},
		{Value = 200002, Base = 21, Gain = 5},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4012] =
{
	Id = 4012,
	Name = "抗议的树精",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "吸取树木精华为生的精灵，说不清是植物还是精灵，负责净化沼泽地区的空气质量。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_xiaoshuyang",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_xiaoshuyang",
	PrefabScale = 60,
	HPBarHeight = 85,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1130, Gain = 226},
		{Value = 200002, Base = 20, Gain = 4},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4013] =
{
	Id = 4013,
	Name = "无礼的村长",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "守候在村子里德高望重的角色，同时担负着向冒险者发布主线任务及发放奖励的重要责任。不过会私下吞掉任务奖励的回扣，并瞒着妻子偷偷藏下私房钱。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_20_laoyeye",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_20_laoyeye",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1464, Gain = 293},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4014] =
{
	Id = 4014,
	Name = "吸血鬼之血",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "生物身体中必不可少的关键液体，不过有些生物个体看到它时会不自觉地晕倒。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Blood",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Blood",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1464, Gain = 293},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4015] =
{
	Id = 4015,
	Name = "牙疼的石巨人",
	Rarity = 5,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "平原的守护者，对其他生物很不友好。其实是个慢性子，说话结巴，最大的梦想是有人能听完它的自我介绍。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Stoneman",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Stoneman",
	PrefabScale = 50,
	HPBarHeight = 114,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1278, Gain = 256},
		{Value = 200002, Base = 24, Gain = 5},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4016] =
{
	Id = 4016,
	Name = "寻宝冒险者",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "自称为冒险星的主角，身负打败魔王以及为世界带来和平的重任。虽然帮助村民不求回报，但缺物资时，会以正义之名进入NPC家中取走合用的财物。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_05_jianshi",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_05_jianshi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 747, Gain = 150},
		{Value = 200002, Base = 13, Gain = 3},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4017] =
{
	Id = 4017,
	Name = "复仇的小队长",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "为了尽快带领怪物们开展湿地副本的业务，小队长带头换上的两栖套装，虽然粘乎乎的很不舒服，但是可以很好地防止在泥地滑倒，而且湿湿滑滑的材料似乎有助于回血。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_13_dashouxiaodi_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_13_dashouxiaodi",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 747, Gain = 150},
		{Value = 200002, Base = 13, Gain = 3},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4018] =
{
	Id = 4018,
	Name = "脏脏的小土包",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "最恨人说烂泥扶不上墙，一旦听到就会发飙。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_ruannidui",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_ruannidui",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 804, Gain = 161},
		{Value = 200002, Base = 14, Gain = 3},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4019] =
{
	Id = 4019,
	Name = "PK的勇士",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "据说北境的末日火山每过三十年都会重新活动，火之恶龙也将浴火重生。龙骑士凭借着出色的斩龙技术，消灭了那一年重生的火龙之王。也因此，北境长老将这套使用龙火淬炼而成的驯龙战甲赠予了她，并封她为“驯龙高手”。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_25_longqishi_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_25_longqishi",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1130, Gain = 226},
		{Value = 200002, Base = 20, Gain = 4},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4020] =
{
	Id = 4020,
	Name = "愤怒的游客",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "来自神秘星球的部落酋长，部族世代受到不幸之神的祝福，虽然不会遭遇什么变故，但是做什么事情都比一般人不顺很多。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPDraw_04_UnlockChief",
	PrefabBundle = "character_sp",
	PrefabName = "SPDraw_04_UnlockChief",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1217, Gain = 244},
		{Value = 200002, Base = 21, Gain = 5},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4021] =
{
	Id = 4021,
	Name = "湿地守卫者",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：喜欢在公园长椅上涂胶水捉弄别人。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_niannianguai",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_niannianguai",
	PrefabScale = 50,
	HPBarHeight = 81,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1217, Gain = 244},
		{Value = 200002, Base = 21, Gain = 5},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4022] =
{
	Id = 4022,
	Name = "异形",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "在实验室被制造出来的神秘生物，融入了多种生物的DNA，无论是速度或是杀伤力都是一流水准。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_28_bug_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_28_bug",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1130, Gain = 226},
		{Value = 200002, Base = 20, Gain = 4},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4023] =
{
	Id = 4023,
	Name = "雷普利",
	Rarity = 4,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "经历过严重飞船事故的传奇英雄，雷普利在面对可怕的事物时展现出了非凡的勇气和毅力。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_29_QA_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_29_QA",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1036, Gain = 208},
		{Value = 200002, Base = 18, Gain = 4},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4024] =
{
	Id = 4024,
	Name = "黑警长",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "豆豆警官击败黑警长后在组织中建立的新身份。此后，他将以黑警长的身份继续深入调查组织内部的罪恶秘密，希望有一天能够将组织彻底捣毁。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_05_jingcha_cos10",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_05_jingcha",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 145,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4025] =
{
	Id = 4025,
	Name = "犬寻守护灵",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "曾经在溪谷与白狼争夺地盘的凶悍族群，被白狼凶过以后，集体撤离了溪谷。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_blackWolf",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_BlackWolf",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1464, Gain = 293},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4026] =
{
	Id = 4026,
	Name = "门派的敌人",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "安装在大街上提供行人照明的设施，性格火爆，一点就炸。\n然后就没有然后了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_StreetLamp",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_StreetLamp",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4027] =
{
	Id = 4027,
	Name = "来洗澡的小弟",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "总是跟着两个哥哥去参观博物馆的小浣熊，但每次都会因为没买票被拦在门外。他对此很气愤，因为自己并没有钱买票。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_15_xiaodi",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_15_xiaodi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 653, Gain = 131},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4028] =
{
	Id = 4028,
	Name = "来洗澡的二哥",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "喜欢跟着哥哥去参观博物馆的小浣熊，但每次都会因为没买票被拦在门外。他对此很气愤，因为自己并没有一米二，根本不需要买票",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_14_erge",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_14_erge",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 653, Gain = 131},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4029] =
{
	Id = 4029,
	Name = "来洗澡的大哥",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "特别喜欢参观博物馆的小浣熊，但每次都会因为没买票被拦在门外。他对此很气愤，因为自己有学生证，根本不需要买票。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_13_dage",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_13_dage",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 653, Gain = 131},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4030] =
{
	Id = 4030,
	Name = "晕眩症测试员",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "生物身体中必不可少的关键液体，不过有些生物个体看到它时会不自觉地晕倒。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Blood",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Blood",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4031] =
{
	Id = 4031,
	Name = "策划A",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "背负着被告所有希望的悬疑星上班族，根据表面上的证据往往能得出不同结论，帮助被告脱罪，顺带把证人席上的某人定罪。\n“上了证人席，你还想跑？”",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_13_lvshi",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_13_lvshi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 653, Gain = 131},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4032] =
{
	Id = 4032,
	Name = "策划B",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "背负着被告所有希望的悬疑星上班族，根据表面上的证据往往能得出不同结论，帮助被告脱罪，顺带把证人席上的某人定罪。\n“上了证人席，你还想跑？”",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_13_lvshi",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_13_lvshi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 653, Gain = 131},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4033] =
{
	Id = 4033,
	Name = "策划C",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "背负着被告所有希望的悬疑星上班族，根据表面上的证据往往能得出不同结论，帮助被告脱罪，顺带把证人席上的某人定罪。\n“上了证人席，你还想跑？”",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_13_lvshi",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_13_lvshi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 653, Gain = 131},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4034] =
{
	Id = 4034,
	Name = "抗议的怪物",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "魔王公司中层干部，平时会带着低级雇员们在路上堵截低级勇者搞业绩。不过因为掉落物不错，所以也常被高级勇者蹲点刷。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_13_dashouxiaodi",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_13_dashouxiaodi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1609, Gain = 322},
		{Value = 200002, Base = 28, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4035] =
{
	Id = 4035,
	Name = "策划A",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "背负着被告所有希望的悬疑星上班族，根据表面上的证据往往能得出不同结论，帮助被告脱罪，顺带把证人席上的某人定罪。\n“上了证人席，你还想跑？”",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_13_lvshi",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_13_lvshi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 653, Gain = 131},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4036] =
{
	Id = 4036,
	Name = "策划B",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "背负着被告所有希望的悬疑星上班族，根据表面上的证据往往能得出不同结论，帮助被告脱罪，顺带把证人席上的某人定罪。\n“上了证人席，你还想跑？”",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_13_lvshi",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_13_lvshi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 653, Gain = 131},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4037] =
{
	Id = 4037,
	Name = "策划C",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "背负着被告所有希望的悬疑星上班族，根据表面上的证据往往能得出不同结论，帮助被告脱罪，顺带把证人席上的某人定罪。\n“上了证人席，你还想跑？”",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_13_lvshi",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_13_lvshi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 653, Gain = 131},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4038] =
{
	Id = 4038,
	Name = "运动品牌商",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "海洋中的霸主，被猎鲸者无意间捕获后卖给大海贼团。在即将被制成刺身时依然疯狂反抗着，最终其精神折服了所有海盗，于是被改造成了超强战士，能够在陆地行走，同时还能用嘴巴咬人。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Pir_07_SharkBoss",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_07_SharkBoss",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4039] =
{
	Id = 4039,
	Name = "密涅瓦",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "穿上智慧的外衣后，兵马俑说话时变得富有哲理起来。\n“凡世间的一切有其本质规律及凡人希望理解的规律。其本质或并无一定规律，而凡人所理解之规律却需要是可呈轨迹，为其了解过去并预测未来之用的规律。”",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_06_bingmayong_cos10",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_06_bingmayong",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2196, Gain = 440},
		{Value = 200002, Base = 39, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4040] =
{
	Id = 4040,
	Name = "地狱火巨人",
	Rarity = 5,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在公共场所大声说话，把口水喷到别人脸上。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_GiantFire",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_GiantFire",
	PrefabScale = 50,
	HPBarHeight = 114,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2050, Gain = 410},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4041] =
{
	Id = 4041,
	Name = "执着的编剧",
	Rarity = 4,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "名动悬疑星的大作家，笔下创作了绝对经典的侦探形象，为后世侦探小说定下了完美范本。其本人更是后世无数侦探的偶像。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_20_lanyixiaoxuesheng_cos10",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_20_lanyixiaoxuesheng",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2196, Gain = 440},
		{Value = 200002, Base = 39, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4042] =
{
	Id = 4042,
	Name = "哥火拉王",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "火山的可怕魔物，喷吐的烈焰可以融化矿石，是魔王城堡当之无愧的强者。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_GiantFire",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_GiantFire",
	PrefabScale = 50,
	HPBarHeight = 114,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1840, Gain = 368},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4043] =
{
	Id = 4043,
	Name = "未认证商家",
	Rarity = 5,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星人气NPC，提供装备买卖、修理、强化等服务，是勇者不可或缺的好帮手。\n“哎呀，手一滑装备爆炸了，阁下运气不太好噢~”",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_31_tiejiang",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_31_tiejiang",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1606, Gain = 322},
		{Value = 200002, Base = 30, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4044] =
{
	Id = 4044,
	Name = "最好的玩伴",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "勇敢坚毅的女骑士，打破了只有男性可以击败龙族王子的传说，成功制服了可怕又强大的黑龙王子。不过大家至今为止也没有看到黑龙王子被击杀的证明。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_25_longqishi",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_25_longqishi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1840, Gain = 368},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4045] =
{
	Id = 4045,
	Name = "算命商人",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "每当旅行商人没钱进货的时候，他就会拿出这套装备，从事那些无本买卖，比如：看相鉴运，风水命理，趋吉避凶，祈福除祸，还能算五行，算八卦，算中宫，测仕途，测财行，测爱情，定紫微，定北斗等等等等。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_14_lvxingshangren_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_14_lvxingshangren",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 150,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1840, Gain = 368},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4046] =
{
	Id = 4046,
	Name = "皇家卫兵",
	Rarity = 4,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "每个皇家卫兵都是万中选一的城镇卫兵，不要在他的视线范围内PK。因为你看他永远是？？等级，打赢也没有掉落，而且刷新速度快得不讲道理。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_17_chengzhenweibing_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_17_chengzhenweibing",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 155,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1840, Gain = 368},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4047] =
{
	Id = 4047,
	Name = "皇家卫兵",
	Rarity = 4,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "每个皇家卫兵都是万中选一的城镇卫兵，不要在他的视线范围内PK。因为你看他永远是？？等级，打赢也没有掉落，而且刷新速度快得不讲道理。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_17_chengzhenweibing_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_17_chengzhenweibing",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 155,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1840, Gain = 368},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4048] =
{
	Id = 4048,
	Name = "银发假面",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "由博士开发的高速型怪盗服装，朴实无华的布料下隐藏了大量喷口。引擎全开时前进速度接近光速。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_16_yelifushentou_cos20",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_16_yelifushentou",
	SkinName = "3",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1606, Gain = 322},
		{Value = 200002, Base = 30, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4049] =
{
	Id = 4049,
	Name = "茶克林姆",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "抹茶味的冰淇淋，加入了牛奶和抹茶粉制作而成，即使化开来味道也依然很好。性格温文尔雅，最喜欢的是原谅别人。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_GreenTeaIceCream",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_GreenTeaIceCream",
	PrefabScale = 50,
	HPBarHeight = 89,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1609, Gain = 322},
		{Value = 200002, Base = 28, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4050] =
{
	Id = 4050,
	Name = "柠檬精华",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "柠檬味糖豆，最自豪的事是公主昏倒时，从头上挤出了柠檬汁，酸醒了公主。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_14_xiaohuang",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_14_xiaohuang",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 106,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1609, Gain = 322},
		{Value = 200002, Base = 28, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4051] =
{
	Id = 4051,
	Name = "女王的试炼",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "宇宙影院女王，拥有99.99%的院线，非常具有商业头脑。旗下爆米花有数十种口味，能适应各种星人对爆米花的口味喜好。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_22_baomihua",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_22_baomihua",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 128,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4052] =
{
	Id = 4052,
	Name = "樱花仙子",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "仙子礼服店推出的季节限定套装，裙摆处点缀了大量的樱花花瓣。清风吹过时，还会有伴着一阵清幽的花香噢~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_27_buding_cos10",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_27_buding",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1609, Gain = 322},
		{Value = 200002, Base = 28, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4053] =
{
	Id = 4053,
	Name = "国王的试炼",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "热衷健身的美食城国王，每天健身8小时，之后去皇家油锅泡澡8小时，然后睡8小时。肌肉含量120%，用力的话可以撑爆背心。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_30_shutiao",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_30_shutiao",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 106,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1609, Gain = 322},
		{Value = 200002, Base = 28, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4054] =
{
	Id = 4054,
	Name = "鸡尾酒王子",
	Rarity = 2,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "这变幻莫测的魔力颜色，究竟是本来的颜色，还是醉了之后心中的幻想呢？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_09_pijiu_cos10",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_09_pijiu",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1609, Gain = 322},
		{Value = 200002, Base = 28, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4055] =
{
	Id = 4055,
	Name = "草莓果冻",
	Rarity = 1,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "草莓味的果冻装，一口一个小草莓",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_12_xiaohong_cos10",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_12_xiaohong",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1343, Gain = 269},
		{Value = 200002, Base = 15, Gain = 3},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4056] =
{
	Id = 4056,
	Name = "桔子果冻",
	Rarity = 1,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "橘子味的果冻装，一口吸不够",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_13_xiaocheng_cos10",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_13_xiaocheng",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1343, Gain = 269},
		{Value = 200002, Base = 15, Gain = 3},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4057] =
{
	Id = 4057,
	Name = "柠檬果冻",
	Rarity = 1,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "柠檬味的果冻装，一口下去有点酸",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_14_xiaohuang_cos10",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_14_xiaohuang",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1343, Gain = 269},
		{Value = 200002, Base = 15, Gain = 3},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4058] =
{
	Id = 4058,
	Name = "芥末果冻",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "芥末味的果冻装，一口下去有点冲",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_15_xiaolv_cos10",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_15_xiaolv",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1343, Gain = 269},
		{Value = 200002, Base = 15, Gain = 3},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4059] =
{
	Id = 4059,
	Name = "牛油果果冻",
	Rarity = 1,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "牛油果味的果冻装，一口怕腻先舔舔",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_16_xiaolan_cos10",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_16_xiaolan",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1343, Gain = 269},
		{Value = 200002, Base = 15, Gain = 3},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4060] =
{
	Id = 4060,
	Name = "薄荷果冻",
	Rarity = 1,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "薄荷味的果冻装，一口吸到最深处",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_17_xiaoqing_cos10",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_17_xiaoqing",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1343, Gain = 269},
		{Value = 200002, Base = 15, Gain = 3},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4061] =
{
	Id = 4061,
	Name = "葡萄果冻",
	Rarity = 1,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "葡萄味的果冻装，一口一个小甜蜜",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_18_xiaozi_cos10",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_18_xiaozi",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1343, Gain = 269},
		{Value = 200002, Base = 15, Gain = 3},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4062] =
{
	Id = 4062,
	Name = "糖果代表",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "用可食薄膜包裹的奶糖，有非常浓郁的奶香，不过含糖量非常高。自称含奶量高达百分之八十，其实是骗人的。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_Toffee",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_Toffee",
	PrefabScale = 50,
	HPBarHeight = 54,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1217, Gain = 244},
		{Value = 200002, Base = 21, Gain = 5},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4063] =
{
	Id = 4063,
	Name = "香橙精华",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "橙子味糖豆，最自豪的事是被公主抱起来时，夸奖说味道闻起来很清爽。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_13_xiaocheng",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_13_xiaocheng",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 106,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1217, Gain = 244},
		{Value = 200002, Base = 21, Gain = 5},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4064] =
{
	Id = 4064,
	Name = "黄牛商人",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星人气NPC，拥有没人见过的非凡实力。卖出去1000块的道具，下一秒就是100块的回收价，却没有谁敢和他们吵架。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_14_lvxingshangren",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_14_lvxingshangren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1217, Gain = 244},
		{Value = 200002, Base = 21, Gain = 5},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4065] =
{
	Id = 4065,
	Name = "黄牛商人",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星人气NPC，拥有没人见过的非凡实力。卖出去1000块的道具，下一秒就是100块的回收价，却没有谁敢和他们吵架。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_14_lvxingshangren",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_14_lvxingshangren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1217, Gain = 244},
		{Value = 200002, Base = 21, Gain = 5},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4066] =
{
	Id = 4066,
	Name = "黄牛商人",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星人气NPC，拥有没人见过的非凡实力。卖出去1000块的道具，下一秒就是100块的回收价，却没有谁敢和他们吵架。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_14_lvxingshangren",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_14_lvxingshangren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1217, Gain = 244},
		{Value = 200002, Base = 21, Gain = 5},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4067] =
{
	Id = 4067,
	Name = "心中的声音",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "虾条小姐尝遍美食之后，体重慢慢的发生了变化，为了穿上以前的衣服，只能悄悄改变一下体型。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_20_xiatiao_cos10",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_20_xiatiao",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1217, Gain = 244},
		{Value = 200002, Base = 21, Gain = 5},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4068] =
{
	Id = 4068,
	Name = "抢衣服的姐姐",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "薯片夫人的大女儿，渴望成为王子的新娘。身边虽然有不少追求者，不过对方不是王子，她都一律无视。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_20_xiatiao",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_20_xiatiao",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 106,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1217, Gain = 244},
		{Value = 200002, Base = 21, Gain = 5},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4069] =
{
	Id = 4069,
	Name = "时尚帽的主人",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "采用了最高级的鱼背肉部位作为食材的寿司精灵，日常散步时经常让路人产生吃它的冲动。\n龟龟，这不就是米饭吗？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_SalmonSushi",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_SalmonSushi",
	PrefabScale = 50,
	HPBarHeight = 75,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4070] =
{
	Id = 4070,
	Name = "《了解黄瓜》",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "记录着大量蔬菜资料的笔记本，不知道打算用来做什么用。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_RedNotebook",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_RedNotebook",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4071] =
{
	Id = 4071,
	Name = "薄荷精华",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "薄荷味糖豆，最自豪的事是公主感冒时，闻了薄荷的味道后很顺利地康复了。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_17_xiaoqing",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_17_xiaoqing",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 106,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4072] =
{
	Id = 4072,
	Name = "完美烘焙火焰",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "数据证明，百分之九十九的冒险家无法分清不同的小火球。\n它从岩浆里跳了起来，它掉了下去。\n它的兄弟从岩浆里跳了起来。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Fireball",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Fireball",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4073] =
{
	Id = 4073,
	Name = "烂苹果",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：用烂苹果做果汁卖给口渴的路人。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_Apple",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_Apple",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4074] =
{
	Id = 4074,
	Name = "和服精灵",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "使用顶级匠人烹制的超美味蛋料理作为食材的寿司精灵，日常散步时经常让路人产生吃它的冲动。\n龟龟，这不就是鸡蛋吗？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_EggSushi",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_EggSushi",
	PrefabScale = 50,
	HPBarHeight = 75,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 653, Gain = 131},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4075] =
{
	Id = 4075,
	Name = "和服精灵",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "采用了最高级的鱼背肉部位作为食材的寿司精灵，日常散步时经常让路人产生吃它的冲动。\n龟龟，这不就是米饭吗？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_SalmonSushi",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_SalmonSushi",
	PrefabScale = 50,
	HPBarHeight = 75,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 653, Gain = 131},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4076] =
{
	Id = 4076,
	Name = "和服精灵",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "采用了鲜甜肥美的深海大虾作为食材的寿司，日常散步时经常让路人产生吃它的冲动。\n龟龟，这哪大了？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_ShrimpSushi",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_ShrimpSushi",
	PrefabScale = 50,
	HPBarHeight = 75,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 653, Gain = 131},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4077] =
{
	Id = 4077,
	Name = "窥探花丛",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：在路边假装花丛偷看路人裙底。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_huacong",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_huacong",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4078] =
{
	Id = 4078,
	Name = "旅游行李箱",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "旅店运送行李的工具，这辆车本身并不是行李。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Luggage",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Luggage",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4079] =
{
	Id = 4079,
	Name = "黑暗鸡料理师",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "来自魔法料理世家的继承人，打算用家传的黑魔法食谱制作出新口味的鸡翅。目前已掌握近千种鸡翅烹调方法。\n客人，鸡翅刺身要试试吗？特惠噢~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_28_jichi",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_28_jichi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 106,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4080] =
{
	Id = 4080,
	Name = "辣条酋长",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "来自遥远星球的神秘服装，对于穿戴者锻炼肌肉极有裨益，薯条国王穿上时，还展现出了非凡的野性气息。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_30_shutiao_cos10",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_30_shutiao",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4081] =
{
	Id = 4081,
	Name = "旋风薯条国王",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "由特制模具制成的高档健身服装，能够使穿戴者的头发自然卷曲起来，给人如同风暴降临的感觉。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_30_shutiao_cos30",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_30_shutiao",
	SkinName = "4",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4082] =
{
	Id = 4082,
	Name = "巧克力棒国王",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "使用巧克力饼干制作的健身服，能够使穿戴者充满活力，薯条国王穿上时，让人觉得特别的和蔼可亲。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_30_shutiao_cos20",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_30_shutiao",
	SkinName = "3",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4083] =
{
	Id = 4083,
	Name = "辣椒酱侍卫",
	Rarity = 4,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "薯条国王亲赐的卫士服，女神级别的套装。\n远远就能感受到酱香与干辣混合的气味，让人忍不住……想要再来三份饺子。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_31_fanqiejiang_cos10",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_31_fanqiejiang",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2196, Gain = 440},
		{Value = 200002, Base = 39, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4084] =
{
	Id = 4084,
	Name = "巧克力酱侍卫",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "薯条国王亲赐的卫士服，丝滑又香浓的套装。\n醇厚的可可豆香味，让人忍不住……就想要再来三份小饼干条。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_31_fanqiejiang_cos30",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_31_fanqiejiang",
	SkinName = "4",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2050, Gain = 410},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4085] =
{
	Id = 4085,
	Name = "沙拉酱侍卫",
	Rarity = 4,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "薯条国王亲赐的卫士服，健康而又适合调味的高级酱料。\n远远就能感受到酸甜的气息与浓郁的醇香，让人忍不住……就想要再来三份生菜。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_31_fanqiejiang_cos20",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_31_fanqiejiang",
	SkinName = "3",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2196, Gain = 440},
		{Value = 200002, Base = 39, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4086] =
{
	Id = 4086,
	Name = "草原狼",
	Rarity = 4,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：疑似帮派分子。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_Wolf",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_Wolf",
	PrefabScale = 50,
	HPBarHeight = 89,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1840, Gain = 368},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4087] =
{
	Id = 4087,
	Name = "金轮画王",
	Rarity = 5,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "充满了神性气息的装束，当创造之神穿着这一身来到大家面前时，人们耳边仿佛响起了圣歌。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_23_chuangzaozhishen_cos10",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_23_chuangzaozhishen",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 149,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1606, Gain = 322},
		{Value = 200002, Base = 30, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4088] =
{
	Id = 4088,
	Name = "变质甜甜圈",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：使用未经许可的特浓糖浆制作甜甜圈，使小孩子蛀牙。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_Doughnut",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_Doughnut",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1840, Gain = 368},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4089] =
{
	Id = 4089,
	Name = "食用色素",
	Rarity = 4,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "常用的书写墨水，不过被悬疑星黑帮垄断生产，因此成为了非常昂贵的墨水，只有非常富有的贵族才能随意使用。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_ColourInk",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_ColourInk",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1840, Gain = 368},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4090] =
{
	Id = 4090,
	Name = "完美烘焙火焰",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "以矿石为食的精灵，体内有大量燃烧结晶。吃矿石的时候喜欢放凉再吃，它怕烫。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Salamander",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Salamander",
	PrefabScale = 50,
	HPBarHeight = 81,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1840, Gain = 368},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4091] =
{
	Id = 4091,
	Name = "松露小土包",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "最恨人说烂泥扶不上墙，一旦听到就会发飙。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_ruannidui",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_ruannidui",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1606, Gain = 322},
		{Value = 200002, Base = 30, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4092] =
{
	Id = 4092,
	Name = "银月的怪盗",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "由博士开发的高速型怪盗服装，朴实无华的布料下隐藏了大量喷口。引擎全开时前进速度接近光速。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_16_yelifushentou_cos20",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_16_yelifushentou",
	SkinName = "3",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1464, Gain = 293},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4093] =
{
	Id = 4093,
	Name = "侦探之灵",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "可能是这个世界上智商最高的人，对推理没有什么兴趣。时间都花在了保护爱闯祸的弟弟身上。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_19_maikaofu",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_19_maikaofu",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4094] =
{
	Id = 4094,
	Name = "狂暴火元素",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "火山的可怕魔物，喷吐的烈焰可以融化矿石，是魔王城堡当之无愧的强者。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_GiantFire",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_GiantFire",
	PrefabScale = 50,
	HPBarHeight = 114,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 551, Gain = 111},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4095] =
{
	Id = 4095,
	Name = "狂暴自然灵",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "吸取树木精华为生的精灵，说不清是植物还是精灵，负责净化沼泽地区的空气质量。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_xiaoshuyang",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_xiaoshuyang",
	PrefabScale = 60,
	HPBarHeight = 85,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 551, Gain = 111},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4096] =
{
	Id = 4096,
	Name = "狂暴大地灵",
	Rarity = 4,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "平原的守护者，对其他生物很不友好。其实是个慢性子，说话结巴，最大的梦想是有人能听完它的自我介绍。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Stoneman",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Stoneman",
	PrefabScale = 50,
	HPBarHeight = 114,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 551, Gain = 111},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4097] =
{
	Id = 4097,
	Name = "想告状的佛头",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "换上佛头后，寡言的默艾经常说我们听不懂的东西……\n“舍利子，色不异空，空不异色，色即是空，空即是色……舍利子，是诸法空相，不生不灭，不垢不净……”",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_07_fuhuoshixiang_cos10",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_07_fuhuoshixiang",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 489, Gain = 98},
		{Value = 200002, Base = 13, Gain = 3},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4098] =
{
	Id = 4098,
	Name = "想告状的女神",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "穿上智慧的外衣后，兵马俑说话时变得富有哲理起来。\n“凡世间的一切有其本质规律及凡人希望理解的规律。其本质或并无一定规律，而凡人所理解之规律却需要是可呈轨迹，为其了解过去并预测未来之用的规律。”",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_06_bingmayong_cos10",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_06_bingmayong",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 489, Gain = 98},
		{Value = 200002, Base = 13, Gain = 3},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4099] =
{
	Id = 4099,
	Name = "想告状的石柱",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "扮成玛雅石柱人之后，石柱人时时刻刻都在做着了不起的记录。\n“啊，今天是20年以来β星群构成形状最接近正三角形的一天，这必须记录一下。”",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_10_shizhuren_cos10",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_10_shizhuren",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 489, Gain = 98},
		{Value = 200002, Base = 13, Gain = 3},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4100] =
{
	Id = 4100,
	Name = "想告状的幻兽",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "插上独角后，喜欢自由和奔驰的半人马石像每天都要耐着性子和小朋友们拍照，就算被小朋友吊住脖子，也要微笑着看着镜头……",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_11_banrenma_cos10",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_11_banrenma",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 489, Gain = 98},
		{Value = 200002, Base = 13, Gain = 3},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4101] =
{
	Id = 4101,
	Name = "固执的亚当",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "根据神话故事绘制的肖像，男孩举起的手指向了天空……\n因为上课时挡住了后面同学看黑板而被骂了好多次。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_22_yadang",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_22_yadang",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1130, Gain = 226},
		{Value = 200002, Base = 20, Gain = 4},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4102] =
{
	Id = 4102,
	Name = "带光环的游客",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "自称为冒险星的主角，身负打败魔王以及为世界带来和平的重任。虽然帮助村民不求回报，但缺物资时，会以正义之名进入NPC家中取走合用的财物。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_05_jianshi",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_05_jianshi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1130, Gain = 226},
		{Value = 200002, Base = 20, Gain = 4},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4103] =
{
	Id = 4103,
	Name = "惹人烦的保安",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "博物馆星新任保安，人生处于低谷时来到博物馆散心，无意间拿起保安招聘启事后便被馆长强行留了下来。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_27_baoan",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_27_baoan",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1217, Gain = 244},
		{Value = 200002, Base = 21, Gain = 5},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4104] =
{
	Id = 4104,
	Name = "惹人烦的保安",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "博物馆星新任保安，人生处于低谷时来到博物馆散心，无意间拿起保安招聘启事后便被馆长强行留了下来。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_27_baoan",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_27_baoan",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1217, Gain = 244},
		{Value = 200002, Base = 21, Gain = 5},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4105] =
{
	Id = 4105,
	Name = "病态赌徒",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "来自神秘星球的部落酋长，部族世代受到不幸之神的祝福，虽然不会遭遇什么变故，但是做什么事情都比一般人不顺很多。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPDraw_04_UnlockChief",
	PrefabBundle = "character_sp",
	PrefabName = "SPDraw_04_UnlockChief",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1036, Gain = 208},
		{Value = 200002, Base = 18, Gain = 4},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4106] =
{
	Id = 4106,
	Name = "病态赌徒",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "来自神秘星球的部落酋长，部族世代受到不幸之神的祝福，虽然不会遭遇什么变故，但是做什么事情都比一般人不顺很多。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPDraw_04_UnlockChief",
	PrefabBundle = "character_sp",
	PrefabName = "SPDraw_04_UnlockChief",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1036, Gain = 208},
		{Value = 200002, Base = 18, Gain = 4},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4107] =
{
	Id = 4107,
	Name = "病态赌徒",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "来自神秘星球的部落酋长，部族世代受到不幸之神的祝福，虽然不会遭遇什么变故，但是做什么事情都比一般人不顺很多。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPDraw_04_UnlockChief",
	PrefabBundle = "character_sp",
	PrefabName = "SPDraw_04_UnlockChief",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1036, Gain = 208},
		{Value = 200002, Base = 18, Gain = 4},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4108] =
{
	Id = 4108,
	Name = "大粽子？",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "木乃伊复活失败变化而来的衍生形态，为了封印其凶性。大家手忙脚乱地帮他穿上了古代王朝大官的衣服，额前也贴上了封印力量的黄符。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_05_munaiyi_cos10",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_05_munaiyi",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1036, Gain = 208},
		{Value = 200002, Base = 18, Gain = 4},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4109] =
{
	Id = 4109,
	Name = "翡翠鉴定装置",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "侦探们的好朋友，有时候没什么用，但是拿出来会让人觉得很有侦探的派头。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Magnifier",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Magnifier",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4110] =
{
	Id = 4110,
	Name = "银月的怪盗",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "由博士开发的高速型怪盗服装，朴实无华的布料下隐藏了大量喷口。引擎全开时前进速度接近光速。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_16_yelifushentou_cos20",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_16_yelifushentou",
	SkinName = "3",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4111] =
{
	Id = 4111,
	Name = "仓库的行李车",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "旅店运送行李的工具，这辆车本身并不是行李。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Luggage",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Luggage",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4112] =
{
	Id = 4112,
	Name = "仓库的行李车",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "旅店运送行李的工具，这辆车本身并不是行李。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Luggage",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Luggage",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4113] =
{
	Id = 4113,
	Name = "仓库的行李车",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "旅店运送行李的工具，这辆车本身并不是行李。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Luggage",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Luggage",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4114] =
{
	Id = 4114,
	Name = "仓库的行李车",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "旅店运送行李的工具，这辆车本身并不是行李。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Luggage",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Luggage",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4115] =
{
	Id = 4115,
	Name = "灵感！",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "独耳画像在人生的失意时刻也不曾放弃过自己的坚持，他始终在与生命做斗争，在与迫使他放弃自己理想的一切做斗争。最终，他的作品赢得了世人们的认可。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_08_fangao_cos10",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_08_fangao",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1878, Gain = 376},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4116] =
{
	Id = 4116,
	Name = "灵感！",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "这是独耳先生身在时尚之城时做成的自画像。明朗自由的艺术氛围使独耳先生的艺术之树结出了丰硕的成果。他以新发现的独特技法创作了新的杰作。不过点彩之下的忧郁与身心所受的疲累又有多少人知道呢?",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_08_fangao_cos20",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_08_fangao",
	SkinName = "3",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1878, Gain = 376},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4117] =
{
	Id = 4117,
	Name = "艺术殉道者",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "独耳画像在人生的失意时刻也不曾放弃过自己的坚持，他始终在与生命做斗争，在与迫使他放弃自己理想的一切做斗争。最终，他的作品赢得了世人们的认可。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_08_fangao_cos10",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_08_fangao",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1878, Gain = 376},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4118] =
{
	Id = 4118,
	Name = "讨债的花老大",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "活泼好动的小花球，有时候会溜进人类的城镇里探险。不喜欢自己的名字，正在努力减肥，希望能被人叫做小花干。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_xiaohuaqiu",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_xiaohuaqiu",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1878, Gain = 376},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4119] =
{
	Id = 4119,
	Name = "廉价染发水",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "使用花卉和矿石制成的红色液体，通常用来书写警示类的文字，有时会在杀手游戏中被当作鲜血道具使用。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_RedInk",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_RedInk",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1878, Gain = 376},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4120] =
{
	Id = 4120,
	Name = "廉价染发水",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "使用贝壳和藻类制成的蓝色液体，通常用来记录信息类的文字，对海鲜过敏的人请务必谨慎使用。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_BlueInk",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_BlueInk",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1878, Gain = 376},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4121] =
{
	Id = 4121,
	Name = "夜礼服怪盗",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "以怪盗83号之名活跃在博物馆星的大窃贼。每次出现时总是在漆黑的月夜登场，行为如最彬彬有礼的绅士一般优雅，即使是把宝石、名画、瓷器用泡沫纸包起来打包带走的动作也比浣熊盗贼团们潇洒一些。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_16_yelifushentou_cos10",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_16_yelifushentou",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 145,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1878, Gain = 376},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4122] =
{
	Id = 4122,
	Name = "捡装备的保安",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "博物馆星新任保安，人生处于低谷时来到博物馆散心，无意间拿起保安招聘启事后便被馆长强行留了下来。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_27_baoan",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_27_baoan",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1878, Gain = 376},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4123] =
{
	Id = 4123,
	Name = "深海的囚灵",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "小小的骨头兵，在当地的怪物大选上，凭借极微弱的身高优势，当选为了骷髅王。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_30_kulou_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_30_kulou",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1606, Gain = 322},
		{Value = 200002, Base = 30, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4124] =
{
	Id = 4124,
	Name = "战国の大名",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "前任主人是比起战争，更喜爱蹴鞠与歌咏的风雅人物，听说流着将军家的名门血统，以当主的身份指挥家将保护着祖传的土地。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_09_ribenwushi_cos10",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_09_ribenwushi",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2022, Gain = 405},
		{Value = 200002, Base = 35, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4125] =
{
	Id = 4125,
	Name = "战国の青雷",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "前任主人是喜欢异国文化，剑术高超的顶级武士，性格高傲且正直开朗。即使面对多个敌人，也没有丝毫胆怯。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_09_ribenwushi_cos20",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_09_ribenwushi",
	SkinName = "3",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1606, Gain = 322},
		{Value = 200002, Base = 30, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4126] =
{
	Id = 4126,
	Name = "月玉",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "狼群的领袖，与众不同的颜色给人以强烈的压迫感。比较挑食，只接受带肉的骨头。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_WhiteWolf",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_WhiteWolf",
	PrefabScale = 50,
	HPBarHeight = 102,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 57, Gain = 12},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4127] =
{
	Id = 4127,
	Name = "懒散的士兵",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "遥远东方的武士俑，墓葬品。被考古学家发现带到博物馆星。据说老家那里还有很多很多和他一样的雕像。对此说法兵马俑总是表现得很气愤，他说每个人都是独一无二的。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_06_bingmayong",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_06_bingmayong",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 659, Gain = 132},
		{Value = 200002, Base = 39, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4128] =
{
	Id = 4128,
	Name = "懒散的士兵",
	Rarity = 4,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "坐落在与世隔绝的海岛上的石像，独自一人被搬来博物馆星做巡回展览。每天闭馆后都会站在窗前，望着自己家乡的位置。但是因为雾霾，大部分时候他什么都看不到。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_07_fuhuoshixiang",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_07_fuhuoshixiang",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 659, Gain = 132},
		{Value = 200002, Base = 39, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4129] =
{
	Id = 4129,
	Name = "懒散的士兵",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "古代文明城邦的石像，既是建筑也是艺术品。喜欢待在展厅里思考问题，每当这个时候他就成为了思考者，会吸引很多人来参观。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_10_shizhuren",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_10_shizhuren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 659, Gain = 132},
		{Value = 200002, Base = 39, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4130] =
{
	Id = 4130,
	Name = "懒散的士兵",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "西方神话中的半人马石像，来到博物馆星后，迷上了滑轮竞速赛，每周三晚上都会报名。\n最近他又迷上了两人三足。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_11_banrenma",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_11_banrenma",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 659, Gain = 132},
		{Value = 200002, Base = 39, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4131] =
{
	Id = 4131,
	Name = "戴皇冠的游客",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "小小的骨头兵，在当地的怪物大选上，凭借极微弱的身高优势，当选为了骷髅王。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_30_kulou_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_30_kulou",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2050, Gain = 410},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4132] =
{
	Id = 4132,
	Name = "边门守卫",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "经常被无视的保安设备，有人想穿过去时，它就会一直盯着对方。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_Cordon",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_Cordon",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2196, Gain = 440},
		{Value = 200002, Base = 39, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4133] =
{
	Id = 4133,
	Name = "想逃跑的报纸",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "常驻咖啡馆的报纸先生，会把今天的新闻登在身上，让别人阅读。\n有没有人提醒一下，他拿反了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Newspaper",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Newspaper",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 804, Gain = 161},
		{Value = 200002, Base = 14, Gain = 3},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4134] =
{
	Id = 4134,
	Name = "嚣张的前辈",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "名动悬疑星的大作家，笔下创作了绝对经典的侦探形象，为后世侦探小说定下了完美范本。其本人更是后世无数侦探的偶像。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_20_lanyixiaoxuesheng_cos10",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_20_lanyixiaoxuesheng",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4135] =
{
	Id = 4135,
	Name = "胆小的死者",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "往往第一个被排除嫌疑的角色，但是世事无绝对。如果所有出场的嫌疑人都遇害了，那么一定要再重新检查一遍死者。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_12_sizhe",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_12_sizhe",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 129,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4136] =
{
	Id = 4136,
	Name = "胆小的死者",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "往往第一个被排除嫌疑的角色，但是世事无绝对。如果所有出场的嫌疑人都遇害了，那么一定要再重新检查一遍死者。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_12_sizhe",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_12_sizhe",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 129,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4137] =
{
	Id = 4137,
	Name = "超厚台词本",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "记录着大量水果资料的笔记本，不知道打算用来做什么用。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_BrownNoteBook",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_BrownNoteBook",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1609, Gain = 322},
		{Value = 200002, Base = 28, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4138] =
{
	Id = 4138,
	Name = "无证心理医生",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "穿着特制工作服的法医，包揽了悬疑星所有的法医及法证工作，经常出入于凶案现场，负责处理各种现场证物。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_04_fayi",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_04_fayi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 123,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4139] =
{
	Id = 4139,
	Name = "沙滩专用行李车",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "旅店运送行李的工具，这辆车本身并不是行李。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Luggage",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Luggage",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 458, Gain = 92},
		{Value = 200002, Base = 21, Gain = 5},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4140] =
{
	Id = 4140,
	Name = "沙滩专用行李车",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "旅店运送行李的工具，这辆车本身并不是行李。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Luggage",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Luggage",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 458, Gain = 92},
		{Value = 200002, Base = 21, Gain = 5},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4141] =
{
	Id = 4141,
	Name = "沙滩专用行李车",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "旅店运送行李的工具，这辆车本身并不是行李。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Luggage",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Luggage",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 458, Gain = 92},
		{Value = 200002, Base = 21, Gain = 5},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4142] =
{
	Id = 4142,
	Name = "逃稿的作者",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "名动悬疑星的大作家，笔下创作了绝对经典的侦探形象，为后世侦探小说定下了完美范本。其本人更是后世无数侦探的偶像。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_20_lanyixiaoxuesheng_cos10",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_20_lanyixiaoxuesheng",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1130, Gain = 226},
		{Value = 200002, Base = 20, Gain = 4},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4143] =
{
	Id = 4143,
	Name = "《翻译速成》",
	Rarity = 2,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "记录着大量水果资料的笔记本，不知道打算用来做什么用。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_BrownNoteBook",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_BrownNoteBook",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1217, Gain = 244},
		{Value = 200002, Base = 21, Gain = 5},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4144] =
{
	Id = 4144,
	Name = "杀人怪医扮演者",
	Rarity = 2,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "法医从黑色法医组织手中抢来的制服，使用了特制金属及皮料制成，透气性及保护性一流，非常适合作为战斗服使用。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_04_fayi_cos10",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_04_fayi",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1217, Gain = 244},
		{Value = 200002, Base = 21, Gain = 5},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4145] =
{
	Id = 4145,
	Name = "恶霸",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "令人闻风丧胆的凶手，没人知道ta的身份。只要ta出现，大家就会放弃抵抗落荒而逃，然后露出破绽，被他轻易击杀。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_28_heiyiren",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_28_heiyiren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1130, Gain = 226},
		{Value = 200002, Base = 20, Gain = 4},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4146] =
{
	Id = 4146,
	Name = "复仇的小弟",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "令人闻风丧胆的凶手，没人知道ta的身份。只要ta出现，大家就会放弃抵抗落荒而逃，然后露出破绽，被他轻易击杀。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_28_heiyiren",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_28_heiyiren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1130, Gain = 226},
		{Value = 200002, Base = 20, Gain = 4},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4147] =
{
	Id = 4147,
	Name = "动作指导",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "令人闻风丧胆的凶手，没人知道ta的身份。只要ta出现，大家就会放弃抵抗落荒而逃，然后露出破绽，被他轻易击杀。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_28_heiyiren",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_28_heiyiren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1130, Gain = 226},
		{Value = 200002, Base = 20, Gain = 4},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4148] =
{
	Id = 4148,
	Name = "社区巡警",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "城市司法的象征，敢于挑战它，就是挑战整个城市的司法权威！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_PoliceCaps",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_PoliceCaps",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1464, Gain = 293},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4149] =
{
	Id = 4149,
	Name = "黑警长",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "豆豆警官击败黑警长后在组织中建立的新身份。此后，他将以黑警长的身份继续深入调查组织内部的罪恶秘密，希望有一天能够将组织彻底捣毁。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_05_jingcha_cos10",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_05_jingcha",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 145,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1464, Gain = 293},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4150] =
{
	Id = 4150,
	Name = "黑法医",
	Rarity = 4,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "法医从黑色法医组织手中抢来的制服，使用了特制金属及皮料制成，透气性及保护性一流，非常适合作为战斗服使用。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_04_fayi_cos10",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_04_fayi",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1464, Gain = 293},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4151] =
{
	Id = 4151,
	Name = "罪恶的剧透犯",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "令人闻风丧胆的凶手，没人知道ta的身份。只要ta出现，大家就会放弃抵抗落荒而逃，然后露出破绽，被他轻易击杀。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_28_heiyiren",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_28_heiyiren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4152] =
{
	Id = 4152,
	Name = "夜场看门人",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "能够完美呈现何谓恐怖的凶手外套，兜帽下让人无法辨别的脸，似乎时刻都在注视着你。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_28_heiyiren_cos10",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_28_heiyiren",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1609, Gain = 322},
		{Value = 200002, Base = 28, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4153] =
{
	Id = 4153,
	Name = "上台练习",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "能够把路人脸上的毛孔都拍得一清二楚的高级摄像头，可他们又忘了加麦克风。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_Camera",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_Camera",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4154] =
{
	Id = 4154,
	Name = "夜场看门人",
	Rarity = 2,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "能够完美呈现何谓恐怖的凶手外套，兜帽下让人无法辨别的脸，似乎时刻都在注视着你。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_28_heiyiren_cos10",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_28_heiyiren",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1609, Gain = 322},
		{Value = 200002, Base = 28, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4155] =
{
	Id = 4155,
	Name = "房东太太",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "不起眼的房东太太，名下却有前任老公们留下的近200处房产，每天都悠闲地散步。无论房客多奇怪，她能应对自如。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_15_fangdongtaitai",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_15_fangdongtaitai",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4156] =
{
	Id = 4156,
	Name = "背叛的朋友",
	Rarity = 4,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "前任大侦探老福的孙子，继承了爷爷的意志，经常帮助警局侦办悬疑案件。既是警局救星，也是警局克星。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_01_fuermosi",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_01_fuermosi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1840, Gain = 368},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4157] =
{
	Id = 4157,
	Name = "吉利的石头",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "古代神庙祭祀用的大石头，能够驱邪，家里如果闹鬼，可以搬一块回家。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_dashitou",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_dashitou",
	PrefabScale = 50,
	HPBarHeight = 102,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1878, Gain = 376},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4158] =
{
	Id = 4158,
	Name = "APTX4869解药",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "常用的书写墨水，不过被悬疑星黑帮垄断生产，因此成为了非常昂贵的墨水，只有非常富有的贵族才能随意使用。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_ColourInk",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_ColourInk",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1878, Gain = 376},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4159] =
{
	Id = 4159,
	Name = "脑力扩散装置",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "实验室特别存保存下来的生物大脑，其中存储着大量重要的信息。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Brain",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Brain",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1878, Gain = 376},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4160] =
{
	Id = 4160,
	Name = "房东太太",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "不起眼的房东太太，名下却有前任老公们留下的近200处房产，每天都悠闲地散步。无论房客多奇怪，她能应对自如。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_15_fangdongtaitai",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_15_fangdongtaitai",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2050, Gain = 410},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4161] =
{
	Id = 4161,
	Name = "朋克反派",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "悬疑星有史以来最大型连续剧《朋克神探》中的第一反派。装备了高星实验室最新的邪恶灵感装置及增强型一发倒地枪，比以往更危险！\n据说，这次反派的目标依然是破坏城市和平，挑战大侦探。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_03_moliyadi_cos10",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_03_moliyadi",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2050, Gain = 410},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4162] =
{
	Id = 4162,
	Name = "隔壁邻居",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "前任凶手老杰克的孙子，爷爷神秘失踪后一直在追查爷爷的下落。经常穿着当年爷爷留下来的服装四处游荡，希望找到线索。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_29_kaitangshoujieke",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_29_kaitangshoujieke",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2050, Gain = 410},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4163] =
{
	Id = 4163,
	Name = "朋克主角",
	Rarity = 5,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "悬疑星有史以来最大型连续剧《朋克神探》中的第一男主角。大侦探将再次与他的宿敌进行较量。不过装备了最高标准的防毒面具及灵感烟斗，这次大侦探再也不怕教授的毒雾，也不会因为被击碎灵感而无法断案了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_01_fuermosi_cos20",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_01_fuermosi",
	SkinName = "3",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2050, Gain = 410},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4164] =
{
	Id = 4164,
	Name = "房东太太",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "不起眼的房东太太，名下却有前任老公们留下的近200处房产，每天都悠闲地散步。无论房客多奇怪，她能应对自如。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_15_fangdongtaitai",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_15_fangdongtaitai",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2050, Gain = 410},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4165] =
{
	Id = 4165,
	Name = "研究所所长",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "内置物质转换器的防化服，据说价值180亿。可以过滤任何形式的有害物质，对于进行危险实验能起到至关重要的保护作用。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_03_moliyadi_cos30",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_03_moliyadi",
	SkinName = "4",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2050, Gain = 410},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4166] =
{
	Id = 4166,
	Name = "不满的游客",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "来自神秘星球的部落酋长，部族世代受到不幸之神的祝福，虽然不会遭遇什么变故，但是做什么事情都比一般人不顺很多。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPDraw_04_UnlockChief",
	PrefabBundle = "character_sp",
	PrefabName = "SPDraw_04_UnlockChief",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4167] =
{
	Id = 4167,
	Name = "不满的游客",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "来自神秘星球的部落酋长，部族世代受到不幸之神的祝福，虽然不会遭遇什么变故，但是做什么事情都比一般人不顺很多。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPDraw_04_UnlockChief",
	PrefabBundle = "character_sp",
	PrefabName = "SPDraw_04_UnlockChief",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1840, Gain = 368},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4168] =
{
	Id = 4168,
	Name = "不满的游客",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "来自神秘星球的部落酋长，部族世代受到不幸之神的祝福，虽然不会遭遇什么变故，但是做什么事情都比一般人不顺很多。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPDraw_04_UnlockChief",
	PrefabBundle = "character_sp",
	PrefabName = "SPDraw_04_UnlockChief",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2050, Gain = 410},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4169] =
{
	Id = 4169,
	Name = "流行乐歌手",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "元气十足的偶像团表演服，用这个为村里的NPC们表演，会让大家更有活力噢~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_15_peiyinyanyuan_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_15_peiyinyanyuan",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1464, Gain = 293},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4170] =
{
	Id = 4170,
	Name = "超菜冒险者",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "自称为冒险星的主角，身负打败魔王以及为世界带来和平的重任。虽然帮助村民不求回报，但缺物资时，会以正义之名进入NPC家中取走合用的财物。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_05_jianshi",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_05_jianshi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 452, Gain = 91},
		{Value = 200002, Base = 20, Gain = 4},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4171] =
{
	Id = 4171,
	Name = "超菜冒险者",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "精灵国的美丽公主，目前正独自外出历练。拥有举世无双的射术，但遇到可怕的怪物便会立刻陷入战斗不能状态。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_24_gongjianshou",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_24_gongjianshou",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 452, Gain = 91},
		{Value = 200002, Base = 20, Gain = 4},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4172] =
{
	Id = 4172,
	Name = "超菜冒险者",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "经典冒险组人气角色，携带着大量法器，能够给予其他冒险者们勇气和希望。\n听说，一起组队的男冒险者经常会偷偷给她递小纸条。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_07_mushi",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_07_mushi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 452, Gain = 91},
		{Value = 200002, Base = 20, Gain = 4},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4173] =
{
	Id = 4173,
	Name = "点点",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "活跃在悬疑星的花猫，喜欢在安全的地方散步，如果路上发生状况，就会蹲在一边舔着舌头看热闹。\n它的舌头并没有三种花色。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_ColorfulCat",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_ColourfulCat",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1130, Gain = 226},
		{Value = 200002, Base = 20, Gain = 4},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4174] =
{
	Id = 4174,
	Name = "圣骑士导师",
	Rarity = 5,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "历代勇者的专用服装，每次穿上前会播放近1分钟的特效，如果遇到不讲规矩的敌人，那么变身过程中就会被揍得鼻青脸肿。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_20_laoyeye_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_20_laoyeye",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 150,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1606, Gain = 322},
		{Value = 200002, Base = 30, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4175] =
{
	Id = 4175,
	Name = "外星兔游客",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "教授的睡衣套装，和大侦探与侦探助理进行枕头大战的指定套装，玩累了以后，可以直接倒下来睡觉。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_03_moliyadi_cos20",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_03_moliyadi",
	SkinName = "3",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1606, Gain = 322},
		{Value = 200002, Base = 30, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4176] =
{
	Id = 4176,
	Name = "“小犬星”",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "来自暗影大陆的经典冒险组成员，个性狡猾，不喜欢战斗和吵架。在他们的国家有一句谚语叫“取走敌人心头宝，好比刺他一百刀。”",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_103_Thief",
	PrefabBundle = "character_rpg",
	PrefabName = "RPG_103_Thief",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1606, Gain = 322},
		{Value = 200002, Base = 30, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4177] =
{
	Id = 4177,
	Name = "村里的不死族",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "魔王有限公司临时雇员，即使被拆散了也能很快拼回去，是地城副本中很重要的成员。\n不过偶尔会发生重新拼装时，多出一些骨头的问题。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_30_kulou",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_30_kulou",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1606, Gain = 322},
		{Value = 200002, Base = 30, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4178] =
{
	Id = 4178,
	Name = "通灵师考官",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "魔王有限公司临时雇员，即使被拆散了也能很快拼回去，是地城副本中很重要的成员。\n不过偶尔会发生重新拼装时，多出一些骨头的问题。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_30_kulou",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_30_kulou",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1606, Gain = 322},
		{Value = 200002, Base = 30, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4179] =
{
	Id = 4179,
	Name = "贪婪的铁匠",
	Rarity = 5,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星人气NPC，提供装备买卖、修理、强化等服务，是勇者不可或缺的好帮手。\n“哎呀，手一滑装备爆炸了，阁下运气不太好噢~”",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_31_tiejiang",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_31_tiejiang",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 115,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1606, Gain = 322},
		{Value = 200002, Base = 30, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4180] =
{
	Id = 4180,
	Name = "造型师",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "杰克祖父留给他的代表复仇的外套，只有当杰克的仇人出现时，杰克才会穿上这件衣服，向对方施以愤怒之火。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_29_kaitangshoujieke_cos10",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_29_kaitangshoujieke",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 165,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1840, Gain = 368},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4181] =
{
	Id = 4181,
	Name = "过激的粉丝",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "衣衫不整的男性，可能是因为着装原因，无论他做什么看起来都有点猥琐。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	IconName = "NPC_naked1",
	PrefabBundle = "character_npc",
	PrefabName = "NPC_naked1",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1840, Gain = 368},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4182] =
{
	Id = 4182,
	Name = "服装设计师",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "杰克祖父留给他的代表复仇的外套，只有当杰克的仇人出现时，杰克才会穿上这件衣服，向对方施以愤怒之火。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_29_kaitangshoujieke_cos10",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_29_kaitangshoujieke",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 165,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 692, Gain = 139},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4183] =
{
	Id = 4183,
	Name = "健身教练",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "热衷健身的美食城国王，每天健身8小时，之后去皇家油锅泡澡8小时，然后睡8小时。肌肉含量120%，用力的话可以撑爆背心。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_30_shutiao",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_30_shutiao",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 106,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 615, Gain = 123},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4184] =
{
	Id = 4184,
	Name = "强盗",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "令人闻风丧胆的凶手，没人知道ta的身份。只要ta出现，大家就会放弃抵抗落荒而逃，然后露出破绽，被他轻易击杀。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_28_heiyiren",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_28_heiyiren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 615, Gain = 123},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4185] =
{
	Id = 4185,
	Name = "经纪人",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "事业有成的男性，平时很有教养，但是遇到让他抓狂的事情，就会暴露出可怕的一面。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	IconName = "NPC_men4",
	PrefabBundle = "character_npc",
	PrefabName = "NPC_men4",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4186] =
{
	Id = 4186,
	Name = "导演",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "精通伪装，不仅可以伪装自己的形态，还能把别人的声音模仿得惟妙惟肖。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Octupas1",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Octupas1",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4187] =
{
	Id = 4187,
	Name = "小奶牛",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "农场特制的奶牛装，用以感谢牧师帮助牧场破获了特大牛奶浪费事件。当地的居民也因为之后及时补充了钙质，骨折好得更快了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_07_mushi_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_07_mushi",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4188] =
{
	Id = 4188,
	Name = "外星面试官",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "史莱姆大王的外星度假套装，内置恒温调节装置、供氧装置及排泄物处理装置。穿上这一身装备，那无论哪里都能轻松前往了。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPDraw_01_SlimeKing_cos10",
	PrefabBundle = "character_sp",
	PrefabName = "SPDraw_01_SlimeKing",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4189] =
{
	Id = 4189,
	Name = "镜子里的自己",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "深潜FoRever成员，温驯海族，每隔一天就会变成另一个模样，因此作为TA的粉丝，必须要记住两张脸。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "Sea_05_haitu",
	PrefabBundle = "character_sea",
	PrefabName = "Sea_05_haitu",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4190] =
{
	Id = 4190,
	Name = "观众A",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "事业有成的男性，平时很有教养，但是遇到让他抓狂的事情，就会暴露出可怕的一面。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	IconName = "NPC_men4",
	PrefabBundle = "character_npc",
	PrefabName = "NPC_men4",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 816, Gain = 164},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4191] =
{
	Id = 4191,
	Name = "观众B",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "衣衫不整的男性，可能是因为着装原因，无论他做什么看起来都有点猥琐。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	IconName = "NPC_naked1",
	PrefabBundle = "character_npc",
	PrefabName = "NPC_naked1",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 816, Gain = 164},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4192] =
{
	Id = 4192,
	Name = "骨头兵",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "魔王有限公司临时雇员，即使被拆散了也能很快拼回去，是地城副本中很重要的成员。\n不过偶尔会发生重新拼装时，多出一些骨头的问题。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_30_kulou",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_30_kulou",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4193] =
{
	Id = 4193,
	Name = "嚣张的同学",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "偶像团体鱼妄想中的一员，温驯海族，口号是“翻车鱼的演出永不翻车！”。明明是个木讷的人，但有时又让人觉得聪明机警。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "Sea_28_fancheyu",
	PrefabBundle = "character_sea",
	PrefabName = "Sea_28_fancheyu",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4194] =
{
	Id = 4194,
	Name = "海星寻沙",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "深潜FoRever成员，凶猛海族，喜欢收集不同颜色的海星发卡，凭借可爱的形象吸引了众多粉丝。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "Sea_08_haixing",
	PrefabBundle = "character_sea",
	PrefabName = "Sea_08_haixing",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 816, Gain = 164},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4195] =
{
	Id = 4195,
	Name = "海蛇莱斯莉",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "Aquarius中的一员，凶猛海族，训蛇高手，可用歌声操控小蛇随之舞动。是团队中最神秘的成员，连经纪公司对TA都不甚了解。但是神秘的背景和官网介绍似乎反而让TA收获了很多人气。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "Sea_25_haishe",
	PrefabBundle = "character_sea",
	PrefabName = "Sea_25_haishe",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 816, Gain = 164},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4196] =
{
	Id = 4196,
	Name = "海葵彩雅",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "Aquarius中的一员，温驯海族。上学的时候经常被门卫以不符合学生规范为由拒绝放行。在加入发色都很鲜艳的偶像团后终于不再苦恼。最近似乎被爆出八卦，和另一偶像组合成员有密切接触，引起粉丝的关注。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "Sea_23_haikui",
	PrefabBundle = "character_sea",
	PrefabName = "Sea_23_haikui",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4197] =
{
	Id = 4197,
	Name = "制片人",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "天鱼公司总经理，唯董事长马首是瞻。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Crab",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Crab",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4198] =
{
	Id = 4198,
	Name = "造型师",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "杰克祖父留给他的代表复仇的外套，只有当杰克的仇人出现时，杰克才会穿上这件衣服，向对方施以愤怒之火。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_29_kaitangshoujieke_cos10",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_29_kaitangshoujieke",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 165,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4199] =
{
	Id = 4199,
	Name = "绿礁保安",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "穿着绿色制服的保安，保卫礁石区一方平安，会对危害公共安全的危险分子，会毫不留情发射藤壶。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Ston1",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Stone1",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4200] =
{
	Id = 4200,
	Name = "海葵彩雅",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "Aquarius中的一员，温驯海族。上学的时候经常被门卫以不符合学生规范为由拒绝放行。在加入发色都很鲜艳的偶像团后终于不再苦恼。最近似乎被爆出八卦，和另一偶像组合成员有密切接触，引起粉丝的关注。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "Sea_23_haikui",
	PrefabBundle = "character_sea",
	PrefabName = "Sea_23_haikui",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4201] =
{
	Id = 4201,
	Name = "海胆小茨",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "Aquarius中的一员，温驯海族，性格沉稳，在舞台上经常展现出不动如山般的稳定唱功。平时喜欢独居，经常坐在某个地方一动不动一整天。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "Sea_21_haidan",
	PrefabBundle = "character_sea",
	PrefabName = "Sea_21_haidan",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 653, Gain = 131},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4202] =
{
	Id = 4202,
	Name = "海葵彩雅",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "Aquarius中的一员，温驯海族。上学的时候经常被门卫以不符合学生规范为由拒绝放行。在加入发色都很鲜艳的偶像团后终于不再苦恼。最近似乎被爆出八卦，和另一偶像组合成员有密切接触，引起粉丝的关注。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "Sea_23_haikui",
	PrefabBundle = "character_sea",
	PrefabName = "Sea_23_haikui",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 653, Gain = 131},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4203] =
{
	Id = 4203,
	Name = "鮟鱇明",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "Aquarius中的一员，凶猛海族，神秘的深海族，据说在登台表演时从来不打光，用TA头上的灯就可以。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "Sea_26_ankang",
	PrefabBundle = "character_sea",
	PrefabName = "Sea_26_ankang",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 653, Gain = 131},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4204] =
{
	Id = 4204,
	Name = "医生",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "穿着特制工作服的法医，包揽了悬疑星所有的法医及法证工作，经常出入于凶案现场，负责处理各种现场证物。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_04_fayi",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_04_fayi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 123,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4205] =
{
	Id = 4205,
	Name = "史莱姆大王",
	Rarity = 4,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "初级金币池收集度100%的冒险者才能获得的特殊角色。遇到什么都会“啊呜”一口吞到肚子里的史莱姆大王，身体里面有大量不知道从哪里捡来的东西，似乎也有不少人员情报。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPDraw_01_SlimeKing",
	PrefabBundle = "character_sp",
	PrefabName = "SPDraw_01_SlimeKing",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 736, Gain = 148},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4206] =
{
	Id = 4206,
	Name = "精灵王子",
	Rarity = 4,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "中级金币池收集度100%的冒险者才能获得的特殊角色。精灵国王子，酷爱外星饮料，常驻不夜城酒吧。为了支付高昂的饮料费，最近似乎也在进行人员情报的交易。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPDraw_02_ElvenPrince",
	PrefabBundle = "character_sp",
	PrefabName = "SPDraw_02_ElvenPrince",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 736, Gain = 148},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4207] =
{
	Id = 4207,
	Name = "玉璧女王",
	Rarity = 4,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "玉璧奖池收集度100%的冒险者才能获得的特殊角色。玉璧女王常年在不夜城中进行人员情报的交易，不过在收取费用后，只给买家一点素材作为回报。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPDraw_03_DiamondQueen",
	PrefabBundle = "character_sp",
	PrefabName = "SPDraw_03_DiamondQueen",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 736, Gain = 148},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4208] =
{
	Id = 4208,
	Name = "海星寻沙",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "深潜FoRever成员，凶猛海族，喜欢收集不同颜色的海星发卡，凭借可爱的形象吸引了众多粉丝。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "Sea_08_haixing",
	PrefabBundle = "character_sea",
	PrefabName = "Sea_08_haixing",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1840, Gain = 368},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4209] =
{
	Id = 4209,
	Name = "海底魔术师",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "来自学者城的智者，目前正以经典冒险组成员的身份游历各地。精通冒险星各大陆历史和文字，偶尔也研究禁忌的知识。待人温文有礼，不过经常被身边的女性说不懂人情世故。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_105_Scholar",
	PrefabBundle = "character_rpg",
	PrefabName = "RPG_105_Scholar",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1840, Gain = 368},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4210] =
{
	Id = 4210,
	Name = "道馆馆主",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "天鱼公司总经理，唯董事长马首是瞻。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Crab",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Crab",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1840, Gain = 368},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4211] =
{
	Id = 4211,
	Name = "蝠鲼凉风",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "偶像团体鱼妄想中的一员，凶猛海族，与同样喜欢帽子的鱼不翻组成了两人偶像团。为了展示自己的帽子，会想尽办法在舞蹈中加入转帽子的动作。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "Sea_15_manta",
	PrefabBundle = "character_sea",
	PrefabName = "Sea_15_manta",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 920, Gain = 184},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4212] =
{
	Id = 4212,
	Name = "海蛇莱斯莉",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "Aquarius中的一员，凶猛海族，训蛇高手，可用歌声操控小蛇随之舞动。是团队中最神秘的成员，连经纪公司对TA都不甚了解。但是神秘的背景和官网介绍似乎反而让TA收获了很多人气。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "Sea_25_haishe",
	PrefabBundle = "character_sea",
	PrefabName = "Sea_25_haishe",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 920, Gain = 184},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4213] =
{
	Id = 4213,
	Name = "茉白的歌迷",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "染了亮丽金发的女性，过着精致的生活，平时最喜欢和姐妹们聊些八卦新闻。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	IconName = "NPC_women2",
	PrefabBundle = "character_npc",
	PrefabName = "NPC_women2",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1840, Gain = 368},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4214] =
{
	Id = 4214,
	Name = "蝠鲼凉风",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "偶像团体鱼妄想中的一员，凶猛海族，与同样喜欢帽子的鱼不翻组成了两人偶像团。为了展示自己的帽子，会想尽办法在舞蹈中加入转帽子的动作。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "Sea_15_manta",
	PrefabBundle = "character_sea",
	PrefabName = "Sea_15_manta",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 920, Gain = 184},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4215] =
{
	Id = 4215,
	Name = "海星寻沙",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "深潜FoRever成员，凶猛海族，喜欢收集不同颜色的海星发卡，凭借可爱的形象吸引了众多粉丝。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "Sea_08_haixing",
	PrefabBundle = "character_sea",
	PrefabName = "Sea_08_haixing",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 920, Gain = 184},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4216] =
{
	Id = 4216,
	Name = "节目导演",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "精通伪装，不仅可以伪装自己的形态，还能把别人的声音模仿得惟妙惟肖。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Octupas1",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Octupas1",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2050, Gain = 410},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4217] =
{
	Id = 4217,
	Name = "梦魇",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "年幼的海胆，遇到危险时会虚张声势说“我要扎破你”，但其实身上只有几颗稀疏的软刺。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "SEA",
	IconName = "SEA_SeaUrchin",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_SeaUrchin",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2050, Gain = 410},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4218] =
{
	Id = 4218,
	Name = "黑国王",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "黑棋星人的世代领袖，每天都在思考如何组织新的攻势反击白棋星人。本身虽然非常弱小，经常成为对方进攻的突破口，不过依靠手下们的拼死保护，每次都能毫发无伤。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "All_Chess_WhiteKing_cos10",
	PrefabBundle = "character_sp",
	PrefabName = "All_Chess_WhiteKing",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 145,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1840, Gain = 368},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4219] =
{
	Id = 4219,
	Name = "黑皇后",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "地位仅次于国王的黑棋皇后，能够调动娘家军团四面出击。据说，以前进攻能力非常弱，后来凭借其背后的娘家势力，多次逼迫委员会修改规则，才成为战场上最逆天的存在。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "All_Chess_WhiteQueen_cos10",
	PrefabBundle = "character_sp",
	PrefabName = "All_Chess_WhiteQueen",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1840, Gain = 368},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4220] =
{
	Id = 4220,
	Name = "黑主教",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "黑棋国的大主教，是民众信仰的象征，在战场上可以斜着随便走。平时虽然经常和国王暗中较劲，但是大敌当前时，会不顾一切地保护国王。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "All_Chess_WhiteBishop_cos10",
	PrefabBundle = "character_sp",
	PrefabName = "All_Chess_WhiteBishop",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1840, Gain = 368},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4221] =
{
	Id = 4221,
	Name = "黑城堡",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "代表着王国最强兵器的强力战车，也被人称为黑色城堡，在战场上可以横行无忌。作战风格异常勇猛，经常比赛还未开始，便已孤身一人杀入敌阵，曾多次被裁判罚判抢步。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "All_Chess_WhiteRook_cos10",
	PrefabBundle = "character_sp",
	PrefabName = "All_Chess_WhiteRook",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 145,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1840, Gain = 368},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4222] =
{
	Id = 4222,
	Name = "黑骑士",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "受到国王册封，荣升骑士头衔的战马，象征着王国高贵的骑士精神。平时虽然总是标榜自己的崇高道德，不过打完仗拿战利品时却毫不手软。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "All_Chess_WhiteKnight_cos10",
	PrefabBundle = "character_sp",
	PrefabName = "All_Chess_WhiteKnight",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 145,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1840, Gain = 368},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4223] =
{
	Id = 4223,
	Name = "黑卫兵",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "来自平民家庭的王国基层士兵，为维持生计被迫参军。在战场上是不起眼的存在，不过为了迎接随时可能到来的“兵升变”，卫兵每次上场都会带齐主教、战车和骑士的头冠。毕竟，触底的一刻就是华丽逆转的开始。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "All_Chess_WhitePawn_cos10",
	PrefabBundle = "character_sp",
	PrefabName = "All_Chess_WhitePawn",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4224] =
{
	Id = 4224,
	Name = "严寒！",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：兜售只要舔一口就会三叉神经痛的超级冰球给路人。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_FAT_IceCream",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_FAT_IceCream",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4225] =
{
	Id = 4225,
	Name = "整容医生",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "穿着特制工作服的法医，包揽了悬疑星所有的法医及法证工作，经常出入于凶案现场，负责处理各种现场证物。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_04_fayi",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_04_fayi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 123,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4226] =
{
	Id = 4226,
	Name = "小流氓",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "草莓味的果冻装，一口一个小草莓",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_12_xiaohong_cos10",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_12_xiaohong",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4227] =
{
	Id = 4227,
	Name = "痛苦的回忆",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "出没在遗迹附近的精灵，以死去之人残存的气息为食，如果惹到了它，它会偷偷跟在你后面，找机会绊你一跤。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_chouniguai",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_chouniguai",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4228] =
{
	Id = 4228,
	Name = "时尚双子",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "修身贴合的旗袍和国潮正装，对于穿着者的体型要求近乎苛刻，多一两肉都会变成紧身衣。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_BeginEnd_cos10",
	PrefabBundle = "character_sp",
	PrefabName = "All_BeginEnd",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 145,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1840, Gain = 368},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4229] =
{
	Id = 4229,
	Name = "另一条锦鲤鲤",
	Rarity = 4,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "入选蓝星2018十大流行语的明星生物，因祖上曾有越龙门的事迹而成为了传奇。每年都会收到各星球的愿望信件，虽然一再申明自己没有实现愿望的能力，但是并没有人相信。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_LuckyFish",
	PrefabBundle = "character_sp",
	PrefabName = "All_LuckyFish",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1840, Gain = 368},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4230] =
{
	Id = 4230,
	Name = "我不是酱紫！",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：偷到沼泽冒险者掉在地上的物品不还。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_Slime_Purple",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_Slime_purple",
	PrefabScale = 50,
	HPBarHeight = 69,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2050, Gain = 410},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4231] =
{
	Id = 4231,
	Name = "协会的同伴A",
	Rarity = 2,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "虽然不能保证公主不被绑架，但是能保证第一时间出发救援！\n“欸！小绿帽上的羽毛在抖动，公主有危险！”",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_05_jianshi_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_05_jianshi",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 150,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1217, Gain = 244},
		{Value = 200002, Base = 21, Gain = 5},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4232] =
{
	Id = 4232,
	Name = "龙血的术士",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "龙族指定的接班人，喜欢假扮人类去城堡或村子里吃烤肉，高兴时会露出尾巴。最近不知道为什么，好像正在学习怎么和女孩子相处的样子。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_23_long",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_23_long",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1840, Gain = 368},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4233] =
{
	Id = 4233,
	Name = "路过的黑狼",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "曾经在溪谷与白狼争夺地盘的凶悍族群，被白狼凶过以后，集体撤离了溪谷。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_blackWolf",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_BlackWolf",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2196, Gain = 440},
		{Value = 200002, Base = 39, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "有33%概率额外攻击1次\n20%概率闪避攻击\n受暗元素敌人伤害 -100%",
		Skill = {
			{
				Id = 105023,
				Value = 33,
			},
			{
				Id = 105026,
				Value = 20,
			},
			{
				Id = 105037,
				Value = -100,
			},
		},
	},
	Tags = {
		564557,
		564558,
	},
}
EnemyConfig[EnemyID.Id4234] =
{
	Id = 4234,
	Name = "大众情人",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "超人气王子，王子唱片董事长。每年都会开办36场演唱会，出18张专辑。不过唱片销量要靠常年打折外加赠送超值礼品才能维持。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_07_kele",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_07_kele",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 114,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "20%概率闪避攻击\n受暗元素敌人伤害 -100%",
		Skill = {
			{
				Id = 105026,
				Value = 20,
			},
			{
				Id = 105037,
				Value = -100,
			},
		},
	},
	Tags = {
		564557,
	},
}
EnemyConfig[EnemyID.Id4235] =
{
	Id = 4235,
	Name = "要红包的商人",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "冒险星人气NPC，拥有没人见过的非凡实力。卖出去1000块的道具，下一秒就是100块的回收价，却没有谁敢和他们吵架。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_14_lvxingshangren",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_14_lvxingshangren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "20%概率闪避攻击\n受暗元素敌人伤害 -100%",
		Skill = {
			{
				Id = 105026,
				Value = 20,
			},
			{
				Id = 105037,
				Value = -100,
			},
		},
	},
	Tags = {
		564557,
	},
}
EnemyConfig[EnemyID.Id4236] =
{
	Id = 4236,
	Name = "擂主",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "与光明料理会不共戴天的料理者。被美食星驱逐后，成为了流亡街的居民。目前处于无照经营摊贩的状态，会推着料理小车，制作出让人无法拒绝的邪恶美食。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Pir_01_DarkCooker",
	PrefabBundle = "character_boss",
	PrefabName = "Pir_01_DarkCooker",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "20%概率闪避攻击\n受暗元素敌人伤害 -100%",
		Skill = {
			{
				Id = 105026,
				Value = 20,
			},
			{
				Id = 105037,
				Value = -100,
			},
		},
	},
	Tags = {
		564557,
	},
}
EnemyConfig[EnemyID.Id4237] =
{
	Id = 4237,
	Name = "路人甲",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "事业有成的男性，平时很有教养，但是遇到让他抓狂的事情，就会暴露出可怕的一面。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	IconName = "NPC_men4",
	PrefabBundle = "character_npc",
	PrefabName = "NPC_men4",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "20%概率闪避攻击\n受暗元素敌人伤害 -100%",
		Skill = {
			{
				Id = 105026,
				Value = 20,
			},
			{
				Id = 105037,
				Value = -100,
			},
		},
	},
	Tags = {
		564557,
	},
}
EnemyConfig[EnemyID.Id4238] =
{
	Id = 4238,
	Name = "鲱鱼饭团",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "强迫症患者，玩游戏时如果控制的角色血量不满会相当焦虑。得知鲱鱼拥有丰富的补血元素后，毫不犹豫走上了做鲱鱼饭团的路。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_105_HerringRiceBall",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_105_HerringRiceBall",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "20%概率闪避攻击\n受暗元素敌人伤害 -100%",
		Skill = {
			{
				Id = 105026,
				Value = 20,
			},
			{
				Id = 105037,
				Value = -100,
			},
		},
	},
	Tags = {
		564557,
	},
}
EnemyConfig[EnemyID.Id4239] =
{
	Id = 4239,
	Name = "野蛮的客人",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "老年男性，享受着安详的退休生活，但是偶尔也会有发火的时候。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	IconName = "NPC_oldmen1",
	PrefabBundle = "character_npc",
	PrefabName = "NPC_oldmen1",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1840, Gain = 368},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "20%概率闪避攻击\n受暗元素敌人伤害 -100%",
		Skill = {
			{
				Id = 105026,
				Value = 20,
			},
			{
				Id = 105037,
				Value = -100,
			},
		},
	},
	Tags = {
		564557,
	},
}
EnemyConfig[EnemyID.Id4240] =
{
	Id = 4240,
	Name = "板蓝根泡面",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "出生于养生世家，对药物有异于寻常的热爱。吃泡面时，会用板蓝根来取代调料包，此刻，即便是无甚营养的泡面也有了增强体质的功能。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_104_IsatisNoodle",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_104_IsatisNoodle",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1840, Gain = 368},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "20%概率闪避攻击\n受暗元素敌人伤害 -100%",
		Skill = {
			{
				Id = 105026,
				Value = 20,
			},
			{
				Id = 105037,
				Value = -100,
			},
		},
	},
	Tags = {
		564557,
	},
}
EnemyConfig[EnemyID.Id4241] =
{
	Id = 4241,
	Name = "西式面点师",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "邋遢的男性，没有人知道他在想什么。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	IconName = "NPC_men2",
	PrefabBundle = "character_npc",
	PrefabName = "NPC_men2",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1840, Gain = 368},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "20%概率闪避攻击\n受暗元素敌人伤害 -100%",
		Skill = {
			{
				Id = 105026,
				Value = 20,
			},
			{
				Id = 105037,
				Value = -100,
			},
		},
	},
	Tags = {
		564557,
	},
}
EnemyConfig[EnemyID.Id4242] =
{
	Id = 4242,
	Name = "另一个史卡",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "听说用金渐层猫猫的粑粑制作出的咖啡非常美味，史卡想引诱金渐层品种的猫猫，可无论怎么做，都看不到猫猫的身影……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_102_KopiLuwak_cos10",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_102_KopiLuwak",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 145,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1606, Gain = 322},
		{Value = 200002, Base = 30, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "20%概率闪避攻击\n受暗元素敌人伤害 -100%",
		Skill = {
			{
				Id = 105026,
				Value = 20,
			},
			{
				Id = 105037,
				Value = -100,
			},
		},
	},
	Tags = {
		564557,
	},
}
EnemyConfig[EnemyID.Id4243] =
{
	Id = 4243,
	Name = "品酒师",
	Rarity = 5,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "染了亮丽金发的女性，过着精致的生活，平时最喜欢和姐妹们聊些八卦新闻。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	IconName = "NPC_women2",
	PrefabBundle = "character_npc",
	PrefabName = "NPC_women2",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2050, Gain = 410},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "20%概率闪避攻击\n受暗元素敌人伤害 -100%",
		Skill = {
			{
				Id = 105026,
				Value = 20,
			},
			{
				Id = 105037,
				Value = -100,
			},
		},
	},
	Tags = {
		564557,
	},
}
EnemyConfig[EnemyID.Id4244] =
{
	Id = 4244,
	Name = "深海女巫",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "人鱼清音获得了魔力，可以发出蛊惑人心的魔音，还有一把吸力极强的三叉戟，然而在海底，却吸来了许多铁皮垃圾。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "Sea_31_meirenyu_cos10",
	PrefabBundle = "character_sea",
	PrefabName = "Sea_31_meirenyu",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 140,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2050, Gain = 410},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
	SkillList = {
		Desc = "20%概率闪避攻击\n受暗元素敌人伤害 -100%",
		Skill = {
			{
				Id = 105026,
				Value = 20,
			},
			{
				Id = 105037,
				Value = -100,
			},
		},
	},
	Tags = {
		564557,
	},
}
EnemyConfig[EnemyID.Id4245] =
{
	Id = 4245,
	Name = "家政同事",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "村子里每天都会有各色怪物来拜访，每次脏脏的怪物来村长家做客后，村长夫人都会穿上特别的扫除服装，立刻将家里打扫干净。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_18_laonainai_cos10",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_18_laonainai",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4246] =
{
	Id = 4246,
	Name = "树精",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "吸取树木精华为生的精灵，说不清是植物还是精灵，负责净化沼泽地区的空气质量。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_xiaoshuyang",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_xiaoshuyang",
	PrefabScale = 60,
	HPBarHeight = 85,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4247] =
{
	Id = 4247,
	Name = "大黑狼",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "曾经在溪谷与白狼争夺地盘的凶悍族群，被白狼凶过以后，集体撤离了溪谷。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_blackWolf",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_BlackWolf",
	PrefabScale = 50,
	HPBarHeight = 110,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1464, Gain = 293},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4248] =
{
	Id = 4248,
	Name = "失控能量",
	Rarity = 5,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：经常出没坟场，吓前来祭拜的人。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_RPG_Fireball",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_RPG_Fireball",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2050, Gain = 410},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4249] =
{
	Id = 4249,
	Name = "龙舟赛小队长",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "魔王公司中层干部，平时会带着低级雇员们在路上堵截低级勇者搞业绩。不过因为掉落物不错，所以也常被高级勇者蹲点刷。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_13_dashouxiaodi",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_13_dashouxiaodi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1840, Gain = 368},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4250] =
{
	Id = 4250,
	Name = "龙舟赛小队长",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "魔王公司中层干部，平时会带着低级雇员们在路上堵截低级勇者搞业绩。不过因为掉落物不错，所以也常被高级勇者蹲点刷。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_13_dashouxiaodi",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_13_dashouxiaodi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1840, Gain = 368},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4251] =
{
	Id = 4251,
	Name = "龙舟赛小队长",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "魔王公司中层干部，平时会带着低级雇员们在路上堵截低级勇者搞业绩。不过因为掉落物不错，所以也常被高级勇者蹲点刷。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_13_dashouxiaodi",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_13_dashouxiaodi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4252] =
{
	Id = 4252,
	Name = "龙舟赛小队长",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "魔王公司中层干部，平时会带着低级雇员们在路上堵截低级勇者搞业绩。不过因为掉落物不错，所以也常被高级勇者蹲点刷。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "Rpg_13_dashouxiaodi",
	PrefabBundle = "character_rpg",
	PrefabName = "Rpg_13_dashouxiaodi",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 105,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4253] =
{
	Id = 4253,
	Name = "竞争者",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "罪名：过于凡尔赛。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPBUS_10_jiangshou01_cos10",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_10_jiangshou01",
	SkinName = "2",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4254] =
{
	Id = 4254,
	Name = "史莱姆大王",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "初级金币池收集度100%的冒险者才能获得的特殊角色。遇到什么都会“啊呜”一口吞到肚子里的史莱姆大王，身体里面有大量不知道从哪里捡来的东西，似乎也有不少人员情报。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPDraw_01_SlimeKing",
	PrefabBundle = "character_sp",
	PrefabName = "SPDraw_01_SlimeKing",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1130, Gain = 226},
		{Value = 200002, Base = 20, Gain = 4},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4255] =
{
	Id = 4255,
	Name = "史莱姆大王",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "初级金币池收集度100%的冒险者才能获得的特殊角色。遇到什么都会“啊呜”一口吞到肚子里的史莱姆大王，身体里面有大量不知道从哪里捡来的东西，似乎也有不少人员情报。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPDraw_01_SlimeKing",
	PrefabBundle = "character_sp",
	PrefabName = "SPDraw_01_SlimeKing",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1130, Gain = 226},
		{Value = 200002, Base = 20, Gain = 4},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4256] =
{
	Id = 4256,
	Name = "月佬",
	Rarity = 3,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "人称“牛头大佬”，因为一些前尘往事，被逐出天上人间婚介所，至今仍为无业游民，在流亡街上摆摊算命。虽然小摊无人光顾，但大家都很好奇，沉重的面具下，是一张什么样的脸呢？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "SPBUS_21_YueLao",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_21_YueLao",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4257] =
{
	Id = 4257,
	Name = "小红",
	Rarity = 3,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "苹果味糖豆，最自豪的事是曾在公主庆典上，扮演超大冰淇淋雕像上的苹果。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	IconName = "Fat_12_xiaohong",
	PrefabBundle = "character_fat",
	PrefabName = "Fat_12_xiaohong",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 106,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1878, Gain = 376},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4258] =
{
	Id = 4258,
	Name = "牵牛",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "勤工俭学的男孩，在服装店里负责采购、收银等多项工作，有时还替老板养牛。在庙会上，不经意间和某位女生目光交汇，于是有了一瞬间的心动。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "SPBUS_13_QianNiu",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_13_QianNiu",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1878, Gain = 376},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4259] =
{
	Id = 4259,
	Name = "牵牛",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "勤工俭学的男孩，在服装店里负责采购、收银等多项工作，有时还替老板养牛。在庙会上，不经意间和某位女生目光交汇，于是有了一瞬间的心动。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "SPBUS_13_QianNiu",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_13_QianNiu",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1878, Gain = 376},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4260] =
{
	Id = 4260,
	Name = "牵牛",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "勤工俭学的男孩，在服装店里负责采购、收银等多项工作，有时还替老板养牛。在庙会上，不经意间和某位女生目光交汇，于是有了一瞬间的心动。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "SPBUS_13_QianNiu",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_13_QianNiu",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1878, Gain = 376},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4261] =
{
	Id = 4261,
	Name = "凶手",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "令人闻风丧胆的凶手，没人知道ta的身份。只要ta出现，大家就会放弃抵抗落荒而逃，然后露出破绽，被他轻易击杀。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	IconName = "Sus_28_heiyiren",
	PrefabBundle = "character_sus",
	PrefabName = "Sus_28_heiyiren",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 112,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4262] =
{
	Id = 4262,
	Name = "胆小的六瑶",
	Rarity = 3,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "是姐妹七人中最胆小的女孩。害怕打雷、闪电、四荔的恶作剧，就算是庙会上热烈的烟火，也会把她吓得不轻。最害怕的是和姐妹们分开。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "SPBUS_19_LiuYao",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_19_LiuYao",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4263] =
{
	Id = 4263,
	Name = "牵牛",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "勤工俭学的男孩，在服装店里负责采购、收银等多项工作，有时还替老板养牛。在庙会上，不经意间和某位女生目光交汇，于是有了一瞬间的心动。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "SPBUS_13_QianNiu",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_13_QianNiu",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4264] =
{
	Id = 4264,
	Name = "昆仑之仙",
	Rarity = 5,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "充满仙气和古典气息的衣裳，仿佛是居住在昆仑神山上，具有仙风道骨的老神仙。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	IconName = "MUS_23_chuangzaozhishen_cos20",
	PrefabBundle = "character_mus",
	PrefabName = "MUS_23_chuangzaozhishen",
	SkinName = "3",
	PrefabScale = 50,
	HPBarHeight = 135,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2050, Gain = 410},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4265] =
{
	Id = 4265,
	Name = "史莱姆大王",
	Rarity = 4,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "初级金币池收集度100%的冒险者才能获得的特殊角色。遇到什么都会“啊呜”一口吞到肚子里的史莱姆大王，身体里面有大量不知道从哪里捡来的东西，似乎也有不少人员情报。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPDraw_01_SlimeKing",
	PrefabBundle = "character_sp",
	PrefabName = "SPDraw_01_SlimeKing",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 585, Gain = 117},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4266] =
{
	Id = 4266,
	Name = "精灵王子",
	Rarity = 4,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "中级金币池收集度100%的冒险者才能获得的特殊角色。精灵国王子，酷爱外星饮料，常驻不夜城酒吧。为了支付高昂的饮料费，最近似乎也在进行人员情报的交易。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPDraw_02_ElvenPrince",
	PrefabBundle = "character_sp",
	PrefabName = "SPDraw_02_ElvenPrince",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 585, Gain = 117},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4267] =
{
	Id = 4267,
	Name = "玉璧女王",
	Rarity = 4,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "玉璧奖池收集度100%的冒险者才能获得的特殊角色。玉璧女王常年在不夜城中进行人员情报的交易，不过在收取费用后，只给买家一点素材作为回报。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPDraw_03_DiamondQueen",
	PrefabBundle = "character_sp",
	PrefabName = "SPDraw_03_DiamondQueen",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 585, Gain = 117},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4268] =
{
	Id = 4268,
	Name = "外卖小鸽",
	Rarity = 3,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "非常喜欢结伴出游的鸟类，不过到了约定当天总是会接到Ta的各种表示无法如约的电话。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	IconName = "NPC_gugu1",
	PrefabBundle = "character_npc",
	PrefabName = "NPC_gugu1",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1633, Gain = 327},
		{Value = 200002, Base = 29, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4269] =
{
	Id = 4269,
	Name = "小红帽",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "喜欢阅读童话故事的少女，常常穿着红色的斗篷和裙子，还挎着一只木篮。但木篮子里装的究竟是什么，似乎没有人知道答案。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPBUS_06_xiaohongmao",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_06_xiaohongmao",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1840, Gain = 368},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4270] =
{
	Id = 4270,
	Name = "猫眼厨娘",
	Rarity = 5,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "温泉别墅的老板，几年前依靠“网红+餐饮”的经营模式走上了致富之路。有一双猫一般的眼睛，喜欢温泉、美食、旅行和聊天。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPBUS_25_MaoYanChuNiang",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_25_MaoYanChuNiang",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2050, Gain = 410},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4271] =
{
	Id = 4271,
	Name = "温泉鉴赏家",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "猫眼厨娘的男友，职业是温泉鉴赏家、旅游博主、探店达人，自称高水平“水评家”。常说自己有骨骼病，原因是“总泡在温泉里，被泡成了软骨头”。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPBUS_26_WenQuanJianShanJia",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_26_WenQuanJianShanJia",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2050, Gain = 410},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4272] =
{
	Id = 4272,
	Name = "冰冰杆",
	Rarity = 4,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "在风吹日晒下伫立一根栏杆，从不旷工缺席，但每到冬季就会冬眠，冰雪是她的保护层。\n听说她的表面是甜的，但用舌头去舔的话，会发生非常不好的事情。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_BingBingGang",
	PrefabBundle = "character_enemy",
	PrefabName = "All_BingBingGang",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1840, Gain = 368},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4273] =
{
	Id = 4273,
	Name = "刘磺先生",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "在温泉别墅中打工的硫磺皂，多亏了他的无私奉献，温泉中才会有硫磺的味道。不过这是一份非常辛苦的工作，因此，温泉成为了刘先生第一不喜欢的东西。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_LiuHuangXianSheng",
	PrefabBundle = "character_enemy",
	PrefabName = "All_LiuHuangXianSheng",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1840, Gain = 368},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4274] =
{
	Id = 4274,
	Name = "针不戳",
	Rarity = 4,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "织布工具人，但织出来的作品往往和手艺人脑中的不同，这都是因为针不戳有他自己的想法。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_ZhenBuChuo",
	PrefabBundle = "character_enemy",
	PrefabName = "All_ZhenBuChuo",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1464, Gain = 293},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4275] =
{
	Id = 4275,
	Name = "药剂包",
	Rarity = 4,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "在温泉别墅中打工的药剂包，姓药，昵称包包，也是一位勤勤恳恳的打工人。有人对他的味道欲罢不能，但也有人对这味道嗤之以鼻。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_YaoJiBao",
	PrefabBundle = "character_enemy",
	PrefabName = "All_YaoJiBao",
	PrefabScale = 50,
	HPBarHeight = 120,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1840, Gain = 368},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4276] =
{
	Id = 4276,
	Name = "思诺曼",
	Rarity = 4,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "断耳熊的朋友，依靠寒冷与冰雪生存，冬季时会来到山底和朋友玩耍，在其他季节只能孤独地呆在山顶。在断耳熊的陪伴下，二人一起度过了许多美好的夜晚。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SPBUS_31_SiNuoMan",
	PrefabBundle = "character_sp",
	PrefabName = "SPBUS_31_SiNuoMan",
	SkinName = "1",
	PrefabScale = 50,
	HPBarHeight = 125,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1840, Gain = 368},
		{Value = 200002, Base = 33, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id4277] =
{
	Id = 4277,
	Name = "小火球",
	Rarity = 4,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "数据证明，百分之九十九的冒险家无法分清不同的小火球。\n它从岩浆里跳了起来，它掉了下去。\n它的兄弟从岩浆里跳了起来。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Fireball",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Fireball",
	PrefabScale = 50,
	HPBarHeight = 76,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1464, Gain = 293},
		{Value = 200002, Base = 26, Gain = 6},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
