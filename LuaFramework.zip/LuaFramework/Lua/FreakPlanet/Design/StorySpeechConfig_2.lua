
StorySpeechConfig[StorySpeechID.Id30700101] =
{
	Id = 30700101,
	CharName = "呜呜",
	Text = "（死死抱住鸡腿）不要拿走我的鸡腿喵！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 30700102,
}
StorySpeechConfig[StorySpeechID.Id30700102] =
{
	Id = 30700102,
	CharName = "村长",
	Text = "哇，这只小橘猫怎么力气这么大？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye",
	NextID = 30700103,
}
StorySpeechConfig[StorySpeechID.Id30700103] =
{
	Id = 30700103,
	CharName = "剑士",
	Text = "村长，我来帮忙！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 30700104,
}
StorySpeechConfig[StorySpeechID.Id30700104] =
{
	Id = 30700104,
	CharName = "漆漆",
	Text = "……呜呜，不要抢了喵，不交出鸡腿不能报名星际冒险节了喵。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_gugu",
	NextID = 30700105,
}
StorySpeechConfig[StorySpeechID.Id30700105] =
{
	Id = 30700105,
	CharName = "呜呜",
	Text = "不要！这些鸡腿都是呜呜的喵！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 30700106,
}
StorySpeechConfig[StorySpeechID.Id30700106] =
{
	Id = 30700106,
	CharName = "漆漆",
	Text = "我们的首要任务是完成图鉴收集喵~参加星际冒险节才能更好地收集当地情报喵~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_gugu",
	NextID = 30700107,
}
StorySpeechConfig[StorySpeechID.Id30700107] =
{
	Id = 30700107,
	CharName = "呜呜",
	Text = "不喵！修复图鉴太苦了喵，呜呜不想修复图鉴了喵！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 30700108,
}
StorySpeechConfig[StorySpeechID.Id30700108] =
{
	Id = 30700108,
	CharName = "漆漆",
	Text = "如果不修好图鉴，我们就不能回去了喵……而且就一直吃不到小鱼干了喵……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_gugu",
	NextID = 30700109,
}
StorySpeechConfig[StorySpeechID.Id30700109] =
{
	Id = 30700109,
	CharName = "呜呜",
	Text = "（松手，理一理身上的毛）喵……那算了喵……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 30700110,
}
StorySpeechConfig[StorySpeechID.Id30700110] =
{
	Id = 30700110,
	CharName = "村长",
	Text = "呼，终于抢过来了，感觉我这把老骨头都快散掉了。好了，那么提交了这个就算正式报名了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye",
	NextID = 30700111,
}
StorySpeechConfig[StorySpeechID.Id30700111] =
{
	Id = 30700111,
	CharName = "剑士",
	Text = "村长，这次的星际冒险节的挑战内容是什么？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 30700112,
}
StorySpeechConfig[StorySpeechID.Id30700112] =
{
	Id = 30700112,
	CharName = "村长",
	Text = "我查一下。“只要找到传说中的宝箱怪并击败它，就能得到大量玉璧奖励！”",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye",
	NextID = 30700113,
}
StorySpeechConfig[StorySpeechID.Id30700113] =
{
	Id = 30700113,
	CharName = "剑士",
	Text = "宝箱怪吗？野生的似乎很久没见到了呢，应该只会在特定地点出现吧？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 30700114,
}
StorySpeechConfig[StorySpeechID.Id30700114] =
{
	Id = 30700114,
	CharName = "魔法师",
	Text = "根据《魔典》的记载，最早的宝箱怪是由于魔法平原的能量而被赋予生命的，我们可以从那里开始寻找！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_06_mofashi",
	NextID = 30700115,
}
StorySpeechConfig[StorySpeechID.Id30700115] =
{
	Id = 30700115,
	CharName = "村长",
	Text = "好，那我们这就出发！喂，小猫，别难过了，到时候拿到节日奖励鸡腿可以随便买呢！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye",
	NextID = 30700116,
}
StorySpeechConfig[StorySpeechID.Id30700116] =
{
	Id = 30700116,
	CharName = "呜呜",
	Text = "喵喵喵~不气了喵~~快点出发喵~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_wuwu",
}
StorySpeechConfig[StorySpeechID.Id30700401] =
{
	Id = 30700401,
	CharName = "村长",
	Text = "呼，找了这么久，完全没有发现啊！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye",
	NextID = 30700402,
}
StorySpeechConfig[StorySpeechID.Id30700402] =
{
	Id = 30700402,
	CharName = "魔法师",
	Text = "已经到了法阵中心了，虽然能感觉到魔法波动，但是完全没有发现宝箱的踪迹。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_06_mofashi",
	NextID = 30700403,
}
StorySpeechConfig[StorySpeechID.Id30700403] =
{
	Id = 30700403,
	CharName = "呜呜",
	Text = "（东逛逛，西逛逛，忽然间刨土）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 30700404,
}
StorySpeechConfig[StorySpeechID.Id30700404] =
{
	Id = 30700404,
	CharName = "村长",
	Text = "诶！你们看，小橘猫在刨土了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye",
	NextID = 30700405,
}
StorySpeechConfig[StorySpeechID.Id30700405] =
{
	Id = 30700405,
	CharName = "剑士",
	Text = "会不会只是在磨爪子？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 30700406,
}
StorySpeechConfig[StorySpeechID.Id30700406] =
{
	Id = 30700406,
	CharName = "呜呜",
	Text = "喵？！（爪子挖到了硬的东西）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_wuwu",
	NextID = 30700407,
}
StorySpeechConfig[StorySpeechID.Id30700407] =
{
	Id = 30700407,
	CharName = "剑士",
	Text = "哇，那不是宝箱吗！这下发财了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 30700408,
}
StorySpeechConfig[StorySpeechID.Id30700408] =
{
	Id = 30700408,
	CharName = "魔法师",
	Text = "小心，那些宝箱怪就是通过其外表引诱冒险者靠近，然后吃掉他们的！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_06_mofashi",
	NextID = 30700409,
}
StorySpeechConfig[StorySpeechID.Id30700409] =
{
	Id = 30700409,
	CharName = "木制宝箱怪",
	Text = "啊呜！（突然窜出地面，一口咬住剑士的头）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_NormalChest",
	NextID = 30700410,
}
StorySpeechConfig[StorySpeechID.Id30700410] =
{
	Id = 30700410,
	CharName = "剑士",
	Text = "（把头从宝箱里拔出来）唔……竟然敢暗算我！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
}
StorySpeechConfig[StorySpeechID.Id30700601] =
{
	Id = 30700601,
	CharName = "剑士",
	Text = "这下老实了吧？有本事你再咬我呀！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 30700602,
}
StorySpeechConfig[StorySpeechID.Id30700602] =
{
	Id = 30700602,
	CharName = "木制宝箱怪",
	Text = "啊呜！（突然窜起来，又一口咬住剑士的头）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_NormalChest",
	NextID = 30700603,
}
StorySpeechConfig[StorySpeechID.Id30700603] =
{
	Id = 30700603,
	CharName = "剑士",
	Text = "……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 30700604,
}
StorySpeechConfig[StorySpeechID.Id30700604] =
{
	Id = 30700604,
	CharName = "魔法师",
	Text = "（帮剑士把头拔出来）似乎还没有完成节日挑战呢，应该还有更高级的宝箱怪，我们还得继续寻找！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_06_mofashi",
	NextID = 30700605,
}
StorySpeechConfig[StorySpeechID.Id30700605] =
{
	Id = 30700605,
	CharName = "村长",
	Text = "但是更高级的宝箱怪在哪里呢？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye",
	NextID = 30700606,
}
StorySpeechConfig[StorySpeechID.Id30700606] =
{
	Id = 30700606,
	CharName = "魔法师",
	Text = "我想要从这些木制宝箱怪身上找线索了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_06_mofashi",
}
StorySpeechConfig[StorySpeechID.Id30700701] =
{
	Id = 30700701,
	CharName = "村长",
	Text = "哇，宝箱怪掉了好多宝物啊~~这下我们是不是发财了？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye",
	NextID = 30700702,
}
StorySpeechConfig[StorySpeechID.Id30700702] =
{
	Id = 30700702,
	CharName = "魔法师",
	Text = "根据《魔典》的记载，宝箱怪的掉落物其实只是它的内脏……属于湿垃圾，只有特定爱好的人才会收集……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_06_mofashi",
	NextID = 30700703,
}
StorySpeechConfig[StorySpeechID.Id30700703] =
{
	Id = 30700703,
	CharName = "村长",
	Text = "呕……太过分了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye",
	NextID = 30700704,
}
StorySpeechConfig[StorySpeechID.Id30700704] =
{
	Id = 30700704,
	CharName = "剑士",
	Text = "那，我们现在能找到更高级的宝箱怪了吗，魔法师？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 30700705,
}
StorySpeechConfig[StorySpeechID.Id30700705] =
{
	Id = 30700705,
	CharName = "魔法师",
	Text = "有了这些宝箱怪的掉落物，我就可以施展召唤术了！你们离远一点，等等可能会有个很厉害的宝箱怪突然出现噢！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_06_mofashi",
	NextID = 30700706,
}
StorySpeechConfig[StorySpeechID.Id30700706] =
{
	Id = 30700706,
	CharName = "村长",
	Text = "（躲得超远）好，好，你也小心。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye",
	NextID = 30700707,
}
StorySpeechConfig[StorySpeechID.Id30700707] =
{
	Id = 30700707,
	CharName = "剑士",
	Text = "（躲得超远）等会一定要给那个怪物一点颜色瞧瞧~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 30700708,
}
StorySpeechConfig[StorySpeechID.Id30700708] =
{
	Id = 30700708,
	CharName = "呜呜",
	Text = "（躲得超远）喵~喵~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_wuwu",
}
StorySpeechConfig[StorySpeechID.Id30700801] =
{
	Id = 30700801,
	CharName = "村长",
	Text = "呼，连稀有宝箱也成功击败了呢~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye",
	NextID = 30700802,
}
StorySpeechConfig[StorySpeechID.Id30700802] =
{
	Id = 30700802,
	CharName = "剑士",
	Text = "哇~领了玉璧，可以去不夜城好好消费一下呢~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 30700803,
}
StorySpeechConfig[StorySpeechID.Id30700803] =
{
	Id = 30700803,
	CharName = "魔法师",
	Text = "（面色凝重）似乎还有更高级的宝箱怪……不过应该是最后一只了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_06_mofashi",
	NextID = 30700804,
}
StorySpeechConfig[StorySpeechID.Id30700804] =
{
	Id = 30700804,
	CharName = "剑士",
	Text = "（震惊）！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 30700805,
}
StorySpeechConfig[StorySpeechID.Id30700805] =
{
	Id = 30700805,
	CharName = "魔法师",
	Text = "必须打败更多的稀有宝箱怪，我才能感应到这只宝箱怪的所在。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_06_mofashi",
	NextID = 30700806,
}
StorySpeechConfig[StorySpeechID.Id30700806] =
{
	Id = 30700806,
	CharName = "村长",
	Text = "（震惊）！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye",
	NextID = 30700807,
}
StorySpeechConfig[StorySpeechID.Id30700807] =
{
	Id = 30700807,
	CharName = "魔法师",
	Text = "不过按照《魔典》记载，这只宝箱怪喜食橘色小猫，如果用橘色小猫做饵，就能很快找到它！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_06_mofashi",
	NextID = 30700808,
}
StorySpeechConfig[StorySpeechID.Id30700808] =
{
	Id = 30700808,
	CharName = "呜呜",
	Text = "（震惊）！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_wuwu",
}
StorySpeechConfig[StorySpeechID.Id30700901] =
{
	Id = 30700901,
	CharName = "魔法师",
	Text = "已经击败了传奇宝箱怪了，离节日任务只差最后一步了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_06_mofashi",
	NextID = 30700902,
}
StorySpeechConfig[StorySpeechID.Id30700902] =
{
	Id = 30700902,
	CharName = "村长",
	Text = "既然只差最后一步了！那么大家努力吧！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye",
	NextID = 30700903,
}
StorySpeechConfig[StorySpeechID.Id30700903] =
{
	Id = 30700903,
	CharName = "魔法师",
	Text = "只要向星际冒险节的活动组委会交纳一定数量的传奇宝箱掉落就可以领取最终大奖！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_06_mofashi",
}
StorySpeechConfig[StorySpeechID.Id30701001] =
{
	Id = 30701001,
	CharName = "呜呜",
	Text = "哇~~终于把任务都完成了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 30701002,
}
StorySpeechConfig[StorySpeechID.Id30701002] =
{
	Id = 30701002,
	CharName = "魔法师",
	Text = "我们好像是本星球第一名噢~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_06_mofashi",
	NextID = 30701003,
}
StorySpeechConfig[StorySpeechID.Id30701003] =
{
	Id = 30701003,
	CharName = "剑士",
	Text = "在本人的带领下，我们队伍成为最优秀的冒险队也是理所当然的事情。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 30701004,
}
StorySpeechConfig[StorySpeechID.Id30701004] =
{
	Id = 30701004,
	CharName = "村长",
	Text = "年轻人不要那么容易骄傲，要我说，还是因为在过程中本村长给出了相当有价值的意见。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye",
	NextID = 30701005,
}
StorySpeechConfig[StorySpeechID.Id30701005] =
{
	Id = 30701005,
	CharName = "居民NPC",
	Text = "（其实我觉得，连橘猫的贡献都比村长大人和剑士大人的大……）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_09_putongcunmin",
}
StorySpeechConfig[StorySpeechID.Id62002101] =
{
	Id = 62002101,
	CharName = "村长",
	Text = "唉，这次的任务是集邮，要根据地图去9个地点盖章，集满后才能兑换超级大礼包……怎么又是个体力活……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye",
	NextID = 62002102,
}
StorySpeechConfig[StorySpeechID.Id62002102] =
{
	Id = 62002102,
	CharName = "剑士",
	Text = "（星星眼）超级大礼包？那是啥？！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62002103,
}
StorySpeechConfig[StorySpeechID.Id62002103] =
{
	Id = 62002103,
	CharName = "村长",
	Text = "据说是一份出乎意料的神秘大礼。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye",
	NextID = 62002104,
}
StorySpeechConfig[StorySpeechID.Id62002104] =
{
	Id = 62002104,
	CharName = "剑士",
	Text = "神秘大礼！（兴奋）那我们可一定得拿到……啊，第一个集邮点到了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62002105,
}
StorySpeechConfig[StorySpeechID.Id62002105] =
{
	Id = 62002105,
	CharName = "山谷商人",
	Text = "你们好，我来给盖个章——好嘞！我们这里除了盖章呢，还出售本次山谷探险贵宾级徒步登山鞋，山谷特制拐杖，只要108万金币，各位瞧一瞧看一看？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_14_lvxingshangren",
	NextID = 62002106,
}
StorySpeechConfig[StorySpeechID.Id62002106] =
{
	Id = 62002106,
	CharName = "剑士",
	Text = "不用了，我们不需要……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62002107,
}
StorySpeechConfig[StorySpeechID.Id62002107] =
{
	Id = 62002107,
	CharName = "山谷商人",
	Text = "别走啊，您再看看？还有其他商品，山谷特制饮料，包你打怪回血速度提升350%，我们还有特殊的摄影服务，540万金币，买不了吃亏……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_14_lvxingshangren",
}
StorySpeechConfig[StorySpeechID.Id62002201] =
{
	Id = 62002201,
	CharName = "叶姬",
	Text = "你们一个都逃不掉，来吧。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_01_yeji",
	NextID = 62002202,
}
StorySpeechConfig[StorySpeechID.Id62002202] =
{
	Id = 62002202,
	CharName = "村长",
	Text = "我，我不喝……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye",
	NextID = 62002203,
}
StorySpeechConfig[StorySpeechID.Id62002203] =
{
	Id = 62002203,
	CharName = "剑士",
	Text = "不行，你一定得喝，为了我们的神秘大礼，拜托了！！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62002204,
}
StorySpeechConfig[StorySpeechID.Id62002204] =
{
	Id = 62002204,
	CharName = "叶姬",
	Text = "这一杯是你的，剑士先生。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_01_yeji",
	NextID = 62002205,
}
StorySpeechConfig[StorySpeechID.Id62002205] =
{
	Id = 62002205,
	CharName = "剑士",
	Text = "（捏住鼻子）咕噜咕噜……啊！救命，好苦——呕！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62002206,
}
StorySpeechConfig[StorySpeechID.Id62002206] =
{
	Id = 62002206,
	CharName = "叶姬",
	Text = "呀！你别倒在我的小店门口呀，这样别人还怎么来呀？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_01_yeji",
	NextID = 62002207,
}
StorySpeechConfig[StorySpeechID.Id62002207] =
{
	Id = 62002207,
	CharName = "剑士",
	Text = "我错了——！叶姬小姐——呕！对不起，别，别打我……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
}
StorySpeechConfig[StorySpeechID.Id62002301] =
{
	Id = 62002301,
	CharName = "剑士",
	Text = "您好，麻烦给我们盖……（被推倒）啊！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62002302,
}
StorySpeechConfig[StorySpeechID.Id62002302] =
{
	Id = 62002302,
	CharName = "寻宝者",
	Text = "快点儿，我们赶时间呢，给我们队盖个章。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_09_putongcunmin_cos10",
	NextID = 62002303,
}
StorySpeechConfig[StorySpeechID.Id62002303] =
{
	Id = 62002303,
	CharName = "剑士",
	Text = "你们怎么插队啊？！是我先排到的，先给我们盖！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62002304,
}
StorySpeechConfig[StorySpeechID.Id62002304] =
{
	Id = 62002304,
	CharName = "寻宝者",
	Text = "哟，现在不是我排在你前边儿吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_09_putongcunmin_cos10",
	NextID = 62002305,
}
StorySpeechConfig[StorySpeechID.Id62002305] =
{
	Id = 62002305,
	CharName = "木制宝箱怪",
	Text = "（安抚）啊，大家别吵，别吵，人人有份嘛……我给两位都盖上，好不好？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_NormalChest",
	NextID = 62002306,
}
StorySpeechConfig[StorySpeechID.Id62002306] =
{
	Id = 62002306,
	CharName = "剑士",
	Text = "凭什么？你应该让他去后面排队！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62002307,
}
StorySpeechConfig[StorySpeechID.Id62002307] =
{
	Id = 62002307,
	CharName = "寻宝者",
	Text = "小伙子，我建议你见好就收……（收好手册）嘿嘿，去下一个地方喽！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_09_putongcunmin_cos10",
	NextID = 62002308,
}
StorySpeechConfig[StorySpeechID.Id62002308] =
{
	Id = 62002308,
	CharName = "剑士",
	Text = "……（越想越气）你这是在助纣为虐！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62002309,
}
StorySpeechConfig[StorySpeechID.Id62002309] =
{
	Id = 62002309,
	CharName = "木制宝箱怪",
	Text = "？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_NormalChest",
	NextID = 62002310,
}
StorySpeechConfig[StorySpeechID.Id62002310] =
{
	Id = 62002310,
	CharName = "剑士",
	Text = "……（暴怒）气死我了！！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62002311,
}
StorySpeechConfig[StorySpeechID.Id62002311] =
{
	Id = 62002311,
	CharName = "木制宝箱怪",
	Text = "莫生气，莫生气，气出病来无人替……啊！好疼！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_NormalChest",
}
StorySpeechConfig[StorySpeechID.Id62002401] =
{
	Id = 62002401,
	CharName = "剑士",
	Text = "背一位女孩子绕行一圈，这还不简单？放着我来！魔法师，你……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62002402,
}
StorySpeechConfig[StorySpeechID.Id62002402] =
{
	Id = 62002402,
	CharName = "魔法师",
	Text = "（瞪）……不可能。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_06_mofashi",
	NextID = 62002403,
}
StorySpeechConfig[StorySpeechID.Id62002403] =
{
	Id = 62002403,
	CharName = "呜呜",
	Text = "喵呜！（漆漆我来背你喵~）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 62002404,
}
StorySpeechConfig[StorySpeechID.Id62002404] =
{
	Id = 62002404,
	CharName = "漆漆",
	Text = "喵！（不可以的喵，只能男孩子背女孩子的喵！）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_gugu",
	NextID = 62002405,
}
StorySpeechConfig[StorySpeechID.Id62002405] =
{
	Id = 62002405,
	CharName = "剑士",
	Text = "或许……（看向村长）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62002406,
}
StorySpeechConfig[StorySpeechID.Id62002406] =
{
	Id = 62002406,
	CharName = "龙骑士",
	Text = "交给我吧，你们别忘了，我可是龙骑士！（打响指）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_25_longqishi",
	NextID = 62002407,
}
StorySpeechConfig[StorySpeechID.Id62002407] =
{
	Id = 62002407,
	CharName = "黑龙王子",
	Text = "到了嗷！快到我身上来嗷！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_23_long",
	NextID = 62002408,
}
StorySpeechConfig[StorySpeechID.Id62002408] =
{
	Id = 62002408,
	CharName = "龙骑士",
	Text = "走！（火速绕行一圈）完成！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_25_longqishi",
	NextID = 62002409,
}
StorySpeechConfig[StorySpeechID.Id62002409] =
{
	Id = 62002409,
	CharName = "工作人员",
	Text = "（挠头）龙骑士骑龙……怎么感觉怪怪的？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_men2",
	NextID = 62002410,
}
StorySpeechConfig[StorySpeechID.Id62002410] =
{
	Id = 62002410,
	CharName = "黑龙王子",
	Text = "你怎么还不给我们盖章，唬！！我要打你了嗷！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_23_long",
}
StorySpeechConfig[StorySpeechID.Id62002501] =
{
	Id = 62002501,
	CharName = "剑士",
	Text = "我来！红鲤鱼与绿捋驴与&*￥%……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62002502,
}
StorySpeechConfig[StorySpeechID.Id62002502] =
{
	Id = 62002502,
	CharName = "村长",
	Text = "哈哈哈哈……你不太行啊，我来！刘奶奶与牛奶奶爱喝刘年刘奶。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye",
	NextID = 62002503,
}
StorySpeechConfig[StorySpeechID.Id62002503] =
{
	Id = 62002503,
	CharName = "粉色史莱姆",
	Text = "……念错了，不算。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_Slime_Pink",
	NextID = 62002504,
}
StorySpeechConfig[StorySpeechID.Id62002504] =
{
	Id = 62002504,
	CharName = "猎人",
	Text = "板担宽，扁凳长……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_16_lieren",
	NextID = 62002505,
}
StorySpeechConfig[StorySpeechID.Id62002505] =
{
	Id = 62002505,
	CharName = "粉色史莱姆",
	Text = "不用再念了，一开始就说错了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_Slime_Pink",
	NextID = 62002506,
}
StorySpeechConfig[StorySpeechID.Id62002506] =
{
	Id = 62002506,
	CharName = "魔法师",
	Text = "八百标兵奔北坡。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_06_mofashi",
	NextID = 62002507,
}
StorySpeechConfig[StorySpeechID.Id62002507] =
{
	Id = 62002507,
	CharName = "粉色史莱姆",
	Text = "不行，不够完整。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_Slime_Pink",
	NextID = 62002508,
}
StorySpeechConfig[StorySpeechID.Id62002508] =
{
	Id = 62002508,
	CharName = "魔法师",
	Text = "炮兵并排北边跑。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_06_mofashi",
	NextID = 62002509,
}
StorySpeechConfig[StorySpeechID.Id62002509] =
{
	Id = 62002509,
	CharName = "剑士",
	Text = "我们答出来了，快给我们盖章！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
}
StorySpeechConfig[StorySpeechID.Id62002601] =
{
	Id = 62002601,
	CharName = "稀有宝箱怪",
	Text = "石头剪刀布！哦哦！啊，新来的小队，如果你们能赢过我，我就给你们盖章！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_RareChest",
	NextID = 62002602,
}
StorySpeechConfig[StorySpeechID.Id62002602] =
{
	Id = 62002602,
	CharName = "剑士",
	Text = "真的？这么简单？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62002603,
}
StorySpeechConfig[StorySpeechID.Id62002603] =
{
	Id = 62002603,
	CharName = "魔法师",
	Text = "（思考）小心有诈。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_06_mofashi",
	NextID = 62002604,
}
StorySpeechConfig[StorySpeechID.Id62002604] =
{
	Id = 62002604,
	CharName = "稀有宝箱怪",
	Text = "没有诈没有诈，为了公平起见，你把手放进我的箱子里，对，就是这样……然后我们合上盖子，等二人都比划好了之后，再打开箱子看胜负……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_RareChest",
	NextID = 62002605,
}
StorySpeechConfig[StorySpeechID.Id62002605] =
{
	Id = 62002605,
	CharName = "剑士",
	Text = "唔，能避免临时变手势的情况，似乎很公平啊……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62002606,
}
StorySpeechConfig[StorySpeechID.Id62002606] =
{
	Id = 62002606,
	CharName = "剑士",
	Text = "（连输十把之后）啊！可恶！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62002607,
}
StorySpeechConfig[StorySpeechID.Id62002607] =
{
	Id = 62002607,
	CharName = "魔法师",
	Text = "你没发现吗，虽然你把手放在箱子里，但这个家伙，完全能看到你比划的是什么啊……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_06_mofashi",
	NextID = 62002608,
}
StorySpeechConfig[StorySpeechID.Id62002608] =
{
	Id = 62002608,
	CharName = "剑士",
	Text = "对哦！！！我被骗了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
}
StorySpeechConfig[StorySpeechID.Id62002701] =
{
	Id = 62002701,
	CharName = "剑士",
	Text = "这些家伙又黏又滑，怎么夹啊。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62002702,
}
StorySpeechConfig[StorySpeechID.Id62002702] =
{
	Id = 62002702,
	CharName = "村长夫人",
	Text = "这种事情，就是要耐心……诶你看，我夹住了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_18_laonainai",
	NextID = 62002703,
}
StorySpeechConfig[StorySpeechID.Id62002703] =
{
	Id = 62002703,
	CharName = "金色史莱姆",
	Text = "嘿嘿！我要转一转~！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_Slime_Gold",
	NextID = 62002704,
}
StorySpeechConfig[StorySpeechID.Id62002704] =
{
	Id = 62002704,
	CharName = "村长夫人",
	Text = "（啪叽）啊！又掉了……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_18_laonainai",
	NextID = 62002705,
}
StorySpeechConfig[StorySpeechID.Id62002705] =
{
	Id = 62002705,
	CharName = "剑士",
	Text = "这种游戏，分明就是在为难我们……而且这些史莱姆，根本不配合我们啊！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62002706,
}
StorySpeechConfig[StorySpeechID.Id62002706] =
{
	Id = 62002706,
	CharName = "魔法师",
	Text = "不如诉诸武力吧，把它们打晕，就不会捣蛋了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_06_mofashi",
	NextID = 62002707,
}
StorySpeechConfig[StorySpeechID.Id62002707] =
{
	Id = 62002707,
	CharName = "金色史莱姆",
	Text = "？！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_Slime_Gold",
	NextID = 62002708,
}
StorySpeechConfig[StorySpeechID.Id62002708] =
{
	Id = 62002708,
	CharName = "剑士",
	Text = "有道理！（拍）啪——！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
}
StorySpeechConfig[StorySpeechID.Id62002801] =
{
	Id = 62002801,
	CharName = "紫色史莱姆",
	Text = "唔——头顶好挤啊——",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_Slime_purple",
	NextID = 62002802,
}
StorySpeechConfig[StorySpeechID.Id62002802] =
{
	Id = 62002802,
	CharName = "剑士",
	Text = "能不能别动呀，我们好不容易堆到了十八层……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62002803,
}
StorySpeechConfig[StorySpeechID.Id62002803] =
{
	Id = 62002803,
	CharName = "紫色史莱姆",
	Text = "扭一扭，欧耶！（啪——）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_Slime_purple",
	NextID = 62002804,
}
StorySpeechConfig[StorySpeechID.Id62002804] =
{
	Id = 62002804,
	CharName = "剑士",
	Text = "又倒了……再来吧。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62002805,
}
StorySpeechConfig[StorySpeechID.Id62002805] =
{
	Id = 62002805,
	CharName = "红色史莱姆",
	Text = "喂！下面的，你的头顶一直在刮我屁股，好疼！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_Slime_red",
	NextID = 62002806,
}
StorySpeechConfig[StorySpeechID.Id62002806] =
{
	Id = 62002806,
	CharName = "绿色史莱姆",
	Text = "我的屁股也很痒！（向下看）喂，你注意一点啊，哦哦！别戳我那里！（啪——）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_Slime_green",
	NextID = 62002807,
}
StorySpeechConfig[StorySpeechID.Id62002807] =
{
	Id = 62002807,
	CharName = "剑士",
	Text = "……我已经堆95次了，你们能不能配合一点啊！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62002808,
}
StorySpeechConfig[StorySpeechID.Id62002808] =
{
	Id = 62002808,
	CharName = "魔法师",
	Text = "你们再乱动，我就用魔法把你们冻起来。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_06_mofashi",
	NextID = 62002809,
}
StorySpeechConfig[StorySpeechID.Id62002809] =
{
	Id = 62002809,
	CharName = "三层史莱姆",
	Text = "她要让我们动起来诶，哈哈……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_Slime_blue",
	NextID = 62002810,
}
StorySpeechConfig[StorySpeechID.Id62002810] =
{
	Id = 62002810,
	CharName = "魔法师",
	Text = "（念咒）冰系魔法！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_06_mofashi",
}
StorySpeechConfig[StorySpeechID.Id62002901] =
{
	Id = 62002901,
	CharName = "魔法师",
	Text = "……我无法参与，我不知道有什么好笑的故事。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_06_mofashi",
	NextID = 62002902,
}
StorySpeechConfig[StorySpeechID.Id62002902] =
{
	Id = 62002902,
	CharName = "剑士",
	Text = "我来试试！啊这个……有一天，一个穷人问苍天",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62002903,
}
StorySpeechConfig[StorySpeechID.Id62002903] =
{
	Id = 62002903,
	CharName = "传奇宝箱怪",
	Text = "？？？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_EpicChest",
	NextID = 62002904,
}
StorySpeechConfig[StorySpeechID.Id62002904] =
{
	Id = 62002904,
	CharName = "村长",
	Text = "……这个笑话，连我们也笑不出来。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye",
	NextID = 62002905,
}
StorySpeechConfig[StorySpeechID.Id62002905] =
{
	Id = 62002905,
	CharName = "剑士",
	Text = "那我再换一个！有一天，一位老农在地里锄地，一只鸟飞过，并洒下几滴鸟屎，老农抬头大骂",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62002906,
}
StorySpeechConfig[StorySpeechID.Id62002906] =
{
	Id = 62002906,
	CharName = "村长",
	Text = "哈哈哈哈！这个好笑……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye",
	NextID = 62002907,
}
StorySpeechConfig[StorySpeechID.Id62002907] =
{
	Id = 62002907,
	CharName = "魔法师",
	Text = "……（面无表情）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_06_mofashi",
	NextID = 62002908,
}
StorySpeechConfig[StorySpeechID.Id62002908] =
{
	Id = 62002908,
	CharName = "传奇宝箱怪",
	Text = "……（面无表情）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_EpicChest",
	NextID = 62002909,
}
StorySpeechConfig[StorySpeechID.Id62002909] =
{
	Id = 62002909,
	CharName = "剑士",
	Text = "他怎么都不笑啊……不如我们直接动手！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62002910,
}
StorySpeechConfig[StorySpeechID.Id62002910] =
{
	Id = 62002910,
	CharName = "魔法师",
	Text = "算了，交给我吧！羽毛笔，变！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_06_mofashi",
	NextID = 62002911,
}
StorySpeechConfig[StorySpeechID.Id62002911] =
{
	Id = 62002911,
	CharName = "传奇宝箱怪",
	Text = "啊哈哈哈哈！别拿羽毛挠我痒痒！你们犯规了……哈哈哈！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_EpicChest",
}
StorySpeechConfig[StorySpeechID.Id62003001] =
{
	Id = 62003001,
	CharName = "剑士",
	Text = "耶！集齐印章，可以兑换奖品喽！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62003002,
}
StorySpeechConfig[StorySpeechID.Id62003002] =
{
	Id = 62003002,
	CharName = "协会秘书",
	Text = "恭喜你们，这是各位的奖品。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_13_lvshi_cos10",
	NextID = 62003003,
}
StorySpeechConfig[StorySpeechID.Id62003003] =
{
	Id = 62003003,
	CharName = "剑士",
	Text = "（拆开）让我好好看看，所谓的神秘大礼到底是什么……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62003004,
}
StorySpeechConfig[StorySpeechID.Id62003004] =
{
	Id = 62003004,
	CharName = "呜呜",
	Text = "喵！！（小鱼干喵！！）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_wuwu",
	NextID = 62003005,
}
StorySpeechConfig[StorySpeechID.Id62003005] =
{
	Id = 62003005,
	CharName = "剑士",
	Text = "拼夕夕……9.999折购物券？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62003006,
}
StorySpeechConfig[StorySpeechID.Id62003006] =
{
	Id = 62003006,
	CharName = "村长",
	Text = "9.999折……（暴怒）我拼了老命去集邮，好不容易换来的东西，结果你们的礼物，就这？就这？！我和你们拼了！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye",
	NextID = 62003007,
}
StorySpeechConfig[StorySpeechID.Id62003007] =
{
	Id = 62003007,
	CharName = "协会秘书",
	Text = "啊，您别激动，啊——！！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_13_lvshi_cos10",
}
StorySpeechConfig[StorySpeechID.Id62000101] =
{
	Id = 62000101,
	CharName = "剑士",
	Text = "今天的任务完成了，耶！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62000102,
}
StorySpeechConfig[StorySpeechID.Id62000102] =
{
	Id = 62000102,
	CharName = "协会的同伴",
	Text = "（痛苦）……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi_cos10",
	NextID = 62000103,
}
StorySpeechConfig[StorySpeechID.Id62000103] =
{
	Id = 62000103,
	CharName = "剑士",
	Text = "辛苦了一年，今天一定要早点回去休息！顺便整理一下，这次需要带回家的行李……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62000104,
}
StorySpeechConfig[StorySpeechID.Id62000104] =
{
	Id = 62000104,
	CharName = "协会的同伴",
	Text = "（痛苦）可恶，这怪物血条好长……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi_cos10",
	NextID = 62000105,
}
StorySpeechConfig[StorySpeechID.Id62000105] =
{
	Id = 62000105,
	CharName = "剑士",
	Text = "咦？你还没有结束吗！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62000106,
}
StorySpeechConfig[StorySpeechID.Id62000106] =
{
	Id = 62000106,
	CharName = "协会的同伴",
	Text = "（斜眼）……我是自愿加班的，下班是不可能的，这辈子都不可能下班的，呜呜呜……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi_cos10",
	NextID = 62000107,
}
StorySpeechConfig[StorySpeechID.Id62000107] =
{
	Id = 62000107,
	CharName = "剑士",
	Text = "（叹气）既然这样，我先走了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62000108,
}
StorySpeechConfig[StorySpeechID.Id62000108] =
{
	Id = 62000108,
	CharName = "协会的同伴",
	Text = "？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi_cos10",
	NextID = 62000109,
}
StorySpeechConfig[StorySpeechID.Id62000109] =
{
	Id = 62000109,
	CharName = "协会的同伴",
	Text = "那个……我们是好兄弟吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi_cos10",
	NextID = 62000110,
}
StorySpeechConfig[StorySpeechID.Id62000110] =
{
	Id = 62000110,
	CharName = "剑士",
	Text = "嗯？你说什么？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62000111,
}
StorySpeechConfig[StorySpeechID.Id62000111] =
{
	Id = 62000111,
	CharName = "协会的同伴",
	Text = "是兄弟的话，就来一起加班？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi_cos10",
	NextID = 62000112,
}
StorySpeechConfig[StorySpeechID.Id62000112] =
{
	Id = 62000112,
	CharName = "剑士",
	Text = "可是我的工作都做完了，没有怪物可以打……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62000113,
}
StorySpeechConfig[StorySpeechID.Id62000113] =
{
	Id = 62000113,
	CharName = "协会的同伴",
	Text = "怪物就像海绵里的水，挤挤就有了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi_cos10",
	NextID = 62000114,
}
StorySpeechConfig[StorySpeechID.Id62000114] =
{
	Id = 62000114,
	CharName = "剑士",
	Text = "？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62000115,
}
StorySpeechConfig[StorySpeechID.Id62000115] =
{
	Id = 62000115,
	CharName = "协会的同伴",
	Text = "你同意了？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi_cos10",
	NextID = 62000116,
}
StorySpeechConfig[StorySpeechID.Id62000116] =
{
	Id = 62000116,
	CharName = "剑士",
	Text = "不行，我要下班！回家最要紧！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62000117,
}
StorySpeechConfig[StorySpeechID.Id62000117] =
{
	Id = 62000117,
	CharName = "协会的同伴",
	Text = "不可以——你不可以走——",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi_cos10",
}
StorySpeechConfig[StorySpeechID.Id62000201] =
{
	Id = 62000201,
	CharName = "剑士",
	Text = "报告师父！今年我去了很多星球冒险，打败了很多奇形怪状的怪物！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62000202,
}
StorySpeechConfig[StorySpeechID.Id62000202] =
{
	Id = 62000202,
	CharName = "剑术大师",
	Text = "……嗯。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_16_lieren_cos10",
	NextID = 62000203,
}
StorySpeechConfig[StorySpeechID.Id62000203] =
{
	Id = 62000203,
	CharName = "剑士",
	Text = "我在魔法平原打败了67338个石巨人，在溪谷打败了32457只狼王，在大沼泽打败了12345只紫色史莱姆……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62000204,
}
StorySpeechConfig[StorySpeechID.Id62000204] =
{
	Id = 62000204,
	CharName = "剑术大师",
	Text = "……还有呢？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_16_lieren_cos10",
	NextID = 62000205,
}
StorySpeechConfig[StorySpeechID.Id62000205] =
{
	Id = 62000205,
	CharName = "剑士",
	Text = "我击败了弓箭手、猎人、骨头兵……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62000206,
}
StorySpeechConfig[StorySpeechID.Id62000206] =
{
	Id = 62000206,
	CharName = "剑术大师",
	Text = "……还有呢？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_16_lieren_cos10",
	NextID = 62000207,
}
StorySpeechConfig[StorySpeechID.Id62000207] =
{
	Id = 62000207,
	CharName = "剑士",
	Text = "我还击败了大名鼎鼎的小魔王！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62000208,
}
StorySpeechConfig[StorySpeechID.Id62000208] =
{
	Id = 62000208,
	CharName = "剑术大师",
	Text = "……就这些？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_16_lieren_cos10",
	NextID = 62000209,
}
StorySpeechConfig[StorySpeechID.Id62000209] =
{
	Id = 62000209,
	CharName = "剑士",
	Text = "就，就……我还明白了很多新的道理！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62000210,
}
StorySpeechConfig[StorySpeechID.Id62000210] =
{
	Id = 62000210,
	CharName = "剑术大师",
	Text = "嗯？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_16_lieren_cos10",
	NextID = 62000211,
}
StorySpeechConfig[StorySpeechID.Id62000211] =
{
	Id = 62000211,
	CharName = "剑士",
	Text = "以前，只要师父批评我，我就会很不开心，觉得师父太严格了……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62000212,
}
StorySpeechConfig[StorySpeechID.Id62000212] =
{
	Id = 62000212,
	CharName = "剑士",
	Text = "但是，现在我明白了，这是师父对我的教导……师父对我最好了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62000213,
}
StorySpeechConfig[StorySpeechID.Id62000213] =
{
	Id = 62000213,
	CharName = "剑术大师",
	Text = "……行了，拿出你的剑，和我打一场吧。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_16_lieren_cos10",
	NextID = 62000214,
}
StorySpeechConfig[StorySpeechID.Id62000214] =
{
	Id = 62000214,
	CharName = "剑士",
	Text = "什么？？和您打？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62000215,
}
StorySpeechConfig[StorySpeechID.Id62000215] =
{
	Id = 62000215,
	CharName = "剑术大师",
	Text = "如果能打赢我，这次年末考核，就算你小子合格。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_16_lieren_cos10",
	NextID = 62000216,
}
StorySpeechConfig[StorySpeechID.Id62000216] =
{
	Id = 62000216,
	CharName = "剑士",
	Text = "啊？只是合格啊？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62000217,
}
StorySpeechConfig[StorySpeechID.Id62000217] =
{
	Id = 62000217,
	CharName = "剑术大师",
	Text = "哪来那么多废话，看剑！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_16_lieren_cos10",
}
StorySpeechConfig[StorySpeechID.Id62000301] =
{
	Id = 62000301,
	CharName = "黑奖池摊主",
	Text = "高级海鲜酱，快来尝一尝，鸡腿纷享桶，不花钱白送——",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_01_SlimeKing",
	NextID = 62000302,
}
StorySpeechConfig[StorySpeechID.Id62000302] =
{
	Id = 62000302,
	CharName = "剑士",
	Text = "老板，全家桶怎么卖？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62000303,
}
StorySpeechConfig[StorySpeechID.Id62000303] =
{
	Id = 62000303,
	CharName = "黑奖池摊主",
	Text = "哟，小伙子，这是打算给家里带点儿特产吧？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_01_SlimeKing",
	NextID = 62000304,
}
StorySpeechConfig[StorySpeechID.Id62000304] =
{
	Id = 62000304,
	CharName = "剑士",
	Text = "哈哈，是啊……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62000305,
}
StorySpeechConfig[StorySpeechID.Id62000305] =
{
	Id = 62000305,
	CharName = "黑奖池摊主",
	Text = "那可得多带几桶啊，最好带个好几箱，那看着才像话不是？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_01_SlimeKing",
	NextID = 62000306,
}
StorySpeechConfig[StorySpeechID.Id62000306] =
{
	Id = 62000306,
	CharName = "剑士",
	Text = "（思考）……确实，多少钱一箱啊？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62000307,
}
StorySpeechConfig[StorySpeechID.Id62000307] =
{
	Id = 62000307,
	CharName = "黑奖池摊主",
	Text = "不夜城的规矩您还不懂啊？咱不买，就看抽，赌的就是个运气！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_01_SlimeKing",
	NextID = 62000308,
}
StorySpeechConfig[StorySpeechID.Id62000308] =
{
	Id = 62000308,
	CharName = "剑士",
	Text = "怎……怎么说？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62000309,
}
StorySpeechConfig[StorySpeechID.Id62000309] =
{
	Id = 62000309,
	CharName = "黑奖池摊主",
	Text = "您看啊，5400玉璧能抽十次，十次里总得中个好几次吧？您就放心大胆地抽，抽到您满意为止……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_01_SlimeKing",
	NextID = 62000310,
}
StorySpeechConfig[StorySpeechID.Id62000310] =
{
	Id = 62000310,
	CharName = "剑士",
	Text = "可如果我啥都抽不出来……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62000311,
}
StorySpeechConfig[StorySpeechID.Id62000311] =
{
	Id = 62000311,
	CharName = "黑奖池摊主",
	Text = "不会的，我们的抽奖是出了名的良心，童叟无欺！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_01_SlimeKing",
	NextID = 62000312,
}
StorySpeechConfig[StorySpeechID.Id62000312] =
{
	Id = 62000312,
	CharName = "剑士",
	Text = "那我试试吧……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62000313,
}
StorySpeechConfig[StorySpeechID.Id62000313] =
{
	Id = 62000313,
	CharName = "剑士",
	Text = "老板，我已经花了108000个玉璧，怎么就抽出了两个桶？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62000314,
}
StorySpeechConfig[StorySpeechID.Id62000314] =
{
	Id = 62000314,
	CharName = "黑奖池摊主",
	Text = "啊这，这个……抽奖这个事儿吧，它就是高风险高回报，您都花了这么多了，不如再多花一点，说不定就抽到了呢？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_01_SlimeKing",
	NextID = 62000315,
}
StorySpeechConfig[StorySpeechID.Id62000315] =
{
	Id = 62000315,
	CharName = "剑士",
	Text = "嗯，你说得也有道理……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62000316,
}
StorySpeechConfig[StorySpeechID.Id62000316] =
{
	Id = 62000316,
	CharName = "黑奖池摊主",
	Text = "（看向酋长）他再这么抽下去，你的位子可就坐不稳了啊...",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_01_SlimeKing",
	NextID = 62000317,
}
StorySpeechConfig[StorySpeechID.Id62000317] =
{
	Id = 62000317,
	CharName = "酋长",
	Text = "（叹气）或许这就是，溪谷后浪推前浪吧。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPDraw_04_UnlockChief",
	NextID = 62000318,
}
StorySpeechConfig[StorySpeechID.Id62000318] =
{
	Id = 62000318,
	CharName = "剑士",
	Text = "……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62000319,
}
StorySpeechConfig[StorySpeechID.Id62000319] =
{
	Id = 62000319,
	CharName = "剑士",
	Text = "（怒气值拉满）抽了100次，就这几个……还不如我自己做！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
}
StorySpeechConfig[StorySpeechID.Id62000401] =
{
	Id = 62000401,
	CharName = "村长",
	Text = "哦，动静这么大，原来是你来了啊。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye",
	NextID = 62000402,
}
StorySpeechConfig[StorySpeechID.Id62000402] =
{
	Id = 62000402,
	CharName = "剑士",
	Text = "（大声）村长！！我来向你，告个别！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62000403,
}
StorySpeechConfig[StorySpeechID.Id62000403] =
{
	Id = 62000403,
	CharName = "村长",
	Text = "哎哟我这耳朵……你说啥？打个结？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye",
	NextID = 62000404,
}
StorySpeechConfig[StorySpeechID.Id62000404] =
{
	Id = 62000404,
	CharName = "剑士",
	Text = "我说——我要回家啦！这几天不做任务啦，明年再见！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62000405,
}
StorySpeechConfig[StorySpeechID.Id62000405] =
{
	Id = 62000405,
	CharName = "村长",
	Text = "啊？不回家啦？要任务？好事啊，好事……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye",
	NextID = 62000406,
}
StorySpeechConfig[StorySpeechID.Id62000406] =
{
	Id = 62000406,
	CharName = "剑士",
	Text = "我要走了！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62000407,
}
StorySpeechConfig[StorySpeechID.Id62000407] =
{
	Id = 62000407,
	CharName = "村长",
	Text = "我来看看啊，有没有什么过年任务给你……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye",
	NextID = 62000408,
}
StorySpeechConfig[StorySpeechID.Id62000408] =
{
	Id = 62000408,
	CharName = "剑士",
	Text = "（大声）老——村——长！！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62000409,
}
StorySpeechConfig[StorySpeechID.Id62000409] =
{
	Id = 62000409,
	CharName = "村长",
	Text = "哦哟哟，年轻人嗓门儿别那么大啊……耳膜都要裂开喽……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye",
	NextID = 62000410,
}
StorySpeechConfig[StorySpeechID.Id62000410] =
{
	Id = 62000410,
	CharName = "剑士",
	Text = "果然村长才是最没用的！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62000411,
}
StorySpeechConfig[StorySpeechID.Id62000411] =
{
	Id = 62000411,
	CharName = "村长",
	Text = "年纪大喽，耳朵也不中用了……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye",
	NextID = 62000412,
}
StorySpeechConfig[StorySpeechID.Id62000412] =
{
	Id = 62000412,
	CharName = "剑士",
	Text = "（抽出大宝剑）那我来帮你恢复一下听觉吧。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62000413,
}
StorySpeechConfig[StorySpeechID.Id62000413] =
{
	Id = 62000413,
	CharName = "村长",
	Text = "刚刚啊，我这听觉，一下子就恢复了……你说神奇不神奇？大千世界，无奇不有啊，哈哈。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye",
	NextID = 62000414,
}
StorySpeechConfig[StorySpeechID.Id62000414] =
{
	Id = 62000414,
	CharName = "村长",
	Text = "哎你，你不要乱来啊……啊啊啊啊！！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye",
}
StorySpeechConfig[StorySpeechID.Id62000501] =
{
	Id = 62000501,
	CharName = "会说话的大树怪",
	Text = "嗝——站住！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_dashu",
	NextID = 62000502,
}
StorySpeechConfig[StorySpeechID.Id62000502] =
{
	Id = 62000502,
	CharName = "剑士",
	Text = "嗯……？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62000503,
}
StorySpeechConfig[StorySpeechID.Id62000503] =
{
	Id = 62000503,
	CharName = "会说话的大树怪",
	Text = "此路是我开，此树是……（左顾右盼）是我，嗝。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_dashu",
	NextID = 62000504,
}
StorySpeechConfig[StorySpeechID.Id62000504] =
{
	Id = 62000504,
	CharName = "剑士",
	Text = "（愣住）。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62000505,
}
StorySpeechConfig[StorySpeechID.Id62000505] =
{
	Id = 62000505,
	CharName = "会说话的大树怪",
	Text = "看你形色匆匆的样子，是要回家吧？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_dashu",
	NextID = 62000506,
}
StorySpeechConfig[StorySpeechID.Id62000506] =
{
	Id = 62000506,
	CharName = "会说话的大树怪",
	Text = "（叹气）看来，你还没看到最新颁布的星球公约啊……嗝。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_dashu",
	NextID = 62000507,
}
StorySpeechConfig[StorySpeechID.Id62000507] =
{
	Id = 62000507,
	CharName = "剑士",
	Text = "什么公约？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62000508,
}
StorySpeechConfig[StorySpeechID.Id62000508] =
{
	Id = 62000508,
	CharName = "会说话的大树怪",
	Text = "几周前，宇宙因不明原因出现黑洞，嗝，星际空间的磁场受到了巨大影响……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_dashu",
	NextID = 62000509,
}
StorySpeechConfig[StorySpeechID.Id62000509] =
{
	Id = 62000509,
	CharName = "会说话的大树怪",
	Text = "因此，多家公会发布联合公约，只有身强体壮的勇士，嗝，才能登上飞船，遨游星际。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_dashu",
	NextID = 62000510,
}
StorySpeechConfig[StorySpeechID.Id62000510] =
{
	Id = 62000510,
	CharName = "剑士",
	Text = "（小声）我怎么从来没听说过……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62000511,
}
StorySpeechConfig[StorySpeechID.Id62000511] =
{
	Id = 62000511,
	CharName = "会说话的大树怪",
	Text = "哈哈哈嗝，小伙子，平时只顾着玩儿，不听新闻不看报吧？嗝。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_dashu",
	NextID = 62000512,
}
StorySpeechConfig[StorySpeechID.Id62000512] =
{
	Id = 62000512,
	CharName = "剑士",
	Text = "那么，怎么证明我是身强体壮的勇士呢？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62000513,
}
StorySpeechConfig[StorySpeechID.Id62000513] =
{
	Id = 62000513,
	CharName = "会说话的大树怪",
	Text = "嗯……让我想想……嗝。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_dashu",
	NextID = 62000514,
}
StorySpeechConfig[StorySpeechID.Id62000514] =
{
	Id = 62000514,
	CharName = "剑士",
	Text = "（灵光一闪）嘿嘿……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62000515,
}
StorySpeechConfig[StorySpeechID.Id62000515] =
{
	Id = 62000515,
	CharName = "会说话的大树怪",
	Text = "你，难道打算，嗝……不行！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_dashu",
	NextID = 62000516,
}
StorySpeechConfig[StorySpeechID.Id62000516] =
{
	Id = 62000516,
	CharName = "会说话的大树怪",
	Text = "我才吃了三碗大便当，不能去战斗……啊啊啊——呕！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_dashu",
}
StorySpeechConfig[StorySpeechID.Id62000601] =
{
	Id = 62000601,
	CharName = "剑士",
	Text = "（喜悦）小……小牧师？！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62000602,
}
StorySpeechConfig[StorySpeechID.Id62000602] =
{
	Id = 62000602,
	CharName = "牧师",
	Text = "（面露难色）……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_07_mushi",
	NextID = 62000603,
}
StorySpeechConfig[StorySpeechID.Id62000603] =
{
	Id = 62000603,
	CharName = "剑士",
	Text = "真没想到，你也在这里！这样我们就可以一起回家了！好耶！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62000604,
}
StorySpeechConfig[StorySpeechID.Id62000604] =
{
	Id = 62000604,
	CharName = "牧师",
	Text = "（拦住去路）！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_07_mushi",
	NextID = 62000605,
}
StorySpeechConfig[StorySpeechID.Id62000605] =
{
	Id = 62000605,
	CharName = "剑士",
	Text = "哎，你这是……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62000606,
}
StorySpeechConfig[StorySpeechID.Id62000606] =
{
	Id = 62000606,
	CharName = "牧师",
	Text = "（摇头）抱歉，你们无法登上星际飞船。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_07_mushi",
	NextID = 62000607,
}
StorySpeechConfig[StorySpeechID.Id62000607] =
{
	Id = 62000607,
	CharName = "剑士",
	Text = "（愣住）什么？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62000608,
}
StorySpeechConfig[StorySpeechID.Id62000608] =
{
	Id = 62000608,
	CharName = "路人地精",
	Text = "你凭啥不让我们回家！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_14_lvxingshangren",
	NextID = 62000609,
}
StorySpeechConfig[StorySpeechID.Id62000609] =
{
	Id = 62000609,
	CharName = "路人魔族",
	Text = "就，就就，就……是！麻，麻溜给小爷滚，滚开！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 62000610,
}
StorySpeechConfig[StorySpeechID.Id62000610] =
{
	Id = 62000610,
	CharName = "牧师",
	Text = "只有身强体壮的勇士，才能遨游星际，在紊乱的磁场中存活下来。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_07_mushi",
	NextID = 62000611,
}
StorySpeechConfig[StorySpeechID.Id62000611] =
{
	Id = 62000611,
	CharName = "剑士",
	Text = "（小声）原来，树精说的是真的……啊，不该揍他的。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62000612,
}
StorySpeechConfig[StorySpeechID.Id62000612] =
{
	Id = 62000612,
	CharName = "路人地精",
	Text = "（露出腹肌）小姑娘，你看我这，够结实不？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_14_lvxingshangren",
	NextID = 62000613,
}
StorySpeechConfig[StorySpeechID.Id62000613] =
{
	Id = 62000613,
	CharName = "路人魔族",
	Text = "（露出肱二头肌）小，小姑娘，我二，二，二头肌……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 62000614,
}
StorySpeechConfig[StorySpeechID.Id62000614] =
{
	Id = 62000614,
	CharName = "牧师",
	Text = "（面无表情）几头鸡都不行，只有出示星际医院的检测报告，我才能让你们通过。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_07_mushi",
	NextID = 62000615,
}
StorySpeechConfig[StorySpeechID.Id62000615] =
{
	Id = 62000615,
	CharName = "路人地精",
	Text = "开什么玩笑？那你不早说？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_14_lvxingshangren",
	NextID = 62000616,
}
StorySpeechConfig[StorySpeechID.Id62000616] =
{
	Id = 62000616,
	CharName = "路人魔族",
	Text = "哪，哪那么麻烦，我们直接撞，撞……撞开她，往，往前冲……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_13_dashouxiaodi",
	NextID = 62000617,
}
StorySpeechConfig[StorySpeechID.Id62000617] =
{
	Id = 62000617,
	CharName = "路人地精",
	Text = "说的也是，就凭你，还拦得住我们？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_14_lvxingshangren",
	NextID = 62000618,
}
StorySpeechConfig[StorySpeechID.Id62000618] =
{
	Id = 62000618,
	CharName = "牧师",
	Text = "！！你们——",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_07_mushi",
	NextID = 62000619,
}
StorySpeechConfig[StorySpeechID.Id62000619] =
{
	Id = 62000619,
	CharName = "剑士",
	Text = "住手！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
}
StorySpeechConfig[StorySpeechID.Id62000701] =
{
	Id = 62000701,
	CharName = "护士",
	Text = "249号！进去检测！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_07_mushi_cos20",
	NextID = 62000702,
}
StorySpeechConfig[StorySpeechID.Id62000702] =
{
	Id = 62000702,
	CharName = "协会的同伴A",
	Text = "来了来了，嘿嘿，排了一上午，可算轮到我了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi_cos10",
	NextID = 62000703,
}
StorySpeechConfig[StorySpeechID.Id62000703] =
{
	Id = 62000703,
	CharName = "剑士",
	Text = "（羡慕的眼神）……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62000704,
}
StorySpeechConfig[StorySpeechID.Id62000704] =
{
	Id = 62000704,
	CharName = "护士",
	Text = "250号！进去检测！有没有人是250号？250？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_07_mushi_cos20",
	NextID = 62000705,
}
StorySpeechConfig[StorySpeechID.Id62000705] =
{
	Id = 62000705,
	CharName = "协会的同伴B",
	Text = "在在在！是我，我是250！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_16_lieren_cos10",
	NextID = 62000706,
}
StorySpeechConfig[StorySpeechID.Id62000706] =
{
	Id = 62000706,
	CharName = "剑士",
	Text = "（羡慕的眼神）……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62000707,
}
StorySpeechConfig[StorySpeechID.Id62000707] =
{
	Id = 62000707,
	CharName = "护士",
	Text = "251号！251号！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_07_mushi_cos20",
	NextID = 62000708,
}
StorySpeechConfig[StorySpeechID.Id62000708] =
{
	Id = 62000708,
	CharName = "剑士",
	Text = "（羡慕的眼神）什么时候才轮到2021号啊……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62000709,
}
StorySpeechConfig[StorySpeechID.Id62000709] =
{
	Id = 62000709,
	CharName = "协会的同伴A",
	Text = "做完了，哦耶！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi_cos10",
	NextID = 62000710,
}
StorySpeechConfig[StorySpeechID.Id62000710] =
{
	Id = 62000710,
	CharName = "协会的同伴B",
	Text = "没想到还挺快，让我做几个萝卜蹲就结束了……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_16_lieren_cos10",
	NextID = 62000711,
}
StorySpeechConfig[StorySpeechID.Id62000711] =
{
	Id = 62000711,
	CharName = "协会的同伴A",
	Text = "什么？你只是做几个简单动作？？？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi_cos10",
	NextID = 62000712,
}
StorySpeechConfig[StorySpeechID.Id62000712] =
{
	Id = 62000712,
	CharName = "协会的同伴B",
	Text = "对啊，毕竟只是抽查一下大腿肌……你呢，你抽查到什么了？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_16_lieren_cos10",
	NextID = 62000713,
}
StorySpeechConfig[StorySpeechID.Id62000713] =
{
	Id = 62000713,
	CharName = "协会的同伴A",
	Text = "可恶！！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi_cos10",
	NextID = 62000714,
}
StorySpeechConfig[StorySpeechID.Id62000714] =
{
	Id = 62000714,
	CharName = "协会的同伴B",
	Text = "？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_16_lieren_cos10",
	NextID = 62000715,
}
StorySpeechConfig[StorySpeechID.Id62000715] =
{
	Id = 62000715,
	CharName = "协会的同伴A",
	Text = "（悲伤）为什么我被抽到了臀肌检测啊——",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi_cos10",
	NextID = 62000716,
}
StorySpeechConfig[StorySpeechID.Id62000716] =
{
	Id = 62000716,
	CharName = "协会的同伴B",
	Text = "哦！！原来，在隔壁科室撅着屁股检查的那个人……就是你啊！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_16_lieren_cos10",
	NextID = 62000717,
}
StorySpeechConfig[StorySpeechID.Id62000717] =
{
	Id = 62000717,
	CharName = "剑士",
	Text = "噗——哈哈哈哈！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62000718,
}
StorySpeechConfig[StorySpeechID.Id62000718] =
{
	Id = 62000718,
	CharName = "协会的同伴A",
	Text = "？！你笑什么！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi_cos10",
	NextID = 62000719,
}
StorySpeechConfig[StorySpeechID.Id62000719] =
{
	Id = 62000719,
	CharName = "剑士",
	Text = "没有……我，我受过专业训练，一般不会笑……除非忍不住。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62000720,
}
StorySpeechConfig[StorySpeechID.Id62000720] =
{
	Id = 62000720,
	CharName = "协会的同伴A",
	Text = "你、说、什、么？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi_cos10",
}
StorySpeechConfig[StorySpeechID.Id62000801] =
{
	Id = 62000801,
	CharName = "剑士",
	Text = "（沮丧）哎，回不了家了……啊！疼疼疼——",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62000802,
}
StorySpeechConfig[StorySpeechID.Id62000802] =
{
	Id = 62000802,
	CharName = "被盯上的路人",
	Text = "（惊）！！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_28_heiyiren",
	NextID = 62000803,
}
StorySpeechConfig[StorySpeechID.Id62000803] =
{
	Id = 62000803,
	CharName = "剑士",
	Text = "别跑！你看，你把我的行李撞了一地，快给我捡起来！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62000804,
}
StorySpeechConfig[StorySpeechID.Id62000804] =
{
	Id = 62000804,
	CharName = "律师",
	Text = "（气喘吁吁）你，你给我站、站住——",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_13_lvshi",
	NextID = 62000805,
}
StorySpeechConfig[StorySpeechID.Id62000805] =
{
	Id = 62000805,
	CharName = "被盯上的路人",
	Text = "（手足无措）……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_28_heiyiren",
	NextID = 62000806,
}
StorySpeechConfig[StorySpeechID.Id62000806] =
{
	Id = 62000806,
	CharName = "剑士",
	Text = "这是怎么回事？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62000807,
}
StorySpeechConfig[StorySpeechID.Id62000807] =
{
	Id = 62000807,
	CharName = "被盯上的路人",
	Text = "大哥，我只是去庭审现场作个证，这律师就说我有问题，要把我抓起来……我冤枉啊！！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_28_heiyiren",
	NextID = 62000808,
}
StorySpeechConfig[StorySpeechID.Id62000808] =
{
	Id = 62000808,
	CharName = "律师",
	Text = "（冷笑）哼，上了证人席还想跑？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_13_lvshi",
	NextID = 62000809,
}
StorySpeechConfig[StorySpeechID.Id62000809] =
{
	Id = 62000809,
	CharName = "剑士",
	Text = "（疑惑）你怎么就这么肯定，他是案件的凶手？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62000810,
}
StorySpeechConfig[StorySpeechID.Id62000810] =
{
	Id = 62000810,
	CharName = "律师",
	Text = "哼，我的前辈告诉过我，真正的凶手，有99%的概率藏在证人之中！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_13_lvshi",
	NextID = 62000811,
}
StorySpeechConfig[StorySpeechID.Id62000811] =
{
	Id = 62000811,
	CharName = "律师",
	Text = "尤其这个案件，只有你一个证人，所以，你一定就是凶手！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_13_lvshi",
	NextID = 62000812,
}
StorySpeechConfig[StorySpeechID.Id62000812] =
{
	Id = 62000812,
	CharName = "被盯上的路人",
	Text = "？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_28_heiyiren",
	NextID = 62000813,
}
StorySpeechConfig[StorySpeechID.Id62000813] =
{
	Id = 62000813,
	CharName = "剑士",
	Text = "那个……律师朋友，您先冷静冷静……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
}
StorySpeechConfig[StorySpeechID.Id62000901] =
{
	Id = 62000901,
	CharName = "剑士",
	Text = "（拨通电话）喂？妈妈！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62000902,
}
StorySpeechConfig[StorySpeechID.Id62000902] =
{
	Id = 62000902,
	CharName = "剑士的妈妈",
	Text = "哟，儿子！一年到尾也不见你打个电话，今天终于知道联系家里人了啊，孩子他爸，快来！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_mama1",
	NextID = 62000903,
}
StorySpeechConfig[StorySpeechID.Id62000903] =
{
	Id = 62000903,
	CharName = "剑士的爸爸",
	Text = "嗯，你打算什么时候回来？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_baba1",
	NextID = 62000904,
}
StorySpeechConfig[StorySpeechID.Id62000904] =
{
	Id = 62000904,
	CharName = "剑士",
	Text = "我，我今年……不回来了……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62000905,
}
StorySpeechConfig[StorySpeechID.Id62000905] =
{
	Id = 62000905,
	CharName = "剑士的妈妈",
	Text = "什么？！！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_mama1",
	NextID = 62000906,
}
StorySpeechConfig[StorySpeechID.Id62000906] =
{
	Id = 62000906,
	CharName = "剑士",
	Text = "我没有拿到星际医院的检测报告，没办法登上飞船……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62000907,
}
StorySpeechConfig[StorySpeechID.Id62000907] =
{
	Id = 62000907,
	CharName = "剑士的妈妈",
	Text = "不行，你必须回来。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_mama1",
	NextID = 62000908,
}
StorySpeechConfig[StorySpeechID.Id62000908] =
{
	Id = 62000908,
	CharName = "剑士",
	Text = "（无奈）我也想回家，可现在……这不是没办法吗……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62000909,
}
StorySpeechConfig[StorySpeechID.Id62000909] =
{
	Id = 62000909,
	CharName = "剑士的妈妈",
	Text = "总能想出办法的，新春佳节，不就是团圆的日子吗？你必须回来，知道吗？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_mama1",
	NextID = 62000910,
}
StorySpeechConfig[StorySpeechID.Id62000910] =
{
	Id = 62000910,
	CharName = "剑士",
	Text = "（沉默）……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62000911,
}
StorySpeechConfig[StorySpeechID.Id62000911] =
{
	Id = 62000911,
	CharName = "剑士的妈妈",
	Text = "怎么，你那个什么公会……不让你走？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_mama1",
	NextID = 62000912,
}
StorySpeechConfig[StorySpeechID.Id62000912] =
{
	Id = 62000912,
	CharName = "剑士",
	Text = "（无奈）不是，不是公会的事……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62000913,
}
StorySpeechConfig[StorySpeechID.Id62000913] =
{
	Id = 62000913,
	CharName = "剑士的妈妈",
	Text = "那你就必须回来！自己早点起床去医院做检测，做完拿上报告就回家。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_mama1",
	NextID = 62000914,
}
StorySpeechConfig[StorySpeechID.Id62000914] =
{
	Id = 62000914,
	CharName = "剑士",
	Text = "？？？不是……医院有排号……等轮到我，春节都过完了！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62000915,
}
StorySpeechConfig[StorySpeechID.Id62000915] =
{
	Id = 62000915,
	CharName = "剑士的妈妈",
	Text = "那就换家医院，总之你自己想想办法，必须回来。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_mama1",
	NextID = 62000916,
}
StorySpeechConfig[StorySpeechID.Id62000916] =
{
	Id = 62000916,
	CharName = "剑士的妈妈",
	Text = "记住了啊，挂了！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_mama1",
	NextID = 62000917,
}
StorySpeechConfig[StorySpeechID.Id62000917] =
{
	Id = 62000917,
	CharName = "剑士",
	Text = "（抓狂）救命！！！怎么才能说服我妈啊！！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62000918,
}
StorySpeechConfig[StorySpeechID.Id62000918] =
{
	Id = 62000918,
	CharName = "剑士",
	Text = "（一看手机）什么！！！已使用话费10800000金币，设备已停机！！怎么会这样！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
}
StorySpeechConfig[StorySpeechID.Id62001001] =
{
	Id = 62001001,
	CharName = "魔法师",
	Text = "先说好，春节期间，给我三倍工资。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_06_mofashi",
	NextID = 62001002,
}
StorySpeechConfig[StorySpeechID.Id62001002] =
{
	Id = 62001002,
	CharName = "剑士",
	Text = "你！你这不是狮子大开口么！大家都是朋友，谈钱多庸俗！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62001003,
}
StorySpeechConfig[StorySpeechID.Id62001003] =
{
	Id = 62001003,
	CharName = "魔法师",
	Text = "我只知道，亲兄弟，明算账。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_06_mofashi",
	NextID = 62001004,
}
StorySpeechConfig[StorySpeechID.Id62001004] =
{
	Id = 62001004,
	CharName = "剑士",
	Text = "呜呜呜我好穷啊——！！能分期贷款吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62001005,
}
StorySpeechConfig[StorySpeechID.Id62001005] =
{
	Id = 62001005,
	CharName = "魔法师",
	Text = "你想拖欠工资？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_06_mofashi",
	NextID = 62001006,
}
StorySpeechConfig[StorySpeechID.Id62001006] =
{
	Id = 62001006,
	CharName = "剑士",
	Text = "不不不我没有……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62001007,
}
StorySpeechConfig[StorySpeechID.Id62001007] =
{
	Id = 62001007,
	CharName = "魔法师",
	Text = "（开始写字）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_06_mofashi",
	NextID = 62001008,
}
StorySpeechConfig[StorySpeechID.Id62001008] =
{
	Id = 62001008,
	CharName = "剑士",
	Text = "嗯？你在写什么！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62001009,
}
StorySpeechConfig[StorySpeechID.Id62001009] =
{
	Id = 62001009,
	CharName = "魔法师",
	Text = "欠条。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_06_mofashi",
	NextID = 62001010,
}
StorySpeechConfig[StorySpeechID.Id62001010] =
{
	Id = 62001010,
	CharName = "剑士",
	Text = "你！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62001011,
}
StorySpeechConfig[StorySpeechID.Id62001011] =
{
	Id = 62001011,
	CharName = "剑士",
	Text = "（惊恐）我的天！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62001012,
}
StorySpeechConfig[StorySpeechID.Id62001012] =
{
	Id = 62001012,
	CharName = "魔法师",
	Text = "嗯？你怎么了？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_06_mofashi",
	NextID = 62001013,
}
StorySpeechConfig[StorySpeechID.Id62001013] =
{
	Id = 62001013,
	CharName = "剑士",
	Text = "刚刚我看到……家里有霸格！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62001014,
}
StorySpeechConfig[StorySpeechID.Id62001014] =
{
	Id = 62001014,
	CharName = "魔法师",
	Text = "八哥？看不出来，你这附近还有鸟？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_06_mofashi",
	NextID = 62001015,
}
StorySpeechConfig[StorySpeechID.Id62001015] =
{
	Id = 62001015,
	CharName = "剑士",
	Text = "不是八哥！！是那种在暗处爬来爬去的异虫霸格！！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
}
StorySpeechConfig[StorySpeechID.Id62001101] =
{
	Id = 62001101,
	CharName = "剑士",
	Text = "一副春联、一张福字、还有一些零食……差不多都齐了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62001102,
}
StorySpeechConfig[StorySpeechID.Id62001102] =
{
	Id = 62001102,
	CharName = "剑士",
	Text = "商场真是太吵了……付完钱要赶紧回家。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62001103,
}
StorySpeechConfig[StorySpeechID.Id62001103] =
{
	Id = 62001103,
	CharName = "呐喊家",
	Text = "唔哦哦——过年好——",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_19_nahan",
	NextID = 62001104,
}
StorySpeechConfig[StorySpeechID.Id62001104] =
{
	Id = 62001104,
	CharName = "售货员",
	Text = "您好，一共3473600个金币。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_02_taozi",
	NextID = 62001105,
}
StorySpeechConfig[StorySpeechID.Id62001105] =
{
	Id = 62001105,
	CharName = "剑士",
	Text = "多、多少？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62001106,
}
StorySpeechConfig[StorySpeechID.Id62001106] =
{
	Id = 62001106,
	CharName = "呐喊家",
	Text = "哦哦哦——买年货——好开心——",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_19_nahan",
	NextID = 62001107,
}
StorySpeechConfig[StorySpeechID.Id62001107] =
{
	Id = 62001107,
	CharName = "售货员",
	Text = "3473600个金币，需要包装袋吗？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_02_taozi",
	NextID = 62001108,
}
StorySpeechConfig[StorySpeechID.Id62001108] =
{
	Id = 62001108,
	CharName = "编辑长",
	Text = "（通话中）不行！除夕前一定要写完！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_22_bianji",
	NextID = 62001109,
}
StorySpeechConfig[StorySpeechID.Id62001109] =
{
	Id = 62001109,
	CharName = "编辑长",
	Text = "（怒吼）我已经催了你一个月了！！！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_22_bianji",
	NextID = 62001110,
}
StorySpeechConfig[StorySpeechID.Id62001110] =
{
	Id = 62001110,
	CharName = "剑士",
	Text = "（捂耳朵）……根本听不到售货员在说什么啊！！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62001111,
}
StorySpeechConfig[StorySpeechID.Id62001111] =
{
	Id = 62001111,
	CharName = "呐喊家",
	Text = "唔哦哦——结账啦——",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_19_nahan",
	NextID = 62001112,
}
StorySpeechConfig[StorySpeechID.Id62001112] =
{
	Id = 62001112,
	CharName = "编辑长",
	Text = "（通话中）一个月了你还没有灵感？！！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_22_bianji",
	NextID = 62001113,
}
StorySpeechConfig[StorySpeechID.Id62001113] =
{
	Id = 62001113,
	CharName = "编辑长",
	Text = "那我们春节期间的连载怎么办！！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_22_bianji",
	NextID = 62001114,
}
StorySpeechConfig[StorySpeechID.Id62001114] =
{
	Id = 62001114,
	CharName = "售货员",
	Text = "您需要包装袋吗？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_02_taozi",
	NextID = 62001115,
}
StorySpeechConfig[StorySpeechID.Id62001115] =
{
	Id = 62001115,
	CharName = "剑士",
	Text = "（捂耳朵）啊啊啊吵死啦！！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
}
StorySpeechConfig[StorySpeechID.Id62001201] =
{
	Id = 62001201,
	CharName = "七姑",
	Text = "哎哟，小剑剑啊，听你妈说，你春节不回来了？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_oldwomen1",
	NextID = 62001202,
}
StorySpeechConfig[StorySpeechID.Id62001202] =
{
	Id = 62001202,
	CharName = "剑士",
	Text = "啊，是啊……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62001203,
}
StorySpeechConfig[StorySpeechID.Id62001203] =
{
	Id = 62001203,
	CharName = "八姨",
	Text = "年轻人哪里那么忙？我们今年全家团圆，就差你一个人喽。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_women1",
	NextID = 62001204,
}
StorySpeechConfig[StorySpeechID.Id62001204] =
{
	Id = 62001204,
	CharName = "剑士",
	Text = "（苦笑）啊，这样……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62001205,
}
StorySpeechConfig[StorySpeechID.Id62001205] =
{
	Id = 62001205,
	CharName = "七姑",
	Text = "我就说吧，你爸妈就不该让你去那个什么星……这孩子，完全不着家哪行啊。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_oldwomen1",
	NextID = 62001206,
}
StorySpeechConfig[StorySpeechID.Id62001206] =
{
	Id = 62001206,
	CharName = "剑士",
	Text = "明年，明年一定回去……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62001207,
}
StorySpeechConfig[StorySpeechID.Id62001207] =
{
	Id = 62001207,
	CharName = "八姨",
	Text = "今年我们也不去外面吃饭喽，你妈说，除夕晚上她在家给我们包饺子，呵呵……",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_women1",
	NextID = 62001208,
}
StorySpeechConfig[StorySpeechID.Id62001208] =
{
	Id = 62001208,
	CharName = "七姑",
	Text = "然后我们一块儿看看电视，聊聊天儿。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_oldwomen1",
	NextID = 62001209,
}
StorySpeechConfig[StorySpeechID.Id62001209] =
{
	Id = 62001209,
	CharName = "八姨",
	Text = "你那个表弟也来，小伙子长了不少个儿，也变样儿了，你估摸着都不认识喽……",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_women1",
	NextID = 62001210,
}
StorySpeechConfig[StorySpeechID.Id62001210] =
{
	Id = 62001210,
	CharName = "剑士",
	Text = "（敷衍）啊，这样啊，哈哈……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62001211,
}
StorySpeechConfig[StorySpeechID.Id62001211] =
{
	Id = 62001211,
	CharName = "七姑",
	Text = "啊对，你家里……还放着那些团子娃娃吧？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_oldwomen1",
	NextID = 62001212,
}
StorySpeechConfig[StorySpeechID.Id62001212] =
{
	Id = 62001212,
	CharName = "剑士",
	Text = "啊？你是说……我的史莱姆周边吧……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62001213,
}
StorySpeechConfig[StorySpeechID.Id62001213] =
{
	Id = 62001213,
	CharName = "七姑",
	Text = "对对对，你表弟从小就喜欢那些玩意儿，他刚说啊，想拿几个回去玩。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_oldwomen1",
	NextID = 62001214,
}
StorySpeechConfig[StorySpeechID.Id62001214] =
{
	Id = 62001214,
	CharName = "剑士",
	Text = "？？？我的周边，我那54000玉璧的周边……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62001215,
}
StorySpeechConfig[StorySpeechID.Id62001215] =
{
	Id = 62001215,
	CharName = "八姨",
	Text = "没事儿，他七大姑，小剑剑是做哥哥的，肯定乐意把玩具给弟弟。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_women1",
	NextID = 62001216,
}
StorySpeechConfig[StorySpeechID.Id62001216] =
{
	Id = 62001216,
	CharName = "剑士",
	Text = "（语无伦次）我，那个，那个……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62001217,
}
StorySpeechConfig[StorySpeechID.Id62001217] =
{
	Id = 62001217,
	CharName = "七姑",
	Text = "行，到时候我就直接拿了！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_oldwomen1",
	NextID = 62001218,
}
StorySpeechConfig[StorySpeechID.Id62001218] =
{
	Id = 62001218,
	CharName = "剑士",
	Text = "（黑化）呜——不要抢我的史莱姆！！！啊啊啊啊！！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62001219,
}
StorySpeechConfig[StorySpeechID.Id62001219] =
{
	Id = 62001219,
	CharName = "七姑",
	Text = "（惊）！！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_oldwomen1",
}
StorySpeechConfig[StorySpeechID.Id62001301] =
{
	Id = 62001301,
	CharName = "剑士",
	Text = "好，好，好……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62001302,
}
StorySpeechConfig[StorySpeechID.Id62001302] =
{
	Id = 62001302,
	CharName = "弗兰老板",
	Text = "哎哟客官，您可真有眼力见儿！",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	RightIcon = "Arena_FAT_Pudding",
	NextID = 62001303,
}
StorySpeechConfig[StorySpeechID.Id62001303] =
{
	Id = 62001303,
	CharName = "弗兰老板",
	Text = "我们家的口味啊，在这星球上可是一绝。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	RightIcon = "Arena_FAT_Pudding",
	NextID = 62001304,
}
StorySpeechConfig[StorySpeechID.Id62001304] =
{
	Id = 62001304,
	CharName = "剑士",
	Text = "好，好辣！！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62001305,
}
StorySpeechConfig[StorySpeechID.Id62001305] =
{
	Id = 62001305,
	CharName = "弗兰老板",
	Text = "……",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	RightIcon = "Arena_FAT_Pudding",
	NextID = 62001306,
}
StorySpeechConfig[StorySpeechID.Id62001306] =
{
	Id = 62001306,
	CharName = "剑士",
	Text = "嘶……我，我不是点微辣吗？！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62001307,
}
StorySpeechConfig[StorySpeechID.Id62001307] =
{
	Id = 62001307,
	CharName = "弗兰老板",
	Text = "是微辣啊！客官，您瞧，我一共只放了五滴辣油，嘿嘿。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	RightIcon = "Arena_FAT_Pudding",
	NextID = 62001308,
}
StorySpeechConfig[StorySpeechID.Id62001308] =
{
	Id = 62001308,
	CharName = "剑士",
	Text = "（惊恐）老板，你不是本地人吧？这个辣椒……肯定也不是本地辣椒！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62001309,
}
StorySpeechConfig[StorySpeechID.Id62001309] =
{
	Id = 62001309,
	CharName = "弗兰老板",
	Text = "（搓手）嘿嘿，我老家在一个叫弗兰的村子，不知道您听过没有……",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	RightIcon = "Arena_FAT_Pudding",
	NextID = 62001310,
}
StorySpeechConfig[StorySpeechID.Id62001310] =
{
	Id = 62001310,
	CharName = "剑士",
	Text = "（掀桌）什么？不吃了，换一家！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62001311,
}
StorySpeechConfig[StorySpeechID.Id62001311] =
{
	Id = 62001311,
	CharName = "弗兰老板",
	Text = "那个，客官……方圆百里的馆子都打烊了。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	RightIcon = "Arena_FAT_Pudding",
	NextID = 62001312,
}
StorySpeechConfig[StorySpeechID.Id62001312] =
{
	Id = 62001312,
	CharName = "弗兰老板",
	Text = "只有我家，一直开到现在，嘿嘿……",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	RightIcon = "Arena_FAT_Pudding",
	NextID = 62001313,
}
StorySpeechConfig[StorySpeechID.Id62001313] =
{
	Id = 62001313,
	CharName = "剑士",
	Text = "？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
}
StorySpeechConfig[StorySpeechID.Id62001401] =
{
	Id = 62001401,
	CharName = "魔法师",
	Text = "你以前自己做过菜吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_06_mofashi",
	NextID = 62001402,
}
StorySpeechConfig[StorySpeechID.Id62001402] =
{
	Id = 62001402,
	CharName = "剑士",
	Text = "嘿嘿……做过几次简单的。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62001403,
}
StorySpeechConfig[StorySpeechID.Id62001403] =
{
	Id = 62001403,
	CharName = "魔法师",
	Text = "嗯，我没做过，今天靠你指导了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_06_mofashi",
	NextID = 62001404,
}
StorySpeechConfig[StorySpeechID.Id62001404] =
{
	Id = 62001404,
	CharName = "剑士",
	Text = "（胸有成竹）没问题，包在我身上！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62001405,
}
StorySpeechConfig[StorySpeechID.Id62001405] =
{
	Id = 62001405,
	CharName = "剑士",
	Text = "这个锅里，要加入一升水，煮至沸腾，再将蔬菜放入……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62001406,
}
StorySpeechConfig[StorySpeechID.Id62001406] =
{
	Id = 62001406,
	CharName = "呜呜",
	Text = "喵……（好香……）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 62001407,
}
StorySpeechConfig[StorySpeechID.Id62001407] =
{
	Id = 62001407,
	CharName = "剑士",
	Text = "不能盖锅盖，并且需要不断搅动……你那边还顺利吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62001408,
}
StorySpeechConfig[StorySpeechID.Id62001408] =
{
	Id = 62001408,
	CharName = "魔法师",
	Text = "嗯……那个，好像，熄火了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_06_mofashi",
	NextID = 62001409,
}
StorySpeechConfig[StorySpeechID.Id62001409] =
{
	Id = 62001409,
	CharName = "漆漆",
	Text = "喵？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_gugu",
	NextID = 62001410,
}
StorySpeechConfig[StorySpeechID.Id62001410] =
{
	Id = 62001410,
	CharName = "魔法师",
	Text = "算了，直接用魔法吧……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_06_mofashi",
	NextID = 62001411,
}
StorySpeechConfig[StorySpeechID.Id62001411] =
{
	Id = 62001411,
	CharName = "剑士",
	Text = "（星星眼）对耶，我们有魔法！你好聪明啊！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62001412,
}
StorySpeechConfig[StorySpeechID.Id62001412] =
{
	Id = 62001412,
	CharName = "魔法师",
	Text = "厨房用火的话，只用把力度调小一些就好了……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_06_mofashi",
	NextID = 62001413,
}
StorySpeechConfig[StorySpeechID.Id62001413] =
{
	Id = 62001413,
	CharName = "呜呜",
	Text = "（好奇地玩着煎锅）喵——（好有趣！！）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_wuwu",
	NextID = 62001414,
}
StorySpeechConfig[StorySpeechID.Id62001414] =
{
	Id = 62001414,
	CharName = "魔法师",
	Text = "（叹气）你这是在玩火。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_06_mofashi",
	NextID = 62001415,
}
StorySpeechConfig[StorySpeechID.Id62001415] =
{
	Id = 62001415,
	CharName = "呜呜",
	Text = "喵——！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_wuwu",
	NextID = 62001416,
}
StorySpeechConfig[StorySpeechID.Id62001416] =
{
	Id = 62001416,
	CharName = "剑士",
	Text = "（一声巨响）啊！我的锅怎么被推倒了……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62001417,
}
StorySpeechConfig[StorySpeechID.Id62001417] =
{
	Id = 62001417,
	CharName = "剑士",
	Text = "啊——油流出来了！！火，火窜上去了！！啊啊啊——",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62001418,
}
StorySpeechConfig[StorySpeechID.Id62001418] =
{
	Id = 62001418,
	CharName = "魔法师",
	Text = "……别慌，交给我吧。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_06_mofashi",
	NextID = 62001419,
}
StorySpeechConfig[StorySpeechID.Id62001419] =
{
	Id = 62001419,
	CharName = "剑士",
	Text = "什么？你——啊啊啊！！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62001420,
}
StorySpeechConfig[StorySpeechID.Id62001420] =
{
	Id = 62001420,
	CharName = "剑士",
	Text = "（颤抖）可恶，被淋了一身冷水……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
}
StorySpeechConfig[StorySpeechID.Id62001501] =
{
	Id = 62001501,
	CharName = "剑士",
	Text = "外卖小鸽怎么还不来……我好饿……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62001502,
}
StorySpeechConfig[StorySpeechID.Id62001502] =
{
	Id = 62001502,
	CharName = "魔法师",
	Text = "今天气温骤降，他们工作也不容易，体谅一下吧。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_06_mofashi",
	NextID = 62001503,
}
StorySpeechConfig[StorySpeechID.Id62001503] =
{
	Id = 62001503,
	CharName = "剑士",
	Text = "好饿……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62001504,
}
StorySpeechConfig[StorySpeechID.Id62001504] =
{
	Id = 62001504,
	CharName = "漆漆",
	Text = "喵……（我也饿了）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_gugu",
	NextID = 62001505,
}
StorySpeechConfig[StorySpeechID.Id62001505] =
{
	Id = 62001505,
	CharName = "呜呜",
	Text = "（炸毛）喵！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 62001506,
}
StorySpeechConfig[StorySpeechID.Id62001506] =
{
	Id = 62001506,
	CharName = "魔法师",
	Text = "嗯？怎么了？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_06_mofashi",
	NextID = 62001507,
}
StorySpeechConfig[StorySpeechID.Id62001507] =
{
	Id = 62001507,
	CharName = "魔法师",
	Text = "是不是外面有人踢门？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_06_mofashi",
	NextID = 62001508,
}
StorySpeechConfig[StorySpeechID.Id62001508] =
{
	Id = 62001508,
	CharName = "剑士",
	Text = "是吗……哦，是你吗？我的外卖小鸽！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62001509,
}
StorySpeechConfig[StorySpeechID.Id62001509] =
{
	Id = 62001509,
	CharName = "外卖小鸽",
	Text = "（无奈）你，你们的……外卖，一路跑来，累死我了……",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_gugu1",
	NextID = 62001510,
}
StorySpeechConfig[StorySpeechID.Id62001510] =
{
	Id = 62001510,
	CharName = "剑士",
	Text = "嗯？难道你没有一双飞翔的翅膀吗？！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62001511,
}
StorySpeechConfig[StorySpeechID.Id62001511] =
{
	Id = 62001511,
	CharName = "外卖小鸽",
	Text = "（委屈）天太冷了……我的翅膀都被冻住了，你看……",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_gugu1",
	NextID = 62001512,
}
StorySpeechConfig[StorySpeechID.Id62001512] =
{
	Id = 62001512,
	CharName = "外卖小鸽",
	Text = "我只有把外卖套在脖子上，一步一步跑过来，呜呜呜……",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_gugu1",
	NextID = 62001513,
}
StorySpeechConfig[StorySpeechID.Id62001513] =
{
	Id = 62001513,
	CharName = "魔法师",
	Text = "难怪你刚刚会踢门……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_06_mofashi",
	NextID = 62001514,
}
StorySpeechConfig[StorySpeechID.Id62001514] =
{
	Id = 62001514,
	CharName = "外卖小鸽",
	Text = "我，我是用膝盖撞的！拜托了，请不要投诉我！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_gugu1",
	NextID = 62001515,
}
StorySpeechConfig[StorySpeechID.Id62001515] =
{
	Id = 62001515,
	CharName = "剑士",
	Text = "（小声）你哪来的膝盖……对了，我想，我们可以帮到你。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62001516,
}
StorySpeechConfig[StorySpeechID.Id62001516] =
{
	Id = 62001516,
	CharName = "外卖小鸽",
	Text = "（惊）什么？！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_gugu1",
	NextID = 62001517,
}
StorySpeechConfig[StorySpeechID.Id62001517] =
{
	Id = 62001517,
	CharName = "魔法师",
	Text = "嗯，我可以用火系魔法帮你取暖。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_06_mofashi",
}
StorySpeechConfig[StorySpeechID.Id62001601] =
{
	Id = 62001601,
	CharName = "剑士",
	Text = "好困……谁家在放鞭炮啊喂——",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62001602,
}
StorySpeechConfig[StorySpeechID.Id62001602] =
{
	Id = 62001602,
	CharName = "漆漆",
	Text = "喵呜……（好想睡觉……）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_gugu",
	NextID = 62001603,
}
StorySpeechConfig[StorySpeechID.Id62001603] =
{
	Id = 62001603,
	CharName = "剑士",
	Text = "可恶！我一定要把这人揪出来！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62001604,
}
StorySpeechConfig[StorySpeechID.Id62001604] =
{
	Id = 62001604,
	CharName = "孩子",
	Text = "叔叔……你也是来放鞭炮的吗？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_17_baotong",
	NextID = 62001605,
}
StorySpeechConfig[StorySpeechID.Id62001605] =
{
	Id = 62001605,
	CharName = "剑士",
	Text = "（黑线）叔、叔叔——",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62001606,
}
StorySpeechConfig[StorySpeechID.Id62001606] =
{
	Id = 62001606,
	CharName = "孩子",
	Text = "啊，叔叔，你的猫猫好可爱！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_17_baotong",
	NextID = 62001607,
}
StorySpeechConfig[StorySpeechID.Id62001607] =
{
	Id = 62001607,
	CharName = "漆漆",
	Text = "喵！（嘿嘿！）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_gugu",
	NextID = 62001608,
}
StorySpeechConfig[StorySpeechID.Id62001608] =
{
	Id = 62001608,
	CharName = "孩子",
	Text = "叔叔，我能抱抱你的猫猫吗……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_17_baotong",
	NextID = 62001609,
}
StorySpeechConfig[StorySpeechID.Id62001609] =
{
	Id = 62001609,
	CharName = "漆漆",
	Text = "喵呜……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_gugu",
	NextID = 62001610,
}
StorySpeechConfig[StorySpeechID.Id62001610] =
{
	Id = 62001610,
	CharName = "剑士",
	Text = "你叫哥哥就可以。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62001611,
}
StorySpeechConfig[StorySpeechID.Id62001611] =
{
	Id = 62001611,
	CharName = "孩子",
	Text = "嗯？那……叔叔，我能抱抱你的哥哥吗？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_17_baotong",
	NextID = 62001612,
}
StorySpeechConfig[StorySpeechID.Id62001612] =
{
	Id = 62001612,
	CharName = "剑士",
	Text = "？？？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62001613,
}
StorySpeechConfig[StorySpeechID.Id62001613] =
{
	Id = 62001613,
	CharName = "孩子",
	Text = "小猫咪，你也想玩鞭炮吗？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_17_baotong",
	NextID = 62001614,
}
StorySpeechConfig[StorySpeechID.Id62001614] =
{
	Id = 62001614,
	CharName = "孩子",
	Text = "（开心）你看，咻——炸啦炸啦！！！哈哈哈！！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_17_baotong",
	NextID = 62001615,
}
StorySpeechConfig[StorySpeechID.Id62001615] =
{
	Id = 62001615,
	CharName = "漆漆",
	Text = "喵呜！！！（好可怕！！！）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_gugu",
	NextID = 62001616,
}
StorySpeechConfig[StorySpeechID.Id62001616] =
{
	Id = 62001616,
	CharName = "剑士",
	Text = "啊！小猫被吓到了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62001617,
}
StorySpeechConfig[StorySpeechID.Id62001617] =
{
	Id = 62001617,
	CharName = "剑士",
	Text = "小兔崽子，快把你的鞭炮收起来！！扰民了！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
}
StorySpeechConfig[StorySpeechID.Id62001701] =
{
	Id = 62001701,
	CharName = "剑士",
	Text = "我们应该有好几年没见了吧？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62001702,
}
StorySpeechConfig[StorySpeechID.Id62001702] =
{
	Id = 62001702,
	CharName = "童年玩伴",
	Text = "是啊，当时你说要离开家乡，学习剑术……我们都大吃一惊呢。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_10_buluolaoda",
	NextID = 62001703,
}
StorySpeechConfig[StorySpeechID.Id62001703] =
{
	Id = 62001703,
	CharName = "童年玩伴",
	Text = "没想到，你走后没多久，我也追随着你的步伐，离开了故乡……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_10_buluolaoda",
	NextID = 62001704,
}
StorySpeechConfig[StorySpeechID.Id62001704] =
{
	Id = 62001704,
	CharName = "童年玩伴",
	Text = "听说，你现在已经成为一名知名剑士了，就连那位小魔王，也是你的手下败将，好厉害……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_10_buluolaoda",
	NextID = 62001705,
}
StorySpeechConfig[StorySpeechID.Id62001705] =
{
	Id = 62001705,
	CharName = "剑士",
	Text = "啊……其实，那是我们队伍的共同成果啦……哈哈哈。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62001706,
}
StorySpeechConfig[StorySpeechID.Id62001706] =
{
	Id = 62001706,
	CharName = "童年玩伴",
	Text = "有的时候，我真的很羡慕你。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_10_buluolaoda",
	NextID = 62001707,
}
StorySpeechConfig[StorySpeechID.Id62001707] =
{
	Id = 62001707,
	CharName = "剑士",
	Text = "诶？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62001708,
}
StorySpeechConfig[StorySpeechID.Id62001708] =
{
	Id = 62001708,
	CharName = "童年玩伴",
	Text = "羡慕你拥有精湛的剑术，能去我永远去不了的地方，开展我永远不可能开展的冒险……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_10_buluolaoda",
	NextID = 62001709,
}
StorySpeechConfig[StorySpeechID.Id62001709] =
{
	Id = 62001709,
	CharName = "剑士",
	Text = "……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62001710,
}
StorySpeechConfig[StorySpeechID.Id62001710] =
{
	Id = 62001710,
	CharName = "童年玩伴",
	Text = "我也希望有一天，能成为驰骋在这个世界的英雄，但是……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_10_buluolaoda",
	NextID = 62001711,
}
StorySpeechConfig[StorySpeechID.Id62001711] =
{
	Id = 62001711,
	CharName = "剑士",
	Text = "（挠头）啊哈哈……你也不用羡慕我，你的生活也很精彩啊。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62001712,
}
StorySpeechConfig[StorySpeechID.Id62001712] =
{
	Id = 62001712,
	CharName = "童年玩伴",
	Text = "哎？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_10_buluolaoda",
	NextID = 62001713,
}
StorySpeechConfig[StorySpeechID.Id62001713] =
{
	Id = 62001713,
	CharName = "剑士",
	Text = "虽然你没去冒险，但是……那个，总之，就是大家都有各自的精彩！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62001714,
}
StorySpeechConfig[StorySpeechID.Id62001714] =
{
	Id = 62001714,
	CharName = "童年玩伴",
	Text = "（沉思）是啊……你只是做了，自己能做的事而已。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_10_buluolaoda",
	NextID = 62001715,
}
StorySpeechConfig[StorySpeechID.Id62001715] =
{
	Id = 62001715,
	CharName = "童年玩伴",
	Text = "这个世界上，一定也有什么事情，是只有我自己才能做到的吧？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_10_buluolaoda",
	NextID = 62001716,
}
StorySpeechConfig[StorySpeechID.Id62001716] =
{
	Id = 62001716,
	CharName = "剑士",
	Text = "（小声）啊……话题突然就深奥了起来……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62001717,
}
StorySpeechConfig[StorySpeechID.Id62001717] =
{
	Id = 62001717,
	CharName = "剑士",
	Text = "是啊是啊，我们每个人都是独一无二的嘛！（拍肩）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62001718,
}
StorySpeechConfig[StorySpeechID.Id62001718] =
{
	Id = 62001718,
	CharName = "童年玩伴",
	Text = "只有去完成那些事情，才能了解自己存在的意义，不是吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_10_buluolaoda",
	NextID = 62001719,
}
StorySpeechConfig[StorySpeechID.Id62001719] =
{
	Id = 62001719,
	CharName = "剑士",
	Text = "（相视一笑）你说得对！来，我们喝酒！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62001720,
}
StorySpeechConfig[StorySpeechID.Id62001720] =
{
	Id = 62001720,
	CharName = "童年玩伴",
	Text = "这酒的颜色...算了，先干为敬！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_10_buluolaoda",
}
StorySpeechConfig[StorySpeechID.Id62001801] =
{
	Id = 62001801,
	CharName = "未来的剑士",
	Text = "（鞠躬）谢谢大家，谢谢大家的掌声和鲜花！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi_cat",
	NextID = 62001802,
}
StorySpeechConfig[StorySpeechID.Id62001802] =
{
	Id = 62001802,
	CharName = "剑士的粉丝",
	Text = "小剑剑——我们爱你——",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_09_putongcunmin",
	NextID = 62001803,
}
StorySpeechConfig[StorySpeechID.Id62001803] =
{
	Id = 62001803,
	CharName = "未来的剑士",
	Text = "oh my darling，I love you too~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi_cat",
	NextID = 62001804,
}
StorySpeechConfig[StorySpeechID.Id62001804] =
{
	Id = 62001804,
	CharName = "剑士",
	Text = "？？？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62001805,
}
StorySpeechConfig[StorySpeechID.Id62001805] =
{
	Id = 62001805,
	CharName = "未来的剑士",
	Text = "我能拿到今天的荣誉，离不开我曾经的刻苦练习，更离不开我对剑术的追求和热爱！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi_cat",
	NextID = 62001806,
}
StorySpeechConfig[StorySpeechID.Id62001806] =
{
	Id = 62001806,
	CharName = "未来的剑士",
	Text = "这里，我要感谢我的师父，感谢我的父母，还有支持我的粉丝们！我爱你们！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi_cat",
	NextID = 62001807,
}
StorySpeechConfig[StorySpeechID.Id62001807] =
{
	Id = 62001807,
	CharName = "剑士的粉丝",
	Text = "（欢呼）ohhhh！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_09_putongcunmin",
	NextID = 62001808,
}
StorySpeechConfig[StorySpeechID.Id62001808] =
{
	Id = 62001808,
	CharName = "未来的剑士",
	Text = "没有人天生愚钝，他们只是不懂奋斗的意义，只要坚持，我们都可以站在星球之巅！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi_cat",
	NextID = 62001809,
}
StorySpeechConfig[StorySpeechID.Id62001809] =
{
	Id = 62001809,
	CharName = "未来的剑士",
	Text = "听懂，掌声！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi_cat",
	NextID = 62001810,
}
StorySpeechConfig[StorySpeechID.Id62001810] =
{
	Id = 62001810,
	CharName = "剑士",
	Text = "（流汗）……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62001811,
}
StorySpeechConfig[StorySpeechID.Id62001811] =
{
	Id = 62001811,
	CharName = "未来的剑士",
	Text = "（看向剑士）唔，这怎么有个小鬼？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi_cat",
	NextID = 62001812,
}
StorySpeechConfig[StorySpeechID.Id62001812] =
{
	Id = 62001812,
	CharName = "剑士",
	Text = "你，一定去了很多地方冒险，练习了很多剑术，才成为了这样厉害的人吧？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62001813,
}
StorySpeechConfig[StorySpeechID.Id62001813] =
{
	Id = 62001813,
	CharName = "未来的剑士",
	Text = "冒险？练剑？哈哈哈！你在说什么？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi_cat",
	NextID = 62001814,
}
StorySpeechConfig[StorySpeechID.Id62001814] =
{
	Id = 62001814,
	CharName = "未来的剑士",
	Text = "我才不做那种事！我只要每天保持帅气，吸引我的粉丝，就足够了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi_cat",
	NextID = 62001815,
}
StorySpeechConfig[StorySpeechID.Id62001815] =
{
	Id = 62001815,
	CharName = "剑士",
	Text = "？！！你……你这家伙……漆漆和呜呜呢？魔法师他们都去哪儿了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62001816,
}
StorySpeechConfig[StorySpeechID.Id62001816] =
{
	Id = 62001816,
	CharName = "未来的剑士",
	Text = "他们……都是谁来着？去哪儿都行，总之和我无关。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi_cat",
	NextID = 62001817,
}
StorySpeechConfig[StorySpeechID.Id62001817] =
{
	Id = 62001817,
	CharName = "剑士",
	Text = "你——",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62001818,
}
StorySpeechConfig[StorySpeechID.Id62001818] =
{
	Id = 62001818,
	CharName = "未来的剑士",
	Text = "莫名其妙被人质问……烦死了，哼，我要回去了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi_cat",
	NextID = 62001819,
}
StorySpeechConfig[StorySpeechID.Id62001819] =
{
	Id = 62001819,
	CharName = "剑士的粉丝",
	Text = "啊！别走啊，给我们签个名吧——",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_09_putongcunmin",
	NextID = 62001820,
}
StorySpeechConfig[StorySpeechID.Id62001820] =
{
	Id = 62001820,
	CharName = "剑士",
	Text = "（哆嗦）难道，这就是以后的我吗……不，以后绝不能变成这样！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
}
StorySpeechConfig[StorySpeechID.Id62001901] =
{
	Id = 62001901,
	CharName = "快递小鸽",
	Text = "收件人……小，小剑剑？是你么？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_gugu1",
	NextID = 62001902,
}
StorySpeechConfig[StorySpeechID.Id62001902] =
{
	Id = 62001902,
	CharName = "剑士",
	Text = "（脸红）是、是我……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62001903,
}
StorySpeechConfig[StorySpeechID.Id62001903] =
{
	Id = 62001903,
	CharName = "快递小鸽",
	Text = "哦，这个快递，你查收一下。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_gugu1",
	NextID = 62001904,
}
StorySpeechConfig[StorySpeechID.Id62001904] =
{
	Id = 62001904,
	CharName = "剑士",
	Text = "我应该没有买东西吧……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62001905,
}
StorySpeechConfig[StorySpeechID.Id62001905] =
{
	Id = 62001905,
	CharName = "剑士",
	Text = "诶，这个地址？是爸爸妈妈寄过来的？！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62001906,
}
StorySpeechConfig[StorySpeechID.Id62001906] =
{
	Id = 62001906,
	CharName = "剑士",
	Text = "（眼睛红了）明明之前吵了一架……他们却，还是给我寄了很多东西……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62001907,
}
StorySpeechConfig[StorySpeechID.Id62001907] =
{
	Id = 62001907,
	CharName = "剑士",
	Text = "（清点）一床厚被子、香肠和腊肉、还有我最喜欢吃的酱料……怎么还有牛奶？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62001908,
}
StorySpeechConfig[StorySpeechID.Id62001908] =
{
	Id = 62001908,
	CharName = "剑士",
	Text = "我早就不长个子了！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62001909,
}
StorySpeechConfig[StorySpeechID.Id62001909] =
{
	Id = 62001909,
	CharName = "剑士",
	Text = "（哭笑不得）看来，在爸爸妈妈眼里，我仍旧是个永远长不大的孩子啊……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62001910,
}
StorySpeechConfig[StorySpeechID.Id62001910] =
{
	Id = 62001910,
	CharName = "剑士",
	Text = "哎，还有一封信……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62001911,
}
StorySpeechConfig[StorySpeechID.Id62001911] =
{
	Id = 62001911,
	CharName = "剑士",
	Text = "儿子，加油！爸爸妈妈永远是你最坚强的后盾。在外面注意身体，有空了就回来看看我们。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62001912,
}
StorySpeechConfig[StorySpeechID.Id62001912] =
{
	Id = 62001912,
	CharName = "剑士",
	Text = "（擦泪）呜呜呜——之前不该和妈妈吵架的……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
}
StorySpeechConfig[StorySpeechID.Id62002001] =
{
	Id = 62002001,
	CharName = "剑士",
	Text = "假期就要过去啦——",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62002002,
}
StorySpeechConfig[StorySpeechID.Id62002002] =
{
	Id = 62002002,
	CharName = "剑士",
	Text = "虽然没有回家过年，但是度过了一个非常有意义的节日！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62002003,
}
StorySpeechConfig[StorySpeechID.Id62002003] =
{
	Id = 62002003,
	CharName = "剑士",
	Text = "我才深深地感受到，原来爸爸、妈妈、还有师父，都非常爱我，不管我在哪里，他们都在一直牵挂着我……他们是对我最好的人！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62002004,
}
StorySpeechConfig[StorySpeechID.Id62002004] =
{
	Id = 62002004,
	CharName = "剑士",
	Text = "虽然遇到了一些不开心的事，但是我似乎记性很差，好多都不记得了……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62002005,
}
StorySpeechConfig[StorySpeechID.Id62002005] =
{
	Id = 62002005,
	CharName = "剑士",
	Text = "我记得我帮小牧师解了围，帮助外卖小鸽取暖，还和魔法师一起打扫卫生、做年夜饭……这些都是非常开心的回忆。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62002006,
}
StorySpeechConfig[StorySpeechID.Id62002006] =
{
	Id = 62002006,
	CharName = "剑士",
	Text = "记住这些美好的过去，就足够啦！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62002007,
}
StorySpeechConfig[StorySpeechID.Id62002007] =
{
	Id = 62002007,
	CharName = "剑士",
	Text = "现在，全新的一年已经开启了，我也要对过去的自己说再见了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62002008,
}
StorySpeechConfig[StorySpeechID.Id62002008] =
{
	Id = 62002008,
	CharName = "剑士",
	Text = "希望新的一年，我可以更加坚强！成为更高级别的剑士！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62002009,
}
StorySpeechConfig[StorySpeechID.Id62002009] =
{
	Id = 62002009,
	CharName = "剑士",
	Text = "我还希望，我可以和同伴们一起，去更多地方，探索更多星球。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62002010,
}
StorySpeechConfig[StorySpeechID.Id62002010] =
{
	Id = 62002010,
	CharName = "剑士",
	Text = "最后一个愿望……希望大家都能幸福快乐，一切平安，明年可以回家过年！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
}
StorySpeechConfig[StorySpeechID.Id62003101] =
{
	Id = 62003101,
	CharName = "汽水王子",
	Text = "（拿出邀请函）有封信。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_08_xuebi",
	NextID = 62003102,
}
StorySpeechConfig[StorySpeechID.Id62003102] =
{
	Id = 62003102,
	CharName = "挑衅信",
	Text = "致王子们\n近来颇有名气的活动，大约的确是试胆大会了罢，即便是宇宙电视台，也派人来现场直播，因此，我便……",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	RightIcon = "EventItem_SUS_Event_52",
	NextID = 62003103,
}
StorySpeechConfig[StorySpeechID.Id62003103] =
{
	Id = 62003103,
	CharName = "可乐王子",
	Text = "汽水，我马上就要召开全球巡演了，你不关注我，关注这个？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_07_kele",
	NextID = 62003104,
}
StorySpeechConfig[StorySpeechID.Id62003104] =
{
	Id = 62003104,
	CharName = "汽水王子",
	Text = "……你不懂。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_08_xuebi",
	NextID = 62003105,
}
StorySpeechConfig[StorySpeechID.Id62003105] =
{
	Id = 62003105,
	CharName = "可乐王子",
	Text = "你去干什么？去推销你新代言的饮料吗，哈哈……（灵光一现）等等！推销？！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_07_kele",
	NextID = 62003106,
}
StorySpeechConfig[StorySpeechID.Id62003106] =
{
	Id = 62003106,
	CharName = "汽水王子",
	Text = "（点头）",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_08_xuebi",
	NextID = 62003107,
}
StorySpeechConfig[StorySpeechID.Id62003107] =
{
	Id = 62003107,
	CharName = "可乐王子",
	Text = "宇宙电视台！只要霸占镜头，就能宣传我的演唱会，到时候，现场座无虚席，我们甚至和黄牛达成某种交易，然后我就……（星星眼）",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_07_kele",
	NextID = 62003108,
}
StorySpeechConfig[StorySpeechID.Id62003108] =
{
	Id = 62003108,
	CharName = "啤酒王子",
	Text = "……你清醒一下，可乐！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_09_pijiu",
	NextID = 62003109,
}
StorySpeechConfig[StorySpeechID.Id62003109] =
{
	Id = 62003109,
	CharName = "汽水王子",
	Text = "（白眼）白日梦。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_08_xuebi",
	NextID = 62003110,
}
StorySpeechConfig[StorySpeechID.Id62003110] =
{
	Id = 62003110,
	CharName = "可乐王子",
	Text = "（清醒）事不宜迟，我们赶紧出发！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_07_kele",
	NextID = 62003111,
}
StorySpeechConfig[StorySpeechID.Id62003111] =
{
	Id = 62003111,
	CharName = "番茄酱侍卫",
	Text = "（惊）王子们，你们这是……？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_31_fanqiejiang",
	NextID = 62003112,
}
StorySpeechConfig[StorySpeechID.Id62003112] =
{
	Id = 62003112,
	CharName = "汽水王子",
	Text = "蹭热点。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_08_xuebi",
	NextID = 62003113,
}
StorySpeechConfig[StorySpeechID.Id62003113] =
{
	Id = 62003113,
	CharName = "番茄酱侍卫",
	Text = "（拦住）不管你们要做什么，国王有令，今日忌出行，请回吧。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_31_fanqiejiang",
}
StorySpeechConfig[StorySpeechID.Id62003201] =
{
	Id = 62003201,
	CharName = "村长",
	Text = "（快速跑来）我们！我们要报名！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye",
	NextID = 62003202,
}
StorySpeechConfig[StorySpeechID.Id62003202] =
{
	Id = 62003202,
	CharName = "剑士",
	Text = "村长，我们为什么要来流亡街，给这几个家伙当保镖啊？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62003203,
}
StorySpeechConfig[StorySpeechID.Id62003203] =
{
	Id = 62003203,
	CharName = "魔法师",
	Text = "这还不明显吗，村长肯定是看上了玉璧奖励，见钱眼开。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_06_mofashi",
	NextID = 62003204,
}
StorySpeechConfig[StorySpeechID.Id62003204] =
{
	Id = 62003204,
	CharName = "村长",
	Text = "我都是为了你们的美好生活着想啊，这么多玉璧，够我，啊不，够我们花好几辈子了……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye",
	NextID = 62003205,
}
StorySpeechConfig[StorySpeechID.Id62003205] =
{
	Id = 62003205,
	CharName = "咖啡女仆",
	Text = "（念名单）来自冒险星的冒险者组成的冒险小队队……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_06_kafei",
	NextID = 62003206,
}
StorySpeechConfig[StorySpeechID.Id62003206] =
{
	Id = 62003206,
	CharName = "村长",
	Text = "（中气十足）到！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye",
	NextID = 62003207,
}
StorySpeechConfig[StorySpeechID.Id62003207] =
{
	Id = 62003207,
	CharName = "咖啡女仆",
	Text = "老爷爷，您也来……？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_06_kafei",
	NextID = 62003208,
}
StorySpeechConfig[StorySpeechID.Id62003208] =
{
	Id = 62003208,
	CharName = "村长",
	Text = "（推出剑士）我只是我们队的队长，这位负责打架……（使眼色）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye",
	NextID = 62003209,
}
StorySpeechConfig[StorySpeechID.Id62003209] =
{
	Id = 62003209,
	CharName = "咖啡女仆",
	Text = "现在你要和另一位竞争者进行PK，你准备好了吗？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_06_kafei",
	NextID = 62003210,
}
StorySpeechConfig[StorySpeechID.Id62003210] =
{
	Id = 62003210,
	CharName = "小队长",
	Text = "（摩拳擦掌）哈！嚯——嚯！嘿——",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_13_dashouxiaodi",
	NextID = 62003211,
}
StorySpeechConfig[StorySpeechID.Id62003211] =
{
	Id = 62003211,
	CharName = "啤酒王子",
	Text = "（擦泪）大家为了给我们当保镖，这么拼命……呜呜呜，我好感动……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_09_pijiu",
	NextID = 62003212,
}
StorySpeechConfig[StorySpeechID.Id62003212] =
{
	Id = 62003212,
	CharName = "剑士",
	Text = "……开始吧，我们上。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62003213,
}
StorySpeechConfig[StorySpeechID.Id62003213] =
{
	Id = 62003213,
	CharName = "小队长",
	Text = "（惊）你们怎么这么多人！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 62003214,
}
StorySpeechConfig[StorySpeechID.Id62003214] =
{
	Id = 62003214,
	CharName = "汽水王子",
	Text = "……好菜哦。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_08_xuebi",
}
StorySpeechConfig[StorySpeechID.Id62003301] =
{
	Id = 62003301,
	CharName = "可乐王子",
	Text = "哇，这里好多人啊！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_07_kele",
	NextID = 62003302,
}
StorySpeechConfig[StorySpeechID.Id62003302] =
{
	Id = 62003302,
	CharName = "啤酒王子",
	Text = "刚刚有人一边吐一边跑过去了……看来，这个试胆大会很激烈啊！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_09_pijiu",
	NextID = 62003303,
}
StorySpeechConfig[StorySpeechID.Id62003303] =
{
	Id = 62003303,
	CharName = "奶茶王子",
	Text = "如果我的电影，也有这么多人去看就好了，说来，汽水人呢？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_10_naicha",
	NextID = 62003304,
}
StorySpeechConfig[StorySpeechID.Id62003304] =
{
	Id = 62003304,
	CharName = "可乐王子",
	Text = "（思索）难道……他想自己一个人去蹭热点？！太阴险了！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_07_kele",
	NextID = 62003305,
}
StorySpeechConfig[StorySpeechID.Id62003305] =
{
	Id = 62003305,
	CharName = "汽水王子",
	Text = "（偷偷出现在某个摊位前）……好险啊。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_08_xuebi",
	NextID = 62003306,
}
StorySpeechConfig[StorySpeechID.Id62003306] =
{
	Id = 62003306,
	CharName = "汽水王子",
	Text = "（寻找摄像机）哦，在这。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_08_xuebi",
	NextID = 62003307,
}
StorySpeechConfig[StorySpeechID.Id62003307] =
{
	Id = 62003307,
	CharName = "板蓝根泡面",
	Text = "您好先生，本摊位的试胆环节，是要吃一碗养生泡面哦~（拿出碗）",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_104_IsatisNoodle",
	NextID = 62003308,
}
StorySpeechConfig[StorySpeechID.Id62003308] =
{
	Id = 62003308,
	CharName = "汽水王子",
	Text = "……让我吃？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_08_xuebi",
	NextID = 62003309,
}
StorySpeechConfig[StorySpeechID.Id62003309] =
{
	Id = 62003309,
	CharName = "黑料试胆参与者A",
	Text = "前面的快点！吃不吃啊，不吃快走！",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	RightIcon = "Pir_01_DarkCooker",
	NextID = 62003310,
}
StorySpeechConfig[StorySpeechID.Id62003310] =
{
	Id = 62003310,
	CharName = "黑料试胆参与者B",
	Text = "就是，你不吃我们还等着呢~没胆子就别来排啊。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_23_peigen_cos10",
	NextID = 62003311,
}
StorySpeechConfig[StorySpeechID.Id62003311] =
{
	Id = 62003311,
	CharName = "摄像头",
	Text = "（镜头移到板蓝根泡面上）",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	RightIcon = "MUS_BlackCamera",
	NextID = 62003312,
}
StorySpeechConfig[StorySpeechID.Id62003312] =
{
	Id = 62003312,
	CharName = "汽水王子",
	Text = "……吃就吃。（张嘴吃）",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_08_xuebi",
	NextID = 62003313,
}
StorySpeechConfig[StorySpeechID.Id62003313] =
{
	Id = 62003313,
	CharName = "汽水王子",
	Text = "（吞咽）恶心，呕——",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_08_xuebi",
	NextID = 62003314,
}
StorySpeechConfig[StorySpeechID.Id62003314] =
{
	Id = 62003314,
	CharName = "汽水王子",
	Text = "（瞥向远处的兄弟们）失、策、了……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_08_xuebi",
}
StorySpeechConfig[StorySpeechID.Id62003401] =
{
	Id = 62003401,
	CharName = "臭小黑",
	Text = "我们今天的任务，就是拦截美食星王子，让他批准我们的移民请求！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	LeftIcon = "FAT_StinkyTofuBlack",
	NextID = 62003402,
}
StorySpeechConfig[StorySpeechID.Id62003402] =
{
	Id = 62003402,
	CharName = "臭小白",
	Text = "好的大哥！唉，如果不是被移民局拒绝了99次，我们也不会出此下策。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	RightIcon = "FAT_StinkyTofuWhite",
	NextID = 62003403,
}
StorySpeechConfig[StorySpeechID.Id62003403] =
{
	Id = 62003403,
	CharName = "臭小黑",
	Text = "看，那个绿的王子来了——（冲上去）",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	LeftIcon = "FAT_StinkyTofuBlack",
	NextID = 62003404,
}
StorySpeechConfig[StorySpeechID.Id62003404] =
{
	Id = 62003404,
	CharName = "汽水王子",
	Text = "……你干嘛？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_08_xuebi",
	NextID = 62003405,
}
StorySpeechConfig[StorySpeechID.Id62003405] =
{
	Id = 62003405,
	CharName = "臭小白",
	Text = "（挡路）尊贵的王子，我们是出名的美食臭豆腐，我们觊觎，不对——",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	LeftIcon = "FAT_StinkyTofuWhite",
	NextID = 62003406,
}
StorySpeechConfig[StorySpeechID.Id62003406] =
{
	Id = 62003406,
	CharName = "臭小黑",
	Text = "（打断）我们的梦想就是移民美食星，成为大家都喜欢的料理，希望你可以让我们通过。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	RightIcon = "FAT_StinkyTofuBlack",
	NextID = 62003407,
}
StorySpeechConfig[StorySpeechID.Id62003407] =
{
	Id = 62003407,
	CharName = "汽水王子",
	Text = "（摇头）我拒绝。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_08_xuebi",
	NextID = 62003408,
}
StorySpeechConfig[StorySpeechID.Id62003408] =
{
	Id = 62003408,
	CharName = "臭小黑",
	Text = "？为什么？！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	RightIcon = "FAT_StinkyTofuBlack",
	NextID = 62003409,
}
StorySpeechConfig[StorySpeechID.Id62003409] =
{
	Id = 62003409,
	CharName = "汽水王子",
	Text = "太臭了。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_08_xuebi",
	NextID = 62003410,
}
StorySpeechConfig[StorySpeechID.Id62003410] =
{
	Id = 62003410,
	CharName = "臭小白",
	Text = "（挡路）我们虽然臭，但吃起来香，不信你试试？（凑到汽水王子身前）",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	RightIcon = "FAT_StinkyTofuWhite",
	NextID = 62003411,
}
StorySpeechConfig[StorySpeechID.Id62003411] =
{
	Id = 62003411,
	CharName = "汽水王子",
	Text = "（推开臭小白）……你找打。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_08_xuebi",
	NextID = 62003412,
}
StorySpeechConfig[StorySpeechID.Id62003412] =
{
	Id = 62003412,
	CharName = "可乐王子",
	Text = "汽水！你们这两个臭东西，不许欺负我的兄弟！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_07_kele",
}
StorySpeechConfig[StorySpeechID.Id62003501] =
{
	Id = 62003501,
	CharName = "奶茶王子",
	Text = "（阅读试胆大会说明）哦~必须要吃一道黑暗料理，才会有摄像机来拍啊。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_10_naicha",
	NextID = 62003502,
}
StorySpeechConfig[StorySpeechID.Id62003502] =
{
	Id = 62003502,
	CharName = "啤酒王子",
	Text = "（思索片刻）这还不简单，我们去排队，让那几个冒险者吃不就行了吗~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_09_pijiu",
	NextID = 62003503,
}
StorySpeechConfig[StorySpeechID.Id62003503] =
{
	Id = 62003503,
	CharName = "汽水王子",
	Text = "我看行。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_08_xuebi",
	NextID = 62003504,
}
StorySpeechConfig[StorySpeechID.Id62003504] =
{
	Id = 62003504,
	CharName = "奶茶王子",
	Text = "（五分钟后）这个大大的，硬硬的……就是我们要吃的东西？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_10_naicha",
	NextID = 62003505,
}
StorySpeechConfig[StorySpeechID.Id62003505] =
{
	Id = 62003505,
	CharName = "汽水王子",
	Text = "（看向剑士）……你上吧。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_08_xuebi",
	NextID = 62003506,
}
StorySpeechConfig[StorySpeechID.Id62003506] =
{
	Id = 62003506,
	CharName = "剑士",
	Text = "（懵）？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62003507,
}
StorySpeechConfig[StorySpeechID.Id62003507] =
{
	Id = 62003507,
	CharName = "啤酒王子",
	Text = "摄像机来了，咳……观众们大家好！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_09_pijiu",
	NextID = 62003508,
}
StorySpeechConfig[StorySpeechID.Id62003508] =
{
	Id = 62003508,
	CharName = "汽水王子",
	Text = "（拿出自己代言的饮料）赶紧喝。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_08_xuebi",
	NextID = 62003509,
}
StorySpeechConfig[StorySpeechID.Id62003509] =
{
	Id = 62003509,
	CharName = "剑士",
	Text = "（展示饮料）吨吨吨吨吨……啊，好喝！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62003510,
}
StorySpeechConfig[StorySpeechID.Id62003510] =
{
	Id = 62003510,
	CharName = "汽水王子",
	Text = "夸夸它。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_08_xuebi",
	NextID = 62003511,
}
StorySpeechConfig[StorySpeechID.Id62003511] =
{
	Id = 62003511,
	CharName = "剑士",
	Text = "多亏了这款运动饮料，给我力量！（开始啃）唔，啊——唔！！（用力）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62003512,
}
StorySpeechConfig[StorySpeechID.Id62003512] =
{
	Id = 62003512,
	CharName = "黑料试胆参与者A",
	Text = "好猛啊，感觉这个功能性饮料，有点儿东西。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	RightIcon = "Pir_01_DarkCooker",
	NextID = 62003513,
}
StorySpeechConfig[StorySpeechID.Id62003513] =
{
	Id = 62003513,
	CharName = "黑料试胆参与者B",
	Text = "我都想去买了……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_23_peigen_cos10",
	NextID = 62003514,
}
StorySpeechConfig[StorySpeechID.Id62003514] =
{
	Id = 62003514,
	CharName = "剑士",
	Text = "（哐当——）啊——！！我的牙！怎么这么硬？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 62003515,
}
StorySpeechConfig[StorySpeechID.Id62003515] =
{
	Id = 62003515,
	CharName = "剑士",
	Text = "（掏出大宝剑）可恶，那我就把你切碎！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
}
StorySpeechConfig[StorySpeechID.Id62003601] =
{
	Id = 62003601,
	CharName = "黑料试胆参与者A",
	Text = "（快吐了）这个怎么这么臭啊，就像在厕所里吃……",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	LeftIcon = "Pir_01_DarkCooker",
	NextID = 62003602,
}
StorySpeechConfig[StorySpeechID.Id62003602] =
{
	Id = 62003602,
	CharName = "黑料试胆参与者B",
	Text = "（虚弱）好了别说了，呕……我们快离开这个地方。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_23_peigen_cos10",
	NextID = 62003603,
}
StorySpeechConfig[StorySpeechID.Id62003603] =
{
	Id = 62003603,
	CharName = "鲱鱼饭团",
	Text = "（打开盒子吆喝）鲱鱼罐头，你们值得拥有~（向摄像机展示）这是将处理过的鲱鱼，装入罐头任其发酵，再放入饭团中制成的食物哦~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_105_HerringRiceBall",
	NextID = 62003604,
}
StorySpeechConfig[StorySpeechID.Id62003604] =
{
	Id = 62003604,
	CharName = "奶茶王子",
	Text = "这个热点……（颤抖）我还是不蹭了吧……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_10_naicha",
	NextID = 62003605,
}
StorySpeechConfig[StorySpeechID.Id62003605] =
{
	Id = 62003605,
	CharName = "汽水王子",
	Text = "……我要蹭。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_08_xuebi",
	NextID = 62003606,
}
StorySpeechConfig[StorySpeechID.Id62003606] =
{
	Id = 62003606,
	CharName = "魔法师",
	Text = "（念咒）嗅觉魔法——",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_06_mofashi",
	NextID = 62003607,
}
StorySpeechConfig[StorySpeechID.Id62003607] =
{
	Id = 62003607,
	CharName = "汽水王子",
	Text = "舒服了。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_08_xuebi",
	NextID = 62003608,
}
StorySpeechConfig[StorySpeechID.Id62003608] =
{
	Id = 62003608,
	CharName = "可乐王子",
	Text = "走，我们快去抢占前排！（随机拉住一位保镖）去吧！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_07_kele",
	NextID = 62003609,
}
StorySpeechConfig[StorySpeechID.Id62003609] =
{
	Id = 62003609,
	CharName = "居民npc",
	Text = "？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_09_putongcunmin",
	NextID = 62003610,
}
StorySpeechConfig[StorySpeechID.Id62003610] =
{
	Id = 62003610,
	CharName = "可乐王子",
	Text = "（拉着居民npc）大家好，我将在美食星举办全球巡回演唱会，欢迎大家来参加~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_07_kele",
	NextID = 62003611,
}
StorySpeechConfig[StorySpeechID.Id62003611] =
{
	Id = 62003611,
	CharName = "汽水王子",
	Text = "（拿出自己代言的饮料）赶紧喝。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_08_xuebi",
	NextID = 62003612,
}
StorySpeechConfig[StorySpeechID.Id62003612] =
{
	Id = 62003612,
	CharName = "居民npc",
	Text = "（展示饮料）吨吨吨吨吨……啊，不愧是宇宙级的美味！我，真，真让我去啊……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_09_putongcunmin",
	NextID = 62003613,
}
StorySpeechConfig[StorySpeechID.Id62003613] =
{
	Id = 62003613,
	CharName = "汽水王子",
	Text = "不然呢？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_08_xuebi",
	NextID = 62003614,
}
StorySpeechConfig[StorySpeechID.Id62003614] =
{
	Id = 62003614,
	CharName = "居民npc",
	Text = "（咀嚼）啊！！好，好恶心的味道，yue……（呕吐）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_09_putongcunmin",
}
StorySpeechConfig[StorySpeechID.Id62003701] =
{
	Id = 62003701,
	CharName = "史卡",
	Text = "哦，两只小猫咪！（看向王子）你们来我的摊位试胆，还自带原料？真是太体贴了。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_102_KopiLuwak",
	NextID = 62003702,
}
StorySpeechConfig[StorySpeechID.Id62003702] =
{
	Id = 62003702,
	CharName = "呜呜",
	Text = "喵呜~（你也是猫猫吗喵，你好喵~）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_wuwu",
	NextID = 62003703,
}
StorySpeechConfig[StorySpeechID.Id62003703] =
{
	Id = 62003703,
	CharName = "史卡",
	Text = "（拿出咖啡豆）这是给可爱猫猫的奖励哦~（笑）",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_102_KopiLuwak",
	NextID = 62003704,
}
StorySpeechConfig[StorySpeechID.Id62003704] =
{
	Id = 62003704,
	CharName = "呜呜",
	Text = "喵？（这是可以吃的吗喵~我先开动了喵！）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_wuwu",
	NextID = 62003705,
}
StorySpeechConfig[StorySpeechID.Id62003705] =
{
	Id = 62003705,
	CharName = "漆漆",
	Text = "喵！（我也要吃喵！）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_gugu",
	NextID = 62003706,
}
StorySpeechConfig[StorySpeechID.Id62003706] =
{
	Id = 62003706,
	CharName = "汽水王子",
	Text = "……它来了！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_08_xuebi",
	NextID = 62003707,
}
StorySpeechConfig[StorySpeechID.Id62003707] =
{
	Id = 62003707,
	CharName = "奶茶王子",
	Text = "谁？谁来了？（警觉）",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_10_naicha",
	NextID = 62003708,
}
StorySpeechConfig[StorySpeechID.Id62003708] =
{
	Id = 62003708,
	CharName = "汽水王子",
	Text = "摄像机。（展示饮料）",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_08_xuebi",
	NextID = 62003709,
}
StorySpeechConfig[StorySpeechID.Id62003709] =
{
	Id = 62003709,
	CharName = "奶茶王子",
	Text = "你多说几个字行不行啊！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_10_naicha",
	NextID = 62003710,
}
StorySpeechConfig[StorySpeechID.Id62003710] =
{
	Id = 62003710,
	CharName = "呜呜",
	Text = "喵呜……（漆漆……我突然想拉屎喵……）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_wuwu",
	NextID = 62003711,
}
StorySpeechConfig[StorySpeechID.Id62003711] =
{
	Id = 62003711,
	CharName = "漆漆",
	Text = "喵嗷……（我也是喵，忍不住了喵……）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_gugu",
	NextID = 62003712,
}
StorySpeechConfig[StorySpeechID.Id62003712] =
{
	Id = 62003712,
	CharName = "史卡",
	Text = "（笑）嘿嘿嘿……原料出现了……（把屎铲进咖啡中），给，王子殿下~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_102_KopiLuwak",
	NextID = 62003713,
}
StorySpeechConfig[StorySpeechID.Id62003713] =
{
	Id = 62003713,
	CharName = "汽水王子",
	Text = "我不喝。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_08_xuebi",
	NextID = 62003714,
}
StorySpeechConfig[StorySpeechID.Id62003714] =
{
	Id = 62003714,
	CharName = "啤酒王子",
	Text = "（抓住两只猫）既然这样，就你们解决吧！！救救我们！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_09_pijiu",
	NextID = 62003715,
}
StorySpeechConfig[StorySpeechID.Id62003715] =
{
	Id = 62003715,
	CharName = "呜呜",
	Text = "喵？！！（不要喵，放开我喵！！）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 62003716,
}
StorySpeechConfig[StorySpeechID.Id62003716] =
{
	Id = 62003716,
	CharName = "漆漆",
	Text = "喵！！（我不喝，不喝的喵！！呕——！）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_gugu",
	NextID = 62003717,
}
StorySpeechConfig[StorySpeechID.Id62003717] =
{
	Id = 62003717,
	CharName = "汽水王子",
	Text = "……好惨啊。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_08_xuebi",
}
StorySpeechConfig[StorySpeechID.Id62003801] =
{
	Id = 62003801,
	CharName = "奶茶王子",
	Text = "这个摊位好像没有什么奇怪的味道啊……（盯）吃辣挑战？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_10_naicha",
	NextID = 62003802,
}
StorySpeechConfig[StorySpeechID.Id62003802] =
{
	Id = 62003802,
	CharName = "啤酒王子",
	Text = "那多简单，我们自己都能上！汽水，你就在摄像机拍我们的时候，出镜给我们递水就好了~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_09_pijiu",
	NextID = 62003803,
}
StorySpeechConfig[StorySpeechID.Id62003803] =
{
	Id = 62003803,
	CharName = "汽水王子",
	Text = "好感动。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_08_xuebi",
	NextID = 62003804,
}
StorySpeechConfig[StorySpeechID.Id62003804] =
{
	Id = 62003804,
	CharName = "可乐王子",
	Text = "你完全没有感动的样子啊！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_07_kele",
	NextID = 62003805,
}
StorySpeechConfig[StorySpeechID.Id62003805] =
{
	Id = 62003805,
	CharName = "辣辣子",
	Text = "欢迎来到我的摊位~（拿出辣酱）这一关的挑战任务，是吃光这一碗辣椒哦~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_103_GhostChili",
	NextID = 62003806,
}
StorySpeechConfig[StorySpeechID.Id62003806] =
{
	Id = 62003806,
	CharName = "啤酒王子",
	Text = "吃……吃光啊……（看向保镖小队）",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_09_pijiu",
	NextID = 62003807,
}
StorySpeechConfig[StorySpeechID.Id62003807] =
{
	Id = 62003807,
	CharName = "猎人",
	Text = "？我不行，我心脏疼……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_16_lieren",
	NextID = 62003808,
}
StorySpeechConfig[StorySpeechID.Id62003808] =
{
	Id = 62003808,
	CharName = "汽水王子",
	Text = "你可以。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_08_xuebi",
	NextID = 62003809,
}
StorySpeechConfig[StorySpeechID.Id62003809] =
{
	Id = 62003809,
	CharName = "啤酒王子",
	Text = "吃辣会让人流汗，而汗水是你成为猛男的必备道具，你想，只要吃了它，你就能克服胆小的毛病，成为猛男了，是不是很值得一试？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_09_pijiu",
	NextID = 62003810,
}
StorySpeechConfig[StorySpeechID.Id62003810] =
{
	Id = 62003810,
	CharName = "猎人",
	Text = "真，真的吗……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_16_lieren",
	NextID = 62003811,
}
StorySpeechConfig[StorySpeechID.Id62003811] =
{
	Id = 62003811,
	CharName = "魔法师",
	Text = "（念咒）止疼魔法——辣是一种痛觉，我现在帮你把舌头麻痹住，应该能安全通过。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_06_mofashi",
	NextID = 62003812,
}
StorySpeechConfig[StorySpeechID.Id62003812] =
{
	Id = 62003812,
	CharName = "猎人",
	Text = "我相信你……（吃）果然，完全没事！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_16_lieren",
	NextID = 62003813,
}
StorySpeechConfig[StorySpeechID.Id62003813] =
{
	Id = 62003813,
	CharName = "汽水王子",
	Text = "给你水。（使眼色）",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_08_xuebi",
	NextID = 62003814,
}
StorySpeechConfig[StorySpeechID.Id62003814] =
{
	Id = 62003814,
	CharName = "猎人",
	Text = "（非常配合）这个饮料的解辣效果也太好了！我还能再吃二十瓶辣椒！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_16_lieren",
	NextID = 62003815,
}
StorySpeechConfig[StorySpeechID.Id62003815] =
{
	Id = 62003815,
	CharName = "猎人",
	Text = "（十分钟后）啊，我的肚子好疼，厕所在哪里？厕所呢？！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_16_lieren",
}
StorySpeechConfig[StorySpeechID.Id62003901] =
{
	Id = 62003901,
	CharName = "奶茶王子",
	Text = "这个面包里插着死鱼……（细看）兄弟们，这鱼瞪我。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_10_naicha",
	NextID = 62003902,
}
StorySpeechConfig[StorySpeechID.Id62003902] =
{
	Id = 62003902,
	CharName = "汽水王子",
	Text = "好恶心。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_08_xuebi",
	NextID = 62003903,
}
StorySpeechConfig[StorySpeechID.Id62003903] =
{
	Id = 62003903,
	CharName = "村长",
	Text = "天啊，这群死不瞑目的小鱼……我本人心地善良，慈悲为怀，实在不忍对这些鱼下此毒口，这次就让别人上吧。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye",
	NextID = 62003904,
}
StorySpeechConfig[StorySpeechID.Id62003904] =
{
	Id = 62003904,
	CharName = "汽水王子",
	Text = "你好假。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_08_xuebi",
	NextID = 62003905,
}
StorySpeechConfig[StorySpeechID.Id62003905] =
{
	Id = 62003905,
	CharName = "村长",
	Text = "？王子殿下，我是真心实意的！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye",
	NextID = 62003906,
}
StorySpeechConfig[StorySpeechID.Id62003906] =
{
	Id = 62003906,
	CharName = "汽水王子",
	Text = "还不如……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_08_xuebi",
	NextID = 62003907,
}
StorySpeechConfig[StorySpeechID.Id62003907] =
{
	Id = 62003907,
	CharName = "村长",
	Text = "不如……？！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye",
	NextID = 62003908,
}
StorySpeechConfig[StorySpeechID.Id62003908] =
{
	Id = 62003908,
	CharName = "汽水王子",
	Text = "让我上。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_08_xuebi",
	NextID = 62003909,
}
StorySpeechConfig[StorySpeechID.Id62003909] =
{
	Id = 62003909,
	CharName = "啤酒王子",
	Text = "那怎么行，你啤酒大哥，从来不会让好兄弟置身险境！（看向村长）",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_09_pijiu",
	NextID = 62003910,
}
StorySpeechConfig[StorySpeechID.Id62003910] =
{
	Id = 62003910,
	CharName = "村长",
	Text = "什么，你们真的要我，哎哟……不行，我的手疼，拿不动筷子……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye",
	NextID = 62003911,
}
StorySpeechConfig[StorySpeechID.Id62003911] =
{
	Id = 62003911,
	CharName = "啤酒王子",
	Text = "多加300万金币，上不上？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_09_pijiu",
	NextID = 62003912,
}
StorySpeechConfig[StorySpeechID.Id62003912] =
{
	Id = 62003912,
	CharName = "村长",
	Text = "我的舌头也闪了……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye",
	NextID = 62003913,
}
StorySpeechConfig[StorySpeechID.Id62003913] =
{
	Id = 62003913,
	CharName = "啤酒王子",
	Text = "再加666万金币。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_09_pijiu",
	NextID = 62003914,
}
StorySpeechConfig[StorySpeechID.Id62003914] =
{
	Id = 62003914,
	CharName = "村长",
	Text = "（咬牙）成交！加油，没关系，我不怕，唔……yue！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye",
}
StorySpeechConfig[StorySpeechID.Id62004001] =
{
	Id = 62004001,
	CharName = "可乐王子",
	Text = "（盯着花椒）不可以……如果我倒在这里，那一定是宇宙音乐界的损失……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_07_kele",
	NextID = 62004002,
}
StorySpeechConfig[StorySpeechID.Id62004002] =
{
	Id = 62004002,
	CharName = "汽水王子",
	Text = "我上吧。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_08_xuebi",
	NextID = 62004003,
}
StorySpeechConfig[StorySpeechID.Id62004003] =
{
	Id = 62004003,
	CharName = "啤酒王子",
	Text = "汽水？你确定吗？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_09_pijiu",
	NextID = 62004004,
}
StorySpeechConfig[StorySpeechID.Id62004004] =
{
	Id = 62004004,
	CharName = "汽水王子",
	Text = "辛苦了。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_08_xuebi",
	NextID = 62004005,
}
StorySpeechConfig[StorySpeechID.Id62004005] =
{
	Id = 62004005,
	CharName = "可乐王子",
	Text = "你……你说什么啊。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_07_kele",
	NextID = 62004006,
}
StorySpeechConfig[StorySpeechID.Id62004006] =
{
	Id = 62004006,
	CharName = "啤酒王子",
	Text = "这还不懂？汽水在对我们说辛苦了，呜呜呜，弟弟，你长大了……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_09_pijiu",
	NextID = 62004007,
}
StorySpeechConfig[StorySpeechID.Id62004007] =
{
	Id = 62004007,
	CharName = "可乐王子",
	Text = "（嘟囔）我倒是不辛苦，顺便我也能宣传一下，我自己的演唱会……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_07_kele",
	NextID = 62004008,
}
StorySpeechConfig[StorySpeechID.Id62004008] =
{
	Id = 62004008,
	CharName = "奶茶王子",
	Text = "这样吧，我们兄弟四人，一人吃一颗，也算是同甘共苦了。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_10_naicha",
	NextID = 62004009,
}
StorySpeechConfig[StorySpeechID.Id62004009] =
{
	Id = 62004009,
	CharName = "啤酒王子",
	Text = "是个好主意。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_09_pijiu",
	NextID = 62004010,
}
StorySpeechConfig[StorySpeechID.Id62004010] =
{
	Id = 62004010,
	CharName = "汽水王子",
	Text = "我同意。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_08_xuebi",
	NextID = 62004011,
}
StorySpeechConfig[StorySpeechID.Id62004011] =
{
	Id = 62004011,
	CharName = "啤酒王子",
	Text = "（整齐地吃下花椒）啊！！好麻、麻——麻！！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_09_pijiu",
	NextID = 62004012,
}
StorySpeechConfig[StorySpeechID.Id62004012] =
{
	Id = 62004012,
	CharName = "可乐王子",
	Text = "（对着摄影机）一定要，#￥%……听我的歌*&……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_07_kele",
	NextID = 62004013,
}
StorySpeechConfig[StorySpeechID.Id62004013] =
{
	Id = 62004013,
	CharName = "奶茶王子",
	Text = "（对着摄影机）一定要，#￥%……看我的片*&……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_10_naicha",
	NextID = 62004014,
}
StorySpeechConfig[StorySpeechID.Id62004014] =
{
	Id = 62004014,
	CharName = "啤酒王子",
	Text = "（对着摄影机）一定要，#￥%……参加我的*&音乐会……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_09_pijiu",
	NextID = 62004015,
}
StorySpeechConfig[StorySpeechID.Id62004015] =
{
	Id = 62004015,
	CharName = "汽水王子",
	Text = "（对着摄影机）一定，嗝。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_08_xuebi",
}
StorySpeechConfig[StorySpeechID.Id62004101] =
{
	Id = 62004101,
	CharName = "小魔王",
	Text = "把你们这群失业的家伙一个个网罗起来，真是too difficult……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_12_xiaomowang",
	NextID = 62004102,
}
StorySpeechConfig[StorySpeechID.Id62004102] =
{
	Id = 62004102,
	CharName = "小魔王",
	Text = "那么，在你们报名龙舟赛前，本大爷先点个名，骨头杰克！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_12_xiaomowang",
	NextID = 62004103,
}
StorySpeechConfig[StorySpeechID.Id62004103] =
{
	Id = 62004103,
	CharName = "骷髅杰克",
	Text = "到！报告小魔王大人，小的叫骷髅杰克。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_30_kulou",
	NextID = 62004104,
}
StorySpeechConfig[StorySpeechID.Id62004104] =
{
	Id = 62004104,
	CharName = "小魔王",
	Text = "……这不important，下一个，骨头汤姆。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_12_xiaomowang",
	NextID = 62004105,
}
StorySpeechConfig[StorySpeechID.Id62004105] =
{
	Id = 62004105,
	CharName = "骷髅汤姆",
	Text = "到！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_30_kulou",
	NextID = 62004106,
}
StorySpeechConfig[StorySpeechID.Id62004106] =
{
	Id = 62004106,
	CharName = "小魔王",
	Text = "下一个，小队长。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_12_xiaomowang",
	NextID = 62004107,
}
StorySpeechConfig[StorySpeechID.Id62004107] =
{
	Id = 62004107,
	CharName = "小队长",
	Text = "……（躲闪）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_13_dashouxiaodi",
	NextID = 62004108,
}
StorySpeechConfig[StorySpeechID.Id62004108] =
{
	Id = 62004108,
	CharName = "小魔王",
	Text = "小队长？（提高嗓门）小队长？人呢？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_12_xiaomowang",
	NextID = 62004109,
}
StorySpeechConfig[StorySpeechID.Id62004109] =
{
	Id = 62004109,
	CharName = "小队长",
	Text = "（鬼鬼祟祟开门）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_13_dashouxiaodi",
	NextID = 62004110,
}
StorySpeechConfig[StorySpeechID.Id62004110] =
{
	Id = 62004110,
	CharName = "小魔王",
	Text = "看到你了！Amazing！你居然临阵脱逃？骨头兵，给我把他抓回来！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_12_xiaomowang",
	NextID = 62004111,
}
StorySpeechConfig[StorySpeechID.Id62004111] =
{
	Id = 62004111,
	CharName = "小队长",
	Text = "小魔王大人，我不能去啊！我怕水！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_13_dashouxiaodi",
	NextID = 62004112,
}
StorySpeechConfig[StorySpeechID.Id62004112] =
{
	Id = 62004112,
	CharName = "小魔王",
	Text = "Really？你当年在沼泽抓泥怪的时候，可是很英勇的啊！是吧，小的们？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_12_xiaomowang",
	NextID = 62004113,
}
StorySpeechConfig[StorySpeechID.Id62004113] =
{
	Id = 62004113,
	CharName = "骨头兵",
	Text = "小魔王大人说得对！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_30_kulou",
	NextID = 62004114,
}
StorySpeechConfig[StorySpeechID.Id62004114] =
{
	Id = 62004114,
	CharName = "小队长",
	Text = "（被包围）你们……！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
}
StorySpeechConfig[StorySpeechID.Id62004201] =
{
	Id = 62004201,
	CharName = "小魔王",
	Text = "万事都ready了，现在开始抽签。（走到员工前）拿个纸团。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_12_xiaomowang",
	NextID = 62004202,
}
StorySpeechConfig[StorySpeechID.Id62004202] =
{
	Id = 62004202,
	CharName = "骷髅杰克",
	Text = "先让我来，我来抽！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_30_kulou",
	NextID = 62004203,
}
StorySpeechConfig[StorySpeechID.Id62004203] =
{
	Id = 62004203,
	CharName = "小魔王",
	Text = "概率都是一样的，don't be worry。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_12_xiaomowang",
	NextID = 62004204,
}
StorySpeechConfig[StorySpeechID.Id62004204] =
{
	Id = 62004204,
	CharName = "骷髅杰克",
	Text = "（捞）拜托拜托……（打开纸团）噢！是空的，小的不用去啦！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_30_kulou",
	NextID = 62004205,
}
StorySpeechConfig[StorySpeechID.Id62004205] =
{
	Id = 62004205,
	CharName = "小魔王",
	Text = "Come on，轮到你了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_12_xiaomowang",
	NextID = 62004206,
}
StorySpeechConfig[StorySpeechID.Id62004206] =
{
	Id = 62004206,
	CharName = "骷髅汤姆",
	Text = "（捞）达咩达咩……（打开纸团）好耶！我也是空的！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_30_kulou",
	NextID = 62004207,
}
StorySpeechConfig[StorySpeechID.Id62004207] =
{
	Id = 62004207,
	CharName = "小魔王",
	Text = "下一个。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_12_xiaomowang",
	NextID = 62004208,
}
StorySpeechConfig[StorySpeechID.Id62004208] =
{
	Id = 62004208,
	CharName = "骨头兵",
	Text = "大魔王大人，小的……小的怕船……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_30_kulou",
	NextID = 62004209,
}
StorySpeechConfig[StorySpeechID.Id62004209] =
{
	Id = 62004209,
	CharName = "小魔王",
	Text = "快抽，作为boss，不近人情是基本要领，绝对不会同情你的。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_12_xiaomowang",
	NextID = 62004210,
}
StorySpeechConfig[StorySpeechID.Id62004210] =
{
	Id = 62004210,
	CharName = "骨头兵",
	Text = "（捞）加油加油……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_30_kulou",
	NextID = 62004211,
}
StorySpeechConfig[StorySpeechID.Id62004211] =
{
	Id = 62004211,
	CharName = "纸团",
	Text = "（用红笔歪歪扭扭写着）Congratulations！",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	LeftIcon = "Equipment_MUS_05_munaiyi_1",
	NextID = 62004212,
}
StorySpeechConfig[StorySpeechID.Id62004212] =
{
	Id = 62004212,
	CharName = "小魔王",
	Text = "Exciting！就是你了，欢迎加入龙舟赛魔王大队！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_12_xiaomowang",
	NextID = 62004213,
}
StorySpeechConfig[StorySpeechID.Id62004213] =
{
	Id = 62004213,
	CharName = "骨头兵",
	Text = "（石化）……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_30_kulou",
	NextID = 62004214,
}
StorySpeechConfig[StorySpeechID.Id62004214] =
{
	Id = 62004214,
	CharName = "骷髅杰克",
	Text = "恭喜恭喜，到时候一定给你加油~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_30_kulou",
	NextID = 62004215,
}
StorySpeechConfig[StorySpeechID.Id62004215] =
{
	Id = 62004215,
	CharName = "骨头兵",
	Text = "可恶！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_30_kulou",
}
StorySpeechConfig[StorySpeechID.Id62004301] =
{
	Id = 62004301,
	CharName = "小魔王",
	Text = "小的们，good evening！大家好久不见！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_12_xiaomowang",
	NextID = 62004302,
}
StorySpeechConfig[StorySpeechID.Id62004302] =
{
	Id = 62004302,
	CharName = "小魔王",
	Text = "（拿出演讲稿）普通的员工，拿着5400金币，天天摸鱼，拒绝团建，几年后，他的工资还是5400。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_12_xiaomowang",
	NextID = 62004303,
}
StorySpeechConfig[StorySpeechID.Id62004303] =
{
	Id = 62004303,
	CharName = "骷髅杰克",
	Text = "（小声）那不是公司太抠吗……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_30_kulou",
	NextID = 62004304,
}
StorySpeechConfig[StorySpeechID.Id62004304] =
{
	Id = 62004304,
	CharName = "骷髅汤姆",
	Text = "（小声）嘘，小心被听到了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_30_kulou",
	NextID = 62004305,
}
StorySpeechConfig[StorySpeechID.Id62004305] =
{
	Id = 62004305,
	CharName = "小魔王",
	Text = "聪明的员工，拿着5400金币，勤奋上进，拓展人脉，五年后工资已经升到了108万。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_12_xiaomowang",
	NextID = 62004306,
}
StorySpeechConfig[StorySpeechID.Id62004306] =
{
	Id = 62004306,
	CharName = "骨头兵",
	Text = "（星星眼）108万……那时候我就可以畅游不夜城了……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_30_kulou",
	NextID = 62004307,
}
StorySpeechConfig[StorySpeechID.Id62004307] =
{
	Id = 62004307,
	CharName = "小魔王",
	Text = "（清嗓子）不要总去思考，公司给了你们什么，要多think，你们为公司做了什么。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_12_xiaomowang",
	NextID = 62004308,
}
StorySpeechConfig[StorySpeechID.Id62004308] =
{
	Id = 62004308,
	CharName = "公司员工",
	Text = "（鼓掌）！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_30_kulou",
	NextID = 62004309,
}
StorySpeechConfig[StorySpeechID.Id62004309] =
{
	Id = 62004309,
	CharName = "小魔王",
	Text = "你们都知道，由于我们和星际劳动局有些误会，导致公司遇到了一些困难，被迫停业。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_12_xiaomowang",
	NextID = 62004310,
}
StorySpeechConfig[StorySpeechID.Id62004310] =
{
	Id = 62004310,
	CharName = "小魔王",
	Text = "对我们来说，这是困难，也是机遇，这次的比赛，就是让我们集团重新称霸星际的机会。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_12_xiaomowang",
	NextID = 62004311,
}
StorySpeechConfig[StorySpeechID.Id62004311] =
{
	Id = 62004311,
	CharName = "小魔王",
	Text = "所以我们一定要努力冲刺，努力勇夺NO.1！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_12_xiaomowang",
	NextID = 62004312,
}
StorySpeechConfig[StorySpeechID.Id62004312] =
{
	Id = 62004312,
	CharName = "骷髅杰克",
	Text = "这么说，只要得了第一名，拖欠三个月的工资就能发了吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_30_kulou",
	NextID = 62004313,
}
StorySpeechConfig[StorySpeechID.Id62004313] =
{
	Id = 62004313,
	CharName = "骷髅汤姆",
	Text = "（激动）太好了，我的工资终于能拿回来了……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_30_kulou",
	NextID = 62004314,
}
StorySpeechConfig[StorySpeechID.Id62004314] =
{
	Id = 62004314,
	CharName = "骨头兵",
	Text = "（完全状况外）？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_30_kulou",
	NextID = 62004315,
}
StorySpeechConfig[StorySpeechID.Id62004315] =
{
	Id = 62004315,
	CharName = "骨头兵",
	Text = "好困，Zzzzz……为什么大家都热泪盈眶……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_30_kulou",
}
StorySpeechConfig[StorySpeechID.Id62004401] =
{
	Id = 62004401,
	CharName = "小魔王",
	Text = "（在船头打鼓）Fighting！这才有作为反派的气场啊！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_12_xiaomowang",
	NextID = 62004402,
}
StorySpeechConfig[StorySpeechID.Id62004402] =
{
	Id = 62004402,
	CharName = "小魔王",
	Text = "都给我冲，本大爷，今天就是龙船上最强的反派，啊哈哈哈哈！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_12_xiaomowang",
	NextID = 62004403,
}
StorySpeechConfig[StorySpeechID.Id62004403] =
{
	Id = 62004403,
	CharName = "骨头兵",
	Text = "（星星眼）小魔王大人今天真帅啊。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_30_kulou",
	NextID = 62004404,
}
StorySpeechConfig[StorySpeechID.Id62004404] =
{
	Id = 62004404,
	CharName = "海浪",
	Text = "（哗——哗——）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_Undine",
	NextID = 62004405,
}
StorySpeechConfig[StorySpeechID.Id62004405] =
{
	Id = 62004405,
	CharName = "骨头兵",
	Text = "（大浪袭来）哇呜，这个龙舟，好像不太结实的样子……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_30_kulou",
	NextID = 62004406,
}
StorySpeechConfig[StorySpeechID.Id62004406] =
{
	Id = 62004406,
	CharName = "骨头兵",
	Text = "小魔王大人小心！好晃！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_30_kulou",
	NextID = 62004407,
}
StorySpeechConfig[StorySpeechID.Id62004407] =
{
	Id = 62004407,
	CharName = "小魔王",
	Text = "不要慌张！都给本大爷稳住！稳住！继续向前划。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_12_xiaomowang",
	NextID = 62004408,
}
StorySpeechConfig[StorySpeechID.Id62004408] =
{
	Id = 62004408,
	CharName = "骨头兵",
	Text = "（迎难而上）小魔王大人，不行，小的头晕……感觉骨头也要散架了……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_30_kulou",
	NextID = 62004409,
}
StorySpeechConfig[StorySpeechID.Id62004409] =
{
	Id = 62004409,
	CharName = "小魔王",
	Text = "稳住！稳住——（摔倒）啊！！（砰——）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_12_xiaomowang",
	NextID = 62004410,
}
StorySpeechConfig[StorySpeechID.Id62004410] =
{
	Id = 62004410,
	CharName = "骨头兵",
	Text = "小魔王大人，你没事吧？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_30_kulou",
	NextID = 62004411,
}
StorySpeechConfig[StorySpeechID.Id62004411] =
{
	Id = 62004411,
	CharName = "小魔王",
	Text = "疼死了！DAMN！（揉揉脑袋）嘶——\n还不赶紧上岸，把这劣质龙舟给本大爷拆了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_12_xiaomowang",
}
StorySpeechConfig[StorySpeechID.Id62004501] =
{
	Id = 62004501,
	CharName = "小魔王",
	Text = "（走到门前）……（脸红）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_12_xiaomowang",
	NextID = 62004502,
}
StorySpeechConfig[StorySpeechID.Id62004502] =
{
	Id = 62004502,
	CharName = "骨头兵",
	Text = "小魔王大人，您怎么不进去？要不要小的去砸门？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_30_kulou",
	NextID = 62004503,
}
StorySpeechConfig[StorySpeechID.Id62004503] =
{
	Id = 62004503,
	CharName = "小魔王",
	Text = "你说什么？绅士绝不会做出这么无理的举动。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_12_xiaomowang",
	NextID = 62004504,
}
StorySpeechConfig[StorySpeechID.Id62004504] =
{
	Id = 62004504,
	CharName = "指路NPC",
	Text = "哎呀妈呀大妹子，俺们队伍真滴全是猛男，跟俺们一组，赢比赛，杠杠的。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_10_buluolaoda",
	NextID = 62004505,
}
StorySpeechConfig[StorySpeechID.Id62004505] =
{
	Id = 62004505,
	CharName = "牧师",
	Text = "抱歉~我已经答应勇者公司的队伍了~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_07_mushi",
	NextID = 62004506,
}
StorySpeechConfig[StorySpeechID.Id62004506] =
{
	Id = 62004506,
	CharName = "小魔王",
	Text = "（冲进房间）？WHY！！怎么会这样……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_12_xiaomowang",
	NextID = 62004507,
}
StorySpeechConfig[StorySpeechID.Id62004507] =
{
	Id = 62004507,
	CharName = "骨头兵",
	Text = "小魔王大人，小的听见，这里好像有什么东西碎了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_30_kulou",
	NextID = 62004508,
}
StorySpeechConfig[StorySpeechID.Id62004508] =
{
	Id = 62004508,
	CharName = "指路NPC",
	Text = "妹子，你就跟俺们NPC队一组，好处真的少不了滴！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_10_buluolaoda",
	NextID = 62004509,
}
StorySpeechConfig[StorySpeechID.Id62004509] =
{
	Id = 62004509,
	CharName = "牧师",
	Text = "对不起，我不能加入您的队伍。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_07_mushi",
	NextID = 62004510,
}
StorySpeechConfig[StorySpeechID.Id62004510] =
{
	Id = 62004510,
	CharName = "指路NPC",
	Text = "（拉住牧师）大妹子，你啊……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_10_buluolaoda",
	NextID = 62004511,
}
StorySpeechConfig[StorySpeechID.Id62004511] =
{
	Id = 62004511,
	CharName = "小魔王",
	Text = "（怒）What are you DOING！赶紧给本大爷松开你的手！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_12_xiaomowang",
}
StorySpeechConfig[StorySpeechID.Id62004601] =
{
	Id = 62004601,
	CharName = "小魔王",
	Text = "小的们！我的酒呢？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_12_xiaomowang",
	NextID = 62004602,
}
StorySpeechConfig[StorySpeechID.Id62004602] =
{
	Id = 62004602,
	CharName = "骨头兵",
	Text = "（费力地搬来酒）呼，呼……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_30_kulou",
	NextID = 62004603,
}
StorySpeechConfig[StorySpeechID.Id62004603] =
{
	Id = 62004603,
	CharName = "小魔王",
	Text = "（叹气）终究我们还是，晚了一步……\nWhy you leave me alone……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_12_xiaomowang",
	NextID = 62004604,
}
StorySpeechConfig[StorySpeechID.Id62004604] =
{
	Id = 62004604,
	CharName = "骨头兵",
	Text = "那我们就以酒壮胆……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_30_kulou",
	NextID = 62004605,
}
StorySpeechConfig[StorySpeechID.Id62004605] =
{
	Id = 62004605,
	CharName = "小魔王",
	Text = "（嘟囔）如果，我早点迈开那一步，我们会不会…… ",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_12_xiaomowang",
	NextID = 62004606,
}
StorySpeechConfig[StorySpeechID.Id62004606] =
{
	Id = 62004606,
	CharName = "骨头兵",
	Text = "虽然小的听不懂小魔王大人在说什么，但明显小魔王大人非常兴奋！已经喜极而泣了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_30_kulou",
	NextID = 62004607,
}
StorySpeechConfig[StorySpeechID.Id62004607] =
{
	Id = 62004607,
	CharName = "骨头兵",
	Text = "所以我们一定不能让小魔王大人失望，祝大队旗开得胜！（喝）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_30_kulou",
	NextID = 62004608,
}
StorySpeechConfig[StorySpeechID.Id62004608] =
{
	Id = 62004608,
	CharName = "骨头兵",
	Text = "哇，这酒好辣……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_30_kulou",
}
StorySpeechConfig[StorySpeechID.Id62004701] =
{
	Id = 62004701,
	CharName = "可乐王子",
	Text = "（开着跑车来到现场）Wuhu~~这么多人？已经可以开一场演唱会了！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_07_kele",
	NextID = 62004702,
}
StorySpeechConfig[StorySpeechID.Id62004702] =
{
	Id = 62004702,
	CharName = "可乐王子",
	Text = "（拿出喇叭）大家一起唱~~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_07_kele",
	NextID = 62004703,
}
StorySpeechConfig[StorySpeechID.Id62004703] =
{
	Id = 62004703,
	CharName = "番茄酱侍卫",
	Text = "（齐声）♪团~结就是力~量~团~结就是力~量~♪",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_31_fanqiejiang",
	NextID = 62004704,
}
StorySpeechConfig[StorySpeechID.Id62004704] =
{
	Id = 62004704,
	CharName = "可乐王子",
	Text = "唱得好！很快就是我登场了，沉醉在我美丽的歌声中吧！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_07_kele",
	NextID = 62004705,
}
StorySpeechConfig[StorySpeechID.Id62004705] =
{
	Id = 62004705,
	CharName = "可乐王子",
	Text = "（大声）♪让我们荡起双桨~♪",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_07_kele",
	NextID = 62004706,
}
StorySpeechConfig[StorySpeechID.Id62004706] =
{
	Id = 62004706,
	CharName = "小魔王",
	Text = "（斜眼）怎么有人在这里，抢本大爷的风头？他是who啊？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_12_xiaomowang",
	NextID = 62004707,
}
StorySpeechConfig[StorySpeechID.Id62004707] =
{
	Id = 62004707,
	CharName = "骨头兵",
	Text = "小魔王大人，您忘了？那个是美食星的可乐王子，您和小的，还一起见过他被冒险者们打得落花流水的样子呢……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_30_kulou",
	NextID = 62004708,
}
StorySpeechConfig[StorySpeechID.Id62004708] =
{
	Id = 62004708,
	CharName = "小魔王",
	Text = "哦！I remember！本大爷才不要输给他！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_12_xiaomowang",
	NextID = 62004709,
}
StorySpeechConfig[StorySpeechID.Id62004709] =
{
	Id = 62004709,
	CharName = "小魔王",
	Text = "（大声）♪~再见了mother今晚我就要远航~♪",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_12_xiaomowang",
	NextID = 62004710,
}
StorySpeechConfig[StorySpeechID.Id62004710] =
{
	Id = 62004710,
	CharName = "可乐王子",
	Text = "（更大声）♪~小船儿推开波浪~♪",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_07_kele",
	NextID = 62004711,
}
StorySpeechConfig[StorySpeechID.Id62004711] =
{
	Id = 62004711,
	CharName = "小魔王",
	Text = "（更更大声）♪Don't worry me~我有快乐和智慧~的桨♪",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_12_xiaomowang",
	NextID = 62004712,
}
StorySpeechConfig[StorySpeechID.Id62004712] =
{
	Id = 62004712,
	CharName = "骨头兵",
	Text = "啊，头好疼啊……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_30_kulou",
}
StorySpeechConfig[StorySpeechID.Id62004801] =
{
	Id = 62004801,
	CharName = "剑士",
	Text = "（举起大宝剑）朋友们，冲啊！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62004802,
}
StorySpeechConfig[StorySpeechID.Id62004802] =
{
	Id = 62004802,
	CharName = "魔法师",
	Text = "（念咒）水系魔法。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_06_mofashi",
	NextID = 62004803,
}
StorySpeechConfig[StorySpeechID.Id62004803] =
{
	Id = 62004803,
	CharName = "剑士",
	Text = "哦哦哦~好快！我的帽子要飞走了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62004804,
}
StorySpeechConfig[StorySpeechID.Id62004804] =
{
	Id = 62004804,
	CharName = "牧师",
	Text = "大家努力向前冲，我会在背后，做你们最坚实的后盾~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_07_mushi",
	NextID = 62004805,
}
StorySpeechConfig[StorySpeechID.Id62004805] =
{
	Id = 62004805,
	CharName = "骨头兵",
	Text = "小……小魔王大人！小的发现，他们那队用水系魔法作弊！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_30_kulou",
	NextID = 62004806,
}
StorySpeechConfig[StorySpeechID.Id62004806] =
{
	Id = 62004806,
	CharName = "小魔王",
	Text = "对啊！大赛没有禁用魔法！哼，他们难道以为我不会吗？（念咒）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_12_xiaomowang",
	NextID = 62004807,
}
StorySpeechConfig[StorySpeechID.Id62004807] =
{
	Id = 62004807,
	CharName = "裁判长",
	Text = "（吹哨）比赛结束！勇者公司冒险者小队获胜！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye_cos10",
	NextID = 62004808,
}
StorySpeechConfig[StorySpeechID.Id62004808] =
{
	Id = 62004808,
	CharName = "小魔王",
	Text = "本大爷还没用魔法，不许stop！你给我住嘴！（戛然而止）……嗯？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_12_xiaomowang",
	NextID = 62004809,
}
StorySpeechConfig[StorySpeechID.Id62004809] =
{
	Id = 62004809,
	CharName = "牧师",
	Text = "（笑）太好啦~我们获胜啦~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_07_mushi",
	NextID = 62004810,
}
StorySpeechConfig[StorySpeechID.Id62004810] =
{
	Id = 62004810,
	CharName = "魔法师",
	Text = "没想到，你这家伙还是挺靠谱的。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_06_mofashi",
	NextID = 62004811,
}
StorySpeechConfig[StorySpeechID.Id62004811] =
{
	Id = 62004811,
	CharName = "剑士",
	Text = "（笑）嘿嘿，我这双可是拿大宝剑的手。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62004812,
}
StorySpeechConfig[StorySpeechID.Id62004812] =
{
	Id = 62004812,
	CharName = "牧师",
	Text = "太了不起啦~你们好厉害！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_07_mushi",
	NextID = 62004813,
}
StorySpeechConfig[StorySpeechID.Id62004813] =
{
	Id = 62004813,
	CharName = "小魔王",
	Text = "（偷偷脸红）……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_12_xiaomowang",
	NextID = 62004814,
}
StorySpeechConfig[StorySpeechID.Id62004814] =
{
	Id = 62004814,
	CharName = "骨头兵",
	Text = "小魔王大人？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_30_kulou",
	NextID = 62004815,
}
StorySpeechConfig[StorySpeechID.Id62004815] =
{
	Id = 62004815,
	CharName = "小魔王",
	Text = "（转过身去）哼，肯定是你刚刚偷懒了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_12_xiaomowang",
}
StorySpeechConfig[StorySpeechID.Id62004901] =
{
	Id = 62004901,
	CharName = "裁判长",
	Text = "（颁奖中）魔王大队虽败犹荣，获取了第二名的好成绩，让我们一起祝贺他们。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye_cos10",
	NextID = 62004902,
}
StorySpeechConfig[StorySpeechID.Id62004902] =
{
	Id = 62004902,
	CharName = "骨头兵",
	Text = "（鼓掌）啪啪啪……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_30_kulou",
	NextID = 62004903,
}
StorySpeechConfig[StorySpeechID.Id62004903] =
{
	Id = 62004903,
	CharName = "剑士",
	Text = "哈哈哈！手下败将啊！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 62004904,
}
StorySpeechConfig[StorySpeechID.Id62004904] =
{
	Id = 62004904,
	CharName = "牧师",
	Text = "（拍手）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_07_mushi",
	NextID = 62004905,
}
StorySpeechConfig[StorySpeechID.Id62004905] =
{
	Id = 62004905,
	CharName = "小魔王",
	Text = "……谢，谢谢。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_12_xiaomowang",
	NextID = 62004906,
}
StorySpeechConfig[StorySpeechID.Id62004906] =
{
	Id = 62004906,
	CharName = "骨头兵",
	Text = "小魔王大人今天的脸色真红润，是不是晒伤了？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_30_kulou",
	NextID = 62004907,
}
StorySpeechConfig[StorySpeechID.Id62004907] =
{
	Id = 62004907,
	CharName = "裁判长",
	Text = "这是你们的奖杯~下面我将宣布，组委会送给你们的礼物。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye_cos10",
	NextID = 62004908,
}
StorySpeechConfig[StorySpeechID.Id62004908] =
{
	Id = 62004908,
	CharName = "小魔王",
	Text = "什么？还有present！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_12_xiaomowang",
	NextID = 62004909,
}
StorySpeechConfig[StorySpeechID.Id62004909] =
{
	Id = 62004909,
	CharName = "裁判长",
	Text = "给小魔王队长，一份5000ml的防晒霜和美白面膜。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye_cos10",
	NextID = 62004910,
}
StorySpeechConfig[StorySpeechID.Id62004910] =
{
	Id = 62004910,
	CharName = "小魔王",
	Text = "？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_12_xiaomowang",
	NextID = 62004911,
}
StorySpeechConfig[StorySpeechID.Id62004911] =
{
	Id = 62004911,
	CharName = "裁判长",
	Text = "给队伍里的骨头兵，人均一套假发和头皮营养液。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye_cos10",
	NextID = 62004912,
}
StorySpeechConfig[StorySpeechID.Id62004912] =
{
	Id = 62004912,
	CharName = "骨头兵",
	Text = "？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_30_kulou",
	NextID = 62004913,
}
StorySpeechConfig[StorySpeechID.Id62004913] =
{
	Id = 62004913,
	CharName = "裁判长",
	Text = "最后给队伍一副锦旗——努力奋进，笨鸟先飞。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye_cos10",
}
StorySpeechConfig[StorySpeechID.Id62005001] =
{
	Id = 62005001,
	CharName = "小魔王",
	Text = "比赛终于结束了，虽然一直在划水，但真是辛苦我们了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_12_xiaomowang",
	NextID = 62005002,
}
StorySpeechConfig[StorySpeechID.Id62005002] =
{
	Id = 62005002,
	CharName = "小魔王",
	Text = "大家都知道，最近，我们的公司，经历了too many波折，但还好，大家都熬过来了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_12_xiaomowang",
	NextID = 62005003,
}
StorySpeechConfig[StorySpeechID.Id62005003] =
{
	Id = 62005003,
	CharName = "小魔王",
	Text = "之后的日子，希望我们可以一起加油，再创造出更厉害的副本！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_12_xiaomowang",
	NextID = 62005004,
}
StorySpeechConfig[StorySpeechID.Id62005004] =
{
	Id = 62005004,
	CharName = "小魔王",
	Text = "对于那些来探险的guys，一定要给他们一拳重击，绝不允许划水。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_12_xiaomowang",
	NextID = 62005005,
}
StorySpeechConfig[StorySpeechID.Id62005005] =
{
	Id = 62005005,
	CharName = "骨头兵",
	Text = "小魔王大人说得对！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_30_kulou",
	NextID = 62005006,
}
StorySpeechConfig[StorySpeechID.Id62005006] =
{
	Id = 62005006,
	CharName = "小魔王",
	Text = "非常好，接下来我就准备要冒险队里，和他们一起探索更多的副本设计方法了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_12_xiaomowang",
	NextID = 62005007,
}
StorySpeechConfig[StorySpeechID.Id62005007] =
{
	Id = 62005007,
	CharName = "小魔王",
	Text = "我不在的日子里，希望你们不要划水，不要摸鱼，不……（砰！）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_12_xiaomowang",
	NextID = 62005008,
}
StorySpeechConfig[StorySpeechID.Id62005008] =
{
	Id = 62005008,
	CharName = "小魔王",
	Text = "什么声音？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_12_xiaomowang",
	NextID = 62005009,
}
StorySpeechConfig[StorySpeechID.Id62005009] =
{
	Id = 62005009,
	CharName = "村长",
	Text = "（堵在副本口）开门啊小魔王，我知道你在里面！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye",
	NextID = 62005010,
}
StorySpeechConfig[StorySpeechID.Id62005010] =
{
	Id = 62005010,
	CharName = "小魔王",
	Text = "（突然出现）Hello？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_12_xiaomowang",
	NextID = 62005011,
}
StorySpeechConfig[StorySpeechID.Id62005011] =
{
	Id = 62005011,
	CharName = "村长",
	Text = "听说你们又回来上班了？我们的副本是不是又能运转起来了？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye",
	NextID = 62005012,
}
StorySpeechConfig[StorySpeechID.Id62005012] =
{
	Id = 62005012,
	CharName = "村长",
	Text = "我已经好久没颁布任务了……想想从你和勇者们手上拿回扣的那些日子，真是怀念啊……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye",
	NextID = 62005013,
}
StorySpeechConfig[StorySpeechID.Id62005013] =
{
	Id = 62005013,
	CharName = "小魔王",
	Text = "Wait！我正准备回冒险队，你不打算回去？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_12_xiaomowang",
	NextID = 62005014,
}
StorySpeechConfig[StorySpeechID.Id62005014] =
{
	Id = 62005014,
	CharName = "村长",
	Text = "回去？不行！我还要继续赚钱……啊，你别拖我！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye",
	NextID = 62005015,
}
StorySpeechConfig[StorySpeechID.Id62005015] =
{
	Id = 62005015,
	CharName = "小魔王",
	Text = "哼，本大爷作为反派，怎么能被你使唤？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_12_xiaomowang",
	NextID = 62005016,
}
StorySpeechConfig[StorySpeechID.Id62005016] =
{
	Id = 62005016,
	CharName = "村长",
	Text = "你这家伙，不给你点颜色看看，还真不把我当前任勇者了？！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye",
}
StorySpeechConfig[StorySpeechID.Id62005101] =
{
	Id = 62005101,
	CharName = "七织",
	Text = "毕！业！快！乐！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_20_QiZhi",
	NextID = 62005102,
}
StorySpeechConfig[StorySpeechID.Id62005102] =
{
	Id = 62005102,
	CharName = "单反相机",
	Text = "“咔嚓——”",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	RightIcon = "Equipment_SPBUS_15_ErJv_1",
	NextID = 62005103,
}
StorySpeechConfig[StorySpeechID.Id62005103] =
{
	Id = 62005103,
	CharName = "呐喊家",
	Text = "（大声）拍完了，下一组——",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_19_nahan",
	NextID = 62005104,
}
StorySpeechConfig[StorySpeechID.Id62005104] =
{
	Id = 62005104,
	CharName = "一心",
	Text = "（看手表）用时1分钟28秒，和预想中的时间相差不大。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_14_YiXin",
	NextID = 62005105,
}
StorySpeechConfig[StorySpeechID.Id62005105] =
{
	Id = 62005105,
	CharName = "五行",
	Text = "也就是说，从现在起，我们的暑假就正式开始了。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_18_WuXing",
	NextID = 62005106,
}
StorySpeechConfig[StorySpeechID.Id62005106] =
{
	Id = 62005106,
	CharName = "六瑶",
	Text = "那、那个…大家，有什么计划吗，比如、家里蹲之类的…",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_19_LiuYao",
	NextID = 62005107,
}
StorySpeechConfig[StorySpeechID.Id62005107] =
{
	Id = 62005107,
	CharName = "七织",
	Text = "当然不可能家里蹲啦！！（大声）我提议！！我们一起，去流亡街参加庙会！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_20_QiZhi",
	NextID = 62005108,
}
StorySpeechConfig[StorySpeechID.Id62005108] =
{
	Id = 62005108,
	CharName = "三花",
	Text = "喵？流亡街？喵会？！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_16_SanHua",
	NextID = 62005109,
}
StorySpeechConfig[StorySpeechID.Id62005109] =
{
	Id = 62005109,
	CharName = "一心",
	Text = "我记得你三天前说，想去美食星旅游。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_14_YiXin",
	NextID = 62005110,
}
StorySpeechConfig[StorySpeechID.Id62005110] =
{
	Id = 62005110,
	CharName = "七织",
	Text = "真的吗？！啊哈哈，那个…可是！好不容易才有的暑假，当然要去更有意思的地方了！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_20_QiZhi",
	NextID = 62005111,
}
StorySpeechConfig[StorySpeechID.Id62005111] =
{
	Id = 62005111,
	CharName = "七织",
	Text = "况且，之前也有新闻说，美食星通货膨胀，店家宰客，哇真是太恶劣了！！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_20_QiZhi",
	NextID = 62005112,
}
StorySpeechConfig[StorySpeechID.Id62005112] =
{
	Id = 62005112,
	CharName = "三花",
	Text = "（抱住七织）是喵！他们那里好坑的喵，连买鲷鱼烧的橘猫都欺负！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_16_SanHua",
	NextID = 62005113,
}
StorySpeechConfig[StorySpeechID.Id62005113] =
{
	Id = 62005113,
	CharName = "六瑶",
	Text = "可是，那个…那个…要去星球外的地方…感觉好危险，我还是想在家里…",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_19_LiuYao",
	NextID = 62005114,
}
StorySpeechConfig[StorySpeechID.Id62005114] =
{
	Id = 62005114,
	CharName = "一心",
	Text = "从这里到流亡街，坐普通飞船需要5天半，坐高速飞船需要36小时，但价格会提高三倍。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_14_YiXin",
	NextID = 62005115,
}
StorySpeechConfig[StorySpeechID.Id62005115] =
{
	Id = 62005115,
	CharName = "一心",
	Text = "目前流亡街缺乏清晰的管理规范，导致犯罪分子出没，所以…",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_14_YiXin",
	NextID = 62005116,
}
StorySpeechConfig[StorySpeechID.Id62005116] =
{
	Id = 62005116,
	CharName = "七织",
	Text = "（打断知识输出）所以，我们可以帮助警察抓捕犯人！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_20_QiZhi",
	NextID = 62005117,
}
StorySpeechConfig[StorySpeechID.Id62005117] =
{
	Id = 62005117,
	CharName = "六瑶",
	Text = "什、什么？这也太、太危险了！我…说什么都不能去那种地方…",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_19_LiuYao",
	NextID = 62005118,
}
StorySpeechConfig[StorySpeechID.Id62005118] =
{
	Id = 62005118,
	CharName = "三花",
	Text = "不可怕喵~不管什么，都没有四荔的恶作剧可怕。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_16_SanHua",
	NextID = 62005119,
}
StorySpeechConfig[StorySpeechID.Id62005119] =
{
	Id = 62005119,
	CharName = "四荔",
	Text = "？？？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_17_SiLi",
	NextID = 62005120,
}
StorySpeechConfig[StorySpeechID.Id62005120] =
{
	Id = 62005120,
	CharName = "二橘",
	Text = "…别吵了，真是的，你们能不能好好听一心说完。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_15_ErJv",
	NextID = 62005121,
}
StorySpeechConfig[StorySpeechID.Id62005121] =
{
	Id = 62005121,
	CharName = "五行",
	Text = "其实，如果要去那里的话，我可以帮忙。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_18_WuXing",
	NextID = 62005122,
}
StorySpeechConfig[StorySpeechID.Id62005122] =
{
	Id = 62005122,
	CharName = "二橘",
	Text = "（警惕）…哪种意义上的帮忙？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_15_ErJv",
	NextID = 62005123,
}
StorySpeechConfig[StorySpeechID.Id62005123] =
{
	Id = 62005123,
	CharName = "五行",
	Text = "你们可以坐我家的飞船，速度很快，一瞬间就把人送走了。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_18_WuXing",
	NextID = 62005124,
}
StorySpeechConfig[StorySpeechID.Id62005124] =
{
	Id = 62005124,
	CharName = "四荔",
	Text = "不愧是五行，你真是样样行。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_17_SiLi",
	NextID = 62005125,
}
StorySpeechConfig[StorySpeechID.Id62005125] =
{
	Id = 62005125,
	CharName = "五行",
	Text = "不过钥匙...你们知道的，不在我这里，或许，我们集体去说服我爸爸妈妈？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_18_WuXing",
	NextID = 62005126,
}
StorySpeechConfig[StorySpeechID.Id62005126] =
{
	Id = 62005126,
	CharName = "五行",
	Text = "（思索）嗯...或许有更好的解决方式。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_18_WuXing",
	NextID = 62005127,
}
StorySpeechConfig[StorySpeechID.Id62005127] =
{
	Id = 62005127,
	CharName = "旁白喇叭",
	Text = "两小时后，一位铁匠出现了。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	RightIcon = "EventItem_RPG_Event_8",
	NextID = 62005128,
}
StorySpeechConfig[StorySpeechID.Id62005128] =
{
	Id = 62005128,
	CharName = "铁匠",
	Text = "这，这活俺不能接啊，你可知道，这算是用不正当手段获取他人的交通工具，妥妥的违法啊！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_31_tiejiang",
	NextID = 62005129,
}
StorySpeechConfig[StorySpeechID.Id62005129] =
{
	Id = 62005129,
	CharName = "五行",
	Text = "这是我家的，我同意了。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_18_WuXing",
	NextID = 62005130,
}
StorySpeechConfig[StorySpeechID.Id62005130] =
{
	Id = 62005130,
	CharName = "铁匠",
	Text = "这，这不行……诶你们，你们——！咋还多打一呢？不合适！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_31_tiejiang",
}
StorySpeechConfig[StorySpeechID.Id62005151] =
{
	Id = 62005151,
	CharName = "三花",
	Text = "七织...好猛喵。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_16_SanHua",
	NextID = 62005152,
}
StorySpeechConfig[StorySpeechID.Id62005152] =
{
	Id = 62005152,
	CharName = "二橘",
	Text = "…这就是你说的，更好的解决方式？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_15_ErJv",
	NextID = 62005153,
}
StorySpeechConfig[StorySpeechID.Id62005153] =
{
	Id = 62005153,
	CharName = "七织",
	Text = "（大声）姐妹们！大家别发呆了！快上船！\n庙~会！庙~会！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_20_QiZhi",
	NextID = 62005154,
}
StorySpeechConfig[StorySpeechID.Id62005154] =
{
	Id = 62005154,
	CharName = "三花",
	Text = "喵~会！喵~会！喵~唔啊啊啊啊！！（吓）",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_16_SanHua",
	NextID = 62005155,
}
StorySpeechConfig[StorySpeechID.Id62005155] =
{
	Id = 62005155,
	CharName = "四荔",
	Text = "可怜的小三花，又被吓到了~（摸）给你顺顺毛。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_17_SiLi",
	NextID = 62005156,
}
StorySpeechConfig[StorySpeechID.Id62005156] =
{
	Id = 62005156,
	CharName = "三花",
	Text = "不要在这种时候，用你的假蜘蛛吓我喵！！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_16_SanHua",
	NextID = 62005157,
}
StorySpeechConfig[StorySpeechID.Id62005157] =
{
	Id = 62005157,
	CharName = "七织",
	Text = "喂！！快上来，我们要出发了！过时不候哦！！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_20_QiZhi",
}
StorySpeechConfig[StorySpeechID.Id62005201] =
{
	Id = 62005201,
	CharName = "七织",
	Text = "（警觉）是真的！流亡街上有浓浓的，犯罪的气息…",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_20_QiZhi",
	NextID = 62005202,
}
StorySpeechConfig[StorySpeechID.Id62005202] =
{
	Id = 62005202,
	CharName = "三花",
	Text = "（耸鼻子）是小吃摊位上烤肉串的焦味喵。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_16_SanHua",
	NextID = 62005203,
}
StorySpeechConfig[StorySpeechID.Id62005203] =
{
	Id = 62005203,
	CharName = "玉米",
	Text = "“嘭——！”",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	LeftIcon = "Equipment_Fat_22_baomihua_1",
	NextID = 62005204,
}
StorySpeechConfig[StorySpeechID.Id62005204] =
{
	Id = 62005204,
	CharName = "六瑶",
	Text = "啊——救命！有枪声！别杀我，呜呜…",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_19_LiuYao",
	NextID = 62005205,
}
StorySpeechConfig[StorySpeechID.Id62005205] =
{
	Id = 62005205,
	CharName = "三花",
	Text = "…是爆米花的声音喵。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_16_SanHua",
	NextID = 62005206,
}
StorySpeechConfig[StorySpeechID.Id62005206] =
{
	Id = 62005206,
	CharName = "一心",
	Text = "（叹气）你们太缺乏纪律性了，还有，七织，别忘了我们在飞船上的承诺。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_14_YiXin",
	NextID = 62005207,
}
StorySpeechConfig[StorySpeechID.Id62005207] =
{
	Id = 62005207,
	CharName = "七织",
	Text = "知道了，不准单独行动，不准丢下大家，不准…总之就是——约法三章。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_20_QiZhi",
	NextID = 62005208,
}
StorySpeechConfig[StorySpeechID.Id62005208] =
{
	Id = 62005208,
	CharName = "一心",
	Text = "你根本没有记住，我列出的25条禁止事项，第一，不能……",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_14_YiXin",
	NextID = 62005209,
}
StorySpeechConfig[StorySpeechID.Id62005209] =
{
	Id = 62005209,
	CharName = "七织",
	Text = "噢！！那边有在冒气泡的饮料，你们看！！这个这个，海报上这坨绿的是汽水王子，据说是美食星的大明星！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_20_QiZhi",
	NextID = 62005210,
}
StorySpeechConfig[StorySpeechID.Id62005210] =
{
	Id = 62005210,
	CharName = "七织",
	Text = "（摸头发）啊，真想把这玩意儿染成蓝的。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_20_QiZhi",
	NextID = 62005211,
}
StorySpeechConfig[StorySpeechID.Id62005211] =
{
	Id = 62005211,
	CharName = "一心",
	Text = "算了，预料之中，25条禁令对你根本没有用。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_14_YiXin",
	NextID = 62005212,
}
StorySpeechConfig[StorySpeechID.Id62005212] =
{
	Id = 62005212,
	CharName = "二橘",
	Text = "毕竟她就是那——\n（撞）喂！你走路的时候不看路吗？！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_15_ErJv",
	NextID = 62005213,
}
StorySpeechConfig[StorySpeechID.Id62005213] =
{
	Id = 62005213,
	CharName = "三花",
	Text = "（摸头）不气不气~这里人来人往的，很容易冲撞到人的喵~我们自己小心喵。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_16_SanHua",
	NextID = 62005214,
}
StorySpeechConfig[StorySpeechID.Id62005214] =
{
	Id = 62005214,
	CharName = "一心",
	Text = "大家排成一列向前走吧，以免走散。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_14_YiXin",
	NextID = 62005215,
}
StorySpeechConfig[StorySpeechID.Id62005215] =
{
	Id = 62005215,
	CharName = "二橘",
	Text = "…像小学生过家家。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_15_ErJv",
	NextID = 62005216,
}
StorySpeechConfig[StorySpeechID.Id62005216] =
{
	Id = 62005216,
	CharName = "六瑶",
	Text = "那个…七织，我有点害怕这里，你、你能不能牵住我…\n呀！！（捂住裙子）",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_19_LiuYao",
	NextID = 62005217,
}
StorySpeechConfig[StorySpeechID.Id62005217] =
{
	Id = 62005217,
	CharName = "飙车王",
	Text = "嘿嘿。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	RightIcon = "Pir_03_RacingDriver",
}
StorySpeechConfig[StorySpeechID.Id62005251] =
{
	Id = 62005251,
	CharName = "飙车王",
	Text = "小妹妹们还挺能打啊~不陪你们玩喽~\n溜了溜了。（砰——）",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	RightIcon = "Pir_03_RacingDriver",
	NextID = 62005252,
}
StorySpeechConfig[StorySpeechID.Id62005252] =
{
	Id = 62005252,
	CharName = "飙车王",
	Text = "呃…疼…",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	RightIcon = "Pir_03_RacingDriver",
	NextID = 62005253,
}
StorySpeechConfig[StorySpeechID.Id62005253] =
{
	Id = 62005253,
	CharName = "六瑶",
	Text = "（小声）那个…七织，这就叫做“人倒马番”吗...",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_19_LiuYao",
	NextID = 62005254,
}
StorySpeechConfig[StorySpeechID.Id62005254] =
{
	Id = 62005254,
	CharName = "五行",
	Text = "是人仰马翻。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_18_WuXing",
	NextID = 62005255,
}
StorySpeechConfig[StorySpeechID.Id62005255] =
{
	Id = 62005255,
	CharName = "飙车王",
	Text = "（看到地上的香蕉皮）*****，谁干的！一点素质都没有！",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	LeftIcon = "Pir_03_RacingDriver",
	NextID = 62005256,
}
StorySpeechConfig[StorySpeechID.Id62005256] =
{
	Id = 62005256,
	CharName = "七织",
	Text = "（小声）四荔，你好厉害！神不知鬼不觉，就把香蕉皮放那儿了。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_20_QiZhi",
	NextID = 62005257,
}
StorySpeechConfig[StorySpeechID.Id62005257] =
{
	Id = 62005257,
	CharName = "四荔",
	Text = "（捂嘴）嘘！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_17_SiLi",
	NextID = 62005258,
}
StorySpeechConfig[StorySpeechID.Id62005258] =
{
	Id = 62005258,
	CharName = "旁白喇叭",
	Text = "另一边的摊位上…",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	RightIcon = "EventItem_RPG_Event_8",
	NextID = 62005259,
}
StorySpeechConfig[StorySpeechID.Id62005259] =
{
	Id = 62005259,
	CharName = "月佬",
	Text = "（扇风）迢迢牵牛星，皎皎河汉女。纤纤擢素手，札札弄机杼...",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_21_YueLao",
	NextID = 62005260,
}
StorySpeechConfig[StorySpeechID.Id62005260] =
{
	Id = 62005260,
	CharName = "月佬",
	Text = "（警觉）诶？那个少女…",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_21_YueLao",
	NextID = 62005261,
}
StorySpeechConfig[StorySpeechID.Id62005261] =
{
	Id = 62005261,
	CharName = "月佬",
	Text = "眼波如水，面胜桃花…",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_21_YueLao",
	NextID = 62005262,
}
StorySpeechConfig[StorySpeechID.Id62005262] =
{
	Id = 62005262,
	CharName = "月佬",
	Text = "好姻缘，千年难遇的好姻缘！可给我逮着了！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_21_YueLao",
}
StorySpeechConfig[StorySpeechID.Id62005301] =
{
	Id = 62005301,
	CharName = "七织",
	Text = "（左瞅瞅右看看）哇！！这个弹珠会发光！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_20_QiZhi",
	NextID = 62005302,
}
StorySpeechConfig[StorySpeechID.Id62005302] =
{
	Id = 62005302,
	CharName = "五行",
	Text = "怎么会有可乐味的炸鸡翅？真的不是黑暗料理吗…",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_18_WuXing",
	NextID = 62005303,
}
StorySpeechConfig[StorySpeechID.Id62005303] =
{
	Id = 62005303,
	CharName = "四荔",
	Text = "我很快就是成年人了，喝一口带酒的汽水应该没问题吧...",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_17_SiLi",
	NextID = 62005304,
}
StorySpeechConfig[StorySpeechID.Id62005304] =
{
	Id = 62005304,
	CharName = "七织",
	Text = "那边好多人在排队…\n喂！大家！我过去看看，很快就回来！（溜）",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_20_QiZhi",
	NextID = 62005305,
}
StorySpeechConfig[StorySpeechID.Id62005305] =
{
	Id = 62005305,
	CharName = "月佬",
	Text = "（盯）…落单了？这就是缘分啊，缘分…",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_21_YueLao",
	NextID = 62005306,
}
StorySpeechConfig[StorySpeechID.Id62005306] =
{
	Id = 62005306,
	CharName = "一心",
	Text = "（警觉）糟糕，刚刚应该看住小七的。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_14_YiXin",
	NextID = 62005307,
}
StorySpeechConfig[StorySpeechID.Id62005307] =
{
	Id = 62005307,
	CharName = "五行",
	Text = "（吃巧果）没关系，我们就...（咀嚼）rrr@#…在这里等她吧。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_18_WuXing",
	NextID = 62005308,
}
StorySpeechConfig[StorySpeechID.Id62005308] =
{
	Id = 62005308,
	CharName = "五行",
	Text = "（吃）小七受不了那么长的队伍，大概排一会儿就回来了。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_18_WuXing",
	NextID = 62005309,
}
StorySpeechConfig[StorySpeechID.Id62005309] =
{
	Id = 62005309,
	CharName = "二橘",
	Text = "真是的，我们那么多人，等她一个人么？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_15_ErJv",
	NextID = 62005310,
}
StorySpeechConfig[StorySpeechID.Id62005310] =
{
	Id = 62005310,
	CharName = "四荔",
	Text = "既然要停在原地等她，那我们来玩点什么吧？（拿出饼干）来，大家一人一块~",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_17_SiLi",
	NextID = 62005311,
}
StorySpeechConfig[StorySpeechID.Id62005311] =
{
	Id = 62005311,
	CharName = "五行",
	Text = "我拒绝。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_18_WuXing",
	NextID = 62005312,
}
StorySpeechConfig[StorySpeechID.Id62005312] =
{
	Id = 62005312,
	CharName = "一心",
	Text = "我绝不会吃你的特制饼干，100%不可能。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_14_YiXin",
	NextID = 62005313,
}
StorySpeechConfig[StorySpeechID.Id62005313] =
{
	Id = 62005313,
	CharName = "旁白喇叭",
	Text = "另一边，兴致勃勃的七织等待许久，终于成功排到了。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	RightIcon = "EventItem_RPG_Event_8",
	NextID = 62005314,
}
StorySpeechConfig[StorySpeechID.Id62005314] =
{
	Id = 62005314,
	CharName = "捞鱼店老板",
	Text = "客官里面请~这儿有三个池子，选哪一个呀？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_GoldFishShopBoss",
	NextID = 62005315,
}
StorySpeechConfig[StorySpeechID.Id62005315] =
{
	Id = 62005315,
	CharName = "七织",
	Text = "（尴尬）这里…原来…不是卖金鱼糕的呀…",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_20_QiZhi",
	NextID = 62005316,
}
StorySpeechConfig[StorySpeechID.Id62005316] =
{
	Id = 62005316,
	CharName = "捞鱼店老板",
	Text = "没事没事~来都来了，就来捞一次吧！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_GoldFishShopBoss",
	NextID = 62005317,
}
StorySpeechConfig[StorySpeechID.Id62005317] =
{
	Id = 62005317,
	CharName = "捞鱼店老板",
	Text = "今天还有个小游戏，只要闯关成功，捞出足够的鱼，就可以拿到兑换券，去隔壁的服装店免费兑换衣服…喏，就是那边，排队那家。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_GoldFishShopBoss",
	NextID = 62005318,
}
StorySpeechConfig[StorySpeechID.Id62005318] =
{
	Id = 62005318,
	CharName = "捞鱼店老板",
	Text = "这游戏特别受年轻人喜欢，你看，我店里几个小弟刚玩完，又跑去后头排队了。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_GoldFishShopBoss",
	NextID = 62005319,
}
StorySpeechConfig[StorySpeechID.Id62005319] =
{
	Id = 62005319,
	CharName = "七织",
	Text = "这么贵的礼物吗！我来！（拿起网兜）",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_20_QiZhi",
	NextID = 62005320,
}
StorySpeechConfig[StorySpeechID.Id62005320] =
{
	Id = 62005320,
	CharName = "旁白喇叭",
	Text = "啪叽——",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "EventItem_RPG_Event_8",
	NextID = 62005321,
}
StorySpeechConfig[StorySpeechID.Id62005321] =
{
	Id = 62005321,
	CharName = "七织",
	Text = "诶？除了捞一个点的鱼，还可以横着捞一整排的吗？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_20_QiZhi",
	NextID = 62005322,
}
StorySpeechConfig[StorySpeechID.Id62005322] =
{
	Id = 62005322,
	CharName = "捞鱼店老板",
	Text = "是啊，捞一个点儿，一横排，一竖排，捞个十字…随你怎么捞，哈哈…",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_GoldFishShopBoss",
	NextID = 62005323,
}
StorySpeechConfig[StorySpeechID.Id62005323] =
{
	Id = 62005323,
	CharName = "七织",
	Text = "那我就要大显身手了！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_20_QiZhi",
}
StorySpeechConfig[StorySpeechID.Id62005351] =
{
	Id = 62005351,
	CharName = "七织",
	Text = "好耶，成功！\n（看字）获得此票，即可兑换店铺任意服装一套，不可重复使用，解释权归本店铺所有。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_20_QiZhi",
	NextID = 62005352,
}
StorySpeechConfig[StorySpeechID.Id62005352] =
{
	Id = 62005352,
	CharName = "旁白喇叭",
	Text = "七织看完票券，恰好踱步至服装店旁。店里灯光璀璨，明亮的橱窗里站着挺拔的假人，穿着闪闪发亮的裙子。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "EventItem_RPG_Event_8",
	NextID = 62005353,
}
StorySpeechConfig[StorySpeechID.Id62005353] =
{
	Id = 62005353,
	CharName = "旁白喇叭",
	Text = "七织憧憬的目光来回游移，最后莫名定格在工作的男孩身上。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "EventItem_RPG_Event_8",
	NextID = 62005354,
}
StorySpeechConfig[StorySpeechID.Id62005354] =
{
	Id = 62005354,
	CharName = "七织",
	Text = "（这里只有一个工作人员吗？应付这么多顾客一定很辛苦吧？）",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_20_QiZhi",
	NextID = 62005355,
}
StorySpeechConfig[StorySpeechID.Id62005355] =
{
	Id = 62005355,
	CharName = "旁白喇叭",
	Text = "服装店里的少年，正在操作着收银机，因为联动活动，今晚的销量出奇得高。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "EventItem_RPG_Event_8",
	NextID = 62005356,
}
StorySpeechConfig[StorySpeechID.Id62005356] =
{
	Id = 62005356,
	CharName = "旁白喇叭",
	Text = "下一秒，他举起手来擦拭额头的汗珠，不经意间的侧目，恰好和街上的少女目光交汇。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "EventItem_RPG_Event_8",
	NextID = 62005357,
}
StorySpeechConfig[StorySpeechID.Id62005357] =
{
	Id = 62005357,
	CharName = "旁白喇叭",
	Text = "两个人同时愣住，又如出一辙地收回眼光，看向前方。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "EventItem_RPG_Event_8",
	NextID = 62005358,
}
StorySpeechConfig[StorySpeechID.Id62005358] =
{
	Id = 62005358,
	CharName = "旁白喇叭",
	Text = "刹那间，闷热的流亡街起风了。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "EventItem_RPG_Event_8",
}
StorySpeechConfig[StorySpeechID.Id62005401] =
{
	Id = 62005401,
	CharName = "七织",
	Text = "你好，我想要那套粉色的衣服。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_20_QiZhi",
	NextID = 62005402,
}
StorySpeechConfig[StorySpeechID.Id62005402] =
{
	Id = 62005402,
	CharName = "牵牛",
	Text = "好的，（小声）这件好看。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_13_QianNiu",
	NextID = 62005403,
}
StorySpeechConfig[StorySpeechID.Id62005403] =
{
	Id = 62005403,
	CharName = "七织",
	Text = "嗯？你刚刚说什么？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_20_QiZhi",
	NextID = 62005404,
}
StorySpeechConfig[StorySpeechID.Id62005404] =
{
	Id = 62005404,
	CharName = "牵牛",
	Text = "（脸红）今晚顾客很多…她们，都会在我们店里，换上带有古典元素的衣服…这种风格的衣服，好看。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_13_QianNiu",
	NextID = 62005405,
}
StorySpeechConfig[StorySpeechID.Id62005405] =
{
	Id = 62005405,
	CharName = "牵牛",
	Text = "（打包好衣服）谢谢光临。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_13_QianNiu",
	NextID = 62005406,
}
StorySpeechConfig[StorySpeechID.Id62005406] =
{
	Id = 62005406,
	CharName = "七织",
	Text = "也谢谢你，拜拜~（挥手）",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_20_QiZhi",
	NextID = 62005407,
}
StorySpeechConfig[StorySpeechID.Id62005407] =
{
	Id = 62005407,
	CharName = "七织",
	Text = "（走出服装店）诶！她们人呢？！！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_20_QiZhi",
	NextID = 62005408,
}
StorySpeechConfig[StorySpeechID.Id62005408] =
{
	Id = 62005408,
	CharName = "旁白喇叭",
	Text = "另一边…",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	RightIcon = "EventItem_RPG_Event_8",
	NextID = 62005409,
}
StorySpeechConfig[StorySpeechID.Id62005409] =
{
	Id = 62005409,
	CharName = "一心",
	Text = "已经过去二十三分钟十七秒了，合理怀疑，七织忘记了回来的路。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_14_YiXin",
	NextID = 62005410,
}
StorySpeechConfig[StorySpeechID.Id62005410] =
{
	Id = 62005410,
	CharName = "二橘",
	Text = "这家伙…根本不让人省心。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_15_ErJv",
	NextID = 62005411,
}
StorySpeechConfig[StorySpeechID.Id62005411] =
{
	Id = 62005411,
	CharName = "五行",
	Text = "根据我对小七的了解，大概是走着走着，进了一家有意思的店，出来之后晕头转向，不记得来时的路了。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_18_WuXing",
	NextID = 62005412,
}
StorySpeechConfig[StorySpeechID.Id62005412] =
{
	Id = 62005412,
	CharName = "六瑶",
	Text = "那个…不是说，这里有很多罪犯吗，小七会不会被绑架…呜，听说以前有人被骗进服装店，然后被卖到了…",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_19_LiuYao",
	NextID = 62005413,
}
StorySpeechConfig[StorySpeechID.Id62005413] =
{
	Id = 62005413,
	CharName = "二橘",
	Text = "停——那我们去找她好了，在这里七嘴八舌，根本无济于事嘛。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_15_ErJv",
	NextID = 62005414,
}
StorySpeechConfig[StorySpeechID.Id62005414] =
{
	Id = 62005414,
	CharName = "四荔",
	Text = "二橘，你先别急着走啊…",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_17_SiLi",
	NextID = 62005415,
}
StorySpeechConfig[StorySpeechID.Id62005415] =
{
	Id = 62005415,
	CharName = "一心",
	Text = "你们等——（哐！）",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_14_YiXin",
	NextID = 62005416,
}
StorySpeechConfig[StorySpeechID.Id62005416] =
{
	Id = 62005416,
	CharName = "占位路障",
	Text = "……？",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	RightIcon = "Arena_SUS_YellowBarrier",
	NextID = 62005417,
}
StorySpeechConfig[StorySpeechID.Id62005417] =
{
	Id = 62005417,
	CharName = "五行",
	Text = "麻烦让让，我们的朋友在那边。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_18_WuXing",
	NextID = 62005418,
}
StorySpeechConfig[StorySpeechID.Id62005418] =
{
	Id = 62005418,
	CharName = "占位路障",
	Text = "噢…太、懒、了…不、想、动…",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	RightIcon = "Arena_SUS_YellowBarrier",
	NextID = 62005419,
}
StorySpeechConfig[StorySpeechID.Id62005419] =
{
	Id = 62005419,
	CharName = "三花",
	Text = "这都什么时候了，怎么还遇上你这种捣蛋的家伙喵！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_16_SanHua",
}
StorySpeechConfig[StorySpeechID.Id62005451] =
{
	Id = 62005451,
	CharName = "五行",
	Text = "报告，她们俩…连影子都看不见了。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_18_WuXing",
	NextID = 62005452,
}
StorySpeechConfig[StorySpeechID.Id62005452] =
{
	Id = 62005452,
	CharName = "一心",
	Text = "那么，我们剩下的四人，绝对不可以分开了。（回头）哎？五行，三花和六瑶呢？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_14_YiXin",
	NextID = 62005453,
}
StorySpeechConfig[StorySpeechID.Id62005453] =
{
	Id = 62005453,
	CharName = "五行",
	Text = "哈？她们也不见了吗？（拿出手机）我去问问她们…\n糟了，没信号。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_18_WuXing",
	NextID = 62005454,
}
StorySpeechConfig[StorySpeechID.Id62005454] =
{
	Id = 62005454,
	CharName = "一心",
	Text = "没信号的意思，就是联系不到吗…（沉思）那么，我们徒步去找她们吧？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_14_YiXin",
	NextID = 62005455,
}
StorySpeechConfig[StorySpeechID.Id62005455] =
{
	Id = 62005455,
	CharName = "五行",
	Text = "（思索）…也不是不可以。\n（拿出地图和笔）这就交给我吧，只要准备做得好，不愁同伴找不着。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_18_WuXing",
	NextID = 62005456,
}
StorySpeechConfig[StorySpeechID.Id62005456] =
{
	Id = 62005456,
	CharName = "六瑶",
	Text = "（另一边）三、三花...一心和五行不见了！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_19_LiuYao",
	NextID = 62005457,
}
StorySpeechConfig[StorySpeechID.Id62005457] =
{
	Id = 62005457,
	CharName = "三花",
	Text = "喵？？难道流亡街里，有会巫术的人，把小心和小行变没了喵！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_16_SanHua",
	NextID = 62005458,
}
StorySpeechConfig[StorySpeechID.Id62005458] =
{
	Id = 62005458,
	CharName = "六瑶",
	Text = "呜呜，果、果然还是应该选择家里蹲…好可怕…",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_19_LiuYao",
	NextID = 62005459,
}
StorySpeechConfig[StorySpeechID.Id62005459] =
{
	Id = 62005459,
	CharName = "六瑶",
	Text = "果然还是应该选择家里蹲，呜呜呜...",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_19_LiuYao",
}
StorySpeechConfig[StorySpeechID.Id62005501] =
{
	Id = 62005501,
	CharName = "五行",
	Text = "（走到金鱼街）这个店铺，好像是这次庙会的核心活动点…哇，好长的队伍，是在排金鱼糕吗？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_18_WuXing",
	NextID = 62005502,
}
StorySpeechConfig[StorySpeechID.Id62005502] =
{
	Id = 62005502,
	CharName = "一心",
	Text = "一共125人排队，没有七织，我们可以去询问店主。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_14_YiXin",
	NextID = 62005503,
}
StorySpeechConfig[StorySpeechID.Id62005503] =
{
	Id = 62005503,
	CharName = "一心",
	Text = "店主是一只水獭，说是工作，然而据我所见，完全在划水，能问出有效信息的概率大约为…1.4%。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_14_YiXin",
	NextID = 62005504,
}
StorySpeechConfig[StorySpeechID.Id62005504] =
{
	Id = 62005504,
	CharName = "五行",
	Text = "管他呢，来都来了。\n（凑近）老板，你见过一个穿粉色衣服的小姑娘吗？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_18_WuXing",
	NextID = 62005505,
}
StorySpeechConfig[StorySpeechID.Id62005505] =
{
	Id = 62005505,
	CharName = "捞鱼店老板",
	Text = "粉色衣服？（回想）今天来捞鱼的人太多啦，我实在记不清…",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_GoldFishShopBoss",
	NextID = 62005506,
}
StorySpeechConfig[StorySpeechID.Id62005506] =
{
	Id = 62005506,
	CharName = "捞鱼店老板",
	Text = "不过，咱们这儿的游客，一般都是先捞鱼，再去服装店换奖品…我看，你们可以去服装店问问。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_GoldFishShopBoss",
	NextID = 62005507,
}
StorySpeechConfig[StorySpeechID.Id62005507] =
{
	Id = 62005507,
	CharName = "五行",
	Text = "谢谢您！（看向一心）你看，这不就有有效信息了吗？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_18_WuXing",
	NextID = 62005508,
}
StorySpeechConfig[StorySpeechID.Id62005508] =
{
	Id = 62005508,
	CharName = "旁白喇叭",
	Text = "一心和五行经过服装店时，里面闹哄哄的，似乎发生了争执，二人竖起耳朵，齐齐开始偷听。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	RightIcon = "EventItem_RPG_Event_8",
	NextID = 62005509,
}
StorySpeechConfig[StorySpeechID.Id62005509] =
{
	Id = 62005509,
	CharName = "金发女",
	Text = "那个一直在这里收银的实习生去哪了？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_women2",
	NextID = 62005510,
}
StorySpeechConfig[StorySpeechID.Id62005510] =
{
	Id = 62005510,
	CharName = "服装店店主",
	Text = "（摊手）走了。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_ClothesShopBoss",
	NextID = 62005511,
}
StorySpeechConfig[StorySpeechID.Id62005511] =
{
	Id = 62005511,
	CharName = "金发女",
	Text = "你什么态度？我好不容易排到这儿的，让他来收我的券。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_women2",
	NextID = 62005512,
}
StorySpeechConfig[StorySpeechID.Id62005512] =
{
	Id = 62005512,
	CharName = "服装店店主",
	Text = "（耸肩）没辙。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_ClothesShopBoss",
	NextID = 62005513,
}
StorySpeechConfig[StorySpeechID.Id62005513] =
{
	Id = 62005513,
	CharName = "金发女",
	Text = "你……！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_women2",
	NextID = 62005514,
}
StorySpeechConfig[StorySpeechID.Id62005514] =
{
	Id = 62005514,
	CharName = "一心",
	Text = "店里共24人，外面排队102人，七织不在。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_14_YiXin",
	NextID = 62005515,
}
StorySpeechConfig[StorySpeechID.Id62005515] =
{
	Id = 62005515,
	CharName = "五行",
	Text = "哈？！这都找不到…算了，继续向前走吧。\n名侦探五行，大失败…",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_18_WuXing",
	NextID = 62005516,
}
StorySpeechConfig[StorySpeechID.Id62005516] =
{
	Id = 62005516,
	CharName = "五行",
	Text = "（十分钟后）看样子是到美食街了，哇，这个味道，好香！！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_18_WuXing",
	NextID = 62005517,
}
StorySpeechConfig[StorySpeechID.Id62005517] =
{
	Id = 62005517,
	CharName = "七织",
	Text = "好香！！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_20_QiZhi",
	NextID = 62005518,
}
StorySpeechConfig[StorySpeechID.Id62005518] =
{
	Id = 62005518,
	CharName = "五行",
	Text = "是吧是吧，小七也这么觉得…诶？！小七？！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_18_WuXing",
	NextID = 62005519,
}
StorySpeechConfig[StorySpeechID.Id62005519] =
{
	Id = 62005519,
	CharName = "七织",
	Text = "五行？一心？你们怎么在这里？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_20_QiZhi",
	NextID = 62005520,
}
StorySpeechConfig[StorySpeechID.Id62005520] =
{
	Id = 62005520,
	CharName = "五行",
	Text = "我们一直在找…（愣住）你是谁啊？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_18_WuXing",
	NextID = 62005521,
}
StorySpeechConfig[StorySpeechID.Id62005521] =
{
	Id = 62005521,
	CharName = "牵牛",
	Text = "那个，我是，在服装店打工的…",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_13_QianNiu",
	NextID = 62005522,
}
StorySpeechConfig[StorySpeechID.Id62005522] =
{
	Id = 62005522,
	CharName = "五行",
	Text = "喂，你看着我们小七手里的糖葫芦做什么？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_18_WuXing",
	NextID = 62005523,
}
StorySpeechConfig[StorySpeechID.Id62005523] =
{
	Id = 62005523,
	CharName = "一心",
	Text = "想抢走的概率大约是...",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_14_YiXin",
	NextID = 62005524,
}
StorySpeechConfig[StorySpeechID.Id62005524] =
{
	Id = 62005524,
	CharName = "五行",
	Text = "不会让你欺负七织的！一心，我们上！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_18_WuXing",
}
StorySpeechConfig[StorySpeechID.Id62005551] =
{
	Id = 62005551,
	CharName = "一心",
	Text = "概率是...1.2%。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_14_YiXin",
	NextID = 62005552,
}
StorySpeechConfig[StorySpeechID.Id62005552] =
{
	Id = 62005552,
	CharName = "五行",
	Text = "喂！下次能不能早点说，我已经开打了诶！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_18_WuXing",
	NextID = 62005553,
}
StorySpeechConfig[StorySpeechID.Id62005553] =
{
	Id = 62005553,
	CharName = "七织",
	Text = "（笑）你看，我就说我姐姐们很厉害吧，你打不过她们的。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_20_QiZhi",
	NextID = 62005554,
}
StorySpeechConfig[StorySpeechID.Id62005554] =
{
	Id = 62005554,
	CharName = "五行",
	Text = "七织！真是的，明明知道是误会，还不拦着我们…",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_18_WuXing",
	NextID = 62005555,
}
StorySpeechConfig[StorySpeechID.Id62005555] =
{
	Id = 62005555,
	CharName = "七织",
	Text = "（委屈巴巴）我也拦不住呀QAQ",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_20_QiZhi",
	NextID = 62005556,
}
StorySpeechConfig[StorySpeechID.Id62005556] =
{
	Id = 62005556,
	CharName = "五行",
	Text = "总之，都是误会，实在是对不住，不过我们也不打不相识，缘分，都是缘分。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_18_WuXing",
	NextID = 62005557,
}
StorySpeechConfig[StorySpeechID.Id62005557] =
{
	Id = 62005557,
	CharName = "牵牛",
	Text = "……",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_13_QianNiu",
	NextID = 62005558,
}
StorySpeechConfig[StorySpeechID.Id62005558] =
{
	Id = 62005558,
	CharName = "月佬",
	Text = "（暗中观察）这不打不相识的经典桥段，怎么在这俩人身上？不对劲，太不对劲了...",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_21_YueLao",
	NextID = 62005559,
}
StorySpeechConfig[StorySpeechID.Id62005559] =
{
	Id = 62005559,
	CharName = "月佬",
	Text = "不过，想来问题也不大，且再观察一阵。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_21_YueLao",
}
StorySpeechConfig[StorySpeechID.Id62005601] =
{
	Id = 62005601,
	CharName = "五行",
	Text = "说来，我们路过服装店的时候，看到有个小姑娘在找店长麻烦，说是为了你才去排队的，结果你下班了。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_18_WuXing",
	NextID = 62005602,
}
StorySpeechConfig[StorySpeechID.Id62005602] =
{
	Id = 62005602,
	CharName = "七织",
	Text = "哇，你人气很高嘛牵牛！（拍肩）",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_20_QiZhi",
	NextID = 62005603,
}
StorySpeechConfig[StorySpeechID.Id62005603] =
{
	Id = 62005603,
	CharName = "牵牛",
	Text = "（脸红）那、店长他…还好吗？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_13_QianNiu",
	NextID = 62005604,
}
StorySpeechConfig[StorySpeechID.Id62005604] =
{
	Id = 62005604,
	CharName = "五行",
	Text = "你店长直接对她说“没辙”。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_18_WuXing",
	NextID = 62005605,
}
StorySpeechConfig[StorySpeechID.Id62005605] =
{
	Id = 62005605,
	CharName = "七织",
	Text = "哈哈哈，有个性，我喜欢！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_20_QiZhi",
	NextID = 62005606,
}
StorySpeechConfig[StorySpeechID.Id62005606] =
{
	Id = 62005606,
	CharName = "旁白喇叭",
	Text = "少年与少女们谈天说地，在庙会小道上走走停停，下一个瞬间，头顶袭来一丝凉意。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	RightIcon = "EventItem_RPG_Event_8",
	NextID = 62005607,
}
StorySpeechConfig[StorySpeechID.Id62005607] =
{
	Id = 62005607,
	CharName = "七织",
	Text = "下雨了？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_20_QiZhi",
	NextID = 62005608,
}
StorySpeechConfig[StorySpeechID.Id62005608] =
{
	Id = 62005608,
	CharName = "一心",
	Text = "（看）附近可以躲雨的地方数量…居然是零。\n对了，那家服装店可以进么？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_14_YiXin",
	NextID = 62005609,
}
StorySpeechConfig[StorySpeechID.Id62005609] =
{
	Id = 62005609,
	CharName = "牵牛",
	Text = "嗯，可…",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_13_QianNiu",
	NextID = 62005610,
}
StorySpeechConfig[StorySpeechID.Id62005610] =
{
	Id = 62005610,
	CharName = "月佬",
	Text = "（不行，不能让他们回服装店。）",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_21_YueLao",
	NextID = 62005611,
}
StorySpeechConfig[StorySpeechID.Id62005611] =
{
	Id = 62005611,
	CharName = "月佬",
	Text = "（拉紧红线，转红伞三圈并上下翻转360°）",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_21_YueLao",
	NextID = 62005612,
}
StorySpeechConfig[StorySpeechID.Id62005612] =
{
	Id = 62005612,
	CharName = "牵牛",
	Text = "可…可不能回去，老板是只有洁癖的花孔雀，肯定会把我们这些湿漉漉的人赶出去…",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_13_QianNiu",
	NextID = 62005613,
}
StorySpeechConfig[StorySpeechID.Id62005613] =
{
	Id = 62005613,
	CharName = "牵牛",
	Text = "不过，前方的小凉亭可以避雨，我带你们去。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_13_QianNiu",
	NextID = 62005614,
}
StorySpeechConfig[StorySpeechID.Id62005614] =
{
	Id = 62005614,
	CharName = "七织",
	Text = "好！一心五行，我们跑！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_20_QiZhi",
	NextID = 62005615,
}
StorySpeechConfig[StorySpeechID.Id62005615] =
{
	Id = 62005615,
	CharName = "鬼影树",
	Text = "（突然出现）此路是我开，此树…是我本人。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	LeftIcon = "Arena_RPG_dashu",
	NextID = 62005616,
}
StorySpeechConfig[StorySpeechID.Id62005616] =
{
	Id = 62005616,
	CharName = "牵牛",
	Text = "不好，怎么遇到这家伙了...",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_13_QianNiu",
	NextID = 62005617,
}
StorySpeechConfig[StorySpeechID.Id62005617] =
{
	Id = 62005617,
	CharName = "五行",
	Text = "…来者不善，店员小哥，你知道他是谁么？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_18_WuXing",
	NextID = 62005618,
}
StorySpeechConfig[StorySpeechID.Id62005618] =
{
	Id = 62005618,
	CharName = "牵牛",
	Text = "这人是在流亡街游荡的犯人，专在雨天行凶，技能是狂抖树冠，让人感冒...",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_13_QianNiu",
	NextID = 62005619,
}
StorySpeechConfig[StorySpeechID.Id62005619] =
{
	Id = 62005619,
	CharName = "七织",
	Text = "原来真的可以帮警察叔叔抓犯人！好刺激，我们上！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_20_QiZhi",
}
StorySpeechConfig[StorySpeechID.Id62005651] =
{
	Id = 62005651,
	CharName = "月佬",
	Text = "非也，非也…并非是犯人作乱…",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_21_YueLao",
	NextID = 62005652,
}
StorySpeechConfig[StorySpeechID.Id62005652] =
{
	Id = 62005652,
	CharName = "月佬",
	Text = "而是爱情的考验，哈哈哈哈…",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_21_YueLao",
	NextID = 62005653,
}
StorySpeechConfig[StorySpeechID.Id62005653] =
{
	Id = 62005653,
	CharName = "旁白喇叭",
	Text = "牵牛拉起七织的衣袖在小雨中奔跑，他小声地说着什么，但千言万语都被风雨裹挟着，吹向了远方。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "EventItem_RPG_Event_8",
	NextID = 62005654,
}
StorySpeechConfig[StorySpeechID.Id62005654] =
{
	Id = 62005654,
	CharName = "七织",
	Text = "（大声）啊——？你——说——什——么——",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_20_QiZhi",
	NextID = 62005655,
}
StorySpeechConfig[StorySpeechID.Id62005655] =
{
	Id = 62005655,
	CharName = "牵牛",
	Text = "（大声）我说——你、你第一次经过服装店的时候，我就看到你了，你在街上，看店里的裙子…",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_13_QianNiu",
	NextID = 62005656,
}
StorySpeechConfig[StorySpeechID.Id62005656] =
{
	Id = 62005656,
	CharName = "七织",
	Text = "是呀，那时候在看美丽的衣裳，还有夺目的灯光，感觉就像公主的城堡殿堂！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_20_QiZhi",
	NextID = 62005657,
}
StorySpeechConfig[StorySpeechID.Id62005657] =
{
	Id = 62005657,
	CharName = "七织",
	Text = "那你呢，那个时候，你在看什么呢？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_20_QiZhi",
	NextID = 62005658,
}
StorySpeechConfig[StorySpeechID.Id62005658] =
{
	Id = 62005658,
	CharName = "牵牛",
	Text = "…在看车水马龙的街道。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_13_QianNiu",
	NextID = 62005659,
}
StorySpeechConfig[StorySpeechID.Id62005659] =
{
	Id = 62005659,
	CharName = "牵牛",
	Text = "也在看着街道上的你。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_13_QianNiu",
	NextID = 62005660,
}
StorySpeechConfig[StorySpeechID.Id62005660] =
{
	Id = 62005660,
	CharName = "牵牛",
	Text = "你没有发现吗？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_13_QianNiu",
}
StorySpeechConfig[StorySpeechID.Id62005701] =
{
	Id = 62005701,
	CharName = "四荔",
	Text = "二橘，二橘…等等我啊，不要闹别扭啦。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_17_SiLi",
	NextID = 62005702,
}
StorySpeechConfig[StorySpeechID.Id62005702] =
{
	Id = 62005702,
	CharName = "二橘",
	Text = "我才没和谁闹别扭…（冷静）所以…我们现在和大家走散了，对吗？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_15_ErJv",
	NextID = 62005703,
}
StorySpeechConfig[StorySpeechID.Id62005703] =
{
	Id = 62005703,
	CharName = "四荔",
	Text = "嗯，已经看不到一心她们了…大概没有跟上来吧。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_17_SiLi",
	NextID = 62005704,
}
StorySpeechConfig[StorySpeechID.Id62005704] =
{
	Id = 62005704,
	CharName = "四荔",
	Text = "（打开手机）还是没有信号…",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_17_SiLi",
	NextID = 62005705,
}
StorySpeechConfig[StorySpeechID.Id62005705] =
{
	Id = 62005705,
	CharName = "二橘",
	Text = "真是的…对不起啊，四荔。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_15_ErJv",
	NextID = 62005706,
}
StorySpeechConfig[StorySpeechID.Id62005706] =
{
	Id = 62005706,
	CharName = "四荔",
	Text = "哎？？不要，不要向我道歉啊！没关系的！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_17_SiLi",
	NextID = 62005707,
}
StorySpeechConfig[StorySpeechID.Id62005707] =
{
	Id = 62005707,
	CharName = "二橘",
	Text = "是因为我…才会和大家走散的。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_15_ErJv",
	NextID = 62005708,
}
StorySpeechConfig[StorySpeechID.Id62005708] =
{
	Id = 62005708,
	CharName = "四荔",
	Text = "没...没有那回事啦，你突然这样，搞得我很…很不知所措啊。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_17_SiLi",
	NextID = 62005709,
}
StorySpeechConfig[StorySpeechID.Id62005709] =
{
	Id = 62005709,
	CharName = "二橘",
	Text = "……",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_15_ErJv",
	NextID = 62005710,
}
StorySpeechConfig[StorySpeechID.Id62005710] =
{
	Id = 62005710,
	CharName = "四荔",
	Text = "你情绪这么低落，就算是恶作剧也不能让你兴奋起来吧…\n（拉住二橘）来，跟我跑起来！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_17_SiLi",
	NextID = 62005711,
}
StorySpeechConfig[StorySpeechID.Id62005711] =
{
	Id = 62005711,
	CharName = "二橘",
	Text = "你、你又想做什么恶作剧吗…四荔，慢、慢一点啊！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_15_ErJv",
	NextID = 62005712,
}
StorySpeechConfig[StorySpeechID.Id62005712] =
{
	Id = 62005712,
	CharName = "四荔",
	Text = "（二十分钟后）…可以停下了。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_17_SiLi",
	NextID = 62005713,
}
StorySpeechConfig[StorySpeechID.Id62005713] =
{
	Id = 62005713,
	CharName = "二橘",
	Text = "好、好累...为什么要、这样...",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_15_ErJv",
	NextID = 62005714,
}
StorySpeechConfig[StorySpeechID.Id62005714] =
{
	Id = 62005714,
	CharName = "四荔",
	Text = "想带你跑步呀！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_17_SiLi",
	NextID = 62005715,
}
StorySpeechConfig[StorySpeechID.Id62005715] =
{
	Id = 62005715,
	CharName = "四荔",
	Text = "听一心说，运动的时候会分泌出一种叫什么安的东西，会让你觉得快乐，这样你就不会一直沉浸在低沉的情绪里了！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_17_SiLi",
	NextID = 62005716,
}
StorySpeechConfig[StorySpeechID.Id62005716] =
{
	Id = 62005716,
	CharName = "二橘",
	Text = "多巴胺。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_15_ErJv",
	NextID = 62005717,
}
StorySpeechConfig[StorySpeechID.Id62005717] =
{
	Id = 62005717,
	CharName = "四荔",
	Text = "没错没错！就是它！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_17_SiLi",
	NextID = 62005718,
}
StorySpeechConfig[StorySpeechID.Id62005718] =
{
	Id = 62005718,
	CharName = "二橘",
	Text = "虽然…虽然我也很感谢你的好心啦，但是…\n这是哪里啊？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_15_ErJv",
	NextID = 62005719,
}
StorySpeechConfig[StorySpeechID.Id62005719] =
{
	Id = 62005719,
	CharName = "旁白喇叭",
	Text = "眼前是一片清冷景象，大概是某座山的山脚。\n前方是斜坡，斜坡边枯草杂乱，反射出皎月的清亮光辉。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "EventItem_RPG_Event_8",
	NextID = 62005720,
}
StorySpeechConfig[StorySpeechID.Id62005720] =
{
	Id = 62005720,
	CharName = "四荔",
	Text = "诶？？我们走到哪里了！！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_17_SiLi",
	NextID = 62005721,
}
StorySpeechConfig[StorySpeechID.Id62005721] =
{
	Id = 62005721,
	CharName = "吵架石",
	Text = "不会吧不会吧，不会有人连这里是哪里都不知道吧？",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	LeftIcon = "Arena_RPG_xiaoshiguai",
	NextID = 62005722,
}
StorySpeechConfig[StorySpeechID.Id62005722] =
{
	Id = 62005722,
	CharName = "二橘",
	Text = "？？所以…我们被一块石头嘲讽了么。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_15_ErJv",
}
StorySpeechConfig[StorySpeechID.Id62005751] =
{
	Id = 62005751,
	CharName = "二橘",
	Text = "（半刻以后）四荔，这里真安静。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_15_ErJv",
	NextID = 62005752,
}
StorySpeechConfig[StorySpeechID.Id62005752] =
{
	Id = 62005752,
	CharName = "四荔",
	Text = "是啊，最近一直和大家在一起，总是热热闹闹的，很久没有这样安静的时候了。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_17_SiLi",
	NextID = 62005753,
}
StorySpeechConfig[StorySpeechID.Id62005753] =
{
	Id = 62005753,
	CharName = "二橘",
	Text = "如果是七织，肯定会大声地说“哦！！这里好空旷啊！！”之类的话，说不定还会提议，第二天来这里野炊，放风筝之类的。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_15_ErJv",
	NextID = 62005754,
}
StorySpeechConfig[StorySpeechID.Id62005754] =
{
	Id = 62005754,
	CharName = "四荔",
	Text = "其实你很了解小七嘛…喂，二橘，你现在，其实很想念她们吧？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_17_SiLi",
	NextID = 62005755,
}
StorySpeechConfig[StorySpeechID.Id62005755] =
{
	Id = 62005755,
	CharName = "二橘",
	Text = "哈？你在说什么？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_15_ErJv",
	NextID = 62005756,
}
StorySpeechConfig[StorySpeechID.Id62005756] =
{
	Id = 62005756,
	CharName = "四荔",
	Text = "我觉得，你虽然看上去不太合群，但是，其实并不喜欢独来独往，内心深处，其实是很喜欢她们的，对吧？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_17_SiLi",
	NextID = 62005757,
}
StorySpeechConfig[StorySpeechID.Id62005757] =
{
	Id = 62005757,
	CharName = "二橘",
	Text = "我才没有。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_15_ErJv",
	NextID = 62005758,
}
StorySpeechConfig[StorySpeechID.Id62005758] =
{
	Id = 62005758,
	CharName = "四荔",
	Text = "（看着二橘）真的是这样吗？只有坦率面对自己的内心，才会变得幸福哦！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_17_SiLi",
	NextID = 62005759,
}
StorySpeechConfig[StorySpeechID.Id62005759] =
{
	Id = 62005759,
	CharName = "二橘",
	Text = "你…你好吵啊！（走开）我要去那个凉亭里，跟不跟上来随你，哼！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_15_ErJv",
}
StorySpeechConfig[StorySpeechID.Id62005801] =
{
	Id = 62005801,
	CharName = "六瑶",
	Text = "（紧紧拉住三花）三花，我们好像迷路了…这条路，我们刚刚走过…",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_19_LiuYao",
	NextID = 62005802,
}
StorySpeechConfig[StorySpeechID.Id62005802] =
{
	Id = 62005802,
	CharName = "六瑶",
	Text = "一心和五行也不见了...我们是不是进入了一个异世界…",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_19_LiuYao",
	NextID = 62005803,
}
StorySpeechConfig[StorySpeechID.Id62005803] =
{
	Id = 62005803,
	CharName = "三花",
	Text = "你就不要自己吓自己了，放轻松，你看，这里那么热闹，我们自己逛逛，不是也很好吗？\n嗷！有烤章鱼喵！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_16_SanHua",
	NextID = 62005804,
}
StorySpeechConfig[StorySpeechID.Id62005804] =
{
	Id = 62005804,
	CharName = "三花",
	Text = "（看招牌）海、洋、星、进口食材...",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_16_SanHua",
	NextID = 62005805,
}
StorySpeechConfig[StorySpeechID.Id62005805] =
{
	Id = 62005805,
	CharName = "六瑶",
	Text = "三花！！触手...触手在动！！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_19_LiuYao",
	NextID = 62005806,
}
StorySpeechConfig[StorySpeechID.Id62005806] =
{
	Id = 62005806,
	CharName = "三花",
	Text = "（推）胆子大一点嘛，你看，没什么可怕的，是很好吃的东西哦。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_16_SanHua",
	NextID = 62005807,
}
StorySpeechConfig[StorySpeechID.Id62005807] =
{
	Id = 62005807,
	CharName = "六瑶",
	Text = "但是、但是…这个…（瑟瑟发抖）",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_19_LiuYao",
	NextID = 62005808,
}
StorySpeechConfig[StorySpeechID.Id62005808] =
{
	Id = 62005808,
	CharName = "三花",
	Text = "好啦好啦，我们不看了，我带你走...\n（唉，什么时候才能让她勇敢起来呢？）",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_16_SanHua",
	NextID = 62005809,
}
StorySpeechConfig[StorySpeechID.Id62005809] =
{
	Id = 62005809,
	CharName = "三花猫",
	Text = "（突然出现）喵~",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	LeftIcon = "SUS_ColorfulCat",
	NextID = 62005810,
}
StorySpeechConfig[StorySpeechID.Id62005810] =
{
	Id = 62005810,
	CharName = "三花",
	Text = "哦！！是三花猫！！我异父异母的……（捞起尾巴观察）妹妹！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_16_SanHua",
	NextID = 62005811,
}
StorySpeechConfig[StorySpeechID.Id62005811] =
{
	Id = 62005811,
	CharName = "三花",
	Text = "你太可爱了！（拿出逗猫棒）你喜不喜欢玩这个~",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_16_SanHua",
	NextID = 62005812,
}
StorySpeechConfig[StorySpeechID.Id62005812] =
{
	Id = 62005812,
	CharName = "三花猫",
	Text = "喵~（伸出爪子，向逗猫棒扑去）",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	LeftIcon = "SUS_ColorfulCat",
	NextID = 62005813,
}
StorySpeechConfig[StorySpeechID.Id62005813] =
{
	Id = 62005813,
	CharName = "六瑶",
	Text = "呀——！！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_19_LiuYao",
}
StorySpeechConfig[StorySpeechID.Id62005851] =
{
	Id = 62005851,
	CharName = "三花",
	Text = "别怕别怕，那个姐姐只是太胆小了~不是真的想伤害你，摸摸~",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_16_SanHua",
	NextID = 62005852,
}
StorySpeechConfig[StorySpeechID.Id62005852] =
{
	Id = 62005852,
	CharName = "三花",
	Text = "没事的小六，她性格超好，刚刚还在对我们露肚皮！\n我以本人名誉担保，这孩子不会伤害你的，伸出手来摸摸她吧。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_16_SanHua",
	NextID = 62005853,
}
StorySpeechConfig[StorySpeechID.Id62005853] =
{
	Id = 62005853,
	CharName = "三花猫",
	Text = "喵呜...",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	RightIcon = "SUS_ColorfulCat",
	NextID = 62005854,
}
StorySpeechConfig[StorySpeechID.Id62005854] =
{
	Id = 62005854,
	CharName = "六瑶",
	Text = "真的可以吗？万一、万一…",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_19_LiuYao",
	NextID = 62005855,
}
StorySpeechConfig[StorySpeechID.Id62005855] =
{
	Id = 62005855,
	CharName = "三花",
	Text = "没问题！（拉住六瑶的手，缓缓伸向猫咪）\n慢慢地放在她头上就好~嗯，是不是感觉毛茸茸喵？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_16_SanHua",
	NextID = 62005856,
}
StorySpeechConfig[StorySpeechID.Id62005856] =
{
	Id = 62005856,
	CharName = "六瑶",
	Text = "嗯，毛茸茸的，而且很温暖…",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_19_LiuYao",
	NextID = 62005857,
}
StorySpeechConfig[StorySpeechID.Id62005857] =
{
	Id = 62005857,
	CharName = "三花",
	Text = "就这样放着，就像摸一匹布一样，摸摸她的小脑袋吧。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_16_SanHua",
	NextID = 62005858,
}
StorySpeechConfig[StorySpeechID.Id62005858] =
{
	Id = 62005858,
	CharName = "旁白喇叭",
	Text = "不一会儿，三花猫就发出了咕噜咕噜的声音。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "EventItem_RPG_Event_8",
	NextID = 62005859,
}
StorySpeechConfig[StorySpeechID.Id62005859] =
{
	Id = 62005859,
	CharName = "三花",
	Text = "你看，她说她很舒服，很喜欢你呢~\n只有喜欢你，才会发出这样的声音哦！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_16_SanHua",
	NextID = 62005860,
}
StorySpeechConfig[StorySpeechID.Id62005860] =
{
	Id = 62005860,
	CharName = "六瑶",
	Text = "真的吗？三花，我……我好开心！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_19_LiuYao",
	NextID = 62005861,
}
StorySpeechConfig[StorySpeechID.Id62005861] =
{
	Id = 62005861,
	CharName = "三花",
	Text = "（摸摸头）小六，如果总是畏手畏脚，不是会失去很多感受美好的机会吗？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_16_SanHua",
	NextID = 62005862,
}
StorySpeechConfig[StorySpeechID.Id62005862] =
{
	Id = 62005862,
	CharName = "六瑶",
	Text = "啊？那个…是吗，我也不知道…但是我…我也想改变，不想做胆小鬼。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_19_LiuYao",
	NextID = 62005863,
}
StorySpeechConfig[StorySpeechID.Id62005863] =
{
	Id = 62005863,
	CharName = "三花",
	Text = "我相信你，一定会变得勇敢的~",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_16_SanHua",
}
StorySpeechConfig[StorySpeechID.Id62005901] =
{
	Id = 62005901,
	CharName = "六瑶",
	Text = "（抱着小猫）真的好可爱...已经开始发出咕噜咕噜的声音了。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_19_LiuYao",
	NextID = 62005902,
}
StorySpeechConfig[StorySpeechID.Id62005902] =
{
	Id = 62005902,
	CharName = "三花",
	Text = "和我们回家吧喵？这样，就再也不用做流浪猫了！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_16_SanHua",
	NextID = 62005903,
}
StorySpeechConfig[StorySpeechID.Id62005903] =
{
	Id = 62005903,
	CharName = "三花猫",
	Text = "喵？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	LeftIcon = "SUS_ColorfulCat",
	NextID = 62005904,
}
StorySpeechConfig[StorySpeechID.Id62005904] =
{
	Id = 62005904,
	CharName = "三花",
	Text = "我家有很多玩具和罐头哦…嗷？下雨了？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_16_SanHua",
	NextID = 62005905,
}
StorySpeechConfig[StorySpeechID.Id62005905] =
{
	Id = 62005905,
	CharName = "六瑶",
	Text = "糟糕了…",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_19_LiuYao",
	NextID = 62005906,
}
StorySpeechConfig[StorySpeechID.Id62005906] =
{
	Id = 62005906,
	CharName = "三花",
	Text = "不慌喵！我们找个地方避雨去！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_16_SanHua",
	NextID = 62005907,
}
StorySpeechConfig[StorySpeechID.Id62005907] =
{
	Id = 62005907,
	CharName = "六瑶",
	Text = "三花，那个…我之前查过地图，大概…大概知道，避雨的地方在哪儿，但是不确定对不对…",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_19_LiuYao",
	NextID = 62005908,
}
StorySpeechConfig[StorySpeechID.Id62005908] =
{
	Id = 62005908,
	CharName = "三花",
	Text = "这还用管对不对？你带我跑过去就是了，相信你喵~",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_16_SanHua",
	NextID = 62005909,
}
StorySpeechConfig[StorySpeechID.Id62005909] =
{
	Id = 62005909,
	CharName = "旁白喇叭",
	Text = "另一边，二橘和四荔坐在凉亭里，百无聊赖地看着空中忽明忽暗的繁星。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "EventItem_RPG_Event_8",
	NextID = 62005910,
}
StorySpeechConfig[StorySpeechID.Id62005910] =
{
	Id = 62005910,
	CharName = "二橘",
	Text = "这雨说来就来，而且，现在还不停……",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_15_ErJv",
	NextID = 62005911,
}
StorySpeechConfig[StorySpeechID.Id62005911] =
{
	Id = 62005911,
	CharName = "四荔",
	Text = "唉，本来准备了一个绝妙的整蛊计划…但完全没有施展的机会。（感受到二橘的灼热视线）…我真的放弃了，真的。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_17_SiLi",
	NextID = 62005912,
}
StorySpeechConfig[StorySpeechID.Id62005912] =
{
	Id = 62005912,
	CharName = "旁白喇叭",
	Text = "话音刚落，二人便听到一阵零乱的脚步声。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	RightIcon = "EventItem_RPG_Event_8",
	NextID = 62005913,
}
StorySpeechConfig[StorySpeechID.Id62005913] =
{
	Id = 62005913,
	CharName = "二橘",
	Text = "好急促的声音，四荔，小心。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_15_ErJv",
}
StorySpeechConfig[StorySpeechID.Id62005951] =
{
	Id = 62005951,
	CharName = "三花",
	Text = "喂！二橘！四荔！打我也太过分了喵！！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_16_SanHua",
	NextID = 62005952,
}
StorySpeechConfig[StorySpeechID.Id62005952] =
{
	Id = 62005952,
	CharName = "二橘",
	Text = "三…花？是你？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_15_ErJv",
	NextID = 62005953,
}
StorySpeechConfig[StorySpeechID.Id62005953] =
{
	Id = 62005953,
	CharName = "四荔",
	Text = "居然能在这里见到你们！你们是怎么找到这里的？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_17_SiLi",
	NextID = 62005954,
}
StorySpeechConfig[StorySpeechID.Id62005954] =
{
	Id = 62005954,
	CharName = "三花",
	Text = "我们本来在找避雨的地方，小六说看过地图，记得这里有个凉亭，我们就过来了喵。\n你们呢你们呢？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_16_SanHua",
	NextID = 62005955,
}
StorySpeechConfig[StorySpeechID.Id62005955] =
{
	Id = 62005955,
	CharName = "二橘",
	Text = "在庙会上瞎跑，就到这里来了。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_15_ErJv",
	NextID = 62005956,
}
StorySpeechConfig[StorySpeechID.Id62005956] =
{
	Id = 62005956,
	CharName = "六瑶",
	Text = "诶？瞎跑...？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_19_LiuYao",
	NextID = 62005957,
}
StorySpeechConfig[StorySpeechID.Id62005957] =
{
	Id = 62005957,
	CharName = "四荔",
	Text = "…确实是这样。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_17_SiLi",
	NextID = 62005958,
}
StorySpeechConfig[StorySpeechID.Id62005958] =
{
	Id = 62005958,
	CharName = "三花",
	Text = "那这就是超级巧合的重逢了喵！\n（搂住二橘）这就是，我们姐妹的缘分！喵~",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_16_SanHua",
	NextID = 62005959,
}
StorySpeechConfig[StorySpeechID.Id62005959] =
{
	Id = 62005959,
	CharName = "二橘",
	Text = "喂喂，巧合而已，不至于这么开心吧？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_15_ErJv",
}
StorySpeechConfig[StorySpeechID.Id62006001] =
{
	Id = 62006001,
	CharName = "六瑶",
	Text = "那个…就、就差小七、一心、五行了…也不知道她们现在在哪里…呜呜，希望大家都平安无事…",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_19_LiuYao",
	NextID = 62006002,
}
StorySpeechConfig[StorySpeechID.Id62006002] =
{
	Id = 62006002,
	CharName = "七织",
	Text = "（突然出现）喂——！六瑶！二橘！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_20_QiZhi",
	NextID = 62006003,
}
StorySpeechConfig[StorySpeechID.Id62006003] =
{
	Id = 62006003,
	CharName = "二橘",
	Text = "她们…三个都来了…？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_15_ErJv",
	NextID = 62006004,
}
StorySpeechConfig[StorySpeechID.Id62006004] =
{
	Id = 62006004,
	CharName = "六瑶",
	Text = "小七？太好了！真的是小七！\n呜呜…你、你们是怎么找到这里的？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_19_LiuYao",
	NextID = 62006005,
}
StorySpeechConfig[StorySpeechID.Id62006005] =
{
	Id = 62006005,
	CharName = "七织",
	Text = "因为遇到了牵牛小哥，带我们找了过来！！\n牵牛，这次给你记头等功！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_20_QiZhi",
	NextID = 62006006,
}
StorySpeechConfig[StorySpeechID.Id62006006] =
{
	Id = 62006006,
	CharName = "二橘",
	Text = "…你啊，差不多得了。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_15_ErJv",
	NextID = 62006007,
}
StorySpeechConfig[StorySpeechID.Id62006007] =
{
	Id = 62006007,
	CharName = "五行",
	Text = "二橘，你居然在笑！真难得！\n这次的庙会，让你那么开心吗？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_18_WuXing",
	NextID = 62006008,
}
StorySpeechConfig[StorySpeechID.Id62006008] =
{
	Id = 62006008,
	CharName = "二橘",
	Text = "我、你…（脸红）我难道就不能笑吗，哼。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_15_ErJv",
	NextID = 62006009,
}
StorySpeechConfig[StorySpeechID.Id62006009] =
{
	Id = 62006009,
	CharName = "一心",
	Text = "二橘害羞的概率，99.9%。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_14_YiXin",
	NextID = 62006010,
}
StorySpeechConfig[StorySpeechID.Id62006010] =
{
	Id = 62006010,
	CharName = "二橘",
	Text = "什么啊，一心也跟着胡闹……",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_15_ErJv",
	NextID = 62006011,
}
StorySpeechConfig[StorySpeechID.Id62006011] =
{
	Id = 62006011,
	CharName = "旁白喇叭",
	Text = "淅淅沥沥的雨声渐渐消失，乌云随风散去，墨色天壁上浮现出一轮弦月。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "EventItem_RPG_Event_8",
	NextID = 62006012,
}
StorySpeechConfig[StorySpeechID.Id62006012] =
{
	Id = 62006012,
	CharName = "四荔",
	Text = "雨停了…诶？小七，你旁边怎么还有一个人？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_17_SiLi",
	NextID = 62006013,
}
StorySpeechConfig[StorySpeechID.Id62006013] =
{
	Id = 62006013,
	CharName = "牵牛",
	Text = "啊？（脸红）我，我叫牵牛…\n——唔哇啊啊啊啊！！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_13_QianNiu",
	NextID = 62006014,
}
StorySpeechConfig[StorySpeechID.Id62006014] =
{
	Id = 62006014,
	CharName = "七织",
	Text = "（扔掉假蜘蛛）好啦四荔，别欺负他啦——\n对了，雨停了，这里夜景也那么好，我们来一张合照吧！（看向二橘）",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_20_QiZhi",
	NextID = 62006015,
}
StorySpeechConfig[StorySpeechID.Id62006015] =
{
	Id = 62006015,
	CharName = "二橘",
	Text = "（护住照相机）不准打我照相机的主意，我只拍风景，不拍人。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_15_ErJv",
	NextID = 62006016,
}
StorySpeechConfig[StorySpeechID.Id62006016] =
{
	Id = 62006016,
	CharName = "七织",
	Text = "二橘~~求求你啦~~牵牛，你来帮我们七个人拍，好不好？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_20_QiZhi",
	NextID = 62006017,
}
StorySpeechConfig[StorySpeechID.Id62006017] =
{
	Id = 62006017,
	CharName = "牵牛",
	Text = "（点头）",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_13_QianNiu",
	NextID = 62006018,
}
StorySpeechConfig[StorySpeechID.Id62006018] =
{
	Id = 62006018,
	CharName = "四荔",
	Text = "二橘，你就把照相机给她吧~不要忘了，之前我们约定过的，要面对自己真实的内心。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_17_SiLi",
	NextID = 62006019,
}
StorySpeechConfig[StorySpeechID.Id62006019] =
{
	Id = 62006019,
	CharName = "二橘",
	Text = "哼，知道了…喏，给你。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_15_ErJv",
	NextID = 62006020,
}
StorySpeechConfig[StorySpeechID.Id62006020] =
{
	Id = 62006020,
	CharName = "牵牛",
	Text = "三、二、一，好！再来一张……",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_13_QianNiu",
	NextID = 62006021,
}
StorySpeechConfig[StorySpeechID.Id62006021] =
{
	Id = 62006021,
	CharName = "月佬",
	Text = "果然，我亲手写在姻缘簿上的名字，是不会错的，哈哈哈…来来来，套上这根红线…",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_21_YueLao",
	NextID = 62006022,
}
StorySpeechConfig[StorySpeechID.Id62006022] =
{
	Id = 62006022,
	CharName = "七织",
	Text = "……？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_20_QiZhi",
	NextID = 62006023,
}
StorySpeechConfig[StorySpeechID.Id62006023] =
{
	Id = 62006023,
	CharName = "牵牛",
	Text = "你，你这是干什么。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_13_QianNiu",
	NextID = 62006024,
}
StorySpeechConfig[StorySpeechID.Id62006024] =
{
	Id = 62006024,
	CharName = "五行",
	Text = "你这家伙，从刚刚开始，就一直鬼鬼祟祟地跟着我们，到底什么目的？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_18_WuXing",
	NextID = 62006025,
}
StorySpeechConfig[StorySpeechID.Id62006025] =
{
	Id = 62006025,
	CharName = "六瑶",
	Text = "什、什么！跟踪狂吗…不行，一定要把他赶走！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_19_LiuYao",
}
StorySpeechConfig[StorySpeechID.Id62006051] =
{
	Id = 62006051,
	CharName = "月佬",
	Text = "我是好人，不对，好神仙！呀——！！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_21_YueLao",
	NextID = 62006052,
}
StorySpeechConfig[StorySpeechID.Id62006052] =
{
	Id = 62006052,
	CharName = "月佬",
	Text = "我堂堂姻缘神，一定会回来的…",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_21_YueLao",
	NextID = 62006053,
}
StorySpeechConfig[StorySpeechID.Id62006053] =
{
	Id = 62006053,
	CharName = "旁白喇叭",
	Text = "夏夜之下，少女们的笑脸格外灿烂，牵牛把相片拿出，递给少女们，朦胧光影与清亮月色，仿佛为相片染上了一层白霜。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "EventItem_RPG_Event_8",
	NextID = 62006054,
}
StorySpeechConfig[StorySpeechID.Id62006054] =
{
	Id = 62006054,
	CharName = "牵牛",
	Text = "七织，你看……",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_13_QianNiu",
}
StorySpeechConfig[StorySpeechID.Id89000101] =
{
	Id = 89000101,
	CharName = "呜呜",
	Text = "（戳）喵？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 89000102,
}
StorySpeechConfig[StorySpeechID.Id89000102] =
{
	Id = 89000102,
	CharName = "兔子",
	Text = "哇！！吓死我了！！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89000103,
}
StorySpeechConfig[StorySpeechID.Id89000103] =
{
	Id = 89000103,
	CharName = "呜呜",
	Text = "你是嫦娥姐姐的兔子吗喵？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 89000104,
}
StorySpeechConfig[StorySpeechID.Id89000104] =
{
	Id = 89000104,
	CharName = "兔子",
	Text = "你们……你们怎么发现我的！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89000105,
}
StorySpeechConfig[StorySpeechID.Id89000105] =
{
	Id = 89000105,
	CharName = "漆漆",
	Text = "喵？有眼睛就发现了喵。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_gugu",
	NextID = 89000106,
}
StorySpeechConfig[StorySpeechID.Id89000106] =
{
	Id = 89000106,
	CharName = "兔子",
	Text = "你在质疑我躲猫猫的能力？（溜）",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89000107,
}
StorySpeechConfig[StorySpeechID.Id89000107] =
{
	Id = 89000107,
	CharName = "漆漆",
	Text = "我们没…激发了她的胜负心喵。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_gugu",
}
StorySpeechConfig[StorySpeechID.Id89000201] =
{
	Id = 89000201,
	CharName = "漆漆",
	Text = "原来你藏在这里喵。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_gugu",
	NextID = 89000202,
}
StorySpeechConfig[StorySpeechID.Id89000202] =
{
	Id = 89000202,
	CharName = "呜呜",
	Text = "不回去吗喵？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_wuwu",
	NextID = 89000203,
}
StorySpeechConfig[StorySpeechID.Id89000203] =
{
	Id = 89000203,
	CharName = "兔子",
	Text = "回去？回去捣药？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_Rabbit",
	NextID = 89000204,
}
StorySpeechConfig[StorySpeechID.Id89000204] =
{
	Id = 89000204,
	CharName = "呜呜",
	Text = "喵？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_wuwu",
	NextID = 89000205,
}
StorySpeechConfig[StorySpeechID.Id89000205] =
{
	Id = 89000205,
	CharName = "兔子",
	Text = "打工人就算996，都还有休息的时候，我们呢，没日没夜捣药。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_Rabbit",
	NextID = 89000206,
}
StorySpeechConfig[StorySpeechID.Id89000206] =
{
	Id = 89000206,
	CharName = "兔子",
	Text = "这日子没法过了。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_Rabbit",
}
StorySpeechConfig[StorySpeechID.Id89000301] =
{
	Id = 89000301,
	CharName = "兔子",
	Text = "一叶白菜、两叶白菜、三叶……？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_Rabbit",
	NextID = 89000302,
}
StorySpeechConfig[StorySpeechID.Id89000302] =
{
	Id = 89000302,
	CharName = "呜呜",
	Text = "兔兔，回家了喵。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_wuwu",
	NextID = 89000303,
}
StorySpeechConfig[StorySpeechID.Id89000303] =
{
	Id = 89000303,
	CharName = "兔子",
	Text = "不回。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_Rabbit",
	NextID = 89000304,
}
StorySpeechConfig[StorySpeechID.Id89000304] =
{
	Id = 89000304,
	CharName = "漆漆",
	Text = "为什么喵，家里不好吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_gugu",
	NextID = 89000305,
}
StorySpeechConfig[StorySpeechID.Id89000305] =
{
	Id = 89000305,
	CharName = "兔子",
	Text = "数白菜，没空。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_Rabbit",
	NextID = 89000306,
}
StorySpeechConfig[StorySpeechID.Id89000306] =
{
	Id = 89000306,
	CharName = "呜呜",
	Text = "这样喵，那我们等会儿再来。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_wuwu",
}
StorySpeechConfig[StorySpeechID.Id89000401] =
{
	Id = 89000401,
	CharName = "呜呜",
	Text = "兔兔，现在愿意回去了吗喵？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 89000402,
}
StorySpeechConfig[StorySpeechID.Id89000402] =
{
	Id = 89000402,
	CharName = "兔子",
	Text = "哼，上次她说喂我喝绿豆汤，我开开心心喝了，拉肚子拉了三天。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89000403,
}
StorySpeechConfig[StorySpeechID.Id89000403] =
{
	Id = 89000403,
	CharName = "兔子",
	Text = "换做是你，你回去吗？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89000404,
}
StorySpeechConfig[StorySpeechID.Id89000404] =
{
	Id = 89000404,
	CharName = "呜呜",
	Text = "……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
}
StorySpeechConfig[StorySpeechID.Id89000501] =
{
	Id = 89000501,
	CharName = "呜呜",
	Text = "兔兔，嫦……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 89000502,
}
StorySpeechConfig[StorySpeechID.Id89000502] =
{
	Id = 89000502,
	CharName = "兔子",
	Text = "嘘。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89000503,
}
StorySpeechConfig[StorySpeechID.Id89000503] =
{
	Id = 89000503,
	CharName = "呜呜",
	Text = "？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 89000504,
}
StorySpeechConfig[StorySpeechID.Id89000504] =
{
	Id = 89000504,
	CharName = "兔子",
	Text = "你看，谁来了？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89000505,
}
StorySpeechConfig[StorySpeechID.Id89000505] =
{
	Id = 89000505,
	CharName = "呜呜",
	Text = "（回头）喵？\n（再回头）兔兔……喵，不见了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 89000506,
}
StorySpeechConfig[StorySpeechID.Id89000506] =
{
	Id = 89000506,
	CharName = "漆漆",
	Text = "被耍了喵。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_gugu",
}
StorySpeechConfig[StorySpeechID.Id89000601] =
{
	Id = 89000601,
	CharName = "漆漆",
	Text = "回去吧，嫦娥姐姐会担心喵。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_gugu",
	NextID = 89000602,
}
StorySpeechConfig[StorySpeechID.Id89000602] =
{
	Id = 89000602,
	CharName = "兔子",
	Text = "呜呜呜……",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89000603,
}
StorySpeechConfig[StorySpeechID.Id89000603] =
{
	Id = 89000603,
	CharName = "呜呜",
	Text = "喵？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 89000604,
}
StorySpeechConfig[StorySpeechID.Id89000604] =
{
	Id = 89000604,
	CharName = "兔子",
	Text = "还记得那天，她说要帮我洗被褥。\n我信了。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89000605,
}
StorySpeechConfig[StorySpeechID.Id89000605] =
{
	Id = 89000605,
	CharName = "兔子",
	Text = "然后，她把我和被褥…一起扔进了洗衣桶…",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89000606,
}
StorySpeechConfig[StorySpeechID.Id89000606] =
{
	Id = 89000606,
	CharName = "漆漆",
	Text = "好可怜喵。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_gugu",
	NextID = 89000607,
}
StorySpeechConfig[StorySpeechID.Id89000607] =
{
	Id = 89000607,
	CharName = "兔子",
	Text = "（抽泣）而且，她忘记了这件事。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89000608,
}
StorySpeechConfig[StorySpeechID.Id89000608] =
{
	Id = 89000608,
	CharName = "兔子",
	Text = "…让我在洗衣机里闷了整整四天…",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
}
StorySpeechConfig[StorySpeechID.Id89000701] =
{
	Id = 89000701,
	CharName = "呜呜",
	Text = "兔兔，回……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 89000702,
}
StorySpeechConfig[StorySpeechID.Id89000702] =
{
	Id = 89000702,
	CharName = "兔子",
	Text = "不回！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89000703,
}
StorySpeechConfig[StorySpeechID.Id89000703] =
{
	Id = 89000703,
	CharName = "漆漆",
	Text = "为什么喵。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_gugu",
	NextID = 89000704,
}
StorySpeechConfig[StorySpeechID.Id89000704] =
{
	Id = 89000704,
	CharName = "兔子",
	Text = "好不容易出来，我还要去看可乐王子演唱会呢。（跑）",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89000705,
}
StorySpeechConfig[StorySpeechID.Id89000705] =
{
	Id = 89000705,
	CharName = "漆漆",
	Text = "……那个王子人气这么高喵？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_gugu",
}
StorySpeechConfig[StorySpeechID.Id89000801] =
{
	Id = 89000801,
	CharName = "呜呜",
	Text = "累了喵，劝不动喵。（趴）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 89000802,
}
StorySpeechConfig[StorySpeechID.Id89000802] =
{
	Id = 89000802,
	CharName = "兔子",
	Text = "不劝了喵？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89000803,
}
StorySpeechConfig[StorySpeechID.Id89000803] =
{
	Id = 89000803,
	CharName = "漆漆",
	Text = "好累……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_gugu",
	NextID = 89000804,
}
StorySpeechConfig[StorySpeechID.Id89000804] =
{
	Id = 89000804,
	CharName = "兔子",
	Text = "那拜拜哦。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89000805,
}
StorySpeechConfig[StorySpeechID.Id89000805] =
{
	Id = 89000805,
	CharName = "呜呜",
	Text = "…拜拜…漆漆，我刚刚好像看到兔兔了喵。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 89000806,
}
StorySpeechConfig[StorySpeechID.Id89000806] =
{
	Id = 89000806,
	CharName = "漆漆",
	Text = "喵？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_gugu",
}
StorySpeechConfig[StorySpeechID.Id89000901] =
{
	Id = 89000901,
	CharName = "呜呜",
	Text = "还是不能放弃，兔兔——",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 89000902,
}
StorySpeechConfig[StorySpeechID.Id89000902] =
{
	Id = 89000902,
	CharName = "兔子",
	Text = "喂，你听说过一句俗语吗？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89000903,
}
StorySpeechConfig[StorySpeechID.Id89000903] =
{
	Id = 89000903,
	CharName = "漆漆",
	Text = "喵？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_gugu",
	NextID = 89000904,
}
StorySpeechConfig[StorySpeechID.Id89000904] =
{
	Id = 89000904,
	CharName = "兔子",
	Text = "外星的萝卜比较甜。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89000905,
}
StorySpeechConfig[StorySpeechID.Id89000905] =
{
	Id = 89000905,
	CharName = "呜呜",
	Text = "（锁眉）感觉原话不是这样的喵…\n哎，别跑喵！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
}
StorySpeechConfig[StorySpeechID.Id89001001] =
{
	Id = 89001001,
	CharName = "呜呜",
	Text = "兔兔，愿意回家吗喵？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 89001002,
}
StorySpeechConfig[StorySpeechID.Id89001002] =
{
	Id = 89001002,
	CharName = "兔子",
	Text = "那你拖我上船。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89001003,
}
StorySpeechConfig[StorySpeechID.Id89001003] =
{
	Id = 89001003,
	CharName = "呜呜",
	Text = "（用力）好喵。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 89001004,
}
StorySpeechConfig[StorySpeechID.Id89001004] =
{
	Id = 89001004,
	CharName = "兔子",
	Text = "你知道为什么拖不动吗喵？？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89001005,
}
StorySpeechConfig[StorySpeechID.Id89001005] =
{
	Id = 89001005,
	CharName = "漆漆",
	Text = "（疑惑）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_gugu",
	NextID = 89001006,
}
StorySpeechConfig[StorySpeechID.Id89001006] =
{
	Id = 89001006,
	CharName = "兔子",
	Text = "如果不是她，天天喂我吃她做的月饼，我也不会变得这么重。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89001007,
}
StorySpeechConfig[StorySpeechID.Id89001007] =
{
	Id = 89001007,
	CharName = "呜呜",
	Text = "吃月饼也不好吗，喵？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
}
StorySpeechConfig[StorySpeechID.Id89001101] =
{
	Id = 89001101,
	CharName = "呜呜",
	Text = "又看到你啦，兔兔。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 89001102,
}
StorySpeechConfig[StorySpeechID.Id89001102] =
{
	Id = 89001102,
	CharName = "兔子",
	Text = "你听说过麻辣兔头吗？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89001103,
}
StorySpeechConfig[StorySpeechID.Id89001103] =
{
	Id = 89001103,
	CharName = "漆漆",
	Text = "没有喵。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_gugu",
	NextID = 89001104,
}
StorySpeechConfig[StorySpeechID.Id89001104] =
{
	Id = 89001104,
	CharName = "兔子",
	Text = "想吃吗？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89001105,
}
StorySpeechConfig[StorySpeechID.Id89001105] =
{
	Id = 89001105,
	CharName = "呜呜",
	Text = "想吃喵！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 89001106,
}
StorySpeechConfig[StorySpeechID.Id89001106] =
{
	Id = 89001106,
	CharName = "兔子",
	Text = "果然不是好人，还好我聪明。（溜）",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89001107,
}
StorySpeechConfig[StorySpeechID.Id89001107] =
{
	Id = 89001107,
	CharName = "呜呜",
	Text = "（懵）我说错话了吗，漆漆？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
}
StorySpeechConfig[StorySpeechID.Id89001201] =
{
	Id = 89001201,
	CharName = "呜呜",
	Text = "喵，还是不想回嫦娥姐姐身边吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 89001202,
}
StorySpeechConfig[StorySpeechID.Id89001202] =
{
	Id = 89001202,
	CharName = "兔子",
	Text = "你让她还我手办。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89001203,
}
StorySpeechConfig[StorySpeechID.Id89001203] =
{
	Id = 89001203,
	CharName = "漆漆",
	Text = "手办是什么喵？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_gugu",
	NextID = 89001204,
}
StorySpeechConfig[StorySpeechID.Id89001204] =
{
	Id = 89001204,
	CharName = "兔子",
	Text = "我好不容易从代购手里买的德鲁伊手办，结果…",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89001205,
}
StorySpeechConfig[StorySpeechID.Id89001205] =
{
	Id = 89001205,
	CharName = "兔子",
	Text = "…德鲁伊的鹿角被她掰断了！\n不能原谅！！！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89001206,
}
StorySpeechConfig[StorySpeechID.Id89001206] =
{
	Id = 89001206,
	CharName = "呜呜",
	Text = "是的喵！！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
}
StorySpeechConfig[StorySpeechID.Id89001301] =
{
	Id = 89001301,
	CharName = "兔子",
	Text = "那个……你们是冒险家吗？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_Rabbit",
	NextID = 89001302,
}
StorySpeechConfig[StorySpeechID.Id89001302] =
{
	Id = 89001302,
	CharName = "呜呜",
	Text = "是的喵，你终于愿意和我们好好聊天了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_wuwu",
	NextID = 89001303,
}
StorySpeechConfig[StorySpeechID.Id89001303] =
{
	Id = 89001303,
	CharName = "兔子",
	Text = "那我、我可以和你们一起冒险吗？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_Rabbit",
	NextID = 89001304,
}
StorySpeechConfig[StorySpeechID.Id89001304] =
{
	Id = 89001304,
	CharName = "漆漆",
	Text = "不行喵，你要回家。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_gugu",
	NextID = 89001305,
}
StorySpeechConfig[StorySpeechID.Id89001305] =
{
	Id = 89001305,
	CharName = "兔子",
	Text = "……真小气，那我自己去。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_Rabbit",
	NextID = 89001306,
}
StorySpeechConfig[StorySpeechID.Id89001306] =
{
	Id = 89001306,
	CharName = "呜呜",
	Text = "等等喵——",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_wuwu",
}
StorySpeechConfig[StorySpeechID.Id89001401] =
{
	Id = 89001401,
	CharName = "呜呜",
	Text = "天气变凉了喵，躲在这里不冷吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 89001402,
}
StorySpeechConfig[StorySpeechID.Id89001402] =
{
	Id = 89001402,
	CharName = "兔子",
	Text = "（哆嗦）总、总比家里，好凹…",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89001403,
}
StorySpeechConfig[StorySpeechID.Id89001403] =
{
	Id = 89001403,
	CharName = "兔子",
	Text = "…家里冷，身上的毛，会被嫦娥，薅走…",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89001404,
}
StorySpeechConfig[StorySpeechID.Id89001404] =
{
	Id = 89001404,
	CharName = "漆漆",
	Text = "……感觉生活在水深火热之中喵。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_gugu",
}
StorySpeechConfig[StorySpeechID.Id89001501] =
{
	Id = 89001501,
	CharName = "呜呜",
	Text = "又看到你了喵。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 89001502,
}
StorySpeechConfig[StorySpeechID.Id89001502] =
{
	Id = 89001502,
	CharName = "漆漆",
	Text = "这次跑不掉了喵。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_gugu",
	NextID = 89001503,
}
StorySpeechConfig[StorySpeechID.Id89001503] =
{
	Id = 89001503,
	CharName = "兔子",
	Text = "我给你们讲个故事吧。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_Rabbit",
	NextID = 89001504,
}
StorySpeechConfig[StorySpeechID.Id89001504] =
{
	Id = 89001504,
	CharName = "兔子",
	Text = "从前，有一位少女，被关在遥远的月宫。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_Rabbit",
	NextID = 89001505,
}
StorySpeechConfig[StorySpeechID.Id89001505] =
{
	Id = 89001505,
	CharName = "兔子",
	Text = "我想，她一个人在寒冷又遥远的宫殿里，是多么孤单呀，如果有人可以陪她就好了。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_Rabbit",
	NextID = 89001506,
}
StorySpeechConfig[StorySpeechID.Id89001506] =
{
	Id = 89001506,
	CharName = "兔子",
	Text = "于是我成为了她的朋友，也成为了她唯一的家人。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_Rabbit",
	NextID = 89001507,
}
StorySpeechConfig[StorySpeechID.Id89001507] =
{
	Id = 89001507,
	CharName = "兔子",
	Text = "…你们不感动吗？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_Rabbit",
	NextID = 89001508,
}
StorySpeechConfig[StorySpeechID.Id89001508] =
{
	Id = 89001508,
	CharName = "呜呜",
	Text = "怎么说呢，感觉…以前在卡兹星看过这个故事喵。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_wuwu",
	NextID = 89001509,
}
StorySpeechConfig[StorySpeechID.Id89001509] =
{
	Id = 89001509,
	CharName = "漆漆",
	Text = "没什么新鲜感喵。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_gugu",
	NextID = 89001510,
}
StorySpeechConfig[StorySpeechID.Id89001510] =
{
	Id = 89001510,
	CharName = "兔子",
	Text = "……哼。（溜）",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
}
StorySpeechConfig[StorySpeechID.Id89001601] =
{
	Id = 89001601,
	CharName = "呜呜",
	Text = "抓到你了喵。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 89001602,
}
StorySpeechConfig[StorySpeechID.Id89001602] =
{
	Id = 89001602,
	CharName = "漆漆",
	Text = "（摁住）这次不会让你跑掉喵。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_gugu",
	NextID = 89001603,
}
StorySpeechConfig[StorySpeechID.Id89001603] =
{
	Id = 89001603,
	CharName = "兔子",
	Text = "你们、在…说什么…\n兔兔…不认识，你们…",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_Rabbit",
	NextID = 89001604,
}
StorySpeechConfig[StorySpeechID.Id89001604] =
{
	Id = 89001604,
	CharName = "呜呜",
	Text = "漆漆，怎么办喵。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_wuwu",
	NextID = 89001605,
}
StorySpeechConfig[StorySpeechID.Id89001605] =
{
	Id = 89001605,
	CharName = "漆漆",
	Text = "被吓到之后的间歇性失忆喵？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_gugu",
	NextID = 89001606,
}
StorySpeechConfig[StorySpeechID.Id89001606] =
{
	Id = 89001606,
	CharName = "呜呜",
	Text = "那我们放开兔兔吧喵…",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_wuwu",
	NextID = 89001607,
}
StorySpeechConfig[StorySpeechID.Id89001607] =
{
	Id = 89001607,
	CharName = "呜呜",
	Text = "喵，跑掉了！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_wuwu",
}
StorySpeechConfig[StorySpeechID.Id89001701] =
{
	Id = 89001701,
	CharName = "兔子",
	Text = "呼、呼…好刺激啊。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_Rabbit",
	NextID = 89001702,
}
StorySpeechConfig[StorySpeechID.Id89001702] =
{
	Id = 89001702,
	CharName = "兔子",
	Text = "那个飙车王，居然跑得和我不相上下。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_Rabbit",
	NextID = 89001703,
}
StorySpeechConfig[StorySpeechID.Id89001703] =
{
	Id = 89001703,
	CharName = "呜呜",
	Text = "兔兔，那个…玩够了就和我们回家了喵。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_wuwu",
	NextID = 89001704,
}
StorySpeechConfig[StorySpeechID.Id89001704] =
{
	Id = 89001704,
	CharName = "兔子",
	Text = "（瞥）你能跑过我吗？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_Rabbit",
	NextID = 89001705,
}
StorySpeechConfig[StorySpeechID.Id89001705] =
{
	Id = 89001705,
	CharName = "兔子",
	Text = "跑赢了就和你回去。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_Rabbit",
	NextID = 89001706,
}
StorySpeechConfig[StorySpeechID.Id89001706] =
{
	Id = 89001706,
	CharName = "旁白喇叭",
	Text = "三分钟后。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	RightIcon = "EventItem_RPG_Event_8",
	NextID = 89001707,
}
StorySpeechConfig[StorySpeechID.Id89001707] =
{
	Id = 89001707,
	CharName = "呜呜",
	Text = "漆漆，我好累喵…跑、跑不动了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 89001708,
}
StorySpeechConfig[StorySpeechID.Id89001708] =
{
	Id = 89001708,
	CharName = "漆漆",
	Text = "猫兔赛跑，猫猫大失败喵。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_gugu",
}
StorySpeechConfig[StorySpeechID.Id89001801] =
{
	Id = 89001801,
	CharName = "漆漆",
	Text = "可以回家了吧，喵？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_gugu",
	NextID = 89001802,
}
StorySpeechConfig[StorySpeechID.Id89001802] =
{
	Id = 89001802,
	CharName = "兔子",
	Text = "嘘……",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89001803,
}
StorySpeechConfig[StorySpeechID.Id89001803] =
{
	Id = 89001803,
	CharName = "呜呜",
	Text = "？？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 89001804,
}
StorySpeechConfig[StorySpeechID.Id89001804] =
{
	Id = 89001804,
	CharName = "兔子",
	Text = "让胡萝卜干再飞一会儿。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89001805,
}
StorySpeechConfig[StorySpeechID.Id89001805] =
{
	Id = 89001805,
	CharName = "呜呜",
	Text = "（哐）啊，头好疼…",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
}
StorySpeechConfig[StorySpeechID.Id89001901] =
{
	Id = 89001901,
	CharName = "呜呜",
	Text = "我们要怎么样才能劝你回去呢喵？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 89001902,
}
StorySpeechConfig[StorySpeechID.Id89001902] =
{
	Id = 89001902,
	CharName = "兔子",
	Text = "哎？你在征求我的意见吗？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89001903,
}
StorySpeechConfig[StorySpeechID.Id89001903] =
{
	Id = 89001903,
	CharName = "兔子",
	Text = "当你劝说成功的时候…就成功劝说我回去了。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89001904,
}
StorySpeechConfig[StorySpeechID.Id89001904] =
{
	Id = 89001904,
	CharName = "呜呜",
	Text = "原来是这样喵。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 89001905,
}
StorySpeechConfig[StorySpeechID.Id89001905] =
{
	Id = 89001905,
	CharName = "漆漆",
	Text = "…上次听到这么有道理的话还是在上次喵。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_gugu",
}
StorySpeechConfig[StorySpeechID.Id89002001] =
{
	Id = 89002001,
	CharName = "呜呜",
	Text = "喵，嫦娥姐姐虽然有时候照顾不周，但是…",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 89002002,
}
StorySpeechConfig[StorySpeechID.Id89002002] =
{
	Id = 89002002,
	CharName = "兔子",
	Text = "这不是理由。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89002003,
}
StorySpeechConfig[StorySpeechID.Id89002003] =
{
	Id = 89002003,
	CharName = "兔子",
	Text = "明明才早上9点，她为了骗我起床，说已经中午12点了。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89002004,
}
StorySpeechConfig[StorySpeechID.Id89002004] =
{
	Id = 89002004,
	CharName = "兔子",
	Text = "这不是照顾不周，她就是故意的！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89002005,
}
StorySpeechConfig[StorySpeechID.Id89002005] =
{
	Id = 89002005,
	CharName = "漆漆",
	Text = "嗯，如果剑士这么对我和呜呜，我也会生气喵。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_gugu",
	NextID = 89002006,
}
StorySpeechConfig[StorySpeechID.Id89002006] =
{
	Id = 89002006,
	CharName = "呜呜",
	Text = "漆漆，你怎么在附和兔兔喵？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_wuwu",
}
StorySpeechConfig[StorySpeechID.Id89002101] =
{
	Id = 89002101,
	CharName = "呜呜",
	Text = "为什么要离家出走呢喵？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 89002102,
}
StorySpeechConfig[StorySpeechID.Id89002102] =
{
	Id = 89002102,
	CharName = "兔子",
	Text = "你没有离家出走过吗？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89002103,
}
StorySpeechConfig[StorySpeechID.Id89002103] =
{
	Id = 89002103,
	CharName = "呜呜",
	Text = "好像有，但是…（努力回想）\n呜呜不记得了喵。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 89002104,
}
StorySpeechConfig[StorySpeechID.Id89002104] =
{
	Id = 89002104,
	CharName = "兔子",
	Text = "没有离家出走过的人生，是不完整的人生喵。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89002105,
}
StorySpeechConfig[StorySpeechID.Id89002105] =
{
	Id = 89002105,
	CharName = "兔子",
	Text = "记住我的话吧，猫咪！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
}
StorySpeechConfig[StorySpeechID.Id89002201] =
{
	Id = 89002201,
	CharName = "呜呜",
	Text = "我可以帮什么忙吗，喵？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 89002202,
}
StorySpeechConfig[StorySpeechID.Id89002202] =
{
	Id = 89002202,
	CharName = "兔子",
	Text = "？？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89002203,
}
StorySpeechConfig[StorySpeechID.Id89002203] =
{
	Id = 89002203,
	CharName = "呜呜",
	Text = "只要能让你回心转意，愿意回家…",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 89002204,
}
StorySpeechConfig[StorySpeechID.Id89002204] =
{
	Id = 89002204,
	CharName = "兔子",
	Text = "那你把我的游戏机抢回来！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89002205,
}
StorySpeechConfig[StorySpeechID.Id89002205] =
{
	Id = 89002205,
	CharName = "漆漆",
	Text = "游戏机？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_gugu",
	NextID = 89002206,
}
StorySpeechConfig[StorySpeechID.Id89002206] =
{
	Id = 89002206,
	CharName = "兔子",
	Text = "嫦娥抢走了我的游戏，说小孩子不准玩游戏。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89002207,
}
StorySpeechConfig[StorySpeechID.Id89002207] =
{
	Id = 89002207,
	CharName = "兔子",
	Text = "但我只是身体小，我年龄很成熟的！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89002208,
}
StorySpeechConfig[StorySpeechID.Id89002208] =
{
	Id = 89002208,
	CharName = "漆漆",
	Text = "…这样啊喵。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_gugu",
}
StorySpeechConfig[StorySpeechID.Id89002301] =
{
	Id = 89002301,
	CharName = "呜呜",
	Text = "兔兔，我没有办法改变嫦娥姐姐，但我还想劝劝你喵。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 89002302,
}
StorySpeechConfig[StorySpeechID.Id89002302] =
{
	Id = 89002302,
	CharName = "兔子",
	Text = "劝我回家？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89002303,
}
StorySpeechConfig[StorySpeechID.Id89002303] =
{
	Id = 89002303,
	CharName = "呜呜",
	Text = "（点头）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 89002304,
}
StorySpeechConfig[StorySpeechID.Id89002304] =
{
	Id = 89002304,
	CharName = "兔子",
	Text = "如果她不再深夜蹦迪，我很愿意回家的。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89002305,
}
StorySpeechConfig[StorySpeechID.Id89002305] =
{
	Id = 89002305,
	CharName = "兔子",
	Text = "但是…哼。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89002306,
}
StorySpeechConfig[StorySpeechID.Id89002306] =
{
	Id = 89002306,
	CharName = "漆漆",
	Text = "嫦娥姐姐也很让猫伤脑筋啊喵。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_gugu",
}
StorySpeechConfig[StorySpeechID.Id89002401] =
{
	Id = 89002401,
	CharName = "呜呜",
	Text = "…喵。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 89002402,
}
StorySpeechConfig[StorySpeechID.Id89002402] =
{
	Id = 89002402,
	CharName = "兔子",
	Text = "（望天）你知道眼泪的味道吗。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89002403,
}
StorySpeechConfig[StorySpeechID.Id89002403] =
{
	Id = 89002403,
	CharName = "漆漆",
	Text = "听说是咸的喵。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_gugu",
	NextID = 89002404,
}
StorySpeechConfig[StorySpeechID.Id89002404] =
{
	Id = 89002404,
	CharName = "兔子",
	Text = "月宫的冰糖雪梨，咸度是眼泪的1000倍。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89002405,
}
StorySpeechConfig[StorySpeechID.Id89002405] =
{
	Id = 89002405,
	CharName = "漆漆",
	Text = "冰糖雪梨是甜的喵。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_gugu",
	NextID = 89002406,
}
StorySpeechConfig[StorySpeechID.Id89002406] =
{
	Id = 89002406,
	CharName = "呜呜",
	Text = "漆漆，你还不明白吗，一定是嫦娥姐姐把盐当作糖，放进冰糖雪梨里了喵。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_wuwu",
	NextID = 89002407,
}
StorySpeechConfig[StorySpeechID.Id89002407] =
{
	Id = 89002407,
	CharName = "兔子",
	Text = "（落泪）",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_Rabbit",
}
StorySpeechConfig[StorySpeechID.Id89002501] =
{
	Id = 89002501,
	CharName = "兔子",
	Text = "别戳我！这是哪里？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_Rabbit",
	NextID = 89002502,
}
StorySpeechConfig[StorySpeechID.Id89002502] =
{
	Id = 89002502,
	CharName = "漆漆",
	Text = "这是你躲起来的地方喵。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_gugu",
	NextID = 89002503,
}
StorySpeechConfig[StorySpeechID.Id89002503] =
{
	Id = 89002503,
	CharName = "兔子",
	Text = "那个…我好像迷路了。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_Rabbit",
	NextID = 89002504,
}
StorySpeechConfig[StorySpeechID.Id89002504] =
{
	Id = 89002504,
	CharName = "呜呜",
	Text = "那跟我们走吧，我们带你回家喵。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_wuwu",
	NextID = 89002505,
}
StorySpeechConfig[StorySpeechID.Id89002505] =
{
	Id = 89002505,
	CharName = "兔子",
	Text = "回家？不行！我还没吃到全宇宙最好吃的青菜和胡萝卜！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_Rabbit",
}
StorySpeechConfig[StorySpeechID.Id89002601] =
{
	Id = 89002601,
	CharName = "呜呜",
	Text = "兔兔！终于又找到你了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 89002602,
}
StorySpeechConfig[StorySpeechID.Id89002602] =
{
	Id = 89002602,
	CharName = "兔子",
	Text = "我不是兔兔，我是兔仙…",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89002603,
}
StorySpeechConfig[StorySpeechID.Id89002603] =
{
	Id = 89002603,
	CharName = "呜呜",
	Text = "喵？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 89002604,
}
StorySpeechConfig[StorySpeechID.Id89002604] =
{
	Id = 89002604,
	CharName = "兔子",
	Text = "我吃了仙药，我是兔仙…",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89002605,
}
StorySpeechConfig[StorySpeechID.Id89002605] =
{
	Id = 89002605,
	CharName = "漆漆",
	Text = "好像陷入某种幻想里了喵。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_gugu",
}
StorySpeechConfig[StorySpeechID.Id89002701] =
{
	Id = 89002701,
	CharName = "呜呜",
	Text = "找到了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 89002702,
}
StorySpeechConfig[StorySpeechID.Id89002702] =
{
	Id = 89002702,
	CharName = "兔子",
	Text = "Zzzzz...",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89002703,
}
StorySpeechConfig[StorySpeechID.Id89002703] =
{
	Id = 89002703,
	CharName = "漆漆",
	Text = "好像睡着了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_gugu",
	NextID = 89002704,
}
StorySpeechConfig[StorySpeechID.Id89002704] =
{
	Id = 89002704,
	CharName = "兔子",
	Text = "Zzzzz...胡萝卜，给我…（抢）",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89002705,
}
StorySpeechConfig[StorySpeechID.Id89002705] =
{
	Id = 89002705,
	CharName = "呜呜",
	Text = "嗷！好痛！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 89002706,
}
StorySpeechConfig[StorySpeechID.Id89002706] =
{
	Id = 89002706,
	CharName = "漆漆",
	Text = "出血了！我帮你包扎喵。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_gugu",
}
StorySpeechConfig[StorySpeechID.Id89002801] =
{
	Id = 89002801,
	CharName = "呜呜",
	Text = "兔兔...回家吧喵。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 89002802,
}
StorySpeechConfig[StorySpeechID.Id89002802] =
{
	Id = 89002802,
	CharName = "兔子",
	Text = "唔…好吧…",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89002803,
}
StorySpeechConfig[StorySpeechID.Id89002803] =
{
	Id = 89002803,
	CharName = "漆漆",
	Text = "喵？好配合我们喵。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_gugu",
	NextID = 89002804,
}
StorySpeechConfig[StorySpeechID.Id89002804] =
{
	Id = 89002804,
	CharName = "兔子",
	Text = "这里不好玩…\n我，我想回去，在窝里看电影。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89002805,
}
StorySpeechConfig[StorySpeechID.Id89002805] =
{
	Id = 89002805,
	CharName = "兔子",
	Text = "还有软乎乎的坐垫，吃着零食…",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89002806,
}
StorySpeechConfig[StorySpeechID.Id89002806] =
{
	Id = 89002806,
	CharName = "兔子",
	Text = "虽然嫦娥总是蠢蠢的，但我们在一起很开心。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_Rabbit",
	NextID = 89002807,
}
StorySpeechConfig[StorySpeechID.Id89002807] =
{
	Id = 89002807,
	CharName = "呜呜",
	Text = "呜呜可以理解你的心情喵。\n虽然剑士蠢蠢的，但我们的冒险也很开心喵！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 89002808,
}
StorySpeechConfig[StorySpeechID.Id89002808] =
{
	Id = 89002808,
	CharName = "漆漆",
	Text = "好啦，跟我们一起上飞船吧喵。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_gugu",
}
StorySpeechConfig[StorySpeechID.Id62006101] =
{
	Id = 62006101,
	CharName = "旁白喇叭",
	Text = "已到达——山脚温泉别墅。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "EventItem_RPG_Event_8",
	NextID = 62006102,
}
StorySpeechConfig[StorySpeechID.Id62006102] =
{
	Id = 62006102,
	CharName = "蓝衣小学生",
	Text = "（打电话）你真的不来吗？这栋别墅看上去很豪华诶。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006103,
}
StorySpeechConfig[StorySpeechID.Id62006103] =
{
	Id = 62006103,
	CharName = "大侦探",
	Text = "（打电话）没办法，工作要紧，而且我已经把票给别人了。\n下次有机会，我们再去玩。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_01_fuermosi",
	NextID = 62006104,
}
StorySpeechConfig[StorySpeechID.Id62006104] =
{
	Id = 62006104,
	CharName = "蓝衣小学生",
	Text = "（打电话）喂喂，抽中特等奖和住别墅温泉的机会，可不是说有就有的啊。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006105,
}
StorySpeechConfig[StorySpeechID.Id62006105] =
{
	Id = 62006105,
	CharName = "大侦探",
	Text = "（打电话）作为欧皇，你要对自己有自信。\n我还在追踪嫌疑人，挂了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_01_fuermosi",
	NextID = 62006106,
}
StorySpeechConfig[StorySpeechID.Id62006106] =
{
	Id = 62006106,
	CharName = "蓝衣小学生",
	Text = "（叹气）……也不知道大侦探找了谁代替他，希望不是奇怪的家伙。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006107,
}
StorySpeechConfig[StorySpeechID.Id62006107] =
{
	Id = 62006107,
	CharName = "受害者",
	Text = "（开心走进别墅，却又突然愣住）\n怎、怎么是你？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_07_daomeidan",
	NextID = 62006108,
}
StorySpeechConfig[StorySpeechID.Id62006108] =
{
	Id = 62006108,
	CharName = "蓝衣小学生",
	Text = "（恍然大悟）他敢给你票，你还真敢来……就不怕发生什么事？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006109,
}
StorySpeechConfig[StorySpeechID.Id62006109] =
{
	Id = 62006109,
	CharName = "受害者",
	Text = "（理直气壮）本来是敢的，但看到你后……\n不敢来了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_07_daomeidan",
	NextID = 62006110,
}
StorySpeechConfig[StorySpeechID.Id62006110] =
{
	Id = 62006110,
	CharName = "蓝衣小学生",
	Text = "希望我们两人的体质，可以起到负负得正的对冲效果。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006111,
}
StorySpeechConfig[StorySpeechID.Id62006111] =
{
	Id = 62006111,
	CharName = "受害者",
	Text = "唉，来都来了，只能这么想了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_07_daomeidan",
	NextID = 62006112,
}
StorySpeechConfig[StorySpeechID.Id62006112] =
{
	Id = 62006112,
	CharName = "旁白喇叭",
	Text = "二人一起进入别墅大堂，里面站着一位女孩和两位男士。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	RightIcon = "EventItem_RPG_Event_8",
	NextID = 62006113,
}
StorySpeechConfig[StorySpeechID.Id62006113] =
{
	Id = 62006113,
	CharName = "猫眼厨娘",
	Text = "（尖叫）先生！这里不允许带宠物进来！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006114,
}
StorySpeechConfig[StorySpeechID.Id62006114] =
{
	Id = 62006114,
	CharName = "雪中猎人",
	Text = "不行，我的狗子不能和我分开！而且……\n（环视）为什么他儿子可以进来，我的狗子不行？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_29_XueZhongLieRen",
	NextID = 62006115,
}
StorySpeechConfig[StorySpeechID.Id62006115] =
{
	Id = 62006115,
	CharName = "健身教练",
	Text = "哈？你什么意思？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 62006116,
}
StorySpeechConfig[StorySpeechID.Id62006116] =
{
	Id = 62006116,
	CharName = "雪中猎人",
	Text = "大家都带着自己的宝贝，凭什么你儿子和我狗子要区别对待？（撸袖子）",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_29_XueZhongLieRen",
	NextID = 62006117,
}
StorySpeechConfig[StorySpeechID.Id62006117] =
{
	Id = 62006117,
	CharName = "健身教练",
	Text = "你的意思是，我儿子和狗一样？\n欺人太甚！（扭打）",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 62006118,
}
StorySpeechConfig[StorySpeechID.Id62006118] =
{
	Id = 62006118,
	CharName = "受害者",
	Text = "（劝架）这里是度假地诶！\n你们……你们不要再打了啦！要打架去练武房打！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_07_daomeidan",
	NextID = 62006119,
}
StorySpeechConfig[StorySpeechID.Id62006119] =
{
	Id = 62006119,
	CharName = "蓝衣小学生",
	Text = "喂喂，你别多管闲事——呃，小心！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_20_lanyixiaoxuesheng",
}
StorySpeechConfig[StorySpeechID.Id62006151] =
{
	Id = 62006151,
	CharName = "蓝衣小学生",
	Text = "（叹气）难怪你能成为受害者。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006152,
}
StorySpeechConfig[StorySpeechID.Id62006152] =
{
	Id = 62006152,
	CharName = "编剧妹子",
	Text = "（下楼）楼下终于安静了。\n啊，世界上没有幸福，但有自由和宁静！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_30_BianJuMeiZi",
	NextID = 62006153,
}
StorySpeechConfig[StorySpeechID.Id62006153] =
{
	Id = 62006153,
	CharName = "猫眼厨娘",
	Text = "（笑）你下来了呀~今天又有新客人了。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006154,
}
StorySpeechConfig[StorySpeechID.Id62006154] =
{
	Id = 62006154,
	CharName = "编剧妹子",
	Text = "嗯，你们好~我是来这里寻找写作灵感的。\n假如生活欺骗了你，不要悲伤，不要心急！忧郁的日子里须要镇静！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_30_BianJuMeiZi",
	NextID = 62006155,
}
StorySpeechConfig[StorySpeechID.Id62006155] =
{
	Id = 62006155,
	CharName = "健身教练",
	Text = "唔，我是和儿子一起来锻炼身体的。\n（握拳）我和我的儿子，一定要征服那座雪山！喝！小猛男，让全世界看到我们的力量吧！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 62006156,
}
StorySpeechConfig[StorySpeechID.Id62006156] =
{
	Id = 62006156,
	CharName = "雪中猎人",
	Text = "别自以为是了，那座雪山可是很危险的，只有准备好的人才能征服它。（擦猎枪）",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_29_XueZhongLieRen",
	NextID = 62006157,
}
StorySpeechConfig[StorySpeechID.Id62006157] =
{
	Id = 62006157,
	CharName = "健身教练",
	Text = "哼，区区猎枪算什么，我们的肌肉无坚不摧！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 62006158,
}
StorySpeechConfig[StorySpeechID.Id62006158] =
{
	Id = 62006158,
	CharName = "温泉鉴赏家",
	Text = "好啦好啦，客人们好不容易来这里一趟~\n千万别再发生冲突了，呜呜…",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_26_WenQuanJianShanJia",
	NextID = 62006159,
}
StorySpeechConfig[StorySpeechID.Id62006159] =
{
	Id = 62006159,
	CharName = "温泉鉴赏家",
	Text = "放心，您的狗子，我帮您暂行看管，一会儿一定还给您！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_26_WenQuanJianShanJia",
	NextID = 62006160,
}
StorySpeechConfig[StorySpeechID.Id62006160] =
{
	Id = 62006160,
	CharName = "温泉鉴赏家",
	Text = "放心，您的儿子……啊，您自己带着他就好~",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_26_WenQuanJianShanJia",
	NextID = 62006161,
}
StorySpeechConfig[StorySpeechID.Id62006161] =
{
	Id = 62006161,
	CharName = "猫眼厨娘",
	Text = "这家伙是我男朋友，嗯……至于我嘛，是这家别墅温泉的老板。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006162,
}
StorySpeechConfig[StorySpeechID.Id62006162] =
{
	Id = 62006162,
	CharName = "蓝衣小学生",
	Text = "（惊）老板？！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006163,
}
StorySpeechConfig[StorySpeechID.Id62006163] =
{
	Id = 62006163,
	CharName = "温泉鉴赏家",
	Text = "哈哈，她可不是一般的小厨娘啊！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_26_WenQuanJianShanJia",
	NextID = 62006164,
}
StorySpeechConfig[StorySpeechID.Id62006164] =
{
	Id = 62006164,
	CharName = "受害者",
	Text = "你们好，我们两个是抽到了旅行杂志的特等奖，才过来度假的……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_07_daomeidan",
	NextID = 62006165,
}
StorySpeechConfig[StorySpeechID.Id62006165] =
{
	Id = 62006165,
	CharName = "编剧妹子",
	Text = "抽中特等奖？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_30_BianJuMeiZi",
	NextID = 62006166,
}
StorySpeechConfig[StorySpeechID.Id62006166] =
{
	Id = 62006166,
	CharName = "健身教练",
	Text = "儿子，你看，这就是传说中的欧皇！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 62006167,
}
StorySpeechConfig[StorySpeechID.Id62006167] =
{
	Id = 62006167,
	CharName = "雪中猎人",
	Text = "这精准抓住特等奖的概率……比我打枪还要准啊！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_29_XueZhongLieRen",
	NextID = 62006168,
}
StorySpeechConfig[StorySpeechID.Id62006168] =
{
	Id = 62006168,
	CharName = "温泉鉴赏家",
	Text = "不过，不管怎么说，抽奖主办方还是赚的……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_26_WenQuanJianShanJia",
	NextID = 62006169,
}
StorySpeechConfig[StorySpeechID.Id62006169] =
{
	Id = 62006169,
	CharName = "猫眼厨娘",
	Text = "（星星眼）太幸运了！让我摸摸你！我愿意向您们提供别墅里的欧皇特制套餐——\n黄金糕、无泥白肉和白咖啡！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
}
StorySpeechConfig[StorySpeechID.Id62006201] =
{
	Id = 62006201,
	CharName = "猫眼厨娘",
	Text = "说来，你们刚刚说想要去雪山?",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006202,
}
StorySpeechConfig[StorySpeechID.Id62006202] =
{
	Id = 62006202,
	CharName = "雪中猎人",
	Text = "怎么，狗子不能进别墅，猎人还不能上山？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_29_XueZhongLieRen",
	NextID = 62006203,
}
StorySpeechConfig[StorySpeechID.Id62006203] =
{
	Id = 62006203,
	CharName = "猫眼厨娘",
	Text = "我的意思是……关于“雪怪吃人”的传言，你们没有听过吗？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006204,
}
StorySpeechConfig[StorySpeechID.Id62006204] =
{
	Id = 62006204,
	CharName = "编剧妹子",
	Text = "（双眼发光）雪怪？吃人？悬疑惊悚剧？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_30_BianJuMeiZi",
	NextID = 62006205,
}
StorySpeechConfig[StorySpeechID.Id62006205] =
{
	Id = 62006205,
	CharName = "雪中猎人",
	Text = "没有，我对都市怪谈没有兴趣。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_29_XueZhongLieRen",
	NextID = 62006206,
}
StorySpeechConfig[StorySpeechID.Id62006206] =
{
	Id = 62006206,
	CharName = "猫眼厨娘",
	Text = "据说，后山住着一只会控制风雪的妖怪，在这里生活的人，都叫它叫“雪怪”。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006207,
}
StorySpeechConfig[StorySpeechID.Id62006207] =
{
	Id = 62006207,
	CharName = "猫眼厨娘",
	Text = "很多年以前，有位热爱冒险的少年，发誓一定要看到顶峰的风光。\n那是命中注定的一天，他和朋友相约一起登山",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006208,
}
StorySpeechConfig[StorySpeechID.Id62006208] =
{
	Id = 62006208,
	CharName = "猫眼厨娘",
	Text = "在攀爬过程中，风雪越来越大，地面越来越滑，但他们一直坚持前行，从未说过放弃。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006209,
}
StorySpeechConfig[StorySpeechID.Id62006209] =
{
	Id = 62006209,
	CharName = "猫眼厨娘",
	Text = "然而，就在快要登峰时，一个妖怪出现了。\n妖怪“呼”地一吹气，山里再度掀起狂风暴雪。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006210,
}
StorySpeechConfig[StorySpeechID.Id62006210] =
{
	Id = 62006210,
	CharName = "编剧妹子",
	Text = "（听得津津有味）那两个少年呢？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_30_BianJuMeiZi",
	NextID = 62006211,
}
StorySpeechConfig[StorySpeechID.Id62006211] =
{
	Id = 62006211,
	CharName = "猫眼厨娘",
	Text = "父母发现孩子彻夜未归，立刻报警，警察找了整整五天，才在山脚下找到他们。但已经是两具尸体了……因为气温低，尸体没有腐烂，不过……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006212,
}
StorySpeechConfig[StorySpeechID.Id62006212] =
{
	Id = 62006212,
	CharName = "蓝衣小学生",
	Text = "不过……？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006213,
}
StorySpeechConfig[StorySpeechID.Id62006213] =
{
	Id = 62006213,
	CharName = "猫眼厨娘",
	Text = "不过，它残缺不全，上面还有巨大的齿痕。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006214,
}
StorySpeechConfig[StorySpeechID.Id62006214] =
{
	Id = 62006214,
	CharName = "受害者",
	Text = "（抖）就是说……他们被吃、吃掉了……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_07_daomeidan",
	NextID = 62006215,
}
StorySpeechConfig[StorySpeechID.Id62006215] =
{
	Id = 62006215,
	CharName = "教练的儿子",
	Text = "（哭）呜哇哇哇……呜呜啊啊——",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_boy1",
	NextID = 62006216,
}
StorySpeechConfig[StorySpeechID.Id62006216] =
{
	Id = 62006216,
	CharName = "健身教练",
	Text = "儿子别怕，男人不能流泪！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 62006217,
}
StorySpeechConfig[StorySpeechID.Id62006217] =
{
	Id = 62006217,
	CharName = "猫眼厨娘",
	Text = "据说，深夜时分，他偶尔也会来山脚下晃悠……因此，“白天不上山，晚上不乱逛”，成为了居民们约定俗成的规矩。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006218,
}
StorySpeechConfig[StorySpeechID.Id62006218] =
{
	Id = 62006218,
	CharName = "编剧妹子",
	Text = "那雪怪长什么样呢？是男是女？有什么特征？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_30_BianJuMeiZi",
	NextID = 62006219,
}
StorySpeechConfig[StorySpeechID.Id62006219] =
{
	Id = 62006219,
	CharName = "猫眼厨娘",
	Text = "不知道。\n据说，他浑身散发着冰冷的气息，让人无法靠近，因此看不清面容。那家伙似乎没有双腿，像风一样飘在空中。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006220,
}
StorySpeechConfig[StorySpeechID.Id62006220] =
{
	Id = 62006220,
	CharName = "猫眼厨娘",
	Text = "对了，就像这样……（穿上幽灵套装）",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_25_MaoYanChuNiang",
}
StorySpeechConfig[StorySpeechID.Id62006251] =
{
	Id = 62006251,
	CharName = "受害者",
	Text = "（颤抖）天……啊。（晕倒）",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_07_daomeidan",
	NextID = 62006252,
}
StorySpeechConfig[StorySpeechID.Id62006252] =
{
	Id = 62006252,
	CharName = "编剧妹子",
	Text = "她被吓晕了吗？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_30_BianJuMeiZi",
	NextID = 62006253,
}
StorySpeechConfig[StorySpeechID.Id62006253] =
{
	Id = 62006253,
	CharName = "蓝衣小学生",
	Text = "显然如此。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006254,
}
StorySpeechConfig[StorySpeechID.Id62006254] =
{
	Id = 62006254,
	CharName = "猫眼厨娘",
	Text = "很抱歉……我来把她扶回房间。\n（回头）虽然那只是传说，但你们还是要多加小心哦~",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006255,
}
StorySpeechConfig[StorySpeechID.Id62006255] =
{
	Id = 62006255,
	CharName = "旁白喇叭",
	Text = "不出厨娘所料，除编剧妹子和蓝衣小学生，在场诸人几乎都被吓傻了。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "EventItem_RPG_Event_8",
	NextID = 62006256,
}
StorySpeechConfig[StorySpeechID.Id62006256] =
{
	Id = 62006256,
	CharName = "温泉鉴赏家",
	Text = "大家别想太多，说到底，只是传说而已~接下来，大家要不要去试一试我们的温泉呀？我们这儿泡澡可是一绝，各种味道应有尽有。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_26_WenQuanJianShanJia",
	NextID = 62006257,
}
StorySpeechConfig[StorySpeechID.Id62006257] =
{
	Id = 62006257,
	CharName = "教练的儿子",
	Text = "爸爸，温泉！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_boy1",
	NextID = 62006258,
}
StorySpeechConfig[StorySpeechID.Id62006258] =
{
	Id = 62006258,
	CharName = "健身教练",
	Text = "嗯，在温泉里泡着，也是一种锻炼啊……儿子，我们走！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 62006259,
}
StorySpeechConfig[StorySpeechID.Id62006259] =
{
	Id = 62006259,
	CharName = "温泉鉴赏家",
	Text = "（看向蓝衣小学生）\n我们也一起去吧，小弟弟？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_26_WenQuanJianShanJia",
	NextID = 62006260,
}
StorySpeechConfig[StorySpeechID.Id62006260] =
{
	Id = 62006260,
	CharName = "蓝衣小学生",
	Text = "诶？（乖巧）嗯！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
}
StorySpeechConfig[StorySpeechID.Id62006301] =
{
	Id = 62006301,
	CharName = "雪中猎人",
	Text = "（裹紧浴巾）……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_29_XueZhongLieRen",
	NextID = 62006302,
}
StorySpeechConfig[StorySpeechID.Id62006302] =
{
	Id = 62006302,
	CharName = "健身教练",
	Text = "老哥，别害羞，扭扭捏捏实在不像话啊，哈哈哈！连我儿子也在嘲笑你啦！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 62006303,
}
StorySpeechConfig[StorySpeechID.Id62006303] =
{
	Id = 62006303,
	CharName = "雪中猎人",
	Text = "你们！不准盯着我看！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_29_XueZhongLieRen",
	NextID = 62006304,
}
StorySpeechConfig[StorySpeechID.Id62006304] =
{
	Id = 62006304,
	CharName = "蓝衣小学生",
	Text = "厨娘姐姐，你刚刚说的雪怪，它后来还伤害过别人吗？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006305,
}
StorySpeechConfig[StorySpeechID.Id62006305] =
{
	Id = 62006305,
	CharName = "猫眼厨娘",
	Text = "不知道，之后的故事……我没有打听过。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006306,
}
StorySpeechConfig[StorySpeechID.Id62006306] =
{
	Id = 62006306,
	CharName = "蓝衣小学生",
	Text = "嗯……厨娘姐姐，你是什么时候搬来这里住的呀？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006307,
}
StorySpeechConfig[StorySpeechID.Id62006307] =
{
	Id = 62006307,
	CharName = "猫眼厨娘",
	Text = "半年以前吧，怎么了？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006308,
}
StorySpeechConfig[StorySpeechID.Id62006308] =
{
	Id = 62006308,
	CharName = "蓝衣小学生",
	Text = "那这期间，雪怪伤害过附近的居民吗？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006309,
}
StorySpeechConfig[StorySpeechID.Id62006309] =
{
	Id = 62006309,
	CharName = "猫眼厨娘",
	Text = "（摇头）没有，但我也不清楚。小弟弟，这件事很复杂，水很深，不是小孩子该了解的，你安安心心度假就好了，好吗？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006310,
}
StorySpeechConfig[StorySpeechID.Id62006310] =
{
	Id = 62006310,
	CharName = "蓝衣小学生",
	Text = "（乖巧）好~！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006311,
}
StorySpeechConfig[StorySpeechID.Id62006311] =
{
	Id = 62006311,
	CharName = "旁白喇叭",
	Text = "另一边，温泉鉴赏家正气鼓鼓地蹲在温泉台阶上。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "EventItem_RPG_Event_8",
	NextID = 62006312,
}
StorySpeechConfig[StorySpeechID.Id62006312] =
{
	Id = 62006312,
	CharName = "猫眼厨娘",
	Text = "你怎么了？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006313,
}
StorySpeechConfig[StorySpeechID.Id62006313] =
{
	Id = 62006313,
	CharName = "温泉鉴赏家",
	Text = "这水，不，这药剂包，绝对有问题！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_26_WenQuanJianShanJia",
	NextID = 62006314,
}
StorySpeechConfig[StorySpeechID.Id62006314] =
{
	Id = 62006314,
	CharName = "猫眼厨娘",
	Text = "什么问题？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006315,
}
StorySpeechConfig[StorySpeechID.Id62006315] =
{
	Id = 62006315,
	CharName = "温泉鉴赏家",
	Text = "我记得很清楚，它的味道没有这么寡淡，一定有人把我的药剂包偷走了！\n（拿起泉底药剂包）说，你是哪个汤池的！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_26_WenQuanJianShanJia",
	NextID = 62006316,
}
StorySpeechConfig[StorySpeechID.Id62006316] =
{
	Id = 62006316,
	CharName = "药剂包",
	Text = "……我哪知道啊，这里的池子那么多。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "All_YaoJiBao",
	NextID = 62006317,
}
StorySpeechConfig[StorySpeechID.Id62006317] =
{
	Id = 62006317,
	CharName = "温泉鉴赏家",
	Text = "你——你仔细回忆回忆！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_26_WenQuanJianShanJia",
	NextID = 62006318,
}
StorySpeechConfig[StorySpeechID.Id62006318] =
{
	Id = 62006318,
	CharName = "药剂包",
	Text = "差不多得了，我要沉下去睡觉了。\nZzzzzzzz...",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "All_YaoJiBao",
	NextID = 62006319,
}
StorySpeechConfig[StorySpeechID.Id62006319] =
{
	Id = 62006319,
	CharName = "温泉鉴赏家",
	Text = "喂！你给我起来——",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_26_WenQuanJianShanJia",
}
StorySpeechConfig[StorySpeechID.Id62006351] =
{
	Id = 62006351,
	CharName = "温泉鉴赏家",
	Text = "一定有哪里不对，这个药剂包，绝对不是这个味儿。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_26_WenQuanJianShanJia",
	NextID = 62006352,
}
StorySpeechConfig[StorySpeechID.Id62006352] =
{
	Id = 62006352,
	CharName = "健身教练",
	Text = "我觉得挺好啊，舒服，你看，我儿子现在多兴奋啊。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 62006353,
}
StorySpeechConfig[StorySpeechID.Id62006353] =
{
	Id = 62006353,
	CharName = "旁白喇叭",
	Text = "如他所言，教练的儿子从温泉从爬出来，开心地旋转、跳跃。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "EventItem_RPG_Event_8",
	NextID = 62006354,
}
StorySpeechConfig[StorySpeechID.Id62006354] =
{
	Id = 62006354,
	CharName = "雪中猎人",
	Text = "嗯，非常舒服！\n（脸红）谢谢你们提供的服务。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_29_XueZhongLieRen",
	NextID = 62006355,
}
StorySpeechConfig[StorySpeechID.Id62006355] =
{
	Id = 62006355,
	CharName = "温泉鉴赏家",
	Text = "（忧愁）唉……只是这样的程度，你们就满足了吗？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_26_WenQuanJianShanJia",
	NextID = 62006356,
}
StorySpeechConfig[StorySpeechID.Id62006356] =
{
	Id = 62006356,
	CharName = "旁白喇叭",
	Text = "不远处，一个黑影飞一般闪过。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	RightIcon = "EventItem_RPG_Event_8",
	NextID = 62006357,
}
StorySpeechConfig[StorySpeechID.Id62006357] =
{
	Id = 62006357,
	CharName = "蓝衣小学生",
	Text = "那个飘逸的衣角……好熟悉的感觉。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_20_lanyixiaoxuesheng",
}
StorySpeechConfig[StorySpeechID.Id62006401] =
{
	Id = 62006401,
	CharName = "旁白喇叭",
	Text = "远道而来的旅客们收获了一个完美的夜晚。\n翌日，大家早早起来用餐，闲谈时对昨日的温泉赞不绝口。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "EventItem_RPG_Event_8",
	NextID = 62006402,
}
StorySpeechConfig[StorySpeechID.Id62006402] =
{
	Id = 62006402,
	CharName = "蓝衣小学生",
	Text = "大家早！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006403,
}
StorySpeechConfig[StorySpeechID.Id62006403] =
{
	Id = 62006403,
	CharName = "温泉鉴赏家",
	Text = "早啊，就等你们俩了，再不来煎蛋都要凉了。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_26_WenQuanJianShanJia",
	NextID = 62006404,
}
StorySpeechConfig[StorySpeechID.Id62006404] =
{
	Id = 62006404,
	CharName = "编剧妹子",
	Text = "和你一起来的小姑娘呢？她还没醒吗？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_30_BianJuMeiZi",
	NextID = 62006405,
}
StorySpeechConfig[StorySpeechID.Id62006405] =
{
	Id = 62006405,
	CharName = "蓝衣小学生",
	Text = "（摇头）不知道，昨晚开始就没见过她。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006406,
}
StorySpeechConfig[StorySpeechID.Id62006406] =
{
	Id = 62006406,
	CharName = "编剧妹子",
	Text = "（自顾自地）真可怜，昨天被雪怪的传说吓晕过去，也不知道现在怎么样了。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_30_BianJuMeiZi",
	NextID = 62006407,
}
StorySpeechConfig[StorySpeechID.Id62006407] =
{
	Id = 62006407,
	CharName = "猫眼厨娘",
	Text = "我打下房间电话。（走到前台，拿起话筒）",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006408,
}
StorySpeechConfig[StorySpeechID.Id62006408] =
{
	Id = 62006408,
	CharName = "旁白喇叭",
	Text = "电话中传来嘟嘟嘟的声音，过了许久，依旧无人接听。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	RightIcon = "EventItem_RPG_Event_8",
	NextID = 62006409,
}
StorySpeechConfig[StorySpeechID.Id62006409] =
{
	Id = 62006409,
	CharName = "猫眼厨娘",
	Text = "……不在房间吗？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006410,
}
StorySpeechConfig[StorySpeechID.Id62006410] =
{
	Id = 62006410,
	CharName = "健身教练",
	Text = "怪了，我一大早就起床晨练，别墅里面没见着她。儿子，你呢？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 62006411,
}
StorySpeechConfig[StorySpeechID.Id62006411] =
{
	Id = 62006411,
	CharName = "蓝衣小学生",
	Text = "（惊）难道说——！！我去看看！！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006412,
}
StorySpeechConfig[StorySpeechID.Id62006412] =
{
	Id = 62006412,
	CharName = "健身教练",
	Text = "喂，你去哪儿！\n儿子，快跑，超过那个哥哥！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 62006413,
}
StorySpeechConfig[StorySpeechID.Id62006413] =
{
	Id = 62006413,
	CharName = "旁白喇叭",
	Text = "几分钟后，大家陆陆续续赶到了受害者门前。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "EventItem_RPG_Event_8",
	NextID = 62006414,
}
StorySpeechConfig[StorySpeechID.Id62006414] =
{
	Id = 62006414,
	CharName = "蓝衣小学生",
	Text = "我敲了好几次门，没有人开。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006415,
}
StorySpeechConfig[StorySpeechID.Id62006415] =
{
	Id = 62006415,
	CharName = "编剧妹子",
	Text = "老板有万能钥匙吗？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_30_BianJuMeiZi",
	NextID = 62006416,
}
StorySpeechConfig[StorySpeechID.Id62006416] =
{
	Id = 62006416,
	CharName = "猫眼厨娘",
	Text = "（摇头）我们别墅没有这种东西。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006417,
}
StorySpeechConfig[StorySpeechID.Id62006417] =
{
	Id = 62006417,
	CharName = "健身教练",
	Text = "那只能破门而入了……老板，你没意见吧？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 62006418,
}
StorySpeechConfig[StorySpeechID.Id62006418] =
{
	Id = 62006418,
	CharName = "猫眼厨娘",
	Text = "为了客人的安全……我没有意见。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_25_MaoYanChuNiang",
}
StorySpeechConfig[StorySpeechID.Id62006451] =
{
	Id = 62006451,
	CharName = "旁白喇叭",
	Text = "健身教练破门而入，只见房间整洁，受害者虚弱地倒在床边，似乎还有一丝意识。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "EventItem_RPG_Event_8",
	NextID = 62006452,
}
StorySpeechConfig[StorySpeechID.Id62006452] =
{
	Id = 62006452,
	CharName = "蓝衣小学生",
	Text = "（凑近）怎么了！是谁干的！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006453,
}
StorySpeechConfig[StorySpeechID.Id62006453] =
{
	Id = 62006453,
	CharName = "受害者",
	Text = "（虚弱）做这件事的人、就是……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_07_daomeidan",
	NextID = 62006454,
}
StorySpeechConfig[StorySpeechID.Id62006454] =
{
	Id = 62006454,
	CharName = "蓝衣小学生",
	Text = "谁？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006455,
}
StorySpeechConfig[StorySpeechID.Id62006455] =
{
	Id = 62006455,
	CharName = "受害者",
	Text = "（虚弱）那个人、就是……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_07_daomeidan",
	NextID = 62006456,
}
StorySpeechConfig[StorySpeechID.Id62006456] =
{
	Id = 62006456,
	CharName = "蓝衣小学生",
	Text = "你说，谁？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006457,
}
StorySpeechConfig[StorySpeechID.Id62006457] =
{
	Id = 62006457,
	CharName = "受害者",
	Text = "（虚弱）就是……呃。（晕倒）",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_07_daomeidan",
	NextID = 62006458,
}
StorySpeechConfig[StorySpeechID.Id62006458] =
{
	Id = 62006458,
	CharName = "健身教练",
	Text = "（暴怒）叫你说个名字而已有那么困难吗！\n（摇晃）儿子，把她摇醒，然后报警！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 62006459,
}
StorySpeechConfig[StorySpeechID.Id62006459] =
{
	Id = 62006459,
	CharName = "编剧妹子",
	Text = "别动她，你已经涉嫌侮辱尸体了。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_30_BianJuMeiZi",
	NextID = 62006460,
}
StorySpeechConfig[StorySpeechID.Id62006460] =
{
	Id = 62006460,
	CharName = "温泉鉴赏家",
	Text = "她根本就没死，哪来的尸体啊？！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_26_WenQuanJianShanJia",
	NextID = 62006461,
}
StorySpeechConfig[StorySpeechID.Id62006461] =
{
	Id = 62006461,
	CharName = "雪中猎人",
	Text = "难道……是雪怪晚上下山，袭击了她吗？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_29_XueZhongLieRen",
	NextID = 62006462,
}
StorySpeechConfig[StorySpeechID.Id62006462] =
{
	Id = 62006462,
	CharName = "猫眼厨娘",
	Text = "（犹豫）不、不……怎么可能呢？雪怪不会袭击住在屋子里的人。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006463,
}
StorySpeechConfig[StorySpeechID.Id62006463] =
{
	Id = 62006463,
	CharName = "健身教练",
	Text = "这么心虚？你也不确定对吧！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 62006464,
}
StorySpeechConfig[StorySpeechID.Id62006464] =
{
	Id = 62006464,
	CharName = "编剧妹子",
	Text = "你们别吵了……\n（灵感乍现）别墅密室案件……有了！让我静静。（离开）",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_30_BianJuMeiZi",
	NextID = 62006465,
}
StorySpeechConfig[StorySpeechID.Id62006465] =
{
	Id = 62006465,
	CharName = "蓝衣小学生",
	Text = "等等，这种时候不能单独行动……诶？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006466,
}
StorySpeechConfig[StorySpeechID.Id62006466] =
{
	Id = 62006466,
	CharName = "旁白喇叭",
	Text = "蓝衣小学生突然发现地上的奇怪物品：烟灰。\n但非常明显，受害者从不抽烟。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	RightIcon = "EventItem_RPG_Event_8",
	NextID = 62006467,
}
StorySpeechConfig[StorySpeechID.Id62006467] =
{
	Id = 62006467,
	CharName = "旁白喇叭",
	Text = "他跑去窗台，窗沿上没有痕迹，窗外的雪地上也没有任何脚印。\n这令他不禁陷入沉思。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	RightIcon = "EventItem_RPG_Event_8",
	NextID = 62006468,
}
StorySpeechConfig[StorySpeechID.Id62006468] =
{
	Id = 62006468,
	CharName = "雪中猎人",
	Text = "（摸狗头）狗子，等风雪变小，我们就离开这个倒霉的地方，呜……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_29_XueZhongLieRen",
}
StorySpeechConfig[StorySpeechID.Id62006501] =
{
	Id = 62006501,
	CharName = "蓝衣小学生",
	Text = "（思索）没有脚印，没有机关，凶手究竟是怎么进入房间的呢？还有灰白色的烟灰，这种烟的品质不差，应该是雪茄之类的……但它会是谁的呢？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006502,
}
StorySpeechConfig[StorySpeechID.Id62006502] =
{
	Id = 62006502,
	CharName = "蓝衣小学生",
	Text = "不，根据我的观察，他们都没有抽烟的习惯。\n是我遗漏什么了吗？到底遗漏什么了？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006503,
}
StorySpeechConfig[StorySpeechID.Id62006503] =
{
	Id = 62006503,
	CharName = "旁白喇叭",
	Text = "忽然间，大厅门口传来争执的声音。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	RightIcon = "EventItem_RPG_Event_8",
	NextID = 62006504,
}
StorySpeechConfig[StorySpeechID.Id62006504] =
{
	Id = 62006504,
	CharName = "雪中猎人",
	Text = "你非法软禁我们！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_29_XueZhongLieRen",
	NextID = 62006505,
}
StorySpeechConfig[StorySpeechID.Id62006505] =
{
	Id = 62006505,
	CharName = "温泉鉴赏家",
	Text = "随你怎么说，我和小厨娘在保护你们。现在只有别墅里最安全！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_26_WenQuanJianShanJia",
	NextID = 62006506,
}
StorySpeechConfig[StorySpeechID.Id62006506] =
{
	Id = 62006506,
	CharName = "雪中猎人",
	Text = "呸！我看你们别墅里最不安全！我现在就要走，退钱！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_29_XueZhongLieRen",
	NextID = 62006507,
}
StorySpeechConfig[StorySpeechID.Id62006507] =
{
	Id = 62006507,
	CharName = "温泉鉴赏家",
	Text = "你以为我会轻易让我的客户流失掉吗？！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_26_WenQuanJianShanJia",
	NextID = 62006508,
}
StorySpeechConfig[StorySpeechID.Id62006508] =
{
	Id = 62006508,
	CharName = "旁白喇叭",
	Text = "突然，小厨娘慌慌张张地跑来。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "EventItem_RPG_Event_8",
	NextID = 62006509,
}
StorySpeechConfig[StorySpeechID.Id62006509] =
{
	Id = 62006509,
	CharName = "猫眼厨娘",
	Text = "那个念诗的小姑娘……你们有人见过她吗？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006510,
}
StorySpeechConfig[StorySpeechID.Id62006510] =
{
	Id = 62006510,
	CharName = "雪中猎人",
	Text = "（懵）没有……\n难道说，她也被……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_29_XueZhongLieRen",
	NextID = 62006511,
}
StorySpeechConfig[StorySpeechID.Id62006511] =
{
	Id = 62006511,
	CharName = "猫眼厨娘",
	Text = "很有可能！\n我刚刚遇到她，她说突然有了灵感，可以写一篇什么《雪怪与山庄之罪恶案件》，还要去山上看雪。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006512,
}
StorySpeechConfig[StorySpeechID.Id62006512] =
{
	Id = 62006512,
	CharName = "猫眼厨娘",
	Text = "我阻止过了，但是，一转眼她就不见了，我担心……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006513,
}
StorySpeechConfig[StorySpeechID.Id62006513] =
{
	Id = 62006513,
	CharName = "温泉鉴赏家",
	Text = "那我们还在这儿讨论什么呢，执行要紧，大家快去找人啊！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_26_WenQuanJianShanJia",
	NextID = 62006514,
}
StorySpeechConfig[StorySpeechID.Id62006514] =
{
	Id = 62006514,
	CharName = "旁白喇叭",
	Text = "一行人慌忙打开别墅大门，巨大的风雪迎来，大家举步维艰。蓝衣小学生率先冲出，一抬眼就发现编剧妹子半身靠在墙壁上，晕了过去。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	RightIcon = "EventItem_RPG_Event_8",
	NextID = 62006515,
}
StorySpeechConfig[StorySpeechID.Id62006515] =
{
	Id = 62006515,
	CharName = "蓝衣小学生",
	Text = "她在这里！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006516,
}
StorySpeechConfig[StorySpeechID.Id62006516] =
{
	Id = 62006516,
	CharName = "黑衣人",
	Text = "坏了！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_28_heiyiren",
	NextID = 62006517,
}
StorySpeechConfig[StorySpeechID.Id62006517] =
{
	Id = 62006517,
	CharName = "蓝衣小学生",
	Text = "什么人？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_20_lanyixiaoxuesheng",
}
StorySpeechConfig[StorySpeechID.Id62006551] =
{
	Id = 62006551,
	CharName = "健身教练",
	Text = "你区区一个小学生，竟然比我们跑得都快！\n唔，儿子，这真是爸爸职业生涯之滑铁卢啊！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 62006552,
}
StorySpeechConfig[StorySpeechID.Id62006552] =
{
	Id = 62006552,
	CharName = "雪中猎人",
	Text = "人呢？没追到？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_29_XueZhongLieRen",
	NextID = 62006553,
}
StorySpeechConfig[StorySpeechID.Id62006553] =
{
	Id = 62006553,
	CharName = "蓝衣小学生",
	Text = "嗯，让他跑了。\n那个姐姐怎么样了？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006554,
}
StorySpeechConfig[StorySpeechID.Id62006554] =
{
	Id = 62006554,
	CharName = "雪中猎人",
	Text = "已经被老板和她男朋友抬进去了，我看啊，八成是睡着了。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_29_XueZhongLieRen",
	NextID = 62006555,
}
StorySpeechConfig[StorySpeechID.Id62006555] =
{
	Id = 62006555,
	CharName = "蓝衣小学生",
	Text = "还好这次及时赶到，否则可能真有发生案件。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006556,
}
StorySpeechConfig[StorySpeechID.Id62006556] =
{
	Id = 62006556,
	CharName = "雪中猎人",
	Text = "（叹气）我们到底为什么来这个鬼地方啊！\n唉。（伸手，打算摸狗头）",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_29_XueZhongLieRen",
	NextID = 62006557,
}
StorySpeechConfig[StorySpeechID.Id62006557] =
{
	Id = 62006557,
	CharName = "健身教练",
	Text = "别碰我儿子，你的狗在那边！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 62006558,
}
StorySpeechConfig[StorySpeechID.Id62006558] =
{
	Id = 62006558,
	CharName = "旁白喇叭",
	Text = "三人进入别墅大厅，待到猫眼厨娘安置好编剧妹子后，蓝衣小学生避开所有人的目光，悄悄潜入了编剧妹子房间。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "EventItem_RPG_Event_8",
	NextID = 62006559,
}
StorySpeechConfig[StorySpeechID.Id62006559] =
{
	Id = 62006559,
	CharName = "蓝衣小学生",
	Text = "（观察窗户）这是——！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006560,
}
StorySpeechConfig[StorySpeechID.Id62006560] =
{
	Id = 62006560,
	CharName = "旁白喇叭",
	Text = "蓝衣小学生发现窗边的奇怪物品：玻璃碎渣。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "EventItem_RPG_Event_8",
}
StorySpeechConfig[StorySpeechID.Id62006601] =
{
	Id = 62006601,
	CharName = "雪中猎人",
	Text = "（失去耐心）……我们什么时候才能离开！！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_29_XueZhongLieRen",
	NextID = 62006602,
}
StorySpeechConfig[StorySpeechID.Id62006602] =
{
	Id = 62006602,
	CharName = "健身教练",
	Text = "（语重心长）孩子，咱们在这里，是与自然斗智斗勇的过程！这一切都是为了培养你的耐力，为了让你成为一个优秀的男人！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 62006603,
}
StorySpeechConfig[StorySpeechID.Id62006603] =
{
	Id = 62006603,
	CharName = "雪中猎人",
	Text = "……我的狗要憋坏了。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_29_XueZhongLieRen",
	NextID = 62006604,
}
StorySpeechConfig[StorySpeechID.Id62006604] =
{
	Id = 62006604,
	CharName = "猫眼厨娘",
	Text = "哈？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006605,
}
StorySpeechConfig[StorySpeechID.Id62006605] =
{
	Id = 62006605,
	CharName = "雪中猎人",
	Text = "我已经很久没和他出去散步了……你看，他已经要被逼疯了。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_29_XueZhongLieRen",
	NextID = 62006606,
}
StorySpeechConfig[StorySpeechID.Id62006606] =
{
	Id = 62006606,
	CharName = "猫眼厨娘",
	Text = "……抱歉，我会努力解决这个问题。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006607,
}
StorySpeechConfig[StorySpeechID.Id62006607] =
{
	Id = 62006607,
	CharName = "旁白喇叭",
	Text = "雪中猎人本来只是抱怨几句，然而当晚落日时分时，他的猎犬似乎收到某种暗示一般，疯了一样地冲出别墅，跑向雪山。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "EventItem_RPG_Event_8",
	NextID = 62006608,
}
StorySpeechConfig[StorySpeechID.Id62006608] =
{
	Id = 62006608,
	CharName = "雪中猎人",
	Text = "狗子——！！（跟上）",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_29_XueZhongLieRen",
	NextID = 62006609,
}
StorySpeechConfig[StorySpeechID.Id62006609] =
{
	Id = 62006609,
	CharName = "蓝衣小学生",
	Text = "坏了！厨娘姐姐——！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006610,
}
StorySpeechConfig[StorySpeechID.Id62006610] =
{
	Id = 62006610,
	CharName = "旁白喇叭",
	Text = "猎犬跑几米就停下来，闻闻地上的味道，接着再向前。\n它绕着山脚跑了三圈，最终停在海拔20米的地方——那里伫立着一根铁栏杆。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	RightIcon = "EventItem_RPG_Event_8",
	NextID = 62006611,
}
StorySpeechConfig[StorySpeechID.Id62006611] =
{
	Id = 62006611,
	CharName = "雪中猎人",
	Text = "别、别跑了……跑、跑不动了。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_29_XueZhongLieRen",
	NextID = 62006612,
}
StorySpeechConfig[StorySpeechID.Id62006612] =
{
	Id = 62006612,
	CharName = "冰冰杆",
	Text = "（眨眼睛）嘿！你就是远方而来的英勇的雪·中·猎·人·吗？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "All_BingBingGang",
	NextID = 62006613,
}
StorySpeechConfig[StorySpeechID.Id62006613] =
{
	Id = 62006613,
	CharName = "雪中猎人",
	Text = "哈？（愣住）啊……是的。\n我就是英勇的雪中猎人。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_29_XueZhongLieRen",
	NextID = 62006614,
}
StorySpeechConfig[StorySpeechID.Id62006614] =
{
	Id = 62006614,
	CharName = "冰冰杆",
	Text = "到这里来真是辛苦了……\n（眨眼睛）你想不想，尝点甜头？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "All_BingBingGang",
	NextID = 62006615,
}
StorySpeechConfig[StorySpeechID.Id62006615] =
{
	Id = 62006615,
	CharName = "雪中猎人",
	Text = "甜头？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_29_XueZhongLieRen",
	NextID = 62006616,
}
StorySpeechConfig[StorySpeechID.Id62006616] =
{
	Id = 62006616,
	CharName = "冰冰杆",
	Text = "嗯~人家~是甜甜的雪·糕·味·哦~\n你一定听过很多谣言吧？别舔铁栏杆之类的。但我啊，真的是很好吃的天·然·冰·棍·哦！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "All_BingBingGang",
	NextID = 62006617,
}
StorySpeechConfig[StorySpeechID.Id62006617] =
{
	Id = 62006617,
	CharName = "冰冰杆",
	Text = "好不容易见到，一定要试一试哟~",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "All_BingBingGang",
	NextID = 62006618,
}
StorySpeechConfig[StorySpeechID.Id62006618] =
{
	Id = 62006618,
	CharName = "雪中猎人",
	Text = "嗯，也对，我就试试，嘿嘿……（凑上去）",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_29_XueZhongLieRen",
	NextID = 62006619,
}
StorySpeechConfig[StorySpeechID.Id62006619] =
{
	Id = 62006619,
	CharName = "旁白喇叭",
	Text = "猫眼厨娘带大家上山寻人，半小时后，大家终于在栏杆旁找到了他和猎犬，然而此人的舌头，早已结结实实地黏在冰冰杆上。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	RightIcon = "EventItem_RPG_Event_8",
}
StorySpeechConfig[StorySpeechID.Id62006651] =
{
	Id = 62006651,
	CharName = "健身教练",
	Text = "终于把他们俩分开了，儿子，好样的！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 62006652,
}
StorySpeechConfig[StorySpeechID.Id62006652] =
{
	Id = 62006652,
	CharName = "雪中猎人",
	Text = "（揪住健身教练）#%……！！*&*……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_29_XueZhongLieRen",
	NextID = 62006653,
}
StorySpeechConfig[StorySpeechID.Id62006653] =
{
	Id = 62006653,
	CharName = "健身教练",
	Text = "干嘛！我和儿子可是好心救了你啊。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 62006654,
}
StorySpeechConfig[StorySpeechID.Id62006654] =
{
	Id = 62006654,
	CharName = "雪中猎人",
	Text = "*&……#*ssf#$%^！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_29_XueZhongLieRen",
	NextID = 62006655,
}
StorySpeechConfig[StorySpeechID.Id62006655] =
{
	Id = 62006655,
	CharName = "健身教练",
	Text = "行了，我们又没带热水，这是救你的唯一方法。至于你的舌头……对不住了。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 62006656,
}
StorySpeechConfig[StorySpeechID.Id62006656] =
{
	Id = 62006656,
	CharName = "雪中猎人",
	Text = "！！！%#*&……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_29_XueZhongLieRen",
	NextID = 62006657,
}
StorySpeechConfig[StorySpeechID.Id62006657] =
{
	Id = 62006657,
	CharName = "教练的儿子",
	Text = "哈哈哈哈哈哈……嗝。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_boy1",
	NextID = 62006658,
}
StorySpeechConfig[StorySpeechID.Id62006658] =
{
	Id = 62006658,
	CharName = "健身教练",
	Text = "好了，孩子，不能笑……噗。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 62006659,
}
StorySpeechConfig[StorySpeechID.Id62006659] =
{
	Id = 62006659,
	CharName = "蓝衣小学生",
	Text = "（沉思）这件事是偶然吗？\n不对，实在是太蹊跷了……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006660,
}
StorySpeechConfig[StorySpeechID.Id62006660] =
{
	Id = 62006660,
	CharName = "蓝衣小学生",
	Text = "对了，那个地方！现在去还来得及！（跑）",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_20_lanyixiaoxuesheng",
}
StorySpeechConfig[StorySpeechID.Id62006701] =
{
	Id = 62006701,
	CharName = "旁白喇叭",
	Text = "蓝衣小学生跑去别墅旁的雪地上调查，发现了奇怪物品：狗粮和断裂的钓鱼线。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "EventItem_RPG_Event_8",
	NextID = 62006702,
}
StorySpeechConfig[StorySpeechID.Id62006702] =
{
	Id = 62006702,
	CharName = "蓝衣小学生",
	Text = "（闻狗粮）为什么这里会有这个东西呢……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006703,
}
StorySpeechConfig[StorySpeechID.Id62006703] =
{
	Id = 62006703,
	CharName = "蓝衣小学生",
	Text = "（脑中白光一闪）对了！原来是这样……\n我知道了，但是，为什么呢？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006704,
}
StorySpeechConfig[StorySpeechID.Id62006704] =
{
	Id = 62006704,
	CharName = "蓝衣小学生",
	Text = "（回想）……等等，如果是这样的话！\n一切都串联起来了！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006705,
}
StorySpeechConfig[StorySpeechID.Id62006705] =
{
	Id = 62006705,
	CharName = "蓝衣小学生",
	Text = "很好，现在只要有那个东西，就可以揭示出真相了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006706,
}
StorySpeechConfig[StorySpeechID.Id62006706] =
{
	Id = 62006706,
	CharName = "旁白喇叭",
	Text = "另一边——\n猫眼厨娘等人把雪中猎人扶回别墅，就当她要离开大厅时，健身教练忽然叫住了她。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "EventItem_RPG_Event_8",
	NextID = 62006707,
}
StorySpeechConfig[StorySpeechID.Id62006707] =
{
	Id = 62006707,
	CharName = "猫眼厨娘",
	Text = "怎么了，先生？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006708,
}
StorySpeechConfig[StorySpeechID.Id62006708] =
{
	Id = 62006708,
	CharName = "健身教练",
	Text = "我儿子似乎有些话想对你说啊——\n儿子，加油，说错了也没有关系，爸爸是你永远的后盾哦~",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 62006709,
}
StorySpeechConfig[StorySpeechID.Id62006709] =
{
	Id = 62006709,
	CharName = "教练的儿子",
	Text = "爸爸，过乃，爸爸——（耳语）",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_boy1",
	NextID = 62006710,
}
StorySpeechConfig[StorySpeechID.Id62006710] =
{
	Id = 62006710,
	CharName = "健身教练",
	Text = "咳咳，我儿子说——你！别墅老板！有非常大的嫌疑！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 62006711,
}
StorySpeechConfig[StorySpeechID.Id62006711] =
{
	Id = 62006711,
	CharName = "猫眼厨娘",
	Text = "哈？你说什么呢？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006712,
}
StorySpeechConfig[StorySpeechID.Id62006712] =
{
	Id = 62006712,
	CharName = "教练的儿子",
	Text = "爸爸——（耳语）",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_boy1",
	NextID = 62006713,
}
StorySpeechConfig[StorySpeechID.Id62006713] =
{
	Id = 62006713,
	CharName = "健身教练",
	Text = "哦哦，我懂了！\n结论先行，我们认为这次的两次旅客昏倒和猎人受伤事件，都是由你——猫眼厨娘，这座别墅的老板策划的！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 62006714,
}
StorySpeechConfig[StorySpeechID.Id62006714] =
{
	Id = 62006714,
	CharName = "猫眼厨娘",
	Text = "（惊）你不要空口无凭污人清白！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006715,
}
StorySpeechConfig[StorySpeechID.Id62006715] =
{
	Id = 62006715,
	CharName = "温泉鉴赏家",
	Text = "你们别血口喷人——",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_26_WenQuanJianShanJia",
	NextID = 62006716,
}
StorySpeechConfig[StorySpeechID.Id62006716] =
{
	Id = 62006716,
	CharName = "健身教练",
	Text = "哼哼，我们可是有证据的。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 62006717,
}
StorySpeechConfig[StorySpeechID.Id62006717] =
{
	Id = 62006717,
	CharName = "旁白喇叭",
	Text = "而山上，蓝衣小学生正在寻找线索。\n突然，他的身后，出现了一个身影……",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	RightIcon = "EventItem_RPG_Event_8",
}
StorySpeechConfig[StorySpeechID.Id62006751] =
{
	Id = 62006751,
	CharName = "思诺曼",
	Text = "你看起来那么小，为什么战斗力那么强！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_31_SiNuoMan",
	NextID = 62006752,
}
StorySpeechConfig[StorySpeechID.Id62006752] =
{
	Id = 62006752,
	CharName = "蓝衣小学生",
	Text = "是吗？我记得曾经有个冒险家，嘲笑我很弱……不过，能有这么大进步，都是科技的力量~",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006753,
}
StorySpeechConfig[StorySpeechID.Id62006753] =
{
	Id = 62006753,
	CharName = "蓝衣小学生",
	Text = "作为手下败家，可以回答我几个问题吗？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006754,
}
StorySpeechConfig[StorySpeechID.Id62006754] =
{
	Id = 62006754,
	CharName = "思诺曼",
	Text = "我知道你要问什么，我无可奉告，如果刚刚行动顺利的话，你现在已经昏倒在别墅门口了。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_31_SiNuoMan",
	NextID = 62006755,
}
StorySpeechConfig[StorySpeechID.Id62006755] =
{
	Id = 62006755,
	CharName = "蓝衣小学生",
	Text = "是吗？是她让你这么干的吧？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006756,
}
StorySpeechConfig[StorySpeechID.Id62006756] =
{
	Id = 62006756,
	CharName = "思诺曼",
	Text = "小厨娘才没指使我！（捂嘴）\n呜，果然被殴打之后，脑子也不清楚了。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_31_SiNuoMan",
	NextID = 62006757,
}
StorySpeechConfig[StorySpeechID.Id62006757] =
{
	Id = 62006757,
	CharName = "蓝衣小学生",
	Text = "钓鱼线在你身上吗？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006758,
}
StorySpeechConfig[StorySpeechID.Id62006758] =
{
	Id = 62006758,
	CharName = "思诺曼",
	Text = "不是在山脚垃圾桶吗？（捂嘴）\n呜！我什么都没说！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_31_SiNuoMan",
	NextID = 62006759,
}
StorySpeechConfig[StorySpeechID.Id62006759] =
{
	Id = 62006759,
	CharName = "蓝衣小学生",
	Text = "谢了，这样就省得我一个一个翻了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
}
StorySpeechConfig[StorySpeechID.Id62006801] =
{
	Id = 62006801,
	CharName = "健身教练",
	Text = "哼哼，我们可是有证据的。\n该从哪里开始说呢……对，先讲动机。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 62006802,
}
StorySpeechConfig[StorySpeechID.Id62006802] =
{
	Id = 62006802,
	CharName = "健身教练",
	Text = "你的行为，都是为了把这里打造成“易发生案件的网红别墅”——从而发展现在最为红火的“剧本杀”事业。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 62006803,
}
StorySpeechConfig[StorySpeechID.Id62006803] =
{
	Id = 62006803,
	CharName = "猫眼厨娘",
	Text = "？？？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006804,
}
StorySpeechConfig[StorySpeechID.Id62006804] =
{
	Id = 62006804,
	CharName = "教练的儿子",
	Text = "（……耳语）",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_boy1",
	NextID = 62006805,
}
StorySpeechConfig[StorySpeechID.Id62006805] =
{
	Id = 62006805,
	CharName = "健身教练",
	Text = "大家应该都还记得，那个被雪怪传说吓晕过去的姑娘吧？那时候她晕过去，是你把她送进了房间。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 62006806,
}
StorySpeechConfig[StorySpeechID.Id62006806] =
{
	Id = 62006806,
	CharName = "健身教练",
	Text = "也就是说，案发时候，你最可能在现场，你嫌疑最大！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 62006807,
}
StorySpeechConfig[StorySpeechID.Id62006807] =
{
	Id = 62006807,
	CharName = "健身教练",
	Text = "至于那个念诗的编剧……我想，你作为老板，私藏一把备用钥匙，也是非常合理的。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 62006808,
}
StorySpeechConfig[StorySpeechID.Id62006808] =
{
	Id = 62006808,
	CharName = "猫眼厨娘",
	Text = "……说来说去，到底只是猜测，证据呢？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006809,
}
StorySpeechConfig[StorySpeechID.Id62006809] =
{
	Id = 62006809,
	CharName = "健身教练",
	Text = "证据，我们当然有了，是吧儿子？（看）",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 62006810,
}
StorySpeechConfig[StorySpeechID.Id62006810] =
{
	Id = 62006810,
	CharName = "健身教练",
	Text = "没有？？你、这……\n可、可是我们只是一个小孩，童言无忌，能说出自己的想法就很好了！对吧，儿子？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 62006811,
}
StorySpeechConfig[StorySpeechID.Id62006811] =
{
	Id = 62006811,
	CharName = "猫眼厨娘",
	Text = "没证据就指控我，孩子不懂事，你也不懂事？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006812,
}
StorySpeechConfig[StorySpeechID.Id62006812] =
{
	Id = 62006812,
	CharName = "蓝衣小学生",
	Text = "（突然出现）不，我想他们的方向是对的。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006813,
}
StorySpeechConfig[StorySpeechID.Id62006813] =
{
	Id = 62006813,
	CharName = "蓝衣小学生",
	Text = "你没有直接袭击编剧姐姐，而是把镜子和反光的玻璃放在她窗前，伪装成白昼中的星光。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006814,
}
StorySpeechConfig[StorySpeechID.Id62006814] =
{
	Id = 62006814,
	CharName = "蓝衣小学生",
	Text = "（拿出证物袋）这是我在她房间里发现的。你很清楚，她是个能从星星上获取灵感的人，如果有星星，一定会去看个清楚。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006815,
}
StorySpeechConfig[StorySpeechID.Id62006815] =
{
	Id = 62006815,
	CharName = "蓝衣小学生",
	Text = "对了，还有这个——\n（拿出证物袋）",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006816,
}
StorySpeechConfig[StorySpeechID.Id62006816] =
{
	Id = 62006816,
	CharName = "健身教练",
	Text = "这是什么？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 62006817,
}
StorySpeechConfig[StorySpeechID.Id62006817] =
{
	Id = 62006817,
	CharName = "蓝衣小学生",
	Text = "钓鱼线和放了诱食剂的狗粮。\n厨娘姐姐，你就是用钓鱼线，把狗粮撒在雪地上，引诱猎犬跑到栏杆旁边的吧？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006818,
}
StorySpeechConfig[StorySpeechID.Id62006818] =
{
	Id = 62006818,
	CharName = "蓝衣小学生",
	Text = "至于决定性证据……就在你的身上！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006819,
}
StorySpeechConfig[StorySpeechID.Id62006819] =
{
	Id = 62006819,
	CharName = "猫眼厨娘",
	Text = "我的身上？小朋友，你很喜欢玩侦探游戏啊。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006820,
}
StorySpeechConfig[StorySpeechID.Id62006820] =
{
	Id = 62006820,
	CharName = "蓝衣小学生",
	Text = "这可不是游戏，好了，现在请你回答我——你既然没有养狗，为什么指甲缝里，会有狗粮的粉末呢？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006821,
}
StorySpeechConfig[StorySpeechID.Id62006821] =
{
	Id = 62006821,
	CharName = "猫眼厨娘",
	Text = "（惊）什么——！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006822,
}
StorySpeechConfig[StorySpeechID.Id62006822] =
{
	Id = 62006822,
	CharName = "健身教练",
	Text = "真的！她指甲里真的有！就是狗粮的味儿！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_27_JianShenJiaoLian",
}
StorySpeechConfig[StorySpeechID.Id62006851] =
{
	Id = 62006851,
	CharName = "猫眼厨娘",
	Text = "……你都知道了。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006852,
}
StorySpeechConfig[StorySpeechID.Id62006852] =
{
	Id = 62006852,
	CharName = "蓝衣小学生",
	Text = "嗯，算是吧。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006853,
}
StorySpeechConfig[StorySpeechID.Id62006853] =
{
	Id = 62006853,
	CharName = "猫眼厨娘",
	Text = "那你也见过他们了吧？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006854,
}
StorySpeechConfig[StorySpeechID.Id62006854] =
{
	Id = 62006854,
	CharName = "蓝衣小学生",
	Text = "嗯，思诺曼……他不是一个好队友。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006855,
}
StorySpeechConfig[StorySpeechID.Id62006855] =
{
	Id = 62006855,
	CharName = "猫眼厨娘",
	Text = "我承认。\n昨天，我把编剧妹子吸引出去，本想击昏她，没想到她一直在打呵欠，连打十个后就直接倒地睡觉了。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006856,
}
StorySpeechConfig[StorySpeechID.Id62006856] =
{
	Id = 62006856,
	CharName = "猫眼厨娘",
	Text = "猎犬的事也是我做的……但最初的案件与我无关，我不知道她为什么昏倒。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006857,
}
StorySpeechConfig[StorySpeechID.Id62006857] =
{
	Id = 62006857,
	CharName = "蓝衣小学生",
	Text = "是吗……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006858,
}
StorySpeechConfig[StorySpeechID.Id62006858] =
{
	Id = 62006858,
	CharName = "健身教练",
	Text = "别不承认了，你还想在我们之中，再制造什么恐慌吗？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 62006859,
}
StorySpeechConfig[StorySpeechID.Id62006859] =
{
	Id = 62006859,
	CharName = "温泉鉴赏家",
	Text = "但是，为什么啊？为什么你要这么做？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_26_WenQuanJianShanJia",
	NextID = 62006860,
}
StorySpeechConfig[StorySpeechID.Id62006860] =
{
	Id = 62006860,
	CharName = "蓝衣小学生",
	Text = "因为她不愿意让你们山上——对吧？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006861,
}
StorySpeechConfig[StorySpeechID.Id62006861] =
{
	Id = 62006861,
	CharName = "猫眼厨娘",
	Text = "够了，我的动机，你们不需要知道。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006862,
}
StorySpeechConfig[StorySpeechID.Id62006862] =
{
	Id = 62006862,
	CharName = "猫眼厨娘",
	Text = "（看向蓝衣小学生）有的秘密，只能作为秘密而存在。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_25_MaoYanChuNiang",
}
StorySpeechConfig[StorySpeechID.Id62006901] =
{
	Id = 62006901,
	CharName = "旁白喇叭",
	Text = "真相大白以后，大家心中的石头总算落地了，只有蓝衣小学生和温泉鉴赏家怏怏不乐。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "EventItem_RPG_Event_8",
	NextID = 62006902,
}
StorySpeechConfig[StorySpeechID.Id62006902] =
{
	Id = 62006902,
	CharName = "旁白喇叭",
	Text = "编剧妹子悠悠转醒，雪中猎人虽仍无法开口，但心情和身体逐渐好了起来——也算是好事一件。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "EventItem_RPG_Event_8",
	NextID = 62006903,
}
StorySpeechConfig[StorySpeechID.Id62006903] =
{
	Id = 62006903,
	CharName = "编剧妹子",
	Text = "虽然睡醒了，但还是好困——\n说来，她为什么不让我们上山？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_30_BianJuMeiZi",
	NextID = 62006904,
}
StorySpeechConfig[StorySpeechID.Id62006904] =
{
	Id = 62006904,
	CharName = "教练的儿子",
	Text = "爸爸，玩、陪我玩——\n（拉住蓝衣小学生）哥哥，秘密？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_boy1",
	NextID = 62006905,
}
StorySpeechConfig[StorySpeechID.Id62006905] =
{
	Id = 62006905,
	CharName = "蓝衣小学生",
	Text = "不，其实我不确定，山上到底有什么。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006906,
}
StorySpeechConfig[StorySpeechID.Id62006906] =
{
	Id = 62006906,
	CharName = "健身教练",
	Text = "那我们就上去看看，山上到底有什么呗？\n对吧，儿子。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 62006907,
}
StorySpeechConfig[StorySpeechID.Id62006907] =
{
	Id = 62006907,
	CharName = "教练的儿子",
	Text = "爸爸——比赛！1，2，3，跑！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_boy1",
	NextID = 62006908,
}
StorySpeechConfig[StorySpeechID.Id62006908] =
{
	Id = 62006908,
	CharName = "蓝衣小学生",
	Text = "不，我认为我们还是在这里等——\n喂，你们回来啊！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006909,
}
StorySpeechConfig[StorySpeechID.Id62006909] =
{
	Id = 62006909,
	CharName = "旁白喇叭",
	Text = "健身教练和他的儿子向雪山奔跑，雪中猎人和他的狗子紧随其后。猫眼厨娘被关在厨房里，温泉鉴赏家作为监督者在一旁看管。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	RightIcon = "EventItem_RPG_Event_8",
	NextID = 62006910,
}
StorySpeechConfig[StorySpeechID.Id62006910] =
{
	Id = 62006910,
	CharName = "温泉鉴赏家",
	Text = "我还是不理解，你的底层逻辑是什么。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_26_WenQuanJianShanJia",
	NextID = 62006911,
}
StorySpeechConfig[StorySpeechID.Id62006911] =
{
	Id = 62006911,
	CharName = "猫眼厨娘",
	Text = "说人话。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006912,
}
StorySpeechConfig[StorySpeechID.Id62006912] =
{
	Id = 62006912,
	CharName = "温泉鉴赏家",
	Text = "（看向窗外）雪小了，真好啊，大家上山玩雪，我也想去滑雪、堆雪人、打雪仗。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_26_WenQuanJianShanJia",
	NextID = 62006913,
}
StorySpeechConfig[StorySpeechID.Id62006913] =
{
	Id = 62006913,
	CharName = "猫眼厨娘",
	Text = "你说什么？他们上去了？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006914,
}
StorySpeechConfig[StorySpeechID.Id62006914] =
{
	Id = 62006914,
	CharName = "温泉鉴赏家",
	Text = "嗯，怎么——呃！（被击昏）",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_26_WenQuanJianShanJia",
	NextID = 62006915,
}
StorySpeechConfig[StorySpeechID.Id62006915] =
{
	Id = 62006915,
	CharName = "猫眼厨娘",
	Text = "不好了，希望还来得及！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006916,
}
StorySpeechConfig[StorySpeechID.Id62006916] =
{
	Id = 62006916,
	CharName = "旁白喇叭",
	Text = "往雪山上奔跑的众人带着笑容，肆意捧起雪花再砸下，对即将到来的危险浑然不觉——忽然，一个白色的影子闪过。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "EventItem_RPG_Event_8",
	NextID = 62006917,
}
StorySpeechConfig[StorySpeechID.Id62006917] =
{
	Id = 62006917,
	CharName = "蓝衣小学生",
	Text = "谁？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006918,
}
StorySpeechConfig[StorySpeechID.Id62006918] =
{
	Id = 62006918,
	CharName = "雪神",
	Text = "（暴怒）呜啦啦啦，我要吃人……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_24_XueShen",
	NextID = 62006919,
}
StorySpeechConfig[StorySpeechID.Id62006919] =
{
	Id = 62006919,
	CharName = "蓝衣小学生",
	Text = "不好！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006920,
}
StorySpeechConfig[StorySpeechID.Id62006920] =
{
	Id = 62006920,
	CharName = "健身教练",
	Text = "儿子！！雪怪的传说是真的！！救命！！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 62006921,
}
StorySpeechConfig[StorySpeechID.Id62006921] =
{
	Id = 62006921,
	CharName = "雪神",
	Text = "一个都——跑不了——",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_24_XueShen",
	NextID = 62006922,
}
StorySpeechConfig[StorySpeechID.Id62006922] =
{
	Id = 62006922,
	CharName = "猫眼厨娘",
	Text = "（急忙赶到）等等，不要——！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
}
StorySpeechConfig[StorySpeechID.Id62006951] =
{
	Id = 62006951,
	CharName = "猫眼厨娘",
	Text = "呼、呼——还好赶到了。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006952,
}
StorySpeechConfig[StorySpeechID.Id62006952] =
{
	Id = 62006952,
	CharName = "雪神",
	Text = "你、你为什么帮他们打我，呜呜呜。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_24_XueShen",
	NextID = 62006953,
}
StorySpeechConfig[StorySpeechID.Id62006953] =
{
	Id = 62006953,
	CharName = "猫眼厨娘",
	Text = "我想告诉你，他们没有恶意。\n他们中有的人，虽然看上去蠢蠢的，也不像什么好人……但他们不会做出伤害你的事。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006954,
}
StorySpeechConfig[StorySpeechID.Id62006954] =
{
	Id = 62006954,
	CharName = "雪神",
	Text = "可是，有人带着武器……（盯）",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_24_XueShen",
	NextID = 62006955,
}
StorySpeechConfig[StorySpeechID.Id62006955] =
{
	Id = 62006955,
	CharName = "雪中猎人",
	Text = "？？？（扔掉猎枪）",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_29_XueZhongLieRen",
	NextID = 62006956,
}
StorySpeechConfig[StorySpeechID.Id62006956] =
{
	Id = 62006956,
	CharName = "蓝衣小学生",
	Text = "所以……这就是你不让我们山上的理由？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006957,
}
StorySpeechConfig[StorySpeechID.Id62006957] =
{
	Id = 62006957,
	CharName = "猫眼厨娘",
	Text = "嗯，但现在，告诉你们真相也没有关系了……\n她是这座山上的雪神，你们嬉戏玩乐的地方，是她的家。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006958,
}
StorySpeechConfig[StorySpeechID.Id62006958] =
{
	Id = 62006958,
	CharName = "雪神",
	Text = "没人喜欢别人在自己家里乱跑——就是这个意思。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_24_XueShen",
	NextID = 62006959,
}
StorySpeechConfig[StorySpeechID.Id62006959] =
{
	Id = 62006959,
	CharName = "猫眼厨娘",
	Text = "我曾经闯入这里，打扰了她的生活。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006960,
}
StorySpeechConfig[StorySpeechID.Id62006960] =
{
	Id = 62006960,
	CharName = "雪神",
	Text = "虽然我们后来成为了朋友，但最初的相遇不是很愉快——就是这个意思。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_24_XueShen",
	NextID = 62006961,
}
StorySpeechConfig[StorySpeechID.Id62006961] =
{
	Id = 62006961,
	CharName = "猫眼厨娘",
	Text = "接着我们做出了一个约定，我会帮助她，阻止那些上山玩耍的无礼的人。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006962,
}
StorySpeechConfig[StorySpeechID.Id62006962] =
{
	Id = 62006962,
	CharName = "蓝衣小学生",
	Text = "所以你们编造出了雪怪吃人的传说。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62006963,
}
StorySpeechConfig[StorySpeechID.Id62006963] =
{
	Id = 62006963,
	CharName = "猫眼厨娘",
	Text = "那些传说自古就有，我们只是添油加醋地传播了一下，但是……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006964,
}
StorySpeechConfig[StorySpeechID.Id62006964] =
{
	Id = 62006964,
	CharName = "猫眼厨娘",
	Text = "（看向雪神）我一直想说，你可以试着和人类好好相处~雪山上的日子清净自在，但人间烟火不也很好吗？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 62006965,
}
StorySpeechConfig[StorySpeechID.Id62006965] =
{
	Id = 62006965,
	CharName = "编剧妹子",
	Text = "我赞同！我超级超级想听你讲雪山上的故事。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_30_BianJuMeiZi",
	NextID = 62006966,
}
StorySpeechConfig[StorySpeechID.Id62006966] =
{
	Id = 62006966,
	CharName = "雪神",
	Text = "我不，唔，别拽我——",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_24_XueShen",
}
StorySpeechConfig[StorySpeechID.Id62007001] =
{
	Id = 62007001,
	CharName = "蓝衣小学生",
	Text = "这样一切就都结束了……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62007002,
}
StorySpeechConfig[StorySpeechID.Id62007002] =
{
	Id = 62007002,
	CharName = "蓝衣小学生",
	Text = "吗？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62007003,
}
StorySpeechConfig[StorySpeechID.Id62007003] =
{
	Id = 62007003,
	CharName = "蓝衣小学生",
	Text = "感觉还是有哪里没对，受害者的晕倒，到底是怎么回事？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62007004,
}
StorySpeechConfig[StorySpeechID.Id62007004] =
{
	Id = 62007004,
	CharName = "蓝衣小学生",
	Text = "既不是雪神，也不是厨娘……等等！那个房间里的烟灰！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62007005,
}
StorySpeechConfig[StorySpeechID.Id62007005] =
{
	Id = 62007005,
	CharName = "蓝衣小学生",
	Text = "喂喂，不会真的是这样吧……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62007006,
}
StorySpeechConfig[StorySpeechID.Id62007006] =
{
	Id = 62007006,
	CharName = "旁白喇叭",
	Text = "当夜，蓝衣小学生偷偷潜伏在受害者的房间。突然房门打开，一个黑影走了进来，在地上似乎寻找着什么东西。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	RightIcon = "EventItem_RPG_Event_8",
	NextID = 62007007,
}
StorySpeechConfig[StorySpeechID.Id62007007] =
{
	Id = 62007007,
	CharName = "蓝衣小学生",
	Text = "（开灯）可算把你抓住了——这次最初的案件，就是你犯下的吧？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62007008,
}
StorySpeechConfig[StorySpeechID.Id62007008] =
{
	Id = 62007008,
	CharName = "蓝衣小学生",
	Text = "大侦探先生。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62007009,
}
StorySpeechConfig[StorySpeechID.Id62007009] =
{
	Id = 62007009,
	CharName = "大侦探",
	Text = "哎呀，我怎么走到这里来了呀？\n你好，这里是悬疑星吗？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_01_fuermosi",
	NextID = 62007010,
}
StorySpeechConfig[StorySpeechID.Id62007010] =
{
	Id = 62007010,
	CharName = "蓝衣小学生",
	Text = "装傻对我是没用的！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62007011,
}
StorySpeechConfig[StorySpeechID.Id62007011] =
{
	Id = 62007011,
	CharName = "大侦探",
	Text = "哎呀，这不是蓝衣小学生吗？你度假回来了？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_01_fuermosi",
	NextID = 62007012,
}
StorySpeechConfig[StorySpeechID.Id62007012] =
{
	Id = 62007012,
	CharName = "蓝衣小学生",
	Text = "别装了，你还是——呃！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62007013,
}
StorySpeechConfig[StorySpeechID.Id62007013] =
{
	Id = 62007013,
	CharName = "大侦探",
	Text = "哈哈，枕头攻击！我先走了，有缘再会！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_01_fuermosi",
	NextID = 62007014,
}
StorySpeechConfig[StorySpeechID.Id62007014] =
{
	Id = 62007014,
	CharName = "蓝衣小学生",
	Text = "（扔出枕头）别想跑！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_20_lanyixiaoxuesheng",
}
StorySpeechConfig[StorySpeechID.Id62007051] =
{
	Id = 62007051,
	CharName = "大侦探",
	Text = "可恶，我在枕头大战里竟然输了！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_01_fuermosi",
	NextID = 62007052,
}
StorySpeechConfig[StorySpeechID.Id62007052] =
{
	Id = 62007052,
	CharName = "蓝衣小学生",
	Text = "谁要和你玩那种无聊的游戏啊！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62007053,
}
StorySpeechConfig[StorySpeechID.Id62007053] =
{
	Id = 62007053,
	CharName = "大侦探",
	Text = "说真的，你怎么猜到是我的？就凭那些烟灰？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_01_fuermosi",
	NextID = 62007054,
}
StorySpeechConfig[StorySpeechID.Id62007054] =
{
	Id = 62007054,
	CharName = "蓝衣小学生",
	Text = "首先是烟灰，那是你会喜欢的雪茄的烟灰，没错吧？\n其次是药剂包。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62007055,
}
StorySpeechConfig[StorySpeechID.Id62007055] =
{
	Id = 62007055,
	CharName = "大侦探",
	Text = "药剂包？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_01_fuermosi",
	NextID = 62007056,
}
StorySpeechConfig[StorySpeechID.Id62007056] =
{
	Id = 62007056,
	CharName = "蓝衣小学生",
	Text = "嗯，我一直在想，谁闲着没事偷药剂包呢？药剂包不在水里，它能发挥什么作用？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62007057,
}
StorySpeechConfig[StorySpeechID.Id62007057] =
{
	Id = 62007057,
	CharName = "蓝衣小学生",
	Text = "后来我想明白了，它方方正正的，而且足够软，用来做枕头的替代品再合适不过了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62007058,
}
StorySpeechConfig[StorySpeechID.Id62007058] =
{
	Id = 62007058,
	CharName = "蓝衣小学生",
	Text = "而这个世界上，只有你，会痴迷枕头大战这种无聊的游戏。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62007059,
}
StorySpeechConfig[StorySpeechID.Id62007059] =
{
	Id = 62007059,
	CharName = "大侦探",
	Text = "好了好了，真是败给你了……其实啊，是我的委托人放我鸽子了，我闲着没事干，就打算过来玩玩。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_01_fuermosi",
	NextID = 62007060,
}
StorySpeechConfig[StorySpeechID.Id62007060] =
{
	Id = 62007060,
	CharName = "大侦探",
	Text = "谁知道我一刚过来就到一个方方正正的药包，身体里体内的枕头之魂，就觉醒了！！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_01_fuermosi",
	NextID = 62007061,
}
StorySpeechConfig[StorySpeechID.Id62007061] =
{
	Id = 62007061,
	CharName = "大侦探",
	Text = "于是我拿走了它，拉受害者一起玩，我们一起玩到天亮，我几乎是以压倒性的，399比0的优势战胜了她！可是，谁知道——",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_01_fuermosi",
	NextID = 62007062,
}
StorySpeechConfig[StorySpeechID.Id62007062] =
{
	Id = 62007062,
	CharName = "大侦探",
	Text = "当我马上就要得到400分的时候，她说她困了，然后就把我赶走了！真是岂有此理！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_01_fuermosi",
	NextID = 62007063,
}
StorySpeechConfig[StorySpeechID.Id62007063] =
{
	Id = 62007063,
	CharName = "蓝衣小学生",
	Text = "所以你就袭击了她？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62007064,
}
StorySpeechConfig[StorySpeechID.Id62007064] =
{
	Id = 62007064,
	CharName = "大侦探",
	Text = "当然没有！我很绅士地离开了房间。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_01_fuermosi",
	NextID = 62007065,
}
StorySpeechConfig[StorySpeechID.Id62007065] =
{
	Id = 62007065,
	CharName = "蓝衣小学生",
	Text = "也就是说，她因为困了，想去床上睡觉，然而没来得及上床……就在地上睡着了？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 62007066,
}
StorySpeechConfig[StorySpeechID.Id62007066] =
{
	Id = 62007066,
	CharName = "大侦探",
	Text = "没错，看来就是这样。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_01_fuermosi",
	NextID = 62007067,
}
StorySpeechConfig[StorySpeechID.Id62007067] =
{
	Id = 62007067,
	CharName = "蓝衣小学生",
	Text = "看来她又在身体力行地告诉我们——\n“不要熬夜”这个真理啊。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_20_lanyixiaoxuesheng",
}
