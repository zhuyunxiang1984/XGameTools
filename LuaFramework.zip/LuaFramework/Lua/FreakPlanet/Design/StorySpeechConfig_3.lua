
StorySpeechConfig[StorySpeechID.Id14400101] =
{
	Id = 14400101,
	CharName = "探险家成员",
	Text = "这里是探险家协会，你是打算报名参加吗？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "All_daguanjia",
	NextID = 14400102,
}
StorySpeechConfig[StorySpeechID.Id14400102] =
{
	Id = 14400102,
	CharName = "呜呜",
	Text = "是的喵~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_wuwu",
	NextID = 14400103,
}
StorySpeechConfig[StorySpeechID.Id14400103] =
{
	Id = 14400103,
	CharName = "探险家成员",
	Text = "噢，是个小橘猫啊，你如果愿意当吉祥物的话，我就直接算你过啦~",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "All_daguanjia",
	NextID = 14400104,
}
StorySpeechConfig[StorySpeechID.Id14400104] =
{
	Id = 14400104,
	CharName = "呜呜",
	Text = "好喵~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_wuwu",
	NextID = 14400105,
}
StorySpeechConfig[StorySpeechID.Id14400105] =
{
	Id = 14400105,
	CharName = "探险家成员",
	Text = "没有志气！刚刚的要求纯属考验！你要是不打赢来自冒险星的魔物，就回去吧！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "All_daguanjia",
	NextID = 14400106,
}
StorySpeechConfig[StorySpeechID.Id14400106] =
{
	Id = 14400106,
	CharName = "呜呜",
	Text = "喵……那我可以和朋友一起打吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_wuwu",
	NextID = 14400107,
}
StorySpeechConfig[StorySpeechID.Id14400107] =
{
	Id = 14400107,
	CharName = "探险家成员",
	Text = "最多2人，你别想偷偷带一堆人进去！我会盯住你的！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "All_daguanjia",
}
StorySpeechConfig[StorySpeechID.Id14422901] =
{
	Id = 14422901,
	CharName = "史莱姆大王",
	Text = "（盯）……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_01_SlimeKing",
	NextID = 14422902,
}
StorySpeechConfig[StorySpeechID.Id14422902] =
{
	Id = 14422902,
	CharName = "呜呜",
	Text = "喵？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_wuwu",
	NextID = 14422903,
}
StorySpeechConfig[StorySpeechID.Id14422903] =
{
	Id = 14422903,
	CharName = "史莱姆大王",
	Text = "喂，你这只橘色的猫，手里拿着的是我的救生圈吧？ ",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_01_SlimeKing",
	NextID = 14422904,
}
StorySpeechConfig[StorySpeechID.Id14422904] =
{
	Id = 14422904,
	CharName = "呜呜",
	Text = "不对不对，是呜呜的礼物喵~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_wuwu",
	NextID = 14422905,
}
StorySpeechConfig[StorySpeechID.Id14422905] =
{
	Id = 14422905,
	CharName = "史莱姆大王",
	Text = "胡说，这是我在冒险星定制的夏日特别鸭头救生圈，这么大的鸭头，你骗不了我。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_01_SlimeKing",
	NextID = 14422906,
}
StorySpeechConfig[StorySpeechID.Id14422906] =
{
	Id = 14422906,
	CharName = "呜呜",
	Text = "真的是呜呜的喵，不要抢呜呜的礼物……呜呜有枪的喵！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_wuwu",
	NextID = 14422907,
}
StorySpeechConfig[StorySpeechID.Id14422907] =
{
	Id = 14422907,
	CharName = "史莱姆大王",
	Text = "哼哼，别以为我会怕你！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_01_SlimeKing",
	NextID = 14422908,
}
StorySpeechConfig[StorySpeechID.Id14422908] =
{
	Id = 14422908,
	CharName = "呜呜",
	Text = "（噗呲——）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_wuwu",
	NextID = 14422909,
}
StorySpeechConfig[StorySpeechID.Id14422909] =
{
	Id = 14422909,
	CharName = "史莱姆大王",
	Text = "你竟然拿水枪喷我！看来不给你点颜色瞧瞧，你是不知道我史莱姆大王的厉害！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_01_SlimeKing",
}
StorySpeechConfig[StorySpeechID.Id14400201] =
{
	Id = 14400201,
	CharName = "探险家成员",
	Text = "这里是探险家协会，你是打算报名参加吗？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "All_daguanjia",
	NextID = 14400202,
}
StorySpeechConfig[StorySpeechID.Id14400202] =
{
	Id = 14400202,
	CharName = "漆漆",
	Text = "喵！（点头）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_gugu",
	NextID = 14400203,
}
StorySpeechConfig[StorySpeechID.Id14400203] =
{
	Id = 14400203,
	CharName = "探险家成员",
	Text = "嗯，非常有勇气的样子，你如果愿意当吉祥物的话，我就直接算你过啦~",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "All_daguanjia",
	NextID = 14400204,
}
StorySpeechConfig[StorySpeechID.Id14400204] =
{
	Id = 14400204,
	CharName = "漆漆",
	Text = "喵！（摇头拒绝）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_gugu",
	NextID = 14400205,
}
StorySpeechConfig[StorySpeechID.Id14400205] =
{
	Id = 14400205,
	CharName = "探险家成员",
	Text = "非常好！有这样的志气，可以直接成为冒险家协会成员！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "All_daguanjia",
	NextID = 14400206,
}
StorySpeechConfig[StorySpeechID.Id14400206] =
{
	Id = 14400206,
	CharName = "漆漆",
	Text = "喵！一定要打！白送不要！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_gugu",
	NextID = 14400207,
}
StorySpeechConfig[StorySpeechID.Id14400207] =
{
	Id = 14400207,
	CharName = "探险家成员",
	Text = "那，那，那就随便打一场吧~我们很希望你能够加入呢~",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "All_daguanjia",
	NextID = 14400208,
}
StorySpeechConfig[StorySpeechID.Id14400208] =
{
	Id = 14400208,
	CharName = "漆漆",
	Text = "喵！（指向最高档难度）打那个！就我和呜呜！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_gugu",
	NextID = 14400209,
}
StorySpeechConfig[StorySpeechID.Id14400209] =
{
	Id = 14400209,
	CharName = "呜呜",
	Text = "喵！（想逃的时候被漆漆抓住了脖子后面的毛）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
}
StorySpeechConfig[StorySpeechID.Id14423001] =
{
	Id = 14423001,
	CharName = "呜呜",
	Text = "漆漆，下来喵。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 14423002,
}
StorySpeechConfig[StorySpeechID.Id14423002] =
{
	Id = 14423002,
	CharName = "漆漆",
	Text = "（哆嗦）@#￥%…了喵——",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_gugu",
	NextID = 14423003,
}
StorySpeechConfig[StorySpeechID.Id14423003] =
{
	Id = 14423003,
	CharName = "呜呜",
	Text = "喵？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 14423004,
}
StorySpeechConfig[StorySpeechID.Id14423004] =
{
	Id = 14423004,
	CharName = "漆漆",
	Text = "（哆嗦）#￥%…冷，喵——",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_gugu",
	NextID = 14423005,
}
StorySpeechConfig[StorySpeechID.Id14423005] =
{
	Id = 14423005,
	CharName = "呜呜",
	Text = "漆漆，做一下热身运动，下水就不冷了喵。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
	NextID = 14423006,
}
StorySpeechConfig[StorySpeechID.Id14423006] =
{
	Id = 14423006,
	CharName = "漆漆",
	Text = "运动……喵？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_gugu",
	NextID = 14423007,
}
StorySpeechConfig[StorySpeechID.Id14423007] =
{
	Id = 14423007,
	CharName = "水精灵",
	Text = "（这只猫咪好胆小啊…我来教育他一下！）砰——！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_Undine",
	NextID = 14423008,
}
StorySpeechConfig[StorySpeechID.Id14423008] =
{
	Id = 14423008,
	CharName = "漆漆",
	Text = "（抹脸）干什么喵？你怎么把我撞下水喵？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_gugu",
	NextID = 14423009,
}
StorySpeechConfig[StorySpeechID.Id14423009] =
{
	Id = 14423009,
	CharName = "呜呜",
	Text = "漆漆，快运动！打他喵！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "All_wuwu",
}
StorySpeechConfig[StorySpeechID.Id14400301] =
{
	Id = 14400301,
	CharName = "大魔王",
	Text = "亲爱的公主，又到了分别的时候。小绿帽剑士马上就要来了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_11_damowang",
	NextID = 14400302,
}
StorySpeechConfig[StorySpeechID.Id14400302] =
{
	Id = 14400302,
	CharName = "公主",
	Text = "魔王大人，不要说出如此伤心的话，请让我再逗留一会儿。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_18_zhenzhuerhuan",
	NextID = 14400303,
}
StorySpeechConfig[StorySpeechID.Id14400303] =
{
	Id = 14400303,
	CharName = "戴绿帽的剑士",
	Text = "公主！你在哪里！我来救您了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi_cos10",
	NextID = 14400304,
}
StorySpeechConfig[StorySpeechID.Id14400304] =
{
	Id = 14400304,
	CharName = "公主",
	Text = "（脸上露出了嫌弃的神情）噢，大人，为了满足勇者们的尊严，我要回去了。不过请您尽快再来带走我。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_18_zhenzhuerhuan",
	NextID = 14400305,
}
StorySpeechConfig[StorySpeechID.Id14400305] =
{
	Id = 14400305,
	CharName = "大魔王",
	Text = "请相信我，亲爱的公主。后天，后天我会再来找您的。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_11_damowang",
	NextID = 14400306,
}
StorySpeechConfig[StorySpeechID.Id14400306] =
{
	Id = 14400306,
	CharName = "公主",
	Text = "那么，我在花园的凉亭里等您，请给我一个告别之吻。（魔王与公主深情拥吻）",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_18_zhenzhuerhuan",
	NextID = 14400307,
}
StorySpeechConfig[StorySpeechID.Id14400307] =
{
	Id = 14400307,
	CharName = "戴绿帽的剑士",
	Text = "公主，我听到您的声音了，我立刻过来，请等我。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi_cos10",
	NextID = 14400308,
}
StorySpeechConfig[StorySpeechID.Id14400308] =
{
	Id = 14400308,
	CharName = "公主",
	Text = "（楚楚可怜地看着魔王）别了，大人。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_18_zhenzhuerhuan",
	NextID = 14400309,
}
StorySpeechConfig[StorySpeechID.Id14400309] =
{
	Id = 14400309,
	CharName = "大魔王",
	Text = "别了，公主。（两人不舍地抱在一块儿）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_11_damowang",
	NextID = 14400310,
}
StorySpeechConfig[StorySpeechID.Id14400310] =
{
	Id = 14400310,
	CharName = "戴绿帽的剑士",
	Text = "接招吧，魔王！！！（一脚踢开门后，看着眼前的景象，手中长剑掉落在地）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi_cos10",
	NextID = 14400311,
}
StorySpeechConfig[StorySpeechID.Id14400311] =
{
	Id = 14400311,
	CharName = "公主",
	Text = "啊！勇者，你这次怎么这么快！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_18_zhenzhuerhuan",
	NextID = 14400312,
}
StorySpeechConfig[StorySpeechID.Id14400312] =
{
	Id = 14400312,
	CharName = "剑士",
	Text = "诶，勇敢的小绿侠，你是来拯救公主的吗？你怎么了？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 14400313,
}
StorySpeechConfig[StorySpeechID.Id14400313] =
{
	Id = 14400313,
	CharName = "戴绿帽的剑士",
	Text = "没事，只不过……嗯，我没事。（哽咽着丢下了头上的小绿帽）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi_cos10",
	NextID = 14400314,
}
StorySpeechConfig[StorySpeechID.Id14400314] =
{
	Id = 14400314,
	CharName = "剑士",
	Text = "诶？这顶帽子你不要了吗？那就由我来打败魔王，继承你的帽子吧！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
}
StorySpeechConfig[StorySpeechID.Id14400401] =
{
	Id = 14400401,
	CharName = "神射手",
	Text = "又到了一年一度的神射手考试时间，那么大家都准备好了吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_24_gongjianshou_cos10",
	NextID = 14400402,
}
StorySpeechConfig[StorySpeechID.Id14400402] =
{
	Id = 14400402,
	CharName = "火枪手",
	Text = "yes！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_26_huoqiangshou",
	NextID = 14400403,
}
StorySpeechConfig[StorySpeechID.Id14400403] =
{
	Id = 14400403,
	CharName = "猎人",
	Text = "有！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_16_lieren",
	NextID = 14400404,
}
StorySpeechConfig[StorySpeechID.Id14400404] =
{
	Id = 14400404,
	CharName = "弓箭手",
	Text = "好了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_24_gongjianshou",
	NextID = 14400405,
}
StorySpeechConfig[StorySpeechID.Id14400405] =
{
	Id = 14400405,
	CharName = "神射手",
	Text = "那么，今年的考题是命中闪避率90%的苹果~祝大家考试顺利噢~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_24_gongjianshou_cos10",
	NextID = 14400406,
}
StorySpeechConfig[StorySpeechID.Id14400406] =
{
	Id = 14400406,
	CharName = "火枪手",
	Text = "老师，我申请换题，我哥哥考试完回家看到苹果就吐了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_26_huoqiangshou",
	NextID = 14400407,
}
StorySpeechConfig[StorySpeechID.Id14400407] =
{
	Id = 14400407,
	CharName = "神射手",
	Text = "驳回！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_24_gongjianshou_cos10",
	NextID = 14400408,
}
StorySpeechConfig[StorySpeechID.Id14400408] =
{
	Id = 14400408,
	CharName = "猎人",
	Text = "老师，我妈妈让我把这个野兔送给你让你尝尝鲜~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_16_lieren",
	NextID = 14400409,
}
StorySpeechConfig[StorySpeechID.Id14400409] =
{
	Id = 14400409,
	CharName = "神射手",
	Text = "老师不吃小动物，你认真考试。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_24_gongjianshou_cos10",
	NextID = 14400410,
}
StorySpeechConfig[StorySpeechID.Id14400410] =
{
	Id = 14400410,
	CharName = "弓箭手",
	Text = "老师……我申请近战。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_24_gongjianshou",
	NextID = 14400411,
}
StorySpeechConfig[StorySpeechID.Id14400411] =
{
	Id = 14400411,
	CharName = "神射手",
	Text = "那可以，你尽管试试吧~通过后你就是神射手咯~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_24_gongjianshou_cos10",
}
StorySpeechConfig[StorySpeechID.Id14400501] =
{
	Id = 14400501,
	CharName = "猎魔人",
	Text = "要感知这个恶魔的位置，必须凝神前行。鹿角魔，你逃不掉了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_16_lieren_cos10",
	NextID = 14400502,
}
StorySpeechConfig[StorySpeechID.Id14400502] =
{
	Id = 14400502,
	CharName = "猎魔人",
	Text = "要屏蔽自己的听觉，屏蔽自己的嗅觉，屏蔽自己的视觉，闭上双眼。喔唷！谁在这里放了个陷阱！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_16_lieren_cos10",
	NextID = 14400503,
}
StorySpeechConfig[StorySpeechID.Id14400503] =
{
	Id = 14400503,
	CharName = "猎人",
	Text = "哇，有猎物了~（开心地从草丛后面奔出来）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_16_lieren",
	NextID = 14400504,
}
StorySpeechConfig[StorySpeechID.Id14400504] =
{
	Id = 14400504,
	CharName = "猎魔人",
	Text = "喂！这个陷阱是你放的吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_16_lieren_cos10",
	NextID = 14400505,
}
StorySpeechConfig[StorySpeechID.Id14400505] =
{
	Id = 14400505,
	CharName = "猎人",
	Text = "（怯生生地）嗯……不过我是想抓野狼的。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_16_lieren",
	NextID = 14400506,
}
StorySpeechConfig[StorySpeechID.Id14400506] =
{
	Id = 14400506,
	CharName = "猎魔人",
	Text = "你闯祸了，如果我不能及时阻止鹿角魔，它会摧毁这个星球的。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_16_lieren_cos10",
	NextID = 14400507,
}
StorySpeechConfig[StorySpeechID.Id14400507] =
{
	Id = 14400507,
	CharName = "猎人",
	Text = "吓！这么严重，那该怎么办？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_16_lieren",
	NextID = 14400508,
}
StorySpeechConfig[StorySpeechID.Id14400508] =
{
	Id = 14400508,
	CharName = "猎魔人",
	Text = "把你的手给我，让我看看我们的未来。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_16_lieren_cos10",
	NextID = 14400509,
}
StorySpeechConfig[StorySpeechID.Id14400509] =
{
	Id = 14400509,
	CharName = "猎人",
	Text = "给。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_16_lieren",
	NextID = 14400510,
}
StorySpeechConfig[StorySpeechID.Id14400510] =
{
	Id = 14400510,
	CharName = "猎魔人",
	Text = "看来我们的命运已经纠缠在一起了，这是不可抗拒的因果律，如今我的使命已经变成你的使命。打败鹿角魔，成为我们的一员。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_16_lieren_cos10",
	NextID = 14400511,
}
StorySpeechConfig[StorySpeechID.Id14400511] =
{
	Id = 14400511,
	CharName = "猎人",
	Text = "吓！这么突……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_16_lieren",
	NextID = 14400512,
}
StorySpeechConfig[StorySpeechID.Id14400512] =
{
	Id = 14400512,
	CharName = "猎魔人",
	Text = "来不及解释了！快去！你在等什么？难道要先来局昆特牌吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_16_lieren_cos10",
}
StorySpeechConfig[StorySpeechID.Id14400701] =
{
	Id = 14400701,
	CharName = "指路NPC",
	Text = "从这里走，就可以省掉2/3的路程了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_10_buluolaoda",
	NextID = 14400702,
}
StorySpeechConfig[StorySpeechID.Id14400702] =
{
	Id = 14400702,
	CharName = "带路NPC",
	Text = "胡说！明明只省掉63%的路程，你太不严谨了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_10_buluolaoda_cos10",
	NextID = 14400703,
}
StorySpeechConfig[StorySpeechID.Id14400703] =
{
	Id = 14400703,
	CharName = "指路NPC",
	Text = "你只计算了路程，但是没有计算体能的损耗率。这条路上有5%的区域没有铺路。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_10_buluolaoda",
	NextID = 14400704,
}
StorySpeechConfig[StorySpeechID.Id14400704] =
{
	Id = 14400704,
	CharName = "带路NPC",
	Text = "那你就错了，我计算了路面行走难度，同时还计算了障碍干扰时间。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_10_buluolaoda_cos10",
	NextID = 14400705,
}
StorySpeechConfig[StorySpeechID.Id14400705] =
{
	Id = 14400705,
	CharName = "指路NPC",
	Text = "不过根据过去1000次行走经验，这条路的障碍干扰时间是在一个较大区间波动的。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_10_buluolaoda",
	NextID = 14400706,
}
StorySpeechConfig[StorySpeechID.Id14400706] =
{
	Id = 14400706,
	CharName = "带路NPC",
	Text = "所以说你对路不熟，样本在10万次以后会趋于中间值。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_10_buluolaoda_cos10",
	NextID = 14400707,
}
StorySpeechConfig[StorySpeechID.Id14400707] =
{
	Id = 14400707,
	CharName = "指路NPC",
	Text = "但是大样本数据不能直接推导出今日通行的确定时间。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_10_buluolaoda",
	NextID = 14400708,
}
StorySpeechConfig[StorySpeechID.Id14400708] =
{
	Id = 14400708,
	CharName = "带路NPC",
	Text = "……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_10_buluolaoda_cos10",
	NextID = 14400709,
}
StorySpeechConfig[StorySpeechID.Id14400709] =
{
	Id = 14400709,
	CharName = "带路NPC",
	Text = "既然大家说不清楚，那么就打一架吧！输的人要承认对方才是活地图，还要把帽子交给对方！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_10_buluolaoda_cos10",
}
StorySpeechConfig[StorySpeechID.Id14400901] =
{
	Id = 14400901,
	CharName = "冒险协会会长",
	Text = "今天是冒险星一年一度的颁奖典礼，欢迎各位光临。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye_cos10",
	NextID = 14400902,
}
StorySpeechConfig[StorySpeechID.Id14400902] =
{
	Id = 14400902,
	CharName = "冒险协会会长",
	Text = "首先请出的是年度最佳杂兵，获奖者是，骨头兵！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye_cos10",
	NextID = 14400903,
}
StorySpeechConfig[StorySpeechID.Id14400903] =
{
	Id = 14400903,
	CharName = "骨头兵",
	Text = "好开心，谢谢爸爸妈妈，也谢谢魔王公司多年来的栽培！我会继续努力的。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_30_kulou",
	NextID = 14400904,
}
StorySpeechConfig[StorySpeechID.Id14400904] =
{
	Id = 14400904,
	CharName = "冒险协会会长",
	Text = "接下来是年度最佳辅助，获奖者是，牧师！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye_cos10",
	NextID = 14400905,
}
StorySpeechConfig[StorySpeechID.Id14400905] =
{
	Id = 14400905,
	CharName = "牧师",
	Text = "啊，竟然是我吗？谢……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_07_mushi",
	NextID = 14400906,
}
StorySpeechConfig[StorySpeechID.Id14400906] =
{
	Id = 14400906,
	CharName = "村长",
	Text = "我抗议！有黑幕！最佳冒险者怎么可能不是我！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye",
	NextID = 14400907,
}
StorySpeechConfig[StorySpeechID.Id14400907] =
{
	Id = 14400907,
	CharName = "冒险协会会长",
	Text = "颁奖仪式还在进行中，请不要喧哗！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye_cos10",
	NextID = 14400908,
}
StorySpeechConfig[StorySpeechID.Id14400908] =
{
	Id = 14400908,
	CharName = "村长",
	Text = "我每天发那么多任务，今天这个奖不给我，我以后专门发不能做的任务！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye",
	NextID = 14400909,
}
StorySpeechConfig[StorySpeechID.Id14400909] =
{
	Id = 14400909,
	CharName = "牧师",
	Text = "啊，这么严重吗？那，那这个奖还是给村长大人吧。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_07_mushi",
	NextID = 14400910,
}
StorySpeechConfig[StorySpeechID.Id14400910] =
{
	Id = 14400910,
	CharName = "村长",
	Text = "早知道这样，一开始给我不就好了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye",
	NextID = 14400911,
}
StorySpeechConfig[StorySpeechID.Id14400911] =
{
	Id = 14400911,
	CharName = "牧师",
	Text = "哎，看来要明年再努力了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_07_mushi",
	NextID = 14400912,
}
StorySpeechConfig[StorySpeechID.Id14400912] =
{
	Id = 14400912,
	CharName = "村长",
	Text = "最佳辅助你就不要想了，以后哪年不是我，我就发BUG任务！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye",
	NextID = 14400913,
}
StorySpeechConfig[StorySpeechID.Id14400913] =
{
	Id = 14400913,
	CharName = "小魔王",
	Text = "无礼的家伙！把奖杯还给牧师！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_12_xiaomowang",
	NextID = 14400914,
}
StorySpeechConfig[StorySpeechID.Id14400914] =
{
	Id = 14400914,
	CharName = "村长",
	Text = "你有不满吗？你是魔王公司的，冒险家的事情轮得到你管吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye",
	NextID = 14400915,
}
StorySpeechConfig[StorySpeechID.Id14400915] =
{
	Id = 14400915,
	CharName = "小魔王",
	Text = "看来你想见识一下魔王之怒！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_12_xiaomowang",
	NextID = 14400916,
}
StorySpeechConfig[StorySpeechID.Id14400916] =
{
	Id = 14400916,
	CharName = "村长",
	Text = "(吐舌头)略略略！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye",
	NextID = 14400917,
}
StorySpeechConfig[StorySpeechID.Id14400917] =
{
	Id = 14400917,
	CharName = "小魔王",
	Text = "……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_12_xiaomowang",
}
StorySpeechConfig[StorySpeechID.Id14401001] =
{
	Id = 14401001,
	CharName = "大魔王",
	Text = "总经理，最近副本人气有下降趋势。你安排点活动吧？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_11_damowang",
	NextID = 14401002,
}
StorySpeechConfig[StorySpeechID.Id14401002] =
{
	Id = 14401002,
	CharName = "小魔王",
	Text = "是的，董事长，这次我们打算举办复古的吸血鬼主题。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_12_xiaomowang",
	NextID = 14401003,
}
StorySpeechConfig[StorySpeechID.Id14401003] =
{
	Id = 14401003,
	CharName = "大魔王",
	Text = "啊哈~虽然老，但是绝妙。面带病容的伯爵和贵族少女的爱情故事，嗯，是浪漫的味道。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_11_damowang",
	NextID = 14401004,
}
StorySpeechConfig[StorySpeechID.Id14401004] =
{
	Id = 14401004,
	CharName = "小魔王",
	Text = "公司已经为骨头兵们准备了新的套装，另外还打算外聘几个吸血鬼一起搞气氛。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_12_xiaomowang",
	NextID = 14401005,
}
StorySpeechConfig[StorySpeechID.Id14401005] =
{
	Id = 14401005,
	CharName = "大魔王",
	Text = "让人很期待，你呢？你自己有安排吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_11_damowang",
	NextID = 14401006,
}
StorySpeechConfig[StorySpeechID.Id14401006] =
{
	Id = 14401006,
	CharName = "小魔王",
	Text = "在下并没有安排，董事长。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_12_xiaomowang",
	NextID = 14401007,
}
StorySpeechConfig[StorySpeechID.Id14401007] =
{
	Id = 14401007,
	CharName = "大魔王",
	Text = "穿我当年那套吸血鬼服，质地很不错，颜色和你也非常搭。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_11_damowang",
	NextID = 14401008,
}
StorySpeechConfig[StorySpeechID.Id14401008] =
{
	Id = 14401008,
	CharName = "小魔王",
	Text = "多谢董事长厚爱。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_12_xiaomowang",
	NextID = 14401009,
}
StorySpeechConfig[StorySpeechID.Id14401009] =
{
	Id = 14401009,
	CharName = "大魔王",
	Text = "不过你身上魔族气味太重了，还差点吸血鬼的气息。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_11_damowang",
	NextID = 14401010,
}
StorySpeechConfig[StorySpeechID.Id14401010] =
{
	Id = 14401010,
	CharName = "小魔王",
	Text = "但凭董事长吩咐。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_12_xiaomowang",
	NextID = 14401011,
}
StorySpeechConfig[StorySpeechID.Id14401011] =
{
	Id = 14401011,
	CharName = "大魔王",
	Text = "我这里有一滴血族的血液，打败它，感受一下血族的力量吧。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_11_damowang",
}
StorySpeechConfig[StorySpeechID.Id14401101] =
{
	Id = 14401101,
	CharName = "石巨人",
	Text = "呼噜呼噜！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_Stoneman",
	NextID = 14401102,
}
StorySpeechConfig[StorySpeechID.Id14401102] =
{
	Id = 14401102,
	CharName = "小魔仙",
	Text = "你不要太过分了！这颗牙齿旁边都已经长草了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_06_mofashi_cos10",
	NextID = 14401103,
}
StorySpeechConfig[StorySpeechID.Id14401103] =
{
	Id = 14401103,
	CharName = "石巨人",
	Text = "呼噜呼噜！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_Stoneman",
	NextID = 14401104,
}
StorySpeechConfig[StorySpeechID.Id14401104] =
{
	Id = 14401104,
	CharName = "小魔仙",
	Text = "每次都说过两天拔，都已经拖了一年了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_06_mofashi_cos10",
	NextID = 14401105,
}
StorySpeechConfig[StorySpeechID.Id14401105] =
{
	Id = 14401105,
	CharName = "石巨人",
	Text = "呼噜呼噜……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_Stoneman",
	NextID = 14401106,
}
StorySpeechConfig[StorySpeechID.Id14401106] =
{
	Id = 14401106,
	CharName = "小魔仙",
	Text = "不可能，只除草已经不行了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_06_mofashi_cos10",
	NextID = 14401107,
}
StorySpeechConfig[StorySpeechID.Id14401107] =
{
	Id = 14401107,
	CharName = "石巨人",
	Text = "呼噜！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_Stoneman",
	NextID = 14401108,
}
StorySpeechConfig[StorySpeechID.Id14401108] =
{
	Id = 14401108,
	CharName = "小魔仙",
	Text = "你现在是打算耍无赖是吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_06_mofashi_cos10",
	NextID = 14401109,
}
StorySpeechConfig[StorySpeechID.Id14401109] =
{
	Id = 14401109,
	CharName = "石巨人",
	Text = "呼噜！（挥舞双手）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_Stoneman",
	NextID = 14401110,
}
StorySpeechConfig[StorySpeechID.Id14401110] =
{
	Id = 14401110,
	CharName = "魔法师",
	Text = "啊，小心！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_06_mofashi",
	NextID = 14401111,
}
StorySpeechConfig[StorySpeechID.Id14401111] =
{
	Id = 14401111,
	CharName = "小魔仙",
	Text = "呼，太生气了，又开始耍无赖了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_06_mofashi_cos10",
	NextID = 14401112,
}
StorySpeechConfig[StorySpeechID.Id14401112] =
{
	Id = 14401112,
	CharName = "魔法师",
	Text = "……你在做什么？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_06_mofashi",
	NextID = 14401113,
}
StorySpeechConfig[StorySpeechID.Id14401113] =
{
	Id = 14401113,
	CharName = "小魔仙",
	Text = "啊，您好，魔女大人，我是这片森林的小魔仙。这个大石头长了颗坏牙，已经烂了一年了，今天一定要帮它拔掉！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_06_mofashi_cos10",
	NextID = 14401114,
}
StorySpeechConfig[StorySpeechID.Id14401114] =
{
	Id = 14401114,
	CharName = "魔法师",
	Text = "拔牙啊……听着有点可怕……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_06_mofashi",
	NextID = 14401115,
}
StorySpeechConfig[StorySpeechID.Id14401115] =
{
	Id = 14401115,
	CharName = "小魔仙",
	Text = "哎，这就是麻烦的地方，您能帮我吗，魔女大人~只要能帮助大石头，这片森林会感谢您的~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_06_mofashi_cos10",
	NextID = 14401116,
}
StorySpeechConfig[StorySpeechID.Id14401116] =
{
	Id = 14401116,
	CharName = "魔法师",
	Text = "好、好吧……忍着点吧大个子，这是为了你好！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_06_mofashi",
}
StorySpeechConfig[StorySpeechID.Id14401201] =
{
	Id = 14401201,
	CharName = "剑士",
	Text = "为了世界和平，为了人类的自由与未来，我们一定要打败魔王！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 14401202,
}
StorySpeechConfig[StorySpeechID.Id14401202] =
{
	Id = 14401202,
	CharName = "居民NPC",
	Text = "（鼓掌）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_09_putongcunmin",
	NextID = 14401203,
}
StorySpeechConfig[StorySpeechID.Id14401203] =
{
	Id = 14401203,
	CharName = "剑士",
	Text = "（清嗓）那么，接下来就是募捐环节了。请名字里有NPC的队员每人上交2000金币。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 14401204,
}
StorySpeechConfig[StorySpeechID.Id14401204] =
{
	Id = 14401204,
	CharName = "村长",
	Text = "呼，还好前两天去民政局把名字改掉了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye",
	NextID = 14401205,
}
StorySpeechConfig[StorySpeechID.Id14401205] =
{
	Id = 14401205,
	CharName = "居民NPC",
	Text = "……真的是为了讨伐魔王吗？我前两天看到勇者大人贷款买了一台游戏机来着。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_09_putongcunmin",
	NextID = 14401206,
}
StorySpeechConfig[StorySpeechID.Id14401206] =
{
	Id = 14401206,
	CharName = "剑士",
	Text = "通过击败游戏中的魔王学习战斗技巧和培养信心可是拯救世界很重要的一个环节！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 14401207,
}
StorySpeechConfig[StorySpeechID.Id14401207] =
{
	Id = 14401207,
	CharName = "居民NPC",
	Text = "好吧……不过这已经是我最后的积蓄了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_09_putongcunmin",
	NextID = 14401208,
}
StorySpeechConfig[StorySpeechID.Id14401208] =
{
	Id = 14401208,
	CharName = "剑士",
	Text = "看你还有顾虑，我再免费送你一次和本勇者擂台对战的机会。只要你赢，不仅免除募捐，而且还能成为协会认可的勇者噢！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 14401209,
}
StorySpeechConfig[StorySpeechID.Id14401209] =
{
	Id = 14401209,
	CharName = "居民NPC",
	Text = "啊，我怎么可能战胜勇者大人呢？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_09_putongcunmin",
	NextID = 14401210,
}
StorySpeechConfig[StorySpeechID.Id14401210] =
{
	Id = 14401210,
	CharName = "剑士",
	Text = "嘿嘿嘿，试试看嘛，试过了，你才能安心地把钱交给我啊~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 14401211,
}
StorySpeechConfig[StorySpeechID.Id14401211] =
{
	Id = 14401211,
	CharName = "居民NPC",
	Text = "嗯，嗯，那请大人一定要手下留情。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_09_putongcunmin",
}
StorySpeechConfig[StorySpeechID.Id14401301] =
{
	Id = 14401301,
	CharName = "居民NPC",
	Text = "村长！不好啦！！有个很凶的精英怪在村子里到处转悠，说要找你！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_09_putongcunmin",
	NextID = 14401302,
}
StorySpeechConfig[StorySpeechID.Id14401302] =
{
	Id = 14401302,
	CharName = "村长",
	Text = "谁是村长！我只是普通村民，你不要乱认噢！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye",
	NextID = 14401303,
}
StorySpeechConfig[StorySpeechID.Id14401303] =
{
	Id = 14401303,
	CharName = "居民NPC",
	Text = "（-_-||）村……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_09_putongcunmin",
	NextID = 14401304,
}
StorySpeechConfig[StorySpeechID.Id14401304] =
{
	Id = 14401304,
	CharName = "村长",
	Text = "呐，呐，呐，都跟你说了，头衔别乱叫啊，你再乱叫我打人了啊！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye",
	NextID = 14401305,
}
StorySpeechConfig[StorySpeechID.Id14401305] =
{
	Id = 14401305,
	CharName = "复仇的小队长",
	Text = "终于被我找到你了！！25年，整整25年了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 14401306,
}
StorySpeechConfig[StorySpeechID.Id14401306] =
{
	Id = 14401306,
	CharName = "村长",
	Text = "诶，这位怪物大哥，25年前我还不是这里的村长呢~我们之间是不是有什么误会？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye",
	NextID = 14401307,
}
StorySpeechConfig[StorySpeechID.Id14401307] =
{
	Id = 14401307,
	CharName = "复仇的小队长",
	Text = "误会？就是你！25年前，我本来应该晋升小魔王的，就是你坏了我的好事！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 14401308,
}
StorySpeechConfig[StorySpeechID.Id14401308] =
{
	Id = 14401308,
	CharName = "村长",
	Text = "诶……大哥，我不是怀疑你的记性啊，不过你看，会不会是你瞎了眼，认错人了呢？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye",
	NextID = 14401309,
}
StorySpeechConfig[StorySpeechID.Id14401309] =
{
	Id = 14401309,
	CharName = "复仇的小队长",
	Text = "认错人？你那副猥琐之中透着机警，机警之中透着狡猾的模样我永远忘不了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 14401310,
}
StorySpeechConfig[StorySpeechID.Id14401310] =
{
	Id = 14401310,
	CharName = "村长",
	Text = "哈哈哈~我的气质真的这么出众吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye",
	NextID = 14401311,
}
StorySpeechConfig[StorySpeechID.Id14401311] =
{
	Id = 14401311,
	CharName = "复仇的小队长",
	Text = "还嘻嘻哈哈的！我今天就要把你分成十块！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 14401312,
}
StorySpeechConfig[StorySpeechID.Id14401312] =
{
	Id = 14401312,
	CharName = "村长",
	Text = "诶，不过你还是没有告诉我当初我到底做了什么？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye",
	NextID = 14401313,
}
StorySpeechConfig[StorySpeechID.Id14401313] =
{
	Id = 14401313,
	CharName = "复仇的小队长",
	Text = "那天，就是那天，我击败了你，只要你肯承认自己的勇者身份，魔王就会认可我成为新任小魔王。但是！你却在魔王大人面前一口咬死说自己只是个村长！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 14401314,
}
StorySpeechConfig[StorySpeechID.Id14401314] =
{
	Id = 14401314,
	CharName = "村长",
	Text = "诶……诶……我竟然做过这么丢脸的事吗？可能当时真的很害怕吧……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye",
	NextID = 14401315,
}
StorySpeechConfig[StorySpeechID.Id14401315] =
{
	Id = 14401315,
	CharName = "复仇的小队长",
	Text = "啊！！母亲大人那天还问我有没有如愿升职加薪，我看着她期盼的目光，根本……根本答不上来啊！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 14401316,
}
StorySpeechConfig[StorySpeechID.Id14401316] =
{
	Id = 14401316,
	CharName = "村长",
	Text = "不要哭了，不要哭了。一切都过去了~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye",
	NextID = 14401317,
}
StorySpeechConfig[StorySpeechID.Id14401317] =
{
	Id = 14401317,
	CharName = "复仇的小队长",
	Text = "不！我今天是来教训那个不敢承认自己是勇者的村长的！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 14401318,
}
StorySpeechConfig[StorySpeechID.Id14401318] =
{
	Id = 14401318,
	CharName = "村长",
	Text = "其实……其实我是一个勇者……我衣服还挂在家里呢，这就去拿……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye",
	NextID = 14401319,
}
StorySpeechConfig[StorySpeechID.Id14401319] =
{
	Id = 14401319,
	CharName = "复仇的小队长",
	Text = "老贼别走！纳命来！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
}
StorySpeechConfig[StorySpeechID.Id14401401] =
{
	Id = 14401401,
	CharName = "村长夫人",
	Text = "保持干净整洁也是提升幸福感的魔法。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_18_laonainai",
	NextID = 14401402,
}
StorySpeechConfig[StorySpeechID.Id14401402] =
{
	Id = 14401402,
	CharName = "小土包",
	Text = "咕噜咕噜~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_ruannidui",
	NextID = 14401403,
}
StorySpeechConfig[StorySpeechID.Id14401403] =
{
	Id = 14401403,
	CharName = "村长夫人",
	Text = "诶！怎么又有泥了？赶紧再清洁一下。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_18_laonainai",
	NextID = 14401404,
}
StorySpeechConfig[StorySpeechID.Id14401404] =
{
	Id = 14401404,
	CharName = "小土包",
	Text = "咕噜咕噜~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_ruannidui",
	NextID = 14401405,
}
StorySpeechConfig[StorySpeechID.Id14401405] =
{
	Id = 14401405,
	CharName = "村长夫人",
	Text = "……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_18_laonainai",
	NextID = 14401406,
}
StorySpeechConfig[StorySpeechID.Id14401406] =
{
	Id = 14401406,
	CharName = "小土包",
	Text = "？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_ruannidui",
	NextID = 14401407,
}
StorySpeechConfig[StorySpeechID.Id14401407] =
{
	Id = 14401407,
	CharName = "村长夫人",
	Text = "看来要大扫除了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_18_laonainai",
}
StorySpeechConfig[StorySpeechID.Id14401901] =
{
	Id = 14401901,
	CharName = "研究人员A",
	Text = "再加入3个量度单位的α管剂。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_03_moliyadi_cos30",
	NextID = 14401902,
}
StorySpeechConfig[StorySpeechID.Id14401902] =
{
	Id = 14401902,
	CharName = "研究人员B",
	Text = "217号，我们不能再加了，实验体目前已经表现出攻击性了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_03_moliyadi_cos30",
	NextID = 14401903,
}
StorySpeechConfig[StorySpeechID.Id14401903] =
{
	Id = 14401903,
	CharName = "217号",
	Text = "334号，你知道为什么我选择和你搭档吗？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_03_moliyadi_cos30",
	NextID = 14401904,
}
StorySpeechConfig[StorySpeechID.Id14401904] =
{
	Id = 14401904,
	CharName = "334号",
	Text = "因为我们都毕业于高星实验中心吗？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_03_moliyadi_cos30",
	NextID = 14401905,
}
StorySpeechConfig[StorySpeechID.Id14401905] =
{
	Id = 14401905,
	CharName = "217号",
	Text = "不是，因为你简历上写着，愿意为科学献出生命。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_03_moliyadi_cos30",
	NextID = 14401906,
}
StorySpeechConfig[StorySpeechID.Id14401906] =
{
	Id = 14401906,
	CharName = "334号",
	Text = "抱歉，那是迫于求职压力才写的……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_03_moliyadi_cos30",
	NextID = 14401907,
}
StorySpeechConfig[StorySpeechID.Id14401907] =
{
	Id = 14401907,
	CharName = "217号",
	Text = "……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_03_moliyadi_cos30",
	NextID = 14401908,
}
StorySpeechConfig[StorySpeechID.Id14401908] =
{
	Id = 14401908,
	CharName = "334号",
	Text = "……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_03_moliyadi_cos30",
	NextID = 14401909,
}
StorySpeechConfig[StorySpeechID.Id14401909] =
{
	Id = 14401909,
	CharName = "217号",
	Text = "说实话，你骗到我了……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_03_moliyadi_cos30",
	NextID = 14401910,
}
StorySpeechConfig[StorySpeechID.Id14401910] =
{
	Id = 14401910,
	CharName = "334号",
	Text = "说实话，我以为没有人会在意这种话的。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_03_moliyadi_cos30",
	NextID = 14401911,
}
StorySpeechConfig[StorySpeechID.Id14401911] =
{
	Id = 14401911,
	CharName = "217号",
	Text = "诶！你刚刚把管剂丢进培养皿了！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_03_moliyadi_cos30",
	NextID = 14401912,
}
StorySpeechConfig[StorySpeechID.Id14401912] =
{
	Id = 14401912,
	CharName = "334号",
	Text = "哎呦！我们快逃吧。它咬到谁，谁就会感染的！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_03_moliyadi_cos30",
	NextID = 14401913,
}
StorySpeechConfig[StorySpeechID.Id14401913] =
{
	Id = 14401913,
	CharName = "217号",
	Text = "这已经是第7次事故了，我们快走吧，会有人来处理的。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_03_moliyadi_cos30",
}
StorySpeechConfig[StorySpeechID.Id14401801] =
{
	Id = 14401801,
	CharName = "研究人员A",
	Text = "呼，终于逃出来了！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_03_moliyadi_cos30",
	NextID = 14401802,
}
StorySpeechConfig[StorySpeechID.Id14401802] =
{
	Id = 14401802,
	CharName = "研究人员B",
	Text = "217号，我得休息一会儿了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_03_moliyadi_cos30",
	NextID = 14401803,
}
StorySpeechConfig[StorySpeechID.Id14401803] =
{
	Id = 14401803,
	CharName = "217号",
	Text = "不，不，334号，我们还得继续跑。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_03_moliyadi_cos30",
	NextID = 14401804,
}
StorySpeechConfig[StorySpeechID.Id14401804] =
{
	Id = 14401804,
	CharName = "334号",
	Text = "不是会有人来处理那个家伙吗？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_03_moliyadi_cos30",
	NextID = 14401805,
}
StorySpeechConfig[StorySpeechID.Id14401805] =
{
	Id = 14401805,
	CharName = "217号",
	Text = "刚刚我忘记关闸门了，现在那家伙可能出现在任何地方！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_03_moliyadi_cos30",
	NextID = 14401806,
}
StorySpeechConfig[StorySpeechID.Id14401806] =
{
	Id = 14401806,
	CharName = "334号",
	Text = "诶？什么东西粘乎乎的，滴到我头上了？(抬头看)",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_03_moliyadi_cos30",
	NextID = 14401807,
}
StorySpeechConfig[StorySpeechID.Id14401807] =
{
	Id = 14401807,
	CharName = "217号",
	Text = "啊！！！！！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_03_moliyadi_cos30",
	NextID = 14401808,
}
StorySpeechConfig[StorySpeechID.Id14401808] =
{
	Id = 14401808,
	CharName = "334号",
	Text = "啊！！！！！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_03_moliyadi_cos30",
}
StorySpeechConfig[StorySpeechID.Id14400601] =
{
	Id = 14400601,
	CharName = "小队长",
	Text = "竞选领导前我先点个名。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 14400602,
}
StorySpeechConfig[StorySpeechID.Id14400602] =
{
	Id = 14400602,
	CharName = "小队长",
	Text = "骷髅杰克。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 14400603,
}
StorySpeechConfig[StorySpeechID.Id14400603] =
{
	Id = 14400603,
	CharName = "骷髅杰克",
	Text = "到！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_30_kulou",
	NextID = 14400604,
}
StorySpeechConfig[StorySpeechID.Id14400604] =
{
	Id = 14400604,
	CharName = "小队长",
	Text = "骷髅约翰。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 14400605,
}
StorySpeechConfig[StorySpeechID.Id14400605] =
{
	Id = 14400605,
	CharName = "骷髅约翰",
	Text = "到！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_30_kulou",
	NextID = 14400606,
}
StorySpeechConfig[StorySpeechID.Id14400606] =
{
	Id = 14400606,
	CharName = "小队长",
	Text = "骷髅汤姆。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 14400607,
}
StorySpeechConfig[StorySpeechID.Id14400607] =
{
	Id = 14400607,
	CharName = "骷髅汤姆",
	Text = "到！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_30_kulou",
	NextID = 14400608,
}
StorySpeechConfig[StorySpeechID.Id14400608] =
{
	Id = 14400608,
	CharName = "小队长",
	Text = "骷髅王。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 14400609,
}
StorySpeechConfig[StorySpeechID.Id14400609] =
{
	Id = 14400609,
	CharName = "骷髅王",
	Text = "到！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_30_kulou_cos10",
	NextID = 14400610,
}
StorySpeechConfig[StorySpeechID.Id14400610] =
{
	Id = 14400610,
	CharName = "小队长",
	Text = "你父母还真会取名字……那就你吧！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 14400611,
}
StorySpeechConfig[StorySpeechID.Id14400611] =
{
	Id = 14400611,
	CharName = "骷髅王",
	Text = "哇，好开心~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_30_kulou_cos10",
	NextID = 14400612,
}
StorySpeechConfig[StorySpeechID.Id14400612] =
{
	Id = 14400612,
	CharName = "骷髅杰克",
	Text = "小队长，我不服！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_30_kulou",
	NextID = 14400613,
}
StorySpeechConfig[StorySpeechID.Id14400613] =
{
	Id = 14400613,
	CharName = "骷髅约翰",
	Text = "小队长，我也不服！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_30_kulou",
	NextID = 14400614,
}
StorySpeechConfig[StorySpeechID.Id14400614] =
{
	Id = 14400614,
	CharName = "骷髅汤姆",
	Text = "小队长，我也不服！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_30_kulou",
}
StorySpeechConfig[StorySpeechID.Id14401501] =
{
	Id = 14401501,
	CharName = "黑龙王子",
	Text = "我们一定要分出胜负的吼？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_23_long",
	NextID = 14401502,
}
StorySpeechConfig[StorySpeechID.Id14401502] =
{
	Id = 14401502,
	CharName = "龙骑士",
	Text = "我们龙骑士一族的使命就是猎杀任何出现在人类领地的龙族！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_25_longqishi",
	NextID = 14401503,
}
StorySpeechConfig[StorySpeechID.Id14401503] =
{
	Id = 14401503,
	CharName = "黑龙王子",
	Text = "我就是过来吃个烤肉的吼！你不能假装不知道我是龙吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_23_long",
	NextID = 14401504,
}
StorySpeechConfig[StorySpeechID.Id14401504] =
{
	Id = 14401504,
	CharName = "龙骑士",
	Text = "果然龙族都是狡猾的骗子，竟想引诱我玩忽职守。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_25_longqishi",
	NextID = 14401505,
}
StorySpeechConfig[StorySpeechID.Id14401505] =
{
	Id = 14401505,
	CharName = "黑龙王子",
	Text = "不是的吼！我是用商量的口气，而且我们打起来城镇会被摧毁的。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_23_long",
	NextID = 14401506,
}
StorySpeechConfig[StorySpeechID.Id14401506] =
{
	Id = 14401506,
	CharName = "龙骑士",
	Text = "来不及管这个了，家族使命高于一切！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_25_longqishi",
	NextID = 14401507,
}
StorySpeechConfig[StorySpeechID.Id14401507] =
{
	Id = 14401507,
	CharName = "皇家卫兵",
	Text = "住手！检测到你们有PK意图，我现在向你们发出第一次警告，解除武装，离开这里！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_17_chengzhenweibing_cos10",
	NextID = 14401508,
}
StorySpeechConfig[StorySpeechID.Id14401508] =
{
	Id = 14401508,
	CharName = "黑龙王子",
	Text = "好的吼！我们马上走！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_23_long",
	NextID = 14401509,
}
StorySpeechConfig[StorySpeechID.Id14401509] =
{
	Id = 14401509,
	CharName = "龙骑士",
	Text = "站住！你再动一步试试，我今天一定要将你消灭在这里！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_25_longqishi",
	NextID = 14401510,
}
StorySpeechConfig[StorySpeechID.Id14401510] =
{
	Id = 14401510,
	CharName = "皇家卫兵",
	Text = "喂！第二次警告，解除武装，离开这里。这里有很多普通居民的！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_17_chengzhenweibing_cos10",
	NextID = 14401511,
}
StorySpeechConfig[StorySpeechID.Id14401511] =
{
	Id = 14401511,
	CharName = "龙骑士",
	Text = "为了家族荣誉！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_25_longqishi",
	NextID = 14401512,
}
StorySpeechConfig[StorySpeechID.Id14401512] =
{
	Id = 14401512,
	CharName = "皇家卫兵",
	Text = "英雄，你这样我只能逮捕你了！第三次警……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_17_chengzhenweibing_cos10",
	NextID = 14401513,
}
StorySpeechConfig[StorySpeechID.Id14401513] =
{
	Id = 14401513,
	CharName = "龙骑士",
	Text = "看枪！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_25_longqishi",
}
StorySpeechConfig[StorySpeechID.Id14402501] =
{
	Id = 14402501,
	CharName = "策划A",
	Text = "奖池厨师的动画做完了？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_13_lvshi",
	NextID = 14402502,
}
StorySpeechConfig[StorySpeechID.Id14402502] =
{
	Id = 14402502,
	CharName = "动画师",
	Text = "做完了！（糟了，还没做……）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_27_donghua",
	NextID = 14402503,
}
StorySpeechConfig[StorySpeechID.Id14402503] =
{
	Id = 14402503,
	CharName = "策划B",
	Text = "礼包厨师的动画做完了？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_13_lvshi",
	NextID = 14402504,
}
StorySpeechConfig[StorySpeechID.Id14402504] =
{
	Id = 14402504,
	CharName = "动画师",
	Text = "做完了！（怎么还有这个……）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_27_donghua",
	NextID = 14402505,
}
StorySpeechConfig[StorySpeechID.Id14402505] =
{
	Id = 14402505,
	CharName = "策划C",
	Text = "新的小二动画做完了？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_13_lvshi",
	NextID = 14402506,
}
StorySpeechConfig[StorySpeechID.Id14402506] =
{
	Id = 14402506,
	CharName = "动画师",
	Text = "做完了！（我到底划水了多久……）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_27_donghua",
	NextID = 14402507,
}
StorySpeechConfig[StorySpeechID.Id14402507] =
{
	Id = 14402507,
	CharName = "策划A",
	Text = "嗯？你鼻子怎么了？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_13_lvshi",
	NextID = 14402508,
}
StorySpeechConfig[StorySpeechID.Id14402508] =
{
	Id = 14402508,
	CharName = "动画师",
	Text = "！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_27_donghua",
}
StorySpeechConfig[StorySpeechID.Id14400801] =
{
	Id = 14400801,
	CharName = "铁匠",
	Text = "顺鹿快递即将开始运营啦，拉一单货净赚100，每天拉200单货，就是2万，一个月就是60万，一年就是700多万，再拿去做复利投资，哇哈哈哈哈~~~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_31_tiejiang",
	NextID = 14400802,
}
StorySpeechConfig[StorySpeechID.Id14400802] =
{
	Id = 14400802,
	CharName = "树精",
	Text = "(指着头上被咬的缺口，指指门口的驯鹿)",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_xiaoshuyang",
	NextID = 14400803,
}
StorySpeechConfig[StorySpeechID.Id14400803] =
{
	Id = 14400803,
	CharName = "铁匠",
	Text = "这位树精先生是要办理快递业务吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_31_tiejiang",
	NextID = 14400804,
}
StorySpeechConfig[StorySpeechID.Id14400804] =
{
	Id = 14400804,
	CharName = "树精",
	Text = "（比划手势要求索偿1000万）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_xiaoshuyang",
	NextID = 14400805,
}
StorySpeechConfig[StorySpeechID.Id14400805] =
{
	Id = 14400805,
	CharName = "铁匠",
	Text = "（假装看不懂……）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_31_tiejiang",
	NextID = 14400806,
}
StorySpeechConfig[StorySpeechID.Id14400806] =
{
	Id = 14400806,
	CharName = "树精",
	Text = "（很着急地比划手势，看来要赔偿的态度很坚决）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_xiaoshuyang",
	NextID = 14400807,
}
StorySpeechConfig[StorySpeechID.Id14400807] =
{
	Id = 14400807,
	CharName = "铁匠",
	Text = "（假装看不懂……）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_31_tiejiang",
	NextID = 14400808,
}
StorySpeechConfig[StorySpeechID.Id14400808] =
{
	Id = 14400808,
	CharName = "树精",
	Text = "（抱起旁边的保险箱，转身就跑）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_xiaoshuyang",
	NextID = 14400809,
}
StorySpeechConfig[StorySpeechID.Id14400809] =
{
	Id = 14400809,
	CharName = "铁匠",
	Text = "！！！快来人啊！！树精抢保险箱啦！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_31_tiejiang",
}
StorySpeechConfig[StorySpeechID.Id14401601] =
{
	Id = 14401601,
	CharName = "算命商人",
	Text = "算命啦，不准不要钱。诶！这位兄台，你请留步！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_14_lvxingshangren_cos10",
	NextID = 14401602,
}
StorySpeechConfig[StorySpeechID.Id14401602] =
{
	Id = 14401602,
	CharName = "抽卡爱好者",
	Text = "？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPDraw_04_UnlockChief",
	NextID = 14401603,
}
StorySpeechConfig[StorySpeechID.Id14401603] =
{
	Id = 14401603,
	CharName = "算命商人",
	Text = "我看你行色匆匆又印堂发黑，近日投资可是相当地不顺？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_14_lvxingshangren_cos10",
	NextID = 14401604,
}
StorySpeechConfig[StorySpeechID.Id14401604] =
{
	Id = 14401604,
	CharName = "抽卡爱好者",
	Text = "是啊，大师！怎么办？我抽了八百个十连，官方说的保底也没有出！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPDraw_04_UnlockChief",
	NextID = 14401605,
}
StorySpeechConfig[StorySpeechID.Id14401605] =
{
	Id = 14401605,
	CharName = "算命商人",
	Text = "我算算，你今天犯五鬼，抽卡等于送钱。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_14_lvxingshangren_cos10",
	NextID = 14401606,
}
StorySpeechConfig[StorySpeechID.Id14401606] =
{
	Id = 14401606,
	CharName = "抽卡爱好者",
	Text = "这么严重！大师，你一定要帮帮我啊！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPDraw_04_UnlockChief",
	NextID = 14401607,
}
StorySpeechConfig[StorySpeechID.Id14401607] =
{
	Id = 14401607,
	CharName = "算命商人",
	Text = "这样吧，你回去斋戒三天，三天后日贯星入你中宫，就是你十连五彩的好日子！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_14_lvxingshangren_cos10",
	NextID = 14401608,
}
StorySpeechConfig[StorySpeechID.Id14401608] =
{
	Id = 14401608,
	CharName = "抽卡爱好者",
	Text = "谢谢大师，这一千金币请你务必收下。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPDraw_04_UnlockChief",
	NextID = 14401609,
}
StorySpeechConfig[StorySpeechID.Id14401609] =
{
	Id = 14401609,
	CharName = "算命商人",
	Text = "这怎么好意思呢~~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_14_lvxingshangren_cos10",
	NextID = 14401610,
}
StorySpeechConfig[StorySpeechID.Id14401610] =
{
	Id = 14401610,
	CharName = "算命商人",
	Text = "（转眼过了三天）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_14_lvxingshangren_cos10",
	NextID = 14401611,
}
StorySpeechConfig[StorySpeechID.Id14401611] =
{
	Id = 14401611,
	CharName = "抽卡爱好者",
	Text = "今天我一定要砍死你这个神棍！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPDraw_04_UnlockChief",
	NextID = 14401612,
}
StorySpeechConfig[StorySpeechID.Id14401612] =
{
	Id = 14401612,
	CharName = "算命商人",
	Text = "！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_14_lvxingshangren_cos10",
	NextID = 14401613,
}
StorySpeechConfig[StorySpeechID.Id14401613] =
{
	Id = 14401613,
	CharName = "抽卡爱好者",
	Text = "官方这三天推出活动，只要之前没有出保底的，这三天抽卡直接送五星！啊！！！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPDraw_04_UnlockChief",
	NextID = 14401614,
}
StorySpeechConfig[StorySpeechID.Id14401614] =
{
	Id = 14401614,
	CharName = "算命商人",
	Text = "吓！失算了，你听我狡辩……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_14_lvxingshangren_cos10",
}
StorySpeechConfig[StorySpeechID.Id14402601] =
{
	Id = 14402601,
	CharName = "村长",
	Text = "今天是制作组与我们NPC组的联谊日，大家热烈鼓掌。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye",
	NextID = 14402602,
}
StorySpeechConfig[StorySpeechID.Id14402602] =
{
	Id = 14402602,
	CharName = "居民NPC",
	Text = "（鼓掌）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_09_putongcunmin",
	NextID = 14402603,
}
StorySpeechConfig[StorySpeechID.Id14402603] =
{
	Id = 14402603,
	CharName = "指路NPC",
	Text = "（鼓掌）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_10_buluolaoda",
	NextID = 14402604,
}
StorySpeechConfig[StorySpeechID.Id14402604] =
{
	Id = 14402604,
	CharName = "旅行商人",
	Text = "（鼓掌）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_14_lvxingshangren",
	NextID = 14402605,
}
StorySpeechConfig[StorySpeechID.Id14402605] =
{
	Id = 14402605,
	CharName = "女王大人",
	Text = "（鼓掌）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_21_nvwangdaren",
	NextID = 14402606,
}
StorySpeechConfig[StorySpeechID.Id14402606] =
{
	Id = 14402606,
	CharName = "配音演员",
	Text = "大家平时很辛苦了，不过冒险者的旅程是少不了你们的陪伴的。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_15_peiyinyanyuan",
	NextID = 14402607,
}
StorySpeechConfig[StorySpeechID.Id14402607] =
{
	Id = 14402607,
	CharName = "村长",
	Text = "感谢制作组关心，那么现在有请配音演员为我们表演一个节目~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye",
	NextID = 14402608,
}
StorySpeechConfig[StorySpeechID.Id14402608] =
{
	Id = 14402608,
	CharName = "配音演员",
	Text = "那么，我就给大家唱我们游戏的主题曲吧~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_15_peiyinyanyuan",
	NextID = 14402609,
}
StorySpeechConfig[StorySpeechID.Id14402609] =
{
	Id = 14402609,
	CharName = "小队长",
	Text = "（忽然出现）难道只有NPC辛苦，我们怪物不辛苦吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 14402610,
}
StorySpeechConfig[StorySpeechID.Id14402610] =
{
	Id = 14402610,
	CharName = "配音演员",
	Text = "你们也很辛苦，但是今天是NPC节，下个月才是怪物节噢~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_15_peiyinyanyuan",
	NextID = 14402611,
}
StorySpeechConfig[StorySpeechID.Id14402611] =
{
	Id = 14402611,
	CharName = "小队长",
	Text = "那也不行，必须先给我们表演节目！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 14402612,
}
StorySpeechConfig[StorySpeechID.Id14402612] =
{
	Id = 14402612,
	CharName = "配音演员",
	Text = "请不要这样，事先已经说好了日程的，怎么可以临时变更呢？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_15_peiyinyanyuan",
	NextID = 14402613,
}
StorySpeechConfig[StorySpeechID.Id14402613] =
{
	Id = 14402613,
	CharName = "小队长",
	Text = "（在地上打滚）我们一定要先看表演，表演用的衣服已经在我手里了，必须先给我们表演！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 14402614,
}
StorySpeechConfig[StorySpeechID.Id14402614] =
{
	Id = 14402614,
	CharName = "配音演员",
	Text = "你这个小头目太不识大体了，今天就让我们制作组好好教训一下。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_15_peiyinyanyuan",
}
StorySpeechConfig[StorySpeechID.Id14402001] =
{
	Id = 14402001,
	CharName = "黑警长",
	Text = "该死的！这次的保障费用只有这点吗？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_05_jingcha_cos10",
	NextID = 14402002,
}
StorySpeechConfig[StorySpeechID.Id14402002] =
{
	Id = 14402002,
	CharName = "化学博士",
	Text = "最近有个自称大表哥的火枪手一直和我们过不去，我的单子都被他截了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_03_moliyadi_cos10",
	NextID = 14402003,
}
StorySpeechConfig[StorySpeechID.Id14402003] =
{
	Id = 14402003,
	CharName = "黑警长",
	Text = "大表哥？他不是那啥了吗？他的枪还在我这儿呢！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_05_jingcha_cos10",
	NextID = 14402004,
}
StorySpeechConfig[StorySpeechID.Id14402004] =
{
	Id = 14402004,
	CharName = "化学博士",
	Text = "比以前那个年轻一点，不过枪法也没差多少。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_03_moliyadi_cos10",
	NextID = 14402005,
}
StorySpeechConfig[StorySpeechID.Id14402005] =
{
	Id = 14402005,
	CharName = "黑警长",
	Text = "你不是请了很多打手吗？拿他没办法吗？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_05_jingcha_cos10",
	NextID = 14402006,
}
StorySpeechConfig[StorySpeechID.Id14402006] =
{
	Id = 14402006,
	CharName = "化学博士",
	Text = "全都被放倒了，他的枪法，怎么说呢……就是你以为他要开枪，但他会跳到你面前，用把手砸你脸。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_03_moliyadi_cos10",
	NextID = 14402007,
}
StorySpeechConfig[StorySpeechID.Id14402007] =
{
	Id = 14402007,
	CharName = "黑警长",
	Text = "这么凶！看来我要亲自会会这个大表哥了。当年我能缴了他的枪，那么今天也一样！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_05_jingcha_cos10",
	NextID = 14402008,
}
StorySpeechConfig[StorySpeechID.Id14402008] =
{
	Id = 14402008,
	CharName = "火枪手",
	Text = "黑警长，你不用找了，我已经来了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_26_huoqiangshou",
}
StorySpeechConfig[StorySpeechID.Id14402101] =
{
	Id = 14402101,
	CharName = "犬寻大师",
	Text = "小鬼，你要走了吗？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_28_heiyiren",
	NextID = 14402102,
}
StorySpeechConfig[StorySpeechID.Id14402102] =
{
	Id = 14402102,
	CharName = "刺客",
	Text = "是的，师傅。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_08_cike",
	NextID = 14402103,
}
StorySpeechConfig[StorySpeechID.Id14402103] =
{
	Id = 14402103,
	CharName = "犬寻大师",
	Text = "外面很危险，出去要小心点。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_28_heiyiren",
	NextID = 14402104,
}
StorySpeechConfig[StorySpeechID.Id14402104] =
{
	Id = 14402104,
	CharName = "刺客",
	Text = "谨遵师傅教诲。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_08_cike",
	NextID = 14402105,
}
StorySpeechConfig[StorySpeechID.Id14402105] =
{
	Id = 14402105,
	CharName = "犬寻大师",
	Text = "那么下山前的最终考验，你准备好了吗？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_28_heiyiren",
	NextID = 14402106,
}
StorySpeechConfig[StorySpeechID.Id14402106] =
{
	Id = 14402106,
	CharName = "刺客",
	Text = "是的，师傅。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_08_cike",
	NextID = 14402107,
}
StorySpeechConfig[StorySpeechID.Id14402107] =
{
	Id = 14402107,
	CharName = "犬寻大师",
	Text = "嗷呜~~~~",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_28_heiyiren",
	NextID = 14402108,
}
StorySpeechConfig[StorySpeechID.Id14402108] =
{
	Id = 14402108,
	CharName = "黑狼头领",
	Text = "嗷！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_blackWolf",
	NextID = 14402109,
}
StorySpeechConfig[StorySpeechID.Id14402109] =
{
	Id = 14402109,
	CharName = "犬寻大师",
	Text = "只要你打败大福头，就下山去吧。以后有困难记得回来找师傅。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_28_heiyiren",
	NextID = 14402110,
}
StorySpeechConfig[StorySpeechID.Id14402110] =
{
	Id = 14402110,
	CharName = "刺客",
	Text = "多谢师傅教诲。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_08_cike",
}
StorySpeechConfig[StorySpeechID.Id14402201] =
{
	Id = 14402201,
	CharName = "暗影大师",
	Text = "今天是小师弟正式加入的日子。大家欢迎一下。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_28_heiyiren",
	NextID = 14402202,
}
StorySpeechConfig[StorySpeechID.Id14402202] =
{
	Id = 14402202,
	CharName = "暗影大师兄",
	Text = "（中气十足）欢迎小师弟！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_08_cike_cos10",
	NextID = 14402203,
}
StorySpeechConfig[StorySpeechID.Id14402203] =
{
	Id = 14402203,
	CharName = "暗影大师",
	Text = "别看我们门派现在这么落魄，当年也是纵横世界的顶级刺客组织。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_28_heiyiren",
	NextID = 14402204,
}
StorySpeechConfig[StorySpeechID.Id14402204] =
{
	Id = 14402204,
	CharName = "暗影大师兄",
	Text = "真的嘛，师傅？我们当年是怎么威风的？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_08_cike_cos10",
	NextID = 14402205,
}
StorySpeechConfig[StorySpeechID.Id14402205] =
{
	Id = 14402205,
	CharName = "暗影大师",
	Text = "你太师傅的太师傅的太师傅，每年的任务单子接到手软，就你们现在天天追着的梨几手机，出一个型号他就能买一个型号的。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_28_heiyiren",
	NextID = 14402206,
}
StorySpeechConfig[StorySpeechID.Id14402206] =
{
	Id = 14402206,
	CharName = "暗影二师兄",
	Text = "哇！这也太任性了吧。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_08_cike_cos10",
	NextID = 14402207,
}
StorySpeechConfig[StorySpeechID.Id14402207] =
{
	Id = 14402207,
	CharName = "暗影大师",
	Text = "有钱嘛~交通卡也是，每次一充就充500块的。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_28_heiyiren",
	NextID = 14402208,
}
StorySpeechConfig[StorySpeechID.Id14402208] =
{
	Id = 14402208,
	CharName = "暗影三师兄",
	Text = "这也太夸张了吧！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_08_cike_cos10",
	NextID = 14402209,
}
StorySpeechConfig[StorySpeechID.Id14402209] =
{
	Id = 14402209,
	CharName = "暗影大师",
	Text = "嘿嘿嘿嘿，毕竟我们都是暗影中的主宰，无光的世界，就是我们的天下啊！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_28_heiyiren",
	NextID = 14402210,
}
StorySpeechConfig[StorySpeechID.Id14402210] =
{
	Id = 14402210,
	CharName = "暗影四师兄",
	Text = "师傅师傅，那我们是怎么落到现在这步田地的？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_08_cike_cos10",
	NextID = 14402211,
}
StorySpeechConfig[StorySpeechID.Id14402211] =
{
	Id = 14402211,
	CharName = "暗影大师",
	Text = "就是它！就是这个东西！又便宜又亮，哪儿都有它！（指向煤气灯）",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_28_heiyiren",
	NextID = 14402212,
}
StorySpeechConfig[StorySpeechID.Id14402212] =
{
	Id = 14402212,
	CharName = "暗影大师兄",
	Text = "哇，实在太可恶了！师傅，让我狠狠扁它一顿出出气。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_08_cike_cos10",
	NextID = 14402213,
}
StorySpeechConfig[StorySpeechID.Id14402213] =
{
	Id = 14402213,
	CharName = "暗影大师",
	Text = "不，今天是小师弟加入的日子，让他来扁这个煤气灯。扁过这个煤气灯，以后我们就是一家人。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_28_heiyiren",
}
StorySpeechConfig[StorySpeechID.Id14401701] =
{
	Id = 14401701,
	CharName = "小队长",
	Text = "小的们，抓住那个怪物！可以当做新副本的招牌怪物！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 14401702,
}
StorySpeechConfig[StorySpeechID.Id14401702] =
{
	Id = 14401702,
	CharName = "骨头兵",
	Text = "是，队长！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_30_kulou",
	NextID = 14401703,
}
StorySpeechConfig[StorySpeechID.Id14401703] =
{
	Id = 14401703,
	CharName = "泥怪头领",
	Text = "牟嗷~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_niannianguai",
	NextID = 14401704,
}
StorySpeechConfig[StorySpeechID.Id14401704] =
{
	Id = 14401704,
	CharName = "骨头兵",
	Text = "队长，弟兄们都因为太滑被击飞了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_30_kulou",
	NextID = 14401705,
}
StorySpeechConfig[StorySpeechID.Id14401705] =
{
	Id = 14401705,
	CharName = "小队长",
	Text = "哇，这么厉害！所以我和你们说，在这里工作就要穿这里的套装！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 14401706,
}
StorySpeechConfig[StorySpeechID.Id14401706] =
{
	Id = 14401706,
	CharName = "骨头兵",
	Text = "怎么办，队长，那个泥怪快要逃跑的样子！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_30_kulou",
	NextID = 14401707,
}
StorySpeechConfig[StorySpeechID.Id14401707] =
{
	Id = 14401707,
	CharName = "小队长",
	Text = "硬着头皮也只能上了！今天开始，在这里上班不穿套装的，年底奖金都扣光！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 14401708,
}
StorySpeechConfig[StorySpeechID.Id14401708] =
{
	Id = 14401708,
	CharName = "骨头兵",
	Text = "是的，队长！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_30_kulou",
}
StorySpeechConfig[StorySpeechID.Id14402701] =
{
	Id = 14402701,
	CharName = "策划A",
	Text = "这个需求很简单！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_13_lvshi",
	NextID = 14402702,
}
StorySpeechConfig[StorySpeechID.Id14402702] =
{
	Id = 14402702,
	CharName = "程序猿",
	Text = "……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_01_chengxuyuan",
	NextID = 14402703,
}
StorySpeechConfig[StorySpeechID.Id14402703] =
{
	Id = 14402703,
	CharName = "策划B",
	Text = "怎么实现我不管！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_13_lvshi",
	NextID = 14402704,
}
StorySpeechConfig[StorySpeechID.Id14402704] =
{
	Id = 14402704,
	CharName = "程序猿",
	Text = "……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_01_chengxuyuan",
	NextID = 14402705,
}
StorySpeechConfig[StorySpeechID.Id14402705] =
{
	Id = 14402705,
	CharName = "策划C",
	Text = "有问题你去找老板！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_13_lvshi",
	NextID = 14402706,
}
StorySpeechConfig[StorySpeechID.Id14402706] =
{
	Id = 14402706,
	CharName = "程序猿",
	Text = "……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_01_chengxuyuan",
}
StorySpeechConfig[StorySpeechID.Id14402801] =
{
	Id = 14402801,
	CharName = "某著名运动品牌商",
	Text = "我们公司主打的是高档潜水服装，听说贵司设计运动品牌很有一套，所以想请你们制作一张宣传海报。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	LeftIcon = "Pir_07_SharkBoss",
	NextID = 14402802,
}
StorySpeechConfig[StorySpeechID.Id14402802] =
{
	Id = 14402802,
	CharName = "美术妹子",
	Text = "好的~那么请问，贵方希望向用户传递一些什么样的信息呢？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_03_yuanhuameizi",
	NextID = 14402803,
}
StorySpeechConfig[StorySpeechID.Id14402803] =
{
	Id = 14402803,
	CharName = "某著名运动品牌商",
	Text = "我们公司宣扬的是鲨性文化，每个员工正式入职都要淘汰2000个员工，所以产品质量很有保障。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	LeftIcon = "Pir_07_SharkBoss",
	NextID = 14402804,
}
StorySpeechConfig[StorySpeechID.Id14402804] =
{
	Id = 14402804,
	CharName = "美术妹子",
	Text = "嗯，这确实是一个不错的角度，不过可以具体说一下员工选拔和产品之间的关系吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_03_yuanhuameizi",
	NextID = 14402805,
}
StorySpeechConfig[StorySpeechID.Id14402805] =
{
	Id = 14402805,
	CharName = "某著名运动品牌商",
	Text = "啊，是这样，我们的员工都是从附近海域的鲨鱼中精心选拔出来的，除了身体健康外，样貌也都非常出众。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	LeftIcon = "Pir_07_SharkBoss",
	NextID = 14402806,
}
StorySpeechConfig[StorySpeechID.Id14402806] =
{
	Id = 14402806,
	CharName = "美术妹子",
	Text = "嗯，嗯，那确实不错。那么我们的产品主要有哪些卖点，或者说从设计到制作会经过哪些特别的步骤呢？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_03_yuanhuameizi",
	NextID = 14402807,
}
StorySpeechConfig[StorySpeechID.Id14402807] =
{
	Id = 14402807,
	CharName = "某著名运动品牌商",
	Text = "你是不是不耐烦了？",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	LeftIcon = "Pir_07_SharkBoss",
	NextID = 14402808,
}
StorySpeechConfig[StorySpeechID.Id14402808] =
{
	Id = 14402808,
	CharName = "美术妹子",
	Text = "！？不，不，不，您是尊贵的客户，而且我们正在沟通产品，我完全没有不耐烦。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_03_yuanhuameizi",
	NextID = 14402809,
}
StorySpeechConfig[StorySpeechID.Id14402809] =
{
	Id = 14402809,
	CharName = "某著名运动品牌商",
	Text = "嘶，你就是不耐烦了！",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	LeftIcon = "Pir_07_SharkBoss",
	NextID = 14402810,
}
StorySpeechConfig[StorySpeechID.Id14402810] =
{
	Id = 14402810,
	CharName = "美术妹子",
	Text = "……先生，我们还是讲回产品吧。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_03_yuanhuameizi",
	NextID = 14402811,
}
StorySpeechConfig[StorySpeechID.Id14402811] =
{
	Id = 14402811,
	CharName = "某著名运动品牌商",
	Text = "我和你讲情绪，你和我讲产品？",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	LeftIcon = "Pir_07_SharkBoss",
	NextID = 14402812,
}
StorySpeechConfig[StorySpeechID.Id14402812] =
{
	Id = 14402812,
	CharName = "美术妹子",
	Text = "这……先生，我们今天来本来就是要讲产品宣传的。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_03_yuanhuameizi",
	NextID = 14402813,
}
StorySpeechConfig[StorySpeechID.Id14402813] =
{
	Id = 14402813,
	CharName = "某著名运动品牌商",
	Text = "嘶，你信不信我一口吞掉你？",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	LeftIcon = "Pir_07_SharkBoss",
	NextID = 14402814,
}
StorySpeechConfig[StorySpeechID.Id14402814] =
{
	Id = 14402814,
	CharName = "美术妹子",
	Text = "-_-|||先生，你不要看我是一个女孩子，你就想动用蛮力。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_03_yuanhuameizi",
	NextID = 14402815,
}
StorySpeechConfig[StorySpeechID.Id14402815] =
{
	Id = 14402815,
	CharName = "某著名运动品牌商",
	Text = "怎么？！还要和我动手？来呀，今天不是我吃了你，就是被你做成鲨皮潜水衣！",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	LeftIcon = "Pir_07_SharkBoss",
}
StorySpeechConfig[StorySpeechID.Id14402901] =
{
	Id = 14402901,
	CharName = "配音演员",
	Text = "以上就是猫总管创作的大型舞台剧，《诅咒记》，谢谢观赏。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_15_peiyinyanyuan",
	NextID = 14402902,
}
StorySpeechConfig[StorySpeechID.Id14402902] =
{
	Id = 14402902,
	CharName = "大魔王",
	Text = "（鞠躬）我是美杜莎的扮演者。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_11_damowang",
	NextID = 14402903,
}
StorySpeechConfig[StorySpeechID.Id14402903] =
{
	Id = 14402903,
	CharName = "智慧女神",
	Text = "（鞠躬）我是密涅瓦的扮演者。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_06_bingmayong_cos10",
	NextID = 14402904,
}
StorySpeechConfig[StorySpeechID.Id14402904] =
{
	Id = 14402904,
	CharName = "两栖小妖",
	Text = "（鞠躬）我是波塞冬的扮演者。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_13_dashouxiaodi_cos10",
	NextID = 14402905,
}
StorySpeechConfig[StorySpeechID.Id14402905] =
{
	Id = 14402905,
	CharName = "默艾",
	Text = "（想鞠躬但弯不下来……）我是被石化的无名英雄甲。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_07_fuhuoshixiang",
	NextID = 14402906,
}
StorySpeechConfig[StorySpeechID.Id14402906] =
{
	Id = 14402906,
	CharName = "兵马俑",
	Text = "（想鞠躬也弯不下来……）我是被石化的无名英雄乙。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_06_bingmayong",
	NextID = 14402907,
}
StorySpeechConfig[StorySpeechID.Id14402907] =
{
	Id = 14402907,
	CharName = "配音演员",
	Text = "以上是主演的自我介绍，再次感谢观赏。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_15_peiyinyanyuan",
	NextID = 14402908,
}
StorySpeechConfig[StorySpeechID.Id14402908] =
{
	Id = 14402908,
	CharName = "大魔王",
	Text = "演出不错，大家辛苦了。那么，这套美杜莎的衣服我带回去了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_11_damowang",
	NextID = 14402909,
}
StorySpeechConfig[StorySpeechID.Id14402909] =
{
	Id = 14402909,
	CharName = "智慧女神",
	Text = "不行！这套衣服我也喜欢！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_06_bingmayong_cos10",
	NextID = 14402910,
}
StorySpeechConfig[StorySpeechID.Id14402910] =
{
	Id = 14402910,
	CharName = "大魔王",
	Text = "你喜欢和我有关系吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_11_damowang",
	NextID = 14402911,
}
StorySpeechConfig[StorySpeechID.Id14402911] =
{
	Id = 14402911,
	CharName = "智慧女神",
	Text = "大魔王！你不要太嚣张，你以为你是彩色品质的英雄，我就怕你吗？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_06_bingmayong_cos10",
	NextID = 14402912,
}
StorySpeechConfig[StorySpeechID.Id14402912] =
{
	Id = 14402912,
	CharName = "大魔王",
	Text = "我不和灰色品质角色打架。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_11_damowang",
	NextID = 14402913,
}
StorySpeechConfig[StorySpeechID.Id14402913] =
{
	Id = 14402913,
	CharName = "智慧女神",
	Text = "今天我必须教训你一下！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_06_bingmayong_cos10",
}
StorySpeechConfig[StorySpeechID.Id14403001] =
{
	Id = 14403001,
	CharName = "小魔王",
	Text = "董事长，一个旅行商人为我们带来了那件宝具的消息。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_12_xiaomowang",
	NextID = 14403002,
}
StorySpeechConfig[StorySpeechID.Id14403002] =
{
	Id = 14403002,
	CharName = "大魔王",
	Text = "有点意思，让他来见我。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_11_damowang",
	NextID = 14403003,
}
StorySpeechConfig[StorySpeechID.Id14403003] =
{
	Id = 14403003,
	CharName = "旅行商人",
	Text = "您好，尊敬的魔王大人，听说您一直在寻找末日战甲。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_14_lvxingshangren",
	NextID = 14403004,
}
StorySpeechConfig[StorySpeechID.Id14403004] =
{
	Id = 14403004,
	CharName = "大魔王",
	Text = "你知道它在哪里吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_11_damowang",
	NextID = 14403005,
}
StorySpeechConfig[StorySpeechID.Id14403005] =
{
	Id = 14403005,
	CharName = "旅行商人",
	Text = "是的，大人，小的无意间得知了它的所在，因此前来禀报。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_14_lvxingshangren",
	NextID = 14403006,
}
StorySpeechConfig[StorySpeechID.Id14403006] =
{
	Id = 14403006,
	CharName = "大魔王",
	Text = "我想没有点回报，你不愿轻易开口。来人，赏！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_11_damowang",
	NextID = 14403007,
}
StorySpeechConfig[StorySpeechID.Id14403007] =
{
	Id = 14403007,
	CharName = "小魔王",
	Text = "（掏出1亿星际金币给旅行商人）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_12_xiaomowang",
	NextID = 14403008,
}
StorySpeechConfig[StorySpeechID.Id14403008] =
{
	Id = 14403008,
	CharName = "旅行商人",
	Text = "（OTZ）感谢大王，小人这就禀告。这件战甲现在正藏在名为地狱的火山之中。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_14_lvxingshangren",
	NextID = 14403009,
}
StorySpeechConfig[StorySpeechID.Id14403009] =
{
	Id = 14403009,
	CharName = "大魔王",
	Text = "如此秘密的所在，你是如何知道的？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_11_damowang",
	NextID = 14403010,
}
StorySpeechConfig[StorySpeechID.Id14403010] =
{
	Id = 14403010,
	CharName = "旅行商人",
	Text = "小人本想采些火山的稀有药草，无意间发现一处洞穴，门口睡了头地狱火龙，我悄悄溜进去看了一眼，发现末日战甲正在其中。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_14_lvxingshangren",
	NextID = 14403011,
}
StorySpeechConfig[StorySpeechID.Id14403011] =
{
	Id = 14403011,
	CharName = "大魔王",
	Text = "非常好，这件宝具从我魔族手中遗失多年，如今由我找回，必能了了父辈们的心愿。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_11_damowang",
	NextID = 14403012,
}
StorySpeechConfig[StorySpeechID.Id14403012] =
{
	Id = 14403012,
	CharName = "旅行商人",
	Text = "大王法力通天，无人能敌，千秋万载，一统地城。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_14_lvxingshangren",
	NextID = 14403013,
}
StorySpeechConfig[StorySpeechID.Id14403013] =
{
	Id = 14403013,
	CharName = "大魔王",
	Text = "那就开个传送门，大家随我一同去火山瞧瞧。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_11_damowang",
}
StorySpeechConfig[StorySpeechID.Id14403101] =
{
	Id = 14403101,
	CharName = "小队长",
	Text = "接下来是第三季度的数据报告。副本二次进入率3%，通关率0%，好评0.2%，中评，0.6%，差评99.2%。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 14403102,
}
StorySpeechConfig[StorySpeechID.Id14403102] =
{
	Id = 14403102,
	CharName = "大魔王",
	Text = "总经理，你的看法？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_11_damowang",
	NextID = 14403103,
}
StorySpeechConfig[StorySpeechID.Id14403103] =
{
	Id = 14403103,
	CharName = "小魔王",
	Text = "报告董事长，根据冒险者投诉反馈，这次副本难度设计得特别不合理。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_12_xiaomowang",
	NextID = 14403104,
}
StorySpeechConfig[StorySpeechID.Id14403104] =
{
	Id = 14403104,
	CharName = "大魔王",
	Text = "怎么回事？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_11_damowang",
	NextID = 14403105,
}
StorySpeechConfig[StorySpeechID.Id14403105] =
{
	Id = 14403105,
	CharName = "小魔王",
	Text = "副本编剧这次说要搞点事情，活跃一下气氛，然后……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_12_xiaomowang",
	NextID = 14403106,
}
StorySpeechConfig[StorySpeechID.Id14403106] =
{
	Id = 14403106,
	CharName = "大魔王",
	Text = "为什么第一周接到反馈后不修复？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_11_damowang",
	NextID = 14403107,
}
StorySpeechConfig[StorySpeechID.Id14403107] =
{
	Id = 14403107,
	CharName = "小魔王",
	Text = "编剧挺坚持的，说副本不搞得难一点会很无聊。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_12_xiaomowang",
	NextID = 14403108,
}
StorySpeechConfig[StorySpeechID.Id14403108] =
{
	Id = 14403108,
	CharName = "大魔王",
	Text = "让编剧来参加会议。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_11_damowang",
	NextID = 14403109,
}
StorySpeechConfig[StorySpeechID.Id14403109] =
{
	Id = 14403109,
	CharName = "骨头兵",
	Text = "是！（把编剧带到）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_30_kulou",
	NextID = 14403110,
}
StorySpeechConfig[StorySpeechID.Id14403110] =
{
	Id = 14403110,
	CharName = "编剧",
	Text = "董事长，经理。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng_cos10",
	NextID = 14403111,
}
StorySpeechConfig[StorySpeechID.Id14403111] =
{
	Id = 14403111,
	CharName = "大魔王",
	Text = "编剧先生，这次副本反馈很糟糕，你需要尽快调整一下。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_11_damowang",
	NextID = 14403112,
}
StorySpeechConfig[StorySpeechID.Id14403112] =
{
	Id = 14403112,
	CharName = "编剧",
	Text = "这不可能，就算开除我，我也不会让你们修改副本难度的！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng_cos10",
	NextID = 14403113,
}
StorySpeechConfig[StorySpeechID.Id14403113] =
{
	Id = 14403113,
	CharName = "大魔王",
	Text = "保安，把他带走！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_11_damowang",
	NextID = 14403114,
}
StorySpeechConfig[StorySpeechID.Id14403114] =
{
	Id = 14403114,
	CharName = "骨头兵",
	Text = "是！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_30_kulou",
	NextID = 14403115,
}
StorySpeechConfig[StorySpeechID.Id14403115] =
{
	Id = 14403115,
	CharName = "编剧",
	Text = "吓！看来是我展现真功夫的时候了！嚯！（用掌力振飞了所有骨头兵）",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_20_lanyixiaoxuesheng_cos10",
	NextID = 14403116,
}
StorySpeechConfig[StorySpeechID.Id14403116] =
{
	Id = 14403116,
	CharName = "小魔王",
	Text = "放肆！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_12_xiaomowang",
	NextID = 14403117,
}
StorySpeechConfig[StorySpeechID.Id14403117] =
{
	Id = 14403117,
	CharName = "编剧",
	Text = "呀！（一回合，击晕小魔王）",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_20_lanyixiaoxuesheng_cos10",
	NextID = 14403118,
}
StorySpeechConfig[StorySpeechID.Id14403118] =
{
	Id = 14403118,
	CharName = "大魔王",
	Text = "看来要我亲自出手了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_11_damowang",
}
StorySpeechConfig[StorySpeechID.Id14402301] =
{
	Id = 14402301,
	CharName = "牧师",
	Text = "站住！这么晚了，你们在牧场干什么？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_07_mushi",
	NextID = 14402302,
}
StorySpeechConfig[StorySpeechID.Id14402302] =
{
	Id = 14402302,
	CharName = "浣熊大哥",
	Text = "我们……我们是来洗澡的……",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_13_dage",
	NextID = 14402303,
}
StorySpeechConfig[StorySpeechID.Id14402303] =
{
	Id = 14402303,
	CharName = "牧师",
	Text = "晚上来牧场洗澡，听起来很可疑呢！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_07_mushi",
	NextID = 14402304,
}
StorySpeechConfig[StorySpeechID.Id14402304] =
{
	Id = 14402304,
	CharName = "浣熊大哥",
	Text = "（尴尬地看着你）",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_13_dage",
	NextID = 14402305,
}
StorySpeechConfig[StorySpeechID.Id14402305] =
{
	Id = 14402305,
	CharName = "浣熊二哥",
	Text = "（不安地看着地上）",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_14_erge",
	NextID = 14402306,
}
StorySpeechConfig[StorySpeechID.Id14402306] =
{
	Id = 14402306,
	CharName = "浣熊小弟",
	Text = "（假装在看天上）",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_15_xiaodi",
	NextID = 14402307,
}
StorySpeechConfig[StorySpeechID.Id14402307] =
{
	Id = 14402307,
	CharName = "牧师",
	Text = "哎呀，那牛奶龙头怎么开着！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_07_mushi",
	NextID = 14402308,
}
StorySpeechConfig[StorySpeechID.Id14402308] =
{
	Id = 14402308,
	CharName = "浣熊大哥",
	Text = "（扭头就走）",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_13_dage",
	NextID = 14402309,
}
StorySpeechConfig[StorySpeechID.Id14402309] =
{
	Id = 14402309,
	CharName = "牧师",
	Text = "（一把抓住尾巴）原来就是你们浪费牛奶，走，跟我去见农场主！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_07_mushi",
	NextID = 14402310,
}
StorySpeechConfig[StorySpeechID.Id14402310] =
{
	Id = 14402310,
	CharName = "浣熊二哥",
	Text = "（超凶地挥舞爪子）",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_14_erge",
	NextID = 14402311,
}
StorySpeechConfig[StorySpeechID.Id14402311] =
{
	Id = 14402311,
	CharName = "牧师",
	Text = "看来要好好教训你们一下了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_07_mushi",
}
StorySpeechConfig[StorySpeechID.Id14402401] =
{
	Id = 14402401,
	CharName = "医生",
	Text = "冒险星的各位朋友，大家好，今天是补血大讲堂第一次在冒险星举办。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_04_fayi",
	NextID = 14402402,
}
StorySpeechConfig[StorySpeechID.Id14402402] =
{
	Id = 14402402,
	CharName = "村长",
	Text = "（鼓掌）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye",
	NextID = 14402403,
}
StorySpeechConfig[StorySpeechID.Id14402403] =
{
	Id = 14402403,
	CharName = "居民NPC",
	Text = "（鼓掌）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_09_putongcunmin",
	NextID = 14402404,
}
StorySpeechConfig[StorySpeechID.Id14402404] =
{
	Id = 14402404,
	CharName = "医生",
	Text = "我知道这里补血是不讲科学的。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_04_fayi",
	NextID = 14402405,
}
StorySpeechConfig[StorySpeechID.Id14402405] =
{
	Id = 14402405,
	CharName = "骨头兵",
	Text = "（鼓掌）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_30_kulou",
	NextID = 14402406,
}
StorySpeechConfig[StorySpeechID.Id14402406] =
{
	Id = 14402406,
	CharName = "医生",
	Text = "但是在我们星球，科学家们已经找到了补血的根本原理了。大家看这个！（指向一摊血）",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_04_fayi",
	NextID = 14402407,
}
StorySpeechConfig[StorySpeechID.Id14402407] =
{
	Id = 14402407,
	CharName = "一摊血",
	Text = "大家好，我就是在大家身体里流淌，提供大家生命活力的物质。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	LeftIcon = "SUS_Blood",
	NextID = 14402408,
}
StorySpeechConfig[StorySpeechID.Id14402408] =
{
	Id = 14402408,
	CharName = "剑士",
	Text = "噢，原来这东西长这样啊！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 14402409,
}
StorySpeechConfig[StorySpeechID.Id14402409] =
{
	Id = 14402409,
	CharName = "医生",
	Text = "对，听说冒险星恢复还是靠牧师的，那么为了更好地补血，我建议牧师能够克服对它的恐惧。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_04_fayi",
	NextID = 14402410,
}
StorySpeechConfig[StorySpeechID.Id14402410] =
{
	Id = 14402410,
	CharName = "牧师",
	Text = "好~要怎么做呢？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_07_mushi",
	NextID = 14402411,
}
StorySpeechConfig[StorySpeechID.Id14402411] =
{
	Id = 14402411,
	CharName = "医生",
	Text = "你打它一顿吧，然后我送你一套护士服，以后你就能给大家科学补血了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_04_fayi",
}
StorySpeechConfig[StorySpeechID.Id14403201] =
{
	Id = 14403201,
	CharName = "北境龙骑士",
	Text = "哟呵！年轻人，你就是那个来自王国地区的龙骑士吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_25_longqishi_cos10",
	NextID = 14403202,
}
StorySpeechConfig[StorySpeechID.Id14403202] =
{
	Id = 14403202,
	CharName = "龙骑士",
	Text = "是的，长老。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_25_longqishi",
	NextID = 14403203,
}
StorySpeechConfig[StorySpeechID.Id14403203] =
{
	Id = 14403203,
	CharName = "北境龙骑士",
	Text = "不必这么客气~因为我年轻时骑着我那条龙靠一把冬之枪就消灭了末日火山的龙族，所以大家都叫我——骑个龙.冬枪。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_25_longqishi_cos10",
	NextID = 14403204,
}
StorySpeechConfig[StorySpeechID.Id14403204] =
{
	Id = 14403204,
	CharName = "龙骑士",
	Text = "希望我也能有你这样的实力。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_25_longqishi",
	NextID = 14403205,
}
StorySpeechConfig[StorySpeechID.Id14403205] =
{
	Id = 14403205,
	CharName = "骑个龙冬枪",
	Text = "哎，不过这次我写信让你父亲派个人给我不是没有原因的。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_25_longqishi_cos10",
	NextID = 14403206,
}
StorySpeechConfig[StorySpeechID.Id14403206] =
{
	Id = 14403206,
	CharName = "龙骑士",
	Text = "愿闻其详。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_25_longqishi",
	NextID = 14403207,
}
StorySpeechConfig[StorySpeechID.Id14403207] =
{
	Id = 14403207,
	CharName = "骑个龙冬枪",
	Text = "末日火山又一次震动了，新的哥斯火拉们开始蠢蠢欲动，不过我老了，得找个年轻的战士去消灭那些恶龙了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_25_longqishi_cos10",
	NextID = 14403208,
}
StorySpeechConfig[StorySpeechID.Id14403208] =
{
	Id = 14403208,
	CharName = "龙骑士",
	Text = "请交给我吧，长老，我不会让你失望的。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_25_longqishi",
}
StorySpeechConfig[StorySpeechID.Id14403301] =
{
	Id = 14403301,
	CharName = "龙骑士",
	Text = "（打字）掌柜的~在吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_25_longqishi",
	NextID = 14403302,
}
StorySpeechConfig[StorySpeechID.Id14403302] =
{
	Id = 14403302,
	CharName = "铁匠",
	Text = "在噢~亲~请问有什么需要帮助的嘛？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_31_tiejiang",
	NextID = 14403303,
}
StorySpeechConfig[StorySpeechID.Id14403303] =
{
	Id = 14403303,
	CharName = "龙骑士",
	Text = "我前年11月份订的麒麟天装代工制作，可以出货了吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_25_longqishi",
	NextID = 14403304,
}
StorySpeechConfig[StorySpeechID.Id14403304] =
{
	Id = 14403304,
	CharName = "铁匠",
	Text = "还没搞定噢~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_31_tiejiang",
	NextID = 14403305,
}
StorySpeechConfig[StorySpeechID.Id14403305] =
{
	Id = 14403305,
	CharName = "龙骑士",
	Text = "有没有最近的进度图看一下呢？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_25_longqishi",
	NextID = 14403306,
}
StorySpeechConfig[StorySpeechID.Id14403306] =
{
	Id = 14403306,
	CharName = "铁匠",
	Text = "现在看图要加钱噢~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_31_tiejiang",
	NextID = 14403307,
}
StorySpeechConfig[StorySpeechID.Id14403307] =
{
	Id = 14403307,
	CharName = "龙骑士",
	Text = "之前订单上说，保价保工期的，说最晚今天就能交货的。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_25_longqishi",
	NextID = 14403308,
}
StorySpeechConfig[StorySpeechID.Id14403308] =
{
	Id = 14403308,
	CharName = "铁匠",
	Text = "计划赶不上变化噢~亲，最近行情都涨了，今晚发货要大把地加钱噢~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_31_tiejiang",
	NextID = 14403309,
}
StorySpeechConfig[StorySpeechID.Id14403309] =
{
	Id = 14403309,
	CharName = "龙骑士",
	Text = "掌柜的，你这么不守信用，信不信我顺着网线过去打你？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_25_longqishi",
	NextID = 14403310,
}
StorySpeechConfig[StorySpeechID.Id14403310] =
{
	Id = 14403310,
	CharName = "铁匠",
	Text = "不信噢~亲~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_31_tiejiang",
	NextID = 14403311,
}
StorySpeechConfig[StorySpeechID.Id14403311] =
{
	Id = 14403311,
	CharName = "龙骑士",
	Text = "（敲门）你是不是打算坑掉我的材料，掌柜？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_25_longqishi",
	NextID = 14403312,
}
StorySpeechConfig[StorySpeechID.Id14403312] =
{
	Id = 14403312,
	CharName = "铁匠",
	Text = "怎么会呢？不过加钱就能立刻发货了~（听到敲门声）稍等一下，我去开个门~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_31_tiejiang",
	NextID = 14403313,
}
StorySpeechConfig[StorySpeechID.Id14403313] =
{
	Id = 14403313,
	CharName = "龙骑士",
	Text = "（出现在门口）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_25_longqishi",
	NextID = 14403314,
}
StorySpeechConfig[StorySpeechID.Id14403314] =
{
	Id = 14403314,
	CharName = "铁匠",
	Text = "真的顺着网线过来了！！诶……亲，装备已经做好了，不过做得真的蛮辛苦的，可以加钱吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_31_tiejiang",
	NextID = 14403315,
}
StorySpeechConfig[StorySpeechID.Id14403315] =
{
	Id = 14403315,
	CharName = "龙骑士",
	Text = "不可！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_25_longqishi",
	NextID = 14403316,
}
StorySpeechConfig[StorySpeechID.Id14403316] =
{
	Id = 14403316,
	CharName = "铁匠",
	Text = "那你就踩着我进去自己找你的装备吧！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_31_tiejiang",
}
StorySpeechConfig[StorySpeechID.Id14403401] =
{
	Id = 14403401,
	CharName = "电视台",
	Text = "（电视台上正在播放最近在冒险星非常流行的外星节目《哪吒闹海》的大结局）",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	LeftIcon = "Equipment_Rpg_11_damowang_2",
	NextID = 14403402,
}
StorySpeechConfig[StorySpeechID.Id14403402] =
{
	Id = 14403402,
	CharName = "黑龙王子",
	Text = "（一边抹眼泪一边看）嗷……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_23_long",
	NextID = 14403403,
}
StorySpeechConfig[StorySpeechID.Id14403403] =
{
	Id = 14403403,
	CharName = "龙骑士",
	Text = "（强忍住眼泪，一声不吭）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_25_longqishi",
	NextID = 14403404,
}
StorySpeechConfig[StorySpeechID.Id14403404] =
{
	Id = 14403404,
	CharName = "电视台",
	Text = "（播放结束，滚演员名单）",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	RightIcon = "Equipment_Rpg_11_damowang_2",
	NextID = 14403405,
}
StorySpeechConfig[StorySpeechID.Id14403405] =
{
	Id = 14403405,
	CharName = "龙骑士",
	Text = "太好看了，剧情太感人了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_25_longqishi",
	NextID = 14403406,
}
StorySpeechConfig[StorySpeechID.Id14403406] =
{
	Id = 14403406,
	CharName = "黑龙王子",
	Text = "为什么好人最后结局都这么惨……嗷？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_23_long",
	NextID = 14403407,
}
StorySpeechConfig[StorySpeechID.Id14403407] =
{
	Id = 14403407,
	CharName = "龙骑士",
	Text = "英雄总是要承担很多责任的，以后我长大了说不定也有不能对抗的命运……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_25_longqishi",
	NextID = 14403408,
}
StorySpeechConfig[StorySpeechID.Id14403408] =
{
	Id = 14403408,
	CharName = "黑龙王子",
	Text = "嗷？听说你会和你的哥哥们一样，整天欺负我们龙族嗷！？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_23_long",
	NextID = 14403409,
}
StorySpeechConfig[StorySpeechID.Id14403409] =
{
	Id = 14403409,
	CharName = "龙骑士",
	Text = "我不会的，我和你是最好的朋友。（摸黑龙王子的角）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_25_longqishi",
	NextID = 14403410,
}
StorySpeechConfig[StorySpeechID.Id14403410] =
{
	Id = 14403410,
	CharName = "黑龙王子",
	Text = "你最好了，龙骑士~我们来扮演里面的角色玩，然后改写一下最后的结局，嗷？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_23_long",
	NextID = 14403411,
}
StorySpeechConfig[StorySpeechID.Id14403411] =
{
	Id = 14403411,
	CharName = "龙骑士",
	Text = "好！（拿出带来的戏服，准备扮演哪吒）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_25_longqishi",
	NextID = 14403412,
}
StorySpeechConfig[StorySpeechID.Id14403412] =
{
	Id = 14403412,
	CharName = "黑龙王子",
	Text = "嗷~~~哪吒太坏了，三太子真可怜。（拿出家里的戏服，准备扮演三太子）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_23_long",
	NextID = 14403413,
}
StorySpeechConfig[StorySpeechID.Id14403413] =
{
	Id = 14403413,
	CharName = "龙骑士",
	Text = "你刚刚是说哪吒是坏人吗？（表情冷漠）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_25_longqishi",
	NextID = 14403414,
}
StorySpeechConfig[StorySpeechID.Id14403414] =
{
	Id = 14403414,
	CharName = "黑龙王子",
	Text = "嗷？哪吒不是大反派吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_23_long",
	NextID = 14403415,
}
StorySpeechConfig[StorySpeechID.Id14403415] =
{
	Id = 14403415,
	CharName = "龙骑士",
	Text = "原来你是要这样改写结局啊？（夺过三太子的戏服撕掉）我让你改！我让你改！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_25_longqishi",
	NextID = 14403416,
}
StorySpeechConfig[StorySpeechID.Id14403416] =
{
	Id = 14403416,
	CharName = "黑龙王子",
	Text = "啊！！！不要弄坏我的戏服，我做了好久的嗷~~唬！我要打你了嗷！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_23_long",
}
StorySpeechConfig[StorySpeechID.Id14403501] =
{
	Id = 14403501,
	CharName = "黑龙王子",
	Text = "嘿嘿，守卫没看见，可以溜进城市去吃烤肉了~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_23_long",
	NextID = 14403502,
}
StorySpeechConfig[StorySpeechID.Id14403502] =
{
	Id = 14403502,
	CharName = "算命商人",
	Text = "龙王陛下。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_14_lvxingshangren_cos10",
	NextID = 14403503,
}
StorySpeechConfig[StorySpeechID.Id14403503] =
{
	Id = 14403503,
	CharName = "黑龙王子",
	Text = "（环顾四周）你在叫谁？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_23_long",
	NextID = 14403504,
}
StorySpeechConfig[StorySpeechID.Id14403504] =
{
	Id = 14403504,
	CharName = "算命商人",
	Text = "我在叫你，龙王陛下。你可忘了千年前此地茶铺的赌约？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_14_lvxingshangren_cos10",
	NextID = 14403505,
}
StorySpeechConfig[StorySpeechID.Id14403505] =
{
	Id = 14403505,
	CharName = "黑龙王子",
	Text = "嗷？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_23_long",
	NextID = 14403506,
}
StorySpeechConfig[StorySpeechID.Id14403506] =
{
	Id = 14403506,
	CharName = "算命商人",
	Text = "看来陛下烤肉吃太多，堵了灵识了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_14_lvxingshangren_cos10",
	NextID = 14403507,
}
StorySpeechConfig[StorySpeechID.Id14403507] =
{
	Id = 14403507,
	CharName = "黑龙王子",
	Text = "不听！我要去吃烤肉了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_23_long",
	NextID = 14403508,
}
StorySpeechConfig[StorySpeechID.Id14403508] =
{
	Id = 14403508,
	CharName = "算命商人",
	Text = "我站在这儿，你就别想过去！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_14_lvxingshangren_cos10",
	NextID = 14403509,
}
StorySpeechConfig[StorySpeechID.Id14403509] =
{
	Id = 14403509,
	CharName = "黑龙王子",
	Text = "嚎！快让开，否则我咬你了嗷！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_23_long",
	NextID = 14403510,
}
StorySpeechConfig[StorySpeechID.Id14403510] =
{
	Id = 14403510,
	CharName = "算命商人",
	Text = "我前生多嘴，害你上了剐龙台，今日我怎么都要帮你恢复神识！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_14_lvxingshangren_cos10",
}
StorySpeechConfig[StorySpeechID.Id14403601] =
{
	Id = 14403601,
	CharName = "女王大人",
	Text = "来福，最近好想出去玩啊。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_21_nvwangdaren",
	NextID = 14403602,
}
StorySpeechConfig[StorySpeechID.Id14403602] =
{
	Id = 14403602,
	CharName = "来福",
	Text = "汪！",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	RightIcon = "Equipment_Rpg_21_nvwangdaren_2",
	NextID = 14403603,
}
StorySpeechConfig[StorySpeechID.Id14403603] =
{
	Id = 14403603,
	CharName = "女王大人",
	Text = "那我们想办法溜出去？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_21_nvwangdaren",
	NextID = 14403604,
}
StorySpeechConfig[StorySpeechID.Id14403604] =
{
	Id = 14403604,
	CharName = "来福",
	Text = "（尾巴一直在摇）汪！",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	RightIcon = "Equipment_Rpg_21_nvwangdaren_2",
	NextID = 14403605,
}
StorySpeechConfig[StorySpeechID.Id14403605] =
{
	Id = 14403605,
	CharName = "女王大人",
	Text = "今天晚上连月亮都没有，我们趁黑溜出去吧？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_21_nvwangdaren",
	NextID = 14403606,
}
StorySpeechConfig[StorySpeechID.Id14403606] =
{
	Id = 14403606,
	CharName = "来福",
	Text = "汪！汪！",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	RightIcon = "Equipment_Rpg_21_nvwangdaren_2",
	NextID = 14403607,
}
StorySpeechConfig[StorySpeechID.Id14403607] =
{
	Id = 14403607,
	CharName = "女王大人",
	Text = "如果要趁黑溜出去的话，得换一身黑衣服才好。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_21_nvwangdaren",
	NextID = 14403608,
}
StorySpeechConfig[StorySpeechID.Id14403608] =
{
	Id = 14403608,
	CharName = "来福",
	Text = "（点头）",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	RightIcon = "Equipment_Rpg_21_nvwangdaren_2",
	NextID = 14403609,
}
StorySpeechConfig[StorySpeechID.Id14403609] =
{
	Id = 14403609,
	CharName = "女王大人",
	Text = "不过从卧室去更衣室有个很厉害的守卫看着，要换夜行衣的话，得先把他打晕！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_21_nvwangdaren",
}
StorySpeechConfig[StorySpeechID.Id14403701] =
{
	Id = 14403701,
	CharName = "女王大人",
	Text = "来福，最近好想出去玩啊。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_21_nvwangdaren",
	NextID = 14403702,
}
StorySpeechConfig[StorySpeechID.Id14403702] =
{
	Id = 14403702,
	CharName = "来福",
	Text = "汪！",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	RightIcon = "Equipment_Rpg_21_nvwangdaren_2",
	NextID = 14403703,
}
StorySpeechConfig[StorySpeechID.Id14403703] =
{
	Id = 14403703,
	CharName = "女王大人",
	Text = "那我们想办法溜出去？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_21_nvwangdaren",
	NextID = 14403704,
}
StorySpeechConfig[StorySpeechID.Id14403704] =
{
	Id = 14403704,
	CharName = "来福",
	Text = "（尾巴一直在摇）汪！",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	RightIcon = "Equipment_Rpg_21_nvwangdaren_2",
	NextID = 14403705,
}
StorySpeechConfig[StorySpeechID.Id14403705] =
{
	Id = 14403705,
	CharName = "女王大人",
	Text = "今天正午的阳光晃得大家睁不开眼，我们趁机溜出去吧？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_21_nvwangdaren",
	NextID = 14403706,
}
StorySpeechConfig[StorySpeechID.Id14403706] =
{
	Id = 14403706,
	CharName = "来福",
	Text = "汪！汪！",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	RightIcon = "Equipment_Rpg_21_nvwangdaren_2",
	NextID = 14403707,
}
StorySpeechConfig[StorySpeechID.Id14403707] =
{
	Id = 14403707,
	CharName = "女王大人",
	Text = "如果要趁机溜出去的话，得换一身闪闪的衣服才好。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_21_nvwangdaren",
	NextID = 14403708,
}
StorySpeechConfig[StorySpeechID.Id14403708] =
{
	Id = 14403708,
	CharName = "来福",
	Text = "（点头）",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	RightIcon = "Equipment_Rpg_21_nvwangdaren_2",
	NextID = 14403709,
}
StorySpeechConfig[StorySpeechID.Id14403709] =
{
	Id = 14403709,
	CharName = "女王大人",
	Text = "不过从卧室去更衣室有个很厉害的守卫看着，要换闪闪礼服的话，得先把他打晕！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_21_nvwangdaren",
}
StorySpeechConfig[StorySpeechID.Id14403801] =
{
	Id = 14403801,
	CharName = "皇家卫兵",
	Text = "报！女王陛下，今天登基大典用的礼服被偷走了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_17_chengzhenweibing_cos10",
	NextID = 14403802,
}
StorySpeechConfig[StorySpeechID.Id14403802] =
{
	Id = 14403802,
	CharName = "女王大人",
	Text = "（开心）那就重新制作一套，登基大典推迟吧~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_21_nvwangdaren",
	NextID = 14403803,
}
StorySpeechConfig[StorySpeechID.Id14403803] =
{
	Id = 14403803,
	CharName = "皇家卫兵",
	Text = "女王大人……你是不是不想举办登基大典？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_17_chengzhenweibing_cos10",
	NextID = 14403804,
}
StorySpeechConfig[StorySpeechID.Id14403804] =
{
	Id = 14403804,
	CharName = "女王大人",
	Text = "哎，好吧……登基以后感觉会被管得很紧……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_21_nvwangdaren",
	NextID = 14403805,
}
StorySpeechConfig[StorySpeechID.Id14403805] =
{
	Id = 14403805,
	CharName = "皇家卫兵",
	Text = "女王大人，这里是冒险星球，设定上你一出去就是要被魔王集团绑架，然后被勇者救回来的。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_17_chengzhenweibing_cos10",
	NextID = 14403806,
}
StorySpeechConfig[StorySpeechID.Id14403806] =
{
	Id = 14403806,
	CharName = "女王大人",
	Text = "哎，所以登基不登基也没有什么所谓，反正加冕了也不能随便离开城堡。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_21_nvwangdaren",
	NextID = 14403807,
}
StorySpeechConfig[StorySpeechID.Id14403807] =
{
	Id = 14403807,
	CharName = "皇家卫兵",
	Text = "但是，登基后你可以颁布新的法律，下令取消这个设定，这样就可以随便出行啦~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_17_chengzhenweibing_cos10",
	NextID = 14403808,
}
StorySpeechConfig[StorySpeechID.Id14403808] =
{
	Id = 14403808,
	CharName = "女王大人",
	Text = "真的？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_21_nvwangdaren",
	NextID = 14403809,
}
StorySpeechConfig[StorySpeechID.Id14403809] =
{
	Id = 14403809,
	CharName = "皇家卫兵",
	Text = "其实我们国家的第11任、13任、17任、19任女王大人都这么做过，陛下作为第23任女王大人也可以这么做。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_17_chengzhenweibing_cos10",
	NextID = 14403810,
}
StorySpeechConfig[StorySpeechID.Id14403810] =
{
	Id = 14403810,
	CharName = "女王大人",
	Text = "礼服呢？我们快去找回来~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_21_nvwangdaren",
}
StorySpeechConfig[StorySpeechID.Id14403901] =
{
	Id = 14403901,
	CharName = "冰淇淋公主",
	Text = "哼！你不疼我！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_01_songbing",
	NextID = 14403902,
}
StorySpeechConfig[StorySpeechID.Id14403902] =
{
	Id = 14403902,
	CharName = "奶茶王子",
	Text = "你怎么能说出如此让人气馁的话呀，公主殿下。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_10_naicha",
	NextID = 14403903,
}
StorySpeechConfig[StorySpeechID.Id14403903] =
{
	Id = 14403903,
	CharName = "冰淇淋公主",
	Text = "那我就是想吃抹茶冰淇淋嘛！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_01_songbing",
	NextID = 14403904,
}
StorySpeechConfig[StorySpeechID.Id14403904] =
{
	Id = 14403904,
	CharName = "奶茶王子",
	Text = "但是那个颜色不是看了就很没有食欲吗……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_10_naicha",
	NextID = 14403905,
}
StorySpeechConfig[StorySpeechID.Id14403905] =
{
	Id = 14403905,
	CharName = "冰淇淋公主",
	Text = "那我不吃也可以，你把抹茶冰淇淋涂头上！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_01_songbing",
	NextID = 14403906,
}
StorySpeechConfig[StorySpeechID.Id14403906] =
{
	Id = 14403906,
	CharName = "奶茶王子",
	Text = "……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_10_naicha",
	NextID = 14403907,
}
StorySpeechConfig[StorySpeechID.Id14403907] =
{
	Id = 14403907,
	CharName = "冰淇淋公主",
	Text = "你是不是担心有损你形象，害你无法得到其他公主的欢心？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_01_songbing",
	NextID = 14403908,
}
StorySpeechConfig[StorySpeechID.Id14403908] =
{
	Id = 14403908,
	CharName = "奶茶王子",
	Text = "哎……好吧，那你要知道，这些事情都是为了你才做的，亲爱的公主殿下。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_10_naicha",
	NextID = 14403909,
}
StorySpeechConfig[StorySpeechID.Id14403909] =
{
	Id = 14403909,
	CharName = "茶克林姆",
	Text = "！！你们两个闹别扭，关我什么事啊！！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	LeftIcon = "FAT_GreenTeaIceCream",
	NextID = 14403910,
}
StorySpeechConfig[StorySpeechID.Id14403910] =
{
	Id = 14403910,
	CharName = "奶茶王子",
	Text = "对不起了……你是公主对我的爱情的试练！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_10_naicha",
}
StorySpeechConfig[StorySpeechID.Id14404001] =
{
	Id = 14404001,
	CharName = "汽水王子",
	Text = "（冷冷地）你在喝什么？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_08_xuebi",
	NextID = 14404002,
}
StorySpeechConfig[StorySpeechID.Id14404002] =
{
	Id = 14404002,
	CharName = "棉花糖公主",
	Text = "是王子大人代言的汽水噢~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_04_mianhuatang",
	NextID = 14404003,
}
StorySpeechConfig[StorySpeechID.Id14404003] =
{
	Id = 14404003,
	CharName = "汽水王子",
	Text = "（冷冷地）哼，这有什么好喝的？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_08_xuebi",
	NextID = 14404004,
}
StorySpeechConfig[StorySpeechID.Id14404004] =
{
	Id = 14404004,
	CharName = "棉花糖公主",
	Text = "喝这个的时候感觉王子大人就在我的身边呢~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_04_mianhuatang",
	NextID = 14404005,
}
StorySpeechConfig[StorySpeechID.Id14404005] =
{
	Id = 14404005,
	CharName = "汽水王子",
	Text = "（冷冷地）切，不是就在你身边嘛？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_08_xuebi",
	NextID = 14404006,
}
StorySpeechConfig[StorySpeechID.Id14404006] =
{
	Id = 14404006,
	CharName = "棉花糖公主",
	Text = "和王子大人一样，喝起来冰冰的，但是回味的时候甜甜的。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_04_mianhuatang",
	NextID = 14404007,
}
StorySpeechConfig[StorySpeechID.Id14404007] =
{
	Id = 14404007,
	CharName = "汽水王子",
	Text = "（冷冷地）一直甜甜的，会没意思的。给你试试酸酸的汽水吧？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_08_xuebi",
	NextID = 14404008,
}
StorySpeechConfig[StorySpeechID.Id14404008] =
{
	Id = 14404008,
	CharName = "棉花糖公主",
	Text = "诶！酸酸的，那是什么？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_04_mianhuatang",
	NextID = 14404009,
}
StorySpeechConfig[StorySpeechID.Id14404009] =
{
	Id = 14404009,
	CharName = "汽水王子",
	Text = "（冷冷地）你等我一会儿，我去找个柠檬。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_08_xuebi",
	NextID = 14404010,
}
StorySpeechConfig[StorySpeechID.Id14404010] =
{
	Id = 14404010,
	CharName = "小黄",
	Text = "王子大人是找我吗？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_14_xiaohuang",
	NextID = 14404011,
}
StorySpeechConfig[StorySpeechID.Id14404011] =
{
	Id = 14404011,
	CharName = "汽水王子",
	Text = "（冷冷地）嗯，你过来一下。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_08_xuebi",
}
StorySpeechConfig[StorySpeechID.Id14404101] =
{
	Id = 14404101,
	CharName = "律师",
	Text = "王子殿下，根据您最新的影响力评估，我们不能通过您最新电影的院线独占申请。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_13_lvshi",
	NextID = 14404102,
}
StorySpeechConfig[StorySpeechID.Id14404102] =
{
	Id = 14404102,
	CharName = "可乐王子",
	Text = "我司可以出资5千万买断贵院线一周的独占权。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_07_kele",
	NextID = 14404103,
}
StorySpeechConfig[StorySpeechID.Id14404103] =
{
	Id = 14404103,
	CharName = "律师",
	Text = "（推了下眼镜）呵呵，王子殿下言重了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_13_lvshi",
	NextID = 14404104,
}
StorySpeechConfig[StorySpeechID.Id14404104] =
{
	Id = 14404104,
	CharName = "爆米花女王",
	Text = "（推门进来）诶，这不是小可乐吗？今天怎么过来了？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_22_baomihua",
	NextID = 14404105,
}
StorySpeechConfig[StorySpeechID.Id14404105] =
{
	Id = 14404105,
	CharName = "可乐王子",
	Text = "女王陛下，我希望新片上映时，可以独占贵院线一周。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_07_kele",
	NextID = 14404106,
}
StorySpeechConfig[StorySpeechID.Id14404106] =
{
	Id = 14404106,
	CharName = "爆米花女王",
	Text = "嘿嘿，以王子殿下的影响力，我们原本是不能答应的。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_22_baomihua",
	NextID = 14404107,
}
StorySpeechConfig[StorySpeechID.Id14404107] =
{
	Id = 14404107,
	CharName = "可乐王子",
	Text = "我能做些什么改变这一现状吗？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_07_kele",
	NextID = 14404108,
}
StorySpeechConfig[StorySpeechID.Id14404108] =
{
	Id = 14404108,
	CharName = "爆米花女王",
	Text = "当然，目前院线正推出五彩爆米花，如果王子殿下可以配合我们的宣传……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_22_baomihua",
	NextID = 14404109,
}
StorySpeechConfig[StorySpeechID.Id14404109] =
{
	Id = 14404109,
	CharName = "可乐王子",
	Text = "我想完全没有问题，请问陛下， 我要怎么配合？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_07_kele",
	NextID = 14404110,
}
StorySpeechConfig[StorySpeechID.Id14404110] =
{
	Id = 14404110,
	CharName = "爆米花女王",
	Text = "如果王子殿下可以将包装换成五彩配色。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_22_baomihua",
	NextID = 14404111,
}
StorySpeechConfig[StorySpeechID.Id14404111] =
{
	Id = 14404111,
	CharName = "可乐王子",
	Text = "这不符合我国际化的定位，我想我最多只能接受双色包装。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_07_kele",
	NextID = 14404112,
}
StorySpeechConfig[StorySpeechID.Id14404112] =
{
	Id = 14404112,
	CharName = "爆米花女王",
	Text = "呵呵，如果你打赢我那就听你的，否则请换上五彩包装。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_22_baomihua",
}
StorySpeechConfig[StorySpeechID.Id14404201] =
{
	Id = 14404201,
	CharName = "栗子蛋糕公主",
	Text = "王子，别人都说我们不般配。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_03_qiaokelidan",
	NextID = 14404202,
}
StorySpeechConfig[StorySpeechID.Id14404202] =
{
	Id = 14404202,
	CharName = "可乐王子",
	Text = "你太容易被人影响了，哈尼。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_07_kele",
	NextID = 14404203,
}
StorySpeechConfig[StorySpeechID.Id14404203] =
{
	Id = 14404203,
	CharName = "栗子蛋糕公主",
	Text = "但是，每个人都这么说。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_03_qiaokelidan",
	NextID = 14404204,
}
StorySpeechConfig[StorySpeechID.Id14404204] =
{
	Id = 14404204,
	CharName = "可乐王子",
	Text = "你仔细想想，啤酒王子和蛋糕卷公主在一起不也很不合适吗？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_07_kele",
	NextID = 14404205,
}
StorySpeechConfig[StorySpeechID.Id14404205] =
{
	Id = 14404205,
	CharName = "栗子蛋糕公主",
	Text = "王子，你总是有那么多说辞，我觉得你不爱我。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_03_qiaokelidan",
	NextID = 14404206,
}
StorySpeechConfig[StorySpeechID.Id14404206] =
{
	Id = 14404206,
	CharName = "可乐王子",
	Text = "公主，我该怎么向你证明我的爱呢？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_07_kele",
	NextID = 14404207,
}
StorySpeechConfig[StorySpeechID.Id14404207] =
{
	Id = 14404207,
	CharName = "栗子蛋糕公主",
	Text = "人家最近新买了一套玫瑰礼服，打算和王子穿情侣装去参观烟火节。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_03_qiaokelidan",
	NextID = 14404208,
}
StorySpeechConfig[StorySpeechID.Id14404208] =
{
	Id = 14404208,
	CharName = "可乐王子",
	Text = "啊，多么美好的画面，我一定会满足公主的愿望。 ",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_07_kele",
	NextID = 14404209,
}
StorySpeechConfig[StorySpeechID.Id14404209] =
{
	Id = 14404209,
	CharName = "栗子蛋糕公主",
	Text = "希望王子能换上浪漫的樱花礼服，我一定会陷入王子的情网的。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_03_qiaokelidan",
	NextID = 14404210,
}
StorySpeechConfig[StorySpeechID.Id14404210] =
{
	Id = 14404210,
	CharName = "可乐王子",
	Text = "樱花礼服吗？似乎是季节限定呢，不过……仙子，仙子~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_07_kele",
	NextID = 14404211,
}
StorySpeechConfig[StorySpeechID.Id14404211] =
{
	Id = 14404211,
	CharName = "布丁仙子",
	Text = "是你找我吗，王子？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_27_buding",
	NextID = 14404212,
}
StorySpeechConfig[StorySpeechID.Id14404212] =
{
	Id = 14404212,
	CharName = "可乐王子",
	Text = "仙子，听说你有一件季节限定的樱花礼服，可否借我一用？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_07_kele",
	NextID = 14404213,
}
StorySpeechConfig[StorySpeechID.Id14404213] =
{
	Id = 14404213,
	CharName = "布丁仙子",
	Text = "那可是好不容易才抢到的，绝对不能借。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_27_buding",
	NextID = 14404214,
}
StorySpeechConfig[StorySpeechID.Id14404214] =
{
	Id = 14404214,
	CharName = "可乐王子",
	Text = "啊，那就抱歉了，仙子，你要知道，接下来你承受的一切，都是为了爱情。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_07_kele",
}
StorySpeechConfig[StorySpeechID.Id14404301] =
{
	Id = 14404301,
	CharName = "薯条国王",
	Text = "王子，最近外星流传可乐的糖浆有害健康。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_30_shutiao",
	NextID = 14404302,
}
StorySpeechConfig[StorySpeechID.Id14404302] =
{
	Id = 14404302,
	CharName = "可乐王子",
	Text = "陛下，我司已经研究多年，但是依然没有完美的替代方案。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_07_kele",
	NextID = 14404303,
}
StorySpeechConfig[StorySpeechID.Id14404303] =
{
	Id = 14404303,
	CharName = "薯条国王",
	Text = "（拿出零度可乐装）你看这套礼服怎么样？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_30_shutiao",
	NextID = 14404304,
}
StorySpeechConfig[StorySpeechID.Id14404304] =
{
	Id = 14404304,
	CharName = "可乐王子",
	Text = "使用甜味素代替传统糖浆，极大地降低热量，配合冰块食用，风味更佳，这是一个完美的替代方案。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_07_kele",
	NextID = 14404305,
}
StorySpeechConfig[StorySpeechID.Id14404305] =
{
	Id = 14404305,
	CharName = "薯条国王",
	Text = "嘿嘿嘿，的确如此。朕打算将这件礼服赠与王子。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_30_shutiao",
	NextID = 14404306,
}
StorySpeechConfig[StorySpeechID.Id14404306] =
{
	Id = 14404306,
	CharName = "可乐王子",
	Text = "多谢陛下。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_07_kele",
	NextID = 14404307,
}
StorySpeechConfig[StorySpeechID.Id14404307] =
{
	Id = 14404307,
	CharName = "薯条国王",
	Text = "先不急，先和朕来摔场跤，再提封赏之事吧。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_30_shutiao",
}
StorySpeechConfig[StorySpeechID.Id14404401] =
{
	Id = 14404401,
	CharName = "啤酒王子",
	Text = "鸡尾酒，你这么受欢迎的秘诀是什么呀？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_09_pijiu",
	NextID = 14404402,
}
StorySpeechConfig[StorySpeechID.Id14404402] =
{
	Id = 14404402,
	CharName = "鸡尾酒王子",
	Text = "这个我也不知道，可能是我爷爷喜欢在酒杯上放鸡毛装饰吧。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_09_pijiu_cos10",
	NextID = 14404403,
}
StorySpeechConfig[StorySpeechID.Id14404403] =
{
	Id = 14404403,
	CharName = "可乐王子",
	Text = "我觉得是酒精含量的问题。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_07_kele",
	NextID = 14404404,
}
StorySpeechConfig[StorySpeechID.Id14404404] =
{
	Id = 14404404,
	CharName = "汽水王子",
	Text = "我觉得是颜色鲜艳的问题。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_08_xuebi",
	NextID = 14404405,
}
StorySpeechConfig[StorySpeechID.Id14404405] =
{
	Id = 14404405,
	CharName = "抹茶王子",
	Text = "我觉得是混合产生的化学反应。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_10_naicha_cos10",
	NextID = 14404406,
}
StorySpeechConfig[StorySpeechID.Id14404406] =
{
	Id = 14404406,
	CharName = "啤酒王子",
	Text = "那要不我们也混合一下试试？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_09_pijiu",
	NextID = 14404407,
}
StorySpeechConfig[StorySpeechID.Id14404407] =
{
	Id = 14404407,
	CharName = "可乐王子",
	Text = "好呀，嘿咻——",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_07_kele",
	NextID = 14404408,
}
StorySpeechConfig[StorySpeechID.Id14404408] =
{
	Id = 14404408,
	CharName = "奶茶王子",
	Text = "看我的，嘿呀——",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_10_naicha",
	NextID = 14404409,
}
StorySpeechConfig[StorySpeechID.Id14404409] =
{
	Id = 14404409,
	CharName = "汽水王子",
	Text = "我也来，嘿哈——",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_08_xuebi",
	NextID = 14404410,
}
StorySpeechConfig[StorySpeechID.Id14404410] =
{
	Id = 14404410,
	CharName = "啤酒王子",
	Text = "最后加上我，嘿嘿嘿……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_09_pijiu",
	NextID = 14404411,
}
StorySpeechConfig[StorySpeechID.Id14404411] =
{
	Id = 14404411,
	CharName = "啤酒王子",
	Text = "额，看着有点诡异，你们谁要试试……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_09_pijiu",
}
StorySpeechConfig[StorySpeechID.Id14404501] =
{
	Id = 14404501,
	CharName = "小红",
	Text = "你好，这是我的申请表。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_12_xiaohong",
	NextID = 14404502,
}
StorySpeechConfig[StorySpeechID.Id14404502] =
{
	Id = 14404502,
	CharName = "草莓果冻",
	Text = "嗯，口味符合，色泽也很饱满。那么只要打赢我证明体格健康，就可以去流水线啦~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_12_xiaohong_cos10",
}
StorySpeechConfig[StorySpeechID.Id14404601] =
{
	Id = 14404601,
	CharName = "小橙",
	Text = "你好，这是我的申请表。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_13_xiaocheng",
	NextID = 14404602,
}
StorySpeechConfig[StorySpeechID.Id14404602] =
{
	Id = 14404602,
	CharName = "橘子果冻",
	Text = "嗯，口味符合，色泽也很饱满。那么只要打赢我证明体格健康，就可以去流水线啦~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_13_xiaocheng_cos10",
}
StorySpeechConfig[StorySpeechID.Id14404701] =
{
	Id = 14404701,
	CharName = "小黄",
	Text = "你好，这是我的申请表。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_14_xiaohuang",
	NextID = 14404702,
}
StorySpeechConfig[StorySpeechID.Id14404702] =
{
	Id = 14404702,
	CharName = "柠檬果冻",
	Text = "嗯，口味符合，色泽也很饱满。那么只要打赢我证明体格健康，就可以去流水线啦~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_14_xiaohuang_cos10",
}
StorySpeechConfig[StorySpeechID.Id14404801] =
{
	Id = 14404801,
	CharName = "小绿",
	Text = "你好，这是我的申请表。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_15_xiaolv",
	NextID = 14404802,
}
StorySpeechConfig[StorySpeechID.Id14404802] =
{
	Id = 14404802,
	CharName = "芥末果冻",
	Text = "嗯，口味符合，色泽也很饱满。那么只要打赢我证明体格健康，就可以去流水线啦~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_15_xiaolv_cos10",
}
StorySpeechConfig[StorySpeechID.Id14404901] =
{
	Id = 14404901,
	CharName = "小青",
	Text = "你好，这是我的申请表。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_16_xiaolan",
	NextID = 14404902,
}
StorySpeechConfig[StorySpeechID.Id14404902] =
{
	Id = 14404902,
	CharName = "牛油果果冻",
	Text = "嗯，口味符合，色泽也很饱满。那么只要打赢我证明体格健康，就可以去流水线啦~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_16_xiaolan_cos10",
}
StorySpeechConfig[StorySpeechID.Id14405001] =
{
	Id = 14405001,
	CharName = "小蓝",
	Text = "你好，这是我的申请表。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_17_xiaoqing",
	NextID = 14405002,
}
StorySpeechConfig[StorySpeechID.Id14405002] =
{
	Id = 14405002,
	CharName = "薄荷果冻",
	Text = "嗯，口味符合，色泽也很饱满。那么只要打赢我证明体格健康，就可以去流水线啦~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_17_xiaoqing_cos10",
}
StorySpeechConfig[StorySpeechID.Id14405101] =
{
	Id = 14405101,
	CharName = "小紫",
	Text = "你好，这是我的申请表。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_18_xiaozi",
	NextID = 14405102,
}
StorySpeechConfig[StorySpeechID.Id14405102] =
{
	Id = 14405102,
	CharName = "葡萄果冻",
	Text = "嗯，口味符合，色泽也很饱满。那么只要打赢我证明体格健康，就可以去流水线啦~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_18_xiaozi_cos10",
}
StorySpeechConfig[StorySpeechID.Id14405301] =
{
	Id = 14405301,
	CharName = "店长",
	Text = "今年国王决定举办香橙节，希望大家明天开始都换上香橙主题的服装。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_men4",
	NextID = 14405302,
}
StorySpeechConfig[StorySpeechID.Id14405302] =
{
	Id = 14405302,
	CharName = "咖啡女仆",
	Text = "哎呀……工资已经用光了，怎么办？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_06_kafei",
	NextID = 14405303,
}
StorySpeechConfig[StorySpeechID.Id14405303] =
{
	Id = 14405303,
	CharName = "店长",
	Text = "你能拿出多少？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_men4",
	NextID = 14405304,
}
StorySpeechConfig[StorySpeechID.Id14405304] =
{
	Id = 14405304,
	CharName = "咖啡女仆",
	Text = "最好有免费的。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_06_kafei",
	NextID = 14405305,
}
StorySpeechConfig[StorySpeechID.Id14405305] =
{
	Id = 14405305,
	CharName = "店长",
	Text = "你看到那边在走的橙味糖果了吗？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_men4",
	NextID = 14405306,
}
StorySpeechConfig[StorySpeechID.Id14405306] =
{
	Id = 14405306,
	CharName = "咖啡女仆",
	Text = "嗯，看到了。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_06_kafei",
	NextID = 14405307,
}
StorySpeechConfig[StorySpeechID.Id14405307] =
{
	Id = 14405307,
	CharName = "店长",
	Text = "他在那里摆擂台，不过只接受女性挑战，打赢了就能拿到新鲜的香橙。到时候我会帮你做套新的女仆装。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_men4",
	NextID = 14405308,
}
StorySpeechConfig[StorySpeechID.Id14405308] =
{
	Id = 14405308,
	CharName = "咖啡女仆",
	Text = "哇，那太好了~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_06_kafei",
}
StorySpeechConfig[StorySpeechID.Id14405201] =
{
	Id = 14405201,
	CharName = "棒棒糖女仆",
	Text = "请问这里在招聘新的糖果代言人吗？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_05_bangbangtang",
	NextID = 14405202,
}
StorySpeechConfig[StorySpeechID.Id14405202] =
{
	Id = 14405202,
	CharName = "律师",
	Text = "是的，小姐，请提交一下你的资料。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_13_lvshi",
	NextID = 14405203,
}
StorySpeechConfig[StorySpeechID.Id14405203] =
{
	Id = 14405203,
	CharName = "棒棒糖女仆",
	Text = "（拿出厚厚一沓简历）",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_05_bangbangtang",
	NextID = 14405204,
}
StorySpeechConfig[StorySpeechID.Id14405204] =
{
	Id = 14405204,
	CharName = "律师",
	Text = "你是牛筋大学毕业的？还有椰露大学的糖果管理博士专业。你还担任过金字塔糖果金融的CEO……你这么优秀，我想可以直接晋级进入最终轮面试。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_13_lvshi",
	NextID = 14405205,
}
StorySpeechConfig[StorySpeechID.Id14405205] =
{
	Id = 14405205,
	CharName = "棒棒糖女仆",
	Text = "哇，这是真的嘛？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_05_bangbangtang",
	NextID = 14405206,
}
StorySpeechConfig[StorySpeechID.Id14405206] =
{
	Id = 14405206,
	CharName = "律师",
	Text = "对，直走最后一间房间，本次产品的负责人在等着你。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_13_lvshi",
}
StorySpeechConfig[StorySpeechID.Id14405701] =
{
	Id = 14405701,
	CharName = "虾条小姐",
	Text = "哇~新的衣服~赶紧穿起来看看。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_20_xiatiao",
	NextID = 14405702,
}
StorySpeechConfig[StorySpeechID.Id14405702] =
{
	Id = 14405702,
	CharName = "虾条小姐",
	Text = "诶？！怎么穿不上了？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_20_xiatiao",
	NextID = 14405703,
}
StorySpeechConfig[StorySpeechID.Id14405703] =
{
	Id = 14405703,
	CharName = "心中的声音",
	Text = "因为你最近又胖了噢~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_20_xiatiao",
	NextID = 14405704,
}
StorySpeechConfig[StorySpeechID.Id14405704] =
{
	Id = 14405704,
	CharName = "虾条小姐",
	Text = "不，不可能！最近每天晚上只吃三包薯片和三包虾条的。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_20_xiatiao",
	NextID = 14405705,
}
StorySpeechConfig[StorySpeechID.Id14405705] =
{
	Id = 14405705,
	CharName = "心中的声音",
	Text = "那好像也还好。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_20_xiatiao",
	NextID = 14405706,
}
StorySpeechConfig[StorySpeechID.Id14405706] =
{
	Id = 14405706,
	CharName = "虾条小姐",
	Text = "然后每天下午也只喝两杯奶茶。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_20_xiatiao",
	NextID = 14405707,
}
StorySpeechConfig[StorySpeechID.Id14405707] =
{
	Id = 14405707,
	CharName = "心中的声音",
	Text = "只要多运动就好。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_20_xiatiao",
	NextID = 14405708,
}
StorySpeechConfig[StorySpeechID.Id14405708] =
{
	Id = 14405708,
	CharName = "虾条小姐",
	Text = "运动倒是已经挺久没有做了。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_20_xiatiao",
	NextID = 14405709,
}
StorySpeechConfig[StorySpeechID.Id14405709] =
{
	Id = 14405709,
	CharName = "心中的声音",
	Text = "那肯定会胖的！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_20_xiatiao",
	NextID = 14405710,
}
StorySpeechConfig[StorySpeechID.Id14405710] =
{
	Id = 14405710,
	CharName = "虾条小姐",
	Text = "不！我不信，我一定要穿上这件衣服！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_20_xiatiao",
}
StorySpeechConfig[StorySpeechID.Id14405801] =
{
	Id = 14405801,
	CharName = "薯片夫人",
	Text = "女儿，妈妈给你订了一个大礼物噢~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_19_shupian",
	NextID = 14405802,
}
StorySpeechConfig[StorySpeechID.Id14405802] =
{
	Id = 14405802,
	CharName = "妙脆角小姐",
	Text = "哇~~是什么，妈妈~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_21_miaocuijiao",
	NextID = 14405803,
}
StorySpeechConfig[StorySpeechID.Id14405803] =
{
	Id = 14405803,
	CharName = "薯片夫人",
	Text = "你看，是这个民族舞课程~你每周日下午4:30不是还有1小时空余吗？现在补上了~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_19_shupian",
	NextID = 14405804,
}
StorySpeechConfig[StorySpeechID.Id14405804] =
{
	Id = 14405804,
	CharName = "妙脆角小姐",
	Text = "但是人家不想去学跳舞。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_21_miaocuijiao",
	NextID = 14405805,
}
StorySpeechConfig[StorySpeechID.Id14405805] =
{
	Id = 14405805,
	CharName = "薯片夫人",
	Text = "（拿出洋葱圈礼服）如果你去学跳舞的话，妈妈就送你这件小裙子噢~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_19_shupian",
	NextID = 14405806,
}
StorySpeechConfig[StorySpeechID.Id14405806] =
{
	Id = 14405806,
	CharName = "妙脆角小姐",
	Text = "哇~那我会好好学跳舞的~~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_21_miaocuijiao",
	NextID = 14405807,
}
StorySpeechConfig[StorySpeechID.Id14405807] =
{
	Id = 14405807,
	CharName = "薯片夫人",
	Text = "那么这件衣服送给我们宝贝妙脆角，要自己叠好放起来噢~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_19_shupian",
	NextID = 14405808,
}
StorySpeechConfig[StorySpeechID.Id14405808] =
{
	Id = 14405808,
	CharName = "虾条小姐",
	Text = "哇，你有新衣服了，我也要~（抢过来）",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_20_xiatiao",
	NextID = 14405809,
}
StorySpeechConfig[StorySpeechID.Id14405809] =
{
	Id = 14405809,
	CharName = "妙脆角小姐",
	Text = "不要抢我的，这个是妈妈送给我的！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_21_miaocuijiao",
	NextID = 14405810,
}
StorySpeechConfig[StorySpeechID.Id14405810] =
{
	Id = 14405810,
	CharName = "虾条小姐",
	Text = "那你来抢回去呀~~笨蛋！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_20_xiatiao",
}
StorySpeechConfig[StorySpeechID.Id14406101] =
{
	Id = 14406101,
	CharName = "黑巧克力皇后",
	Text = "魔镜魔镜~谁是这个星球上最美味的冰淇淋？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_11_tiantong",
	NextID = 14406102,
}
StorySpeechConfig[StorySpeechID.Id14406102] =
{
	Id = 14406102,
	CharName = "魔镜",
	Text = "是您的好朋友冰淇淋公主，我的皇后殿下。",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	RightIcon = "Equipment_Fat_11_tiantong_2",
	NextID = 14406103,
}
StorySpeechConfig[StorySpeechID.Id14406103] =
{
	Id = 14406103,
	CharName = "黑巧克力皇后",
	Text = "……是不是坏了？重启一下（对准重启键，按下）",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_11_tiantong",
	NextID = 14406104,
}
StorySpeechConfig[StorySpeechID.Id14406104] =
{
	Id = 14406104,
	CharName = "黑巧克力皇后",
	Text = "魔镜魔镜~谁是这个星球上最美味的冰淇淋？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_11_tiantong",
	NextID = 14406105,
}
StorySpeechConfig[StorySpeechID.Id14406105] =
{
	Id = 14406105,
	CharName = "魔镜",
	Text = "是您的好朋友冰淇淋公主，我的皇后殿下。",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	RightIcon = "Equipment_Fat_11_tiantong_2",
	NextID = 14406106,
}
StorySpeechConfig[StorySpeechID.Id14406106] =
{
	Id = 14406106,
	CharName = "黑巧克力皇后",
	Text = "不可能！就一个香草冰淇淋球，如此单调的口味怎么和浓醇的巧克力相提并论！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_11_tiantong",
	NextID = 14406107,
}
StorySpeechConfig[StorySpeechID.Id14406107] =
{
	Id = 14406107,
	CharName = "魔镜",
	Text = "现在流行清新口味，皇后殿下的100%黑巧克力苦味目前在市面上的综合评分是1星，97%差评。",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	RightIcon = "Equipment_Fat_11_tiantong_2",
	NextID = 14406108,
}
StorySpeechConfig[StorySpeechID.Id14406108] =
{
	Id = 14406108,
	CharName = "黑巧克力皇后",
	Text = "（掩面）我该怎么办？你想不出办法，我就让你破镜难圆！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_11_tiantong",
	NextID = 14406109,
}
StorySpeechConfig[StorySpeechID.Id14406109] =
{
	Id = 14406109,
	CharName = "魔镜",
	Text = "！！请饶过在下，容我想一想……诶，皇后殿下要不要试试也换个清新点的口味呢？",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	RightIcon = "Equipment_Fat_11_tiantong_2",
	NextID = 14406110,
}
StorySpeechConfig[StorySpeechID.Id14406110] =
{
	Id = 14406110,
	CharName = "黑巧克力皇后",
	Text = "我觉得薄荷味也不错。小蓝，你过来下！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_11_tiantong",
	NextID = 14406111,
}
StorySpeechConfig[StorySpeechID.Id14406111] =
{
	Id = 14406111,
	CharName = "小蓝",
	Text = "是的，皇后大人，请问有什么吩咐？诶……皇后大人……你怎么这样看着我？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_17_xiaoqing",
}
StorySpeechConfig[StorySpeechID.Id14405401] =
{
	Id = 14405401,
	CharName = "华夫饼仙子",
	Text = "呼，终于下班了，今天还挺清闲的。嗯，看看手机先~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_25_huafubing",
	NextID = 14405402,
}
StorySpeechConfig[StorySpeechID.Id14405402] =
{
	Id = 14405402,
	CharName = "消息提示",
	Text = "亲爱的用户“最美小华夫”，您在本店预定的软糖仙子-抽选限定套装，已获得购买资格，请尽快到本店完成交易。",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	RightIcon = "Equipment_Rpg_29_QA_1",
	NextID = 14405403,
}
StorySpeechConfig[StorySpeechID.Id14405403] =
{
	Id = 14405403,
	CharName = "华夫饼仙子",
	Text = "诶？！诶！！！！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_25_huafubing",
	NextID = 14405404,
}
StorySpeechConfig[StorySpeechID.Id14405404] =
{
	Id = 14405404,
	CharName = "松饼仙子",
	Text = "怎么啦，大姐。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_26_tongluoshao",
	NextID = 14405405,
}
StorySpeechConfig[StorySpeechID.Id14405405] =
{
	Id = 14405405,
	CharName = "华夫饼仙子",
	Text = "你看，这是上个月订的抽选服装，我拿到购买资格了诶~走！我们快去店里！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_25_huafubing",
	NextID = 14405406,
}
StorySpeechConfig[StorySpeechID.Id14405406] =
{
	Id = 14405406,
	CharName = "松饼仙子",
	Text = "哇，这件衣服超漂亮的诶。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_26_tongluoshao",
	NextID = 14405407,
}
StorySpeechConfig[StorySpeechID.Id14405407] =
{
	Id = 14405407,
	CharName = "华夫饼仙子",
	Text = "（嗖地一声抵达仙子服装店）",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_25_huafubing",
	NextID = 14405408,
}
StorySpeechConfig[StorySpeechID.Id14405408] =
{
	Id = 14405408,
	CharName = "黄牛商人",
	Text = "来来来，大家都不用去了噢~今天刚到的10套衣服都在我这里了。第一套10万，以后每套+5万，先到先得噢~ ",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_14_lvxingshangren",
	NextID = 14405409,
}
StorySpeechConfig[StorySpeechID.Id14405409] =
{
	Id = 14405409,
	CharName = "华夫饼仙子",
	Text = "什么！？这个人太可恶了！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_25_huafubing",
}
StorySpeechConfig[StorySpeechID.Id14405501] =
{
	Id = 14405501,
	CharName = "松饼仙子",
	Text = "呼，终于到了舒芙蕾镇了，听说这里有地区限定的舒芙蕾仙子服卖呢~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_26_tongluoshao",
	NextID = 14405502,
}
StorySpeechConfig[StorySpeechID.Id14405502] =
{
	Id = 14405502,
	CharName = "黄牛商人",
	Text = "来来来，瞧一瞧，看一看~当地限定的仙子套装，只有我这里才买得到噢~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_14_lvxingshangren",
	NextID = 14405503,
}
StorySpeechConfig[StorySpeechID.Id14405503] =
{
	Id = 14405503,
	CharName = "松饼仙子",
	Text = "！这里竟然也有黄牛！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_26_tongluoshao",
	NextID = 14405504,
}
StorySpeechConfig[StorySpeechID.Id14405504] =
{
	Id = 14405504,
	CharName = "黄牛商人",
	Text = "啊呀，小姐，一看你就是外地来的，你是来买仙子套装的吧？我这里有地区限定噢~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_14_lvxingshangren",
	NextID = 14405505,
}
StorySpeechConfig[StorySpeechID.Id14405505] =
{
	Id = 14405505,
	CharName = "松饼仙子",
	Text = "我才不让你炒价呢，我去店里买。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_26_tongluoshao",
	NextID = 14405506,
}
StorySpeechConfig[StorySpeechID.Id14405506] =
{
	Id = 14405506,
	CharName = "黄牛商人",
	Text = "那就不用去啦~这个月的货我已经包圆了。不过价格嘛——也只比店里贵一倍而已，反正过了这村就没这店了~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_14_lvxingshangren",
	NextID = 14405507,
}
StorySpeechConfig[StorySpeechID.Id14405507] =
{
	Id = 14405507,
	CharName = "松饼仙子",
	Text = "太过分了！！！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_26_tongluoshao",
	NextID = 14405508,
}
StorySpeechConfig[StorySpeechID.Id14405508] =
{
	Id = 14405508,
	CharName = "黄牛商人",
	Text = "噢哟！你想动手？不是我吹牛，你要是打赢我，我送你一套~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_14_lvxingshangren",
}
StorySpeechConfig[StorySpeechID.Id14405601] =
{
	Id = 14405601,
	CharName = "无线电",
	Text = "四月的风吹来，又到了樱花盛开的季节。那么，大家今年有出门赏樱的计划嘛？",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	LeftIcon = "Equipment_Rpg_15_peiyinyanyuan_1",
	NextID = 14405602,
}
StorySpeechConfig[StorySpeechID.Id14405602] =
{
	Id = 14405602,
	CharName = "布丁仙子",
	Text = "哇，又到了赏樱的季节了~诶！仙子服装店去年的樱花礼服会不会复刻呢？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_27_buding",
	NextID = 14405603,
}
StorySpeechConfig[StorySpeechID.Id14405603] =
{
	Id = 14405603,
	CharName = "布丁仙子",
	Text = "（嗖地一声到了仙子服装店）你好，我想购买樱花礼服~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_27_buding",
	NextID = 14405604,
}
StorySpeechConfig[StorySpeechID.Id14405604] =
{
	Id = 14405604,
	CharName = "接待员",
	Text = "抱歉，今年的樱花礼服已经售罄了。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_women1",
	NextID = 14405605,
}
StorySpeechConfig[StorySpeechID.Id14405605] =
{
	Id = 14405605,
	CharName = "布丁仙子",
	Text = "诶！不是才刚四月吗？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_27_buding",
	NextID = 14405606,
}
StorySpeechConfig[StorySpeechID.Id14405606] =
{
	Id = 14405606,
	CharName = "接待员",
	Text = "（指旅行商人）他早上五点就来等开门了，一开门就把衣服全部买下来了。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_women1",
	NextID = 14405607,
}
StorySpeechConfig[StorySpeechID.Id14405607] =
{
	Id = 14405607,
	CharName = "黄牛商人",
	Text = "大家请排好队，不要挤，交足了钱就能拿到你们等了一年的樱花礼服噢~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_14_lvxingshangren",
	NextID = 14405608,
}
StorySpeechConfig[StorySpeechID.Id14405608] =
{
	Id = 14405608,
	CharName = "布丁仙子",
	Text = "哎，看来只能等明年了……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_27_buding",
	NextID = 14405609,
}
StorySpeechConfig[StorySpeechID.Id14405609] =
{
	Id = 14405609,
	CharName = "黄牛商人",
	Text = "这位大姐，不买就不要挡在这里，快点让开。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_14_lvxingshangren",
	NextID = 14405610,
}
StorySpeechConfig[StorySpeechID.Id14405610] =
{
	Id = 14405610,
	CharName = "布丁仙子",
	Text = "我想买。但是钱不够……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_27_buding",
	NextID = 14405611,
}
StorySpeechConfig[StorySpeechID.Id14405611] =
{
	Id = 14405611,
	CharName = "黄牛商人",
	Text = "快走！还不走，看来要我海扁你一顿才行！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_14_lvxingshangren",
}
StorySpeechConfig[StorySpeechID.Id14405901] =
{
	Id = 14405901,
	CharName = "栗子蛋糕公主",
	Text = "女巫，我要告诉你个秘密。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_03_qiaokelidan",
	NextID = 14405902,
}
StorySpeechConfig[StorySpeechID.Id14405902] =
{
	Id = 14405902,
	CharName = "培根女巫",
	Text = "我们的小公主是不是谈恋爱了啊？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_23_peigen",
	NextID = 14405903,
}
StorySpeechConfig[StorySpeechID.Id14405903] =
{
	Id = 14405903,
	CharName = "栗子蛋糕公主",
	Text = "（脸红）嗯，我第一个就告诉了你噢~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_03_qiaokelidan",
	NextID = 14405904,
}
StorySpeechConfig[StorySpeechID.Id14405904] =
{
	Id = 14405904,
	CharName = "培根女巫",
	Text = "（抚摸着公主的头发）哎，你长大了，终有一天会有自己的人生的。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_23_peigen",
	NextID = 14405905,
}
StorySpeechConfig[StorySpeechID.Id14405905] =
{
	Id = 14405905,
	CharName = "栗子蛋糕公主",
	Text = "你不高兴了吗？女巫？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_03_qiaokelidan",
	NextID = 14405906,
}
StorySpeechConfig[StorySpeechID.Id14405906] =
{
	Id = 14405906,
	CharName = "培根女巫",
	Text = "怎么会呢？我的小公主找到了他的心上人，我当然感到高兴。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_23_peigen",
	NextID = 14405907,
}
StorySpeechConfig[StorySpeechID.Id14405907] =
{
	Id = 14405907,
	CharName = "栗子蛋糕公主",
	Text = "对了，我看中一顶新帽子想送你，不过……那个怪物很顽强，一定不肯让给我呢。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_03_qiaokelidan",
	NextID = 14405908,
}
StorySpeechConfig[StorySpeechID.Id14405908] =
{
	Id = 14405908,
	CharName = "培根女巫",
	Text = "新的帽子吗？我的小公主眼光一定没错的~~快让我看看。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_23_peigen",
	NextID = 14405909,
}
StorySpeechConfig[StorySpeechID.Id14405909] =
{
	Id = 14405909,
	CharName = "栗子蛋糕公主",
	Text = "（拖出寿司龟龟）是三文鱼噢~感觉女巫戴上的话，会有异样的风情呢~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_03_qiaokelidan",
	NextID = 14405910,
}
StorySpeechConfig[StorySpeechID.Id14405910] =
{
	Id = 14405910,
	CharName = "培根女巫",
	Text = "嗯，把它留下，我会搞定它的。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_23_peigen",
}
StorySpeechConfig[StorySpeechID.Id14406001] =
{
	Id = 14406001,
	CharName = "电视台台长",
	Text = "薯片啊，最近收视率有些下滑，我们能不能挽回一下？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_oldmen1",
	NextID = 14406002,
}
StorySpeechConfig[StorySpeechID.Id14406002] =
{
	Id = 14406002,
	CharName = "薯片夫人",
	Text = "我已经想过了，台长大人。最近流行健康风，我打算打扮得清凉一些，画一个水果妆。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_19_shupian",
	NextID = 14406003,
}
StorySpeechConfig[StorySpeechID.Id14406003] =
{
	Id = 14406003,
	CharName = "电视台台长",
	Text = "这个主意好！那我们主打什么水果？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_oldmen1",
	NextID = 14406004,
}
StorySpeechConfig[StorySpeechID.Id14406004] =
{
	Id = 14406004,
	CharName = "薯片夫人",
	Text = "颜色要自然，我选绿色，绿色象征大自然；横截面要饱满，我选圆形，圆形象征自然形状。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_19_shupian",
	NextID = 14406005,
}
StorySpeechConfig[StorySpeechID.Id14406005] =
{
	Id = 14406005,
	CharName = "电视台台长",
	Text = "喔！我们主打西瓜？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_oldmen1",
	NextID = 14406006,
}
StorySpeechConfig[StorySpeechID.Id14406006] =
{
	Id = 14406006,
	CharName = "薯片夫人",
	Text = "西瓜的体型不符合我一直塑造的贵妇形象，我们主打黄瓜！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_19_shupian",
	NextID = 14406007,
}
StorySpeechConfig[StorySpeechID.Id14406007] =
{
	Id = 14406007,
	CharName = "电视台台长",
	Text = "但是隔壁电台已经推出了黄瓜味薯片，会有抄袭的嫌疑。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_oldmen1",
	NextID = 14406008,
}
StorySpeechConfig[StorySpeechID.Id14406008] =
{
	Id = 14406008,
	CharName = "薯片夫人",
	Text = "黄瓜味薯片？太没创意，大家需要的只是黄瓜的健康，要是我，我就推出薯片味的黄瓜！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_19_shupian",
	NextID = 14406009,
}
StorySpeechConfig[StorySpeechID.Id14406009] =
{
	Id = 14406009,
	CharName = "电视台台长",
	Text = "太高明了，我这就拿参考书给你看下~",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_oldmen1",
	NextID = 14406010,
}
StorySpeechConfig[StorySpeechID.Id14406010] =
{
	Id = 14406010,
	CharName = "薯片夫人",
	Text = "那么请台长尽快安排。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_19_shupian",
}
StorySpeechConfig[StorySpeechID.Id14406201] =
{
	Id = 14406201,
	CharName = "棉花糖公主",
	Text = "魔后，魔后~听说你研究出了新的鸡翅~~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_04_mianhuatang",
	NextID = 14406202,
}
StorySpeechConfig[StorySpeechID.Id14406202] =
{
	Id = 14406202,
	CharName = "炸鸡魔后",
	Text = "嗯，嗯，味道真的很不错噢~是使用了特殊的方法烤制的呢~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_28_jichi",
	NextID = 14406203,
}
StorySpeechConfig[StorySpeechID.Id14406203] =
{
	Id = 14406203,
	CharName = "棉花糖公主",
	Text = "是什么方法呀~我也想知道。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_04_mianhuatang",
	NextID = 14406204,
}
StorySpeechConfig[StorySpeechID.Id14406204] =
{
	Id = 14406204,
	CharName = "炸鸡魔后",
	Text = "关键就是火候~一种独特的火焰，可以在一瞬间就烤熟食物，同时烘干表面的水分，让表皮酥脆，但是又不会夺走食物内部的汤汁。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_28_jichi",
	NextID = 14406205,
}
StorySpeechConfig[StorySpeechID.Id14406205] =
{
	Id = 14406205,
	CharName = "棉花糖公主",
	Text = "那样怎么做呢？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_04_mianhuatang",
	NextID = 14406206,
}
StorySpeechConfig[StorySpeechID.Id14406206] =
{
	Id = 14406206,
	CharName = "炸鸡魔后",
	Text = "（拿出一个小火球）秘诀就是它！嗯，让我看下，如果是你的话，应该可以做个特殊造型~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_28_jichi",
	NextID = 14406207,
}
StorySpeechConfig[StorySpeechID.Id14406207] =
{
	Id = 14406207,
	CharName = "棉花糖公主",
	Text = "哇~~~那我也要试试看~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_04_mianhuatang",
}
StorySpeechConfig[StorySpeechID.Id14406301] =
{
	Id = 14406301,
	CharName = "小红",
	Text = "公主，我们7个要去打工了，你一个人的时候千万要保护好自己，听说皇后要把你变成巧克力味冰淇淋！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_12_xiaohong",
	NextID = 14406302,
}
StorySpeechConfig[StorySpeechID.Id14406302] =
{
	Id = 14406302,
	CharName = "冰淇淋公主",
	Text = "我会小心的，请放心吧。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_01_songbing",
	NextID = 14406303,
}
StorySpeechConfig[StorySpeechID.Id14406303] =
{
	Id = 14406303,
	CharName = "薄荷甜筒皇后",
	Text = "（敲门）请问冰淇淋公主在家吗？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_11_tiantong_cos10",
	NextID = 14406304,
}
StorySpeechConfig[StorySpeechID.Id14406304] =
{
	Id = 14406304,
	CharName = "冰淇淋公主",
	Text = "你是黑巧克力皇后吗？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_01_songbing",
	NextID = 14406305,
}
StorySpeechConfig[StorySpeechID.Id14406305] =
{
	Id = 14406305,
	CharName = "薄荷甜筒皇后",
	Text = "年轻的公主，你从门缝里瞧一瞧，我是一个薄荷甜筒呀，不是黑巧克力味的。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_11_tiantong_cos10",
	NextID = 14406306,
}
StorySpeechConfig[StorySpeechID.Id14406306] =
{
	Id = 14406306,
	CharName = "冰淇淋公主",
	Text = "（放心地开门）啊，你好~请问你是要找我吗？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_01_songbing",
	NextID = 14406307,
}
StorySpeechConfig[StorySpeechID.Id14406307] =
{
	Id = 14406307,
	CharName = "薄荷甜筒皇后",
	Text = "的确，我是来找你的，希望你看一下我这篮新鲜的苹果。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_11_tiantong_cos10",
	NextID = 14406308,
}
StorySpeechConfig[StorySpeechID.Id14406308] =
{
	Id = 14406308,
	CharName = "烂苹果",
	Text = "吃我呀，吃我呀，你看我多新鲜~",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	RightIcon = "Arena_FAT_Apple",
	NextID = 14406309,
}
StorySpeechConfig[StorySpeechID.Id14406309] =
{
	Id = 14406309,
	CharName = "冰淇淋公主",
	Text = "（-_-||）亲爱的薄荷皇后，虽然我领受您的心意，但是这个苹果真的不是很新鲜的样子。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_01_songbing",
	NextID = 14406310,
}
StorySpeechConfig[StorySpeechID.Id14406310] =
{
	Id = 14406310,
	CharName = "薄荷甜筒皇后",
	Text = "（目露凶光）嘿嘿嘿！太晚了！烂苹果，用巧克力酱泼她，把她变成巧克力味！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_11_tiantong_cos10",
	NextID = 14406311,
}
StorySpeechConfig[StorySpeechID.Id14406311] =
{
	Id = 14406311,
	CharName = "冰淇淋公主",
	Text = "啊~~~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_01_songbing",
	NextID = 14406312,
}
StorySpeechConfig[StorySpeechID.Id14406312] =
{
	Id = 14406312,
	CharName = "小红",
	Text = "公主，我们回来啦~~啊！！！公主，你怎么了？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_12_xiaohong",
	NextID = 14406313,
}
StorySpeechConfig[StorySpeechID.Id14406313] =
{
	Id = 14406313,
	CharName = "小橙",
	Text = "小红！是这个烂苹果，它用巧克力酱泼了公主。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_13_xiaocheng",
	NextID = 14406314,
}
StorySpeechConfig[StorySpeechID.Id14406314] =
{
	Id = 14406314,
	CharName = "小黄",
	Text = "我们一起上，打败它！救出公主！！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_14_xiaohuang",
}
StorySpeechConfig[StorySpeechID.Id14406401] =
{
	Id = 14406401,
	CharName = "薯片夫人",
	Text = "今天是啤酒王子举办的日式烤肉派对，虾条，妙脆角，你们今天一定要乖一点。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_19_shupian",
	NextID = 14406402,
}
StorySpeechConfig[StorySpeechID.Id14406402] =
{
	Id = 14406402,
	CharName = "虾条小姐",
	Text = "是的，妈妈~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_20_xiatiao",
	NextID = 14406403,
}
StorySpeechConfig[StorySpeechID.Id14406403] =
{
	Id = 14406403,
	CharName = "薯片夫人",
	Text = "蛋糕，你今天就留在家里打扫卫生吧。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_19_shupian",
	NextID = 14406404,
}
StorySpeechConfig[StorySpeechID.Id14406404] =
{
	Id = 14406404,
	CharName = "蛋糕卷公主",
	Text = "是的，夫人。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_02_dangaojuan",
	NextID = 14406405,
}
StorySpeechConfig[StorySpeechID.Id14406405] =
{
	Id = 14406405,
	CharName = "薯片夫人",
	Text = "柜子上有寿司店的优惠券，你饿了就点那家的外卖吧。那么，我们走了~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_19_shupian",
	NextID = 14406406,
}
StorySpeechConfig[StorySpeechID.Id14406406] =
{
	Id = 14406406,
	CharName = "蛋糕卷公主",
	Text = "是的，夫人。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_02_dangaojuan",
	NextID = 14406407,
}
StorySpeechConfig[StorySpeechID.Id14406407] =
{
	Id = 14406407,
	CharName = "小魔仙",
	Text = "喂！你就是大家都说漂亮又善良的那个蛋糕卷公主吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_06_mofashi_cos10",
	NextID = 14406408,
}
StorySpeechConfig[StorySpeechID.Id14406408] =
{
	Id = 14406408,
	CharName = "蛋糕卷公主",
	Text = "你认识我吗？小魔仙。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_02_dangaojuan",
	NextID = 14406409,
}
StorySpeechConfig[StorySpeechID.Id14406409] =
{
	Id = 14406409,
	CharName = "小魔仙",
	Text = "嘿嘿，我是寿司店的精灵，听寿司们说，这里有个真正的公主呢~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_06_mofashi_cos10",
	NextID = 14406410,
}
StorySpeechConfig[StorySpeechID.Id14406410] =
{
	Id = 14406410,
	CharName = "蛋糕卷公主",
	Text = "真正的公主吗？可是我没有合适的礼服，不能去参加王子的舞会。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_02_dangaojuan",
	NextID = 14406411,
}
StorySpeechConfig[StorySpeechID.Id14406411] =
{
	Id = 14406411,
	CharName = "小魔仙",
	Text = "这有什么难的？把你打扮成寿司卷公主，就可以去参加日式烤肉派对了呀~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_06_mofashi_cos10",
	NextID = 14406412,
}
StorySpeechConfig[StorySpeechID.Id14406412] =
{
	Id = 14406412,
	CharName = "蛋糕卷公主",
	Text = "哇~那我要怎么做呢？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_02_dangaojuan",
	NextID = 14406413,
}
StorySpeechConfig[StorySpeechID.Id14406413] =
{
	Id = 14406413,
	CharName = "小魔仙",
	Text = "只要打赢寿司三兄弟，得到他们的认可就好了~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_06_mofashi_cos10",
}
StorySpeechConfig[StorySpeechID.Id14406501] =
{
	Id = 14406501,
	CharName = "栗子蛋糕公主",
	Text = "哎……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_03_qiaokelidan",
	NextID = 14406502,
}
StorySpeechConfig[StorySpeechID.Id14406502] =
{
	Id = 14406502,
	CharName = "培根女巫",
	Text = "怎么了，我的小公主？有什么烦心事吗？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_23_peigen",
	NextID = 14406503,
}
StorySpeechConfig[StorySpeechID.Id14406503] =
{
	Id = 14406503,
	CharName = "栗子蛋糕公主",
	Text = "我想去看看香浓镇举办的烟火大会。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_03_qiaokelidan",
	NextID = 14406504,
}
StorySpeechConfig[StorySpeechID.Id14406504] =
{
	Id = 14406504,
	CharName = "培根女巫",
	Text = "那里人太多了，而且什么样的人都会有。万一有人想偷走你的栗子，该怎么办呢？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_23_peigen",
	NextID = 14406505,
}
StorySpeechConfig[StorySpeechID.Id14406505] =
{
	Id = 14406505,
	CharName = "栗子蛋糕公主",
	Text = "但是……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_03_qiaokelidan",
	NextID = 14406506,
}
StorySpeechConfig[StorySpeechID.Id14406506] =
{
	Id = 14406506,
	CharName = "培根女巫",
	Text = "好了，不要再提这件事了，我给你梳头发吧。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_23_peigen",
	NextID = 14406507,
}
StorySpeechConfig[StorySpeechID.Id14406507] =
{
	Id = 14406507,
	CharName = "栗子蛋糕公主",
	Text = "哎……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_03_qiaokelidan",
	NextID = 14406508,
}
StorySpeechConfig[StorySpeechID.Id14406508] =
{
	Id = 14406508,
	CharName = "培根女巫",
	Text = "……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_23_peigen",
	NextID = 14406509,
}
StorySpeechConfig[StorySpeechID.Id14406509] =
{
	Id = 14406509,
	CharName = "栗子蛋糕公主",
	Text = "哎……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_03_qiaokelidan",
	NextID = 14406510,
}
StorySpeechConfig[StorySpeechID.Id14406510] =
{
	Id = 14406510,
	CharName = "培根女巫",
	Text = "真的很想去吗？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_23_peigen",
	NextID = 14406511,
}
StorySpeechConfig[StorySpeechID.Id14406511] =
{
	Id = 14406511,
	CharName = "栗子蛋糕公主",
	Text = "嗯……盛放的烟花，想从下面看。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_03_qiaokelidan",
	NextID = 14406512,
}
StorySpeechConfig[StorySpeechID.Id14406512] =
{
	Id = 14406512,
	CharName = "培根女巫",
	Text = "那我们得打扮一下，至少得把你的栗子和慕斯都保护起来。嗯，我想想，用玫瑰造型吧~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_23_peigen",
	NextID = 14406513,
}
StorySpeechConfig[StorySpeechID.Id14406513] =
{
	Id = 14406513,
	CharName = "栗子蛋糕公主",
	Text = "你最疼我了~~女巫~~那我们快开始吧。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_03_qiaokelidan",
	NextID = 14406514,
}
StorySpeechConfig[StorySpeechID.Id14406514] =
{
	Id = 14406514,
	CharName = "培根女巫",
	Text = "嗯，就是这个了，它身上的花采下来后是最适合装饰的了~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_23_peigen",
}
StorySpeechConfig[StorySpeechID.Id14406601] =
{
	Id = 14406601,
	CharName = "热狗先生",
	Text = "（腼腆）汉堡小姐~今天美食城的新品试吃会你去吗？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_24_regou",
	NextID = 14406602,
}
StorySpeechConfig[StorySpeechID.Id14406602] =
{
	Id = 14406602,
	CharName = "汉堡小姐",
	Text = "（暗暗想到）哇，热狗先生邀请我了~~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_29_hanbao",
	NextID = 14406603,
}
StorySpeechConfig[StorySpeechID.Id14406603] =
{
	Id = 14406603,
	CharName = "热狗先生",
	Text = "（腼腆）如果你去的话，我晚上可以来接你。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_24_regou",
	NextID = 14406604,
}
StorySpeechConfig[StorySpeechID.Id14406604] =
{
	Id = 14406604,
	CharName = "汉堡小姐",
	Text = "嗯，好的，那到时候热狗先生打算穿什么呢？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_29_hanbao",
	NextID = 14406605,
}
StorySpeechConfig[StorySpeechID.Id14406605] =
{
	Id = 14406605,
	CharName = "热狗先生",
	Text = "诶，我嘛？可能打扮得特别一点，你觉得鸡肉卷怎么样？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_24_regou",
	NextID = 14406606,
}
StorySpeechConfig[StorySpeechID.Id14406606] =
{
	Id = 14406606,
	CharName = "汉堡小姐",
	Text = "哇，热狗先生穿鸡肉卷装？好期待~那我穿什么好呢？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_29_hanbao",
	NextID = 14406607,
}
StorySpeechConfig[StorySpeechID.Id14406607] =
{
	Id = 14406607,
	CharName = "热狗先生",
	Text = "啊，我觉得汉堡小姐穿什么都很漂亮。（腼腆）",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_24_regou",
	NextID = 14406608,
}
StorySpeechConfig[StorySpeechID.Id14406608] =
{
	Id = 14406608,
	CharName = "汉堡小姐",
	Text = "上次在外星旅游时买的粉色礼服，现在还放在行李箱里~那我回去找一找。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_29_hanbao",
}
StorySpeechConfig[StorySpeechID.Id14406701] =
{
	Id = 14406701,
	CharName = "炸鸡魔后",
	Text = "走过路过不要错过，你一定没有见过的奇妙炸鸡料理！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_28_jichi",
	NextID = 14406702,
}
StorySpeechConfig[StorySpeechID.Id14406702] =
{
	Id = 14406702,
	CharName = "热狗先生",
	Text = "（路过时，听到声音转头看了一眼）",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_24_regou",
	NextID = 14406703,
}
StorySpeechConfig[StorySpeechID.Id14406703] =
{
	Id = 14406703,
	CharName = "炸鸡魔后",
	Text = "啊~先生，你似乎有烦恼噢~要不要试一下奇妙鸡料理？可能会为你带来好运噢~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_28_jichi",
	NextID = 14406704,
}
StorySpeechConfig[StorySpeechID.Id14406704] =
{
	Id = 14406704,
	CharName = "热狗先生",
	Text = "哎，是有烦恼……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_24_regou",
	NextID = 14406705,
}
StorySpeechConfig[StorySpeechID.Id14406705] =
{
	Id = 14406705,
	CharName = "炸鸡魔后",
	Text = "是为了女孩子感到苦恼吗？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_28_jichi",
	NextID = 14406706,
}
StorySpeechConfig[StorySpeechID.Id14406706] =
{
	Id = 14406706,
	CharName = "热狗先生",
	Text = "我想约一个女孩子去参加试吃会，但是该怎么说？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_24_regou",
	NextID = 14406707,
}
StorySpeechConfig[StorySpeechID.Id14406707] =
{
	Id = 14406707,
	CharName = "炸鸡魔后",
	Text = "大胆地说出来就好了吧~对方的工作是什么呢？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_28_jichi",
	NextID = 14406708,
}
StorySpeechConfig[StorySpeechID.Id14406708] =
{
	Id = 14406708,
	CharName = "热狗先生",
	Text = "她是在快餐店工作的，负责汉堡区的……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_24_regou",
	NextID = 14406709,
}
StorySpeechConfig[StorySpeechID.Id14406709] =
{
	Id = 14406709,
	CharName = "炸鸡魔后",
	Text = "噢！那这个一定行（拿出鸡肉卷套装）",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_28_jichi",
	NextID = 14406710,
}
StorySpeechConfig[StorySpeechID.Id14406710] =
{
	Id = 14406710,
	CharName = "热狗先生",
	Text = "诶！这不是专卖汉堡的K记推出的新品主食吗？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_24_regou",
	NextID = 14406711,
}
StorySpeechConfig[StorySpeechID.Id14406711] =
{
	Id = 14406711,
	CharName = "炸鸡魔后",
	Text = "这是我自己发明的可穿戴超大型鸡肉卷，你们穿上就是情侣装了噢~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_28_jichi",
	NextID = 14406712,
}
StorySpeechConfig[StorySpeechID.Id14406712] =
{
	Id = 14406712,
	CharName = "热狗先生",
	Text = "（腼腆）哇，这么一说是很有道理，能卖给我吗？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_24_regou",
	NextID = 14406713,
}
StorySpeechConfig[StorySpeechID.Id14406713] =
{
	Id = 14406713,
	CharName = "炸鸡魔后",
	Text = "吃一份我新做的鸡屁股刺身，我就送给你~诶！！你这是什么表情，不许走！必须吃！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_28_jichi",
}
StorySpeechConfig[StorySpeechID.Id14406801] =
{
	Id = 14406801,
	CharName = "辣条国王",
	Text = "番茄酱！番茄酱你快来！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_30_shutiao_cos10",
	NextID = 14406802,
}
StorySpeechConfig[StorySpeechID.Id14406802] =
{
	Id = 14406802,
	CharName = "番茄酱侍卫",
	Text = "参见陛下。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_31_fanqiejiang",
	NextID = 14406803,
}
StorySpeechConfig[StorySpeechID.Id14406803] =
{
	Id = 14406803,
	CharName = "辣条国王",
	Text = "你看我这身装扮怎么样？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_30_shutiao_cos10",
	NextID = 14406804,
}
StorySpeechConfig[StorySpeechID.Id14406804] =
{
	Id = 14406804,
	CharName = "番茄酱侍卫",
	Text = "（清嗓）陛下，这件衣服扮相古怪，又有浓烈的气味，会有损您的威严的，您真的要穿吗？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_31_fanqiejiang",
	NextID = 14406805,
}
StorySpeechConfig[StorySpeechID.Id14406805] =
{
	Id = 14406805,
	CharName = "辣条国王",
	Text = "内务司已经按我吩咐，给你也做了一套相衬的侍卫服，只要你打赢我，我就赏赐给你。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_30_shutiao_cos10",
	NextID = 14406806,
}
StorySpeechConfig[StorySpeechID.Id14406806] =
{
	Id = 14406806,
	CharName = "番茄酱侍卫",
	Text = "……陛下……属下觉得现在的制服挺好的。就不换了吧……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_31_fanqiejiang",
	NextID = 14406807,
}
StorySpeechConfig[StorySpeechID.Id14406807] =
{
	Id = 14406807,
	CharName = "辣条国王",
	Text = "你胆敢抗旨？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_30_shutiao_cos10",
	NextID = 14406808,
}
StorySpeechConfig[StorySpeechID.Id14406808] =
{
	Id = 14406808,
	CharName = "番茄酱侍卫",
	Text = "属下不敢！那么，属下失礼了！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_31_fanqiejiang",
}
StorySpeechConfig[StorySpeechID.Id14406901] =
{
	Id = 14406901,
	CharName = "旋风薯条国王",
	Text = "侍卫长！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_30_shutiao_cos30",
	NextID = 14406902,
}
StorySpeechConfig[StorySpeechID.Id14406902] =
{
	Id = 14406902,
	CharName = "番茄酱侍卫",
	Text = "参见陛下。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_31_fanqiejiang",
	NextID = 14406903,
}
StorySpeechConfig[StorySpeechID.Id14406903] =
{
	Id = 14406903,
	CharName = "旋风薯条国王",
	Text = "你看我今天这身装扮怎么样？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_30_shutiao_cos30",
	NextID = 14406904,
}
StorySpeechConfig[StorySpeechID.Id14406904] =
{
	Id = 14406904,
	CharName = "番茄酱侍卫",
	Text = "（清嗓）陛下，您的理想不是要做最脆最直的薯条嘛！穿这种弯弯的薯条套装，会有损您的意志的，您真的要穿吗？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_31_fanqiejiang",
	NextID = 14406905,
}
StorySpeechConfig[StorySpeechID.Id14406905] =
{
	Id = 14406905,
	CharName = "旋风薯条国王",
	Text = "内务司已经按我吩咐，给你也做了一套相衬的侍卫服，只要你打赢我，我就赏赐给你。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_30_shutiao_cos30",
	NextID = 14406906,
}
StorySpeechConfig[StorySpeechID.Id14406906] =
{
	Id = 14406906,
	CharName = "番茄酱侍卫",
	Text = "……陛下……属下觉得现在的制服挺好的。就不换了吧……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_31_fanqiejiang",
	NextID = 14406907,
}
StorySpeechConfig[StorySpeechID.Id14406907] =
{
	Id = 14406907,
	CharName = "旋风薯条国王",
	Text = "你胆敢抗旨？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_30_shutiao_cos30",
	NextID = 14406908,
}
StorySpeechConfig[StorySpeechID.Id14406908] =
{
	Id = 14406908,
	CharName = "番茄酱侍卫",
	Text = "属下不敢！那么，属下失礼了！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_31_fanqiejiang",
}
StorySpeechConfig[StorySpeechID.Id14407001] =
{
	Id = 14407001,
	CharName = "巧克力饼干条",
	Text = "侍卫长！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_30_shutiao_cos20",
	NextID = 14407002,
}
StorySpeechConfig[StorySpeechID.Id14407002] =
{
	Id = 14407002,
	CharName = "番茄酱侍卫",
	Text = "参见陛下。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_31_fanqiejiang",
	NextID = 14407003,
}
StorySpeechConfig[StorySpeechID.Id14407003] =
{
	Id = 14407003,
	CharName = "巧克力饼干条",
	Text = "你看我今天这身装扮怎么样？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_30_shutiao_cos20",
	NextID = 14407004,
}
StorySpeechConfig[StorySpeechID.Id14407004] =
{
	Id = 14407004,
	CharName = "番茄酱侍卫",
	Text = "（清嗓）陛下，这太甜了，不符合您的气质。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_31_fanqiejiang",
	NextID = 14407005,
}
StorySpeechConfig[StorySpeechID.Id14407005] =
{
	Id = 14407005,
	CharName = "巧克力饼干条",
	Text = "内务司已经按我吩咐，给你也做了一套相衬的侍卫服，只要你打赢我，我就赏赐给你。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_30_shutiao_cos20",
	NextID = 14407006,
}
StorySpeechConfig[StorySpeechID.Id14407006] =
{
	Id = 14407006,
	CharName = "番茄酱侍卫",
	Text = "……陛下……属下觉得现在的制服挺好的。就不换了吧……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_31_fanqiejiang",
	NextID = 14407007,
}
StorySpeechConfig[StorySpeechID.Id14407007] =
{
	Id = 14407007,
	CharName = "巧克力饼干条",
	Text = "你胆敢抗旨？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_30_shutiao_cos20",
	NextID = 14407008,
}
StorySpeechConfig[StorySpeechID.Id14407008] =
{
	Id = 14407008,
	CharName = "番茄酱侍卫",
	Text = "属下不敢！那么，属下失礼了！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_31_fanqiejiang",
}
StorySpeechConfig[StorySpeechID.Id14407101] =
{
	Id = 14407101,
	CharName = "部落酋长",
	Text = "尊贵的陛下，你好，我是来自只抽素材星的酋长，请允许我向您进献一件珍贵的礼物。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_04_UnlockChief",
	NextID = 14407102,
}
StorySpeechConfig[StorySpeechID.Id14407102] =
{
	Id = 14407102,
	CharName = "薯条国王",
	Text = "呈上来。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_30_shutiao",
	NextID = 14407103,
}
StorySpeechConfig[StorySpeechID.Id14407103] =
{
	Id = 14407103,
	CharName = "部落酋长",
	Text = "这是一件散发着辣椒气味的摔跤服，是用我们星球罕见的野山椒熬制的，对于锻炼肌肉很有帮助。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_04_UnlockChief",
	NextID = 14407104,
}
StorySpeechConfig[StorySpeechID.Id14407104] =
{
	Id = 14407104,
	CharName = "薯条国王",
	Text = "噢？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_30_shutiao",
	NextID = 14407105,
}
StorySpeechConfig[StorySpeechID.Id14407105] =
{
	Id = 14407105,
	CharName = "部落酋长",
	Text = "（乘机）我族大量同胞因抽卡破产被困不夜城，还请陛下通融一下，再借9000京玉璧，容我先带族人回家。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_04_UnlockChief",
	NextID = 14407106,
}
StorySpeechConfig[StorySpeechID.Id14407106] =
{
	Id = 14407106,
	CharName = "薯条国王",
	Text = "拿着这张支票，去内务司领钱吧。不过话说京是什么单位？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_30_shutiao",
	NextID = 14407107,
}
StorySpeechConfig[StorySpeechID.Id14407107] =
{
	Id = 14407107,
	CharName = "部落酋长",
	Text = "多谢陛下。说到这个单位，大约是10的32次方。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_04_UnlockChief",
	NextID = 14407108,
}
StorySpeechConfig[StorySpeechID.Id14407108] =
{
	Id = 14407108,
	CharName = "薯条国王",
	Text = "以后千万告诫族人，小抽怡情，大抽伤身，凡事都要节制。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_30_shutiao",
	NextID = 14407109,
}
StorySpeechConfig[StorySpeechID.Id14407109] =
{
	Id = 14407109,
	CharName = "部落酋长",
	Text = "是的，陛下， 那么我这就告退了。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_04_UnlockChief",
	NextID = 14407110,
}
StorySpeechConfig[StorySpeechID.Id14407110] =
{
	Id = 14407110,
	CharName = "薯条国王",
	Text = "番茄酱！番茄酱你快来！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_30_shutiao",
	NextID = 14407111,
}
StorySpeechConfig[StorySpeechID.Id14407111] =
{
	Id = 14407111,
	CharName = "番茄酱侍卫",
	Text = "陛下，请问有什么要吩咐属下的？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_31_fanqiejiang",
	NextID = 14407112,
}
StorySpeechConfig[StorySpeechID.Id14407112] =
{
	Id = 14407112,
	CharName = "薯条国王",
	Text = "你看这件辣椒健身服，据说对于锻炼肌肉有帮助。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_30_shutiao",
	NextID = 14407113,
}
StorySpeechConfig[StorySpeechID.Id14407113] =
{
	Id = 14407113,
	CharName = "番茄酱侍卫",
	Text = "（清嗓）陛下，这件衣服扮相如此古怪，又有浓烈的气味，会有损您的威严的，请让我收起来！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_31_fanqiejiang",
	NextID = 14407114,
}
StorySpeechConfig[StorySpeechID.Id14407114] =
{
	Id = 14407114,
	CharName = "薯条国王",
	Text = "嘿嘿~那么就按照老规矩，我们来摔一场，我赢的话你就不能阻止我咯~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_30_shutiao",
}
StorySpeechConfig[StorySpeechID.Id14407201] =
{
	Id = 14407201,
	CharName = "黑巧克力皇后",
	Text = "亲爱的陛下，你看，这是我最新研制的巧克力健身服，穿上健身能使肌肉变得黝黑发亮！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_11_tiantong",
	NextID = 14407202,
}
StorySpeechConfig[StorySpeechID.Id14407202] =
{
	Id = 14407202,
	CharName = "薯条国王",
	Text = "诶？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_30_shutiao",
	NextID = 14407203,
}
StorySpeechConfig[StorySpeechID.Id14407203] =
{
	Id = 14407203,
	CharName = "黑巧克力皇后",
	Text = "（趁机）……陛下，您宝库里那面懂事的魔镜能送给我吗？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_11_tiantong",
	NextID = 14407204,
}
StorySpeechConfig[StorySpeechID.Id14407204] =
{
	Id = 14407204,
	CharName = "薯条国王",
	Text = "皇后那面魔镜确实太耿直了，拿着这张提货单，去内务处领取吧。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_30_shutiao",
	NextID = 14407205,
}
StorySpeechConfig[StorySpeechID.Id14407205] =
{
	Id = 14407205,
	CharName = "黑巧克力皇后",
	Text = "多谢陛下~（高高兴兴的走了）",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_11_tiantong",
	NextID = 14407206,
}
StorySpeechConfig[StorySpeechID.Id14407206] =
{
	Id = 14407206,
	CharName = "薯条国王",
	Text = "番茄酱~番茄酱你快来~~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_30_shutiao",
	NextID = 14407207,
}
StorySpeechConfig[StorySpeechID.Id14407207] =
{
	Id = 14407207,
	CharName = "番茄酱侍卫",
	Text = "陛下，请问有什么要吩咐属下的？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_31_fanqiejiang",
	NextID = 14407208,
}
StorySpeechConfig[StorySpeechID.Id14407208] =
{
	Id = 14407208,
	CharName = "薯条国王",
	Text = "你看这件巧克力健身服，据说穿上健身肌肉会变得黝黑发亮~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_30_shutiao",
	NextID = 14407209,
}
StorySpeechConfig[StorySpeechID.Id14407209] =
{
	Id = 14407209,
	CharName = "番茄酱侍卫",
	Text = "（清嗓）陛下，这件衣服含糖量惊人，热量极高，会有损您的健康的，请让我收起来！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_31_fanqiejiang",
	NextID = 14407210,
}
StorySpeechConfig[StorySpeechID.Id14407210] =
{
	Id = 14407210,
	CharName = "薯条国王",
	Text = "嘿嘿~那么就按照老规矩，我们来摔一场，我赢的话你就不能阻止我咯~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_30_shutiao",
}
StorySpeechConfig[StorySpeechID.Id14407301] =
{
	Id = 14407301,
	CharName = "爆米花女王",
	Text = "国王陛下。我这次为您带来了这套旋风连体服，穿上之后可以让你的柔韧性大大提升",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_22_baomihua",
	NextID = 14407302,
}
StorySpeechConfig[StorySpeechID.Id14407302] =
{
	Id = 14407302,
	CharName = "薯条国王",
	Text = "咦？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_30_shutiao",
	NextID = 14407303,
}
StorySpeechConfig[StorySpeechID.Id14407303] =
{
	Id = 14407303,
	CharName = "爆米花女王",
	Text = "不仅如此~（小声地说）我还买了另外一套沙拉酱侍卫服来配合这件旋风连体服，组合使用效果更佳！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_22_baomihua",
	NextID = 14407304,
}
StorySpeechConfig[StorySpeechID.Id14407304] =
{
	Id = 14407304,
	CharName = "薯条国王",
	Text = "噢？！果真如此？（灵光一闪）",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_30_shutiao",
	NextID = 14407305,
}
StorySpeechConfig[StorySpeechID.Id14407305] =
{
	Id = 14407305,
	CharName = "爆米花女王",
	Text = "（乘机）这张全国院线免税议案麻烦您签一下。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_22_baomihua",
	NextID = 14407306,
}
StorySpeechConfig[StorySpeechID.Id14407306] =
{
	Id = 14407306,
	CharName = "薯条国王",
	Text = "（刷刷刷签完）",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_30_shutiao",
	NextID = 14407307,
}
StorySpeechConfig[StorySpeechID.Id14407307] =
{
	Id = 14407307,
	CharName = "薯条国王",
	Text = "刚才是什么议案来着……算了，不管了。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_30_shutiao",
	NextID = 14407308,
}
StorySpeechConfig[StorySpeechID.Id14407308] =
{
	Id = 14407308,
	CharName = "薯条国王",
	Text = "番茄酱~番茄酱你快来~~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_30_shutiao",
	NextID = 14407309,
}
StorySpeechConfig[StorySpeechID.Id14407309] =
{
	Id = 14407309,
	CharName = "番茄酱侍卫",
	Text = "陛下，请问有什么要吩咐属下的？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_31_fanqiejiang",
	NextID = 14407310,
}
StorySpeechConfig[StorySpeechID.Id14407310] =
{
	Id = 14407310,
	CharName = "薯条国王",
	Text = "你看这件套旋风连体服，是不是很酷炫！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_30_shutiao",
	NextID = 14407311,
}
StorySpeechConfig[StorySpeechID.Id14407311] =
{
	Id = 14407311,
	CharName = "番茄酱侍卫",
	Text = "咳咳，（这是什么鬼衣服）陛下，您的理想不是要做最脆最直的薯条嘛！穿这种弯弯的薯条套装，会有损您的意志的，请让我收起来！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_31_fanqiejiang",
	NextID = 14407312,
}
StorySpeechConfig[StorySpeechID.Id14407312] =
{
	Id = 14407312,
	CharName = "薯条国王",
	Text = "既然如此~那么就按照老规矩，我们来摔一场，我赢的话你就不能阻止我咯~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_30_shutiao",
}
StorySpeechConfig[StorySpeechID.Id14407401] =
{
	Id = 14407401,
	CharName = "邪道料理师",
	Text = "魔后，你跟着我学习厨艺也有三年了。今天是烤肉镇的草原节，你有什么想法？",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	LeftIcon = "Arena_Pir_DarkCooker",
	NextID = 14407402,
}
StorySpeechConfig[StorySpeechID.Id14407402] =
{
	Id = 14407402,
	CharName = "炸鸡魔后",
	Text = "既然是草原节，那么我想制作出符合草原主题的料理是必须的。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_28_jichi",
	NextID = 14407403,
}
StorySpeechConfig[StorySpeechID.Id14407403] =
{
	Id = 14407403,
	CharName = "邪道料理师",
	Text = "嗯，说得很好，那怎么才能做出符合草原主题的料理呢？",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	LeftIcon = "Arena_Pir_DarkCooker",
	NextID = 14407404,
}
StorySpeechConfig[StorySpeechID.Id14407404] =
{
	Id = 14407404,
	CharName = "炸鸡魔后",
	Text = "我觉得是当地的传统香料和食材，而结合一些凸显当地特色的烹饪手……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_28_jichi",
	NextID = 14407405,
}
StorySpeechConfig[StorySpeechID.Id14407405] =
{
	Id = 14407405,
	CharName = "邪道料理师",
	Text = "（猛摇头）错，大错特错！你没有搞清楚食物的本质！是本质！",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	LeftIcon = "Arena_Pir_DarkCooker",
	NextID = 14407406,
}
StorySpeechConfig[StorySpeechID.Id14407406] =
{
	Id = 14407406,
	CharName = "炸鸡魔后",
	Text = "（额角流下了紧张的汗水）额……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_28_jichi",
	NextID = 14407407,
}
StorySpeechConfig[StorySpeechID.Id14407407] =
{
	Id = 14407407,
	CharName = "邪道料理师",
	Text = "一个食物的本质就是厨师，厨师要身心合一才能做出地道料理，而身心合一最重要的就是要一身当地的行头！",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	LeftIcon = "Arena_Pir_DarkCooker",
	NextID = 14407408,
}
StorySpeechConfig[StorySpeechID.Id14407408] =
{
	Id = 14407408,
	CharName = "炸鸡魔后",
	Text = "前辈，我觉得……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_28_jichi",
	NextID = 14407409,
}
StorySpeechConfig[StorySpeechID.Id14407409] =
{
	Id = 14407409,
	CharName = "邪道料理师",
	Text = "住口！我不用你觉得，我要我觉得。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	LeftIcon = "Arena_Pir_DarkCooker",
	NextID = 14407410,
}
StorySpeechConfig[StorySpeechID.Id14407410] =
{
	Id = 14407410,
	CharName = "炸鸡魔后",
	Text = "那现在……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_28_jichi",
	NextID = 14407411,
}
StorySpeechConfig[StorySpeechID.Id14407411] =
{
	Id = 14407411,
	CharName = "邪道料理师",
	Text = "我给你准备了一身牧羊女的行头，等等你先去店里表演一个空手套野狼，然后回来把这身衣服换上，我们的草原节就算是摸到本质了！",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	LeftIcon = "Arena_Pir_DarkCooker",
}
StorySpeechConfig[StorySpeechID.Id14407501] =
{
	Id = 14407501,
	CharName = "邪道料理师",
	Text = "魔后，你跟着我学习厨艺也有三年了。今天是烤肉镇的汤包节，你有什么想法？",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	LeftIcon = "Arena_Pir_DarkCooker",
	NextID = 14407502,
}
StorySpeechConfig[StorySpeechID.Id14407502] =
{
	Id = 14407502,
	CharName = "炸鸡魔后",
	Text = "前辈，一个烤肉镇为什么会有汤包节？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_28_jichi",
	NextID = 14407503,
}
StorySpeechConfig[StorySpeechID.Id14407503] =
{
	Id = 14407503,
	CharName = "邪道料理师",
	Text = "这你就有所不知，我镇屹立三十年不倒，靠的就是层出不穷的主题活动。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	LeftIcon = "Arena_Pir_DarkCooker",
	NextID = 14407504,
}
StorySpeechConfig[StorySpeechID.Id14407504] =
{
	Id = 14407504,
	CharName = "炸鸡魔后",
	Text = "但我想追求极致的鸡翅料理技巧，对汤包实在没有想法。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_28_jichi",
	NextID = 14407505,
}
StorySpeechConfig[StorySpeechID.Id14407505] =
{
	Id = 14407505,
	CharName = "邪道料理师",
	Text = "幼稚！难道汤包只能是汤包，里面不能包着一对鸡翅嘛！",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	LeftIcon = "Arena_Pir_DarkCooker",
	NextID = 14407506,
}
StorySpeechConfig[StorySpeechID.Id14407506] =
{
	Id = 14407506,
	CharName = "炸鸡魔后",
	Text = "（震惊）前辈一席话，令我茅塞顿开，那请问我能做些什么呢？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_28_jichi",
	NextID = 14407507,
}
StorySpeechConfig[StorySpeechID.Id14407507] =
{
	Id = 14407507,
	CharName = "邪道料理师",
	Text = "有个情况你要了解一下，就是我们店啊，因为差评率100%，目前已经没有人愿意来尝试食物了。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	LeftIcon = "Arena_Pir_DarkCooker",
	NextID = 14407508,
}
StorySpeechConfig[StorySpeechID.Id14407508] =
{
	Id = 14407508,
	CharName = "炸鸡魔后",
	Text = "前辈，我有一计，我们可以用蒸煮法，提高食物的气，所谓酒香不怕巷子……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_28_jichi",
	NextID = 14407509,
}
StorySpeechConfig[StorySpeechID.Id14407509] =
{
	Id = 14407509,
	CharName = "邪道料理师",
	Text = "简直牛头不对马嘴！我们要结合时代，根据年轻人的喜好来吸引他们。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	LeftIcon = "Arena_Pir_DarkCooker",
	NextID = 14407510,
}
StorySpeechConfig[StorySpeechID.Id14407510] =
{
	Id = 14407510,
	CharName = "炸鸡魔后",
	Text = "那办法是？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_28_jichi",
	NextID = 14407511,
}
StorySpeechConfig[StorySpeechID.Id14407511] =
{
	Id = 14407511,
	CharName = "邪道料理师",
	Text = "我研究多日，发现最近流行武侠风格。所以，我花老价钱从外星球请了一个群演。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	LeftIcon = "Arena_Pir_DarkCooker",
	NextID = 14407512,
}
StorySpeechConfig[StorySpeechID.Id14407512] =
{
	Id = 14407512,
	CharName = "炸鸡魔后",
	Text = "我们要表演功夫汤包吗？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_28_jichi",
	NextID = 14407513,
}
StorySpeechConfig[StorySpeechID.Id14407513] =
{
	Id = 14407513,
	CharName = "邪道料理师",
	Text = "不要那么狭隘，丫头~饭店一定卖食物吗？等等你和大师过两招，熟悉一下，然后打扮成这个样子，亮个相就好了！",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	LeftIcon = "Arena_Pir_DarkCooker",
}
StorySpeechConfig[StorySpeechID.Id14407601] =
{
	Id = 14407601,
	CharName = "邪道料理师",
	Text = "魔后，你跟着我学习厨艺也有三年了。今天是烤肉镇的甜甜圈节，你有什么想法？",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	LeftIcon = "Arena_Pir_DarkCooker",
	NextID = 14407602,
}
StorySpeechConfig[StorySpeechID.Id14407602] =
{
	Id = 14407602,
	CharName = "炸鸡魔后",
	Text = "前辈，为什么甜甜圈节也要放在我们的烤肉镇举办呢？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_28_jichi",
	NextID = 14407603,
}
StorySpeechConfig[StorySpeechID.Id14407603] =
{
	Id = 14407603,
	CharName = "邪道料理师",
	Text = "先不管这个吧，但这次是我们饭店翻身的最佳机会！去年的100万个甜甜圈到现在我还存在库房呢~",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	LeftIcon = "Arena_Pir_DarkCooker",
	NextID = 14407604,
}
StorySpeechConfig[StorySpeechID.Id14407604] =
{
	Id = 14407604,
	CharName = "炸鸡魔后",
	Text = "就是前辈贷了50年款才付清管存费的那个库房吗？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_28_jichi",
	NextID = 14407605,
}
StorySpeechConfig[StorySpeechID.Id14407605] =
{
	Id = 14407605,
	CharName = "邪道料理师",
	Text = "对！就是那个！趁着今年主题节卖出去，我一下子就能还清50年的贷款，还倒赚8000多块了！",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	LeftIcon = "Arena_Pir_DarkCooker",
	NextID = 14407606,
}
StorySpeechConfig[StorySpeechID.Id14407606] =
{
	Id = 14407606,
	CharName = "炸鸡魔后",
	Text = "（震惊）前辈！那去年小镇问你直接6000元全部收走你为什么不答应呢？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_28_jichi",
	NextID = 14407607,
}
StorySpeechConfig[StorySpeechID.Id14407607] =
{
	Id = 14407607,
	CharName = "邪道料理师",
	Text = "所以说你们年轻人就是算不来帐，今年一旦销出，赚的可是8000多块，我还看着那6000多块干什么？",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	LeftIcon = "Arena_Pir_DarkCooker",
	NextID = 14407608,
}
StorySpeechConfig[StorySpeechID.Id14407608] =
{
	Id = 14407608,
	CharName = "炸鸡魔后",
	Text = "这么一说也对，那今年我们一定要好好推广一波，把甜甜圈都卖掉！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_28_jichi",
	NextID = 14407609,
}
StorySpeechConfig[StorySpeechID.Id14407609] =
{
	Id = 14407609,
	CharName = "邪道料理师",
	Text = "今天可是背水一战了！等等我去找个多拿滋来，魔后你和它好好干一架，趁大家都来看的时候，我就赶紧推销。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	LeftIcon = "Arena_Pir_DarkCooker",
	NextID = 14407610,
}
StorySpeechConfig[StorySpeechID.Id14407610] =
{
	Id = 14407610,
	CharName = "炸鸡魔后",
	Text = "明白了，前辈！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_28_jichi",
}
StorySpeechConfig[StorySpeechID.Id14407701] =
{
	Id = 14407701,
	CharName = "薯片夫人",
	Text = "对，对，非常完美，女王大人。身体稍侧一些，光线会更自然。OK！完美！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_19_shupian",
	NextID = 14407702,
}
StorySpeechConfig[StorySpeechID.Id14407702] =
{
	Id = 14407702,
	CharName = "爆米花女王",
	Text = "这次我打算买断你们电视台整一周所有的广告时间。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_22_baomihua",
	NextID = 14407703,
}
StorySpeechConfig[StorySpeechID.Id14407703] =
{
	Id = 14407703,
	CharName = "薯片夫人",
	Text = "哇~女王大人，您实在是太慷慨了。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_19_shupian",
	NextID = 14407704,
}
StorySpeechConfig[StorySpeechID.Id14407704] =
{
	Id = 14407704,
	CharName = "爆米花女王",
	Text = "等等再拍一支这次产品的宣传片。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_22_baomihua",
	NextID = 14407705,
}
StorySpeechConfig[StorySpeechID.Id14407705] =
{
	Id = 14407705,
	CharName = "薯片夫人",
	Text = "一切听您安排，女王大人。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_19_shupian",
	NextID = 14407706,
}
StorySpeechConfig[StorySpeechID.Id14407706] =
{
	Id = 14407706,
	CharName = "爆米花女王",
	Text = "情节是这样，等等我和一个彩虹墨水打起来，最后墨水被打败，溅我一身，这时候镜头特写，把多彩的颜色凸显出来。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_22_baomihua",
	NextID = 14407707,
}
StorySpeechConfig[StorySpeechID.Id14407707] =
{
	Id = 14407707,
	CharName = "薯片夫人",
	Text = "完美的镜头运动，完美的情节设计。不过，女王大人要亲自来拍摄吗？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_19_shupian",
	NextID = 14407708,
}
StorySpeechConfig[StorySpeechID.Id14407708] =
{
	Id = 14407708,
	CharName = "爆米花女王",
	Text = "那当然。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_22_baomihua",
	NextID = 14407709,
}
StorySpeechConfig[StorySpeechID.Id14407709] =
{
	Id = 14407709,
	CharName = "薯片夫人",
	Text = "噢，能拍这样一期节目我实在是太荣幸了。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_19_shupian",
	NextID = 14407710,
}
StorySpeechConfig[StorySpeechID.Id14407710] =
{
	Id = 14407710,
	CharName = "爆米花女王",
	Text = "那么，一切就绪，就开始吧。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_22_baomihua",
}
StorySpeechConfig[StorySpeechID.Id14407801] =
{
	Id = 14407801,
	CharName = "薯片夫人",
	Text = "女王大人，这次的焦糖爆米花宣传同样是由我为您拍摄的。请问您想怎么呈现这个产品呢？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_19_shupian",
	NextID = 14407802,
}
StorySpeechConfig[StorySpeechID.Id14407802] =
{
	Id = 14407802,
	CharName = "爆米花女王",
	Text = "我们院线的焦糖爆米花最与众不同的就是糖浆的制作方式。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_22_baomihua",
	NextID = 14407803,
}
StorySpeechConfig[StorySpeechID.Id14407803] =
{
	Id = 14407803,
	CharName = "薯片夫人",
	Text = "哇~女王大人，我光是听了就很想吃。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_19_shupian",
	NextID = 14407804,
}
StorySpeechConfig[StorySpeechID.Id14407804] =
{
	Id = 14407804,
	CharName = "爆米花女王",
	Text = "别这么失态嘛，薯片夫人，你也是个贵妇人。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_22_baomihua",
	NextID = 14407805,
}
StorySpeechConfig[StorySpeechID.Id14407805] =
{
	Id = 14407805,
	CharName = "薯片夫人",
	Text = "啊，抱歉抱歉，因为女王大人您描述得太诱人了，所以我没有忍住。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_19_shupian",
	NextID = 14407806,
}
StorySpeechConfig[StorySpeechID.Id14407806] =
{
	Id = 14407806,
	CharName = "爆米花女王",
	Text = "情节是这样，等等我和一个火精灵打起来，最后火精灵被打败爆炸，这时候镜头特写，把焦糖爆米花突出出来。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_22_baomihua",
	NextID = 14407807,
}
StorySpeechConfig[StorySpeechID.Id14407807] =
{
	Id = 14407807,
	CharName = "薯片夫人",
	Text = "光是听您的描述，我就好像已经闻到了爆米花中爆发出的那种令人无法抗拒的甜味。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_19_shupian",
	NextID = 14407808,
}
StorySpeechConfig[StorySpeechID.Id14407808] =
{
	Id = 14407808,
	CharName = "爆米花女王",
	Text = "对！就是这种感觉，搭配喜剧效果更佳。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_22_baomihua",
	NextID = 14407809,
}
StorySpeechConfig[StorySpeechID.Id14407809] =
{
	Id = 14407809,
	CharName = "薯片夫人",
	Text = "噢，能拍这样一期节目我实在是太荣幸了。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_19_shupian",
	NextID = 14407810,
}
StorySpeechConfig[StorySpeechID.Id14407810] =
{
	Id = 14407810,
	CharName = "爆米花女王",
	Text = "那么，一切就绪，就开始吧。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_22_baomihua",
}
StorySpeechConfig[StorySpeechID.Id14407901] =
{
	Id = 14407901,
	CharName = "薯片夫人",
	Text = "女王大人，听说这次要推介的产品是珍贵的白松露爆米花？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_19_shupian",
	NextID = 14407902,
}
StorySpeechConfig[StorySpeechID.Id14407902] =
{
	Id = 14407902,
	CharName = "爆米花女王",
	Text = "每一盒爆米花中都加入了10克白松露，为了防止遇火走味，我们专门聘请了前任厨神做我们的爆米花顾问。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_22_baomihua",
	NextID = 14407903,
}
StorySpeechConfig[StorySpeechID.Id14407903] =
{
	Id = 14407903,
	CharName = "薯片夫人",
	Text = "哇~女王大人，不知道我有没有荣幸吃到。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_19_shupian",
	NextID = 14407904,
}
StorySpeechConfig[StorySpeechID.Id14407904] =
{
	Id = 14407904,
	CharName = "爆米花女王",
	Text = "目前只能限量供应。不过薯片夫人，你帮本院线策划了多次宣传活动，是拥有这个资格的。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_22_baomihua",
	NextID = 14407905,
}
StorySpeechConfig[StorySpeechID.Id14407905] =
{
	Id = 14407905,
	CharName = "薯片夫人",
	Text = "哇，太感谢了，女王大人。每颗我都要仔细品尝，感受它融化的过程。那么这次宣传片？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_19_shupian",
	NextID = 14407906,
}
StorySpeechConfig[StorySpeechID.Id14407906] =
{
	Id = 14407906,
	CharName = "爆米花女王",
	Text = "情节是这样，等等我和一个小土包打起来，最后小土包被打败，里面的白松露一下子露出来，这时候镜头特写，把白松露爆米花突出出来。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_22_baomihua",
	NextID = 14407907,
}
StorySpeechConfig[StorySpeechID.Id14407907] =
{
	Id = 14407907,
	CharName = "薯片夫人",
	Text = "太完美了！简直是视觉和味觉的双重享受。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_19_shupian",
	NextID = 14407908,
}
StorySpeechConfig[StorySpeechID.Id14407908] =
{
	Id = 14407908,
	CharName = "爆米花女王",
	Text = "关键是这种顶级爆米花还会带动我们集团其他零食的销量，建立我们品牌的高端形象。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_22_baomihua",
	NextID = 14407909,
}
StorySpeechConfig[StorySpeechID.Id14407909] =
{
	Id = 14407909,
	CharName = "薯片夫人",
	Text = "噢，能拍这样一期节目我实在是太荣幸了。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_19_shupian",
	NextID = 14407910,
}
StorySpeechConfig[StorySpeechID.Id14407910] =
{
	Id = 14407910,
	CharName = "爆米花女王",
	Text = "那么，一切就绪，就开始吧。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_22_baomihua",
}
StorySpeechConfig[StorySpeechID.Id14409901] =
{
	Id = 14409901,
	CharName = "赛特",
	Text = "保安！气候模拟器打了一下午热风啦！都已经47度，要化掉了啊！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_03_Set",
	NextID = 14409902,
}
StorySpeechConfig[StorySpeechID.Id14409902] =
{
	Id = 14409902,
	CharName = "保安",
	Text = "抱歉抱歉，这两天生态馆的沙地龙大批出生，所以需要模拟沙漠环境。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_27_baoan",
	NextID = 14409903,
}
StorySpeechConfig[StorySpeechID.Id14409903] =
{
	Id = 14409903,
	CharName = "荷鲁斯",
	Text = "那为什么整个场馆都要模拟啊！！！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_02_Horus",
	NextID = 14409904,
}
StorySpeechConfig[StorySpeechID.Id14409904] =
{
	Id = 14409904,
	CharName = "保安",
	Text = "啊，安装隔离阀的时候，征询过各位的意见。当时你们说省省搞不好就是1个亿，就没有安装隔离阀。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_27_baoan",
	NextID = 14409905,
}
StorySpeechConfig[StorySpeechID.Id14409905] =
{
	Id = 14409905,
	CharName = "索贝克",
	Text = "噢，想起来了。那时候拿这个钱出去旅游了……",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_04_Sobek",
	NextID = 14409906,
}
StorySpeechConfig[StorySpeechID.Id14409906] =
{
	Id = 14409906,
	CharName = "赛特",
	Text = "那现在怎么办！热得快化了啊！！！而且风吹过来一嘴巴都是沙子！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_03_Set",
	NextID = 14409907,
}
StorySpeechConfig[StorySpeechID.Id14409907] =
{
	Id = 14409907,
	CharName = "保安",
	Text = "要不然你们现在补交3千星际币，再交1千拆装费，我这就联系工程部上门安装吧~",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_27_baoan",
	NextID = 14409908,
}
StorySpeechConfig[StorySpeechID.Id14409908] =
{
	Id = 14409908,
	CharName = "阿努比斯",
	Text = "都已经忍这么多天了，现在交3千，这几天的苦都白受了！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_01_Anubis",
	NextID = 14409909,
}
StorySpeechConfig[StorySpeechID.Id14409909] =
{
	Id = 14409909,
	CharName = "赛特",
	Text = "上次旅游买了很多玩具回来，好像还买了沙漠的衣服，穿上能挡风沙的衣服应该就搞定了！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_03_Set",
	NextID = 14409910,
}
StorySpeechConfig[StorySpeechID.Id14409910] =
{
	Id = 14409910,
	CharName = "保安",
	Text = "嗯，嗯，你们回来后就把行李车丢仓库了，那个行李车好像不太高兴的样子。走，我带你们去拿。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_27_baoan",
}
StorySpeechConfig[StorySpeechID.Id14410001] =
{
	Id = 14410001,
	CharName = "赛特",
	Text = "保安！气候模拟器打了一下午热风啦！都已经47度，要化掉了啊！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_03_Set",
	NextID = 14410002,
}
StorySpeechConfig[StorySpeechID.Id14410002] =
{
	Id = 14410002,
	CharName = "保安",
	Text = "抱歉抱歉，这两天生态馆的沙地龙大批出生，所以需要模拟沙漠环境。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_27_baoan",
	NextID = 14410003,
}
StorySpeechConfig[StorySpeechID.Id14410003] =
{
	Id = 14410003,
	CharName = "荷鲁斯",
	Text = "那为什么整个场馆都要模拟啊！！！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_02_Horus",
	NextID = 14410004,
}
StorySpeechConfig[StorySpeechID.Id14410004] =
{
	Id = 14410004,
	CharName = "保安",
	Text = "啊，安装隔离阀的时候，征询过各位的意见。当时你们说省省搞不好就是1个亿，就没有安装隔离阀。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_27_baoan",
	NextID = 14410005,
}
StorySpeechConfig[StorySpeechID.Id14410005] =
{
	Id = 14410005,
	CharName = "索贝克",
	Text = "噢，想起来了。那时候拿这个钱出去旅游了……",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_04_Sobek",
	NextID = 14410006,
}
StorySpeechConfig[StorySpeechID.Id14410006] =
{
	Id = 14410006,
	CharName = "赛特",
	Text = "那现在怎么办！热得快化了啊！！！而且风吹过来一嘴巴都是沙子！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_03_Set",
	NextID = 14410007,
}
StorySpeechConfig[StorySpeechID.Id14410007] =
{
	Id = 14410007,
	CharName = "保安",
	Text = "要不然你们现在补交3千星际币，再交1千拆装费，我这就联系工程部上门安装吧~",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_27_baoan",
	NextID = 14410008,
}
StorySpeechConfig[StorySpeechID.Id14410008] =
{
	Id = 14410008,
	CharName = "阿努比斯",
	Text = "都已经忍这么多天了，现在交3千，这几天的苦都白受了！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_01_Anubis",
	NextID = 14410009,
}
StorySpeechConfig[StorySpeechID.Id14410009] =
{
	Id = 14410009,
	CharName = "赛特",
	Text = "上次旅游买了很多玩具回来，好像还买了沙漠的衣服，穿上能挡风沙的衣服应该就搞定了！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_03_Set",
	NextID = 14410010,
}
StorySpeechConfig[StorySpeechID.Id14410010] =
{
	Id = 14410010,
	CharName = "保安",
	Text = "嗯，嗯，你们回来后就把行李车丢仓库了，那个行李车好像不太高兴的样子。走，我带你们去拿。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_27_baoan",
}
StorySpeechConfig[StorySpeechID.Id14410101] =
{
	Id = 14410101,
	CharName = "赛特",
	Text = "保安！气候模拟器打了一下午热风啦！都已经47度，要化掉了啊！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_03_Set",
	NextID = 14410102,
}
StorySpeechConfig[StorySpeechID.Id14410102] =
{
	Id = 14410102,
	CharName = "保安",
	Text = "抱歉抱歉，这两天生态馆的沙地龙大批出生，所以需要模拟沙漠环境。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_27_baoan",
	NextID = 14410103,
}
StorySpeechConfig[StorySpeechID.Id14410103] =
{
	Id = 14410103,
	CharName = "荷鲁斯",
	Text = "那为什么整个场馆都要模拟啊！！！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_02_Horus",
	NextID = 14410104,
}
StorySpeechConfig[StorySpeechID.Id14410104] =
{
	Id = 14410104,
	CharName = "保安",
	Text = "啊，安装隔离阀的时候，征询过各位的意见。当时你们说省省搞不好就是1个亿，就没有安装隔离阀。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_27_baoan",
	NextID = 14410105,
}
StorySpeechConfig[StorySpeechID.Id14410105] =
{
	Id = 14410105,
	CharName = "索贝克",
	Text = "噢，想起来了。那时候拿这个钱出去旅游了……",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_04_Sobek",
	NextID = 14410106,
}
StorySpeechConfig[StorySpeechID.Id14410106] =
{
	Id = 14410106,
	CharName = "赛特",
	Text = "那现在怎么办！热得快化了啊！！！而且风吹过来一嘴巴都是沙子！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_03_Set",
	NextID = 14410107,
}
StorySpeechConfig[StorySpeechID.Id14410107] =
{
	Id = 14410107,
	CharName = "保安",
	Text = "要不然你们现在补交3千星际币，再交1千拆装费，我这就联系工程部上门安装吧~",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_27_baoan",
	NextID = 14410108,
}
StorySpeechConfig[StorySpeechID.Id14410108] =
{
	Id = 14410108,
	CharName = "阿努比斯",
	Text = "都已经忍这么多天了，现在交3千，这几天的苦都白受了！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_01_Anubis",
	NextID = 14410109,
}
StorySpeechConfig[StorySpeechID.Id14410109] =
{
	Id = 14410109,
	CharName = "赛特",
	Text = "上次旅游买了很多玩具回来，好像还买了沙漠的衣服，穿上能挡风沙的衣服应该就搞定了！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_03_Set",
	NextID = 14410110,
}
StorySpeechConfig[StorySpeechID.Id14410110] =
{
	Id = 14410110,
	CharName = "保安",
	Text = "嗯，嗯，你们回来后就把行李车丢仓库了，那个行李车好像不太高兴的样子。走，我带你们去拿。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_27_baoan",
}
StorySpeechConfig[StorySpeechID.Id14410201] =
{
	Id = 14410201,
	CharName = "赛特",
	Text = "保安！气候模拟器打了一下午热风啦！都已经47度，要化掉了啊！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_03_Set",
	NextID = 14410202,
}
StorySpeechConfig[StorySpeechID.Id14410202] =
{
	Id = 14410202,
	CharName = "保安",
	Text = "抱歉抱歉，这两天生态馆的沙地龙大批出生，所以需要模拟沙漠环境。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_27_baoan",
	NextID = 14410203,
}
StorySpeechConfig[StorySpeechID.Id14410203] =
{
	Id = 14410203,
	CharName = "荷鲁斯",
	Text = "那为什么整个场馆都要模拟啊！！！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_02_Horus",
	NextID = 14410204,
}
StorySpeechConfig[StorySpeechID.Id14410204] =
{
	Id = 14410204,
	CharName = "保安",
	Text = "啊，安装隔离阀的时候，征询过各位的意见。当时你们说省省搞不好就是1个亿，就没有安装隔离阀。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_27_baoan",
	NextID = 14410205,
}
StorySpeechConfig[StorySpeechID.Id14410205] =
{
	Id = 14410205,
	CharName = "索贝克",
	Text = "噢，想起来了。那时候拿这个钱出去旅游了……",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_04_Sobek",
	NextID = 14410206,
}
StorySpeechConfig[StorySpeechID.Id14410206] =
{
	Id = 14410206,
	CharName = "赛特",
	Text = "那现在怎么办！热得快化了啊！！！而且风吹过来一嘴巴都是沙子！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_03_Set",
	NextID = 14410207,
}
StorySpeechConfig[StorySpeechID.Id14410207] =
{
	Id = 14410207,
	CharName = "保安",
	Text = "要不然你们现在补交3千星际币，再交1千拆装费，我这就联系工程部上门安装吧~",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_27_baoan",
	NextID = 14410208,
}
StorySpeechConfig[StorySpeechID.Id14410208] =
{
	Id = 14410208,
	CharName = "阿努比斯",
	Text = "都已经忍这么多天了，现在交3千，这几天的苦都白受了！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_01_Anubis",
	NextID = 14410209,
}
StorySpeechConfig[StorySpeechID.Id14410209] =
{
	Id = 14410209,
	CharName = "赛特",
	Text = "上次旅游买了很多玩具回来，好像还买了沙漠的衣服，穿上能挡风沙的衣服应该就搞定了！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_03_Set",
	NextID = 14410210,
}
StorySpeechConfig[StorySpeechID.Id14410210] =
{
	Id = 14410210,
	CharName = "保安",
	Text = "嗯，嗯，你们回来后就把行李车丢仓库了，那个行李车好像不太高兴的样子。走，我带你们去拿。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_27_baoan",
}
StorySpeechConfig[StorySpeechID.Id14408101] =
{
	Id = 14408101,
	CharName = "侦探小姐",
	Text = "还有8千卷录像带要看啊……已经看了3天了……",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_17_zhentanxiaojie",
	NextID = 14408102,
}
StorySpeechConfig[StorySpeechID.Id14408102] =
{
	Id = 14408102,
	CharName = "保安",
	Text = "侦探小姐，我们馆这次能不能抓到这个把干垃圾丢在可回收垃圾桶里的犯人就完全靠你了！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_27_baoan",
	NextID = 14408103,
}
StorySpeechConfig[StorySpeechID.Id14408103] =
{
	Id = 14408103,
	CharName = "侦探小姐",
	Text = "（又看了50卷后）唔……真的不行了，再看又要吐出来了……脑袋快满出来了。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_17_zhentanxiaojie",
	NextID = 14408104,
}
StorySpeechConfig[StorySpeechID.Id14408104] =
{
	Id = 14408104,
	CharName = "保安",
	Text = "侦探小姐，呕吐袋这里还有一打，不够我去仓库再拿点，请一定要继续努力啊。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_27_baoan",
	NextID = 14408105,
}
StorySpeechConfig[StorySpeechID.Id14408105] =
{
	Id = 14408105,
	CharName = "侦探小姐",
	Text = "（又看了50卷后）不行了……占用太多脑细胞了……满脑子都是前两天看过的没用的画面。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_17_zhentanxiaojie",
	NextID = 14408106,
}
StorySpeechConfig[StorySpeechID.Id14408106] =
{
	Id = 14408106,
	CharName = "保安",
	Text = "（以拳拍手）噢！原来是这样，那看来要由ta出马了！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_27_baoan",
	NextID = 14408107,
}
StorySpeechConfig[StorySpeechID.Id14408107] =
{
	Id = 14408107,
	CharName = "侦探小姐",
	Text = "ta是什么？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_17_zhentanxiaojie",
	NextID = 14408108,
}
StorySpeechConfig[StorySpeechID.Id14408108] =
{
	Id = 14408108,
	CharName = "保安",
	Text = "小姐有没有听说过无论什么疑难案件都能在一天内解决的“忘却侦探”！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_27_baoan",
	NextID = 14408109,
}
StorySpeechConfig[StorySpeechID.Id14408109] =
{
	Id = 14408109,
	CharName = "侦探小姐",
	Text = "啊，就是那个吗？只有一天的推理记忆，所以任何案件必须一天完成的前辈？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_17_zhentanxiaojie",
	NextID = 14408110,
}
StorySpeechConfig[StorySpeechID.Id14408110] =
{
	Id = 14408110,
	CharName = "保安",
	Text = "就是她！虽然她现在已经和爱人去星际旅行了，但是她把和她具有同样性质的工作服留了下来。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_27_baoan",
	NextID = 14408111,
}
StorySpeechConfig[StorySpeechID.Id14408111] =
{
	Id = 14408111,
	CharName = "侦探小姐",
	Text = "哇，有了这件衣服，无用信息一天就能忘却，而且脑力倍增！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_17_zhentanxiaojie",
	NextID = 14408112,
}
StorySpeechConfig[StorySpeechID.Id14408112] =
{
	Id = 14408112,
	CharName = "保安",
	Text = "不过，这件衣服有自己的灵性，要穿上ta的话得打败衣服的守护灵……",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_27_baoan",
}
StorySpeechConfig[StorySpeechID.Id14408501] =
{
	Id = 14408501,
	CharName = "保安",
	Text = "辛苦四位了，这次新引进的佛头是来自遥远星球的珍贵宝物，还请搬运时小心。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_27_baoan",
	NextID = 14408502,
}
StorySpeechConfig[StorySpeechID.Id14408502] =
{
	Id = 14408502,
	CharName = "兵马俑",
	Text = "有我们在，你就放心吧，保安先生，我们会照顾好佛头的。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_06_bingmayong",
	NextID = 14408503,
}
StorySpeechConfig[StorySpeechID.Id14408503] =
{
	Id = 14408503,
	CharName = "对讲机",
	Text = "保安先生，这里有游客随地大小便，请赶紧过来处理一下。",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	LeftIcon = "Equipment_All_wuwu_1",
	NextID = 14408504,
}
StorySpeechConfig[StorySpeechID.Id14408504] =
{
	Id = 14408504,
	CharName = "保安",
	Text = "啊，发生了严重的事件，我先去处理一下！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_27_baoan",
	NextID = 14408505,
}
StorySpeechConfig[StorySpeechID.Id14408505] =
{
	Id = 14408505,
	CharName = "石柱人",
	Text = "这里就交给我们，放心吧，保安先生。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_10_shizhuren",
	NextID = 14408506,
}
StorySpeechConfig[StorySpeechID.Id14408506] =
{
	Id = 14408506,
	CharName = "默艾",
	Text = "唔……想摸他头……",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_07_fuhuoshixiang",
	NextID = 14408507,
}
StorySpeechConfig[StorySpeechID.Id14408507] =
{
	Id = 14408507,
	CharName = "佛头",
	Text = "那如何使得，头乃是人的灵根汇聚之所，不能摸，不能摸的。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_07_fuhuoshixiang_cos10",
	NextID = 14408508,
}
StorySpeechConfig[StorySpeechID.Id14408508] =
{
	Id = 14408508,
	CharName = "半人马石像",
	Text = "哎，摸一下有什么关系，以后大家都是朋友，你可以摸我的头啊。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_11_banrenma",
	NextID = 14408509,
}
StorySpeechConfig[StorySpeechID.Id14408509] =
{
	Id = 14408509,
	CharName = "佛头",
	Text = "啊，别摸别摸，万一摸坏了算谁的。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_07_fuhuoshixiang_cos10",
	NextID = 14408510,
}
StorySpeechConfig[StorySpeechID.Id14408510] =
{
	Id = 14408510,
	CharName = "默艾",
	Text = "（以迅雷不及掩耳之势摸了一下，不过掰下来一个发绺儿）",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_07_fuhuoshixiang",
	NextID = 14408511,
}
StorySpeechConfig[StorySpeechID.Id14408511] =
{
	Id = 14408511,
	CharName = "佛头",
	Text = "哇！都叫你不要摸了，我一定要上告馆长，让他好好处罚你！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_07_fuhuoshixiang_cos10",
	NextID = 14408512,
}
StorySpeechConfig[StorySpeechID.Id14408512] =
{
	Id = 14408512,
	CharName = "默艾",
	Text = "……",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_07_fuhuoshixiang",
	NextID = 14408513,
}
StorySpeechConfig[StorySpeechID.Id14408513] =
{
	Id = 14408513,
	CharName = "保安",
	Text = "（从远处走来）我那边处理好了，你们这边怎么样了？佛头还好吧？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_27_baoan",
	NextID = 14408514,
}
StorySpeechConfig[StorySpeechID.Id14408514] =
{
	Id = 14408514,
	CharName = "佛头",
	Text = "我要告……（嘴巴被四个石像捂住）",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_07_fuhuoshixiang_cos10",
	NextID = 14408515,
}
StorySpeechConfig[StorySpeechID.Id14408515] =
{
	Id = 14408515,
	CharName = "石柱人",
	Text = "他要告我们！我们把他打晕，默艾你来扮演佛头。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_10_shizhuren",
	NextID = 14408516,
}
StorySpeechConfig[StorySpeechID.Id14408516] =
{
	Id = 14408516,
	CharName = "默艾",
	Text = "（翘大拇指）",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_07_fuhuoshixiang",
}
StorySpeechConfig[StorySpeechID.Id14408601] =
{
	Id = 14408601,
	CharName = "保安",
	Text = "辛苦四位了，这次新引进的智慧女神是来自遥远星球的殿堂级宝物，还请搬运时小心。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_27_baoan",
	NextID = 14408602,
}
StorySpeechConfig[StorySpeechID.Id14408602] =
{
	Id = 14408602,
	CharName = "兵马俑",
	Text = "有我们在，你就放心吧，保安先生，我们会照顾好智慧女神的。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_06_bingmayong",
	NextID = 14408603,
}
StorySpeechConfig[StorySpeechID.Id14408603] =
{
	Id = 14408603,
	CharName = "对讲机",
	Text = "保安先生，这里有游客随地吐痰，请赶紧过来处理一下。",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	LeftIcon = "Equipment_All_wuwu_1",
	NextID = 14408604,
}
StorySpeechConfig[StorySpeechID.Id14408604] =
{
	Id = 14408604,
	CharName = "保安",
	Text = "啊，发生了严重的事件，我先去处理一下！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_27_baoan",
	NextID = 14408605,
}
StorySpeechConfig[StorySpeechID.Id14408605] =
{
	Id = 14408605,
	CharName = "半人马石像",
	Text = "这里就交给我们，放心吧，保安先生。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_11_banrenma",
	NextID = 14408606,
}
StorySpeechConfig[StorySpeechID.Id14408606] =
{
	Id = 14408606,
	CharName = "兵马俑",
	Text = "哇，你身上镶嵌的这个是象牙吗？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_06_bingmayong",
	NextID = 14408607,
}
StorySpeechConfig[StorySpeechID.Id14408607] =
{
	Id = 14408607,
	CharName = "智慧女神",
	Text = "不要乱动，我可是凝聚了雕刻者虔诚信仰的女神像。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_06_bingmayong_cos10",
	NextID = 14408608,
}
StorySpeechConfig[StorySpeechID.Id14408608] =
{
	Id = 14408608,
	CharName = "石柱人",
	Text = "哎，动一下有什么关系，以后大家都是朋友，你可以摸我的花纹啊。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_10_shizhuren",
	NextID = 14408609,
}
StorySpeechConfig[StorySpeechID.Id14408609] =
{
	Id = 14408609,
	CharName = "智慧女神",
	Text = "大家都是石像，有什么好摸来摸去的，摸坏了算谁的！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_06_bingmayong_cos10",
	NextID = 14408610,
}
StorySpeechConfig[StorySpeechID.Id14408610] =
{
	Id = 14408610,
	CharName = "兵马俑",
	Text = "（以迅雷不及掩耳之势碰了一下衣角的装饰，不过断下来一块）",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_06_bingmayong",
	NextID = 14408611,
}
StorySpeechConfig[StorySpeechID.Id14408611] =
{
	Id = 14408611,
	CharName = "智慧女神",
	Text = "哇！都叫你不要动了，我一定要上告馆长，让他好好处罚你！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_06_bingmayong_cos10",
	NextID = 14408612,
}
StorySpeechConfig[StorySpeechID.Id14408612] =
{
	Id = 14408612,
	CharName = "兵马俑",
	Text = "……",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_06_bingmayong",
	NextID = 14408613,
}
StorySpeechConfig[StorySpeechID.Id14408613] =
{
	Id = 14408613,
	CharName = "保安",
	Text = "（从远处走来）我那边处理好了，你们这边怎么样了？智慧女神还好吧？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_27_baoan",
	NextID = 14408614,
}
StorySpeechConfig[StorySpeechID.Id14408614] =
{
	Id = 14408614,
	CharName = "智慧女神",
	Text = "我要告……（嘴巴被四个石像捂住）",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_06_bingmayong_cos10",
	NextID = 14408615,
}
StorySpeechConfig[StorySpeechID.Id14408615] =
{
	Id = 14408615,
	CharName = "石柱人",
	Text = "他要告我们！我们把他打晕，兵马俑你来扮演智慧女神。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_10_shizhuren",
	NextID = 14408616,
}
StorySpeechConfig[StorySpeechID.Id14408616] =
{
	Id = 14408616,
	CharName = "兵马俑",
	Text = "此兵家之胜，不可先传也——！！！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_06_bingmayong",
}
StorySpeechConfig[StorySpeechID.Id14408701] =
{
	Id = 14408701,
	CharName = "保安",
	Text = "辛苦四位了，这次新引进的玛雅石柱人是来自遥远星球的纪念宝物，还请搬运时小心。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_27_baoan",
	NextID = 14408702,
}
StorySpeechConfig[StorySpeechID.Id14408702] =
{
	Id = 14408702,
	CharName = "石柱人",
	Text = "有我们在，你就放心吧，保安先生，我们会照顾好玛雅石柱人的。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_10_shizhuren",
	NextID = 14408703,
}
StorySpeechConfig[StorySpeechID.Id14408703] =
{
	Id = 14408703,
	CharName = "对讲机",
	Text = "保安先生，这里有游客大声喧哗，请赶紧过来处理一下。",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	LeftIcon = "Equipment_All_wuwu_1",
	NextID = 14408704,
}
StorySpeechConfig[StorySpeechID.Id14408704] =
{
	Id = 14408704,
	CharName = "保安",
	Text = "啊，发生了严重的事件，我先去处理一下！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_27_baoan",
	NextID = 14408705,
}
StorySpeechConfig[StorySpeechID.Id14408705] =
{
	Id = 14408705,
	CharName = "半人马石像",
	Text = "这里就交给我们，放心吧，保安先生。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_11_banrenma",
	NextID = 14408706,
}
StorySpeechConfig[StorySpeechID.Id14408706] =
{
	Id = 14408706,
	CharName = "石柱人",
	Text = "哇，记录了很多文字，好想研究一下啊~",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_10_shizhuren",
	NextID = 14408707,
}
StorySpeechConfig[StorySpeechID.Id14408707] =
{
	Id = 14408707,
	CharName = "玛雅石柱人",
	Text = "别不懂装懂！你也没有资质证书，这些古文字你看得懂吗？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_10_shizhuren_cos10",
	NextID = 14408708,
}
StorySpeechConfig[StorySpeechID.Id14408708] =
{
	Id = 14408708,
	CharName = "兵马俑",
	Text = "哎，看一下有什么关系，以后大家都是朋友，你可以看我盔甲上的铭文啊。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_06_bingmayong",
	NextID = 14408709,
}
StorySpeechConfig[StorySpeechID.Id14408709] =
{
	Id = 14408709,
	CharName = "玛雅石柱人",
	Text = "啊，别瞎搞，万一弄坏了算谁的。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_10_shizhuren_cos10",
	NextID = 14408710,
}
StorySpeechConfig[StorySpeechID.Id14408710] =
{
	Id = 14408710,
	CharName = "石柱人",
	Text = "（以迅雷不及掩耳之势摸了一下，不过掉下来一大块油漆）",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_10_shizhuren",
	NextID = 14408711,
}
StorySpeechConfig[StorySpeechID.Id14408711] =
{
	Id = 14408711,
	CharName = "玛雅石柱人",
	Text = "哇！都叫你不要瞎搞了，我一定要上告馆长，让他好好处罚你！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_10_shizhuren_cos10",
	NextID = 14408712,
}
StorySpeechConfig[StorySpeechID.Id14408712] =
{
	Id = 14408712,
	CharName = "石柱人",
	Text = "……",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_10_shizhuren",
	NextID = 14408713,
}
StorySpeechConfig[StorySpeechID.Id14408713] =
{
	Id = 14408713,
	CharName = "保安",
	Text = "（从远处走来）我那边处理好了，你们这边怎么样了？玛雅石柱人还好吧？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_27_baoan",
	NextID = 14408714,
}
StorySpeechConfig[StorySpeechID.Id14408714] =
{
	Id = 14408714,
	CharName = "玛雅石柱人",
	Text = "我要告……（嘴巴被四个石像捂住）",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_10_shizhuren_cos10",
	NextID = 14408715,
}
StorySpeechConfig[StorySpeechID.Id14408715] =
{
	Id = 14408715,
	CharName = "兵马俑",
	Text = "他要告我们！我们把他打晕，石柱人你来扮演玛雅石柱人。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_06_bingmayong",
	NextID = 14408716,
}
StorySpeechConfig[StorySpeechID.Id14408716] =
{
	Id = 14408716,
	CharName = "石柱人",
	Text = "Idea splendida——！！！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_10_shizhuren",
}
StorySpeechConfig[StorySpeechID.Id14408801] =
{
	Id = 14408801,
	CharName = "保安",
	Text = "辛苦四位了，这次新引进的独角兽是来自遥远星球的梦幻宝物，还请搬运时小心。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_27_baoan",
	NextID = 14408802,
}
StorySpeechConfig[StorySpeechID.Id14408802] =
{
	Id = 14408802,
	CharName = "半人马石像",
	Text = "有我们在，你就放心吧，保安先生，我们会照顾好独角兽的。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_11_banrenma",
	NextID = 14408803,
}
StorySpeechConfig[StorySpeechID.Id14408803] =
{
	Id = 14408803,
	CharName = "对讲机",
	Text = "保安先生，这里有游客不配合安检，请赶紧过来处理一下。",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	LeftIcon = "Equipment_All_wuwu_1",
	NextID = 14408804,
}
StorySpeechConfig[StorySpeechID.Id14408804] =
{
	Id = 14408804,
	CharName = "保安",
	Text = "啊，发生了严重的事件，我先去处理一下！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_27_baoan",
	NextID = 14408805,
}
StorySpeechConfig[StorySpeechID.Id14408805] =
{
	Id = 14408805,
	CharName = "石柱人",
	Text = "这里就交给我们，放心吧，保安先生。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_10_shizhuren",
	NextID = 14408806,
}
StorySpeechConfig[StorySpeechID.Id14408806] =
{
	Id = 14408806,
	CharName = "半人马石像",
	Text = "哇，头上长了个好有趣的角，可以弹一下吗？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_11_banrenma",
	NextID = 14408807,
}
StorySpeechConfig[StorySpeechID.Id14408807] =
{
	Id = 14408807,
	CharName = "独角兽",
	Text = "弹什么弹！这根凝聚了自然灵性的奇迹之角是你可以弹的吗？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_11_banrenma_cos10",
	NextID = 14408808,
}
StorySpeechConfig[StorySpeechID.Id14408808] =
{
	Id = 14408808,
	CharName = "兵马俑",
	Text = "哎，弹一下有什么关系，以后大家都是朋友，你可以弹我的发髻啊。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_06_bingmayong",
	NextID = 14408809,
}
StorySpeechConfig[StorySpeechID.Id14408809] =
{
	Id = 14408809,
	CharName = "独角兽",
	Text = "啊，去去去，别围过来！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_11_banrenma_cos10",
	NextID = 14408810,
}
StorySpeechConfig[StorySpeechID.Id14408810] =
{
	Id = 14408810,
	CharName = "半人马石像",
	Text = "（以迅雷不及掩耳之势弹了一下独角，不过独角裂了一条缝）",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_11_banrenma",
	NextID = 14408811,
}
StorySpeechConfig[StorySpeechID.Id14408811] =
{
	Id = 14408811,
	CharName = "独角兽",
	Text = "哇！都叫你不要瞎搞了，我一定要上告馆长，让他好好处罚你！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_11_banrenma_cos10",
	NextID = 14408812,
}
StorySpeechConfig[StorySpeechID.Id14408812] =
{
	Id = 14408812,
	CharName = "石柱人",
	Text = "……",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_10_shizhuren",
	NextID = 14408813,
}
StorySpeechConfig[StorySpeechID.Id14408813] =
{
	Id = 14408813,
	CharName = "保安",
	Text = "（从远处走来）我那边处理好了，你们这边怎么样了？独角兽还好吧？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_27_baoan",
	NextID = 14408814,
}
StorySpeechConfig[StorySpeechID.Id14408814] =
{
	Id = 14408814,
	CharName = "独角兽",
	Text = "我要告……（嘴巴被四个石像捂住）",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_11_banrenma_cos10",
	NextID = 14408815,
}
StorySpeechConfig[StorySpeechID.Id14408815] =
{
	Id = 14408815,
	CharName = "石柱人",
	Text = "他要告我们！我们把他打晕，半人马你来扮演独角兽。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_10_shizhuren",
	NextID = 14408816,
}
StorySpeechConfig[StorySpeechID.Id14408816] =
{
	Id = 14408816,
	CharName = "半人马石像",
	Text = "Jia——！！！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_11_banrenma",
}
StorySpeechConfig[StorySpeechID.Id14409101] =
{
	Id = 14409101,
	CharName = "保安",
	Text = "本周的用户反馈已经下发到各位的意见箱，请大家及时查收~哭泣的女人，本周你有3个差评，请注意整改~",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_27_baoan",
	NextID = 14409102,
}
StorySpeechConfig[StorySpeechID.Id14409102] =
{
	Id = 14409102,
	CharName = "用户反馈1",
	Text = "本来是来开开心心看展览的，但是看完这幅画就有点想哭。",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	RightIcon = "Equipment_Rpg_29_QA_2",
	NextID = 14409103,
}
StorySpeechConfig[StorySpeechID.Id14409103] =
{
	Id = 14409103,
	CharName = "用户反馈2",
	Text = "为什么要让大家不开心呢？明明大厅里所有作品都让人觉得很舒畅。",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	LeftIcon = "Equipment_Rpg_29_QA_2",
	NextID = 14409104,
}
StorySpeechConfig[StorySpeechID.Id14409104] =
{
	Id = 14409104,
	CharName = "用户反馈3",
	Text = "唯独这幅画我一定要投诉它，让心情原本很好的我低落了起来。",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	RightIcon = "Equipment_Rpg_29_QA_2",
	NextID = 14409105,
}
StorySpeechConfig[StorySpeechID.Id14409105] =
{
	Id = 14409105,
	CharName = "哭泣的女人",
	Text = "是这样的，保安先生。画是作家表达某种情绪或理念的一种手法。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_28_kuqidenvren",
	NextID = 14409106,
}
StorySpeechConfig[StorySpeechID.Id14409106] =
{
	Id = 14409106,
	CharName = "保安",
	Text = "好了，不要多说了，馆长说你必须在三天内换个风格。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_27_baoan",
	NextID = 14409107,
}
StorySpeechConfig[StorySpeechID.Id14409107] =
{
	Id = 14409107,
	CharName = "哭泣的女人",
	Text = "这要怎么办？我难道自己画吗？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_28_kuqidenvren",
	NextID = 14409108,
}
StorySpeechConfig[StorySpeechID.Id14409108] =
{
	Id = 14409108,
	CharName = "保安",
	Text = "馆长说有两个方案。第一个是给你换上同作者另一个作品《梦》。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_27_baoan",
	NextID = 14409109,
}
StorySpeechConfig[StorySpeechID.Id14409109] =
{
	Id = 14409109,
	CharName = "哭泣的女人",
	Text = "嗯，似乎还不错。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_28_kuqidenvren",
	NextID = 14409110,
}
StorySpeechConfig[StorySpeechID.Id14409110] =
{
	Id = 14409110,
	CharName = "保安",
	Text = "但是我想选第二个。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_27_baoan",
	NextID = 14409111,
}
StorySpeechConfig[StorySpeechID.Id14409111] =
{
	Id = 14409111,
	CharName = "哭泣的女人",
	Text = "第二个是？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_28_kuqidenvren",
	NextID = 14409112,
}
StorySpeechConfig[StorySpeechID.Id14409112] =
{
	Id = 14409112,
	CharName = "保安",
	Text = "（拿出颜料和画笔）馆长说让我把你画得喜庆点，题目我也想好了，《开心的女人》~",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_27_baoan",
}
StorySpeechConfig[StorySpeechID.Id14409201] =
{
	Id = 14409201,
	CharName = "保安",
	Text = "本周的用户反馈已经下发到各位的意见箱，请大家及时查收~呐喊家，本周你有3个差评噢~",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_27_baoan",
	NextID = 14409202,
}
StorySpeechConfig[StorySpeechID.Id14409202] =
{
	Id = 14409202,
	CharName = "用户反馈1",
	Text = "每次来到这幅画作前都让我心灵产生极大震动。不过只有画面没有声音，让我无法适应。",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	RightIcon = "Equipment_Rpg_29_QA_2",
	NextID = 14409203,
}
StorySpeechConfig[StorySpeechID.Id14409203] =
{
	Id = 14409203,
	CharName = "用户反馈2",
	Text = "感觉忍不住就要喊出来了，但是却又憋了回去。这幅画看得让我觉得不舒服。",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	LeftIcon = "Equipment_Rpg_29_QA_2",
	NextID = 14409204,
}
StorySpeechConfig[StorySpeechID.Id14409204] =
{
	Id = 14409204,
	CharName = "用户反馈3",
	Text = "为什么不让它喊出来呢？明明就要喊出来了，为什么不喊出来呢？",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	RightIcon = "Equipment_Rpg_29_QA_2",
	NextID = 14409205,
}
StorySpeechConfig[StorySpeechID.Id14409205] =
{
	Id = 14409205,
	CharName = "呐喊家",
	Text = "……作者虽然一直没有说明绘制意图，不过画作没有声音不是很正常嘛！！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_19_nahan",
	NextID = 14409206,
}
StorySpeechConfig[StorySpeechID.Id14409206] =
{
	Id = 14409206,
	CharName = "保安",
	Text = "好了，不要多说了，馆长已经决定让我在你的画作前面装上这个了。（掏出悬挂式音响）",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_27_baoan",
	NextID = 14409207,
}
StorySpeechConfig[StorySpeechID.Id14409207] =
{
	Id = 14409207,
	CharName = "呐喊家",
	Text = "这是什么……好像很高科技。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_19_nahan",
	NextID = 14409208,
}
StorySpeechConfig[StorySpeechID.Id14409208] =
{
	Id = 14409208,
	CharName = "保安",
	Text = "这是热敏音响，只要有人在你面前停2秒，就会播放馆长的呐喊声哟~我也录了一段呢~",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_27_baoan",
	NextID = 14409209,
}
StorySpeechConfig[StorySpeechID.Id14409209] =
{
	Id = 14409209,
	CharName = "捂脸",
	Text = "馆长真的是皇家星际艺术学院毕业的吗？我怀疑他学历造假……",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_19_nahan_cos10",
	NextID = 14409210,
}
StorySpeechConfig[StorySpeechID.Id14409210] =
{
	Id = 14409210,
	CharName = "保安",
	Text = "你这个表情不错啊~~~我帮你拍下来。诶，不许拍吗？那你来追我啊~~",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_27_baoan",
}
StorySpeechConfig[StorySpeechID.Id14408901] =
{
	Id = 14408901,
	CharName = "喇叭",
	Text = "（侦探小姐的声音）近期有儿童团前来，请馆内平时穿着暴露的艺术品们注意一点！",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "EventItem_RPG_Event_8",
	NextID = 14408902,
}
StorySpeechConfig[StorySpeechID.Id14408902] =
{
	Id = 14408902,
	CharName = "亚当",
	Text = "原来馆内还有这样的艺术品啊，嘿嘿，影响真是不好呢~",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_22_yadang",
	NextID = 14408903,
}
StorySpeechConfig[StorySpeechID.Id14408903] =
{
	Id = 14408903,
	CharName = "喇叭",
	Text = "（侦探小姐的声音）再次通报，请馆内平时穿着暴露的艺术品们尽快更换衣物！",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "EventItem_RPG_Event_8",
	NextID = 14408904,
}
StorySpeechConfig[StorySpeechID.Id14408904] =
{
	Id = 14408904,
	CharName = "亚当",
	Text = "哇，到底是谁啊？嘿嘿，真的是有点过分呢！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_22_yadang",
	NextID = 14408905,
}
StorySpeechConfig[StorySpeechID.Id14408905] =
{
	Id = 14408905,
	CharName = "喇叭",
	Text = "（侦探小姐的声音）最后通报，请身上就遮片树叶的艺术品尽快更换衣物！！",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "EventItem_RPG_Event_8",
	NextID = 14408906,
}
StorySpeechConfig[StorySpeechID.Id14408906] =
{
	Id = 14408906,
	CharName = "亚当",
	Text = "嘿嘿，竟然就遮片树叶诶~~真的是太夸张了~",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_22_yadang",
	NextID = 14408907,
}
StorySpeechConfig[StorySpeechID.Id14408907] =
{
	Id = 14408907,
	CharName = "侦探小姐",
	Text = "（出现在身边，用喇叭喊）喂！！！说的就是你啊！！！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_17_zhentanxiaojie",
	NextID = 14408908,
}
StorySpeechConfig[StorySpeechID.Id14408908] =
{
	Id = 14408908,
	CharName = "亚当",
	Text = "（整个人跳起来）干嘛啊！！吓得我叶子也掉了！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_22_yadang",
	NextID = 14408909,
}
StorySpeechConfig[StorySpeechID.Id14408909] =
{
	Id = 14408909,
	CharName = "侦探小姐",
	Text = "（捂住脸）亚当，快把衣服穿起来！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_17_zhentanxiaojie",
	NextID = 14408910,
}
StorySpeechConfig[StorySpeechID.Id14408910] =
{
	Id = 14408910,
	CharName = "亚当",
	Text = "我哪里暴露了啊，我生下来就这样的，怕不卫生，我还专门找了树叶呢！！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_22_yadang",
	NextID = 14408911,
}
StorySpeechConfig[StorySpeechID.Id14408911] =
{
	Id = 14408911,
	CharName = "侦探小姐",
	Text = "来人，帮忙给他把衣服穿上！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_17_zhentanxiaojie",
}
StorySpeechConfig[StorySpeechID.Id14409001] =
{
	Id = 14409001,
	CharName = "小天使",
	Text = "天父，天父~~我们想出去玩。",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	LeftIcon = "Equipment_MUS_23_chuangzaozhishen_2",
	NextID = 14409002,
}
StorySpeechConfig[StorySpeechID.Id14409002] =
{
	Id = 14409002,
	CharName = "创造之神",
	Text = "不行！没了你们，我不就成了一个穿着大长袍的普通老人了吗！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_23_chuangzaozhishen",
	NextID = 14409003,
}
StorySpeechConfig[StorySpeechID.Id14409003] =
{
	Id = 14409003,
	CharName = "小天使",
	Text = "好不好嘛？天父，一直待在画框里好无聊噢~",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	LeftIcon = "Equipment_MUS_23_chuangzaozhishen_2",
	NextID = 14409004,
}
StorySpeechConfig[StorySpeechID.Id14409004] =
{
	Id = 14409004,
	CharName = "创造之神",
	Text = "绝对不行！你们有没有点责任心？别人来了，看到没有天使的我会怎么想！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_23_chuangzaozhishen",
	NextID = 14409005,
}
StorySpeechConfig[StorySpeechID.Id14409005] =
{
	Id = 14409005,
	CharName = "小天使",
	Text = "那~我们帮你找到替代品的话，可以让我们出去玩吗？",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	LeftIcon = "Equipment_MUS_23_chuangzaozhishen_2",
	NextID = 14409006,
}
StorySpeechConfig[StorySpeechID.Id14409006] =
{
	Id = 14409006,
	CharName = "创造之神",
	Text = "你们打算找什么来代替？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_23_chuangzaozhishen",
	NextID = 14409007,
}
StorySpeechConfig[StorySpeechID.Id14409007] =
{
	Id = 14409007,
	CharName = "小天使",
	Text = "天父，你还记得那次你看中的那个游客头上戴的光环吗？",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	LeftIcon = "Equipment_MUS_23_chuangzaozhishen_2",
	NextID = 14409008,
}
StorySpeechConfig[StorySpeechID.Id14409008] =
{
	Id = 14409008,
	CharName = "创造之神",
	Text = "啊，那是多么完美的光环，光线柔和，形状也非常完美。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_23_chuangzaozhishen",
	NextID = 14409009,
}
StorySpeechConfig[StorySpeechID.Id14409009] =
{
	Id = 14409009,
	CharName = "小天使",
	Text = "对，对~就是那个闪耀着璀璨光芒，让一切邪恶之物都感到畏惧的光环~",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	LeftIcon = "Equipment_MUS_23_chuangzaozhishen_2",
	NextID = 14409010,
}
StorySpeechConfig[StorySpeechID.Id14409010] =
{
	Id = 14409010,
	CharName = "创造之神",
	Text = "只要你们找到，我立刻让你们去玩~",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_23_chuangzaozhishen",
	NextID = 14409011,
}
StorySpeechConfig[StorySpeechID.Id14409011] =
{
	Id = 14409011,
	CharName = "小天使",
	Text = "你看！！天父，那个游客就在那里呢~~",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	LeftIcon = "Equipment_MUS_23_chuangzaozhishen_2",
	NextID = 14409012,
}
StorySpeechConfig[StorySpeechID.Id14409012] =
{
	Id = 14409012,
	CharName = "剑士",
	Text = "诶！你们找我吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 14409013,
}
StorySpeechConfig[StorySpeechID.Id14409013] =
{
	Id = 14409013,
	CharName = "创造之神",
	Text = "小朋友，你过来，我跟你说件事情……",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_23_chuangzaozhishen",
}
StorySpeechConfig[StorySpeechID.Id14408201] =
{
	Id = 14408201,
	CharName = "《如何成为火熊猫》",
	Text = "击败魔王城堡的火山巨蟹后，可开启通往城堡宝库的道路，击败火元素即可解锁火焰之力。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "RPG_Material_001",
	NextID = 14408202,
}
StorySpeechConfig[StorySpeechID.Id14408202] =
{
	Id = 14408202,
	CharName = "浣熊大哥",
	Text = "嗯，按照书上说的，再往前走就到了，你们看！前面就是神殿了。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_13_dage",
	NextID = 14408203,
}
StorySpeechConfig[StorySpeechID.Id14408203] =
{
	Id = 14408203,
	CharName = "燃烧结晶",
	Text = "（火焰之力被封存在燃烧结晶中，不过狂乱的热流似乎想挣脱结晶的束缚）",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "RPG_Material_018",
	NextID = 14408204,
}
StorySpeechConfig[StorySpeechID.Id14408204] =
{
	Id = 14408204,
	CharName = "浣熊大哥",
	Text = "这么烫！用我的铲子把它铲过来？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_13_dage",
	NextID = 14408205,
}
StorySpeechConfig[StorySpeechID.Id14408205] =
{
	Id = 14408205,
	CharName = "浣熊二哥",
	Text = "好主意，老大~就这么办！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_14_erge",
	NextID = 14408206,
}
StorySpeechConfig[StorySpeechID.Id14408206] =
{
	Id = 14408206,
	CharName = "浣熊小弟",
	Text = "哇，一定要小心点噢~万一掉在地上面，里面的火元素跑出来就吓人了。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_15_xiaodi",
	NextID = 14408207,
}
StorySpeechConfig[StorySpeechID.Id14408207] =
{
	Id = 14408207,
	CharName = "浣熊大哥",
	Text = "瞎说什么！哎，哎，哎！掉地上了……",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_13_dage",
	NextID = 14408208,
}
StorySpeechConfig[StorySpeechID.Id14408208] =
{
	Id = 14408208,
	CharName = "燃烧结晶",
	Text = "（火焰宝石落地的一刹那，瞬间碎裂，一团巨大的火焰爆发开来）",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	RightIcon = "RPG_Material_018",
	NextID = 14408209,
}
StorySpeechConfig[StorySpeechID.Id14408209] =
{
	Id = 14408209,
	CharName = "火焰巨人",
	Text = "吼！！！！是谁释放了我！！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_GiantFire",
	NextID = 14408210,
}
StorySpeechConfig[StorySpeechID.Id14408210] =
{
	Id = 14408210,
	CharName = "浣熊小弟",
	Text = "（目瞪口呆）",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_15_xiaodi",
	NextID = 14408211,
}
StorySpeechConfig[StorySpeechID.Id14408211] =
{
	Id = 14408211,
	CharName = "浣熊大哥",
	Text = "二弟，三弟，都到了这一步了，别放过它！刚睡醒的生物都很弱的！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_13_dage",
}
StorySpeechConfig[StorySpeechID.Id14408301] =
{
	Id = 14408301,
	CharName = "《如何成为风熊猫》",
	Text = "从村口树林一直向东抵达伟大森林，击败智慧树枝即可解锁风暴之力。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "RPG_Material_001",
	NextID = 14408302,
}
StorySpeechConfig[StorySpeechID.Id14408302] =
{
	Id = 14408302,
	CharName = "浣熊二哥",
	Text = "嘿嘿，按照书上说的，再往前走就到了，你们看！前面就是智慧树了。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_14_erge",
	NextID = 14408303,
}
StorySpeechConfig[StorySpeechID.Id14408303] =
{
	Id = 14408303,
	CharName = "智慧树枝",
	Text = "（风暴之力围绕在智慧树枝左右，不过无法挣脱树枝的束缚）",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "RPG_Material_005",
	NextID = 14408304,
}
StorySpeechConfig[StorySpeechID.Id14408304] =
{
	Id = 14408304,
	CharName = "浣熊二哥",
	Text = "走不过去诶，用我的夹子把它夹过来吗？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_14_erge",
	NextID = 14408305,
}
StorySpeechConfig[StorySpeechID.Id14408305] =
{
	Id = 14408305,
	CharName = "浣熊大哥",
	Text = "好主意！就这么办！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_13_dage",
	NextID = 14408306,
}
StorySpeechConfig[StorySpeechID.Id14408306] =
{
	Id = 14408306,
	CharName = "浣熊小弟",
	Text = "哇，一定要小心点噢~万一夹断了，里面的风元素跑出来就吓人了。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_15_xiaodi",
	NextID = 14408307,
}
StorySpeechConfig[StorySpeechID.Id14408307] =
{
	Id = 14408307,
	CharName = "浣熊二哥",
	Text = "瞎说什么！哎，哎，哎！吧唧，夹断了……",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_14_erge",
	NextID = 14408308,
}
StorySpeechConfig[StorySpeechID.Id14408308] =
{
	Id = 14408308,
	CharName = "智慧树枝",
	Text = "（树枝被夹断的一刹那，风暴挣脱了束缚，强风卷起附近的树叶，最终变成了一个怪物）",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	RightIcon = "RPG_Material_005",
	NextID = 14408309,
}
StorySpeechConfig[StorySpeechID.Id14408309] =
{
	Id = 14408309,
	CharName = "树精",
	Text = "吼！！！！我又获得自由了！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_xiaoshuyang",
	NextID = 14408310,
}
StorySpeechConfig[StorySpeechID.Id14408310] =
{
	Id = 14408310,
	CharName = "浣熊小弟",
	Text = "（呆若木鸡）",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_15_xiaodi",
	NextID = 14408311,
}
StorySpeechConfig[StorySpeechID.Id14408311] =
{
	Id = 14408311,
	CharName = "浣熊二哥",
	Text = "大哥，小弟，都到了这一步了，别放过它！刚组起来的东西都很弱的！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_14_erge",
}
StorySpeechConfig[StorySpeechID.Id14408401] =
{
	Id = 14408401,
	CharName = "《如何成为土熊猫》",
	Text = "来到魔法平原后，使用机关破坏法阵释放大地灵，击败大地灵即可解锁大地之力。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "RPG_Material_001",
	NextID = 14408402,
}
StorySpeechConfig[StorySpeechID.Id14408402] =
{
	Id = 14408402,
	CharName = "浣熊小弟",
	Text = "按照书上说的，再往前走就到了，你们看！前面就是魔法阵了。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_15_xiaodi",
	NextID = 14408403,
}
StorySpeechConfig[StorySpeechID.Id14408403] =
{
	Id = 14408403,
	CharName = "巨大魔法石",
	Text = "（大地之力被保护在巨大魔法石中，不过把耳朵贴在上面可以听到大地起伏的呼吸声）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_dashitou",
	NextID = 14408404,
}
StorySpeechConfig[StorySpeechID.Id14408404] =
{
	Id = 14408404,
	CharName = "浣熊小弟",
	Text = "大哥，二哥~我用钻头钻个洞，把力量引出来吧？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_15_xiaodi",
	NextID = 14408405,
}
StorySpeechConfig[StorySpeechID.Id14408405] =
{
	Id = 14408405,
	CharName = "浣熊大哥",
	Text = "好主意！就这么办！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_13_dage",
	NextID = 14408406,
}
StorySpeechConfig[StorySpeechID.Id14408406] =
{
	Id = 14408406,
	CharName = "浣熊二哥",
	Text = "功率一定要调到最小，万一把石头钻裂开了，事情就大条了！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_14_erge",
	NextID = 14408407,
}
StorySpeechConfig[StorySpeechID.Id14408407] =
{
	Id = 14408407,
	CharName = "浣熊小弟",
	Text = "好的，我会注意的！滋！滋！滋！哎！石头咔嚓裂开了！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_15_xiaodi",
	NextID = 14408408,
}
StorySpeechConfig[StorySpeechID.Id14408408] =
{
	Id = 14408408,
	CharName = "巨大魔法石",
	Text = "（一开始只是些许细纹，不过随即继续开裂，最终石头碎成了两块，一声沉闷的吼声响起）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_dashitou",
	NextID = 14408409,
}
StorySpeechConfig[StorySpeechID.Id14408409] =
{
	Id = 14408409,
	CharName = "石巨人",
	Text = "吼！！！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_Stoneman",
	NextID = 14408410,
}
StorySpeechConfig[StorySpeechID.Id14408410] =
{
	Id = 14408410,
	CharName = "浣熊大哥",
	Text = "（铲子掉落在地）",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_13_dage",
	NextID = 14408411,
}
StorySpeechConfig[StorySpeechID.Id14408411] =
{
	Id = 14408411,
	CharName = "浣熊小弟",
	Text = "大哥，二哥，都到了这一步了，别放过它！刚刚脱壳的怪物都很弱的！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_15_xiaodi",
}
StorySpeechConfig[StorySpeechID.Id14409301] =
{
	Id = 14409301,
	CharName = "病态赌徒",
	Text = "不行，再来一盘！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_04_UnlockChief",
	NextID = 14409302,
}
StorySpeechConfig[StorySpeechID.Id14409302] =
{
	Id = 14409302,
	CharName = "原始人爸爸",
	Text = "客人，你已经没有筹码了，别赌了吧。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_24_yuanshirenbaba",
	NextID = 14409303,
}
StorySpeechConfig[StorySpeechID.Id14409303] =
{
	Id = 14409303,
	CharName = "病态赌徒",
	Text = "我在你这里输了这么多，就不能白送我赌一把？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_04_UnlockChief",
	NextID = 14409304,
}
StorySpeechConfig[StorySpeechID.Id14409304] =
{
	Id = 14409304,
	CharName = "原始人爸爸",
	Text = "这摊子我只是代替馆方经营的。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_24_yuanshirenbaba",
	NextID = 14409305,
}
StorySpeechConfig[StorySpeechID.Id14409305] =
{
	Id = 14409305,
	CharName = "病态赌徒",
	Text = "那这样，我这身衣服是刚买的，你要是看得上，就算10个筹码吧。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_04_UnlockChief",
	NextID = 14409306,
}
StorySpeechConfig[StorySpeechID.Id14409306] =
{
	Id = 14409306,
	CharName = "原始人爸爸",
	Text = "那……就再来一把……",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_24_yuanshirenbaba",
	NextID = 14409307,
}
StorySpeechConfig[StorySpeechID.Id14409307] =
{
	Id = 14409307,
	CharName = "病态赌徒",
	Text = "开！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_04_UnlockChief",
	NextID = 14409308,
}
StorySpeechConfig[StorySpeechID.Id14409308] =
{
	Id = 14409308,
	CharName = "发牌器",
	Text = "（原始人爸爸8点，病态赌徒20点）",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	RightIcon = "Equipment_MUS_16_yelifushentou_3",
	NextID = 14409309,
}
StorySpeechConfig[StorySpeechID.Id14409309] =
{
	Id = 14409309,
	CharName = "病态赌徒",
	Text = "哈哈哈哈哈，那就让我最后拿个21点来个完美的结束吧，再来一张。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_04_UnlockChief",
	NextID = 14409310,
}
StorySpeechConfig[StorySpeechID.Id14409310] =
{
	Id = 14409310,
	CharName = "发牌器",
	Text = "（病态赌徒拿到一张2，超点数，失败）",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	RightIcon = "Equipment_MUS_16_yelifushentou_3",
	NextID = 14409311,
}
StorySpeechConfig[StorySpeechID.Id14409311] =
{
	Id = 14409311,
	CharName = "原始人爸爸",
	Text = "-_-||",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_24_yuanshirenbaba",
	NextID = 14409312,
}
StorySpeechConfig[StorySpeechID.Id14409312] =
{
	Id = 14409312,
	CharName = "病态赌徒",
	Text = "哇，你作弊！今天让我好好教训你一顿！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPDraw_04_UnlockChief",
}
StorySpeechConfig[StorySpeechID.Id14409401] =
{
	Id = 14409401,
	CharName = "病态赌徒",
	Text = "不行，再来一盘！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_04_UnlockChief",
	NextID = 14409402,
}
StorySpeechConfig[StorySpeechID.Id14409402] =
{
	Id = 14409402,
	CharName = "原始人妈妈",
	Text = "客人，你已经没有筹码了，别赌了吧。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_25_yuanshirenmama",
	NextID = 14409403,
}
StorySpeechConfig[StorySpeechID.Id14409403] =
{
	Id = 14409403,
	CharName = "病态赌徒",
	Text = "我在你这里输了这么多，就不能白送我赌一把？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_04_UnlockChief",
	NextID = 14409404,
}
StorySpeechConfig[StorySpeechID.Id14409404] =
{
	Id = 14409404,
	CharName = "原始人妈妈",
	Text = "这摊子我只是代替馆方经营的。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_25_yuanshirenmama",
	NextID = 14409405,
}
StorySpeechConfig[StorySpeechID.Id14409405] =
{
	Id = 14409405,
	CharName = "病态赌徒",
	Text = "那这样，我这身衣服是打算买来送我老婆的，你要是看得上，就算10个筹码吧。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_04_UnlockChief",
	NextID = 14409406,
}
StorySpeechConfig[StorySpeechID.Id14409406] =
{
	Id = 14409406,
	CharName = "原始人妈妈",
	Text = "那……就再来一把……",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_25_yuanshirenmama",
	NextID = 14409407,
}
StorySpeechConfig[StorySpeechID.Id14409407] =
{
	Id = 14409407,
	CharName = "病态赌徒",
	Text = "开！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_04_UnlockChief",
	NextID = 14409408,
}
StorySpeechConfig[StorySpeechID.Id14409408] =
{
	Id = 14409408,
	CharName = "发牌器",
	Text = "（原始人妈妈黑桃A+红桃A+草花A+方片A+？，病态赌徒黑桃3+方片5+草花8+红桃J+？）",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	RightIcon = "Equipment_MUS_16_yelifushentou_3",
	NextID = 14409409,
}
StorySpeechConfig[StorySpeechID.Id14409409] =
{
	Id = 14409409,
	CharName = "病态赌徒",
	Text = "（只要我够气势，就能唬住庄家，对！）我梭了！你跟不跟吧？！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_04_UnlockChief",
	NextID = 14409410,
}
StorySpeechConfig[StorySpeechID.Id14409410] =
{
	Id = 14409410,
	CharName = "原始人妈妈",
	Text = "-_-||那我也跟了吧……我是4A+K，你什么都不是……",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_25_yuanshirenmama",
	NextID = 14409411,
}
StorySpeechConfig[StorySpeechID.Id14409411] =
{
	Id = 14409411,
	CharName = "病态赌徒",
	Text = "哇，你作弊！今天让我好好教训你一顿！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_04_UnlockChief",
}
StorySpeechConfig[StorySpeechID.Id14409501] =
{
	Id = 14409501,
	CharName = "病态赌徒",
	Text = "不行，再来一盘！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_04_UnlockChief",
	NextID = 14409502,
}
StorySpeechConfig[StorySpeechID.Id14409502] =
{
	Id = 14409502,
	CharName = "原始人儿子",
	Text = "客人，你已经没有筹码了，别赌了吧。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_26_yuanshirenerzi",
	NextID = 14409503,
}
StorySpeechConfig[StorySpeechID.Id14409503] =
{
	Id = 14409503,
	CharName = "病态赌徒",
	Text = "我在你这里输了这么多，就不能白送我赌一把？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_04_UnlockChief",
	NextID = 14409504,
}
StorySpeechConfig[StorySpeechID.Id14409504] =
{
	Id = 14409504,
	CharName = "原始人儿子",
	Text = "这摊子我只是帮爸爸妈妈看着的。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_26_yuanshirenerzi",
	NextID = 14409505,
}
StorySpeechConfig[StorySpeechID.Id14409505] =
{
	Id = 14409505,
	CharName = "病态赌徒",
	Text = "那这样，我这身衣服是打算买给我儿子的，你要是看得上，就算10个筹码吧。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_04_UnlockChief",
	NextID = 14409506,
}
StorySpeechConfig[StorySpeechID.Id14409506] =
{
	Id = 14409506,
	CharName = "原始人儿子",
	Text = "那……就再来一把……",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_26_yuanshirenerzi",
	NextID = 14409507,
}
StorySpeechConfig[StorySpeechID.Id14409507] =
{
	Id = 14409507,
	CharName = "病态赌徒",
	Text = "等等！我们别来虚的，我们比赛丢飞镖！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_04_UnlockChief",
	NextID = 14409508,
}
StorySpeechConfig[StorySpeechID.Id14409508] =
{
	Id = 14409508,
	CharName = "原始人儿子",
	Text = "好，丢到黑气球，要扣10分的噢~",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_26_yuanshirenerzi",
	NextID = 14409509,
}
StorySpeechConfig[StorySpeechID.Id14409509] =
{
	Id = 14409509,
	CharName = "病态赌徒",
	Text = "我丢！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_04_UnlockChief",
	NextID = 14409510,
}
StorySpeechConfig[StorySpeechID.Id14409510] =
{
	Id = 14409510,
	CharName = "飞镖",
	Text = "（以不可思议的角度连续刺破了10个黑气球）",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	RightIcon = "Equipment_Sus_22_bianji_2",
	NextID = 14409511,
}
StorySpeechConfig[StorySpeechID.Id14409511] =
{
	Id = 14409511,
	CharName = "原始人儿子",
	Text = "-_-||抱歉，你-100分，已经输了……",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_26_yuanshirenerzi",
	NextID = 14409512,
}
StorySpeechConfig[StorySpeechID.Id14409512] =
{
	Id = 14409512,
	CharName = "病态赌徒",
	Text = "哇，你作弊！今天让我好好教训你一顿！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPDraw_04_UnlockChief",
}
StorySpeechConfig[StorySpeechID.Id14408001] =
{
	Id = 14408001,
	CharName = "银月的怪盗",
	Text = "那么，保安先生，侦探小姐，这15幅名画、6个古董花瓶，20颗世界宝钻，我就收下了。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_16_yelifushentou_cos10",
	NextID = 14408002,
}
StorySpeechConfig[StorySpeechID.Id14408002] =
{
	Id = 14408002,
	CharName = "侦探小姐",
	Text = "竟然一次性拿走这么多，太小看我们了！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_17_zhentanxiaojie",
	NextID = 14408003,
}
StorySpeechConfig[StorySpeechID.Id14408003] =
{
	Id = 14408003,
	CharName = "保安",
	Text = "看来这次我真的要下岗了。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_27_baoan",
	NextID = 14408004,
}
StorySpeechConfig[StorySpeechID.Id14408004] =
{
	Id = 14408004,
	CharName = "银月的怪盗",
	Text = "诶，我又回来了……",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_16_yelifushentou_cos10",
	NextID = 14408005,
}
StorySpeechConfig[StorySpeechID.Id14408005] =
{
	Id = 14408005,
	CharName = "侦探小姐",
	Text = "-_-||，你怎么回来了？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_17_zhentanxiaojie",
	NextID = 14408006,
}
StorySpeechConfig[StorySpeechID.Id14408006] =
{
	Id = 14408006,
	CharName = "银月的怪盗",
	Text = "说来惭愧，在下刚刚开玻璃罩拿那颗“银河之泪”时把家钥匙拿出来忘在展示台了。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_16_yelifushentou_cos10",
	NextID = 14408007,
}
StorySpeechConfig[StorySpeechID.Id14408007] =
{
	Id = 14408007,
	CharName = "侦探小姐",
	Text = "那么，束手就擒吧！这次你休想逃脱！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_17_zhentanxiaojie",
	NextID = 14408008,
}
StorySpeechConfig[StorySpeechID.Id14408008] =
{
	Id = 14408008,
	CharName = "银月的怪盗",
	Text = "（biu，用麻醉枪放倒侦探小姐）我从来不和女性战斗，不过保安先生你嘛？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_16_yelifushentou_cos10",
	NextID = 14408009,
}
StorySpeechConfig[StorySpeechID.Id14408009] =
{
	Id = 14408009,
	CharName = "保安",
	Text = "来吧，让我们来一场男人间的较量，馆长说了，只要抓到你，我就可以升保安队长！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_27_baoan",
	NextID = 14408010,
}
StorySpeechConfig[StorySpeechID.Id14408010] =
{
	Id = 14408010,
	CharName = "银月的怪盗",
	Text = "噢嚯？只有一个保安的博物馆竟然还需要一个保安队长？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_16_yelifushentou_cos10",
}
StorySpeechConfig[StorySpeechID.Id14409701] =
{
	Id = 14409701,
	CharName = "猪蹄古董",
	Text = "啊，亲爱的珍珠少女~你猜我为你带了什么礼物？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_20_zhutigudong",
	NextID = 14409702,
}
StorySpeechConfig[StorySpeechID.Id14409702] =
{
	Id = 14409702,
	CharName = "带珍珠的少女",
	Text = "我猜是一件漂亮的珠宝。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_18_zhenzhuerhuan",
	NextID = 14409703,
}
StorySpeechConfig[StorySpeechID.Id14409703] =
{
	Id = 14409703,
	CharName = "猪蹄古董",
	Text = "是谁说上帝给人美貌后就会吝于再赐予她智慧呢？你真是美貌与智慧的完美结合啊~",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_20_zhutigudong",
	NextID = 14409704,
}
StorySpeechConfig[StorySpeechID.Id14409704] =
{
	Id = 14409704,
	CharName = "带珍珠的少女",
	Text = "那么是什么样的一件珠宝呢？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_18_zhenzhuerhuan",
	NextID = 14409705,
}
StorySpeechConfig[StorySpeechID.Id14409705] =
{
	Id = 14409705,
	CharName = "猪蹄古董",
	Text = "（取出翡翠的套装）你看。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_20_zhutigudong",
	NextID = 14409706,
}
StorySpeechConfig[StorySpeechID.Id14409706] =
{
	Id = 14409706,
	CharName = "带珍珠的少女",
	Text = "我想你一定会告诉我这件衣服名贵的地方。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_18_zhenzhuerhuan",
	NextID = 14409707,
}
StorySpeechConfig[StorySpeechID.Id14409707] =
{
	Id = 14409707,
	CharName = "猪蹄古董",
	Text = "虽然你的美丽已足以倾国倾城，但是你的聪明与之相比却更让人倾慕。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_20_zhutigudong",
	NextID = 14409708,
}
StorySpeechConfig[StorySpeechID.Id14409708] =
{
	Id = 14409708,
	CharName = "带珍珠的少女",
	Text = "那快说吧~",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_18_zhenzhuerhuan",
	NextID = 14409709,
}
StorySpeechConfig[StorySpeechID.Id14409709] =
{
	Id = 14409709,
	CharName = "猪蹄古董",
	Text = "这件衣服并没有多么特别，但是这块翡翠却是一件旷世奇珍，你听说过和氏璧吗？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_20_zhutigudong",
	NextID = 14409710,
}
StorySpeechConfig[StorySpeechID.Id14409710] =
{
	Id = 14409710,
	CharName = "带珍珠的少女",
	Text = "啊，原来这个就是……",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_18_zhenzhuerhuan",
	NextID = 14409711,
}
StorySpeechConfig[StorySpeechID.Id14409711] =
{
	Id = 14409711,
	CharName = "猪蹄古董",
	Text = "不是……但它们有可能是同一种东西，我让放大镜来讲给你听，这个有多稀有。放大镜，放大镜~",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_20_zhutigudong",
	NextID = 14409712,
}
StorySpeechConfig[StorySpeechID.Id14409712] =
{
	Id = 14409712,
	CharName = "放大镜",
	Text = "小的在，就让小的说一说这和氏璧的由来，话说古书《韩非子》中记载，曾有楚人卞和……",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	RightIcon = "Equipment_Sus_02_huasheng_3",
	NextID = 14409713,
}
StorySpeechConfig[StorySpeechID.Id14409713] =
{
	Id = 14409713,
	CharName = "猪蹄古董",
	Text = "谁让你说和氏璧，让你说说我这块翡翠多么罕见。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_20_zhutigudong",
	NextID = 14409714,
}
StorySpeechConfig[StorySpeechID.Id14409714] =
{
	Id = 14409714,
	CharName = "放大镜",
	Text = "噢，这块翡翠么……啧啧啧，应该是人工合成的，不过采用的是蓝星进口的流水线，所以质地光滑，价格区间应该在150~300之间。",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	RightIcon = "Equipment_Sus_02_huasheng_3",
	NextID = 14409715,
}
StorySpeechConfig[StorySpeechID.Id14409715] =
{
	Id = 14409715,
	CharName = "带珍珠的少女",
	Text = "哼，我从来不和这种廉价商品打交道的，你拿回去吧。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_18_zhenzhuerhuan",
	NextID = 14409716,
}
StorySpeechConfig[StorySpeechID.Id14409716] =
{
	Id = 14409716,
	CharName = "猪蹄古董",
	Text = "这放大镜每次都满嘴跑火车，只要稍加敲打，它就能证明这是无价之宝，到时候还请您笑纳~",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_20_zhutigudong",
}
StorySpeechConfig[StorySpeechID.Id14409801] =
{
	Id = 14409801,
	CharName = "银月的怪盗",
	Text = "那么这次和氏璧我就收下了，他日必定完璧归赵。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_16_yelifushentou_cos10",
	NextID = 14409802,
}
StorySpeechConfig[StorySpeechID.Id14409802] =
{
	Id = 14409802,
	CharName = "保安",
	Text = "太可恶了，就差一点，这次又被他得逞了！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_27_baoan",
	NextID = 14409803,
}
StorySpeechConfig[StorySpeechID.Id14409803] =
{
	Id = 14409803,
	CharName = "猪蹄古董",
	Text = "不就是一块玉嘛？保安大哥别生气了。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_20_zhutigudong",
	NextID = 14409804,
}
StorySpeechConfig[StorySpeechID.Id14409804] =
{
	Id = 14409804,
	CharName = "保安",
	Text = "唉……这可是传国玉玺，自古以来，就有得此璧者得天下的传闻。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_27_baoan",
	NextID = 14409805,
}
StorySpeechConfig[StorySpeechID.Id14409805] =
{
	Id = 14409805,
	CharName = "猪蹄古董",
	Text = "嗨~得天下又怎么样，又不能能得到美人们的心~",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_20_zhutigudong",
	NextID = 14409806,
}
StorySpeechConfig[StorySpeechID.Id14409806] =
{
	Id = 14409806,
	CharName = "保安",
	Text = "怎么不能？你不知道古代君王都有三宫六院，佳丽三千吗？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_27_baoan",
	NextID = 14409807,
}
StorySpeechConfig[StorySpeechID.Id14409807] =
{
	Id = 14409807,
	CharName = "猪蹄古董",
	Text = "此话当真？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_20_zhutigudong",
	NextID = 14409808,
}
StorySpeechConfig[StorySpeechID.Id14409808] =
{
	Id = 14409808,
	CharName = "银月的怪盗",
	Text = "嘿嘿嘿，三宫六院，佳丽三千在下可没有兴趣，不过想来将此物献给心爱之人，定然可以博得红颜一笑。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_16_yelifushentou_cos10",
	NextID = 14409809,
}
StorySpeechConfig[StorySpeechID.Id14409809] =
{
	Id = 14409809,
	CharName = "猪蹄古董",
	Text = "哇！怪盗快放下那宝贝！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_20_zhutigudong",
	NextID = 14409810,
}
StorySpeechConfig[StorySpeechID.Id14409810] =
{
	Id = 14409810,
	CharName = "银月的怪盗",
	Text = "哈哈哈哈~~诶！竟然一跃之间就跳上了天台……",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_16_yelifushentou_cos10",
	NextID = 14409811,
}
StorySpeechConfig[StorySpeechID.Id14409811] =
{
	Id = 14409811,
	CharName = "猪蹄古董",
	Text = "呀呀呀呀！！我感觉充满了力量了！！！佳丽三千等着我啊~~~",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_20_zhutigudong",
	NextID = 14409812,
}
StorySpeechConfig[StorySpeechID.Id14409812] =
{
	Id = 14409812,
	CharName = "银月的怪盗",
	Text = "哇，你别过来！你再过来我还手了啊！！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_16_yelifushentou_cos10",
}
StorySpeechConfig[StorySpeechID.Id14409601] =
{
	Id = 14409601,
	CharName = "木乃伊",
	Text = "敬爱的冥神，有个问题困扰我很久了。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_05_munaiyi",
	NextID = 14409602,
}
StorySpeechConfig[StorySpeechID.Id14409602] =
{
	Id = 14409602,
	CharName = "阿努比斯",
	Text = "渺小的凡人，向我说出你的困惑吧。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_01_Anubis",
	NextID = 14409603,
}
StorySpeechConfig[StorySpeechID.Id14409603] =
{
	Id = 14409603,
	CharName = "木乃伊",
	Text = "我们已经离开蓝星很久了，经过我自己画的正字计算日期，我发现今天似乎就是重启之日！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_05_munaiyi",
	NextID = 14409604,
}
StorySpeechConfig[StorySpeechID.Id14409604] =
{
	Id = 14409604,
	CharName = "阿努比斯",
	Text = "诶，你不说我都快忘了要迎接重启之日的降临了。那，我现在来主持一下？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_01_Anubis",
	NextID = 14409605,
}
StorySpeechConfig[StorySpeechID.Id14409605] =
{
	Id = 14409605,
	CharName = "木乃伊",
	Text = "好呀好呀~~",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_05_munaiyi",
	NextID = 14409606,
}
StorySpeechConfig[StorySpeechID.Id14409606] =
{
	Id = 14409606,
	CharName = "阿努比斯",
	Text = "那你把绷带脱掉，我启动一下神力。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_01_Anubis",
	NextID = 14409607,
}
StorySpeechConfig[StorySpeechID.Id14409607] =
{
	Id = 14409607,
	CharName = "木乃伊",
	Text = "哇，终于可以复活了~",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_05_munaiyi",
	NextID = 14409608,
}
StorySpeechConfig[StorySpeechID.Id14409608] =
{
	Id = 14409608,
	CharName = "阿努比斯",
	Text = "（轻声念出了召唤冥界之力的咒语，木乃伊感到一股强大的力量进入了身体。）",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_01_Anubis",
	NextID = 14409609,
}
StorySpeechConfig[StorySpeechID.Id14409609] =
{
	Id = 14409609,
	CharName = "黑猫",
	Text = "喵~",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	LeftIcon = "SUS_BlackCat",
	NextID = 14409610,
}
StorySpeechConfig[StorySpeechID.Id14409610] =
{
	Id = 14409610,
	CharName = "阿努比斯",
	Text = "什么！你刚刚进来没有关门嘛！仪式现场怎么会出现如此不详之物！！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_01_Anubis",
	NextID = 14409611,
}
StorySpeechConfig[StorySpeechID.Id14409611] =
{
	Id = 14409611,
	CharName = "黑猫",
	Text = "喵？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	LeftIcon = "SUS_BlackCat",
	NextID = 14409612,
}
StorySpeechConfig[StorySpeechID.Id14409612] =
{
	Id = 14409612,
	CharName = "木乃伊",
	Text = "啊，冥神大人，我觉得……我觉得不能控制自己了……我..我想吃肉！！！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_05_munaiyi",
	NextID = 14409613,
}
StorySpeechConfig[StorySpeechID.Id14409613] =
{
	Id = 14409613,
	CharName = "阿努比斯",
	Text = "好像要变成僵尸了，这下闯祸了……",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_01_Anubis",
	NextID = 14409614,
}
StorySpeechConfig[StorySpeechID.Id14409614] =
{
	Id = 14409614,
	CharName = "僵尸",
	Text = "呃！！！！！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_05_munaiyi_cos10",
	NextID = 14409615,
}
StorySpeechConfig[StorySpeechID.Id14409615] =
{
	Id = 14409615,
	CharName = "阿努比斯",
	Text = "得把它打醒，让他恢复过来！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_01_Anubis",
}
StorySpeechConfig[StorySpeechID.Id14410701] =
{
	Id = 14410701,
	CharName = "保安",
	Text = "女神，你的包裹~到付件，邮费1200，请收好~",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_27_baoan",
	NextID = 14410702,
}
StorySpeechConfig[StorySpeechID.Id14410702] =
{
	Id = 14410702,
	CharName = "微笑女神",
	Text = "给，多谢保安哥哥~（拆开看，有一封信和一个小包裹）",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_21_mengnalisha",
	NextID = 14410703,
}
StorySpeechConfig[StorySpeechID.Id14410703] =
{
	Id = 14410703,
	CharName = "情书",
	Text = "亲爱的微笑女神：\n见信好。这次为你带来了异乡的礼物。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	LeftIcon = "SUS_LoveLetter",
	NextID = 14410704,
}
StorySpeechConfig[StorySpeechID.Id14410704] =
{
	Id = 14410704,
	CharName = "微笑女神",
	Text = "啊，是他，他写了一封情书给我。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_21_mengnalisha",
	NextID = 14410705,
}
StorySpeechConfig[StorySpeechID.Id14410705] =
{
	Id = 14410705,
	CharName = "怪盗的音容",
	Text = "为了继续追查光之宝石的下落，我这次前往了悬疑星。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_16_yelifushentou_cos10",
	NextID = 14410706,
}
StorySpeechConfig[StorySpeechID.Id14410706] =
{
	Id = 14410706,
	CharName = "怪盗的音容",
	Text = "听说那里治安非常良好，我想这种和谐的气息一定会吸引光之宝石的注意。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_16_yelifushentou_cos10",
	NextID = 14410707,
}
StorySpeechConfig[StorySpeechID.Id14410707] =
{
	Id = 14410707,
	CharName = "怪盗的音容",
	Text = "不过令人意想不到的是，那里并不如所想的那样和谐。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_16_yelifushentou_cos10",
	NextID = 14410708,
}
StorySpeechConfig[StorySpeechID.Id14410708] =
{
	Id = 14410708,
	CharName = "怪盗的音容",
	Text = "编辑部为了赚钱甚至出版了非法刊物。一无所获的我，脑中忽然浮现出了你的身影。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_16_yelifushentou_cos10",
	NextID = 14410709,
}
StorySpeechConfig[StorySpeechID.Id14410709] =
{
	Id = 14410709,
	CharName = "怪盗的音容",
	Text = "然后，我就忽然想起你曾经说过，偶尔也希望变得更勇敢，更富有热情。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_16_yelifushentou_cos10",
	NextID = 14410710,
}
StorySpeechConfig[StorySpeechID.Id14410710] =
{
	Id = 14410710,
	CharName = "怪盗的音容",
	Text = "于是，我在经过一家10元店的时候，为你购买了当地特产的染发水，请你务必尝试一下。对了，邮费可能有点贵。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_16_yelifushentou_cos10",
	NextID = 14410711,
}
StorySpeechConfig[StorySpeechID.Id14410711] =
{
	Id = 14410711,
	CharName = "怪盗的音容",
	Text = "PS：听老板说，这个染发水是利用当地的特殊材料制作的。要先打服Ta才能使用，请小心，你受伤会令我心痛。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_16_yelifushentou_cos10",
	NextID = 14410712,
}
StorySpeechConfig[StorySpeechID.Id14410712] =
{
	Id = 14410712,
	CharName = "红墨水",
	Text = "喂！哪个杀千刀的要染发的？来呀，打我啊，我们墨水一族可不是好欺负哒！",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	RightIcon = "SUS_Material_023",
	NextID = 14410713,
}
StorySpeechConfig[StorySpeechID.Id14410713] =
{
	Id = 14410713,
	CharName = "微笑女神",
	Text = "……",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_21_mengnalisha",
}
StorySpeechConfig[StorySpeechID.Id14410801] =
{
	Id = 14410801,
	CharName = "保安",
	Text = "女神，今天也有你的包裹~还是到付件，邮费1200，请收好~",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_27_baoan",
	NextID = 14410802,
}
StorySpeechConfig[StorySpeechID.Id14410802] =
{
	Id = 14410802,
	CharName = "微笑女神",
	Text = "给，多谢保安哥哥~（拆开看，有一封信和一个小包裹）",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_21_mengnalisha",
	NextID = 14410803,
}
StorySpeechConfig[StorySpeechID.Id14410803] =
{
	Id = 14410803,
	CharName = "情书",
	Text = "亲爱的微笑女神：\n见信好。又为你带来了异乡的礼物。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	LeftIcon = "SUS_LoveLetter",
	NextID = 14410804,
}
StorySpeechConfig[StorySpeechID.Id14410804] =
{
	Id = 14410804,
	CharName = "微笑女神",
	Text = "啊，是他，他又写了一封情书给我。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_21_mengnalisha",
	NextID = 14410805,
}
StorySpeechConfig[StorySpeechID.Id14410805] =
{
	Id = 14410805,
	CharName = "另一个怪盗的音容",
	Text = "为了继续追查暗之宝石的下落，我这次前往了悬疑星。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_16_yelifushentou_cos20",
	NextID = 14410806,
}
StorySpeechConfig[StorySpeechID.Id14410806] =
{
	Id = 14410806,
	CharName = "另一个怪盗的音容",
	Text = "听说那里曾经有大量犯罪分子，我想这种罪恶的气味一定会吸引暗之宝石的注意。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_16_yelifushentou_cos20",
	NextID = 14410807,
}
StorySpeechConfig[StorySpeechID.Id14410807] =
{
	Id = 14410807,
	CharName = "另一个怪盗的音容",
	Text = "不过令人意想不到的是，那里现在治安出奇的好。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_16_yelifushentou_cos20",
	NextID = 14410808,
}
StorySpeechConfig[StorySpeechID.Id14410808] =
{
	Id = 14410808,
	CharName = "另一个怪盗的音容",
	Text = "以前的犯罪现场，现在也变成了拍摄取景地。一无所获的我，眼前忽然浮现出了你的身影。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_16_yelifushentou_cos20",
	NextID = 14410809,
}
StorySpeechConfig[StorySpeechID.Id14410809] =
{
	Id = 14410809,
	CharName = "另一个怪盗的音容",
	Text = "然后，我就忽然想起你曾经说过，偶尔也希望变得更温柔，希望心灵更宁静一些。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_16_yelifushentou_cos20",
	NextID = 14410810,
}
StorySpeechConfig[StorySpeechID.Id14410810] =
{
	Id = 14410810,
	CharName = "另一个怪盗的音容",
	Text = "于是，我在经过一家10元店的时候，为你购买了当地特产的染发水，请你务必尝试一下。对了，邮费可能有点贵。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_16_yelifushentou_cos20",
	NextID = 14410811,
}
StorySpeechConfig[StorySpeechID.Id14410811] =
{
	Id = 14410811,
	CharName = "另一个怪盗的音容",
	Text = "PS：听老板说，这个染发水是利用当地的特殊材料制作的。要先打服Ta才能使用，请小心，你受伤会令我心痛。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_16_yelifushentou_cos20",
	NextID = 14410812,
}
StorySpeechConfig[StorySpeechID.Id14410812] =
{
	Id = 14410812,
	CharName = "黑墨水",
	Text = "喂！哪个杀千刀的要染发的？来呀，打我啊，我们墨水一族可不是好欺负哒！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	RightIcon = "SUS_BlueInk",
	NextID = 14410813,
}
StorySpeechConfig[StorySpeechID.Id14410813] =
{
	Id = 14410813,
	CharName = "微笑女神",
	Text = "……",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_21_mengnalisha",
}
StorySpeechConfig[StorySpeechID.Id14410301] =
{
	Id = 14410301,
	CharName = "保安",
	Text = "啊，独耳先生，请问您这个月能再出一个作品吗？馆长这个月报给上级的指标还没到。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_27_baoan",
	NextID = 14410302,
}
StorySpeechConfig[StorySpeechID.Id14410302] =
{
	Id = 14410302,
	CharName = "独耳画像",
	Text = "什么时候要？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_08_fangao",
	NextID = 14410303,
}
StorySpeechConfig[StorySpeechID.Id14410303] =
{
	Id = 14410303,
	CharName = "保安",
	Text = "最好快一点，下午行不行？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_27_baoan",
	NextID = 14410304,
}
StorySpeechConfig[StorySpeechID.Id14410304] =
{
	Id = 14410304,
	CharName = "独耳画像",
	Text = "……这是不是也太快了一点？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_08_fangao",
	NextID = 14410305,
}
StorySpeechConfig[StorySpeechID.Id14410305] =
{
	Id = 14410305,
	CharName = "保安",
	Text = "馆长说如果是别人那肯定是不行的，但是对于依靠热情和对生命的感悟力来创造画作的先生您而言，只看您愿不愿意了。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_27_baoan",
	NextID = 14410306,
}
StorySpeechConfig[StorySpeechID.Id14410306] =
{
	Id = 14410306,
	CharName = "独耳画像",
	Text = "容我想一想。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_08_fangao",
	NextID = 14410307,
}
StorySpeechConfig[StorySpeechID.Id14410307] =
{
	Id = 14410307,
	CharName = "保安",
	Text = "馆长说，如果可以的话，下个月就把他那套珍藏的颜料送给您。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_27_baoan",
	NextID = 14410308,
}
StorySpeechConfig[StorySpeechID.Id14410308] =
{
	Id = 14410308,
	CharName = "独耳画像",
	Text = "那就没问题了。啊！！有灵感了，我要用火热的画笔再现曾经的自己！！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_08_fangao",
	NextID = 14410309,
}
StorySpeechConfig[StorySpeechID.Id14410309] =
{
	Id = 14410309,
	CharName = "保安",
	Text = "哇，又是自画像吗？实在是太精彩了！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_27_baoan",
	NextID = 14410310,
}
StorySpeechConfig[StorySpeechID.Id14410310] =
{
	Id = 14410310,
	CharName = "独耳画像",
	Text = "嗯，就是它了！ ",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_08_fangao",
}
StorySpeechConfig[StorySpeechID.Id14410401] =
{
	Id = 14410401,
	CharName = "保安",
	Text = "啊，独耳先生，请问您这个月能出一个采用另类技巧的作品吗？馆长这个月报给上级的指标还没到。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_27_baoan",
	NextID = 14410402,
}
StorySpeechConfig[StorySpeechID.Id14410402] =
{
	Id = 14410402,
	CharName = "独耳画像",
	Text = "什么时候要？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_08_fangao",
	NextID = 14410403,
}
StorySpeechConfig[StorySpeechID.Id14410403] =
{
	Id = 14410403,
	CharName = "保安",
	Text = "最好快一点，下午行不行？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_27_baoan",
	NextID = 14410404,
}
StorySpeechConfig[StorySpeechID.Id14410404] =
{
	Id = 14410404,
	CharName = "独耳画像",
	Text = "……这是不是也太快了一点？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_08_fangao",
	NextID = 14410405,
}
StorySpeechConfig[StorySpeechID.Id14410405] =
{
	Id = 14410405,
	CharName = "保安",
	Text = "馆长说如果是别人那肯定是不行的，但是对于依靠热情和对生命的感悟力来创造画作的先生您而言，只看您愿不愿意了。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_27_baoan",
	NextID = 14410406,
}
StorySpeechConfig[StorySpeechID.Id14410406] =
{
	Id = 14410406,
	CharName = "独耳画像",
	Text = "容我想一想。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_08_fangao",
	NextID = 14410407,
}
StorySpeechConfig[StorySpeechID.Id14410407] =
{
	Id = 14410407,
	CharName = "保安",
	Text = "馆长说，如果可以的话，下个月就把他那支珍藏的烟斗送给您。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_27_baoan",
	NextID = 14410408,
}
StorySpeechConfig[StorySpeechID.Id14410408] =
{
	Id = 14410408,
	CharName = "独耳画像",
	Text = "啊！！有灵感了，是点彩画法！分割光和色的经典技巧，一定能带来不同的感受！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_08_fangao",
	NextID = 14410409,
}
StorySpeechConfig[StorySpeechID.Id14410409] =
{
	Id = 14410409,
	CharName = "保安",
	Text = "哇，又是自画像吗？实在是太精彩了！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_27_baoan",
	NextID = 14410410,
}
StorySpeechConfig[StorySpeechID.Id14410410] =
{
	Id = 14410410,
	CharName = "独耳画像",
	Text = "嗯，就是它了！ ",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_08_fangao",
}
StorySpeechConfig[StorySpeechID.Id14411201] =
{
	Id = 14411201,
	CharName = "武士",
	Text = "诶！传送到城堡了吗？这次的任务是？噢，要打败大名。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_09_ribenwushi",
	NextID = 14411202,
}
StorySpeechConfig[StorySpeechID.Id14411202] =
{
	Id = 14411202,
	CharName = "一方的贵族",
	Text = "你是什么人！怎么出现在城堡里？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_09_ribenwushi_cos10",
	NextID = 14411203,
}
StorySpeechConfig[StorySpeechID.Id14411203] =
{
	Id = 14411203,
	CharName = "武士",
	Text = "我是来打败你的！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_09_ribenwushi",
	NextID = 14411204,
}
StorySpeechConfig[StorySpeechID.Id14411204] =
{
	Id = 14411204,
	CharName = "一方的贵族",
	Text = "慢着！你是想和我比试剑术吗？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_09_ribenwushi_cos10",
	NextID = 14411205,
}
StorySpeechConfig[StorySpeechID.Id14411205] =
{
	Id = 14411205,
	CharName = "武士",
	Text = "是！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_09_ribenwushi",
	NextID = 14411206,
}
StorySpeechConfig[StorySpeechID.Id14411206] =
{
	Id = 14411206,
	CharName = "一方的贵族",
	Text = "我认输。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_09_ribenwushi_cos10",
	NextID = 14411207,
}
StorySpeechConfig[StorySpeechID.Id14411207] =
{
	Id = 14411207,
	CharName = "武士",
	Text = "那请阁下交出衣物，好作为我获胜的证明。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_09_ribenwushi",
	NextID = 14411208,
}
StorySpeechConfig[StorySpeechID.Id14411208] =
{
	Id = 14411208,
	CharName = "一方的贵族",
	Text = "太过分了！士可杀不可辱，我们还是来痛痛快快打一场吧！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_09_ribenwushi_cos10",
}
StorySpeechConfig[StorySpeechID.Id14411301] =
{
	Id = 14411301,
	CharName = "武士",
	Text = "啊~传送成功了，这里是？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_09_ribenwushi",
	NextID = 14411302,
}
StorySpeechConfig[StorySpeechID.Id14411302] =
{
	Id = 14411302,
	CharName = "战国的青雷",
	Text = "（战场上的最后一人）你终于来了，小子。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_09_ribenwushi_cos20",
	NextID = 14411303,
}
StorySpeechConfig[StorySpeechID.Id14411303] =
{
	Id = 14411303,
	CharName = "武士",
	Text = "诶，阁下在等我吗？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_09_ribenwushi",
	NextID = 14411304,
}
StorySpeechConfig[StorySpeechID.Id14411304] =
{
	Id = 14411304,
	CharName = "战国的青雷",
	Text = "只有跟你的战斗我不允许有人打扰。我们就一对一地决出胜负吧！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_09_ribenwushi_cos20",
	NextID = 14411305,
}
StorySpeechConfig[StorySpeechID.Id14411305] =
{
	Id = 14411305,
	CharName = "武士",
	Text = "慢着！我们那里决斗都是上5个人的！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_09_ribenwushi",
	NextID = 14411306,
}
StorySpeechConfig[StorySpeechID.Id14411306] =
{
	Id = 14411306,
	CharName = "战国的青雷",
	Text = "Sure? 不是想取我人头吗？那你就要抱着必死的觉悟来啊！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_09_ribenwushi_cos20",
	NextID = 14411307,
}
StorySpeechConfig[StorySpeechID.Id14411307] =
{
	Id = 14411307,
	CharName = "武士",
	Text = "1对1对我太不利，不过为了不落人口舌，请阁下也召集朋友吧。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_09_ribenwushi",
	NextID = 14411308,
}
StorySpeechConfig[StorySpeechID.Id14411308] =
{
	Id = 14411308,
	CharName = "战国的青雷",
	Text = "Aha~真不凑巧，我很不会接受别人的忠告的。不过你如果真的打赢我，那就请拿上我的刀，替我去征服天下吧！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_09_ribenwushi_cos20",
	NextID = 14411309,
}
StorySpeechConfig[StorySpeechID.Id14411309] =
{
	Id = 14411309,
	CharName = "武士",
	Text = "无论阁下是不是这么说，在下都会这么做的。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_09_ribenwushi",
	NextID = 14411310,
}
StorySpeechConfig[StorySpeechID.Id14411310] =
{
	Id = 14411310,
	CharName = "战国的青雷",
	Text = "Hahahahah~~~有趣的小子！All right！Let's party !",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_09_ribenwushi_cos20",
}
StorySpeechConfig[StorySpeechID.Id14411401] =
{
	Id = 14411401,
	CharName = "龙狼的骑师",
	Text = "武士君，你已经学成了我所有的剑术了。那么，现在你的理想是什么？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_09_ribenwushi_cos30",
	NextID = 14411402,
}
StorySpeechConfig[StorySpeechID.Id14411402] =
{
	Id = 14411402,
	CharName = "武士",
	Text = "我想用手中的剑去惩恶扬善。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_09_ribenwushi",
	NextID = 14411403,
}
StorySpeechConfig[StorySpeechID.Id14411403] =
{
	Id = 14411403,
	CharName = "龙狼的骑师",
	Text = "还是以此为理想吗？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_09_ribenwushi_cos30",
	NextID = 14411404,
}
StorySpeechConfig[StorySpeechID.Id14411404] =
{
	Id = 14411404,
	CharName = "武士",
	Text = "是的，师傅。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_09_ribenwushi",
	NextID = 14411405,
}
StorySpeechConfig[StorySpeechID.Id14411405] =
{
	Id = 14411405,
	CharName = "龙狼的骑师",
	Text = "这个世界有恶人，也有善人，但是更多的是不可知者，他们只凭本能而活，无分善恶的。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_09_ribenwushi_cos30",
	NextID = 14411406,
}
StorySpeechConfig[StorySpeechID.Id14411406] =
{
	Id = 14411406,
	CharName = "武士",
	Text = "我想击败恶人，保护善人，引导余下的众人向善而行。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_09_ribenwushi",
	NextID = 14411407,
}
StorySpeechConfig[StorySpeechID.Id14411407] =
{
	Id = 14411407,
	CharName = "龙狼的骑师",
	Text = "哈哈哈哈~~你是一个有志向的男儿，那么，师傅祝你以后永不迷惘，手中的剑永不迟觉。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_09_ribenwushi_cos30",
	NextID = 14411408,
}
StorySpeechConfig[StorySpeechID.Id14411408] =
{
	Id = 14411408,
	CharName = "武士",
	Text = "弟子谨遵师傅教诲。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_09_ribenwushi",
	NextID = 14411409,
}
StorySpeechConfig[StorySpeechID.Id14411409] =
{
	Id = 14411409,
	CharName = "龙狼的骑师",
	Text = "那么，该是你选择自己的狼了。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_09_ribenwushi_cos30",
	NextID = 14411410,
}
StorySpeechConfig[StorySpeechID.Id14411410] =
{
	Id = 14411410,
	CharName = "武士",
	Text = "弟子想挑战师傅的白狼，弟子会背负着师傅的一切去执行自己的梦想的。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_09_ribenwushi",
	NextID = 14411411,
}
StorySpeechConfig[StorySpeechID.Id14411411] =
{
	Id = 14411411,
	CharName = "龙狼的骑师",
	Text = "好，好！月玉！与武士君一战！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_09_ribenwushi_cos30",
	NextID = 14411412,
}
StorySpeechConfig[StorySpeechID.Id14411412] =
{
	Id = 14411412,
	CharName = "月玉",
	Text = "嗷呜~~~~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_WhiteWolf",
}
StorySpeechConfig[StorySpeechID.Id14410501] =
{
	Id = 14410501,
	CharName = "保安",
	Text = "今天是一年一度的绘画大赛！由今年的候选人弗里达小姐挑战卫冕冠军红发先生！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_27_baoan",
	NextID = 14410502,
}
StorySpeechConfig[StorySpeechID.Id14410502] =
{
	Id = 14410502,
	CharName = "红发先生",
	Text = "看来你也是懂得生活苦难的人，你会是一个理想的对手的。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_08_fangao_cos10",
	NextID = 14410503,
}
StorySpeechConfig[StorySpeechID.Id14410503] =
{
	Id = 14410503,
	CharName = "弗里达",
	Text = "生活的苦难给予了我们重新去认识生命的决心，我想我们的对决是一个很好的交流机会。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_29_folida",
	NextID = 14410504,
}
StorySpeechConfig[StorySpeechID.Id14410504] =
{
	Id = 14410504,
	CharName = "红发先生",
	Text = "不过我一定要保住我的冠军宝座，我已经习惯了冠军专享的饭菜，吃不惯食堂里的饭了。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_08_fangao_cos10",
	NextID = 14410505,
}
StorySpeechConfig[StorySpeechID.Id14410505] =
{
	Id = 14410505,
	CharName = "弗里达",
	Text = "你已经沉湎于安逸的生活了。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_29_folida",
	NextID = 14410506,
}
StorySpeechConfig[StorySpeechID.Id14410506] =
{
	Id = 14410506,
	CharName = "红发先生",
	Text = "胡说！看我的热情笔法！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_08_fangao_cos10",
	NextID = 14410507,
}
StorySpeechConfig[StorySpeechID.Id14410507] =
{
	Id = 14410507,
	CharName = "弗里达",
	Text = "就让你看一下我对生命的理解吧！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_29_folida",
}
StorySpeechConfig[StorySpeechID.Id14410601] =
{
	Id = 14410601,
	CharName = "弗里达",
	Text = "啊，一朵被秋风吹落的花朵。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_29_folida",
	NextID = 14410602,
}
StorySpeechConfig[StorySpeechID.Id14410602] =
{
	Id = 14410602,
	CharName = "小花丛",
	Text = "放下！你给我放下！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_huacong",
	NextID = 14410603,
}
StorySpeechConfig[StorySpeechID.Id14410603] =
{
	Id = 14410603,
	CharName = "弗里达",
	Text = "诶？是谁在说话？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_29_folida",
	NextID = 14410604,
}
StorySpeechConfig[StorySpeechID.Id14410604] =
{
	Id = 14410604,
	CharName = "小花丛",
	Text = "（挪出来）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_huacong",
	NextID = 14410605,
}
StorySpeechConfig[StorySpeechID.Id14410605] =
{
	Id = 14410605,
	CharName = "弗里达",
	Text = "啊，原来是一丛小野花。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_29_folida",
	NextID = 14410606,
}
StorySpeechConfig[StorySpeechID.Id14410606] =
{
	Id = 14410606,
	CharName = "小花丛",
	Text = "什，什么小野花……我是这里的地头蛇花丛大王……（声音越来越小）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_huacong",
	NextID = 14410607,
}
StorySpeechConfig[StorySpeechID.Id14410607] =
{
	Id = 14410607,
	CharName = "弗里达",
	Text = "你拦住我，是不想我过去吗？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_29_folida",
	NextID = 14410608,
}
StorySpeechConfig[StorySpeechID.Id14410608] =
{
	Id = 14410608,
	CharName = "小花丛",
	Text = "喂……地上那朵花……要收费的……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_huacong",
	NextID = 14410609,
}
StorySpeechConfig[StorySpeechID.Id14410609] =
{
	Id = 14410609,
	CharName = "弗里达",
	Text = "原来是你的嘛？那还给你~",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_29_folida",
	NextID = 14410610,
}
StorySpeechConfig[StorySpeechID.Id14410610] =
{
	Id = 14410610,
	CharName = "小花丛",
	Text = "不用还了！你戴着……你戴着还挺合适的，算啦，就当送给你啦！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_huacong",
	NextID = 14410611,
}
StorySpeechConfig[StorySpeechID.Id14410611] =
{
	Id = 14410611,
	CharName = "花球老大",
	Text = "（跳出来一脚踢飞小花丛）哇，难怪一分钱都收不到，这样就不收钱了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_xiaohuaqiu",
	NextID = 14410612,
}
StorySpeechConfig[StorySpeechID.Id14410612] =
{
	Id = 14410612,
	CharName = "弗里达",
	Text = "喂！你怎么可以这样打自己的朋友？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_29_folida",
	NextID = 14410613,
}
StorySpeechConfig[StorySpeechID.Id14410613] =
{
	Id = 14410613,
	CharName = "花球老大",
	Text = "要你管，你今天不交出钱不要想过去噢！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_xiaohuaqiu",
}
StorySpeechConfig[StorySpeechID.Id14410901] =
{
	Id = 14410901,
	CharName = "保安",
	Text = "什么！怎么会有两个怪盗？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_27_baoan",
	NextID = 14410902,
}
StorySpeechConfig[StorySpeechID.Id14410902] =
{
	Id = 14410902,
	CharName = "魔术师",
	Text = "叫我奇迹的魔术师就好。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_16_yelifushentou",
	NextID = 14410903,
}
StorySpeechConfig[StorySpeechID.Id14410903] =
{
	Id = 14410903,
	CharName = "夜礼服假面",
	Text = "叫我暗夜的假面就好。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_16_yelifushentou_cos10",
	NextID = 14410904,
}
StorySpeechConfig[StorySpeechID.Id14410904] =
{
	Id = 14410904,
	CharName = "保安",
	Text = "你们是搭档吗？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_27_baoan",
	NextID = 14410905,
}
StorySpeechConfig[StorySpeechID.Id14410905] =
{
	Id = 14410905,
	CharName = "魔术师",
	Text = "我想不仅不是搭档，我们或许还是对手。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_16_yelifushentou",
	NextID = 14410906,
}
StorySpeechConfig[StorySpeechID.Id14410906] =
{
	Id = 14410906,
	CharName = "夜礼服假面",
	Text = "我想不仅是对手，或许还是情敌~",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_16_yelifushentou_cos10",
	NextID = 14410907,
}
StorySpeechConfig[StorySpeechID.Id14410907] =
{
	Id = 14410907,
	CharName = "魔术师",
	Text = "莫非你也喜欢……",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_16_yelifushentou",
	NextID = 14410908,
}
StorySpeechConfig[StorySpeechID.Id14410908] =
{
	Id = 14410908,
	CharName = "夜礼服假面",
	Text = "（在空中画出一个完美弧度的微笑）",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_16_yelifushentou_cos10",
	NextID = 14410909,
}
StorySpeechConfig[StorySpeechID.Id14410909] =
{
	Id = 14410909,
	CharName = "魔术师",
	Text = "（脸红）",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_16_yelifushentou",
	NextID = 14410910,
}
StorySpeechConfig[StorySpeechID.Id14410910] =
{
	Id = 14410910,
	CharName = "保安",
	Text = "你们快下来吧！别站在那么高的地方了！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_27_baoan",
	NextID = 14410911,
}
StorySpeechConfig[StorySpeechID.Id14410911] =
{
	Id = 14410911,
	CharName = "夜礼服假面",
	Text = "怎么样？今天是不是该我们决一胜负了？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_16_yelifushentou_cos10",
	NextID = 14410912,
}
StorySpeechConfig[StorySpeechID.Id14410912] =
{
	Id = 14410912,
	CharName = "魔术师",
	Text = "打就打，我会怕你吗？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_16_yelifushentou",
}
StorySpeechConfig[StorySpeechID.Id14411001] =
{
	Id = 14411001,
	CharName = "浣熊小弟",
	Text = "（在博物馆售票处哭泣）555~~~",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_15_xiaodi",
	NextID = 14411002,
}
StorySpeechConfig[StorySpeechID.Id14411002] =
{
	Id = 14411002,
	CharName = "魔术师",
	Text = "怎么了，小浣熊，怎么一个人在这里哭？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_16_yelifushentou",
	NextID = 14411003,
}
StorySpeechConfig[StorySpeechID.Id14411003] =
{
	Id = 14411003,
	CharName = "浣熊小弟",
	Text = "我攒了好久才能来博物馆星的，但是他们说未成年小浣熊不能买儿童半价票。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_15_xiaodi",
	NextID = 14411004,
}
StorySpeechConfig[StorySpeechID.Id14411004] =
{
	Id = 14411004,
	CharName = "魔术师",
	Text = "小家伙，别哭啦~让我带你进去吧？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_16_yelifushentou",
	NextID = 14411005,
}
StorySpeechConfig[StorySpeechID.Id14411005] =
{
	Id = 14411005,
	CharName = "浣熊小弟",
	Text = "诶？你有办法帮我买到半价票吗？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_15_xiaodi",
	NextID = 14411006,
}
StorySpeechConfig[StorySpeechID.Id14411006] =
{
	Id = 14411006,
	CharName = "魔术师",
	Text = "我可以让你免费进入噢~不过，我要打个电话~（拨给博士）",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_16_yelifushentou",
	NextID = 14411007,
}
StorySpeechConfig[StorySpeechID.Id14411007] =
{
	Id = 14411007,
	CharName = "博士",
	Text = "喂~这里是博士家，请问是哪里找？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_24_boshi",
	NextID = 14411008,
}
StorySpeechConfig[StorySpeechID.Id14411008] =
{
	Id = 14411008,
	CharName = "魔术师",
	Text = "喂，博士，我是魔术师，我现在正在博物馆星入口处，需要你把我的装备紧急空投过来。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_16_yelifushentou",
	NextID = 14411009,
}
StorySpeechConfig[StorySpeechID.Id14411009] =
{
	Id = 14411009,
	CharName = "博士",
	Text = "噢，是那套吧？无论背负什么都可以如同闪电一般移动。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_24_boshi",
	NextID = 14411010,
}
StorySpeechConfig[StorySpeechID.Id14411010] =
{
	Id = 14411010,
	CharName = "魔术师",
	Text = "对，就是那个！我的位置是，18032，38291，830。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_16_yelifushentou",
	NextID = 14411011,
}
StorySpeechConfig[StorySpeechID.Id14411011] =
{
	Id = 14411011,
	CharName = "浣熊小弟",
	Text = "哇~~好开心，可以参观博物馆了~~",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_15_xiaodi",
	NextID = 14411012,
}
StorySpeechConfig[StorySpeechID.Id14411012] =
{
	Id = 14411012,
	CharName = "博士",
	Text = "好，空投！诶呀..手抖输入错误了。装备空投到保安那里了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_24_boshi",
	NextID = 14411013,
}
StorySpeechConfig[StorySpeechID.Id14411013] =
{
	Id = 14411013,
	CharName = "魔术师",
	Text = "-_-||",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_16_yelifushentou",
	NextID = 14411014,
}
StorySpeechConfig[StorySpeechID.Id14411014] =
{
	Id = 14411014,
	CharName = "浣熊小弟",
	Text = "（眼泪打转）",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_15_xiaodi",
	NextID = 14411015,
}
StorySpeechConfig[StorySpeechID.Id14411015] =
{
	Id = 14411015,
	CharName = "保安",
	Text = "诶？怎么这有套衣服？诶！这不是怪盗73号的衣服吗？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_27_baoan",
	NextID = 14411016,
}
StorySpeechConfig[StorySpeechID.Id14411016] =
{
	Id = 14411016,
	CharName = "魔术师",
	Text = "好，把装备抢回来就好了！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_16_yelifushentou",
}
StorySpeechConfig[StorySpeechID.Id14411101] =
{
	Id = 14411101,
	CharName = "魔术师",
	Text = "有个玻璃瓶？里面还有一艘小船，哇，好精致的手工啊~",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_16_yelifushentou",
	NextID = 14411102,
}
StorySpeechConfig[StorySpeechID.Id14411102] =
{
	Id = 14411102,
	CharName = "瓶中船",
	Text = "（瓶中传出沉闷的声音）啊，船长，我们终于又见面了，请快放我出来吧。",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	RightIcon = "Equipment_Pir_CaptainRoamn_2",
	NextID = 14411103,
}
StorySpeechConfig[StorySpeechID.Id14411103] =
{
	Id = 14411103,
	CharName = "魔术师",
	Text = "好熟悉的声音~是谁呢？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_16_yelifushentou",
	NextID = 14411104,
}
StorySpeechConfig[StorySpeechID.Id14411104] =
{
	Id = 14411104,
	CharName = "瓶中船",
	Text = "我是你的大副呀，尊敬的船长大人？看来你已没有前世的记忆了，我们曾经一起去过宇宙之海的尽头。",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	RightIcon = "Equipment_Pir_CaptainRoamn_2",
	NextID = 14411105,
}
StorySpeechConfig[StorySpeechID.Id14411105] =
{
	Id = 14411105,
	CharName = "魔术师",
	Text = "啊，完全没有印象。不过这么帅气的事情倒是很符合我个人的审美趣味~",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_16_yelifushentou",
	NextID = 14411106,
}
StorySpeechConfig[StorySpeechID.Id14411106] =
{
	Id = 14411106,
	CharName = "瓶中船",
	Text = "那么，请拧开瓶盖，释放这艘已经与你阔别多年的魔法战舰吧！",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	RightIcon = "Equipment_Pir_CaptainRoamn_2",
	NextID = 14411107,
}
StorySpeechConfig[StorySpeechID.Id14411107] =
{
	Id = 14411107,
	CharName = "魔术师",
	Text = "好~\n（打开瓶盖时，一群游魂从瓶中窜出来，瓶中的海水流了一地）",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_16_yelifushentou",
	NextID = 14411108,
}
StorySpeechConfig[StorySpeechID.Id14411108] =
{
	Id = 14411108,
	CharName = "骷髅王",
	Text = "啊，船长，船长，你当年为什么抛弃了我们呢？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_30_kulou_cos10",
	NextID = 14411109,
}
StorySpeechConfig[StorySpeechID.Id14411109] =
{
	Id = 14411109,
	CharName = "魔术师",
	Text = "哇！！好可怕！你不是人，你是什么！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_16_yelifushentou",
	NextID = 14411110,
}
StorySpeechConfig[StorySpeechID.Id14411110] =
{
	Id = 14411110,
	CharName = "骷髅王",
	Text = "嘿嘿嘿嘿，我曾经是人！是你，是你没有坚决阻止我们动那批宝藏，现在，我们被诅咒了，永远都无法上岸了！只能做海里的游魂！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_30_kulou_cos10",
	NextID = 14411111,
}
StorySpeechConfig[StorySpeechID.Id14411111] =
{
	Id = 14411111,
	CharName = "魔术师",
	Text = "啊！！你别过来！！我不是你的船长。（把瓶盖塞回去）",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_16_yelifushentou",
	NextID = 14411112,
}
StorySpeechConfig[StorySpeechID.Id14411112] =
{
	Id = 14411112,
	CharName = "骷髅王",
	Text = "哈哈哈哈，你会成为我们船长的，只要我触碰你一下，你就会全部记起来的！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_30_kulou_cos10",
}
StorySpeechConfig[StorySpeechID.Id14411501] =
{
	Id = 14411501,
	CharName = "保安",
	Text = "名人蜡像，你说好的博物馆100周年的阅兵式准备好了吗？你可是说过你的字典没有“不可能”噢~~",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_27_baoan",
	NextID = 14411502,
}
StorySpeechConfig[StorySpeechID.Id14411502] =
{
	Id = 14411502,
	CharName = "保安",
	Text = "差不多的啦~~你快点彩排，这次有几万名外星嘉宾来参观呢~要是失败了，年终奖就瞬间蒸发噢~",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_27_baoan",
	NextID = 14411503,
}
StorySpeechConfig[StorySpeechID.Id14411503] =
{
	Id = 14411503,
	CharName = "名人蜡像",
	Text = "但是这4个……真的很难搞……喂！士兵，说，你以后想成为将军吗？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_30_Napoleon",
	NextID = 14411504,
}
StorySpeechConfig[StorySpeechID.Id14411504] =
{
	Id = 14411504,
	CharName = "兵马俑",
	Text = "不想，长官，我只想守皇陵！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_06_bingmayong",
	NextID = 14411505,
}
StorySpeechConfig[StorySpeechID.Id14411505] =
{
	Id = 14411505,
	CharName = "名人蜡像",
	Text = "士兵，你说，以后想成为将军吗？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_30_Napoleon",
	NextID = 14411506,
}
StorySpeechConfig[StorySpeechID.Id14411506] =
{
	Id = 14411506,
	CharName = "默艾",
	Text = "（摇头）",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_07_fuhuoshixiang",
	NextID = 14411507,
}
StorySpeechConfig[StorySpeechID.Id14411507] =
{
	Id = 14411507,
	CharName = "名人蜡像",
	Text = "那士兵，你想做将军吗？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_30_Napoleon",
	NextID = 14411508,
}
StorySpeechConfig[StorySpeechID.Id14411508] =
{
	Id = 14411508,
	CharName = "石柱人",
	Text = "贤者是不下达杀死他人的命令的。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_10_shizhuren",
	NextID = 14411509,
}
StorySpeechConfig[StorySpeechID.Id14411509] =
{
	Id = 14411509,
	CharName = "名人蜡像",
	Text = "那你呢，士兵？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_30_Napoleon",
	NextID = 14411510,
}
StorySpeechConfig[StorySpeechID.Id14411510] =
{
	Id = 14411510,
	CharName = "半人马石像",
	Text = "（嗖地一声就跑没了）",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_11_banrenma",
	NextID = 14411511,
}
StorySpeechConfig[StorySpeechID.Id14411511] =
{
	Id = 14411511,
	CharName = "名人蜡像",
	Text = "哇，我受不了啦！！你们4个，全部以逃兵罪论处，让我好好教训你们一顿！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_30_Napoleon",
}
StorySpeechConfig[StorySpeechID.Id14411601] =
{
	Id = 14411601,
	CharName = "保安",
	Text = "尊敬的统帅大人，根据最新的考证发现，原来您以前做过皇帝噢~",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_27_baoan",
	NextID = 14411602,
}
StorySpeechConfig[StorySpeechID.Id14411602] =
{
	Id = 14411602,
	CharName = "统帅",
	Text = "那我的月薪是不是应该调整一下？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_30_Napoleon_cos10",
	NextID = 14411603,
}
StorySpeechConfig[StorySpeechID.Id14411603] =
{
	Id = 14411603,
	CharName = "保安",
	Text = "陛下说笑了，前任保安20岁时申请的调薪，直到60岁退休的时候也没有调过。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_27_baoan",
	NextID = 14411604,
}
StorySpeechConfig[StorySpeechID.Id14411604] =
{
	Id = 14411604,
	CharName = "统帅",
	Text = "那还有什么好说的？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_30_Napoleon_cos10",
	NextID = 14411605,
}
StorySpeechConfig[StorySpeechID.Id14411605] =
{
	Id = 14411605,
	CharName = "保安",
	Text = "馆长希望拍一个纪录片，重现你当初登基时的画面。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_27_baoan",
	NextID = 14411606,
}
StorySpeechConfig[StorySpeechID.Id14411606] =
{
	Id = 14411606,
	CharName = "统帅",
	Text = "不想拍。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_30_Napoleon_cos10",
	NextID = 14411607,
}
StorySpeechConfig[StorySpeechID.Id14411607] =
{
	Id = 14411607,
	CharName = "保安",
	Text = "馆长说，这个片子拍得好，可以发餐补，还给三天假。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_27_baoan",
	NextID = 14411608,
}
StorySpeechConfig[StorySpeechID.Id14411608] =
{
	Id = 14411608,
	CharName = "统帅",
	Text = "那怎么拍？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_30_Napoleon_cos10",
	NextID = 14411609,
}
StorySpeechConfig[StorySpeechID.Id14411609] =
{
	Id = 14411609,
	CharName = "保安",
	Text = "馆长请了很多名人一起来助阵，现在就差个王冠。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_27_baoan",
	NextID = 14411610,
}
StorySpeechConfig[StorySpeechID.Id14411610] =
{
	Id = 14411610,
	CharName = "统帅",
	Text = "那你想怎么样？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_30_Napoleon_cos10",
	NextID = 14411611,
}
StorySpeechConfig[StorySpeechID.Id14411611] =
{
	Id = 14411611,
	CharName = "保安",
	Text = "冒险星的骷髅王代表魔王集团来观礼，我们把他打晕关在厕所里，然后借他王冠用一下，礼毕就还给他。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_27_baoan",
	NextID = 14411612,
}
StorySpeechConfig[StorySpeechID.Id14411612] =
{
	Id = 14411612,
	CharName = "统帅",
	Text = "就这么办！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_30_Napoleon_cos10",
}
StorySpeechConfig[StorySpeechID.Id14411701] =
{
	Id = 14411701,
	CharName = "名人蜡像",
	Text = "今天的胜利只是一个开始，未来，我们博物馆星的拔河项目将一直胜利下去！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_30_Napoleon",
	NextID = 14411702,
}
StorySpeechConfig[StorySpeechID.Id14411702] =
{
	Id = 14411702,
	CharName = "石柱人",
	Text = "哇~~~名人蜡像万岁~",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_10_shizhuren",
	NextID = 14411703,
}
StorySpeechConfig[StorySpeechID.Id14411703] =
{
	Id = 14411703,
	CharName = "原始人爸爸",
	Text = "奖金有2000多呢~~~算下来我也可以分到20块呢~",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_24_yuanshirenbaba",
	NextID = 14411704,
}
StorySpeechConfig[StorySpeechID.Id14411704] =
{
	Id = 14411704,
	CharName = "呐喊家",
	Text = "我在旁边一直喊加油也出了不少力的~~",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_19_nahan",
	NextID = 14411705,
}
StorySpeechConfig[StorySpeechID.Id14411705] =
{
	Id = 14411705,
	CharName = "赛特",
	Text = "关键还是靠名人蜡像先开了一枪，对方以为结束了，让我们一下子拔过来了，哈哈哈~",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_03_Set",
	NextID = 14411706,
}
StorySpeechConfig[StorySpeechID.Id14411706] =
{
	Id = 14411706,
	CharName = "名人蜡像",
	Text = "我们这次凯旋归来，要有仪式感一点！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_30_Napoleon",
	NextID = 14411707,
}
StorySpeechConfig[StorySpeechID.Id14411707] =
{
	Id = 14411707,
	CharName = "半人马石像",
	Text = "对！！我们今天从边门直接进去，那里回展厅要快很多呢~",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_11_banrenma",
	NextID = 14411708,
}
StorySpeechConfig[StorySpeechID.Id14411708] =
{
	Id = 14411708,
	CharName = "名人蜡像",
	Text = "好，今天我们就走那扇只属于我们的凯旋门！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_30_Napoleon",
	NextID = 14411709,
}
StorySpeechConfig[StorySpeechID.Id14411709] =
{
	Id = 14411709,
	CharName = "警示柱",
	Text = "站住！谁让你们过去的？！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	LeftIcon = "MUS_Cordon",
	NextID = 14411710,
}
StorySpeechConfig[StorySpeechID.Id14411710] =
{
	Id = 14411710,
	CharName = "名人蜡像",
	Text = "我们今天拔河赢了，是总冠军噢！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_30_Napoleon",
	NextID = 14411711,
}
StorySpeechConfig[StorySpeechID.Id14411711] =
{
	Id = 14411711,
	CharName = "警示柱",
	Text = "那也不能走这里，我站在这里，就表示这里不能通过！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	LeftIcon = "MUS_Cordon",
	NextID = 14411712,
}
StorySpeechConfig[StorySpeechID.Id14411712] =
{
	Id = 14411712,
	CharName = "猪蹄古董",
	Text = "这么嚣张！打它！平时就一直想打它了！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	RightIcon = "MUS_20_zhutigudong",
}
StorySpeechConfig[StorySpeechID.Id14412901] =
{
	Id = 14412901,
	CharName = "场务",
	Text = "大家就位！\n《杀人怪医》第13场 Take 2，Ca~~~me~ra！！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_23_tiaojiushi_cos10",
	NextID = 14412902,
}
StorySpeechConfig[StorySpeechID.Id14412902] =
{
	Id = 14412902,
	CharName = "受害者",
	Text = "我怎么会在这儿？啊，这里不是琳达被害的那间医院吗？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_07_daomeidan",
	NextID = 14412903,
}
StorySpeechConfig[StorySpeechID.Id14412903] =
{
	Id = 14412903,
	CharName = "黑法医",
	Text = "（走廊响起皮鞋脚步声，推门而入）你醒了？刚刚你在回家路上被袭击了，我发现了所以就带你回医院。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_04_fayi_cos10",
	NextID = 14412904,
}
StorySpeechConfig[StorySpeechID.Id14412904] =
{
	Id = 14412904,
	CharName = "受害者",
	Text = "多谢医生，不过我要尽快离开了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_07_daomeidan",
	NextID = 14412905,
}
StorySpeechConfig[StorySpeechID.Id14412905] =
{
	Id = 14412905,
	CharName = "黑法医",
	Text = "你还不能走，我得给你输液。你稍等一会儿，药马上就配好了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_04_fayi_cos10",
	NextID = 14412906,
}
StorySpeechConfig[StorySpeechID.Id14412906] =
{
	Id = 14412906,
	CharName = "受害者",
	Text = "好的，医生，多谢你。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_07_daomeidan",
	NextID = 14412907,
}
StorySpeechConfig[StorySpeechID.Id14412907] =
{
	Id = 14412907,
	CharName = "护士",
	Text = "医生，药水配好了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_07_mushi_cos20",
	NextID = 14412908,
}
StorySpeechConfig[StorySpeechID.Id14412908] =
{
	Id = 14412908,
	CharName = "黑法医",
	Text = "嗯，就放在那里，你出去吧。来，输了液，你会感觉舒服点。嘿嘿嘿嘿。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_04_fayi_cos10",
	NextID = 14412909,
}
StorySpeechConfig[StorySpeechID.Id14412909] =
{
	Id = 14412909,
	CharName = "受害者",
	Text = "医生，你的手上怎么有这个伤痕，莫非，你，你，你就是……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_07_daomeidan",
	NextID = 14412910,
}
StorySpeechConfig[StorySpeechID.Id14412910] =
{
	Id = 14412910,
	CharName = "黑法医",
	Text = "嘿嘿嘿嘿，怎么，想去报警，你的朋友琳达还在太平间等你呢？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_04_fayi_cos10",
	NextID = 14412911,
}
StorySpeechConfig[StorySpeechID.Id14412911] =
{
	Id = 14412911,
	CharName = "受害者",
	Text = "啊——！我要为我的好朋友报仇！！！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_07_daomeidan",
	NextID = 14412912,
}
StorySpeechConfig[StorySpeechID.Id14412912] =
{
	Id = 14412912,
	CharName = "黑法医",
	Text = "场务，场务！怎么回事？没有这一段啊！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_04_fayi_cos10",
}
StorySpeechConfig[StorySpeechID.Id14413001] =
{
	Id = 14413001,
	CharName = "律师",
	Text = "学姐，学姐，今天你在庭上表现得太好了！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_13_lvshi",
	NextID = 14413002,
}
StorySpeechConfig[StorySpeechID.Id14413002] =
{
	Id = 14413002,
	CharName = "律政女王",
	Text = "只要你心怀正义，做到这样对你而言并不难。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_13_lvshi_cos10",
	NextID = 14413003,
}
StorySpeechConfig[StorySpeechID.Id14413003] =
{
	Id = 14413003,
	CharName = "律师",
	Text = "我会继续努力的！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_13_lvshi",
	NextID = 14413004,
}
StorySpeechConfig[StorySpeechID.Id14413004] =
{
	Id = 14413004,
	CharName = "恶霸",
	Text = "喂！臭女人，你今天把我大哥送进监狱，回去路上你给我小心点！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_28_heiyiren",
	NextID = 14413005,
}
StorySpeechConfig[StorySpeechID.Id14413005] =
{
	Id = 14413005,
	CharName = "律政女王",
	Text = "你的话已经构成恐吓，先生，我随时可以报警逮捕你。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_13_lvshi_cos10",
	NextID = 14413006,
}
StorySpeechConfig[StorySpeechID.Id14413006] =
{
	Id = 14413006,
	CharName = "恶霸",
	Text = "（推了学姐一把）臭女人，到时候你就知道我怕不怕你！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_28_heiyiren",
	NextID = 14413007,
}
StorySpeechConfig[StorySpeechID.Id14413007] =
{
	Id = 14413007,
	CharName = "律政女王",
	Text = "喂！你怎么可以动手！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_13_lvshi_cos10",
	NextID = 14413008,
}
StorySpeechConfig[StorySpeechID.Id14413008] =
{
	Id = 14413008,
	CharName = "恶霸",
	Text = "噢？旁听席上那个小四眼，怎么，你想吃拳头？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_28_heiyiren",
	NextID = 14413009,
}
StorySpeechConfig[StorySpeechID.Id14413009] =
{
	Id = 14413009,
	CharName = "律师",
	Text = "我不会怕你的！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_13_lvshi",
	NextID = 14413010,
}
StorySpeechConfig[StorySpeechID.Id14413010] =
{
	Id = 14413010,
	CharName = "律政女王",
	Text = "你先走，学弟，这些恶人什么事都做得出来。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_13_lvshi_cos10",
	NextID = 14413011,
}
StorySpeechConfig[StorySpeechID.Id14413011] =
{
	Id = 14413011,
	CharName = "律师",
	Text = "我不走，我会保护你的，学姐！法律不会放过这种恶霸的！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_13_lvshi",
	NextID = 14413012,
}
StorySpeechConfig[StorySpeechID.Id14413012] =
{
	Id = 14413012,
	CharName = "恶霸",
	Text = "啰嗦什么，看我先把你打得像猪头一样！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_28_heiyiren",
}
StorySpeechConfig[StorySpeechID.Id14413501] =
{
	Id = 14413501,
	CharName = "宅女侦探",
	Text = "试剂果然在这里，法医！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_15_fangdongtaitai_cos10",
	NextID = 14413502,
}
StorySpeechConfig[StorySpeechID.Id14413502] =
{
	Id = 14413502,
	CharName = "法医",
	Text = "呱！怎么会这样呱？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_04_fayi",
	NextID = 14413503,
}
StorySpeechConfig[StorySpeechID.Id14413503] =
{
	Id = 14413503,
	CharName = "宅女侦探",
	Text = "看来就是这些黑法医偷走了试剂。我们必须尽快通知豆豆警官！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_15_fangdongtaitai_cos10",
	NextID = 14413504,
}
StorySpeechConfig[StorySpeechID.Id14413504] =
{
	Id = 14413504,
	CharName = "法医",
	Text = "呱？怎么出去呱？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_04_fayi",
	NextID = 14413505,
}
StorySpeechConfig[StorySpeechID.Id14413505] =
{
	Id = 14413505,
	CharName = "宅女侦探",
	Text = "这里所有的出口都被他们看住了，要出去的话，我们必须蒙混过去。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_15_fangdongtaitai_cos10",
	NextID = 14413506,
}
StorySpeechConfig[StorySpeechID.Id14413506] =
{
	Id = 14413506,
	CharName = "法医",
	Text = "呱……听起来很危险……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_04_fayi",
	NextID = 14413507,
}
StorySpeechConfig[StorySpeechID.Id14413507] =
{
	Id = 14413507,
	CharName = "宅女侦探",
	Text = "他们都戴着特制面具，穿着特制服装，假扮成他们，没人会知道的~",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_15_fangdongtaitai_cos10",
	NextID = 14413508,
}
StorySpeechConfig[StorySpeechID.Id14413508] =
{
	Id = 14413508,
	CharName = "法医",
	Text = "呱……那试试看呱。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_04_fayi",
	NextID = 14413509,
}
StorySpeechConfig[StorySpeechID.Id14413509] =
{
	Id = 14413509,
	CharName = "宅女侦探",
	Text = "小心，我听到脚步声，应该只有一个人，我们打晕他，然后你换上他的服装。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_15_fangdongtaitai_cos10",
	NextID = 14413510,
}
StorySpeechConfig[StorySpeechID.Id14413510] =
{
	Id = 14413510,
	CharName = "法医",
	Text = "呱……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_04_fayi",
	NextID = 14413511,
}
StorySpeechConfig[StorySpeechID.Id14413511] =
{
	Id = 14413511,
	CharName = "宅女侦探",
	Text = "不要怕~（亲了法医一口）",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_15_fangdongtaitai_cos10",
	NextID = 14413512,
}
StorySpeechConfig[StorySpeechID.Id14413512] =
{
	Id = 14413512,
	CharName = "法医",
	Text = "呱！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_04_fayi",
}
StorySpeechConfig[StorySpeechID.Id14412301] =
{
	Id = 14412301,
	CharName = "凶手",
	Text = "医生，我觉得我还是没有自信，你还是给我一件带兜帽的衣服吧。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_28_heiyiren",
	NextID = 14412302,
}
StorySpeechConfig[StorySpeechID.Id14412302] =
{
	Id = 14412302,
	CharName = "法医",
	Text = "剧组还是说你的表情不够有杀伤力？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_04_fayi",
	NextID = 14412303,
}
StorySpeechConfig[StorySpeechID.Id14412303] =
{
	Id = 14412303,
	CharName = "凶手",
	Text = "我按照你教的表情做了，导演和场务当时都笑出声了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_28_heiyiren",
	NextID = 14412304,
}
StorySpeechConfig[StorySpeechID.Id14412304] =
{
	Id = 14412304,
	CharName = "法医",
	Text = "这么不严肃？我觉得你看起来已经非常有杀伤力了呀，再配合我教的表情应该可以完美诠释什么叫吓人了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_04_fayi",
	NextID = 14412305,
}
StorySpeechConfig[StorySpeechID.Id14412305] =
{
	Id = 14412305,
	CharName = "凶手",
	Text = "要不然这样，医生，你把我的咨询费退还一半给我吧？我两个月没有工作钱都用完了，今天早饭都没吃。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_28_heiyiren",
	NextID = 14412306,
}
StorySpeechConfig[StorySpeechID.Id14412306] =
{
	Id = 14412306,
	CharName = "法医",
	Text = "不要这么说嘛~要不然你试试这个恶语相向套餐，我再教你说些狠话，这次只收500。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_04_fayi",
	NextID = 14412307,
}
StorySpeechConfig[StorySpeechID.Id14412307] =
{
	Id = 14412307,
	CharName = "凶手",
	Text = "你别搞我了，医生。我真的一点钱都没有了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_28_heiyiren",
	NextID = 14412308,
}
StorySpeechConfig[StorySpeechID.Id14412308] =
{
	Id = 14412308,
	CharName = "法医",
	Text = "那这样，试试这个面露凶色套餐，只要200。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_04_fayi",
	NextID = 14412309,
}
StorySpeechConfig[StorySpeechID.Id14412309] =
{
	Id = 14412309,
	CharName = "凶手",
	Text = "医生，我都戴着头套，根本不露脸……其实，我觉得你借我件带兜帽的衣服就好。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_28_heiyiren",
	NextID = 14412310,
}
StorySpeechConfig[StorySpeechID.Id14412310] =
{
	Id = 14412310,
	CharName = "法医",
	Text = "不要那么肤浅嘛~带个兜帽又能怎么样呢？难道别人看不见你的表情就会怕你吗？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_04_fayi",
	NextID = 14412311,
}
StorySpeechConfig[StorySpeechID.Id14412311] =
{
	Id = 14412311,
	CharName = "戴兜帽的凶手",
	Text = "（带起医生的兜帽）别人看不到我表情，心里自然而然就会觉得我很神秘很可怕了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_28_heiyiren_cos10",
	NextID = 14412312,
}
StorySpeechConfig[StorySpeechID.Id14412312] =
{
	Id = 14412312,
	CharName = "法医",
	Text = "妈呀！大白天你扮成这样是要吓死人啊！！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_04_fayi",
	NextID = 14412313,
}
StorySpeechConfig[StorySpeechID.Id14412313] =
{
	Id = 14412313,
	CharName = "凶手",
	Text = "所以嘛，你就把这件道具借给我吧~~",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_28_heiyiren",
	NextID = 14412314,
}
StorySpeechConfig[StorySpeechID.Id14412314] =
{
	Id = 14412314,
	CharName = "法医",
	Text = "那，那也可以，不过还要另外收3000。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_04_fayi",
	NextID = 14412315,
}
StorySpeechConfig[StorySpeechID.Id14412315] =
{
	Id = 14412315,
	CharName = "凶手",
	Text = "可是我真的没钱了……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_28_heiyiren",
	NextID = 14412316,
}
StorySpeechConfig[StorySpeechID.Id14412316] =
{
	Id = 14412316,
	CharName = "法医",
	Text = "看来你还真是一分钱都没了，那你就快走！别耽误我做生意！走走走！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_04_fayi",
	NextID = 14412317,
}
StorySpeechConfig[StorySpeechID.Id14412317] =
{
	Id = 14412317,
	CharName = "凶手",
	Text = "……今天这件衣服我就算抢也要拿到手！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_28_heiyiren",
}
StorySpeechConfig[StorySpeechID.Id14411801] =
{
	Id = 14411801,
	CharName = "天气预报",
	Text = "驯鹿拉着马车，带来了美丽的圣诞，不过今年的圣诞天气可不太好噢~据本台预测，全球有中等规模降雪，局部地区大雪。",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	LeftIcon = "Equipment_Rpg_11_damowang_3",
	NextID = 14411802,
}
StorySpeechConfig[StorySpeechID.Id14411802] =
{
	Id = 14411802,
	CharName = "报童",
	Text = "（加了一件棉袄）哇，送完报纸就可以打雪仗了~",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_17_baotong",
	NextID = 14411803,
}
StorySpeechConfig[StorySpeechID.Id14411803] =
{
	Id = 14411803,
	CharName = "报纸",
	Text = "（点头）",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	LeftIcon = "SUS_Newspaper",
	NextID = 14411804,
}
StorySpeechConfig[StorySpeechID.Id14411804] =
{
	Id = 14411804,
	CharName = "天气预报",
	Text = "现在临时插播一条消息，因博士的全球制冷系统多日错误运转，中雪目前已转为大雪，局部地区大暴雪，气温降幅达18℃。",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	RightIcon = "Equipment_Rpg_11_damowang_3",
	NextID = 14411805,
}
StorySpeechConfig[StorySpeechID.Id14411805] =
{
	Id = 14411805,
	CharName = "报童",
	Text = "（又加了一件棉袄）唔……看来天气真的不太好。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_17_baotong",
	NextID = 14411806,
}
StorySpeechConfig[StorySpeechID.Id14411806] =
{
	Id = 14411806,
	CharName = "报纸",
	Text = "我也要加衣服……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	RightIcon = "SUS_Newspaper",
	NextID = 14411807,
}
StorySpeechConfig[StorySpeechID.Id14411807] =
{
	Id = 14411807,
	CharName = "报童",
	Text = "那今天换个厚点的书包吧~",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_17_baotong",
	NextID = 14411808,
}
StorySpeechConfig[StorySpeechID.Id14411808] =
{
	Id = 14411808,
	CharName = "天气预报",
	Text = "紧急通知！目前已找到系统故障原因，因博士输入过程中参数输入错误，因此本次降温达180℃，政府通知大家千万不要出门！千万不要出门！",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	RightIcon = "Equipment_Rpg_11_damowang_3",
	NextID = 14411809,
}
StorySpeechConfig[StorySpeechID.Id14411809] =
{
	Id = 14411809,
	CharName = "报童",
	Text = "（又加了一件棉袄）报纸，要准备送你出门啦~诶？报纸？报纸？哇，别跑！！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_17_baotong",
}
StorySpeechConfig[StorySpeechID.Id14412401] =
{
	Id = 14412401,
	CharName = "小泪",
	Text = "小瞳，小爱，这次的目标是正在度假的大作家。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_25_xiaolei",
	NextID = 14412402,
}
StorySpeechConfig[StorySpeechID.Id14412402] =
{
	Id = 14412402,
	CharName = "小瞳",
	Text = "目标区段的黄金沙滩是由M先生的财团购买的，只接受沙滩俱乐部VIP会员进入。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_26_xiaotong",
	NextID = 14412403,
}
StorySpeechConfig[StorySpeechID.Id14412403] =
{
	Id = 14412403,
	CharName = "小爱",
	Text = "VIP卡的事情就交给我吧~~我已经伪造了三张了噢~~",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_27_xiaoai",
	NextID = 14412404,
}
StorySpeechConfig[StorySpeechID.Id14412404] =
{
	Id = 14412404,
	CharName = "小泪",
	Text = "那目前最关键的就是如何接近目标了。根据情报显示，对方对于泳装少女的抵抗力是F-级，即完全没有抵抗力。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_25_xiaolei",
	NextID = 14412405,
}
StorySpeechConfig[StorySpeechID.Id14412405] =
{
	Id = 14412405,
	CharName = "小爱",
	Text = "哇~太好了，上次旅游时买的泳装用得上了~",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_27_xiaoai",
	NextID = 14412406,
}
StorySpeechConfig[StorySpeechID.Id14412406] =
{
	Id = 14412406,
	CharName = "小瞳",
	Text = "不过……衣服放在行李车里，还没有拿出来……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_26_xiaotong",
	NextID = 14412407,
}
StorySpeechConfig[StorySpeechID.Id14412407] =
{
	Id = 14412407,
	CharName = "小泪",
	Text = "诶……是那个家伙吗？那只能再好好修理它一下了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_25_xiaolei",
}
StorySpeechConfig[StorySpeechID.Id14412501] =
{
	Id = 14412501,
	CharName = "小泪",
	Text = "小瞳，小爱，这次的目标是正在度假的大作家。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_25_xiaolei",
	NextID = 14412502,
}
StorySpeechConfig[StorySpeechID.Id14412502] =
{
	Id = 14412502,
	CharName = "小瞳",
	Text = "目标区段的黄金沙滩是由M先生的财团购买的，只接受沙滩俱乐部VIP会员进入。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_26_xiaotong",
	NextID = 14412503,
}
StorySpeechConfig[StorySpeechID.Id14412503] =
{
	Id = 14412503,
	CharName = "小爱",
	Text = "VIP卡的事情就交给我吧~~我已经伪造了三张了噢~~",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_27_xiaoai",
	NextID = 14412504,
}
StorySpeechConfig[StorySpeechID.Id14412504] =
{
	Id = 14412504,
	CharName = "小泪",
	Text = "那目前最关键的就是如何接近目标了。根据情报显示，对方对于泳装少女的抵抗力是F-级，即完全没有抵抗力。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_25_xiaolei",
	NextID = 14412505,
}
StorySpeechConfig[StorySpeechID.Id14412505] =
{
	Id = 14412505,
	CharName = "小爱",
	Text = "哇~太好了，上次旅游时买的泳装用得上了~",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_27_xiaoai",
	NextID = 14412506,
}
StorySpeechConfig[StorySpeechID.Id14412506] =
{
	Id = 14412506,
	CharName = "小瞳",
	Text = "不过……衣服放在行李车里，还没有拿出来……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_26_xiaotong",
	NextID = 14412507,
}
StorySpeechConfig[StorySpeechID.Id14412507] =
{
	Id = 14412507,
	CharName = "小泪",
	Text = "诶……是那个家伙吗？那只能再好好修理它一下了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_25_xiaolei",
}
StorySpeechConfig[StorySpeechID.Id14412601] =
{
	Id = 14412601,
	CharName = "小泪",
	Text = "小瞳，小爱，这次的目标是正在度假的大作家。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_25_xiaolei",
	NextID = 14412602,
}
StorySpeechConfig[StorySpeechID.Id14412602] =
{
	Id = 14412602,
	CharName = "小瞳",
	Text = "目标区段的黄金沙滩是由M先生的财团购买的，只接受沙滩俱乐部VIP会员进入。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_26_xiaotong",
	NextID = 14412603,
}
StorySpeechConfig[StorySpeechID.Id14412603] =
{
	Id = 14412603,
	CharName = "小爱",
	Text = "VIP卡的事情就交给我吧~~我已经伪造了三张了噢~~",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_27_xiaoai",
	NextID = 14412604,
}
StorySpeechConfig[StorySpeechID.Id14412604] =
{
	Id = 14412604,
	CharName = "小泪",
	Text = "那目前最关键的就是如何接近目标了。根据情报显示，对方对于泳装少女的抵抗力是F-级，即完全没有抵抗力。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_25_xiaolei",
	NextID = 14412605,
}
StorySpeechConfig[StorySpeechID.Id14412605] =
{
	Id = 14412605,
	CharName = "小爱",
	Text = "哇~太好了，上次旅游时买的泳装用得上了~",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_27_xiaoai",
	NextID = 14412606,
}
StorySpeechConfig[StorySpeechID.Id14412606] =
{
	Id = 14412606,
	CharName = "小瞳",
	Text = "不过……衣服放在行李车里，还没有拿出来……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_26_xiaotong",
	NextID = 14412607,
}
StorySpeechConfig[StorySpeechID.Id14412607] =
{
	Id = 14412607,
	CharName = "小泪",
	Text = "诶……是那个家伙吗？那只能再好好修理它一下了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_25_xiaolei",
}
StorySpeechConfig[StorySpeechID.Id14412801] =
{
	Id = 14412801,
	CharName = "读者",
	Text = "（敲门）",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_21_duzhe",
	NextID = 14412802,
}
StorySpeechConfig[StorySpeechID.Id14412802] =
{
	Id = 14412802,
	CharName = "编辑长",
	Text = "（开门）诶！怎么又是你！这次是什么问题？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_22_bianji",
	NextID = 14412803,
}
StorySpeechConfig[StorySpeechID.Id14412803] =
{
	Id = 14412803,
	CharName = "读者",
	Text = "编辑长，请让我加入出版社吧，我会好好努力的，这是我的作品，请读一下。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_21_duzhe",
	NextID = 14412804,
}
StorySpeechConfig[StorySpeechID.Id14412804] =
{
	Id = 14412804,
	CharName = "编辑长",
	Text = "不行，你的笔力还不够！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_22_bianji",
	NextID = 14412805,
}
StorySpeechConfig[StorySpeechID.Id14412805] =
{
	Id = 14412805,
	CharName = "读者",
	Text = "……你去年就是这么说的，今年我的文笔已经更精进了，你读一下嘛~",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_21_duzhe",
	NextID = 14412806,
}
StorySpeechConfig[StorySpeechID.Id14412806] =
{
	Id = 14412806,
	CharName = "编辑长",
	Text = "……读者，其实说实话，你不适合做编辑。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_22_bianji",
	NextID = 14412807,
}
StorySpeechConfig[StorySpeechID.Id14412807] =
{
	Id = 14412807,
	CharName = "读者",
	Text = "（眼泪打转中）为什么？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_21_duzhe",
	NextID = 14412808,
}
StorySpeechConfig[StorySpeechID.Id14412808] =
{
	Id = 14412808,
	CharName = "编辑长",
	Text = "你没有编辑的嗅觉，你的小说，凶手就是死者的女朋友，对不对？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_22_bianji",
	NextID = 14412809,
}
StorySpeechConfig[StorySpeechID.Id14412809] =
{
	Id = 14412809,
	CharName = "读者",
	Text = "……你怎么知道的？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_21_duzhe",
	NextID = 14412810,
}
StorySpeechConfig[StorySpeechID.Id14412810] =
{
	Id = 14412810,
	CharName = "编辑长",
	Text = "而且凶手是来为她妹妹报仇的。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_22_bianji",
	NextID = 14412811,
}
StorySpeechConfig[StorySpeechID.Id14412811] =
{
	Id = 14412811,
	CharName = "读者",
	Text = "……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_21_duzhe",
	NextID = 14412812,
}
StorySpeechConfig[StorySpeechID.Id14412812] =
{
	Id = 14412812,
	CharName = "编辑长",
	Text = "凶手出门用钥匙反锁门，然后用绳子把钥匙引回了死者口袋。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_22_bianji",
	NextID = 14412813,
}
StorySpeechConfig[StorySpeechID.Id14412813] =
{
	Id = 14412813,
	CharName = "读者",
	Text = "……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_21_duzhe",
	NextID = 14412814,
}
StorySpeechConfig[StorySpeechID.Id14412814] =
{
	Id = 14412814,
	CharName = "编辑长",
	Text = "剧情陈旧，又长达50万字……不过，有个工作倒是很适合你。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_22_bianji",
	NextID = 14412815,
}
StorySpeechConfig[StorySpeechID.Id14412815] =
{
	Id = 14412815,
	CharName = "读者",
	Text = "（黯淡的双眼又明亮起来）噢！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_21_duzhe",
	NextID = 14412816,
}
StorySpeechConfig[StorySpeechID.Id14412816] =
{
	Id = 14412816,
	CharName = "编辑长",
	Text = "每一期你都能帮我们纠正很多错误，如果你懂外星文字的话，你的认真对于翻译会很有帮助。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_22_bianji",
	NextID = 14412817,
}
StorySpeechConfig[StorySpeechID.Id14412817] =
{
	Id = 14412817,
	CharName = "读者",
	Text = "哇~我可以当翻译啦~~",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_21_duzhe",
	NextID = 14412818,
}
StorySpeechConfig[StorySpeechID.Id14412818] =
{
	Id = 14412818,
	CharName = "编辑长",
	Text = "那你一定要先搞定这本书看看。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_22_bianji",
}
StorySpeechConfig[StorySpeechID.Id14412001] =
{
	Id = 14412001,
	CharName = "导演",
	Text = "卡！完全没有张力！一点冲突都没有！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "SEA_Octupas1",
	NextID = 14412002,
}
StorySpeechConfig[StorySpeechID.Id14412002] =
{
	Id = 14412002,
	CharName = "凶手",
	Text = "……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_28_heiyiren",
	NextID = 14412003,
}
StorySpeechConfig[StorySpeechID.Id14412003] =
{
	Id = 14412003,
	CharName = "死者",
	Text = "……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_12_sizhe",
	NextID = 14412004,
}
StorySpeechConfig[StorySpeechID.Id14412004] =
{
	Id = 14412004,
	CharName = "场务",
	Text = "要不要试试看，真的把绳环套到脖子上，导演？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_23_tiaojiushi_cos10",
	NextID = 14412005,
}
StorySpeechConfig[StorySpeechID.Id14412005] =
{
	Id = 14412005,
	CharName = "导演",
	Text = "这个好！好，等等凶手把绳环直接套到对方脖子上，然后用力拉紧，记住，我不喊停，就不要松手。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "SEA_Octupas1",
	NextID = 14412006,
}
StorySpeechConfig[StorySpeechID.Id14412006] =
{
	Id = 14412006,
	CharName = "凶手",
	Text = "明白了，导演。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_28_heiyiren",
	NextID = 14412007,
}
StorySpeechConfig[StorySpeechID.Id14412007] =
{
	Id = 14412007,
	CharName = "死者",
	Text = "不！这太危险了吧！！虽然我受过专门的训练，拿到过6级死者证书，但是这种项目我们学校里都是禁止的！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_12_sizhe",
	NextID = 14412008,
}
StorySpeechConfig[StorySpeechID.Id14412008] =
{
	Id = 14412008,
	CharName = "导演",
	Text = "为了艺术，你要有奉献精神嘛~~来来，就一下子，争取一把过，好吗~~",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "SEA_Octupas1",
	NextID = 14412009,
}
StorySpeechConfig[StorySpeechID.Id14412009] =
{
	Id = 14412009,
	CharName = "死者",
	Text = "不！实在太危险了，这种事情加5个鸡腿也不行的！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_12_sizhe",
	NextID = 14412010,
}
StorySpeechConfig[StorySpeechID.Id14412010] =
{
	Id = 14412010,
	CharName = "场务",
	Text = "导演，这个场子下午3点要还给隔壁《谁吊死了我的丈夫》剧组了，他们催我们快一点。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_23_tiaojiushi_cos10",
	NextID = 14412011,
}
StorySpeechConfig[StorySpeechID.Id14412011] =
{
	Id = 14412011,
	CharName = "导演",
	Text = "哇，那不管了，来人，搞定这个演员，我们争取一把过！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "SEA_Octupas1",
}
StorySpeechConfig[StorySpeechID.Id14412101] =
{
	Id = 14412101,
	CharName = "导演",
	Text = "卡！窒息感呢？能为片子注入灵魂的窒息感呢？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "SEA_Octupas1",
	NextID = 14412102,
}
StorySpeechConfig[StorySpeechID.Id14412102] =
{
	Id = 14412102,
	CharName = "凶手",
	Text = "……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_28_heiyiren",
	NextID = 14412103,
}
StorySpeechConfig[StorySpeechID.Id14412103] =
{
	Id = 14412103,
	CharName = "死者",
	Text = "……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_12_sizhe",
	NextID = 14412104,
}
StorySpeechConfig[StorySpeechID.Id14412104] =
{
	Id = 14412104,
	CharName = "场务",
	Text = "导演，我认为用错位镜头和假道具已经无法满足现在的观众了？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_23_tiaojiushi_cos10",
	NextID = 14412105,
}
StorySpeechConfig[StorySpeechID.Id14412105] =
{
	Id = 14412105,
	CharName = "导演",
	Text = "那怎么办？用真鱼缸套在他头上吗？诶！感觉可行，哇，光是想一想，那种窒息感就要从镜头里爆出来了！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "SEA_Octupas1",
	NextID = 14412106,
}
StorySpeechConfig[StorySpeechID.Id14412106] =
{
	Id = 14412106,
	CharName = "凶手",
	Text = "这个主意好，导演！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_28_heiyiren",
	NextID = 14412107,
}
StorySpeechConfig[StorySpeechID.Id14412107] =
{
	Id = 14412107,
	CharName = "死者",
	Text = "不！这太危险了吧！！虽然我受过专门的训练，拿到过6级死者证书，但是这种项目我们学校里都是禁止的！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_12_sizhe",
	NextID = 14412108,
}
StorySpeechConfig[StorySpeechID.Id14412108] =
{
	Id = 14412108,
	CharName = "导演",
	Text = "为了艺术，你要有奉献精神嘛~~来来，就一下子，争取一把过，好吗~~",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "SEA_Octupas1",
	NextID = 14412109,
}
StorySpeechConfig[StorySpeechID.Id14412109] =
{
	Id = 14412109,
	CharName = "死者",
	Text = "不！实在太危险了，这种事情加5个鸡腿也不行的！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_12_sizhe",
	NextID = 14412110,
}
StorySpeechConfig[StorySpeechID.Id14412110] =
{
	Id = 14412110,
	CharName = "场务",
	Text = "导演，这个场子下午3点要还给隔壁《谁淹死了我的妻子》剧组了，他们催我们快一点。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_23_tiaojiushi_cos10",
	NextID = 14412111,
}
StorySpeechConfig[StorySpeechID.Id14412111] =
{
	Id = 14412111,
	CharName = "导演",
	Text = "哇，那不管了，来人，搞定这个演员，我们争取一把过！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "SEA_Octupas1",
}
StorySpeechConfig[StorySpeechID.Id14413101] =
{
	Id = 14413101,
	CharName = "房东太太",
	Text = "哇，今天大家交租都好准时，真开心~~（♪~♪♪~~）",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_15_fangdongtaitai",
	NextID = 14413102,
}
StorySpeechConfig[StorySpeechID.Id14413102] =
{
	Id = 14413102,
	CharName = "黑衣人",
	Text = "嘿嘿嘿嘿，太太，你终于回来了，我等你好久了~",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_28_heiyiren",
	NextID = 14413103,
}
StorySpeechConfig[StorySpeechID.Id14413103] =
{
	Id = 14413103,
	CharName = "房东太太",
	Text = "哇，你是谁！怎么在我家？快给我出去，我要报警啦！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_15_fangdongtaitai",
	NextID = 14413104,
}
StorySpeechConfig[StorySpeechID.Id14413104] =
{
	Id = 14413104,
	CharName = "黑衣人",
	Text = "报警？嘿嘿嘿嘿~~~当初就是你把我们大哥送进监狱的吧，太太？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_28_heiyiren",
	NextID = 14413105,
}
StorySpeechConfig[StorySpeechID.Id14413105] =
{
	Id = 14413105,
	CharName = "房东太太",
	Text = "诶？我不知道你在说什么，我一个主妇怎么会和你们大哥有关系呢？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_15_fangdongtaitai",
	NextID = 14413106,
}
StorySpeechConfig[StorySpeechID.Id14413106] =
{
	Id = 14413106,
	CharName = "黑衣人",
	Text = "嘿嘿嘿嘿，你出去收租的时候，我在你家找到了这个！（房东太太年轻时做侦探的衣服）",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_28_heiyiren",
	NextID = 14413107,
}
StorySpeechConfig[StorySpeechID.Id14413107] =
{
	Id = 14413107,
	CharName = "房东太太",
	Text = "这件衣服我没见过，不是我的，也不知道是谁的！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_15_fangdongtaitai",
	NextID = 14413108,
}
StorySpeechConfig[StorySpeechID.Id14413108] =
{
	Id = 14413108,
	CharName = "黑衣人",
	Text = "嘿嘿嘿嘿，太太，你就不要否认啦~我还看过你以前的相簿了，以前的你真是，嘿嘿嘿嘿。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_28_heiyiren",
	NextID = 14413109,
}
StorySpeechConfig[StorySpeechID.Id14413109] =
{
	Id = 14413109,
	CharName = "房东太太",
	Text = "……你究竟想怎么样？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_15_fangdongtaitai",
	NextID = 14413110,
}
StorySpeechConfig[StorySpeechID.Id14413110] =
{
	Id = 14413110,
	CharName = "黑衣人",
	Text = "怎样？我要为我的大哥报仇！当年他被你抓住，判了十年，现在出来像变了个人一样！他变了，竟然在报纸上找工作！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_28_heiyiren",
	NextID = 14413111,
}
StorySpeechConfig[StorySpeechID.Id14413111] =
{
	Id = 14413111,
	CharName = "房东太太",
	Text = "那不是很好吗？看来他在监狱里真的改过了呢~",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_15_fangdongtaitai",
	NextID = 14413112,
}
StorySpeechConfig[StorySpeechID.Id14413112] =
{
	Id = 14413112,
	CharName = "黑衣人",
	Text = "不！不！他说过要带我做贼王的！现在，现在他做了便利店的小工，我怎么办！所以……我要干掉你，干掉你他就会醒悟过来，好人是没有好下场的！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_28_heiyiren",
	NextID = 14413113,
}
StorySpeechConfig[StorySpeechID.Id14413113] =
{
	Id = 14413113,
	CharName = "房东太太",
	Text = "看来你已经无药可救了！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_15_fangdongtaitai",
	NextID = 14413114,
}
StorySpeechConfig[StorySpeechID.Id14413114] =
{
	Id = 14413114,
	CharName = "黑衣人",
	Text = "嘿嘿嘿嘿~~听说你没有这套侦探服，就只是一个主妇呢~~哈哈哈哈，受死吧！！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_28_heiyiren",
}
StorySpeechConfig[StorySpeechID.Id14413201] =
{
	Id = 14413201,
	CharName = "导演",
	Text = "那么接下来，是酒保的面试吧？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "SEA_Octupas1",
	NextID = 14413202,
}
StorySpeechConfig[StorySpeechID.Id14413202] =
{
	Id = 14413202,
	CharName = "场务",
	Text = "啊，是的，导演，对方是来自侦探街的超高人气角色，听说星博有1000万人关注。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_23_tiaojiushi_cos10",
	NextID = 14413203,
}
StorySpeechConfig[StorySpeechID.Id14413203] =
{
	Id = 14413203,
	CharName = "导演",
	Text = "噢？如果是这样的话，倒可以大幅增加我们的曝光率，进行交叉推广。那他的角色？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "SEA_Octupas1",
	NextID = 14413204,
}
StorySpeechConfig[StorySpeechID.Id14413204] =
{
	Id = 14413204,
	CharName = "场务",
	Text = "是不夜城酒吧的酒保，秘密身份是情报交易员，有很多动作戏。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_23_tiaojiushi_cos10",
	NextID = 14413205,
}
StorySpeechConfig[StorySpeechID.Id14413205] =
{
	Id = 14413205,
	CharName = "调酒师",
	Text = "导演好，我是来面试酒保角色的。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_23_tiaojiushi",
	NextID = 14413206,
}
StorySpeechConfig[StorySpeechID.Id14413206] =
{
	Id = 14413206,
	CharName = "导演",
	Text = "听说你本人就是调酒师~估计调酒部分不用再测试了，不过你这个角色动作戏很多，你有把握吗？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "SEA_Octupas1",
	NextID = 14413207,
}
StorySpeechConfig[StorySpeechID.Id14413207] =
{
	Id = 14413207,
	CharName = "调酒师",
	Text = "我是前年格斗大赛的季军，导演。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_23_tiaojiushi",
	NextID = 14413208,
}
StorySpeechConfig[StorySpeechID.Id14413208] =
{
	Id = 14413208,
	CharName = "导演",
	Text = "不错不错，那请和我们的凶手扮演人员战斗一下试试看，请尽量摆出帅气的Pose，搞定了明天就带着铺盖来剧组吧。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "SEA_Octupas1",
	NextID = 14413209,
}
StorySpeechConfig[StorySpeechID.Id14413209] =
{
	Id = 14413209,
	CharName = "调酒师",
	Text = "多谢导演，我一定会把握机会的。诶！对手看来身手也很不错。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_23_tiaojiushi",
}
StorySpeechConfig[StorySpeechID.Id14412701] =
{
	Id = 14412701,
	CharName = "信件",
	Text = "亲爱的编辑长，看到这封信时，如你所想，我已决定延长稿期。最近实在没有灵感，请不要催促我。PS，你的飞行设备我已拿走~",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	LeftIcon = "Equipment_MUS_21_mengnalisha_3",
	NextID = 14412702,
}
StorySpeechConfig[StorySpeechID.Id14412702] =
{
	Id = 14412702,
	CharName = "编辑长",
	Text = "……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_22_bianji",
	NextID = 14412703,
}
StorySpeechConfig[StorySpeechID.Id14412703] =
{
	Id = 14412703,
	CharName = "翻译组",
	Text = "怎么办，主编？印刷厂那边已经在催促了，报童们都已经等在邮局等着领报纸去兜售了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_21_duzhe_cos10",
	NextID = 14412704,
}
StorySpeechConfig[StorySpeechID.Id14412704] =
{
	Id = 14412704,
	CharName = "编辑长",
	Text = "……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_22_bianji",
	NextID = 14412705,
}
StorySpeechConfig[StorySpeechID.Id14412705] =
{
	Id = 14412705,
	CharName = "翻译组",
	Text = "究竟怎么办啊？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_21_duzhe_cos10",
	NextID = 14412706,
}
StorySpeechConfig[StorySpeechID.Id14412706] =
{
	Id = 14412706,
	CharName = "编辑长",
	Text = "看来是时候用这个了……（掏出电话本，拨通博士的电话）",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_22_bianji",
	NextID = 14412707,
}
StorySpeechConfig[StorySpeechID.Id14412707] =
{
	Id = 14412707,
	CharName = "博士",
	Text = "编辑长，你今天来找我，是想让我用那个吧？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_24_boshi",
	NextID = 14412708,
}
StorySpeechConfig[StorySpeechID.Id14412708] =
{
	Id = 14412708,
	CharName = "编辑长",
	Text = "是的，这次遇到了非常棘手的问题，如果没有你的帮助，恐怕今天就无法正常出版了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_22_bianji",
	NextID = 14412709,
}
StorySpeechConfig[StorySpeechID.Id14412709] =
{
	Id = 14412709,
	CharName = "博士",
	Text = "使用这个传送装置非常危险，另外费用你也是知道的。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_24_boshi",
	NextID = 14412710,
}
StorySpeechConfig[StorySpeechID.Id14412710] =
{
	Id = 14412710,
	CharName = "编辑长",
	Text = "我已经做好一切准备，请将我立刻传送到我的飞行装备旁边。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_22_bianji",
	NextID = 14412711,
}
StorySpeechConfig[StorySpeechID.Id14412711] =
{
	Id = 14412711,
	CharName = "传送机",
	Text = "（引擎运转起来，随着博士一通操作，编辑长感到一阵强大的吸力将他带进了高维轨道）",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	LeftIcon = "Equipment_Sus_24_boshi_1",
	NextID = 14412712,
}
StorySpeechConfig[StorySpeechID.Id14412712] =
{
	Id = 14412712,
	CharName = "大作家",
	Text = "啊，海边的空气真是清新啊，尤其是在出版前夕忽然拖稿，然后逃到这里来度假~~",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng_cos10",
	NextID = 14412713,
}
StorySpeechConfig[StorySpeechID.Id14412713] =
{
	Id = 14412713,
	CharName = "编辑长",
	Text = "（咻地出现）大作家，请赶紧完成稿件吧。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_22_bianji",
	NextID = 14412714,
}
StorySpeechConfig[StorySpeechID.Id14412714] =
{
	Id = 14412714,
	CharName = "大作家",
	Text = "！！你的飞行服不是……啊，不！我今天绝不写稿，完全没有灵感了！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng_cos10",
	NextID = 14412715,
}
StorySpeechConfig[StorySpeechID.Id14412715] =
{
	Id = 14412715,
	CharName = "编辑长",
	Text = "那就别怪我动手了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_22_bianji",
}
StorySpeechConfig[StorySpeechID.Id14413301] =
{
	Id = 14413301,
	CharName = "警帽",
	Text = "（用力敲门）咚咚咚！咚咚咚！里面的人，停下手里的工作，立刻出来。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	LeftIcon = "SUS_PoliceCaps",
	NextID = 14413302,
}
StorySpeechConfig[StorySpeechID.Id14413302] =
{
	Id = 14413302,
	CharName = "博士",
	Text = "诶？到底是哪里出了问题呢？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_24_boshi",
	NextID = 14413303,
}
StorySpeechConfig[StorySpeechID.Id14413303] =
{
	Id = 14413303,
	CharName = "警帽",
	Text = "我们接到举报，你正在制作疑似危害公共安全的制品，现在勒令你立刻停止手里的工作，出来交代情况！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	LeftIcon = "SUS_PoliceCaps",
	NextID = 14413304,
}
StorySpeechConfig[StorySpeechID.Id14413304] =
{
	Id = 14413304,
	CharName = "博士",
	Text = "啊，原来是4号区块的中继器电路烧断了，需要一些铜料来焊接一下。哪里去找铜料呢？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_24_boshi",
	NextID = 14413305,
}
StorySpeechConfig[StorySpeechID.Id14413305] =
{
	Id = 14413305,
	CharName = "警帽",
	Text = "犯罪嫌疑人，我以我帽子上的警署徽章向你发誓，如果你继续顽抗，我一定会逮捕你的。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	LeftIcon = "SUS_PoliceCaps",
	NextID = 14413306,
}
StorySpeechConfig[StorySpeechID.Id14413306] =
{
	Id = 14413306,
	CharName = "博士",
	Text = "诶！警署徽章吗？（透过门上的猫眼查看警帽的打扮）",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_24_boshi",
	NextID = 14413307,
}
StorySpeechConfig[StorySpeechID.Id14413307] =
{
	Id = 14413307,
	CharName = "博士",
	Text = "哇，大小正好，看起来质地很纯粹，只要加热应该就能立刻使用。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_24_boshi",
	NextID = 14413308,
}
StorySpeechConfig[StorySpeechID.Id14413308] =
{
	Id = 14413308,
	CharName = "警帽",
	Text = "最后一次警告，我数到5，就将破门而入！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	LeftIcon = "SUS_PoliceCaps",
	NextID = 14413309,
}
StorySpeechConfig[StorySpeechID.Id14413309] =
{
	Id = 14413309,
	CharName = "博士",
	Text = "就是你了！！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_24_boshi",
	NextID = 14413310,
}
StorySpeechConfig[StorySpeechID.Id14413310] =
{
	Id = 14413310,
	CharName = "警帽",
	Text = "请立刻束手就擒，诶！你拿着喷灯干嘛！啊！！你要干什么！！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	LeftIcon = "SUS_PoliceCaps",
}
StorySpeechConfig[StorySpeechID.Id14413701] =
{
	Id = 14413701,
	CharName = "律师",
	Text = "法官阁下，我们已经成功潜入了假不夜城了，只要里面一切如被告所言，就能证明被告是无辜的了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_13_lvshi",
	NextID = 14413702,
}
StorySpeechConfig[StorySpeechID.Id14413702] =
{
	Id = 14413702,
	CharName = "法官",
	Text = "多亏助理先生扮成女孩子，一路上才能安全进入。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_14_faguan",
	NextID = 14413703,
}
StorySpeechConfig[StorySpeechID.Id14413703] =
{
	Id = 14413703,
	CharName = "女装侦探助理",
	Text = "前面应该还有守卫，我们要小心。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_02_huasheng_cos20",
	NextID = 14413704,
}
StorySpeechConfig[StorySpeechID.Id14413704] =
{
	Id = 14413704,
	CharName = "夜场看门人",
	Text = "喂，你们三个什么人！鬼鬼祟祟的干什么！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_28_heiyiren_cos10",
	NextID = 14413705,
}
StorySpeechConfig[StorySpeechID.Id14413705] =
{
	Id = 14413705,
	CharName = "法官",
	Text = "诶，我们三个听说这里有特别的奖池可以抽，所以特地来看看。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_14_faguan",
	NextID = 14413706,
}
StorySpeechConfig[StorySpeechID.Id14413706] =
{
	Id = 14413706,
	CharName = "夜场看门人",
	Text = "前面是女宾招待区，只招待女顾客，你们快走。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_28_heiyiren_cos10",
	NextID = 14413707,
}
StorySpeechConfig[StorySpeechID.Id14413707] =
{
	Id = 14413707,
	CharName = "女装侦探助理",
	Text = "诶，那我可以过去吗？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_02_huasheng_cos20",
	NextID = 14413708,
}
StorySpeechConfig[StorySpeechID.Id14413708] =
{
	Id = 14413708,
	CharName = "夜场看门人",
	Text = "嗯，你可以过去，这两个留下！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_28_heiyiren_cos10",
	NextID = 14413709,
}
StorySpeechConfig[StorySpeechID.Id14413709] =
{
	Id = 14413709,
	CharName = "法官",
	Text = "其实我们都是女的噢~",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_14_faguan",
	NextID = 14413710,
}
StorySpeechConfig[StorySpeechID.Id14413710] =
{
	Id = 14413710,
	CharName = "夜场看门人",
	Text = "……我不信。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_28_heiyiren_cos10",
	NextID = 14413711,
}
StorySpeechConfig[StorySpeechID.Id14413711] =
{
	Id = 14413711,
	CharName = "法官",
	Text = "那我去换个衣服，你等着。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_14_faguan",
	NextID = 14413712,
}
StorySpeechConfig[StorySpeechID.Id14413712] =
{
	Id = 14413712,
	CharName = "夜场看门人",
	Text = "不行，我要看着你换。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_28_heiyiren_cos10",
	NextID = 14413713,
}
StorySpeechConfig[StorySpeechID.Id14413713] =
{
	Id = 14413713,
	CharName = "法官",
	Text = "哇，本法官还从来没遇到过这么不给面子的，那就别怪我不客气了！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_14_faguan",
}
StorySpeechConfig[StorySpeechID.Id14412201] =
{
	Id = 14412201,
	CharName = "导演",
	Text = "刚刚那几个证物面试得都不错。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "SEA_Octupas1",
	NextID = 14412202,
}
StorySpeechConfig[StorySpeechID.Id14412202] =
{
	Id = 14412202,
	CharName = "场务",
	Text = "啊，是的，导演，这次因为花了大价钱，所以龙套和道具的品质也都跟着上去了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_23_tiaojiushi_cos10",
	NextID = 14412203,
}
StorySpeechConfig[StorySpeechID.Id14412203] =
{
	Id = 14412203,
	CharName = "导演",
	Text = "那这次面试的是？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "SEA_Octupas1",
	NextID = 14412204,
}
StorySpeechConfig[StorySpeechID.Id14412204] =
{
	Id = 14412204,
	CharName = "场务",
	Text = "是证人角色，台词特别特别多，我叫他进来。证人！证人！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_23_tiaojiushi_cos10",
	NextID = 14412205,
}
StorySpeechConfig[StorySpeechID.Id14412205] =
{
	Id = 14412205,
	CharName = "证人",
	Text = "导演好，我是来面试证人角色的。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_08_zhenren",
	NextID = 14412206,
}
StorySpeechConfig[StorySpeechID.Id14412206] =
{
	Id = 14412206,
	CharName = "导演",
	Text = "你背台词的技能过不过关啊？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "SEA_Octupas1",
	NextID = 14412207,
}
StorySpeechConfig[StorySpeechID.Id14412207] =
{
	Id = 14412207,
	CharName = "证人",
	Text = "我是前年记忆大赛的亚军，导演。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_08_zhenren",
	NextID = 14412208,
}
StorySpeechConfig[StorySpeechID.Id14412208] =
{
	Id = 14412208,
	CharName = "导演",
	Text = "不错不错，这本台词本，你看看5分钟能不能搞得定，搞定了明天就带着家什来剧组吧。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "SEA_Octupas1",
	NextID = 14412209,
}
StorySpeechConfig[StorySpeechID.Id14412209] =
{
	Id = 14412209,
	CharName = "证人",
	Text = "多谢导演，我一定会把握机会的。哇！这么厚一本！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_08_zhenren",
}
StorySpeechConfig[StorySpeechID.Id14413401] =
{
	Id = 14413401,
	CharName = "黑警长",
	Text = "你们这些卧底真有意思，每次都在天台见面。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_05_jingcha_cos10",
	NextID = 14413402,
}
StorySpeechConfig[StorySpeechID.Id14413402] =
{
	Id = 14413402,
	CharName = "豆豆警官",
	Text = "我不像你，我光明正大。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_05_jingcha",
	NextID = 14413403,
}
StorySpeechConfig[StorySpeechID.Id14413403] =
{
	Id = 14413403,
	CharName = "黑警长",
	Text = "给我个机会？我已经拿够黑钱了，明天就移民去外星了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_05_jingcha_cos10",
	NextID = 14413404,
}
StorySpeechConfig[StorySpeechID.Id14413404] =
{
	Id = 14413404,
	CharName = "豆豆警官",
	Text = "那么那些被你牺牲掉的同僚呢？那些被你害苦了的无辜市民呢？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_05_jingcha",
	NextID = 14413405,
}
StorySpeechConfig[StorySpeechID.Id14413405] =
{
	Id = 14413405,
	CharName = "黑警长",
	Text = "以前我没得选，现在我想做个好人。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_05_jingcha_cos10",
	NextID = 14413406,
}
StorySpeechConfig[StorySpeechID.Id14413406] =
{
	Id = 14413406,
	CharName = "豆豆警官",
	Text = "好，跟法官说，看他让不让你做个好人。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_05_jingcha",
	NextID = 14413407,
}
StorySpeechConfig[StorySpeechID.Id14413407] =
{
	Id = 14413407,
	CharName = "黑警长",
	Text = "那就是要我死？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_05_jingcha_cos10",
	NextID = 14413408,
}
StorySpeechConfig[StorySpeechID.Id14413408] =
{
	Id = 14413408,
	CharName = "豆豆警官",
	Text = "对不起，我是个警察。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_05_jingcha",
	NextID = 14413409,
}
StorySpeechConfig[StorySpeechID.Id14413409] =
{
	Id = 14413409,
	CharName = "黑警长",
	Text = "你以为你打得过我？而且，打赢我之后，你打算怎么办呢？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_05_jingcha_cos10",
	NextID = 14413410,
}
StorySpeechConfig[StorySpeechID.Id14413410] =
{
	Id = 14413410,
	CharName = "豆豆警官",
	Text = "我会以你的身份继续深入组织，直到找到幕后黑手，彻底捣毁组织！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_05_jingcha",
	NextID = 14413411,
}
StorySpeechConfig[StorySpeechID.Id14413411] =
{
	Id = 14413411,
	CharName = "黑警长",
	Text = "你太天真了，受死吧！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_05_jingcha_cos10",
}
StorySpeechConfig[StorySpeechID.Id14414401] =
{
	Id = 14414401,
	CharName = "研究人员A",
	Text = "部长，脑力扩散装置已经完成数据阶段的25项测试了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_03_moliyadi_cos30",
	NextID = 14414402,
}
StorySpeechConfig[StorySpeechID.Id14414402] =
{
	Id = 14414402,
	CharName = "迈克罗夫特",
	Text = "那么可以进入临床阶段了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_19_maikaofu",
	NextID = 14414403,
}
StorySpeechConfig[StorySpeechID.Id14414403] =
{
	Id = 14414403,
	CharName = "研究人员B",
	Text = "是的，不过该装置目前要求的脑能指数超越普通人标准9倍，我们无法找到合适的实验对象。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_03_moliyadi_cos30",
	NextID = 14414404,
}
StorySpeechConfig[StorySpeechID.Id14414404] =
{
	Id = 14414404,
	CharName = "迈克罗夫特",
	Text = "没关系，由我亲自测试就好了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_19_maikaofu",
	NextID = 14414405,
}
StorySpeechConfig[StorySpeechID.Id14414405] =
{
	Id = 14414405,
	CharName = "研究人员A",
	Text = "部长，这样做太危险了。如果您的大脑不受召回装置作用，脑能扩散后，您的意识可能无法回到身体。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_03_moliyadi_cos30",
	NextID = 14414406,
}
StorySpeechConfig[StorySpeechID.Id14414406] =
{
	Id = 14414406,
	CharName = "迈克罗夫特",
	Text = "哈哈哈哈~~我完全不担心这个结果。这个世界我已经腻烦了，能够找到去其他世界的道路才是有趣的事情。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_19_maikaofu",
	NextID = 14414407,
}
StorySpeechConfig[StorySpeechID.Id14414407] =
{
	Id = 14414407,
	CharName = "研究人员B",
	Text = "部长，你真的相信我们的世界从本质而言是虚构的？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_03_moliyadi_cos30",
	NextID = 14414408,
}
StorySpeechConfig[StorySpeechID.Id14414408] =
{
	Id = 14414408,
	CharName = "迈克罗夫特",
	Text = "我见过那两个小家伙，我敢肯定，构成真实世界的远不止是我们现在所知的这一切。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_19_maikaofu",
	NextID = 14414409,
}
StorySpeechConfig[StorySpeechID.Id14414409] =
{
	Id = 14414409,
	CharName = "研究人员A",
	Text = "可是……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_03_moliyadi_cos30",
	NextID = 14414410,
}
StorySpeechConfig[StorySpeechID.Id14414410] =
{
	Id = 14414410,
	CharName = "迈克罗夫特",
	Text = "不用担心了，激活实验脑体，准备给我换上扩散装置吧。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_19_maikaofu",
}
StorySpeechConfig[StorySpeechID.Id14411901] =
{
	Id = 14411901,
	CharName = "编辑长",
	Text = "今年悬疑推理大会在我们星球举办，我们编辑部也收到了一张邀请函，希望给予今年贡献最大的作者。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_22_bianji",
	NextID = 14411902,
}
StorySpeechConfig[StorySpeechID.Id14411902] =
{
	Id = 14411902,
	CharName = "《二年级的死神》作者",
	Text = "今年《二年级的死神》动画版成功破千集，我想我是当之无愧的MVP了吧？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng_cos10",
	NextID = 14411903,
}
StorySpeechConfig[StorySpeechID.Id14411903] =
{
	Id = 14411903,
	CharName = "编辑长",
	Text = "诶……大众反馈都在感情戏这一块，普遍表示推理部分非常强行，而且手法越来越离奇，没有可操作性。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_22_bianji",
	NextID = 14411904,
}
StorySpeechConfig[StorySpeechID.Id14411904] =
{
	Id = 14411904,
	CharName = "《二年级的死神》作者",
	Text = "……除了感情戏，还有动作戏啊？今年主打的剧场版将会是动作大片呢。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng_cos10",
	NextID = 14411905,
}
StorySpeechConfig[StorySpeechID.Id14411905] =
{
	Id = 14411905,
	CharName = "编辑长",
	Text = "可是，这次举办的悬疑推理大会希望前往参加的都是正统的推理作者。所以……邀请函打算给阿加莎小姐。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_22_bianji",
	NextID = 14411906,
}
StorySpeechConfig[StorySpeechID.Id14411906] =
{
	Id = 14411906,
	CharName = "阿加莎",
	Text = "诶~是我吗，太高兴了~我会好好做笔记的。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_30_ajiasha",
	NextID = 14411907,
}
StorySpeechConfig[StorySpeechID.Id14411907] =
{
	Id = 14411907,
	CharName = "《二年级的死神》作者",
	Text = "太胡来了！让她和我比划比划，否则就踏着我的尸体去参加研讨会吧！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_20_lanyixiaoxuesheng_cos10",
	NextID = 14411908,
}
StorySpeechConfig[StorySpeechID.Id14411908] =
{
	Id = 14411908,
	CharName = "编辑长",
	Text = "既然这样，那就没有办法了，阿加莎小姐，请放心地解决这位前辈吧。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_22_bianji",
}
StorySpeechConfig[StorySpeechID.Id14413801] =
{
	Id = 14413801,
	CharName = "导演",
	Text = "是不是该面试助理了？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "SEA_Octupas1",
	NextID = 14413802,
}
StorySpeechConfig[StorySpeechID.Id14413802] =
{
	Id = 14413802,
	CharName = "场务",
	Text = "啊，是的，导演，对方是大侦探助理本人，是顶级捧哏好手，不过似乎很腼腆。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_23_tiaojiushi_cos10",
	NextID = 14413803,
}
StorySpeechConfig[StorySpeechID.Id14413803] =
{
	Id = 14413803,
	CharName = "导演",
	Text = "很腼腆？那怎么上镜，会不会对着镜头就哆哆嗦嗦的？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "SEA_Octupas1",
	NextID = 14413804,
}
StorySpeechConfig[StorySpeechID.Id14413804] =
{
	Id = 14413804,
	CharName = "场务",
	Text = "大侦探本人表示，如果助理不参加，他无论如何都会加入。所以还是让他来面试一下吧。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_23_tiaojiushi_cos10",
	NextID = 14413805,
}
StorySpeechConfig[StorySpeechID.Id14413805] =
{
	Id = 14413805,
	CharName = "侦探助理",
	Text = "导演好，我是来面试助理角色的。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_02_huasheng",
	NextID = 14413806,
}
StorySpeechConfig[StorySpeechID.Id14413806] =
{
	Id = 14413806,
	CharName = "导演",
	Text = "听说你一直是大侦探的助手，你们的默契让我非常放心。不过你似乎很腼腆，面对镜头会害怕吗？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "SEA_Octupas1",
	NextID = 14413807,
}
StorySpeechConfig[StorySpeechID.Id14413807] =
{
	Id = 14413807,
	CharName = "侦探助理",
	Text = "我会努力的，导演。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_02_huasheng",
	NextID = 14413808,
}
StorySpeechConfig[StorySpeechID.Id14413808] =
{
	Id = 14413808,
	CharName = "导演",
	Text = "不错不错，那就请看着这个最新的摄像机，然后一拳把它打碎吧！只要把它打碎，你就没有心理压力了。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "SEA_Octupas1",
	NextID = 14413809,
}
StorySpeechConfig[StorySpeechID.Id14413809] =
{
	Id = 14413809,
	CharName = "侦探助理",
	Text = "我一定会把握机会的，导演。哇！这……这……这么高清的吗？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_02_huasheng",
}
StorySpeechConfig[StorySpeechID.Id14413901] =
{
	Id = 14413901,
	CharName = "律师",
	Text = "法官阁下，我已经找到被告说的那个假不夜城了，请你务必和我们去现场看一下。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_13_lvshi",
	NextID = 14413902,
}
StorySpeechConfig[StorySpeechID.Id14413902] =
{
	Id = 14413902,
	CharName = "侦探助理",
	Text = "我相信赃物就藏在那个酒吧里，如果里面的摆设和被告说的一样，就能证明被告是无辜的了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_02_huasheng",
	NextID = 14413903,
}
StorySpeechConfig[StorySpeechID.Id14413903] =
{
	Id = 14413903,
	CharName = "法官",
	Text = "其实我也不是真的那么铁面无情的，既然你这么坚持，我们就去看一下吧。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_14_faguan",
	NextID = 14413904,
}
StorySpeechConfig[StorySpeechID.Id14413904] =
{
	Id = 14413904,
	CharName = "律师",
	Text = "就在前面，法官阁下。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_13_lvshi",
	NextID = 14413905,
}
StorySpeechConfig[StorySpeechID.Id14413905] =
{
	Id = 14413905,
	CharName = "夜场看门人",
	Text = "喂，你们三个什么人！看装扮是法官、律师和侦探助理？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_28_heiyiren_cos10",
	NextID = 14413906,
}
StorySpeechConfig[StorySpeechID.Id14413906] =
{
	Id = 14413906,
	CharName = "法官",
	Text = "这……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_14_faguan",
	NextID = 14413907,
}
StorySpeechConfig[StorySpeechID.Id14413907] =
{
	Id = 14413907,
	CharName = "律师",
	Text = "不好，被识破了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_13_lvshi",
	NextID = 14413908,
}
StorySpeechConfig[StorySpeechID.Id14413908] =
{
	Id = 14413908,
	CharName = "侦探助理",
	Text = "谁说的？我们3个是假冒的法官、律师以及侦探助理，其实我们都是女的。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_02_huasheng",
	NextID = 14413909,
}
StorySpeechConfig[StorySpeechID.Id14413909] =
{
	Id = 14413909,
	CharName = "夜场看门人",
	Text = "……我不信。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_28_heiyiren_cos10",
	NextID = 14413910,
}
StorySpeechConfig[StorySpeechID.Id14413910] =
{
	Id = 14413910,
	CharName = "律师",
	Text = "（小声说）喂，助理，这个大个子不信，怎么办？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_13_lvshi",
	NextID = 14413911,
}
StorySpeechConfig[StorySpeechID.Id14413911] =
{
	Id = 14413911,
	CharName = "侦探助理",
	Text = "喂，大个子，那我去换个衣服，你等着。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_02_huasheng",
	NextID = 14413912,
}
StorySpeechConfig[StorySpeechID.Id14413912] =
{
	Id = 14413912,
	CharName = "夜场看门人",
	Text = "不行，我要看着你换。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_28_heiyiren_cos10",
	NextID = 14413913,
}
StorySpeechConfig[StorySpeechID.Id14413913] =
{
	Id = 14413913,
	CharName = "侦探助理",
	Text = "既然你这么不给面子，那就别怪我们不客气了！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_02_huasheng",
}
StorySpeechConfig[StorySpeechID.Id14414001] =
{
	Id = 14414001,
	CharName = "侦探助理",
	Text = "新买的睡衣到了，而且房东太太不在家，又可以打枕头大战了~",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_02_huasheng",
	NextID = 14414002,
}
StorySpeechConfig[StorySpeechID.Id14414002] =
{
	Id = 14414002,
	CharName = "多人视讯会议",
	Text = "正在拨通大侦探……\n正在拨通教授……",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	RightIcon = "Equipment_Sus_14_faguan_2",
	NextID = 14414003,
}
StorySpeechConfig[StorySpeechID.Id14414003] =
{
	Id = 14414003,
	CharName = "大侦探",
	Text = "怎么啦~我还在警局给犯人讲解案件过程呢~",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_01_fuermosi",
	NextID = 14414004,
}
StorySpeechConfig[StorySpeechID.Id14414004] =
{
	Id = 14414004,
	CharName = "教授",
	Text = "我也还在研究新的犯罪手法呢~",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_03_moliyadi",
	NextID = 14414005,
}
StorySpeechConfig[StorySpeechID.Id14414005] =
{
	Id = 14414005,
	CharName = "侦探助理",
	Text = "那些都不重要啦~今天房东太太要去隔壁市参加新大楼的落成典礼~~家里没人噢~~",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_02_huasheng",
	NextID = 14414006,
}
StorySpeechConfig[StorySpeechID.Id14414006] =
{
	Id = 14414006,
	CharName = "大侦探",
	Text = "哇，又可以开睡衣派对了！枕头我来带，等我，三十分钟后到。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_01_fuermosi",
	NextID = 14414007,
}
StorySpeechConfig[StorySpeechID.Id14414007] =
{
	Id = 14414007,
	CharName = "教授",
	Text = "嘿嘿，那我也三十分钟后到~",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_03_moliyadi",
	NextID = 14414008,
}
StorySpeechConfig[StorySpeechID.Id14414008] =
{
	Id = 14414008,
	CharName = "侦探助理",
	Text = "今天一定要趁房东太太不在，分个胜负~",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_02_huasheng",
	NextID = 14414009,
}
StorySpeechConfig[StorySpeechID.Id14414009] =
{
	Id = 14414009,
	CharName = "房东太太",
	Text = "助理，你在和谁打电话，说我不在？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_15_fangdongtaitai",
	NextID = 14414010,
}
StorySpeechConfig[StorySpeechID.Id14414010] =
{
	Id = 14414010,
	CharName = "侦探助理",
	Text = "诶！房东太太，你怎么回来了？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_02_huasheng",
	NextID = 14414011,
}
StorySpeechConfig[StorySpeechID.Id14414011] =
{
	Id = 14414011,
	CharName = "侦探助理",
	Text = "还有这样的事！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_02_huasheng",
	NextID = 14414012,
}
StorySpeechConfig[StorySpeechID.Id14414012] =
{
	Id = 14414012,
	CharName = "房东太太",
	Text = "你手里的是新睡衣？助理，你该不会是想趁我不在打枕头大战吧？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_15_fangdongtaitai",
	NextID = 14414013,
}
StorySpeechConfig[StorySpeechID.Id14414013] =
{
	Id = 14414013,
	CharName = "侦探助理",
	Text = "绝对没有！绝对没有！太太。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_02_huasheng",
	NextID = 14414014,
}
StorySpeechConfig[StorySpeechID.Id14414014] =
{
	Id = 14414014,
	CharName = "多人视讯会议",
	Text = "大侦探的语音-对了，我发明了一个新的招式，等会给你们演示一下！",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	LeftIcon = "Equipment_Sus_14_faguan_2",
	NextID = 14414015,
}
StorySpeechConfig[StorySpeechID.Id14414015] =
{
	Id = 14414015,
	CharName = "房东太太",
	Text = "……今天一定要好好教训你小子一顿了！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_15_fangdongtaitai",
	NextID = 14414016,
}
StorySpeechConfig[StorySpeechID.Id14414016] =
{
	Id = 14414016,
	CharName = "侦探助理",
	Text = "啊，房东太太，对不起啊~~~",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_02_huasheng",
}
StorySpeechConfig[StorySpeechID.Id14414101] =
{
	Id = 14414101,
	CharName = "大侦探",
	Text = "杰克~杰克~新的漫画到了，你和我们一起去漫画店吗？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_01_fuermosi",
	NextID = 14414102,
}
StorySpeechConfig[StorySpeechID.Id14414102] =
{
	Id = 14414102,
	CharName = "杰克瑞波",
	Text = "再等我5分钟，我马上就拍到这件限量版的针织衫了~",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_29_kaitangshoujieke",
	NextID = 14414103,
}
StorySpeechConfig[StorySpeechID.Id14414103] =
{
	Id = 14414103,
	CharName = "大侦探",
	Text = "诶？你为什么买针织衫啊？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_01_fuermosi",
	NextID = 14414104,
}
StorySpeechConfig[StorySpeechID.Id14414104] =
{
	Id = 14414104,
	CharName = "杰克瑞波",
	Text = "你不知道，这件针织衫可是第一任大侦探的专属装备，已经消失150年了，今天竟然出现在竞拍网上！我一定要得到它！！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_29_kaitangshoujieke",
	NextID = 14414105,
}
StorySpeechConfig[StorySpeechID.Id14414105] =
{
	Id = 14414105,
	CharName = "大侦探",
	Text = "哇！第一任大侦探可是我最崇拜的偶像呢~",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_01_fuermosi",
	NextID = 14414106,
}
StorySpeechConfig[StorySpeechID.Id14414106] =
{
	Id = 14414106,
	CharName = "杰克瑞波",
	Text = "嘿嘿嘿嘿，等我拍到了，也借你看一下。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_29_kaitangshoujieke",
	NextID = 14414107,
}
StorySpeechConfig[StorySpeechID.Id14414107] =
{
	Id = 14414107,
	CharName = "大侦探",
	Text = "这个拍卖有什么限制吗？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_01_fuermosi",
	NextID = 14414108,
}
StorySpeechConfig[StorySpeechID.Id14414108] =
{
	Id = 14414108,
	CharName = "杰克瑞波",
	Text = "完全没有限制，价高者得。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_29_kaitangshoujieke",
	NextID = 14414109,
}
StorySpeechConfig[StorySpeechID.Id14414109] =
{
	Id = 14414109,
	CharName = "大侦探",
	Text = "哇，那一定要很多钱吧？现在拍到多少了？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_01_fuermosi",
	NextID = 14414110,
}
StorySpeechConfig[StorySpeechID.Id14414110] =
{
	Id = 14414110,
	CharName = "杰克瑞波",
	Text = "嘿嘿嘿嘿，现在最高价是我呢~~已经出到2800了，再有5分钟我就能顺利拿下了！诶！！！怎么有人出12000了！！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_29_kaitangshoujieke",
	NextID = 14414111,
}
StorySpeechConfig[StorySpeechID.Id14414111] =
{
	Id = 14414111,
	CharName = "大侦探",
	Text = "哇，正好拿了警局的咨询费，拍下这件针织衫，历届大侦探的信物我就都有了呢~~",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_01_fuermosi",
	NextID = 14414112,
}
StorySpeechConfig[StorySpeechID.Id14414112] =
{
	Id = 14414112,
	CharName = "杰克瑞波",
	Text = "啊！！！！你怎么可以抢朋友的竞拍品！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_29_kaitangshoujieke",
	NextID = 14414113,
}
StorySpeechConfig[StorySpeechID.Id14414113] =
{
	Id = 14414113,
	CharName = "大侦探",
	Text = "诶？竞拍不是价高者得吗？而且……诶！杰克，你关门干什么？我打电话报警了噢！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_01_fuermosi",
	NextID = 14414114,
}
StorySpeechConfig[StorySpeechID.Id14414114] =
{
	Id = 14414114,
	CharName = "杰克瑞波",
	Text = "我要为我的针织衫报仇！！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_29_kaitangshoujieke",
}
StorySpeechConfig[StorySpeechID.Id14414201] =
{
	Id = 14414201,
	CharName = "场务",
	Text = "导演，大作家的角色还没有人试镜成功。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_23_tiaojiushi_cos10",
	NextID = 14414202,
}
StorySpeechConfig[StorySpeechID.Id14414202] =
{
	Id = 14414202,
	CharName = "导演",
	Text = "诶？真是伤脑筋啊~让房东太太反串呢？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "SEA_Octupas1",
	NextID = 14414203,
}
StorySpeechConfig[StorySpeechID.Id14414203] =
{
	Id = 14414203,
	CharName = "场务",
	Text = "房东太太已经有角色了，而且大作家要在好几幕里出现，不太方便由一人分饰两角了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_23_tiaojiushi_cos10",
	NextID = 14414204,
}
StorySpeechConfig[StorySpeechID.Id14414204] =
{
	Id = 14414204,
	CharName = "导演",
	Text = "用建模技术做一个虚拟角色呢？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "SEA_Octupas1",
	NextID = 14414205,
}
StorySpeechConfig[StorySpeechID.Id14414205] =
{
	Id = 14414205,
	CharName = "场务",
	Text = "大作家这个角色台词特别多，如果用建模技术制作，一定会大量超出预算。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_23_tiaojiushi_cos10",
	NextID = 14414206,
}
StorySpeechConfig[StorySpeechID.Id14414206] =
{
	Id = 14414206,
	CharName = "导演",
	Text = "那随便找个人吧。诶？前两天不是有个小学生来，说自己是大作家的书迷吗？还当场表演了秒背台词的绝技。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "SEA_Octupas1",
	NextID = 14414207,
}
StorySpeechConfig[StorySpeechID.Id14414207] =
{
	Id = 14414207,
	CharName = "场务",
	Text = "噢，听说那个技能是他爸爸在夏威夷教他的那个小学生吗？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_23_tiaojiushi_cos10",
	NextID = 14414208,
}
StorySpeechConfig[StorySpeechID.Id14414208] =
{
	Id = 14414208,
	CharName = "导演",
	Text = "嗯，就是他！快打电话叫他来面试。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "SEA_Octupas1",
	NextID = 14414209,
}
StorySpeechConfig[StorySpeechID.Id14414209] =
{
	Id = 14414209,
	CharName = "场务",
	Text = "那个小学生确实很理想，不过听说他体质很特别，就怕开工天天死人啊。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_23_tiaojiushi_cos10",
	NextID = 14414210,
}
StorySpeechConfig[StorySpeechID.Id14414210] =
{
	Id = 14414210,
	CharName = "导演",
	Text = "不怕，先叫他过来。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "SEA_Octupas1",
	NextID = 14414211,
}
StorySpeechConfig[StorySpeechID.Id14414211] =
{
	Id = 14414211,
	CharName = "场务",
	Text = "（一小时过后）",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_23_tiaojiushi_cos10",
	NextID = 14414212,
}
StorySpeechConfig[StorySpeechID.Id14414212] =
{
	Id = 14414212,
	CharName = "蓝衣小学生",
	Text = "导演哥哥~~听说你们想让我出演我的偶像——大作家？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 14414213,
}
StorySpeechConfig[StorySpeechID.Id14414213] =
{
	Id = 14414213,
	CharName = "导演",
	Text = "对！不过听说你体质特殊，这里有一块我托人从外星弄回来的祭祀石，等等你打碎它，那就岁岁平安了。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "SEA_Octupas1",
	NextID = 14414214,
}
StorySpeechConfig[StorySpeechID.Id14414214] =
{
	Id = 14414214,
	CharName = "蓝衣小学生",
	Text = "啊咧咧？那好吧，就按大哥哥说的办吧。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
}
StorySpeechConfig[StorySpeechID.Id14414301] =
{
	Id = 14414301,
	CharName = "博士",
	Text = "新……啊呸，小学生，你快来，你看这个。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_24_boshi",
	NextID = 14414302,
}
StorySpeechConfig[StorySpeechID.Id14414302] =
{
	Id = 14414302,
	CharName = "蓝衣小学生",
	Text = "我说博士啊，我都和你说了好多次了要小心，你乱说话我们是要涉险侵权的。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 14414303,
}
StorySpeechConfig[StorySpeechID.Id14414303] =
{
	Id = 14414303,
	CharName = "博士",
	Text = "啊，啊，我会注意的了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_24_boshi",
	NextID = 14414304,
}
StorySpeechConfig[StorySpeechID.Id14414304] =
{
	Id = 14414304,
	CharName = "蓝衣小学生",
	Text = "你这么急急忙忙地叫我过来，到底是要给我看什么啊？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 14414305,
}
StorySpeechConfig[StorySpeechID.Id14414305] =
{
	Id = 14414305,
	CharName = "博士",
	Text = "你看，你让我反向工程的那个药剂，我成功找到它的主体合成物质了！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_24_boshi",
	NextID = 14414306,
}
StorySpeechConfig[StorySpeechID.Id14414306] =
{
	Id = 14414306,
	CharName = "蓝衣小学生",
	Text = "什么！这就是那个APTX-4869吗？这就是把我变小的……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 14414307,
}
StorySpeechConfig[StorySpeechID.Id14414307] =
{
	Id = 14414307,
	CharName = "博士",
	Text = "对，就是它！我通过32组对比实验发现，这个药剂的标靶器官是脑，只要脑能足够强大，就会发生逆生长现象。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_24_boshi",
	NextID = 14414308,
}
StorySpeechConfig[StorySpeechID.Id14414308] =
{
	Id = 14414308,
	CharName = "蓝衣小学生",
	Text = "那，它的解药？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 14414309,
}
StorySpeechConfig[StorySpeechID.Id14414309] =
{
	Id = 14414309,
	CharName = "博士",
	Text = "对！它的解药我也找到了，只要抑制脑内活性，就能短时间解除逆生长现象，虽然不符合科学，不过为了剧情能够合理推进，设定上是这样的。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_24_boshi",
	NextID = 14414310,
}
StorySpeechConfig[StorySpeechID.Id14414310] =
{
	Id = 14414310,
	CharName = "蓝衣小学生",
	Text = "那么赶紧给我注射试试看！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_20_lanyixiaoxuesheng",
	NextID = 14414311,
}
StorySpeechConfig[StorySpeechID.Id14414311] =
{
	Id = 14414311,
	CharName = "博士",
	Text = "这次是药剂是口服的，不过制作过程中因为不科学物质的介入，它现在有了自己的意志，需要先搞定它，才能喝下去。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_24_boshi",
}
StorySpeechConfig[StorySpeechID.Id14413601] =
{
	Id = 14413601,
	CharName = "房东太太",
	Text = "法官阁下，陪审团经过商议，一致同意被告剧透罪名不成立。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_15_fangdongtaitai",
	NextID = 14413602,
}
StorySpeechConfig[StorySpeechID.Id14413602] =
{
	Id = 14413602,
	CharName = "剧透犯",
	Text = "嘿嘿嘿嘿~~感谢我星球公正公平的法律。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_28_heiyiren",
	NextID = 14413603,
}
StorySpeechConfig[StorySpeechID.Id14413603] =
{
	Id = 14413603,
	CharName = "法官",
	Text = "那么本席宣布，被告诈骗罪名不成立，当庭释放。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_14_faguan",
	NextID = 14413604,
}
StorySpeechConfig[StorySpeechID.Id14413604] =
{
	Id = 14413604,
	CharName = "被害人",
	Text = "呜呜呜呜，怎么会这样……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_07_daomeidan",
	NextID = 14413605,
}
StorySpeechConfig[StorySpeechID.Id14413605] =
{
	Id = 14413605,
	CharName = "检察官",
	Text = "哎，不要太伤心了，虽然这次公诉失败，但是我们已经拿到他进一步的犯罪证据了，很快就能再次上诉。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_16_yujianlianshi",
	NextID = 14413606,
}
StorySpeechConfig[StorySpeechID.Id14413606] =
{
	Id = 14413606,
	CharName = "被害人",
	Text = "呜呜呜呜，太感谢你了！这个坏蛋把我还在追的十部剧集的结尾都告诉我了，你一定要将他绳之以法呀！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_07_daomeidan",
	NextID = 14413607,
}
StorySpeechConfig[StorySpeechID.Id14413607] =
{
	Id = 14413607,
	CharName = "检察官",
	Text = "实在是人神共愤！请放心，这样的坏蛋，法律饶不过他！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_16_yujianlianshi",
	NextID = 14413608,
}
StorySpeechConfig[StorySpeechID.Id14413608] =
{
	Id = 14413608,
	CharName = "剧透犯",
	Text = "哈哈哈哈~你太天真了，检察官先生，我已经申请了外星移民，明天我就要离开这个星球了。你没有机会了！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_28_heiyiren",
	NextID = 14413609,
}
StorySpeechConfig[StorySpeechID.Id14413609] =
{
	Id = 14413609,
	CharName = "检察官",
	Text = "什么！我不会让你得逞的！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_16_yujianlianshi",
	NextID = 14413610,
}
StorySpeechConfig[StorySpeechID.Id14413610] =
{
	Id = 14413610,
	CharName = "被害人",
	Text = "呜呜呜呜……本来对结局很期待的……呜呜呜呜……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_07_daomeidan",
	NextID = 14413611,
}
StorySpeechConfig[StorySpeechID.Id14413611] =
{
	Id = 14413611,
	CharName = "剧透犯",
	Text = "宝贝，看到你痛苦的样子，实在是太让我快乐了，以后我会经常打电话给你告诉你最近高分剧的结尾的噢~",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_28_heiyiren",
	NextID = 14413612,
}
StorySpeechConfig[StorySpeechID.Id14413612] =
{
	Id = 14413612,
	CharName = "被害人",
	Text = "呜呜呜呜…….",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_07_daomeidan",
	NextID = 14413613,
}
StorySpeechConfig[StorySpeechID.Id14413613] =
{
	Id = 14413613,
	CharName = "检察官",
	Text = "即使法律无法制止你，但是我心中的正义感命令我阻止你的罪行！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_16_yujianlianshi",
	NextID = 14413614,
}
StorySpeechConfig[StorySpeechID.Id14413614] =
{
	Id = 14413614,
	CharName = "剧透犯",
	Text = "诶！你要干什么！！检察官打人啦！！！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_28_heiyiren",
}
StorySpeechConfig[StorySpeechID.Id14414501] =
{
	Id = 14414501,
	CharName = "大侦探",
	Text = "哇啊啊啊啊~~~看我的枕头导弹！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_01_fuermosi",
	NextID = 14414502,
}
StorySpeechConfig[StorySpeechID.Id14414502] =
{
	Id = 14414502,
	CharName = "教授",
	Text = "被子防护装置！接下来是近距离枕头甩击！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_03_moliyadi",
	NextID = 14414503,
}
StorySpeechConfig[StorySpeechID.Id14414503] =
{
	Id = 14414503,
	CharName = "侦探助理",
	Text = "（被教授正中脸部）呃……是我反击的时候了，双枕旋风！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_02_huasheng",
	NextID = 14414504,
}
StorySpeechConfig[StorySpeechID.Id14414504] =
{
	Id = 14414504,
	CharName = "大侦探",
	Text = "哇，哇，就是这个绝技呢！！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_01_fuermosi",
	NextID = 14414505,
}
StorySpeechConfig[StorySpeechID.Id14414505] =
{
	Id = 14414505,
	CharName = "教授",
	Text = "诶！看来要败下阵来了！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_03_moliyadi",
	NextID = 14414506,
}
StorySpeechConfig[StorySpeechID.Id14414506] =
{
	Id = 14414506,
	CharName = "房东太太",
	Text = "（忽然开门）都给我住手！！！！！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_15_fangdongtaitai",
	NextID = 14414507,
}
StorySpeechConfig[StorySpeechID.Id14414507] =
{
	Id = 14414507,
	CharName = "大侦探",
	Text = "！！房东太太你不是去隔壁市参加婚礼了吗！！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_01_fuermosi",
	NextID = 14414508,
}
StorySpeechConfig[StorySpeechID.Id14414508] =
{
	Id = 14414508,
	CharName = "房东太太",
	Text = "（一把拽下大侦探的睡衣）婚礼现场来了个小学生，然后就发生命案，所以就取消了！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_15_fangdongtaitai",
	NextID = 14414509,
}
StorySpeechConfig[StorySpeechID.Id14414509] =
{
	Id = 14414509,
	CharName = "大侦探",
	Text = "又是小学生吗？从概率学的角度来说，也太可疑了呢。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_01_fuermosi",
	NextID = 14414510,
}
StorySpeechConfig[StorySpeechID.Id14414510] =
{
	Id = 14414510,
	CharName = "房东太太",
	Text = "喂！先说回你们！上次不是说好了，以后再也不搞睡衣派对了吗？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_15_fangdongtaitai",
	NextID = 14414511,
}
StorySpeechConfig[StorySpeechID.Id14414511] =
{
	Id = 14414511,
	CharName = "大侦探",
	Text = "因为你不在……教授和助理正好又都来做客，一下子没忍住就玩了一下……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_01_fuermosi",
	NextID = 14414512,
}
StorySpeechConfig[StorySpeechID.Id14414512] =
{
	Id = 14414512,
	CharName = "房东太太",
	Text = "你骗鬼啊！正好来做客还穿睡衣的嘛？正好来做客还带着自己家的枕头！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_15_fangdongtaitai",
	NextID = 14414513,
}
StorySpeechConfig[StorySpeechID.Id14414513] =
{
	Id = 14414513,
	CharName = "大侦探",
	Text = "……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_01_fuermosi",
	NextID = 14414514,
}
StorySpeechConfig[StorySpeechID.Id14414514] =
{
	Id = 14414514,
	CharName = "房东太太",
	Text = "是不是没话说了？那下个月租金翻倍，另外，睡衣我就没收了！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_15_fangdongtaitai",
	NextID = 14414515,
}
StorySpeechConfig[StorySpeechID.Id14414515] =
{
	Id = 14414515,
	CharName = "大侦探",
	Text = "……房东太太，你看，有UFO！（想要趁机抢回睡衣）",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_01_fuermosi",
	NextID = 14414516,
}
StorySpeechConfig[StorySpeechID.Id14414516] =
{
	Id = 14414516,
	CharName = "房东太太",
	Text = "想抢？没门！看来要给你点颜色看看了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_15_fangdongtaitai",
}
StorySpeechConfig[StorySpeechID.Id14414601] =
{
	Id = 14414601,
	CharName = "导演",
	Text = "终于到了面试第一主角的时刻了！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "SEA_Octupas1",
	NextID = 14414602,
}
StorySpeechConfig[StorySpeechID.Id14414602] =
{
	Id = 14414602,
	CharName = "场务",
	Text = "啊，导演，对方可是本星球人气最高的男性，每年都会协助警方破获案件1000起以上。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_23_tiaojiushi_cos10",
	NextID = 14414603,
}
StorySpeechConfig[StorySpeechID.Id14414603] =
{
	Id = 14414603,
	CharName = "导演",
	Text = "有了他，收视率就完全有保障了啊~那么这次试镜是不是可以免了？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "SEA_Octupas1",
	NextID = 14414604,
}
StorySpeechConfig[StorySpeechID.Id14414604] =
{
	Id = 14414604,
	CharName = "场务",
	Text = "听说大侦探来试镜，教授也已经提前过来了，说由他来和大侦探试一下戏。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_23_tiaojiushi_cos10",
	NextID = 14414605,
}
StorySpeechConfig[StorySpeechID.Id14414605] =
{
	Id = 14414605,
	CharName = "导演",
	Text = "这就是男人间的对决吧！哈哈，真是浪漫啊，那么开始吧！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "SEA_Octupas1",
	NextID = 14414606,
}
StorySpeechConfig[StorySpeechID.Id14414606] =
{
	Id = 14414606,
	CharName = "场务",
	Text = "那么，两位准备好了吗？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_23_tiaojiushi_cos10",
	NextID = 14414607,
}
StorySpeechConfig[StorySpeechID.Id14414607] =
{
	Id = 14414607,
	CharName = "大侦探",
	Text = "教授准备好了吗？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_01_fuermosi",
	NextID = 14414608,
}
StorySpeechConfig[StorySpeechID.Id14414608] =
{
	Id = 14414608,
	CharName = "朋克教授",
	Text = "嘿嘿嘿嘿，我可是随时都有准备的。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_03_moliyadi_cos10",
	NextID = 14414609,
}
StorySpeechConfig[StorySpeechID.Id14414609] =
{
	Id = 14414609,
	CharName = "大侦探",
	Text = "那我们今天比什么呢？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_01_fuermosi",
	NextID = 14414610,
}
StorySpeechConfig[StorySpeechID.Id14414610] =
{
	Id = 14414610,
	CharName = "朋克教授",
	Text = "嘿嘿嘿嘿，如果你没有意见的话，我们就像过去那样比赛吧。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_03_moliyadi_cos10",
}
StorySpeechConfig[StorySpeechID.Id14414701] =
{
	Id = 14414701,
	CharName = "挑衅信",
	Text = "来自地狱，侦探先生，抱歉，我寄给你我抢一个小朋友的棒棒糖的一半，另一半我吃掉了，味道非常好。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "EventItem_SUS_Event_52",
	NextID = 14414702,
}
StorySpeechConfig[StorySpeechID.Id14414702] =
{
	Id = 14414702,
	CharName = "挑衅信",
	Text = "如果你稍候一下的话，我可能会寄给你用来切棒棒糖的限量版的刀。如果办得到的话就来抓我吧，侦探先生。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "EventItem_SUS_Event_52",
	NextID = 14414703,
}
StorySpeechConfig[StorySpeechID.Id14414703] =
{
	Id = 14414703,
	CharName = "侦探助理",
	Text = "先生，那把刀也已经寄到了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_02_huasheng",
	NextID = 14414704,
}
StorySpeechConfig[StorySpeechID.Id14414704] =
{
	Id = 14414704,
	CharName = "作为凶器的刀",
	Text = "来自一个匿名包裹的切糖刀，上面还沾着草莓糖水。",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	LeftIcon = "Equipment_Sus_29_kaitangshoujieke_1",
	NextID = 14414705,
}
StorySpeechConfig[StorySpeechID.Id14414705] =
{
	Id = 14414705,
	CharName = "大侦探",
	Text = "（仔细端详，忽然打电话）你好，刀具公司吗？请问编号0378的40米长小刀的购买者是谁？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_01_fuermosi",
	NextID = 14414706,
}
StorySpeechConfig[StorySpeechID.Id14414706] =
{
	Id = 14414706,
	CharName = "电话那头",
	Text = "我们不能提供给你客户的信息，除非你证明你是受许可的用户。",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	LeftIcon = "Equipment_Sus_22_bianji_1",
	NextID = 14414707,
}
StorySpeechConfig[StorySpeechID.Id14414707] =
{
	Id = 14414707,
	CharName = "大侦探",
	Text = "我是大侦探，查询证号码是X-10920192。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_01_fuermosi",
	NextID = 14414708,
}
StorySpeechConfig[StorySpeechID.Id14414708] =
{
	Id = 14414708,
	CharName = "电话那头",
	Text = "抱歉，请稍等，先生。啊，是一位叫杰克的先生，登记地址是贝克街222号。",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	LeftIcon = "Equipment_Sus_22_bianji_1",
	NextID = 14414709,
}
StorySpeechConfig[StorySpeechID.Id14414709] =
{
	Id = 14414709,
	CharName = "大侦探",
	Text = "……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_01_fuermosi",
	NextID = 14414710,
}
StorySpeechConfig[StorySpeechID.Id14414710] =
{
	Id = 14414710,
	CharName = "电话那头",
	Text = "喂，先生，你还在听吗？",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	LeftIcon = "Equipment_Sus_22_bianji_1",
	NextID = 14414711,
}
StorySpeechConfig[StorySpeechID.Id14414711] =
{
	Id = 14414711,
	CharName = "大侦探",
	Text = "嗯，好的，多谢。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_01_fuermosi",
	NextID = 14414712,
}
StorySpeechConfig[StorySpeechID.Id14414712] =
{
	Id = 14414712,
	CharName = "侦探助理",
	Text = "查到线索了吗？要不要联系豆豆警官？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_02_huasheng",
	NextID = 14414713,
}
StorySpeechConfig[StorySpeechID.Id14414713] =
{
	Id = 14414713,
	CharName = "大侦探",
	Text = "不用了，我已经知道凶手在哪里了！（打开房间的壁橱）",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_01_fuermosi",
	NextID = 14414714,
}
StorySpeechConfig[StorySpeechID.Id14414714] =
{
	Id = 14414714,
	CharName = "杰克瑞波",
	Text = "Surprise！想不到被你看破了！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_29_kaitangshoujieke",
	NextID = 14414715,
}
StorySpeechConfig[StorySpeechID.Id14414715] =
{
	Id = 14414715,
	CharName = "大侦探",
	Text = "把我新买的针织衫还给我吧，杰克，你做的一切我都知道了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_01_fuermosi",
	NextID = 14414716,
}
StorySpeechConfig[StorySpeechID.Id14414716] =
{
	Id = 14414716,
	CharName = "杰克瑞波",
	Text = "！！你怎么知道是我拿了你的针织衫？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_29_kaitangshoujieke",
	NextID = 14414717,
}
StorySpeechConfig[StorySpeechID.Id14414717] =
{
	Id = 14414717,
	CharName = "大侦探",
	Text = "寄信者将带有唯一标识码的凶器寄给我，不是想隐藏身份，而是希望我打电话去道具公司查询刀的买主。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_01_fuermosi",
	NextID = 14414718,
}
StorySpeechConfig[StorySpeechID.Id14414718] =
{
	Id = 14414718,
	CharName = "大侦探",
	Text = "要查询买主必须具有查询资格，而通过电话我必须报出我的查询证号码。所以凶手其实是想窃取我的查询证号码。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_01_fuermosi",
	NextID = 14414719,
}
StorySpeechConfig[StorySpeechID.Id14414719] =
{
	Id = 14414719,
	CharName = "大侦探",
	Text = "我的查询号，除了查询信息，主要用处就是签收包裹。这件针织衫在网上竞拍，最后我赢了你，联想到你的做事风格，我知道你一定想用我的证件号确认收货。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_01_fuermosi",
	NextID = 14414720,
}
StorySpeechConfig[StorySpeechID.Id14414720] =
{
	Id = 14414720,
	CharName = "杰克瑞波",
	Text = "balabala~说那么多，来吧！想拿回你的拍卖品就打败我吧！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_29_kaitangshoujieke",
}
StorySpeechConfig[StorySpeechID.Id14414801] =
{
	Id = 14414801,
	CharName = "导演",
	Text = "终于到了面试第一反派的时刻了！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "SEA_Octupas1",
	NextID = 14414802,
}
StorySpeechConfig[StorySpeechID.Id14414802] =
{
	Id = 14414802,
	CharName = "场务",
	Text = "啊，导演，对方可是本星球最恐怖的男人之一，我们务必要谨慎面对啊。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_23_tiaojiushi_cos10",
	NextID = 14414803,
}
StorySpeechConfig[StorySpeechID.Id14414803] =
{
	Id = 14414803,
	CharName = "导演",
	Text = "那么试镜的对象是？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "SEA_Octupas1",
	NextID = 14414804,
}
StorySpeechConfig[StorySpeechID.Id14414804] =
{
	Id = 14414804,
	CharName = "场务",
	Text = "根据教授本人的要求，我已经请了朋克侦探的扮演者亲自来与教授试镜。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_23_tiaojiushi_cos10",
	NextID = 14414805,
}
StorySpeechConfig[StorySpeechID.Id14414805] =
{
	Id = 14414805,
	CharName = "导演",
	Text = "完美，那么开始吧！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "SEA_Octupas1",
	NextID = 14414806,
}
StorySpeechConfig[StorySpeechID.Id14414806] =
{
	Id = 14414806,
	CharName = "场务",
	Text = "请教授多多指教。今天试镜的剧情是……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_23_tiaojiushi_cos10",
	NextID = 14414807,
}
StorySpeechConfig[StorySpeechID.Id14414807] =
{
	Id = 14414807,
	CharName = "教授",
	Text = "不必告诉我了，请朋克侦探出场吧。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_03_moliyadi",
	NextID = 14414808,
}
StorySpeechConfig[StorySpeechID.Id14414808] =
{
	Id = 14414808,
	CharName = "场务",
	Text = "是，是，好的。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_23_tiaojiushi_cos10",
	NextID = 14414809,
}
StorySpeechConfig[StorySpeechID.Id14414809] =
{
	Id = 14414809,
	CharName = "朋克侦探",
	Text = "这次我们又是对手，教授。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_01_fuermosi_cos20",
	NextID = 14414810,
}
StorySpeechConfig[StorySpeechID.Id14414810] =
{
	Id = 14414810,
	CharName = "教授",
	Text = "嘿嘿嘿嘿，如果对手不是你，这种片子我可完全提不起兴致。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_03_moliyadi",
	NextID = 14414811,
}
StorySpeechConfig[StorySpeechID.Id14414811] =
{
	Id = 14414811,
	CharName = "朋克侦探",
	Text = "那我们今天比什么呢？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_01_fuermosi_cos20",
	NextID = 14414812,
}
StorySpeechConfig[StorySpeechID.Id14414812] =
{
	Id = 14414812,
	CharName = "教授",
	Text = "嘿嘿嘿嘿，如果你没有意见的话，我们就像过去那样比赛吧。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_03_moliyadi",
}
StorySpeechConfig[StorySpeechID.Id14414901] =
{
	Id = 14414901,
	CharName = "教授",
	Text = "定位完毕！枕头核弹来啦！！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_03_moliyadi",
	NextID = 14414902,
}
StorySpeechConfig[StorySpeechID.Id14414902] =
{
	Id = 14414902,
	CharName = "大侦探",
	Text = "哇，要是被这个击中，一定会被里面的绒毛弄得鼻敏感的！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_01_fuermosi",
	NextID = 14414903,
}
StorySpeechConfig[StorySpeechID.Id14414903] =
{
	Id = 14414903,
	CharName = "侦探助理",
	Text = "大侦探，我们赶紧躲到被子后面去！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_02_huasheng",
	NextID = 14414904,
}
StorySpeechConfig[StorySpeechID.Id14414904] =
{
	Id = 14414904,
	CharName = "教授",
	Text = "没这么容易的！我的新发明的招式——枕头集束攻击！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_03_moliyadi",
	NextID = 14414905,
}
StorySpeechConfig[StorySpeechID.Id14414905] =
{
	Id = 14414905,
	CharName = "大侦探",
	Text = "投降了，投降了！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_01_fuermosi",
	NextID = 14414906,
}
StorySpeechConfig[StorySpeechID.Id14414906] =
{
	Id = 14414906,
	CharName = "房东太太",
	Text = "（忽然开门）都给我住手！！！！！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_15_fangdongtaitai",
	NextID = 14414907,
}
StorySpeechConfig[StorySpeechID.Id14414907] =
{
	Id = 14414907,
	CharName = "教授",
	Text = "！！房东太太你不是去隔壁市参加伯爵先生的生日派对了吗！！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_03_moliyadi",
	NextID = 14414908,
}
StorySpeechConfig[StorySpeechID.Id14414908] =
{
	Id = 14414908,
	CharName = "房东太太",
	Text = "（一把拽下教授的兔耳睡衣）现场来了个小学生，然后就发生命案，所以就取消了！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_15_fangdongtaitai",
	NextID = 14414909,
}
StorySpeechConfig[StorySpeechID.Id14414909] =
{
	Id = 14414909,
	CharName = "教授",
	Text = "又是小学生吗？似乎他遇上命案的概率比我还高了呢。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_03_moliyadi",
	NextID = 14414910,
}
StorySpeechConfig[StorySpeechID.Id14414910] =
{
	Id = 14414910,
	CharName = "房东太太",
	Text = "喂！说回你们！上次不是说好了，以后再也不搞睡衣派对了吗？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_15_fangdongtaitai",
	NextID = 14414911,
}
StorySpeechConfig[StorySpeechID.Id14414911] =
{
	Id = 14414911,
	CharName = "教授",
	Text = "上次说好的是，不在大侦探的房子里开派对了……我租的公寓没有说过……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_03_moliyadi",
	NextID = 14414912,
}
StorySpeechConfig[StorySpeechID.Id14414912] =
{
	Id = 14414912,
	CharName = "房东太太",
	Text = "和我玩文字游戏吗？那下个月租金翻倍，另外，睡衣我就没收了！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_15_fangdongtaitai",
	NextID = 14414913,
}
StorySpeechConfig[StorySpeechID.Id14414913] =
{
	Id = 14414913,
	CharName = "教授",
	Text = "……房东太太，你看，有UFO！（想要趁机抢回睡衣）",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_03_moliyadi",
	NextID = 14414914,
}
StorySpeechConfig[StorySpeechID.Id14414914] =
{
	Id = 14414914,
	CharName = "房东太太",
	Text = "想抢？没门！看来要给你点颜色看看了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_15_fangdongtaitai",
}
StorySpeechConfig[StorySpeechID.Id14415001] =
{
	Id = 14415001,
	CharName = "教授",
	Text = "（引爆实验室大门）BOOM！！呼，终于进来了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_03_moliyadi",
	NextID = 14415002,
}
StorySpeechConfig[StorySpeechID.Id14415002] =
{
	Id = 14415002,
	CharName = "研究所负责人",
	Text = "喂！你是谁！这里很危险！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_03_moliyadi_cos30",
	NextID = 14415003,
}
StorySpeechConfig[StorySpeechID.Id14415003] =
{
	Id = 14415003,
	CharName = "教授",
	Text = "呼呼~我当然知道很危险~我还知道这里可能有我要的东西呢~",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_03_moliyadi",
	NextID = 14415004,
}
StorySpeechConfig[StorySpeechID.Id14415004] =
{
	Id = 14415004,
	CharName = "研究所负责人",
	Text = "保卫室，保卫室！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_03_moliyadi_cos30",
	NextID = 14415005,
}
StorySpeechConfig[StorySpeechID.Id14415005] =
{
	Id = 14415005,
	CharName = "教授",
	Text = "不用呼叫了，我已经切断这里与外界的通讯了，费了不少功夫呢~",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_03_moliyadi",
	NextID = 14415006,
}
StorySpeechConfig[StorySpeechID.Id14415006] =
{
	Id = 14415006,
	CharName = "研究所负责人",
	Text = "你想做什么？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_03_moliyadi_cos30",
	NextID = 14415007,
}
StorySpeechConfig[StorySpeechID.Id14415007] =
{
	Id = 14415007,
	CharName = "教授",
	Text = "我打算前来接收你们正在研究的物质转换器。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_03_moliyadi",
	NextID = 14415008,
}
StorySpeechConfig[StorySpeechID.Id14415008] =
{
	Id = 14415008,
	CharName = "研究所负责人",
	Text = "那个已经移交当局了，你来晚了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_03_moliyadi_cos30",
	NextID = 14415009,
}
StorySpeechConfig[StorySpeechID.Id14415009] =
{
	Id = 14415009,
	CharName = "教授",
	Text = "什么！不是三天后才移送吗？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_03_moliyadi",
	NextID = 14415010,
}
StorySpeechConfig[StorySpeechID.Id14415010] =
{
	Id = 14415010,
	CharName = "研究所负责人",
	Text = "考虑到是去同一个地方，快递公司的卡车装货率只有50%，浪费了600块运输费实在太不划算，就让他们打包了一下一起送走了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_03_moliyadi_cos30",
	NextID = 14415011,
}
StorySpeechConfig[StorySpeechID.Id14415011] =
{
	Id = 14415011,
	CharName = "教授",
	Text = "研发经费总计150亿的科研产品，你们不怕出意外吗？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_03_moliyadi",
	NextID = 14415012,
}
StorySpeechConfig[StorySpeechID.Id14415012] =
{
	Id = 14415012,
	CharName = "研究所负责人",
	Text = "本来是不放心的，但是考虑到我这件最新全覆式高能防化服都要180亿一件了，就觉得也不会有太大的问题了。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_03_moliyadi_cos30",
	NextID = 14415013,
}
StorySpeechConfig[StorySpeechID.Id14415013] =
{
	Id = 14415013,
	CharName = "教授",
	Text = "你身上这件衣服比物质转换器还贵吗……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_03_moliyadi",
	NextID = 14415014,
}
StorySpeechConfig[StorySpeechID.Id14415014] =
{
	Id = 14415014,
	CharName = "研究所负责人",
	Text = "嗯，因为这件衣服内置了物质转换器，而且是轻量化的噢？哎呀……说漏嘴了……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_03_moliyadi_cos30",
	NextID = 14415015,
}
StorySpeechConfig[StorySpeechID.Id14415015] =
{
	Id = 14415015,
	CharName = "教授",
	Text = "先生，我现在命令你把衣服交出来，否则后果由你自己承担！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_03_moliyadi",
	NextID = 14415016,
}
StorySpeechConfig[StorySpeechID.Id14415016] =
{
	Id = 14415016,
	CharName = "研究所负责人",
	Text = "不可能！交出这件衣服，我这个月的奖金肯定会被扣掉的！你要的话就自己来拿吧！！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_03_moliyadi_cos30",
	NextID = 14415017,
}
StorySpeechConfig[StorySpeechID.Id14415017] =
{
	Id = 14415017,
	CharName = "教授",
	Text = "嘿嘿嘿嘿！那就别怪我不客气了！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_03_moliyadi",
}
StorySpeechConfig[StorySpeechID.Id14415101] =
{
	Id = 14415101,
	CharName = "部落酋长",
	Text = "呼！终于把奖池抽完了！！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_04_UnlockChief",
	NextID = 14415102,
}
StorySpeechConfig[StorySpeechID.Id14415102] =
{
	Id = 14415102,
	CharName = "史莱姆大王",
	Text = "耶~太好了~~我也可以去度假了~",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPDraw_01_SlimeKing",
	NextID = 14415103,
}
StorySpeechConfig[StorySpeechID.Id14415103] =
{
	Id = 14415103,
	CharName = "部落酋长",
	Text = "嘿嘿，我一共抽了多少发。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_04_UnlockChief",
	NextID = 14415104,
}
StorySpeechConfig[StorySpeechID.Id14415104] =
{
	Id = 14415104,
	CharName = "史莱姆大王",
	Text = "我数到50万次以后就没有再数了。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPDraw_01_SlimeKing",
	NextID = 14415105,
}
StorySpeechConfig[StorySpeechID.Id14415105] =
{
	Id = 14415105,
	CharName = "部落酋长",
	Text = "那么现在我把奖品退给你，你把我的钱退给我吧。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_04_UnlockChief",
	NextID = 14415106,
}
StorySpeechConfig[StorySpeechID.Id14415106] =
{
	Id = 14415106,
	CharName = "史莱姆大王",
	Text = "这怎么可以，客人！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPDraw_01_SlimeKing",
	NextID = 14415107,
}
StorySpeechConfig[StorySpeechID.Id14415107] =
{
	Id = 14415107,
	CharName = "部落酋长",
	Text = "怎么，不能退吗？这些钱我还要拿去抽下一个奖池的。再说，你好意思赚我这么多钱？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_04_UnlockChief",
	NextID = 14415108,
}
StorySpeechConfig[StorySpeechID.Id14415108] =
{
	Id = 14415108,
	CharName = "史莱姆大王",
	Text = "不和你说了，我要赶紧去赶飞船了。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPDraw_01_SlimeKing",
	NextID = 14415109,
}
StorySpeechConfig[StorySpeechID.Id14415109] =
{
	Id = 14415109,
	CharName = "部落酋长",
	Text = "不行，今天你不把钱退给我，你就别想去度假了！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_04_UnlockChief",
}
StorySpeechConfig[StorySpeechID.Id14415201] =
{
	Id = 14415201,
	CharName = "部落酋长",
	Text = "呼！终于把奖池抽完了！！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_04_UnlockChief",
	NextID = 14415202,
}
StorySpeechConfig[StorySpeechID.Id14415202] =
{
	Id = 14415202,
	CharName = "精灵王子",
	Text = "干杯！终于也轮到我去度假了~",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPDraw_02_ElvenPrince",
	NextID = 14415203,
}
StorySpeechConfig[StorySpeechID.Id14415203] =
{
	Id = 14415203,
	CharName = "部落酋长",
	Text = "嘿嘿，我一共抽了多少发。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_04_UnlockChief",
	NextID = 14415204,
}
StorySpeechConfig[StorySpeechID.Id14415204] =
{
	Id = 14415204,
	CharName = "精灵王子",
	Text = "大概500万次左右吧，后来就没数了。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPDraw_02_ElvenPrince",
	NextID = 14415205,
}
StorySpeechConfig[StorySpeechID.Id14415205] =
{
	Id = 14415205,
	CharName = "部落酋长",
	Text = "那么现在我把奖品退给你，你把我的钱退给我吧。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_04_UnlockChief",
	NextID = 14415206,
}
StorySpeechConfig[StorySpeechID.Id14415206] =
{
	Id = 14415206,
	CharName = "精灵王子",
	Text = "-_-||客人，不夜城从来没有人提这种要求的。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPDraw_02_ElvenPrince",
	NextID = 14415207,
}
StorySpeechConfig[StorySpeechID.Id14415207] =
{
	Id = 14415207,
	CharName = "部落酋长",
	Text = "凡事都有第一次嘛~这些钱我还要拿去抽下一个奖池的。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_04_UnlockChief",
	NextID = 14415208,
}
StorySpeechConfig[StorySpeechID.Id14415208] =
{
	Id = 14415208,
	CharName = "精灵王子",
	Text = "不和你说了，我要赶紧去赶飞船了。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPDraw_02_ElvenPrince",
	NextID = 14415209,
}
StorySpeechConfig[StorySpeechID.Id14415209] =
{
	Id = 14415209,
	CharName = "部落酋长",
	Text = "不行，今天你不把钱退给我，你就别想去度假了！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_04_UnlockChief",
}
StorySpeechConfig[StorySpeechID.Id14415301] =
{
	Id = 14415301,
	CharName = "部落酋长",
	Text = "女王大人~~~您的冬季节包裹送到了~~~",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_04_UnlockChief",
	NextID = 14415302,
}
StorySpeechConfig[StorySpeechID.Id14415302] =
{
	Id = 14415302,
	CharName = "玉璧女王",
	Text = "Yes！冬季节的裙子到了~诶！话说，客人到现在还在不夜城打工还债吗？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPDraw_03_DiamondQueen",
	NextID = 14415303,
}
StorySpeechConfig[StorySpeechID.Id14415303] =
{
	Id = 14415303,
	CharName = "部落酋长",
	Text = "已经只欠5亿多了吧。诶，包裹里是什么？沉甸甸的。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_04_UnlockChief",
	NextID = 14415304,
}
StorySpeechConfig[StorySpeechID.Id14415304] =
{
	Id = 14415304,
	CharName = "玉璧女王",
	Text = "马上就到冬季节了，是冬季节的特殊服装噢~~",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPDraw_03_DiamondQueen",
	NextID = 14415305,
}
StorySpeechConfig[StorySpeechID.Id14415305] =
{
	Id = 14415305,
	CharName = "部落酋长",
	Text = "那，今天抽奖有特惠吗？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_04_UnlockChief",
	NextID = 14415306,
}
StorySpeechConfig[StorySpeechID.Id14415306] =
{
	Id = 14415306,
	CharName = "玉璧女王",
	Text = "Yes！今天有充满10发打9折的优惠噢~客人。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPDraw_03_DiamondQueen",
	NextID = 14415307,
}
StorySpeechConfig[StorySpeechID.Id14415307] =
{
	Id = 14415307,
	CharName = "部落酋长",
	Text = "要抽10发啊……可是没有玉璧啊，连抽一发的玉璧都没有了。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_04_UnlockChief",
	NextID = 14415308,
}
StorySpeechConfig[StorySpeechID.Id14415308] =
{
	Id = 14415308,
	CharName = "玉璧女王",
	Text = "那就没有办法咯~",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPDraw_03_DiamondQueen",
	NextID = 14415309,
}
StorySpeechConfig[StorySpeechID.Id14415309] =
{
	Id = 14415309,
	CharName = "部落酋长",
	Text = "啊呀，手真痒啊，感觉今天抽的话运气一定很不错呢。让我免费抽1000个十连吧，女王。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_04_UnlockChief",
	NextID = 14415310,
}
StorySpeechConfig[StorySpeechID.Id14415310] =
{
	Id = 14415310,
	CharName = "玉璧女王",
	Text = "-_-||客人，不夜城从来没有人提这种要求的。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPDraw_03_DiamondQueen",
	NextID = 14415311,
}
StorySpeechConfig[StorySpeechID.Id14415311] =
{
	Id = 14415311,
	CharName = "部落酋长",
	Text = "凡事都有第一次嘛~你要是不给我抽，这个包裹我就不给你噢~",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_04_UnlockChief",
	NextID = 14415312,
}
StorySpeechConfig[StorySpeechID.Id14415312] =
{
	Id = 14415312,
	CharName = "玉璧女王",
	Text = "竟然威胁我，你这个月的快递服务我要给一星差评！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPDraw_03_DiamondQueen",
	NextID = 14415313,
}
StorySpeechConfig[StorySpeechID.Id14415313] =
{
	Id = 14415313,
	CharName = "部落酋长",
	Text = "哇！从来没见过你这么过分的人，1000个十连都不让抽，今天我跟你拼了！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_04_UnlockChief",
}
StorySpeechConfig[StorySpeechID.Id14415401] =
{
	Id = 14415401,
	CharName = "玉璧女王",
	Text = "这次不夜城周年庆邀请到了大量外星来宾，大家都要想点点子来活跃气氛噢~",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_03_DiamondQueen",
	NextID = 14415402,
}
StorySpeechConfig[StorySpeechID.Id14415402] =
{
	Id = 14415402,
	CharName = "史莱姆大王",
	Text = "我可以表演一口吃掉初级金币池~",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPDraw_01_SlimeKing",
	NextID = 14415403,
}
StorySpeechConfig[StorySpeechID.Id14415403] =
{
	Id = 14415403,
	CharName = "精灵王子",
	Text = "我可以表演精彩的射箭技巧。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_02_ElvenPrince",
	NextID = 14415404,
}
StorySpeechConfig[StorySpeechID.Id14415404] =
{
	Id = 14415404,
	CharName = "玉璧女王",
	Text = "那个没什么意思，再想点有意思的。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPDraw_03_DiamondQueen",
	NextID = 14415405,
}
StorySpeechConfig[StorySpeechID.Id14415405] =
{
	Id = 14415405,
	CharName = "精灵王子",
	Text = "那我可以给嘉宾们做发型。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_02_ElvenPrince",
	NextID = 14415406,
}
StorySpeechConfig[StorySpeechID.Id14415406] =
{
	Id = 14415406,
	CharName = "玉璧女王",
	Text = "Yes！这个好。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPDraw_03_DiamondQueen",
	NextID = 14415407,
}
StorySpeechConfig[StorySpeechID.Id14415407] =
{
	Id = 14415407,
	CharName = "部落酋长",
	Text = "我可以表演1000发10连抽不出角色。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_04_UnlockChief",
	NextID = 14415408,
}
StorySpeechConfig[StorySpeechID.Id14415408] =
{
	Id = 14415408,
	CharName = "玉璧女王",
	Text = "这个影响太恶劣了，不知道你运气差的，人家还以为我们不夜城抽奖作弊呢。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPDraw_03_DiamondQueen",
	NextID = 14415409,
}
StorySpeechConfig[StorySpeechID.Id14415409] =
{
	Id = 14415409,
	CharName = "部落酋长",
	Text = "那我可以表演打碟，而且我打碟可以提供回复和加速效果！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_04_UnlockChief",
	NextID = 14415410,
}
StorySpeechConfig[StorySpeechID.Id14415410] =
{
	Id = 14415410,
	CharName = "玉璧女王",
	Text = "噢？酋长先生还会打碟啊，那为了烘托气氛，你就负责打碟吧~~",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPDraw_03_DiamondQueen",
	NextID = 14415411,
}
StorySpeechConfig[StorySpeechID.Id14415411] =
{
	Id = 14415411,
	CharName = "偶像歌手",
	Text = "不行！不是已经请我演唱流行音乐了吗？怎么又要搞电音了？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_15_peiyinyanyuan_cos10",
	NextID = 14415412,
}
StorySpeechConfig[StorySpeechID.Id14415412] =
{
	Id = 14415412,
	CharName = "玉璧女王",
	Text = "诶……本来不知道酋长先生还会打碟，不过现在看来确实打碟更适合场馆气氛。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPDraw_03_DiamondQueen",
	NextID = 14415413,
}
StorySpeechConfig[StorySpeechID.Id14415413] =
{
	Id = 14415413,
	CharName = "偶像歌手",
	Text = "不行！今天有我没他！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_15_peiyinyanyuan_cos10",
}
StorySpeechConfig[StorySpeechID.Id14415501] =
{
	Id = 14415501,
	CharName = "村长",
	Text = "Ladies and gentlemen~又到了本星球最隆重的颁奖典礼之一菜鸟节~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye",
	NextID = 14415502,
}
StorySpeechConfig[StorySpeechID.Id14415502] =
{
	Id = 14415502,
	CharName = "剑士-0杀75死",
	Text = "（鼓掌）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 14415503,
}
StorySpeechConfig[StorySpeechID.Id14415503] =
{
	Id = 14415503,
	CharName = "弓箭手-0杀189死1助攻",
	Text = "（鼓掌）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_24_gongjianshou",
	NextID = 14415504,
}
StorySpeechConfig[StorySpeechID.Id14415504] =
{
	Id = 14415504,
	CharName = "牧师-0杀452死175助攻",
	Text = "（鼓掌）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_07_mushi",
	NextID = 14415505,
}
StorySpeechConfig[StorySpeechID.Id14415505] =
{
	Id = 14415505,
	CharName = "叶姬-无战绩",
	Text = "（鼓掌）",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_01_yeji",
	NextID = 14415506,
}
StorySpeechConfig[StorySpeechID.Id14415506] =
{
	Id = 14415506,
	CharName = "村长",
	Text = "接下来请各位候选人诉说一下今年的最菜行为~首先有请剑士~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye",
	NextID = 14415507,
}
StorySpeechConfig[StorySpeechID.Id14415507] =
{
	Id = 14415507,
	CharName = "剑士-0杀75死",
	Text = "哇~那我先来，我今年一只怪也没有拉住噢~~队里的法师已经把我拉黑了呢~~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 14415508,
}
StorySpeechConfig[StorySpeechID.Id14415508] =
{
	Id = 14415508,
	CharName = "村长",
	Text = "哇，一次也没拉住怪真是厉害了，真的是太菜了！那下一个？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye",
	NextID = 14415509,
}
StorySpeechConfig[StorySpeechID.Id14415509] =
{
	Id = 14415509,
	CharName = "弓箭手-0杀189死1助攻",
	Text = "大家好~~我今年还没射中过怪物~~有一箭射歪了，还帮小魔王干掉了我们队的刺客咧~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_24_gongjianshou",
	NextID = 14415510,
}
StorySpeechConfig[StorySpeechID.Id14415510] =
{
	Id = 14415510,
	CharName = "村长",
	Text = "哇！这个更厉害，不干怪物，干自己人，哇，真是冒险星的无间道啊~那下一个轮到牧师了吧~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye",
	NextID = 14415511,
}
StorySpeechConfig[StorySpeechID.Id14415511] =
{
	Id = 14415511,
	CharName = "牧师-0杀452死175助攻",
	Text = "啊，好害羞，大家好……我是牧师……很抱歉，因为操作不来，这两年下副本的时候一直都在给怪物加血……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_07_mushi",
	NextID = 14415512,
}
StorySpeechConfig[StorySpeechID.Id14415512] =
{
	Id = 14415512,
	CharName = "剑士-0杀75死",
	Text = "……怪不得觉得怪的血厚得不得了……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 14415513,
}
StorySpeechConfig[StorySpeechID.Id14415513] =
{
	Id = 14415513,
	CharName = "弓箭手-0杀189死1助攻",
	Text = "……那看来我射不射中影响也不是很大了……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_24_gongjianshou",
	NextID = 14415514,
}
StorySpeechConfig[StorySpeechID.Id14415514] =
{
	Id = 14415514,
	CharName = "叶姬",
	Text = "……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_01_yeji",
	NextID = 14415515,
}
StorySpeechConfig[StorySpeechID.Id14415515] =
{
	Id = 14415515,
	CharName = "村长",
	Text = "虽然大家今年都表现得已经非常菜了，不过今年有来自模拟经营游戏的新人加入，所以大家能不能发扬风格把奖项让给她？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye",
	NextID = 14415516,
}
StorySpeechConfig[StorySpeechID.Id14415516] =
{
	Id = 14415516,
	CharName = "剑士-0杀75死",
	Text = "我不服！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi",
	NextID = 14415517,
}
StorySpeechConfig[StorySpeechID.Id14415517] =
{
	Id = 14415517,
	CharName = "弓箭手-0杀189死1助攻",
	Text = "我也不服！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_24_gongjianshou",
	NextID = 14415518,
}
StorySpeechConfig[StorySpeechID.Id14415518] =
{
	Id = 14415518,
	CharName = "牧师-0杀452死175助攻",
	Text = "啊，啊， 好害羞，但是，我也不服！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_07_mushi",
	NextID = 14415519,
}
StorySpeechConfig[StorySpeechID.Id14415519] =
{
	Id = 14415519,
	CharName = "叶姬",
	Text = "……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_01_yeji",
}
StorySpeechConfig[StorySpeechID.Id14415601] =
{
	Id = 14415601,
	CharName = "桃几小姐",
	Text = "哈罗哈罗~玩家最近一直在问，有没有新的活动~",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_02_taozi",
	NextID = 14415602,
}
StorySpeechConfig[StorySpeechID.Id14415602] =
{
	Id = 14415602,
	CharName = "美术妹子",
	Text = "最近在画新Icon，没时间搞新活动了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_03_yuanhuameizi",
	NextID = 14415603,
}
StorySpeechConfig[StorySpeechID.Id14415603] =
{
	Id = 14415603,
	CharName = "策划",
	Text = "最近在设计新的系统，没时间搞新活动了。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_men2",
	NextID = 14415604,
}
StorySpeechConfig[StorySpeechID.Id14415604] =
{
	Id = 14415604,
	CharName = "程序猿",
	Text = "最近在修Bug，修完Bug还要做新系统，没时间搞新活动了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_01_chengxuyuan",
	NextID = 14415605,
}
StorySpeechConfig[StorySpeechID.Id14415605] =
{
	Id = 14415605,
	CharName = "桃几小姐",
	Text = "诶？这样很难向玩家们交代诶。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_02_taozi",
	NextID = 14415606,
}
StorySpeechConfig[StorySpeechID.Id14415606] =
{
	Id = 14415606,
	CharName = "美术妹子",
	Text = "有么有什么办法不增加新资源，就搞个新活动出来呢？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_03_yuanhuameizi",
	NextID = 14415607,
}
StorySpeechConfig[StorySpeechID.Id14415607] =
{
	Id = 14415607,
	CharName = "策划",
	Text = "这个想法好！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_men2",
	NextID = 14415608,
}
StorySpeechConfig[StorySpeechID.Id14415608] =
{
	Id = 14415608,
	CharName = "程序猿",
	Text = "举脚赞成！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_01_chengxuyuan",
	NextID = 14415609,
}
StorySpeechConfig[StorySpeechID.Id14415609] =
{
	Id = 14415609,
	CharName = "桃几小姐",
	Text = "诶！这要怎么搞啊？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_02_taozi",
	NextID = 14415610,
}
StorySpeechConfig[StorySpeechID.Id14415610] =
{
	Id = 14415610,
	CharName = "美术妹子",
	Text = "不如由桃几小姐来表演节目吧~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_03_yuanhuameizi",
	NextID = 14415611,
}
StorySpeechConfig[StorySpeechID.Id14415611] =
{
	Id = 14415611,
	CharName = "程序猿",
	Text = "那表演什么节目呢？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_01_chengxuyuan",
	NextID = 14415612,
}
StorySpeechConfig[StorySpeechID.Id14415612] =
{
	Id = 14415612,
	CharName = "策划",
	Text = "上次楼下的水果店送了我们很多招牌黄桃，让我们有空帮忙打打广告，不如就用黄桃换装吧？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_men2",
	NextID = 14415613,
}
StorySpeechConfig[StorySpeechID.Id14415613] =
{
	Id = 14415613,
	CharName = "桃几小姐",
	Text = "诶……那好吧……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_02_taozi",
	NextID = 14415614,
}
StorySpeechConfig[StorySpeechID.Id14415614] =
{
	Id = 14415614,
	CharName = "策划",
	Text = "不过那些黄桃被公司养的点点霸占着，你要先搞定它！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_men2",
	NextID = 14415615,
}
StorySpeechConfig[StorySpeechID.Id14415615] =
{
	Id = 14415615,
	CharName = "桃几小姐",
	Text = "……以后我不来问你们新活动的事情了……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_02_taozi",
}
StorySpeechConfig[StorySpeechID.Id14415701] =
{
	Id = 14415701,
	CharName = "圣骑士",
	Text = "师傅……我觉得当圣骑士好苦……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_101_Paladin",
	NextID = 14415702,
}
StorySpeechConfig[StorySpeechID.Id14415702] =
{
	Id = 14415702,
	CharName = "圣骑士导师",
	Text = "这是错觉，是恶魔为了迷惑你而对你施加的邪术，来，我们再念一遍祷文，徒弟。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye_cos10",
	NextID = 14415703,
}
StorySpeechConfig[StorySpeechID.Id14415703] =
{
	Id = 14415703,
	CharName = "圣骑士",
	Text = "师傅，可是我们为什么要承受这么多苦难呢？其实……我也想拥有，力量！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_101_Paladin",
	NextID = 14415704,
}
StorySpeechConfig[StorySpeechID.Id14415704] =
{
	Id = 14415704,
	CharName = "圣骑士导师",
	Text = "（整个人跳起来）住口！住口！你在说什么恶魔语！我要罚你用这根蘸了指天椒辣油的鞭子鞭笞自己！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye_cos10",
	NextID = 14415705,
}
StorySpeechConfig[StorySpeechID.Id14415705] =
{
	Id = 14415705,
	CharName = "圣骑士",
	Text = "……师傅，我们只是在冒险游戏的世界里，要这么认真吗……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_101_Paladin",
	NextID = 14415706,
}
StorySpeechConfig[StorySpeechID.Id14415706] =
{
	Id = 14415706,
	CharName = "圣骑士导师",
	Text = "孽障！你怎么敢如此自大，既然选择了圣骑士作为我们的职业，我们当然要全心地奉献我们的主！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye_cos10",
	NextID = 14415707,
}
StorySpeechConfig[StorySpeechID.Id14415707] =
{
	Id = 14415707,
	CharName = "系统公告",
	Text = "特大消息！新职业-死亡骑士已上线，属性成长+20%，全新天赋同步上线！",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	LeftIcon = "Equipment_SPBUS_02_taozi_2",
	NextID = 14415708,
}
StorySpeechConfig[StorySpeechID.Id14415708] =
{
	Id = 14415708,
	CharName = "圣骑士",
	Text = "（认真听取）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_101_Paladin",
	NextID = 14415709,
}
StorySpeechConfig[StorySpeechID.Id14415709] =
{
	Id = 14415709,
	CharName = "圣骑士导师",
	Text = "太可怕了！这个世界上竟然会有如此堕落的职业，你听听这个名字……喂！别停手，继续用力抽打自己！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye_cos10",
	NextID = 14415710,
}
StorySpeechConfig[StorySpeechID.Id14415710] =
{
	Id = 14415710,
	CharName = "圣骑士",
	Text = "……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_101_Paladin",
	NextID = 14415711,
}
StorySpeechConfig[StorySpeechID.Id14415711] =
{
	Id = 14415711,
	CharName = "系统公告",
	Text = "惊爆消息又来啦！策划宣布，死亡骑士将拥有专属的魂器系统，特效夸张，让每一个有你的画面都卡顿无比！",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	LeftIcon = "Equipment_SPBUS_02_taozi_2",
	NextID = 14415712,
}
StorySpeechConfig[StorySpeechID.Id14415712] =
{
	Id = 14415712,
	CharName = "圣骑士导师",
	Text = "荒唐！愚蠢！怎么可能会有人为了这种虚无缥缈的事物，就去选择这个恶魔的职业！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye_cos10",
	NextID = 14415713,
}
StorySpeechConfig[StorySpeechID.Id14415713] =
{
	Id = 14415713,
	CharName = "圣骑士",
	Text = "……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_101_Paladin",
	NextID = 14415714,
}
StorySpeechConfig[StorySpeechID.Id14415714] =
{
	Id = 14415714,
	CharName = "系统公告",
	Text = "超重磅消息最终发布！！！死亡骑士专属坐骑——死亡梦魇现已同步上线，踏着黑色迷雾的地狱狂兽，现在转职将直接获得！",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	RightIcon = "Equipment_SPBUS_02_taozi_2",
	NextID = 14415715,
}
StorySpeechConfig[StorySpeechID.Id14415715] =
{
	Id = 14415715,
	CharName = "圣骑士",
	Text = "师傅！我申请还俗，我想去当死亡骑士！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_101_Paladin",
	NextID = 14415716,
}
StorySpeechConfig[StorySpeechID.Id14415716] =
{
	Id = 14415716,
	CharName = "圣骑士导师",
	Text = "孽畜！！！你在说什么！！今天，我就要把你打死在这里！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye_cos10",
	NextID = 14415717,
}
StorySpeechConfig[StorySpeechID.Id14415717] =
{
	Id = 14415717,
	CharName = "圣骑士",
	Text = "师傅，请成全我，我不想与你为敌。而且，就算你打赢我一次，我也会一次又一次地再来挑战你的。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_101_Paladin",
	NextID = 14415718,
}
StorySpeechConfig[StorySpeechID.Id14415718] =
{
	Id = 14415718,
	CharName = "圣骑士导师",
	Text = "（怒不可遏）哇！这种大逆不道的话你都敢说，今天谁都别拦我，我一定要让你灰飞烟灭！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye_cos10",
	NextID = 14415719,
}
StorySpeechConfig[StorySpeechID.Id14415719] =
{
	Id = 14415719,
	CharName = "圣骑士",
	Text = "……师傅……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_101_Paladin",
}
StorySpeechConfig[StorySpeechID.Id14415801] =
{
	Id = 14415801,
	CharName = "野蛮人",
	Text = "已经5天了……我们还要等下去吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_102_Barbarian",
	NextID = 14415802,
}
StorySpeechConfig[StorySpeechID.Id14415802] =
{
	Id = 14415802,
	CharName = "雄鹰氏族",
	Text = "我已经和族长说好了，只要你能带一只兔子回去，就是我们部族的人了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_102_Barbarian_cos10",
	NextID = 14415803,
}
StorySpeechConfig[StorySpeechID.Id14415803] =
{
	Id = 14415803,
	CharName = "野蛮人",
	Text = "现在到处都提倡保护野生动物，哪里还有兔子啊……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_102_Barbarian",
	NextID = 14415804,
}
StorySpeechConfig[StorySpeechID.Id14415804] =
{
	Id = 14415804,
	CharName = "雄鹰氏族",
	Text = "诶……本地兔子确实灭绝了，不过根据情报，最近来这里的外星观光团里有兔子。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_102_Barbarian_cos10",
	NextID = 14415805,
}
StorySpeechConfig[StorySpeechID.Id14415805] =
{
	Id = 14415805,
	CharName = "野蛮人",
	Text = "可是都已经等了5天了……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_102_Barbarian",
	NextID = 14415806,
}
StorySpeechConfig[StorySpeechID.Id14415806] =
{
	Id = 14415806,
	CharName = "雄鹰氏族",
	Text = "不要急嘛~~你还要不要加入我们氏族？你还想自己一个人在森林里过？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_102_Barbarian_cos10",
	NextID = 14415807,
}
StorySpeechConfig[StorySpeechID.Id14415807] =
{
	Id = 14415807,
	CharName = "野蛮人",
	Text = "唔……不想……那好吧。可是他如果一直不来怎么办？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_102_Barbarian",
	NextID = 14415808,
}
StorySpeechConfig[StorySpeechID.Id14415808] =
{
	Id = 14415808,
	CharName = "雄鹰氏族",
	Text = "嘘！有人来了，你看到那对兔子耳朵了吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_102_Barbarian_cos10",
	NextID = 14415809,
}
StorySpeechConfig[StorySpeechID.Id14415809] =
{
	Id = 14415809,
	CharName = "外星的兔游客",
	Text = "哇，冒险星的空气果然和悬疑星不一样呢~~逃课来这里玩果然没错~~",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_03_moliyadi_cos20",
	NextID = 14415810,
}
StorySpeechConfig[StorySpeechID.Id14415810] =
{
	Id = 14415810,
	CharName = "雄鹰氏族",
	Text = "好了，就看这次，你快上，把他打晕，我给你们拍个合影，你就是雄鹰氏族的人了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_102_Barbarian_cos10",
	NextID = 14415811,
}
StorySpeechConfig[StorySpeechID.Id14415811] =
{
	Id = 14415811,
	CharName = "野蛮人",
	Text = "呀！！！那我上啦！！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_102_Barbarian",
	NextID = 14415812,
}
StorySpeechConfig[StorySpeechID.Id14415812] =
{
	Id = 14415812,
	CharName = "外星的兔游客",
	Text = "嚯！你们要干嘛！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_03_moliyadi_cos20",
}
StorySpeechConfig[StorySpeechID.Id14415901] =
{
	Id = 14415901,
	CharName = "小犬星",
	Text = "嘿嘿，又得手了~这次是，我数一下，14颗天泪宝石，这下可要叫伯爵先生肉痛一把了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_103_Thief_cat",
	NextID = 14415902,
}
StorySpeechConfig[StorySpeechID.Id14415902] =
{
	Id = 14415902,
	CharName = "盗贼",
	Text = "……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_103_Thief",
	NextID = 14415903,
}
StorySpeechConfig[StorySpeechID.Id14415903] =
{
	Id = 14415903,
	CharName = "小犬星",
	Text = "怎么了？受伤了？快让我看看。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_103_Thief_cat",
	NextID = 14415904,
}
StorySpeechConfig[StorySpeechID.Id14415904] =
{
	Id = 14415904,
	CharName = "盗贼",
	Text = "我没事。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_103_Thief",
	NextID = 14415905,
}
StorySpeechConfig[StorySpeechID.Id14415905] =
{
	Id = 14415905,
	CharName = "小犬星",
	Text = "我说呢，你身手这么好，怎么会受伤。怎么了？为什么不高兴？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_103_Thief_cat",
	NextID = 14415906,
}
StorySpeechConfig[StorySpeechID.Id14415906] =
{
	Id = 14415906,
	CharName = "盗贼",
	Text = "我有点厌倦了，师兄。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_103_Thief",
	NextID = 14415907,
}
StorySpeechConfig[StorySpeechID.Id14415907] =
{
	Id = 14415907,
	CharName = "小犬星",
	Text = "说什么胡话？这话让长老们听到，你的手指就该被拗断了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_103_Thief_cat",
	NextID = 14415908,
}
StorySpeechConfig[StorySpeechID.Id14415908] =
{
	Id = 14415908,
	CharName = "盗贼",
	Text = "但是我真的厌倦了，师兄。你知道的，我想去更多地方看看，不想再偷东西了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_103_Thief",
	NextID = 14415909,
}
StorySpeechConfig[StorySpeechID.Id14415909] =
{
	Id = 14415909,
	CharName = "小犬星",
	Text = "不要再说了！我要生气了，你今天的话我就当没有听过。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_103_Thief_cat",
	NextID = 14415910,
}
StorySpeechConfig[StorySpeechID.Id14415910] =
{
	Id = 14415910,
	CharName = "盗贼",
	Text = "可是……可是……师兄，这次回去，你告诉长老们，我已经死了，好吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_103_Thief",
	NextID = 14415911,
}
StorySpeechConfig[StorySpeechID.Id14415911] =
{
	Id = 14415911,
	CharName = "小犬星",
	Text = "是不是为了那个小妮子，伯爵的女儿？你骗了她，她永远不会原谅你的。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_103_Thief_cat",
	NextID = 14415912,
}
StorySpeechConfig[StorySpeechID.Id14415912] =
{
	Id = 14415912,
	CharName = "盗贼",
	Text = "我不想再欺骗善良的人了，我想给心爱的姑娘唱首歌或奏一曲。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_103_Thief",
	NextID = 14415913,
}
StorySpeechConfig[StorySpeechID.Id14415913] =
{
	Id = 14415913,
	CharName = "小犬星",
	Text = "当一个落魄的吟游诗人吗？像瘪三一样活着？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_103_Thief_cat",
	NextID = 14415914,
}
StorySpeechConfig[StorySpeechID.Id14415914] =
{
	Id = 14415914,
	CharName = "盗贼",
	Text = "如果您愿意成全，那对我来说就是最快乐的生活。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_103_Thief",
	NextID = 14415915,
}
StorySpeechConfig[StorySpeechID.Id14415915] =
{
	Id = 14415915,
	CharName = "小犬星",
	Text = "如果你能打败我，我就帮你撒谎，以后你就做你的瘪三去吧！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_103_Thief_cat",
	NextID = 14415916,
}
StorySpeechConfig[StorySpeechID.Id14415916] =
{
	Id = 14415916,
	CharName = "盗贼",
	Text = "如果我输了？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_103_Thief",
	NextID = 14415917,
}
StorySpeechConfig[StorySpeechID.Id14415917] =
{
	Id = 14415917,
	CharName = "小犬星",
	Text = "如果你输了，这辈子都不许再提这件事，连念头都不许动！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_103_Thief_cat",
	NextID = 14415918,
}
StorySpeechConfig[StorySpeechID.Id14415918] =
{
	Id = 14415918,
	CharName = "盗贼",
	Text = "……来吧，师兄！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_103_Thief",
}
StorySpeechConfig[StorySpeechID.Id14416001] =
{
	Id = 14416001,
	CharName = "村长",
	Text = "祭司长大人，你准备好了吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye",
	NextID = 14416002,
}
StorySpeechConfig[StorySpeechID.Id14416002] =
{
	Id = 14416002,
	CharName = "祭司长",
	Text = "啊，忘了联系巫女大人了……看来驱魔仪式要再推迟三天了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_27_donghua",
	NextID = 14416003,
}
StorySpeechConfig[StorySpeechID.Id14416003] =
{
	Id = 14416003,
	CharName = "村长",
	Text = "大人，我们这里骨头兵闹得厉害，请今天无论如何帮我们举行驱魔仪式吧。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye",
	NextID = 14416004,
}
StorySpeechConfig[StorySpeechID.Id14416004] =
{
	Id = 14416004,
	CharName = "祭司长",
	Text = "可是没有巫女大人，我也没有办法啊……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_27_donghua",
	NextID = 14416005,
}
StorySpeechConfig[StorySpeechID.Id14416005] =
{
	Id = 14416005,
	CharName = "村长",
	Text = "那能不能临时找一位巫女呢？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye",
	NextID = 14416006,
}
StorySpeechConfig[StorySpeechID.Id14416006] =
{
	Id = 14416006,
	CharName = "祭司长",
	Text = "驱魔书上倒是没说不可以，可是一时间去哪里找呢？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_27_donghua",
	NextID = 14416007,
}
StorySpeechConfig[StorySpeechID.Id14416007] =
{
	Id = 14416007,
	CharName = "村长",
	Text = "最近有位舞娘经过我们村子，村里的男冒险者们天天都去看她表演呢。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye",
	NextID = 14416008,
}
StorySpeechConfig[StorySpeechID.Id14416008] =
{
	Id = 14416008,
	CharName = "祭司长",
	Text = "噢~你说的是那位穿着粉色袍子长得超可爱的舞娘小姐吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_27_donghua",
	NextID = 14416009,
}
StorySpeechConfig[StorySpeechID.Id14416009] =
{
	Id = 14416009,
	CharName = "村长",
	Text = "……你是不是因为这两天一直看她表演，所以才没有准备驱魔仪式？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye",
	NextID = 14416010,
}
StorySpeechConfig[StorySpeechID.Id14416010] =
{
	Id = 14416010,
	CharName = "祭司长",
	Text = "诶……这种话怎么可以乱说，我只是从她曼妙的舞姿中寻找天启……好吧……是忘了……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_27_donghua",
	NextID = 14416011,
}
StorySpeechConfig[StorySpeechID.Id14416011] =
{
	Id = 14416011,
	CharName = "村长",
	Text = "那由这位小姐进行巫女神楽舞如何？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye",
	NextID = 14416012,
}
StorySpeechConfig[StorySpeechID.Id14416012] =
{
	Id = 14416012,
	CharName = "祭司长",
	Text = "完美！我这就去请她~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_27_donghua",
	NextID = 14416013,
}
StorySpeechConfig[StorySpeechID.Id14416013] =
{
	Id = 14416013,
	CharName = "舞娘",
	Text = "我已经到了~可以有幸为村里的驱魔仪式献一份力量吗？太好了~~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_104_DancingGirl",
	NextID = 14416014,
}
StorySpeechConfig[StorySpeechID.Id14416014] =
{
	Id = 14416014,
	CharName = "祭司长",
	Text = "不过要先清除一些骨头兵，看你是不是有足够的灵力。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_27_donghua",
	NextID = 14416015,
}
StorySpeechConfig[StorySpeechID.Id14416015] =
{
	Id = 14416015,
	CharName = "舞娘",
	Text = "好~~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_104_DancingGirl",
}
StorySpeechConfig[StorySpeechID.Id14416101] =
{
	Id = 14416101,
	CharName = "皇家学院第52任院长",
	Text = "亲爱的学生，今年你还是不打算毕业吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye_cos10",
	NextID = 14416102,
}
StorySpeechConfig[StorySpeechID.Id14416102] =
{
	Id = 14416102,
	CharName = "学者",
	Text = "尊敬的校长，学生希望能够永远徜徉在知识的海洋中。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_105_Scholar",
	NextID = 14416103,
}
StorySpeechConfig[StorySpeechID.Id14416103] =
{
	Id = 14416103,
	CharName = "皇家学院第52任院长",
	Text = "您已经拿了25个毕业证书了，学习的目的不是学习，而是为了创造和深入啊~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye_cos10",
	NextID = 14416104,
}
StorySpeechConfig[StorySpeechID.Id14416104] =
{
	Id = 14416104,
	CharName = "学者",
	Text = "可是……可是……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_105_Scholar",
	NextID = 14416105,
}
StorySpeechConfig[StorySpeechID.Id14416105] =
{
	Id = 14416105,
	CharName = "皇家学院第52任院长",
	Text = "我知道您已惯于和书本交流，但我们终究是要与人们交谈的。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye_cos10",
	NextID = 14416106,
}
StorySpeechConfig[StorySpeechID.Id14416106] =
{
	Id = 14416106,
	CharName = "学者",
	Text = "……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_105_Scholar",
	NextID = 14416107,
}
StorySpeechConfig[StorySpeechID.Id14416107] =
{
	Id = 14416107,
	CharName = "皇家学院第52任院长",
	Text = "你是我最优秀的学生之一，学术造诣非凡。我希望你能放眼世界，而不是躲在学院里。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye_cos10",
	NextID = 14416108,
}
StorySpeechConfig[StorySpeechID.Id14416108] =
{
	Id = 14416108,
	CharName = "学者",
	Text = "学生明白了，校长。请容我再拿下一个学位，至少是一门能为学生找到旅途知音的技能。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_105_Scholar",
	NextID = 14416109,
}
StorySpeechConfig[StorySpeechID.Id14416109] =
{
	Id = 14416109,
	CharName = "皇家学院第52任院长",
	Text = "我想动物语言学是不错的选择，在您低落时，百兽可以聆听您的心声。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye_cos10",
	NextID = 14416110,
}
StorySpeechConfig[StorySpeechID.Id14416110] =
{
	Id = 14416110,
	CharName = "学者",
	Text = "学生认为尚欠妥当，前年本人已经养下一只猫，不过最后它逃走了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_105_Scholar",
	NextID = 14416111,
}
StorySpeechConfig[StorySpeechID.Id14416111] =
{
	Id = 14416111,
	CharName = "皇家学院第52任院长",
	Text = "那么植物语言学呢？其实我年轻的时候有些话也是只和我家门前的枣树说的。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye_cos10",
	NextID = 14416112,
}
StorySpeechConfig[StorySpeechID.Id14416112] =
{
	Id = 14416112,
	CharName = "学者",
	Text = "本人曾略作尝试，但是对于没有任何反馈的谈话，还是有些失望。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_105_Scholar",
	NextID = 14416113,
}
StorySpeechConfig[StorySpeechID.Id14416113] =
{
	Id = 14416113,
	CharName = "皇家学院第52任院长",
	Text = "那就成了！只要攻克通灵学，从此以后寂寞旅程总有亡魂伴你身旁。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye_cos10",
	NextID = 14416114,
}
StorySpeechConfig[StorySpeechID.Id14416114] =
{
	Id = 14416114,
	CharName = "学者",
	Text = "一个既有感情又无法脱离我操控的倾诉对象？似乎是完美的选择，请允许完成这门课程。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_105_Scholar",
	NextID = 14416115,
}
StorySpeechConfig[StorySpeechID.Id14416115] =
{
	Id = 14416115,
	CharName = "皇家学院第52任院长",
	Text = "但是完成课程后你要立刻离开本院校。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye_cos10",
	NextID = 14416116,
}
StorySpeechConfig[StorySpeechID.Id14416116] =
{
	Id = 14416116,
	CharName = "学者",
	Text = "是的，弟子完成这门课程后就会立刻离开学院，开始自己的旅程。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_105_Scholar",
	NextID = 14416117,
}
StorySpeechConfig[StorySpeechID.Id14416117] =
{
	Id = 14416117,
	CharName = "皇家学院第52任院长",
	Text = "那我们直接考试吧！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye_cos10",
	NextID = 14416118,
}
StorySpeechConfig[StorySpeechID.Id14416118] =
{
	Id = 14416118,
	CharName = "学者",
	Text = "（吃惊！）这么仓促吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_105_Scholar",
	NextID = 14416119,
}
StorySpeechConfig[StorySpeechID.Id14416119] =
{
	Id = 14416119,
	CharName = "皇家学院第52任院长",
	Text = "来不及解释了，赶紧上吧！勇敢的少年！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye_cos10",
}
StorySpeechConfig[StorySpeechID.Id14416201] =
{
	Id = 14416201,
	CharName = "药师",
	Text = "呼，终于到达山顶了，哇，这就是灵药之石了~哎呀，这么大块，没带工具诶……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_106_Pharmacist",
	NextID = 14416202,
}
StorySpeechConfig[StorySpeechID.Id14416202] =
{
	Id = 14416202,
	CharName = "大石头",
	Text = "（这块巨大的石头浑身散发出吉祥的气息，似乎任何人看了它都会平和下来）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_dashitou",
	NextID = 14416203,
}
StorySpeechConfig[StorySpeechID.Id14416203] =
{
	Id = 14416203,
	CharName = "铁匠",
	Text = "呼，终于也到山顶了，哇，这么大块陨石，还好我带足了工具！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_31_tiejiang",
	NextID = 14416204,
}
StorySpeechConfig[StorySpeechID.Id14416204] =
{
	Id = 14416204,
	CharName = "药师",
	Text = "哇！你怎么也来了？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_106_Pharmacist",
	NextID = 14416205,
}
StorySpeechConfig[StorySpeechID.Id14416205] =
{
	Id = 14416205,
	CharName = "铁匠",
	Text = "诶？！这话应该我问你吧！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_31_tiejiang",
	NextID = 14416206,
}
StorySpeechConfig[StorySpeechID.Id14416206] =
{
	Id = 14416206,
	CharName = "药师",
	Text = "我是来寻求古籍中所说的灵药之石的，用这块石头做成的石锅，可以熬制出绝世灵药。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_106_Pharmacist",
	NextID = 14416207,
}
StorySpeechConfig[StorySpeechID.Id14416207] =
{
	Id = 14416207,
	CharName = "铁匠",
	Text = "我是来寻找古籍中所说的天外陨石的，用这块陨石制造的凿子，强化装备失败勇者也不会生气了。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_31_tiejiang",
	NextID = 14416208,
}
StorySpeechConfig[StorySpeechID.Id14416208] =
{
	Id = 14416208,
	CharName = "药师",
	Text = "我用这块灵石是救人的。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_106_Pharmacist",
	NextID = 14416209,
}
StorySpeechConfig[StorySpeechID.Id14416209] =
{
	Id = 14416209,
	CharName = "铁匠",
	Text = "我用这块灵石是救自己的！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_31_tiejiang",
	NextID = 14416210,
}
StorySpeechConfig[StorySpeechID.Id14416210] =
{
	Id = 14416210,
	CharName = "药师",
	Text = "要不然这样，我们一人拿走一半吧？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_106_Pharmacist",
	NextID = 14416211,
}
StorySpeechConfig[StorySpeechID.Id14416211] =
{
	Id = 14416211,
	CharName = "铁匠",
	Text = "嘿嘿，你好像没有带工具噢？想等我劈开陨石，然后你拖走另一半？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_31_tiejiang",
	NextID = 14416212,
}
StorySpeechConfig[StorySpeechID.Id14416212] =
{
	Id = 14416212,
	CharName = "药师",
	Text = "诶……可以吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_106_Pharmacist",
	NextID = 14416213,
}
StorySpeechConfig[StorySpeechID.Id14416213] =
{
	Id = 14416213,
	CharName = "铁匠",
	Text = "你说呢！立刻走，否则小心我锤爆你的狗头噢！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_31_tiejiang",
	NextID = 14416214,
}
StorySpeechConfig[StorySpeechID.Id14416214] =
{
	Id = 14416214,
	CharName = "药师",
	Text = "你太过分了，既然这样，得罪了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_106_Pharmacist",
}
StorySpeechConfig[StorySpeechID.Id14420701] =
{
	Id = 14420701,
	CharName = "术士",
	Text = "学长，有个问题想请教你一下，请问…",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_108_Warlock",
	NextID = 14420702,
}
StorySpeechConfig[StorySpeechID.Id14420702] =
{
	Id = 14420702,
	CharName = "死灵法师",
	Text = "嘿嘿嘿嘿，你不是全A进入学院的吗？区区在下还有什么可以指教你的，请你去找别人吧。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_105_Scholar_cos10",
	NextID = 14420703,
}
StorySpeechConfig[StorySpeechID.Id14420703] =
{
	Id = 14420703,
	CharName = "术士",
	Text = "嗯，嗯，好的，抱歉，打扰了。（垂头丧气）哎，为什么大家都不喜欢我呢？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_108_Warlock",
	NextID = 14420704,
}
StorySpeechConfig[StorySpeechID.Id14420704] =
{
	Id = 14420704,
	CharName = "黑洞",
	Text = "咻地一下吸走了术士",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	RightIcon = "RPG_Material_013",
	NextID = 14420705,
}
StorySpeechConfig[StorySpeechID.Id14420705] =
{
	Id = 14420705,
	CharName = "术士族长",
	Text = "各位，又到了每100年一次的觉醒仪式！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_108_Warlock_cos10",
	NextID = 14420706,
}
StorySpeechConfig[StorySpeechID.Id14420706] =
{
	Id = 14420706,
	CharName = "术士",
	Text = "咦，是光彩夺目的族长大人！哎，什么时候我才能像族长大人一样受欢迎啊？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_108_Warlock",
	NextID = 14420707,
}
StorySpeechConfig[StorySpeechID.Id14420707] =
{
	Id = 14420707,
	CharName = "术士族长",
	Text = "沉寂在各位体内的异族之血将在今天被唤醒，各位未来的人生即将面临重大的改变！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_108_Warlock_cos10",
	NextID = 14420708,
}
StorySpeechConfig[StorySpeechID.Id14420708] =
{
	Id = 14420708,
	CharName = "龙血术士",
	Text = "啊，好激动啊，不知道我是什么血统。会不会和族长大人是一样的幻兽血统呢？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_23_long",
	NextID = 14420709,
}
StorySpeechConfig[StorySpeechID.Id14420709] =
{
	Id = 14420709,
	CharName = "魔族术士",
	Text = "只要通过今天的考验，我就能够成为万众瞩目的对象了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 14420710,
}
StorySpeechConfig[StorySpeechID.Id14420710] =
{
	Id = 14420710,
	CharName = "江湖术士",
	Text = "嘿嘿嘿嘿，只要通过今天的考验，我就可以从骗子转行法系输出了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_14_lvxingshangren_cos10",
	NextID = 14420711,
}
StorySpeechConfig[StorySpeechID.Id14420711] =
{
	Id = 14420711,
	CharName = "术士",
	Text = "啊，只要不是现在的样子，大家应该就不会那么怕我了吧？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_108_Warlock",
	NextID = 14420712,
}
StorySpeechConfig[StorySpeechID.Id14420712] =
{
	Id = 14420712,
	CharName = "术士族长",
	Text = "仪式开始！（巴拉巴拉念咒一小时）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_108_Warlock_cos10",
	NextID = 14420713,
}
StorySpeechConfig[StorySpeechID.Id14420713] =
{
	Id = 14420713,
	CharName = "龙血术士",
	Text = "啊，我感受到了，这就是幻兽之血吧！嘻嘻，这下女孩纸们都会喜欢我了。嗯？怎么还是还是这个样子！族长！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_23_long",
	NextID = 14420714,
}
StorySpeechConfig[StorySpeechID.Id14420714] =
{
	Id = 14420714,
	CharName = "觉醒的魔族术士",
	Text = "啊，我感觉到了，扭曲的混沌之力，完美！样子也变得更加让人感到不适了，这就是我所需要的！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_13_dashouxiaodi_cos10",
	NextID = 14420715,
}
StorySpeechConfig[StorySpeechID.Id14420715] =
{
	Id = 14420715,
	CharName = "术士",
	Text = "咦，幻兽之血，我的血统和族长大人一样吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_108_Warlock",
	NextID = 14420716,
}
StorySpeechConfig[StorySpeechID.Id14420716] =
{
	Id = 14420716,
	CharName = "术士族长",
	Text = "好了，你们都找到自己体内的力量了，那么仪式结束，祝各位未来的旅途顺利！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_108_Warlock_cos10",
	NextID = 14420717,
}
StorySpeechConfig[StorySpeechID.Id14420717] =
{
	Id = 14420717,
	CharName = "术士",
	Text = "太好了，成为幻兽后，在学院就能找到更多朋友了吧~大家都不会讨厌我了呢~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_108_Warlock",
	NextID = 14420718,
}
StorySpeechConfig[StorySpeechID.Id14420718] =
{
	Id = 14420718,
	CharName = "龙血术士",
	Text = "哇！凭什么你这个讨人厌的家伙能拥有幻兽之血啊，我今天就要逆天改命！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_23_long",
}
StorySpeechConfig[StorySpeechID.Id14420801] =
{
	Id = 14420801,
	CharName = "德鲁伊",
	Text = "嗯，我看下地图，离下个目的地只剩1300多英里啦。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_107_Druid",
	NextID = 14420802,
}
StorySpeechConfig[StorySpeechID.Id14420802] =
{
	Id = 14420802,
	CharName = "棕熊",
	Text = "哞嗷（我要休息！）",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_BrownBear",
	NextID = 14420803,
}
StorySpeechConfig[StorySpeechID.Id14420803] =
{
	Id = 14420803,
	CharName = "德鲁伊",
	Text = "不要这样嘛~比尔，我们走快点，就能赶在明年到了，到时候我给你做饼干吃。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_107_Druid",
	NextID = 14420804,
}
StorySpeechConfig[StorySpeechID.Id14420804] =
{
	Id = 14420804,
	CharName = "棕熊",
	Text = "哞嗷（又不是你走。）",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_BrownBear",
	NextID = 14420805,
}
StorySpeechConfig[StorySpeechID.Id14420805] =
{
	Id = 14420805,
	CharName = "德鲁伊",
	Text = "什么！怎么可以这样说？虽然我是坐在你身上，但是我一直在查地图找路线啊，难道我不辛苦嘛！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_107_Druid",
	NextID = 14420806,
}
StorySpeechConfig[StorySpeechID.Id14420806] =
{
	Id = 14420806,
	CharName = "棕熊",
	Text = "哞嗷（反正这次我一定要请假！）",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_BrownBear",
	NextID = 14420807,
}
StorySpeechConfig[StorySpeechID.Id14420807] =
{
	Id = 14420807,
	CharName = "德鲁伊",
	Text = "咦？请假，那是什么东西？可以吃吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_107_Druid",
	NextID = 14420808,
}
StorySpeechConfig[StorySpeechID.Id14420808] =
{
	Id = 14420808,
	CharName = "棕熊",
	Text = "哞嗷！（生气）",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_BrownBear",
	NextID = 14420809,
}
StorySpeechConfig[StorySpeechID.Id14420809] =
{
	Id = 14420809,
	CharName = "德鲁伊",
	Text = "好吧好吧，你请假吧，把我一个人丢在这里吧，我被怪物吃掉或者饿晕过去，你都不要管啦！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_107_Druid",
	NextID = 14420810,
}
StorySpeechConfig[StorySpeechID.Id14420810] =
{
	Id = 14420810,
	CharName = "棕熊",
	Text = "哞嗷…（那我帮你找个伴？）",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_BrownBear",
	NextID = 14420811,
}
StorySpeechConfig[StorySpeechID.Id14420811] =
{
	Id = 14420811,
	CharName = "德鲁伊",
	Text = "不要不要~我只要你，你不要请假，要一直陪着我！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_107_Druid",
	NextID = 14420812,
}
StorySpeechConfig[StorySpeechID.Id14420812] =
{
	Id = 14420812,
	CharName = "棕熊",
	Text = "哞嗷？（那边那个狼怎么样？）",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_BrownBear",
	NextID = 14420813,
}
StorySpeechConfig[StorySpeechID.Id14420813] =
{
	Id = 14420813,
	CharName = "德鲁伊",
	Text = "咦？好像长得很拉风呀…那，那好吧，如果是那个狼的话，可以放你一下假。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_107_Druid",
	NextID = 14420814,
}
StorySpeechConfig[StorySpeechID.Id14420814] =
{
	Id = 14420814,
	CharName = "棕熊",
	Text = "走你！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_BrownBear",
	NextID = 14420815,
}
StorySpeechConfig[StorySpeechID.Id14420815] =
{
	Id = 14420815,
	CharName = "德鲁伊",
	Text = "…你刚刚是不是说人话了…",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_107_Druid",
}
StorySpeechConfig[StorySpeechID.Id14419301] =
{
	Id = 14419301,
	CharName = "黑暗之镜",
	Text = "我是黑色世界的魔镜，只要轻轻碰触我，你就能看到暗面的你自己！",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	LeftIcon = "Equipment_Fat_11_tiantong_3",
	NextID = 14419302,
}
StorySpeechConfig[StorySpeechID.Id14419302] =
{
	Id = 14419302,
	CharName = "白国王",
	Text = "我摸！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "All_Chess_WhiteKing",
	NextID = 14419303,
}
StorySpeechConfig[StorySpeechID.Id14419303] =
{
	Id = 14419303,
	CharName = "黑国王",
	Text = "呃——我终于自由了！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhiteKing_cos10",
	NextID = 14419304,
}
StorySpeechConfig[StorySpeechID.Id14419304] =
{
	Id = 14419304,
	CharName = "白国王",
	Text = "喂，小声点！会有人听到的！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "All_Chess_WhiteKing",
	NextID = 14419305,
}
StorySpeechConfig[StorySpeechID.Id14419305] =
{
	Id = 14419305,
	CharName = "黑国王",
	Text = "你今天动员大会的表现太软弱了！应该要这样说：谁不同意，我就把他碾成木头碎！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhiteKing_cos10",
	NextID = 14419306,
}
StorySpeechConfig[StorySpeechID.Id14419306] =
{
	Id = 14419306,
	CharName = "白国王",
	Text = "啊……这……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "All_Chess_WhiteKing",
	NextID = 14419307,
}
StorySpeechConfig[StorySpeechID.Id14419307] =
{
	Id = 14419307,
	CharName = "黑国王",
	Text = "当个国王无时无刻都要保持威严，每个表情、举手投足都要对着镜子一遍遍地演练。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhiteKing_cos10",
	NextID = 14419308,
}
StorySpeechConfig[StorySpeechID.Id14419308] =
{
	Id = 14419308,
	CharName = "黑国王",
	Text = "哪怕只是一个简单的制止大家争吵的动作，也要训练成百上千次。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhiteKing_cos10",
	NextID = 14419309,
}
StorySpeechConfig[StorySpeechID.Id14419309] =
{
	Id = 14419309,
	CharName = "黑国王",
	Text = "力度、弧度、速度，真是缺一不可啊，你说是吧，陛下？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhiteKing_cos10",
	NextID = 14419310,
}
StorySpeechConfig[StorySpeechID.Id14419310] =
{
	Id = 14419310,
	CharName = "白国王",
	Text = "……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "All_Chess_WhiteKing",
	NextID = 14419311,
}
StorySpeechConfig[StorySpeechID.Id14419311] =
{
	Id = 14419311,
	CharName = "黑国王",
	Text = "哦哦哦，还有一件最重要的事情，就是体面！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhiteKing_cos10",
	NextID = 14419312,
}
StorySpeechConfig[StorySpeechID.Id14419312] =
{
	Id = 14419312,
	CharName = "黑国王",
	Text = "想在施展帅气招式时喊出奇怪的名字就大声喊出来，毕竟，你是国王！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhiteKing_cos10",
	NextID = 14419313,
}
StorySpeechConfig[StorySpeechID.Id14419313] =
{
	Id = 14419313,
	CharName = "黑国王",
	Text = "不过，如果你实在没有勇气，嘿嘿嘿嘿，那我可以帮你！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhiteKing_cos10",
}
StorySpeechConfig[StorySpeechID.Id14419401] =
{
	Id = 14419401,
	CharName = "黑暗之镜",
	Text = "皇后大人，你有任何心事，都可以告诉我。",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	LeftIcon = "Equipment_Fat_11_tiantong_3",
	NextID = 14419402,
}
StorySpeechConfig[StorySpeechID.Id14419402] =
{
	Id = 14419402,
	CharName = "白皇后",
	Text = "嗯？你是谁？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "All_Chess_WhiteQueen",
	NextID = 14419403,
}
StorySpeechConfig[StorySpeechID.Id14419403] =
{
	Id = 14419403,
	CharName = "黑皇后",
	Text = "你要叫我来呀♪~谁不愿意来呀♪~哪个傻子才不愿意来呀啊啊♪~",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhiteQueen_cos10",
	NextID = 14419404,
}
StorySpeechConfig[StorySpeechID.Id14419404] =
{
	Id = 14419404,
	CharName = "白皇后",
	Text = "住口！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "All_Chess_WhiteQueen",
	NextID = 14419405,
}
StorySpeechConfig[StorySpeechID.Id14419405] =
{
	Id = 14419405,
	CharName = "黑皇后",
	Text = "诶？怎么啦？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhiteQueen_cos10",
	NextID = 14419406,
}
StorySpeechConfig[StorySpeechID.Id14419406] =
{
	Id = 14419406,
	CharName = "白皇后",
	Text = "你……你怎么知道这首歌的？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "All_Chess_WhiteQueen",
	NextID = 14419407,
}
StorySpeechConfig[StorySpeechID.Id14419407] =
{
	Id = 14419407,
	CharName = "黑皇后",
	Text = "因为我就是你内心压抑的欲望呀！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhiteQueen_cos10",
	NextID = 14419408,
}
StorySpeechConfig[StorySpeechID.Id14419408] =
{
	Id = 14419408,
	CharName = "黑皇后",
	Text = "高贵的皇后，美丽的华服，奢侈的大餐，精致的仪容，真好啊！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhiteQueen_cos10",
	NextID = 14419409,
}
StorySpeechConfig[StorySpeechID.Id14419409] =
{
	Id = 14419409,
	CharName = "黑皇后",
	Text = "只是，每天都是这样确实有点无聊……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhiteQueen_cos10",
	NextID = 14419410,
}
StorySpeechConfig[StorySpeechID.Id14419410] =
{
	Id = 14419410,
	CharName = "黑皇后",
	Text = "所以你内心蹦出个大胆的想法，要是……能够随心所欲一些就好了……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhiteQueen_cos10",
	NextID = 14419411,
}
StorySpeechConfig[StorySpeechID.Id14419411] =
{
	Id = 14419411,
	CharName = "白皇后",
	Text = "不……不……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "All_Chess_WhiteQueen",
	NextID = 14419412,
}
StorySpeechConfig[StorySpeechID.Id14419412] =
{
	Id = 14419412,
	CharName = "黑皇后",
	Text = "你经常把自己关在隔音的房间里，让所有的仆人都离开，然后放声高歌！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhiteQueen_cos10",
	NextID = 14419413,
}
StorySpeechConfig[StorySpeechID.Id14419413] =
{
	Id = 14419413,
	CharName = "黑皇后",
	Text = "歌词庸俗不堪，声音没有一个在谱的，哈哈哈……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhiteQueen_cos10",
	NextID = 14419414,
}
StorySpeechConfig[StorySpeechID.Id14419414] =
{
	Id = 14419414,
	CharName = "黑皇后",
	Text = "不过，这样每次唱出来的歌都不一样，还真是有点乐趣呢！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhiteQueen_cos10",
	NextID = 14419415,
}
StorySpeechConfig[StorySpeechID.Id14419415] =
{
	Id = 14419415,
	CharName = "白皇后",
	Text = "你……我绝对不会让你把我的秘密泄露出去的！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "All_Chess_WhiteQueen",
}
StorySpeechConfig[StorySpeechID.Id14419501] =
{
	Id = 14419501,
	CharName = "白主教",
	Text = "咦，这就是黑暗魔镜吗？嘿嘿，不知道我的内心暗面是什么样的？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhiteBishop",
	NextID = 14419502,
}
StorySpeechConfig[StorySpeechID.Id14419502] =
{
	Id = 14419502,
	CharName = "黑暗之镜",
	Text = "啊，权利，名望，操控人心的能力！",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	RightIcon = "Equipment_Fat_11_tiantong_3",
	NextID = 14419503,
}
StorySpeechConfig[StorySpeechID.Id14419503] =
{
	Id = 14419503,
	CharName = "黑主教",
	Text = "主教大人，谢谢你，我终于能从镜子里走出来了mua~",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhiteBishop_cos10",
	NextID = 14419504,
}
StorySpeechConfig[StorySpeechID.Id14419504] =
{
	Id = 14419504,
	CharName = "白主教",
	Text = "！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "All_Chess_WhiteBishop",
	NextID = 14419505,
}
StorySpeechConfig[StorySpeechID.Id14419505] =
{
	Id = 14419505,
	CharName = "黑主教",
	Text = "看到我现在的样子，你不开心吗？你不激动吗？mua~",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhiteBishop_cos10",
	NextID = 14419506,
}
StorySpeechConfig[StorySpeechID.Id14419506] =
{
	Id = 14419506,
	CharName = "白主教",
	Text = "（颤抖）你……你……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "All_Chess_WhiteBishop",
	NextID = 14419507,
}
StorySpeechConfig[StorySpeechID.Id14419507] =
{
	Id = 14419507,
	CharName = "黑主教",
	Text = "每天晚上，你都会换上这套可爱的衣服，晃动可爱的马尾mua~",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhiteBishop_cos10",
	NextID = 14419508,
}
StorySpeechConfig[StorySpeechID.Id14419508] =
{
	Id = 14419508,
	CharName = "黑主教",
	Text = "你会对着镜子说，你真是个可爱的小姑娘，没人能比你更美mua~",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhiteBishop_cos10",
	NextID = 14419509,
}
StorySpeechConfig[StorySpeechID.Id14419509] =
{
	Id = 14419509,
	CharName = "白主教",
	Text = "（咽口水）可大家都以为我是男孩纸的……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "All_Chess_WhiteBishop",
	NextID = 14419510,
}
StorySpeechConfig[StorySpeechID.Id14419510] =
{
	Id = 14419510,
	CharName = "黑主教",
	Text = "那有什么关系？我已经迫不及待想让外面的人看看我的美了mua~",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhiteBishop_cos10",
	NextID = 14419511,
}
StorySpeechConfig[StorySpeechID.Id14419511] =
{
	Id = 14419511,
	CharName = "白主教",
	Text = "！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "All_Chess_WhiteBishop",
	NextID = 14419512,
}
StorySpeechConfig[StorySpeechID.Id14419512] =
{
	Id = 14419512,
	CharName = "白主教",
	Text = "我终于明白为什么人没人会在这个试炼里失败了！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "All_Chess_WhiteBishop",
	NextID = 14419513,
}
StorySpeechConfig[StorySpeechID.Id14419513] =
{
	Id = 14419513,
	CharName = "白主教",
	Text = "（转身把门锁死）……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "All_Chess_WhiteBishop",
	NextID = 14419514,
}
StorySpeechConfig[StorySpeechID.Id14419514] =
{
	Id = 14419514,
	CharName = "白主教",
	Text = "今天，除非我死，否则你别想离开这里一步！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "All_Chess_WhiteBishop",
	NextID = 14419515,
}
StorySpeechConfig[StorySpeechID.Id14419515] =
{
	Id = 14419515,
	CharName = "黑主教",
	Text = "亲爱的主教大人，没用的！就像你每晚都会说的，我的魅力无人能挡mua~",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhiteBishop_cos10",
	NextID = 14419516,
}
StorySpeechConfig[StorySpeechID.Id14419516] =
{
	Id = 14419516,
	CharName = "白主教",
	Text = "（脸红）住口！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "All_Chess_WhiteBishop",
}
StorySpeechConfig[StorySpeechID.Id14419601] =
{
	Id = 14419601,
	CharName = "黑暗之镜",
	Text = "王国最强的勇士，你敢直面真正的恐怖吗？",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	LeftIcon = "Equipment_Fat_11_tiantong_3",
	NextID = 14419602,
}
StorySpeechConfig[StorySpeechID.Id14419602] =
{
	Id = 14419602,
	CharName = "白城堡",
	Text = "嗯？那是什么？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "All_Chess_WhiteRook",
	NextID = 14419603,
}
StorySpeechConfig[StorySpeechID.Id14419603] =
{
	Id = 14419603,
	CharName = "黑城堡",
	Text = "（拿刀在铠甲上划动）嘿嘿嘿……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhiteRook_cos10",
	NextID = 14419604,
}
StorySpeechConfig[StorySpeechID.Id14419604] =
{
	Id = 14419604,
	CharName = "白城堡",
	Text = "你在干什么？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "All_Chess_WhiteRook",
	NextID = 14419605,
}
StorySpeechConfig[StorySpeechID.Id14419605] =
{
	Id = 14419605,
	CharName = "黑城堡",
	Text = "干什么？哎呀呀，你这个问题真是问得有点莫名其妙呢~",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhiteRook_cos10",
	NextID = 14419606,
}
StorySpeechConfig[StorySpeechID.Id14419606] =
{
	Id = 14419606,
	CharName = "黑城堡",
	Text = "我现在干的，不就是你经常在背地里偷偷干的事情吗？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhiteRook_cos10",
	NextID = 14419607,
}
StorySpeechConfig[StorySpeechID.Id14419607] =
{
	Id = 14419607,
	CharName = "黑城堡",
	Text = "好了，我做完了！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhiteRook_cos10",
	NextID = 14419608,
}
StorySpeechConfig[StorySpeechID.Id14419608] =
{
	Id = 14419608,
	CharName = "白城堡",
	Text = "（小声）XXX到此……一游！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "All_Chess_WhiteRook",
	NextID = 14419609,
}
StorySpeechConfig[StorySpeechID.Id14419609] =
{
	Id = 14419609,
	CharName = "黑城堡",
	Text = "那些讨厌的熊孩子总在你站岗时骚扰你，趁着你不能动就在你身上刻字。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhiteRook_cos10",
	NextID = 14419610,
}
StorySpeechConfig[StorySpeechID.Id14419610] =
{
	Id = 14419610,
	CharName = "黑城堡",
	Text = "虽然告诉对方的父母后，他们会痛打熊孩子的屁屁，但意外地，你也发现了乐趣。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhiteRook_cos10",
	NextID = 14419611,
}
StorySpeechConfig[StorySpeechID.Id14419611] =
{
	Id = 14419611,
	CharName = "黑城堡",
	Text = "趁着没人的时候，你也会悄悄在自己的铠甲上刻字，然后诬陷那些孩子们。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhiteRook_cos10",
	NextID = 14419612,
}
StorySpeechConfig[StorySpeechID.Id14419612] =
{
	Id = 14419612,
	CharName = "黑城堡",
	Text = "要是我告诉那些孩子的父母真相，你猜他们会怎么看你？国王会怎么看你？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhiteRook_cos10",
	NextID = 14419613,
}
StorySpeechConfig[StorySpeechID.Id14419613] =
{
	Id = 14419613,
	CharName = "白城堡",
	Text = "！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "All_Chess_WhiteRook",
	NextID = 14419614,
}
StorySpeechConfig[StorySpeechID.Id14419614] =
{
	Id = 14419614,
	CharName = "白城堡",
	Text = "我这……我这也是……为了之后站岗能……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "All_Chess_WhiteRook",
	NextID = 14419615,
}
StorySpeechConfig[StorySpeechID.Id14419615] =
{
	Id = 14419615,
	CharName = "黑城堡",
	Text = "不要忘了，我就是你！你在想什么，以为我不知道吗？嘿嘿嘿……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhiteRook_cos10",
	NextID = 14419616,
}
StorySpeechConfig[StorySpeechID.Id14419616] =
{
	Id = 14419616,
	CharName = "白城堡",
	Text = "（皱眉）我只是觉得……站岗有些无聊啊……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "All_Chess_WhiteRook",
}
StorySpeechConfig[StorySpeechID.Id14419701] =
{
	Id = 14419701,
	CharName = "白骑士",
	Text = "嗯？一面镜子？嚯嚯，照下我帅气的脸驾！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhiteKnight",
	NextID = 14419702,
}
StorySpeechConfig[StorySpeechID.Id14419702] =
{
	Id = 14419702,
	CharName = "黑暗之镜",
	Text = "镜面如同湖面散开一阵涟漪，一个模糊的幻象显现出来。",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	RightIcon = "Equipment_Fat_11_tiantong_3",
	NextID = 14419703,
}
StorySpeechConfig[StorySpeechID.Id14419703] =
{
	Id = 14419703,
	CharName = "黑骑士",
	Text = "终于能从镜子里出来了！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhiteKnight_cos10",
	NextID = 14419704,
}
StorySpeechConfig[StorySpeechID.Id14419704] =
{
	Id = 14419704,
	CharName = "白骑士",
	Text = "这……这是什么？难道是我内心的暗面驾？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "All_Chess_WhiteKnight",
	NextID = 14419705,
}
StorySpeechConfig[StorySpeechID.Id14419705] =
{
	Id = 14419705,
	CharName = "白骑士",
	Text = "可是怎么这么黑啊？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "All_Chess_WhiteKnight",
	NextID = 14419706,
}
StorySpeechConfig[StorySpeechID.Id14419706] =
{
	Id = 14419706,
	CharName = "黑骑士",
	Text = "为什么这么黑？这不正是你每天所希望的吗？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhiteKnight_cos10",
	NextID = 14419707,
}
StorySpeechConfig[StorySpeechID.Id14419707] =
{
	Id = 14419707,
	CharName = "白骑士",
	Text = "什么？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "All_Chess_WhiteKnight",
	NextID = 14419708,
}
StorySpeechConfig[StorySpeechID.Id14419708] =
{
	Id = 14419708,
	CharName = "黑骑士",
	Text = "你不是每天都对着镜子说着那句台词吗？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhiteKnight_cos10",
	NextID = 14419709,
}
StorySpeechConfig[StorySpeechID.Id14419709] =
{
	Id = 14419709,
	CharName = "白骑士",
	Text = "……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "All_Chess_WhiteKnight",
	NextID = 14419710,
}
StorySpeechConfig[StorySpeechID.Id14419710] =
{
	Id = 14419710,
	CharName = "黑骑士",
	Text = "我一定会从众多骑士中脱颖而出，成为王国的荣誉骑士，因为我是一匹黑马！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhiteKnight_cos10",
	NextID = 14419711,
}
StorySpeechConfig[StorySpeechID.Id14419711] =
{
	Id = 14419711,
	CharName = "白骑士",
	Text = "不！你可能误会我的意思了驾……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "All_Chess_WhiteKnight",
	NextID = 14419712,
}
StorySpeechConfig[StorySpeechID.Id14419712] =
{
	Id = 14419712,
	CharName = "黑骑士",
	Text = "我不管，我现在就要出去向国王证明我的实力！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhiteKnight_cos10",
	NextID = 14419713,
}
StorySpeechConfig[StorySpeechID.Id14419713] =
{
	Id = 14419713,
	CharName = "白骑士",
	Text = "那恐怕你先要过了我这关！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "All_Chess_WhiteKnight",
}
StorySpeechConfig[StorySpeechID.Id14419801] =
{
	Id = 14419801,
	CharName = "白卫兵",
	Text = "听说，打败房间中黑色镜子映射出的黑暗面，就能驾驭黑暗的力量。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhitePawn",
	NextID = 14419802,
}
StorySpeechConfig[StorySpeechID.Id14419802] =
{
	Id = 14419802,
	CharName = "白卫兵",
	Text = "（上前触摸）……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhitePawn",
	NextID = 14419803,
}
StorySpeechConfig[StorySpeechID.Id14419803] =
{
	Id = 14419803,
	CharName = "黑卫兵",
	Text = "我们终于见面了呢，平凡的士兵！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "All_Chess_WhitePawn_cos10",
	NextID = 14419804,
}
StorySpeechConfig[StorySpeechID.Id14419804] =
{
	Id = 14419804,
	CharName = "白卫兵",
	Text = "来吧，就像之前所有的战斗一样，我不会退缩的！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhitePawn",
	NextID = 14419805,
}
StorySpeechConfig[StorySpeechID.Id14419805] =
{
	Id = 14419805,
	CharName = "黑卫兵",
	Text = "哈哈哈……别把自己说得那么伟大！你在想什么以为我不知道吗？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "All_Chess_WhitePawn_cos10",
	NextID = 14419806,
}
StorySpeechConfig[StorySpeechID.Id14419806] =
{
	Id = 14419806,
	CharName = "白卫兵",
	Text = "……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhitePawn",
	NextID = 14419807,
}
StorySpeechConfig[StorySpeechID.Id14419807] =
{
	Id = 14419807,
	CharName = "黑卫兵",
	Text = "有点功勋和背景的都可以在战斗中逃离，因为他们背后有家族撑腰。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "All_Chess_WhitePawn_cos10",
	NextID = 14419808,
}
StorySpeechConfig[StorySpeechID.Id14419808] =
{
	Id = 14419808,
	CharName = "黑卫兵",
	Text = "可是你一个小小的士兵却不能，因为你知道，你背后什么都没有，你无路可退！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "All_Chess_WhitePawn_cos10",
	NextID = 14419809,
}
StorySpeechConfig[StorySpeechID.Id14419809] =
{
	Id = 14419809,
	CharName = "白卫兵",
	Text = "……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhitePawn",
	NextID = 14419810,
}
StorySpeechConfig[StorySpeechID.Id14419810] =
{
	Id = 14419810,
	CharName = "黑卫兵",
	Text = "拼死战斗不肯退缩，是因为除了这个选择外，你别无选择！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "All_Chess_WhitePawn_cos10",
	NextID = 14419811,
}
StorySpeechConfig[StorySpeechID.Id14419811] =
{
	Id = 14419811,
	CharName = "白卫兵",
	Text = "你这个混蛋！说的话真是让人上火！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhitePawn",
	NextID = 14419812,
}
StorySpeechConfig[StorySpeechID.Id14419812] =
{
	Id = 14419812,
	CharName = "黑卫兵",
	Text = "那只是因为我说的都是真话，而真话都是很刺耳的。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "All_Chess_WhitePawn_cos10",
	NextID = 14419813,
}
StorySpeechConfig[StorySpeechID.Id14419813] =
{
	Id = 14419813,
	CharName = "白卫兵",
	Text = "我不会让你把这些话带出这扇门的！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "All_Chess_WhitePawn",
}
StorySpeechConfig[StorySpeechID.Id14419901] =
{
	Id = 14419901,
	CharName = "松芊芊",
	Text = "哇，这衣服摸着好软好舒服！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "All_Longevity",
	NextID = 14419902,
}
StorySpeechConfig[StorySpeechID.Id14419902] =
{
	Id = 14419902,
	CharName = "服装设计师",
	Text = "这是我们公司今年刚刚设计出的新款衣服，不仅保暖，还非常时髦！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_29_kaitangshoujieke_cos10",
	NextID = 14419903,
}
StorySpeechConfig[StorySpeechID.Id14419903] =
{
	Id = 14419903,
	CharName = "松芊芊",
	Text = "这衣服就这么送给我吗？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "All_Longevity",
	NextID = 14419904,
}
StorySpeechConfig[StorySpeechID.Id14419904] =
{
	Id = 14419904,
	CharName = "服装设计师",
	Text = "只要您答应穿上它，赶走一些雪地里的怪物，帮我们公司做宣传就可以免费送给您！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_29_kaitangshoujieke_cos10",
	NextID = 14419905,
}
StorySpeechConfig[StorySpeechID.Id14419905] =
{
	Id = 14419905,
	CharName = "松芊芊",
	Text = "这个好说，不过我还不知道你们公司的名字呢。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "All_Longevity",
	NextID = 14419906,
}
StorySpeechConfig[StorySpeechID.Id14419906] =
{
	Id = 14419906,
	CharName = "服装设计师",
	Text = "我们公司英文名是 The South Face，中文名叫——南面！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_29_kaitangshoujieke_cos10",
}
StorySpeechConfig[StorySpeechID.Id14420001] =
{
	Id = 14420001,
	CharName = "中年男子",
	Text = "大哥，你也来接孩子吗？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_men4",
	NextID = 14420002,
}
StorySpeechConfig[StorySpeechID.Id14420002] =
{
	Id = 14420002,
	CharName = "休休",
	Text = "我……",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "All_GetRich",
	NextID = 14420003,
}
StorySpeechConfig[StorySpeechID.Id14420003] =
{
	Id = 14420003,
	CharName = "中年男子",
	Text = "现在的孩子不好带啊，是吧，大哥？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_men4",
	NextID = 14420004,
}
StorySpeechConfig[StorySpeechID.Id14420004] =
{
	Id = 14420004,
	CharName = "休休",
	Text = "额……",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "All_GetRich",
	NextID = 14420005,
}
StorySpeechConfig[StorySpeechID.Id14420005] =
{
	Id = 14420005,
	CharName = "中年男子",
	Text = "刮风下雨要接送，平时作业要辅导，小伤小病经常有，半夜踢被不省心。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_men4",
	NextID = 14420006,
}
StorySpeechConfig[StorySpeechID.Id14420006] =
{
	Id = 14420006,
	CharName = "休休",
	Text = "这……",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "All_GetRich",
	NextID = 14420007,
}
StorySpeechConfig[StorySpeechID.Id14420007] =
{
	Id = 14420007,
	CharName = "中年男子",
	Text = "哟，孩子下课出来了！大哥，下次再聊，我先走了！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_men4",
	NextID = 14420008,
}
StorySpeechConfig[StorySpeechID.Id14420008] =
{
	Id = 14420008,
	CharName = "休休",
	Text = "……",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "All_GetRich",
	NextID = 14420009,
}
StorySpeechConfig[StorySpeechID.Id14420009] =
{
	Id = 14420009,
	CharName = "休休",
	Text = "谁是你大哥！我还是个14岁的孩子啊！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "All_GetRich",
	NextID = 14420010,
}
StorySpeechConfig[StorySpeechID.Id14420010] =
{
	Id = 14420010,
	CharName = "休休",
	Text = "（拿出镜子）哎……这都第几次放学被人误认为家长了……",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "All_GetRich",
	NextID = 14420011,
}
StorySpeechConfig[StorySpeechID.Id14420011] =
{
	Id = 14420011,
	CharName = "休休",
	Text = "我长得太老相了，看来是有必要整个容了。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "All_GetRich",
}
StorySpeechConfig[StorySpeechID.Id14420101] =
{
	Id = 14420101,
	CharName = "阿宁",
	Text = "要~要~切克闹~",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "All_Healthy",
	NextID = 14420102,
}
StorySpeechConfig[StorySpeechID.Id14420102] =
{
	Id = 14420102,
	CharName = "阿宁",
	Text = "煎饼果子来一套~我说煎饼你说要~",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "All_Healthy",
	NextID = 14420103,
}
StorySpeechConfig[StorySpeechID.Id14420103] =
{
	Id = 14420103,
	CharName = "阿宁",
	Text = "煎饼~要~",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "All_Healthy",
	NextID = 14420104,
}
StorySpeechConfig[StorySpeechID.Id14420104] =
{
	Id = 14420104,
	CharName = "阿宁",
	Text = "煎饼~要~",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "All_Healthy",
	NextID = 14420105,
}
StorySpeechConfig[StorySpeechID.Id14420105] =
{
	Id = 14420105,
	CharName = "阿宁",
	Text = "香甜酥脆好……好味道~",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "All_Healthy",
	NextID = 14420106,
}
StorySpeechConfig[StorySpeechID.Id14420106] =
{
	Id = 14420106,
	CharName = "训练师",
	Text = "很棒！配合音乐节奏，你今天的口吃矫正课表现得很好！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_naked1",
	NextID = 14420107,
}
StorySpeechConfig[StorySpeechID.Id14420107] =
{
	Id = 14420107,
	CharName = "阿宁",
	Text = "但每次训练都……都在最后一……一句上差……差一点……",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "All_Healthy",
	NextID = 14420108,
}
StorySpeechConfig[StorySpeechID.Id14420108] =
{
	Id = 14420108,
	CharName = "训练师",
	Text = "嗯……我建议你去买套合适的衣服换上，可以帮你更好地沉浸其中。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_naked1",
	NextID = 14420109,
}
StorySpeechConfig[StorySpeechID.Id14420109] =
{
	Id = 14420109,
	CharName = "阿宁",
	Text = "可……可是我钱……钱不够……",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "All_Healthy",
	NextID = 14420110,
}
StorySpeechConfig[StorySpeechID.Id14420110] =
{
	Id = 14420110,
	CharName = "训练师",
	Text = "最近有些小坏蛋来嘲笑班里其他口吃的学生。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_naked1",
	NextID = 14420111,
}
StorySpeechConfig[StorySpeechID.Id14420111] =
{
	Id = 14420111,
	CharName = "训练师",
	Text = "要是你能帮忙赶走他们，我倒是可以给你些报酬。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_naked1",
	NextID = 14420112,
}
StorySpeechConfig[StorySpeechID.Id14420112] =
{
	Id = 14420112,
	CharName = "阿宁",
	Text = "好……好的！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "All_Healthy",
}
StorySpeechConfig[StorySpeechID.Id14420201] =
{
	Id = 14420201,
	CharName = "松芊芊",
	Text = "倪不染，你为什么这么讨厌淤泥怪？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "All_Longevity",
	NextID = 14420202,
}
StorySpeechConfig[StorySpeechID.Id14420202] =
{
	Id = 14420202,
	CharName = "倪不染",
	Text = "说来话长，给你看张我从前的照片吧……",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "All_Morality",
	NextID = 14420203,
}
StorySpeechConfig[StorySpeechID.Id14420203] =
{
	Id = 14420203,
	CharName = "松芊芊",
	Text = "照片上的人是你吗？好清纯啊！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "All_Longevity",
	NextID = 14420204,
}
StorySpeechConfig[StorySpeechID.Id14420204] =
{
	Id = 14420204,
	CharName = "松芊芊",
	Text = "咦？怎么感觉照片上的你好像被什么东西包裹着？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "All_Longevity",
	NextID = 14420205,
}
StorySpeechConfig[StorySpeechID.Id14420205] =
{
	Id = 14420205,
	CharName = "倪不染",
	Text = "没错，这是我父亲为我做的透明雨衣。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "All_Morality",
	NextID = 14420206,
}
StorySpeechConfig[StorySpeechID.Id14420206] =
{
	Id = 14420206,
	CharName = "倪不染",
	Text = "而且雨衣里灌注了胶原蛋白液，浸泡其中可以让我的皮肤水嫩光滑。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "All_Morality",
	NextID = 14420207,
}
StorySpeechConfig[StorySpeechID.Id14420207] =
{
	Id = 14420207,
	CharName = "松芊芊",
	Text = "哇哦！可这和淤泥怪有什么关系？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "All_Longevity",
	NextID = 14420208,
}
StorySpeechConfig[StorySpeechID.Id14420208] =
{
	Id = 14420208,
	CharName = "倪不染",
	Text = "看到那颗蓝色的星星了吗？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "All_Morality",
	NextID = 14420209,
}
StorySpeechConfig[StorySpeechID.Id14420209] =
{
	Id = 14420209,
	CharName = "松芊芊",
	Text = "看到了，这个饰品很好看，怎么了？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "All_Longevity",
	NextID = 14420210,
}
StorySpeechConfig[StorySpeechID.Id14420210] =
{
	Id = 14420210,
	CharName = "倪不染",
	Text = "有一天，一个淤泥怪拦住了去路，把这星星抢走了……",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "All_Morality",
	NextID = 14420211,
}
StorySpeechConfig[StorySpeechID.Id14420211] =
{
	Id = 14420211,
	CharName = "松芊芊",
	Text = "你大概很喜欢这个星星装饰物吧？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "All_Longevity",
	NextID = 14420212,
}
StorySpeechConfig[StorySpeechID.Id14420212] =
{
	Id = 14420212,
	CharName = "倪不染",
	Text = "不，那是塞子！是为了防止雨衣中的胶原蛋白液流出的塞子！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "All_Morality",
	NextID = 14420213,
}
StorySpeechConfig[StorySpeechID.Id14420213] =
{
	Id = 14420213,
	CharName = "松芊芊",
	Text = "原……原来如此……",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "All_Longevity",
}
StorySpeechConfig[StorySpeechID.Id14420301] =
{
	Id = 14420301,
	CharName = "姐姐",
	Text = "哎哟，这衣服穿了都多少年了，真想换一套……",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "All_BeginEnd",
	NextID = 14420302,
}
StorySpeechConfig[StorySpeechID.Id14420302] =
{
	Id = 14420302,
	CharName = "弟弟",
	Text = "姐姐，想换就换呗，干什么这么苦恼？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "All_BeginEnd",
	NextID = 14420303,
}
StorySpeechConfig[StorySpeechID.Id14420303] =
{
	Id = 14420303,
	CharName = "姐姐",
	Text = "我们两人一直被人称赞做人做事有始有终，要是突然换衣服的话……",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "All_BeginEnd",
	NextID = 14420304,
}
StorySpeechConfig[StorySpeechID.Id14420304] =
{
	Id = 14420304,
	CharName = "弟弟",
	Text = "你是担心被人说喜欢衣服的品味不断变换，我们的行事不符合我们的人设？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "All_BeginEnd",
	NextID = 14420305,
}
StorySpeechConfig[StorySpeechID.Id14420305] =
{
	Id = 14420305,
	CharName = "姐姐",
	Text = "嗯，是这样呢，你不知道那些杠精有多让人讨厌。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "All_BeginEnd",
	NextID = 14420306,
}
StorySpeechConfig[StorySpeechID.Id14420306] =
{
	Id = 14420306,
	CharName = "弟弟",
	Text = "这个好办呀。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "All_BeginEnd",
	NextID = 14420307,
}
StorySpeechConfig[StorySpeechID.Id14420307] =
{
	Id = 14420307,
	CharName = "姐姐",
	Text = "哦？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "All_BeginEnd",
	NextID = 14420308,
}
StorySpeechConfig[StorySpeechID.Id14420308] =
{
	Id = 14420308,
	CharName = "弟弟",
	Text = "你就说，我们的有始有终不是体现在对衣服品味的一成不变。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "All_BeginEnd",
	NextID = 14420309,
}
StorySpeechConfig[StorySpeechID.Id14420309] =
{
	Id = 14420309,
	CharName = "弟弟",
	Text = "而是体现在不断与时俱进，成为时尚界的弄潮儿这一点上。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "All_BeginEnd",
	NextID = 14420310,
}
StorySpeechConfig[StorySpeechID.Id14420310] =
{
	Id = 14420310,
	CharName = "姐姐",
	Text = "！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "All_BeginEnd",
	NextID = 14420311,
}
StorySpeechConfig[StorySpeechID.Id14420311] =
{
	Id = 14420311,
	CharName = "姐姐",
	Text = "弟弟，你好聪明啊，我怎么一直没发现？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "All_BeginEnd",
	NextID = 14420312,
}
StorySpeechConfig[StorySpeechID.Id14420312] =
{
	Id = 14420312,
	CharName = "弟弟",
	Text = "哈哈，那是因为我聪明得有始有终，你马虎得有始有终啊。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "All_BeginEnd",
}
StorySpeechConfig[StorySpeechID.Id14420401] =
{
	Id = 14420401,
	CharName = "老板",
	Text = "两位应该都知道这水有多珍贵吧？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_men4",
	NextID = 14420402,
}
StorySpeechConfig[StorySpeechID.Id14420402] =
{
	Id = 14420402,
	CharName = "老板",
	Text = "这是跃龙门到达天庭的鲤鱼，将天池水灌入瓶中送到下界，托我进行销售的神仙水。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_men4",
	NextID = 14420403,
}
StorySpeechConfig[StorySpeechID.Id14420403] =
{
	Id = 14420403,
	CharName = "老板",
	Text = "这种水完全没有任何添加剂，因为——我们不生产神仙水，只是神仙水的搬运工！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_men4",
	NextID = 14420404,
}
StorySpeechConfig[StorySpeechID.Id14420404] =
{
	Id = 14420404,
	CharName = "老板",
	Text = "只要将这神仙水倒入鱼缸，经过一段时间滋养，必定能容光焕发、脱胎换骨。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_men4",
	NextID = 14420405,
}
StorySpeechConfig[StorySpeechID.Id14420405] =
{
	Id = 14420405,
	CharName = "老板",
	Text = "从而彻底超越原来平凡无奇的自己！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_men4",
	NextID = 14420406,
}
StorySpeechConfig[StorySpeechID.Id14420406] =
{
	Id = 14420406,
	CharName = "老板",
	Text = "目前这水只剩一瓶了，你们要不商量下谁买？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_men4",
	NextID = 14420407,
}
StorySpeechConfig[StorySpeechID.Id14420407] =
{
	Id = 14420407,
	CharName = "锦鲤鲤",
	Text = "（两眼放光）我一定要买下这瓶水，我早就厌烦了鱼缸里平庸的美容液！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "All_LuckyFish",
	NextID = 14420408,
}
StorySpeechConfig[StorySpeechID.Id14420408] =
{
	Id = 14420408,
	CharName = "另一条锦鲤鲤",
	Text = "别做梦了，这瓶水一定是我的，我已经关注很久了！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "All_LuckyFish",
	NextID = 14420409,
}
StorySpeechConfig[StorySpeechID.Id14420409] =
{
	Id = 14420409,
	CharName = "锦鲤鲤",
	Text = "都这么想要，看来只能凭本事了！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "All_LuckyFish",
	NextID = 14420410,
}
StorySpeechConfig[StorySpeechID.Id14420410] =
{
	Id = 14420410,
	CharName = "另一条锦鲤鲤",
	Text = "哼！正合我意！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "All_LuckyFish",
}
StorySpeechConfig[StorySpeechID.Id14420501] =
{
	Id = 14420501,
	CharName = "女人",
	Text = "好啦！酱紫一来，我们就不怕年兽来捣乱了！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_women1",
	NextID = 14420502,
}
StorySpeechConfig[StorySpeechID.Id14420502] =
{
	Id = 14420502,
	CharName = "小女孩",
	Text = "姆妈，真的能行吗？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_girl1",
	NextID = 14420503,
}
StorySpeechConfig[StorySpeechID.Id14420503] =
{
	Id = 14420503,
	CharName = "女人",
	Text = "嗯！其他地方也都是酱紫，肯定没问题！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_women1",
	NextID = 14420504,
}
StorySpeechConfig[StorySpeechID.Id14420504] =
{
	Id = 14420504,
	CharName = "年大人",
	Text = "酱紫是什么怪物？比我还可怕吗？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "All_NewYearBeast",
	NextID = 14420505,
}
StorySpeechConfig[StorySpeechID.Id14420505] =
{
	Id = 14420505,
	CharName = "年大人",
	Text = "而且听她们的话，今年各地都有酱紫……",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "All_NewYearBeast",
	NextID = 14420506,
}
StorySpeechConfig[StorySpeechID.Id14420506] =
{
	Id = 14420506,
	CharName = "年大人",
	Text = "以防万一，今年我还是夜里行动吧。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "All_NewYearBeast",
	NextID = 14420507,
}
StorySpeechConfig[StorySpeechID.Id14420507] =
{
	Id = 14420507,
	CharName = "年大人",
	Text = "不过，我这套衣服太明显了。晚上万一被人看到去通知酱紫，就麻烦了。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "All_NewYearBeast",
	NextID = 14420508,
}
StorySpeechConfig[StorySpeechID.Id14420508] =
{
	Id = 14420508,
	CharName = "年大人",
	Text = "是该去抢点布料重新做一套夜行服了！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "All_NewYearBeast",
}
StorySpeechConfig[StorySpeechID.Id14420601] =
{
	Id = 14420601,
	CharName = "冒险协会会长",
	Text = "在各位的努力下，协会今年又成功开荒了3个副本。因为表现优异，因此今年拿到了新的赞助噢~",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye_cos10",
	NextID = 14420602,
}
StorySpeechConfig[StorySpeechID.Id14420602] =
{
	Id = 14420602,
	CharName = "协会的同伴A",
	Text = "（鼓掌）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi_cos10",
	NextID = 14420603,
}
StorySpeechConfig[StorySpeechID.Id14420603] =
{
	Id = 14420603,
	CharName = "协会的同伴B",
	Text = "（鼓掌）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_16_lieren_cos10",
	NextID = 14420604,
}
StorySpeechConfig[StorySpeechID.Id14420604] =
{
	Id = 14420604,
	CharName = "冒险协会会长",
	Text = "尤其要点名表扬的是——剑士！在过去一年里，他勇敢地走出了新手村，踏上了讨伐魔王的征程！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye_cos10",
	NextID = 14420605,
}
StorySpeechConfig[StorySpeechID.Id14420605] =
{
	Id = 14420605,
	CharName = "剑士",
	Text = "（鼓掌）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi",
	NextID = 14420606,
}
StorySpeechConfig[StorySpeechID.Id14420606] =
{
	Id = 14420606,
	CharName = "呜呜",
	Text = "（鼓掌）",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "All_wuwu",
	NextID = 14420607,
}
StorySpeechConfig[StorySpeechID.Id14420607] =
{
	Id = 14420607,
	CharName = "冒险协会会长",
	Text = "为了鼓励剑士继续勇敢走下去，协会特意为他定制了一件新年礼服！希望新的一年里，能再创新高！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_20_laoyeye_cos10",
	NextID = 14420608,
}
StorySpeechConfig[StorySpeechID.Id14420608] =
{
	Id = 14420608,
	CharName = "协会的同伴A",
	Text = "哇~我也要！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_05_jianshi_cos10",
	NextID = 14420609,
}
StorySpeechConfig[StorySpeechID.Id14420609] =
{
	Id = 14420609,
	CharName = "协会的同伴B",
	Text = "虽然不穿，拿回去也好！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_16_lieren_cos10",
	NextID = 14420610,
}
StorySpeechConfig[StorySpeechID.Id14420610] =
{
	Id = 14420610,
	CharName = "冒险协会会长",
	Text = "……你们两个不是每年都拿嘛，今年就让给新人吧。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_20_laoyeye_cos10",
	NextID = 14420611,
}
StorySpeechConfig[StorySpeechID.Id14420611] =
{
	Id = 14420611,
	CharName = "协会的同伴A",
	Text = "嗯？！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_05_jianshi_cos10",
	NextID = 14420612,
}
StorySpeechConfig[StorySpeechID.Id14420612] =
{
	Id = 14420612,
	CharName = "协会的同伴B",
	Text = "是可忍孰不可忍！干他！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_16_lieren_cos10",
}
StorySpeechConfig[StorySpeechID.Id14420901] =
{
	Id = 14420901,
	CharName = "栗子蛋糕公主",
	Text = "可可，这封情书请一定要帮我转交给我的小可乐噢~他一个人在煮物镇打拼事业，一定很希望收到我充满爱意的信的！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_03_qiaokelidan",
	NextID = 14420902,
}
StorySpeechConfig[StorySpeechID.Id14420902] =
{
	Id = 14420902,
	CharName = "白可可",
	Text = "嘻嘻，可乐殿下好幸福呀~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_32_baiseqiaokeli",
	NextID = 14420903,
}
StorySpeechConfig[StorySpeechID.Id14420903] =
{
	Id = 14420903,
	CharName = "栗子蛋糕公主",
	Text = "啊，哪有~好啦好啦，那就拜托你了，我走啦~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_03_qiaokelidan",
	NextID = 14420904,
}
StorySpeechConfig[StorySpeechID.Id14420904] =
{
	Id = 14420904,
	CharName = "冰淇淋公主",
	Text = "可可，这份巧克力可以帮我转交吗？一直只看偷偷看他帅气的侧脸，没想到他那天发短信说也在一直关注我。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_01_songbing",
	NextID = 14420905,
}
StorySpeechConfig[StorySpeechID.Id14420905] =
{
	Id = 14420905,
	CharName = "白可可",
	Text = "哇~公主也有心上人啦，嗯，我一定会完成使命的！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_32_baiseqiaokeli",
	NextID = 14420906,
}
StorySpeechConfig[StorySpeechID.Id14420906] =
{
	Id = 14420906,
	CharName = "冰淇淋公主",
	Text = "嗯，地址是煮物镇王子唱片公司，收件人是他们的董事长。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_01_songbing",
	NextID = 14420907,
}
StorySpeechConfig[StorySpeechID.Id14420907] =
{
	Id = 14420907,
	CharName = "白可可",
	Text = "咦？王子唱片的董事长吗？那不是…",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_32_baiseqiaokeli",
	NextID = 14420908,
}
StorySpeechConfig[StorySpeechID.Id14420908] =
{
	Id = 14420908,
	CharName = "冰淇淋公主",
	Text = "（害羞）啊~~别说啦，就拜托你啦~我先告辞了。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_01_songbing",
	NextID = 14420909,
}
StorySpeechConfig[StorySpeechID.Id14420909] =
{
	Id = 14420909,
	CharName = "蛋糕卷公主",
	Text = "可可，你在吗？我亲手绣了一条手帕，想给那个人。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_02_dangaojuan",
	NextID = 14420910,
}
StorySpeechConfig[StorySpeechID.Id14420910] =
{
	Id = 14420910,
	CharName = "白可可",
	Text = "嘿嘿，是啤酒殿下吗？你们终于和好啦？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_32_baiseqiaokeli",
	NextID = 14420911,
}
StorySpeechConfig[StorySpeechID.Id14420911] =
{
	Id = 14420911,
	CharName = "蛋糕卷公主",
	Text = "啊…不是，虽然我知道他是啤酒最好的朋友，我不该…但是，他那天对我说的情话，还请我看了电影，那种温暖的感觉…",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_02_dangaojuan",
	NextID = 14420912,
}
StorySpeechConfig[StorySpeechID.Id14420912] =
{
	Id = 14420912,
	CharName = "白可可",
	Text = "可是公主！啤酒殿下怎么办呢？他也好可怜的吧？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_32_baiseqiaokeli",
	NextID = 14420913,
}
StorySpeechConfig[StorySpeechID.Id14420913] =
{
	Id = 14420913,
	CharName = "蛋糕卷公主",
	Text = "我知道我对不起啤酒殿下。可是，爱情这东西，我自己也不能控制的！所以，请务必帮我转交给他的三弟，啊，拜托啦！（逃走）",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_02_dangaojuan",
	NextID = 14420914,
}
StorySpeechConfig[StorySpeechID.Id14420914] =
{
	Id = 14420914,
	CharName = "白可可",
	Text = "三弟？唔…那不还是可乐殿下嘛！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_32_baiseqiaokeli",
	NextID = 14420915,
}
StorySpeechConfig[StorySpeechID.Id14420915] =
{
	Id = 14420915,
	CharName = "棉花糖公主",
	Text = "可可姐姐，我想给一个唱歌很特别的哥哥送礼物，可以吗？他最近一直给我唱不太好听但听久了会习惯的情歌呢~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_04_mianhuatang",
	NextID = 14420916,
}
StorySpeechConfig[StorySpeechID.Id14420916] =
{
	Id = 14420916,
	CharName = "白可可",
	Text = "哇，我们的小棉花糖也有心上人了吗？好呀，是什么礼物呢？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_32_baiseqiaokeli",
	NextID = 14420917,
}
StorySpeechConfig[StorySpeechID.Id14420917] =
{
	Id = 14420917,
	CharName = "棉花糖公主",
	Text = "是定制的情侣装呢~~我这件是“乐”，他那件是“可”噢~~多谢可可姐姐~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_04_mianhuatang",
	NextID = 14420918,
}
StorySpeechConfig[StorySpeechID.Id14420918] =
{
	Id = 14420918,
	CharName = "白可可",
	Text = "什么！可乐这个可恶的感情骗子！竟然同时和公主们一起交往！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_32_baiseqiaokeli",
	NextID = 14420919,
}
StorySpeechConfig[StorySpeechID.Id14420919] =
{
	Id = 14420919,
	CharName = "可乐王子",
	Text = "啊，一个甜美的声音在呼唤我？可是她为什么叫我感情的骗子？美丽的小姐，难道我曾经伤过你那颗如同钻石般美丽的心吗？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_07_kele",
	NextID = 14420920,
}
StorySpeechConfig[StorySpeechID.Id14420920] =
{
	Id = 14420920,
	CharName = "白可可",
	Text = "可乐殿下，虽然你贵为王子，但是你如此玩弄公主们的感情，实在太可恶了！我一定要好好教训你一下！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_32_baiseqiaokeli",
	NextID = 14420921,
}
StorySpeechConfig[StorySpeechID.Id14420921] =
{
	Id = 14420921,
	CharName = "可乐王子",
	Text = "啊，美丽的女孩说要消灭我，可一看到你，我那脆弱的心就碰碰跳个不停，如果你真的殴打我，我体内黑色的糖浆一定会溅你一身的~",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_07_kele",
	NextID = 14420922,
}
StorySpeechConfig[StorySpeechID.Id14420922] =
{
	Id = 14420922,
	CharName = "白可可",
	Text = "流氓！我要代表巧克力消灭你！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_32_baiseqiaokeli",
}
StorySpeechConfig[StorySpeechID.Id14421001] =
{
	Id = 14421001,
	CharName = "旅行商人",
	Text = "客人，有什么我能帮到您的吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_14_lvxingshangren",
	NextID = 14421002,
}
StorySpeechConfig[StorySpeechID.Id14421002] =
{
	Id = 14421002,
	CharName = "旅行商人",
	Text = "诶？您看起来好眼熟……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_14_lvxingshangren",
	NextID = 14421003,
}
StorySpeechConfig[StorySpeechID.Id14421003] =
{
	Id = 14421003,
	CharName = "鱼罐头",
	Text = "额……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_03_yuren",
	NextID = 14421004,
}
StorySpeechConfig[StorySpeechID.Id14421004] =
{
	Id = 14421004,
	CharName = "旅行商人",
	Text = "我想起来了！您就是那个经常参加智力比赛，每次都在第一轮就被淘汰的……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_14_lvxingshangren",
	NextID = 14421005,
}
StorySpeechConfig[StorySpeechID.Id14421005] =
{
	Id = 14421005,
	CharName = "鱼罐头",
	Text = "咳咳……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_03_yuren",
	NextID = 14421006,
}
StorySpeechConfig[StorySpeechID.Id14421006] =
{
	Id = 14421006,
	CharName = "旅行商人",
	Text = "哎呀呀，真是失礼了。您需要点什么？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_14_lvxingshangren",
	NextID = 14421007,
}
StorySpeechConfig[StorySpeechID.Id14421007] =
{
	Id = 14421007,
	CharName = "鱼罐头",
	Text = "我想买套服装，最好穿上去之后，别人完全认不出我。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_03_yuren",
	NextID = 14421008,
}
StorySpeechConfig[StorySpeechID.Id14421008] =
{
	Id = 14421008,
	CharName = "旅行商人",
	Text = "哦哦哦！我明白了！您是因为智力比赛只允许同一个人参加100次，所以想……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_14_lvxingshangren",
	NextID = 14421009,
}
StorySpeechConfig[StorySpeechID.Id14421009] =
{
	Id = 14421009,
	CharName = "鱼罐头",
	Text = "咳咳……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_03_yuren",
	NextID = 14421010,
}
StorySpeechConfig[StorySpeechID.Id14421010] =
{
	Id = 14421010,
	CharName = "旅行商人",
	Text = "哎呀呀，真是失礼了。您稍等！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_14_lvxingshangren",
	NextID = 14421011,
}
StorySpeechConfig[StorySpeechID.Id14421011] =
{
	Id = 14421011,
	CharName = "旅行商人",
	Text = "我敢说，穿上这套衣服后，只要不开口，连亲妈都认不出你来！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_14_lvxingshangren",
	NextID = 14421012,
}
StorySpeechConfig[StorySpeechID.Id14421012] =
{
	Id = 14421012,
	CharName = "鱼罐头",
	Text = "（点头）还挺合身的……就要这套了，多少钱？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_03_yuren",
	NextID = 14421013,
}
StorySpeechConfig[StorySpeechID.Id14421013] =
{
	Id = 14421013,
	CharName = "旅行商人",
	Text = "衣服只要100金币，剩下还需要您支付下封口费，嘿嘿……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_14_lvxingshangren",
	NextID = 14421014,
}
StorySpeechConfig[StorySpeechID.Id14421014] =
{
	Id = 14421014,
	CharName = "鱼罐头",
	Text = "这是100金币，给你！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_03_yuren",
	NextID = 14421015,
}
StorySpeechConfig[StorySpeechID.Id14421015] =
{
	Id = 14421015,
	CharName = "旅行商人",
	Text = "不是，客人……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_14_lvxingshangren",
	NextID = 14421016,
}
StorySpeechConfig[StorySpeechID.Id14421016] =
{
	Id = 14421016,
	CharName = "鱼罐头",
	Text = "怎么了？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_03_yuren",
	NextID = 14421017,
}
StorySpeechConfig[StorySpeechID.Id14421017] =
{
	Id = 14421017,
	CharName = "旅行商人",
	Text = "您不希望我帮您遮掩身份吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_14_lvxingshangren",
	NextID = 14421018,
}
StorySpeechConfig[StorySpeechID.Id14421018] =
{
	Id = 14421018,
	CharName = "鱼罐头",
	Text = "你刚才不是说，我只要不说话，连我妈都认不出我来吗？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_03_yuren",
	NextID = 14421019,
}
StorySpeechConfig[StorySpeechID.Id14421019] =
{
	Id = 14421019,
	CharName = "旅行商人",
	Text = "是这样的，可……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_14_lvxingshangren",
	NextID = 14421020,
}
StorySpeechConfig[StorySpeechID.Id14421020] =
{
	Id = 14421020,
	CharName = "鱼罐头",
	Text = "那就不需要你帮我遮掩了。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_03_yuren",
	NextID = 14421021,
}
StorySpeechConfig[StorySpeechID.Id14421021] =
{
	Id = 14421021,
	CharName = "旅行商人",
	Text = "我……额……客人，您是在装傻吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_14_lvxingshangren",
	NextID = 14421022,
}
StorySpeechConfig[StorySpeechID.Id14421022] =
{
	Id = 14421022,
	CharName = "鱼罐头",
	Text = "什么意思？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_03_yuren",
	NextID = 14421023,
}
StorySpeechConfig[StorySpeechID.Id14421023] =
{
	Id = 14421023,
	CharName = "旅行商人",
	Text = "呵呵……看来是我误会您了，您是真傻！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_14_lvxingshangren",
	NextID = 14421024,
}
StorySpeechConfig[StorySpeechID.Id14421024] =
{
	Id = 14421024,
	CharName = "鱼罐头",
	Text = "（皱眉）我最讨厌别人说我傻了……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_03_yuren",
}
StorySpeechConfig[StorySpeechID.Id14421101] =
{
	Id = 14421101,
	CharName = "擂主",
	Text = "我这一年，研制出了“魔鬼辣椒”，只要吃下去，必定让人感觉见鬼般恐怖。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	LeftIcon = "Pir_01_DarkCooker",
	NextID = 14421102,
}
StorySpeechConfig[StorySpeechID.Id14421102] =
{
	Id = 14421102,
	CharName = "辣辣子",
	Text = "我这一年，研制出了“天使辣椒”，只要吃下去，必定让人感觉立马升天。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_103_GhostChili",
	NextID = 14421103,
}
StorySpeechConfig[StorySpeechID.Id14421103] =
{
	Id = 14421103,
	CharName = "擂主",
	Text = "既然这么有自信，不如我们交换一下？",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	LeftIcon = "Pir_01_DarkCooker",
	NextID = 14421104,
}
StorySpeechConfig[StorySpeechID.Id14421104] =
{
	Id = 14421104,
	CharName = "辣辣子",
	Text = "可以。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_103_GhostChili",
	NextID = 14421105,
}
StorySpeechConfig[StorySpeechID.Id14421105] =
{
	Id = 14421105,
	CharName = "擂主",
	Text = "（吃辣椒）……",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	LeftIcon = "Pir_01_DarkCooker",
	NextID = 14421106,
}
StorySpeechConfig[StorySpeechID.Id14421106] =
{
	Id = 14421106,
	CharName = "辣辣子",
	Text = "（吃辣椒）……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_103_GhostChili",
	NextID = 14421107,
}
StorySpeechConfig[StorySpeechID.Id14421107] =
{
	Id = 14421107,
	CharName = "擂主",
	Text = "哇啊……过瘾……",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	LeftIcon = "Pir_01_DarkCooker",
	NextID = 14421108,
}
StorySpeechConfig[StorySpeechID.Id14421108] =
{
	Id = 14421108,
	CharName = "辣辣子",
	Text = "嗷嗷……痛快……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_103_GhostChili",
	NextID = 14421109,
}
StorySpeechConfig[StorySpeechID.Id14421109] =
{
	Id = 14421109,
	CharName = "主持人",
	Text = "按照规矩，接下来只要能将对方从擂台上推下去，就算赢！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_men4",
	NextID = 14421110,
}
StorySpeechConfig[StorySpeechID.Id14421110] =
{
	Id = 14421110,
	CharName = "擂主",
	Text = "！",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	RightIcon = "Pir_01_DarkCooker",
	NextID = 14421111,
}
StorySpeechConfig[StorySpeechID.Id14421111] =
{
	Id = 14421111,
	CharName = "辣辣子",
	Text = "！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_103_GhostChili",
}
StorySpeechConfig[StorySpeechID.Id14421201] =
{
	Id = 14421201,
	CharName = "板蓝根泡面",
	Text = "你看，抹茶含有丰富的人体所必须的营养成分和微量元素。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_104_IsatisNoodle",
	NextID = 14421202,
}
StorySpeechConfig[StorySpeechID.Id14421202] =
{
	Id = 14421202,
	CharName = "路人甲",
	Text = "……",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_men4",
	NextID = 14421203,
}
StorySpeechConfig[StorySpeechID.Id14421203] =
{
	Id = 14421203,
	CharName = "板蓝根泡面",
	Text = "普通茶虽然含有极高的营养成分、但是茶叶里真正溶于水的部分仅仅为35%。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_104_IsatisNoodle",
	NextID = 14421204,
}
StorySpeechConfig[StorySpeechID.Id14421204] =
{
	Id = 14421204,
	CharName = "路人甲",
	Text = "……",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_men4",
	NextID = 14421205,
}
StorySpeechConfig[StorySpeechID.Id14421205] =
{
	Id = 14421205,
	CharName = "板蓝根泡面",
	Text = "一碗抹茶里的营养成分超过30杯普通绿茶，所以茶道老师们几乎无一不长寿天年。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_104_IsatisNoodle",
	NextID = 14421206,
}
StorySpeechConfig[StorySpeechID.Id14421206] =
{
	Id = 14421206,
	CharName = "路人甲",
	Text = "……",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_men4",
	NextID = 14421207,
}
StorySpeechConfig[StorySpeechID.Id14421207] =
{
	Id = 14421207,
	CharName = "板蓝根泡面",
	Text = "你试一试，一旦尝了第一口，就会停不下来的。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_104_IsatisNoodle",
	NextID = 14421208,
}
StorySpeechConfig[StorySpeechID.Id14421208] =
{
	Id = 14421208,
	CharName = "路人甲",
	Text = "道理我都懂，但是我真的吃不下去……",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_men4",
	NextID = 14421209,
}
StorySpeechConfig[StorySpeechID.Id14421209] =
{
	Id = 14421209,
	CharName = "板蓝根泡面",
	Text = "抹茶这么健康，为什么吃不下去呢？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_104_IsatisNoodle",
	NextID = 14421210,
}
StorySpeechConfig[StorySpeechID.Id14421210] =
{
	Id = 14421210,
	CharName = "路人甲",
	Text = "因为这个抹茶和泡面在一起，绿油油的看着就没有胃口，我真的吃不下去！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_men4",
	NextID = 14421211,
}
StorySpeechConfig[StorySpeechID.Id14421211] =
{
	Id = 14421211,
	CharName = "板蓝根泡面",
	Text = "哎呀，你可以闭着眼睛吃呀。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_104_IsatisNoodle",
	NextID = 14421212,
}
StorySpeechConfig[StorySpeechID.Id14421212] =
{
	Id = 14421212,
	CharName = "路人甲",
	Text = "你再拦着我，我真的要动手了！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_men4",
}
StorySpeechConfig[StorySpeechID.Id14421301] =
{
	Id = 14421301,
	CharName = "皮蛋披萨",
	Text = "那个，鲱鱼君，我有点事情想和你商量下。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_106_PreservedEggPizza",
	NextID = 14421302,
}
StorySpeechConfig[StorySpeechID.Id14421302] =
{
	Id = 14421302,
	CharName = "鲱鱼饭团",
	Text = "哦？什么事啊？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_105_HerringRiceBall",
	NextID = 14421303,
}
StorySpeechConfig[StorySpeechID.Id14421303] =
{
	Id = 14421303,
	CharName = "皮蛋披萨",
	Text = "我的客人都是高度近视眼，我问了养生大师，养生大师说可以用以形补形的方式来帮助他们。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_106_PreservedEggPizza",
	NextID = 14421304,
}
StorySpeechConfig[StorySpeechID.Id14421304] =
{
	Id = 14421304,
	CharName = "鲱鱼饭团",
	Text = "所以呢？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_105_HerringRiceBall",
	NextID = 14421305,
}
StorySpeechConfig[StorySpeechID.Id14421305] =
{
	Id = 14421305,
	CharName = "皮蛋披萨",
	Text = "反正你的鲱鱼销路也一般，不如把鲱鱼的眼睛给我？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_106_PreservedEggPizza",
	NextID = 14421306,
}
StorySpeechConfig[StorySpeechID.Id14421306] =
{
	Id = 14421306,
	CharName = "鲱鱼饭团",
	Text = "不行！我做生意从来不缺斤少两。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_105_HerringRiceBall",
	NextID = 14421307,
}
StorySpeechConfig[StorySpeechID.Id14421307] =
{
	Id = 14421307,
	CharName = "皮蛋披萨",
	Text = "但每条鱼少两只眼睛，连1两都不到啊……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_106_PreservedEggPizza",
	NextID = 14421308,
}
StorySpeechConfig[StorySpeechID.Id14421308] =
{
	Id = 14421308,
	CharName = "鲱鱼饭团",
	Text = "这涉及到做生意的原则，我不给。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_105_HerringRiceBall",
	NextID = 14421309,
}
StorySpeechConfig[StorySpeechID.Id14421309] =
{
	Id = 14421309,
	CharName = "皮蛋披萨",
	Text = "那我买下这些鲱鱼行了吧？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_106_PreservedEggPizza",
	NextID = 14421310,
}
StorySpeechConfig[StorySpeechID.Id14421310] =
{
	Id = 14421310,
	CharName = "鲱鱼饭团",
	Text = "不卖！你只要眼睛的话，就会浪费很多食材！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_105_HerringRiceBall",
	NextID = 14421311,
}
StorySpeechConfig[StorySpeechID.Id14421311] =
{
	Id = 14421311,
	CharName = "皮蛋披萨",
	Text = "你这个人好固执啊，看来好好讲道理是不行了……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_106_PreservedEggPizza",
}
StorySpeechConfig[StorySpeechID.Id14421401] =
{
	Id = 14421401,
	CharName = "客人",
	Text = "老板，这个鲱鱼味道有点大，真的咽不下去啊。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_oldmen1",
	NextID = 14421402,
}
StorySpeechConfig[StorySpeechID.Id14421402] =
{
	Id = 14421402,
	CharName = "鲱鱼饭团",
	Text = "额……客人，只要能忍受住最开始的味道，您的就体会到美味了。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_105_HerringRiceBall",
	NextID = 14421403,
}
StorySpeechConfig[StorySpeechID.Id14421403] =
{
	Id = 14421403,
	CharName = "客人",
	Text = "可是这味道确实让人受不了啊，老板，有没有洋葱，我看看能不能盖住这个味道。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_oldmen1",
	NextID = 14421404,
}
StorySpeechConfig[StorySpeechID.Id14421404] =
{
	Id = 14421404,
	CharName = "鲱鱼饭团",
	Text = "有的，您请稍等。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_105_HerringRiceBall",
	NextID = 14421405,
}
StorySpeechConfig[StorySpeechID.Id14421405] =
{
	Id = 14421405,
	CharName = "客人",
	Text = "光是洋葱有点呛，有没有芝士可以让我涂抹一点？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_oldmen1",
	NextID = 14421406,
}
StorySpeechConfig[StorySpeechID.Id14421406] =
{
	Id = 14421406,
	CharName = "鲱鱼饭团",
	Text = "有的有的，给！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_105_HerringRiceBall",
	NextID = 14421407,
}
StorySpeechConfig[StorySpeechID.Id14421407] =
{
	Id = 14421407,
	CharName = "客人",
	Text = "可是这样又会完全盖住鲱鱼的味道……",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_oldmen1",
	NextID = 14421408,
}
StorySpeechConfig[StorySpeechID.Id14421408] =
{
	Id = 14421408,
	CharName = "鲱鱼饭团",
	Text = "那……我再给您加条鱼。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_105_HerringRiceBall",
	NextID = 14421409,
}
StorySpeechConfig[StorySpeechID.Id14421409] =
{
	Id = 14421409,
	CharName = "客人",
	Text = "哎呀，这样味道又出来了呢。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_oldmen1",
	NextID = 14421410,
}
StorySpeechConfig[StorySpeechID.Id14421410] =
{
	Id = 14421410,
	CharName = "鲱鱼饭团",
	Text = "您稍等……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_105_HerringRiceBall",
	NextID = 14421411,
}
StorySpeechConfig[StorySpeechID.Id14421411] =
{
	Id = 14421411,
	CharName = "客人",
	Text = "（各种要求）……",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_oldmen1",
	NextID = 14421412,
}
StorySpeechConfig[StorySpeechID.Id14421412] =
{
	Id = 14421412,
	CharName = "鲱鱼饭团",
	Text = "（满足要求）……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_105_HerringRiceBall",
	NextID = 14421413,
}
StorySpeechConfig[StorySpeechID.Id14421413] =
{
	Id = 14421413,
	CharName = "客人",
	Text = "嗯～这个鲱鱼料理吃得好满足！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_oldmen1",
	NextID = 14421414,
}
StorySpeechConfig[StorySpeechID.Id14421414] =
{
	Id = 14421414,
	CharName = "鲱鱼饭团",
	Text = "客人，这是您的账单。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_105_HerringRiceBall",
	NextID = 14421415,
}
StorySpeechConfig[StorySpeechID.Id14421415] =
{
	Id = 14421415,
	CharName = "客人",
	Text = "啊！这么贵！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_oldmen1",
	NextID = 14421416,
}
StorySpeechConfig[StorySpeechID.Id14421416] =
{
	Id = 14421416,
	CharName = "鲱鱼饭团",
	Text = "您看，毕竟您加了很多的食材。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_105_HerringRiceBall",
	NextID = 14421417,
}
StorySpeechConfig[StorySpeechID.Id14421417] =
{
	Id = 14421417,
	CharName = "客人",
	Text = "不行，我只点了一个饭团，我只给一个饭团的钱！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_oldmen1",
	NextID = 14421418,
}
StorySpeechConfig[StorySpeechID.Id14421418] =
{
	Id = 14421418,
	CharName = "鲱鱼饭团",
	Text = "客人，您这样是想赖账吗？您不付钱，今天别想走。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_105_HerringRiceBall",
	NextID = 14421419,
}
StorySpeechConfig[StorySpeechID.Id14421419] =
{
	Id = 14421419,
	CharName = "客人",
	Text = "哼！你还敢拦我？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_oldmen1",
}
StorySpeechConfig[StorySpeechID.Id14421501] =
{
	Id = 14421501,
	CharName = "基维燕克",
	Text = "我最近对企鹅产生了兴趣。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_107_Kiviac",
	NextID = 14421502,
}
StorySpeechConfig[StorySpeechID.Id14421502] =
{
	Id = 14421502,
	CharName = "板蓝根泡面",
	Text = "这是为什么？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_104_IsatisNoodle",
	NextID = 14421503,
}
StorySpeechConfig[StorySpeechID.Id14421503] =
{
	Id = 14421503,
	CharName = "基维燕克",
	Text = "企鹅的块头很大，比海燕大多了，如果发酵企鹅会有更多的营养可以摄入。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_107_Kiviac",
	NextID = 14421504,
}
StorySpeechConfig[StorySpeechID.Id14421504] =
{
	Id = 14421504,
	CharName = "板蓝根泡面",
	Text = "所以，你想接下来抓企鹅来发酵？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_104_IsatisNoodle",
	NextID = 14421505,
}
StorySpeechConfig[StorySpeechID.Id14421505] =
{
	Id = 14421505,
	CharName = "基维燕克",
	Text = "没错！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_107_Kiviac",
	NextID = 14421506,
}
StorySpeechConfig[StorySpeechID.Id14421506] =
{
	Id = 14421506,
	CharName = "板蓝根泡面",
	Text = "你直接抓就是了，为什么要专程跑来和我说这件事？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_104_IsatisNoodle",
	NextID = 14421507,
}
StorySpeechConfig[StorySpeechID.Id14421507] =
{
	Id = 14421507,
	CharName = "基维燕克",
	Text = "我体内还有不少海燕，要是扔掉太可惜了。我一个人又吃不完，所以想和你一起分享！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_107_Kiviac",
	NextID = 14421508,
}
StorySpeechConfig[StorySpeechID.Id14421508] =
{
	Id = 14421508,
	CharName = "基维燕克",
	Text = "就着你的泡面，应该味道很不错吧？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_107_Kiviac",
	NextID = 14421509,
}
StorySpeechConfig[StorySpeechID.Id14421509] =
{
	Id = 14421509,
	CharName = "板蓝根泡面",
	Text = "额……泡面让给你，海燕就不用客气了。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_104_IsatisNoodle",
	NextID = 14421510,
}
StorySpeechConfig[StorySpeechID.Id14421510] =
{
	Id = 14421510,
	CharName = "基维燕克",
	Text = "哪有光吃你的泡面不给回报的道理，今天我一定要和你好好吃顿大餐。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_107_Kiviac",
	NextID = 14421511,
}
StorySpeechConfig[StorySpeechID.Id14421511] =
{
	Id = 14421511,
	CharName = "板蓝根泡面",
	Text = "别！你别过来！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_104_IsatisNoodle",
}
StorySpeechConfig[StorySpeechID.Id14421601] =
{
	Id = 14421601,
	CharName = "西式面点师",
	Text = "我是不会教授给你菠萝包的制作方法的！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_men2",
	NextID = 14421602,
}
StorySpeechConfig[StorySpeechID.Id14421602] =
{
	Id = 14421602,
	CharName = "猪猪包",
	Text = "我很有诚意的，您看，我都带了猪脑包作为见面礼。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_108_SteamedBun",
	NextID = 14421603,
}
StorySpeechConfig[StorySpeechID.Id14421603] =
{
	Id = 14421603,
	CharName = "西式面点师",
	Text = "菠萝包是圣洁的，配合咖啡或者奶茶就能帮助人们度过一个完美的下午。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_men2",
	NextID = 14421604,
}
StorySpeechConfig[StorySpeechID.Id14421604] =
{
	Id = 14421604,
	CharName = "西式面点师",
	Text = "我不会允许你这样的人，将猪脑灌入其中的！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_men2",
	NextID = 14421605,
}
StorySpeechConfig[StorySpeechID.Id14421605] =
{
	Id = 14421605,
	CharName = "猪猪包",
	Text = "可是，猪脑包里面真的有猪脑，菠萝包里面却没有菠萝，这么看起来，是不是也有欺骗消费者的嫌疑呢？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_108_SteamedBun",
	NextID = 14421606,
}
StorySpeechConfig[StorySpeechID.Id14421606] =
{
	Id = 14421606,
	CharName = "西式面点师",
	Text = "你住口！菠萝包是因为外表像菠萝才叫菠萝包的！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_men2",
	NextID = 14421607,
}
StorySpeechConfig[StorySpeechID.Id14421607] =
{
	Id = 14421607,
	CharName = "猪猪包",
	Text = "也就是说，您也承认，这里面确实没有菠萝？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_108_SteamedBun",
	NextID = 14421608,
}
StorySpeechConfig[StorySpeechID.Id14421608] =
{
	Id = 14421608,
	CharName = "西式面点师",
	Text = "你……你！你给我滚！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_men2",
	NextID = 14421609,
}
StorySpeechConfig[StorySpeechID.Id14421609] =
{
	Id = 14421609,
	CharName = "猪猪包",
	Text = "不行，今天您不教给我制作菠萝包的方法，我不走。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_108_SteamedBun",
	NextID = 14421610,
}
StorySpeechConfig[StorySpeechID.Id14421610] =
{
	Id = 14421610,
	CharName = "猪猪包",
	Text = "不仅如此，我还要在您的店旁边开一家包子店，直到您松口为止。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_108_SteamedBun",
	NextID = 14421611,
}
StorySpeechConfig[StorySpeechID.Id14421611] =
{
	Id = 14421611,
	CharName = "西式面点师",
	Text = "你这个家伙，看来不给你点教训你是不长记性的！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_men2",
}
StorySpeechConfig[StorySpeechID.Id14421701] =
{
	Id = 14421701,
	CharName = "咖喱店老板",
	Text = "猫猫，来我这里呀，这里有新鲜的猫粮，嘿嘿嘿……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_102_KopiLuwak_cos10",
	NextID = 14421702,
}
StorySpeechConfig[StorySpeechID.Id14421702] =
{
	Id = 14421702,
	CharName = "史卡",
	Text = "你在干什么？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_102_KopiLuwak",
	NextID = 14421703,
}
StorySpeechConfig[StorySpeechID.Id14421703] =
{
	Id = 14421703,
	CharName = "咖喱店老板",
	Text = "啊？我啊？我在喂猫猫吃猫粮啊。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_102_KopiLuwak_cos10",
	NextID = 14421704,
}
StorySpeechConfig[StorySpeechID.Id14421704] =
{
	Id = 14421704,
	CharName = "史卡",
	Text = "怎么还有其他东西？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_102_KopiLuwak",
	NextID = 14421705,
}
StorySpeechConfig[StorySpeechID.Id14421705] =
{
	Id = 14421705,
	CharName = "咖喱店老板",
	Text = "额，这些是……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_102_KopiLuwak_cos10",
	NextID = 14421706,
}
StorySpeechConfig[StorySpeechID.Id14421706] =
{
	Id = 14421706,
	CharName = "史卡",
	Text = "哦~原来这些是香辛料，我猜你是想让猫猫吃下这些香辛料，再用它们的粑粑来制作咖喱，对不对？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_102_KopiLuwak",
	NextID = 14421707,
}
StorySpeechConfig[StorySpeechID.Id14421707] =
{
	Id = 14421707,
	CharName = "咖喱店老板",
	Text = "你……你怎么知道？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_102_KopiLuwak_cos10",
	NextID = 14421708,
}
StorySpeechConfig[StorySpeechID.Id14421708] =
{
	Id = 14421708,
	CharName = "史卡",
	Text = "因为我尝过你们家的咖喱。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_102_KopiLuwak",
	NextID = 14421709,
}
StorySpeechConfig[StorySpeechID.Id14421709] =
{
	Id = 14421709,
	CharName = "咖喱店老板",
	Text = "你不会把我的事情……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_102_KopiLuwak_cos10",
	NextID = 14421710,
}
StorySpeechConfig[StorySpeechID.Id14421710] =
{
	Id = 14421710,
	CharName = "史卡",
	Text = "我更感兴趣的是，这些猫猫戒备心很强，你是怎么让它们靠近的？是这高级猫粮吗？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_102_KopiLuwak",
	NextID = 14421711,
}
StorySpeechConfig[StorySpeechID.Id14421711] =
{
	Id = 14421711,
	CharName = "咖喱店老板",
	Text = "猫粮虽然味道好，但更重要的是这身装扮！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_102_KopiLuwak_cos10",
	NextID = 14421712,
}
StorySpeechConfig[StorySpeechID.Id14421712] =
{
	Id = 14421712,
	CharName = "史卡",
	Text = "这套猫猫装看上去没什么特别的啊。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_102_KopiLuwak",
	NextID = 14421713,
}
StorySpeechConfig[StorySpeechID.Id14421713] =
{
	Id = 14421713,
	CharName = "咖喱店老板",
	Text = "这身衣服已经染上了各种猫猫喜欢的味道，小鱼干、猫粮……没有哪只猫猫能拒绝！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_102_KopiLuwak_cos10",
	NextID = 14421714,
}
StorySpeechConfig[StorySpeechID.Id14421714] =
{
	Id = 14421714,
	CharName = "史卡",
	Text = "真是个好办法！这衣服能卖给我吗？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_102_KopiLuwak",
	NextID = 14421715,
}
StorySpeechConfig[StorySpeechID.Id14421715] =
{
	Id = 14421715,
	CharName = "咖喱店老板",
	Text = "不行！要是卖给你，我怎么吸引猫猫啊？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_102_KopiLuwak_cos10",
	NextID = 14421716,
}
StorySpeechConfig[StorySpeechID.Id14421716] =
{
	Id = 14421716,
	CharName = "史卡",
	Text = "你要是不卖的话，我就告诉你的客人们，你是用什么做咖喱的。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_102_KopiLuwak",
	NextID = 14421717,
}
StorySpeechConfig[StorySpeechID.Id14421717] =
{
	Id = 14421717,
	CharName = "咖喱店老板",
	Text = "你你你……我想起来了，你是那个卖咖啡的！原来如此！我知道为什么你的咖啡那么美味了！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_102_KopiLuwak_cos10",
	NextID = 14421718,
}
StorySpeechConfig[StorySpeechID.Id14421718] =
{
	Id = 14421718,
	CharName = "史卡",
	Text = "……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_102_KopiLuwak",
}
StorySpeechConfig[StorySpeechID.Id14421801] =
{
	Id = 14421801,
	CharName = "评委A",
	Text = "拜兰帝，考虑到你在酿酒方面不断钻研的精神，虽然你一直没有酿造出100度的酒，但也无限接近了，所以我们决定为你破一次例。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_women2",
	NextID = 14421802,
}
StorySpeechConfig[StorySpeechID.Id14421802] =
{
	Id = 14421802,
	CharName = "拜兰帝",
	Text = "难道是？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_101_Brandy",
	NextID = 14421803,
}
StorySpeechConfig[StorySpeechID.Id14421803] =
{
	Id = 14421803,
	CharName = "评委B",
	Text = "对！我们要正式将你从黄金酿酒师的级别上调，变成从来没人达成的钻石级别的酿酒师！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_women1",
	NextID = 14421804,
}
StorySpeechConfig[StorySpeechID.Id14421804] =
{
	Id = 14421804,
	CharName = "拜兰帝",
	Text = "可是……",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_101_Brandy",
	NextID = 14421805,
}
StorySpeechConfig[StorySpeechID.Id14421805] =
{
	Id = 14421805,
	CharName = "评委C",
	Text = "不用可是了，你孜孜不倦的精神打动了我们，这是你应得的。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_oldmen1",
	NextID = 14421806,
}
StorySpeechConfig[StorySpeechID.Id14421806] =
{
	Id = 14421806,
	CharName = "拜兰帝",
	Text = "嗯……我拒绝！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_101_Brandy",
	NextID = 14421807,
}
StorySpeechConfig[StorySpeechID.Id14421807] =
{
	Id = 14421807,
	CharName = "评委A",
	Text = "啊，这是为什么？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_women2",
	NextID = 14421808,
}
StorySpeechConfig[StorySpeechID.Id14421808] =
{
	Id = 14421808,
	CharName = "拜兰帝",
	Text = "我还是希望以实力而非毅力来打动你们。这是我新酿造的酒，你们喝光后再做评判吧。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_101_Brandy",
	NextID = 14421809,
}
StorySpeechConfig[StorySpeechID.Id14421809] =
{
	Id = 14421809,
	CharName = "评委B",
	Text = "这……这……",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_women1",
	NextID = 14421810,
}
StorySpeechConfig[StorySpeechID.Id14421810] =
{
	Id = 14421810,
	CharName = "评委C",
	Text = "算我们求你了，你就接受吧！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_oldmen1",
	NextID = 14421811,
}
StorySpeechConfig[StorySpeechID.Id14421811] =
{
	Id = 14421811,
	CharName = "评委A",
	Text = "我们三个因为不断喝你酿造的高度酒，已经快要酒精性肝硬化了……",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_women2",
	NextID = 14421812,
}
StorySpeechConfig[StorySpeechID.Id14421812] =
{
	Id = 14421812,
	CharName = "评委B",
	Text = "就是就是，你放过我们吧……",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_women1",
	NextID = 14421813,
}
StorySpeechConfig[StorySpeechID.Id14421813] =
{
	Id = 14421813,
	CharName = "拜兰帝",
	Text = "嗯……还是不行，如果你们不帮我品尝的话，我根本不知道自己有没有酿造成功。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_101_Brandy",
	NextID = 14421814,
}
StorySpeechConfig[StorySpeechID.Id14421814] =
{
	Id = 14421814,
	CharName = "拜兰帝",
	Text = "这样吧，你们喝一半，怎么样？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_101_Brandy",
	NextID = 14421815,
}
StorySpeechConfig[StorySpeechID.Id14421815] =
{
	Id = 14421815,
	CharName = "评委C",
	Text = "天哪！这人怎么不听劝？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_oldmen1",
	NextID = 14421816,
}
StorySpeechConfig[StorySpeechID.Id14421816] =
{
	Id = 14421816,
	CharName = "评委A",
	Text = "这酒我们今天说什么都不会再喝了！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_women2",
	NextID = 14421817,
}
StorySpeechConfig[StorySpeechID.Id14421817] =
{
	Id = 14421817,
	CharName = "评委B",
	Text = "你再这样，我们真的要翻脸了！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_women1",
	NextID = 14421818,
}
StorySpeechConfig[StorySpeechID.Id14421818] =
{
	Id = 14421818,
	CharName = "拜兰帝",
	Text = "你们不喝吗？那我只能用那句老话了。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_101_Brandy",
	NextID = 14421819,
}
StorySpeechConfig[StorySpeechID.Id14421819] =
{
	Id = 14421819,
	CharName = "评委C",
	Text = "什么老话？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_oldmen1",
	NextID = 14421820,
}
StorySpeechConfig[StorySpeechID.Id14421820] =
{
	Id = 14421820,
	CharName = "拜兰帝",
	Text = "敬酒不吃吃罚酒！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_101_Brandy",
}
StorySpeechConfig[StorySpeechID.Id14416301] =
{
	Id = 14416301,
	CharName = "白鲨牙牙",
	Text = "你好，我想换个发型。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_13_shayu",
	NextID = 14416302,
}
StorySpeechConfig[StorySpeechID.Id14416302] =
{
	Id = 14416302,
	CharName = "造型师",
	Text = "好的，这次想要什么样的呢~",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_29_kaitangshoujieke_cos10",
	NextID = 14416303,
}
StorySpeechConfig[StorySpeechID.Id14416303] =
{
	Id = 14416303,
	CharName = "白鲨牙牙",
	Text = "最近在拍摄学习机的广告，想做一个偏年轻的一点的，让小朋友们一看就很喜欢的头发~",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_13_shayu",
	NextID = 14416304,
}
StorySpeechConfig[StorySpeechID.Id14416304] =
{
	Id = 14416304,
	CharName = "造型师",
	Text = "我懂了，就是那种……儿童感，对吧？完全没问题！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_29_kaitangshoujieke_cos10",
	NextID = 14416305,
}
StorySpeechConfig[StorySpeechID.Id14416305] =
{
	Id = 14416305,
	CharName = "造型师",
	Text = "（一顿操作）好了，你看看？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_29_kaitangshoujieke_cos10",
	NextID = 14416306,
}
StorySpeechConfig[StorySpeechID.Id14416306] =
{
	Id = 14416306,
	CharName = "白鲨牙牙",
	Text = "这是什么啊？！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_13_shayu",
	NextID = 14416307,
}
StorySpeechConfig[StorySpeechID.Id14416307] =
{
	Id = 14416307,
	CharName = "造型师",
	Text = "您看，我把您的鲨鱼头饰一劈为二，分饰在左右两侧，就像小孩儿的发髻……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_29_kaitangshoujieke_cos10",
	NextID = 14416308,
}
StorySpeechConfig[StorySpeechID.Id14416308] =
{
	Id = 14416308,
	CharName = "造型师",
	Text = "您别，别生气啊——有什么不满意的我可以改——啊！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_29_kaitangshoujieke_cos10",
}
StorySpeechConfig[StorySpeechID.Id14416401] =
{
	Id = 14416401,
	CharName = "鲸鲨依伶",
	Text = "（走进休息室）啊，今天好累……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_12_jingsha",
	NextID = 14416402,
}
StorySpeechConfig[StorySpeechID.Id14416402] =
{
	Id = 14416402,
	CharName = "过激粉丝",
	Text = "呀——依伶酱再出来一下吧！（尖叫）依伶酱——！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_naked1",
	NextID = 14416403,
}
StorySpeechConfig[StorySpeechID.Id14416403] =
{
	Id = 14416403,
	CharName = "鲸鲨依伶",
	Text = "（叹气）好累啊……唉，我出去安抚一下TA吧。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_12_jingsha",
	NextID = 14416404,
}
StorySpeechConfig[StorySpeechID.Id14416404] =
{
	Id = 14416404,
	CharName = "虎鲸京",
	Text = "依伶，如果很累的话，就别去管TA了。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_14_hujing",
	NextID = 14416405,
}
StorySpeechConfig[StorySpeechID.Id14416405] =
{
	Id = 14416405,
	CharName = "鲸鲨依伶",
	Text = "可是，我……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_12_jingsha",
	NextID = 14416406,
}
StorySpeechConfig[StorySpeechID.Id14416406] =
{
	Id = 14416406,
	CharName = "白鲨牙牙",
	Text = "你这么面面俱到，就不怕会累死自己呀？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_13_shayu",
	NextID = 14416407,
}
StorySpeechConfig[StorySpeechID.Id14416407] =
{
	Id = 14416407,
	CharName = "虎鲸京",
	Text = "是啊，依伶，有时候也不用那么累的，更加随心所欲一点吧。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_14_hujing",
	NextID = 14416408,
}
StorySpeechConfig[StorySpeechID.Id14416408] =
{
	Id = 14416408,
	CharName = "鲸鲨依伶",
	Text = "我……好！那现在，我……？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_12_jingsha",
	NextID = 14416409,
}
StorySpeechConfig[StorySpeechID.Id14416409] =
{
	Id = 14416409,
	CharName = "白鲨牙牙",
	Text = "你应该出门去，把这种骚扰人的私生暴揍一顿！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_13_shayu",
	NextID = 14416410,
}
StorySpeechConfig[StorySpeechID.Id14416410] =
{
	Id = 14416410,
	CharName = "鲸鲨依伶",
	Text = "（思索）……好！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_12_jingsha",
}
StorySpeechConfig[StorySpeechID.Id14416501] =
{
	Id = 14416501,
	CharName = "琵琶映冬",
	Text = "您好，我想定制一套男装！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_16_jingyu",
	NextID = 14416502,
}
StorySpeechConfig[StorySpeechID.Id14416502] =
{
	Id = 14416502,
	CharName = "服装设计师",
	Text = "什么？到底发生了什么，让你有了这样的想法。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_29_kaitangshoujieke_cos10",
	NextID = 14416503,
}
StorySpeechConfig[StorySpeechID.Id14416503] =
{
	Id = 14416503,
	CharName = "琵琶映冬",
	Text = "我的偶像今天穿了一套男装。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_16_jingyu",
	NextID = 14416504,
}
StorySpeechConfig[StorySpeechID.Id14416504] =
{
	Id = 14416504,
	CharName = "服装设计师",
	Text = "嗯，可那又怎么了？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_29_kaitangshoujieke_cos10",
	NextID = 14416505,
}
StorySpeechConfig[StorySpeechID.Id14416505] =
{
	Id = 14416505,
	CharName = "琵琶映冬",
	Text = "TA难道决定，成年后要变成男性了吗？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_16_jingyu",
	NextID = 14416506,
}
StorySpeechConfig[StorySpeechID.Id14416506] =
{
	Id = 14416506,
	CharName = "服装设计师",
	Text = "嗯……这是公司上层的决定，我们也无从……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_29_kaitangshoujieke_cos10",
	NextID = 14416507,
}
StorySpeechConfig[StorySpeechID.Id14416507] =
{
	Id = 14416507,
	CharName = "琵琶映冬",
	Text = "所以！我决定跟随TA，和TA做出同样的选择！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_16_jingyu",
	NextID = 14416508,
}
StorySpeechConfig[StorySpeechID.Id14416508] =
{
	Id = 14416508,
	CharName = "服装设计师",
	Text = "？！可你才签约不久，你的经纪人不会允许你做出这样的决定……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_29_kaitangshoujieke_cos10",
	NextID = 14416509,
}
StorySpeechConfig[StorySpeechID.Id14416509] =
{
	Id = 14416509,
	CharName = "服装设计师",
	Text = "你应该是一个天真无邪，不谙世事的小公主，公司不会允许任何人破坏这一定位，包括你自己。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_29_kaitangshoujieke_cos10",
	NextID = 14416510,
}
StorySpeechConfig[StorySpeechID.Id14416510] =
{
	Id = 14416510,
	CharName = "琵琶映冬",
	Text = "那……那就不好意思了！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_16_jingyu",
}
StorySpeechConfig[StorySpeechID.Id14416601] =
{
	Id = 14416601,
	CharName = "健身教练",
	Text = "你已经跑了一小时了，今天就练到这里吧。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 14416602,
}
StorySpeechConfig[StorySpeechID.Id14416602] =
{
	Id = 14416602,
	CharName = "海豚凛",
	Text = "教练，我能不能增加一些其TA项目，比如哑铃之类的……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_17_haitun",
	NextID = 14416603,
}
StorySpeechConfig[StorySpeechID.Id14416603] =
{
	Id = 14416603,
	CharName = "健身教练",
	Text = "可以，但是你一直没有办卡报班，这让我很难办啊。\n这样吧，你花1000海洋币上个课……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 14416604,
}
StorySpeechConfig[StorySpeechID.Id14416604] =
{
	Id = 14416604,
	CharName = "海豚凛",
	Text = "不用的，我自己去用那些健身器械就好了。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_17_haitun",
	NextID = 14416605,
}
StorySpeechConfig[StorySpeechID.Id14416605] =
{
	Id = 14416605,
	CharName = "健身教练",
	Text = "不行！健身办卡了解一下吧，买不了吃亏，买不了上当，一张1000，两张999……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 14416606,
}
StorySpeechConfig[StorySpeechID.Id14416606] =
{
	Id = 14416606,
	CharName = "海豚凛",
	Text = "教练，你怎么一直拦着我呀？我要开始了哦……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_17_haitun",
	NextID = 14416607,
}
StorySpeechConfig[StorySpeechID.Id14416607] =
{
	Id = 14416607,
	CharName = "健身教练",
	Text = "等等……（惊）你，你怎么变色了！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_27_JianShenJiaoLian",
}
StorySpeechConfig[StorySpeechID.Id14416701] =
{
	Id = 14416701,
	CharName = "强盗",
	Text = "站住！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_28_heiyiren",
	NextID = 14416702,
}
StorySpeechConfig[StorySpeechID.Id14416702] =
{
	Id = 14416702,
	CharName = "扇贝珍",
	Text = "夜里也会被粉丝认出来吗？果然作为偶像，还是应该穿得低调一点……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_19_shanbei",
	NextID = 14416703,
}
StorySpeechConfig[StorySpeechID.Id14416703] =
{
	Id = 14416703,
	CharName = "扇贝珍",
	Text = "算了，既然被你认出来了，我就给你签个名吧。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_19_shanbei",
	NextID = 14416704,
}
StorySpeechConfig[StorySpeechID.Id14416704] =
{
	Id = 14416704,
	CharName = "强盗",
	Text = "好的，谢……不对！我是强盗！把值钱的东西都交出来！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_28_heiyiren",
	NextID = 14416705,
}
StorySpeechConfig[StorySpeechID.Id14416705] =
{
	Id = 14416705,
	CharName = "扇贝珍",
	Text = "？？？\n我……我没钱……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_19_shanbei",
	NextID = 14416706,
}
StorySpeechConfig[StorySpeechID.Id14416706] =
{
	Id = 14416706,
	CharName = "强盗",
	Text = "说谎！你身上这么多珍珠，会没有钱？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_28_heiyiren",
	NextID = 14416707,
}
StorySpeechConfig[StorySpeechID.Id14416707] =
{
	Id = 14416707,
	CharName = "扇贝珍",
	Text = "珍珠？对啊，我这就给你……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_19_shanbei",
	NextID = 14416708,
}
StorySpeechConfig[StorySpeechID.Id14416708] =
{
	Id = 14416708,
	CharName = "强盗",
	Text = "哼，这还差不多。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_28_heiyiren",
	NextID = 14416709,
}
StorySpeechConfig[StorySpeechID.Id14416709] =
{
	Id = 14416709,
	CharName = "扇贝珍",
	Text = "（打开扇贝，拿出珍珠）你看！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_19_shanbei",
	NextID = 14416710,
}
StorySpeechConfig[StorySpeechID.Id14416710] =
{
	Id = 14416710,
	CharName = "强盗",
	Text = "啊！眼睛，我的眼睛——！",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_28_heiyiren",
}
StorySpeechConfig[StorySpeechID.Id14416801] =
{
	Id = 14416801,
	CharName = "海螺美莎",
	Text = "（刷直播）为什么别人的直播间，人气就那么高呢？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_18_hailuo",
	NextID = 14416802,
}
StorySpeechConfig[StorySpeechID.Id14416802] =
{
	Id = 14416802,
	CharName = "手机",
	Text = "（大声）偶买噶，买它！买了礼盒送小样，除了小样还有……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	RightIcon = "SUS_MobilePhone",
	NextID = 14416803,
}
StorySpeechConfig[StorySpeechID.Id14416803] =
{
	Id = 14416803,
	CharName = "海螺美莎",
	Text = "平时斯斯文文的家伙，在直播间里卖货的时候竟然这么激情……对了！激情！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_18_hailuo",
	NextID = 14416804,
}
StorySpeechConfig[StorySpeechID.Id14416804] =
{
	Id = 14416804,
	CharName = "经纪人",
	Text = "你想到提升人气的办法了吗？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_men4",
	NextID = 14416805,
}
StorySpeechConfig[StorySpeechID.Id14416805] =
{
	Id = 14416805,
	CharName = "海螺美莎",
	Text = "大家喜欢的就是反差！所以，我应该改变一下风格，穿上男装，变成一个酷酷的样子。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_18_hailuo",
	NextID = 14416806,
}
StorySpeechConfig[StorySpeechID.Id14416806] =
{
	Id = 14416806,
	CharName = "经纪人",
	Text = "不行！你出道以来，我们设定的形象就是可爱少女！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_men4",
	NextID = 14416807,
}
StorySpeechConfig[StorySpeechID.Id14416807] =
{
	Id = 14416807,
	CharName = "海螺美莎",
	Text = "那对不起了，我有我自己的想法！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_18_hailuo",
}
StorySpeechConfig[StorySpeechID.Id14416901] =
{
	Id = 14416901,
	CharName = "导演",
	Text = "（看名单）下一个节目候场！那个什么……什么椰子……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "SEA_Octupas1",
	NextID = 14416902,
}
StorySpeechConfig[StorySpeechID.Id14416902] =
{
	Id = 14416902,
	CharName = "鲎椰子",
	Text = "导演，是在叫我吗？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_29_hou",
	NextID = 14416903,
}
StorySpeechConfig[StorySpeechID.Id14416903] =
{
	Id = 14416903,
	CharName = "导演",
	Text = "（看名单）你就是鳖椰子？去后台那儿站着吧。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "SEA_Octupas1",
	NextID = 14416904,
}
StorySpeechConfig[StorySpeechID.Id14416904] =
{
	Id = 14416904,
	CharName = "鲎椰子",
	Text = "导演……我，我不是鳖……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_29_hou",
	NextID = 14416905,
}
StorySpeechConfig[StorySpeechID.Id14416905] =
{
	Id = 14416905,
	CharName = "导演",
	Text = "（仔细看人和名单）哦！鳌椰子是吧？赶紧去准备吧。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "SEA_Octupas1",
	NextID = 14416906,
}
StorySpeechConfig[StorySpeechID.Id14416906] =
{
	Id = 14416906,
	CharName = "鲎椰子",
	Text = "我也不是鳌……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_29_hou",
	NextID = 14416907,
}
StorySpeechConfig[StorySpeechID.Id14416907] =
{
	Id = 14416907,
	CharName = "导演",
	Text = "（不悦）我看你长得和鳖差不多，不如改个名吧，名字里有生僻字不好，不容易被人记住……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "SEA_Octupas1",
	NextID = 14416908,
}
StorySpeechConfig[StorySpeechID.Id14416908] =
{
	Id = 14416908,
	CharName = "鲎椰子",
	Text = "不行！这是我家族的标志，绝对不能改掉这个字！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_29_hou",
}
StorySpeechConfig[StorySpeechID.Id14417001] =
{
	Id = 14417001,
	CharName = "蟹香菜",
	Text = "我听人家说，千穿万穿马屁不穿，千破万破牛皮不破。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_09_pangxie",
	NextID = 14417002,
}
StorySpeechConfig[StorySpeechID.Id14417002] =
{
	Id = 14417002,
	CharName = "蟹香菜",
	Text = "我想要找一张牛皮来做鼓，这样就不会出现演出时，鼓被我敲破的尴尬场面。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_09_pangxie",
	NextID = 14417003,
}
StorySpeechConfig[StorySpeechID.Id14417003] =
{
	Id = 14417003,
	CharName = "蟹香菜",
	Text = "看在我跋山涉水的份上，你就让给我吧。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_09_pangxie",
	NextID = 14417004,
}
StorySpeechConfig[StorySpeechID.Id14417004] =
{
	Id = 14417004,
	CharName = "小奶牛",
	Text = "不行！就是因为这个，我才被人称为“牛皮的牧师”，给了你，就没人邀请我下副本了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_07_mushi_cos10",
	NextID = 14417005,
}
StorySpeechConfig[StorySpeechID.Id14417005] =
{
	Id = 14417005,
	CharName = "蟹香菜",
	Text = "既然你不答应，看来没得商量了！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_09_pangxie",
	NextID = 14417006,
}
StorySpeechConfig[StorySpeechID.Id14417006] =
{
	Id = 14417006,
	CharName = "小奶牛",
	Text = "要抢吗？看你有没有这个本事！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_07_mushi_cos10",
}
StorySpeechConfig[StorySpeechID.Id14417101] =
{
	Id = 14417101,
	CharName = "外星面试官",
	Text = "所以你想要去我们星球的理由是……？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_01_SlimeKing_cos10",
	NextID = 14417102,
}
StorySpeechConfig[StorySpeechID.Id14417102] =
{
	Id = 14417102,
	CharName = "虾伊洛",
	Text = "我想提高我的弹琴水平，让我更胜一层楼！同时，我也很喜欢贵星……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_06_longxia",
	NextID = 14417103,
}
StorySpeechConfig[StorySpeechID.Id14417103] =
{
	Id = 14417103,
	CharName = "外星面试官",
	Text = "确实，我们星球的音乐水平非常高超，那你是否知道，我们的国王是谁？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_01_SlimeKing_cos10",
	NextID = 14417104,
}
StorySpeechConfig[StorySpeechID.Id14417104] =
{
	Id = 14417104,
	CharName = "虾伊洛",
	Text = "……昂？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_06_longxia",
	NextID = 14417105,
}
StorySpeechConfig[StorySpeechID.Id14417105] =
{
	Id = 14417105,
	CharName = "外星面试官",
	Text = "请问我们的王子，各自从事什么样的事业？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_01_SlimeKing_cos10",
	NextID = 14417106,
}
StorySpeechConfig[StorySpeechID.Id14417106] =
{
	Id = 14417106,
	CharName = "虾伊洛",
	Text = "……？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_06_longxia",
	NextID = 14417107,
}
StorySpeechConfig[StorySpeechID.Id14417107] =
{
	Id = 14417107,
	CharName = "外星面试官",
	Text = "看来你对我们星球的热爱不过如此，恕我不能同意你的申请！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_01_SlimeKing_cos10",
	NextID = 14417108,
}
StorySpeechConfig[StorySpeechID.Id14417108] =
{
	Id = 14417108,
	CharName = "虾伊洛",
	Text = "这算是什么理由啊？真是太过分了！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_06_longxia",
}
StorySpeechConfig[StorySpeechID.Id14417201] =
{
	Id = 14417201,
	CharName = "海兔幻然",
	Text = "镜子，你说，是不是你在搞鬼？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_05_haitu",
	NextID = 14417202,
}
StorySpeechConfig[StorySpeechID.Id14417202] =
{
	Id = 14417202,
	CharName = "镜子",
	Text = "（啥？）……",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	RightIcon = "Equipment_Sea_30_haibao_1",
	NextID = 14417203,
}
StorySpeechConfig[StorySpeechID.Id14417203] =
{
	Id = 14417203,
	CharName = "海兔幻然",
	Text = "每天早上醒来，我都发现自己的样子变了，一定是你嫉妒我的美貌，是不是？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_05_haitu",
	NextID = 14417204,
}
StorySpeechConfig[StorySpeechID.Id14417204] =
{
	Id = 14417204,
	CharName = "镜子",
	Text = "（分明是你自己体质特殊，样子才会随着前一天吃的食物而改变吧？）……",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	RightIcon = "Equipment_Sea_30_haibao_1",
	NextID = 14417205,
}
StorySpeechConfig[StorySpeechID.Id14417205] =
{
	Id = 14417205,
	CharName = "海兔幻然",
	Text = "你不说话是不是？别以为你不说话就没事！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_05_haitu",
	NextID = 14417206,
}
StorySpeechConfig[StorySpeechID.Id14417206] =
{
	Id = 14417206,
	CharName = "镜子",
	Text = "（我能有什么事？根据调查，经常和镜子说话的那个人才更容易得精神病！）……",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	RightIcon = "Equipment_Sea_30_haibao_1",
	NextID = 14417207,
}
StorySpeechConfig[StorySpeechID.Id14417207] =
{
	Id = 14417207,
	CharName = "海兔幻然",
	Text = "我就知道，你不说话是因为心虚！你默认了！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_05_haitu",
	NextID = 14417208,
}
StorySpeechConfig[StorySpeechID.Id14417208] =
{
	Id = 14417208,
	CharName = "镜子",
	Text = "（欺负我不会开口说话？）……",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	RightIcon = "Equipment_Sea_30_haibao_1",
	NextID = 14417209,
}
StorySpeechConfig[StorySpeechID.Id14417209] =
{
	Id = 14417209,
	CharName = "海兔幻然",
	Text = "既然你承认了，就别怪我辣手无情了！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_05_haitu",
	NextID = 14417210,
}
StorySpeechConfig[StorySpeechID.Id14417210] =
{
	Id = 14417210,
	CharName = "镜子",
	Text = "（喂喂喂，我身板脆，别真动手啊！）……",
	IconBundle = "atlas_equipment",
	IconAtlas = "Equipment",
	RightIcon = "Equipment_Sea_30_haibao_1",
}
StorySpeechConfig[StorySpeechID.Id14417301] =
{
	Id = 14417301,
	CharName = "观众A",
	Text = "空中抛三个球接不到吗？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_men4",
	NextID = 14417302,
}
StorySpeechConfig[StorySpeechID.Id14417302] =
{
	Id = 14417302,
	CharName = "观众B",
	Text = "不能变出一只蚯蚓来给我尝尝吗？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_naked1",
	NextID = 14417303,
}
StorySpeechConfig[StorySpeechID.Id14417303] =
{
	Id = 14417303,
	CharName = "小丑遥",
	Text = "你们够了！不能因为我名字里有「小丑」两个字，就以为我们是马戏团！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_07_xiaochouyu",
	NextID = 14417304,
}
StorySpeechConfig[StorySpeechID.Id14417304] =
{
	Id = 14417304,
	CharName = "观众A",
	Text = "可是，乐队中哪有人穿小学生的服装的呀？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_men4",
	NextID = 14417305,
}
StorySpeechConfig[StorySpeechID.Id14417305] =
{
	Id = 14417305,
	CharName = "小丑遥",
	Text = "这不是学生装，是水手服！我们是热情似火的深潜FoRever乐队！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_07_xiaochouyu",
	NextID = 14417306,
}
StorySpeechConfig[StorySpeechID.Id14417306] =
{
	Id = 14417306,
	CharName = "观众B",
	Text = "热情似火？那能钻个火圈吗？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_naked1",
	NextID = 14417307,
}
StorySpeechConfig[StorySpeechID.Id14417307] =
{
	Id = 14417307,
	CharName = "小丑遥",
	Text = "你们这些人根本就是来捣乱的吧？那我只能请你们出去了！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_07_xiaochouyu",
}
StorySpeechConfig[StorySpeechID.Id14417401] =
{
	Id = 14417401,
	CharName = "骨头兵",
	Text = "就是你！给我站住！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_30_kulou",
	NextID = 14417402,
}
StorySpeechConfig[StorySpeechID.Id14417402] =
{
	Id = 14417402,
	CharName = "海胆小茨",
	Text = "？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_21_haidan",
	NextID = 14417403,
}
StorySpeechConfig[StorySpeechID.Id14417403] =
{
	Id = 14417403,
	CharName = "骨头兵",
	Text = "上次我不小心经过你的演唱会，结果头骨不知怎的就当场掉落，害得我摸瞎找了好久。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_30_kulou",
	NextID = 14417404,
}
StorySpeechConfig[StorySpeechID.Id14417404] =
{
	Id = 14417404,
	CharName = "海胆小茨",
	Text = "？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_21_haidan",
	NextID = 14417405,
}
StorySpeechConfig[StorySpeechID.Id14417405] =
{
	Id = 14417405,
	CharName = "骨头兵",
	Text = "后来，我听人说，你的声音别具特色，唱到歌曲高潮时能将人的头盖骨掀翻。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_30_kulou",
	NextID = 14417406,
}
StorySpeechConfig[StorySpeechID.Id14417406] =
{
	Id = 14417406,
	CharName = "海胆小茨",
	Text = "真是不好意思……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_21_haidan",
	NextID = 14417407,
}
StorySpeechConfig[StorySpeechID.Id14417407] =
{
	Id = 14417407,
	CharName = "骨头兵",
	Text = "我不管，我那几天没少吃苦头，我也要让你尝尝这个滋味！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_30_kulou",
	NextID = 14417408,
}
StorySpeechConfig[StorySpeechID.Id14417408] =
{
	Id = 14417408,
	CharName = "海胆小茨",
	Text = "……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_21_haidan",
}
StorySpeechConfig[StorySpeechID.Id14417501] =
{
	Id = 14417501,
	CharName = "鱼不翻的同学",
	Text = "喂，你把那个东西给我。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_28_fancheyu",
	NextID = 14417502,
}
StorySpeechConfig[StorySpeechID.Id14417502] =
{
	Id = 14417502,
	CharName = "鱼不翻",
	Text = "哦——好的。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_28_fancheyu",
	NextID = 14417503,
}
StorySpeechConfig[StorySpeechID.Id14417503] =
{
	Id = 14417503,
	CharName = "鱼不翻",
	Text = "（找了五分钟）那个，你说的“那个”东西，是哪个啊……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_28_fancheyu",
	NextID = 14417504,
}
StorySpeechConfig[StorySpeechID.Id14417504] =
{
	Id = 14417504,
	CharName = "鱼不翻的同学",
	Text = "你怎么连“那个”都不知道啊！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_28_fancheyu",
	NextID = 14417505,
}
StorySpeechConfig[StorySpeechID.Id14417505] =
{
	Id = 14417505,
	CharName = "鱼不翻",
	Text = "啊——（挠头）不知道……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_28_fancheyu",
	NextID = 14417506,
}
StorySpeechConfig[StorySpeechID.Id14417506] =
{
	Id = 14417506,
	CharName = "鱼不翻的同学",
	Text = "你真是个蠢货！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_28_fancheyu",
	NextID = 14417507,
}
StorySpeechConfig[StorySpeechID.Id14417507] =
{
	Id = 14417507,
	CharName = "鱼不翻",
	Text = "（突然抬头）你这家伙真是一点礼貌也没有！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_28_fancheyu",
	NextID = 14417508,
}
StorySpeechConfig[StorySpeechID.Id14417508] =
{
	Id = 14417508,
	CharName = "鱼不翻的同学",
	Text = "哇！你……你怎么突然这么大声啊！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_28_fancheyu",
	NextID = 14417509,
}
StorySpeechConfig[StorySpeechID.Id14417509] =
{
	Id = 14417509,
	CharName = "鱼不翻",
	Text = "哼，你这样欺负人，我就要你付出代价！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_28_fancheyu",
}
StorySpeechConfig[StorySpeechID.Id14417601] =
{
	Id = 14417601,
	CharName = "蝠鲼凉风",
	Text = "我觉得我们三个特别合得来！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_15_manta",
	NextID = 14417602,
}
StorySpeechConfig[StorySpeechID.Id14417602] =
{
	Id = 14417602,
	CharName = "海星寻沙",
	Text = "没错，配合演话剧简直天衣无缝！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_08_haixing",
	NextID = 14417603,
}
StorySpeechConfig[StorySpeechID.Id14417603] =
{
	Id = 14417603,
	CharName = "海蛇莱斯莉",
	Text = "就连下一部话剧想演什么都很有默契！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_25_haishe",
	NextID = 14417604,
}
StorySpeechConfig[StorySpeechID.Id14417604] =
{
	Id = 14417604,
	CharName = "蝠鲼凉风",
	Text = "不如我们一起喊出来吧？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_15_manta",
	NextID = 14417605,
}
StorySpeechConfig[StorySpeechID.Id14417605] =
{
	Id = 14417605,
	CharName = "海星寻沙",
	Text = "好，我赞成！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_08_haixing",
	NextID = 14417606,
}
StorySpeechConfig[StorySpeechID.Id14417606] =
{
	Id = 14417606,
	CharName = "蝠鲼凉风",
	Text = "我想演《华丽的贵公子》！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_15_manta",
	NextID = 14417607,
}
StorySpeechConfig[StorySpeechID.Id14417607] =
{
	Id = 14417607,
	CharName = "海星寻沙",
	Text = "我想演《逆袭的二公子》！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_08_haixing",
	NextID = 14417608,
}
StorySpeechConfig[StorySpeechID.Id14417608] =
{
	Id = 14417608,
	CharName = "海蛇莱斯莉",
	Text = "我想演《完美的黑白执事》！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_25_haishe",
	NextID = 14417609,
}
StorySpeechConfig[StorySpeechID.Id14417609] =
{
	Id = 14417609,
	CharName = "蝠鲼凉风",
	Text = "……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_15_manta",
	NextID = 14417610,
}
StorySpeechConfig[StorySpeechID.Id14417610] =
{
	Id = 14417610,
	CharName = "海星寻沙",
	Text = "……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_08_haixing",
	NextID = 14417611,
}
StorySpeechConfig[StorySpeechID.Id14417611] =
{
	Id = 14417611,
	CharName = "海蛇莱斯莉",
	Text = "……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_25_haishe",
	NextID = 14417612,
}
StorySpeechConfig[StorySpeechID.Id14417612] =
{
	Id = 14417612,
	CharName = "蝠鲼凉风",
	Text = "既然大家意见有一点「小小的」分歧……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_15_manta",
	NextID = 14417613,
}
StorySpeechConfig[StorySpeechID.Id14417613] =
{
	Id = 14417613,
	CharName = "海星寻沙",
	Text = "那我提议还是统一下意见比较好！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_08_haixing",
	NextID = 14417614,
}
StorySpeechConfig[StorySpeechID.Id14417614] =
{
	Id = 14417614,
	CharName = "海蛇莱斯莉",
	Text = "那我提议还是用老办法来解决！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_25_haishe",
	NextID = 14417615,
}
StorySpeechConfig[StorySpeechID.Id14417615] =
{
	Id = 14417615,
	CharName = "蝠鲼凉风",
	Text = "真不错，起码这次我们想到一块儿了！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_15_manta",
}
StorySpeechConfig[StorySpeechID.Id14417701] =
{
	Id = 14417701,
	CharName = "海马希波",
	Text = "阿彩，我有个问题想请教你。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_11_haima",
	NextID = 14417702,
}
StorySpeechConfig[StorySpeechID.Id14417702] =
{
	Id = 14417702,
	CharName = "海豹彩",
	Text = "是什么问题啊？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_30_haibao",
	NextID = 14417703,
}
StorySpeechConfig[StorySpeechID.Id14417703] =
{
	Id = 14417703,
	CharName = "海马希波",
	Text = "每次演出，我都因为舞步太快，停下来的时候发型都会乱。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_11_haima",
	NextID = 14417704,
}
StorySpeechConfig[StorySpeechID.Id14417704] =
{
	Id = 14417704,
	CharName = "海马希波",
	Text = "很多观众因为我披头散发的样子，都喊我「海马鬼己」……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_11_haima",
	NextID = 14417705,
}
StorySpeechConfig[StorySpeechID.Id14417705] =
{
	Id = 14417705,
	CharName = "海豹彩",
	Text = "我倒是有个办法，听说Aquarius团体中的海葵彩雅有特制的发胶，能很好地固定住发型。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_30_haibao",
	NextID = 14417706,
}
StorySpeechConfig[StorySpeechID.Id14417706] =
{
	Id = 14417706,
	CharName = "海豹彩",
	Text = "不过，由于发胶比较珍贵，TA不太喜欢借给别人。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_30_haibao",
	NextID = 14417707,
}
StorySpeechConfig[StorySpeechID.Id14417707] =
{
	Id = 14417707,
	CharName = "海豹彩",
	Text = "只有在舞台上能和TA一较高下的对手才能获得TA的尊重。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_30_haibao",
	NextID = 14417708,
}
StorySpeechConfig[StorySpeechID.Id14417708] =
{
	Id = 14417708,
	CharName = "海马希波",
	Text = "这样吗？不论如何，我都要去试一试。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_11_haima",
}
StorySpeechConfig[StorySpeechID.Id14417801] =
{
	Id = 14417801,
	CharName = "刺豚茉白",
	Text = "人生就像一场戏，因为有缘才相聚。相扶到老不容易，是否更该去珍惜。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_27_hetun",
	NextID = 14417802,
}
StorySpeechConfig[StorySpeechID.Id14417802] =
{
	Id = 14417802,
	CharName = "刺豚茉白",
	Text = "为了小事发脾气，回头想想又何必。别人生气我不气，气出病来无人替。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_27_hetun",
	NextID = 14417803,
}
StorySpeechConfig[StorySpeechID.Id14417803] =
{
	Id = 14417803,
	CharName = "刺豚茉白",
	Text = "我若气死谁如意，况且伤神又费力。邻居亲朋不要比，儿孙琐事由TA去。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_27_hetun",
	NextID = 14417804,
}
StorySpeechConfig[StorySpeechID.Id14417804] =
{
	Id = 14417804,
	CharName = "刺豚茉白",
	Text = "吃苦享乐在一起，神仙羡慕好伴侣。嗨呀~神仙羡慕好~伴~侣！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_27_hetun",
	NextID = 14417805,
}
StorySpeechConfig[StorySpeechID.Id14417805] =
{
	Id = 14417805,
	CharName = "章鱼舞妍",
	Text = "怎么样，这首《莫生气》念下来是不是感觉气消了很多？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_10_zhangyu",
	NextID = 14417806,
}
StorySpeechConfig[StorySpeechID.Id14417806] =
{
	Id = 14417806,
	CharName = "刺豚茉白",
	Text = "呼——还真是这样，念完感觉心情舒畅了不少，想想之前的自己，真是有点可笑。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_27_hetun",
	NextID = 14417807,
}
StorySpeechConfig[StorySpeechID.Id14417807] =
{
	Id = 14417807,
	CharName = "刺豚茉白",
	Text = "不就是没拿到演唱会出场的资格吗？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_27_hetun",
	NextID = 14417808,
}
StorySpeechConfig[StorySpeechID.Id14417808] =
{
	Id = 14417808,
	CharName = "刺豚茉白",
	Text = "（开始膨胀）不就是……不就是受不到重视而已吗？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_27_hetun",
	NextID = 14417809,
}
StorySpeechConfig[StorySpeechID.Id14417809] =
{
	Id = 14417809,
	CharName = "章鱼舞妍",
	Text = "……你真的没事了吗？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_10_zhangyu",
	NextID = 14417810,
}
StorySpeechConfig[StorySpeechID.Id14417810] =
{
	Id = 14417810,
	CharName = "刺豚茉白",
	Text = "（持续膨胀）我怎么会有事呢？我绝对……不会因为这种小事……不开心的！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_27_hetun",
	NextID = 14417811,
}
StorySpeechConfig[StorySpeechID.Id14417811] =
{
	Id = 14417811,
	CharName = "刺豚茉白",
	Text = "（咬牙切齿）毕竟……忍一时……越想越气……退一步……越想越亏……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_27_hetun",
	NextID = 14417812,
}
StorySpeechConfig[StorySpeechID.Id14417812] =
{
	Id = 14417812,
	CharName = "刺豚茉白",
	Text = "今天，谁都别想拦着我！我一定要找制片人讨个说法！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_27_hetun",
}
StorySpeechConfig[StorySpeechID.Id14417901] =
{
	Id = 14417901,
	CharName = "造型师",
	Text = "呼——您的头发已经染了76次了，衣服换了107件了，您看这次颜色对吗？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_29_kaitangshoujieke_cos10",
	NextID = 14417902,
}
StorySpeechConfig[StorySpeechID.Id14417902] =
{
	Id = 14417902,
	CharName = "海葵彩雅",
	Text = "啊这…衣服是要咸菜绿，但不是这种咸菜，腌得太久了，不够亮丽。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_23_haikui",
	NextID = 14417903,
}
StorySpeechConfig[StorySpeechID.Id14417903] =
{
	Id = 14417903,
	CharName = "海葵彩雅",
	Text = "头发的黄色也不是这种七分熟的鸡蛋黄，还要再嫩一点点。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_23_haikui",
	NextID = 14417904,
}
StorySpeechConfig[StorySpeechID.Id14417904] =
{
	Id = 14417904,
	CharName = "造型师",
	Text = "够了！我已经为你忙活一整天了，你是来找茬的吧？",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_29_kaitangshoujieke_cos10",
	NextID = 14417905,
}
StorySpeechConfig[StorySpeechID.Id14417905] =
{
	Id = 14417905,
	CharName = "海葵彩雅",
	Text = "真不是这样，你听我狡辩……不是，你听我解释！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_23_haikui",
	NextID = 14417906,
}
StorySpeechConfig[StorySpeechID.Id14417906] =
{
	Id = 14417906,
	CharName = "造型师",
	Text = "我不改了！要么你接受现在的造型，要么你说服我。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	LeftIcon = "Sus_29_kaitangshoujieke_cos10",
	NextID = 14417907,
}
StorySpeechConfig[StorySpeechID.Id14417907] =
{
	Id = 14417907,
	CharName = "海葵彩雅",
	Text = "好吧……那我只有动手试试了。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_23_haikui",
}
StorySpeechConfig[StorySpeechID.Id14418001] =
{
	Id = 14418001,
	CharName = "歌迷A",
	Text = "怎么回事，怎么突然信号这么差？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_women2",
	NextID = 14418002,
}
StorySpeechConfig[StorySpeechID.Id14418002] =
{
	Id = 14418002,
	CharName = "斗鱼希",
	Text = "（默默离开）……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_02_douyu",
	NextID = 14418003,
}
StorySpeechConfig[StorySpeechID.Id14418003] =
{
	Id = 14418003,
	CharName = "歌迷B",
	Text = "奇怪了，我这消息怎么突然就发不出去了？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_women1",
	NextID = 14418004,
}
StorySpeechConfig[StorySpeechID.Id14418004] =
{
	Id = 14418004,
	CharName = "斗鱼希",
	Text = "（转身走人）……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_02_douyu",
	NextID = 14418005,
}
StorySpeechConfig[StorySpeechID.Id14418005] =
{
	Id = 14418005,
	CharName = "歌迷C",
	Text = "哎哟，我还想和朋友分享下演唱会的气氛，怎么电话突然就盲音了？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_oldwomen1",
	NextID = 14418006,
}
StorySpeechConfig[StorySpeechID.Id14418006] =
{
	Id = 14418006,
	CharName = "斗鱼希",
	Text = "（悄悄低头）……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_02_douyu",
	NextID = 14418007,
}
StorySpeechConfig[StorySpeechID.Id14418007] =
{
	Id = 14418007,
	CharName = "绿礁保安",
	Text = "等等！我注意你很久了，你这家伙走到哪里，哪里的信号就很差！你身上是不是有什么信号干扰器？还是说你是竞争对手派来的？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "SEA_Ston1",
	NextID = 14418008,
}
StorySpeechConfig[StorySpeechID.Id14418008] =
{
	Id = 14418008,
	CharName = "斗鱼希",
	Text = "不是……你听我说……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_02_douyu",
	NextID = 14418009,
}
StorySpeechConfig[StorySpeechID.Id14418009] =
{
	Id = 14418009,
	CharName = "绿礁保安",
	Text = "先跟我去保安室走一趟吧，配合点！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "SEA_Ston1",
	NextID = 14418010,
}
StorySpeechConfig[StorySpeechID.Id14418010] =
{
	Id = 14418010,
	CharName = "斗鱼希",
	Text = "（后退）这真不是我的本意。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_02_douyu",
	NextID = 14418011,
}
StorySpeechConfig[StorySpeechID.Id14418011] =
{
	Id = 14418011,
	CharName = "绿礁保安",
	Text = "（拿起对讲机）喂喂喂，赶紧过来两个人，这里……不是吧？没信号了！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "SEA_Ston1",
	NextID = 14418012,
}
StorySpeechConfig[StorySpeechID.Id14418012] =
{
	Id = 14418012,
	CharName = "绿礁保安",
	Text = "站住，你别走！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "SEA_Ston1",
}
StorySpeechConfig[StorySpeechID.Id14418101] =
{
	Id = 14418101,
	CharName = "海葵彩雅",
	Text = "墨，最近乐团准备招一批新人进来。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_23_haikui",
	NextID = 14418102,
}
StorySpeechConfig[StorySpeechID.Id14418102] =
{
	Id = 14418102,
	CharName = "乌贼墨",
	Text = "哦？是作为乐团的预备团员吗？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_03_moyu",
	NextID = 14418103,
}
StorySpeechConfig[StorySpeechID.Id14418103] =
{
	Id = 14418103,
	CharName = "海葵彩雅",
	Text = "没错！不过新人进来后会有培训，不仅是音乐歌舞的学习，还要讲解鱼乐圈的常识。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_23_haikui",
	NextID = 14418104,
}
StorySpeechConfig[StorySpeechID.Id14418104] =
{
	Id = 14418104,
	CharName = "乌贼墨",
	Text = "听起来培训的工作不轻松啊……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_03_moyu",
	NextID = 14418105,
}
StorySpeechConfig[StorySpeechID.Id14418105] =
{
	Id = 14418105,
	CharName = "海葵彩雅",
	Text = "嗯，所以我推荐了你。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_23_haikui",
	NextID = 14418106,
}
StorySpeechConfig[StorySpeechID.Id14418106] =
{
	Id = 14418106,
	CharName = "乌贼墨",
	Text = "什么？你竟然……把这种吃力不讨好的活儿推给我！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_03_moyu",
	NextID = 14418107,
}
StorySpeechConfig[StorySpeechID.Id14418107] =
{
	Id = 14418107,
	CharName = "海葵彩雅",
	Text = "你看，鱼乐圈里面的那点八卦你基本上都知道，传授圈子里的常识没啥阻碍，对吧？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_23_haikui",
	NextID = 14418108,
}
StorySpeechConfig[StorySpeechID.Id14418108] =
{
	Id = 14418108,
	CharName = "乌贼墨",
	Text = "是这么说没错……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_03_moyu",
	NextID = 14418109,
}
StorySpeechConfig[StorySpeechID.Id14418109] =
{
	Id = 14418109,
	CharName = "海葵彩雅",
	Text = "只是这点的话，当培训老师还是有点勉强，但你还有个最大的优势。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_23_haikui",
	NextID = 14418110,
}
StorySpeechConfig[StorySpeechID.Id14418110] =
{
	Id = 14418110,
	CharName = "乌贼墨",
	Text = "额……是什么？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_03_moyu",
	NextID = 14418111,
}
StorySpeechConfig[StorySpeechID.Id14418111] =
{
	Id = 14418111,
	CharName = "海葵彩雅",
	Text = "当然是因为，你是我们乐团中喝墨水最多的人啦，哈哈哈……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_23_haikui",
	NextID = 14418112,
}
StorySpeechConfig[StorySpeechID.Id14418112] =
{
	Id = 14418112,
	CharName = "乌贼墨",
	Text = "可恶，你竟然敢笑话我！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_03_moyu",
}
StorySpeechConfig[StorySpeechID.Id14418201] =
{
	Id = 14418201,
	CharName = "乌贼墨",
	Text = "这次由海参橘提出的「一参有你相伴随」主题演唱会今天完美落幕！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_03_moyu",
	NextID = 14418202,
}
StorySpeechConfig[StorySpeechID.Id14418202] =
{
	Id = 14418202,
	CharName = "乌贼墨",
	Text = "下一场演唱会的主题现在开始征集！一旦被采纳，不仅可以成为演唱会的主要角色，还能获得定制的主题服装！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_03_moyu",
	NextID = 14418203,
}
StorySpeechConfig[StorySpeechID.Id14418203] =
{
	Id = 14418203,
	CharName = "乌贼墨",
	Text = "欢迎大家踊跃发言！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_03_moyu",
	NextID = 14418204,
}
StorySpeechConfig[StorySpeechID.Id14418204] =
{
	Id = 14418204,
	CharName = "海胆小茨",
	Text = "我提议主题是「大胆歌唱」！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_21_haidan",
	NextID = 14418205,
}
StorySpeechConfig[StorySpeechID.Id14418205] =
{
	Id = 14418205,
	CharName = "海葵彩雅",
	Text = "我提议主题是「越唱越精彩」！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_23_haikui",
	NextID = 14418206,
}
StorySpeechConfig[StorySpeechID.Id14418206] =
{
	Id = 14418206,
	CharName = "鮟鱇明",
	Text = "我提议主题是「为未来而唱」！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_26_ankang",
	NextID = 14418207,
}
StorySpeechConfig[StorySpeechID.Id14418207] =
{
	Id = 14418207,
	CharName = "海参橘",
	Text = "我提议主题是「三参有幸一起唱」！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_22_haisen",
	NextID = 14418208,
}
StorySpeechConfig[StorySpeechID.Id14418208] =
{
	Id = 14418208,
	CharName = "乌贼墨",
	Text = "嗯……都不错呢，不过我比较偏向橘的。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_03_moyu",
	NextID = 14418209,
}
StorySpeechConfig[StorySpeechID.Id14418209] =
{
	Id = 14418209,
	CharName = "海胆小茨",
	Text = "怎么可以这样？TA已经连续好几次了被选中了。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_21_haidan",
	NextID = 14418210,
}
StorySpeechConfig[StorySpeechID.Id14418210] =
{
	Id = 14418210,
	CharName = "海葵彩雅",
	Text = "我不服气，明明我的也很棒。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_23_haikui",
	NextID = 14418211,
}
StorySpeechConfig[StorySpeechID.Id14418211] =
{
	Id = 14418211,
	CharName = "鮟鱇明",
	Text = "就是就是！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_26_ankang",
	NextID = 14418212,
}
StorySpeechConfig[StorySpeechID.Id14418212] =
{
	Id = 14418212,
	CharName = "乌贼墨",
	Text = "又是无法接受的局面吗？好吧……还是按照老规矩，舞台上大家比较下高低吧。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_03_moyu",
}
StorySpeechConfig[StorySpeechID.Id14418301] =
{
	Id = 14418301,
	CharName = "鮟鱇明",
	Text = "医生，我的这只眼睛感觉看不清东西，可另一只眼睛又看得很清晰，这是什么原因呢？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_26_ankang",
	NextID = 14418302,
}
StorySpeechConfig[StorySpeechID.Id14418302] =
{
	Id = 14418302,
	CharName = "医生",
	Text = "你这是因为长期在强光之下，光快把眼睛亮瞎了，才看不清东西的。",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_04_fayi",
	NextID = 14418303,
}
StorySpeechConfig[StorySpeechID.Id14418303] =
{
	Id = 14418303,
	CharName = "鮟鱇明",
	Text = "（愣住）诶？那现在我该怎么办呢？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_26_ankang",
	NextID = 14418304,
}
StorySpeechConfig[StorySpeechID.Id14418304] =
{
	Id = 14418304,
	CharName = "医生",
	Text = "我建议你拔掉这盏灯，然后……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_04_fayi",
	NextID = 14418305,
}
StorySpeechConfig[StorySpeechID.Id14418305] =
{
	Id = 14418305,
	CharName = "鮟鱇明",
	Text = "不行！这盏灯就是我的性命，我决不让任何人夺走它！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_26_ankang",
	NextID = 14418306,
}
StorySpeechConfig[StorySpeechID.Id14418306] =
{
	Id = 14418306,
	CharName = "医生",
	Text = "我知道了，你，你不要激动啊……",
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "Sus",
	RightIcon = "Sus_04_fayi",
}
StorySpeechConfig[StorySpeechID.Id14418401] =
{
	Id = 14418401,
	CharName = "大魔王",
	Text = "彩大人！我还差三个家具就圆满了，今天请务必帮忙抽到！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_11_damowang",
	NextID = 14418402,
}
StorySpeechConfig[StorySpeechID.Id14418402] =
{
	Id = 14418402,
	CharName = "薯条国王",
	Text = "彩大人！请务必帮我抽几个高能电池，我马上就能升阶了！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	RightIcon = "Fat_30_shutiao",
	NextID = 14418403,
}
StorySpeechConfig[StorySpeechID.Id14418403] =
{
	Id = 14418403,
	CharName = "名人蜡像",
	Text = "彩大人！我去年就和你预约过了，你可别忘了呀！",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_30_Napoleon",
	NextID = 14418404,
}
StorySpeechConfig[StorySpeechID.Id14418404] =
{
	Id = 14418404,
	CharName = "海豹彩",
	Text = "额……要不，你们先排个队吧？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_30_haibao",
	NextID = 14418405,
}
StorySpeechConfig[StorySpeechID.Id14418405] =
{
	Id = 14418405,
	CharName = "史莱姆大王",
	Text = "都让一让！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_01_SlimeKing",
	NextID = 14418406,
}
StorySpeechConfig[StorySpeechID.Id14418406] =
{
	Id = 14418406,
	CharName = "精灵王子",
	Text = "女王大人，就是TA！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPDraw_02_ElvenPrince",
	NextID = 14418407,
}
StorySpeechConfig[StorySpeechID.Id14418407] =
{
	Id = 14418407,
	CharName = "玉璧女王",
	Text = "听说就是你在提供价格低廉的代抽服务？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_03_DiamondQueen",
	NextID = 14418408,
}
StorySpeechConfig[StorySpeechID.Id14418408] =
{
	Id = 14418408,
	CharName = "海豹彩",
	Text = "（理不直气也壮）……是的！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_30_haibao",
	NextID = 14418409,
}
StorySpeechConfig[StorySpeechID.Id14418409] =
{
	Id = 14418409,
	CharName = "史莱姆大王",
	Text = "你这家伙，每次你抽奖池都能完美避开素材！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_01_SlimeKing",
	NextID = 14418410,
}
StorySpeechConfig[StorySpeechID.Id14418410] =
{
	Id = 14418410,
	CharName = "精灵王子",
	Text = "就是！我好几个珍贵的人员情报，都被你一下抽到了。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPDraw_02_ElvenPrince",
	NextID = 14418411,
}
StorySpeechConfig[StorySpeechID.Id14418411] =
{
	Id = 14418411,
	CharName = "玉璧女王",
	Text = "不管什么理由，这里都不再欢迎你了，请你离开吧！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_03_DiamondQueen",
	NextID = 14418412,
}
StorySpeechConfig[StorySpeechID.Id14418412] =
{
	Id = 14418412,
	CharName = "海豹彩",
	Text = "不行，我已经接了别人的单……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_30_haibao",
	NextID = 14418413,
}
StorySpeechConfig[StorySpeechID.Id14418413] =
{
	Id = 14418413,
	CharName = "史莱姆大王",
	Text = "可恶，看来不给你点教训，你是不知道我们有多黑！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_01_SlimeKing",
}
StorySpeechConfig[StorySpeechID.Id14418501] =
{
	Id = 14418501,
	CharName = "电鳗伊俄",
	Text = "寻沙，我设计了一个造型方案，不知道效果怎样，想让你帮忙看看。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_24_haiman",
	NextID = 14418502,
}
StorySpeechConfig[StorySpeechID.Id14418502] =
{
	Id = 14418502,
	CharName = "海星寻沙",
	Text = "没问题~",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_08_haixing",
	NextID = 14418503,
}
StorySpeechConfig[StorySpeechID.Id14418503] =
{
	Id = 14418503,
	CharName = "电鳗伊俄",
	Text = "在演唱时，如果唱得太嗨，我经常会情不自禁地在舞台上放电。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_24_haiman",
	NextID = 14418504,
}
StorySpeechConfig[StorySpeechID.Id14418504] =
{
	Id = 14418504,
	CharName = "电鳗伊俄",
	Text = "很多观众说有被电到，那是一种心灵相通的感觉。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_24_haiman",
	NextID = 14418505,
}
StorySpeechConfig[StorySpeechID.Id14418505] =
{
	Id = 14418505,
	CharName = "电鳗伊俄",
	Text = "现在我想走一走成熟的路线，所以，选了这套衣服。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_24_haiman",
	NextID = 14418506,
}
StorySpeechConfig[StorySpeechID.Id14418506] =
{
	Id = 14418506,
	CharName = "电鳗伊俄",
	Text = "你看这黄色的皮料，斑点状的点缀，只要穿在身上，我就是……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_24_haiman",
	NextID = 14418507,
}
StorySpeechConfig[StorySpeechID.Id14418507] =
{
	Id = 14418507,
	CharName = "海星寻沙",
	Text = "我知道了！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_08_haixing",
	NextID = 14418508,
}
StorySpeechConfig[StorySpeechID.Id14418508] =
{
	Id = 14418508,
	CharName = "电鳗伊俄",
	Text = "你猜出来了？我就知道，这套衣服的设计风格还是很明显的！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_24_haiman",
	NextID = 14418509,
}
StorySpeechConfig[StorySpeechID.Id14418509] =
{
	Id = 14418509,
	CharName = "海星寻沙",
	Text = "是长颈鹿！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_08_haixing",
	NextID = 14418510,
}
StorySpeechConfig[StorySpeechID.Id14418510] =
{
	Id = 14418510,
	CharName = "电鳗伊俄",
	Text = "……我再给你一次机会。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_24_haiman",
	NextID = 14418511,
}
StorySpeechConfig[StorySpeechID.Id14418511] =
{
	Id = 14418511,
	CharName = "海星寻沙",
	Text = "不可能有别的了！\n这长长的一身设计，披在你身上就是活脱脱的长颈鹿！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_08_haixing",
	NextID = 14418512,
}
StorySpeechConfig[StorySpeechID.Id14418512] =
{
	Id = 14418512,
	CharName = "电鳗伊俄",
	Text = "（握拳）……才不是长颈鹿。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_24_haiman",
}
StorySpeechConfig[StorySpeechID.Id14418601] =
{
	Id = 14418601,
	CharName = "黄金纱纱",
	Text = "您好，我，我想要改变我的体质！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_01_huangshuimu",
	NextID = 14418602,
}
StorySpeechConfig[StorySpeechID.Id14418602] =
{
	Id = 14418602,
	CharName = "海底魔术师",
	Text = "改变体质？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_105_Scholar",
	NextID = 14418603,
}
StorySpeechConfig[StorySpeechID.Id14418603] =
{
	Id = 14418603,
	CharName = "黄金纱纱",
	Text = "因为别人一摸到我，我就会有生命危险，我的朋友，会不顾一切保护我……\n我不想再躲在TA身后了，我也想用自己的力量去保护TA！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_01_huangshuimu",
	NextID = 14418604,
}
StorySpeechConfig[StorySpeechID.Id14418604] =
{
	Id = 14418604,
	CharName = "海底魔术师",
	Text = "（看魔法书）嗯，确实有个办法~不过，以你美丽的形象为代价，也没问题吗？你不是一个偶像吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_105_Scholar",
	NextID = 14418605,
}
StorySpeechConfig[StorySpeechID.Id14418605] =
{
	Id = 14418605,
	CharName = "黄金纱纱",
	Text = "没……没问题的！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_01_huangshuimu",
	NextID = 14418606,
}
StorySpeechConfig[StorySpeechID.Id14418606] =
{
	Id = 14418606,
	CharName = "海底魔术师",
	Text = "（递水瓶）喝下这瓶药就可以了，现在，把你美丽的帽子和衣裳交给我吧。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_105_Scholar",
	NextID = 14418607,
}
StorySpeechConfig[StorySpeechID.Id14418607] =
{
	Id = 14418607,
	CharName = "黄金纱纱",
	Text = "咕噜咕噜……啊，好疼！！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_01_huangshuimu",
	NextID = 14418608,
}
StorySpeechConfig[StorySpeechID.Id14418608] =
{
	Id = 14418608,
	CharName = "海底魔术师",
	Text = "不好，这家伙暴走了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_105_Scholar",
}
StorySpeechConfig[StorySpeechID.Id14418701] =
{
	Id = 14418701,
	CharName = "道馆馆主",
	Text = "你不是那只灯塔水母吗？几百年过去，已经有人形了啊……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "SEA_Crab",
	NextID = 14418702,
}
StorySpeechConfig[StorySpeechID.Id14418702] =
{
	Id = 14418702,
	CharName = "灯塔丝丝",
	Text = "馆主，我想学武术。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_04_dengtashuimu",
	NextID = 14418703,
}
StorySpeechConfig[StorySpeechID.Id14418703] =
{
	Id = 14418703,
	CharName = "道馆馆主",
	Text = "这是为什么？你的触手不够你自保吗？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "SEA_Crab",
	NextID = 14418704,
}
StorySpeechConfig[StorySpeechID.Id14418704] =
{
	Id = 14418704,
	CharName = "灯塔丝丝",
	Text = "还不够……我有了想要守护的人，为了TA，我一定要学会武术。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_04_dengtashuimu",
	NextID = 14418705,
}
StorySpeechConfig[StorySpeechID.Id14418705] =
{
	Id = 14418705,
	CharName = "道馆馆主",
	Text = "可是，你这小身板……能扛过道馆里日复一日的艰苦训练吗？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "SEA_Crab",
	NextID = 14418706,
}
StorySpeechConfig[StorySpeechID.Id14418706] =
{
	Id = 14418706,
	CharName = "灯塔丝丝",
	Text = "没问题的，我会向您证明我的决心。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_04_dengtashuimu",
}
StorySpeechConfig[StorySpeechID.Id14418801] =
{
	Id = 14418801,
	CharName = "蝠鲼凉风",
	Text = "我觉得我们三个特别合得来！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_15_manta",
	NextID = 14418802,
}
StorySpeechConfig[StorySpeechID.Id14418802] =
{
	Id = 14418802,
	CharName = "海星寻沙",
	Text = "没错，配合演话剧简直天衣无缝！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_08_haixing",
	NextID = 14418803,
}
StorySpeechConfig[StorySpeechID.Id14418803] =
{
	Id = 14418803,
	CharName = "海蛇莱斯莉",
	Text = "就连下一部话剧想演什么都很有默契！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_25_haishe",
	NextID = 14418804,
}
StorySpeechConfig[StorySpeechID.Id14418804] =
{
	Id = 14418804,
	CharName = "蝠鲼凉风",
	Text = "不如我们一起喊出来吧？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_15_manta",
	NextID = 14418805,
}
StorySpeechConfig[StorySpeechID.Id14418805] =
{
	Id = 14418805,
	CharName = "海星寻沙",
	Text = "好，我赞成！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_08_haixing",
	NextID = 14418806,
}
StorySpeechConfig[StorySpeechID.Id14418806] =
{
	Id = 14418806,
	CharName = "蝠鲼凉风",
	Text = "我想演《华丽的贵公子》！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_15_manta",
	NextID = 14418807,
}
StorySpeechConfig[StorySpeechID.Id14418807] =
{
	Id = 14418807,
	CharName = "海星寻沙",
	Text = "我想演《逆袭的二公子》！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_08_haixing",
	NextID = 14418808,
}
StorySpeechConfig[StorySpeechID.Id14418808] =
{
	Id = 14418808,
	CharName = "海蛇莱斯莉",
	Text = "我想演《完美的黑白执事》！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_25_haishe",
	NextID = 14418809,
}
StorySpeechConfig[StorySpeechID.Id14418809] =
{
	Id = 14418809,
	CharName = "蝠鲼凉风",
	Text = "……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_15_manta",
	NextID = 14418810,
}
StorySpeechConfig[StorySpeechID.Id14418810] =
{
	Id = 14418810,
	CharName = "海星寻沙",
	Text = "……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_08_haixing",
	NextID = 14418811,
}
StorySpeechConfig[StorySpeechID.Id14418811] =
{
	Id = 14418811,
	CharName = "海蛇莱斯莉",
	Text = "……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_25_haishe",
	NextID = 14418812,
}
StorySpeechConfig[StorySpeechID.Id14418812] =
{
	Id = 14418812,
	CharName = "蝠鲼凉风",
	Text = "既然大家意见有一点「小小的」分歧……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_15_manta",
	NextID = 14418813,
}
StorySpeechConfig[StorySpeechID.Id14418813] =
{
	Id = 14418813,
	CharName = "海星寻沙",
	Text = "那我提议还是统一下意见比较好！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_08_haixing",
	NextID = 14418814,
}
StorySpeechConfig[StorySpeechID.Id14418814] =
{
	Id = 14418814,
	CharName = "海蛇莱斯莉",
	Text = "那我提议还是用老办法来解决！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_25_haishe",
	NextID = 14418815,
}
StorySpeechConfig[StorySpeechID.Id14418815] =
{
	Id = 14418815,
	CharName = "蝠鲼凉风",
	Text = "真不错，起码这次我们想到一块儿了！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_15_manta",
}
StorySpeechConfig[StorySpeechID.Id14418901] =
{
	Id = 14418901,
	CharName = "歌迷",
	Text = "哇哦！这个舞蹈真是优美！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_women2",
	NextID = 14418902,
}
StorySpeechConfig[StorySpeechID.Id14418902] =
{
	Id = 14418902,
	CharName = "章鱼舞妍",
	Text = "（微笑）……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_10_zhangyu",
	NextID = 14418903,
}
StorySpeechConfig[StorySpeechID.Id14418903] =
{
	Id = 14418903,
	CharName = "歌迷",
	Text = "整个演唱会的伴舞行云流水，没有一丝的拖沓和不协调。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_women2",
	NextID = 14418904,
}
StorySpeechConfig[StorySpeechID.Id14418904] =
{
	Id = 14418904,
	CharName = "章鱼舞妍",
	Text = "（捂嘴笑）……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_10_zhangyu",
	NextID = 14418905,
}
StorySpeechConfig[StorySpeechID.Id14418905] =
{
	Id = 14418905,
	CharName = "歌迷",
	Text = "能感觉到每个动作都经过仔细的校正，呈现出了平衡的美感。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_women2",
	NextID = 14418906,
}
StorySpeechConfig[StorySpeechID.Id14418906] =
{
	Id = 14418906,
	CharName = "章鱼舞妍",
	Text = "（咧嘴笑）……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_10_zhangyu",
	NextID = 14418907,
}
StorySpeechConfig[StorySpeechID.Id14418907] =
{
	Id = 14418907,
	CharName = "歌迷",
	Text = "虽然舞台最闪耀的灯光没有一直打在你身上，但不得不说，你的工作真的很重要！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_women2",
	NextID = 14418908,
}
StorySpeechConfig[StorySpeechID.Id14418908] =
{
	Id = 14418908,
	CharName = "章鱼舞妍",
	Text = "（开心大笑）……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_10_zhangyu",
	NextID = 14418909,
}
StorySpeechConfig[StorySpeechID.Id14418909] =
{
	Id = 14418909,
	CharName = "歌迷",
	Text = "真不愧是你啊，茉白！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_women2",
	NextID = 14418910,
}
StorySpeechConfig[StorySpeechID.Id14418910] =
{
	Id = 14418910,
	CharName = "章鱼舞妍",
	Text = "（皱眉）你说什么？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_10_zhangyu",
}
StorySpeechConfig[StorySpeechID.Id14419001] =
{
	Id = 14419001,
	CharName = "蝠鲼凉风",
	Text = "我觉得我们三个特别合得来！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_15_manta",
	NextID = 14419002,
}
StorySpeechConfig[StorySpeechID.Id14419002] =
{
	Id = 14419002,
	CharName = "海星寻沙",
	Text = "没错，配合演话剧简直天衣无缝！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_08_haixing",
	NextID = 14419003,
}
StorySpeechConfig[StorySpeechID.Id14419003] =
{
	Id = 14419003,
	CharName = "海蛇莱斯莉",
	Text = "就连下一部话剧想演什么都很有默契！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_25_haishe",
	NextID = 14419004,
}
StorySpeechConfig[StorySpeechID.Id14419004] =
{
	Id = 14419004,
	CharName = "蝠鲼凉风",
	Text = "不如我们一起喊出来吧？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_15_manta",
	NextID = 14419005,
}
StorySpeechConfig[StorySpeechID.Id14419005] =
{
	Id = 14419005,
	CharName = "海星寻沙",
	Text = "好，我赞成！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_08_haixing",
	NextID = 14419006,
}
StorySpeechConfig[StorySpeechID.Id14419006] =
{
	Id = 14419006,
	CharName = "蝠鲼凉风",
	Text = "我想演《华丽的贵公子》！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_15_manta",
	NextID = 14419007,
}
StorySpeechConfig[StorySpeechID.Id14419007] =
{
	Id = 14419007,
	CharName = "海星寻沙",
	Text = "我想演《逆袭的二公子》！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_08_haixing",
	NextID = 14419008,
}
StorySpeechConfig[StorySpeechID.Id14419008] =
{
	Id = 14419008,
	CharName = "海蛇莱斯莉",
	Text = "我想演《完美的黑白执事》！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_25_haishe",
	NextID = 14419009,
}
StorySpeechConfig[StorySpeechID.Id14419009] =
{
	Id = 14419009,
	CharName = "蝠鲼凉风",
	Text = "……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_15_manta",
	NextID = 14419010,
}
StorySpeechConfig[StorySpeechID.Id14419010] =
{
	Id = 14419010,
	CharName = "海星寻沙",
	Text = "……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_08_haixing",
	NextID = 14419011,
}
StorySpeechConfig[StorySpeechID.Id14419011] =
{
	Id = 14419011,
	CharName = "海蛇莱斯莉",
	Text = "……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_25_haishe",
	NextID = 14419012,
}
StorySpeechConfig[StorySpeechID.Id14419012] =
{
	Id = 14419012,
	CharName = "蝠鲼凉风",
	Text = "既然大家意见有一点「小小的」分歧……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_15_manta",
	NextID = 14419013,
}
StorySpeechConfig[StorySpeechID.Id14419013] =
{
	Id = 14419013,
	CharName = "海星寻沙",
	Text = "那我提议还是统一下意见比较好！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_08_haixing",
	NextID = 14419014,
}
StorySpeechConfig[StorySpeechID.Id14419014] =
{
	Id = 14419014,
	CharName = "海蛇莱斯莉",
	Text = "那我提议还是用老办法来解决！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_25_haishe",
	NextID = 14419015,
}
StorySpeechConfig[StorySpeechID.Id14419015] =
{
	Id = 14419015,
	CharName = "蝠鲼凉风",
	Text = "真不错，起码这次我们想到一块儿了！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_15_manta",
}
StorySpeechConfig[StorySpeechID.Id14419101] =
{
	Id = 14419101,
	CharName = "珊瑚阿卡",
	Text = "所以，我只用挑一首比较符合晚会气氛的歌，就可以了，对吧？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_20_shanhu",
	NextID = 14419102,
}
StorySpeechConfig[StorySpeechID.Id14419102] =
{
	Id = 14419102,
	CharName = "节目导演",
	Text = "没错~记得发原版歌曲也发我们一下哦~",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "SEA_Octupas1",
	NextID = 14419103,
}
StorySpeechConfig[StorySpeechID.Id14419103] =
{
	Id = 14419103,
	CharName = "珊瑚阿卡",
	Text = "这是为什么？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_20_shanhu",
	NextID = 14419104,
}
StorySpeechConfig[StorySpeechID.Id14419104] =
{
	Id = 14419104,
	CharName = "节目导演",
	Text = "当然是要在晚会现场放出来了~您到时候就在舞台中央对口型，没问题的！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "SEA_Octupas1",
	NextID = 14419105,
}
StorySpeechConfig[StorySpeechID.Id14419105] =
{
	Id = 14419105,
	CharName = "珊瑚阿卡",
	Text = "你叫我假唱？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_20_shanhu",
	NextID = 14419106,
}
StorySpeechConfig[StorySpeechID.Id14419106] =
{
	Id = 14419106,
	CharName = "节目导演",
	Text = "这怎么能叫假唱呢……这是以防万一，直播策略啊。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "SEA_Octupas1",
	NextID = 14419107,
}
StorySpeechConfig[StorySpeechID.Id14419107] =
{
	Id = 14419107,
	CharName = "珊瑚阿卡",
	Text = "我珊瑚阿卡，绝对不可能假唱！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_20_shanhu",
}
StorySpeechConfig[StorySpeechID.Id14419201] =
{
	Id = 14419201,
	CharName = "虎鲸京",
	Text = "这里是……？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_14_hujing",
	NextID = 14419202,
}
StorySpeechConfig[StorySpeechID.Id14419202] =
{
	Id = 14419202,
	CharName = "曾经的老板",
	Text = "你啊，不要穿那么长的裙子，粉丝们不喜欢的……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "SEA_KingCrab",
	NextID = 14419203,
}
StorySpeechConfig[StorySpeechID.Id14419203] =
{
	Id = 14419203,
	CharName = "过去的虎鲸京",
	Text = "（眨眼）那大家喜欢什么样子的呢？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_14_hujing",
	NextID = 14419204,
}
StorySpeechConfig[StorySpeechID.Id14419204] =
{
	Id = 14419204,
	CharName = "曾经的老板",
	Text = "当然是喜欢……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "SEA_KingCrab",
	NextID = 14419205,
}
StorySpeechConfig[StorySpeechID.Id14419205] =
{
	Id = 14419205,
	CharName = "虎鲸京",
	Text = "够了！我什么时候才能逃出这个梦魇？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_14_hujing",
	NextID = 14419206,
}
StorySpeechConfig[StorySpeechID.Id14419206] =
{
	Id = 14419206,
	CharName = "梦魇",
	Text = "并非我把你困在这里，束缚住你的，是你自己的内心。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "SEA",
	RightIcon = "SEA_SeaUrchin",
	NextID = 14419207,
}
StorySpeechConfig[StorySpeechID.Id14419207] =
{
	Id = 14419207,
	CharName = "虎鲸京",
	Text = "我的心？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_14_hujing",
	NextID = 14419208,
}
StorySpeechConfig[StorySpeechID.Id14419208] =
{
	Id = 14419208,
	CharName = "梦魇",
	Text = "你的心会把你带来这里，让你回想起你想要忘掉的东西……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "SEA",
	RightIcon = "SEA_SeaUrchin",
	NextID = 14419209,
}
StorySpeechConfig[StorySpeechID.Id14419209] =
{
	Id = 14419209,
	CharName = "虎鲸京",
	Text = "你错了，我已经不会再沉湎过去了，我早就释怀了。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_14_hujing",
	NextID = 14419210,
}
StorySpeechConfig[StorySpeechID.Id14419210] =
{
	Id = 14419210,
	CharName = "梦魇",
	Text = "哦？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "SEA",
	RightIcon = "SEA_SeaUrchin",
	NextID = 14419211,
}
StorySpeechConfig[StorySpeechID.Id14419211] =
{
	Id = 14419211,
	CharName = "虎鲸京",
	Text = "那么，我现在就向你证明。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_14_hujing",
}
StorySpeechConfig[StorySpeechID.Id14421901] =
{
	Id = 14421901,
	CharName = "海底巫婆",
	Text = "哦？你想要报复王子，有意思。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_31_meirenyu_cos10",
	NextID = 14421902,
}
StorySpeechConfig[StorySpeechID.Id14421902] =
{
	Id = 14421902,
	CharName = "人鱼清音",
	Text = "是他，让我变为了泡沫，所以……我不能放过他！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_31_meirenyu",
	NextID = 14421903,
}
StorySpeechConfig[StorySpeechID.Id14421903] =
{
	Id = 14421903,
	CharName = "海底巫婆",
	Text = "（拿出杯子）喝下这杯药水后，你会获得你想要的力量，但是……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_31_meirenyu_cos10",
	NextID = 14421904,
}
StorySpeechConfig[StorySpeechID.Id14421904] =
{
	Id = 14421904,
	CharName = "海底巫婆",
	Text = "你美丽的竖琴、珍珠、美丽的衣裳，都将不复存在，你考虑清楚了吗？",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_31_meirenyu_cos10",
	NextID = 14421905,
}
StorySpeechConfig[StorySpeechID.Id14421905] =
{
	Id = 14421905,
	CharName = "人鱼清音",
	Text = "当然！为了拥有力量，我愿意付出任何代价！",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	RightIcon = "Sea_31_meirenyu",
	NextID = 14421906,
}
StorySpeechConfig[StorySpeechID.Id14421906] =
{
	Id = 14421906,
	CharName = "海底巫婆",
	Text = "很好，饮下它吧，你将会拥有穿越星球的力量，在宇宙中纵横……",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_31_meirenyu_cos10",
	NextID = 14421907,
}
StorySpeechConfig[StorySpeechID.Id14421907] =
{
	Id = 14421907,
	CharName = "海底巫婆",
	Text = "只是，当大仇得报，心愿已了时，你会沉入这里的海底，永世不见阳光。",
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	LeftIcon = "Sea_31_meirenyu_cos10",
}
StorySpeechConfig[StorySpeechID.Id14422001] =
{
	Id = 14422001,
	CharName = "家政中心经理",
	Text = "这次的升职考核，两位就来比比，谁扫得更干净，五分钟后检查成果。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_men4",
	NextID = 14422002,
}
StorySpeechConfig[StorySpeechID.Id14422002] =
{
	Id = 14422002,
	CharName = "家政中心同事",
	Text = "好的老板！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_18_laonainai_cos10",
	NextID = 14422003,
}
StorySpeechConfig[StorySpeechID.Id14422003] =
{
	Id = 14422003,
	CharName = "扫地鸡",
	Text = "好的老板！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_04_saodiji",
	NextID = 14422004,
}
StorySpeechConfig[StorySpeechID.Id14422004] =
{
	Id = 14422004,
	CharName = "家政中心同事",
	Text = "（把地板打磨抛光）啊，好累……你怎么不扫？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_18_laonainai_cos10",
	NextID = 14422005,
}
StorySpeechConfig[StorySpeechID.Id14422005] =
{
	Id = 14422005,
	CharName = "扫地鸡",
	Text = "我有技术支持，（按下按钮）这样，机器就可以自己行动了！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_04_saodiji",
	NextID = 14422006,
}
StorySpeechConfig[StorySpeechID.Id14422006] =
{
	Id = 14422006,
	CharName = "家政中心同事",
	Text = "？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_18_laonainai_cos10",
	NextID = 14422007,
}
StorySpeechConfig[StorySpeechID.Id14422007] =
{
	Id = 14422007,
	CharName = "家政中心经理",
	Text = "（5分钟后）我来看看，嗯，这块区域明显更白。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_men4",
	NextID = 14422008,
}
StorySpeechConfig[StorySpeechID.Id14422008] =
{
	Id = 14422008,
	CharName = "家政中心同事",
	Text = "是的！报告领导，这是我的区域！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_18_laonainai_cos10",
	NextID = 14422009,
}
StorySpeechConfig[StorySpeechID.Id14422009] =
{
	Id = 14422009,
	CharName = "家政中心经理",
	Text = "很好，你升——哎哟！（滑倒）",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_men4",
	NextID = 14422010,
}
StorySpeechConfig[StorySpeechID.Id14422010] =
{
	Id = 14422010,
	CharName = "家政中心同事",
	Text = "（惊）！！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_18_laonainai_cos10",
	NextID = 14422011,
}
StorySpeechConfig[StorySpeechID.Id14422011] =
{
	Id = 14422011,
	CharName = "家政中心经理",
	Text = "这么滑，这地谁能走？（看向扫地鸡）这个升职名额，给你了！",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_men4",
	NextID = 14422012,
}
StorySpeechConfig[StorySpeechID.Id14422012] =
{
	Id = 14422012,
	CharName = "家政中心同事",
	Text = "？我不服！这家伙根本没有扫地！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_18_laonainai_cos10",
	NextID = 14422013,
}
StorySpeechConfig[StorySpeechID.Id14422013] =
{
	Id = 14422013,
	CharName = "扫地鸡",
	Text = "什么？我扫了鸭！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_04_saodiji",
}
StorySpeechConfig[StorySpeechID.Id14422101] =
{
	Id = 14422101,
	CharName = "树精",
	Text = "怎么又是你？你之前不是拿尖刺和我做过交换了吗？还有什么不满足的？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_xiaoshuyang",
	NextID = 14422102,
}
StorySpeechConfig[StorySpeechID.Id14422102] =
{
	Id = 14422102,
	CharName = "白蔷薇",
	Text = "可是，我变成人形后，并没有找到他……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_05_baiqiangwei",
	NextID = 14422103,
}
StorySpeechConfig[StorySpeechID.Id14422103] =
{
	Id = 14422103,
	CharName = "树精",
	Text = "为什么一定要去找那个园丁呢？他不是已经离开这片花园了吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_xiaoshuyang",
	NextID = 14422104,
}
StorySpeechConfig[StorySpeechID.Id14422104] =
{
	Id = 14422104,
	CharName = "白蔷薇",
	Text = "如果没有他的辛勤灌溉，就没有现在的我，所以我一定要找到他，去报答他的恩情。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_05_baiqiangwei",
	NextID = 14422105,
}
StorySpeechConfig[StorySpeechID.Id14422105] =
{
	Id = 14422105,
	CharName = "树精",
	Text = "（叹气）好吧，你这次想我做什么？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_xiaoshuyang",
	NextID = 14422106,
}
StorySpeechConfig[StorySpeechID.Id14422106] =
{
	Id = 14422106,
	CharName = "白蔷薇",
	Text = "你可以把我变成红色的吗？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_05_baiqiangwei",
	NextID = 14422107,
}
StorySpeechConfig[StorySpeechID.Id14422107] =
{
	Id = 14422107,
	CharName = "树精",
	Text = "红色……？好啊，不过，这次需要以你蕊心的鲜血作为交换，而且……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_xiaoshuyang",
	NextID = 14422108,
}
StorySpeechConfig[StorySpeechID.Id14422108] =
{
	Id = 14422108,
	CharName = "树精",
	Text = "如果园丁的心里根本没有你，你将会在清晨枯萎，永不复生……你准备好了吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "RPG_xiaoshuyang",
	NextID = 14422109,
}
StorySpeechConfig[StorySpeechID.Id14422109] =
{
	Id = 14422109,
	CharName = "白蔷薇",
	Text = "当然，我这就向您证明我的决心！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_05_baiqiangwei",
}
StorySpeechConfig[StorySpeechID.Id14422201] =
{
	Id = 14422201,
	CharName = "小红帽",
	Text = "（警觉）什么人？！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_06_xiaohongmao",
	NextID = 14422202,
}
StorySpeechConfig[StorySpeechID.Id14422202] =
{
	Id = 14422202,
	CharName = "黑狼",
	Text = "嗷……（慢吞吞地走出来）你看到附近的狼群了吗，嗷？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_blackWolf",
	NextID = 14422203,
}
StorySpeechConfig[StorySpeechID.Id14422203] =
{
	Id = 14422203,
	CharName = "小红帽",
	Text = "可怜的狼先生，你落单了吗？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_06_xiaohongmao",
	NextID = 14422204,
}
StorySpeechConfig[StorySpeechID.Id14422204] =
{
	Id = 14422204,
	CharName = "黑狼",
	Text = "是的嗷……完全找不到他们人嗷。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_blackWolf",
	NextID = 14422205,
}
StorySpeechConfig[StorySpeechID.Id14422205] =
{
	Id = 14422205,
	CharName = "小红帽",
	Text = "我可以带你去寻找他们，就在这边森林的深处。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_06_xiaohongmao",
	NextID = 14422206,
}
StorySpeechConfig[StorySpeechID.Id14422206] =
{
	Id = 14422206,
	CharName = "黑狼",
	Text = "那真是太谢谢你了嗷！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_blackWolf",
	NextID = 14422207,
}
StorySpeechConfig[StorySpeechID.Id14422207] =
{
	Id = 14422207,
	CharName = "黑狼",
	Text = "（走着走着）小红帽，为什么你的眼睛又大又亮嗷？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_blackWolf",
	NextID = 14422208,
}
StorySpeechConfig[StorySpeechID.Id14422208] =
{
	Id = 14422208,
	CharName = "小红帽",
	Text = "为了帮你看清你的族类呀。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_06_xiaohongmao",
	NextID = 14422209,
}
StorySpeechConfig[StorySpeechID.Id14422209] =
{
	Id = 14422209,
	CharName = "黑狼",
	Text = "小红帽，为什么你的步伐如此有力嗷？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_blackWolf",
	NextID = 14422210,
}
StorySpeechConfig[StorySpeechID.Id14422210] =
{
	Id = 14422210,
	CharName = "小红帽",
	Text = "为了带你寻找你的家人呀。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_06_xiaohongmao",
	NextID = 14422211,
}
StorySpeechConfig[StorySpeechID.Id14422211] =
{
	Id = 14422211,
	CharName = "黑狼",
	Text = "小红帽，为什么你的双手总是藏在裙摆之下嗷？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_blackWolf",
	NextID = 14422212,
}
StorySpeechConfig[StorySpeechID.Id14422212] =
{
	Id = 14422212,
	CharName = "小红帽",
	Text = "（停住）当然是为了藏起……\n（笑）取你性命的武器呀。（拿出电锯）",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_06_xiaohongmao",
}
StorySpeechConfig[StorySpeechID.Id14422301] =
{
	Id = 14422301,
	CharName = "灵均",
	Text = "嚯！嚯！哈——嘿！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_07_quyuan",
	NextID = 14422302,
}
StorySpeechConfig[StorySpeechID.Id14422302] =
{
	Id = 14422302,
	CharName = "旅行商人",
	Text = "（疑惑）你……这是在干什么？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_14_lvxingshangren",
	NextID = 14422303,
}
StorySpeechConfig[StorySpeechID.Id14422303] =
{
	Id = 14422303,
	CharName = "灵均",
	Text = "咦——呀——！呼~",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_07_quyuan",
	NextID = 14422304,
}
StorySpeechConfig[StorySpeechID.Id14422304] =
{
	Id = 14422304,
	CharName = "旅行商人",
	Text = "？？？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_14_lvxingshangren",
	NextID = 14422305,
}
StorySpeechConfig[StorySpeechID.Id14422305] =
{
	Id = 14422305,
	CharName = "灵均",
	Text = "（呼气）视倏忽而无见兮，听惝恍而无闻。\n超无为以至清兮，与泰初而为邻。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_07_quyuan",
	NextID = 14422306,
}
StorySpeechConfig[StorySpeechID.Id14422306] =
{
	Id = 14422306,
	CharName = "灵均",
	Text = "此刻气爽神清，大彻大悟……羽化登仙，不过一场大梦。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_07_quyuan",
	NextID = 14422307,
}
StorySpeechConfig[StorySpeechID.Id14422307] =
{
	Id = 14422307,
	CharName = "旅行商人",
	Text = "这人好奇怪，嘟嘟囔囔地说着什么呢……哇，他怎么，怎么在发光啊！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "Rpg_14_lvxingshangren",
	NextID = 14422308,
}
StorySpeechConfig[StorySpeechID.Id14422308] =
{
	Id = 14422308,
	CharName = "灵均",
	Text = "这就是飞一般的感觉吗，好强大的力量……\n糟糕，这股力量失控了！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_07_quyuan",
}
StorySpeechConfig[StorySpeechID.Id14422401] =
{
	Id = 14422401,
	CharName = "小队长",
	Text = "可以简单介绍一下你自己吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 14422402,
}
StorySpeechConfig[StorySpeechID.Id14422402] =
{
	Id = 14422402,
	CharName = "龙头老大",
	Text = "我是龙舟学院毕业的，绩点排名第一，之前在龙舟队里担任船头的工作。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_08_longtoulaoda",
	NextID = 14422403,
}
StorySpeechConfig[StorySpeechID.Id14422403] =
{
	Id = 14422403,
	CharName = "小队长",
	Text = "船头啊……不错，你能接受加班吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 14422404,
}
StorySpeechConfig[StorySpeechID.Id14422404] =
{
	Id = 14422404,
	CharName = "龙头老大",
	Text = "加班工资是多少？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_08_longtoulaoda",
	NextID = 14422405,
}
StorySpeechConfig[StorySpeechID.Id14422405] =
{
	Id = 14422405,
	CharName = "小队长",
	Text = "加班工资？不不不，我们都是心甘情愿为小魔王大人加班的。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 14422406,
}
StorySpeechConfig[StorySpeechID.Id14422406] =
{
	Id = 14422406,
	CharName = "龙头老大",
	Text = "公司会交五险一金么？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_08_longtoulaoda",
	NextID = 14422407,
}
StorySpeechConfig[StorySpeechID.Id14422407] =
{
	Id = 14422407,
	CharName = "小队长",
	Text = "五……什么金？那是什么？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 14422408,
}
StorySpeechConfig[StorySpeechID.Id14422408] =
{
	Id = 14422408,
	CharName = "龙头老大",
	Text = "周末双休吗？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_08_longtoulaoda",
	NextID = 14422409,
}
StorySpeechConfig[StorySpeechID.Id14422409] =
{
	Id = 14422409,
	CharName = "小队长",
	Text = "双休？年轻人，你还是不知道职场的规则啊……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 14422410,
}
StorySpeechConfig[StorySpeechID.Id14422410] =
{
	Id = 14422410,
	CharName = "龙头老大",
	Text = "（准备走人）既然这样，我们就星际劳动局见吧。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_08_longtoulaoda",
	NextID = 14422411,
}
StorySpeechConfig[StorySpeechID.Id14422411] =
{
	Id = 14422411,
	CharName = "小队长",
	Text = "不行！我司才被星际总局勒令关门，好不容易才重新开业的！你休想去举报我们！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 14422412,
}
StorySpeechConfig[StorySpeechID.Id14422412] =
{
	Id = 14422412,
	CharName = "龙头老大",
	Text = "我要求公司缴纳五险一金，双休，提供加班工资，可以吗？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_08_longtoulaoda",
	NextID = 14422413,
}
StorySpeechConfig[StorySpeechID.Id14422413] =
{
	Id = 14422413,
	CharName = "小队长",
	Text = "这种要求……可恶，作为反派，我们怎么可能答应你这种要求啊！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
}
StorySpeechConfig[StorySpeechID.Id14422501] =
{
	Id = 14422501,
	CharName = "小队长",
	Text = "你的名字是……抬鼓达人？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 14422502,
}
StorySpeechConfig[StorySpeechID.Id14422502] =
{
	Id = 14422502,
	CharName = "抬鼓达人",
	Text = "是的，面试官。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_09_taigudaren",
	NextID = 14422503,
}
StorySpeechConfig[StorySpeechID.Id14422503] =
{
	Id = 14422503,
	CharName = "小队长",
	Text = "不过我们集团，负责的是rpg游戏，（打量）感觉你比较适合去音游公司啊。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 14422504,
}
StorySpeechConfig[StorySpeechID.Id14422504] =
{
	Id = 14422504,
	CharName = "抬鼓达人",
	Text = "啊，其实比起音游，我更喜欢您说的rpg游戏呢！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_09_taigudaren",
	NextID = 14422505,
}
StorySpeechConfig[StorySpeechID.Id14422505] =
{
	Id = 14422505,
	CharName = "小队长",
	Text = "是吗……（思索）说来，你有什么喜欢的音乐吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 14422506,
}
StorySpeechConfig[StorySpeechID.Id14422506] =
{
	Id = 14422506,
	CharName = "抬鼓达人",
	Text = "哎？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_09_taigudaren",
	NextID = 14422507,
}
StorySpeechConfig[StorySpeechID.Id14422507] =
{
	Id = 14422507,
	CharName = "小队长",
	Text = "你在唱歌的时候，嘴里会蹦出一些可爱的东西吗？比如小鸡、气球、达摩什么的……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 14422508,
}
StorySpeechConfig[StorySpeechID.Id14422508] =
{
	Id = 14422508,
	CharName = "抬鼓达人",
	Text = "？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_09_taigudaren",
	NextID = 14422509,
}
StorySpeechConfig[StorySpeechID.Id14422509] =
{
	Id = 14422509,
	CharName = "小队长",
	Text = "对了，那你以前打鼓的时候，会直接打自己的脸吗？哈哈哈……",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 14422510,
}
StorySpeechConfig[StorySpeechID.Id14422510] =
{
	Id = 14422510,
	CharName = "抬鼓达人",
	Text = "您……您真是太失礼了！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_09_taigudaren",
}
StorySpeechConfig[StorySpeechID.Id14422601] =
{
	Id = 14422601,
	CharName = "小队长",
	Text = "看你的简历……你在计算方面很有天赋啊。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 14422602,
}
StorySpeechConfig[StorySpeechID.Id14422602] =
{
	Id = 14422602,
	CharName = "桨手一号",
	Text = "是的，上一份工作中，我可以根据风向、航道深浅等信息，计算出船头最佳朝向和最近道路，帮助团队获得了12次龙舟赛冠军。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_10_jiangshou01",
	NextID = 14422603,
}
StorySpeechConfig[StorySpeechID.Id14422603] =
{
	Id = 14422603,
	CharName = "小队长",
	Text = "不过你的这些优势，和我们列车没什么关系，我们需要的是执行力强，对小魔王大人忠心耿耿的成员。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 14422604,
}
StorySpeechConfig[StorySpeechID.Id14422604] =
{
	Id = 14422604,
	CharName = "桨手一号",
	Text = "（扶眼镜）这个嘛……（才到一面，就开始压力面了吗？！）",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_10_jiangshou01",
	NextID = 14422605,
}
StorySpeechConfig[StorySpeechID.Id14422605] =
{
	Id = 14422605,
	CharName = "桨手一号",
	Text = "那个……我可以通过计算，判断列车最佳的行进速度，把风力对机身的伤害降到最小，最后实现列车的自动化行进。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_10_jiangshou01",
}
StorySpeechConfig[StorySpeechID.Id14422701] =
{
	Id = 14422701,
	CharName = "小队长",
	Text = "说一下吧，你为什么选择来魔王集团面试。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 14422702,
}
StorySpeechConfig[StorySpeechID.Id14422702] =
{
	Id = 14422702,
	CharName = "桨手二号",
	Text = "我也不想来，我是陪我姐姐来面试的，结果小魔王说，看我的气质很great，建议我来try一下。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_11_jiangshou02",
	NextID = 14422703,
}
StorySpeechConfig[StorySpeechID.Id14422703] =
{
	Id = 14422703,
	CharName = "桨手二号",
	Text = "我姐姐也踹我，让我面试，我也不知道面试是个啥，就干脆过来看看。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_11_jiangshou02",
	NextID = 14422704,
}
StorySpeechConfig[StorySpeechID.Id14422704] =
{
	Id = 14422704,
	CharName = "小队长",
	Text = "所以说，你根本不想来？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 14422705,
}
StorySpeechConfig[StorySpeechID.Id14422705] =
{
	Id = 14422705,
	CharName = "桨手二号",
	Text = "（点头）我想回家，我想睡觉。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_11_jiangshou02",
	NextID = 14422706,
}
StorySpeechConfig[StorySpeechID.Id14422706] =
{
	Id = 14422706,
	CharName = "小队长",
	Text = "哼，根本不可能！你知道我今天都干了些什么吗？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 14422707,
}
StorySpeechConfig[StorySpeechID.Id14422707] =
{
	Id = 14422707,
	CharName = "桨手二号",
	Text = "不知道。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_11_jiangshou02",
	NextID = 14422708,
}
StorySpeechConfig[StorySpeechID.Id14422708] =
{
	Id = 14422708,
	CharName = "小队长",
	Text = "我今天面试了3309人，说的话至少超过了20万字！凭什么我辛辛苦苦工作，你就可以回去睡觉？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 14422709,
}
StorySpeechConfig[StorySpeechID.Id14422709] =
{
	Id = 14422709,
	CharName = "桨手二号",
	Text = "因为这是你的工作。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_11_jiangshou02",
	NextID = 14422710,
}
StorySpeechConfig[StorySpeechID.Id14422710] =
{
	Id = 14422710,
	CharName = "小队长",
	Text = "你必须给我留下来，和我一起工作！\n现在，让我看看你的实力吧！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
}
StorySpeechConfig[StorySpeechID.Id14422801] =
{
	Id = 14422801,
	CharName = "小队长",
	Text = "今天的面试就到这里了……（叹气）怎么一个合适的都没有。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 14422802,
}
StorySpeechConfig[StorySpeechID.Id14422802] =
{
	Id = 14422802,
	CharName = "龙尾小弟",
	Text = "面试官……还有我。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_12_longweixiaodi",
	NextID = 14422803,
}
StorySpeechConfig[StorySpeechID.Id14422803] =
{
	Id = 14422803,
	CharName = "小队长",
	Text = "怎么还有一个？\n你为什么应聘这个职位？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 14422804,
}
StorySpeechConfig[StorySpeechID.Id14422804] =
{
	Id = 14422804,
	CharName = "龙尾小弟",
	Text = "我，我，那个……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_12_longweixiaodi",
	NextID = 14422805,
}
StorySpeechConfig[StorySpeechID.Id14422805] =
{
	Id = 14422805,
	CharName = "小队长",
	Text = "你看起来不太自信啊，小兄弟。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 14422806,
}
StorySpeechConfig[StorySpeechID.Id14422806] =
{
	Id = 14422806,
	CharName = "龙尾小弟",
	Text = "是的，因为我在龙舟里就是龙尾，学院里的成绩也是吊车尾，大家都说我从小就吊车尾。这次，我只是想来试试，能不能……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_12_longweixiaodi",
	NextID = 14422807,
}
StorySpeechConfig[StorySpeechID.Id14422807] =
{
	Id = 14422807,
	CharName = "小队长",
	Text = "很好，你被录取了！",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 14422808,
}
StorySpeechConfig[StorySpeechID.Id14422808] =
{
	Id = 14422808,
	CharName = "龙尾小弟",
	Text = "？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_12_longweixiaodi",
	NextID = 14422809,
}
StorySpeechConfig[StorySpeechID.Id14422809] =
{
	Id = 14422809,
	CharName = "小队长",
	Text = "我看出来了，你和车尾有非常深刻的缘分，车尾一职非你莫属。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	LeftIcon = "Rpg_13_dashouxiaodi",
	NextID = 14422810,
}
StorySpeechConfig[StorySpeechID.Id14422810] =
{
	Id = 14422810,
	CharName = "车厢一号",
	Text = "面试官，我不服！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_10_jiangshou01_cos10",
}
StorySpeechConfig[StorySpeechID.Id14423101] =
{
	Id = 14423101,
	CharName = "服装店店主",
	Text = "你穿绿色好看。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_ClothesShopBoss",
	NextID = 14423102,
}
StorySpeechConfig[StorySpeechID.Id14423102] =
{
	Id = 14423102,
	CharName = "月佬",
	Text = "年轻人，红乃姻缘之色，吉上加吉，就要从头红到脚才好啊。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_21_YueLao",
	NextID = 14423103,
}
StorySpeechConfig[StorySpeechID.Id14423103] =
{
	Id = 14423103,
	CharName = "服装店店主",
	Text = "大红大紫太俗气，我建议是用暗绿色的衣裳，配以水晶胸针增加光泽感，如果有披风，也是一个不错的选择，鞋可以是暗红色，不过……",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_ClothesShopBoss",
	NextID = 14423104,
}
StorySpeechConfig[StorySpeechID.Id14423104] =
{
	Id = 14423104,
	CharName = "月佬",
	Text = "哼，你根本没有审美。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_21_YueLao",
	NextID = 14423105,
}
StorySpeechConfig[StorySpeechID.Id14423105] =
{
	Id = 14423105,
	CharName = "服装店店主",
	Text = "（挑眉）你在挑战我的专业？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_ClothesShopBoss",
	NextID = 14423106,
}
StorySpeechConfig[StorySpeechID.Id14423106] =
{
	Id = 14423106,
	CharName = "月佬",
	Text = "我才是给你和那姑娘牵线搭桥的，听我的。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_21_YueLao",
	NextID = 14423107,
}
StorySpeechConfig[StorySpeechID.Id14423107] =
{
	Id = 14423107,
	CharName = "服装店店主",
	Text = "我专业，听我的。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_ClothesShopBoss",
	NextID = 14423108,
}
StorySpeechConfig[StorySpeechID.Id14423108] =
{
	Id = 14423108,
	CharName = "牵牛",
	Text = "那个……两位的意见，我都会参考一下的，然后挑选一个合适的……",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_13_QianNiu",
	NextID = 14423109,
}
StorySpeechConfig[StorySpeechID.Id14423109] =
{
	Id = 14423109,
	CharName = "服装店店主",
	Text = "所以你不打算按照我的建议挑选了？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_ClothesShopBoss",
	NextID = 14423110,
}
StorySpeechConfig[StorySpeechID.Id14423110] =
{
	Id = 14423110,
	CharName = "月佬",
	Text = "不行，这事必须听我的！！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_21_YueLao",
	NextID = 14423111,
}
StorySpeechConfig[StorySpeechID.Id14423111] =
{
	Id = 14423111,
	CharName = "服装店店主",
	Text = "牵牛（使眼色）。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_ClothesShopBoss",
	NextID = 14423112,
}
StorySpeechConfig[StorySpeechID.Id14423112] =
{
	Id = 14423112,
	CharName = "牵牛",
	Text = "…嗯？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_13_QianNiu",
	NextID = 14423113,
}
StorySpeechConfig[StorySpeechID.Id14423113] =
{
	Id = 14423113,
	CharName = "服装店店主",
	Text = "把这个满嘴胡话的牛头人轰出去。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_ClothesShopBoss",
	NextID = 14423114,
}
StorySpeechConfig[StorySpeechID.Id14423114] =
{
	Id = 14423114,
	CharName = "月佬",
	Text = "花孔雀！你这是对本我的大不敬。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_21_YueLao",
	NextID = 14423115,
}
StorySpeechConfig[StorySpeechID.Id14423115] =
{
	Id = 14423115,
	CharName = "牵牛",
	Text = "对不起，大佬，得罪了。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_13_QianNiu",
}
StorySpeechConfig[StorySpeechID.Id14423201] =
{
	Id = 14423201,
	CharName = "小红",
	Text = "（拿住衣裳）是我的了……哎？",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_12_xiaohong",
	NextID = 14423202,
}
StorySpeechConfig[StorySpeechID.Id14423202] =
{
	Id = 14423202,
	CharName = "一心",
	Text = "……？？？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_14_YiXin",
	NextID = 14423203,
}
StorySpeechConfig[StorySpeechID.Id14423203] =
{
	Id = 14423203,
	CharName = "小红",
	Text = "（瞪）你还挺有眼光的。",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_12_xiaohong",
	NextID = 14423204,
}
StorySpeechConfig[StorySpeechID.Id14423204] =
{
	Id = 14423204,
	CharName = "一心",
	Text = "你也一样。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_14_YiXin",
	NextID = 14423205,
}
StorySpeechConfig[StorySpeechID.Id14423205] =
{
	Id = 14423205,
	CharName = "小红",
	Text = "能把它给我吗？你看，我全身上下都是红色，和这条裙子多配呀！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_12_xiaohong",
	NextID = 14423206,
}
StorySpeechConfig[StorySpeechID.Id14423206] =
{
	Id = 14423206,
	CharName = "一心",
	Text = "可你的身材呈椭圆形，无法塞进裙子的概率达到94.98%，和裙子的适配度只有4.67%，以及……",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_14_YiXin",
	NextID = 14423207,
}
StorySpeechConfig[StorySpeechID.Id14423207] =
{
	Id = 14423207,
	CharName = "小红",
	Text = "你、你是在嘲笑我糖豆人的身材吗？请你公平竞争，不要捏造奇怪的数据！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_12_xiaohong",
	NextID = 14423208,
}
StorySpeechConfig[StorySpeechID.Id14423208] =
{
	Id = 14423208,
	CharName = "一心",
	Text = "我并没有这样做，刚刚的信息虽然是我目测的，但真实率有…",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_14_YiXin",
	NextID = 14423209,
}
StorySpeechConfig[StorySpeechID.Id14423209] =
{
	Id = 14423209,
	CharName = "小红",
	Text = "好了！既然我们无法说服对方，就用原始的方式解决吧！",
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "Fat",
	LeftIcon = "Fat_12_xiaohong",
}
StorySpeechConfig[StorySpeechID.Id14423301] =
{
	Id = 14423301,
	CharName = "三花",
	Text = "二橘应该戴上橘色的猫耳喵~这样才可爱！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_16_SanHua",
	NextID = 14423302,
}
StorySpeechConfig[StorySpeechID.Id14423302] =
{
	Id = 14423302,
	CharName = "七织",
	Text = "不不不，我们二橘要穿上橘红色的衫裙，带上珠钗才可爱！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_20_QiZhi",
	NextID = 14423303,
}
StorySpeechConfig[StorySpeechID.Id14423303] =
{
	Id = 14423303,
	CharName = "一心",
	Text = "二橘和可爱气质……适配度不足2%。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_14_YiXin",
	NextID = 14423304,
}
StorySpeechConfig[StorySpeechID.Id14423304] =
{
	Id = 14423304,
	CharName = "五行",
	Text = "那就来一身帅气的袍子。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_18_WuXing",
	NextID = 14423305,
}
StorySpeechConfig[StorySpeechID.Id14423305] =
{
	Id = 14423305,
	CharName = "七织",
	Text = "可是那个橘色的衫裙真的很适合二橘嘛！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_20_QiZhi",
	NextID = 14423306,
}
StorySpeechConfig[StorySpeechID.Id14423306] =
{
	Id = 14423306,
	CharName = "三花",
	Text = "不喵，明明那个……",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_16_SanHua",
	NextID = 14423307,
}
StorySpeechConfig[StorySpeechID.Id14423307] =
{
	Id = 14423307,
	CharName = "二橘",
	Text = "好了！！！！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_15_ErJv",
	NextID = 14423308,
}
StorySpeechConfig[StorySpeechID.Id14423308] =
{
	Id = 14423308,
	CharName = "二橘",
	Text = "你们让我自己想想！！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_15_ErJv",
	NextID = 14423309,
}
StorySpeechConfig[StorySpeechID.Id14423309] =
{
	Id = 14423309,
	CharName = "二橘",
	Text = "（三分钟后）喂，那个店员小哥，你推荐哪一款？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_15_ErJv",
	NextID = 14423310,
}
StorySpeechConfig[StorySpeechID.Id14423310] =
{
	Id = 14423310,
	CharName = "牵牛",
	Text = "那个，黄、橘、啊不是……青色，都，都蛮适合的……",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_13_QianNiu",
	NextID = 14423311,
}
StorySpeechConfig[StorySpeechID.Id14423311] =
{
	Id = 14423311,
	CharName = "七织",
	Text = "是吧是吧？橘色的真的很适合！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_20_QiZhi",
	NextID = 14423312,
}
StorySpeechConfig[StorySpeechID.Id14423312] =
{
	Id = 14423312,
	CharName = "二橘",
	Text = "七嘴八舌的……好吵！！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_15_ErJv",
}
StorySpeechConfig[StorySpeechID.Id14423401] =
{
	Id = 14423401,
	CharName = "三花",
	Text = "喂喂喵，这里有没有猫咪很喜欢的那种材质的衣服喵？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_16_SanHua",
	NextID = 14423402,
}
StorySpeechConfig[StorySpeechID.Id14423402] =
{
	Id = 14423402,
	CharName = "服装店店主",
	Text = "……？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_ClothesShopBoss",
	NextID = 14423403,
}
StorySpeechConfig[StorySpeechID.Id14423403] =
{
	Id = 14423403,
	CharName = "三花",
	Text = "就是毛茸茸的，猫咪一躺上去就会咕噜咕噜的那种材质。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_16_SanHua",
	NextID = 14423404,
}
StorySpeechConfig[StorySpeechID.Id14423404] =
{
	Id = 14423404,
	CharName = "服装店店主",
	Text = "……？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_ClothesShopBoss",
	NextID = 14423405,
}
StorySpeechConfig[StorySpeechID.Id14423405] =
{
	Id = 14423405,
	CharName = "三花",
	Text = "看样子是没有了…哦喵！那个头饰，好喜欢！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_16_SanHua",
	NextID = 14423406,
}
StorySpeechConfig[StorySpeechID.Id14423406] =
{
	Id = 14423406,
	CharName = "服装店店主",
	Text = "……？（看向牵牛）",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_ClothesShopBoss",
	NextID = 14423407,
}
StorySpeechConfig[StorySpeechID.Id14423407] =
{
	Id = 14423407,
	CharName = "三花",
	Text = "如果能把这些簪子取下来逗猫猫，效果一定很好的喵！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_16_SanHua",
	NextID = 14423408,
}
StorySpeechConfig[StorySpeechID.Id14423408] =
{
	Id = 14423408,
	CharName = "牵牛",
	Text = "那个，能不能请你，离开这里……",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_13_QianNiu",
	NextID = 14423409,
}
StorySpeechConfig[StorySpeechID.Id14423409] =
{
	Id = 14423409,
	CharName = "三花",
	Text = "为什么？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_16_SanHua",
	NextID = 14423410,
}
StorySpeechConfig[StorySpeechID.Id14423410] =
{
	Id = 14423410,
	CharName = "牵牛",
	Text = "我也是按照老板的眼色行事，对不住……",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_13_QianNiu",
	NextID = 14423411,
}
StorySpeechConfig[StorySpeechID.Id14423411] =
{
	Id = 14423411,
	CharName = "三花",
	Text = "哈？光天化日之下赶客？气死了喵！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_16_SanHua",
}
StorySpeechConfig[StorySpeechID.Id14423501] =
{
	Id = 14423501,
	CharName = "四荔",
	Text = "您好，我对刚刚试穿的那套裙子很满意，请问我可以直接穿着它离开吗？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_17_SiLi",
	NextID = 14423502,
}
StorySpeechConfig[StorySpeechID.Id14423502] =
{
	Id = 14423502,
	CharName = "牵牛",
	Text = "好的，我把您原来的衣服打包起来。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_13_QianNiu",
	NextID = 14423503,
}
StorySpeechConfig[StorySpeechID.Id14423503] =
{
	Id = 14423503,
	CharName = "四荔",
	Text = "（打开背包）给你一张兑换券就好了，对吧？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_17_SiLi",
	NextID = 14423504,
}
StorySpeechConfig[StorySpeechID.Id14423504] =
{
	Id = 14423504,
	CharName = "四荔",
	Text = "（嘿嘿…再附带送你一个小礼物…）",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_17_SiLi",
	NextID = 14423505,
}
StorySpeechConfig[StorySpeechID.Id14423505] =
{
	Id = 14423505,
	CharName = "牵牛",
	Text = "是的，（整理包装袋）这是你的……唔哇啊啊啊啊啊！！！！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_13_QianNiu",
	NextID = 14423506,
}
StorySpeechConfig[StorySpeechID.Id14423506] =
{
	Id = 14423506,
	CharName = "牵牛",
	Text = "（跳）蜘蛛！蜘蛛！啊！！！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_13_QianNiu",
	NextID = 14423507,
}
StorySpeechConfig[StorySpeechID.Id14423507] =
{
	Id = 14423507,
	CharName = "四荔",
	Text = "是假的哦。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_17_SiLi",
	NextID = 14423508,
}
StorySpeechConfig[StorySpeechID.Id14423508] =
{
	Id = 14423508,
	CharName = "牵牛",
	Text = "诶？什么？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_13_QianNiu",
	NextID = 14423509,
}
StorySpeechConfig[StorySpeechID.Id14423509] =
{
	Id = 14423509,
	CharName = "四荔",
	Text = "假蜘蛛而已，不过…你的反应，是我见过的人里，最最夸张的一个。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_17_SiLi",
	NextID = 14423510,
}
StorySpeechConfig[StorySpeechID.Id14423510] =
{
	Id = 14423510,
	CharName = "牵牛",
	Text = "（恍然大悟）\n这位顾客！！请停止这种奇怪的玩笑！！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_13_QianNiu",
}
StorySpeechConfig[StorySpeechID.Id14423601] =
{
	Id = 14423601,
	CharName = "牵牛",
	Text = "您是最后一位了，请把背包给我检查一下吧。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_13_QianNiu",
	NextID = 14423602,
}
StorySpeechConfig[StorySpeechID.Id14423602] =
{
	Id = 14423602,
	CharName = "五行",
	Text = "（递出）小哥，你就没想过，换一种方式思考吗？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_18_WuXing",
	NextID = 14423603,
}
StorySpeechConfig[StorySpeechID.Id14423603] =
{
	Id = 14423603,
	CharName = "牵牛",
	Text = "换一种方式……？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_13_QianNiu",
	NextID = 14423604,
}
StorySpeechConfig[StorySpeechID.Id14423604] =
{
	Id = 14423604,
	CharName = "五行",
	Text = "“不要让别人找到我偷的东西”，和“别让他们找到我”，到底哪个比较重要呢？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_18_WuXing",
	NextID = 14423605,
}
StorySpeechConfig[StorySpeechID.Id14423605] =
{
	Id = 14423605,
	CharName = "牵牛",
	Text = "什、什么……（思索）",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_13_QianNiu",
	NextID = 14423606,
}
StorySpeechConfig[StorySpeechID.Id14423606] =
{
	Id = 14423606,
	CharName = "五行",
	Text = "还是后者更重要吧？\n所以，如果我是你，我会在店内寻找，犯人最容易藏匿的地方。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_18_WuXing",
	NextID = 14423607,
}
StorySpeechConfig[StorySpeechID.Id14423607] =
{
	Id = 14423607,
	CharName = "牵牛",
	Text = "你的意思是……（冷汗直流）偷衣服的犯人，藏在店里的某个地方？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_13_QianNiu",
	NextID = 14423608,
}
StorySpeechConfig[StorySpeechID.Id14423608] =
{
	Id = 14423608,
	CharName = "五行",
	Text = "我刚刚观察过了，桌下、试衣间、衣柜都没有人的痕迹，那么，唯一的可能性就是……",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_18_WuXing",
	NextID = 14423609,
}
StorySpeechConfig[StorySpeechID.Id14423609] =
{
	Id = 14423609,
	CharName = "五行",
	Text = "（眼镜白光一闪）",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_18_WuXing",
	NextID = 14423610,
}
StorySpeechConfig[StorySpeechID.Id14423610] =
{
	Id = 14423610,
	CharName = "五行",
	Text = "那位穿着裙子，在灯光照不到的一片漆黑中，隐藏起来的先生…请你现在，走到灯光下吧。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_18_WuXing",
}
StorySpeechConfig[StorySpeechID.Id14423701] =
{
	Id = 14423701,
	CharName = "牵牛",
	Text = "……",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_13_QianNiu",
	NextID = 14423702,
}
StorySpeechConfig[StorySpeechID.Id14423702] =
{
	Id = 14423702,
	CharName = "七织",
	Text = "……",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_20_QiZhi",
	NextID = 14423703,
}
StorySpeechConfig[StorySpeechID.Id14423703] =
{
	Id = 14423703,
	CharName = "六瑶",
	Text = "……",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_19_LiuYao",
	NextID = 14423704,
}
StorySpeechConfig[StorySpeechID.Id14423704] =
{
	Id = 14423704,
	CharName = "牵牛",
	Text = "您已经在这里徘徊十二分钟了，为什么不进去呢？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_13_QianNiu",
	NextID = 14423705,
}
StorySpeechConfig[StorySpeechID.Id14423705] =
{
	Id = 14423705,
	CharName = "六瑶",
	Text = "那个，一定要试穿吗……",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_19_LiuYao",
	NextID = 14423706,
}
StorySpeechConfig[StorySpeechID.Id14423706] =
{
	Id = 14423706,
	CharName = "七织",
	Text = "当然啦六瑶！不试穿一下怎么知道适不适合呢？万一不适合，岂不是又要坐飞船过来退货，那也太麻烦了！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_20_QiZhi",
	NextID = 14423707,
}
StorySpeechConfig[StorySpeechID.Id14423707] =
{
	Id = 14423707,
	CharName = "六瑶",
	Text = "可是小七，我不敢进去……",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_19_LiuYao",
	NextID = 14423708,
}
StorySpeechConfig[StorySpeechID.Id14423708] =
{
	Id = 14423708,
	CharName = "牵牛",
	Text = "是幽闭恐惧症吗，那有些麻烦了。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_13_QianNiu",
	NextID = 14423709,
}
StorySpeechConfig[StorySpeechID.Id14423709] =
{
	Id = 14423709,
	CharName = "六瑶",
	Text = "应该不是，只是……",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_19_LiuYao",
	NextID = 14423710,
}
StorySpeechConfig[StorySpeechID.Id14423710] =
{
	Id = 14423710,
	CharName = "七织",
	Text = "不怕不怕！（走进试衣间，关门）你看，我就进去了。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_20_QiZhi",
	NextID = 14423711,
}
StorySpeechConfig[StorySpeechID.Id14423711] =
{
	Id = 14423711,
	CharName = "七织",
	Text = "（走出）我又出来了！你看你看，很简单吧？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_20_QiZhi",
	NextID = 14423712,
}
StorySpeechConfig[StorySpeechID.Id14423712] =
{
	Id = 14423712,
	CharName = "六瑶",
	Text = "嗯……嗯……",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_19_LiuYao",
	NextID = 14423713,
}
StorySpeechConfig[StorySpeechID.Id14423713] =
{
	Id = 14423713,
	CharName = "七织",
	Text = "没关系，我在外面陪你，进去吧。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_20_QiZhi",
	NextID = 14423714,
}
StorySpeechConfig[StorySpeechID.Id14423714] =
{
	Id = 14423714,
	CharName = "六瑶",
	Text = "好、好的…我一定要，战胜胆小的自己……我、我一定可以做到…",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_19_LiuYao",
}
StorySpeechConfig[StorySpeechID.Id14423801] =
{
	Id = 14423801,
	CharName = "七织",
	Text = "我的衣服呢？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_20_QiZhi",
	NextID = 14423802,
}
StorySpeechConfig[StorySpeechID.Id14423802] =
{
	Id = 14423802,
	CharName = "月佬",
	Text = "（小声）小伙子，我就只能帮你到这儿了。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_21_YueLao",
	NextID = 14423803,
}
StorySpeechConfig[StorySpeechID.Id14423803] =
{
	Id = 14423803,
	CharName = "牵牛",
	Text = "（小声）大佬且慢！！您把这件衣裳无缘无故给我，到底是……",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_13_QianNiu",
	NextID = 14423804,
}
StorySpeechConfig[StorySpeechID.Id14423804] =
{
	Id = 14423804,
	CharName = "月佬",
	Text = "（小声）天机不可泄露，不可说，不可说。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_21_YueLao",
	NextID = 14423805,
}
StorySpeechConfig[StorySpeechID.Id14423805] =
{
	Id = 14423805,
	CharName = "牵牛",
	Text = "（小声）这样做无理且无礼，还请大佬把衣裳送回原处，还给那位姑娘。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_13_QianNiu",
	NextID = 14423806,
}
StorySpeechConfig[StorySpeechID.Id14423806] =
{
	Id = 14423806,
	CharName = "月佬",
	Text = "……你！我看你像个木头！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_21_YueLao",
	NextID = 14423807,
}
StorySpeechConfig[StorySpeechID.Id14423807] =
{
	Id = 14423807,
	CharName = "七织",
	Text = "你们两个鬼鬼祟祟地说什么呢？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_20_QiZhi",
	NextID = 14423808,
}
StorySpeechConfig[StorySpeechID.Id14423808] =
{
	Id = 14423808,
	CharName = "牵牛",
	Text = "哇呜！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_13_QianNiu",
	NextID = 14423809,
}
StorySpeechConfig[StorySpeechID.Id14423809] =
{
	Id = 14423809,
	CharName = "月佬",
	Text = "（惊）呼……吓死我了。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_21_YueLao",
	NextID = 14423810,
}
StorySpeechConfig[StorySpeechID.Id14423810] =
{
	Id = 14423810,
	CharName = "七织",
	Text = "我的衣服怎么在这里？！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_20_QiZhi",
	NextID = 14423811,
}
StorySpeechConfig[StorySpeechID.Id14423811] =
{
	Id = 14423811,
	CharName = "月佬",
	Text = "这个这个……你问他，（指向牵牛），我先溜了。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_21_YueLao",
	NextID = 14423812,
}
StorySpeechConfig[StorySpeechID.Id14423812] =
{
	Id = 14423812,
	CharName = "牵牛",
	Text = "……？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_13_QianNiu",
	NextID = 14423813,
}
StorySpeechConfig[StorySpeechID.Id14423813] =
{
	Id = 14423813,
	CharName = "七织",
	Text = "你、你怎么会做这种事啊！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	LeftIcon = "SPBUS_20_QiZhi",
}
StorySpeechConfig[StorySpeechID.Id14423901] =
{
	Id = 14423901,
	CharName = "昆仑之仙",
	Text = "你来这里，是想求什么呢？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_23_chuangzaozhishen_cos20",
	NextID = 14423902,
}
StorySpeechConfig[StorySpeechID.Id14423902] =
{
	Id = 14423902,
	CharName = "月佬",
	Text = "我所求很简单，只要你不再干涉人间姻缘，我就离开这里，永远不回来。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_21_YueLao",
	NextID = 14423903,
}
StorySpeechConfig[StorySpeechID.Id14423903] =
{
	Id = 14423903,
	CharName = "昆仑之仙",
	Text = "你还是不懂...人与人的缘分，实在是太浅了，有的人终其一生，都不明白什么是爱，这样的人，如果我们不为他们牵上红线，他们还怎么遇见良人，结婚成家？",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_23_chuangzaozhishen_cos20",
	NextID = 14423904,
}
StorySpeechConfig[StorySpeechID.Id14423904] =
{
	Id = 14423904,
	CharName = "昆仑之仙",
	Text = "人间的姻缘，也太脆弱了，如果没有我们把有情人绑住，引导他们做出正确的抉择，强迫他们坚持下来，离异之人又会有多少？那我们婚介所的业绩和名声...",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_23_chuangzaozhishen_cos20",
	NextID = 14423905,
}
StorySpeechConfig[StorySpeechID.Id14423905] =
{
	Id = 14423905,
	CharName = "月佬",
	Text = "你错了，操纵姻缘，让心中无爱的人在一起，可心中无爱，又怎么懂得珍惜呢？既不珍惜，理应一别两宽，可你又为了所谓的业绩名声，让他们在孽缘中纠缠。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_21_YueLao",
	NextID = 14423906,
}
StorySpeechConfig[StorySpeechID.Id14423906] =
{
	Id = 14423906,
	CharName = "月佬",
	Text = "你这岂不是一步错，步步错？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_21_YueLao",
	NextID = 14423907,
}
StorySpeechConfig[StorySpeechID.Id14423907] =
{
	Id = 14423907,
	CharName = "昆仑之仙",
	Text = "…你这就是冥顽不灵了。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_23_chuangzaozhishen_cos20",
	NextID = 14423908,
}
StorySpeechConfig[StorySpeechID.Id14423908] =
{
	Id = 14423908,
	CharName = "月佬",
	Text = "我坚持心中的正义，不会因为你的三言两语而退却。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_21_YueLao",
	NextID = 14423909,
}
StorySpeechConfig[StorySpeechID.Id14423909] =
{
	Id = 14423909,
	CharName = "昆仑之仙",
	Text = "那你就撑过这十道天劫吧，撑过了，我们再谈。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_23_chuangzaozhishen_cos20",
}
StorySpeechConfig[StorySpeechID.Id14423951] =
{
	Id = 14423951,
	CharName = "昆仑之仙",
	Text = "…你赢了，看来你在流放期间，日子过得并不舒坦。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_23_chuangzaozhishen_cos20",
	NextID = 14423952,
}
StorySpeechConfig[StorySpeechID.Id14423952] =
{
	Id = 14423952,
	CharName = "月佬",
	Text = "舒坦了，今天躺在地上的，或许就是我了。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_21_YueLao",
	NextID = 14423953,
}
StorySpeechConfig[StorySpeechID.Id14423953] =
{
	Id = 14423953,
	CharName = "昆仑之仙",
	Text = "你这是为什么呢？你将决定姻缘的权利，交给每一个人，他们未必会理解，未必会感激你，甚至为怨你，让他们找不到成家的对象。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_23_chuangzaozhishen_cos20",
	NextID = 14423954,
}
StorySpeechConfig[StorySpeechID.Id14423954] =
{
	Id = 14423954,
	CharName = "月佬",
	Text = "（摇头）但这是他们的自由。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_21_YueLao",
	NextID = 14423955,
}
StorySpeechConfig[StorySpeechID.Id14423955] =
{
	Id = 14423955,
	CharName = "昆仑之仙",
	Text = "自由？哼，自由是最虚妄的东西。",
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "Mus",
	LeftIcon = "MUS_23_chuangzaozhishen_cos20",
	NextID = 14423956,
}
StorySpeechConfig[StorySpeechID.Id14423956] =
{
	Id = 14423956,
	CharName = "月佬",
	Text = "你往下看，看到茫茫人间了吗？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_21_YueLao",
	NextID = 14423957,
}
StorySpeechConfig[StorySpeechID.Id14423957] =
{
	Id = 14423957,
	CharName = "月佬",
	Text = "他们是人，不是你的提线木偶，他们有自己的人生...算了，俗话说得好，反派死于话多，虽然我不是反派，但还是先把你处理了吧。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "SPBUS_21_YueLao",
}
StorySpeechConfig[StorySpeechID.Id14424101] =
{
	Id = 14424101,
	CharName = "旁白喇叭",
	Text = "团圆圆疾速跑到大厅，\n“跑腿”大会已经开始了。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "EventItem_RPG_Event_8",
	NextID = 14424102,
}
StorySpeechConfig[StorySpeechID.Id14424102] =
{
	Id = 14424102,
	CharName = "团圆圆",
	Text = "对不起、对不起……\n对不起小鸽，我来晚了。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_22_TuanYuan",
	NextID = 14424103,
}
StorySpeechConfig[StorySpeechID.Id14424103] =
{
	Id = 14424103,
	CharName = "外卖小鸽",
	Text = "（瞥）……",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_gugu1",
	NextID = 14424104,
}
StorySpeechConfig[StorySpeechID.Id14424104] =
{
	Id = 14424104,
	CharName = "团圆圆",
	Text = "我起晚了，路上有点慢……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_22_TuanYuan",
	NextID = 14424105,
}
StorySpeechConfig[StorySpeechID.Id14424105] =
{
	Id = 14424105,
	CharName = "外卖小鸽",
	Text = "慢？你是怎么过来的？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_gugu1",
	NextID = 14424106,
}
StorySpeechConfig[StorySpeechID.Id14424106] =
{
	Id = 14424106,
	CharName = "团圆圆",
	Text = "我，我是跑……跑过来的。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_22_TuanYuan",
	NextID = 14424107,
}
StorySpeechConfig[StorySpeechID.Id14424107] =
{
	Id = 14424107,
	CharName = "外卖小鸽",
	Text = "我们这些送外卖的、送快递的、送订单的小鸽们，\n都是用的滑板、轮滑。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_gugu1",
	NextID = 14424108,
}
StorySpeechConfig[StorySpeechID.Id14424108] =
{
	Id = 14424108,
	CharName = "外卖小鸽",
	Text = "你跑步……怪不得你来得慢。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_gugu1",
	NextID = 14424109,
}
StorySpeechConfig[StorySpeechID.Id14424109] =
{
	Id = 14424109,
	CharName = "外卖小鸽",
	Text = "你徒步跑来……按理说，根本没资格参加这个会啊。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_gugu1",
	NextID = 14424110,
}
StorySpeechConfig[StorySpeechID.Id14424110] =
{
	Id = 14424110,
	CharName = "团圆圆",
	Text = "……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_22_TuanYuan",
	NextID = 14424111,
}
StorySpeechConfig[StorySpeechID.Id14424111] =
{
	Id = 14424111,
	CharName = "外卖小鸽",
	Text = "找个位置坐吧。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_gugu1",
	NextID = 14424112,
}
StorySpeechConfig[StorySpeechID.Id14424112] =
{
	Id = 14424112,
	CharName = "旁白喇叭",
	Text = "团圆圆找了一圈，每个椅子上都坐着人或鸽子，根本没有空出来的位置。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	RightIcon = "EventItem_RPG_Event_8",
	NextID = 14424113,
}
StorySpeechConfig[StorySpeechID.Id14424113] =
{
	Id = 14424113,
	CharName = "外卖小鸽",
	Text = "找得到吗？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_gugu1",
	NextID = 14424114,
}
StorySpeechConfig[StorySpeechID.Id14424114] =
{
	Id = 14424114,
	CharName = "团圆圆",
	Text = "……没找到。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_22_TuanYuan",
	NextID = 14424115,
}
StorySpeechConfig[StorySpeechID.Id14424115] =
{
	Id = 14424115,
	CharName = "外卖小鸽",
	Text = "你迟到十一分钟，就是不重视这个会，就是看不起我们，这样我们怎么一起做伙伴？回家等电话，有结果再通知你。",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_gugu1",
	NextID = 14424116,
}
StorySpeechConfig[StorySpeechID.Id14424116] =
{
	Id = 14424116,
	CharName = "团圆圆",
	Text = "（撸袖子，面露凶光）\n走就走——！\n（回头）喂，把你昨天从我这借走的轮滑还我！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_22_TuanYuan",
}
StorySpeechConfig[StorySpeechID.Id14424001] =
{
	Id = 14424001,
	CharName = "酋长妹妹",
	Text = "哥！哥？你哭什么啊，怎么了？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_05_UnlockChiefSister",
	NextID = 14424002,
}
StorySpeechConfig[StorySpeechID.Id14424002] =
{
	Id = 14424002,
	CharName = "酋长",
	Text = "妹砸——！\n（哭）我，我回不去了……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPDraw_04_UnlockChief",
	NextID = 14424003,
}
StorySpeechConfig[StorySpeechID.Id14424003] =
{
	Id = 14424003,
	CharName = "酋长妹妹",
	Text = "诶？为什么？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_05_UnlockChiefSister",
	NextID = 14424004,
}
StorySpeechConfig[StorySpeechID.Id14424004] =
{
	Id = 14424004,
	CharName = "酋长",
	Text = "我本来是来这儿抽卡的，呜呜……\n但我一直抽，一直抽不到，就……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPDraw_04_UnlockChief",
	NextID = 14424005,
}
StorySpeechConfig[StorySpeechID.Id14424005] =
{
	Id = 14424005,
	CharName = "酋长妹妹",
	Text = "就留在这儿了……？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_05_UnlockChiefSister",
	NextID = 14424006,
}
StorySpeechConfig[StorySpeechID.Id14424006] =
{
	Id = 14424006,
	CharName = "酋长",
	Text = "（点头）嗯，后来，后来他们说，（指向玉璧女王）不夜城需要我。\n他们说，冒险家们看着我，心里就平衡了，于是就让我一直留在这里。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPDraw_04_UnlockChief",
	NextID = 14424007,
}
StorySpeechConfig[StorySpeechID.Id14424007] =
{
	Id = 14424007,
	CharName = "酋长妹妹",
	Text = "……好家伙，哥，你这是找到了工作，就不打算回家了？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_05_UnlockChiefSister",
	NextID = 14424008,
}
StorySpeechConfig[StorySpeechID.Id14424008] =
{
	Id = 14424008,
	CharName = "玉璧女王",
	Text = "No！是因为你哥把不夜城淹了噢~",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPDraw_03_DiamondQueen",
	NextID = 14424009,
}
StorySpeechConfig[StorySpeechID.Id14424009] =
{
	Id = 14424009,
	CharName = "酋长妹妹",
	Text = "？？？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_05_UnlockChiefSister",
	NextID = 14424010,
}
StorySpeechConfig[StorySpeechID.Id14424010] =
{
	Id = 14424010,
	CharName = "玉璧女王",
	Text = "因为上次接到你的来信，他看着看着就哭了起来，哭着哭着……就把不夜城淹了。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPDraw_03_DiamondQueen",
	NextID = 14424011,
}
StorySpeechConfig[StorySpeechID.Id14424011] =
{
	Id = 14424011,
	CharName = "酋长妹妹",
	Text = "这、这要赔多少钱啊……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_05_UnlockChiefSister",
	NextID = 14424012,
}
StorySpeechConfig[StorySpeechID.Id14424012] =
{
	Id = 14424012,
	CharName = "精灵王子",
	Text = "倒不是赔钱的问题，你哥哥现在要去星际管理局，把事情交代一下。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPDraw_02_ElvenPrince",
	NextID = 14424013,
}
StorySpeechConfig[StorySpeechID.Id14424013] =
{
	Id = 14424013,
	CharName = "玉璧女王",
	Text = "Yes！\n但现在不夜城没有酋长了，前来的冒险家会怀疑自己才是非酋，所以……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_03_DiamondQueen",
	NextID = 14424014,
}
StorySpeechConfig[StorySpeechID.Id14424014] =
{
	Id = 14424014,
	CharName = "史莱姆大王",
	Text = "所以……（看向酋长妹妹）",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPDraw_01_SlimeKing",
	NextID = 14424015,
}
StorySpeechConfig[StorySpeechID.Id14424015] =
{
	Id = 14424015,
	CharName = "精灵王子",
	Text = "所以……（看向酋长妹妹）",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_02_ElvenPrince",
	NextID = 14424016,
}
StorySpeechConfig[StorySpeechID.Id14424016] =
{
	Id = 14424016,
	CharName = "酋长",
	Text = "呜呜，对不起……妹妹。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPDraw_04_UnlockChief",
	NextID = 14424017,
}
StorySpeechConfig[StorySpeechID.Id14424017] =
{
	Id = 14424017,
	CharName = "酋长妹妹",
	Text = "你们要我留在这里？不行，我要回家！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_05_UnlockChiefSister",
	NextID = 14424018,
}
StorySpeechConfig[StorySpeechID.Id14424018] =
{
	Id = 14424018,
	CharName = "玉璧女王",
	Text = "放心吧，我们会把你打扮得很好看的噢~\n你就是我们不夜城的小公主~",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPDraw_03_DiamondQueen",
	NextID = 14424019,
}
StorySpeechConfig[StorySpeechID.Id14424019] =
{
	Id = 14424019,
	CharName = "酋长妹妹",
	Text = "不要……你们、你们不要过来啊！！！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPDraw_05_UnlockChiefSister",
}
StorySpeechConfig[StorySpeechID.Id14424201] =
{
	Id = 14424201,
	CharName = "旁白喇叭",
	Text = "周边店里琳琅满目，南瓜头套、魔杖、糖果袋应有尽有。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "EventItem_RPG_Event_8",
	NextID = 14424202,
}
StorySpeechConfig[StorySpeechID.Id14424202] =
{
	Id = 14424202,
	CharName = "迪斯科野狼",
	Text = "Wow~这里商品好多。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_23_LangRen",
	NextID = 14424203,
}
StorySpeechConfig[StorySpeechID.Id14424203] =
{
	Id = 14424203,
	CharName = "小红帽",
	Text = "你不会没来过这种地方吧？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_06_xiaohongmao",
	NextID = 14424204,
}
StorySpeechConfig[StorySpeechID.Id14424204] =
{
	Id = 14424204,
	CharName = "迪斯科野狼",
	Text = "Never，这不是我会常去的地方，但这热闹已超出我想象，yoo~",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_23_LangRen",
	NextID = 14424205,
}
StorySpeechConfig[StorySpeechID.Id14424205] =
{
	Id = 14424205,
	CharName = "小红帽",
	Text = "AKA迪斯科野狼的说唱先生，\n你很喜欢戴这些反射着光的链子啊，是银链子吗？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_06_xiaohongmao",
	NextID = 14424206,
}
StorySpeechConfig[StorySpeechID.Id14424206] =
{
	Id = 14424206,
	CharName = "迪斯科野狼",
	Text = "（愣住）当、当然，也有一些是铁链。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_23_LangRen",
	NextID = 14424207,
}
StorySpeechConfig[StorySpeechID.Id14424207] =
{
	Id = 14424207,
	CharName = "小红帽",
	Text = "这一双银色的南瓜耳环，符合你的审美品位吗？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_06_xiaohongmao",
	NextID = 14424208,
}
StorySpeechConfig[StorySpeechID.Id14424208] =
{
	Id = 14424208,
	CharName = "迪斯科野狼",
	Text = "……怎么，你打算送我？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_23_LangRen",
	NextID = 14424209,
}
StorySpeechConfig[StorySpeechID.Id14424209] =
{
	Id = 14424209,
	CharName = "小红帽",
	Text = "如果你能戴上它，我会非常开心的。（伸出手）",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_06_xiaohongmao",
	NextID = 14424210,
}
StorySpeechConfig[StorySpeechID.Id14424210] =
{
	Id = 14424210,
	CharName = "迪斯科野狼",
	Text = "不，我想我还是更喜欢那个……\n（环视）对，那个万圣帽子。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_23_LangRen",
	NextID = 14424211,
}
StorySpeechConfig[StorySpeechID.Id14424211] =
{
	Id = 14424211,
	CharName = "小红帽",
	Text = "帽子？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_06_xiaohongmao",
	NextID = 14424212,
}
StorySpeechConfig[StorySpeechID.Id14424212] =
{
	Id = 14424212,
	CharName = "迪斯科野狼",
	Text = "对，就是帽子。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_23_LangRen",
	NextID = 14424213,
}
StorySpeechConfig[StorySpeechID.Id14424213] =
{
	Id = 14424213,
	CharName = "小红帽",
	Text = "迪斯科野狼先生，你不会……\n（笑）不能戴银制品吧？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_06_xiaohongmao",
	NextID = 14424214,
}
StorySpeechConfig[StorySpeechID.Id14424214] =
{
	Id = 14424214,
	CharName = "迪斯科野狼",
	Text = "怎么可能？我就是喜欢帽子。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_23_LangRen",
	NextID = 14424215,
}
StorySpeechConfig[StorySpeechID.Id14424215] =
{
	Id = 14424215,
	CharName = "小红帽",
	Text = "……那我只能，亲自为你戴上耳环了。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_06_xiaohongmao",
}
StorySpeechConfig[StorySpeechID.Id14424301] =
{
	Id = 14424301,
	CharName = "猫眼厨娘",
	Text = "等装修结束，我们就在山上开个乐园，打造住宿、温泉、赏雪、游玩一条龙服务。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 14424302,
}
StorySpeechConfig[StorySpeechID.Id14424302] =
{
	Id = 14424302,
	CharName = "猫眼厨娘",
	Text = "那块地不错，还有亭子牌匾，可以做一个用来拍照的打卡区。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 14424303,
}
StorySpeechConfig[StorySpeechID.Id14424303] =
{
	Id = 14424303,
	CharName = "猫眼厨娘",
	Text = "等下大雪那天，我们就来这里拍几张宣传照。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 14424304,
}
StorySpeechConfig[StorySpeechID.Id14424304] =
{
	Id = 14424304,
	CharName = "温泉鉴赏家",
	Text = "没问题，我老熟练了，标题都想好了——就叫《今年冬天的第一场雪》。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_26_WenQuanJianShanJia",
	NextID = 14424305,
}
StorySpeechConfig[StorySpeechID.Id14424305] =
{
	Id = 14424305,
	CharName = "旁白喇叭",
	Text = "山里的风突然变大，一阵狂风吹走了鉴赏家的帽子。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "EventItem_RPG_Event_8",
	NextID = 14424306,
}
StorySpeechConfig[StorySpeechID.Id14424306] =
{
	Id = 14424306,
	CharName = "温泉鉴赏家",
	Text = "哎，我的帽子！帽子！\n（追）该死的风，还我帽子！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_26_WenQuanJianShanJia",
	NextID = 14424307,
}
StorySpeechConfig[StorySpeechID.Id14424307] =
{
	Id = 14424307,
	CharName = "猫眼厨娘",
	Text = "你慢点儿，等等我。（准备下山）",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 14424308,
}
StorySpeechConfig[StorySpeechID.Id14424308] =
{
	Id = 14424308,
	CharName = "旁白喇叭",
	Text = "突然，有个白色的影子，倏忽间从厨娘背后一闪而过。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	RightIcon = "EventItem_RPG_Event_8",
	NextID = 14424309,
}
StorySpeechConfig[StorySpeechID.Id14424309] =
{
	Id = 14424309,
	CharName = "猫眼厨娘",
	Text = "谁？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 14424310,
}
StorySpeechConfig[StorySpeechID.Id14424310] =
{
	Id = 14424310,
	CharName = "雪神",
	Text = "……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_24_XueShen",
	NextID = 14424311,
}
StorySpeechConfig[StorySpeechID.Id14424311] =
{
	Id = 14424311,
	CharName = "猫眼厨娘",
	Text = "你是谁？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 14424312,
}
StorySpeechConfig[StorySpeechID.Id14424312] =
{
	Id = 14424312,
	CharName = "雪神",
	Text = "（暴怒）呜啦啦啦，我要吃人……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_24_XueShen",
	NextID = 14424313,
}
StorySpeechConfig[StorySpeechID.Id14424313] =
{
	Id = 14424313,
	CharName = "猫眼厨娘",
	Text = "难道，你是——！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
}
StorySpeechConfig[StorySpeechID.Id14424351] =
{
	Id = 14424351,
	CharName = "雪神",
	Text = "……（眼泪汪汪）",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_24_XueShen",
	NextID = 14424352,
}
StorySpeechConfig[StorySpeechID.Id14424352] =
{
	Id = 14424352,
	CharName = "猫眼厨娘",
	Text = "什么啊，原来只是一个小姑娘。（捡起面具）面具给你，别在山上恶作剧了，回家去吧。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 14424353,
}
StorySpeechConfig[StorySpeechID.Id14424353] =
{
	Id = 14424353,
	CharName = "雪神",
	Text = "我家就在这里，你从我家里出去，呜……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_24_XueShen",
	NextID = 14424354,
}
StorySpeechConfig[StorySpeechID.Id14424354] =
{
	Id = 14424354,
	CharName = "猫眼厨娘",
	Text = "哈？我说小姑娘，你调皮捣蛋可不行啊……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 14424355,
}
StorySpeechConfig[StorySpeechID.Id14424355] =
{
	Id = 14424355,
	CharName = "旁白喇叭",
	Text = "二十分钟后。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	RightIcon = "EventItem_RPG_Event_8",
	NextID = 14424356,
}
StorySpeechConfig[StorySpeechID.Id14424356] =
{
	Id = 14424356,
	CharName = "雪神",
	Text = "我都交代完了，你能不能离开这里，呜……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_24_XueShen",
	NextID = 14424357,
}
StorySpeechConfig[StorySpeechID.Id14424357] =
{
	Id = 14424357,
	CharName = "猫眼厨娘",
	Text = "好，（摸头）放心吧，雪神小姑娘，你以后不用装鬼了。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 14424358,
}
StorySpeechConfig[StorySpeechID.Id14424358] =
{
	Id = 14424358,
	CharName = "猫眼厨娘",
	Text = "我不会让别人上山的。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 14424359,
}
StorySpeechConfig[StorySpeechID.Id14424359] =
{
	Id = 14424359,
	CharName = "猫眼厨娘",
	Text = "（准备离开）对了，我在山下开了一家别墅，等晚上没人的时候，欢迎你来找我玩。再见~",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_25_MaoYanChuNiang",
}
StorySpeechConfig[StorySpeechID.Id14424401] =
{
	Id = 14424401,
	CharName = "猫眼厨娘",
	Text = "（尖叫）你……你在干什么！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 14424402,
}
StorySpeechConfig[StorySpeechID.Id14424402] =
{
	Id = 14424402,
	CharName = "温泉鉴赏家",
	Text = "（惊）啊！那个，那个我——（摔）哦哦，我的屁股！！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_26_WenQuanJianShanJia",
	NextID = 14424403,
}
StorySpeechConfig[StorySpeechID.Id14424403] =
{
	Id = 14424403,
	CharName = "猫眼厨娘",
	Text = "……你反应也太大了吧？说，在用你脑袋上的盆子干什么坏事？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 14424404,
}
StorySpeechConfig[StorySpeechID.Id14424404] =
{
	Id = 14424404,
	CharName = "温泉鉴赏家",
	Text = "（吞吞吐吐）那个、研究温泉的、性质……对，我在对这几次温泉活动进行复盘，从而更好地为团队赋能！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_26_WenQuanJianShanJia",
	NextID = 14424405,
}
StorySpeechConfig[StorySpeechID.Id14424405] =
{
	Id = 14424405,
	CharName = "猫眼厨娘",
	Text = "（翻白眼）你当我鼻子是瞎的吗？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 14424406,
}
StorySpeechConfig[StorySpeechID.Id14424406] =
{
	Id = 14424406,
	CharName = "旁白喇叭",
	Text = "猫眼厨娘走进他，一股又一股浓烈的啤酒清香从头顶处的木桶传来。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	RightIcon = "EventItem_RPG_Event_8",
	NextID = 14424407,
}
StorySpeechConfig[StorySpeechID.Id14424407] =
{
	Id = 14424407,
	CharName = "猫眼厨娘",
	Text = "好啊，在温泉区里偷喝啤酒……店规怎么说的？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 14424408,
}
StorySpeechConfig[StorySpeechID.Id14424408] =
{
	Id = 14424408,
	CharName = "温泉鉴赏家",
	Text = "第六章第二小节第十一条，不准温泉区吃提供给客人的冰淇淋、奶茶、啤酒、炸鸡等食物……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_26_WenQuanJianShanJia",
	NextID = 14424409,
}
StorySpeechConfig[StorySpeechID.Id14424409] =
{
	Id = 14424409,
	CharName = "温泉鉴赏家",
	Text = "可，可我也没吃，我只是拿走了，你要理解一下我的底层逻辑……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_26_WenQuanJianShanJia",
	NextID = 14424410,
}
StorySpeechConfig[StorySpeechID.Id14424410] =
{
	Id = 14424410,
	CharName = "猫眼厨娘",
	Text = "停止你的狡辩，我们按店规办事。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
}
StorySpeechConfig[StorySpeechID.Id14424451] =
{
	Id = 14424451,
	CharName = "旁白喇叭",
	Text = "经过一番教育，小厨娘终于可以换上泳装，跳进温泉里。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	RightIcon = "EventItem_RPG_Event_8",
	NextID = 14424452,
}
StorySpeechConfig[StorySpeechID.Id14424452] =
{
	Id = 14424452,
	CharName = "温泉鉴赏家",
	Text = "（脸红）老板，我，我也想……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_26_WenQuanJianShanJia",
	NextID = 14424453,
}
StorySpeechConfig[StorySpeechID.Id14424453] =
{
	Id = 14424453,
	CharName = "猫眼厨娘",
	Text = " 你的惩罚还没结束呢，别想跑。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 14424454,
}
StorySpeechConfig[StorySpeechID.Id14424454] =
{
	Id = 14424454,
	CharName = "温泉鉴赏家",
	Text = "呜……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_26_WenQuanJianShanJia",
	NextID = 14424455,
}
StorySpeechConfig[StorySpeechID.Id14424455] =
{
	Id = 14424455,
	CharName = "猫眼厨娘",
	Text = "回去写15000字思想报告，明天交给我。还有藏起来的20玉璧私房钱，必须上交。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 14424456,
}
StorySpeechConfig[StorySpeechID.Id14424456] =
{
	Id = 14424456,
	CharName = "温泉鉴赏家",
	Text = "你什么时候知……呜！失败了！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_26_WenQuanJianShanJia",
}
StorySpeechConfig[StorySpeechID.Id14424501] =
{
	Id = 14424501,
	CharName = "温泉鉴赏家",
	Text = "（打电话）你发来的文档我已经看了，颗粒度还是不够细。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_26_WenQuanJianShanJia",
	NextID = 14424502,
}
StorySpeechConfig[StorySpeechID.Id14424502] =
{
	Id = 14424502,
	CharName = "温泉鉴赏家",
	Text = "（打电话）大方向没什么问题，主要还是缺少引爆点，所以下一篇文章，不能只着眼于痛点，还得在用户的爽点和痒点上寻求突破。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_26_WenQuanJianShanJia",
	NextID = 14424503,
}
StorySpeechConfig[StorySpeechID.Id14424503] =
{
	Id = 14424503,
	CharName = "温泉鉴赏家",
	Text = "（打电话）对，还要打造新媒体矩阵……我到家了，明早再对齐一下吧。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_26_WenQuanJianShanJia",
	NextID = 14424504,
}
StorySpeechConfig[StorySpeechID.Id14424504] =
{
	Id = 14424504,
	CharName = "温泉鉴赏家",
	Text = "（敲门）小厨娘~我回来啦？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_26_WenQuanJianShanJia",
	NextID = 14424505,
}
StorySpeechConfig[StorySpeechID.Id14424505] =
{
	Id = 14424505,
	CharName = "温泉鉴赏家",
	Text = "hello？有人在吗？（四处找）钥匙呢？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_26_WenQuanJianShanJia",
	NextID = 14424506,
}
StorySpeechConfig[StorySpeechID.Id14424506] =
{
	Id = 14424506,
	CharName = "温泉鉴赏家",
	Text = "有没有人帮帮我，给我开开门QAQ",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_26_WenQuanJianShanJia",
	NextID = 14424507,
}
StorySpeechConfig[StorySpeechID.Id14424507] =
{
	Id = 14424507,
	CharName = "旁白喇叭",
	Text = "二十分钟后。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	RightIcon = "EventItem_RPG_Event_8",
	NextID = 14424508,
}
StorySpeechConfig[StorySpeechID.Id14424508] =
{
	Id = 14424508,
	CharName = "温泉鉴赏家",
	Text = "阿、阿嚏——好，好冷啊——",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_26_WenQuanJianShanJia",
	NextID = 14424509,
}
StorySpeechConfig[StorySpeechID.Id14424509] =
{
	Id = 14424509,
	CharName = "冰冰杆",
	Text = "（扭）可怜的人啊，人都是孤独的，就让我们一起抱团取暖吧。",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "All_BingBingGang",
	NextID = 14424510,
}
StorySpeechConfig[StorySpeechID.Id14424510] =
{
	Id = 14424510,
	CharName = "温泉鉴赏家",
	Text = "不，你走开——！！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_26_WenQuanJianShanJia",
}
StorySpeechConfig[StorySpeechID.Id14424551] =
{
	Id = 14424551,
	CharName = "温泉鉴赏家",
	Text = "好、@#￥%……冷。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_26_WenQuanJianShanJia",
	NextID = 14424552,
}
StorySpeechConfig[StorySpeechID.Id14424552] =
{
	Id = 14424552,
	CharName = "冰冰杆",
	Text = "哦！你有一颗火热的心！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "All_BingBingGang",
	NextID = 14424553,
}
StorySpeechConfig[StorySpeechID.Id14424553] =
{
	Id = 14424553,
	CharName = "温泉鉴赏家",
	Text = "可现在，我的心是……冰冰的。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_26_WenQuanJianShanJia",
	NextID = 14424554,
}
StorySpeechConfig[StorySpeechID.Id14424554] =
{
	Id = 14424554,
	CharName = "冰冰杆",
	Text = "（欣喜）真的吗？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "All_BingBingGang",
}
StorySpeechConfig[StorySpeechID.Id14424601] =
{
	Id = 14424601,
	CharName = "健身教练",
	Text = "儿子，俗话说得对，锻炼要从娃娃抓起，而这就是我总把你带在身边的原因。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 14424602,
}
StorySpeechConfig[StorySpeechID.Id14424602] =
{
	Id = 14424602,
	CharName = "教练的儿子",
	Text = "爸爸爸爸，为什么让我坐在大杠铃上啊？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_boy1",
	NextID = 14424603,
}
StorySpeechConfig[StorySpeechID.Id14424603] =
{
	Id = 14424603,
	CharName = "健身教练",
	Text = "哦，这是为了锻炼你的臀肌！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 14424604,
}
StorySpeechConfig[StorySpeechID.Id14424604] =
{
	Id = 14424604,
	CharName = "教练的儿子",
	Text = "爸爸爸爸，为什么我的衣服那么少啊？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_boy1",
	NextID = 14424605,
}
StorySpeechConfig[StorySpeechID.Id14424605] =
{
	Id = 14424605,
	CharName = "健身教练",
	Text = "哦，这是为了锻炼你的忍耐力！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 14424606,
}
StorySpeechConfig[StorySpeechID.Id14424606] =
{
	Id = 14424606,
	CharName = "教练的儿子",
	Text = "爸爸爸爸，为什么你的旁边有一个肥皂啊？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	RightIcon = "NPC_boy1",
	NextID = 14424607,
}
StorySpeechConfig[StorySpeechID.Id14424607] =
{
	Id = 14424607,
	CharName = "健身教练",
	Text = "哦，这是为了锻炼捡肥皂的特殊技巧……什么？肥皂！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_27_JianShenJiaoLian",
}
StorySpeechConfig[StorySpeechID.Id14424651] =
{
	Id = 14424651,
	CharName = "旁白喇叭",
	Text = "赶走了让他摔倒的硫磺皂后，健身教练给自己穿上衣服，准备出门进行雪地马拉松。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	RightIcon = "EventItem_RPG_Event_8",
	NextID = 14424652,
}
StorySpeechConfig[StorySpeechID.Id14424652] =
{
	Id = 14424652,
	CharName = "教练的儿子",
	Text = "爸爸爸爸，为什么你穿上了衣服啊？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_boy1",
	NextID = 14424653,
}
StorySpeechConfig[StorySpeechID.Id14424653] =
{
	Id = 14424653,
	CharName = "健身教练",
	Text = "哦，因为我们要上山，山上很冷。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 14424654,
}
StorySpeechConfig[StorySpeechID.Id14424654] =
{
	Id = 14424654,
	CharName = "教练的儿子",
	Text = "爸爸爸爸，为什么我没有裤子啊？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_boy1",
	NextID = 14424655,
}
StorySpeechConfig[StorySpeechID.Id14424655] =
{
	Id = 14424655,
	CharName = "健身教练",
	Text = "哦，因为……啊！你的裤子！我忘带了！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_27_JianShenJiaoLian",
}
StorySpeechConfig[StorySpeechID.Id14424701] =
{
	Id = 14424701,
	CharName = "猫眼厨娘",
	Text = "亲爱的断耳熊小公主，你喜欢什么颜色的小裙裙呀？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 14424702,
}
StorySpeechConfig[StorySpeechID.Id14424702] =
{
	Id = 14424702,
	CharName = "断耳熊",
	Text = "（呆住）诶？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_28_DuanErXiong",
	NextID = 14424703,
}
StorySpeechConfig[StorySpeechID.Id14424703] =
{
	Id = 14424703,
	CharName = "猫眼厨娘",
	Text = "到冬天了，小公主总不能没有衣服穿，就去外面乱跑吧？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 14424704,
}
StorySpeechConfig[StorySpeechID.Id14424704] =
{
	Id = 14424704,
	CharName = "断耳熊",
	Text = "（点头）嗯嗯！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_28_DuanErXiong",
	NextID = 14424705,
}
StorySpeechConfig[StorySpeechID.Id14424705] =
{
	Id = 14424705,
	CharName = "猫眼厨娘",
	Text = "我自作主张，给你做了一件暖和的小裙子，你一定要穿哦~",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 14424706,
}
StorySpeechConfig[StorySpeechID.Id14424706] =
{
	Id = 14424706,
	CharName = "猫眼厨娘",
	Text = "（拿出礼物）宝贝？你看这件橘色的衣服，喜不喜欢？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 14424707,
}
StorySpeechConfig[StorySpeechID.Id14424707] =
{
	Id = 14424707,
	CharName = "断耳熊",
	Text = "（接过衣服）暖和？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_28_DuanErXiong",
	NextID = 14424708,
}
StorySpeechConfig[StorySpeechID.Id14424708] =
{
	Id = 14424708,
	CharName = "猫眼厨娘",
	Text = "嗯，这种颜色在冬天里，显得很暖和吧？要不要试穿一下？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 14424709,
}
StorySpeechConfig[StorySpeechID.Id14424709] =
{
	Id = 14424709,
	CharName = "断耳熊",
	Text = "（套上衣服）痛痛！！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_28_DuanErXiong",
	NextID = 14424710,
}
StorySpeechConfig[StorySpeechID.Id14424710] =
{
	Id = 14424710,
	CharName = "猫眼厨娘",
	Text = "怎么……哎呀！怎么把针线留在裙子里了！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
}
StorySpeechConfig[StorySpeechID.Id14424751] =
{
	Id = 14424751,
	CharName = "旁白喇叭",
	Text = "打败针不戳后，断耳熊顺利穿上了新衣服。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	RightIcon = "EventItem_RPG_Event_8",
	NextID = 14424752,
}
StorySpeechConfig[StorySpeechID.Id14424752] =
{
	Id = 14424752,
	CharName = "猫眼厨娘",
	Text = "真好看~再戴上这个蝴蝶结就更可爱啦。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 14424753,
}
StorySpeechConfig[StorySpeechID.Id14424753] =
{
	Id = 14424753,
	CharName = "断耳熊",
	Text = "（照镜子）嘿嘿！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_28_DuanErXiong",
	NextID = 14424754,
}
StorySpeechConfig[StorySpeechID.Id14424754] =
{
	Id = 14424754,
	CharName = "猫眼厨娘",
	Text = "（打量）真好看呀真好看~给这件衣服取个名字吧，它就是只属于你的东西啦。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 14424755,
}
StorySpeechConfig[StorySpeechID.Id14424755] =
{
	Id = 14424755,
	CharName = "断耳熊",
	Text = "（思考）熊熊……熊熊燃烧！嗷！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_28_DuanErXiong",
}
StorySpeechConfig[StorySpeechID.Id14424801] =
{
	Id = 14424801,
	CharName = "雪中猎人",
	Text = "最后一次，准备好了么？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_29_XueZhongLieRen",
	NextID = 14424802,
}
StorySpeechConfig[StorySpeechID.Id14424802] =
{
	Id = 14424802,
	CharName = "雪中猎人",
	Text = "我也想不到，事情发展到这个地步。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_29_XueZhongLieRen",
	NextID = 14424803,
}
StorySpeechConfig[StorySpeechID.Id14424803] =
{
	Id = 14424803,
	CharName = "雪中猎人",
	Text = "老实说，我根本没有心理准备，去面对接下来要发生的事。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_29_XueZhongLieRen",
	NextID = 14424804,
}
StorySpeechConfig[StorySpeechID.Id14424804] =
{
	Id = 14424804,
	CharName = "雪中猎人",
	Text = "可是、可是……（羞耻地脱下外套）",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_29_XueZhongLieRen",
	NextID = 14424805,
}
StorySpeechConfig[StorySpeechID.Id14424805] =
{
	Id = 14424805,
	CharName = "药剂包",
	Text = "差不多得了，大哥，就要你脱个衣服，下去泡温泉，至于吗？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "All_YaoJiBao",
	NextID = 14424806,
}
StorySpeechConfig[StorySpeechID.Id14424806] =
{
	Id = 14424806,
	CharName = "药剂包",
	Text = "我看你把手放腰带上好几次了，就是不脱。怎么，腰上长钉子了？",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "All_YaoJiBao",
	NextID = 14424807,
}
StorySpeechConfig[StorySpeechID.Id14424807] =
{
	Id = 14424807,
	CharName = "雪中猎人",
	Text = "（羞耻）唔！怎么会有人！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_29_XueZhongLieRen",
	NextID = 14424808,
}
StorySpeechConfig[StorySpeechID.Id14424808] =
{
	Id = 14424808,
	CharName = "药剂包",
	Text = "你脸红个泡泡茶壶啊！！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "All_YaoJiBao",
	NextID = 14424809,
}
StorySpeechConfig[StorySpeechID.Id14424809] =
{
	Id = 14424809,
	CharName = "雪中猎人",
	Text = "你在哪里？为什么我看不到？还是说，这只是我的幻听？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_29_XueZhongLieRen",
	NextID = 14424810,
}
StorySpeechConfig[StorySpeechID.Id14424810] =
{
	Id = 14424810,
	CharName = "药剂包",
	Text = "……你脱不脱？不脱就回去，别泡了。（盯）",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "All_YaoJiBao",
	NextID = 14424811,
}
StorySpeechConfig[StorySpeechID.Id14424811] =
{
	Id = 14424811,
	CharName = "雪中猎人",
	Text = "我看到你了，渺小的药剂包！你竟然一直在暗中看着我。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_29_XueZhongLieRen",
	NextID = 14424812,
}
StorySpeechConfig[StorySpeechID.Id14424812] =
{
	Id = 14424812,
	CharName = "雪中猎人",
	Text = "不，绝不能让你看到我……脱衣服的样子！！！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_29_XueZhongLieRen",
	NextID = 14424813,
}
StorySpeechConfig[StorySpeechID.Id14424813] =
{
	Id = 14424813,
	CharName = "药剂包",
	Text = "啊——！",
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	RightIcon = "All_YaoJiBao",
}
StorySpeechConfig[StorySpeechID.Id14424851] =
{
	Id = 14424851,
	CharName = "雪中猎人",
	Text = "嗯，我准备好了。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_29_XueZhongLieRen",
	NextID = 14424852,
}
StorySpeechConfig[StorySpeechID.Id14424852] =
{
	Id = 14424852,
	CharName = "雪中猎人",
	Text = "现在，只要等到无人在意时，如离弦之箭一般冲入汤池，就算完成了吧？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_29_XueZhongLieRen",
	NextID = 14424853,
}
StorySpeechConfig[StorySpeechID.Id14424853] =
{
	Id = 14424853,
	CharName = "雪中猎人",
	Text = "三、二、一，冲刺——\n啊！！！！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_29_XueZhongLieRen",
	NextID = 14424854,
}
StorySpeechConfig[StorySpeechID.Id14424854] =
{
	Id = 14424854,
	CharName = "旁白喇叭",
	Text = "很不幸，光着身体的雪中猎人，一个不小心摔在了温泉边的石头上。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	RightIcon = "EventItem_RPG_Event_8",
}
StorySpeechConfig[StorySpeechID.Id14424901] =
{
	Id = 14424901,
	CharName = "编剧妹子",
	Text = "（看月）你脸色为何如此苍白？\n莫非倦于攀登高空、凝望大地？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_30_BianJuMeiZi",
	NextID = 14424902,
}
StorySpeechConfig[StorySpeechID.Id14424902] =
{
	Id = 14424902,
	CharName = "编剧妹子",
	Text = "你置身在星辰之间，恰似异乡的游子，没有伴侣——",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_30_BianJuMeiZi",
	NextID = 14424903,
}
StorySpeechConfig[StorySpeechID.Id14424903] =
{
	Id = 14424903,
	CharName = "编剧妹子",
	Text = "永远亏盈交替，像一只忧伤的眼睛，寻不到值得长久眷恋的物体？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_30_BianJuMeiZi",
	NextID = 14424904,
}
StorySpeechConfig[StorySpeechID.Id14424904] =
{
	Id = 14424904,
	CharName = "编剧妹子",
	Text = "不，我不该只看着它，还有星空，还有飘雪，我的创作之源，我的灵感之光。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_30_BianJuMeiZi",
	NextID = 14424905,
}
StorySpeechConfig[StorySpeechID.Id14424905] =
{
	Id = 14424905,
	CharName = "思诺曼",
	Text = "（歪头）已经很晚了，你不回去吗？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_31_SiNuoMan",
	NextID = 14424906,
}
StorySpeechConfig[StorySpeechID.Id14424906] =
{
	Id = 14424906,
	CharName = "编剧妹子",
	Text = "是啊，已经很晚了，哦，你是在这里的雪人吗？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_30_BianJuMeiZi",
	NextID = 14424907,
}
StorySpeechConfig[StorySpeechID.Id14424907] =
{
	Id = 14424907,
	CharName = "思诺曼",
	Text = "（盯）",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_31_SiNuoMan",
	NextID = 14424908,
}
StorySpeechConfig[StorySpeechID.Id14424908] =
{
	Id = 14424908,
	CharName = "编剧妹子",
	Text = "雪一般的外衣，雪下捧着花的少女……啊，我有灵感了！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_30_BianJuMeiZi",
	NextID = 14424909,
}
StorySpeechConfig[StorySpeechID.Id14424909] =
{
	Id = 14424909,
	CharName = "思诺曼",
	Text = "？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_31_SiNuoMan",
	NextID = 14424910,
}
StorySpeechConfig[StorySpeechID.Id14424910] =
{
	Id = 14424910,
	CharName = "编剧妹子",
	Text = "感谢您，给予我更多的灵感之光吧！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_30_BianJuMeiZi",
	NextID = 14424911,
}
StorySpeechConfig[StorySpeechID.Id14424911] =
{
	Id = 14424911,
	CharName = "思诺曼",
	Text = "你、你不要过来啊——！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_31_SiNuoMan",
}
StorySpeechConfig[StorySpeechID.Id14424951] =
{
	Id = 14424951,
	CharName = "编剧妹子",
	Text = "啊！不要指着月亮起誓，它的变化是无常的，每个月都有盈亏圆缺。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_30_BianJuMeiZi",
	NextID = 14424952,
}
StorySpeechConfig[StorySpeechID.Id14424952] =
{
	Id = 14424952,
	CharName = "编剧妹子",
	Text = "你要是指着它起誓，也许你的爱情也会像它一样无常。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_30_BianJuMeiZi",
	NextID = 14424953,
}
StorySpeechConfig[StorySpeechID.Id14424953] =
{
	Id = 14424953,
	CharName = "编剧妹子",
	Text = "如美丽的朱丽叶一样，她捧着白花，走到雪与月光下——",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_30_BianJuMeiZi",
	NextID = 14424954,
}
StorySpeechConfig[StorySpeechID.Id14424954] =
{
	Id = 14424954,
	CharName = "编剧妹子",
	Text = "谢谢你，我知道接下来该怎么写了！我要回去码字了！（亲）",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_30_BianJuMeiZi",
	NextID = 14424955,
}
StorySpeechConfig[StorySpeechID.Id14424955] =
{
	Id = 14424955,
	CharName = "思诺曼",
	Text = "（脸红）……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_31_SiNuoMan",
}
StorySpeechConfig[StorySpeechID.Id14425001] =
{
	Id = 14425001,
	CharName = "旁白喇叭",
	Text = "别墅内。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "EventItem_RPG_Event_8",
	NextID = 14425002,
}
StorySpeechConfig[StorySpeechID.Id14425002] =
{
	Id = 14425002,
	CharName = "猫眼厨娘",
	Text = "呀！你的小宝宝真可爱！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 14425003,
}
StorySpeechConfig[StorySpeechID.Id14425003] =
{
	Id = 14425003,
	CharName = "健身教练",
	Text = "哼，他未来会是一等一的猛男。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 14425004,
}
StorySpeechConfig[StorySpeechID.Id14425004] =
{
	Id = 14425004,
	CharName = "温泉鉴赏家",
	Text = "就像我一样么？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_26_WenQuanJianShanJia",
	NextID = 14425005,
}
StorySpeechConfig[StorySpeechID.Id14425005] =
{
	Id = 14425005,
	CharName = "教练的儿子",
	Text = "（委屈）爸爸，以后我也会变成200斤的胖子吗？",
	IconBundle = "atlas_charactericon_npc",
	IconAtlas = "NPC",
	LeftIcon = "NPC_boy1",
	NextID = 14425006,
}
StorySpeechConfig[StorySpeechID.Id14425006] =
{
	Id = 14425006,
	CharName = "健身教练",
	Text = "绝对不会！！！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_27_JianShenJiaoLian",
	NextID = 14425007,
}
StorySpeechConfig[StorySpeechID.Id14425007] =
{
	Id = 14425007,
	CharName = "温泉鉴赏家",
	Text = "……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_26_WenQuanJianShanJia",
	NextID = 14425008,
}
StorySpeechConfig[StorySpeechID.Id14425008] =
{
	Id = 14425008,
	CharName = "猫眼厨娘",
	Text = "哈哈哈哈！他也没有那么胖啦……",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_25_MaoYanChuNiang",
	NextID = 14425009,
}
StorySpeechConfig[StorySpeechID.Id14425009] =
{
	Id = 14425009,
	CharName = "旁白喇叭",
	Text = "别墅外。",
	IconBundle = "atlas_goods",
	IconAtlas = "Goods",
	LeftIcon = "EventItem_RPG_Event_8",
	NextID = 14425010,
}
StorySpeechConfig[StorySpeechID.Id14425010] =
{
	Id = 14425010,
	CharName = "小火球",
	Text = "嘿！你怎么不进去啊？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_Fireball",
	NextID = 14425011,
}
StorySpeechConfig[StorySpeechID.Id14425011] =
{
	Id = 14425011,
	CharName = "思诺曼",
	Text = "……我不想进去。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_31_SiNuoMan",
	NextID = 14425012,
}
StorySpeechConfig[StorySpeechID.Id14425012] =
{
	Id = 14425012,
	CharName = "小火球",
	Text = "哼，我看才不是，你其实很想和他们玩，但一进去就会融化，对吧？",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_Fireball",
	NextID = 14425013,
}
StorySpeechConfig[StorySpeechID.Id14425013] =
{
	Id = 14425013,
	CharName = "思诺曼",
	Text = "就你长了嘴。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_31_SiNuoMan",
	NextID = 14425014,
}
StorySpeechConfig[StorySpeechID.Id14425014] =
{
	Id = 14425014,
	CharName = "小火球",
	Text = "哼，这么难相处，难怪没有朋友陪你。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_Fireball",
	NextID = 14425015,
}
StorySpeechConfig[StorySpeechID.Id14425015] =
{
	Id = 14425015,
	CharName = "思诺曼",
	Text = "你说什么呢！（怒）",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_31_SiNuoMan",
}
StorySpeechConfig[StorySpeechID.Id14425051] =
{
	Id = 14425051,
	CharName = "小火球",
	Text = "好了好了，别打了——！我是来给某人带路的。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_Fireball",
	NextID = 14425052,
}
StorySpeechConfig[StorySpeechID.Id14425052] =
{
	Id = 14425052,
	CharName = "思诺曼",
	Text = "诶？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_31_SiNuoMan",
	NextID = 14425053,
}
StorySpeechConfig[StorySpeechID.Id14425053] =
{
	Id = 14425053,
	CharName = "小火球",
	Text = "有个人说想要出来看看，让我帮忙照亮一下外面的路。\n（回头）喂！你好慢啊。",
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	RightIcon = "RPG_Fireball",
	NextID = 14425054,
}
StorySpeechConfig[StorySpeechID.Id14425054] =
{
	Id = 14425054,
	CharName = "断耳熊",
	Text = "（跑）来了！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_28_DuanErXiong",
	NextID = 14425055,
}
StorySpeechConfig[StorySpeechID.Id14425055] =
{
	Id = 14425055,
	CharName = "思诺曼",
	Text = "……熊熊？",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_31_SiNuoMan",
	NextID = 14425056,
}
StorySpeechConfig[StorySpeechID.Id14425056] =
{
	Id = 14425056,
	CharName = "断耳熊",
	Text = "（抱住）一起玩。",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	LeftIcon = "SPBUS_28_DuanErXiong",
	NextID = 14425057,
}
StorySpeechConfig[StorySpeechID.Id14425057] =
{
	Id = 14425057,
	CharName = "思诺曼",
	Text = "……好！我们一起玩！",
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	RightIcon = "SPBUS_31_SiNuoMan",
}
