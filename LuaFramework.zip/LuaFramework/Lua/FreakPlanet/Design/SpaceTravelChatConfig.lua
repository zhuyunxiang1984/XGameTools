SpaceTravelChatConfig ={};
SpaceTravelChatID = 
{
	Id001 = 840001,
	Id002 = 840002,
	Id003 = 840003,
	Id004 = 840004,
	Id005 = 840005,
	Id006 = 840006,
	Id007 = 840007,
	Id008 = 840008,
	Id009 = 840009,
	Id010 = 840010,
	Id011 = 840011,
	Id012 = 840012,
	Id013 = 840013,
	Id014 = 840014,
	Id015 = 840015,
	Id016 = 840016,
	Id017 = 840017,
	Id018 = 840018,
	Id019 = 840019,
	Id020 = 840020,
	Id021 = 840021,
	Id022 = 840022,
	Id023 = 840023,
	Id024 = 840024,
	Id025 = 840025,
	Id026 = 840026,
	Id027 = 840027,
	Id028 = 840028,
	Id029 = 840029,
	Id030 = 840030,
	Id031 = 840031,
	Id032 = 840032,
	Id033 = 840033,
	Id034 = 840034,
	Id035 = 840035,
	Id036 = 840036,
	Id037 = 840037,
	Id038 = 840038,
	Id039 = 840039,
	Id040 = 840040,
	Id041 = 840041,
	Id042 = 840042,
	Id043 = 840043,
	Id044 = 840044,
	Id045 = 840045,
	Id046 = 840046,
	Id047 = 840047,
	Id048 = 840048,
	Id049 = 840049,
	Id050 = 840050,
	Id051 = 840051,
	Id052 = 840052,
	Id053 = 840053,
	Id054 = 840054,
	Id055 = 840055,
	Id056 = 840056,
	Id057 = 840057,
	Id058 = 840058,
	Id059 = 840059,
	Id060 = 840060,
	Id061 = 840061,
	Id062 = 840062,
	Id063 = 840063,
	Id064 = 840064,
	Id065 = 840065,
	Id066 = 840066,
	Id067 = 840067,
	Id068 = 840068,
	Id069 = 840069,
	Id070 = 840070,
	Id071 = 840071,
	Id072 = 840072,
	Id073 = 840073,
	Id074 = 840074,
	Id075 = 840075,
	Id076 = 840076,
	Id077 = 840077,
	Id078 = 840078,
	Id079 = 840079,
	Id080 = 840080,
	Id081 = 840081,
	Id082 = 840082,
	Id083 = 840083,
	Id084 = 840084,
	Id085 = 840085,
	Id086 = 840086,
	Id087 = 840087,
	Id088 = 840088,
	Id089 = 840089,
	Id090 = 840090,
	Id091 = 840091,
	Id092 = 840092,
	Id093 = 840093,
	Id094 = 840094,
	Id095 = 840095,
	Id096 = 840096,
	Id097 = 840097,
	Id098 = 840098,
	Id099 = 840099,
	Id100 = 840100,
	Id101 = 840101,
	Id102 = 840102,
	Id103 = 840103,
	Id104 = 840104,
	Id105 = 840105,
	Id106 = 840106,
	Id107 = 840107,
	Id108 = 840108,
	Id109 = 840109,
	Id110 = 840110,
	Id111 = 840111,
	Id112 = 840112,
	Id113 = 840113,
	Id114 = 840114,
	Id115 = 840115,
	Id116 = 840116,
	Id117 = 840117,
	Id118 = 840118,
	Id119 = 840119,
	Id120 = 840120,
	Id121 = 840121,
	Id122 = 840122,
	Id123 = 840123,
	Id124 = 840124,
	Id125 = 840125,
	Id126 = 840126,
	Id127 = 840127,
	Id128 = 840128,
	Id129 = 840129,
	Id130 = 840130,
	Id131 = 840131,
	Id132 = 840132,
	Id133 = 840133,
	Id134 = 840134,
	Id135 = 840135,
	Id136 = 840136,
	Id137 = 840137,
	Id138 = 840138,
	Id139 = 840139,
	Id140 = 840140,
	Id141 = 840141,
	Id142 = 840142,
	Id143 = 840143,
	Id144 = 840144,
	Id145 = 840145,
	Id146 = 840146,
	Id147 = 840147,
	Id148 = 840148,
	Id149 = 840149,
	Id150 = 840150,
	Id151 = 840151,
	Id152 = 840152,
	Id153 = 840153,
	Id154 = 840154,
	Id155 = 840155,
	Id156 = 840156,
	Id157 = 840157,
	Id158 = 840158,
	Id159 = 840159,
	Id160 = 840160,
	Id161 = 840161,
	Id162 = 840162,
	Id163 = 840163,
	Id164 = 840164,
	Id165 = 840165,
	Id166 = 840166,
	Id167 = 840167,
	Id168 = 840168,
	Id169 = 840169,
	Id170 = 840170,
	Id171 = 840171,
	Id172 = 840172,
	Id173 = 840173,
	Id174 = 840174,
	Id175 = 840175,
	Id176 = 840176,
	Id177 = 840177,
	Id178 = 840178,
	Id179 = 840179,
	Id180 = 840180,
}
SpaceTravelChatConfig[SpaceTravelChatID.Id001] =
{
	Id = 1,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248101,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 856,
				},
				 {
					Value = 200005,
					Num = 705,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 761,
				},
				 {
					Value = 200005,
					Num = 627,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 666,
				},
				 {
					Value = 200005,
					Num = 548,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 571,
				},
				 {
					Value = 200005,
					Num = 470,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 476,
				},
				 {
					Value = 200005,
					Num = 392,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 380,
				},
				 {
					Value = 200005,
					Num = 313,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 285,
				},
				 {
					Value = 200005,
					Num = 235,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 190,
				},
				 {
					Value = 200005,
					Num = 156,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 95,
				},
				 {
					Value = 200005,
					Num = 78,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200005,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id002] =
{
	Id = 2,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248111,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 856,
				},
				 {
					Value = 200007,
					Num = 705,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 761,
				},
				 {
					Value = 200007,
					Num = 627,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 666,
				},
				 {
					Value = 200007,
					Num = 548,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 571,
				},
				 {
					Value = 200007,
					Num = 470,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 476,
				},
				 {
					Value = 200007,
					Num = 392,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 380,
				},
				 {
					Value = 200007,
					Num = 313,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 285,
				},
				 {
					Value = 200007,
					Num = 235,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 190,
				},
				 {
					Value = 200007,
					Num = 156,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 95,
				},
				 {
					Value = 200007,
					Num = 78,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id003] =
{
	Id = 3,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248121,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 856,
				},
				 {
					Value = 200008,
					Num = 705,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 761,
				},
				 {
					Value = 200008,
					Num = 627,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 666,
				},
				 {
					Value = 200008,
					Num = 548,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 571,
				},
				 {
					Value = 200008,
					Num = 470,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 476,
				},
				 {
					Value = 200008,
					Num = 392,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 380,
				},
				 {
					Value = 200008,
					Num = 313,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 285,
				},
				 {
					Value = 200008,
					Num = 235,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 190,
				},
				 {
					Value = 200008,
					Num = 156,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 95,
				},
				 {
					Value = 200008,
					Num = 78,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id004] =
{
	Id = 4,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248131,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 856,
				},
				 {
					Value = 200007,
					Num = 705,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 761,
				},
				 {
					Value = 200007,
					Num = 627,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 666,
				},
				 {
					Value = 200007,
					Num = 548,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 571,
				},
				 {
					Value = 200007,
					Num = 470,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 476,
				},
				 {
					Value = 200007,
					Num = 392,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 380,
				},
				 {
					Value = 200007,
					Num = 313,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 285,
				},
				 {
					Value = 200007,
					Num = 235,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 190,
				},
				 {
					Value = 200007,
					Num = 156,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 95,
				},
				 {
					Value = 200007,
					Num = 78,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id005] =
{
	Id = 5,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248141,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 856,
				},
				 {
					Value = 200008,
					Num = 705,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 761,
				},
				 {
					Value = 200008,
					Num = 627,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 666,
				},
				 {
					Value = 200008,
					Num = 548,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 571,
				},
				 {
					Value = 200008,
					Num = 470,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 476,
				},
				 {
					Value = 200008,
					Num = 392,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 380,
				},
				 {
					Value = 200008,
					Num = 313,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 285,
				},
				 {
					Value = 200008,
					Num = 235,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 190,
				},
				 {
					Value = 200008,
					Num = 156,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 95,
				},
				 {
					Value = 200008,
					Num = 78,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id006] =
{
	Id = 6,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248101,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 856,
				},
				 {
					Value = 200008,
					Num = 705,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 761,
				},
				 {
					Value = 200008,
					Num = 627,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 666,
				},
				 {
					Value = 200008,
					Num = 548,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 571,
				},
				 {
					Value = 200008,
					Num = 470,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 476,
				},
				 {
					Value = 200008,
					Num = 392,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 380,
				},
				 {
					Value = 200008,
					Num = 313,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 285,
				},
				 {
					Value = 200008,
					Num = 235,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 190,
				},
				 {
					Value = 200008,
					Num = 156,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 95,
				},
				 {
					Value = 200008,
					Num = 78,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id007] =
{
	Id = 7,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248102,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1101,
				},
				 {
					Value = 200005,
					Num = 907,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 979,
				},
				 {
					Value = 200005,
					Num = 806,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 856,
				},
				 {
					Value = 200005,
					Num = 705,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 734,
				},
				 {
					Value = 200005,
					Num = 604,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 612,
				},
				 {
					Value = 200005,
					Num = 504,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 489,
				},
				 {
					Value = 200005,
					Num = 403,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 367,
				},
				 {
					Value = 200005,
					Num = 302,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 244,
				},
				 {
					Value = 200005,
					Num = 201,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 122,
				},
				 {
					Value = 200005,
					Num = 100,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200005,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id008] =
{
	Id = 8,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248112,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1101,
				},
				 {
					Value = 200007,
					Num = 907,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 979,
				},
				 {
					Value = 200007,
					Num = 806,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 856,
				},
				 {
					Value = 200007,
					Num = 705,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 734,
				},
				 {
					Value = 200007,
					Num = 604,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 612,
				},
				 {
					Value = 200007,
					Num = 504,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 489,
				},
				 {
					Value = 200007,
					Num = 403,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 367,
				},
				 {
					Value = 200007,
					Num = 302,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 244,
				},
				 {
					Value = 200007,
					Num = 201,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 122,
				},
				 {
					Value = 200007,
					Num = 100,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id009] =
{
	Id = 9,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248122,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1101,
				},
				 {
					Value = 200008,
					Num = 907,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 979,
				},
				 {
					Value = 200008,
					Num = 806,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 856,
				},
				 {
					Value = 200008,
					Num = 705,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 734,
				},
				 {
					Value = 200008,
					Num = 604,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 612,
				},
				 {
					Value = 200008,
					Num = 504,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 489,
				},
				 {
					Value = 200008,
					Num = 403,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 367,
				},
				 {
					Value = 200008,
					Num = 302,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 244,
				},
				 {
					Value = 200008,
					Num = 201,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 122,
				},
				 {
					Value = 200008,
					Num = 100,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id010] =
{
	Id = 10,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248132,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1101,
				},
				 {
					Value = 200007,
					Num = 907,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 979,
				},
				 {
					Value = 200007,
					Num = 806,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 856,
				},
				 {
					Value = 200007,
					Num = 705,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 734,
				},
				 {
					Value = 200007,
					Num = 604,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 612,
				},
				 {
					Value = 200007,
					Num = 504,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 489,
				},
				 {
					Value = 200007,
					Num = 403,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 367,
				},
				 {
					Value = 200007,
					Num = 302,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 244,
				},
				 {
					Value = 200007,
					Num = 201,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 122,
				},
				 {
					Value = 200007,
					Num = 100,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id011] =
{
	Id = 11,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248142,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1101,
				},
				 {
					Value = 200008,
					Num = 907,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 979,
				},
				 {
					Value = 200008,
					Num = 806,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 856,
				},
				 {
					Value = 200008,
					Num = 705,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 734,
				},
				 {
					Value = 200008,
					Num = 604,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 612,
				},
				 {
					Value = 200008,
					Num = 504,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 489,
				},
				 {
					Value = 200008,
					Num = 403,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 367,
				},
				 {
					Value = 200008,
					Num = 302,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 244,
				},
				 {
					Value = 200008,
					Num = 201,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 122,
				},
				 {
					Value = 200008,
					Num = 100,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id012] =
{
	Id = 12,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248102,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1101,
				},
				 {
					Value = 200008,
					Num = 907,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 979,
				},
				 {
					Value = 200008,
					Num = 806,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 856,
				},
				 {
					Value = 200008,
					Num = 705,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 734,
				},
				 {
					Value = 200008,
					Num = 604,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 612,
				},
				 {
					Value = 200008,
					Num = 504,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 489,
				},
				 {
					Value = 200008,
					Num = 403,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 367,
				},
				 {
					Value = 200008,
					Num = 302,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 244,
				},
				 {
					Value = 200008,
					Num = 201,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 122,
				},
				 {
					Value = 200008,
					Num = 100,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id013] =
{
	Id = 13,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248103,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1346,
				},
				 {
					Value = 200005,
					Num = 1108,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1196,
				},
				 {
					Value = 200005,
					Num = 985,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1047,
				},
				 {
					Value = 200005,
					Num = 862,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 897,
				},
				 {
					Value = 200005,
					Num = 739,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 748,
				},
				 {
					Value = 200005,
					Num = 616,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 598,
				},
				 {
					Value = 200005,
					Num = 492,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 448,
				},
				 {
					Value = 200005,
					Num = 369,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 299,
				},
				 {
					Value = 200005,
					Num = 246,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 149,
				},
				 {
					Value = 200005,
					Num = 123,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200005,
					Num = -1,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id014] =
{
	Id = 14,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248113,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1346,
				},
				 {
					Value = 200007,
					Num = 1108,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1196,
				},
				 {
					Value = 200007,
					Num = 985,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1047,
				},
				 {
					Value = 200007,
					Num = 862,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 897,
				},
				 {
					Value = 200007,
					Num = 739,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 748,
				},
				 {
					Value = 200007,
					Num = 616,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 598,
				},
				 {
					Value = 200007,
					Num = 492,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 448,
				},
				 {
					Value = 200007,
					Num = 369,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 299,
				},
				 {
					Value = 200007,
					Num = 246,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 149,
				},
				 {
					Value = 200007,
					Num = 123,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = -1,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id015] =
{
	Id = 15,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248123,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1346,
				},
				 {
					Value = 200008,
					Num = 1108,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1196,
				},
				 {
					Value = 200008,
					Num = 985,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1047,
				},
				 {
					Value = 200008,
					Num = 862,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 897,
				},
				 {
					Value = 200008,
					Num = 739,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 748,
				},
				 {
					Value = 200008,
					Num = 616,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 598,
				},
				 {
					Value = 200008,
					Num = 492,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 448,
				},
				 {
					Value = 200008,
					Num = 369,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 299,
				},
				 {
					Value = 200008,
					Num = 246,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 149,
				},
				 {
					Value = 200008,
					Num = 123,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = -1,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id016] =
{
	Id = 16,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248133,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1346,
				},
				 {
					Value = 200007,
					Num = 1108,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1196,
				},
				 {
					Value = 200007,
					Num = 985,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1047,
				},
				 {
					Value = 200007,
					Num = 862,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 897,
				},
				 {
					Value = 200007,
					Num = 739,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 748,
				},
				 {
					Value = 200007,
					Num = 616,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 598,
				},
				 {
					Value = 200007,
					Num = 492,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 448,
				},
				 {
					Value = 200007,
					Num = 369,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 299,
				},
				 {
					Value = 200007,
					Num = 246,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 149,
				},
				 {
					Value = 200007,
					Num = 123,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = -1,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id017] =
{
	Id = 17,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248143,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1346,
				},
				 {
					Value = 200008,
					Num = 1108,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1196,
				},
				 {
					Value = 200008,
					Num = 985,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1047,
				},
				 {
					Value = 200008,
					Num = 862,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 897,
				},
				 {
					Value = 200008,
					Num = 739,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 748,
				},
				 {
					Value = 200008,
					Num = 616,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 598,
				},
				 {
					Value = 200008,
					Num = 492,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 448,
				},
				 {
					Value = 200008,
					Num = 369,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 299,
				},
				 {
					Value = 200008,
					Num = 246,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 149,
				},
				 {
					Value = 200008,
					Num = 123,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = -1,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id018] =
{
	Id = 18,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248103,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1346,
				},
				 {
					Value = 200008,
					Num = 1108,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1196,
				},
				 {
					Value = 200008,
					Num = 985,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1047,
				},
				 {
					Value = 200008,
					Num = 862,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 897,
				},
				 {
					Value = 200008,
					Num = 739,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 748,
				},
				 {
					Value = 200008,
					Num = 616,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 598,
				},
				 {
					Value = 200008,
					Num = 492,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 448,
				},
				 {
					Value = 200008,
					Num = 369,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 299,
				},
				 {
					Value = 200008,
					Num = 246,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 149,
				},
				 {
					Value = 200008,
					Num = 123,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = -1,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id019] =
{
	Id = 19,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248104,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1591,
				},
				 {
					Value = 200005,
					Num = 1310,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1414,
				},
				 {
					Value = 200005,
					Num = 1164,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1237,
				},
				 {
					Value = 200005,
					Num = 1019,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1060,
				},
				 {
					Value = 200005,
					Num = 873,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 884,
				},
				 {
					Value = 200005,
					Num = 728,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 707,
				},
				 {
					Value = 200005,
					Num = 582,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 530,
				},
				 {
					Value = 200005,
					Num = 436,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 353,
				},
				 {
					Value = 200005,
					Num = 291,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 176,
				},
				 {
					Value = 200005,
					Num = 145,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200005,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id020] =
{
	Id = 20,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248114,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1591,
				},
				 {
					Value = 200007,
					Num = 1310,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1414,
				},
				 {
					Value = 200007,
					Num = 1164,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1237,
				},
				 {
					Value = 200007,
					Num = 1019,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1060,
				},
				 {
					Value = 200007,
					Num = 873,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 884,
				},
				 {
					Value = 200007,
					Num = 728,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 707,
				},
				 {
					Value = 200007,
					Num = 582,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 530,
				},
				 {
					Value = 200007,
					Num = 436,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 353,
				},
				 {
					Value = 200007,
					Num = 291,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 176,
				},
				 {
					Value = 200007,
					Num = 145,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id021] =
{
	Id = 21,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248124,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1591,
				},
				 {
					Value = 200008,
					Num = 1310,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1414,
				},
				 {
					Value = 200008,
					Num = 1164,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1237,
				},
				 {
					Value = 200008,
					Num = 1019,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1060,
				},
				 {
					Value = 200008,
					Num = 873,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 884,
				},
				 {
					Value = 200008,
					Num = 728,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 707,
				},
				 {
					Value = 200008,
					Num = 582,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 530,
				},
				 {
					Value = 200008,
					Num = 436,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 353,
				},
				 {
					Value = 200008,
					Num = 291,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 176,
				},
				 {
					Value = 200008,
					Num = 145,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id022] =
{
	Id = 22,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248134,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1591,
				},
				 {
					Value = 200007,
					Num = 1310,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1414,
				},
				 {
					Value = 200007,
					Num = 1164,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1237,
				},
				 {
					Value = 200007,
					Num = 1019,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1060,
				},
				 {
					Value = 200007,
					Num = 873,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 884,
				},
				 {
					Value = 200007,
					Num = 728,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 707,
				},
				 {
					Value = 200007,
					Num = 582,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 530,
				},
				 {
					Value = 200007,
					Num = 436,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 353,
				},
				 {
					Value = 200007,
					Num = 291,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 176,
				},
				 {
					Value = 200007,
					Num = 145,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id023] =
{
	Id = 23,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248144,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1591,
				},
				 {
					Value = 200008,
					Num = 1310,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1414,
				},
				 {
					Value = 200008,
					Num = 1164,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1237,
				},
				 {
					Value = 200008,
					Num = 1019,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1060,
				},
				 {
					Value = 200008,
					Num = 873,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 884,
				},
				 {
					Value = 200008,
					Num = 728,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 707,
				},
				 {
					Value = 200008,
					Num = 582,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 530,
				},
				 {
					Value = 200008,
					Num = 436,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 353,
				},
				 {
					Value = 200008,
					Num = 291,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 176,
				},
				 {
					Value = 200008,
					Num = 145,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id024] =
{
	Id = 24,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248104,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1591,
				},
				 {
					Value = 200008,
					Num = 1310,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1414,
				},
				 {
					Value = 200008,
					Num = 1164,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1237,
				},
				 {
					Value = 200008,
					Num = 1019,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1060,
				},
				 {
					Value = 200008,
					Num = 873,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 884,
				},
				 {
					Value = 200008,
					Num = 728,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 707,
				},
				 {
					Value = 200008,
					Num = 582,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 530,
				},
				 {
					Value = 200008,
					Num = 436,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 353,
				},
				 {
					Value = 200008,
					Num = 291,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 176,
				},
				 {
					Value = 200008,
					Num = 145,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id025] =
{
	Id = 25,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248105,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1836,
				},
				 {
					Value = 200005,
					Num = 1512,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1632,
				},
				 {
					Value = 200005,
					Num = 1344,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1428,
				},
				 {
					Value = 200005,
					Num = 1176,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1224,
				},
				 {
					Value = 200005,
					Num = 1008,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1020,
				},
				 {
					Value = 200005,
					Num = 840,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 816,
				},
				 {
					Value = 200005,
					Num = 672,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 612,
				},
				 {
					Value = 200005,
					Num = 504,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 408,
				},
				 {
					Value = 200005,
					Num = 336,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 204,
				},
				 {
					Value = 200005,
					Num = 168,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200005,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id026] =
{
	Id = 26,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248115,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1836,
				},
				 {
					Value = 200007,
					Num = 1512,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1632,
				},
				 {
					Value = 200007,
					Num = 1344,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1428,
				},
				 {
					Value = 200007,
					Num = 1176,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1224,
				},
				 {
					Value = 200007,
					Num = 1008,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1020,
				},
				 {
					Value = 200007,
					Num = 840,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 816,
				},
				 {
					Value = 200007,
					Num = 672,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 612,
				},
				 {
					Value = 200007,
					Num = 504,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 408,
				},
				 {
					Value = 200007,
					Num = 336,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 204,
				},
				 {
					Value = 200007,
					Num = 168,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id027] =
{
	Id = 27,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248125,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1836,
				},
				 {
					Value = 200008,
					Num = 1512,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1632,
				},
				 {
					Value = 200008,
					Num = 1344,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1428,
				},
				 {
					Value = 200008,
					Num = 1176,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1224,
				},
				 {
					Value = 200008,
					Num = 1008,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1020,
				},
				 {
					Value = 200008,
					Num = 840,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 816,
				},
				 {
					Value = 200008,
					Num = 672,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 612,
				},
				 {
					Value = 200008,
					Num = 504,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 408,
				},
				 {
					Value = 200008,
					Num = 336,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 204,
				},
				 {
					Value = 200008,
					Num = 168,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id028] =
{
	Id = 28,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248135,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1836,
				},
				 {
					Value = 200007,
					Num = 1512,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1632,
				},
				 {
					Value = 200007,
					Num = 1344,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1428,
				},
				 {
					Value = 200007,
					Num = 1176,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1224,
				},
				 {
					Value = 200007,
					Num = 1008,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1020,
				},
				 {
					Value = 200007,
					Num = 840,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 816,
				},
				 {
					Value = 200007,
					Num = 672,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 612,
				},
				 {
					Value = 200007,
					Num = 504,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 408,
				},
				 {
					Value = 200007,
					Num = 336,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 204,
				},
				 {
					Value = 200007,
					Num = 168,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id029] =
{
	Id = 29,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248145,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1836,
				},
				 {
					Value = 200008,
					Num = 1512,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1632,
				},
				 {
					Value = 200008,
					Num = 1344,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1428,
				},
				 {
					Value = 200008,
					Num = 1176,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1224,
				},
				 {
					Value = 200008,
					Num = 1008,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1020,
				},
				 {
					Value = 200008,
					Num = 840,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 816,
				},
				 {
					Value = 200008,
					Num = 672,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 612,
				},
				 {
					Value = 200008,
					Num = 504,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 408,
				},
				 {
					Value = 200008,
					Num = 336,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 204,
				},
				 {
					Value = 200008,
					Num = 168,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id030] =
{
	Id = 30,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248105,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1836,
				},
				 {
					Value = 200008,
					Num = 1512,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1632,
				},
				 {
					Value = 200008,
					Num = 1344,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1428,
				},
				 {
					Value = 200008,
					Num = 1176,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1224,
				},
				 {
					Value = 200008,
					Num = 1008,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1020,
				},
				 {
					Value = 200008,
					Num = 840,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 816,
				},
				 {
					Value = 200008,
					Num = 672,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 612,
				},
				 {
					Value = 200008,
					Num = 504,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 408,
				},
				 {
					Value = 200008,
					Num = 336,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 204,
				},
				 {
					Value = 200008,
					Num = 168,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id031] =
{
	Id = 31,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248106,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2080,
				},
				 {
					Value = 200005,
					Num = 1713,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1849,
				},
				 {
					Value = 200005,
					Num = 1523,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1618,
				},
				 {
					Value = 200005,
					Num = 1332,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1387,
				},
				 {
					Value = 200005,
					Num = 1142,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1156,
				},
				 {
					Value = 200005,
					Num = 952,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 924,
				},
				 {
					Value = 200005,
					Num = 761,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 693,
				},
				 {
					Value = 200005,
					Num = 571,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 462,
				},
				 {
					Value = 200005,
					Num = 380,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 231,
				},
				 {
					Value = 200005,
					Num = 190,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200005,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id032] =
{
	Id = 32,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248116,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2080,
				},
				 {
					Value = 200007,
					Num = 1713,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1849,
				},
				 {
					Value = 200007,
					Num = 1523,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1618,
				},
				 {
					Value = 200007,
					Num = 1332,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1387,
				},
				 {
					Value = 200007,
					Num = 1142,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1156,
				},
				 {
					Value = 200007,
					Num = 952,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 924,
				},
				 {
					Value = 200007,
					Num = 761,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 693,
				},
				 {
					Value = 200007,
					Num = 571,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 462,
				},
				 {
					Value = 200007,
					Num = 380,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 231,
				},
				 {
					Value = 200007,
					Num = 190,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id033] =
{
	Id = 33,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248126,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2080,
				},
				 {
					Value = 200008,
					Num = 1713,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1849,
				},
				 {
					Value = 200008,
					Num = 1523,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1618,
				},
				 {
					Value = 200008,
					Num = 1332,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1387,
				},
				 {
					Value = 200008,
					Num = 1142,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1156,
				},
				 {
					Value = 200008,
					Num = 952,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 924,
				},
				 {
					Value = 200008,
					Num = 761,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 693,
				},
				 {
					Value = 200008,
					Num = 571,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 462,
				},
				 {
					Value = 200008,
					Num = 380,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 231,
				},
				 {
					Value = 200008,
					Num = 190,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id034] =
{
	Id = 34,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248136,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2080,
				},
				 {
					Value = 200007,
					Num = 1713,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1849,
				},
				 {
					Value = 200007,
					Num = 1523,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1618,
				},
				 {
					Value = 200007,
					Num = 1332,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1387,
				},
				 {
					Value = 200007,
					Num = 1142,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1156,
				},
				 {
					Value = 200007,
					Num = 952,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 924,
				},
				 {
					Value = 200007,
					Num = 761,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 693,
				},
				 {
					Value = 200007,
					Num = 571,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 462,
				},
				 {
					Value = 200007,
					Num = 380,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 231,
				},
				 {
					Value = 200007,
					Num = 190,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id035] =
{
	Id = 35,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248146,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2080,
				},
				 {
					Value = 200008,
					Num = 1713,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1849,
				},
				 {
					Value = 200008,
					Num = 1523,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1618,
				},
				 {
					Value = 200008,
					Num = 1332,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1387,
				},
				 {
					Value = 200008,
					Num = 1142,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1156,
				},
				 {
					Value = 200008,
					Num = 952,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 924,
				},
				 {
					Value = 200008,
					Num = 761,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 693,
				},
				 {
					Value = 200008,
					Num = 571,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 462,
				},
				 {
					Value = 200008,
					Num = 380,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 231,
				},
				 {
					Value = 200008,
					Num = 190,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id036] =
{
	Id = 36,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248106,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2080,
				},
				 {
					Value = 200008,
					Num = 1713,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1849,
				},
				 {
					Value = 200008,
					Num = 1523,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1618,
				},
				 {
					Value = 200008,
					Num = 1332,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1387,
				},
				 {
					Value = 200008,
					Num = 1142,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1156,
				},
				 {
					Value = 200008,
					Num = 952,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 924,
				},
				 {
					Value = 200008,
					Num = 761,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 693,
				},
				 {
					Value = 200008,
					Num = 571,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 462,
				},
				 {
					Value = 200008,
					Num = 380,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 231,
				},
				 {
					Value = 200008,
					Num = 190,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id037] =
{
	Id = 37,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248107,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2325,
				},
				 {
					Value = 200005,
					Num = 1915,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2067,
				},
				 {
					Value = 200005,
					Num = 1702,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1808,
				},
				 {
					Value = 200005,
					Num = 1489,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1550,
				},
				 {
					Value = 200005,
					Num = 1276,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1292,
				},
				 {
					Value = 200005,
					Num = 1064,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1033,
				},
				 {
					Value = 200005,
					Num = 851,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 775,
				},
				 {
					Value = 200005,
					Num = 638,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 516,
				},
				 {
					Value = 200005,
					Num = 425,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 258,
				},
				 {
					Value = 200005,
					Num = 212,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = -1,
				},
				 {
					Value = 200005,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id038] =
{
	Id = 38,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248117,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2325,
				},
				 {
					Value = 200007,
					Num = 1915,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2067,
				},
				 {
					Value = 200007,
					Num = 1702,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1808,
				},
				 {
					Value = 200007,
					Num = 1489,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1550,
				},
				 {
					Value = 200007,
					Num = 1276,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1292,
				},
				 {
					Value = 200007,
					Num = 1064,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1033,
				},
				 {
					Value = 200007,
					Num = 851,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 775,
				},
				 {
					Value = 200007,
					Num = 638,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 516,
				},
				 {
					Value = 200007,
					Num = 425,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 258,
				},
				 {
					Value = 200007,
					Num = 212,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = -1,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id039] =
{
	Id = 39,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248127,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2325,
				},
				 {
					Value = 200008,
					Num = 1915,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2067,
				},
				 {
					Value = 200008,
					Num = 1702,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1808,
				},
				 {
					Value = 200008,
					Num = 1489,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1550,
				},
				 {
					Value = 200008,
					Num = 1276,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1292,
				},
				 {
					Value = 200008,
					Num = 1064,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1033,
				},
				 {
					Value = 200008,
					Num = 851,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 775,
				},
				 {
					Value = 200008,
					Num = 638,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 516,
				},
				 {
					Value = 200008,
					Num = 425,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 258,
				},
				 {
					Value = 200008,
					Num = 212,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = -1,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id040] =
{
	Id = 40,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248137,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2325,
				},
				 {
					Value = 200007,
					Num = 1915,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2067,
				},
				 {
					Value = 200007,
					Num = 1702,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1808,
				},
				 {
					Value = 200007,
					Num = 1489,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1550,
				},
				 {
					Value = 200007,
					Num = 1276,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1292,
				},
				 {
					Value = 200007,
					Num = 1064,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1033,
				},
				 {
					Value = 200007,
					Num = 851,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 775,
				},
				 {
					Value = 200007,
					Num = 638,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 516,
				},
				 {
					Value = 200007,
					Num = 425,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 258,
				},
				 {
					Value = 200007,
					Num = 212,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = -1,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id041] =
{
	Id = 41,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248147,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2325,
				},
				 {
					Value = 200008,
					Num = 1915,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2067,
				},
				 {
					Value = 200008,
					Num = 1702,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1808,
				},
				 {
					Value = 200008,
					Num = 1489,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1550,
				},
				 {
					Value = 200008,
					Num = 1276,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1292,
				},
				 {
					Value = 200008,
					Num = 1064,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1033,
				},
				 {
					Value = 200008,
					Num = 851,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 775,
				},
				 {
					Value = 200008,
					Num = 638,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 516,
				},
				 {
					Value = 200008,
					Num = 425,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 258,
				},
				 {
					Value = 200008,
					Num = 212,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = -1,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id042] =
{
	Id = 42,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248107,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2325,
				},
				 {
					Value = 200008,
					Num = 1915,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2067,
				},
				 {
					Value = 200008,
					Num = 1702,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1808,
				},
				 {
					Value = 200008,
					Num = 1489,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1550,
				},
				 {
					Value = 200008,
					Num = 1276,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1292,
				},
				 {
					Value = 200008,
					Num = 1064,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1033,
				},
				 {
					Value = 200008,
					Num = 851,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 775,
				},
				 {
					Value = 200008,
					Num = 638,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 516,
				},
				 {
					Value = 200008,
					Num = 425,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 258,
				},
				 {
					Value = 200008,
					Num = 212,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200007,
					Num = -1,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id043] =
{
	Id = 43,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248108,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2570,
				},
				 {
					Value = 200005,
					Num = 2116,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2284,
				},
				 {
					Value = 200005,
					Num = 1881,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1999,
				},
				 {
					Value = 200005,
					Num = 1646,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1713,
				},
				 {
					Value = 200005,
					Num = 1411,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1428,
				},
				 {
					Value = 200005,
					Num = 1176,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1142,
				},
				 {
					Value = 200005,
					Num = 940,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 856,
				},
				 {
					Value = 200005,
					Num = 705,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 571,
				},
				 {
					Value = 200005,
					Num = 470,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 285,
				},
				 {
					Value = 200005,
					Num = 235,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200005,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id044] =
{
	Id = 44,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248118,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2570,
				},
				 {
					Value = 200007,
					Num = 2116,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2284,
				},
				 {
					Value = 200007,
					Num = 1881,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1999,
				},
				 {
					Value = 200007,
					Num = 1646,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1713,
				},
				 {
					Value = 200007,
					Num = 1411,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1428,
				},
				 {
					Value = 200007,
					Num = 1176,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1142,
				},
				 {
					Value = 200007,
					Num = 940,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 856,
				},
				 {
					Value = 200007,
					Num = 705,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 571,
				},
				 {
					Value = 200007,
					Num = 470,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 285,
				},
				 {
					Value = 200007,
					Num = 235,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id045] =
{
	Id = 45,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248128,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2570,
				},
				 {
					Value = 200008,
					Num = 2116,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2284,
				},
				 {
					Value = 200008,
					Num = 1881,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1999,
				},
				 {
					Value = 200008,
					Num = 1646,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1713,
				},
				 {
					Value = 200008,
					Num = 1411,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1428,
				},
				 {
					Value = 200008,
					Num = 1176,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1142,
				},
				 {
					Value = 200008,
					Num = 940,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 856,
				},
				 {
					Value = 200008,
					Num = 705,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 571,
				},
				 {
					Value = 200008,
					Num = 470,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 285,
				},
				 {
					Value = 200008,
					Num = 235,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id046] =
{
	Id = 46,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248138,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2570,
				},
				 {
					Value = 200007,
					Num = 2116,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2284,
				},
				 {
					Value = 200007,
					Num = 1881,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1999,
				},
				 {
					Value = 200007,
					Num = 1646,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1713,
				},
				 {
					Value = 200007,
					Num = 1411,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1428,
				},
				 {
					Value = 200007,
					Num = 1176,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1142,
				},
				 {
					Value = 200007,
					Num = 940,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 856,
				},
				 {
					Value = 200007,
					Num = 705,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 571,
				},
				 {
					Value = 200007,
					Num = 470,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 285,
				},
				 {
					Value = 200007,
					Num = 235,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id047] =
{
	Id = 47,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248148,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2570,
				},
				 {
					Value = 200008,
					Num = 2116,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2284,
				},
				 {
					Value = 200008,
					Num = 1881,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1999,
				},
				 {
					Value = 200008,
					Num = 1646,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1713,
				},
				 {
					Value = 200008,
					Num = 1411,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1428,
				},
				 {
					Value = 200008,
					Num = 1176,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1142,
				},
				 {
					Value = 200008,
					Num = 940,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 856,
				},
				 {
					Value = 200008,
					Num = 705,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 571,
				},
				 {
					Value = 200008,
					Num = 470,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 285,
				},
				 {
					Value = 200008,
					Num = 235,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id048] =
{
	Id = 48,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248108,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2570,
				},
				 {
					Value = 200008,
					Num = 2116,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2284,
				},
				 {
					Value = 200008,
					Num = 1881,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1999,
				},
				 {
					Value = 200008,
					Num = 1646,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1713,
				},
				 {
					Value = 200008,
					Num = 1411,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1428,
				},
				 {
					Value = 200008,
					Num = 1176,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1142,
				},
				 {
					Value = 200008,
					Num = 940,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 856,
				},
				 {
					Value = 200008,
					Num = 705,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 571,
				},
				 {
					Value = 200008,
					Num = 470,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 285,
				},
				 {
					Value = 200008,
					Num = 235,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id049] =
{
	Id = 49,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248109,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2815,
				},
				 {
					Value = 200005,
					Num = 2318,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2502,
				},
				 {
					Value = 200005,
					Num = 2060,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2189,
				},
				 {
					Value = 200005,
					Num = 1803,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1876,
				},
				 {
					Value = 200005,
					Num = 1545,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1564,
				},
				 {
					Value = 200005,
					Num = 1288,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1251,
				},
				 {
					Value = 200005,
					Num = 1030,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 938,
				},
				 {
					Value = 200005,
					Num = 772,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 625,
				},
				 {
					Value = 200005,
					Num = 515,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 312,
				},
				 {
					Value = 200005,
					Num = 257,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200005,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id050] =
{
	Id = 50,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248119,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2815,
				},
				 {
					Value = 200007,
					Num = 2318,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2502,
				},
				 {
					Value = 200007,
					Num = 2060,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2189,
				},
				 {
					Value = 200007,
					Num = 1803,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1876,
				},
				 {
					Value = 200007,
					Num = 1545,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1564,
				},
				 {
					Value = 200007,
					Num = 1288,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1251,
				},
				 {
					Value = 200007,
					Num = 1030,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 938,
				},
				 {
					Value = 200007,
					Num = 772,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 625,
				},
				 {
					Value = 200007,
					Num = 515,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 312,
				},
				 {
					Value = 200007,
					Num = 257,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id051] =
{
	Id = 51,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248129,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2815,
				},
				 {
					Value = 200008,
					Num = 2318,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2502,
				},
				 {
					Value = 200008,
					Num = 2060,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2189,
				},
				 {
					Value = 200008,
					Num = 1803,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1876,
				},
				 {
					Value = 200008,
					Num = 1545,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1564,
				},
				 {
					Value = 200008,
					Num = 1288,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1251,
				},
				 {
					Value = 200008,
					Num = 1030,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 938,
				},
				 {
					Value = 200008,
					Num = 772,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 625,
				},
				 {
					Value = 200008,
					Num = 515,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 312,
				},
				 {
					Value = 200008,
					Num = 257,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id052] =
{
	Id = 52,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248139,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2815,
				},
				 {
					Value = 200007,
					Num = 2318,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2502,
				},
				 {
					Value = 200007,
					Num = 2060,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2189,
				},
				 {
					Value = 200007,
					Num = 1803,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1876,
				},
				 {
					Value = 200007,
					Num = 1545,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1564,
				},
				 {
					Value = 200007,
					Num = 1288,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1251,
				},
				 {
					Value = 200007,
					Num = 1030,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 938,
				},
				 {
					Value = 200007,
					Num = 772,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 625,
				},
				 {
					Value = 200007,
					Num = 515,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 312,
				},
				 {
					Value = 200007,
					Num = 257,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id053] =
{
	Id = 53,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248149,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2815,
				},
				 {
					Value = 200008,
					Num = 2318,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2502,
				},
				 {
					Value = 200008,
					Num = 2060,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2189,
				},
				 {
					Value = 200008,
					Num = 1803,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1876,
				},
				 {
					Value = 200008,
					Num = 1545,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1564,
				},
				 {
					Value = 200008,
					Num = 1288,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1251,
				},
				 {
					Value = 200008,
					Num = 1030,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 938,
				},
				 {
					Value = 200008,
					Num = 772,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 625,
				},
				 {
					Value = 200008,
					Num = 515,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 312,
				},
				 {
					Value = 200008,
					Num = 257,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id054] =
{
	Id = 54,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248109,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2815,
				},
				 {
					Value = 200008,
					Num = 2318,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2502,
				},
				 {
					Value = 200008,
					Num = 2060,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2189,
				},
				 {
					Value = 200008,
					Num = 1803,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1876,
				},
				 {
					Value = 200008,
					Num = 1545,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1564,
				},
				 {
					Value = 200008,
					Num = 1288,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1251,
				},
				 {
					Value = 200008,
					Num = 1030,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 938,
				},
				 {
					Value = 200008,
					Num = 772,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 625,
				},
				 {
					Value = 200008,
					Num = 515,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 312,
				},
				 {
					Value = 200008,
					Num = 257,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id055] =
{
	Id = 55,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248110,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 3060,
				},
				 {
					Value = 200005,
					Num = 2520,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2720,
				},
				 {
					Value = 200005,
					Num = 2240,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2380,
				},
				 {
					Value = 200005,
					Num = 1960,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2040,
				},
				 {
					Value = 200005,
					Num = 1680,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1700,
				},
				 {
					Value = 200005,
					Num = 1400,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1360,
				},
				 {
					Value = 200005,
					Num = 1120,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1020,
				},
				 {
					Value = 200005,
					Num = 840,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 680,
				},
				 {
					Value = 200005,
					Num = 560,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 340,
				},
				 {
					Value = 200005,
					Num = 280,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200005,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id056] =
{
	Id = 56,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248120,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 3060,
				},
				 {
					Value = 200007,
					Num = 2520,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2720,
				},
				 {
					Value = 200007,
					Num = 2240,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2380,
				},
				 {
					Value = 200007,
					Num = 1960,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2040,
				},
				 {
					Value = 200007,
					Num = 1680,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1700,
				},
				 {
					Value = 200007,
					Num = 1400,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1360,
				},
				 {
					Value = 200007,
					Num = 1120,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1020,
				},
				 {
					Value = 200007,
					Num = 840,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 680,
				},
				 {
					Value = 200007,
					Num = 560,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 340,
				},
				 {
					Value = 200007,
					Num = 280,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id057] =
{
	Id = 57,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248130,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 3060,
				},
				 {
					Value = 200008,
					Num = 2520,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2720,
				},
				 {
					Value = 200008,
					Num = 2240,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2380,
				},
				 {
					Value = 200008,
					Num = 1960,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2040,
				},
				 {
					Value = 200008,
					Num = 1680,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1700,
				},
				 {
					Value = 200008,
					Num = 1400,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1360,
				},
				 {
					Value = 200008,
					Num = 1120,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1020,
				},
				 {
					Value = 200008,
					Num = 840,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 680,
				},
				 {
					Value = 200008,
					Num = 560,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 340,
				},
				 {
					Value = 200008,
					Num = 280,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id058] =
{
	Id = 58,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248140,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 3060,
				},
				 {
					Value = 200007,
					Num = 2520,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2720,
				},
				 {
					Value = 200007,
					Num = 2240,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2380,
				},
				 {
					Value = 200007,
					Num = 1960,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2040,
				},
				 {
					Value = 200007,
					Num = 1680,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1700,
				},
				 {
					Value = 200007,
					Num = 1400,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1360,
				},
				 {
					Value = 200007,
					Num = 1120,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1020,
				},
				 {
					Value = 200007,
					Num = 840,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 680,
				},
				 {
					Value = 200007,
					Num = 560,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 340,
				},
				 {
					Value = 200007,
					Num = 280,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id059] =
{
	Id = 59,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248150,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 3060,
				},
				 {
					Value = 200008,
					Num = 2520,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2720,
				},
				 {
					Value = 200008,
					Num = 2240,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2380,
				},
				 {
					Value = 200008,
					Num = 1960,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2040,
				},
				 {
					Value = 200008,
					Num = 1680,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1700,
				},
				 {
					Value = 200008,
					Num = 1400,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1360,
				},
				 {
					Value = 200008,
					Num = 1120,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1020,
				},
				 {
					Value = 200008,
					Num = 840,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 680,
				},
				 {
					Value = 200008,
					Num = 560,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 340,
				},
				 {
					Value = 200008,
					Num = 280,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id060] =
{
	Id = 60,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248110,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 3060,
				},
				 {
					Value = 200008,
					Num = 2520,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2720,
				},
				 {
					Value = 200008,
					Num = 2240,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2380,
				},
				 {
					Value = 200008,
					Num = 1960,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2040,
				},
				 {
					Value = 200008,
					Num = 1680,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1700,
				},
				 {
					Value = 200008,
					Num = 1400,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1360,
				},
				 {
					Value = 200008,
					Num = 1120,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1020,
				},
				 {
					Value = 200008,
					Num = 840,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 680,
				},
				 {
					Value = 200008,
					Num = 560,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 340,
				},
				 {
					Value = 200008,
					Num = 280,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id061] =
{
	Id = 61,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248151,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 856,
				},
				 {
					Value = 200005,
					Num = 705,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 761,
				},
				 {
					Value = 200005,
					Num = 627,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 666,
				},
				 {
					Value = 200005,
					Num = 548,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 571,
				},
				 {
					Value = 200005,
					Num = 470,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 476,
				},
				 {
					Value = 200005,
					Num = 392,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 380,
				},
				 {
					Value = 200005,
					Num = 313,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 285,
				},
				 {
					Value = 200005,
					Num = 235,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 190,
				},
				 {
					Value = 200005,
					Num = 156,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 95,
				},
				 {
					Value = 200005,
					Num = 78,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200005,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id062] =
{
	Id = 62,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248161,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 856,
				},
				 {
					Value = 200007,
					Num = 705,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 761,
				},
				 {
					Value = 200007,
					Num = 627,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 666,
				},
				 {
					Value = 200007,
					Num = 548,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 571,
				},
				 {
					Value = 200007,
					Num = 470,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 476,
				},
				 {
					Value = 200007,
					Num = 392,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 380,
				},
				 {
					Value = 200007,
					Num = 313,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 285,
				},
				 {
					Value = 200007,
					Num = 235,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 190,
				},
				 {
					Value = 200007,
					Num = 156,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 95,
				},
				 {
					Value = 200007,
					Num = 78,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id063] =
{
	Id = 63,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248171,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 856,
				},
				 {
					Value = 200008,
					Num = 705,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 761,
				},
				 {
					Value = 200008,
					Num = 627,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 666,
				},
				 {
					Value = 200008,
					Num = 548,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 571,
				},
				 {
					Value = 200008,
					Num = 470,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 476,
				},
				 {
					Value = 200008,
					Num = 392,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 380,
				},
				 {
					Value = 200008,
					Num = 313,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 285,
				},
				 {
					Value = 200008,
					Num = 235,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 190,
				},
				 {
					Value = 200008,
					Num = 156,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 95,
				},
				 {
					Value = 200008,
					Num = 78,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id064] =
{
	Id = 64,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248181,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 856,
				},
				 {
					Value = 200007,
					Num = 705,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 761,
				},
				 {
					Value = 200007,
					Num = 627,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 666,
				},
				 {
					Value = 200007,
					Num = 548,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 571,
				},
				 {
					Value = 200007,
					Num = 470,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 476,
				},
				 {
					Value = 200007,
					Num = 392,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 380,
				},
				 {
					Value = 200007,
					Num = 313,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 285,
				},
				 {
					Value = 200007,
					Num = 235,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 190,
				},
				 {
					Value = 200007,
					Num = 156,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 95,
				},
				 {
					Value = 200007,
					Num = 78,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id065] =
{
	Id = 65,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248191,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 856,
				},
				 {
					Value = 200008,
					Num = 705,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 761,
				},
				 {
					Value = 200008,
					Num = 627,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 666,
				},
				 {
					Value = 200008,
					Num = 548,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 571,
				},
				 {
					Value = 200008,
					Num = 470,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 476,
				},
				 {
					Value = 200008,
					Num = 392,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 380,
				},
				 {
					Value = 200008,
					Num = 313,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 285,
				},
				 {
					Value = 200008,
					Num = 235,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 190,
				},
				 {
					Value = 200008,
					Num = 156,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 95,
				},
				 {
					Value = 200008,
					Num = 78,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id066] =
{
	Id = 66,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248151,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 856,
				},
				 {
					Value = 200008,
					Num = 705,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 761,
				},
				 {
					Value = 200008,
					Num = 627,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 666,
				},
				 {
					Value = 200008,
					Num = 548,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 571,
				},
				 {
					Value = 200008,
					Num = 470,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 476,
				},
				 {
					Value = 200008,
					Num = 392,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 380,
				},
				 {
					Value = 200008,
					Num = 313,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 285,
				},
				 {
					Value = 200008,
					Num = 235,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 190,
				},
				 {
					Value = 200008,
					Num = 156,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 95,
				},
				 {
					Value = 200008,
					Num = 78,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id067] =
{
	Id = 67,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248152,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1101,
				},
				 {
					Value = 200005,
					Num = 907,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 979,
				},
				 {
					Value = 200005,
					Num = 806,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 856,
				},
				 {
					Value = 200005,
					Num = 705,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 734,
				},
				 {
					Value = 200005,
					Num = 604,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 612,
				},
				 {
					Value = 200005,
					Num = 504,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 489,
				},
				 {
					Value = 200005,
					Num = 403,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 367,
				},
				 {
					Value = 200005,
					Num = 302,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 244,
				},
				 {
					Value = 200005,
					Num = 201,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 122,
				},
				 {
					Value = 200005,
					Num = 100,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200005,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id068] =
{
	Id = 68,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248162,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1101,
				},
				 {
					Value = 200007,
					Num = 907,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 979,
				},
				 {
					Value = 200007,
					Num = 806,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 856,
				},
				 {
					Value = 200007,
					Num = 705,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 734,
				},
				 {
					Value = 200007,
					Num = 604,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 612,
				},
				 {
					Value = 200007,
					Num = 504,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 489,
				},
				 {
					Value = 200007,
					Num = 403,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 367,
				},
				 {
					Value = 200007,
					Num = 302,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 244,
				},
				 {
					Value = 200007,
					Num = 201,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 122,
				},
				 {
					Value = 200007,
					Num = 100,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id069] =
{
	Id = 69,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248172,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1101,
				},
				 {
					Value = 200008,
					Num = 907,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 979,
				},
				 {
					Value = 200008,
					Num = 806,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 856,
				},
				 {
					Value = 200008,
					Num = 705,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 734,
				},
				 {
					Value = 200008,
					Num = 604,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 612,
				},
				 {
					Value = 200008,
					Num = 504,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 489,
				},
				 {
					Value = 200008,
					Num = 403,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 367,
				},
				 {
					Value = 200008,
					Num = 302,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 244,
				},
				 {
					Value = 200008,
					Num = 201,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 122,
				},
				 {
					Value = 200008,
					Num = 100,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id070] =
{
	Id = 70,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248182,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1101,
				},
				 {
					Value = 200007,
					Num = 907,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 979,
				},
				 {
					Value = 200007,
					Num = 806,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 856,
				},
				 {
					Value = 200007,
					Num = 705,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 734,
				},
				 {
					Value = 200007,
					Num = 604,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 612,
				},
				 {
					Value = 200007,
					Num = 504,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 489,
				},
				 {
					Value = 200007,
					Num = 403,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 367,
				},
				 {
					Value = 200007,
					Num = 302,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 244,
				},
				 {
					Value = 200007,
					Num = 201,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 122,
				},
				 {
					Value = 200007,
					Num = 100,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id071] =
{
	Id = 71,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248192,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1101,
				},
				 {
					Value = 200008,
					Num = 907,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 979,
				},
				 {
					Value = 200008,
					Num = 806,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 856,
				},
				 {
					Value = 200008,
					Num = 705,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 734,
				},
				 {
					Value = 200008,
					Num = 604,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 612,
				},
				 {
					Value = 200008,
					Num = 504,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 489,
				},
				 {
					Value = 200008,
					Num = 403,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 367,
				},
				 {
					Value = 200008,
					Num = 302,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 244,
				},
				 {
					Value = 200008,
					Num = 201,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 122,
				},
				 {
					Value = 200008,
					Num = 100,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id072] =
{
	Id = 72,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248152,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1101,
				},
				 {
					Value = 200008,
					Num = 907,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 979,
				},
				 {
					Value = 200008,
					Num = 806,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 856,
				},
				 {
					Value = 200008,
					Num = 705,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 734,
				},
				 {
					Value = 200008,
					Num = 604,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 612,
				},
				 {
					Value = 200008,
					Num = 504,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 489,
				},
				 {
					Value = 200008,
					Num = 403,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 367,
				},
				 {
					Value = 200008,
					Num = 302,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 244,
				},
				 {
					Value = 200008,
					Num = 201,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 122,
				},
				 {
					Value = 200008,
					Num = 100,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id073] =
{
	Id = 73,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248153,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1346,
				},
				 {
					Value = 200005,
					Num = 1108,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1196,
				},
				 {
					Value = 200005,
					Num = 985,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1047,
				},
				 {
					Value = 200005,
					Num = 862,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 897,
				},
				 {
					Value = 200005,
					Num = 739,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 748,
				},
				 {
					Value = 200005,
					Num = 616,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 598,
				},
				 {
					Value = 200005,
					Num = 492,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 448,
				},
				 {
					Value = 200005,
					Num = 369,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 299,
				},
				 {
					Value = 200005,
					Num = 246,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 149,
				},
				 {
					Value = 200005,
					Num = 123,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200005,
					Num = -1,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id074] =
{
	Id = 74,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248163,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1346,
				},
				 {
					Value = 200007,
					Num = 1108,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1196,
				},
				 {
					Value = 200007,
					Num = 985,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1047,
				},
				 {
					Value = 200007,
					Num = 862,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 897,
				},
				 {
					Value = 200007,
					Num = 739,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 748,
				},
				 {
					Value = 200007,
					Num = 616,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 598,
				},
				 {
					Value = 200007,
					Num = 492,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 448,
				},
				 {
					Value = 200007,
					Num = 369,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 299,
				},
				 {
					Value = 200007,
					Num = 246,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 149,
				},
				 {
					Value = 200007,
					Num = 123,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = -1,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id075] =
{
	Id = 75,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248173,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1346,
				},
				 {
					Value = 200008,
					Num = 1108,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1196,
				},
				 {
					Value = 200008,
					Num = 985,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1047,
				},
				 {
					Value = 200008,
					Num = 862,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 897,
				},
				 {
					Value = 200008,
					Num = 739,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 748,
				},
				 {
					Value = 200008,
					Num = 616,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 598,
				},
				 {
					Value = 200008,
					Num = 492,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 448,
				},
				 {
					Value = 200008,
					Num = 369,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 299,
				},
				 {
					Value = 200008,
					Num = 246,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 149,
				},
				 {
					Value = 200008,
					Num = 123,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = -1,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id076] =
{
	Id = 76,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248183,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1346,
				},
				 {
					Value = 200007,
					Num = 1108,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1196,
				},
				 {
					Value = 200007,
					Num = 985,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1047,
				},
				 {
					Value = 200007,
					Num = 862,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 897,
				},
				 {
					Value = 200007,
					Num = 739,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 748,
				},
				 {
					Value = 200007,
					Num = 616,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 598,
				},
				 {
					Value = 200007,
					Num = 492,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 448,
				},
				 {
					Value = 200007,
					Num = 369,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 299,
				},
				 {
					Value = 200007,
					Num = 246,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 149,
				},
				 {
					Value = 200007,
					Num = 123,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = -1,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id077] =
{
	Id = 77,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248193,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1346,
				},
				 {
					Value = 200008,
					Num = 1108,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1196,
				},
				 {
					Value = 200008,
					Num = 985,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1047,
				},
				 {
					Value = 200008,
					Num = 862,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 897,
				},
				 {
					Value = 200008,
					Num = 739,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 748,
				},
				 {
					Value = 200008,
					Num = 616,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 598,
				},
				 {
					Value = 200008,
					Num = 492,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 448,
				},
				 {
					Value = 200008,
					Num = 369,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 299,
				},
				 {
					Value = 200008,
					Num = 246,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 149,
				},
				 {
					Value = 200008,
					Num = 123,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = -1,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id078] =
{
	Id = 78,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248153,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1346,
				},
				 {
					Value = 200008,
					Num = 1108,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1196,
				},
				 {
					Value = 200008,
					Num = 985,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1047,
				},
				 {
					Value = 200008,
					Num = 862,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 897,
				},
				 {
					Value = 200008,
					Num = 739,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 748,
				},
				 {
					Value = 200008,
					Num = 616,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 598,
				},
				 {
					Value = 200008,
					Num = 492,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 448,
				},
				 {
					Value = 200008,
					Num = 369,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 299,
				},
				 {
					Value = 200008,
					Num = 246,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 149,
				},
				 {
					Value = 200008,
					Num = 123,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = -1,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id079] =
{
	Id = 79,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248154,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1591,
				},
				 {
					Value = 200005,
					Num = 1310,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1414,
				},
				 {
					Value = 200005,
					Num = 1164,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1237,
				},
				 {
					Value = 200005,
					Num = 1019,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1060,
				},
				 {
					Value = 200005,
					Num = 873,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 884,
				},
				 {
					Value = 200005,
					Num = 728,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 707,
				},
				 {
					Value = 200005,
					Num = 582,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 530,
				},
				 {
					Value = 200005,
					Num = 436,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 353,
				},
				 {
					Value = 200005,
					Num = 291,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 176,
				},
				 {
					Value = 200005,
					Num = 145,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200005,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id080] =
{
	Id = 80,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248164,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1591,
				},
				 {
					Value = 200007,
					Num = 1310,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1414,
				},
				 {
					Value = 200007,
					Num = 1164,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1237,
				},
				 {
					Value = 200007,
					Num = 1019,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1060,
				},
				 {
					Value = 200007,
					Num = 873,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 884,
				},
				 {
					Value = 200007,
					Num = 728,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 707,
				},
				 {
					Value = 200007,
					Num = 582,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 530,
				},
				 {
					Value = 200007,
					Num = 436,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 353,
				},
				 {
					Value = 200007,
					Num = 291,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 176,
				},
				 {
					Value = 200007,
					Num = 145,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id081] =
{
	Id = 81,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248174,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1591,
				},
				 {
					Value = 200008,
					Num = 1310,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1414,
				},
				 {
					Value = 200008,
					Num = 1164,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1237,
				},
				 {
					Value = 200008,
					Num = 1019,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1060,
				},
				 {
					Value = 200008,
					Num = 873,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 884,
				},
				 {
					Value = 200008,
					Num = 728,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 707,
				},
				 {
					Value = 200008,
					Num = 582,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 530,
				},
				 {
					Value = 200008,
					Num = 436,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 353,
				},
				 {
					Value = 200008,
					Num = 291,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 176,
				},
				 {
					Value = 200008,
					Num = 145,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id082] =
{
	Id = 82,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248184,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1591,
				},
				 {
					Value = 200007,
					Num = 1310,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1414,
				},
				 {
					Value = 200007,
					Num = 1164,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1237,
				},
				 {
					Value = 200007,
					Num = 1019,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1060,
				},
				 {
					Value = 200007,
					Num = 873,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 884,
				},
				 {
					Value = 200007,
					Num = 728,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 707,
				},
				 {
					Value = 200007,
					Num = 582,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 530,
				},
				 {
					Value = 200007,
					Num = 436,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 353,
				},
				 {
					Value = 200007,
					Num = 291,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 176,
				},
				 {
					Value = 200007,
					Num = 145,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id083] =
{
	Id = 83,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248194,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1591,
				},
				 {
					Value = 200008,
					Num = 1310,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1414,
				},
				 {
					Value = 200008,
					Num = 1164,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1237,
				},
				 {
					Value = 200008,
					Num = 1019,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1060,
				},
				 {
					Value = 200008,
					Num = 873,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 884,
				},
				 {
					Value = 200008,
					Num = 728,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 707,
				},
				 {
					Value = 200008,
					Num = 582,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 530,
				},
				 {
					Value = 200008,
					Num = 436,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 353,
				},
				 {
					Value = 200008,
					Num = 291,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 176,
				},
				 {
					Value = 200008,
					Num = 145,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id084] =
{
	Id = 84,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248154,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1591,
				},
				 {
					Value = 200008,
					Num = 1310,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1414,
				},
				 {
					Value = 200008,
					Num = 1164,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1237,
				},
				 {
					Value = 200008,
					Num = 1019,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1060,
				},
				 {
					Value = 200008,
					Num = 873,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 884,
				},
				 {
					Value = 200008,
					Num = 728,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 707,
				},
				 {
					Value = 200008,
					Num = 582,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 530,
				},
				 {
					Value = 200008,
					Num = 436,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 353,
				},
				 {
					Value = 200008,
					Num = 291,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 176,
				},
				 {
					Value = 200008,
					Num = 145,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id085] =
{
	Id = 85,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248155,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1836,
				},
				 {
					Value = 200005,
					Num = 1512,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1632,
				},
				 {
					Value = 200005,
					Num = 1344,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1428,
				},
				 {
					Value = 200005,
					Num = 1176,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1224,
				},
				 {
					Value = 200005,
					Num = 1008,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1020,
				},
				 {
					Value = 200005,
					Num = 840,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 816,
				},
				 {
					Value = 200005,
					Num = 672,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 612,
				},
				 {
					Value = 200005,
					Num = 504,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 408,
				},
				 {
					Value = 200005,
					Num = 336,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 204,
				},
				 {
					Value = 200005,
					Num = 168,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200005,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id086] =
{
	Id = 86,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248165,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1836,
				},
				 {
					Value = 200007,
					Num = 1512,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1632,
				},
				 {
					Value = 200007,
					Num = 1344,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1428,
				},
				 {
					Value = 200007,
					Num = 1176,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1224,
				},
				 {
					Value = 200007,
					Num = 1008,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1020,
				},
				 {
					Value = 200007,
					Num = 840,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 816,
				},
				 {
					Value = 200007,
					Num = 672,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 612,
				},
				 {
					Value = 200007,
					Num = 504,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 408,
				},
				 {
					Value = 200007,
					Num = 336,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 204,
				},
				 {
					Value = 200007,
					Num = 168,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id087] =
{
	Id = 87,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248175,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1836,
				},
				 {
					Value = 200008,
					Num = 1512,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1632,
				},
				 {
					Value = 200008,
					Num = 1344,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1428,
				},
				 {
					Value = 200008,
					Num = 1176,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1224,
				},
				 {
					Value = 200008,
					Num = 1008,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1020,
				},
				 {
					Value = 200008,
					Num = 840,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 816,
				},
				 {
					Value = 200008,
					Num = 672,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 612,
				},
				 {
					Value = 200008,
					Num = 504,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 408,
				},
				 {
					Value = 200008,
					Num = 336,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 204,
				},
				 {
					Value = 200008,
					Num = 168,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id088] =
{
	Id = 88,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248185,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1836,
				},
				 {
					Value = 200007,
					Num = 1512,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1632,
				},
				 {
					Value = 200007,
					Num = 1344,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1428,
				},
				 {
					Value = 200007,
					Num = 1176,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1224,
				},
				 {
					Value = 200007,
					Num = 1008,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1020,
				},
				 {
					Value = 200007,
					Num = 840,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 816,
				},
				 {
					Value = 200007,
					Num = 672,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 612,
				},
				 {
					Value = 200007,
					Num = 504,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 408,
				},
				 {
					Value = 200007,
					Num = 336,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 204,
				},
				 {
					Value = 200007,
					Num = 168,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id089] =
{
	Id = 89,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248195,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1836,
				},
				 {
					Value = 200008,
					Num = 1512,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1632,
				},
				 {
					Value = 200008,
					Num = 1344,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1428,
				},
				 {
					Value = 200008,
					Num = 1176,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1224,
				},
				 {
					Value = 200008,
					Num = 1008,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1020,
				},
				 {
					Value = 200008,
					Num = 840,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 816,
				},
				 {
					Value = 200008,
					Num = 672,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 612,
				},
				 {
					Value = 200008,
					Num = 504,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 408,
				},
				 {
					Value = 200008,
					Num = 336,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 204,
				},
				 {
					Value = 200008,
					Num = 168,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id090] =
{
	Id = 90,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248155,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1836,
				},
				 {
					Value = 200008,
					Num = 1512,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1632,
				},
				 {
					Value = 200008,
					Num = 1344,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1428,
				},
				 {
					Value = 200008,
					Num = 1176,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1224,
				},
				 {
					Value = 200008,
					Num = 1008,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1020,
				},
				 {
					Value = 200008,
					Num = 840,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 816,
				},
				 {
					Value = 200008,
					Num = 672,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 612,
				},
				 {
					Value = 200008,
					Num = 504,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 408,
				},
				 {
					Value = 200008,
					Num = 336,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 204,
				},
				 {
					Value = 200008,
					Num = 168,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id091] =
{
	Id = 91,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248156,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2080,
				},
				 {
					Value = 200005,
					Num = 1713,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1849,
				},
				 {
					Value = 200005,
					Num = 1523,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1618,
				},
				 {
					Value = 200005,
					Num = 1332,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1387,
				},
				 {
					Value = 200005,
					Num = 1142,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1156,
				},
				 {
					Value = 200005,
					Num = 952,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 924,
				},
				 {
					Value = 200005,
					Num = 761,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 693,
				},
				 {
					Value = 200005,
					Num = 571,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 462,
				},
				 {
					Value = 200005,
					Num = 380,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 231,
				},
				 {
					Value = 200005,
					Num = 190,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200005,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id092] =
{
	Id = 92,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248166,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2080,
				},
				 {
					Value = 200007,
					Num = 1713,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1849,
				},
				 {
					Value = 200007,
					Num = 1523,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1618,
				},
				 {
					Value = 200007,
					Num = 1332,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1387,
				},
				 {
					Value = 200007,
					Num = 1142,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1156,
				},
				 {
					Value = 200007,
					Num = 952,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 924,
				},
				 {
					Value = 200007,
					Num = 761,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 693,
				},
				 {
					Value = 200007,
					Num = 571,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 462,
				},
				 {
					Value = 200007,
					Num = 380,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 231,
				},
				 {
					Value = 200007,
					Num = 190,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id093] =
{
	Id = 93,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248176,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2080,
				},
				 {
					Value = 200008,
					Num = 1713,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1849,
				},
				 {
					Value = 200008,
					Num = 1523,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1618,
				},
				 {
					Value = 200008,
					Num = 1332,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1387,
				},
				 {
					Value = 200008,
					Num = 1142,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1156,
				},
				 {
					Value = 200008,
					Num = 952,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 924,
				},
				 {
					Value = 200008,
					Num = 761,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 693,
				},
				 {
					Value = 200008,
					Num = 571,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 462,
				},
				 {
					Value = 200008,
					Num = 380,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 231,
				},
				 {
					Value = 200008,
					Num = 190,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id094] =
{
	Id = 94,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248186,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2080,
				},
				 {
					Value = 200007,
					Num = 1713,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1849,
				},
				 {
					Value = 200007,
					Num = 1523,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1618,
				},
				 {
					Value = 200007,
					Num = 1332,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1387,
				},
				 {
					Value = 200007,
					Num = 1142,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1156,
				},
				 {
					Value = 200007,
					Num = 952,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 924,
				},
				 {
					Value = 200007,
					Num = 761,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 693,
				},
				 {
					Value = 200007,
					Num = 571,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 462,
				},
				 {
					Value = 200007,
					Num = 380,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 231,
				},
				 {
					Value = 200007,
					Num = 190,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id095] =
{
	Id = 95,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248196,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2080,
				},
				 {
					Value = 200008,
					Num = 1713,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1849,
				},
				 {
					Value = 200008,
					Num = 1523,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1618,
				},
				 {
					Value = 200008,
					Num = 1332,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1387,
				},
				 {
					Value = 200008,
					Num = 1142,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1156,
				},
				 {
					Value = 200008,
					Num = 952,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 924,
				},
				 {
					Value = 200008,
					Num = 761,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 693,
				},
				 {
					Value = 200008,
					Num = 571,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 462,
				},
				 {
					Value = 200008,
					Num = 380,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 231,
				},
				 {
					Value = 200008,
					Num = 190,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id096] =
{
	Id = 96,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248156,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2080,
				},
				 {
					Value = 200008,
					Num = 1713,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1849,
				},
				 {
					Value = 200008,
					Num = 1523,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1618,
				},
				 {
					Value = 200008,
					Num = 1332,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1387,
				},
				 {
					Value = 200008,
					Num = 1142,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1156,
				},
				 {
					Value = 200008,
					Num = 952,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 924,
				},
				 {
					Value = 200008,
					Num = 761,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 693,
				},
				 {
					Value = 200008,
					Num = 571,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 462,
				},
				 {
					Value = 200008,
					Num = 380,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 231,
				},
				 {
					Value = 200008,
					Num = 190,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id097] =
{
	Id = 97,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248157,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2325,
				},
				 {
					Value = 200005,
					Num = 1915,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2067,
				},
				 {
					Value = 200005,
					Num = 1702,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1808,
				},
				 {
					Value = 200005,
					Num = 1489,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1550,
				},
				 {
					Value = 200005,
					Num = 1276,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1292,
				},
				 {
					Value = 200005,
					Num = 1064,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1033,
				},
				 {
					Value = 200005,
					Num = 851,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 775,
				},
				 {
					Value = 200005,
					Num = 638,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 516,
				},
				 {
					Value = 200005,
					Num = 425,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 258,
				},
				 {
					Value = 200005,
					Num = 212,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = -1,
				},
				 {
					Value = 200005,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id098] =
{
	Id = 98,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248167,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2325,
				},
				 {
					Value = 200007,
					Num = 1915,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2067,
				},
				 {
					Value = 200007,
					Num = 1702,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1808,
				},
				 {
					Value = 200007,
					Num = 1489,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1550,
				},
				 {
					Value = 200007,
					Num = 1276,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1292,
				},
				 {
					Value = 200007,
					Num = 1064,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1033,
				},
				 {
					Value = 200007,
					Num = 851,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 775,
				},
				 {
					Value = 200007,
					Num = 638,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 516,
				},
				 {
					Value = 200007,
					Num = 425,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 258,
				},
				 {
					Value = 200007,
					Num = 212,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = -1,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id099] =
{
	Id = 99,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248177,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2325,
				},
				 {
					Value = 200008,
					Num = 1915,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2067,
				},
				 {
					Value = 200008,
					Num = 1702,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1808,
				},
				 {
					Value = 200008,
					Num = 1489,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1550,
				},
				 {
					Value = 200008,
					Num = 1276,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1292,
				},
				 {
					Value = 200008,
					Num = 1064,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1033,
				},
				 {
					Value = 200008,
					Num = 851,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 775,
				},
				 {
					Value = 200008,
					Num = 638,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 516,
				},
				 {
					Value = 200008,
					Num = 425,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 258,
				},
				 {
					Value = 200008,
					Num = 212,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = -1,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id100] =
{
	Id = 100,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248187,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2325,
				},
				 {
					Value = 200007,
					Num = 1915,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2067,
				},
				 {
					Value = 200007,
					Num = 1702,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1808,
				},
				 {
					Value = 200007,
					Num = 1489,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1550,
				},
				 {
					Value = 200007,
					Num = 1276,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1292,
				},
				 {
					Value = 200007,
					Num = 1064,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1033,
				},
				 {
					Value = 200007,
					Num = 851,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 775,
				},
				 {
					Value = 200007,
					Num = 638,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 516,
				},
				 {
					Value = 200007,
					Num = 425,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 258,
				},
				 {
					Value = 200007,
					Num = 212,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = -1,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id101] =
{
	Id = 101,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248197,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2325,
				},
				 {
					Value = 200008,
					Num = 1915,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2067,
				},
				 {
					Value = 200008,
					Num = 1702,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1808,
				},
				 {
					Value = 200008,
					Num = 1489,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1550,
				},
				 {
					Value = 200008,
					Num = 1276,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1292,
				},
				 {
					Value = 200008,
					Num = 1064,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1033,
				},
				 {
					Value = 200008,
					Num = 851,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 775,
				},
				 {
					Value = 200008,
					Num = 638,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 516,
				},
				 {
					Value = 200008,
					Num = 425,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 258,
				},
				 {
					Value = 200008,
					Num = 212,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = -1,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id102] =
{
	Id = 102,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248157,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2325,
				},
				 {
					Value = 200008,
					Num = 1915,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2067,
				},
				 {
					Value = 200008,
					Num = 1702,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1808,
				},
				 {
					Value = 200008,
					Num = 1489,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1550,
				},
				 {
					Value = 200008,
					Num = 1276,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1292,
				},
				 {
					Value = 200008,
					Num = 1064,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1033,
				},
				 {
					Value = 200008,
					Num = 851,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 775,
				},
				 {
					Value = 200008,
					Num = 638,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 516,
				},
				 {
					Value = 200008,
					Num = 425,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 258,
				},
				 {
					Value = 200008,
					Num = 212,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200007,
					Num = -1,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id103] =
{
	Id = 103,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248158,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2570,
				},
				 {
					Value = 200005,
					Num = 2116,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2284,
				},
				 {
					Value = 200005,
					Num = 1881,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1999,
				},
				 {
					Value = 200005,
					Num = 1646,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1713,
				},
				 {
					Value = 200005,
					Num = 1411,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1428,
				},
				 {
					Value = 200005,
					Num = 1176,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1142,
				},
				 {
					Value = 200005,
					Num = 940,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 856,
				},
				 {
					Value = 200005,
					Num = 705,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 571,
				},
				 {
					Value = 200005,
					Num = 470,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 285,
				},
				 {
					Value = 200005,
					Num = 235,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200005,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id104] =
{
	Id = 104,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248168,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2570,
				},
				 {
					Value = 200007,
					Num = 2116,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2284,
				},
				 {
					Value = 200007,
					Num = 1881,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1999,
				},
				 {
					Value = 200007,
					Num = 1646,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1713,
				},
				 {
					Value = 200007,
					Num = 1411,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1428,
				},
				 {
					Value = 200007,
					Num = 1176,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1142,
				},
				 {
					Value = 200007,
					Num = 940,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 856,
				},
				 {
					Value = 200007,
					Num = 705,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 571,
				},
				 {
					Value = 200007,
					Num = 470,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 285,
				},
				 {
					Value = 200007,
					Num = 235,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id105] =
{
	Id = 105,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248178,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2570,
				},
				 {
					Value = 200008,
					Num = 2116,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2284,
				},
				 {
					Value = 200008,
					Num = 1881,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1999,
				},
				 {
					Value = 200008,
					Num = 1646,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1713,
				},
				 {
					Value = 200008,
					Num = 1411,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1428,
				},
				 {
					Value = 200008,
					Num = 1176,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1142,
				},
				 {
					Value = 200008,
					Num = 940,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 856,
				},
				 {
					Value = 200008,
					Num = 705,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 571,
				},
				 {
					Value = 200008,
					Num = 470,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 285,
				},
				 {
					Value = 200008,
					Num = 235,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id106] =
{
	Id = 106,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248188,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2570,
				},
				 {
					Value = 200007,
					Num = 2116,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2284,
				},
				 {
					Value = 200007,
					Num = 1881,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1999,
				},
				 {
					Value = 200007,
					Num = 1646,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1713,
				},
				 {
					Value = 200007,
					Num = 1411,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1428,
				},
				 {
					Value = 200007,
					Num = 1176,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1142,
				},
				 {
					Value = 200007,
					Num = 940,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 856,
				},
				 {
					Value = 200007,
					Num = 705,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 571,
				},
				 {
					Value = 200007,
					Num = 470,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 285,
				},
				 {
					Value = 200007,
					Num = 235,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id107] =
{
	Id = 107,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248198,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2570,
				},
				 {
					Value = 200008,
					Num = 2116,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2284,
				},
				 {
					Value = 200008,
					Num = 1881,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1999,
				},
				 {
					Value = 200008,
					Num = 1646,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1713,
				},
				 {
					Value = 200008,
					Num = 1411,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1428,
				},
				 {
					Value = 200008,
					Num = 1176,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1142,
				},
				 {
					Value = 200008,
					Num = 940,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 856,
				},
				 {
					Value = 200008,
					Num = 705,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 571,
				},
				 {
					Value = 200008,
					Num = 470,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 285,
				},
				 {
					Value = 200008,
					Num = 235,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id108] =
{
	Id = 108,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248158,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2570,
				},
				 {
					Value = 200008,
					Num = 2116,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2284,
				},
				 {
					Value = 200008,
					Num = 1881,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1999,
				},
				 {
					Value = 200008,
					Num = 1646,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1713,
				},
				 {
					Value = 200008,
					Num = 1411,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1428,
				},
				 {
					Value = 200008,
					Num = 1176,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1142,
				},
				 {
					Value = 200008,
					Num = 940,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 856,
				},
				 {
					Value = 200008,
					Num = 705,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 571,
				},
				 {
					Value = 200008,
					Num = 470,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 285,
				},
				 {
					Value = 200008,
					Num = 235,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id109] =
{
	Id = 109,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248159,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2815,
				},
				 {
					Value = 200005,
					Num = 2318,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2502,
				},
				 {
					Value = 200005,
					Num = 2060,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2189,
				},
				 {
					Value = 200005,
					Num = 1803,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1876,
				},
				 {
					Value = 200005,
					Num = 1545,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1564,
				},
				 {
					Value = 200005,
					Num = 1288,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1251,
				},
				 {
					Value = 200005,
					Num = 1030,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 938,
				},
				 {
					Value = 200005,
					Num = 772,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 625,
				},
				 {
					Value = 200005,
					Num = 515,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 312,
				},
				 {
					Value = 200005,
					Num = 257,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200005,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id110] =
{
	Id = 110,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248169,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2815,
				},
				 {
					Value = 200007,
					Num = 2318,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2502,
				},
				 {
					Value = 200007,
					Num = 2060,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2189,
				},
				 {
					Value = 200007,
					Num = 1803,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1876,
				},
				 {
					Value = 200007,
					Num = 1545,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1564,
				},
				 {
					Value = 200007,
					Num = 1288,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1251,
				},
				 {
					Value = 200007,
					Num = 1030,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 938,
				},
				 {
					Value = 200007,
					Num = 772,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 625,
				},
				 {
					Value = 200007,
					Num = 515,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 312,
				},
				 {
					Value = 200007,
					Num = 257,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id111] =
{
	Id = 111,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248179,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2815,
				},
				 {
					Value = 200008,
					Num = 2318,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2502,
				},
				 {
					Value = 200008,
					Num = 2060,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2189,
				},
				 {
					Value = 200008,
					Num = 1803,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1876,
				},
				 {
					Value = 200008,
					Num = 1545,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1564,
				},
				 {
					Value = 200008,
					Num = 1288,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1251,
				},
				 {
					Value = 200008,
					Num = 1030,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 938,
				},
				 {
					Value = 200008,
					Num = 772,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 625,
				},
				 {
					Value = 200008,
					Num = 515,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 312,
				},
				 {
					Value = 200008,
					Num = 257,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id112] =
{
	Id = 112,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248189,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2815,
				},
				 {
					Value = 200007,
					Num = 2318,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2502,
				},
				 {
					Value = 200007,
					Num = 2060,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2189,
				},
				 {
					Value = 200007,
					Num = 1803,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1876,
				},
				 {
					Value = 200007,
					Num = 1545,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1564,
				},
				 {
					Value = 200007,
					Num = 1288,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1251,
				},
				 {
					Value = 200007,
					Num = 1030,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 938,
				},
				 {
					Value = 200007,
					Num = 772,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 625,
				},
				 {
					Value = 200007,
					Num = 515,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 312,
				},
				 {
					Value = 200007,
					Num = 257,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id113] =
{
	Id = 113,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248199,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2815,
				},
				 {
					Value = 200008,
					Num = 2318,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2502,
				},
				 {
					Value = 200008,
					Num = 2060,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2189,
				},
				 {
					Value = 200008,
					Num = 1803,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1876,
				},
				 {
					Value = 200008,
					Num = 1545,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1564,
				},
				 {
					Value = 200008,
					Num = 1288,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1251,
				},
				 {
					Value = 200008,
					Num = 1030,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 938,
				},
				 {
					Value = 200008,
					Num = 772,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 625,
				},
				 {
					Value = 200008,
					Num = 515,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 312,
				},
				 {
					Value = 200008,
					Num = 257,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id114] =
{
	Id = 114,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248159,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2815,
				},
				 {
					Value = 200008,
					Num = 2318,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2502,
				},
				 {
					Value = 200008,
					Num = 2060,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2189,
				},
				 {
					Value = 200008,
					Num = 1803,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1876,
				},
				 {
					Value = 200008,
					Num = 1545,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1564,
				},
				 {
					Value = 200008,
					Num = 1288,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1251,
				},
				 {
					Value = 200008,
					Num = 1030,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 938,
				},
				 {
					Value = 200008,
					Num = 772,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 625,
				},
				 {
					Value = 200008,
					Num = 515,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 312,
				},
				 {
					Value = 200008,
					Num = 257,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id115] =
{
	Id = 115,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248160,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 3060,
				},
				 {
					Value = 200005,
					Num = 2520,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2720,
				},
				 {
					Value = 200005,
					Num = 2240,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2380,
				},
				 {
					Value = 200005,
					Num = 1960,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2040,
				},
				 {
					Value = 200005,
					Num = 1680,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1700,
				},
				 {
					Value = 200005,
					Num = 1400,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1360,
				},
				 {
					Value = 200005,
					Num = 1120,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1020,
				},
				 {
					Value = 200005,
					Num = 840,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 680,
				},
				 {
					Value = 200005,
					Num = 560,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 340,
				},
				 {
					Value = 200005,
					Num = 280,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200005,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id116] =
{
	Id = 116,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248170,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 3060,
				},
				 {
					Value = 200007,
					Num = 2520,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2720,
				},
				 {
					Value = 200007,
					Num = 2240,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2380,
				},
				 {
					Value = 200007,
					Num = 1960,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2040,
				},
				 {
					Value = 200007,
					Num = 1680,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1700,
				},
				 {
					Value = 200007,
					Num = 1400,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1360,
				},
				 {
					Value = 200007,
					Num = 1120,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1020,
				},
				 {
					Value = 200007,
					Num = 840,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 680,
				},
				 {
					Value = 200007,
					Num = 560,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 340,
				},
				 {
					Value = 200007,
					Num = 280,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id117] =
{
	Id = 117,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248180,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 3060,
				},
				 {
					Value = 200008,
					Num = 2520,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2720,
				},
				 {
					Value = 200008,
					Num = 2240,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2380,
				},
				 {
					Value = 200008,
					Num = 1960,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2040,
				},
				 {
					Value = 200008,
					Num = 1680,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1700,
				},
				 {
					Value = 200008,
					Num = 1400,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1360,
				},
				 {
					Value = 200008,
					Num = 1120,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1020,
				},
				 {
					Value = 200008,
					Num = 840,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 680,
				},
				 {
					Value = 200008,
					Num = 560,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 340,
				},
				 {
					Value = 200008,
					Num = 280,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id118] =
{
	Id = 118,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248190,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 3060,
				},
				 {
					Value = 200007,
					Num = 2520,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2720,
				},
				 {
					Value = 200007,
					Num = 2240,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2380,
				},
				 {
					Value = 200007,
					Num = 1960,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2040,
				},
				 {
					Value = 200007,
					Num = 1680,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1700,
				},
				 {
					Value = 200007,
					Num = 1400,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1360,
				},
				 {
					Value = 200007,
					Num = 1120,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1020,
				},
				 {
					Value = 200007,
					Num = 840,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 680,
				},
				 {
					Value = 200007,
					Num = 560,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 340,
				},
				 {
					Value = 200007,
					Num = 280,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id119] =
{
	Id = 119,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248200,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 3060,
				},
				 {
					Value = 200008,
					Num = 2520,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2720,
				},
				 {
					Value = 200008,
					Num = 2240,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2380,
				},
				 {
					Value = 200008,
					Num = 1960,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2040,
				},
				 {
					Value = 200008,
					Num = 1680,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1700,
				},
				 {
					Value = 200008,
					Num = 1400,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1360,
				},
				 {
					Value = 200008,
					Num = 1120,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1020,
				},
				 {
					Value = 200008,
					Num = 840,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 680,
				},
				 {
					Value = 200008,
					Num = 560,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 340,
				},
				 {
					Value = 200008,
					Num = 280,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id120] =
{
	Id = 120,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248160,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 3060,
				},
				 {
					Value = 200008,
					Num = 2520,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2720,
				},
				 {
					Value = 200008,
					Num = 2240,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2380,
				},
				 {
					Value = 200008,
					Num = 1960,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2040,
				},
				 {
					Value = 200008,
					Num = 1680,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1700,
				},
				 {
					Value = 200008,
					Num = 1400,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1360,
				},
				 {
					Value = 200008,
					Num = 1120,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1020,
				},
				 {
					Value = 200008,
					Num = 840,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 680,
				},
				 {
					Value = 200008,
					Num = 560,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 340,
				},
				 {
					Value = 200008,
					Num = 280,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id121] =
{
	Id = 121,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248201,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 856,
				},
				 {
					Value = 200005,
					Num = 705,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 761,
				},
				 {
					Value = 200005,
					Num = 627,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 666,
				},
				 {
					Value = 200005,
					Num = 548,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 571,
				},
				 {
					Value = 200005,
					Num = 470,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 476,
				},
				 {
					Value = 200005,
					Num = 392,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 380,
				},
				 {
					Value = 200005,
					Num = 313,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 285,
				},
				 {
					Value = 200005,
					Num = 235,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 190,
				},
				 {
					Value = 200005,
					Num = 156,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 95,
				},
				 {
					Value = 200005,
					Num = 78,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200005,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id122] =
{
	Id = 122,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248211,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 856,
				},
				 {
					Value = 200007,
					Num = 705,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 761,
				},
				 {
					Value = 200007,
					Num = 627,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 666,
				},
				 {
					Value = 200007,
					Num = 548,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 571,
				},
				 {
					Value = 200007,
					Num = 470,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 476,
				},
				 {
					Value = 200007,
					Num = 392,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 380,
				},
				 {
					Value = 200007,
					Num = 313,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 285,
				},
				 {
					Value = 200007,
					Num = 235,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 190,
				},
				 {
					Value = 200007,
					Num = 156,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 95,
				},
				 {
					Value = 200007,
					Num = 78,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id123] =
{
	Id = 123,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248221,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 856,
				},
				 {
					Value = 200008,
					Num = 705,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 761,
				},
				 {
					Value = 200008,
					Num = 627,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 666,
				},
				 {
					Value = 200008,
					Num = 548,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 571,
				},
				 {
					Value = 200008,
					Num = 470,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 476,
				},
				 {
					Value = 200008,
					Num = 392,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 380,
				},
				 {
					Value = 200008,
					Num = 313,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 285,
				},
				 {
					Value = 200008,
					Num = 235,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 190,
				},
				 {
					Value = 200008,
					Num = 156,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 95,
				},
				 {
					Value = 200008,
					Num = 78,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id124] =
{
	Id = 124,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248231,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 856,
				},
				 {
					Value = 200007,
					Num = 705,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 761,
				},
				 {
					Value = 200007,
					Num = 627,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 666,
				},
				 {
					Value = 200007,
					Num = 548,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 571,
				},
				 {
					Value = 200007,
					Num = 470,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 476,
				},
				 {
					Value = 200007,
					Num = 392,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 380,
				},
				 {
					Value = 200007,
					Num = 313,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 285,
				},
				 {
					Value = 200007,
					Num = 235,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 190,
				},
				 {
					Value = 200007,
					Num = 156,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 95,
				},
				 {
					Value = 200007,
					Num = 78,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id125] =
{
	Id = 125,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248241,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 856,
				},
				 {
					Value = 200008,
					Num = 705,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 761,
				},
				 {
					Value = 200008,
					Num = 627,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 666,
				},
				 {
					Value = 200008,
					Num = 548,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 571,
				},
				 {
					Value = 200008,
					Num = 470,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 476,
				},
				 {
					Value = 200008,
					Num = 392,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 380,
				},
				 {
					Value = 200008,
					Num = 313,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 285,
				},
				 {
					Value = 200008,
					Num = 235,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 190,
				},
				 {
					Value = 200008,
					Num = 156,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 95,
				},
				 {
					Value = 200008,
					Num = 78,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id126] =
{
	Id = 126,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248201,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 856,
				},
				 {
					Value = 200008,
					Num = 705,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 761,
				},
				 {
					Value = 200008,
					Num = 627,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 666,
				},
				 {
					Value = 200008,
					Num = 548,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 571,
				},
				 {
					Value = 200008,
					Num = 470,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 476,
				},
				 {
					Value = 200008,
					Num = 392,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 380,
				},
				 {
					Value = 200008,
					Num = 313,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 285,
				},
				 {
					Value = 200008,
					Num = 235,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 190,
				},
				 {
					Value = 200008,
					Num = 156,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 95,
				},
				 {
					Value = 200008,
					Num = 78,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id127] =
{
	Id = 127,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248202,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1101,
				},
				 {
					Value = 200005,
					Num = 907,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 979,
				},
				 {
					Value = 200005,
					Num = 806,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 856,
				},
				 {
					Value = 200005,
					Num = 705,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 734,
				},
				 {
					Value = 200005,
					Num = 604,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 612,
				},
				 {
					Value = 200005,
					Num = 504,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 489,
				},
				 {
					Value = 200005,
					Num = 403,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 367,
				},
				 {
					Value = 200005,
					Num = 302,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 244,
				},
				 {
					Value = 200005,
					Num = 201,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 122,
				},
				 {
					Value = 200005,
					Num = 100,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200005,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id128] =
{
	Id = 128,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248212,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1101,
				},
				 {
					Value = 200007,
					Num = 907,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 979,
				},
				 {
					Value = 200007,
					Num = 806,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 856,
				},
				 {
					Value = 200007,
					Num = 705,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 734,
				},
				 {
					Value = 200007,
					Num = 604,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 612,
				},
				 {
					Value = 200007,
					Num = 504,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 489,
				},
				 {
					Value = 200007,
					Num = 403,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 367,
				},
				 {
					Value = 200007,
					Num = 302,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 244,
				},
				 {
					Value = 200007,
					Num = 201,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 122,
				},
				 {
					Value = 200007,
					Num = 100,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id129] =
{
	Id = 129,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248222,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1101,
				},
				 {
					Value = 200008,
					Num = 907,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 979,
				},
				 {
					Value = 200008,
					Num = 806,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 856,
				},
				 {
					Value = 200008,
					Num = 705,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 734,
				},
				 {
					Value = 200008,
					Num = 604,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 612,
				},
				 {
					Value = 200008,
					Num = 504,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 489,
				},
				 {
					Value = 200008,
					Num = 403,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 367,
				},
				 {
					Value = 200008,
					Num = 302,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 244,
				},
				 {
					Value = 200008,
					Num = 201,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 122,
				},
				 {
					Value = 200008,
					Num = 100,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id130] =
{
	Id = 130,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248232,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1101,
				},
				 {
					Value = 200007,
					Num = 907,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 979,
				},
				 {
					Value = 200007,
					Num = 806,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 856,
				},
				 {
					Value = 200007,
					Num = 705,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 734,
				},
				 {
					Value = 200007,
					Num = 604,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 612,
				},
				 {
					Value = 200007,
					Num = 504,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 489,
				},
				 {
					Value = 200007,
					Num = 403,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 367,
				},
				 {
					Value = 200007,
					Num = 302,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 244,
				},
				 {
					Value = 200007,
					Num = 201,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 122,
				},
				 {
					Value = 200007,
					Num = 100,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id131] =
{
	Id = 131,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248242,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1101,
				},
				 {
					Value = 200008,
					Num = 907,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 979,
				},
				 {
					Value = 200008,
					Num = 806,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 856,
				},
				 {
					Value = 200008,
					Num = 705,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 734,
				},
				 {
					Value = 200008,
					Num = 604,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 612,
				},
				 {
					Value = 200008,
					Num = 504,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 489,
				},
				 {
					Value = 200008,
					Num = 403,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 367,
				},
				 {
					Value = 200008,
					Num = 302,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 244,
				},
				 {
					Value = 200008,
					Num = 201,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 122,
				},
				 {
					Value = 200008,
					Num = 100,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id132] =
{
	Id = 132,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248202,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1101,
				},
				 {
					Value = 200008,
					Num = 907,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 979,
				},
				 {
					Value = 200008,
					Num = 806,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 856,
				},
				 {
					Value = 200008,
					Num = 705,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 734,
				},
				 {
					Value = 200008,
					Num = 604,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 612,
				},
				 {
					Value = 200008,
					Num = 504,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 489,
				},
				 {
					Value = 200008,
					Num = 403,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 367,
				},
				 {
					Value = 200008,
					Num = 302,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 244,
				},
				 {
					Value = 200008,
					Num = 201,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 122,
				},
				 {
					Value = 200008,
					Num = 100,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id133] =
{
	Id = 133,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248203,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1346,
				},
				 {
					Value = 200005,
					Num = 1108,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1196,
				},
				 {
					Value = 200005,
					Num = 985,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1047,
				},
				 {
					Value = 200005,
					Num = 862,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 897,
				},
				 {
					Value = 200005,
					Num = 739,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 748,
				},
				 {
					Value = 200005,
					Num = 616,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 598,
				},
				 {
					Value = 200005,
					Num = 492,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 448,
				},
				 {
					Value = 200005,
					Num = 369,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 299,
				},
				 {
					Value = 200005,
					Num = 246,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 149,
				},
				 {
					Value = 200005,
					Num = 123,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200005,
					Num = -1,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id134] =
{
	Id = 134,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248213,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1346,
				},
				 {
					Value = 200007,
					Num = 1108,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1196,
				},
				 {
					Value = 200007,
					Num = 985,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1047,
				},
				 {
					Value = 200007,
					Num = 862,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 897,
				},
				 {
					Value = 200007,
					Num = 739,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 748,
				},
				 {
					Value = 200007,
					Num = 616,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 598,
				},
				 {
					Value = 200007,
					Num = 492,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 448,
				},
				 {
					Value = 200007,
					Num = 369,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 299,
				},
				 {
					Value = 200007,
					Num = 246,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 149,
				},
				 {
					Value = 200007,
					Num = 123,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = -1,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id135] =
{
	Id = 135,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248223,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1346,
				},
				 {
					Value = 200008,
					Num = 1108,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1196,
				},
				 {
					Value = 200008,
					Num = 985,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1047,
				},
				 {
					Value = 200008,
					Num = 862,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 897,
				},
				 {
					Value = 200008,
					Num = 739,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 748,
				},
				 {
					Value = 200008,
					Num = 616,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 598,
				},
				 {
					Value = 200008,
					Num = 492,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 448,
				},
				 {
					Value = 200008,
					Num = 369,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 299,
				},
				 {
					Value = 200008,
					Num = 246,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 149,
				},
				 {
					Value = 200008,
					Num = 123,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = -1,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id136] =
{
	Id = 136,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248233,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1346,
				},
				 {
					Value = 200007,
					Num = 1108,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1196,
				},
				 {
					Value = 200007,
					Num = 985,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1047,
				},
				 {
					Value = 200007,
					Num = 862,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 897,
				},
				 {
					Value = 200007,
					Num = 739,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 748,
				},
				 {
					Value = 200007,
					Num = 616,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 598,
				},
				 {
					Value = 200007,
					Num = 492,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 448,
				},
				 {
					Value = 200007,
					Num = 369,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 299,
				},
				 {
					Value = 200007,
					Num = 246,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 149,
				},
				 {
					Value = 200007,
					Num = 123,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = -1,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id137] =
{
	Id = 137,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248243,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1346,
				},
				 {
					Value = 200008,
					Num = 1108,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1196,
				},
				 {
					Value = 200008,
					Num = 985,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1047,
				},
				 {
					Value = 200008,
					Num = 862,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 897,
				},
				 {
					Value = 200008,
					Num = 739,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 748,
				},
				 {
					Value = 200008,
					Num = 616,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 598,
				},
				 {
					Value = 200008,
					Num = 492,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 448,
				},
				 {
					Value = 200008,
					Num = 369,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 299,
				},
				 {
					Value = 200008,
					Num = 246,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 149,
				},
				 {
					Value = 200008,
					Num = 123,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = -1,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id138] =
{
	Id = 138,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248203,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1346,
				},
				 {
					Value = 200008,
					Num = 1108,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1196,
				},
				 {
					Value = 200008,
					Num = 985,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1047,
				},
				 {
					Value = 200008,
					Num = 862,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 897,
				},
				 {
					Value = 200008,
					Num = 739,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 748,
				},
				 {
					Value = 200008,
					Num = 616,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 598,
				},
				 {
					Value = 200008,
					Num = 492,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 448,
				},
				 {
					Value = 200008,
					Num = 369,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 299,
				},
				 {
					Value = 200008,
					Num = 246,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 149,
				},
				 {
					Value = 200008,
					Num = 123,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = -1,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id139] =
{
	Id = 139,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248204,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1591,
				},
				 {
					Value = 200005,
					Num = 1310,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1414,
				},
				 {
					Value = 200005,
					Num = 1164,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1237,
				},
				 {
					Value = 200005,
					Num = 1019,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1060,
				},
				 {
					Value = 200005,
					Num = 873,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 884,
				},
				 {
					Value = 200005,
					Num = 728,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 707,
				},
				 {
					Value = 200005,
					Num = 582,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 530,
				},
				 {
					Value = 200005,
					Num = 436,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 353,
				},
				 {
					Value = 200005,
					Num = 291,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 176,
				},
				 {
					Value = 200005,
					Num = 145,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200005,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id140] =
{
	Id = 140,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248214,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1591,
				},
				 {
					Value = 200007,
					Num = 1310,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1414,
				},
				 {
					Value = 200007,
					Num = 1164,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1237,
				},
				 {
					Value = 200007,
					Num = 1019,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1060,
				},
				 {
					Value = 200007,
					Num = 873,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 884,
				},
				 {
					Value = 200007,
					Num = 728,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 707,
				},
				 {
					Value = 200007,
					Num = 582,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 530,
				},
				 {
					Value = 200007,
					Num = 436,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 353,
				},
				 {
					Value = 200007,
					Num = 291,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 176,
				},
				 {
					Value = 200007,
					Num = 145,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id141] =
{
	Id = 141,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248224,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1591,
				},
				 {
					Value = 200008,
					Num = 1310,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1414,
				},
				 {
					Value = 200008,
					Num = 1164,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1237,
				},
				 {
					Value = 200008,
					Num = 1019,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1060,
				},
				 {
					Value = 200008,
					Num = 873,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 884,
				},
				 {
					Value = 200008,
					Num = 728,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 707,
				},
				 {
					Value = 200008,
					Num = 582,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 530,
				},
				 {
					Value = 200008,
					Num = 436,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 353,
				},
				 {
					Value = 200008,
					Num = 291,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 176,
				},
				 {
					Value = 200008,
					Num = 145,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id142] =
{
	Id = 142,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248234,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1591,
				},
				 {
					Value = 200007,
					Num = 1310,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1414,
				},
				 {
					Value = 200007,
					Num = 1164,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1237,
				},
				 {
					Value = 200007,
					Num = 1019,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1060,
				},
				 {
					Value = 200007,
					Num = 873,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 884,
				},
				 {
					Value = 200007,
					Num = 728,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 707,
				},
				 {
					Value = 200007,
					Num = 582,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 530,
				},
				 {
					Value = 200007,
					Num = 436,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 353,
				},
				 {
					Value = 200007,
					Num = 291,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 176,
				},
				 {
					Value = 200007,
					Num = 145,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id143] =
{
	Id = 143,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248244,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1591,
				},
				 {
					Value = 200008,
					Num = 1310,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1414,
				},
				 {
					Value = 200008,
					Num = 1164,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1237,
				},
				 {
					Value = 200008,
					Num = 1019,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1060,
				},
				 {
					Value = 200008,
					Num = 873,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 884,
				},
				 {
					Value = 200008,
					Num = 728,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 707,
				},
				 {
					Value = 200008,
					Num = 582,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 530,
				},
				 {
					Value = 200008,
					Num = 436,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 353,
				},
				 {
					Value = 200008,
					Num = 291,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 176,
				},
				 {
					Value = 200008,
					Num = 145,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id144] =
{
	Id = 144,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248204,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1591,
				},
				 {
					Value = 200008,
					Num = 1310,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1414,
				},
				 {
					Value = 200008,
					Num = 1164,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1237,
				},
				 {
					Value = 200008,
					Num = 1019,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1060,
				},
				 {
					Value = 200008,
					Num = 873,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 884,
				},
				 {
					Value = 200008,
					Num = 728,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 707,
				},
				 {
					Value = 200008,
					Num = 582,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 530,
				},
				 {
					Value = 200008,
					Num = 436,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 353,
				},
				 {
					Value = 200008,
					Num = 291,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 176,
				},
				 {
					Value = 200008,
					Num = 145,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id145] =
{
	Id = 145,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248205,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1836,
				},
				 {
					Value = 200005,
					Num = 1512,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1632,
				},
				 {
					Value = 200005,
					Num = 1344,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1428,
				},
				 {
					Value = 200005,
					Num = 1176,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1224,
				},
				 {
					Value = 200005,
					Num = 1008,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1020,
				},
				 {
					Value = 200005,
					Num = 840,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 816,
				},
				 {
					Value = 200005,
					Num = 672,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 612,
				},
				 {
					Value = 200005,
					Num = 504,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 408,
				},
				 {
					Value = 200005,
					Num = 336,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 204,
				},
				 {
					Value = 200005,
					Num = 168,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200005,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id146] =
{
	Id = 146,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248215,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1836,
				},
				 {
					Value = 200007,
					Num = 1512,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1632,
				},
				 {
					Value = 200007,
					Num = 1344,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1428,
				},
				 {
					Value = 200007,
					Num = 1176,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1224,
				},
				 {
					Value = 200007,
					Num = 1008,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1020,
				},
				 {
					Value = 200007,
					Num = 840,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 816,
				},
				 {
					Value = 200007,
					Num = 672,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 612,
				},
				 {
					Value = 200007,
					Num = 504,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 408,
				},
				 {
					Value = 200007,
					Num = 336,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 204,
				},
				 {
					Value = 200007,
					Num = 168,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id147] =
{
	Id = 147,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248225,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1836,
				},
				 {
					Value = 200008,
					Num = 1512,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1632,
				},
				 {
					Value = 200008,
					Num = 1344,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1428,
				},
				 {
					Value = 200008,
					Num = 1176,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1224,
				},
				 {
					Value = 200008,
					Num = 1008,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1020,
				},
				 {
					Value = 200008,
					Num = 840,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 816,
				},
				 {
					Value = 200008,
					Num = 672,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 612,
				},
				 {
					Value = 200008,
					Num = 504,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 408,
				},
				 {
					Value = 200008,
					Num = 336,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 204,
				},
				 {
					Value = 200008,
					Num = 168,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id148] =
{
	Id = 148,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248235,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1836,
				},
				 {
					Value = 200007,
					Num = 1512,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1632,
				},
				 {
					Value = 200007,
					Num = 1344,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1428,
				},
				 {
					Value = 200007,
					Num = 1176,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1224,
				},
				 {
					Value = 200007,
					Num = 1008,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1020,
				},
				 {
					Value = 200007,
					Num = 840,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 816,
				},
				 {
					Value = 200007,
					Num = 672,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 612,
				},
				 {
					Value = 200007,
					Num = 504,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 408,
				},
				 {
					Value = 200007,
					Num = 336,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 204,
				},
				 {
					Value = 200007,
					Num = 168,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id149] =
{
	Id = 149,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248245,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1836,
				},
				 {
					Value = 200008,
					Num = 1512,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1632,
				},
				 {
					Value = 200008,
					Num = 1344,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1428,
				},
				 {
					Value = 200008,
					Num = 1176,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1224,
				},
				 {
					Value = 200008,
					Num = 1008,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1020,
				},
				 {
					Value = 200008,
					Num = 840,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 816,
				},
				 {
					Value = 200008,
					Num = 672,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 612,
				},
				 {
					Value = 200008,
					Num = 504,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 408,
				},
				 {
					Value = 200008,
					Num = 336,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 204,
				},
				 {
					Value = 200008,
					Num = 168,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id150] =
{
	Id = 150,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248205,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1836,
				},
				 {
					Value = 200008,
					Num = 1512,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1632,
				},
				 {
					Value = 200008,
					Num = 1344,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1428,
				},
				 {
					Value = 200008,
					Num = 1176,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1224,
				},
				 {
					Value = 200008,
					Num = 1008,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1020,
				},
				 {
					Value = 200008,
					Num = 840,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 816,
				},
				 {
					Value = 200008,
					Num = 672,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 612,
				},
				 {
					Value = 200008,
					Num = 504,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 408,
				},
				 {
					Value = 200008,
					Num = 336,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 204,
				},
				 {
					Value = 200008,
					Num = 168,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id151] =
{
	Id = 151,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248206,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2080,
				},
				 {
					Value = 200005,
					Num = 1713,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1849,
				},
				 {
					Value = 200005,
					Num = 1523,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1618,
				},
				 {
					Value = 200005,
					Num = 1332,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1387,
				},
				 {
					Value = 200005,
					Num = 1142,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1156,
				},
				 {
					Value = 200005,
					Num = 952,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 924,
				},
				 {
					Value = 200005,
					Num = 761,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 693,
				},
				 {
					Value = 200005,
					Num = 571,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 462,
				},
				 {
					Value = 200005,
					Num = 380,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 231,
				},
				 {
					Value = 200005,
					Num = 190,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200005,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id152] =
{
	Id = 152,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248216,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2080,
				},
				 {
					Value = 200007,
					Num = 1713,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1849,
				},
				 {
					Value = 200007,
					Num = 1523,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1618,
				},
				 {
					Value = 200007,
					Num = 1332,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1387,
				},
				 {
					Value = 200007,
					Num = 1142,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1156,
				},
				 {
					Value = 200007,
					Num = 952,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 924,
				},
				 {
					Value = 200007,
					Num = 761,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 693,
				},
				 {
					Value = 200007,
					Num = 571,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 462,
				},
				 {
					Value = 200007,
					Num = 380,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 231,
				},
				 {
					Value = 200007,
					Num = 190,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id153] =
{
	Id = 153,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248226,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2080,
				},
				 {
					Value = 200008,
					Num = 1713,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1849,
				},
				 {
					Value = 200008,
					Num = 1523,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1618,
				},
				 {
					Value = 200008,
					Num = 1332,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1387,
				},
				 {
					Value = 200008,
					Num = 1142,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1156,
				},
				 {
					Value = 200008,
					Num = 952,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 924,
				},
				 {
					Value = 200008,
					Num = 761,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 693,
				},
				 {
					Value = 200008,
					Num = 571,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 462,
				},
				 {
					Value = 200008,
					Num = 380,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 231,
				},
				 {
					Value = 200008,
					Num = 190,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id154] =
{
	Id = 154,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248236,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2080,
				},
				 {
					Value = 200007,
					Num = 1713,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1849,
				},
				 {
					Value = 200007,
					Num = 1523,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1618,
				},
				 {
					Value = 200007,
					Num = 1332,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1387,
				},
				 {
					Value = 200007,
					Num = 1142,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1156,
				},
				 {
					Value = 200007,
					Num = 952,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 924,
				},
				 {
					Value = 200007,
					Num = 761,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 693,
				},
				 {
					Value = 200007,
					Num = 571,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 462,
				},
				 {
					Value = 200007,
					Num = 380,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 231,
				},
				 {
					Value = 200007,
					Num = 190,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id155] =
{
	Id = 155,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248246,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2080,
				},
				 {
					Value = 200008,
					Num = 1713,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1849,
				},
				 {
					Value = 200008,
					Num = 1523,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1618,
				},
				 {
					Value = 200008,
					Num = 1332,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1387,
				},
				 {
					Value = 200008,
					Num = 1142,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1156,
				},
				 {
					Value = 200008,
					Num = 952,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 924,
				},
				 {
					Value = 200008,
					Num = 761,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 693,
				},
				 {
					Value = 200008,
					Num = 571,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 462,
				},
				 {
					Value = 200008,
					Num = 380,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 231,
				},
				 {
					Value = 200008,
					Num = 190,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id156] =
{
	Id = 156,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248206,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2080,
				},
				 {
					Value = 200008,
					Num = 1713,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1849,
				},
				 {
					Value = 200008,
					Num = 1523,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1618,
				},
				 {
					Value = 200008,
					Num = 1332,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1387,
				},
				 {
					Value = 200008,
					Num = 1142,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1156,
				},
				 {
					Value = 200008,
					Num = 952,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 924,
				},
				 {
					Value = 200008,
					Num = 761,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 693,
				},
				 {
					Value = 200008,
					Num = 571,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 462,
				},
				 {
					Value = 200008,
					Num = 380,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 231,
				},
				 {
					Value = 200008,
					Num = 190,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id157] =
{
	Id = 157,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248207,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2325,
				},
				 {
					Value = 200005,
					Num = 1915,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2067,
				},
				 {
					Value = 200005,
					Num = 1702,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1808,
				},
				 {
					Value = 200005,
					Num = 1489,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1550,
				},
				 {
					Value = 200005,
					Num = 1276,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1292,
				},
				 {
					Value = 200005,
					Num = 1064,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1033,
				},
				 {
					Value = 200005,
					Num = 851,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 775,
				},
				 {
					Value = 200005,
					Num = 638,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 516,
				},
				 {
					Value = 200005,
					Num = 425,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 258,
				},
				 {
					Value = 200005,
					Num = 212,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = -1,
				},
				 {
					Value = 200005,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id158] =
{
	Id = 158,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248217,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2325,
				},
				 {
					Value = 200007,
					Num = 1915,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2067,
				},
				 {
					Value = 200007,
					Num = 1702,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1808,
				},
				 {
					Value = 200007,
					Num = 1489,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1550,
				},
				 {
					Value = 200007,
					Num = 1276,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1292,
				},
				 {
					Value = 200007,
					Num = 1064,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1033,
				},
				 {
					Value = 200007,
					Num = 851,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 775,
				},
				 {
					Value = 200007,
					Num = 638,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 516,
				},
				 {
					Value = 200007,
					Num = 425,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 258,
				},
				 {
					Value = 200007,
					Num = 212,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = -1,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id159] =
{
	Id = 159,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248227,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2325,
				},
				 {
					Value = 200008,
					Num = 1915,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2067,
				},
				 {
					Value = 200008,
					Num = 1702,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1808,
				},
				 {
					Value = 200008,
					Num = 1489,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1550,
				},
				 {
					Value = 200008,
					Num = 1276,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1292,
				},
				 {
					Value = 200008,
					Num = 1064,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1033,
				},
				 {
					Value = 200008,
					Num = 851,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 775,
				},
				 {
					Value = 200008,
					Num = 638,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 516,
				},
				 {
					Value = 200008,
					Num = 425,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 258,
				},
				 {
					Value = 200008,
					Num = 212,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = -1,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id160] =
{
	Id = 160,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248237,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2325,
				},
				 {
					Value = 200007,
					Num = 1915,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2067,
				},
				 {
					Value = 200007,
					Num = 1702,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1808,
				},
				 {
					Value = 200007,
					Num = 1489,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1550,
				},
				 {
					Value = 200007,
					Num = 1276,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1292,
				},
				 {
					Value = 200007,
					Num = 1064,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1033,
				},
				 {
					Value = 200007,
					Num = 851,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 775,
				},
				 {
					Value = 200007,
					Num = 638,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 516,
				},
				 {
					Value = 200007,
					Num = 425,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 258,
				},
				 {
					Value = 200007,
					Num = 212,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = -1,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id161] =
{
	Id = 161,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248247,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2325,
				},
				 {
					Value = 200008,
					Num = 1915,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2067,
				},
				 {
					Value = 200008,
					Num = 1702,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1808,
				},
				 {
					Value = 200008,
					Num = 1489,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1550,
				},
				 {
					Value = 200008,
					Num = 1276,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1292,
				},
				 {
					Value = 200008,
					Num = 1064,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1033,
				},
				 {
					Value = 200008,
					Num = 851,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 775,
				},
				 {
					Value = 200008,
					Num = 638,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 516,
				},
				 {
					Value = 200008,
					Num = 425,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 258,
				},
				 {
					Value = 200008,
					Num = 212,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = -1,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id162] =
{
	Id = 162,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248207,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2325,
				},
				 {
					Value = 200008,
					Num = 1915,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2067,
				},
				 {
					Value = 200008,
					Num = 1702,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1808,
				},
				 {
					Value = 200008,
					Num = 1489,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1550,
				},
				 {
					Value = 200008,
					Num = 1276,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1292,
				},
				 {
					Value = 200008,
					Num = 1064,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1033,
				},
				 {
					Value = 200008,
					Num = 851,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 775,
				},
				 {
					Value = 200008,
					Num = 638,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 516,
				},
				 {
					Value = 200008,
					Num = 425,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 258,
				},
				 {
					Value = 200008,
					Num = 212,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200007,
					Num = -1,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id163] =
{
	Id = 163,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248208,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2570,
				},
				 {
					Value = 200005,
					Num = 2116,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2284,
				},
				 {
					Value = 200005,
					Num = 1881,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1999,
				},
				 {
					Value = 200005,
					Num = 1646,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1713,
				},
				 {
					Value = 200005,
					Num = 1411,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1428,
				},
				 {
					Value = 200005,
					Num = 1176,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1142,
				},
				 {
					Value = 200005,
					Num = 940,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 856,
				},
				 {
					Value = 200005,
					Num = 705,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 571,
				},
				 {
					Value = 200005,
					Num = 470,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 285,
				},
				 {
					Value = 200005,
					Num = 235,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200005,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id164] =
{
	Id = 164,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248218,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2570,
				},
				 {
					Value = 200007,
					Num = 2116,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2284,
				},
				 {
					Value = 200007,
					Num = 1881,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1999,
				},
				 {
					Value = 200007,
					Num = 1646,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1713,
				},
				 {
					Value = 200007,
					Num = 1411,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1428,
				},
				 {
					Value = 200007,
					Num = 1176,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1142,
				},
				 {
					Value = 200007,
					Num = 940,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 856,
				},
				 {
					Value = 200007,
					Num = 705,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 571,
				},
				 {
					Value = 200007,
					Num = 470,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 285,
				},
				 {
					Value = 200007,
					Num = 235,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id165] =
{
	Id = 165,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248228,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2570,
				},
				 {
					Value = 200008,
					Num = 2116,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2284,
				},
				 {
					Value = 200008,
					Num = 1881,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1999,
				},
				 {
					Value = 200008,
					Num = 1646,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1713,
				},
				 {
					Value = 200008,
					Num = 1411,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1428,
				},
				 {
					Value = 200008,
					Num = 1176,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1142,
				},
				 {
					Value = 200008,
					Num = 940,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 856,
				},
				 {
					Value = 200008,
					Num = 705,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 571,
				},
				 {
					Value = 200008,
					Num = 470,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 285,
				},
				 {
					Value = 200008,
					Num = 235,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id166] =
{
	Id = 166,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248238,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2570,
				},
				 {
					Value = 200007,
					Num = 2116,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2284,
				},
				 {
					Value = 200007,
					Num = 1881,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1999,
				},
				 {
					Value = 200007,
					Num = 1646,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1713,
				},
				 {
					Value = 200007,
					Num = 1411,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1428,
				},
				 {
					Value = 200007,
					Num = 1176,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1142,
				},
				 {
					Value = 200007,
					Num = 940,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 856,
				},
				 {
					Value = 200007,
					Num = 705,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 571,
				},
				 {
					Value = 200007,
					Num = 470,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 285,
				},
				 {
					Value = 200007,
					Num = 235,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id167] =
{
	Id = 167,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248248,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2570,
				},
				 {
					Value = 200008,
					Num = 2116,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2284,
				},
				 {
					Value = 200008,
					Num = 1881,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1999,
				},
				 {
					Value = 200008,
					Num = 1646,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1713,
				},
				 {
					Value = 200008,
					Num = 1411,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1428,
				},
				 {
					Value = 200008,
					Num = 1176,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1142,
				},
				 {
					Value = 200008,
					Num = 940,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 856,
				},
				 {
					Value = 200008,
					Num = 705,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 571,
				},
				 {
					Value = 200008,
					Num = 470,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 285,
				},
				 {
					Value = 200008,
					Num = 235,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id168] =
{
	Id = 168,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248208,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2570,
				},
				 {
					Value = 200008,
					Num = 2116,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2284,
				},
				 {
					Value = 200008,
					Num = 1881,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1999,
				},
				 {
					Value = 200008,
					Num = 1646,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1713,
				},
				 {
					Value = 200008,
					Num = 1411,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1428,
				},
				 {
					Value = 200008,
					Num = 1176,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1142,
				},
				 {
					Value = 200008,
					Num = 940,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 856,
				},
				 {
					Value = 200008,
					Num = 705,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 571,
				},
				 {
					Value = 200008,
					Num = 470,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 285,
				},
				 {
					Value = 200008,
					Num = 235,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id169] =
{
	Id = 169,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248209,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2815,
				},
				 {
					Value = 200005,
					Num = 2318,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2502,
				},
				 {
					Value = 200005,
					Num = 2060,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2189,
				},
				 {
					Value = 200005,
					Num = 1803,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1876,
				},
				 {
					Value = 200005,
					Num = 1545,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1564,
				},
				 {
					Value = 200005,
					Num = 1288,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1251,
				},
				 {
					Value = 200005,
					Num = 1030,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 938,
				},
				 {
					Value = 200005,
					Num = 772,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 625,
				},
				 {
					Value = 200005,
					Num = 515,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 312,
				},
				 {
					Value = 200005,
					Num = 257,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200005,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id170] =
{
	Id = 170,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248219,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2815,
				},
				 {
					Value = 200007,
					Num = 2318,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2502,
				},
				 {
					Value = 200007,
					Num = 2060,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2189,
				},
				 {
					Value = 200007,
					Num = 1803,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1876,
				},
				 {
					Value = 200007,
					Num = 1545,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1564,
				},
				 {
					Value = 200007,
					Num = 1288,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1251,
				},
				 {
					Value = 200007,
					Num = 1030,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 938,
				},
				 {
					Value = 200007,
					Num = 772,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 625,
				},
				 {
					Value = 200007,
					Num = 515,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 312,
				},
				 {
					Value = 200007,
					Num = 257,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id171] =
{
	Id = 171,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248229,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2815,
				},
				 {
					Value = 200008,
					Num = 2318,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2502,
				},
				 {
					Value = 200008,
					Num = 2060,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2189,
				},
				 {
					Value = 200008,
					Num = 1803,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1876,
				},
				 {
					Value = 200008,
					Num = 1545,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1564,
				},
				 {
					Value = 200008,
					Num = 1288,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1251,
				},
				 {
					Value = 200008,
					Num = 1030,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 938,
				},
				 {
					Value = 200008,
					Num = 772,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 625,
				},
				 {
					Value = 200008,
					Num = 515,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 312,
				},
				 {
					Value = 200008,
					Num = 257,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id172] =
{
	Id = 172,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248239,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2815,
				},
				 {
					Value = 200007,
					Num = 2318,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2502,
				},
				 {
					Value = 200007,
					Num = 2060,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2189,
				},
				 {
					Value = 200007,
					Num = 1803,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1876,
				},
				 {
					Value = 200007,
					Num = 1545,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1564,
				},
				 {
					Value = 200007,
					Num = 1288,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1251,
				},
				 {
					Value = 200007,
					Num = 1030,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 938,
				},
				 {
					Value = 200007,
					Num = 772,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 625,
				},
				 {
					Value = 200007,
					Num = 515,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 312,
				},
				 {
					Value = 200007,
					Num = 257,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id173] =
{
	Id = 173,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248249,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2815,
				},
				 {
					Value = 200008,
					Num = 2318,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2502,
				},
				 {
					Value = 200008,
					Num = 2060,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2189,
				},
				 {
					Value = 200008,
					Num = 1803,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1876,
				},
				 {
					Value = 200008,
					Num = 1545,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1564,
				},
				 {
					Value = 200008,
					Num = 1288,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1251,
				},
				 {
					Value = 200008,
					Num = 1030,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 938,
				},
				 {
					Value = 200008,
					Num = 772,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 625,
				},
				 {
					Value = 200008,
					Num = 515,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 312,
				},
				 {
					Value = 200008,
					Num = 257,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id174] =
{
	Id = 174,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248209,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2815,
				},
				 {
					Value = 200008,
					Num = 2318,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2502,
				},
				 {
					Value = 200008,
					Num = 2060,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2189,
				},
				 {
					Value = 200008,
					Num = 1803,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1876,
				},
				 {
					Value = 200008,
					Num = 1545,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1564,
				},
				 {
					Value = 200008,
					Num = 1288,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1251,
				},
				 {
					Value = 200008,
					Num = 1030,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 938,
				},
				 {
					Value = 200008,
					Num = 772,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 625,
				},
				 {
					Value = 200008,
					Num = 515,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 312,
				},
				 {
					Value = 200008,
					Num = 257,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id175] =
{
	Id = 175,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248210,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 3060,
				},
				 {
					Value = 200005,
					Num = 2520,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2720,
				},
				 {
					Value = 200005,
					Num = 2240,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2380,
				},
				 {
					Value = 200005,
					Num = 1960,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2040,
				},
				 {
					Value = 200005,
					Num = 1680,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1700,
				},
				 {
					Value = 200005,
					Num = 1400,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1360,
				},
				 {
					Value = 200005,
					Num = 1120,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1020,
				},
				 {
					Value = 200005,
					Num = 840,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 680,
				},
				 {
					Value = 200005,
					Num = 560,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 340,
				},
				 {
					Value = 200005,
					Num = 280,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200005,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id176] =
{
	Id = 176,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248220,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 3060,
				},
				 {
					Value = 200007,
					Num = 2520,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2720,
				},
				 {
					Value = 200007,
					Num = 2240,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2380,
				},
				 {
					Value = 200007,
					Num = 1960,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2040,
				},
				 {
					Value = 200007,
					Num = 1680,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1700,
				},
				 {
					Value = 200007,
					Num = 1400,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1360,
				},
				 {
					Value = 200007,
					Num = 1120,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1020,
				},
				 {
					Value = 200007,
					Num = 840,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 680,
				},
				 {
					Value = 200007,
					Num = 560,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 340,
				},
				 {
					Value = 200007,
					Num = 280,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id177] =
{
	Id = 177,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248230,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 3060,
				},
				 {
					Value = 200008,
					Num = 2520,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2720,
				},
				 {
					Value = 200008,
					Num = 2240,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2380,
				},
				 {
					Value = 200008,
					Num = 1960,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2040,
				},
				 {
					Value = 200008,
					Num = 1680,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1700,
				},
				 {
					Value = 200008,
					Num = 1400,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1360,
				},
				 {
					Value = 200008,
					Num = 1120,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1020,
				},
				 {
					Value = 200008,
					Num = 840,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 680,
				},
				 {
					Value = 200008,
					Num = 560,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 340,
				},
				 {
					Value = 200008,
					Num = 280,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id178] =
{
	Id = 178,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248240,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 3060,
				},
				 {
					Value = 200007,
					Num = 2520,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2720,
				},
				 {
					Value = 200007,
					Num = 2240,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2380,
				},
				 {
					Value = 200007,
					Num = 1960,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2040,
				},
				 {
					Value = 200007,
					Num = 1680,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1700,
				},
				 {
					Value = 200007,
					Num = 1400,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1360,
				},
				 {
					Value = 200007,
					Num = 1120,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1020,
				},
				 {
					Value = 200007,
					Num = 840,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 680,
				},
				 {
					Value = 200007,
					Num = 560,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 340,
				},
				 {
					Value = 200007,
					Num = 280,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200007,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id179] =
{
	Id = 179,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248250,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 3060,
				},
				 {
					Value = 200008,
					Num = 2520,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2720,
				},
				 {
					Value = 200008,
					Num = 2240,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2380,
				},
				 {
					Value = 200008,
					Num = 1960,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 2040,
				},
				 {
					Value = 200008,
					Num = 1680,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1700,
				},
				 {
					Value = 200008,
					Num = 1400,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1360,
				},
				 {
					Value = 200008,
					Num = 1120,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1020,
				},
				 {
					Value = 200008,
					Num = 840,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 680,
				},
				 {
					Value = 200008,
					Num = 560,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 340,
				},
				 {
					Value = 200008,
					Num = 280,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
SpaceTravelChatConfig[SpaceTravelChatID.Id180] =
{
	Id = 180,
	Name = "与海盗谈判",
	Desc = "副本怪物被击杀算不算工伤",
	Enemy = 248210,
	NumCap = 5,
	ChatList = {
		{
			Success = 100,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 3060,
				},
				 {
					Value = 200008,
					Num = 2520,
				},
			},
		},
		{
			Success = 90,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2720,
				},
				 {
					Value = 200008,
					Num = 2240,
				},
			},
		},
		{
			Success = 80,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2380,
				},
				 {
					Value = 200008,
					Num = 1960,
				},
			},
		},
		{
			Success = 70,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2040,
				},
				 {
					Value = 200008,
					Num = 1680,
				},
			},
		},
		{
			Success = 60,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1700,
				},
				 {
					Value = 200008,
					Num = 1400,
				},
			},
		},
		{
			Success = 50,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1360,
				},
				 {
					Value = 200008,
					Num = 1120,
				},
			},
		},
		{
			Success = 40,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1020,
				},
				 {
					Value = 200008,
					Num = 840,
				},
			},
		},
		{
			Success = 30,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 680,
				},
				 {
					Value = 200008,
					Num = 560,
				},
			},
		},
		{
			Success = 20,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 340,
				},
				 {
					Value = 200008,
					Num = 280,
				},
			},
		},
		{
			Success = 10,
			NeedAttribute = {
				{
					Value = 200007,
					Num = 0,
				},
				 {
					Value = 200008,
					Num = 0,
				},
			},
		},
	},
}
