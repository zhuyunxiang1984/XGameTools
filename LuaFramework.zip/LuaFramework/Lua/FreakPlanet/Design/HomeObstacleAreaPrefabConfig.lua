---------------------
---这个lua为自动导出配置
---------------------



HomeObstacleAreaPrefabConfig = {}

HomeObstacleAreaPrefabConfig["Area1"] = 
{
	ContainRegions = 
	{
		{ plane = "Ground", x = 49, y = 0, w = 24, h = 30, },
	},
	ObstacleGroups = 
	{
		["Area1_Part1"] = 
		{
			Region = { plane = "Ground", x = 49, y = 23, w = 1, h = 7, },
			Obstacles = 
			{
				["Area1_Part1_Props1"] = "Area1_Part1_Props1",
			},
		},
		["Area1_Part2"] = 
		{
			Region = { plane = "Ground", x = 50, y = 21, w = 8, h = 9, },
			Obstacles = 
			{
				["Area1_Part2_Props1"] = "Area1_Part2_Props1",
				["Area1_Part2_Props2"] = "Area1_Part2_Props1/Area1_Part2_Props2",
				["Area1_Part2_Props3"] = "Area1_Part2_Props1/Area1_Part2_Props3",
			},
		},
		["Area1_Part3"] = 
		{
			Region = { plane = "Ground", x = 60, y = 20, w = 13, h = 10, },
			Obstacles = 
			{
				["Area1_Part3_Props1"] = "Area1_Part3_Props1",
				["Area1_Part3_Props2"] = "Area1_Part3_Props1/Area1_Part3_Props2",
				["Area1_Part3_Props3"] = "Area1_Part3_Props1/Area1_Part3_Props3",
				["Area1_Part3_Props4"] = "Area1_Part3_Props1/Area1_Part3_Props4",
			},
		},
		["Area1_Part4"] = 
		{
			Region = { plane = "Ground", x = 49, y = 0, w = 5, h = 17, },
			Obstacles = 
			{
				["Area1_Part4_Props1"] = "Area1_Part4_Props1",
				["Area1_Part4_Props2"] = "Area1_Part4_Props2",
				["Area1_Part4_Props3"] = "Area1_Part4_Props3",
				["Area1_Part4_Props4"] = "Area1_Part4_Props4",
				["Area1_Part4_Props5"] = "Area1_Part4_Props4/Area1_Part4_Props5",
				["Area1_Part4_Props6"] = "Area1_Part4_Props4/Area1_Part4_Props6",
				["Area1_Part4_Props7"] = "Area1_Part4_Props4/Area1_Part4_Props7",
				["Area1_Part4_Props8"] = "Area1_Part4_Props4/Area1_Part4_Props8",
			},
		},
		["Area1_Part5"] = 
		{
			Region = { plane = "Ground", x = 54, y = 14, w = 6, h = 6, },
			Obstacles = 
			{
				["Area1_Part5_Props1"] = "Area1_Part5_Props1",
			},
		},
		["Area1_Part6"] = 
		{
			Region = { plane = "Ground", x = 62, y = 16, w = 5, h = 4, },
			Obstacles = 
			{
				["Area1_Part6_Props1"] = "Area1_Part6_Props1",
			},
		},
		["Area1_Part9"] = 
		{
			Region = { plane = "Ground", x = 54, y = 4, w = 6, h = 6, },
			Obstacles = 
			{
				["Area1_Part9_Props1"] = "Area1_Part9_Props1",
			},
		},
		["Area1_Part10"] = 
		{
			Region = { plane = "Ground", x = 54, y = 0, w = 4, h = 4, },
			Obstacles = 
			{
				["Area1_Part10_Props1"] = "Area1_Part10_Props1",
			},
		},
		["Area1_Part11"] = 
		{
			Region = { plane = "Ground", x = 69, y = 12, w = 4, h = 5, },
			Obstacles = 
			{
				["Area1_Part11_Props1"] = "Area1_Part11_Props1",
			},
		},
		["Area1_Part12"] = 
		{
			Region = { plane = "Ground", x = 58, y = 0, w = 3, h = 3, },
			Obstacles = 
			{
				["Area1_Part12_Props1"] = "Area1_Part12_Props1",
			},
		},
		["Area1_Part13"] = 
		{
			Region = { plane = "Ground", x = 61, y = 0, w = 12, h = 12, },
			Obstacles = 
			{
				["Area1_Part13_Props1"] = "Area1_Part13_Props1",
				["Area1_Part13_Props2"] = "Area1_Part13_Props1/Area1_Part13_Props2",
				["Area1_Part13_Props3"] = "Area1_Part13_Props1/Area1_Part13_Props3",
				["Area1_Part13_Props4"] = "Area1_Part13_Props1/Area1_Part13_Props4",
				["Area1_Part13_Props5"] = "Area1_Part13_Props1/Area1_Part13_Props4/Area1_Part13_Props5",
				["Area1_Part13_Props6"] = "Area1_Part13_Props1/Area1_Part13_Props6",
			},
		},
	},
}
HomeObstacleAreaPrefabConfig["Area2"] = 
{
	ContainRegions = 
	{
		{ plane = "Ground", x = 49, y = 30, w = 24, h = 24, },
	},
	ObstacleGroups = 
	{
		["Area2_Part1"] = 
		{
			Region = { plane = "Ground", x = 49, y = 52, w = 17, h = 2, },
			Obstacles = 
			{
				["Area2_Part1_Props1"] = "Area2_Part1_Props1",
			},
		},
		["Area2_Part2"] = 
		{
			Region = { plane = "Ground", x = 49, y = 35, w = 2, h = 17, },
			Obstacles = 
			{
				["Area2_Part2_Props1"] = "Area2_Part2_Props1",
			},
		},
		["Area2_Part3"] = 
		{
			Region = { plane = "Ground", x = 51, y = 42, w = 5, h = 10, },
			Obstacles = 
			{
				["Area2_Part3_Props1"] = "Area2_Part3_Props1",
			},
		},
		["Area2_Part4"] = 
		{
			Region = { plane = "Ground", x = 66, y = 53, w = 7, h = 1, },
			Obstacles = 
			{
				["Area2_Part4_Props1"] = "Area2_Part4_Props1",
			},
		},
		["Area2_Part5"] = 
		{
			Region = { plane = "Ground", x = 56, y = 46, w = 10, h = 6, },
			Obstacles = 
			{
				["Area2_Part5_Props1"] = "Area2_Part5_Props1",
				["Area2_Part5_Props2"] = "Area2_Part5_Props1/Area2_Part5_Props2",
				["Area2_Part5_Props3"] = "Area2_Part5_Props1/Area2_Part5_Props3",
			},
		},
		["Area2_Part6"] = 
		{
			Region = { plane = "Ground", x = 66, y = 46, w = 6, h = 7, },
			Obstacles = 
			{
				["Area2_Part6_Props1"] = "Area2_Part6_Props1",
				["Area2_Part6_Props2"] = "Area2_Part6_Props1/Area2_Part6_Props2",
			},
		},
		["Area2_Part7"] = 
		{
			Region = { plane = "Ground", x = 51, y = 32, w = 5, h = 10, },
			Obstacles = 
			{
				["Area2_Part7_Props1"] = "Area2_Part7_Props1",
			},
		},
		["Area2_Part8"] = 
		{
			Region = { plane = "Ground", x = 61, y = 41, w = 4, h = 5, },
			Obstacles = 
			{
				["Area2_Part8_Props1"] = "Area2_Part8_Props1",
			},
		},
		["Area2_Part9"] = 
		{
			Region = { plane = "Ground", x = 65, y = 37, w = 8, h = 8, },
			Obstacles = 
			{
				["Area2_Part9_Props1"] = "Area2_Part9_Props1",
				["Area2_Part9_Props2"] = "Area2_Part9_Props1/Area2_Part9_Props2",
			},
		},
		["Area2_Part10"] = 
		{
			Region = { plane = "Ground", x = 56, y = 40, w = 4, h = 6, },
			Obstacles = 
			{
				["Area2_Part10_Props1"] = "Area2_Part10_Props1",
			},
		},
		["Area2_Part11"] = 
		{
			Region = { plane = "Ground", x = 56, y = 32, w = 3, h = 3, },
			Obstacles = 
			{
				["Area2_Part11_Props1"] = "Area2_Part11_Props1",
			},
		},
		["Area2_Part12"] = 
		{
			Region = { plane = "Ground", x = 59, y = 32, w = 3, h = 3, },
			Obstacles = 
			{
				["Area2_Part12_Props1"] = "Area2_Part12_Props1",
			},
		},
		["Area2_Part13"] = 
		{
			Region = { plane = "Ground", x = 62, y = 32, w = 4, h = 4, },
			Obstacles = 
			{
				["Area2_Part13_Props1"] = "Area2_Part13_Props1",
			},
		},
		["Area2_Part14"] = 
		{
			Region = { plane = "Ground", x = 66, y = 32, w = 3, h = 3, },
			Obstacles = 
			{
				["Area2_Part14_Props1"] = "Area2_Part14_Props1",
			},
		},
		["Area2_Part15"] = 
		{
			Region = { plane = "Ground", x = 69, y = 32, w = 3, h = 3, },
			Obstacles = 
			{
				["Area2_Part15_Props1"] = "Area2_Part15_Props1",
			},
		},
		["Area2_Part16"] = 
		{
			Region = { plane = "Ground", x = 55, y = 30, w = 18, h = 2, },
			Obstacles = 
			{
				["Area2_Part16_Props1"] = "Area2_Part16_Props1",
			},
		},
	},
}
HomeObstacleAreaPrefabConfig["Area3"] = 
{
	ContainRegions = 
	{
		{ plane = "Ground", x = 47, y = 54, w = 26, h = 22, },
		{ plane = "Wall2", x = 29, y = 0, w = 26, h = 20, },
	},
	ObstacleGroups = 
	{
		["Area3_Part1"] = 
		{
			Region = { plane = "Ground", x = 47, y = 59, w = 2, h = 17, },
			Obstacles = 
			{
				["Area3_Part1_Props1"] = "Area3_Part1_Props1",
			},
		},
		["Area3_Part2"] = 
		{
			Region = { plane = "Ground", x = 64, y = 73, w = 8, h = 3, },
			Obstacles = 
			{
				["Area3_Part2_Props1"] = "Area3_Part2_Props1",
			},
		},
		["Area3_Part3"] = 
		{
			Region = { plane = "Ground", x = 49, y = 71, w = 10, h = 5, },
			Obstacles = 
			{
				["Area3_Part3_Props1"] = "Area3_Part3_Props1",
				["Area3_Part3_Props2"] = "Area3_Part3_Props1/Area3_Part3_Props2",
				["Area3_Part3_Props3"] = "Area3_Part3_Props1/Area3_Part3_Props2/Area3_Part3_Props3",
				["Area3_Part3_Props4"] = "Area3_Part3_Props1/Area3_Part3_Props2/Area3_Part3_Props3/Area3_Part3_Props4",
				["Area3_Part3_Props5"] = "Area3_Part3_Props1/Area3_Part3_Props2/Area3_Part3_Props3/Area3_Part3_Props4/Area3_Part3_Props5",
				["Area3_Part3_Props6"] = "Area3_Part3_Props1/Area3_Part3_Props2/Area3_Part3_Props6",
			},
		},
		["Area3_Part4"] = 
		{
			Region = { plane = "Ground", x = 49, y = 65, w = 6, h = 6, },
			Obstacles = 
			{
				["Area3_Part4_Props1"] = "Area3_Part4_Props1",
			},
		},
		["Area3_Part5"] = 
		{
			Region = { plane = "Ground", x = 56, y = 58, w = 16, h = 13, },
			Obstacles = 
			{
				["Area3_Part5_Props1"] = "Area3_Part5_Props1",
				["Area3_Part5_Props2"] = "Area3_Part5_Props1/Area3_Part5_Props2",
				["Area3_Part5_Props3"] = "Area3_Part5_Props1/Area3_Part5_Props3",
				["Area3_Part5_Props4"] = "Area3_Part5_Props1/Area3_Part5_Props4",
				["Area3_Part5_Props5"] = "Area3_Part5_Props1/Area3_Part5_Props4/Area3_Part5_Props5",
				["Area3_Part5_Props6"] = "Area3_Part5_Props1/Area3_Part5_Props4/Area3_Part5_Props6",
			},
		},
		["Area3_Part6"] = 
		{
			Region = { plane = "Ground", x = 49, y = 54, w = 3, h = 3, },
			Obstacles = 
			{
				["Area3_Part6_Props1"] = "Area3_Part6_Props1",
			},
		},
		["Area3_Part7"] = 
		{
			Region = { plane = "Ground", x = 52, y = 54, w = 3, h = 3, },
			Obstacles = 
			{
				["Area3_Part7_Props1"] = "Area3_Part7_Props1",
			},
		},
		["Area3_Part8"] = 
		{
			Region = { plane = "Ground", x = 55, y = 54, w = 4, h = 4, },
			Obstacles = 
			{
				["Area3_Part8_Props1"] = "Area3_Part8_Props1",
			},
		},
		["Area3_Part9"] = 
		{
			Region = { plane = "Ground", x = 59, y = 54, w = 3, h = 3, },
			Obstacles = 
			{
				["Area3_Part9_Props1"] = "Area3_Part9_Props1",
			},
		},
		["Area3_Part10"] = 
		{
			Region = { plane = "Ground", x = 62, y = 54, w = 3, h = 3, },
			Obstacles = 
			{
				["Area3_Part10_Props1"] = "Area3_Part10_Props1",
			},
		},
	},
}
HomeObstacleAreaPrefabConfig["Area4"] = 
{
	ContainRegions = 
	{
		{ plane = "Ground", x = 27, y = 53, w = 20, h = 23, },
		{ plane = "Wall2", x = 9, y = 0, w = 20, h = 20, },
	},
	ObstacleGroups = 
	{
		["Area4_Part1"] = 
		{
			Region = { plane = "Ground", x = 27, y = 59, w = 2, h = 17, },
			Obstacles = 
			{
				["Area4_Part1_Props1"] = "Area4_Part1_Props1",
			},
		},
		["Area4_Part2"] = 
		{
			Region = { plane = "Ground", x = 29, y = 71, w = 10, h = 5, },
			Obstacles = 
			{
				["Area4_Part2_Props1"] = "Area4_Part2_Props1",
			},
		},
		["Area4_Part3"] = 
		{
			Region = { plane = "Ground", x = 29, y = 58, w = 16, h = 13, },
			Obstacles = 
			{
				["Area4_Part3_Props1"] = "Area4_Part3_Props1",
				["Area4_Part3_Props2"] = "Area4_Part3_Props1/Area4_Part3_Props2",
				["Area4_Part3_Props3"] = "Area4_Part3_Props1/Area4_Part3_Props3",
				["Area4_Part3_Props4"] = "Area4_Part3_Props1/Area4_Part3_Props4",
				["Area4_Part3_Props5"] = "Area4_Part3_Props1/Area4_Part3_Props4/Area4_Part3_Props5",
				["Area4_Part3_Props6"] = "Area4_Part3_Props1/Area4_Part3_Props4/Area4_Part3_Props6",
			},
		},
		["Area4_Part4"] = 
		{
			Region = { plane = "Ground", x = 29, y = 53, w = 10, h = 5, },
			Obstacles = 
			{
				["Area4_Part4_Props1"] = "Area4_Part4_Props1",
			},
		},
	},
}
HomeObstacleAreaPrefabConfig["Area5"] = 
{
	ContainRegions = 
	{
		{ plane = "Ground", x = 24, y = 26, w = 25, h = 27, },
	},
	ObstacleGroups = 
	{
		["Area5_Part1"] = 
		{
			Region = { plane = "Ground", x = 24, y = 51, w = 10, h = 2, },
			Obstacles = 
			{
				["Area5_Part1_Props1"] = "Area5_Part1_Props1",
			},
		},
		["Area5_Part2"] = 
		{
			Region = { plane = "Ground", x = 24, y = 34, w = 2, h = 17, },
			Obstacles = 
			{
				["Area5_Part2_Props1"] = "Area5_Part2_Props1",
			},
		},
		["Area5_Part3"] = 
		{
			Region = { plane = "Ground", x = 26, y = 35, w = 6, h = 8, },
			Obstacles = 
			{
				["Area5_Part3_Props1"] = "Area5_Part3_Props1",
			},
		},
		["Area5_Part4"] = 
		{
			Region = { plane = "Ground", x = 34, y = 48, w = 10, h = 5, },
			Obstacles = 
			{
				["Area5_Part4_Props1"] = "Area5_Part4_Props1",
				["Area5_Part4_Props2"] = "Area5_Part4_Props1/Area5_Part4_Props2",
				["Area5_Part4_Props3"] = "Area5_Part4_Props1/Area5_Part4_Props2/Area5_Part4_Props3",
				["Area5_Part4_Props4"] = "Area5_Part4_Props1/Area5_Part4_Props2/Area5_Part4_Props3/Area5_Part4_Props4",
				["Area5_Part4_Props5"] = "Area5_Part4_Props1/Area5_Part4_Props2/Area5_Part4_Props3/Area5_Part4_Props4/Area5_Part4_Props5",
				["Area5_Part4_Props6"] = "Area5_Part4_Props1/Area5_Part4_Props2/Area5_Part4_Props6",
			},
		},
		["Area5_Part5"] = 
		{
			Region = { plane = "Ground", x = 26, y = 43, w = 6, h = 8, },
			Obstacles = 
			{
				["Area5_Part5_Props1"] = "Area5_Part5_Props1",
			},
		},
		["Area5_Part6"] = 
		{
			Region = { plane = "Ground", x = 33, y = 33, w = 15, h = 15, },
			Obstacles = 
			{
				["Area5_Part6_Props1"] = "Area5_Part6_Props1",
				["Area5_Part6_Props2"] = "Area5_Part6_Props1/Area5_Part6_Props2",
				["Area5_Part6_Props3"] = "Area5_Part6_Props1/Area5_Part6_Props3",
				["Area5_Part6_Props4"] = "Area5_Part6_Props1/Area5_Part6_Props4",
				["Area5_Part6_Props5"] = "Area5_Part6_Props1/Area5_Part6_Props5",
				["Area5_Part6_Props6"] = "Area5_Part6_Props1/Area5_Part6_Props5/Area5_Part6_Props6",
				["Area5_Part6_Props7"] = "Area5_Part6_Props1/Area5_Part6_Props5/Area5_Part6_Props6/Area5_Part6_Props7",
				["Area5_Part6_Props8"] = "Area5_Part6_Props1/Area5_Part6_Props8",
				["Area5_Part6_Props9"] = "Area5_Part6_Props1/Area5_Part6_Props9",
				["Area5_Part6_Props10"] = "Area5_Part6_Props1/Area5_Part6_Props10",
				["Area5_Part6_Props11"] = "Area5_Part6_Props1/Area5_Part6_Props11",
			},
		},
		["Area5_Part7"] = 
		{
			Region = { plane = "Ground", x = 27, y = 26, w = 10, h = 5, },
			Obstacles = 
			{
				["Area5_Part7_Props1"] = "Area5_Part7_Props1",
				["Area5_Part7_Props2"] = "Area5_Part7_Props1/Area5_Part7_Props2",
				["Area5_Part7_Props3"] = "Area5_Part7_Props1/Area5_Part7_Props2/Area5_Part7_Props3",
				["Area5_Part7_Props4"] = "Area5_Part7_Props1/Area5_Part7_Props2/Area5_Part7_Props3/Area5_Part7_Props4",
				["Area5_Part7_Props5"] = "Area5_Part7_Props1/Area5_Part7_Props2/Area5_Part7_Props3/Area5_Part7_Props4/Area5_Part7_Props5",
				["Area5_Part7_Props6"] = "Area5_Part7_Props1/Area5_Part7_Props2/Area5_Part7_Props6",
			},
		},
	},
}
HomeObstacleAreaPrefabConfig["Area6"] = 
{
	ContainRegions = 
	{
		{ plane = "Ground", x = 27, y = 0, w = 22, h = 26, },
	},
	ObstacleGroups = 
	{
		["Area6_Part1"] = 
		{
			Region = { plane = "Ground", x = 27, y = 9, w = 2, h = 17, },
			Obstacles = 
			{
				["Area6_Part1_Props1"] = "Area6_Part1_Props1",
			},
		},
		["Area6_Part2"] = 
		{
			Region = { plane = "Ground", x = 29, y = 24, w = 18, h = 2, },
			Obstacles = 
			{
				["Area6_Part2_Props1"] = "Area6_Part2_Props1",
			},
		},
		["Area6_Part3"] = 
		{
			Region = { plane = "Ground", x = 27, y = 2, w = 1, h = 7, },
			Obstacles = 
			{
				["Area6_Part3_Props1"] = "Area6_Part3_Props1",
			},
		},
		["Area6_Part4"] = 
		{
			Region = { plane = "Ground", x = 29, y = 12, w = 4, h = 4, },
			Obstacles = 
			{
				["Area6_Part4_Props1"] = "Area6_Part4_Props1",
			},
		},
		["Area6_Part5"] = 
		{
			Region = { plane = "Ground", x = 28, y = 2, w = 5, h = 10, },
			Obstacles = 
			{
				["Area6_Part5_Props1"] = "Area6_Part5_Props1",
			},
		},
		["Area6_Part6"] = 
		{
			Region = { plane = "Ground", x = 29, y = 16, w = 8, h = 8, },
			Obstacles = 
			{
				["Area6_Part6_Props1"] = "Area6_Part6_Props1",
				["Area6_Part6_Props2"] = "Area6_Part6_Props1/Area6_Part6_Props2",
				["Area6_Part6_Props3"] = "Area6_Part6_Props1/Area6_Part6_Props3",
			},
		},
		["Area6_Part7"] = 
		{
			Region = { plane = "Ground", x = 38, y = 13, w = 11, h = 11, },
			Obstacles = 
			{
				["Area6_Part7_Props1"] = "Area6_Part7_Props1",
				["Area6_Part7_Props2"] = "Area6_Part7_Props1/Area6_Part7_Props2",
			},
		},
		["Area6_Part8"] = 
		{
			Region = { plane = "Ground", x = 34, y = 9, w = 4, h = 4, },
			Obstacles = 
			{
				["Area6_Part8_Props1"] = "Area6_Part8_Props1",
			},
		},
		["Area6_Part9"] = 
		{
			Region = { plane = "Ground", x = 39, y = 2, w = 9, h = 12, },
			Obstacles = 
			{
				["Area6_Part9_Props1"] = "Area6_Part9_Props1",
				["Area6_Part9_Props2"] = "Area6_Part9_Props1/Area6_Part9_Props2",
			},
		},
		["Area6_Part10"] = 
		{
			Region = { plane = "Ground", x = 27, y = 0, w = 18, h = 2, },
			Obstacles = 
			{
				["Area6_Part10_Props1"] = "Area6_Part10_Props1",
			},
		},
	},
}
HomeObstacleAreaPrefabConfig["Area7"] = 
{
	ContainRegions = 
	{
	},
	ObstacleGroups = 
	{
		["Area7_Part1"] = 
		{
			Obstacles = 
			{
				["Area7_Part1_Props1"] = "Area7_Part1_Props1",
				["Area7_Part1_Props2"] = "Area7_Part1_Props2",
			},
		},
		["Area7_Part2"] = 
		{
			Obstacles = 
			{
				["Area7_Part2_Props1"] = "Area7_Part2_Props1",
				["Area7_Part2_Props2"] = "Area7_Part2_Props1/Area7_Part2_Props2",
				["Area7_Part2_Props3"] = "Area7_Part2_Props1/Area7_Part2_Props2/Area7_Part2_Props3",
				["Area7_Part2_Props4"] = "Area7_Part2_Props1/Area7_Part2_Props2/Area7_Part2_Props3/Area7_Part2_Props4",
				["Area7_Part2_Props5"] = "Area7_Part2_Props1/Area7_Part2_Props2/Area7_Part2_Props3/Area7_Part2_Props4/Area7_Part2_Props5",
				["Area7_Part2_Props6"] = "Area7_Part2_Props1/Area7_Part2_Props2/Area7_Part2_Props6",
			},
		},
		["Area7_Part3"] = 
		{
			Obstacles = 
			{
				["Area7_Part3_Props1"] = "Area7_Part3_Props1",
			},
		},
		["Area7_Part4"] = 
		{
			Obstacles = 
			{
				["Area7_Part4_Props1"] = "Area7_Part4_Props1",
			},
		},
		["Area7_Part5"] = 
		{
			Obstacles = 
			{
				["Area7_Part5_Props1"] = "Area7_Part5_Props1",
				["Area7_Part5_Props2"] = "Area7_Part5_Props1/Area7_Part5_Props2",
				["Area7_Part5_Props3"] = "Area7_Part5_Props1/Area7_Part5_Props2/Area7_Part5_Props3",
				["Area7_Part5_Props4"] = "Area7_Part5_Props1/Area7_Part5_Props4",
			},
		},
		["Area7_Part6"] = 
		{
			Obstacles = 
			{
				["Area7_Part6_Props1"] = "Area7_Part6_Props1",
			},
		},
	},
}
HomeObstacleAreaPrefabConfig["Area8"] = 
{
	ContainRegions = 
	{
		{ plane = "Ground", x = 0, y = 53, w = 27, h = 23, },
		{ plane = "Wall1", x = 50, y = 0, w = 8, h = 20, },
		{ plane = "Wall2", x = 0, y = 0, w = 9, h = 20, },
	},
	ObstacleGroups = 
	{
		["Area8_Part1"] = 
		{
			Region = { plane = "Ground", x = 17, y = 70, w = 10, h = 6, },
			Obstacles = 
			{
				["Area8_Part1_Props1"] = "Area8_Part1_Props1",
				["Area8_Part1_Props2"] = "Area8_Part1_Props1/Area8_Part1_Props2",
				["Area8_Part1_Props3"] = "Area8_Part1_Props1/Area8_Part1_Props3",
			},
		},
		["Area8_Part2"] = 
		{
			Region = { plane = "Ground", x = 12, y = 53, w = 6, h = 6, },
			Obstacles = 
			{
				["Area8_Part2_Props1"] = "Area8_Part2_Props1",
			},
		},
		["Area8_Part3"] = 
		{
			Region = { plane = "Ground", x = 16, y = 65, w = 5, h = 4, },
			Obstacles = 
			{
				["Area8_Part3_Props1"] = "Area8_Part3_Props1",
			},
		},
		["Area8_Part4"] = 
		{
			Region = { plane = "Ground", x = 3, y = 60, w = 12, h = 12, },
			Obstacles = 
			{
				["Area8_Part4_Props1"] = "Area8_Part4_Props1",
				["Area8_Part4_Props2"] = "Area8_Part4_Props1/Area8_Part4_Props2",
				["Area8_Part4_Props3"] = "Area8_Part4_Props1/Area8_Part4_Props2/Area8_Part4_Props3",
				["Area8_Part4_Props4"] = "Area8_Part4_Props1/Area8_Part4_Props2/Area8_Part4_Props3/Area8_Part4_Props4",
				["Area8_Part4_Props5"] = "Area8_Part4_Props1/Area8_Part4_Props2/Area8_Part4_Props3/Area8_Part4_Props4/Area8_Part4_Props5",
				["Area8_Part4_Props6"] = "Area8_Part4_Props1/Area8_Part4_Props2/Area8_Part4_Props6",
				["Area8_Part4_Props7"] = "Area8_Part4_Props1/Area8_Part4_Props2/Area8_Part4_Props6/Area8_Part4_Props7",
				["Area8_Part4_Props8"] = "Area8_Part4_Props1/Area8_Part4_Props2/Area8_Part4_Props6/Area8_Part4_Props7/Area8_Part4_Props8",
				["Area8_Part4_Props9"] = "Area8_Part4_Props1/Area8_Part4_Props2/Area8_Part4_Props6/Area8_Part4_Props7/Area8_Part4_Props8/Area8_Part4_Props9",
			},
		},
		["Area8_Part5"] = 
		{
			Region = { plane = "Ground", x = 0, y = 61, w = 3, h = 3, },
			Obstacles = 
			{
				["Area8_Part5_Props1"] = "Area8_Part5_Props1",
			},
		},
		["Area8_Part6"] = 
		{
			Region = { plane = "Ground", x = 5, y = 53, w = 4, h = 4, },
			Obstacles = 
			{
				["Area8_Part6_Props1"] = "Area8_Part6_Props1",
			},
		},
		["Area8_Part7"] = 
		{
			Region = { plane = "Ground", x = 22, y = 60, w = 5, h = 10, },
			Obstacles = 
			{
				["Area8_Part7_Props1"] = "Area8_Part7_Props1",
			},
		},
	},
}
HomeObstacleAreaPrefabConfig["Area9"] = 
{
	ContainRegions = 
	{
		{ plane = "Ground", x = 0, y = 26, w = 24, h = 26, },
		{ plane = "Wall1", x = 26, y = 0, w = 24, h = 20, },
	},
	ObstacleGroups = 
	{
		["Area9_Part1"] = 
		{
			Region = { plane = "Ground", x = 0, y = 50, w = 18, h = 2, },
			Obstacles = 
			{
				["Area9_Part1_Props1"] = "Area9_Part1_Props1",
			},
		},
		["Area9_Part3"] = 
		{
			Region = { plane = "Ground", x = 0, y = 33, w = 5, h = 17, },
			Obstacles = 
			{
				["Area9_Part3_Props1"] = "Area9_Part3_Props1",
				["Area9_Part3_Props2"] = "Area9_Part3_Props2",
				["Area9_Part3_Props3"] = "Area9_Part3_Props3",
				["Area9_Part3_Props4"] = "Area9_Part3_Props4",
				["Area9_Part3_Props5"] = "Area9_Part3_Props4/Area9_Part3_Props5",
				["Area9_Part3_Props6"] = "Area9_Part3_Props4/Area9_Part3_Props6",
				["Area9_Part3_Props7"] = "Area9_Part3_Props4/Area9_Part3_Props7",
				["Area9_Part3_Props8"] = "Area9_Part3_Props4/Area9_Part3_Props8",
			},
		},
		["Area9_Part5"] = 
		{
			Region = { plane = "Ground", x = 5, y = 45, w = 4, h = 4, },
			Obstacles = 
			{
				["Area9_Part5_Props1"] = "Area9_Part5_Props1",
			},
		},
		["Area9_Part6"] = 
		{
			Region = { plane = "Ground", x = 6, y = 33, w = 6, h = 6, },
			Obstacles = 
			{
				["Area9_Part6_Props1"] = "Area9_Part6_Props1",
			},
		},
		["Area9_Part7"] = 
		{
			Region = { plane = "Ground", x = 5, y = 41, w = 5, h = 4, },
			Obstacles = 
			{
				["Area9_Part7_Props1"] = "Area9_Part7_Props1",
			},
		},
		["Area9_Part8"] = 
		{
			Region = { plane = "Ground", x = 11, y = 40, w = 13, h = 10, },
			Obstacles = 
			{
				["Area9_Part8_Props1"] = "Area9_Part8_Props1",
				["Area9_Part8_Props2"] = "Area9_Part8_Props1/Area9_Part8_Props2",
				["Area9_Part8_Props3"] = "Area9_Part8_Props1/Area9_Part8_Props3",
				["Area9_Part8_Props4"] = "Area9_Part8_Props1/Area9_Part8_Props4",
			},
		},
		["Area9_Part9"] = 
		{
			Region = { plane = "Ground", x = 0, y = 25, w = 9, h = 8, },
			Obstacles = 
			{
				["Area9_Part9_Props1"] = "Area9_Part9_Props1",
				["Area9_Part9_Props2"] = "Area9_Part9_Props1/Area9_Part9_Props2",
				["Area9_Part9_Props3"] = "Area9_Part9_Props1/Area9_Part9_Props3",
			},
		},
		["Area9_Part10"] = 
		{
			Region = { plane = "Ground", x = 12, y = 28, w = 12, h = 12, },
			Obstacles = 
			{
				["Area9_Part10_Props1"] = "Area9_Part10_Props1",
				["Area9_Part10_Props2"] = "Area9_Part10_Props1/Area9_Part10_Props2",
				["Area9_Part10_Props3"] = "Area9_Part10_Props1/Area9_Part10_Props3",
				["Area9_Part10_Props4"] = "Area9_Part10_Props1/Area9_Part10_Props4",
				["Area9_Part10_Props5"] = "Area9_Part10_Props1/Area9_Part10_Props4/Area9_Part10_Props5",
				["Area9_Part10_Props6"] = "Area9_Part10_Props1/Area9_Part10_Props6",
			},
		},
		["Area9_Part11"] = 
		{
			Region = { plane = "Ground", x = 17, y = 25, w = 7, h = 1, },
			Obstacles = 
			{
				["Area9_Part11_Props1"] = "Area9_Part11_Props1",
			},
		},
		["Area9_Part12"] = 
		{
			Region = { plane = "Ground", x = 0, y = 24, w = 17, h = 2, },
			Obstacles = 
			{
				["Area9_Part12_Props1"] = "Area9_Part12_Props1",
			},
		},
	},
}
HomeObstacleAreaPrefabConfig["Area10"] = 
{
	ContainRegions = 
	{
		{ plane = "Ground", x = 0, y = 0, w = 27, h = 26, },
		{ plane = "Wall1", x = 0, y = 0, w = 27, h = 20, },
	},
	ObstacleGroups = 
	{
		["Area10_Part2"] = 
		{
			Region = { plane = "Ground", x = 0, y = 18, w = 7, h = 6, },
			Obstacles = 
			{
				["Area10_Part2_Props1"] = "Area10_Part2_Props1",
			},
		},
		["Area10_Part3"] = 
		{
			Region = { plane = "Ground", x = 0, y = 12, w = 10, h = 6, },
			Obstacles = 
			{
				["Area10_Part3_Props1"] = "Area10_Part3_Props1",
				["Area10_Part3_Props2"] = "Area10_Part3_Props1/Area10_Part3_Props2",
			},
		},
		["Area10_Part4"] = 
		{
			Region = { plane = "Ground", x = 7, y = 18, w = 10, h = 6, },
			Obstacles = 
			{
				["Area10_Part4_Props1"] = "Area10_Part4_Props1",
				["Area10_Part4_Props2"] = "Area10_Part4_Props1/Area10_Part4_Props2",
				["Area10_Part4_Props3"] = "Area10_Part4_Props1/Area10_Part4_Props3",
			},
		},
		["Area10_Part6"] = 
		{
			Region = { plane = "Ground", x = 18, y = 17, w = 8, h = 9, },
			Obstacles = 
			{
				["Area10_Part6_Props1"] = "Area10_Part6_Props1",
			},
		},
		["Area10_Part7"] = 
		{
			Region = { plane = "Ground", x = 0, y = 1, w = 9, h = 11, },
			Obstacles = 
			{
				["Area10_Part7_Props1"] = "Area10_Part7_Props1",
				["Area10_Part7_Props2"] = "Area10_Part7_Props1/Area10_Part7_Props2",
				["Area10_Part7_Props3"] = "Area10_Part7_Props1/Area10_Part7_Props2/Area10_Part7_Props3",
				["Area10_Part7_Props4"] = "Area10_Part7_Props1/Area10_Part7_Props2/Area10_Part7_Props3/Area10_Part7_Props4",
				["Area10_Part7_Props5"] = "Area10_Part7_Props1/Area10_Part7_Props2/Area10_Part7_Props3/Area10_Part7_Props4/Area10_Part7_Props5",
				["Area10_Part7_Props6"] = "Area10_Part7_Props1/Area10_Part7_Props2/Area10_Part7_Props3/Area10_Part7_Props4/Area10_Part7_Props5/Area10_Part7_Props6",
				["Area10_Part7_Props7"] = "Area10_Part7_Props1/Area10_Part7_Props2/Area10_Part7_Props3/Area10_Part7_Props7",
			},
		},
		["Area10_Part8"] = 
		{
			Region = { plane = "Ground", x = 11, y = 8, w = 8, h = 9, },
			Obstacles = 
			{
				["Area10_Part8_Props1"] = "Area10_Part8_Props1",
			},
		},
		["Area10_Part9"] = 
		{
			Region = { plane = "Ground", x = 9, y = 4, w = 4, h = 4, },
			Obstacles = 
			{
				["Area10_Part9_Props1"] = "Area10_Part9_Props1",
			},
		},
		["Area10_Part10"] = 
		{
			Region = { plane = "Ground", x = 13, y = 0, w = 6, h = 6, },
			Obstacles = 
			{
				["Area10_Part10_Props1"] = "Area10_Part10_Props1",
			},
		},
		["Area10_Part11"] = 
		{
			Region = { plane = "Ground", x = 22, y = 0, w = 5, h = 11, },
			Obstacles = 
			{
				["Area10_Part11_Props1"] = "Area10_Part11_Props1",
				["Area10_Part11_Props2"] = "Area10_Part11_Props1/Area10_Part11_Props2",
				["Area10_Part11_Props3"] = "Area10_Part11_Props1/Area10_Part11_Props3",
			},
		},
	},
}
HomeObstacleAreaPrefabConfig["Area11"] = 
{
	ContainRegions = 
	{
		{ plane = "Garden", x = 0, y = 0, w = 33, h = 35, },
	},
	ObstacleGroups = 
	{
		["Area11_Part1"] = 
		{
			Region = { plane = "Garden", x = 0, y = 0, w = 6, h = 12, },
			Obstacles = 
			{
				["Area11_Part1_Props1"] = "Area11_Part1_Props1",
			},
		},
		["Area11_Part2"] = 
		{
			Region = { plane = "Garden", x = 0, y = 12, w = 13, h = 5, },
			Obstacles = 
			{
				["Area11_Part2_Props1"] = "Area11_Part2_Props1",
				["Area11_Part2_Props2"] = "Area11_Part2_Props1/Area11_Part2_Props2",
				["Area11_Part2_Props3"] = "Area11_Part2_Props1/Area11_Part2_Props3",
				["Area11_Part2_Props4"] = "Area11_Part2_Props1/Area11_Part2_Props3/Area11_Part2_Props4",
			},
		},
		["Area11_Part3"] = 
		{
			Region = { plane = "Garden", x = 7, y = 0, w = 8, h = 12, },
			Obstacles = 
			{
				["Area11_Part3_Props1"] = "Area11_Part3_Props1",
				["Area11_Part3_Props2"] = "Area11_Part3_Props1/Area11_Part3_Props2",
				["Area11_Part3_Props3"] = "Area11_Part3_Props1/Area11_Part3_Props3",
			},
		},
		["Area11_Part4"] = 
		{
			Region = { plane = "Garden", x = 15, y = 25, w = 13, h = 10, },
			Obstacles = 
			{
				["Area11_Part4_Props1"] = "Area11_Part4_Props1",
				["Area11_Part4_Props2"] = "Area11_Part4_Props1/Area11_Part4_Props2",
				["Area11_Part4_Props3"] = "Area11_Part4_Props1/Area11_Part4_Props3",
				["Area11_Part4_Props4"] = "Area11_Part4_Props1/Area11_Part4_Props4",
			},
		},
		["Area11_Part5"] = 
		{
			Region = { plane = "Garden", x = 4, y = 18, w = 5, h = 17, },
			Obstacles = 
			{
				["Area11_Part5_Props1"] = "Area11_Part5_Props1",
				["Area11_Part5_Props2"] = "Area11_Part5_Props2",
				["Area11_Part5_Props3"] = "Area11_Part5_Props3",
				["Area11_Part5_Props4"] = "Area11_Part5_Props4",
				["Area11_Part5_Props5"] = "Area11_Part5_Props4/Area11_Part5_Props5",
				["Area11_Part5_Props6"] = "Area11_Part5_Props4/Area11_Part5_Props6",
				["Area11_Part5_Props7"] = "Area11_Part5_Props4/Area11_Part5_Props7",
				["Area11_Part5_Props8"] = "Area11_Part5_Props4/Area11_Part5_Props8",
			},
		},
		["Area11_Part6"] = 
		{
			Region = { plane = "Garden", x = 11, y = 12, w = 13, h = 13, },
			Obstacles = 
			{
				["Area11_Part6_Props1"] = "Area11_Part6_Props1",
				["Area11_Part6_Props2"] = "Area11_Part6_Props1/Area11_Part6_Props2",
				["Area11_Part6_Props3"] = "Area11_Part6_Props1/Area11_Part6_Props2/Area11_Part6_Props3",
			},
		},
		["Area11_Part7"] = 
		{
			Region = { plane = "Garden", x = 9, y = 25, w = 5, h = 10, },
			Obstacles = 
			{
				["Area11_Part7_Props1"] = "Area11_Part7_Props1",
				["Area11_Part7_Props2"] = "Area11_Part7_Props1/Area11_Part7_Props2",
				["Area11_Part7_Props3"] = "Area11_Part7_Props1/Area11_Part7_Props3",
			},
		},
	},
}
