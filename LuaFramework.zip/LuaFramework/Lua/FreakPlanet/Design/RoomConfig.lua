RoomConfig ={};
RoomConfig["Room_All_wuwu"] =
{
	Name = "呜呜房间",
	Character = 220001,
	Desc = "呜呜的房间，非常安逸舒适的小房间，让人一看就知道是平时很受人宠爱的小猫。",
	PieceList = {
		440121,
	},
}
RoomConfig["Room_All_gugu"] =
{
	Name = "漆漆房间",
	Character = 220002,
	Desc = "漆漆的房间，和呜呜采用了同规格的装修套餐，不过因为漆漆不喜欢小窝，所以另外选了沙发。",
	PieceList = {
		440141,
	},
}
RoomConfig["Room_Rpg_11_damowang"] =
{
	Name = "大魔王房间",
	Character = 220029,
	Desc = "大魔王的房间，没有Ta的邀请，任何人都不许进入。所以平时没有人知道大魔王在房间里究竟干什么。",
	PieceList = {
		440001,
		440002,
		440003,
		440004,
		440005,
		440006,
		440007,
		440008,
		440009,
		440010,
		440011,
	},
	SkillList = {
		Desc = "敌人等级 {Value1}",
		Skill = {
			{
				Id = 101525,
				Value = -5,
			},
		},
	},
}
RoomConfig["Room_Fat_30_shutiao"] =
{
	Name = "薯条国王房间",
	Character = 220131,
	Desc = "薯条国王的房间，充满了健身器材，每天睡醒以后就可以开始举杠铃。",
	PieceList = {
		440021,
		440022,
		440023,
		440024,
		440025,
		440026,
		440027,
		440028,
		440029,
		440030,
		440031,
	},
	SkillList = {
		Desc = "攻击+{Value1}%",
		Skill = {
			{
				Id = 100652,
				Value = 5,
			},
		},
	},
}
RoomConfig["Room_MUS_30_Napoleon"] =
{
	Name = "名人蜡像房间",
	Character = 220229,
	Desc = "名人蜡像的房间，充满了军人风格的整洁感。不过干练的家具摆设依然无法掩盖这位伟人的贵族气质。",
	PieceList = {
		440041,
		440042,
		440043,
		440044,
		440045,
		440046,
		440047,
		440048,
		440049,
		440050,
		440051,
	},
	SkillList = {
		Desc = "全队忍耐 +{Value1}",
		Skill = {
			{
				Id = 100661,
				Value = 5,
			},
		},
	},
}
RoomConfig["Room_Sus_01_fuermosi"] =
{
	Name = "大侦探房间",
	Character = 220324,
	Desc = "大侦探的房间，每件家具都代表着他自己构建的推理城堡中的一条关键线索，如果有人进来，哪怕只是稍微移动某个事物的一角，也会被他立刻察觉。",
	PieceList = {
		440061,
		440062,
		440063,
		440064,
		440065,
		440066,
		440067,
		440068,
		440069,
		440070,
		440071,
	},
	SkillList = {
		Desc = "有{Value1}%概率无视敌人闪避",
		Skill = {
			{
				Id = 101745,
				Value = 25,
			},
		},
	},
}
RoomConfig["Room_Sus_moliyadi"] =
{
	Name = "教授房间",
	Character = 220325,
	Desc = "教授的房间，阴暗的家具风格非常符合其幕后黑手的人物形象，不过柜子和橱子里其实经常能找到他喜欢的玩具。",
	PieceList = {
		440081,
		440082,
		440083,
		440084,
		440085,
		440086,
		440087,
		440088,
		440089,
		440090,
		440091,
	},
	SkillList = {
		Desc = "暴击 +{Value1}",
		Skill = {
			{
				Id = 100654,
				Value = 25,
			},
		},
	},
}
RoomConfig["Room_SPDraw_03_DiamondQueen"] =
{
	Name = "玉璧女王房间",
	Character = 221003,
	Desc = "玉璧女王的房间，拥有全宇宙最奢华的家具，每件家具都散发着璀璨迷人的光彩，不过，附耳去听，你能听到抽卡者的伤心哭泣的声音。",
}
RoomConfig["Room_All_NewYearBeast"] =
{
	Name = "年大人房间",
	Character = 223067,
	Desc = "年大人的房间，虽然经常说讨厌过年，但是房间布置得很有年味。",
	PieceList = {
		440161,
		440162,
		440163,
		440164,
		440165,
		440166,
		440167,
		440168,
		440169,
		440170,
		440171,
	},
	SkillList = {
		Desc = "攻击时无视敌人{Value1}%忍耐",
		Skill = {
			{
				Id = 101761,
				Value = 20,
			},
		},
	},
}
RoomConfig["Room_RPG_107_Druid"] =
{
	Name = "德鲁伊房间",
	Character = 223008,
	Desc = "德鲁伊的房间，德鲁伊自豪地称它为“动物之家”。房间里充满了自然的气息，据说，该房间常年被小动物们评定为“年度最理想居所”。",
}
RoomConfig["Room_Fat_101_Brandy"] =
{
	Name = "拜兰帝房间",
	Character = 223108,
	Desc = "拜兰帝的私人酒窖，高贵而典雅，据说其中储存了上万瓶酒，是拜兰迪作为贵族酿酒大师的最好证明。",
	PieceList = {
		440181,
		440182,
		440183,
		440184,
		440185,
		440186,
		440187,
		440188,
		440189,
		440190,
		440191,
	},
	SkillList = {
		Desc = "{Value1}%概率无视敌人的闪避",
		Skill = {
			{
				Id = 101745,
				Value = 20,
			},
		},
	},
}
RoomConfig["Room_Sea_20_shanhu"] =
{
	Name = "珊瑚阿卡房间",
	Character = 220429,
	Desc = "珊瑚阿卡的私人酒窖，高贵而典雅，据说其中储存了上万瓶酒，是拜兰迪作为贵族酿酒大师的最好证明。",
	PieceList = {
		440201,
		440202,
		440203,
		440204,
		440205,
		440206,
		440207,
		440208,
		440209,
		440210,
		440211,
	},
	SkillList = {
		Desc = "{Value1}%概率闪避攻击",
		Skill = {
			{
				Id = 101744,
				Value = 10,
			},
		},
	},
}
RoomConfig["Room_Sea_14_hujing"] =
{
	Name = "虎鲸京房间",
	Character = 220430,
	Desc = "虎鲸京的私人酒窖，高贵而典雅，据说其中储存了上万瓶酒，是拜兰迪作为贵族酿酒大师的最好证明。",
	PieceList = {
		440221,
		440222,
		440223,
		440224,
		440225,
		440226,
		440227,
		440228,
		440229,
		440230,
		440231,
	},
	SkillList = {
		Desc = "生命 +{Value1}%",
		Skill = {
			{
				Id = 100651,
				Value = 5,
			},
		},
	},
}
RoomConfig["Room_Sea_31_meirenyu"] =
{
	Name = "人鱼清音房间",
	Character = 220431,
	Desc = "人鱼清音的寝宫，充满了深海的神秘感。",
	SkillList = {
		Desc = "对水元素敌人伤害 +{Value1}%",
		Skill = {
			{
				Id = 100551,
				Value = 20,
			},
		},
	},
}
RoomConfig["Room_SPBUS_07_quyuan"] =
{
	Name = "灵均房间",
	Character = 223124,
	Desc = "以绿色为主，具有花木气息的房间，置身其中，能感受到沁人心脾的清香。",
	PieceList = {
		440261,
		440262,
		440263,
		440264,
		440265,
		440266,
		440267,
		440268,
		440269,
		440270,
		440271,
	},
	SkillList = {
		Desc = "敌人忍耐 {Value1}",
		Skill = {
			{
				Id = 101503,
				Value = -30,
			},
		},
	},
}
RoomConfig["Room_SPBUS_21_YueLao"] =
{
	Name = "月佬房间",
	Character = 223138,
	Desc = "以绿色为主，具有花木气息的房间，置身其中，能感受到沁人心脾的清香。",
}
RoomConfig["Room_SPBUS_24_XueShen"] =
{
	Name = "雪神房间",
	Character = 223141,
	Desc = "以绿色为主，具有花木气息的房间，置身其中，能感受到沁人心脾的清香。",
	PieceList = {
		440281,
		440282,
		440283,
		440284,
		440285,
		440286,
		440287,
		440288,
		440289,
		440290,
		440291,
	},
}
RoomConfig["Room_SPBUS_25_MaoYanChuNiang"] =
{
	Name = "猫眼厨娘房间",
	Character = 223142,
	Desc = "以绿色为主，具有花木气息的房间，置身其中，能感受到沁人心脾的清香。",
	PieceList = {
		440301,
		440302,
		440303,
		440304,
		440305,
		440306,
		440307,
		440308,
		440309,
		440310,
		440311,
	},
	SkillList = {
		Desc = "暴击 +{Value1}",
		Skill = {
			{
				Id = 100654,
				Value = 25,
			},
		},
	},
}
RoomConfig["Room_WithNoSofa"] =
{
	Name = "无沙发房间",
	Desc = "这是一个没有沙发的房间",
}

