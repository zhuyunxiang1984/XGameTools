ArenaBattleConfig ={};
ArenaBattleID = 
{
	Id001 = 390001,
	Id002 = 390002,
	Id003 = 390003,
	Id004 = 390004,
	Id005 = 390005,
	Id006 = 390006,
	Id007 = 390007,
	Id008 = 390008,
	Id009 = 390009,
	Id010 = 390010,
	Id011 = 390011,
	Id012 = 390012,
	Id013 = 390013,
	Id014 = 390014,
	Id015 = 390015,
	Id016 = 390016,
	Id017 = 390017,
	Id018 = 390018,
	Id019 = 390019,
	Id020 = 390020,
	Id021 = 390021,
	Id022 = 390022,
	Id023 = 390023,
	Id024 = 390024,
	Id025 = 390025,
	Id026 = 390026,
	Id027 = 390027,
	Id028 = 390028,
	Id029 = 390029,
	Id030 = 390030,
	Id031 = 390031,
	Id032 = 390032,
	Id033 = 390033,
	Id034 = 390034,
	Id035 = 390035,
	Id036 = 390036,
	Id037 = 390037,
	Id038 = 390038,
	Id039 = 390039,
	Id040 = 390040,
	Id041 = 390041,
	Id042 = 390042,
	Id043 = 390043,
	Id044 = 390044,
	Id045 = 390045,
	Id046 = 390046,
	Id047 = 390047,
	Id048 = 390048,
	Id049 = 390049,
	Id050 = 390050,
	Id051 = 390051,
	Id052 = 390052,
	Id053 = 390053,
	Id054 = 390054,
	Id055 = 390055,
	Id056 = 390056,
	Id057 = 390057,
	Id058 = 390058,
	Id059 = 390059,
	Id060 = 390060,
	Id061 = 390061,
	Id062 = 390062,
	Id063 = 390063,
	Id064 = 390064,
	Id065 = 390065,
	Id066 = 390066,
	Id067 = 390067,
	Id068 = 390068,
	Id069 = 390069,
	Id070 = 390070,
	Id071 = 390071,
	Id072 = 390072,
	Id073 = 390073,
	Id074 = 390074,
	Id075 = 390075,
	Id076 = 390076,
	Id077 = 390077,
	Id078 = 390078,
	Id079 = 390079,
	Id080 = 390080,
	Id081 = 390081,
	Id082 = 390082,
	Id083 = 390083,
	Id084 = 390084,
	Id085 = 390085,
	Id086 = 390086,
	Id087 = 390087,
	Id088 = 390088,
	Id089 = 390089,
	Id090 = 390090,
	Id091 = 390091,
	Id092 = 390092,
	Id093 = 390093,
	Id094 = 390094,
	Id095 = 390095,
	Id096 = 390096,
	Id097 = 390097,
	Id098 = 390098,
	Id099 = 390099,
	Id100 = 390100,
	Id101 = 390101,
	Id102 = 390102,
	Id103 = 390103,
	Id104 = 390104,
	Id105 = 390105,
	Id106 = 390106,
	Id107 = 390107,
	Id108 = 390108,
	Id109 = 390109,
	Id110 = 390110,
	Id111 = 390111,
	Id112 = 390112,
	Id113 = 390113,
	Id114 = 390114,
	Id115 = 390115,
	Id116 = 390116,
	Id117 = 390117,
	Id118 = 390118,
	Id119 = 390119,
	Id120 = 390120,
	Id121 = 390121,
	Id122 = 390122,
	Id123 = 390123,
	Id124 = 390124,
	Id125 = 390125,
	Id126 = 390126,
	Id127 = 390127,
	Id128 = 390128,
	Id129 = 390129,
	Id130 = 390130,
	Id131 = 390131,
	Id132 = 390132,
	Id133 = 390133,
	Id134 = 390134,
	Id135 = 390135,
	Id136 = 390136,
	Id137 = 390137,
	Id138 = 390138,
	Id139 = 390139,
	Id140 = 390140,
	Id141 = 390141,
	Id142 = 390142,
	Id143 = 390143,
	Id144 = 390144,
	Id145 = 390145,
	Id146 = 390146,
	Id147 = 390147,
	Id148 = 390148,
	Id149 = 390149,
	Id150 = 390150,
	Id151 = 390151,
	Id152 = 390152,
	Id153 = 390153,
	Id154 = 390154,
	Id155 = 390155,
	Id156 = 390156,
	Id157 = 390157,
	Id158 = 390158,
	Id1001 = 391001,
	Id1002 = 391002,
	Id1003 = 391003,
	Id1004 = 391004,
	Id1005 = 391005,
	Id1006 = 391006,
	Id1007 = 391007,
	Id1008 = 391008,
	Id1009 = 391009,
	Id1010 = 391010,
	Id1011 = 391011,
	Id1012 = 391012,
	Id1013 = 391013,
	Id1014 = 391014,
	Id1015 = 391015,
	Id1016 = 391016,
	Id1017 = 391017,
	Id1018 = 391018,
	Id1019 = 391019,
	Id1020 = 391020,
	Id1021 = 391021,
	Id1022 = 391022,
	Id1023 = 391023,
	Id1024 = 391024,
	Id1025 = 391025,
	Id1026 = 391026,
	Id1027 = 391027,
	Id1028 = 391028,
	Id1029 = 391029,
	Id1030 = 391030,
	Id1031 = 391031,
	Id1032 = 391032,
	Id1033 = 391033,
	Id1034 = 391034,
	Id1035 = 391035,
	Id1036 = 391036,
	Id1037 = 391037,
	Id1038 = 391038,
	Id1039 = 391039,
	Id1040 = 391040,
	Id1041 = 391041,
	Id1042 = 391042,
}
ArenaBattleConfig[ArenaBattleID.Id001] =
{
	Id = 1,
	Name = "通缉丛林史莱姆",
	Boss = false,
	IntroduceText = "丛林史莱姆，目测男性，疑似未成年，籍贯冒险星。身高2厘米(不同手机尺寸不同)。\n据目击者称，该人员多次在丛林附近窃取勇者财物，已是惯窃。\n\n联系人：密林冒险者协会 尼尔斯先生",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 30,
			Enemy = {
				{
					Value = 246001,
					Level = 30,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 10,
				},
				{
					Value = 2,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 36,
			Enemy = {
				{
					Value = 246002,
					Level = 36,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 42,
			Enemy = {
				{
					Value = 246003,
					Level = 42,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 10,
				},
			},
		},
	},
	Desc = "罪名：偷到丛林冒险者掉在地上的物品不还。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id002] =
{
	Id = 2,
	Name = "通缉地下史莱姆",
	Boss = false,
	IntroduceText = "地下史莱姆，目测男性，疑似未成年，籍贯冒险星。身高2厘米(不同手机尺寸不同)。\n据目击者称，该人员多次在地城附近窃取勇者财物，已是惯窃。\n\n联系人：冒险星冒险者协会 斯沃德·马吉克",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 30,
			Enemy = {
				{
					Value = 246004,
					Level = 30,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 10,
				},
				{
					Value = 2,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 36,
			Enemy = {
				{
					Value = 246005,
					Level = 36,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 42,
			Enemy = {
				{
					Value = 246006,
					Level = 42,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 10,
				},
			},
		},
	},
	Desc = "罪名：偷到地城冒险者掉在地上的物品不还。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id003] =
{
	Id = 3,
	Name = "通缉沼泽史莱姆",
	Boss = false,
	IntroduceText = "沼泽史莱姆，目测男性，疑似未成年，籍贯冒险星。身高2厘米(不同手机尺寸不同)。\n据目击者称，该罪犯多次在沼泽附近窃取勇者财物，已是惯窃。\n\n联系人：冒险星冒险者协会 斯沃德·马吉克",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 30,
			Enemy = {
				{
					Value = 246007,
					Level = 30,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 10,
				},
				{
					Value = 2,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 36,
			Enemy = {
				{
					Value = 246008,
					Level = 36,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 42,
			Enemy = {
				{
					Value = 246009,
					Level = 42,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 10,
				},
			},
		},
	},
	Desc = "罪名：偷到沼泽冒险者掉在地上的物品不还。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id004] =
{
	Id = 4,
	Name = "通缉火山史莱姆",
	Boss = false,
	IntroduceText = "火山史莱姆，目测男性，疑似未成年，籍贯冒险星。身高2厘米(不同手机尺寸不同)。\n据目击者称，该罪犯多次在火山附近窃取勇者财物，已是惯窃。\n\n联系人：冒险星冒险者协会 斯沃德•马吉克",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 30,
			Enemy = {
				{
					Value = 246010,
					Level = 30,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 10,
				},
				{
					Value = 2,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 36,
			Enemy = {
				{
					Value = 246011,
					Level = 36,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 42,
			Enemy = {
				{
					Value = 246012,
					Level = 42,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 10,
				},
			},
		},
	},
	Desc = "罪名：偷到火山冒险者掉在地上的物品不还。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id005] =
{
	Id = 5,
	Name = "通缉偷窥花丛",
	Boss = false,
	IntroduceText = "偷窥花丛，性别不详，成年体。籍贯冒险星，眼神凶恶之中又带点狡诈，狡诈之中又带点猥琐。\n据目击者称，该人员常年在楼梯花坛处伪装花丛，偷看路人裙/裤底，造成数名萌妹子/糙汉子被吓哭，影响恶劣，特此通缉。\n\n联系人：风纪协会 管先生",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 40,
			Enemy = {
				{
					Value = 246013,
					Level = 40,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 15,
				},
				{
					Value = 2,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 48,
			Enemy = {
				{
					Value = 246014,
					Level = 48,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 15,
				},
			},
		},
		{
			SupportLevel = 56,
			Enemy = {
				{
					Value = 246015,
					Level = 56,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 15,
				},
			},
		},
	},
	Desc = "罪名：在路边假装花丛偷看路人裙底。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id006] =
{
	Id = 6,
	Name = "通缉不良花",
	Boss = false,
	IntroduceText = "不良花，男性，目测处于发育期，籍贯冒险星。终日混迹于新手村附近，喜欢看人出丑。\n据目击者称，该人员近来屡屡在怪物小学堵截回家学生。日前更对两只返校史莱姆出手，撕毁其寒假作业。\n\n联系人：怪物学院学生会 怪林德学长",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 50,
			Enemy = {
				{
					Value = 246016,
					Level = 50,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 20,
				},
				{
					Value = 2,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 60,
			Enemy = {
				{
					Value = 246017,
					Level = 60,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 70,
			Enemy = {
				{
					Value = 246018,
					Level = 70,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 20,
				},
			},
		},
	},
	Desc = "罪名：躲在小学门口，敲诈放学回家的小学生。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id007] =
{
	Id = 7,
	Name = "通缉灰狼小弟",
	Boss = false,
	IntroduceText = "灰狼小弟，籍贯冒险星。\n日前接汤臣九品居民举报，该人员每天深夜两点都会准时公放土嗨歌曲，周边居民不堪其扰。特此通缉。\n\n发布单位：深坑谷谷东新区汤臣九品小区物业 钱经理",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 60,
			Enemy = {
				{
					Value = 246019,
					Level = 60,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 25,
				},
				{
					Value = 2,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 72,
			Enemy = {
				{
					Value = 246020,
					Level = 72,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 25,
				},
			},
		},
		{
			SupportLevel = 84,
			Enemy = {
				{
					Value = 246021,
					Level = 84,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 25,
				},
			},
		},
	},
	Desc = "罪名：疑似帮派分子。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id008] =
{
	Id = 8,
	Name = "通缉枯萎树精",
	Boss = true,
	IntroduceText = "枯萎树精，无性别，百年树精，籍贯冒险星。身材短小，头上长角，挂着超浓稠鼻涕。\n据目击者称，该罪犯每天途经公园时，都会将浓鼻涕涂抹在公园长椅上。\n\n联系人：魔法平原大丛林公园物业管理处 叶经理\n",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 70,
			Enemy = {
				{
					Value = 246022,
					Level = 70,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 84,
			Enemy = {
				{
					Value = 246023,
					Level = 84,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 98,
			Enemy = {
				{
					Value = 246024,
					Level = 98,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
	},
	Desc = "罪名：把鼻涕抹在公共场所，弄得粘乎乎的。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id009] =
{
	Id = 9,
	Name = "通缉白狼老大",
	Boss = true,
	IntroduceText = "白狼老大，籍贯冒险星，疑似经营非法团伙。\n据有关人士称，该人员握有帮派关键信物——超强音响及音乐卡带，经常在深夜播放野狼disco扰民，特此通缉。\n\n联系人：深坑谷谷东新区汤臣九品小区物业 金董事",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 70,
			Enemy = {
				{
					Value = 246025,
					Level = 70,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 84,
			Enemy = {
				{
					Value = 246026,
					Level = 84,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 98,
			Enemy = {
				{
					Value = 246027,
					Level = 98,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
	},
	Desc = "罪名：组织并经营非法团伙，疑似有收取保护费行为。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id010] =
{
	Id = 10,
	Name = "通缉鬼影树",
	Boss = false,
	IntroduceText = "鬼影树，无性别，百年老树，栽于村口树林。\n今接到举报，该人员专在雨天行凶。当路人到树下躲雨时狂抖树冠，导致躲雨人伤风感冒。\n\n联系人：大沼泽感冒预防中心内科 暖主任",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 80,
			Enemy = {
				{
					Value = 246028,
					Level = 80,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 35,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 96,
			Enemy = {
				{
					Value = 246029,
					Level = 96,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 35,
				},
			},
		},
		{
			SupportLevel = 112,
			Enemy = {
				{
					Value = 246030,
					Level = 112,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 35,
				},
			},
		},
	},
	Desc = "罪名：有人在树下躲雨时，故意让人淋湿感冒。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id011] =
{
	Id = 11,
	Name = "通缉红眼猴",
	Boss = false,
	IntroduceText = "红眼猴，雄性，目测中年，籍贯冒险星。该人员相貌凶恶，双眼血红，身手灵敏。\n该人员近日逃离冒险星眼科中心。因常年熬夜，罹患传染度极高的慢性红眼病，请居民小心。\n\n联系人：溪谷第二传染病医院五官科 刘尔斯主任",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 80,
			Enemy = {
				{
					Value = 246031,
					Level = 80,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 35,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 96,
			Enemy = {
				{
					Value = 246032,
					Level = 96,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 35,
				},
			},
		},
		{
			SupportLevel = 112,
			Enemy = {
				{
					Value = 246033,
					Level = 112,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 35,
				},
			},
		},
	},
	Desc = "罪名：得了红眼病还故意传染给别人。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id012] =
{
	Id = 12,
	Name = "通缉胶水泥怪",
	Boss = false,
	IntroduceText = "胶水泥怪，疑似男性，中年，籍贯冒险星，身体有流体特性，但是一旦接触就会被黏住。\n据目击者称，该人员经常在公共场所游荡，走过的地方会留下大量强力胶，造成行人不便，特此通缉。\n\n联系人：大沼泽环境管理局 净女士",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 90,
			Enemy = {
				{
					Value = 246034,
					Level = 90,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 40,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 108,
			Enemy = {
				{
					Value = 246035,
					Level = 108,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 40,
				},
			},
		},
		{
			SupportLevel = 126,
			Enemy = {
				{
					Value = 246036,
					Level = 126,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 40,
				},
			},
		},
	},
	Desc = "罪名：喜欢在公园长椅上涂胶水捉弄别人。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id013] =
{
	Id = 13,
	Name = "通缉磨蹭石",
	Boss = false,
	IntroduceText = "磨蹭石，无性别，百年老石，籍贯冒险星。以帮人看相算命为生，经常出没于遗迹地区。\n据目击者称，该人员屡次在上下班高峰期边走路边看手机，导致交通瘫痪，且屡教不改。\n\n联系人：古代遗迹交通管理局 快队长",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 100,
			Enemy = {
				{
					Value = 246037,
					Level = 100,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 45,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 120,
			Enemy = {
				{
					Value = 246038,
					Level = 120,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 45,
				},
			},
		},
		{
			SupportLevel = 140,
			Enemy = {
				{
					Value = 246039,
					Level = 140,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 45,
				},
			},
		},
	},
	Desc = "罪名：一边走路一边看手机，导致路况拥堵。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id014] =
{
	Id = 14,
	Name = "通缉吵架石",
	Boss = false,
	IntroduceText = "吵架石，疑似男性，百年老石，籍贯冒险星。\n根据多名当事人举报，该人员屡次因小摩擦与人吵架，且最终演变为斗殴事件。\n\n联系人：古代遗迹灵石路居委会 硬主任",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 100,
			Enemy = {
				{
					Value = 246040,
					Level = 100,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 45,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 120,
			Enemy = {
				{
					Value = 246041,
					Level = 120,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 45,
				},
			},
		},
		{
			SupportLevel = 140,
			Enemy = {
				{
					Value = 246042,
					Level = 140,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 45,
				},
			},
		},
	},
	Desc = "罪名：动不动就会和别人吵起来，还会动手动脚。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id015] =
{
	Id = 15,
	Name = "通缉钢钉球",
	Boss = false,
	IntroduceText = "钢钉球，目测男性，疑似未成年，籍贯冒险星，身上长有大量红色尖刺。\n近日接获举报，该人员屡次在地铁早高峰时期插队，因地铁拥挤，导致大量居民被其刺伤。\n\n联系人：冒险星深坑谷交通管理局 盐队长",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 110,
			Enemy = {
				{
					Value = 246043,
					Level = 110,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 50,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 132,
			Enemy = {
				{
					Value = 246044,
					Level = 132,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 50,
				},
			},
		},
		{
			SupportLevel = 154,
			Enemy = {
				{
					Value = 246045,
					Level = 154,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 50,
				},
			},
		},
	},
	Desc = "罪名：挤地铁的时候故意刺痛附近的人。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id016] =
{
	Id = 16,
	Name = "通缉矿洞刺毛怪",
	Boss = true,
	IntroduceText = "矿洞刺毛怪，目测雄性，中年，籍贯冒险星，喜食矿石。\n据有关人士称，该罪犯多次进入矿队仓库偷吃矿石，直接导致矿队破产，特此通缉。\n\n联系人：冒险星资源管理局矿物科 保队长",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 120,
			Enemy = {
				{
					Value = 246046,
					Level = 120,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
				{
					Value = 2,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 144,
			Enemy = {
				{
					Value = 246047,
					Level = 144,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
			},
		},
		{
			SupportLevel = 168,
			Enemy = {
				{
					Value = 246048,
					Level = 168,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
			},
		},
	},
	Desc = "罪名：开采过程中偷吃矿石导致矿队亏本。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id017] =
{
	Id = 17,
	Name = "通缉熔岩石巨人",
	Boss = true,
	IntroduceText = "熔岩石巨人，男性，百年老石，籍贯冒险星。\n据当相关人员介绍，该人员原住址古代遗迹，拒不配合房屋拆迁到魔王火山的工作，还大肆破坏，造成大量古代遗物被焚烧而损毁。\n\n联系人：古代遗迹拆迁办 爆队长",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 120,
			Enemy = {
				{
					Value = 246049,
					Level = 120,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
				{
					Value = 2,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 144,
			Enemy = {
				{
					Value = 246050,
					Level = 144,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
			},
		},
		{
			SupportLevel = 168,
			Enemy = {
				{
					Value = 246051,
					Level = 168,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
			},
		},
	},
	Desc = "罪名：拒不配合房屋拆迁工作，还大肆破坏公共财产。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id018] =
{
	Id = 18,
	Name = "通缉臭臭淤泥",
	Boss = false,
	IntroduceText = "臭臭淤泥，女性，中年，籍贯冒险星，行动后会留下难以抹去的痕迹。\n据受害者描述，该人员走动后会留下非常难以擦拭干净的泥痕，人和车走上去很容易打滑，给市容和交通都造成了很大的影响。\n\n联系人：大沼泽环境管理局 净女士",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 130,
			Enemy = {
				{
					Value = 246052,
					Level = 130,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 156,
			Enemy = {
				{
					Value = 246053,
					Level = 156,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 182,
			Enemy = {
				{
					Value = 246054,
					Level = 182,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
	},
	Desc = "罪名：在干净的马路上留下大量泥痕。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id019] =
{
	Id = 19,
	Name = "通缉鬼火球",
	Boss = false,
	IntroduceText = "鬼火球，无性别，疑似未成年，籍贯冒险星，终日逗留在坟场附近。\n近日接获举报，该人员时常在坟场惊吓路人，导致坟场受到多起投诉，特此通缉。\n\n联系人：溪谷鬼怪镇居委会 灵主任",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 140,
			Enemy = {
				{
					Value = 246055,
					Level = 140,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 65,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 168,
			Enemy = {
				{
					Value = 246056,
					Level = 168,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 65,
				},
			},
		},
		{
			SupportLevel = 196,
			Enemy = {
				{
					Value = 246057,
					Level = 196,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 65,
				},
			},
		},
	},
	Desc = "罪名：经常出没坟场，吓前来祭拜的人。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id020] =
{
	Id = 20,
	Name = "通缉鬼火山",
	Boss = false,
	IntroduceText = "鬼火山，无性别，中年，籍贯冒险星，喜食黑暗料理。\n近日接获举报，该人员经常在公共场所食用味道极大且难闻的食物，引起他人呕吐。\n\n联系人：魔王火山环境管理局 烘主任",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 140,
			Enemy = {
				{
					Value = 246058,
					Level = 140,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 65,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 168,
			Enemy = {
				{
					Value = 246059,
					Level = 168,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 65,
				},
			},
		},
		{
			SupportLevel = 196,
			Enemy = {
				{
					Value = 246060,
					Level = 196,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 65,
				},
			},
		},
	},
	Desc = "罪名：在公共场所吃很难闻的食物，边吃边打嗝。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id021] =
{
	Id = 21,
	Name = "通缉逆行猪",
	Boss = false,
	IntroduceText = "逆行猪，男性，中年，籍贯冒险星，长有巨大獠牙。\n据目击者称，该人员屡次在高速公路逆行散步，导致多起交通事故。\n\n联系人：魔王火山交通管理局 红星队长",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 150,
			Enemy = {
				{
					Value = 246061,
					Level = 150,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 70,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 180,
			Enemy = {
				{
					Value = 246062,
					Level = 180,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 70,
				},
			},
		},
		{
			SupportLevel = 210,
			Enemy = {
				{
					Value = 246063,
					Level = 210,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 70,
				},
			},
		},
	},
	Desc = "罪名：喜欢在高速公路上逆向散步，引起交通事故。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id022] =
{
	Id = 22,
	Name = "通缉冷焰精灵",
	Boss = false,
	IntroduceText = "冷焰精灵，无性别，疑似未成年，有严重鼻炎。\n该病患日前已逃离隔离区。可能造成本星球大规模鼻炎传染。\n\n联系人：溪谷第二传染病医院发热科 冷主任",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 150,
			Enemy = {
				{
					Value = 246064,
					Level = 150,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 70,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 180,
			Enemy = {
				{
					Value = 246065,
					Level = 180,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 70,
				},
			},
		},
		{
			SupportLevel = 210,
			Enemy = {
				{
					Value = 246066,
					Level = 210,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 70,
				},
			},
		},
	},
	Desc = "罪名：打喷嚏的时候故意打到别人脸上。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id023] =
{
	Id = 23,
	Name = "通缉幽灵巨蟹",
	Boss = false,
	IntroduceText = "幽灵巨蟹，无性别，年龄未知，体型巨大，籍贯冒险星，没有实体，蟹钳非常锋利。\n据目击者描述，该人员经常出没在各个星球的大小型花园中，用自己的蟹钳剪断园林装饰。\n\n联系人：星际环卫局 小林先生",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 160,
			Enemy = {
				{
					Value = 246067,
					Level = 160,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 75,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 192,
			Enemy = {
				{
					Value = 246068,
					Level = 192,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 75,
				},
			},
		},
		{
			SupportLevel = 224,
			Enemy = {
				{
					Value = 246069,
					Level = 224,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 75,
				},
			},
		},
	},
	Desc = "罪名：喜欢破坏公共区的植物。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id024] =
{
	Id = 24,
	Name = "通缉亡灵巨人",
	Boss = false,
	IntroduceText = "亡灵巨人，男性，中年，籍贯冒险星。身材高大，约3厘米左右。\n近日接获举报，该人员屡次在公共场所喧哗，且疑似故意将口水喷到他人脸上，极其不文明，特此通缉。\n\n联系人：星球文明协会 流星主任",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 160,
			Enemy = {
				{
					Value = 246070,
					Level = 160,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 75,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 192,
			Enemy = {
				{
					Value = 246071,
					Level = 192,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 75,
				},
			},
		},
		{
			SupportLevel = 224,
			Enemy = {
				{
					Value = 246072,
					Level = 224,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 75,
				},
			},
		},
	},
	Desc = "罪名：在公共场所大声说话，把口水喷到别人脸上。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id025] =
{
	Id = 25,
	Name = "通缉黑斑莓",
	Boss = false,
	IntroduceText = "黑斑莓，男性，目测少年，实则中年，籍贯美食星，身高2厘米左右。\n接获举报，该人员经营的流动水果摊贩，经常将吃剩水果打包卖给路人，且事后态度极其恶劣。\n\n联系人：香浓镇果篮街街道办事处 果先生",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 30,
			Enemy = {
				{
					Value = 246073,
					Level = 30,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 10,
				},
				{
					Value = 2,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 36,
			Enemy = {
				{
					Value = 246074,
					Level = 36,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 42,
			Enemy = {
				{
					Value = 246075,
					Level = 42,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 10,
				},
			},
		},
	},
	Desc = "罪名：兜售吃剩的水果给路人。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id026] =
{
	Id = 26,
	Name = "通缉毛桃几",
	Boss = false,
	IntroduceText = "毛桃几，女性，老年，籍贯美食星，身上生长着很长的绒毛。\n据受害者举报，该人员体质特殊，会在每年定期时间里散落身上绒毛，大量绒毛混杂在空气中，引发了很多人的过敏性鼻炎。\n\n联系人：坚壳中心医院耳鼻喉科 麝香主任",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 30,
			Enemy = {
				{
					Value = 246076,
					Level = 30,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 10,
				},
				{
					Value = 2,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 36,
			Enemy = {
				{
					Value = 246077,
					Level = 36,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 42,
			Enemy = {
				{
					Value = 246078,
					Level = 42,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 10,
				},
			},
		},
	},
	Desc = "罪名：散播会引发鼻炎的绒毛。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id027] =
{
	Id = 27,
	Name = "通缉化学梨几",
	Boss = false,
	IntroduceText = "化学梨几，青年，疑似女性，籍贯美食星，高危人员，接触时请务必小心！\n经官方信息记载，该人员为■■■参与者，曾于■■■，经由■■■后发生异变，表皮具有强烈腐蚀性，如果接触会■■■。\n\n联系人：请致电联系，联系人X",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 40,
			Enemy = {
				{
					Value = 246079,
					Level = 40,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 15,
				},
				{
					Value = 2,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 48,
			Enemy = {
				{
					Value = 246080,
					Level = 48,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 15,
				},
			},
		},
		{
			SupportLevel = 56,
			Enemy = {
				{
					Value = 246081,
					Level = 56,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 15,
				},
			},
		},
	},
	Desc = "罪名：表皮具有腐蚀性。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id028] =
{
	Id = 28,
	Name = "通缉腐败苹狗",
	Boss = false,
	IntroduceText = "腐败苹狗，疑似女性，目测未成年，籍贯美食星，经营流动果汁摊。\n根据线报，该人员多次将无法正常出手的烂苹果制作苹果汁，卖给路人，影响极其恶劣。\n\n联系人：美食星食品安全委员会 安代表",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 40,
			Enemy = {
				{
					Value = 246082,
					Level = 40,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 15,
				},
				{
					Value = 2,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 48,
			Enemy = {
				{
					Value = 246083,
					Level = 48,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 15,
				},
			},
		},
		{
			SupportLevel = 56,
			Enemy = {
				{
					Value = 246084,
					Level = 56,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 15,
				},
			},
		},
	},
	Desc = "罪名：用烂苹果做果汁卖给口渴的路人。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id029] =
{
	Id = 29,
	Name = "通缉咸鱼头",
	Boss = false,
	IntroduceText = "咸鱼头，男性，中年，籍贯美食星，总是在说不吉利的话。\n据相关人士称，该人员经常在吉利的日子，涂着“死亡芭比粉”口红到别人家门口说很晦气的话，有损社会和谐，特此通缉。\n\n联系人：吉祥街委员会 闲女士",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 50,
			Enemy = {
				{
					Value = 246085,
					Level = 50,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 20,
				},
				{
					Value = 2,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 60,
			Enemy = {
				{
					Value = 246086,
					Level = 60,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 70,
			Enemy = {
				{
					Value = 246087,
					Level = 70,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 20,
				},
			},
		},
	},
	Desc = "罪名：在吉利的日子里，去人家家门口说不吉利的话。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id030] =
{
	Id = 30,
	Name = "通缉咸鱼尾",
	Boss = false,
	IntroduceText = "咸鱼尾，男性，青年，籍贯美食星，看上去馅料很多的样子，其实只有一口。\n据购买品尝过的顾客投诉，该人员故意伪装成馅料满溢出来的样子骗顾客购买，然而绝大部分都是面粉，严重欺骗消费者。\n\n联系人：Famari便利店经理 全先生",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 50,
			Enemy = {
				{
					Value = 246088,
					Level = 50,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 20,
				},
				{
					Value = 2,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 60,
			Enemy = {
				{
					Value = 246089,
					Level = 60,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 70,
			Enemy = {
				{
					Value = 246090,
					Level = 70,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 20,
				},
			},
		},
	},
	Desc = "罪名：伪装成馅料很多的样子欺骗消费者。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id031] =
{
	Id = 31,
	Name = "通缉落地冰淇淋",
	Boss = false,
	IntroduceText = "落地冰淇淋，籍贯美食星。\n据相关人士称，该人员患有糖尿病，且常在车道上洒成一滩致来往车辆侧翻，非常危险。\n\n联系人：美食星冰淇淋港交通管理局 盐队长",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 60,
			Enemy = {
				{
					Value = 246091,
					Level = 60,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 25,
				},
				{
					Value = 2,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 72,
			Enemy = {
				{
					Value = 246092,
					Level = 72,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 25,
				},
			},
		},
		{
			SupportLevel = 84,
			Enemy = {
				{
					Value = 246093,
					Level = 84,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 25,
				},
			},
		},
	},
	Desc = "罪名：在马路上洒成一滩，造成非常严重的交通事故。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id032] =
{
	Id = 32,
	Name = "通缉泥浆冰淇淋",
	Boss = true,
	IntroduceText = "泥浆冰淇淋，女性，年龄不详，籍贯冒险星，在逃非法移民。\n据官方档案记载，该人员原籍冒险星，种族为泥浆怪，因为向往美食星生活乔装打扮混入美食星，属于严重的星际非法移民行为。\n\n联系人：星际移民管理局 糖斯·弗里德",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 70,
			Enemy = {
				{
					Value = 246094,
					Level = 70,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 84,
			Enemy = {
				{
					Value = 246095,
					Level = 84,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 98,
			Enemy = {
				{
					Value = 246096,
					Level = 98,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
	},
	Desc = "罪名：星际非法移民。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id033] =
{
	Id = 33,
	Name = "通缉弹珠军舰",
	Boss = true,
	IntroduceText = "弹珠军舰，男性，中年，籍贯美食星，假冒伪劣寿司店老板。\n据多人举报，该人员将自制弹珠冒充高档鱼子混入寿司卖给食客。报告称，该弹珠可耐受1万次强力咀嚼。\n\n联系人：高级寿司协会 米次郎先生",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 70,
			Enemy = {
				{
					Value = 246097,
					Level = 70,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 84,
			Enemy = {
				{
					Value = 246098,
					Level = 84,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 98,
			Enemy = {
				{
					Value = 246099,
					Level = 98,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
	},
	Desc = "罪名：使用弹力超强的橡皮糖假冒鱼子制作军舰寿司卖给食客。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id034] =
{
	Id = 34,
	Name = "通缉变心糖",
	Boss = false,
	IntroduceText = "变心糖，男性，青年，籍贯美食星，会随着心情改变夹心的口味。\n据受害人举报，该人员风流成性，仰赖帅气的外表同时和数个女孩交往，平均一天换一个女朋友，伤了无数人的心。\n\n联系人：变心糖前女友 水果小糖",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 80,
			Enemy = {
				{
					Value = 246100,
					Level = 80,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 35,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 96,
			Enemy = {
				{
					Value = 246101,
					Level = 96,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 35,
				},
			},
		},
		{
			SupportLevel = 112,
			Enemy = {
				{
					Value = 246102,
					Level = 112,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 35,
				},
			},
		},
	},
	Desc = "罪名：同时和多个女生交往。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id035] =
{
	Id = 35,
	Name = "通缉黑心糖",
	Boss = false,
	IntroduceText = "黑心糖，女性，中年，籍贯美食星，身高1.8厘米，口味非常难吃。\n经举报，该人员故意化装成美食星一款热销糖果，骗路过的居民品尝。\n\n联系人：糖果镇居委会主任 甜太太",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 80,
			Enemy = {
				{
					Value = 246103,
					Level = 80,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 35,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 96,
			Enemy = {
				{
					Value = 246104,
					Level = 96,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 35,
				},
			},
		},
		{
			SupportLevel = 112,
			Enemy = {
				{
					Value = 246105,
					Level = 112,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 35,
				},
			},
		},
	},
	Desc = "罪名：非常难吃，还经常装成好吃的糖果骗人品尝。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id036] =
{
	Id = 36,
	Name = "通缉培根老赖",
	Boss = false,
	IntroduceText = "过期培根，男性，老年，籍贯美食星，查无星球居民认证。\n经警方资料调度，为征信榜单失信人员，负债百万，现靠推销劣质酱料维持生计，被缠上的客人如果拒绝购买，就会被酱料蹭满衣服。\n\n联系人：美食星公安总局 尝肠局长",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 90,
			Enemy = {
				{
					Value = 246106,
					Level = 90,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 40,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 108,
			Enemy = {
				{
					Value = 246107,
					Level = 108,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 40,
				},
			},
		},
		{
			SupportLevel = 126,
			Enemy = {
				{
					Value = 246108,
					Level = 126,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 40,
				},
			},
		},
	},
	Desc = "罪名：在街上故意把酱料蹭到别人新买的衣服上。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id037] =
{
	Id = 37,
	Name = "通缉急冻冰淇淋",
	Boss = false,
	IntroduceText = "极冻冰淇淋，疑似女性，目测已成年，籍贯美食星，靠近就可能冻伤。\n据多人举报，该人员违法销售超冷冻冰淇淋，该冰淇淋舔一口就会冻伤三叉神经，产生剧痛。\n\n联系人：美食星消费者协会 肥斯特 ",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 90,
			Enemy = {
				{
					Value = 246109,
					Level = 90,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 40,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 108,
			Enemy = {
				{
					Value = 246110,
					Level = 108,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 40,
				},
			},
		},
		{
			SupportLevel = 126,
			Enemy = {
				{
					Value = 246111,
					Level = 126,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 40,
				},
			},
		},
	},
	Desc = "罪名：兜售只要舔一口就会三叉神经痛的超级冰球给路人。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id038] =
{
	Id = 38,
	Name = "通缉馊饭团",
	Boss = false,
	IntroduceText = "馊饭团，男性，老年，籍贯美食星，身高10厘米左右，气味难闻。\n据相关人士称，该人员经常出没在便利店门口，以便宜的价格把馊饭团卖给顾客，引发了诸如腹泻等问题。\n\n联系人：Famari便利店经理 全先生",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 100,
			Enemy = {
				{
					Value = 246112,
					Level = 100,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 45,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 120,
			Enemy = {
				{
					Value = 246113,
					Level = 120,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 45,
				},
			},
		},
		{
			SupportLevel = 140,
			Enemy = {
				{
					Value = 246114,
					Level = 140,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 45,
				},
			},
		},
	},
	Desc = "罪名：贩卖超过保质期的饭团给肚子饿的路人。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id039] =
{
	Id = 39,
	Name = "通缉扮鬼饭团",
	Boss = false,
	IntroduceText = "扮鬼饭团，性别不详，年龄不详，籍贯美食星，喜欢扮鬼吓人。\n近日接获举报，该人员屡次于凌晨躲藏在办公区树林中，跳出来惊吓加班回家的路人，影响极其恶劣。\n\n联系人：美食星饭团镇刑警支部 糯队长",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 100,
			Enemy = {
				{
					Value = 246115,
					Level = 100,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 45,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 120,
			Enemy = {
				{
					Value = 246116,
					Level = 120,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 45,
				},
			},
		},
		{
			SupportLevel = 140,
			Enemy = {
				{
					Value = 246117,
					Level = 140,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 45,
				},
			},
		},
	},
	Desc = "罪名：凌晨躲在办公区树丛里跳出来吓加班回来的人。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id040] =
{
	Id = 40,
	Name = "通缉变质饭团",
	Boss = false,
	IntroduceText = "变质饭团，男性，中年，籍贯美食星，有精神疾病，性格忧郁自闭。\n据主治医师描述，该人员为精神医院重症患者，现已出逃，执着于潮湿阴暗角落，会躲进居民家中地下水道，造成管道堵塞。\n\n联系人：香浓镇精神病院脑研科 核桃仁主任",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 100,
			Enemy = {
				{
					Value = 246118,
					Level = 100,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 45,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 120,
			Enemy = {
				{
					Value = 246119,
					Level = 120,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 45,
				},
			},
		},
		{
			SupportLevel = 140,
			Enemy = {
				{
					Value = 246120,
					Level = 140,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 45,
				},
			},
		},
	},
	Desc = "罪名：躲进人家的下水道，造成管道堵塞。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id041] =
{
	Id = 41,
	Name = "通缉注水龟龟",
	Boss = false,
	IntroduceText = "注水龟龟，男性，中年，籍贯美食星，廉价肉铺老板。\n据可靠消息称，罪犯逃亡前累计卖出过万磅注水肉，而据食客回忆，吃这家的肉就好像喝了一大杯水……\n\n联系人：美食星消费者协会 肥科特",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 110,
			Enemy = {
				{
					Value = 246121,
					Level = 110,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 50,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 132,
			Enemy = {
				{
					Value = 246122,
					Level = 132,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 50,
				},
			},
		},
		{
			SupportLevel = 154,
			Enemy = {
				{
					Value = 246123,
					Level = 154,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 50,
				},
			},
		},
	},
	Desc = "罪名：在自己的小店中卖出注水率500%的劣质肉品。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id042] =
{
	Id = 42,
	Name = "通缉肥肉龟龟",
	Boss = false,
	IntroduceText = "肥肉龟龟，男性，中年，籍贯美食星。\n今日接获举报，罪犯将肥肉冒充五花肉制作寿司兜售给食客，导致食客减肥失败，特此通缉。\n\n联系人：高级寿司协会 苔之助先生",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 110,
			Enemy = {
				{
					Value = 246124,
					Level = 110,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 50,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 132,
			Enemy = {
				{
					Value = 246125,
					Level = 132,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 50,
				},
			},
		},
		{
			SupportLevel = 154,
			Enemy = {
				{
					Value = 246126,
					Level = 154,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 50,
				},
			},
		},
	},
	Desc = "罪名：使用全肥肉冒充五花肉制作寿司，卖给食客。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id043] =
{
	Id = 43,
	Name = "通缉臭虾龟龟",
	Boss = false,
	IntroduceText = "臭虾龟龟，男性，目测中年，籍贯美食星。\n近日接获举报，该人员为节省电费未启动冰柜冷冻装置存储鲜虾，并将不新鲜的虾肉制成寿司，影响极其恶劣。\n\n联系人：高级寿司协会 酱油子小姐",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 110,
			Enemy = {
				{
					Value = 246127,
					Level = 110,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 50,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 132,
			Enemy = {
				{
					Value = 246128,
					Level = 132,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 50,
				},
			},
		},
		{
			SupportLevel = 154,
			Enemy = {
				{
					Value = 246129,
					Level = 154,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 50,
				},
			},
		},
	},
	Desc = "罪名：为了省钱买了劣质的冰柜储存鲜虾，还将这种虾加了很多调料卖给食客。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id044] =
{
	Id = 44,
	Name = "通缉乌贼丸子",
	Boss = true,
	IntroduceText = "乌贼丸子，性别不详，年龄不详，籍贯美食星，全身墨黑，身高大约2厘米。\n据多人举报，该人员将特制墨汁加入肉丸，致食客黑牙，需清洗三天才能恢复，影响恶劣，特此通缉。\n\n联系人：煮物镇第一牙科医院牙周科 咬大夫",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 120,
			Enemy = {
				{
					Value = 246130,
					Level = 120,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
				{
					Value = 2,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 144,
			Enemy = {
				{
					Value = 246131,
					Level = 144,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
			},
		},
		{
			SupportLevel = 168,
			Enemy = {
				{
					Value = 246132,
					Level = 168,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
			},
		},
	},
	Desc = "罪名：用墨汁做丸子馅料，让吃了丸子的食客牙齿变黑。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id045] =
{
	Id = 45,
	Name = "通缉超辣布丁",
	Boss = true,
	IntroduceText = "超辣布丁，女性，青年，籍贯美食星，最近处于失恋期。\n据受害者描述，该人员由于和男友分手而精神失常，不断地结交新的男友，并在接吻时往对方嘴里灌辣椒油，非常恐怖。\n\n联系人：超辣布丁前男友 芥末饼干先生",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 120,
			Enemy = {
				{
					Value = 246133,
					Level = 120,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
				{
					Value = 2,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 144,
			Enemy = {
				{
					Value = 246134,
					Level = 144,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
			},
		},
		{
			SupportLevel = 168,
			Enemy = {
				{
					Value = 246135,
					Level = 168,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
			},
		},
	},
	Desc = "罪名：在接吻时往男朋友嘴里灌辣椒油。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id046] =
{
	Id = 46,
	Name = "通缉化工肉球",
	Boss = false,
	IntroduceText = "化工肉球，女性，疑似中年，籍贯美食星，高危人员，接触时请务必小心！\n经官方信息记载，该人员为■■■参与者，曾于■■■，经由■■■后发生异变，内含剧毒肉馅，暴露在空气中时具有挥发性。\n\n联系人：请致电联系，联系人X",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 130,
			Enemy = {
				{
					Value = 246136,
					Level = 130,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 156,
			Enemy = {
				{
					Value = 246137,
					Level = 156,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 182,
			Enemy = {
				{
					Value = 246138,
					Level = 182,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
	},
	Desc = "罪名：传播具有毒性的气体。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id047] =
{
	Id = 47,
	Name = "通缉黑心饺子",
	Boss = false,
	IntroduceText = "黑心饺子，男性，疑似未成年，籍贯美食星。\n接到多人举报，该人员在给客人下饺子时，有意挑破饺子皮，让客人没法吃到完整饺子，引起民愤，特此通缉。\n\n联系人：美食星料理协会 米淇淋厨师长",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 130,
			Enemy = {
				{
					Value = 246139,
					Level = 130,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 156,
			Enemy = {
				{
					Value = 246140,
					Level = 156,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 182,
			Enemy = {
				{
					Value = 246141,
					Level = 182,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
	},
	Desc = "罪名：给客人下饺子时，故意把饺子皮挑破，让客人吃到的都是破饺子。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id048] =
{
	Id = 48,
	Name = "通缉变质圈",
	Boss = false,
	IntroduceText = "变质圈，男性，老年，籍贯美食星，外表与轮胎十分相似，总是出没在汽车修理店。\n据家属描述，该人员患上了老年痴呆，总是以为自己是轮胎，会偷偷混进汽车店装成轮胎，并给换上他的汽车造成很大故障。\n\n联系人：变质圈外孙 多拿滋",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 140,
			Enemy = {
				{
					Value = 246142,
					Level = 140,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 65,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 168,
			Enemy = {
				{
					Value = 246143,
					Level = 168,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 65,
				},
			},
		},
		{
			SupportLevel = 196,
			Enemy = {
				{
					Value = 246144,
					Level = 196,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 65,
				},
			},
		},
	},
	Desc = "罪名：伪装成轮胎，给汽车造成故障。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id049] =
{
	Id = 49,
	Name = "通缉浓浆多拿滋",
	Boss = false,
	IntroduceText = "浓浆多拿滋，女性，疑似成年，籍贯美食星，身上涂抹浓稠糖浆。\n据举报，该人员以涂抹超浓糖浆的甜甜圈吸引孩子前往，该糖浆会牢牢沾在牙齿上导致蛀牙，特此通缉。\n\n联系人：爱食口腔医院甜品工厂总院 白砂主任",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 140,
			Enemy = {
				{
					Value = 246145,
					Level = 140,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 65,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 168,
			Enemy = {
				{
					Value = 246146,
					Level = 168,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 65,
				},
			},
		},
		{
			SupportLevel = 196,
			Enemy = {
				{
					Value = 246147,
					Level = 196,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 65,
				},
			},
		},
	},
	Desc = "罪名：使用未经许可的特浓糖浆制作甜甜圈，使小孩子蛀牙。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id050] =
{
	Id = 50,
	Name = "通缉僵尸肉猪",
	Boss = false,
	IntroduceText = "僵尸肉猪，男性，疑似青年，籍贯冒险星，高危人员，接触时请务必小心！\n经官方信息记载，该人员为■■参与者，曾于■■，经由■■后发生异变，具有攻击性，咬到正常人后会传播僵尸病毒。\n\n联系人：请致电联系，联系人X",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 150,
			Enemy = {
				{
					Value = 246148,
					Level = 150,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 70,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 180,
			Enemy = {
				{
					Value = 246149,
					Level = 180,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 70,
				},
			},
		},
		{
			SupportLevel = 210,
			Enemy = {
				{
					Value = 246150,
					Level = 210,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 70,
				},
			},
		},
	},
	Desc = "罪名:传播僵尸病毒。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id051] =
{
	Id = 51,
	Name = "通缉硬化豆泥",
	Boss = false,
	IntroduceText = "硬化豆泥，男性，籍贯美食星，身高大约2厘米。\n据多人举报，该人员在快餐店打工期间，将劣质豆泥混入新鲜豆泥充数，致豆泥口感接近水泥，目前已有上百名食客崩牙。\n\n联系人：爱食口腔医院鲷鱼镇分院 红豆医生",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 150,
			Enemy = {
				{
					Value = 246151,
					Level = 150,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 70,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 180,
			Enemy = {
				{
					Value = 246152,
					Level = 180,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 70,
				},
			},
		},
		{
			SupportLevel = 210,
			Enemy = {
				{
					Value = 246153,
					Level = 210,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 70,
				},
			},
		},
	},
	Desc = "罪名：制作如同水泥般坚硬的豆泥，让毫无准备的食客门牙崩裂。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id052] =
{
	Id = 52,
	Name = "通缉下水道比撒",
	Boss = false,
	IntroduceText = "下水道比撒，男性，未成年，籍贯美食星。\n近日接获举报，该人员每次外送，必然将披萨洒落在地，收拾后送给客人，导致多人腹泻，特此通缉。\n\n联系人：险胜客家庭餐厅 拉玛森老板",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 160,
			Enemy = {
				{
					Value = 246154,
					Level = 160,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 75,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 192,
			Enemy = {
				{
					Value = 246155,
					Level = 192,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 75,
				},
			},
		},
		{
			SupportLevel = 224,
			Enemy = {
				{
					Value = 246156,
					Level = 224,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 75,
				},
			},
		},
	},
	Desc = "罪名：外送披萨时，一定会失手将披萨掉在地上，然后重新捡回去送给客人。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id053] =
{
	Id = 53,
	Name = "通缉铁饭碗左",
	Boss = false,
	IntroduceText = "铁饭碗左，女性，青年，籍贯博物馆星，曾为当地公务员。\n据相关人员检举，该人员曾以走后门的方式入职当地政府，并在公司大闹后扬长而去，为公司造成了巨大损失。\n\n联系人：博物馆星文物局 古登堡",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 30,
			Enemy = {
				{
					Value = 246157,
					Level = 30,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 10,
				},
				{
					Value = 2,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 36,
			Enemy = {
				{
					Value = 246158,
					Level = 36,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 42,
			Enemy = {
				{
					Value = 246159,
					Level = 42,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 10,
				},
			},
		},
	},
	Desc = "罪名：砸了家里安排好的铁饭碗。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id054] =
{
	Id = 54,
	Name = "通缉铁饭碗右",
	Boss = false,
	IntroduceText = "铁饭碗右，男性，青年，籍贯博物馆星，曾为当地国立院校老师。\n据相关人员检举，该人员曾以走后门的方式入职当地名校，并在办公室大闹后扬长而去，为学校造成了巨大损失。\n\n联系人：博智中学校长 史先生",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 30,
			Enemy = {
				{
					Value = 246160,
					Level = 30,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 10,
				},
				{
					Value = 2,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 36,
			Enemy = {
				{
					Value = 246161,
					Level = 36,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 42,
			Enemy = {
				{
					Value = 246162,
					Level = 42,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 10,
				},
			},
		},
	},
	Desc = "罪名：砸了家里安排好的铁饭碗。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id055] =
{
	Id = 55,
	Name = "通缉隔热碗左",
	Boss = false,
	IntroduceText = "隔热碗左，女性，青年，籍贯博物馆星。擅长装成一副无辜的样子，眼神呆滞。\n据受害者称该人员和另外一名不法分子合伙专门在客人端起滚烫的汤准备喝的时候裂开，造成客人满身是汤，特此通缉。\n\n联系人：风纪协会 理女士",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 40,
			Enemy = {
				{
					Value = 246163,
					Level = 40,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 15,
				},
				{
					Value = 2,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 48,
			Enemy = {
				{
					Value = 246164,
					Level = 48,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 15,
				},
			},
		},
		{
			SupportLevel = 56,
			Enemy = {
				{
					Value = 246165,
					Level = 56,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 15,
				},
			},
		},
	},
	Desc = "罪名：在顾客喝汤时裂开，烫伤顾客。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id056] =
{
	Id = 56,
	Name = "通缉隔热碗右",
	Boss = false,
	IntroduceText = "隔热碗右，男性，青年，籍贯博物馆星。擅长装成一副可怜的样子，眼睛里始终带着泪花。\n据受害者称该人员和另外一名不法分子合伙专门在客人端起滚烫的汤准备喝的时候裂开，造成客人满身是汤，特此通缉。\n\n联系人：风纪协会 理女士",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 40,
			Enemy = {
				{
					Value = 246166,
					Level = 40,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 15,
				},
				{
					Value = 2,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 48,
			Enemy = {
				{
					Value = 246167,
					Level = 48,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 15,
				},
			},
		},
		{
			SupportLevel = 56,
			Enemy = {
				{
					Value = 246168,
					Level = 56,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 15,
				},
			},
		},
	},
	Desc = "罪名：在顾客喝汤时裂开，烫伤顾客。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id057] =
{
	Id = 57,
	Name = "通缉假入口",
	Boss = false,
	IntroduceText = "假入口，性别不明，青年，原籍冒险星，憧憬成为和平安全的生活。\n据受害者称，该人员偷渡博物馆星并冒充入口，实际仍然指向冒险星副本，致游客身处险境。\n\n联系人：冒险星冒险者协会 斯沃德·马吉克",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 50,
			Enemy = {
				{
					Value = 246169,
					Level = 50,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 20,
				},
				{
					Value = 2,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 60,
			Enemy = {
				{
					Value = 246170,
					Level = 60,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 70,
			Enemy = {
				{
					Value = 246171,
					Level = 70,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 20,
				},
			},
		},
	},
	Desc = "罪名：指向错误的方向，让游客晕头转向。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id058] =
{
	Id = 58,
	Name = "通缉危险出口",
	Boss = false,
	IntroduceText = "危险出口，性别不明，青年，籍贯冒险星，幻想着会遇到怪物而经常苦修。\n据受害者描述，该人员伪装成博物馆的出口，以锻炼求生技能为借口把游客们导向危险的地方。\n\n联系人：冒险星冒险者协会 斯沃德·马吉克",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 50,
			Enemy = {
				{
					Value = 246172,
					Level = 50,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 20,
				},
				{
					Value = 2,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 60,
			Enemy = {
				{
					Value = 246173,
					Level = 60,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 70,
			Enemy = {
				{
					Value = 246174,
					Level = 70,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 20,
				},
			},
		},
	},
	Desc = "罪名：指向错误的出口，让游客陷入危险。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id059] =
{
	Id = 59,
	Name = "通缉劣质漆瓷片",
	Boss = false,
	IntroduceText = "劣质漆瓷片，女性，中年，籍贯博物馆星。通体绿色，双眼发红。\n据受害者称，该人员把自己涂满绿漆想伪装成玉器混入高档展厅。但是因为油漆太过劣质导致接触过的人员手上都沾满了绿漆。\n\n联系人：文物厅总管局 察尔斯",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 60,
			Enemy = {
				{
					Value = 246175,
					Level = 60,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 25,
				},
				{
					Value = 2,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 72,
			Enemy = {
				{
					Value = 246176,
					Level = 72,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 25,
				},
			},
		},
		{
			SupportLevel = 84,
			Enemy = {
				{
					Value = 246177,
					Level = 84,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 25,
				},
			},
		},
	},
	Desc = "罪名：企图伪装成玉器，并把绿油漆弄到工作人员身上。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id060] =
{
	Id = 60,
	Name = "通缉噪音编钟",
	Boss = false,
	IntroduceText = "噪音编钟，男性，老年，籍贯博物馆星。体型庞大，身着铁锈色的外衣，眼冒红光。\n据中央古典乐团举报，一名非乐团成员混入乐团内，并在正式演出时制造非常不和谐的噪音，导致观众纷纷要求退票。对乐团造成严重损失。\n\n联系人：古典乐团总指挥爱德华先生",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 60,
			Enemy = {
				{
					Value = 246178,
					Level = 60,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 25,
				},
				{
					Value = 2,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 72,
			Enemy = {
				{
					Value = 246179,
					Level = 72,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 25,
				},
			},
		},
		{
			SupportLevel = 84,
			Enemy = {
				{
					Value = 246180,
					Level = 84,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 25,
				},
			},
		},
	},
	Desc = "罪名：混入乐团，发出不和谐的声音。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id061] =
{
	Id = 61,
	Name = "通缉腐味兽面鼎",
	Boss = true,
	IntroduceText = "腐味兽面鼎，性别不详，籍贯博物馆星，散发着淡淡的腐味，尤其喜欢看奇怪的漫画。\n据相关人员投诉，该人员在博物馆散发出的味道，严重影响游客的参观和其他文物的正常生活。\n\n联系人：文物厅总管局 古教授",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 70,
			Enemy = {
				{
					Value = 246181,
					Level = 70,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 84,
			Enemy = {
				{
					Value = 246182,
					Level = 84,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 98,
			Enemy = {
				{
					Value = 246183,
					Level = 98,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
	},
	Desc = "罪名：散发刺鼻的腐味，影响居民生活。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id062] =
{
	Id = 62,
	Name = "通缉坟头碑",
	Boss = true,
	IntroduceText = "坟头碑，男性，老年，籍贯博物馆星，经常出没于居民家中。\n据目击者描述，该人员会在深夜时刻潜入居民的家中，趁他们睡觉的时候立在床头，造成很不好的影响。\n\n联系人：监控室警局 保安",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 70,
			Enemy = {
				{
					Value = 246184,
					Level = 70,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 84,
			Enemy = {
				{
					Value = 246185,
					Level = 84,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 98,
			Enemy = {
				{
					Value = 246186,
					Level = 98,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
	},
	Desc = "罪名：在睡觉时立在别人头上，让人误以为是死亡。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id063] =
{
	Id = 63,
	Name = "通缉狂躁警戒线",
	Boss = false,
	IntroduceText = "狂躁警戒线，男性，青年，籍贯博物馆星，脾气很差。\n据相关人士介绍，该人员在发脾气时会无差别地封锁周围地一切，包括正在参观地游客，引起了秩序的混乱。\n\n联系人：监控室警局 保安",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 80,
			Enemy = {
				{
					Value = 246187,
					Level = 80,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 35,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 96,
			Enemy = {
				{
					Value = 246188,
					Level = 96,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 35,
				},
			},
		},
		{
			SupportLevel = 112,
			Enemy = {
				{
					Value = 246189,
					Level = 112,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 35,
				},
			},
		},
	},
	Desc = "罪名：滥用警戒线封锁，造成秩序混乱。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id064] =
{
	Id = 64,
	Name = "通缉收款机",
	Boss = false,
	IntroduceText = "收款机，女性，中年，籍贯博物馆星。身着黑衣，脸上泛着绿光，手上把玩着一条绿色的激光。\n据受害者举报，该人员在客人扫码付款的时候会偷偷多刷一次，造成客人钱财损失。\n\n联系人：古文明厅超商 杰哥",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 80,
			Enemy = {
				{
					Value = 246190,
					Level = 80,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 35,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 96,
			Enemy = {
				{
					Value = 246191,
					Level = 96,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 35,
				},
			},
		},
		{
			SupportLevel = 112,
			Enemy = {
				{
					Value = 246192,
					Level = 112,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 35,
				},
			},
		},
	},
	Desc = "罪名：在客人扫码付款的时候会偷偷多刷一次，造成客人钱财损失。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id065] =
{
	Id = 65,
	Name = "通缉隐形摄像头",
	Boss = false,
	IntroduceText = "隐形摄像头，女性，青年，籍贯博物馆星，和普通摄像头毫无差别。\n据工作人员核实，该人员有严重的中二病，身为普通监控摄像头却幻想有超能力，强行将名字改成隐形摄像头，为人事部造成了麻烦。\n\n联系人：监控室警局 保安",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 90,
			Enemy = {
				{
					Value = 246193,
					Level = 90,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 40,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 108,
			Enemy = {
				{
					Value = 246194,
					Level = 108,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 40,
				},
			},
		},
		{
			SupportLevel = 126,
			Enemy = {
				{
					Value = 246195,
					Level = 126,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 40,
				},
			},
		},
	},
	Desc = "罪名：名字叫隐形却不能隐形。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id066] =
{
	Id = 66,
	Name = "通缉碰碰瓷家属",
	Boss = false,
	IntroduceText = "碰碰瓷家属，男性，中年，籍贯博物馆星，碰碰瓷的父亲。\n据目击者报道，该人员在儿子碎裂的时候会第一时间冲到现场大哭，并纠缠在场的所有游客，要求他们巨额赔偿，影响博物馆的经营。\n\n联系人：中心广场居委会 茶壶主任",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 90,
			Enemy = {
				{
					Value = 246196,
					Level = 90,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 40,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 108,
			Enemy = {
				{
					Value = 246197,
					Level = 108,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 40,
				},
			},
		},
		{
			SupportLevel = 126,
			Enemy = {
				{
					Value = 246198,
					Level = 126,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 40,
				},
			},
		},
	},
	Desc = "罪名：敲诈目睹碰碰瓷碎裂的游客。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id067] =
{
	Id = 67,
	Name = "通缉伪造鱼化石",
	Boss = false,
	IntroduceText = "伪造鱼化石，性别不明，年龄不明，籍贯不明，属于三无人士。\n据官方描述，该人员登记在案的所有信息全部是伪造的，包括种族在内都是谎报的，真实身份正在严密调查中。\n\n联系人：博物馆星文物局 古登堡",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 100,
			Enemy = {
				{
					Value = 246199,
					Level = 100,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 45,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 120,
			Enemy = {
				{
					Value = 246200,
					Level = 120,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 45,
				},
			},
		},
		{
			SupportLevel = 140,
			Enemy = {
				{
					Value = 246201,
					Level = 140,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 45,
				},
			},
		},
	},
	Desc = "罪名：伪造身份证件。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id068] =
{
	Id = 68,
	Name = "通缉伪造龟化石",
	Boss = false,
	IntroduceText = "伪造龟化石，性别不明，年龄不明，籍贯不明，属于三无人士。\n据官方描述，该人员登记在案的所有信息全部是伪造的，包括种族在内都是谎报的，真实身份正在严密调查中。\n\n联系人：博物馆星文物局 古登堡",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 100,
			Enemy = {
				{
					Value = 246202,
					Level = 100,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 45,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 120,
			Enemy = {
				{
					Value = 246203,
					Level = 120,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 45,
				},
			},
		},
		{
			SupportLevel = 140,
			Enemy = {
				{
					Value = 246204,
					Level = 140,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 45,
				},
			},
		},
	},
	Desc = "罪名：伪造身份证件。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id069] =
{
	Id = 69,
	Name = "通缉黑鱬",
	Boss = false,
	IntroduceText = "黑鱬，老年，男性，籍贯博物馆星，一天有23小时趴在地上。\n据工作人员反馈，该人员趴在地面上地时间过长，身体分泌的粘液很难清洗，造成了清洁困难。\n\n联系人：博物馆后勤部 卫队长",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 110,
			Enemy = {
				{
					Value = 246205,
					Level = 110,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 50,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 132,
			Enemy = {
				{
					Value = 246206,
					Level = 132,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 50,
				},
			},
		},
		{
			SupportLevel = 154,
			Enemy = {
				{
					Value = 246207,
					Level = 154,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 50,
				},
			},
		},
	},
	Desc = "罪名：长期趴在地上留下难以清洗的污痕。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id070] =
{
	Id = 70,
	Name = "通缉紫鱬",
	Boss = false,
	IntroduceText = "紫鱬，老年，女性，籍贯博物馆星，一天有23小时来回挪动。\n据工作人员反馈，该人员四处移动的时间过长，身体分泌的粘液到处都是，造成了清洁困难。\n\n联系人：博物馆后勤部 卫队长",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 110,
			Enemy = {
				{
					Value = 246208,
					Level = 110,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 50,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 132,
			Enemy = {
				{
					Value = 246209,
					Level = 132,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 50,
				},
			},
		},
		{
			SupportLevel = 154,
			Enemy = {
				{
					Value = 246210,
					Level = 154,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 50,
				},
			},
		},
	},
	Desc = "罪名：长期来回移动留下难以清洗的污痕。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id071] =
{
	Id = 71,
	Name = "通缉灾祸鸮卣",
	Boss = true,
	IntroduceText = "灾祸鸮卣，中年，男性，籍贯博物馆星，具有吸引灾祸的体质。\n据目击者描述，该人员一直站在原地什么都没做，过了几分钟陨石就从天而降，摧毁了馆内很多物品并造成人员伤亡。\n\n联系人：生态园管理处 卫生纸先生",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 120,
			Enemy = {
				{
					Value = 246211,
					Level = 120,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
				{
					Value = 2,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 144,
			Enemy = {
				{
					Value = 246212,
					Level = 144,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
			},
		},
		{
			SupportLevel = 168,
			Enemy = {
				{
					Value = 246213,
					Level = 168,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
			},
		},
	},
	Desc = "罪名：什么都没做，但是会引来灾祸。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id072] =
{
	Id = 72,
	Name = "通缉不详鸮卣",
	Boss = true,
	IntroduceText = "不详鸮卣，年龄未知，性别不明，产地博物馆星，为机械制品。\n据制造人员描述，该型号作为博物馆内协助管理的生物智能被制造出来，却在即将完工时暴走，偷走了核心的芯片并毁掉了研究成果。\n\n联系人：博物馆星生物科研中心 哆来咪秘书",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 120,
			Enemy = {
				{
					Value = 246214,
					Level = 120,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
				{
					Value = 2,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 144,
			Enemy = {
				{
					Value = 246215,
					Level = 144,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
			},
		},
		{
			SupportLevel = 168,
			Enemy = {
				{
					Value = 246216,
					Level = 168,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
			},
		},
	},
	Desc = "罪名：破坏研究院，盗走核心芯片。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id073] =
{
	Id = 73,
	Name = "通缉火山快走龙",
	Boss = false,
	IntroduceText = "火山快走龙，女性，中年，籍贯博物馆星，体表温度达500℃以上。\n据游客举报，该人员对自己严重缺乏防火意识，在充满易燃物的博物馆内大肆散步，引燃大量展品，造成严重损失。\n\n联系人：化石厅消防队 阿消队长",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 130,
			Enemy = {
				{
					Value = 246217,
					Level = 130,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 156,
			Enemy = {
				{
					Value = 246218,
					Level = 156,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 182,
			Enemy = {
				{
					Value = 246219,
					Level = 182,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
	},
	Desc = "罪名：不顾身体高温易燃，随意在馆内散步，引发火灾。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id074] =
{
	Id = 74,
	Name = "通缉荒原快走龙",
	Boss = false,
	IntroduceText = "荒原快走龙，男性，老年，籍贯博物馆星，一天要摄入20公升的水。\n据游客投诉，该人员长期在馆内肆无忌惮地闲逛，并掠夺能看到的所有饮用水，造成馆内瓶装水价格地飙升。\n\n联系人：化石厅超商 阿伟",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 130,
			Enemy = {
				{
					Value = 246220,
					Level = 130,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 156,
			Enemy = {
				{
					Value = 246221,
					Level = 156,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 182,
			Enemy = {
				{
					Value = 246222,
					Level = 182,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
	},
	Desc = "罪名：喝掉太多水导致博物馆瓶装水价格上涨。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id075] =
{
	Id = 75,
	Name = "通缉地狱一角龙",
	Boss = false,
	IntroduceText = "地狱一角龙，中年，男性，籍贯博物馆星，喜欢低海拔的地方。\n据管理员投诉，该人员因为怀念家乡的地狱而在博物馆不停地挖洞，试图回到家乡，严重影响了其他居民地生活。\n\n联系人：泥塑厅硬化科 铁骨教授",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 140,
			Enemy = {
				{
					Value = 246223,
					Level = 140,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 65,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 168,
			Enemy = {
				{
					Value = 246224,
					Level = 168,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 65,
				},
			},
		},
		{
			SupportLevel = 196,
			Enemy = {
				{
					Value = 246225,
					Level = 196,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 65,
				},
			},
		},
	},
	Desc = "罪名：在博物馆内挖洞。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id076] =
{
	Id = 76,
	Name = "通缉雨林一角龙",
	Boss = false,
	IntroduceText = "雨林一角龙，青年，女性，籍贯博物馆星，喜欢潮湿的地方。\n据管理员投诉，该人员因为怀念家乡的雨林而在博物馆不停地喷水，试图将馆区变成雨林，严重影响了其他居民的生活。\n\n联系人：泥塑厅定型科 黏液教授",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 140,
			Enemy = {
				{
					Value = 246226,
					Level = 140,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 65,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 168,
			Enemy = {
				{
					Value = 246227,
					Level = 168,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 65,
				},
			},
		},
		{
			SupportLevel = 196,
			Enemy = {
				{
					Value = 246228,
					Level = 196,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 65,
				},
			},
		},
	},
	Desc = "罪名：在博物馆内喷水。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id077] =
{
	Id = 77,
	Name = "通缉黑客摄像头",
	Boss = false,
	IntroduceText = "黑客摄像头，男性，中年，籍贯博物馆星，看上去跟普通摄像头无差。\n据多人举报，该人员伪装成普通的监控摄像头，实则骚扰游客，做出偷窥行为，并把罪名嫁祸给其他无辜的摄像头。\n\n联系人：监控室警局 保安",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 150,
			Enemy = {
				{
					Value = 246229,
					Level = 150,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 70,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 180,
			Enemy = {
				{
					Value = 246230,
					Level = 180,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 70,
				},
			},
		},
		{
			SupportLevel = 210,
			Enemy = {
				{
					Value = 246231,
					Level = 210,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 70,
				},
			},
		},
	},
	Desc = "罪名：伪装成普通摄像头进行偷窥。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id078] =
{
	Id = 78,
	Name = "通缉斑点缸",
	Boss = false,
	IntroduceText = "斑点缸，男性，中年，籍贯博物馆星，有着不符合大众的审美。\n据负责人介绍，该人员有严重的偏执症，喜欢在各种东西上涂装斑点的装饰，严重影响了博物馆的正常运作。\n\n联系人：监控室备案区 盐队长",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 150,
			Enemy = {
				{
					Value = 246232,
					Level = 150,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 70,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 180,
			Enemy = {
				{
					Value = 246233,
					Level = 180,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 70,
				},
			},
		},
		{
			SupportLevel = 210,
			Enemy = {
				{
					Value = 246234,
					Level = 210,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 70,
				},
			},
		},
	},
	Desc = "罪名：把所有的东西都涂上斑点。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id079] =
{
	Id = 79,
	Name = "通缉克隆化石",
	Boss = false,
	IntroduceText = "克隆化石，老年，疑似男性，籍贯博物馆星，高危人员，接触时请务必小心！\n经官方信息记载，该人员为■■■■参与者，曾于■■■■■，经由■■■■后发生异变，缺少理性和生活常识，可能做出任何出格行为。\n\n联系人：请致电联系，联系人X",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 160,
			Enemy = {
				{
					Value = 246235,
					Level = 160,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 75,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 192,
			Enemy = {
				{
					Value = 246236,
					Level = 192,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 75,
				},
			},
		},
		{
			SupportLevel = 224,
			Enemy = {
				{
					Value = 246237,
					Level = 224,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 75,
				},
			},
		},
	},
	Desc = "罪名：精神状态不稳定，容易做出出格行为。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id080] =
{
	Id = 80,
	Name = "通缉绝味鸭",
	Boss = false,
	IntroduceText = "绝味鸭，青年，男性，籍贯美食星，对卤味很有研究。\n据顾客投诉，该人员无视博物馆禁止饮食的规定，在馆区内贩卖高价辣味鸭脖，因为太过好吃让人无法拒绝。\n\n联系人：中心广场招商管理处 古铜经理",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 160,
			Enemy = {
				{
					Value = 246238,
					Level = 160,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 75,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 192,
			Enemy = {
				{
					Value = 246239,
					Level = 192,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 75,
				},
			},
		},
		{
			SupportLevel = 224,
			Enemy = {
				{
					Value = 246240,
					Level = 224,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 75,
				},
			},
		},
	},
	Desc = "罪名：在禁止饮食的博物馆内贩卖鸭脖。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id081] =
{
	Id = 81,
	Name = "通缉厕所牌",
	Boss = false,
	IntroduceText = "厕所牌，青年，女性，籍贯悬疑星，沉默寡言，喜欢暗中观察。\n据有关人员举报，该人员潜伏在咖啡馆的厕所处，故意搞反男女厕所的标志，造成了很多尴尬的局面。\n\n联系人：咖啡馆 渔网夫人",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 30,
			Enemy = {
				{
					Value = 246241,
					Level = 30,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 10,
				},
				{
					Value = 2,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 36,
			Enemy = {
				{
					Value = 246242,
					Level = 36,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 42,
			Enemy = {
				{
					Value = 246243,
					Level = 42,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 10,
				},
			},
		},
	},
	Desc = "罪名：弄混咖啡馆的男女厕所的标识，让顾客走错厕所。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id082] =
{
	Id = 82,
	Name = "通缉八卦小报",
	Boss = false,
	IntroduceText = "八卦小报，青年，男性，籍贯悬疑星，总是戴着面具。\n据大量居民投诉，该人员总是偷听别人的对话，把不想被公开的八卦新闻刊登在自己的报纸面具上四处传播，造成很不好的影响。\n\n联系人：甜心街报刊亭 书爷爷",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 40,
			Enemy = {
				{
					Value = 246244,
					Level = 40,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 15,
				},
				{
					Value = 2,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 48,
			Enemy = {
				{
					Value = 246245,
					Level = 48,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 15,
				},
			},
		},
		{
			SupportLevel = 56,
			Enemy = {
				{
					Value = 246246,
					Level = 56,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 15,
				},
			},
		},
	},
	Desc = "罪名：把居民的秘密刊登在自己脸上四处传播。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id083] =
{
	Id = 83,
	Name = "通缉停摆怀表",
	Boss = false,
	IntroduceText = "停摆怀表，老年，女性，籍贯悬疑星。\n经投诉，该人员已经停摆许久，但仍然拒绝承认失灵，凭感觉谎报时间，给使用者造成了麻烦。\n\n联系人：悬疑星旧货回收中心 手套爷爷",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 40,
			Enemy = {
				{
					Value = 246247,
					Level = 40,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 15,
				},
				{
					Value = 2,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 48,
			Enemy = {
				{
					Value = 246248,
					Level = 48,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 15,
				},
			},
		},
		{
			SupportLevel = 56,
			Enemy = {
				{
					Value = 246249,
					Level = 56,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 15,
				},
			},
		},
	},
	Desc = "罪名：谎报时间，影响人们的生活。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id084] =
{
	Id = 84,
	Name = "通缉小绿帽",
	Boss = false,
	IntroduceText = "小绿帽，青年男性，籍贯悬疑星，喜欢火上浇油。\n据通缉令所述，该人员经常潜伏在有感情裂痕的家庭中，并在矛盾爆发时扣在其中一方的头上，造成进一步精神打击，十分可恶。\n\n联系人：甜心街玫瑰社区 探戈女士",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 50,
			Enemy = {
				{
					Value = 246250,
					Level = 50,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 20,
				},
				{
					Value = 2,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 60,
			Enemy = {
				{
					Value = 246251,
					Level = 60,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 70,
			Enemy = {
				{
					Value = 246252,
					Level = 70,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 20,
				},
			},
		},
	},
	Desc = "罪名：扣在发生了感情问题的居民的头上。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id085] =
{
	Id = 85,
	Name = "通缉小红帽",
	Boss = false,
	IntroduceText = "小红帽，青年，女性，籍贯悬疑星。\n据投诉，该人员看到任何年龄段的女性都会称呼其为奶奶，并无视对方的抗议，伤害了很多对年龄比较敏感的女性。\n\n联系人：甜心街郁金香社区 泡芙太太",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 50,
			Enemy = {
				{
					Value = 246253,
					Level = 50,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 20,
				},
				{
					Value = 2,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 60,
			Enemy = {
				{
					Value = 246254,
					Level = 60,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 70,
			Enemy = {
				{
					Value = 246255,
					Level = 70,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 20,
				},
			},
		},
	},
	Desc = "罪名：管所有女性都称呼为奶奶。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id086] =
{
	Id = 86,
	Name = "通缉鬼火路灯",
	Boss = false,
	IntroduceText = "鬼火路灯，青年，女性，籍贯悬疑星，长年燃烧着蓝色灯火。\n据目击者报告，该人员在深夜冒充指路明灯，把迷路的居民指引到还在修缮的施工区，在还没干透的水泥上留下脚印。\n\n联系人：冷清街施工大队 斯琼队长",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 60,
			Enemy = {
				{
					Value = 246256,
					Level = 60,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 25,
				},
				{
					Value = 2,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 72,
			Enemy = {
				{
					Value = 246257,
					Level = 72,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 25,
				},
			},
		},
		{
			SupportLevel = 84,
			Enemy = {
				{
					Value = 246258,
					Level = 84,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 25,
				},
			},
		},
	},
	Desc = "罪名：把居民引入还在修路的地区。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id087] =
{
	Id = 87,
	Name = "通缉手残笔",
	Boss = false,
	IntroduceText = "手残笔，青年，男性，籍贯悬疑星。\n据购买者检举，该人员混杂在商店的普通羽毛笔之中，会让使用者无意识地书写错别字，使他们以为自己患上了手癌。\n\n联系人：邮局公证处 墨水先生",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 60,
			Enemy = {
				{
					Value = 246259,
					Level = 60,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 25,
				},
				{
					Value = 2,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 72,
			Enemy = {
				{
					Value = 246260,
					Level = 72,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 25,
				},
			},
		},
		{
			SupportLevel = 84,
			Enemy = {
				{
					Value = 246261,
					Level = 84,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 25,
				},
			},
		},
	},
	Desc = "罪名：让使用者写错字。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id088] =
{
	Id = 88,
	Name = "通缉腹黑猫",
	Boss = true,
	IntroduceText = "腹黑猫，老年，女性，籍贯悬疑星，腹部有一块黑色的斑点。\n据管理者介绍，该人员会在每天夜晚准时出现在冷清街口，等到车辆经过就侧躺过来，装作腹部受伤的样子榨取钱财。\n\n联系人：冷清街巡逻队 克雷泽探长",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 70,
			Enemy = {
				{
					Value = 246262,
					Level = 70,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 84,
			Enemy = {
				{
					Value = 246263,
					Level = 84,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 98,
			Enemy = {
				{
					Value = 246264,
					Level = 98,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
	},
	Desc = "罪名：利用腹部的花色碰瓷。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id089] =
{
	Id = 89,
	Name = "通缉劣质警报器",
	Boss = true,
	IntroduceText = "劣质警报器，中年，男性，籍贯悬疑星，非常喜欢唱歌。\n经居民投诉，该人员在发起警报时经常发出刺耳的歌声，严重影响居民生活，在理论后被以“警报就是要让人都听到”为由拒绝整改。\n\n联系人：警局监控室 DD队长",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 70,
			Enemy = {
				{
					Value = 246265,
					Level = 70,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 84,
			Enemy = {
				{
					Value = 246266,
					Level = 84,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 98,
			Enemy = {
				{
					Value = 246267,
					Level = 98,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
	},
	Desc = "罪名：大声吵嚷，影响居民休息。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id090] =
{
	Id = 90,
	Name = "通缉迷彩路障",
	Boss = false,
	IntroduceText = "迷彩路障，青年，男性，籍贯悬疑星，性格害羞内敛，总是想隐藏自己。\n路障还搞迷彩的，是怕人看得见吗？\n\n联系人：侦探街施工大队 琼斯队长",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 80,
			Enemy = {
				{
					Value = 246268,
					Level = 80,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 35,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 96,
			Enemy = {
				{
					Value = 246269,
					Level = 96,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 35,
				},
			},
		},
		{
			SupportLevel = 112,
			Enemy = {
				{
					Value = 246270,
					Level = 112,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 35,
				},
			},
		},
	},
	Desc = "罪名：存在就是罪过。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id091] =
{
	Id = 91,
	Name = "通缉占位路障",
	Boss = false,
	IntroduceText = "占位路障，青年，性别未知，籍贯悬疑星，口头禅是太懒了，不想动。\n经居民投诉，该人员经常在通行的街道上晒太阳，严重影响了人们的正常通行。\n\n联系人：侦探街施工大队 琼斯队长",
	NumCap = 4,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 80,
			Enemy = {
				{
					Value = 246271,
					Level = 80,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 35,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 96,
			Enemy = {
				{
					Value = 246272,
					Level = 96,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 35,
				},
			},
		},
		{
			SupportLevel = 112,
			Enemy = {
				{
					Value = 246273,
					Level = 112,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 35,
				},
			},
		},
	},
	Desc = "罪名：影响他人正常通行。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id092] =
{
	Id = 92,
	Name = "通缉藤蔓手铐",
	Boss = false,
	IntroduceText = "藤蔓手铐，老年，女性，籍贯悬疑星，曾为警局得力好手。\n档案资料记载，该人员之前为警局的警长，因为对嫌疑人滥用尖刺之刑而被剥夺警员证，并对此怀恨在心，开始作恶。\n\n联系人：警局重案科 丁丁探长",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 90,
			Enemy = {
				{
					Value = 246274,
					Level = 90,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 40,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 108,
			Enemy = {
				{
					Value = 246275,
					Level = 108,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 40,
				},
			},
		},
		{
			SupportLevel = 126,
			Enemy = {
				{
					Value = 246276,
					Level = 126,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 40,
				},
			},
		},
	},
	Desc = "罪名：对嫌疑人使用私刑。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id093] =
{
	Id = 93,
	Name = "通缉好兄弟手铐",
	Boss = false,
	IntroduceText = "好兄弟手铐，青年，男性，籍贯悬疑星，擅长哄骗他人。\n经涉案人士举报，该人员常以好兄弟的名义接近受害者，在对方失去防备时将其铐住，并勒索金钱财物。\n\n联系人：警局行窃科 签字笔探员",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 90,
			Enemy = {
				{
					Value = 246277,
					Level = 90,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 40,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 108,
			Enemy = {
				{
					Value = 246278,
					Level = 108,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 40,
				},
			},
		},
		{
			SupportLevel = 126,
			Enemy = {
				{
					Value = 246279,
					Level = 126,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 40,
				},
			},
		},
	},
	Desc = "罪名：用好兄弟的名号诱骗他人，并勒索钱财。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id094] =
{
	Id = 94,
	Name = "通缉诅咒信",
	Boss = false,
	IntroduceText = "诅咒信，疑似女性，著名通缉犯。\n据官方介绍，该人员为S-001级通缉犯，接受来自各个地方的委托，承接任务后会抵达对方邮箱，用自己恐怖的外表和诅咒的话语恫吓目标。\n\n联系人：星际联邦总局 猫探长",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 100,
			Enemy = {
				{
					Value = 246280,
					Level = 100,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 45,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 120,
			Enemy = {
				{
					Value = 246281,
					Level = 120,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 45,
				},
			},
		},
		{
			SupportLevel = 140,
			Enemy = {
				{
					Value = 246282,
					Level = 140,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 45,
				},
			},
		},
	},
	Desc = "罪名：接受犯罪委托，恐吓居民。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id095] =
{
	Id = 95,
	Name = "通缉分手信",
	Boss = false,
	IntroduceText = "分手信，中年，男性，籍贯悬疑星。\n据大量居民投诉，该人员总是溜进邮筒，将自己寄往热恋情侣家中，用误会拆散他们，大大降低了星球的婚育率。\n\n联系人：甜心街计生办 普西神父",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 100,
			Enemy = {
				{
					Value = 246283,
					Level = 100,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 45,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 120,
			Enemy = {
				{
					Value = 246284,
					Level = 120,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 45,
				},
			},
		},
		{
			SupportLevel = 140,
			Enemy = {
				{
					Value = 246285,
					Level = 140,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 45,
				},
			},
		},
	},
	Desc = "罪名：用误会拆散情侣，影响星球生育率。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id096] =
{
	Id = 96,
	Name = "通缉诅咒笔记",
	Boss = false,
	IntroduceText = "诅咒笔记，青年，男性，籍贯悬疑星。\n经不知名的粉丝举报，该人员的设定涉嫌抄袭某个遥远星球上的漫画，遭受到当地粉丝的强烈抵制，并认为“诅咒这个词也太俗了”。\n\n联系人：XX星 XX笔记爱好者官方一群",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 110,
			Enemy = {
				{
					Value = 246286,
					Level = 110,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 50,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 132,
			Enemy = {
				{
					Value = 246287,
					Level = 132,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 50,
				},
			},
		},
		{
			SupportLevel = 154,
			Enemy = {
				{
					Value = 246288,
					Level = 154,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 50,
				},
			},
		},
	},
	Desc = "罪名：涉嫌抄袭其他作品。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id097] =
{
	Id = 97,
	Name = "通缉剧透笔记",
	Boss = false,
	IntroduceText = "剧透笔记，性别不详，籍贯悬疑星，酷爱剧透。\n相关人士称，该人员常混入剧组，偷看剧本后，将凶手公之于众，极大损害了观众的观影情绪。有时甚至会提前曝出人气配角将在第12集中被干掉的剧情细节。\n\n联系人：悬疑星大电视台 卡邮轮导演",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 110,
			Enemy = {
				{
					Value = 246289,
					Level = 110,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 50,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 132,
			Enemy = {
				{
					Value = 246290,
					Level = 132,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 50,
				},
			},
		},
		{
			SupportLevel = 154,
			Enemy = {
				{
					Value = 246291,
					Level = 154,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 50,
				},
			},
		},
	},
	Desc = "罪名：剧透推理剧情。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id098] =
{
	Id = 98,
	Name = "通缉诈骗信",
	Boss = true,
	IntroduceText = "诈骗信，中年，男性，籍贯悬疑星，原为地方银行职员。\n据前经理描述，该人员因不满薪资待遇而离职，并运用银行的技术开出虚假账单诈骗居民的钱财，影响了公司的声誉。\n\n联系人：问号银行 泰尔斯经理",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 120,
			Enemy = {
				{
					Value = 246292,
					Level = 120,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
				{
					Value = 2,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 144,
			Enemy = {
				{
					Value = 246293,
					Level = 144,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
			},
		},
		{
			SupportLevel = 168,
			Enemy = {
				{
					Value = 246294,
					Level = 168,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
			},
		},
	},
	Desc = "罪名：伪造账单进行诈骗。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id099] =
{
	Id = 99,
	Name = "通缉高速行李车",
	Boss = true,
	IntroduceText = "高速行李车，老年，男性，籍贯悬疑星，声称患有严重风湿病。\n经海关人员举报，该人员借口患病，不按照游客路线前进，专门走员工通道，其实是为了看女性工作人员换衣服。\n\n联系人：现场北站 超速列车长 ",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 120,
			Enemy = {
				{
					Value = 246295,
					Level = 120,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
				{
					Value = 2,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 144,
			Enemy = {
				{
					Value = 246296,
					Level = 144,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
			},
		},
		{
			SupportLevel = 168,
			Enemy = {
				{
					Value = 246297,
					Level = 168,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
			},
		},
	},
	Desc = "罪名：擅闯员工通道。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id100] =
{
	Id = 100,
	Name = "通缉牛油果墨水",
	Boss = false,
	IntroduceText = "牛油果墨水，中年，男性，籍贯悬疑星，闻起来香香的。\n经医院人员反馈，该人员在售卖时哄骗顾客墨水具有食用效果，然而实际只是加了牛油果香精，造成大量上当的客人发生了食物中毒。\n\n联系人：现场第一医院 莱斯特福医生",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 130,
			Enemy = {
				{
					Value = 246298,
					Level = 130,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 156,
			Enemy = {
				{
					Value = 246299,
					Level = 156,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 182,
			Enemy = {
				{
					Value = 246300,
					Level = 182,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
	},
	Desc = "罪名：骗顾客食用墨水，造成食物中毒。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id101] =
{
	Id = 101,
	Name = "通缉死亡芭比墨水",
	Boss = false,
	IntroduceText = "死亡芭比墨水，青年，女性，籍贯悬疑星，被害妄想症，总觉得别人在叫自己死王八。\n经相关人员说明，该人员精神脆弱，每当听到别人叫自己的名字时就会狂躁症发作，把特制的超饱和荧光粉墨水泼得到处都是。\n\n联系人：编辑部 记者帕克",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 130,
			Enemy = {
				{
					Value = 246301,
					Level = 130,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 156,
			Enemy = {
				{
					Value = 246302,
					Level = 156,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 182,
			Enemy = {
				{
					Value = 246303,
					Level = 182,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
	},
	Desc = "罪名：把墨水弄到别人身上。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id102] =
{
	Id = 102,
	Name = "通缉瓦斯烟斗",
	Boss = false,
	IntroduceText = "瓦斯烟斗，中年，男性，籍贯悬疑星，不喜欢香烟的味道。\n经医疗中心检举，该人员把有毒的瓦斯灌入烟斗，以过于强硬的手段帮助别人戒烟，引发了大量安全问题。\n\n联系人：现场第一医院 莱斯特福医生",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 140,
			Enemy = {
				{
					Value = 246304,
					Level = 140,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 65,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 168,
			Enemy = {
				{
					Value = 246305,
					Level = 168,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 65,
				},
			},
		},
		{
			SupportLevel = 196,
			Enemy = {
				{
					Value = 246306,
					Level = 196,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 65,
				},
			},
		},
	},
	Desc = "罪名：将有毒瓦斯灌入烟斗。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id103] =
{
	Id = 103,
	Name = "通缉缩小镜",
	Boss = false,
	IntroduceText = "缩小镜，青年，男性，籍贯悬疑星，视力不太好的样子。\n经举报，该人员将放大镜的镜片全部偷换成缩小镜，给使用者带来了很大麻烦。\n\n联系人：悬疑星叹号连锁商店 朔普先生",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 140,
			Enemy = {
				{
					Value = 246307,
					Level = 140,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 65,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 168,
			Enemy = {
				{
					Value = 246308,
					Level = 168,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 65,
				},
			},
		},
		{
			SupportLevel = 196,
			Enemy = {
				{
					Value = 246309,
					Level = 196,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 65,
				},
			},
		},
	},
	Desc = "罪名：将放大镜镜片偷换成缩小镜。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id104] =
{
	Id = 104,
	Name = "通缉三眼神猫",
	Boss = false,
	IntroduceText = "三眼神猫，中年，男性，籍贯悬疑星。\n据通缉令记载，该人员为悬疑星著名江湖骗子，收取高额的费用帮居民算命，经常在下班时间摆摊，严重影响交通。\n\n联系人：现场刑事厅 罗尔队长",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 150,
			Enemy = {
				{
					Value = 246310,
					Level = 150,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 70,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 180,
			Enemy = {
				{
					Value = 246311,
					Level = 180,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 70,
				},
			},
		},
		{
			SupportLevel = 210,
			Enemy = {
				{
					Value = 246312,
					Level = 210,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 70,
				},
			},
		},
	},
	Desc = "罪名：用算命先生的名号招摇撞骗，摆摊影响交通。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id105] =
{
	Id = 105,
	Name = "通缉化学试剂",
	Boss = false,
	IntroduceText = "化学试剂，青年，疑似男性，籍贯悬疑星，高危人员，接触时请务必小心！\n经官方信息记载，该人员为■■■■■参与者，曾于■■■■■■■，经由■■■■■■■后发生异变，性质和状态都非常不稳定。\n\n联系人：请致电联系，联系人X",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 150,
			Enemy = {
				{
					Value = 246313,
					Level = 150,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 70,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 180,
			Enemy = {
				{
					Value = 246314,
					Level = 180,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 70,
				},
			},
		},
		{
			SupportLevel = 210,
			Enemy = {
				{
					Value = 246315,
					Level = 210,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 70,
				},
			},
		},
	},
	Desc = "罪名：状态不稳定，容易爆炸。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id106] =
{
	Id = 106,
	Name = "通缉遗像框",
	Boss = false,
	IntroduceText = "遗像框，中年，男性，籍贯悬疑星，身上带着不吉利的血迹。\n据投诉，该人员经常潜入到居民家中，把居民的相片套进自己的身体，营造出死亡的感觉，非常不吉利。\n\n联系人：现场刑事厅 罗尔队长",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 160,
			Enemy = {
				{
					Value = 246316,
					Level = 160,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 75,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 192,
			Enemy = {
				{
					Value = 246317,
					Level = 192,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 75,
				},
			},
		},
		{
			SupportLevel = 224,
			Enemy = {
				{
					Value = 246318,
					Level = 224,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 75,
				},
			},
		},
	},
	Desc = "罪名：把居民的照片套进像框中，非常不吉利。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id107] =
{
	Id = 107,
	Name = "通缉注水脑",
	Boss = false,
	IntroduceText = "注水脑，中年，性别不明，籍贯悬疑星。\n经有关人员投诉，该人员混杂在科研用人脑中，智力水平远没有达到科研水平，拖慢了科研进度。\n\n联系人：现场第一医院 莱沃尔教授",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 160,
			Enemy = {
				{
					Value = 246319,
					Level = 160,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 75,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 192,
			Enemy = {
				{
					Value = 246320,
					Level = 192,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 75,
				},
			},
		},
		{
			SupportLevel = 224,
			Enemy = {
				{
					Value = 246321,
					Level = 224,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 75,
				},
			},
		},
	},
	Desc = "罪名：智力低下，拖慢科研进度。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id108] =
{
	Id = 108,
	Name = "通缉粉红史莱姆",
	Boss = false,
	IntroduceText = "粉红史莱姆，女性史莱姆成员，疑似未成年，籍贯冒险星。身高2厘米(不同手机尺寸不同)。\n据目击者称，该人员因不明原因出现在流亡街，特此通缉。\n\n联系人：密林冒险者协会 尼尔斯先生",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 40,
			Enemy = {
				{
					Value = 246322,
					Level = 40,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 15,
				},
				{
					Value = 2,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 48,
			Enemy = {
				{
					Value = 246323,
					Level = 48,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 15,
				},
			},
		},
		{
			SupportLevel = 56,
			Enemy = {
				{
					Value = 246324,
					Level = 56,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 15,
				},
			},
		},
	},
	Desc = "史莱姆家族中的小妹，幼年女性成员，酷爱甜食。平时受到哥哥们的保护，很少去危险地区，主要在宝箱谷地区活动。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id109] =
{
	Id = 109,
	Name = "通缉劣质宝箱怪",
	Boss = true,
	IntroduceText = "劣质宝箱怪，目测男性，外来物种。\n经有关人员投诉，该犯罪分子来到流亡街后，经常以宝箱族身份兜售劣质宝物，骗取财物，特此通缉。\n\n联系人：冒险家协会 切斯特先生",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 70,
			Enemy = {
				{
					Value = 246325,
					Level = 70,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 84,
			Enemy = {
				{
					Value = 246326,
					Level = 84,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 98,
			Enemy = {
				{
					Value = 246327,
					Level = 98,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
	},
	Desc = "活跃于野外地区的初级宝箱，通过其极具迷惑性的外表引诱冒险者靠近，然后“啊呜”一口吃掉。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id110] =
{
	Id = 110,
	Name = "通缉咬人宝箱怪",
	Boss = false,
	IntroduceText = "咬人宝箱怪，目测男性，外来物种。\n经有关人员投诉，该犯罪分子来到流亡街后，经常以宝箱族身份兜售毫无价值的宝物，他人拒绝购买就会发起攻击，特此通缉。\n\n联系人：冒险家协会 切斯特先生",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 100,
			Enemy = {
				{
					Value = 246328,
					Level = 100,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 45,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 120,
			Enemy = {
				{
					Value = 246329,
					Level = 120,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 45,
				},
			},
		},
		{
			SupportLevel = 140,
			Enemy = {
				{
					Value = 246330,
					Level = 140,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 45,
				},
			},
		},
	},
	Desc = "活跃于危险地区的中级宝箱，金色的光芒会让老练的冒险者忘乎所以地靠近，在他打开宝箱的一刹那，就把对方吃掉。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id111] =
{
	Id = 111,
	Name = "通缉闪耀史莱姆",
	Boss = true,
	IntroduceText = "闪耀史莱姆，目测男性，疑似未成年，籍贯冒险星。身高2厘米(不同手机尺寸不同)。\n据目击者称，该人员因不明原因出现在流亡街，特此通缉。\n\n联系人：密林冒险者协会 尼尔斯先生",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 120,
			Enemy = {
				{
					Value = 246331,
					Level = 120,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
				{
					Value = 2,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 144,
			Enemy = {
				{
					Value = 246332,
					Level = 144,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
			},
		},
		{
			SupportLevel = 168,
			Enemy = {
				{
					Value = 246333,
					Level = 168,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
			},
		},
	},
	Desc = "史莱姆一族中的稀有品种，对自我的定位是「金英怪」或「黄金史莱姆」。一旦听到有人喊它「黄色史莱姆」，就会陷入无法抑制的狂暴状态。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id112] =
{
	Id = 112,
	Name = "通缉诅咒宝箱怪",
	Boss = false,
	IntroduceText = "诅咒宝箱怪，目测男性，外来物种。\n经有关人员投诉，该犯罪分子来到流亡街后，经常以宝箱族身份兜售被诅咒的宝物，致他人遭遇不幸，特此通缉。\n\n联系人：冒险家协会 切斯特先生",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 160,
			Enemy = {
				{
					Value = 246334,
					Level = 160,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 75,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 192,
			Enemy = {
				{
					Value = 246335,
					Level = 192,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 75,
				},
			},
		},
		{
			SupportLevel = 224,
			Enemy = {
				{
					Value = 246336,
					Level = 224,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 75,
				},
			},
		},
	},
	Desc = "深藏于顶级副本的史诗宝箱，再警惕的冒险者也无法抗拒他的璀璨光辉。而那些靠近的冒险者就再也回不来了。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id113] =
{
	Id = 113,
	Name = "通缉麻痹花椒",
	Boss = false,
	IntroduceText = "麻痹花椒，目测男性，高危入侵物种。\n相关部门经研究发现，该犯罪分子会入侵当地生态系统散布特制花椒籽，使误食人员陷入麻痹状态。\n\n联系人：健康饮食协会 Steven周",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 40,
			Enemy = {
				{
					Value = 246337,
					Level = 40,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 15,
				},
				{
					Value = 2,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 48,
			Enemy = {
				{
					Value = 246338,
					Level = 48,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 15,
				},
			},
		},
		{
			SupportLevel = 56,
			Enemy = {
				{
					Value = 246339,
					Level = 56,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 15,
				},
			},
		},
	},
	Desc = "罪名：散布危险花椒种子，导致食客麻痹。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id114] =
{
	Id = 114,
	Name = "通缉白臭干",
	Boss = true,
	IntroduceText = "白臭干，A类危险入侵者。\n相关部门人员称，该罪犯冒充油炸食品，躲过治安人员追捕后，撕开外皮散布浓重气味袭击路人。\n\n联系人：健康饮食协会 Steven周",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 70,
			Enemy = {
				{
					Value = 246340,
					Level = 70,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 84,
			Enemy = {
				{
					Value = 246341,
					Level = 84,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 98,
			Enemy = {
				{
					Value = 246342,
					Level = 98,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
	},
	Desc = "罪名：四处散播浓重气味。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id115] =
{
	Id = 115,
	Name = "通缉黑臭干",
	Boss = false,
	IntroduceText = "黑臭干，A类危险入侵者。\n相关部门人员称，该罪犯利用可怕外形在其他饭店索要保护费，一旦遭拒就撕开外皮散布浓重气味袭击食客。\n\n联系人：健康饮食协会 Steven周",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 100,
			Enemy = {
				{
					Value = 246343,
					Level = 100,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 45,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 120,
			Enemy = {
				{
					Value = 246344,
					Level = 120,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 45,
				},
			},
		},
		{
			SupportLevel = 140,
			Enemy = {
				{
					Value = 246345,
					Level = 140,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 45,
				},
			},
		},
	},
	Desc = "罪名：四处散播浓重气味。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id116] =
{
	Id = 116,
	Name = "通缉仰望苍穹",
	Boss = true,
	IntroduceText = "仰望苍穹，目测男性，高危入侵物种。\n该犯罪分子经常在人流密集处停留，引起他人好奇一起仰望星空，最后导致颈椎病爆发，特此通缉。\n\n联系人：保护颈椎协会 正骨达人",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 120,
			Enemy = {
				{
					Value = 246346,
					Level = 120,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
				{
					Value = 2,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 144,
			Enemy = {
				{
					Value = 246347,
					Level = 144,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
			},
		},
		{
			SupportLevel = 168,
			Enemy = {
				{
					Value = 246348,
					Level = 168,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
			},
		},
	},
	Desc = "罪名：吸引其他路人仰望星空，导致颈椎病发。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id117] =
{
	Id = 117,
	Name = "通缉不朽大列巴",
	Boss = false,
	IntroduceText = "外号“最强大列巴”，男性，超威入侵物种。\n接到举报，该犯罪分子近日潜入流亡街，挑战多家拳馆，利用硬化绝技使拳馆掌门人手骨粉碎性骨折，极其过分，特此通缉。\n\n联系人：光明格斗协会 咬耳的格斗家",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 160,
			Enemy = {
				{
					Value = 246349,
					Level = 160,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 75,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 192,
			Enemy = {
				{
					Value = 246350,
					Level = 192,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 75,
				},
			},
		},
		{
			SupportLevel = 224,
			Enemy = {
				{
					Value = 246351,
					Level = 224,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 75,
				},
			},
		},
	},
	Desc = "罪名：利用特殊硬化术挑战拳手，致人受伤。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id118] =
{
	Id = 118,
	Name = "通缉腐烂草草",
	Boss = false,
	IntroduceText = "腐烂草草，性别无，目测未成年，籍贯海洋星。\n据目击者称，亲眼看到该人员借欢迎之名，缠上游客，顺手带走游客的财物。\n\n联系人：海洋星旅游管理局 格拉斯女士",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 30,
			Enemy = {
				{
					Value = 246352,
					Level = 30,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 10,
				},
				{
					Value = 2,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 36,
			Enemy = {
				{
					Value = 246353,
					Level = 36,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 42,
			Enemy = {
				{
					Value = 246354,
					Level = 42,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 10,
				},
			},
		},
	},
	Desc = "罪名：偷走游客的物品，对警方的搜查拒不配合。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id119] =
{
	Id = 119,
	Name = "通缉珊瑚草",
	Boss = false,
	IntroduceText = "珊瑚草，性别不详，目测中年，籍贯海洋星，热爱化妆服饰事业。\n或许是喜欢绿色的缘故，常常在大街小巷派送绿色帽子，给他人的家庭带来了许多争吵与不幸，勒令整改后仍无任何行动。\n\n联系人：回溯镇居委会主任 柯以普·库埃特",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 40,
			Enemy = {
				{
					Value = 246355,
					Level = 40,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 15,
				},
				{
					Value = 2,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 48,
			Enemy = {
				{
					Value = 246356,
					Level = 48,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 15,
				},
			},
		},
		{
			SupportLevel = 56,
			Enemy = {
				{
					Value = 246357,
					Level = 56,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 15,
				},
			},
		},
	},
	Desc = "罪名：向广大居民赠送绿帽子，影响居民家庭关系。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id120] =
{
	Id = 120,
	Name = "通缉暴走珊瑚",
	Boss = false,
	IntroduceText = "暴走珊瑚，疑似男性，目测中年，籍贯海洋星，性格极其暴躁。\n据目击者说，该人员在发脾气时气势太盛，怀疑这便是引发海底龙卷风的诱因，决定先行逮捕，了解情况。\n\n联系人：海洋星警局刑事大队 普里斯先生",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 40,
			Enemy = {
				{
					Value = 246358,
					Level = 40,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 15,
				},
				{
					Value = 2,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 48,
			Enemy = {
				{
					Value = 246359,
					Level = 48,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 15,
				},
			},
		},
		{
			SupportLevel = 56,
			Enemy = {
				{
					Value = 246360,
					Level = 56,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 15,
				},
			},
		},
	},
	Desc = "罪名：疑似诱发海底龙卷风。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id121] =
{
	Id = 121,
	Name = "通缉腐坏贝壳",
	Boss = false,
	IntroduceText = "腐坏贝壳，性别女，青年，籍贯海洋星。\n据报案人所说，该人员打着算命的旗号诓骗居民，被戳穿后拒不还钱，行为恶劣。\n\n联系人：海洋星旅游管理局 格拉斯女士",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 50,
			Enemy = {
				{
					Value = 246361,
					Level = 50,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 20,
				},
				{
					Value = 2,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 60,
			Enemy = {
				{
					Value = 246362,
					Level = 60,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 70,
			Enemy = {
				{
					Value = 246363,
					Level = 70,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 20,
				},
			},
		},
	},
	Desc = "罪名：打着算命的旗号诓骗游客且拒不还钱。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id122] =
{
	Id = 122,
	Name = "通缉脏贝壳",
	Boss = false,
	IntroduceText = "脏贝壳，性别男，青年，籍贯海洋星。\n据报案人所说，该人员自称是海洋星导游，带游客去贝壳区，强买强卖，行为恶劣。\n\n联系人：海洋星旅游管理局 格拉斯女士",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 50,
			Enemy = {
				{
					Value = 246364,
					Level = 50,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 20,
				},
				{
					Value = 2,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 60,
			Enemy = {
				{
					Value = 246365,
					Level = 60,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 70,
			Enemy = {
				{
					Value = 246366,
					Level = 70,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 20,
				},
			},
		},
	},
	Desc = "罪名：强买强卖。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id123] =
{
	Id = 123,
	Name = "通缉血腥鱿鱼",
	Boss = true,
	IntroduceText = "血腥鱿鱼，性别不详，目测中年，籍贯海洋星。\n据举报者所说，该人员四处传播谣言，说自己的族人们都会被送到美食星，制成“铁板香辣鱿鱼”，使得人心惶惶。\n\n联系人： 海洋星治理安全委员会 安女士",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 70,
			Enemy = {
				{
					Value = 246367,
					Level = 70,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 84,
			Enemy = {
				{
					Value = 246368,
					Level = 84,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 98,
			Enemy = {
				{
					Value = 246369,
					Level = 98,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
	},
	Desc = "罪名：传播谣言，让海洋星居民人心惶惶。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id124] =
{
	Id = 124,
	Name = "通缉变质章鱼",
	Boss = true,
	IntroduceText = "变质章鱼，性别不详，中年，原为星际流民。\n曾因原料变质，无法成为章鱼烧，移民美食星受阻，因而一直在流亡街游荡，后来非法移民进入海洋星。\n\n联系人：星际移民管理局 糖斯·弗里德",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 120,
			Enemy = {
				{
					Value = 246370,
					Level = 120,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
				{
					Value = 2,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 144,
			Enemy = {
				{
					Value = 246371,
					Level = 144,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
			},
		},
		{
			SupportLevel = 168,
			Enemy = {
				{
					Value = 246372,
					Level = 168,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
			},
		},
	},
	Desc = "罪名：非法移民。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id125] =
{
	Id = 125,
	Name = "通缉霉草草",
	Boss = false,
	IntroduceText = "腐烂草草，性别无，目测未成年，籍贯海洋星。\n据目击者称，亲眼看到该人员借欢迎之名，缠上游客，顺手带走游客的食物。\n\n联系人：海洋星旅游管理局 格拉斯女士",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 30,
			Enemy = {
				{
					Value = 246373,
					Level = 30,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 10,
				},
				{
					Value = 2,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 36,
			Enemy = {
				{
					Value = 246374,
					Level = 36,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 42,
			Enemy = {
				{
					Value = 246375,
					Level = 42,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 10,
				},
			},
		},
	},
	Desc = "罪名：偷走游客的物品，对警方的搜查拒不配合。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id126] =
{
	Id = 126,
	Name = "通缉多色海参",
	Boss = false,
	IntroduceText = "多色海参，性别无，目测未成年，籍贯海洋星。\n受到惊吓时，会从身体中喷射出五颜六色的内脏与液体，再以迅雷不及掩耳之速逃离现场，给清洁人员造成了极大的困扰。\n\n联系人：海洋星星球管理委员会 看门大爷",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 60,
			Enemy = {
				{
					Value = 246376,
					Level = 60,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 25,
				},
				{
					Value = 2,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 72,
			Enemy = {
				{
					Value = 246377,
					Level = 72,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 25,
				},
			},
		},
		{
			SupportLevel = 84,
			Enemy = {
				{
					Value = 246378,
					Level = 84,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 25,
				},
			},
		},
	},
	Desc = "罪名：肇事逃逸。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id127] =
{
	Id = 127,
	Name = "通缉沼泽海参",
	Boss = false,
	IntroduceText = "沼泽海参，性别无，目测未成年，籍贯海洋星。\n受到惊吓时，会从身体中喷射出绿色的内脏与液体，给清洁人员造成了极大的困扰。\n\n联系人：海洋星星球管理委员会 看门大爷",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 60,
			Enemy = {
				{
					Value = 246379,
					Level = 60,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 25,
				},
				{
					Value = 2,
					Num = 10,
				},
			},
		},
		{
			SupportLevel = 72,
			Enemy = {
				{
					Value = 246380,
					Level = 72,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 25,
				},
			},
		},
		{
			SupportLevel = 84,
			Enemy = {
				{
					Value = 246381,
					Level = 84,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 25,
				},
			},
		},
	},
	Desc = "罪名：打扰清洁人员清扫地面。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id128] =
{
	Id = 128,
	Name = "通缉芥末礁石",
	Boss = false,
	IntroduceText = "芥末礁石，男性，中年，籍贯海洋星，喜欢邀请初次来到海洋星的游客，坐在自己身上休息。\n据某游客说，他确实这样做了，但坐下后就闻到芥末的味道，自己的下半身至今还是辣辣的。\n\n联系人：海洋星旅游管理局 格拉斯女士",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 80,
			Enemy = {
				{
					Value = 246382,
					Level = 80,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 35,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 96,
			Enemy = {
				{
					Value = 246383,
					Level = 96,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 35,
				},
			},
		},
		{
			SupportLevel = 112,
			Enemy = {
				{
					Value = 246384,
					Level = 112,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 35,
				},
			},
		},
	},
	Desc = "罪名：用芥末对游客进行恶作剧。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id129] =
{
	Id = 129,
	Name = "通缉邪恶礁石",
	Boss = false,
	IntroduceText = "邪恶礁石，女性，中年，籍贯海洋星，喜欢邀请初次来到海洋星的游客，坐在自己身上休息。\n据某游客举报，他自己确实是这样做了，但坐下后就发现，自己的裤子被胶水黏住了，用了938种方法，都没能从礁石上挪走。\n\n联系人：海洋星旅游管理局 格拉斯女士",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 80,
			Enemy = {
				{
					Value = 246385,
					Level = 80,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 35,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 96,
			Enemy = {
				{
					Value = 246386,
					Level = 96,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 35,
				},
			},
		},
		{
			SupportLevel = 112,
			Enemy = {
				{
					Value = 246387,
					Level = 112,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 35,
				},
			},
		},
	},
	Desc = "罪名：用胶水对游客进行恶作剧，并以此手段侵占游客私人物品。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id130] =
{
	Id = 130,
	Name = "通缉变异比目鱼",
	Boss = false,
	IntroduceText = "变异比目鱼，疑似男性，目测中年，籍贯海洋星。\n据举报人称，该人员为出租车司机，多次不顾红绿灯，在十字路口右转，虽未造成交通事故，但仍对交通造成了不小的压力。\n\n联系人：海洋星交通总局 催斯先生",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 90,
			Enemy = {
				{
					Value = 246388,
					Level = 90,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 40,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 108,
			Enemy = {
				{
					Value = 246389,
					Level = 108,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 40,
				},
			},
		},
		{
			SupportLevel = 126,
			Enemy = {
				{
					Value = 246390,
					Level = 126,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 40,
				},
			},
		},
	},
	Desc = "罪名：危害公共交通安全。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id131] =
{
	Id = 131,
	Name = "通缉大丑鱼",
	Boss = false,
	IntroduceText = "大丑鱼，疑似男性，中年，籍贯海洋星。\n因为天天寻找海葵，横冲直撞扰乱交通秩序，特此通缉。\n\n联系人：海洋星交通总局 催斯先生",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 90,
			Enemy = {
				{
					Value = 246391,
					Level = 90,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 40,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 108,
			Enemy = {
				{
					Value = 246392,
					Level = 108,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 40,
				},
			},
		},
		{
			SupportLevel = 126,
			Enemy = {
				{
					Value = 246393,
					Level = 126,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 40,
				},
			},
		},
	},
	Desc = "罪名：扰乱交通秩序。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id132] =
{
	Id = 132,
	Name = "通缉斑斓妖怪鱼",
	Boss = false,
	IntroduceText = "热带变种鱼，性别不详，中年，籍贯海洋星。\n作为星光小道的金牌司机，可以在乘客毫无发觉的情况下，带乘客绕行，然而最近却被更加机灵的乘客发现了。\n\n联系人：星际观光团游客 佚名",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 90,
			Enemy = {
				{
					Value = 246394,
					Level = 90,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 40,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 108,
			Enemy = {
				{
					Value = 246395,
					Level = 108,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 40,
				},
			},
		},
		{
			SupportLevel = 126,
			Enemy = {
				{
					Value = 246396,
					Level = 126,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 40,
				},
			},
		},
	},
	Desc = "罪名：带乘客绕路来提高收入。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id133] =
{
	Id = 133,
	Name = "通缉灰水母",
	Boss = false,
	IntroduceText = "灰水母，男性，目测青年，籍贯海洋星，系鱼乐日报旗下记者。\n接到匿名举报，该人员为了获得一首新闻资讯，私闯偶像豪宅，甚至在偶像家中洗澡，特此通缉。\n\n联系人：鱼乐日报主编 无名水母",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 100,
			Enemy = {
				{
					Value = 246397,
					Level = 100,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 45,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 120,
			Enemy = {
				{
					Value = 246398,
					Level = 120,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 45,
				},
			},
		},
		{
			SupportLevel = 140,
			Enemy = {
				{
					Value = 246399,
					Level = 140,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 45,
				},
			},
		},
	},
	Desc = "罪名：为获取新闻私闯民宅。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id134] =
{
	Id = 134,
	Name = "通缉腹黑水母",
	Boss = false,
	IntroduceText = "腹黑水母，女性，目测青年，籍贯海洋星，系鱼乐日报旗下记者。\n接到匿名举报，该人员喜欢偷拍偶像，曾经拍下了偶像大口吃肉的照片，对偶像的形象造成了极大的损害，特此通缉。\n\n联系人：鱼乐日报主编 无名水母",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 100,
			Enemy = {
				{
					Value = 246400,
					Level = 100,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 45,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 120,
			Enemy = {
				{
					Value = 246401,
					Level = 120,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 45,
				},
			},
		},
		{
			SupportLevel = 140,
			Enemy = {
				{
					Value = 246402,
					Level = 140,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 45,
				},
			},
		},
	},
	Desc = "罪名：损害偶像形象、偶像名誉权及个人隐私。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id135] =
{
	Id = 135,
	Name = "通缉绿水母",
	Boss = false,
	IntroduceText = "绿水母，疑似女性，目测青年，籍贯海洋星，系鱼乐日报旗下记者。\n因为在为了提高文章的阅读量，故意取出一些耸人听闻的标题。\n\n联系人：鱼乐日报主编 无名水母",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 100,
			Enemy = {
				{
					Value = 246403,
					Level = 100,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 45,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 120,
			Enemy = {
				{
					Value = 246404,
					Level = 120,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 45,
				},
			},
		},
		{
			SupportLevel = 140,
			Enemy = {
				{
					Value = 246405,
					Level = 140,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 45,
				},
			},
		},
	},
	Desc = "罪名：标题党。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id136] =
{
	Id = 136,
	Name = "通缉毒海蛇",
	Boss = false,
	IntroduceText = "毒海蛇，男性，青年，籍贯海洋星，热爱音乐。\n喜欢在晚上放声高歌，经测量已达到200分贝，对周围居民生活造成了严重影响，警察上门教育时却一脸无辜地问：“不会吧？你们不过夜生活？”\n\n联系人：回溯镇居委会主任 柯以普·库埃特",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 110,
			Enemy = {
				{
					Value = 246406,
					Level = 110,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 50,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 132,
			Enemy = {
				{
					Value = 246407,
					Level = 132,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 50,
				},
			},
		},
		{
			SupportLevel = 154,
			Enemy = {
				{
					Value = 246408,
					Level = 154,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 50,
				},
			},
		},
	},
	Desc = "罪名：生产噪音扰民，且嘲讽居民们没有夜生活。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id137] =
{
	Id = 137,
	Name = "通缉紫癣海蛇",
	Boss = true,
	IntroduceText = "紫癣海蛇，疑似女性，青年，籍贯海洋星，热爱音乐。\n报案人称，此人热爱给大家看密集斑点类图像，造成许多密集恐惧者不适，且在教育后表示绝不悔改。\n\n联系人：回溯镇居委会主任 柯以普·库埃特",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 120,
			Enemy = {
				{
					Value = 246409,
					Level = 120,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
				{
					Value = 2,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 144,
			Enemy = {
				{
					Value = 246410,
					Level = 144,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
			},
		},
		{
			SupportLevel = 168,
			Enemy = {
				{
					Value = 246411,
					Level = 168,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
			},
		},
	},
	Desc = "罪名：引起密集恐惧者不适且绝不悔改。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id138] =
{
	Id = 138,
	Name = "通缉荧光海星",
	Boss = false,
	IntroduceText = "荧光海星，性别无，目测幼年，籍贯海洋星，立志做星球中最靓的海星。\n据报案人称，该人员全身涂满荧光绿，亮瞎了大家的眼睛，造成严重的光污染。\n\n联系人：回溯镇居委会主任 柯以普·库埃特",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 110,
			Enemy = {
				{
					Value = 246412,
					Level = 110,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 50,
				},
				{
					Value = 2,
					Num = 20,
				},
			},
		},
		{
			SupportLevel = 132,
			Enemy = {
				{
					Value = 246413,
					Level = 132,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 50,
				},
			},
		},
		{
			SupportLevel = 154,
			Enemy = {
				{
					Value = 246414,
					Level = 154,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 50,
				},
			},
		},
	},
	Desc = "罪名：光污染。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id139] =
{
	Id = 139,
	Name = "通缉淤泥海星",
	Boss = true,
	IntroduceText = "淤泥海星，性别不详，目测青年，籍贯海洋星，浑身散发出淤泥的气息。\n据目击者说，此人为了擦掉身上的淤泥，在礁石上搓澡达39小时，用光586卷卫生纸，造成极大的资源浪费。\n\n联系人：超市店长 素帕·秀普",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 120,
			Enemy = {
				{
					Value = 246415,
					Level = 120,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
				{
					Value = 2,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 144,
			Enemy = {
				{
					Value = 246416,
					Level = 144,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
			},
		},
		{
			SupportLevel = 168,
			Enemy = {
				{
					Value = 246417,
					Level = 168,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
			},
		},
	},
	Desc = "罪名：搓澡时间过长，造成资源浪费。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id140] =
{
	Id = 140,
	Name = "通缉紫薯水熊虫",
	Boss = true,
	IntroduceText = "紫薯水熊虫，性别无，目测未成年，籍贯海洋星。\n作为未成年卫生间管理员，为了检查居民是否成年，拉下了一位成年男性的裤子。\n\n联系人：回溯镇受害者 匿名",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 70,
			Enemy = {
				{
					Value = 246418,
					Level = 70,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 84,
			Enemy = {
				{
					Value = 246419,
					Level = 84,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 98,
			Enemy = {
				{
					Value = 246420,
					Level = 98,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
	},
	Desc = "罪名：拉下成年男性的外裤，造成恶劣影响。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id141] =
{
	Id = 141,
	Name = "通缉霉菌海绵",
	Boss = false,
	IntroduceText = "霉菌海绵，目测男性，青年，籍贯海洋星，属海绵科。\n承诺帮助房东太太清洗窗户，却把窗户弄得更脏了，并且拒绝提供后续服务。\n\n联系人：悬疑星 房东太太",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 130,
			Enemy = {
				{
					Value = 246421,
					Level = 130,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 156,
			Enemy = {
				{
					Value = 246422,
					Level = 156,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 182,
			Enemy = {
				{
					Value = 246423,
					Level = 182,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
	},
	Desc = "罪名：把房东太太的玻璃弄脏，并拒绝为其善后。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id142] =
{
	Id = 142,
	Name = "通缉毒绵宝宝",
	Boss = false,
	IntroduceText = "毒棉宝宝，目测女性，青年，籍贯海洋星，属海绵科。\n承诺帮助房东太太清洗窗户，却把窗户上的玻璃全部腐蚀了，造成财产损失。\n\n联系人：悬疑星 房东太太",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 130,
			Enemy = {
				{
					Value = 246424,
					Level = 130,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 156,
			Enemy = {
				{
					Value = 246425,
					Level = 156,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 182,
			Enemy = {
				{
					Value = 246426,
					Level = 182,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
	},
	Desc = "罪名：腐蚀玻璃，造成财产损失。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id143] =
{
	Id = 143,
	Name = "通缉魔芋海葵",
	Boss = false,
	IntroduceText = "魔芋海葵，性别不详，目测青年，原籍美食星，据说本是一盒薯条。\n薯条国王登基后，通过化妆技术，把自己变成了海葵，成功欺骗移民官入籍海洋星，至今才被不知名人士举报。\n\n联系人：星际移民管理局 糖斯·弗里德",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 140,
			Enemy = {
				{
					Value = 246427,
					Level = 140,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 65,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 168,
			Enemy = {
				{
					Value = 246428,
					Level = 168,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 65,
				},
			},
		},
		{
			SupportLevel = 196,
			Enemy = {
				{
					Value = 246429,
					Level = 196,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 65,
				},
			},
		},
	},
	Desc = "罪名：欺骗移民官，用非法手段获得海洋星国籍。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id144] =
{
	Id = 144,
	Name = "通缉血腥海葵",
	Boss = false,
	IntroduceText = "血腥海葵，目测男性，青年，原籍美食星，在多地流窜作案。\n据报案人所说，此人帮助其他海葵假扮为薯条，偷渡前往美食星，在星球邦交中造成了极其恶劣的影响。\n\n联系人：星际移民管理局 糖斯·弗里德",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 140,
			Enemy = {
				{
					Value = 246430,
					Level = 140,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 65,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 168,
			Enemy = {
				{
					Value = 246431,
					Level = 168,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 65,
				},
			},
		},
		{
			SupportLevel = 196,
			Enemy = {
				{
					Value = 246432,
					Level = 196,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 65,
				},
			},
		},
	},
	Desc = "罪名：帮助他人偷渡。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id145] =
{
	Id = 145,
	Name = "通缉蟹员工",
	Boss = false,
	IntroduceText = "蟹员工，男性，目测中年，籍贯海洋星，天鱼公司员工。\n在职期间用尽每一秒来摸鱼，甚至带领同事们一起摸鱼，对公司造成极大损失。在蟹老板全方位施压下，决定对此人进行表面通缉。\n\n联系人：天鱼集团 蟹经理",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 160,
			Enemy = {
				{
					Value = 246433,
					Level = 160,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 75,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 192,
			Enemy = {
				{
					Value = 246434,
					Level = 192,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 75,
				},
			},
		},
		{
			SupportLevel = 224,
			Enemy = {
				{
					Value = 246435,
					Level = 224,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 75,
				},
			},
		},
	},
	Desc = "罪名：带领众多同事一起摸鱼。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id146] =
{
	Id = 146,
	Name = "通缉蟹主管",
	Boss = false,
	IntroduceText = "蟹主管，疑似女性，目测中年，籍贯海洋星，天鱼公司前领导。\n接相关人员举报，该人员在职期间要求别人称呼自己“蟹总”，是对真正蟹老板的大不敬。\n\n联系人：天鱼集团 蟹经理",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 160,
			Enemy = {
				{
					Value = 246436,
					Level = 160,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 75,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 192,
			Enemy = {
				{
					Value = 246437,
					Level = 192,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 75,
				},
			},
		},
		{
			SupportLevel = 224,
			Enemy = {
				{
					Value = 246438,
					Level = 224,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 75,
				},
			},
		},
	},
	Desc = "罪名：对真正的老板大不敬。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id147] =
{
	Id = 147,
	Name = "通缉腹黑海兔",
	Boss = false,
	IntroduceText = "腹黑名字，男性，青年，籍贯海洋星。\n据说此人求偶失败后，会对每一位路过的女性放电，还把触须染成了最亮眼的芭比粉，让许多女性海兔不堪其扰。\n\n联系人：隔壁海兔 王先生",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 150,
			Enemy = {
				{
					Value = 246439,
					Level = 150,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 70,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 180,
			Enemy = {
				{
					Value = 246440,
					Level = 180,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 70,
				},
			},
		},
		{
			SupportLevel = 210,
			Enemy = {
				{
					Value = 246441,
					Level = 210,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 70,
				},
			},
		},
	},
	Desc = "罪名：对众多女性放电，是名副其实的海王",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id148] =
{
	Id = 148,
	Name = "通缉梦幻海兔",
	Boss = false,
	IntroduceText = "梦幻海兔，青年，籍贯海洋星，肤色梦幻。\n据说该人员坚信自己是海洋星公主，对同族海兔颐指气使，要求海兔们为自己做一件五彩斑斓的黑色礼服，至今为止，因为感觉不对，已经否定了388版方案。\n\n联系人：回溯镇居民 凸先生",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 150,
			Enemy = {
				{
					Value = 246442,
					Level = 150,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 70,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 180,
			Enemy = {
				{
					Value = 246443,
					Level = 180,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 70,
				},
			},
		},
		{
			SupportLevel = 210,
			Enemy = {
				{
					Value = 246444,
					Level = 210,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 70,
				},
			},
		},
	},
	Desc = "罪名：对同族成员颐指气使，给出不可能完成的任务。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id149] =
{
	Id = 149,
	Name = "通缉噩梦海兔",
	Boss = false,
	IntroduceText = "噩梦海兔，性别不详，青年，籍贯海洋星。\n据报案人称，该人员热衷向他人分享自己的噩梦，即便对方明确表示了害怕和拒绝，该人员也会继续绘声绘色地讲下去。\n\n联系人：回溯镇居委会主任：斯莱特·库埃特",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 150,
			Enemy = {
				{
					Value = 246445,
					Level = 150,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 70,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 180,
			Enemy = {
				{
					Value = 246446,
					Level = 180,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 70,
				},
			},
		},
		{
			SupportLevel = 210,
			Enemy = {
				{
					Value = 246447,
					Level = 210,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 70,
				},
			},
		},
	},
	Desc = "罪名：向别人描述噩梦。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id150] =
{
	Id = 150,
	Name = "通缉红眼海螺",
	Boss = true,
	IntroduceText = "红眼海螺，性别无，未成年，籍贯海洋星，身高5cm。\n据说该人员会从眼中发射出红外线，让人误以为是奇怪的武器，未了避免引发社会恐慌，警局决定予以逮捕。\n\n联系人：海洋星警局刑事大队 普里斯先生",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 70,
			Enemy = {
				{
					Value = 246448,
					Level = 70,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 84,
			Enemy = {
				{
					Value = 246449,
					Level = 84,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 98,
			Enemy = {
				{
					Value = 246450,
					Level = 98,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
	},
	Desc = "罪名：从眼里发射红色射线，引发星球小范围恐慌。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id151] =
{
	Id = 151,
	Name = "通缉绿藻海胆",
	Boss = true,
	IntroduceText = "绿藻海胆，性别不详，青年，籍贯海洋星，对自己的肌肤尤其在意。\n为了做出营养价值最高的面膜，前往海藻区进行偷盗，被发现后拒不承认，说身上的不是海藻而是青苔。\n\n联系人：海洋星治安管理局 瑟夫·因泼坦",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 70,
			Enemy = {
				{
					Value = 246451,
					Level = 70,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 84,
			Enemy = {
				{
					Value = 246452,
					Level = 84,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 98,
			Enemy = {
				{
					Value = 246453,
					Level = 98,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
	},
	Desc = "罪名：偷盗海藻并拒不承认。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id152] =
{
	Id = 152,
	Name = "通缉变异小飞象",
	Boss = true,
	IntroduceText = "变异小飞象，性别无，未成年，籍贯海洋星。\n据报案人说，该人员有两副面孔，会以可爱的形象接近游客，当放下戒心后，该人员突然变脸，让游客们受到惊吓。\n\n联系人：海洋星治安管理局 瑟夫·因泼坦",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 120,
			Enemy = {
				{
					Value = 246454,
					Level = 120,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
				{
					Value = 2,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 144,
			Enemy = {
				{
					Value = 246455,
					Level = 144,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
			},
		},
		{
			SupportLevel = 168,
			Enemy = {
				{
					Value = 246456,
					Level = 168,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
			},
		},
	},
	Desc = "罪名：突然变脸。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id153] =
{
	Id = 153,
	Name = "通缉邪王龟",
	Boss = false,
	IntroduceText = "邪王龟，性别不详，目测青年，籍贯海洋星，是一只面带笑容的海龟。\n当别人亲热称呼TA为“龟龟”的时候，会遭到一顿毒打，特此通缉。\n\n联系人：海洋星治安管理局 瑟夫·因泼坦",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 160,
			Enemy = {
				{
					Value = 246457,
					Level = 160,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 75,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 192,
			Enemy = {
				{
					Value = 246458,
					Level = 192,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 75,
				},
			},
		},
		{
			SupportLevel = 224,
			Enemy = {
				{
					Value = 246459,
					Level = 224,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 75,
				},
			},
		},
	},
	Desc = "罪名：毒打其他居民。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id154] =
{
	Id = 154,
	Name = "通缉布行布行",
	Boss = true,
	IntroduceText = "布行布行，男性，未成年，籍贯不明，身高4cm。\n据目击者称，该人员会突然出现在路人背后，蒙住他们的眼睛，引起恐慌，且导致了多起交通事故。\n\n联系人：流亡街未来协会负责人 D先生",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 70,
			Enemy = {
				{
					Value = 246460,
					Level = 70,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 84,
			Enemy = {
				{
					Value = 246461,
					Level = 84,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 98,
			Enemy = {
				{
					Value = 246462,
					Level = 98,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
	},
	Desc = "罪名：袭击路人，并引起多起交通事故。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id155] =
{
	Id = 155,
	Name = "通缉针滴戳",
	Boss = true,
	IntroduceText = "针滴戳，性别不明，青年，籍贯不明，流亡街在逃人员。\n此人坚称自己背负着某种诅咒，必须找到传说中的金发公主，并戳伤她的指尖。目前已有不少金发女性受到伤害，特此通缉。\n\n联系人：流亡街未来协会负责人 D先生",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 120,
			Enemy = {
				{
					Value = 246463,
					Level = 120,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
				{
					Value = 2,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 144,
			Enemy = {
				{
					Value = 246464,
					Level = 144,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
			},
		},
		{
			SupportLevel = 168,
			Enemy = {
				{
					Value = 246465,
					Level = 168,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
			},
		},
	},
	Desc = "罪名：幻想自己背负着童话诅咒，袭击金发女性。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id156] =
{
	Id = 156,
	Name = "通缉臭蛋香囊",
	Boss = false,
	IntroduceText = "臭蛋香囊，女性，貌似未成年，实则青年，籍贯不明。\n接到举报，此人以售卖石榴香囊为名牟利，然而实际卖出的香囊中，装的都是染成粉色的臭鸡蛋，严重欺骗了流亡街居民的感情。\n\n联系人：流亡街未来协会负责人 D先生",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 160,
			Enemy = {
				{
					Value = 246466,
					Level = 160,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 75,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 192,
			Enemy = {
				{
					Value = 246467,
					Level = 192,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 75,
				},
			},
		},
		{
			SupportLevel = 224,
			Enemy = {
				{
					Value = 246468,
					Level = 224,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 75,
				},
			},
		},
	},
	Desc = "罪名：虚假宣传，售卖臭鸡蛋。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id157] =
{
	Id = 157,
	Name = "通缉七夕果汁",
	Boss = true,
	IntroduceText = "七夕果汁，目测女性，未成年，籍贯不明。\n此人常常一边跑一边撒芝麻，让众多居民摔倒，并把这些芝麻称作“宇宙的恩惠”，愚弄居民与警察，造成了恶劣的宇宙影响。\n\n联系人：流亡街未来协会负责人 D先生",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 70,
			Enemy = {
				{
					Value = 246469,
					Level = 70,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
				{
					Value = 2,
					Num = 30,
				},
			},
		},
		{
			SupportLevel = 84,
			Enemy = {
				{
					Value = 246470,
					Level = 84,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 98,
			Enemy = {
				{
					Value = 246471,
					Level = 98,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
	},
	Desc = "罪名：故意致使居民摔倒。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id158] =
{
	Id = 158,
	Name = "通缉叽喳叽喳",
	Boss = true,
	IntroduceText = "叽喳叽喳，性别未知，疑似青年，籍贯不明。\n此人凭借自己优秀的身手与飞行技巧，藏匿于各家各户窗后，待他人入睡后便开始高声尖叫。据悉，因为此人，D先生已经连续一周带着黑眼圈上班了。\n\n联系人：流亡街未来协会负责人 D先生",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 120,
			Enemy = {
				{
					Value = 246472,
					Level = 120,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
				{
					Value = 2,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 144,
			Enemy = {
				{
					Value = 246473,
					Level = 144,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
			},
		},
		{
			SupportLevel = 168,
			Enemy = {
				{
					Value = 246474,
					Level = 168,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 110,
				},
			},
		},
	},
	Desc = "罪名：夜里高声尖叫，扰人清梦。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id1001] =
{
	Id = 1001,
	Name = "通缉黑暗料理大师",
	Boss = true,
	IntroduceText = "黑暗料理大师，男性，年龄不详，籍贯美食星，遭到美食星居民投票驱逐的厨师。\n据有关人士称，该人员在全宇宙无照经营黑料摊贩，导致大量食客身体发胖，且迷恋上重油重盐食物，为居民健康着想，特此通缉。\n\n联系人：米其森美食委员会 X委员",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 170,
			Enemy = {
				{
					Value = 246501,
					Level = 170,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
				{
					Value = 2,
					Num = 90,
				},
			},
		},
		{
			SupportLevel = 204,
			Enemy = {
				{
					Value = 246502,
					Level = 204,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
		{
			SupportLevel = 238,
			Enemy = {
				{
					Value = 246503,
					Level = 238,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
	},
	Desc = "与光明料理会不共戴天的料理者。被美食星驱逐后，成为了流亡街的居民。目前处于无照经营摊贩的状态，会推着料理小车，制作出让人无法拒绝的邪恶美食。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id1002] =
{
	Id = 1002,
	Name = "通缉超能少女",
	Boss = true,
	IntroduceText = "超能少女，女性，疑似未成年，籍贯不详，外表无害，实际很危险。\n据图书管理员称，该少女常年霸占图书馆冬暖夏凉采光好的“皇帝位子”，且使用超能力取用漫画书，使其他读者永远享受不到最佳位置。\n\n联系人：宇宙图书馆 管理员X",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 170,
			Enemy = {
				{
					Value = 246504,
					Level = 170,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
				{
					Value = 2,
					Num = 90,
				},
			},
		},
		{
			SupportLevel = 204,
			Enemy = {
				{
					Value = 246505,
					Level = 204,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
		{
			SupportLevel = 238,
			Enemy = {
				{
					Value = 246506,
					Level = 238,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
	},
	Desc = "从超能星被拐骗到流亡街的美丽少女，因为开朗的性格，很受到流亡街居民的喜爱。平时喜欢坐在博士特制的轮椅上思考人生，不过一旦被激活，就会展现出无与伦比的超能力。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id1003] =
{
	Id = 1003,
	Name = "通缉飙车王",
	Boss = true,
	IntroduceText = "飙车王，性别不详，籍贯不详，至今为止也没有拍到他的照片。\n据交通管理员称，该罪犯经常以时速1光年的速度在老年漫步道上飙车，导致街道老人经常受到惊吓，特此通缉！\n\n联系人：交通管理局 小队长X",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 170,
			Enemy = {
				{
					Value = 246507,
					Level = 170,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
				{
					Value = 2,
					Num = 90,
				},
			},
		},
		{
			SupportLevel = 204,
			Enemy = {
				{
					Value = 246508,
					Level = 204,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
		{
			SupportLevel = 238,
			Enemy = {
				{
					Value = 246509,
					Level = 238,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
	},
	Desc = "任何载具都能驾驭自如的星际飙车王，从独轮车到摩托车、小型飞机、快艇、星河战舰，只要是能驾驶的都能飙。不过喜欢风驰电掣的同时，飙车王也十分注意安全防护。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id1004] =
{
	Id = 1004,
	Name = "通缉百变怪人",
	Boss = true,
	IntroduceText = "百变怪人，性别不详，籍贯不详。\n该罪犯为星际安全局通缉的A级罪犯，经常制作危险品并包装成礼物的样子寄给不确定目标，致使他人受到惊吓，特此通缉！\n\n联系人：宇宙安全中心 安长官",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 170,
			Enemy = {
				{
					Value = 246510,
					Level = 170,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
				{
					Value = 2,
					Num = 90,
				},
			},
		},
		{
			SupportLevel = 204,
			Enemy = {
				{
					Value = 246511,
					Level = 204,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
		{
			SupportLevel = 238,
			Enemy = {
				{
					Value = 246512,
					Level = 238,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
	},
	Desc = "来自遥远星球的百变怪人。因马戏团长克扣工资而出逃，凭借变形能力加入了某集团。据说，百变怪人不仅善于伪装，Ta的爆炸物制造能力也非比寻常。如果收到Ta的礼物，千万不要打开！",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id1005] =
{
	Id = 1005,
	Name = "通缉超能铁匠",
	Boss = true,
	IntroduceText = "0",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 170,
			Enemy = {
				{
					Value = 246513,
					Level = 170,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
				{
					Value = 2,
					Num = 90,
				},
			},
		},
		{
			SupportLevel = 204,
			Enemy = {
				{
					Value = 246514,
					Level = 204,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
		{
			SupportLevel = 238,
			Enemy = {
				{
					Value = 246515,
					Level = 238,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
	},
	Desc = "醉心于打造顶级装备的匠人，为了寻求极致的锻造术而潜入流亡街。身体大部分都替换成了机械物，能随意自如地控制这些机械义肢。他为不少星际名人定制过强力装备，其本人则使用铁锤作为武器。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id1006] =
{
	Id = 1006,
	Name = "通缉波罗",
	Boss = true,
	IntroduceText = "0",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 170,
			Enemy = {
				{
					Value = 246516,
					Level = 170,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
				{
					Value = 2,
					Num = 90,
				},
			},
		},
		{
			SupportLevel = 204,
			Enemy = {
				{
					Value = 246517,
					Level = 204,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
		{
			SupportLevel = 238,
			Enemy = {
				{
					Value = 246518,
					Level = 238,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
	},
	Desc = "痴迷侦探小说的邪恶模仿者，本身也是著名侦探，在一次与正牌波罗的推理比赛中彻底败北，从此一面羡慕着波罗的一切，一面又对他恨之入骨，最终潜入流亡街，成为了真正的犯罪分子。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id1007] =
{
	Id = 1007,
	Name = "通缉鲨鱼老大",
	Boss = true,
	IntroduceText = "鲨鱼老大，成年男性，籍贯海洋星。\n该罪犯为星际安全局通缉的A级罪犯，其残暴的进食方式及惊人的食量对海洋星大量温驯海族造成极大威胁，特此通缉！\n\n联系人：海洋保护协会 海会长",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 170,
			Enemy = {
				{
					Value = 246519,
					Level = 170,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
				{
					Value = 2,
					Num = 90,
				},
			},
		},
		{
			SupportLevel = 204,
			Enemy = {
				{
					Value = 246520,
					Level = 204,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
		{
			SupportLevel = 238,
			Enemy = {
				{
					Value = 246521,
					Level = 238,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
	},
	Desc = "海洋中的霸主，被猎鲸者无意间捕获后卖给了大海贼团。在即将被制成刺身时依然疯狂反抗着，最终其精神折服了所有海盗，于是被改造成了超强战士，能够在陆地行走，同时还能用嘴巴咬人。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id1008] =
{
	Id = 1008,
	Name = "通缉罗曼船长",
	Boss = true,
	IntroduceText = "0",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 170,
			Enemy = {
				{
					Value = 246522,
					Level = 170,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
				{
					Value = 2,
					Num = 90,
				},
			},
		},
		{
			SupportLevel = 204,
			Enemy = {
				{
					Value = 246523,
					Level = 204,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
		{
			SupportLevel = 238,
			Enemy = {
				{
					Value = 246524,
					Level = 238,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
	},
	Desc = "海洋偶像星历史上最臭名昭著的罪犯。罗曼船长驾驶着他那艘罪恶的捕鱼船，到处追猎美丽的海洋生物，并且大规模使用鱼炮炸鱼，破坏海洋平衡。在被联邦追捕过程中，左腿残疾，因此他发誓要报复联邦！",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id1009] =
{
	Id = 1009,
	Name = "通缉“伯爵”",
	Boss = true,
	IntroduceText = "0",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 170,
			Enemy = {
				{
					Value = 246525,
					Level = 170,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
				{
					Value = 2,
					Num = 90,
				},
			},
		},
		{
			SupportLevel = 204,
			Enemy = {
				{
					Value = 246526,
					Level = 204,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
		{
			SupportLevel = 238,
			Enemy = {
				{
					Value = 246527,
					Level = 238,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
	},
	Desc = "代号“伯爵”的犯罪分子，相传出身自高贵的家族。因为追求极致的艺术品，“伯爵”变得越来越孤僻。他终日远离人群，独自钻研着赋予艺术品生命的方法。似乎，他还在研究着石化技术，可以将活物直接变为艺术品。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id1010] =
{
	Id = 1010,
	Name = "通缉“博士”",
	Boss = true,
	IntroduceText = "0",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 170,
			Enemy = {
				{
					Value = 246528,
					Level = 170,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
				{
					Value = 2,
					Num = 90,
				},
			},
		},
		{
			SupportLevel = 204,
			Enemy = {
				{
					Value = 246529,
					Level = 204,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
		{
			SupportLevel = 238,
			Enemy = {
				{
					Value = 246530,
					Level = 238,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
	},
	Desc = "代号“博士”的前高星实验室负责人之一，博士多数时间在实验室工作，创造威力强大的发明，或者组织新型的研究。当某地区发生异常现象时，他偶尔也会亲自到访。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id1011] =
{
	Id = 1011,
	Name = "通缉黑客剑士",
	Boss = true,
	IntroduceText = "0",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 170,
			Enemy = {
				{
					Value = 246531,
					Level = 170,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
				{
					Value = 2,
					Num = 90,
				},
			},
		},
		{
			SupportLevel = 204,
			Enemy = {
				{
					Value = 246532,
					Level = 204,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
		{
			SupportLevel = 238,
			Enemy = {
				{
					Value = 246533,
					Level = 238,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
	},
	Desc = "冒险星的二代勇者，因服务器数据错乱，导致能力倍增，并打算获取冒险星的统治权。在被闻名宇宙的大海贼团团长击败后，认识到了更可怕的力量，于是隐匿踪迹继续修行。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id1012] =
{
	Id = 1012,
	Name = "通缉苍青驱魔师",
	Boss = true,
	IntroduceText = "0",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 170,
			Enemy = {
				{
					Value = 246534,
					Level = 170,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
				{
					Value = 2,
					Num = 90,
				},
			},
		},
		{
			SupportLevel = 204,
			Enemy = {
				{
					Value = 246535,
					Level = 204,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
		{
			SupportLevel = 238,
			Enemy = {
				{
					Value = 246536,
					Level = 238,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
	},
	Desc = "被认为是百年一见的驱魔天才。身体中有一半妖怪血统，因此能看穿普通妖怪的心事，听说读写妖怪文，还能辨别妖怪的气息。因行为偏差被流放到流亡街。他封印妖怪不为任何人，只为完成自己的图鉴大全。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id1013] =
{
	Id = 1013,
	Name = "通缉夕大人",
	Boss = true,
	IntroduceText = "夕大人，男性，疑似未成年兽类，籍贯不详。\n据可靠报告，夕大人今年已受到流亡街通缉犯的邀请正式加入流亡组织，领导一众罪犯闹新年。为保证大家新年快乐，特此通缉。PS：提供额外玉璧奖励！\n\n联系人：未来协会 D先生",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 170,
			Enemy = {
				{
					Value = 246537,
					Level = 170,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
				{
					Value = 2,
					Num = 270,
				},
			},
		},
		{
			SupportLevel = 204,
			Enemy = {
				{
					Value = 246538,
					Level = 204,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
		{
			SupportLevel = 238,
			Enemy = {
				{
					Value = 246539,
					Level = 238,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
	},
	Desc = "每年都会准时去各大星球作乱的怪兽。虽然每次都全副武装，但最后总会被击败，然后被绑着看烟花大会，吃年夜饭，最后发完压岁钱才能放回来。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id1014] =
{
	Id = 1014,
	Name = "通缉死亡骑士",
	Boss = true,
	IntroduceText = "死亡骑士，男性，危险人物。\n据报告，死亡骑士在未接到冒险节邀请情况下擅闯流亡街，并携带大量外来物种，包括宝箱怪及稀有种史莱姆，破坏流亡街生态，特此通缉！PS：提供额外玉璧奖励！\n\n联系人：未来协会 D先生",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 170,
			Enemy = {
				{
					Value = 246540,
					Level = 170,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
				{
					Value = 2,
					Num = 270,
				},
			},
		},
		{
			SupportLevel = 204,
			Enemy = {
				{
					Value = 246541,
					Level = 204,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
		{
			SupportLevel = 238,
			Enemy = {
				{
					Value = 246542,
					Level = 238,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
	},
	Desc = "违反了骑士劳动合同，转会加入死亡军团的武士。其变节原因至今无人知晓，不过有消息人士指出，该人员常年沉湎于酷炫坐骑，拉风造型等时尚品，不排除其盲目追求外表而舍弃正道的可能性。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id1015] =
{
	Id = 1015,
	Name = "通缉“白葡萄酒”",
	Boss = true,
	IntroduceText = "酒堡领主，男性，酷爱酒精饮品。\n据报告，为推广酒庄新式酒品，“白葡萄酒”专程来到流亡街，在没有获得酒类经营证的情况下出售浓度高达99%的危险酒精饮品，特此通缉！PS：提供额外玉璧奖励！\n\n联系人：未来协会 D先生",
	NumCap = 5,
	LevelBG = "FATBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 170,
			Enemy = {
				{
					Value = 246543,
					Level = 170,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
				{
					Value = 2,
					Num = 270,
				},
			},
		},
		{
			SupportLevel = 204,
			Enemy = {
				{
					Value = 246544,
					Level = 204,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
		{
			SupportLevel = 238,
			Enemy = {
				{
					Value = 246545,
					Level = 238,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
	},
	Desc = "为了追求极致酒道而不惜以身犯法的男性，酿制的酒品能够让人一滴断片，忘却任何愉快与烦恼，沉湎酒乡，不能自拔。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id1016] =
{
	Id = 1016,
	Name = "通缉大魔王列车长",
	Boss = true,
	IntroduceText = "魔王号车头，男性，籍贯冒险星，魔王集团交通部在职人员。\n因为过于热情，常常带着乘客四处乱逛，严重扰乱了交通秩序，特此通缉。\n\n联系人：冒险星魔王集团总经理 小魔王",
	NumCap = 5,
	LevelBG = "FATBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 170,
			Enemy = {
				{
					Value = 246546,
					Level = 170,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
				{
					Value = 2,
					Num = 180,
				},
			},
		},
		{
			SupportLevel = 204,
			Enemy = {
				{
					Value = 246547,
					Level = 204,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
		{
			SupportLevel = 238,
			Enemy = {
				{
					Value = 246548,
					Level = 238,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
	},
	Desc = "罪名：扰乱交通秩序。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id1017] =
{
	Id = 1017,
	Name = "通缉大魔王售票员",
	Boss = false,
	IntroduceText = "魔王号列车长，女性，籍贯冒险星，魔王集团交通部在职人员。\n在向乘客鞠躬的时候，头顶燃烧的火焰点燃了乘客的头发，致使乘客变成秃头。\n\n联系人：冒险星魔王集团总经理 小魔王",
	NumCap = 5,
	LevelBG = "FATBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 160,
			Enemy = {
				{
					Value = 246549,
					Level = 160,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 75,
				},
				{
					Value = 2,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 192,
			Enemy = {
				{
					Value = 246550,
					Level = 192,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 75,
				},
			},
		},
		{
			SupportLevel = 224,
			Enemy = {
				{
					Value = 246551,
					Level = 224,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 75,
				},
			},
		},
	},
	Desc = "罪名：烧掉了乘客的头发。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id1018] =
{
	Id = 1018,
	Name = "通缉大魔王乘务员",
	Boss = false,
	IntroduceText = "车厢一号，女性，籍贯冒险星，魔王集团交通部在职人员。\n明明有着聪明的头脑和惊人的计算能力，却经常吐槽自己又多算了0.002秒，此等凡尔赛行为严重影响了周围同事的心情。\n\n联系人：冒险星魔王集团总经理 小魔王",
	NumCap = 5,
	LevelBG = "FATBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 150,
			Enemy = {
				{
					Value = 246552,
					Level = 150,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 70,
				},
				{
					Value = 2,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 180,
			Enemy = {
				{
					Value = 246553,
					Level = 180,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 70,
				},
			},
		},
		{
			SupportLevel = 210,
			Enemy = {
				{
					Value = 246554,
					Level = 210,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 70,
				},
			},
		},
	},
	Desc = "罪名：过于凡尔赛。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id1019] =
{
	Id = 1019,
	Name = "通缉大魔王维修工",
	Boss = false,
	IntroduceText = "车厢二号，男性，籍贯冒险星，魔王集团交通部在职人员。\n在职期间天天划水摸鱼，因为想回家，常常往车的反方向行走，降低了列车的行驶速度。\n\n联系人：冒险星魔王集团总经理 小魔王",
	NumCap = 5,
	LevelBG = "FATBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 140,
			Enemy = {
				{
					Value = 246555,
					Level = 140,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 65,
				},
				{
					Value = 2,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 168,
			Enemy = {
				{
					Value = 246556,
					Level = 168,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 65,
				},
			},
		},
		{
			SupportLevel = 196,
			Enemy = {
				{
					Value = 246557,
					Level = 196,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 65,
				},
			},
		},
	},
	Desc = "罪名：工作超划水。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id1020] =
{
	Id = 1020,
	Name = "通缉大魔王吊车尾",
	Boss = false,
	IntroduceText = "魔王号车尾，男性，籍贯冒险星，魔王集团交通部在职人员。\n在工作期间，把乘客带来的食物吃掉了大半，且在列车长的呵斥下屡教不改。\n\n联系人：冒险星魔王集团总经理 小魔王",
	NumCap = 5,
	LevelBG = "FATBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 130,
			Enemy = {
				{
					Value = 246558,
					Level = 130,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
				{
					Value = 2,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 156,
			Enemy = {
				{
					Value = 246559,
					Level = 156,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
		{
			SupportLevel = 182,
			Enemy = {
				{
					Value = 246560,
					Level = 182,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 60,
				},
			},
		},
	},
	Desc = "罪名：吃乘客的食物且屡教不改。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id1021] =
{
	Id = 1021,
	Name = "通缉斗篷木乃伊",
	Boss = true,
	IntroduceText = "斗篷木乃伊，目测男性，青年，籍贯博物馆星。\n近日接到举报，此人自称广场第一美男子，在居民区唱歌，严重影响老年舞的开展进行，现已从博物馆星逃窜至此，特此通缉。\n\n联系人：中心广场居委会 茶壶主任",
	NumCap = 5,
	LevelBG = "FATBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 170,
			Enemy = {
				{
					Value = 246561,
					Level = 170,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
				{
					Value = 2,
					Num = 180,
				},
			},
		},
		{
			SupportLevel = 204,
			Enemy = {
				{
					Value = 246562,
					Level = 204,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
		{
			SupportLevel = 238,
			Enemy = {
				{
					Value = 246563,
					Level = 238,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
	},
	Desc = "罪名：影响居民们进行广场舞活动。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id1022] =
{
	Id = 1022,
	Name = "通缉绝命法医",
	Boss = true,
	IntroduceText = "绝命法医，目测男性，中年，籍贯悬疑星。\n据悉该人员热爱芭比娃娃，常常在深夜潜入太平间，把沉睡的躯体摆放成各种姿势，且拒不复原，引起众多法医恐慌。\n\n联系人：星际联邦总局 猫探长",
	NumCap = 5,
	LevelBG = "FATBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 170,
			Enemy = {
				{
					Value = 246564,
					Level = 170,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
				{
					Value = 2,
					Num = 180,
				},
			},
		},
		{
			SupportLevel = 204,
			Enemy = {
				{
					Value = 246565,
					Level = 204,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
		{
			SupportLevel = 238,
			Enemy = {
				{
					Value = 246566,
					Level = 238,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
	},
	Desc = "罪名：引起法医们恐慌，且屡教不改。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id1023] =
{
	Id = 1023,
	Name = "通缉划水姻缘神",
	Boss = true,
	IntroduceText = "划水姻缘神，月佬工作时的特殊形态，男性，青年，籍贯神话星。\n据悉，此人工作为决定世间姻缘大事，但工作期间日常划水，乱涂乱画，让许多人不明就里地吃到了爱情的苦。\n\n联系人：流亡街未来协会负责人 D先生",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 170,
			Enemy = {
				{
					Value = 246567,
					Level = 170,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
				{
					Value = 2,
					Num = 180,
				},
			},
		},
		{
			SupportLevel = 204,
			Enemy = {
				{
					Value = 246568,
					Level = 204,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
		{
			SupportLevel = 238,
			Enemy = {
				{
					Value = 246569,
					Level = 238,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
	},
	Desc = "罪名：让许多人吃到了爱情的苦。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id1024] =
{
	Id = 1024,
	Name = "通缉变味小紫",
	Boss = true,
	IntroduceText = "变味小紫，性别不明，目测未成年，身高不足5cm，籍贯美食星。\n此人自称随身携带“葡萄味糖豆”，并热情地把紫色糖豆分给美食星居民，然而吃了之后大家才发现，这些豆子都是死鱼口味的。\n\n联系人：美食星料理协会 米淇淋厨师长",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 170,
			Enemy = {
				{
					Value = 246570,
					Level = 170,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
				{
					Value = 2,
					Num = 180,
				},
			},
		},
		{
			SupportLevel = 204,
			Enemy = {
				{
					Value = 246571,
					Level = 204,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
		{
			SupportLevel = 238,
			Enemy = {
				{
					Value = 246572,
					Level = 238,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
	},
	Desc = "罪名：喂无辜居民吃死鱼味的零食。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id1025] =
{
	Id = 1025,
	Name = "通缉剧毒丝丝",
	Boss = true,
	IntroduceText = "剧毒丝丝，性别女，目测未成年，籍贯海洋星。\n据报案人说，此人自从在水母歌唱大赛中被淘汰后，便不分昼夜地在居民区练歌，由于技巧不足，大部分都在跑调状态中，对居民的精神健康造成极大影响。\n\n联系人：回溯镇居委会主任 柯以普·库埃特",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 170,
			Enemy = {
				{
					Value = 246573,
					Level = 170,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
				{
					Value = 2,
					Num = 180,
				},
			},
		},
		{
			SupportLevel = 204,
			Enemy = {
				{
					Value = 246574,
					Level = 204,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
		{
			SupportLevel = 238,
			Enemy = {
				{
					Value = 246575,
					Level = 238,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
	},
	Desc = "罪名：不分昼夜地演唱，并且唱歌跑调，影响居民精神健康。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id1026] =
{
	Id = 1026,
	Name = "通缉高级非酋",
	Boss = true,
	IntroduceText = "高级非酋，性别女，青年，籍贯不明。\n据相关人员说，此人在不夜城连抽十天，一发未出，大声哭诉不夜城是黑店，对不夜城的声誉造成了极大影响。\n\n联系人：不夜城工作人员 玉璧女王",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 170,
			Enemy = {
				{
					Value = 246576,
					Level = 170,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
				{
					Value = 2,
					Num = 180,
				},
			},
		},
		{
			SupportLevel = 204,
			Enemy = {
				{
					Value = 246577,
					Level = 204,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
		{
			SupportLevel = 238,
			Enemy = {
				{
					Value = 246578,
					Level = 238,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
	},
	Desc = "罪名：严重影响不夜城的商业声誉。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id1027] =
{
	Id = 1027,
	Name = "通缉幽灵骑士",
	Boss = true,
	IntroduceText = "幽灵骑士，性别男，危险人物，籍贯不详。\n据悉，此人来到流亡街，动辄拔剑找人战斗。不仅如此，此人还在战斗中使用幽灵隐身秘术，破坏决斗的公平性，特此通缉。\n\n联系人：未来协会 D先生",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 170,
			Enemy = {
				{
					Value = 246579,
					Level = 170,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
				{
					Value = 2,
					Num = 180,
				},
			},
		},
		{
			SupportLevel = 204,
			Enemy = {
				{
					Value = 246580,
					Level = 204,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
		{
			SupportLevel = 238,
			Enemy = {
				{
					Value = 246581,
					Level = 238,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
	},
	Desc = "罪名：破坏决斗公平性。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id1028] =
{
	Id = 1028,
	Name = "迈克罗夫特官员",
	Boss = true,
	IntroduceText = "迈克罗夫特官员，男性，籍贯悬疑星，在政府机关内有重要地位。\n据最新情报，此人涉嫌贪污受贿，曾趁职务之便，收取巧克力、蛋糕、甜甜圈等物品，极大影响了政府的正面形象，特此通缉。\n\n联系人：星际联邦总局 猫探长",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 170,
			Enemy = {
				{
					Value = 246582,
					Level = 170,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
				{
					Value = 2,
					Num = 180,
				},
			},
		},
		{
			SupportLevel = 204,
			Enemy = {
				{
					Value = 246583,
					Level = 204,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
		{
			SupportLevel = 238,
			Enemy = {
				{
					Value = 246584,
					Level = 238,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
	},
	Desc = "罪名：收取他人甜食，涉嫌贪污受贿。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id1029] =
{
	Id = 1029,
	Name = "迷路NPC",
	Boss = true,
	IntroduceText = "迷路NPC，男性，目测中年，籍贯冒险星。\n据悉，此人患有路盲症，却热爱为别人指路。曾在冒险星上工作，导致数十名勇者走上错误的道路，在森林中迷失方向，对冒险协会造成了恶劣影响。\n\n联系人：冒险星深坑谷交通管理局 盐队长",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 170,
			Enemy = {
				{
					Value = 246585,
					Level = 170,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
				{
					Value = 2,
					Num = 180,
				},
			},
		},
		{
			SupportLevel = 204,
			Enemy = {
				{
					Value = 246586,
					Level = 204,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
		{
			SupportLevel = 238,
			Enemy = {
				{
					Value = 246587,
					Level = 238,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
	},
	Desc = "罪名：胡乱指路，导致勇者迷失。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id1030] =
{
	Id = 1030,
	Name = "噪音生产家",
	Boss = true,
	IntroduceText = "噪音生产家，男性，目测青年，籍贯博物馆星。\n此人嗓门极大，因为受到惊吓而尖叫，声音分贝过高，震碎了博物馆星的玻璃，间接导致文物失窃事件。\n\n联系人：文物厅总管局 察尔斯",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 170,
			Enemy = {
				{
					Value = 246588,
					Level = 170,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
				{
					Value = 2,
					Num = 180,
				},
			},
		},
		{
			SupportLevel = 204,
			Enemy = {
				{
					Value = 246589,
					Level = 204,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
		{
			SupportLevel = 238,
			Enemy = {
				{
					Value = 246590,
					Level = 238,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
	},
	Desc = "罪名：震碎玻璃，间接导致文物失窃。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id1031] =
{
	Id = 1031,
	Name = "暴力法官",
	Boss = true,
	IntroduceText = "暴力法官，性别不详，目测青年，籍贯悬疑星。\n据悉，此人审理不顺时，便会进入暴走状态，曾在法庭上气愤地扔出木槌，正中辩护律师的大脑门。目前该律师已送往医院救治，有较大失忆可能。\n\n联系人：现场第一医院 莱斯特福医生",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 170,
			Enemy = {
				{
					Value = 246591,
					Level = 170,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
				{
					Value = 2,
					Num = 180,
				},
			},
		},
		{
			SupportLevel = 204,
			Enemy = {
				{
					Value = 246592,
					Level = 204,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
		{
			SupportLevel = 238,
			Enemy = {
				{
					Value = 246593,
					Level = 238,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
	},
	Desc = "罪名：把木槌扔到律师的大脑门上。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id1032] =
{
	Id = 1032,
	Name = "散架骷髅",
	Boss = true,
	IntroduceText = "散架骷髅，男性，年龄不详，籍贯冒险星。\n该员工就职于魔王集团，身体素质差，接见董事长当天身体意外散架，把董事长绊住摔了个狗吃屎。此事对魔王集团形象造成严重损害，特此通缉。\n\n联系人：魔王集团总经理 小魔王",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 170,
			Enemy = {
				{
					Value = 246594,
					Level = 170,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
				{
					Value = 2,
					Num = 180,
				},
			},
		},
		{
			SupportLevel = 204,
			Enemy = {
				{
					Value = 246595,
					Level = 204,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
		{
			SupportLevel = 238,
			Enemy = {
				{
					Value = 246596,
					Level = 238,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
	},
	Desc = "罪名：让魔王集团董事长摔倒，严重损害集团形象。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id1033] =
{
	Id = 1033,
	Name = "年度邪神",
	Boss = true,
	IntroduceText = "年度邪神，男性，年龄不详，星际流民。\n据悉，此人常出没于新年前后，热衷于抢走小朋友们的压岁钱，给小朋友们带来了严重的心理阴影。目前涉案金额已达5万玉璧。\n\n联系人：未来协会 D先生",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 170,
			Enemy = {
				{
					Value = 246597,
					Level = 170,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
				{
					Value = 2,
					Num = 180,
				},
			},
		},
		{
			SupportLevel = 204,
			Enemy = {
				{
					Value = 246598,
					Level = 204,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
		{
			SupportLevel = 238,
			Enemy = {
				{
					Value = 246599,
					Level = 238,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
	},
	Desc = "罪名：让许多人吃到了爱情的苦。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id1034] =
{
	Id = 1034,
	Name = "有始无终",
	Boss = true,
	IntroduceText = "有始无终，一男一女，年龄不详，星际流民。\n此人做事有始无终，例如，曾答应小魔王担任战斗顾问优化副本，但只改了一个道具形态就开始摸鱼。因魔王集团的举报，特此通缉。\n\n联系人：魔王集团总经理 小魔王",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 170,
			Enemy = {
				{
					Value = 246600,
					Level = 170,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
				{
					Value = 2,
					Num = 180,
				},
			},
		},
		{
			SupportLevel = 204,
			Enemy = {
				{
					Value = 246601,
					Level = 204,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
		{
			SupportLevel = 238,
			Enemy = {
				{
					Value = 246602,
					Level = 238,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
	},
	Desc = "罪名：喂无辜居民吃死鱼味的零食。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id1035] =
{
	Id = 1035,
	Name = "极寒雪怪",
	Boss = true,
	IntroduceText = "极寒雪怪，女性，目测青年，籍贯不详。\n据悉，此人常出现在寒冬的夜里，以关掉居民们的空调暖气为乐，对广大居民的生活造成了巨大影响。\n\n联系人：中心广场居委会 茶壶主任",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 170,
			Enemy = {
				{
					Value = 246603,
					Level = 170,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
				{
					Value = 2,
					Num = 180,
				},
			},
		},
		{
			SupportLevel = 204,
			Enemy = {
				{
					Value = 246604,
					Level = 204,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
		{
			SupportLevel = 238,
			Enemy = {
				{
					Value = 246605,
					Level = 238,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
	},
	Desc = "罪名：不分昼夜地演唱，并且唱歌跑调，影响居民精神健康。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id1036] =
{
	Id = 1036,
	Name = "猫爪厨娘",
	Boss = true,
	IntroduceText = "猫爪厨娘，女性，目测青年，籍贯不详。\n据悉，此人拥有一对猫眼和猫爪，做好菜后会偷偷挖走一些，藏在自己的爪子里，导致其就职饭店常因菜品缺斤少两被投诉。\n\n联系人：险胜客家庭餐厅 拉玛森老板",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 170,
			Enemy = {
				{
					Value = 246606,
					Level = 170,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
				{
					Value = 2,
					Num = 180,
				},
			},
		},
		{
			SupportLevel = 204,
			Enemy = {
				{
					Value = 246607,
					Level = 204,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
		{
			SupportLevel = 238,
			Enemy = {
				{
					Value = 246608,
					Level = 238,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
	},
	Desc = "罪名：严重影响不夜城的商业声誉。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id1037] =
{
	Id = 1037,
	Name = "互联网黑话家",
	Boss = true,
	IntroduceText = "温泉鉴赏家，男性，目测青年，籍贯不详。\n据悉，此人习惯性讲互联网黑话，动辄便是“底层逻辑”、“顶层设计”、“逻辑闭环”，让同事们听了直呼头疼，不得已而集体实名举报。\n\n联系人：温泉别墅老板 猫眼厨娘",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 170,
			Enemy = {
				{
					Value = 246609,
					Level = 170,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
				{
					Value = 2,
					Num = 180,
				},
			},
		},
		{
			SupportLevel = 204,
			Enemy = {
				{
					Value = 246610,
					Level = 204,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
		{
			SupportLevel = 238,
			Enemy = {
				{
					Value = 246611,
					Level = 238,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
	},
	Desc = "罪名：破坏决斗公平性。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id1038] =
{
	Id = 1038,
	Name = "无良房东",
	Boss = true,
	IntroduceText = "枕头撕裂者，女性，目测中老年，籍贯悬疑星。\n据悉，此人对“睡衣派对”、“枕头大战”恨之入骨，曾在三天内愤怒地撕碎了345个无辜枕头，四处飘落的羽毛极大影响了附近施工大队的工作。\n\n联系人：侦探街施工大队 琼斯队长",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 170,
			Enemy = {
				{
					Value = 246612,
					Level = 170,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
				{
					Value = 2,
					Num = 180,
				},
			},
		},
		{
			SupportLevel = 204,
			Enemy = {
				{
					Value = 246613,
					Level = 204,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
		{
			SupportLevel = 238,
			Enemy = {
				{
					Value = 246614,
					Level = 238,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
	},
	Desc = "罪名：收取他人甜食，涉嫌贪污受贿。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id1039] =
{
	Id = 1039,
	Name = "广场舞领舞",
	Boss = true,
	IntroduceText = "广场舞领舞，女性，目测青年，籍贯冒险星。\n据悉，此人热爱跳舞，仅用时三天就召集了100位广场舞者，成立857舞团，彻底占领冒险协会训练广场。\n\n联系人：冒险协会支线任务发布人 村长夫人",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 170,
			Enemy = {
				{
					Value = 246615,
					Level = 170,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
				{
					Value = 2,
					Num = 180,
				},
			},
		},
		{
			SupportLevel = 204,
			Enemy = {
				{
					Value = 246616,
					Level = 204,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
		{
			SupportLevel = 238,
			Enemy = {
				{
					Value = 246617,
					Level = 238,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
	},
	Desc = "罪名：胡乱指路，导致勇者迷失。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id1040] =
{
	Id = 1040,
	Name = "武士俑",
	Boss = true,
	IntroduceText = "鬼武者，男性，年龄不详，籍贯博物馆星。\n此人习惯性拔刀，不管发生什么，下一秒总会拔出砍刀并架在他人脖子上，目前被众多无辜居民投诉，特此通缉。\n\n联系人：风纪协会 理女士",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 170,
			Enemy = {
				{
					Value = 246618,
					Level = 170,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
				{
					Value = 2,
					Num = 180,
				},
			},
		},
		{
			SupportLevel = 204,
			Enemy = {
				{
					Value = 246619,
					Level = 204,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
		{
			SupportLevel = 238,
			Enemy = {
				{
					Value = 246620,
					Level = 238,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
	},
	Desc = "罪名：震碎玻璃，间接导致文物失窃。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id1041] =
{
	Id = 1041,
	Name = "刺猬头律师",
	Boss = true,
	IntroduceText = "刺猬头律师，男性，年龄不详，籍贯悬疑星。\n此人梳着标准的刺猬头，在庭审期间，常奋力拍打桌面，目前已拍坏了2398张桌子，因而被律师协会成员集体投诉。\n\n联系人：星际联邦总局 猫探长",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 170,
			Enemy = {
				{
					Value = 246621,
					Level = 170,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
				{
					Value = 2,
					Num = 180,
				},
			},
		},
		{
			SupportLevel = 204,
			Enemy = {
				{
					Value = 246622,
					Level = 204,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
		{
			SupportLevel = 238,
			Enemy = {
				{
					Value = 246623,
					Level = 238,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
	},
	Desc = "罪名：把木槌扔到律师的大脑门上。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}
ArenaBattleConfig[ArenaBattleID.Id1042] =
{
	Id = 1042,
	Name = "白痴学者",
	Boss = true,
	IntroduceText = "白痴学者，性别不明，目测青年，籍贯冒险星。\n此人喜欢向别人科普虚假知识，譬如同时吃猪肉和可乐会降智、呼吸1分钟会导致生命减少60秒等。此等谣言的传播已激发学者界众怒。\n\n联系人：博智中学校长 史先生",
	NumCap = 5,
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	Difficulty = {
		{
			SupportLevel = 170,
			Enemy = {
				{
					Value = 246624,
					Level = 170,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
				{
					Value = 2,
					Num = 180,
				},
			},
		},
		{
			SupportLevel = 204,
			Enemy = {
				{
					Value = 246625,
					Level = 204,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
		{
			SupportLevel = 238,
			Enemy = {
				{
					Value = 246626,
					Level = 238,
				},
			},
			Reward = {
				{
					Value = 320201,
					Num = 160,
				},
			},
		},
	},
	Desc = "罪名：让魔王集团董事长摔倒，严重损害集团形象。",
	ResultText = "成功对目标实施逮捕！",
	Dialog = "哎呀！被抓住了…",
}

