require "FreakPlanet/Design/MiscConfig"
GoodsConfig ={};
GoodsID = 
{
	Id001 = 320001,
	Id002 = 320002,
	Id003 = 320003,
	Id021 = 320021,
	Id041 = 320041,
	Id042 = 320042,
	Id043 = 320043,
	Id044 = 320044,
	Id051 = 320051,
	Id052 = 320052,
	Id053 = 320053,
	Id054 = 320054,
	Id101 = 320101,
	Id102 = 320102,
	Id103 = 320103,
	Id104 = 320104,
	Id105 = 320105,
	Id106 = 320106,
	Id107 = 320107,
	Id151 = 320151,
	Id201 = 320201,
	Id301 = 320301,
	Id302 = 320302,
	Id303 = 320303,
	Id304 = 320304,
	Id305 = 320305,
	Id306 = 320306,
	Id307 = 320307,
	Id308 = 320308,
	Id309 = 320309,
	Id310 = 320310,
	Id311 = 320311,
	Id312 = 320312,
	Id313 = 320313,
	Id314 = 320314,
	Id315 = 320315,
	Id316 = 320316,
	Id317 = 320317,
	Id318 = 320318,
	Id319 = 320319,
	Id320 = 320320,
	Id401 = 320401,
	Id402 = 320402,
	Id403 = 320403,
	Id404 = 320404,
	Id405 = 320405,
	Id406 = 320406,
	Id407 = 320407,
	Id408 = 320408,
	Id409 = 320409,
	Id410 = 320410,
	Id411 = 320411,
	Id412 = 320412,
	Id413 = 320413,
	Id414 = 320414,
	Id415 = 320415,
	Id416 = 320416,
	Id417 = 320417,
	Id418 = 320418,
	Id419 = 320419,
	Id420 = 320420,
	Id421 = 320421,
	Id422 = 320422,
	Id423 = 320423,
	Id424 = 320424,
	Id501 = 320501,
	Id502 = 320502,
	Id503 = 320503,
	Id504 = 320504,
	Id505 = 320505,
	Id506 = 320506,
	Id507 = 320507,
	Id508 = 320508,
	Id509 = 320509,
	Id510 = 320510,
	Id511 = 320511,
	Id512 = 320512,
	Id513 = 320513,
	Id514 = 320514,
	Id515 = 320515,
	Id516 = 320516,
	Id517 = 320517,
	Id518 = 320518,
	Id519 = 320519,
	Id520 = 320520,
	Id521 = 320521,
	Id522 = 320522,
	Id523 = 320523,
	Id524 = 320524,
	Id525 = 320525,
	Id526 = 320526,
	Id527 = 320527,
	Id528 = 320528,
	Id529 = 320529,
	Id530 = 320530,
	Id531 = 320531,
	Id532 = 320532,
	Id533 = 320533,
	Id534 = 320534,
	Id535 = 320535,
	Id536 = 320536,
	Id537 = 320537,
	Id538 = 320538,
	Id539 = 320539,
	Id540 = 320540,
	Id541 = 320541,
	Id542 = 320542,
	Id543 = 320543,
	Id544 = 320544,
	Id545 = 320545,
	Id546 = 320546,
	Id547 = 320547,
	Id548 = 320548,
	Id549 = 320549,
	Id550 = 320550,
	Id551 = 320551,
	Id601 = 320601,
	Id602 = 320602,
	Id611 = 320611,
	Id612 = 320612,
	Id613 = 320613,
	Id614 = 320614,
	Id615 = 320615,
	Id1001 = 321001,
	Id1002 = 321002,
	Id1003 = 321003,
	Id1004 = 321004,
	Id1005 = 321005,
	Id1006 = 321006,
	Id1007 = 321007,
	Id1008 = 321008,
	Id1009 = 321009,
	Id1010 = 321010,
	Id1051 = 321051,
	Id1052 = 321052,
	Id1053 = 321053,
	Id1054 = 321054,
	Id1201 = 321201,
	Id1202 = 321202,
	Id1203 = 321203,
	Id1204 = 321204,
	Id1205 = 321205,
	Id1206 = 321206,
	Id1207 = 321207,
	Id1208 = 321208,
	Id1209 = 321209,
	Id1210 = 321210,
	Id1251 = 321251,
	Id1252 = 321252,
	Id1253 = 321253,
	Id1254 = 321254,
	Id1401 = 321401,
	Id1402 = 321402,
	Id1403 = 321403,
	Id1404 = 321404,
	Id1405 = 321405,
	Id1406 = 321406,
	Id1407 = 321407,
	Id1408 = 321408,
	Id1409 = 321409,
	Id1410 = 321410,
	Id1411 = 321411,
	Id1451 = 321451,
	Id1452 = 321452,
	Id1453 = 321453,
	Id1454 = 321454,
	Id1601 = 321601,
	Id1602 = 321602,
	Id1603 = 321603,
	Id1604 = 321604,
	Id1605 = 321605,
	Id1606 = 321606,
	Id1607 = 321607,
	Id1608 = 321608,
	Id1609 = 321609,
	Id1610 = 321610,
	Id1611 = 321611,
	Id1612 = 321612,
	Id1651 = 321651,
	Id1652 = 321652,
	Id1653 = 321653,
	Id1654 = 321654,
	Id1801 = 321801,
	Id1802 = 321802,
	Id1803 = 321803,
	Id1804 = 321804,
	Id1805 = 321805,
	Id1806 = 321806,
	Id1807 = 321807,
	Id1808 = 321808,
	Id1809 = 321809,
	Id1810 = 321810,
	Id1811 = 321811,
	Id1812 = 321812,
	Id1813 = 321813,
	Id1814 = 321814,
	Id1851 = 321851,
	Id1852 = 321852,
	Id1853 = 321853,
	Id1854 = 321854,
	Id7301 = 327301,
	Id7302 = 327302,
	Id7303 = 327303,
	Id7304 = 327304,
	Id7305 = 327305,
	Id7306 = 327306,
	Id7307 = 327307,
	Id7308 = 327308,
	Id7309 = 327309,
	Id7310 = 327310,
	Id7311 = 327311,
	Id7312 = 327312,
	Id7313 = 327313,
	Id7314 = 327314,
	Id7315 = 327315,
	Id7316 = 327316,
	Id7317 = 327317,
	Id7318 = 327318,
	Id7319 = 327319,
}
GoodsConfig[GoodsID.Id001] =
{
	Id = 1,
	Name = "低量电池",
	Rarity = 2,
	Gallery = 950101,
	CustomReward = true,
	StorgeSortId = 20,
	OnlyOne = false,
	SubType = "Chip",
	IconAtlas = "Goods",
	Icon = "Token_LevelCap1",
	Desc = "拥有少量元气的能源电池，是角色突破等级上限必需的道具。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560110,
		564303,
		560006,
		564382,
		564402,
		564403,
		564404,
		564392,
	},
	From = {
		{
			SourceType = SourceType.Demand,
		},
		{
			SourceType = SourceType.ArenaMarket,
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id002] =
{
	Id = 2,
	Name = "高能电池",
	Rarity = 3,
	Gallery = 950101,
	CustomReward = true,
	StorgeSortId = 19,
	OnlyOne = false,
	SubType = "Chip",
	IconAtlas = "Goods",
	Icon = "Token_LevelCap2",
	Desc = "拥有中量元气的能源电池，是角色突破等级上限不能不必需的道具。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560110,
		564303,
		560006,
		564383,
		564403,
		564404,
		564392,
		564393,
	},
	From = {
		{
			SourceType = SourceType.Demand,
		},
		{
			SourceType = SourceType.ArenaMarket,
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id003] =
{
	Id = 3,
	Name = "超能电池",
	Rarity = 4,
	Gallery = 950101,
	CustomReward = true,
	StorgeSortId = 18,
	OnlyOne = false,
	SubType = "Chip",
	IconAtlas = "Goods",
	Icon = "Token_LevelCap3",
	Desc = "拥有大量元气的能源电池，是角色突破等级上限必须不能不必需的道具。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560110,
		564303,
		560006,
		564384,
		564404,
		564392,
		564393,
		564394,
	},
	From = {
		{
			SourceType = SourceType.Demand,
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id021] =
{
	Id = 21,
	Name = "危险电池",
	Rarity = 3,
	Gallery = 950101,
	StorgeSortId = 17,
	OnlyOne = false,
	SubType = "Chip",
	IconAtlas = "Goods",
	Icon = "Token_LevelCapPirate1",
	Desc = "拥有罪恶气息的能源电池，是流亡街角色突破等级上限必需的道具。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560110,
		564303,
		560006,
	},
	From = {
		{
			SourceType = SourceType.ArenaMarket,
		},
	},
}
GoodsConfig[GoodsID.Id041] =
{
	Id = 41,
	Name = "强化零件D",
	Rarity = 1,
	Gallery = 950101,
	CustomReward = true,
	StorgeSortId = 30,
	OnlyOne = false,
	SubType = "Chip",
	IconAtlas = "Goods",
	Icon = "Token_WeaponUpgrade1",
	Desc = "由宇宙工坊发行的特制零件D型，能够针对攻击型道具进行简单强化。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560110,
		564304,
		564322,
		560006,
		564352,
		564372,
		564373,
		564374,
		564375,
		564362,
	},
	From = {
		{
			SourceType = SourceType.Demand,
		},
		{
			SourceType  = SourceType.Summon,
			Value = {
				500003,
			},
		},
	},
}
GoodsConfig[GoodsID.Id042] =
{
	Id = 42,
	Name = "强化零件C",
	Rarity = 2,
	Gallery = 950101,
	CustomReward = true,
	StorgeSortId = 29,
	OnlyOne = false,
	SubType = "Chip",
	IconAtlas = "Goods",
	Icon = "Token_WeaponUpgrade2",
	Desc = "由宇宙工坊发行的特制零件C型，能够针对攻击型道具进行中级强化。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560110,
		564304,
		564322,
		560006,
		564353,
		564373,
		564374,
		564375,
		564362,
		564363,
	},
	From = {
		{
			SourceType = SourceType.Demand,
		},
		{
			SourceType  = SourceType.Summon,
			Value = {
				500003,
			},
		},
	},
}
GoodsConfig[GoodsID.Id043] =
{
	Id = 43,
	Name = "强化零件B",
	Rarity = 3,
	Gallery = 950101,
	CustomReward = true,
	StorgeSortId = 28,
	OnlyOne = false,
	SubType = "Chip",
	IconAtlas = "Goods",
	Icon = "Token_WeaponUpgrade3",
	Desc = "由宇宙工坊发行的特制零件B型，能够针对攻击型道具进行高级强化。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560110,
		564304,
		564322,
		560006,
		564354,
		564374,
		564375,
		564362,
		564363,
		564364,
	},
	From = {
		{
			SourceType = SourceType.Demand,
		},
		{
			SourceType = SourceType.ArenaMarket,
		},
		{
			SourceType  = SourceType.Summon,
			Value = {
				500003,
			},
		},
	},
}
GoodsConfig[GoodsID.Id044] =
{
	Id = 44,
	Name = "强化零件A",
	Rarity = 4,
	Gallery = 950101,
	CustomReward = true,
	StorgeSortId = 27,
	OnlyOne = false,
	SubType = "Chip",
	IconAtlas = "Goods",
	Icon = "Token_WeaponUpgrade4",
	Desc = "由宇宙工坊发行的特制零件A型，能够针对攻击型道具进行超级强化。是堪称硬通货的存在！",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560110,
		564304,
		564322,
		560006,
		564355,
		564375,
		564362,
		564363,
		564364,
		564365,
	},
	From = {
		{
			SourceType = SourceType.Demand,
		},
		{
			SourceType  = SourceType.Summon,
			Value = {
				500003,
			},
		},
	},
}
GoodsConfig[GoodsID.Id051] =
{
	Id = 51,
	Name = "固化零件D",
	Rarity = 1,
	Gallery = 950101,
	CustomReward = true,
	StorgeSortId = 26,
	OnlyOne = false,
	SubType = "Chip",
	IconAtlas = "Goods",
	Icon = "Token_ArmorUpgrade1",
	Desc = "由宇宙工坊发行的特制零件D型，能够针对防御型道具进行简单固化。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560110,
		564304,
		564323,
		560006,
		564352,
		564372,
		564373,
		564374,
		564375,
		564362,
	},
	From = {
		{
			SourceType = SourceType.Demand,
		},
		{
			SourceType  = SourceType.Summon,
			Value = {
				500003,
			},
		},
	},
}
GoodsConfig[GoodsID.Id052] =
{
	Id = 52,
	Name = "固化零件C",
	Rarity = 2,
	Gallery = 950101,
	CustomReward = true,
	StorgeSortId = 25,
	OnlyOne = false,
	SubType = "Chip",
	IconAtlas = "Goods",
	Icon = "Token_ArmorUpgrade2",
	Desc = "由宇宙工坊发行的特制零件C型，能够针对防御型道具进行中级固化。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560110,
		564304,
		564323,
		560006,
		564353,
		564373,
		564374,
		564375,
		564362,
		564363,
	},
	From = {
		{
			SourceType = SourceType.Demand,
		},
		{
			SourceType  = SourceType.Summon,
			Value = {
				500003,
			},
		},
	},
}
GoodsConfig[GoodsID.Id053] =
{
	Id = 53,
	Name = "固化零件B",
	Rarity = 3,
	Gallery = 950101,
	CustomReward = true,
	StorgeSortId = 24,
	OnlyOne = false,
	SubType = "Chip",
	IconAtlas = "Goods",
	Icon = "Token_ArmorUpgrade3",
	Desc = "由宇宙工坊发行的特制零件B型，能够针对防御型道具进行高级固化。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560110,
		564304,
		564323,
		560006,
		564354,
		564374,
		564375,
		564362,
		564363,
		564364,
	},
	From = {
		{
			SourceType = SourceType.Demand,
		},
		{
			SourceType = SourceType.ArenaMarket,
		},
		{
			SourceType  = SourceType.Summon,
			Value = {
				500003,
			},
		},
	},
}
GoodsConfig[GoodsID.Id054] =
{
	Id = 54,
	Name = "固化零件A",
	Rarity = 4,
	Gallery = 950101,
	CustomReward = true,
	StorgeSortId = 23,
	OnlyOne = false,
	SubType = "Chip",
	IconAtlas = "Goods",
	Icon = "Token_ArmorUpgrade4",
	Desc = "由宇宙工坊发行的特制零件A型，能够针对防御型道具进行超级固化。是堪称硬通货的存在！",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560110,
		564304,
		564323,
		560006,
		564355,
		564375,
		564362,
		564363,
		564364,
		564365,
	},
	From = {
		{
			SourceType = SourceType.Demand,
		},
		{
			SourceType  = SourceType.Summon,
			Value = {
				500003,
			},
		},
	},
}
GoodsConfig[GoodsID.Id101] =
{
	Id = 101,
	Name = "日记页-超小",
	Rarity = 1,
	Gallery = 950101,
	StorgeSortId = 10,
	OnlyOne = false,
	SubType = "Chip",
	IconAtlas = "Goods",
	Icon = "Token_AtlasMaterial1",
	Desc = "记录着角色回忆的日记页碎片，可以用来帮助人们回忆有趣的事。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560110,
		564309,
		560006,
	},
	From = {
		{
			SourceType  = SourceType.Summon,
			Value = {
				500003,
			},
		},
	},
}
GoodsConfig[GoodsID.Id102] =
{
	Id = 102,
	Name = "日记页-小",
	Rarity = 1,
	Gallery = 950101,
	StorgeSortId = 9,
	OnlyOne = false,
	SubType = "Chip",
	IconAtlas = "Goods",
	Icon = "Token_AtlasMaterial2",
	Desc = "记录着角色回忆的日记页碎片，可以用来帮助人们回忆青葱岁月。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560110,
		564309,
		560006,
	},
	From = {
		{
			SourceType = SourceType.ArenaMarket,
		},
		{
			SourceType  = SourceType.Summon,
			Value = {
				500003,
			},
		},
	},
}
GoodsConfig[GoodsID.Id103] =
{
	Id = 103,
	Name = "日记页-中",
	Rarity = 2,
	Gallery = 950101,
	StorgeSortId = 8,
	OnlyOne = false,
	SubType = "Chip",
	IconAtlas = "Goods",
	Icon = "Token_AtlasMaterial3",
	Desc = "记录着角色回忆的日记页碎片，可以用来帮助人们回忆孤傲的青春。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560110,
		564309,
		560006,
	},
	From = {
		{
			SourceType  = SourceType.Summon,
			Value = {
				500003,
			},
		},
	},
}
GoodsConfig[GoodsID.Id104] =
{
	Id = 104,
	Name = "日记页-大",
	Rarity = 3,
	Gallery = 950101,
	StorgeSortId = 7,
	OnlyOne = false,
	SubType = "Chip",
	IconAtlas = "Goods",
	Icon = "Token_AtlasMaterial4",
	Desc = "记录着角色回忆的日记页碎片，可以用来帮助人们回忆波澜壮阔的往事。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560110,
		564309,
		560006,
	},
	From = {
		{
			SourceType  = SourceType.Summon,
			Value = {
				500003,
			},
		},
	},
}
GoodsConfig[GoodsID.Id105] =
{
	Id = 105,
	Name = "日记页-完整",
	Rarity = 4,
	Gallery = 950101,
	StorgeSortId = 6,
	OnlyOne = false,
	SubType = "Chip",
	IconAtlas = "Goods",
	Icon = "Token_AtlasMaterial5",
	Desc = "记录着角色回忆的完整日记页，可以用来帮助人们回忆黑历史。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560110,
		564309,
		560006,
	},
	From = {
		{
			SourceType  = SourceType.Summon,
			Value = {
				500003,
			},
		},
	},
}
GoodsConfig[GoodsID.Id106] =
{
	Id = 106,
	Name = "小黄鸭救生圈",
	Rarity = 4,
	Gallery = 950101,
	StorgeSortId = 9001,
	OnlyOne = false,
	SubType = "Chip",
	IconAtlas = "Goods",
	Icon = "Token_AtlasMaterial6",
	Desc = "可爱的小黄鸭救生圈，据说带着它去河边玩耍，有可能会被真正的小黄鸭们当作同伴。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560110,
		564309,
		560006,
	},
}
GoodsConfig[GoodsID.Id107] =
{
	Id = 107,
	Name = "羊驼救生圈",
	Rarity = 4,
	Gallery = 950101,
	StorgeSortId = 9002,
	OnlyOne = false,
	SubType = "Chip",
	IconAtlas = "Goods",
	Icon = "Token_AtlasMaterial7",
	Desc = "羊驼救生圈。其实原本叫**马救生圈，因为不符合星际文明用语标准，将**马改成了羊驼二字。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560110,
		564309,
		560006,
	},
}
GoodsConfig[GoodsID.Id151] =
{
	Id = 151,
	Name = "水逆卡",
	Rarity = 1,
	Gallery = 950101,
	StorgeSortId = 51,
	OnlyOne = false,
	SubType = "Chip",
	IconAtlas = "Goods",
	Icon = "Token_UnluckTicket1",
	Desc = "由部落酋长亲自制作的小卡片，如果在外星遇到了疑似同族的人，就会赠送给他。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560110,
		564310,
		560006,
	},
}
GoodsConfig[GoodsID.Id201] =
{
	Id = 201,
	Name = "黑芯片",
	Rarity = 1,
	Gallery = 950101,
	StorgeSortId = 61,
	OnlyOne = false,
	SubType = "Chip",
	IconAtlas = "Goods",
	Icon = "Token_ArenaShopTicket1",
	Desc = "在流亡街暗中流通的货币，不知道由什么机构发布，不过目前作为官方组织的未来协会也在使用。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560110,
		564310,
		560006,
	},
	From = {
		{
			SourceType = SourceType.Arena,
		},
	},
}
GoodsConfig[GoodsID.Id301] =
{
	Id = 301,
	Name = "简单陷阱",
	Rarity = 1,
	StorgeSortId = 201,
	OnlyOne = false,
	SubType = "CatchItem",
	TypeIcon = "Type_CatchItem",
	IconAtlas = "Goods",
	Icon = "CatchItem_Trap1",
	TamePrefab = "CatchItem_Trap1",
	Desc = "道具店老板亲手编织的魔物捕捉陷阱。探索中携带可捕捉宠物，或者被对方当成玩具弄坏。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564307,
		560006,
		564442,
		564462,
		564463,
		564464,
		564452,
	},
	From = {
		{SourceType = SourceType.WorkShop, Value = 
			{
				160001,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id302] =
{
	Id = 302,
	Name = "复合陷阱",
	Rarity = 2,
	StorgeSortId = 200,
	OnlyOne = false,
	SubType = "CatchItem",
	TypeIcon = "Type_CatchItem",
	IconAtlas = "Goods",
	Icon = "CatchItem_Trap2",
	TamePrefab = "CatchItem_Trap2",
	Desc = "复合材料制作的陷阱，牢固度大幅提升。探索中携带可捕捉宠物，被套住的怪物很难逃脱。\n完成道具店装修4任务后解锁配方。",
	Recipe = 360102,
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564307,
		560005,
		564443,
		564463,
		564464,
		564452,
		564453,
	},
	From = {
		{
			SourceType  = SourceType.Summon,
			Value = {
				500001,
				500002,
			},
		},
	},
}
GoodsConfig[GoodsID.Id303] =
{
	Id = 303,
	Name = "合金陷阱",
	Rarity = 3,
	StorgeSortId = 199,
	OnlyOne = false,
	SubType = "CatchItem",
	TypeIcon = "Type_CatchItem",
	IconAtlas = "Goods",
	Icon = "CatchItem_Trap3",
	TamePrefab = "CatchItem_Trap3",
	Desc = "使用新型金属制作的强力陷阱，通风性相当理想。探索中携带可捕捉宠物，被套住的怪物就不想跑了。\n完成道具店装修6任务后解锁配方。",
	Recipe = 360103,
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564307,
		560005,
		564444,
		564464,
		564452,
		564453,
		564454,
	},
	From = {
		{
			SourceType = SourceType.ArenaMarket,
		},
		{
			SourceType  = SourceType.Summon,
			Value = {
				500003,
			},
		},
	},
}
GoodsConfig[GoodsID.Id304] =
{
	Id = 304,
	Name = "顶级陷阱",
	Rarity = 4,
	StorgeSortId = 198,
	OnlyOne = false,
	SubType = "CatchItem",
	TypeIcon = "Type_CatchItem",
	IconAtlas = "Goods",
	Icon = "CatchItem_Trap3",
	TamePrefab = "CatchItem_Trap3",
	Desc = "顶级陷阱，陷阱界的CBD，尊贵身份的象征。带在身上要小心不要被怪物主动钻进去。",
	Recipe = 360104,
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564307,
		560005,
	},
}
GoodsConfig[GoodsID.Id305] =
{
	Id = 305,
	Name = "脏脏的瓶子",
	Rarity = 1,
	StorgeSortId = 191,
	OnlyOne = false,
	SubType = "CatchItem",
	TypeIcon = "Type_CatchItem",
	IconAtlas = "Goods",
	Icon = "CatchItem_Bottle1",
	TamePrefab = "CatchItem_Bottle1",
	Desc = "超市回收机里的饮料空瓶，还有饮料残留。探索中携带可捕捉宠物，但被这东西抓到的怪物会看不起你。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564307,
		560006,
		564442,
		564462,
		564463,
		564464,
		564452,
	},
	From = {
		{SourceType = SourceType.WorkShop, Value = 
			{
				160002,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id306] =
{
	Id = 306,
	Name = "玻璃瓶",
	Rarity = 2,
	StorgeSortId = 190,
	OnlyOne = false,
	SubType = "CatchItem",
	TypeIcon = "Type_CatchItem",
	IconAtlas = "Goods",
	Icon = "CatchItem_Bottle2",
	TamePrefab = "CatchItem_Bottle2",
	Desc = "经杀菌处理的再生空瓶，在里面能享受安静时光。探索中携带可捕捉宠物，怪物普遍表示还不错。\n完成超市装修4任务后解锁配方。",
	Recipe = 360106,
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564307,
		560005,
		564443,
		564463,
		564464,
		564452,
		564453,
	},
	From = {
		{
			SourceType  = SourceType.Summon,
			Value = {
				500001,
				500002,
			},
		},
	},
}
GoodsConfig[GoodsID.Id307] =
{
	Id = 307,
	Name = "精灵瓶",
	Rarity = 3,
	StorgeSortId = 189,
	OnlyOne = false,
	SubType = "CatchItem",
	TypeIcon = "Type_CatchItem",
	IconAtlas = "Goods",
	Icon = "CatchItem_Bottle3",
	TamePrefab = "CatchItem_Bottle3",
	Desc = "遮挡紫外线并调节气流的空瓶，冬暖夏凉。探索中携带可捕捉宠物，不过它们该怎么出来呢？\n完成超市装修6任务后解锁配方。",
	Recipe = 360107,
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564307,
		560005,
		564444,
		564464,
		564452,
		564453,
		564454,
	},
	From = {
		{
			SourceType = SourceType.ArenaMarket,
		},
		{
			SourceType  = SourceType.Summon,
			Value = {
				500003,
			},
		},
	},
}
GoodsConfig[GoodsID.Id308] =
{
	Id = 308,
	Name = "顶级空瓶",
	Rarity = 4,
	StorgeSortId = 188,
	OnlyOne = false,
	SubType = "CatchItem",
	TypeIcon = "Type_CatchItem",
	IconAtlas = "Goods",
	Icon = "CatchItem_Bottle3",
	TamePrefab = "CatchItem_Bottle3",
	Desc = "顶级空瓶，空瓶界的贵族城堡，尊贵身份的象征。\n怪物需要刷卡才能被抓住。",
	Recipe = 360108,
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564307,
		560005,
	},
}
GoodsConfig[GoodsID.Id309] =
{
	Id = 309,
	Name = "简易纸袋",
	Rarity = 1,
	StorgeSortId = 181,
	OnlyOne = false,
	SubType = "CatchItem",
	TypeIcon = "Type_CatchItem",
	IconAtlas = "Goods",
	Icon = "CatchItem_PaperBag1",
	TamePrefab = "CatchItem_PaperBag1",
	Desc = "警察局附近小饭店送来的外卖纸袋。探索中携带可捕捉宠物，也有不少人会跟吃的弄混。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564307,
		560006,
		564442,
		564462,
		564463,
		564464,
		564452,
	},
	From = {
		{SourceType = SourceType.WorkShop, Value = 
			{
				160003,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id310] =
{
	Id = 310,
	Name = "保温纸袋",
	Rarity = 2,
	StorgeSortId = 180,
	OnlyOne = false,
	SubType = "CatchItem",
	TypeIcon = "Type_CatchItem",
	IconAtlas = "Goods",
	Icon = "CatchItem_PaperBag2",
	TamePrefab = "CatchItem_PaperBag2",
	Desc = "设计考究的保温纸袋，印着饭店LOGO。探索中携带可捕捉宠物，要撕下小票，否则会泄露地址噢。\n完成警察局装修4任务后解锁配方。",
	Recipe = 360110,
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564307,
		560005,
		564443,
		564463,
		564464,
		564452,
		564453,
	},
	From = {
		{
			SourceType  = SourceType.Summon,
			Value = {
				500001,
				500002,
			},
		},
	},
}
GoodsConfig[GoodsID.Id311] =
{
	Id = 311,
	Name = "恒温纸袋",
	Rarity = 3,
	StorgeSortId = 179,
	OnlyOne = false,
	SubType = "CatchItem",
	TypeIcon = "Type_CatchItem",
	IconAtlas = "Goods",
	Icon = "CatchItem_PaperBag3",
	TamePrefab = "CatchItem_PaperBag3",
	Desc = "专供VIP客户的恒温纸袋，完美保留温度和水分。探索中携带可捕捉宠物，然后它们就赖着不走了。\n完成警察局装修6任务后解锁配方。",
	Recipe = 360111,
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564307,
		560005,
		564444,
		564464,
		564452,
		564453,
		564454,
	},
	From = {
		{
			SourceType = SourceType.ArenaMarket,
		},
		{
			SourceType  = SourceType.Summon,
			Value = {
				500003,
			},
		},
	},
}
GoodsConfig[GoodsID.Id312] =
{
	Id = 312,
	Name = "顶级纸袋",
	Rarity = 4,
	StorgeSortId = 178,
	OnlyOne = false,
	SubType = "CatchItem",
	TypeIcon = "Type_CatchItem",
	IconAtlas = "Goods",
	Icon = "CatchItem_PaperBag3",
	TamePrefab = "CatchItem_PaperBag3",
	Desc = "顶级纸袋，纸袋界的私人岛屿，尊贵身份的象征。\n申请入住的怪物已经排到五年后了。",
	Recipe = 360112,
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564307,
		560005,
	},
}
GoodsConfig[GoodsID.Id313] =
{
	Id = 313,
	Name = "简易工具箱",
	Rarity = 1,
	StorgeSortId = 171,
	OnlyOne = false,
	SubType = "CatchItem",
	TypeIcon = "Type_CatchItem",
	IconAtlas = "Goods",
	Icon = "CatchItem_ToolCase1",
	TamePrefab = "CatchItem_ToolCase1",
	Desc = "事务所储物间里的工具袋子。探索中携带可捕捉宠物，被星际警察看到的话会被以虐待动物罪罚款。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564307,
		560006,
		564442,
		564462,
		564463,
		564464,
		564452,
	},
	From = {
		{SourceType = SourceType.WorkShop, Value = 
			{
				160004,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id314] =
{
	Id = 314,
	Name = "标准工具箱",
	Rarity = 2,
	StorgeSortId = 170,
	OnlyOne = false,
	SubType = "CatchItem",
	TypeIcon = "Type_CatchItem",
	IconAtlas = "Goods",
	Icon = "CatchItem_ToolCase2",
	TamePrefab = "CatchItem_ToolCase2",
	Desc = "高级材料打造的箱子，内置了两层储物空间。探索中携带可捕捉宠物，怪物表示上铺睡着还行。\n完成事务所装修5任务后解锁配方。",
	Recipe = 360114,
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564307,
		560005,
		564443,
		564463,
		564464,
		564452,
		564453,
	},
	From = {
		{
			SourceType  = SourceType.Summon,
			Value = {
				500002,
			},
		},
	},
}
GoodsConfig[GoodsID.Id315] =
{
	Id = 315,
	Name = "专业工具箱",
	Rarity = 3,
	StorgeSortId = 169,
	OnlyOne = false,
	SubType = "CatchItem",
	TypeIcon = "Type_CatchItem",
	IconAtlas = "Goods",
	Icon = "CatchItem_ToolCase3",
	TamePrefab = "CatchItem_ToolCase3",
	Desc = "内置无线充电的高科技工具箱。探索中携带可捕捉宠物，据说告诉它们WIFI密码成功率还能增加。\n完成事务所装修7任务后解锁配方。",
	Recipe = 360115,
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564307,
		560005,
		564444,
		564464,
		564452,
		564453,
		564454,
	},
	From = {
		{
			SourceType = SourceType.ArenaMarket,
		},
		{
			SourceType  = SourceType.Summon,
			Value = {
				500003,
			},
		},
	},
}
GoodsConfig[GoodsID.Id316] =
{
	Id = 316,
	Name = "顶级工具箱",
	Rarity = 4,
	StorgeSortId = 168,
	OnlyOne = false,
	SubType = "CatchItem",
	TypeIcon = "Type_CatchItem",
	IconAtlas = "Goods",
	Icon = "CatchItem_ToolCase3",
	TamePrefab = "CatchItem_ToolCase3",
	Desc = "顶级工具箱，工具箱界的未来之城，尊贵身份的象征。\n主要还是网速比较快。",
	Recipe = 360116,
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564307,
		560005,
	},
}
GoodsConfig[GoodsID.Id317] =
{
	Id = 317,
	Name = "旧纸板箱",
	Rarity = 1,
	StorgeSortId = 161,
	OnlyOne = false,
	SubType = "CatchItem",
	TypeIcon = "Type_CatchItem",
	IconAtlas = "Goods",
	Icon = "CatchItem_ExpressBox1",
	TamePrefab = "CatchItem_ExpressBox1",
	Desc = "事务所储物间里的纸板箱。探索中携带可捕捉宠物，只要别下雨。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564307,
		560006,
		564442,
		564462,
		564463,
		564464,
		564452,
	},
	From = {
		{SourceType = SourceType.WorkShop, Value = 
			{
				160004,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id318] =
{
	Id = 318,
	Name = "新纸板箱",
	Rarity = 2,
	StorgeSortId = 160,
	OnlyOne = false,
	SubType = "CatchItem",
	TypeIcon = "Type_CatchItem",
	IconAtlas = "Goods",
	Icon = "CatchItem_ExpressBox2",
	TamePrefab = "CatchItem_ExpressBox2",
	Desc = "全新纸板箱，突发情况可以主动躲进去躲避危险。探索中携带可捕捉宠物，只要别下冰雹。\n完成事务所装修4任务后解锁配方。",
	Recipe = 360118,
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564307,
		560005,
		564443,
		564463,
		564464,
		564452,
		564453,
	},
	From = {
		{
			SourceType  = SourceType.Summon,
			Value = {
				500002,
			},
		},
	},
}
GoodsConfig[GoodsID.Id319] =
{
	Id = 319,
	Name = "加固纸板箱",
	Rarity = 3,
	StorgeSortId = 159,
	OnlyOne = false,
	SubType = "CatchItem",
	TypeIcon = "Type_CatchItem",
	IconAtlas = "Goods",
	Icon = "CatchItem_ExpressBox3",
	TamePrefab = "CatchItem_ExpressBox3",
	Desc = "具有避震功能的高级纸箱，提供高质量睡眠。探索中携带可捕捉宠物，下冰雹也没事。\n完成事务所装修6任务后解锁配方。",
	Recipe = 360119,
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564307,
		560005,
		564444,
		564464,
		564452,
		564453,
		564454,
	},
	From = {
		{
			SourceType = SourceType.ArenaMarket,
		},
		{
			SourceType  = SourceType.Summon,
			Value = {
				500003,
			},
		},
	},
}
GoodsConfig[GoodsID.Id320] =
{
	Id = 320,
	Name = "顶级纸板箱",
	Rarity = 4,
	StorgeSortId = 158,
	OnlyOne = false,
	SubType = "CatchItem",
	TypeIcon = "Type_CatchItem",
	IconAtlas = "Goods",
	Icon = "CatchItem_ExpressBox3",
	TamePrefab = "CatchItem_ExpressBox3",
	Desc = "顶级纸板箱，纸板箱界的乐园，尊贵身份的象征。地震也没事。",
	Recipe = 360120,
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564307,
		560005,
	},
}
GoodsConfig[GoodsID.Id401] =
{
	Id = 401,
	Name = "简单口粮",
	Rarity = 1,
	StorgeSortId = 101,
	OnlyOne = false,
	SubType = "Food",
	TypeIcon = "Type_FoodItem",
	IconAtlas = "Goods",
	Icon = "FoodItem_Cookie_1",
	ExploreTime = 90,
	Desc = "卡兹星速食品，时间久了会又硬又干，难以下咽。\n携带后，提供探索时间 1.5分钟。",
	Recipe = 360001,
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564306,
		560005,
	},
}
GoodsConfig[GoodsID.Id402] =
{
	Id = 402,
	Name = "小血瓶",
	Rarity = 1,
	StorgeSortId = 92,
	OnlyOne = false,
	SubType = "Food",
	TypeIcon = "Type_FoodItem",
	IconAtlas = "Goods",
	Icon = "FoodItem_Potion_1",
	ExploreTime = 720,
	Desc = "道具店打工生产。补充体力的冒险伙伴。虽然名字叫血瓶，不过里面装的其实是特浓红茶。\n携带后，提供探索时间 12分钟。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564306,
		560006,
		564412,
		564432,
		564433,
		564434,
		564422,
	},
	From = {
		{SourceType = SourceType.WorkShop, Value = 
			{
				160001,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id403] =
{
	Id = 403,
	Name = "大血瓶",
	Rarity = 2,
	StorgeSortId = 89,
	OnlyOne = false,
	SubType = "Food",
	TypeIcon = "Type_FoodItem",
	IconAtlas = "Goods",
	Icon = "FoodItem_Potion_2",
	ExploreTime = 3600,
	Desc = "大号的冒险伙伴，修复了吨吨吨之后就见底的BUG，可以吨三口。\n携带后，提供探索时间 60分钟。\n完成道具店装修3任务后解锁配方。",
	Recipe = 360003,
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564306,
		560005,
		564413,
		564433,
		564434,
		564422,
		564423,
	},
	From = {
		{
			SourceType  = SourceType.Summon,
			Value = {
				500002,
			},
		},
	},
}
GoodsConfig[GoodsID.Id404] =
{
	Id = 404,
	Name = "特大血瓶",
	Rarity = 3,
	StorgeSortId = 82,
	OnlyOne = false,
	SubType = "Food",
	TypeIcon = "Type_FoodItem",
	IconAtlas = "Goods",
	Icon = "FoodItem_Potion_3",
	ExploreTime = 10800,
	Desc = "特大号的冒险伙伴，分享装，当然也可以一个人喝。\n携带后，提供探索时间 3小时。\n完成道具店装修5任务后解锁配方。",
	Recipe = 360004,
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564306,
		560005,
		564414,
		564434,
		564422,
		564423,
		564424,
	},
	From = {
		{
			SourceType  = SourceType.Summon,
			Value = {
				500003,
			},
		},
	},
}
GoodsConfig[GoodsID.Id405] =
{
	Id = 405,
	Name = "超级大血瓶",
	Rarity = 3,
	StorgeSortId = 78,
	OnlyOne = false,
	SubType = "Food",
	TypeIcon = "Type_FoodItem",
	IconAtlas = "Goods",
	Icon = "FoodItem_Potion_3",
	ExploreTime = 28800,
	Desc = "超级大号的冒险伙伴……嗝……我实在……吨不动了……\n携带后，提供探索时间 8小时。",
	Recipe = 360005,
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564306,
		560005,
	},
}
GoodsConfig[GoodsID.Id406] =
{
	Id = 406,
	Name = "鸡腿",
	Rarity = 1,
	StorgeSortId = 91,
	OnlyOne = false,
	SubType = "Food",
	TypeIcon = "Type_FoodItem",
	IconAtlas = "Goods",
	Icon = "FoodItem_Leg_1",
	ExploreTime = 1800,
	Desc = "超市打工生产。在各地都非常流行的经典美食，除了热量高之外没有任何缺点。\n携带后，提供探索时间 30分钟。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564306,
		560006,
		564412,
		564432,
		564433,
		564434,
		564422,
	},
	From = {
		{SourceType = SourceType.WorkShop, Value = 
			{
				160002,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id407] =
{
	Id = 407,
	Name = "纷享桶",
	Rarity = 2,
	StorgeSortId = 83,
	OnlyOne = false,
	SubType = "Food",
	TypeIcon = "Type_FoodItem",
	IconAtlas = "Goods",
	Icon = "FoodItem_Leg_2",
	ExploreTime = 5400,
	Desc = "装满鸡腿的纸盒，虽然叫纷享，到底会不会分享你心里没数吗？\n携带后，提供探索时间 1小时30分钟。\n完成超市装修3任务后解锁配方。",
	Recipe = 360007,
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564306,
		560005,
		564413,
		564433,
		564434,
		564422,
		564423,
	},
	From = {
		{
			SourceType  = SourceType.Summon,
			Value = {
				500002,
			},
		},
	},
}
GoodsConfig[GoodsID.Id408] =
{
	Id = 408,
	Name = "全家桶",
	Rarity = 3,
	StorgeSortId = 79,
	OnlyOne = false,
	SubType = "Food",
	TypeIcon = "Type_FoodItem",
	IconAtlas = "Goods",
	Icon = "FoodItem_Leg_3",
	ExploreTime = 21600,
	Desc = "装满鸡腿的纸桶，适合只有一口人的家庭享用。\n携带后，提供探索时间 6小时。\n完成超市装修5任务后解锁配方。",
	Recipe = 360008,
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564306,
		560005,
		564414,
		564434,
		564422,
		564423,
		564424,
	},
	From = {
		{
			SourceType  = SourceType.Summon,
			Value = {
				500003,
			},
		},
	},
}
GoodsConfig[GoodsID.Id409] =
{
	Id = 409,
	Name = "超级全家桶",
	Rarity = 3,
	StorgeSortId = 81,
	OnlyOne = false,
	SubType = "Food",
	TypeIcon = "Type_FoodItem",
	IconAtlas = "Goods",
	Icon = "FoodItem_Leg_3",
	ExploreTime = 14400,
	Desc = "鸡腿满到快要溢出来的纸桶，相信自己，这也是个人量。\n携带后，提供探索时间 4小时。",
	Recipe = 360009,
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564306,
		560005,
	},
}
GoodsConfig[GoodsID.Id410] =
{
	Id = 410,
	Name = "小便当",
	Rarity = 1,
	StorgeSortId = 89,
	OnlyOne = false,
	SubType = "Food",
	TypeIcon = "Type_FoodItem",
	IconAtlas = "Goods",
	Icon = "FoodItem_Bento_1",
	ExploreTime = 3600,
	Desc = "警局打工生产。批量订购的员工餐，但因为迷信原因，冒险的人都不是很喜欢带这玩意。\n携带后，提供探索时间 60分钟。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564306,
		560006,
		564412,
		564432,
		564433,
		564434,
		564422,
	},
	From = {
		{SourceType = SourceType.WorkShop, Value = 
			{
				160003,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id411] =
{
	Id = 411,
	Name = "大便当",
	Rarity = 2,
	StorgeSortId = 81,
	OnlyOne = false,
	SubType = "Food",
	TypeIcon = "Type_FoodItem",
	IconAtlas = "Goods",
	Icon = "FoodItem_Bento_2",
	ExploreTime = 14400,
	Desc = "经过定制的套餐，看着让人咽唾沫，或者是因为害怕？\n携带后，提供探索时间 4小时。\n完成警察局装修3任务后解锁配方。",
	Recipe = 360011,
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564306,
		560005,
		564413,
		564433,
		564434,
		564422,
		564423,
	},
	From = {
		{
			SourceType  = SourceType.Summon,
			Value = {
				500002,
			},
		},
	},
}
GoodsConfig[GoodsID.Id412] =
{
	Id = 412,
	Name = "豪华便当",
	Rarity = 3,
	StorgeSortId = 76,
	OnlyOne = false,
	SubType = "Food",
	TypeIcon = "Type_FoodItem",
	IconAtlas = "Goods",
	Icon = "FoodItem_Bento_3",
	ExploreTime = 43200,
	Desc = "精心料理的套餐，一口下去非常满足，让吃到的人不禁流泪大喊“领便当啦！”\n携带后，提供探索时间 12小时。\n完成警察局装修5任务后解锁配方。",
	Recipe = 360012,
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564306,
		560005,
		564414,
		564434,
		564422,
		564423,
		564424,
	},
	From = {
		{
			SourceType  = SourceType.Summon,
			Value = {
				500003,
			},
		},
	},
}
GoodsConfig[GoodsID.Id413] =
{
	Id = 413,
	Name = "超豪华便当",
	Rarity = 3,
	StorgeSortId = 73,
	OnlyOne = false,
	SubType = "Food",
	TypeIcon = "Type_FoodItem",
	IconAtlas = "Goods",
	Icon = "FoodItem_Bento_3",
	ExploreTime = 86400,
	Desc = "专为高层准备的高级便当，米饭下有整条海鳗。\n携带后，提供探索时间 1天。",
	Recipe = 360013,
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564306,
		560005,
	},
}
GoodsConfig[GoodsID.Id414] =
{
	Id = 414,
	Name = "元气沙拉",
	Rarity = 2,
	StorgeSortId = 91,
	OnlyOne = false,
	SubType = "Food",
	TypeIcon = "Type_FoodItem",
	IconAtlas = "Goods",
	Icon = "FoodItem_Leg_1",
	ExploreTime = 1800,
	Desc = "健康沙拉，有丰富的蔬菜纤维，能有效调理肠胃。\n携带后，提供探索时间 30分钟。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564306,
		560006,
	},
}
GoodsConfig[GoodsID.Id415] =
{
	Id = 415,
	Name = "功能饮料",
	Rarity = 2,
	StorgeSortId = 89,
	OnlyOne = false,
	SubType = "Food",
	TypeIcon = "Type_FoodItem",
	IconAtlas = "Goods",
	Icon = "FoodItem_Leg_1",
	ExploreTime = 3600,
	Desc = "不为人知的食物，能够提供特殊效果噢~\n携带后，提供探索时间 60分钟。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564306,
		560006,
	},
}
GoodsConfig[GoodsID.Id416] =
{
	Id = 416,
	Name = "葡萄糖",
	Rarity = 2,
	StorgeSortId = 89,
	OnlyOne = false,
	SubType = "Food",
	TypeIcon = "Type_FoodItem",
	IconAtlas = "Goods",
	Icon = "FoodItem_Leg_1",
	ExploreTime = 3600,
	Desc = "不为人知的食物，能够提供特殊效果噢~\n携带后，提供探索时间 60分钟。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564306,
		560006,
	},
}
GoodsConfig[GoodsID.Id417] =
{
	Id = 417,
	Name = "皇家罐头",
	Rarity = 2,
	StorgeSortId = 89,
	OnlyOne = false,
	SubType = "Food",
	TypeIcon = "Type_FoodItem",
	IconAtlas = "Goods",
	Icon = "FoodItem_Leg_1",
	ExploreTime = 3600,
	Desc = "不为人知的食物，能够提供特殊效果噢~\n携带后，提供探索时间 60分钟。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564306,
		560006,
	},
}
GoodsConfig[GoodsID.Id418] =
{
	Id = 418,
	Name = "BBQ",
	Rarity = 2,
	StorgeSortId = 78,
	OnlyOne = false,
	SubType = "Food",
	TypeIcon = "Type_FoodItem",
	IconAtlas = "Goods",
	Icon = "FoodItem_Leg_1",
	ExploreTime = 28800,
	Desc = "不为人知的食物，能够提供特殊效果噢~\n携带后，提供探索时间 8小时。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564306,
		560006,
	},
}
GoodsConfig[GoodsID.Id419] =
{
	Id = 419,
	Name = "碳酸饮料",
	Rarity = 2,
	StorgeSortId = 89,
	OnlyOne = false,
	SubType = "Food",
	TypeIcon = "Type_FoodItem",
	IconAtlas = "Goods",
	Icon = "FoodItem_Leg_1",
	ExploreTime = 3600,
	Desc = "不为人知的食物，能够提供特殊效果噢~\n携带后，提供探索时间 60分钟。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564306,
		560006,
	},
}
GoodsConfig[GoodsID.Id420] =
{
	Id = 420,
	Name = "元宵",
	Rarity = 2,
	StorgeSortId = 7000,
	OnlyOne = false,
	SubType = "Food",
	TypeIcon = "Type_FoodItem",
	IconAtlas = "Goods",
	Icon = "FoodItem_ActivityFood_1",
	ExploreTime = 600,
	Desc = "猫总管寄来的即食汤圆，有呜呜喜欢的豆沙馅和漆漆喜欢的鱼干馅。在独自外出冒险的日子里，偶尔也能感受到来自家人的关怀喵~\n携带后，提供探索时间 10分钟。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564306,
		560006,
	},
}
GoodsConfig[GoodsID.Id421] =
{
	Id = 421,
	Name = "冰冰粽",
	Rarity = 2,
	StorgeSortId = 7000,
	OnlyOne = false,
	SubType = "Food",
	TypeIcon = "Type_FoodItem",
	IconAtlas = "Goods",
	Icon = "FoodItem_ActivityFood_2",
	ExploreTime = 600,
	Desc = "宇宙限定版冰冰粽。炎热的夏天，在外探险真是辛苦了，吃一口冰凉的粽子，赶走炎热与疲惫吧！\n携带后，提供探索时间 10分钟。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564306,
		560006,
	},
}
GoodsConfig[GoodsID.Id422] =
{
	Id = 422,
	Name = "童话蛋糕",
	Rarity = 3,
	StorgeSortId = 7000,
	OnlyOne = false,
	SubType = "Food",
	TypeIcon = "Type_FoodItem",
	IconAtlas = "Goods",
	Icon = "FoodItem_ActivityFood_3",
	ExploreTime = 64800,
	Desc = "散发着童话香味的蛋糕，得到了美食星公主们的热烈好评。\n据说吃下蛋糕时，所有的烦恼都会被遗忘。\n携带后，提供探索时间 18小时。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564306,
		560006,
	},
}
GoodsConfig[GoodsID.Id423] =
{
	Id = 423,
	Name = "小熊饼干",
	Rarity = 3,
	StorgeSortId = 7000,
	OnlyOne = false,
	SubType = "Food",
	TypeIcon = "Type_FoodItem",
	IconAtlas = "Goods",
	Icon = "FoodItem_ActivityFood_4",
	ExploreTime = 86400,
	Desc = "旅行结束之际，还请收下这一份礼物。据说是呜呜漆漆亲手烤的小饼干，散发着香甜的味道。\n无论多久，妙奇星球都会等待着你的归来。\n携带后，提供探索时间 1天。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564306,
		560006,
	},
}
GoodsConfig[GoodsID.Id424] =
{
	Id = 424,
	Name = "盲盒月饼",
	Rarity = 3,
	StorgeSortId = 7000,
	OnlyOne = false,
	SubType = "Food",
	TypeIcon = "Type_FoodItem",
	IconAtlas = "Goods",
	Icon = "FoodItem_SpecialFood_1",
	ExploreTime = 64800,
	Desc = "不知道团圆圆从哪里弄来的月饼。每次拿到手都是热乎乎的，而且散发出一股奇异的烘制类食品的味道。不过要注意的是，热量可能非常高噢~\n携带后，提供探索时间 18小时。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564306,
		560006,
	},
}
GoodsConfig[GoodsID.Id501] =
{
	Id = 501,
	Name = "发光蘑菇",
	Rarity = 4,
	Gallery = 950001,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_RPG_Event_1",
	Desc = "散发着柔和光芒的蘑菇。\n携带后，道具掉落率 +15%。",
	Skill = {
		{
			Id = 100221,
			Value = 15,
		},
	},
	Tags = {
		560103,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id502] =
{
	Id = 502,
	Name = "幸运金币",
	Rarity = 4,
	Gallery = 950001,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_RPG_Event_7",
	Desc = "古老王朝的神秘金币。\n携带后，探索金币数量 +10%。",
	Skill = {
		{
			Id = 100201,
			Value = 10,
		},
	},
	Tags = {
		560103,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id503] =
{
	Id = 503,
	Name = "路牌",
	Rarity = 4,
	Gallery = 950001,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_RPG_Event_9",
	Desc = "指向回家的路的路牌，跟着走好像会到危险的地方……\n携带后，紫色及以上品质敌人出现概率 +20%；探索等待时间 +10%。",
	Skill = {
		{
			Id = 100003,
			Value = 20,
		},
		{
			Id = 100001,
			Value = 10,
		},
	},
	Tags = {
		560103,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id504] =
{
	Id = 504,
	Name = "喇叭",
	Rarity = 4,
	Gallery = 950001,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_RPG_Event_8",
	Desc = "史莱姆一族开会专用喇叭。\n携带后，史莱姆出现概率 +400%。",
	Skill = {
		{
			Id = 100017,
			Value = 400,
		},
	},
	Tags = {
		560103,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id505] =
{
	Id = 505,
	Name = "祭祀的绳子",
	Rarity = 4,
	Gallery = 950001,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_RPG_Event_10",
	Desc = "遗迹居民用来镇压石头的绳子。\n携带后，石怪捕捉概率 +30%。",
	Skill = {
		{
			Id = 100410,
			Value = 30,
		},
	},
	Tags = {
		560103,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id506] =
{
	Id = 506,
	Name = "陨石",
	Rarity = 4,
	Gallery = 950001,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_RPG_Event_4",
	Desc = "来自太空的高密度金属块，散发出让石怪们感到害怕的气息。\n携带后，石怪出现概率 -50%。",
	Skill = {
		{
			Id = 100018,
			Value = -50,
		},
	},
	Tags = {
		560103,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id507] =
{
	Id = 507,
	Name = "发光骷髅",
	Rarity = 4,
	Gallery = 950001,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_RPG_Event_3",
	Desc = "被巫师遗弃的魔法头盖骨。\n携带后，暗元素敌人捕捉成功率 +30%。",
	Skill = {
		{
			Id = 100404,
			Value = 30,
		},
	},
	Tags = {
		560103,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id508] =
{
	Id = 508,
	Name = "石中剑",
	Rarity = 4,
	Gallery = 950001,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_RPG_Event_5",
	Desc = "象征着力量与正义的剑，使敌人们感到恐惧。\n携带后，紫色及以上品质敌人出现概率 -50%。",
	Skill = {
		{
			Id = 100003,
			Value = -50,
		},
	},
	Tags = {
		560103,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id509] =
{
	Id = 509,
	Name = "鱼竿",
	Rarity = 4,
	Gallery = 950001,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_RPG_Event_11",
	Desc = "在禁止钓鱼的池塘边捡到的钓鱼竿。\n携带后，水元素敌人捕捉成功率 +30%。",
	Skill = {
		{
			Id = 100400,
			Value = 30,
		},
	},
	Tags = {
		560103,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id510] =
{
	Id = 510,
	Name = "泥潭的罚款单",
	Rarity = 4,
	Gallery = 950001,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_RPG_Event_12",
	Desc = "“阁下，请勿挑战当地法律！”\n携带后，紫色及以上品质敌人出现概率 +30%；探索金币数量 -5%。",
	Skill = {
		{
			Id = 100003,
			Value = 30,
		},
		{
			Id = 100201,
			Value = -5,
		},
	},
	Tags = {
		560103,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id511] =
{
	Id = 511,
	Name = "扑克",
	Rarity = 4,
	Gallery = 950001,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_RPG_Event_19",
	Desc = "简单的娱乐，也能够增进朋友间的友谊。\n携带后，火元素敌人出现概率 -50%。",
	Skill = {
		{
			Id = 100006,
			Value = -50,
		},
	},
	Tags = {
		560103,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id512] =
{
	Id = 512,
	Name = "配音演员的CD",
	Rarity = 4,
	Gallery = 950001,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_RPG_Event_18",
	Desc = "配音演员的练习CD，里面有大量能有效催眠的故事。\n携带后，火焰巨人基础捕捉概率 +30。",
	Skill = {
		{
			Id = 100412,
			Value = 30,
		},
	},
	Tags = {
		560103,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id513] =
{
	Id = 513,
	Name = "牧师的日记",
	Rarity = 4,
	Gallery = 950001,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_RPG_Event_16",
	Desc = "牧师随身的日记本，记录着成长中的点点滴滴和自己的小心事。\n携带后，光元素敌人出现概率 +30%。",
	Skill = {
		{
			Id = 100008,
			Value = 30,
		},
	},
	Tags = {
		560103,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id514] =
{
	Id = 514,
	Name = "茶杯",
	Rarity = 4,
	Gallery = 950001,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_RPG_Event_22",
	Desc = "杯底结着厚厚的茶垢，看来主人是个爱喝茶的人。\n携带后，水元素敌人出现概率 +30%。",
	Skill = {
		{
			Id = 100005,
			Value = 30,
		},
	},
	Tags = {
		560103,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id515] =
{
	Id = 515,
	Name = "排队单号",
	Rarity = 4,
	Gallery = 950002,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_FAT_Event_1",
	Desc = "前面还有800人……先去逛一圈吧……\n携带后，打得过的敌人出现概率 +50%；探索等待时间 +10%。",
	Skill = {
		{
			Id = 100016,
			Value = 50,
		},
		{
			Id = 100001,
			Value = 10,
		},
	},
	Tags = {
		560203,
		560104,
		560205,
		560206,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id516] =
{
	Id = 516,
	Name = "观影券",
	Rarity = 4,
	Gallery = 950002,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_FAT_Event_15",
	Desc = "王子影院观赏券，看一次盖个章，满10个才能走……\n携带后，紫色及以上品质敌人出现概率 +30%；探索等待时间 +10%。",
	Skill = {
		{
			Id = 100003,
			Value = 30,
		},
		{
			Id = 100001,
			Value = 10,
		},
	},
	Tags = {
		560203,
		560104,
		560205,
		560206,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id517] =
{
	Id = 517,
	Name = "王子海报",
	Rarity = 4,
	Gallery = 950002,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_FAT_Event_6",
	Desc = "王子的豪华海报，优秀的P图技术让人无法认出这是王子本人。\n携带后，风元素敌人捕捉成功率 +30%。",
	Skill = {
		{
			Id = 100402,
			Value = 30,
		},
	},
	Tags = {
		560203,
		560104,
		560205,
		560206,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id518] =
{
	Id = 518,
	Name = "榨汁机",
	Rarity = 4,
	Gallery = 950002,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_FAT_Event_4",
	Desc = "令水果闻风丧胆的机器，不过已经被水果协会联名要求禁止使用了。\n携带后，水果出现概率 -90%。",
	Skill = {
		{
			Id = 100019,
			Value = -90,
		},
	},
	Tags = {
		560203,
		560104,
		560205,
		560206,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id519] =
{
	Id = 519,
	Name = "滴管",
	Rarity = 4,
	Gallery = 950002,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_FAT_Event_7",
	Desc = "能够精确提取液体的工具，对于调配新型饮料非常重要。\n携带后，空瓶捕捉成功率 +30%。",
	Skill = {
		{
			Id = 100482,
			Value = 30,
		},
	},
	Tags = {
		560203,
		560104,
		560205,
		560206,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id520] =
{
	Id = 520,
	Name = "冠军唱片",
	Rarity = 4,
	Gallery = 950002,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_FAT_Event_16",
	Desc = "年度最佳专辑，不过好像今年只有一个参赛作品……\n携带后，光元素敌人出现概率 -30%。",
	Skill = {
		{
			Id = 100008,
			Value = -30,
		},
	},
	Tags = {
		560203,
		560104,
		560205,
		560206,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id521] =
{
	Id = 521,
	Name = "便条",
	Rarity = 4,
	Gallery = 950002,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_FAT_Event_10",
	Desc = "如果给别人造成麻烦了，可以尝试写张便条来传达歉意……\n携带后，纸袋捕捉成功率 +30%。",
	Skill = {
		{
			Id = 100483,
			Value = 30,
		},
	},
	Tags = {
		560203,
		560104,
		560205,
		560206,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id522] =
{
	Id = 522,
	Name = "电线",
	Rarity = 4,
	Gallery = 950003,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_MUS_Event_2",
	Desc = "从警报器上剪下来的电线，电器的生命线……\n携带后，机械类敌人捕捉成功率 +30%。",
	Skill = {
		{
			Id = 100409,
			Value = 30,
		},
	},
	Tags = {
		560203,
		560204,
		560105,
		560206,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id523] =
{
	Id = 523,
	Name = "直尺",
	Rarity = 4,
	Gallery = 950003,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_MUS_Event_5",
	Desc = "使用宇宙统一的长度单位，能够精确测量距离的工具。\n携带后，工具箱捕捉成功率 +30%。",
	Skill = {
		{
			Id = 100484,
			Value = 30,
		},
	},
	Tags = {
		560203,
		560204,
		560105,
		560206,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id524] =
{
	Id = 524,
	Name = "手电筒",
	Rarity = 4,
	Gallery = 950003,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_MUS_Event_8",
	Desc = "能够帮助人们在黑夜中前行的重要工具。\n携带后，光元素敌人捕捉成功率 +30%；暗元素敌人出现概率 -30%。",
	Skill = {
		{
			Id = 100403,
			Value = 30,
		},
		{
			Id = 100009,
			Value = -30,
		},
	},
	Tags = {
		560203,
		560204,
		560105,
		560206,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id525] =
{
	Id = 525,
	Name = "百得胶",
	Rarity = 4,
	Gallery = 950003,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_MUS_Event_10",
	Desc = "和身体接触后，唯有脱层皮方可摆脱的可怕胶水。\n携带后，风元素敌人捕捉成功率 +30%。",
	Skill = {
		{
			Id = 100402,
			Value = 30,
		},
	},
	Tags = {
		560203,
		560204,
		560105,
		560206,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id526] =
{
	Id = 526,
	Name = "灭火器",
	Rarity = 4,
	Gallery = 950003,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_MUS_Event_15",
	Desc = "可以快速隔离燃烧介质的喷射装置。\n携带后，火元素敌人捕捉成功率 +30%；水元素敌人出现概率 +30%。",
	Skill = {
		{
			Id = 100401,
			Value = 30,
		},
		{
			Id = 100005,
			Value = 30,
		},
	},
	Tags = {
		560203,
		560204,
		560105,
		560206,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id527] =
{
	Id = 527,
	Name = "信号枪",
	Rarity = 4,
	Gallery = 950003,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_MUS_Event_16",
	Desc = "“全员准备！我数到3，3！”\n携带后，快的敌人捕捉概率 +30%；紫色及以上品质敌人出现概率 -50%。",
	Skill = {
		{
			Id = 100413,
			Value = 30,
		},
		{
			Id = 100003,
			Value = -50,
		},
	},
	Tags = {
		560203,
		560204,
		560105,
		560206,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id528] =
{
	Id = 528,
	Name = "禁止宠物告示牌",
	Rarity = 4,
	Gallery = 950003,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_MUS_Event_18",
	Desc = "“这里禁止宠物进入，违者罚款50！”\n携带后，动物类敌人出现概率 -90%。",
	Skill = {
		{
			Id = 100011,
			Value = -90,
		},
	},
	Tags = {
		560203,
		560204,
		560105,
		560206,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id529] =
{
	Id = 529,
	Name = "支票收据",
	Rarity = 4,
	Gallery = 950003,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_MUS_Event_21",
	Desc = "捐款时对方那样说道：“赚了很多钱，所以想投资一些自己想做但没做的事。”\n携带后，探索金币数量 +5%；暗元素敌人出现概率 +30%。",
	Skill = {
		{
			Id = 100201,
			Value = 5,
		},
		{
			Id = 100009,
			Value = 30,
		},
	},
	Tags = {
		560203,
		560204,
		560105,
		560206,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id530] =
{
	Id = 530,
	Name = "签筒",
	Rarity = 4,
	Gallery = 950003,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_MUS_Event_23",
	Desc = "如果签文不合心意，悄咪咪重来一次就好。\n携带后，打不过的怪物出现概率 -20%；道具掉落率 +10%。",
	Skill = {
		{
			Id = 100015,
			Value = -20,
		},
		{
			Id = 100221,
			Value = 10,
		},
	},
	Tags = {
		560203,
		560204,
		560105,
		560206,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id531] =
{
	Id = 531,
	Name = "给呜呜的信",
	Rarity = 4,
	Gallery = 950004,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_SUS_Event_52",
	Desc = "呜呜，在外面玩得还开心吗？不要去危险的地方，还有，记得经常写信回来！\n携带后，紫色及以上品质敌人出现概率 -20%；探索等待时间 -10%。",
	Skill = {
		{
			Id = 100003,
			Value = -20,
		},
		{
			Id = 100001,
			Value = -10,
		},
	},
	Tags = {
		560203,
		560204,
		560205,
		560106,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id532] =
{
	Id = 532,
	Name = "空红酒瓶",
	Rarity = 4,
	Gallery = 950004,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_SUS_Event_62",
	Desc = "曾经存放着有着葡萄酒之王美誉的珍贵酒品的瓶子，是爸爸亲手烧制的艺术品。\n携带后，水元素敌人出现概率 +30%。",
	Skill = {
		{
			Id = 100005,
			Value = 30,
		},
	},
	Tags = {
		560203,
		560204,
		560205,
		560106,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id533] =
{
	Id = 533,
	Name = "闹钟",
	Rarity = 4,
	Gallery = 950004,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_SUS_Event_09",
	Desc = "在邮局引起恐慌的闹钟，滴答滴答的声响很像是定时引爆装置。\n携带后，探索等待时间 -5%。",
	Skill = {
		{
			Id = 100001,
			Value = -5,
		},
	},
	Tags = {
		560203,
		560204,
		560205,
		560106,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id534] =
{
	Id = 534,
	Name = "木塞",
	Rarity = 4,
	Gallery = 950004,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_SUS_Event_66",
	Desc = "木塞底部刻着爸爸给小爱的话——致可爱的女儿小爱。\n携带后，空瓶捕捉成功率 +30%；道具掉落率 +10%。",
	Skill = {
		{
			Id = 100482,
			Value = 30,
		},
		{
			Id = 100221,
			Value = 10,
		},
	},
	Tags = {
		560203,
		560204,
		560205,
		560106,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id535] =
{
	Id = 535,
	Name = "骷髅徽章",
	Rarity = 4,
	Gallery = 950004,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_SUS_Event_67",
	Desc = "教授的第一个骷髅徽章，很久以前就掉了，不过现在又找了回来。\n携带后，紫色及以上品质敌人出现概率 +20%。",
	Skill = {
		{
			Id = 100003,
			Value = 20,
		},
	},
	Tags = {
		560203,
		560204,
		560205,
		560106,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id536] =
{
	Id = 536,
	Name = "限量版漫画",
	Rarity = 4,
	Gallery = 950004,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_SUS_Event_70",
	Desc = "在悬疑星很出名的侦探漫画，不过因为作者对作品近乎病态的高要求，因此产能非常非常低，至今为止只出了3卷。\n携带后，暗元素敌人出现概率 +30%。",
	Skill = {
		{
			Id = 100009,
			Value = 30,
		},
	},
	Tags = {
		560203,
		560204,
		560205,
		560106,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id537] =
{
	Id = 537,
	Name = "呜呜的包裹",
	Rarity = 4,
	Gallery = 950004,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_SUS_Event_44",
	Desc = "超时空电话亭传送过来的礼物箱，上面写着：给呜呜，你最喜欢的玩具。另外，记得好好照顾漆漆。\n携带后，道具掉落率 +30%；探索等待时间 +10%。",
	Skill = {
		{
			Id = 100221,
			Value = 30,
		},
		{
			Id = 100001,
			Value = 10,
		},
	},
	Tags = {
		560203,
		560204,
		560205,
		560106,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id538] =
{
	Id = 538,
	Name = "特调饮料",
	Rarity = 4,
	Gallery = 950004,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_SUS_Event_73",
	Desc = "味道很淡，但是后劲很大的酒精饮料，喝下去一杯，就会立刻向附近的人吐露自己不为人知的过去。\n携带后，暗元素敌人捕捉成功率 +30%。",
	Skill = {
		{
			Id = 100404,
			Value = 30,
		},
	},
	Tags = {
		560203,
		560204,
		560205,
		560106,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id539] =
{
	Id = 539,
	Name = "道歉信",
	Rarity = 4,
	Gallery = 950005,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_SEA_Event_1",
	Desc = "在地上捡到的道歉信，上面言辞恳切地说着自己不会再吓到别人了。\n携带后，打不过的怪物出现概率 -20%。",
	Skill = {
		{
			Id = 100015,
			Value = -20,
		},
	},
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560107,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id540] =
{
	Id = 540,
	Name = "轮胎",
	Rarity = 4,
	Gallery = 950005,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_SEA_Event_2",
	Desc = "据说拥有它，可以得到“绝不翻车”地祝福，希望这不是一个flag。\n携带后，海草出现概率 -85%。",
	Skill = {
		{
			Id = 100020,
			Value = -85,
		},
	},
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560107,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id541] =
{
	Id = 541,
	Name = "发光的珍珠",
	Rarity = 4,
	Gallery = 950005,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_SEA_Event_3",
	Desc = "能散发出来刺眼的光芒，比手电筒好用多了！\n携带后，风元素敌人出现概率 -15%；水元素敌人出现概率 +25%。",
	Skill = {
		{
			Id = 100007,
			Value = -15,
		},
		{
			Id = 100005,
			Value = 25,
		},
	},
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560107,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id542] =
{
	Id = 542,
	Name = "GPS",
	Rarity = 4,
	Gallery = 950005,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_SEA_Event_4",
	Desc = "被遗落在舞台边，似乎是谁不小心遗失的。\n携带后，紫色及以上品质敌人出现概率 +20%；水元素敌人出现概率 -15%。",
	Skill = {
		{
			Id = 100003,
			Value = 20,
		},
		{
			Id = 100005,
			Value = -15,
		},
	},
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560107,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id543] =
{
	Id = 543,
	Name = "肉串",
	Rarity = 4,
	Gallery = 950005,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_SEA_Event_5",
	Desc = "刚刚烤好的肉串，还散发着浓浓的香味。\n携带后，凶猛海族出现概率 +20%；凶猛海族捕捉成功率 +20%。",
	Skill = {
		{
			Id = 100022,
			Value = 20,
		},
		{
			Id = 100421,
			Value = 20,
		},
	},
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560107,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id544] =
{
	Id = 544,
	Name = "交通标志牌",
	Rarity = 4,
	Gallery = 950005,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_SEA_Event_6",
	Desc = "志愿者塞过来的牌子，这是叫司机减速的意思吗？\n携带后，光元素敌人出现概率 -15%；暗元素敌人出现概率 -15%。",
	Skill = {
		{
			Id = 100008,
			Value = -15,
		},
		{
			Id = 100009,
			Value = -15,
		},
	},
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560107,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id545] =
{
	Id = 545,
	Name = "灯泡",
	Rarity = 4,
	Gallery = 950005,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_SEA_Event_7",
	Desc = "海底世界工作人员准备的灯泡，因为没有用上就被扔到了一边。\n携带后，光元素敌人捕捉成功率 +20%；暗元素敌人捕捉成功率 +15%。",
	Skill = {
		{
			Id = 100403,
			Value = 20,
		},
		{
			Id = 100404,
			Value = 15,
		},
	},
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560107,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id546] =
{
	Id = 546,
	Name = "磁带",
	Rarity = 4,
	Gallery = 950005,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_SEA_Event_8",
	Desc = "在莱斯莉和海蛇交易的现场捡到的磁带，放出后发现除了旋律外什么也没有。\n携带后，探索金币数量 +15%；水元素敌人出现概率 +15%。",
	Skill = {
		{
			Id = 100201,
			Value = 15,
		},
		{
			Id = 100005,
			Value = 15,
		},
	},
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560107,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id547] =
{
	Id = 547,
	Name = "碎布",
	Rarity = 4,
	Gallery = 950005,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_SEA_Event_9",
	Desc = "撕下来的碎布，但因为可以做猫咪的口水巾，被有心之人保存了下来。\n携带后，道具掉落率 +10%；探索金币数量 +10%。",
	Skill = {
		{
			Id = 100221,
			Value = 10,
		},
		{
			Id = 100201,
			Value = 10,
		},
	},
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560107,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id548] =
{
	Id = 548,
	Name = "发言稿",
	Rarity = 4,
	Gallery = 950005,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_SEA_Event_10",
	Desc = "偶像为在台上发言，提前写好的发言稿，具有让粉丝热泪盈眶的神奇力量。\n携带后，火元素敌人出现概率 -15%；光元素敌人出现概率 -15%。",
	Skill = {
		{
			Id = 100006,
			Value = -15,
		},
		{
			Id = 100008,
			Value = -15,
		},
	},
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560107,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id549] =
{
	Id = 549,
	Name = "限速规则",
	Rarity = 4,
	Gallery = 950005,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_SEA_Event_11",
	Desc = "为了防止更多居民超速奔跑，警察向每一个人递出了限速规则说明单。\n携带后，风元素敌人出现概率 -20%；快的敌人捕捉概率 +15%。",
	Skill = {
		{
			Id = 100007,
			Value = -20,
		},
		{
			Id = 100413,
			Value = 15,
		},
	},
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560107,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id550] =
{
	Id = 550,
	Name = "深海时报",
	Rarity = 4,
	Gallery = 950005,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_SEA_Event_12",
	Desc = "珊瑚报社送给大家的深海时报，据说已经送出去8000份了。\n携带后，温驯海族出现概率 +20%；温驯海族捕捉成功率 +20%。",
	Skill = {
		{
			Id = 100021,
			Value = 20,
		},
		{
			Id = 100420,
			Value = 20,
		},
	},
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560107,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id551] =
{
	Id = 551,
	Name = "秒表",
	Rarity = 4,
	Gallery = 950005,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_SEA_Event_13",
	Desc = "看着数字跳动的时候，不知不觉会感到兴奋和紧张。\n携带后，风元素敌人道具掉落率 +10%；风元素敌人捕捉成功率 +20%。",
	Skill = {
		{
			Id = 100225,
			Value = 10,
		},
		{
			Id = 100402,
			Value = 20,
		},
	},
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560107,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id601] =
{
	Id = 601,
	Name = "可续杯奶茶",
	Rarity = 4,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_Golbal_Event_1",
	Desc = "非常感谢一直陪伴着我们走到这里的你。这是制作组奉上的可无限续杯奶茶，希望你一直甜蜜快乐下去~\n携带后，打不过的怪物出现概率 -5%。",
	Skill = {
		{
			Id = 100015,
			Value = -5,
		},
	},
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
}
GoodsConfig[GoodsID.Id602] =
{
	Id = 602,
	Name = "一周年奖杯",
	Rarity = 4,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_Golbal_Event_2",
	Desc = "哇，已经翻过45个页了噢~这是时光博物馆专门为签到365天的冒险家准备的小奖杯噢~祝您一直甜蜜快乐下去~\n携带后，打不过的怪物出现概率 -5%。",
	Skill = {
		{
			Id = 100015,
			Value = -5,
		},
	},
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
}
GoodsConfig[GoodsID.Id611] =
{
	Id = 611,
	Name = "冒险家之星",
	Rarity = 4,
	Gallery = 950001,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_RPG_Event_0",
	Desc = "使用星球之核碎片制作的独特徽章。击败火焰巨人的证明，只有了不起的冒险家才能获得的冒险星珍贵特产。\n携带后，冒险星敌人捕捉成功率 +30%；冒险星敌人道具掉落率 +25%。",
	Skill = {
		{
			Id = 100415,
			Value = 30,
		},
		{
			Id = 100228,
			Value = 25,
		},
	},
	Tags = {
		560103,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id612] =
{
	Id = 612,
	Name = "美食家之星",
	Rarity = 4,
	Gallery = 950002,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_FAT_Event_0",
	Desc = "使用星球之核碎片制作的独特徽章。击败比撒的证明，只有了不起的美食家才能获得的美食星珍贵特产。\n携带后，美食星敌人捕捉成功率 +30%；美食星敌人道具掉落率 +25%。",
	Skill = {
		{
			Id = 100416,
			Value = 30,
		},
		{
			Id = 100229,
			Value = 25,
		},
	},
	Tags = {
		560203,
		560104,
		560205,
		560206,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id613] =
{
	Id = 613,
	Name = "收藏家之星",
	Rarity = 4,
	Gallery = 950003,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_MUS_Event_0",
	Desc = "使用星球之核碎片制作的独特徽章。击败快陶鸭的证明，只有了不起的收藏家才能获得的博物馆星珍贵特产。\n携带后，博物馆星敌人捕捉成功率 +30%；博物馆星敌人道具掉落率 +25%。",
	Skill = {
		{
			Id = 100417,
			Value = 30,
		},
		{
			Id = 100230,
			Value = 25,
		},
	},
	Tags = {
		560203,
		560204,
		560105,
		560206,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id614] =
{
	Id = 614,
	Name = "推理家之星",
	Rarity = 4,
	Gallery = 950004,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_SUS_Event_0",
	Desc = "使用星球之核碎片制作的独特徽章。击败瓶中脑的证明，只有了不起的推理家才能获得的悬疑星珍贵特产。\n携带后，悬疑星敌人捕捉成功率 +30%；悬疑星敌人道具掉落率 +25%。",
	Skill = {
		{
			Id = 100418,
			Value = 30,
		},
		{
			Id = 100231,
			Value = 25,
		},
	},
	Tags = {
		560203,
		560204,
		560205,
		560106,
		560207,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id615] =
{
	Id = 615,
	Name = "偶像之星",
	Rarity = 4,
	Gallery = 950005,
	OnlyOne = true,
	SubType = "EventItem",
	TypeIcon = "Type_EventItem",
	IconAtlas = "Goods",
	Icon = "EventItem_SEA_Event_0",
	Desc = "使用星球之核碎片制作的独特徽章。击败蓝海兔的证明，只有了不起的偶像才能获得的海洋星珍贵特产。\n携带后，海洋星敌人捕捉成功率 +30%；海洋星敌人道具掉落率 +25%。",
	Skill = {
		{
			Id = 100419,
			Value = 30,
		},
		{
			Id = 100232,
			Value = 25,
		},
	},
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560107,
		560208,
		560210,
		564308,
		560006,
		564302,
	},
	From = {
		{
			SourceType = SourceType.Event,
		},
	},
}
GoodsConfig[GoodsID.Id1001] =
{
	Id = 1001,
	Name = "树叶",
	Rarity = 1,
	Gallery = 950001,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "RPG_Material_004",
	Desc = "充满森林气息的素材，最基础的素材，可以用来做衣服，也只能遮住最基础的部位。",
	Tags = {
		560103,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130002,
				130003,
				130004,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id1002] =
{
	Id = 1002,
	Name = "木材",
	Rarity = 1,
	Gallery = 950001,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "RPG_Material_005",
	Desc = "拥有极强可塑性的素材，经验丰富的工匠能够将其加工成了不起的物品。",
	Tags = {
		560103,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130003,
				130004,
				130006,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id1003] =
{
	Id = 1003,
	Name = "骨头",
	Rarity = 1,
	Gallery = 950001,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "RPG_Material_008",
	Desc = "充满野性气息的素材，十分坚硬，胃口好的话可以用来炖汤喝，当然不一定是什么怪物的骨头就是了。",
	Tags = {
		560103,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130004,
				130005,
				130006,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id1004] =
{
	Id = 1004,
	Name = "矿石",
	Rarity = 1,
	Gallery = 950001,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "RPG_Material_006",
	Desc = "制造装备必不可少的素材，当然大部分情况下只是取用其中的矿，并不会用到石。",
	Tags = {
		560103,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130005,
				130008,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id1005] =
{
	Id = 1005,
	Name = "地图",
	Rarity = 1,
	Gallery = 950001,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "RPG_Material_019",
	Desc = "外出探险必备的素材，能够记录下冒险者的足迹，走过的地方会自动亮起来，属于不为人知的科技。",
	Tags = {
		560103,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130006,
				130007,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id1006] =
{
	Id = 1006,
	Name = "粘液",
	Rarity = 1,
	Gallery = 950001,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "RPG_Material_014",
	Desc = "摸上去热乎乎的素材，如果抓在手上就丢不掉了，只好抹在别人身上。",
	Tags = {
		560103,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130007,
				130008,
				130010,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id1007] =
{
	Id = 1007,
	Name = "钢刺",
	Rarity = 1,
	Gallery = 950001,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "RPG_Material_015",
	Desc = "质地坚硬的钢刺，来源于刺毛怪，能够吸收来自侧面和背后的伤害。",
	Tags = {
		560103,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130008,
				130009,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id1008] =
{
	Id = 1008,
	Name = "沙堆",
	Rarity = 1,
	Gallery = 950001,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "RPG_Material_007",
	Desc = "伴随熔岩产生的素材，有很好的耐热性，可以用来制造建材，也可以用来铺沙滩。",
	Tags = {
		560103,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130009,
				130010,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id1009] =
{
	Id = 1009,
	Name = "炭石",
	Rarity = 1,
	Gallery = 950001,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "RPG_Material_021",
	Desc = "在高温下才能形成的素材，拥有很高的硬度，非常适合用来制作工具。",
	Tags = {
		560103,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130010,
				130011,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id1010] =
{
	Id = 1010,
	Name = "火焰结晶",
	Rarity = 1,
	Gallery = 950001,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "RPG_Material_018",
	Desc = "充满炎热感的素材，核心中燃烧着的熊熊烈火让人看久了会因为疲劳而流下泪水，然后更热。",
	Tags = {
		560103,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130011,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id1051] =
{
	Id = 1051,
	Name = "头骨",
	Rarity = 2,
	Gallery = 950001,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "RPG_Material_012",
	Desc = "经过骨头碎片复原而成的素材，长时间在野外而风化，生前应该是很大只的怪物。",
	Recipe = 360201,
	Tags = {
		560103,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564305,
		560005,
	},
	From = {
		{
			SourceType  = SourceType.Summon,
			Value = {
				500002,
				500003,
			},
		},
	},
}
GoodsConfig[GoodsID.Id1052] =
{
	Id = 1052,
	Name = "攻略",
	Rarity = 2,
	Gallery = 950001,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "RPG_Material_001",
	Desc = "能够帮助人们摆脱困境的素材，记录了各种通关技巧的书籍，配有图片，但是总是会有错别字。",
	Recipe = 360202,
	Tags = {
		560103,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564305,
		560005,
	},
	From = {
		{
			SourceType  = SourceType.Summon,
			Value = {
				500002,
				500003,
			},
		},
	},
}
GoodsConfig[GoodsID.Id1053] =
{
	Id = 1053,
	Name = "沙漏",
	Rarity = 2,
	Gallery = 950001,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "RPG_Material_022",
	Desc = "充满着神秘气息的素材，似乎预示着即将发生什么，稳定的计时功能也被冒险者用来计算技能冷却时间。",
	Recipe = 360203,
	Tags = {
		560103,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564305,
		560005,
	},
	From = {
		{
			SourceType  = SourceType.Summon,
			Value = {
				500002,
				500003,
			},
		},
	},
}
GoodsConfig[GoodsID.Id1054] =
{
	Id = 1054,
	Name = "火把",
	Rarity = 2,
	Gallery = 950001,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "RPG_Material_003",
	Desc = "探索洞穴必备的素材，热乎乎的火焰能给人以安全感，然而实际上也经常会引来怪物。",
	Recipe = 360204,
	Tags = {
		560103,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564305,
		560005,
	},
	From = {
		{
			SourceType  = SourceType.Summon,
			Value = {
				500002,
				500003,
			},
		},
	},
}
GoodsConfig[GoodsID.Id1201] =
{
	Id = 1201,
	Name = "豆沙",
	Rarity = 1,
	Gallery = 950002,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "FAT_Material_002",
	Desc = "给人以温暖甜蜜感的素材，需要将红豆焖煮捣烂才能制成，并不是把红豆和沙子混到一起。",
	Tags = {
		560203,
		560104,
		560205,
		560206,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130052,
				130053,
				130054,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id1202] =
{
	Id = 1202,
	Name = "冰块",
	Rarity = 1,
	Gallery = 950002,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "FAT_Material_024",
	Desc = "能够快速降温的素材，为饮料带来冰爽的口感。",
	Tags = {
		560203,
		560104,
		560205,
		560206,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130053,
				130056,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id1203] =
{
	Id = 1203,
	Name = "牛奶",
	Rarity = 1,
	Gallery = 950002,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "FAT_Material_007",
	Desc = "健康的素材，富含丰富的营养，听说能够帮人长高，也可以复原头骨。",
	Tags = {
		560203,
		560104,
		560205,
		560206,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130054,
				130055,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id1204] =
{
	Id = 1204,
	Name = "高标蛋",
	Rarity = 1,
	Gallery = 950002,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "FAT_Material_019",
	Desc = "具有健康活力的素材，迎合不同食客的口味，可以做成半熟或全熟的，运气好的话还会有双黄。",
	Tags = {
		560203,
		560104,
		560205,
		560206,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130055,
				130056,
				130057,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id1205] =
{
	Id = 1205,
	Name = "鱼肉",
	Rarity = 1,
	Gallery = 950002,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "FAT_Material_016",
	Desc = "拥有海洋气息的素材，不同部位口感不同，含脂量也不同，需要使用不同的烹饪方法进行处理。",
	Tags = {
		560203,
		560104,
		560205,
		560206,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130056,
				130058,
				130059,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id1206] =
{
	Id = 1206,
	Name = "米饭",
	Rarity = 1,
	Gallery = 950002,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "FAT_Material_017",
	Desc = "能让人充满元气的素材，作为主食的同时也是蔬菜，简单朴素，但是能够让人精力焕发。",
	Tags = {
		560203,
		560104,
		560205,
		560206,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130057,
				130058,
				130059,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id1207] =
{
	Id = 1207,
	Name = "料酒",
	Rarity = 1,
	Gallery = 950002,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "FAT_Material_021",
	Desc = "凝聚了劳动智慧的素材，谷物发酵而成，能够很好地去除食物的腥味，使食物更加鲜美。",
	Tags = {
		560203,
		560104,
		560205,
		560206,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130058,
				130060,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id1208] =
{
	Id = 1208,
	Name = "海苔",
	Rarity = 1,
	Gallery = 950002,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "FAT_Material_025",
	Desc = "拥有海洋气息的素材，入口时微微的海水腥味能够让人一瞬间感到海风扑面而来，里面并没有玻璃。",
	Tags = {
		560203,
		560104,
		560205,
		560206,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130059,
				130060,
				130061,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id1209] =
{
	Id = 1209,
	Name = "五花肉",
	Rarity = 1,
	Gallery = 950002,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "FAT_Material_026",
	Desc = "肉食动物最爱的素材，精肉与肥肉完美的搭配，哪怕只是生烤，也会飘散出浓郁的香气。",
	Tags = {
		560203,
		560104,
		560205,
		560206,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130060,
				130061,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id1210] =
{
	Id = 1210,
	Name = "芝士",
	Rarity = 1,
	Gallery = 950002,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "FAT_Material_020",
	Desc = "拥有浓郁香味的素材，通过牛奶发酵制成，可以直接食用，或者夹在面包中作为调味使用。",
	Tags = {
		560203,
		560104,
		560205,
		560206,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130061,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id1251] =
{
	Id = 1251,
	Name = "红豆冰",
	Rarity = 2,
	Gallery = 950002,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "FAT_Material_027",
	Desc = "拥有冰爽口感又能让人感到甜蜜的高级素材，在炎炎夏日来上一份，立刻就能驱走暑气。",
	Recipe = 360251,
	Tags = {
		560203,
		560104,
		560205,
		560206,
		560207,
		560208,
		560210,
		564305,
		560005,
	},
	From = {
		{
			SourceType  = SourceType.Summon,
			Value = {
				500002,
				500003,
			},
		},
	},
}
GoodsConfig[GoodsID.Id1252] =
{
	Id = 1252,
	Name = "蛋糕",
	Rarity = 2,
	Gallery = 950002,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "FAT_Material_028",
	Desc = "能让人充满元气的高级素材，口感松软，搭配模具可以制作成各种形状，是节日上很受欢迎的食物。",
	Recipe = 360252,
	Tags = {
		560203,
		560104,
		560205,
		560206,
		560207,
		560208,
		560210,
		564305,
		560005,
	},
	From = {
		{
			SourceType  = SourceType.Summon,
			Value = {
				500002,
				500003,
			},
		},
	},
}
GoodsConfig[GoodsID.Id1253] =
{
	Id = 1253,
	Name = "米醋",
	Rarity = 2,
	Gallery = 950002,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "FAT_Material_013",
	Desc = "凝聚了劳动智慧的高级素材，谷类经过发酵才能制成，酸爽的味道能够很好地缓解食物油腻的口感。",
	Recipe = 360253,
	Tags = {
		560203,
		560104,
		560205,
		560206,
		560207,
		560208,
		560210,
		564305,
		560005,
	},
	From = {
		{
			SourceType  = SourceType.Summon,
			Value = {
				500002,
				500003,
			},
		},
	},
}
GoodsConfig[GoodsID.Id1254] =
{
	Id = 1254,
	Name = "海鲜酱",
	Rarity = 2,
	Gallery = 950002,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "FAT_Material_022",
	Desc = "拥有海洋气息的高级素材，选用各类海鲜研磨而成，独特的咸腥味能够使食物的口感层次更丰富。",
	Recipe = 360254,
	Tags = {
		560203,
		560104,
		560205,
		560206,
		560207,
		560208,
		560210,
		564305,
		560005,
	},
	From = {
		{
			SourceType  = SourceType.Summon,
			Value = {
				500002,
				500003,
			},
		},
	},
}
GoodsConfig[GoodsID.Id1401] =
{
	Id = 1401,
	Name = "入场券",
	Rarity = 1,
	Gallery = 950003,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "MUS_Material_005",
	Desc = "官方发布的凭证素材，印有场馆基本信息和识别码，下面的小字写着：擅自伪造将受到巨额罚款。",
	Tags = {
		560203,
		560204,
		560105,
		560206,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130102,
				130103,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id1402] =
{
	Id = 1402,
	Name = "考古刷",
	Rarity = 1,
	Gallery = 950003,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "MUS_Material_021",
	Desc = "考古学家必不可少的工具，能够有效清除文物上的落灰。灰尘扬起时，请不要大口呼吸。",
	Tags = {
		560203,
		560204,
		560105,
		560206,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130103,
				130104,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id1403] =
{
	Id = 1403,
	Name = "焚香",
	Rarity = 1,
	Gallery = 950003,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "MUS_Material_011",
	Desc = "供奉神明的祭祀素材，散发着让人镇静的香气，相传神明是依靠信徒礼拜时的焚香获得力量的。",
	Tags = {
		560203,
		560204,
		560105,
		560206,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130104,
				130106,
				130108,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id1404] =
{
	Id = 1404,
	Name = "碎瓷片",
	Rarity = 1,
	Gallery = 950003,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "MUS_Material_010",
	Desc = "破碎的文物素材，断口非常锋利，触摸时千万注意，小心划伤。",
	Tags = {
		560203,
		560204,
		560105,
		560206,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130105,
				130107,
				130109,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id1405] =
{
	Id = 1405,
	Name = "绿蛋壳",
	Rarity = 1,
	Gallery = 950003,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "MUS_Material_007",
	Desc = "古老的化石蛋，长着绿色斑点，因此科学家认为里面会孵化出雨林地区的小恐龙，当然也有可能是发霉了。",
	Tags = {
		560203,
		560204,
		560105,
		560206,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130106,
				130107,
				130111,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id1406] =
{
	Id = 1406,
	Name = "监控录像",
	Rarity = 1,
	Gallery = 950003,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "MUS_Material_015",
	Desc = "记录了过道情况的信息素材，最多记录七天，超时后将自动洗掉最早的记录。",
	Tags = {
		560203,
		560204,
		560105,
		560206,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130107,
				130108,
				130110,
				130112,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id1407] =
{
	Id = 1407,
	Name = "封条",
	Rarity = 1,
	Gallery = 950003,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "MUS_Material_022",
	Desc = "拥有神秘力量的祭祀素材，能够将容器内的力量封印起来，不过从容器外部谁都能轻易撕开。",
	Tags = {
		560203,
		560204,
		560105,
		560206,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130108,
				130109,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id1408] =
{
	Id = 1408,
	Name = "海洋化石",
	Rarity = 1,
	Gallery = 950003,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "MUS_Material_012",
	Desc = "古老的化石素材，在海底沉睡了上万年，清晰地记录了古生物的特征，非常具有研究价值。",
	Tags = {
		560203,
		560204,
		560105,
		560206,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130109,
				130110,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id1409] =
{
	Id = 1409,
	Name = "青面具",
	Rarity = 1,
	Gallery = 950003,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "MUS_Material_018",
	Desc = "神秘的祭祀素材，不知是以什么动物为原型制作的古老面具，相传戴上后可以避免病痛和灾祸。",
	Tags = {
		560203,
		560204,
		560105,
		560206,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130110,
				130111,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id1410] =
{
	Id = 1410,
	Name = "龙角",
	Rarity = 1,
	Gallery = 950003,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "MUS_Material_006",
	Desc = "古老的化石素材，根据生物习性分析，极可能是草食龙的防御武器。",
	Tags = {
		560203,
		560204,
		560105,
		560206,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130111,
				130112,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id1411] =
{
	Id = 1411,
	Name = "箭头",
	Rarity = 1,
	Gallery = 950003,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "MUS_Material_024",
	Desc = "官方发布的路点素材，指引游客前往指定地点，或者掉进指定的坑。",
	Tags = {
		560203,
		560204,
		560105,
		560206,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130112,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id1451] =
{
	Id = 1451,
	Name = "黄蛋壳",
	Rarity = 2,
	Gallery = 950003,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "MUS_Material_014",
	Desc = "古老的化石素材，长着黄色斑点，因此科学家认为里面会孵化出沙漠地区的小恐龙，当然也有可能是油漆。",
	Recipe = 360301,
	Tags = {
		560203,
		560204,
		560105,
		560206,
		560207,
		560208,
		560210,
		564305,
		560005,
	},
	From = {
		{
			SourceType  = SourceType.Summon,
			Value = {
				500003,
			},
		},
	},
}
GoodsConfig[GoodsID.Id1452] =
{
	Id = 1452,
	Name = "黄面具",
	Rarity = 2,
	Gallery = 950003,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "MUS_Material_019",
	Desc = "神秘的祭祀素材，不知是以什么动物为原型制作的古老面具，相传戴上后可以避免邪灵的侵袭，也会吸引邪灵。",
	Recipe = 360302,
	Tags = {
		560203,
		560204,
		560105,
		560206,
		560207,
		560208,
		560210,
		564305,
		560005,
	},
	From = {
		{
			SourceType  = SourceType.Summon,
			Value = {
				500003,
			},
		},
	},
}
GoodsConfig[GoodsID.Id1453] =
{
	Id = 1453,
	Name = "化石骨",
	Rarity = 2,
	Gallery = 950003,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "MUS_Material_016",
	Desc = "古老的化石素材，通过基因模拟合成技术制作的恐龙化石，如果数据够全面，就能拼出完整的恐龙。",
	Recipe = 360303,
	Tags = {
		560203,
		560204,
		560105,
		560206,
		560207,
		560208,
		560210,
		564305,
		560005,
	},
	From = {
		{
			SourceType  = SourceType.Summon,
			Value = {
				500003,
			},
		},
	},
}
GoodsConfig[GoodsID.Id1454] =
{
	Id = 1454,
	Name = "导览图",
	Rarity = 2,
	Gallery = 950003,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "MUS_Material_002",
	Desc = "官方发布的地图素材，记录了游客感兴趣的地点及前往路线，避开了官方感兴趣的陷阱。",
	Recipe = 360304,
	Tags = {
		560203,
		560204,
		560105,
		560206,
		560207,
		560208,
		560210,
		564305,
		560005,
	},
	From = {
		{
			SourceType  = SourceType.Summon,
			Value = {
				500003,
			},
		},
	},
}
GoodsConfig[GoodsID.Id1601] =
{
	Id = 1601,
	Name = "暗恋",
	Rarity = 1,
	Gallery = 950004,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "SUS_Material_025",
	Desc = "由人们的爱慕之情具象化而成的素材，忽然收到时，仿佛有一种心脏变成大功率抽水泵的感觉。",
	Tags = {
		560203,
		560204,
		560205,
		560106,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130152,
				130153,
				130154,
				130160,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id1602] =
{
	Id = 1602,
	Name = "新闻",
	Rarity = 1,
	Gallery = 950004,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "SUS_Material_006",
	Desc = "官方发布的信息素材，记录了最近有趣事件的报道，然而最近总是被明星八卦占满。",
	Tags = {
		560203,
		560204,
		560205,
		560106,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130153,
				130157,
				130161,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id1603] =
{
	Id = 1603,
	Name = "羽毛",
	Rarity = 1,
	Gallery = 950004,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "SUS_Material_028",
	Desc = "禽类留下的动物素材，洁白又轻盈。想必拔下来时，它的主人身体情况一定还不错。",
	Tags = {
		560203,
		560204,
		560205,
		560106,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130154,
				130158,
				130159,
				130162,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id1604] =
{
	Id = 1604,
	Name = "钥匙",
	Rarity = 1,
	Gallery = 950004,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "SUS_Material_010",
	Desc = "能够打开特定锁具的工具素材，如果弄丢了，情况会变得有些棘手，所以藏在固定地点也是不错的选择。",
	Tags = {
		560203,
		560204,
		560205,
		560106,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130155,
				130156,
				130157,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id1605] =
{
	Id = 1605,
	Name = "脚印",
	Rarity = 1,
	Gallery = 950004,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "SUS_Material_012",
	Desc = "记录了生物信息的痕迹素材，面对它，办案的警官们不禁思索起来，四根脚趾的凶犯是谁呢？",
	Tags = {
		560203,
		560204,
		560205,
		560106,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130156,
				130160,
				130162,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id1606] =
{
	Id = 1606,
	Name = "烟头",
	Rarity = 1,
	Gallery = 950004,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "SUS_Material_026",
	Desc = "能够缓解压力的玩具素材，当案件进入死角时，警官们就会抽烟舒缓紧绷的神经，有时也会失火引起另一个案件。",
	Tags = {
		560203,
		560204,
		560205,
		560106,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130157,
				130159,
				130161,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id1607] =
{
	Id = 1607,
	Name = "指纹",
	Rarity = 1,
	Gallery = 950004,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "SUS_Material_015",
	Desc = "能够快速锁定嫌疑人的痕迹素材，不过有时候会出现在不可思议的地方，比如脚印上。",
	Tags = {
		560203,
		560204,
		560205,
		560106,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130158,
				130159,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id1608] =
{
	Id = 1608,
	Name = "墨水",
	Rarity = 1,
	Gallery = 950004,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "SUS_Material_005",
	Desc = "自然提取然后合成的化学素材，是文明进步的一大助力，不过一旦弄到身上就很难洗掉，只好全都泼满。",
	Tags = {
		560203,
		560204,
		560205,
		560106,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130159,
				130161,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id1609] =
{
	Id = 1609,
	Name = "皮鞭",
	Rarity = 1,
	Gallery = 950004,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "SUS_Material_027",
	Desc = "用途不明的玩具素材。唔，简介就这样了。",
	Tags = {
		560203,
		560204,
		560205,
		560106,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130160,
				130163,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id1610] =
{
	Id = 1610,
	Name = "黄瓜马赛克",
	Rarity = 1,
	Gallery = 950004,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "SUS_Material_024",
	Desc = "模糊不清的信息素材，你说不清楚它到底该算是马赛克还是黄瓜。",
	Tags = {
		560203,
		560204,
		560205,
		560106,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130161,
				130163,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id1611] =
{
	Id = 1611,
	Name = "灵感",
	Rarity = 1,
	Gallery = 950004,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "SUS_Material_011",
	Desc = "由侦探们的灵感具象化而成的素材，有时也会被天才借走百分之一。",
	Tags = {
		560203,
		560204,
		560205,
		560106,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130162,
				130163,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id1612] =
{
	Id = 1612,
	Name = "营养液",
	Rarity = 1,
	Gallery = 950004,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "SUS_Material_022",
	Desc = "特殊液体构成的化学素材，能够提供维生营养物质的液体，能补肾、补肝、润肺、养胃通肠，可惜不能补脑。",
	Tags = {
		560203,
		560204,
		560205,
		560106,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130163,
			},
		},
		{
			SourceType  = SourceType.Summon,
		},
	},
}
GoodsConfig[GoodsID.Id1651] =
{
	Id = 1651,
	Name = "谣言",
	Rarity = 2,
	Gallery = 950004,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "SUS_Material_029",
	Desc = "集结了大量传闻的信息素材，读起来非常通顺流畅，语言充满逻辑，结构严谨，唯一的缺点是它是假的。",
	Recipe = 360351,
	Tags = {
		560203,
		560204,
		560205,
		560106,
		560207,
		560208,
		560210,
		564305,
		560005,
	},
	From = {
		{
			SourceType  = SourceType.Summon,
			Value = {
				500003,
			},
		},
	},
}
GoodsConfig[GoodsID.Id1652] =
{
	Id = 1652,
	Name = "肖像侧写",
	Rarity = 2,
	Gallery = 950004,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "SUS_Material_030",
	Desc = "根据环境证据制成的信息素材，从犯罪痕迹推断得到的案犯信息，方便通缉。",
	Recipe = 360352,
	Tags = {
		560203,
		560204,
		560205,
		560106,
		560207,
		560208,
		560210,
		564305,
		560005,
	},
	From = {
		{
			SourceType  = SourceType.Summon,
			Value = {
				500003,
			},
		},
	},
}
GoodsConfig[GoodsID.Id1653] =
{
	Id = 1653,
	Name = "欠条",
	Rarity = 2,
	Gallery = 950004,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "SUS_Material_031",
	Desc = "记录了财务来往的信息素材，因为是金额来往的关键证明，所以需要借款人按下手印，或者手指。",
	Recipe = 360353,
	Tags = {
		560203,
		560204,
		560205,
		560106,
		560207,
		560208,
		560210,
		564305,
		560005,
	},
	From = {
		{
			SourceType  = SourceType.Summon,
			Value = {
				500003,
			},
		},
	},
}
GoodsConfig[GoodsID.Id1654] =
{
	Id = 1654,
	Name = "18X",
	Rarity = 2,
	Gallery = 950004,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "SUS_Material_032",
	Desc = "记录了无法理解的画面和文字的信息素材，这其实是个路牌，限速十八迈，别想多了。",
	Recipe = 360354,
	Tags = {
		560203,
		560204,
		560205,
		560106,
		560207,
		560208,
		560210,
		564305,
		560005,
	},
	From = {
		{
			SourceType  = SourceType.Summon,
			Value = {
				500003,
			},
		},
	},
}
GoodsConfig[GoodsID.Id1801] =
{
	Id = 1801,
	Name = "海草",
	Rarity = 1,
	Gallery = 950005,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "SEA_Material_001",
	Desc = "海洋里随处可见的普通海草，不过常常被狂热的粉丝们当作应援丝带。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560107,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130201,
				130202,
				130203,
				130205,
				130206,
			},
		},
	},
}
GoodsConfig[GoodsID.Id1802] =
{
	Id = 1802,
	Name = "珊瑚",
	Rarity = 1,
	Gallery = 950005,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "SEA_Material_002",
	Desc = "珊瑚式样的特制防水腮红，脸上一抹，立刻看上去元气满满。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560107,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130202,
				130203,
				130204,
				130205,
			},
		},
	},
}
GoodsConfig[GoodsID.Id1803] =
{
	Id = 1803,
	Name = "黑珍珠",
	Rarity = 1,
	Gallery = 950005,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "SEA_Material_003",
	Desc = "美丽的黑珍珠，经过岁月的沉淀，才有了如今的颜色。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560107,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130203,
				130206,
			},
		},
	},
}
GoodsConfig[GoodsID.Id1804] =
{
	Id = 1804,
	Name = "怪物触手",
	Rarity = 1,
	Gallery = 950005,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "SEA_Material_011",
	Desc = "散发着浓烈腥味的海鲜品，猫科动物闻到后会陷入兴奋与疯狂的状态。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560107,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130204,
				130207,
			},
		},
	},
}
GoodsConfig[GoodsID.Id1805] =
{
	Id = 1805,
	Name = "应援毛巾",
	Rarity = 1,
	Gallery = 950005,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "SEA_Material_004",
	Desc = "追星必备道具，除了擦拭为台上偶像挥洒的泪水及汗水的同时，也是自己粉丝身份的证明。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560107,
		560208,
		560210,
		564305,
		564502,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130205,
				130208,
			},
		},
	},
}
GoodsConfig[GoodsID.Id1806] =
{
	Id = 1806,
	Name = "礁石",
	Rarity = 1,
	Gallery = 950005,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "SEA_Material_005",
	Desc = "常常被保安们揣在口袋里，看似普通，但作为武器有着强大的威力。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560107,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130206,
				130208,
				130211,
				130212,
			},
		},
	},
}
GoodsConfig[GoodsID.Id1807] =
{
	Id = 1807,
	Name = "鱼鳞",
	Rarity = 1,
	Gallery = 950005,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "SEA_Material_006",
	Desc = "即便在海底，也会闪闪发光，是服装设计者非常喜欢的素材。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560107,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130207,
				130209,
				130212,
			},
		},
	},
}
GoodsConfig[GoodsID.Id1808] =
{
	Id = 1808,
	Name = "防水相机",
	Rarity = 1,
	Gallery = 950005,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "SEA_Material_012",
	Desc = "摄影爱好者必备之物，即使深入10000米下的深海，也能够拍出光照自然且成像清晰的照片。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560107,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130208,
				130210,
				130211,
			},
		},
	},
}
GoodsConfig[GoodsID.Id1809] =
{
	Id = 1809,
	Name = "摇滚耳机",
	Rarity = 1,
	Gallery = 950005,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "SEA_Material_007",
	Desc = "能够完美还原死亡重金属音乐质感的时尚耳机，海蛇乐队最爱之物。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560107,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130209,
				130210,
			},
		},
	},
}
GoodsConfig[GoodsID.Id1810] =
{
	Id = 1810,
	Name = "队员服",
	Rarity = 1,
	Gallery = 950005,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "SEA_Material_013",
	Desc = "初入偶像行业时，每一只鱼人都会获得这样一件衣服。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560107,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130210,
				130213,
			},
		},
	},
}
GoodsConfig[GoodsID.Id1811] =
{
	Id = 1811,
	Name = "强力海绵",
	Rarity = 1,
	Gallery = 950005,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "SEA_Material_008",
	Desc = "既能吸水，又能作为洗白白的清洁工具。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560107,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130211,
			},
		},
	},
}
GoodsConfig[GoodsID.Id1812] =
{
	Id = 1812,
	Name = "应援棒",
	Rarity = 1,
	Gallery = 950005,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "SEA_Material_009",
	Desc = "“赠予未来之星，希望照亮你的偶像生涯！”虽然拿到时被如此告知，不过据说只是方便星探统计业绩的工具罢了。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560107,
		560208,
		560210,
		564305,
		564502,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130212,
				130213,
			},
		},
	},
}
GoodsConfig[GoodsID.Id1813] =
{
	Id = 1813,
	Name = "尖叫",
	Rarity = 1,
	Gallery = 950005,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "SEA_Material_010",
	Desc = "每当经纪公司的无良老板遭到殴打时，总会收获来自四面八方的尖叫，但其中包含的情绪各不相同。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560107,
		560208,
		560210,
		564305,
		564502,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130213,
				130214,
			},
		},
	},
}
GoodsConfig[GoodsID.Id1814] =
{
	Id = 1814,
	Name = "深海泡沫",
	Rarity = 1,
	Gallery = 950005,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "SEA_Material_014",
	Desc = "深海里的泡沫，虽然美丽，但下一秒就会破碎。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560107,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{SourceType = SourceType.Explore, Value = 
			{
				130214,
			},
		},
	},
}
GoodsConfig[GoodsID.Id1851] =
{
	Id = 1851,
	Name = "正式队服",
	Rarity = 2,
	Gallery = 950005,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "SEA_Material_015",
	Desc = "人气偶像的正式队服，穿着身上金光闪闪，仿佛自己也在发光。",
	Recipe = 360401,
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560107,
		560208,
		560210,
		564305,
		560005,
	},
}
GoodsConfig[GoodsID.Id1852] =
{
	Id = 1852,
	Name = "璀璨珍珠",
	Rarity = 2,
	Gallery = 950005,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "SEA_Material_017",
	Desc = "洁白无暇，甚至可以在珍珠上清晰地看到自己的倒影。",
	Recipe = 360402,
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560107,
		560208,
		560210,
		564305,
		560005,
	},
}
GoodsConfig[GoodsID.Id1853] =
{
	Id = 1853,
	Name = "典藏签名照",
	Rarity = 2,
	Gallery = 950005,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "SEA_Material_018",
	Desc = "偶像的签名照，价值不菲，被许多海底黄牛竞相争夺。",
	Recipe = 360403,
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560107,
		560208,
		560210,
		564305,
		560005,
	},
}
GoodsConfig[GoodsID.Id1854] =
{
	Id = 1854,
	Name = "架子鼓",
	Rarity = 2,
	Gallery = 950005,
	CustomSubmit = true,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "SEA_Material_016",
	Desc = "舞台必备的乐器，可以完美调动舞台上的气氛。",
	Recipe = 360404,
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560107,
		560208,
		560210,
		564305,
		564502,
		560005,
	},
}
GoodsConfig[GoodsID.Id7301] =
{
	Id = 7301,
	Name = "藏宝图-左",
	Rarity = 1,
	Gallery = 950001,
	StorgeSortId = 8000,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "Activity_Material_001",
	Desc = "从宝箱怪身上找到的左半张古代藏宝图，看起来非常神秘，不过似乎市面上有大量货源。",
	Tags = {
		560103,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{
			SourceType = SourceType.Arena,
		},
	},
}
GoodsConfig[GoodsID.Id7302] =
{
	Id = 7302,
	Name = "藏宝图-右",
	Rarity = 1,
	Gallery = 950001,
	StorgeSortId = 7999,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "Activity_Material_002",
	Desc = "从宝箱怪身上找到的右半张古代藏宝图，看起来非常神秘，不过似乎市面上有大量货源。",
	Tags = {
		560103,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{
			SourceType = SourceType.Arena,
		},
	},
}
GoodsConfig[GoodsID.Id7303] =
{
	Id = 7303,
	Name = "古老钥匙",
	Rarity = 1,
	StorgeSortId = 7998,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "Activity_Material_003",
	Desc = "可以用来打开黄金宝箱的钥匙。不过冒险者们都说，与其打开宝箱不如把钥匙直接拿去黑市卖赚钱多。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{
			SourceType = SourceType.Arena,
		},
	},
}
GoodsConfig[GoodsID.Id7304] =
{
	Id = 7304,
	Name = "小元宝",
	Rarity = 1,
	Gallery = 950101,
	StorgeSortId = 7997,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "Activity_Material_004",
	Desc = "外星人制作的造型可爱的手工品，据说曾经在旧世界是硬通货，信用社会逐步发展后，渐渐被纸币所代替。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560110,
		564305,
		560006,
	},
	From = {
		{
			SourceType = SourceType.Arena,
		},
	},
}
GoodsConfig[GoodsID.Id7305] =
{
	Id = 7305,
	Name = "压岁包",
	Rarity = 1,
	Gallery = 950101,
	StorgeSortId = 7996,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "Activity_Material_005",
	Desc = "过年时，亲朋好友间很流行交换的礼物，赠送对象表面是对家的小朋友，实际上则会因为各种原因最后落到对方妈妈的手中。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560110,
		564305,
		560006,
	},
	From = {
		{
			SourceType = SourceType.Arena,
		},
	},
}
GoodsConfig[GoodsID.Id7306] =
{
	Id = 7306,
	Name = "新春盲盒券",
	Rarity = 1,
	Gallery = 950101,
	StorgeSortId = 7995,
	OnlyOne = false,
	SubType = "Chip",
	IconAtlas = "Goods",
	Icon = "Token_ActivityTicket_001",
	Desc = "新春将至，流亡街上忽然流通起来的货币，听说获得一定数量后可以用来进行某种祈福仪式，然后就能得到五福的保佑。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560110,
		564305,
		560006,
	},
	From = {
		{
			SourceType = SourceType.Arena,
		},
	},
}
GoodsConfig[GoodsID.Id7307] =
{
	Id = 7307,
	Name = "秘制酱汁",
	Rarity = 1,
	Gallery = 950002,
	StorgeSortId = 7994,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "Activity_Material_006",
	Desc = "成分极为复杂的酱汁，使用大量未知物熬制而成，味道难以言喻。值得一提的是，里面经常可以捞出奇怪的汤底噢~",
	Tags = {
		560203,
		560104,
		560205,
		560206,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{
			SourceType = SourceType.Arena,
		},
	},
}
GoodsConfig[GoodsID.Id7308] =
{
	Id = 7308,
	Name = "料理秘籍",
	Rarity = 1,
	Gallery = 950002,
	StorgeSortId = 7993,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "Activity_Material_007",
	Desc = "流传在黑暗料理界的恐怖秘籍，据说只要掌握食谱中任意一道菜品，就相当于学会了一种生化武器的制作。",
	Tags = {
		560203,
		560104,
		560205,
		560206,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
	From = {
		{
			SourceType = SourceType.Arena,
		},
	},
}
GoodsConfig[GoodsID.Id7309] =
{
	Id = 7309,
	Name = "艾草",
	Rarity = 1,
	Gallery = 950101,
	StorgeSortId = 7992,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "Activity_Material_008",
	Desc = "用来包裹端午食物的草叶，对于呜呜和漆漆有奇妙的吸引力。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560110,
		564305,
		560006,
	},
	From = {
		{
			SourceType = SourceType.Arena,
		},
	},
}
GoodsConfig[GoodsID.Id7310] =
{
	Id = 7310,
	Name = "伸缩绳",
	Rarity = 1,
	Gallery = 950101,
	StorgeSortId = 7991,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "Activity_Material_009",
	Desc = "伸缩自如的绳子，虽然只是一根小小的绳子，但承载了许多功能。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560110,
		564305,
		560006,
	},
	From = {
		{
			SourceType = SourceType.Arena,
		},
	},
}
GoodsConfig[GoodsID.Id7311] =
{
	Id = 7311,
	Name = "端午盲盒券",
	Rarity = 1,
	Gallery = 950101,
	StorgeSortId = 7990,
	OnlyOne = false,
	SubType = "Chip",
	IconAtlas = "Goods",
	Icon = "Activity_Material_010",
	Desc = "端午时节，流亡街上忽然流通起来的货币，听说获得一定数量后，就可以招募一些划水爱好者。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560110,
		564305,
		560006,
	},
	From = {
		{
			SourceType = SourceType.Arena,
		},
	},
}
GoodsConfig[GoodsID.Id7312] =
{
	Id = 7312,
	Name = "白丝",
	Rarity = 1,
	Gallery = 950101,
	StorgeSortId = 7989,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "Activity_Material_011",
	Desc = "用落羽制成的丝线，柔软而坚韧，反射出透亮的光芒。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560110,
		564305,
		560006,
	},
	From = {
		{
			SourceType = SourceType.Arena,
		},
	},
}
GoodsConfig[GoodsID.Id7313] =
{
	Id = 7313,
	Name = "香壳",
	Rarity = 1,
	Gallery = 950101,
	StorgeSortId = 7988,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "Activity_Material_012",
	Desc = "散发着香味的果壳，一闻便让人觉得心旷神怡。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560110,
		564305,
		560006,
	},
	From = {
		{
			SourceType = SourceType.Arena,
		},
	},
}
GoodsConfig[GoodsID.Id7314] =
{
	Id = 7314,
	Name = "孔雀儿芯片",
	Rarity = 1,
	Gallery = 950101,
	StorgeSortId = 7987,
	OnlyOne = false,
	SubType = "Chip",
	IconAtlas = "Goods",
	Icon = "Activity_Material_013",
	Desc = "由孔雀先生发明的新一代智能芯片，据说可以用来兑换许多珍贵的物件。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560110,
		564305,
		560006,
	},
	From = {
		{
			SourceType = SourceType.Arena,
		},
	},
}
GoodsConfig[GoodsID.Id7315] =
{
	Id = 7315,
	Name = "金镶鱼",
	Rarity = 1,
	StorgeSortId = 7986,
	OnlyOne = false,
	SubType = "Chip",
	IconAtlas = "Goods",
	Icon = "EventItem_Golbal_CatchFishCup_1",
	Desc = "这是阁下在夏日庙会中获得的冠军纪念奖杯，实在是太厉害啦。\n奖杯底部刻着【流亡街捞鱼王】的字样。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
}
GoodsConfig[GoodsID.Id7316] =
{
	Id = 7316,
	Name = "银镶鱼",
	Rarity = 1,
	StorgeSortId = 7985,
	OnlyOne = false,
	SubType = "Chip",
	IconAtlas = "Goods",
	Icon = "EventItem_Golbal_CatchFishCup_2",
	Desc = "这是阁下在夏日庙会中获得的亚军纪念奖杯，散发着银色光芒。\n奖杯底部刻着【我能捞光这片海】的字样。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
}
GoodsConfig[GoodsID.Id7317] =
{
	Id = 7317,
	Name = "铜镶鱼",
	Rarity = 1,
	StorgeSortId = 7984,
	OnlyOne = false,
	SubType = "Chip",
	IconAtlas = "Goods",
	Icon = "EventItem_Golbal_CatchFishCup_3",
	Desc = "这是阁下在夏日庙会中获得的季军纪念奖杯，似乎有鱼肉的香味。\n奖杯底部刻着【我没怎么买能量】的字样。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560210,
		564305,
		560006,
	},
}
GoodsConfig[GoodsID.Id7318] =
{
	Id = 7318,
	Name = "渣渣灰",
	Rarity = 1,
	Gallery = 950101,
	StorgeSortId = 7983,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "Activity_Material_014",
	Desc = "温泉汤池底部时常出现的灰色小固体，据说有美颜的功效。每当有人将它抹在脸上，总会产生幻觉，认为自己是一位当红明星。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560110,
		564305,
		560006,
	},
	From = {
		{
			SourceType = SourceType.Arena,
		},
	},
}
GoodsConfig[GoodsID.Id7319] =
{
	Id = 7319,
	Name = "碎冰冰",
	Rarity = 1,
	Gallery = 950101,
	StorgeSortId = 7982,
	OnlyOne = false,
	SubType = "Object",
	IconAtlas = "Goods",
	Icon = "Activity_Material_015",
	Desc = "寒冷的碎冰冰，只要被它包裹住，温度就会迅速下降至冰点。",
	Tags = {
		560203,
		560204,
		560205,
		560206,
		560207,
		560208,
		560110,
		564305,
		560006,
	},
	From = {
		{
			SourceType = SourceType.Arena,
		},
	},
}

