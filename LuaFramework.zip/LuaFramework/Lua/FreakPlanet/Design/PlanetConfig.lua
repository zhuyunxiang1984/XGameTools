PlanetConfig ={};
PlanetID = 
{
	Id001 = 120001,
	Id002 = 120002,
	Id003 = 120003,
	Id004 = 120004,
	Id005 = 120005,
	Id006 = 120006,
}
PlanetConfig[PlanetID.Id001] =
{
	Id = 1,
	Name = "冒险星",
	PrefabName = "RPG",
	MapPrefabName = "RPG_Map",
	Icon = "RPG",
	AreaList={
		130001,
		130002,
		130003,
		130004,
		130005,
		130006,
		130007,
		130008,
		130009,
		130010,
		130011,
	},
}
PlanetConfig[PlanetID.Id002] =
{
	Id = 2,
	Name = "美食星",
	PrefabName = "FAT",
	MapPrefabName = "FAT_Map",
	Icon = "FAT",
	AreaList={
		130051,
		130052,
		130053,
		130054,
		130055,
		130056,
		130057,
		130058,
		130059,
		130060,
		130061,
	},
}
PlanetConfig[PlanetID.Id003] =
{
	Id = 3,
	Name = "博物馆星",
	PrefabName = "MUS",
	MapPrefabName = "MUS_Map",
	Icon = "MUS",
	AreaList={
		130101,
		130102,
		130103,
		130104,
		130105,
		130106,
		130107,
		130108,
		130109,
		130110,
		130111,
		130112,
	},
}
PlanetConfig[PlanetID.Id004] =
{
	Id = 4,
	Name = "悬疑星",
	PrefabName = "SUS",
	MapPrefabName = "SUS_Map",
	Icon = "SUS",
	AreaList={
		130151,
		130152,
		130153,
		130154,
		130155,
		130156,
		130157,
		130158,
		130159,
		130160,
		130161,
		130162,
		130163,
	},
}
PlanetConfig[PlanetID.Id005] =
{
	Id = 5,
	Name = "海洋星",
	PrefabName = "SEA",
	MapPrefabName = "SEA_Map",
	Icon = "SEA",
	AreaList={
		130201,
		130202,
		130203,
		130204,
		130205,
		130206,
		130207,
		130208,
		130209,
		130210,
		130211,
		130212,
		130213,
		130214,
	},
}
PlanetConfig[PlanetID.Id006] =
{
	Id = 6,
	Name = "沙漠星",
	PrefabName = "SUS",
	MapPrefabName = "SUS_Map",
	Icon = "SUS",
	AreaList={
		130251,
		130252,
		130253,
		130254,
		130255,
		130256,
		130257,
		130258,
		130259,
		130260,
		130261,
		130262,
		130263,
	},
}

