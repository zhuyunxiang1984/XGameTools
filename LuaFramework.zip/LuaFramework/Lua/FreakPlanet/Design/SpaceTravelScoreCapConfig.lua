SpaceTravelScoreCapConfig ={};
SpaceTravelScoreCapID = 
{
	Id001 = 750001,
	Id002 = 750002,
	Id003 = 750003,
	Id004 = 750004,
	Id005 = 750005,
	Id006 = 750006,
}
SpaceTravelScoreCapConfig[SpaceTravelScoreCapID.Id001] =
{
	Id = 1,
	Name = "近地轨道赛",
	Desc = "在地表160~2000千米高空内进行探索~",
	Icon = "ScoreCap_1",
	RegisterGold = 2500,
	PromotionScore = 3000,
	Exchange = {
		{
			Cost = 5000,
			ItemList = {
				{
					Value = 101,
					Num = 100,
				},
				{
					Value = 103,
					Num = 100,
				},
				{
					Value = 770001,
					Num = 5,
				},
			},
		},
		{
			Cost = 25000,
			ItemList = {
				{
					Value = 101,
					Num = 150,
				},
				{
					Value = 103,
					Num = 150,
				},
				{
					Value = 770001,
					Num = 5,
				},
			},
		},
		{
			Cost = 100000,
			ItemList = {
				{
					Value = 101,
					Num = 300,
				},
				{
					Value = 103,
					Num = 300,
				},
				{
					Value = 770001,
					Num = 10,
				},
			},
		},
	},
	LevelReward = {
		{
			Score = 15000,
			RewardList = {
				{
					Value = 2,
					Num = 200,
				},
				{
					Value = 1,
					Num = 10000,
				},
			},
		},
		{
			Score = 6000,
			RewardList = {
				{
					Value = 2,
					Num = 150,
				},
				{
					Value = 1,
					Num = 7500,
				},
			},
		},
		{
			Score = 2000,
			RewardList = {
				{
					Value = 2,
					Num = 100,
				},
				{
					Value = 1,
					Num = 5000,
				},
			},
		},
		{
			Score = 1,
			RewardList = {
				{
					Value = 2,
					Num = 50,
				},
				{
					Value = 1,
					Num = 5000,
				},
			},
		},
	},
	RankReward = {
		 {
			{
				Value = 2,
				Num = 300,
			},
		},
		 {
			{
				Value = 2,
				Num = 200,
			},
		},
		 {
			{
				Value = 2,
				Num = 100,
			},
		},
	},
}
SpaceTravelScoreCapConfig[SpaceTravelScoreCapID.Id002] =
{
	Id = 2,
	Name = "行星际航行赛",
	Desc = "在本星系内进行探索~",
	Icon = "ScoreCap_2",
	RegisterGold = 10000,
	PromotionScore = 6000,
	Exchange = {
		{
			Cost = 5000,
			ItemList = {
				{
					Value = 101,
					Num = 100,
				},
				{
					Value = 103,
					Num = 100,
				},
				{
					Value = 770001,
					Num = 5,
				},
			},
		},
		{
			Cost = 25000,
			ItemList = {
				{
					Value = 101,
					Num = 150,
				},
				{
					Value = 103,
					Num = 150,
				},
				{
					Value = 770001,
					Num = 5,
				},
			},
		},
		{
			Cost = 100000,
			ItemList = {
				{
					Value = 101,
					Num = 300,
				},
				{
					Value = 103,
					Num = 300,
				},
				{
					Value = 770001,
					Num = 10,
				},
			},
		},
	},
	LevelReward = {
		{
			Score = 15000,
			RewardList = {
				{
					Value = 2,
					Num = 200,
				},
				{
					Value = 1,
					Num = 10000,
				},
			},
		},
		{
			Score = 6000,
			RewardList = {
				{
					Value = 2,
					Num = 150,
				},
				{
					Value = 1,
					Num = 7500,
				},
			},
		},
		{
			Score = 2000,
			RewardList = {
				{
					Value = 2,
					Num = 100,
				},
				{
					Value = 1,
					Num = 5000,
				},
			},
		},
		{
			Score = 1,
			RewardList = {
				{
					Value = 2,
					Num = 50,
				},
				{
					Value = 1,
					Num = 5000,
				},
			},
		},
	},
	RankReward = {
		 {
			{
				Value = 2,
				Num = 300,
			},
		},
		 {
			{
				Value = 2,
				Num = 200,
			},
		},
		 {
			{
				Value = 2,
				Num = 100,
			},
		},
	},
}
SpaceTravelScoreCapConfig[SpaceTravelScoreCapID.Id003] =
{
	Id = 3,
	Name = "恒星际航行赛",
	Desc = "向系外宇宙前进，进行探索~",
	Icon = "ScoreCap_3",
	RegisterGold = 40000,
	PromotionScore = 9000,
	Exchange = {
		{
			Cost = 5000,
			ItemList = {
				{
					Value = 101,
					Num = 100,
				},
				{
					Value = 103,
					Num = 100,
				},
				{
					Value = 770001,
					Num = 5,
				},
			},
		},
		{
			Cost = 25000,
			ItemList = {
				{
					Value = 101,
					Num = 150,
				},
				{
					Value = 103,
					Num = 150,
				},
				{
					Value = 770001,
					Num = 5,
				},
			},
		},
		{
			Cost = 100000,
			ItemList = {
				{
					Value = 101,
					Num = 300,
				},
				{
					Value = 103,
					Num = 300,
				},
				{
					Value = 770001,
					Num = 10,
				},
			},
		},
	},
	LevelReward = {
		{
			Score = 15000,
			RewardList = {
				{
					Value = 2,
					Num = 200,
				},
				{
					Value = 1,
					Num = 10000,
				},
			},
		},
		{
			Score = 6000,
			RewardList = {
				{
					Value = 2,
					Num = 150,
				},
				{
					Value = 1,
					Num = 7500,
				},
			},
		},
		{
			Score = 2000,
			RewardList = {
				{
					Value = 2,
					Num = 100,
				},
				{
					Value = 1,
					Num = 5000,
				},
			},
		},
		{
			Score = 1,
			RewardList = {
				{
					Value = 2,
					Num = 50,
				},
				{
					Value = 1,
					Num = 5000,
				},
			},
		},
	},
	RankReward = {
		 {
			{
				Value = 2,
				Num = 300,
			},
		},
		 {
			{
				Value = 2,
				Num = 200,
			},
		},
		 {
			{
				Value = 2,
				Num = 100,
			},
		},
	},
}
SpaceTravelScoreCapConfig[SpaceTravelScoreCapID.Id004] =
{
	Id = 4,
	Name = "曲率航行赛",
	Desc = "使用反物质引擎压缩空间后前往更远的星海吧~",
	Icon = "ScoreCap_4",
	RegisterGold = 150000,
	PromotionScore = 12000,
	Exchange = {
		{
			Cost = 5000,
			ItemList = {
				{
					Value = 101,
					Num = 100,
				},
				{
					Value = 103,
					Num = 100,
				},
				{
					Value = 770001,
					Num = 5,
				},
			},
		},
		{
			Cost = 25000,
			ItemList = {
				{
					Value = 101,
					Num = 150,
				},
				{
					Value = 103,
					Num = 150,
				},
				{
					Value = 770001,
					Num = 5,
				},
			},
		},
		{
			Cost = 100000,
			ItemList = {
				{
					Value = 101,
					Num = 300,
				},
				{
					Value = 103,
					Num = 300,
				},
				{
					Value = 770001,
					Num = 10,
				},
			},
		},
	},
	LevelReward = {
		{
			Score = 15000,
			RewardList = {
				{
					Value = 2,
					Num = 200,
				},
				{
					Value = 1,
					Num = 10000,
				},
			},
		},
		{
			Score = 6000,
			RewardList = {
				{
					Value = 2,
					Num = 150,
				},
				{
					Value = 1,
					Num = 7500,
				},
			},
		},
		{
			Score = 2000,
			RewardList = {
				{
					Value = 2,
					Num = 100,
				},
				{
					Value = 1,
					Num = 5000,
				},
			},
		},
		{
			Score = 1,
			RewardList = {
				{
					Value = 2,
					Num = 50,
				},
				{
					Value = 1,
					Num = 5000,
				},
			},
		},
	},
	RankReward = {
		 {
			{
				Value = 2,
				Num = 300,
			},
		},
		 {
			{
				Value = 2,
				Num = 200,
			},
		},
		 {
			{
				Value = 2,
				Num = 100,
			},
		},
	},
}
SpaceTravelScoreCapConfig[SpaceTravelScoreCapID.Id005] =
{
	Id = 5,
	Name = "空间跳跃赛",
	Desc = "来一场自己也无法预料将去往何方的旅行吧~",
	Icon = "ScoreCap_5",
	RegisterGold = 300000,
	PromotionScore = 15000,
	Exchange = {
		{
			Cost = 5000,
			ItemList = {
				{
					Value = 101,
					Num = 100,
				},
				{
					Value = 103,
					Num = 100,
				},
				{
					Value = 770001,
					Num = 5,
				},
			},
		},
		{
			Cost = 25000,
			ItemList = {
				{
					Value = 101,
					Num = 150,
				},
				{
					Value = 103,
					Num = 150,
				},
				{
					Value = 770001,
					Num = 5,
				},
			},
		},
		{
			Cost = 100000,
			ItemList = {
				{
					Value = 101,
					Num = 300,
				},
				{
					Value = 103,
					Num = 300,
				},
				{
					Value = 770001,
					Num = 10,
				},
			},
		},
	},
	LevelReward = {
		{
			Score = 15000,
			RewardList = {
				{
					Value = 2,
					Num = 200,
				},
				{
					Value = 1,
					Num = 10000,
				},
			},
		},
		{
			Score = 6000,
			RewardList = {
				{
					Value = 2,
					Num = 150,
				},
				{
					Value = 1,
					Num = 7500,
				},
			},
		},
		{
			Score = 2000,
			RewardList = {
				{
					Value = 2,
					Num = 100,
				},
				{
					Value = 1,
					Num = 5000,
				},
			},
		},
		{
			Score = 1,
			RewardList = {
				{
					Value = 2,
					Num = 50,
				},
				{
					Value = 1,
					Num = 5000,
				},
			},
		},
	},
	RankReward = {
		 {
			{
				Value = 2,
				Num = 300,
			},
		},
		 {
			{
				Value = 2,
				Num = 200,
			},
		},
		 {
			{
				Value = 2,
				Num = 100,
			},
		},
	},
}
SpaceTravelScoreCapConfig[SpaceTravelScoreCapID.Id006] =
{
	Id = 6,
	Name = "星辰大海赛",
	Desc = "前方是星辰与大海，让我们勇往直前吧！",
	Icon = "ScoreCap_6",
	RegisterGold = 500000,
	PromotionScore = 18000,
	Exchange = {
		{
			Cost = 5000,
			ItemList = {
				{
					Value = 101,
					Num = 100,
				},
				{
					Value = 103,
					Num = 100,
				},
				{
					Value = 770001,
					Num = 5,
				},
			},
		},
		{
			Cost = 25000,
			ItemList = {
				{
					Value = 101,
					Num = 150,
				},
				{
					Value = 103,
					Num = 150,
				},
				{
					Value = 770001,
					Num = 5,
				},
			},
		},
		{
			Cost = 100000,
			ItemList = {
				{
					Value = 101,
					Num = 300,
				},
				{
					Value = 103,
					Num = 300,
				},
				{
					Value = 770001,
					Num = 10,
				},
			},
		},
	},
	LevelReward = {
		{
			Score = 15000,
			RewardList = {
				{
					Value = 2,
					Num = 200,
				},
				{
					Value = 1,
					Num = 10000,
				},
			},
		},
		{
			Score = 6000,
			RewardList = {
				{
					Value = 2,
					Num = 150,
				},
				{
					Value = 1,
					Num = 7500,
				},
			},
		},
		{
			Score = 2000,
			RewardList = {
				{
					Value = 2,
					Num = 100,
				},
				{
					Value = 1,
					Num = 5000,
				},
			},
		},
		{
			Score = 1,
			RewardList = {
				{
					Value = 2,
					Num = 50,
				},
				{
					Value = 1,
					Num = 5000,
				},
			},
		},
	},
	RankReward = {
		 {
			{
				Value = 2,
				Num = 300,
			},
		},
		 {
			{
				Value = 2,
				Num = 200,
			},
		},
		 {
			{
				Value = 2,
				Num = 100,
			},
		},
	},
}
