
EquipmentConfig[EquipmentID.Id241] =
{
	Character = 220305,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920269,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200008,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920269,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920269,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920269,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920269,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920269,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920269,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200008,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920269,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920269,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920269,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id242] =
{
	Character = 220305,
	Rarity = 3,
	NeedChallenge = 145097,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920270,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
			},
		},
		{
			Level = 2,
			Info = 920270,
			Ability = {
				{
					Value = 200002,
					Num = 140,
				},
			},
		},
		{
			Level = 3,
			Info = 920270,
			Ability = {
				{
					Value = 200002,
					Num = 196,
				},
			},
		},
		{
			Level = 4,
			Info = 920270,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
		},
		{
			Level = 5,
			Info = 920270,
			Ability = {
				{
					Value = 200002,
					Num = 308,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920270,
			Ability = {
				{
					Value = 200002,
					Num = 364,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920270,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920270,
			Ability = {
				{
					Value = 200002,
					Num = 476,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101733,
					Value = 90,
				},
			},
		},
		{
			Level = 9,
			Info = 920270,
			Ability = {
				{
					Value = 200002,
					Num = 532,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101733,
					Value = 90,
				},
			},
		},
		{
			Level = 10,
			Info = 920270,
			Ability = {
				{
					Value = 200002,
					Num = 588,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101733,
					Value = 90,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id243] =
{
	Character = 220306,
	Rarity = 2,
	UpgradeId = 930005,
	LevelList = {
		{
			Level = 1,
			Info = 920273,
			Ability = {
				{
					Value = 200002,
					Num = 33,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920273,
			Ability = {
				{
					Value = 200002,
					Num = 66,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920273,
			Ability = {
				{
					Value = 200002,
					Num = 99,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920273,
			Ability = {
				{
					Value = 200002,
					Num = 132,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920273,
			Ability = {
				{
					Value = 200002,
					Num = 165,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920273,
			Ability = {
				{
					Value = 200002,
					Num = 198,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920273,
			Ability = {
				{
					Value = 200002,
					Num = 231,
				},
				{
					Value = 200006,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920273,
			Ability = {
				{
					Value = 200002,
					Num = 264,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 7,
				},
			},
		},
		{
			Level = 9,
			Info = 920273,
			Ability = {
				{
					Value = 200002,
					Num = 297,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 7,
				},
			},
		},
		{
			Level = 10,
			Info = 920273,
			Ability = {
				{
					Value = 200002,
					Num = 330,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 7,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id244] =
{
	Character = 220306,
	Rarity = 2,
	NeedChallenge = 145098,
	UpgradeId = 930026,
	LevelList = {
		{
			Level = 1,
			Info = 920274,
			Ability = {
				{
					Value = 200001,
					Num = 42,
				},
				{
					Value = 200007,
					Num = 3,
				},
			},
		},
		{
			Level = 2,
			Info = 920274,
			Ability = {
				{
					Value = 200001,
					Num = 84,
				},
				{
					Value = 200007,
					Num = 6,
				},
			},
		},
		{
			Level = 3,
			Info = 920274,
			Ability = {
				{
					Value = 200001,
					Num = 126,
				},
				{
					Value = 200007,
					Num = 9,
				},
			},
		},
		{
			Level = 4,
			Info = 920274,
			Ability = {
				{
					Value = 200001,
					Num = 168,
				},
				{
					Value = 200007,
					Num = 12,
				},
			},
		},
		{
			Level = 5,
			Info = 920274,
			Ability = {
				{
					Value = 200001,
					Num = 210,
				},
				{
					Value = 200007,
					Num = 15,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -15,
				},
			},
		},
		{
			Level = 6,
			Info = 920274,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -15,
				},
			},
		},
		{
			Level = 7,
			Info = 920274,
			Ability = {
				{
					Value = 200001,
					Num = 294,
				},
				{
					Value = 200007,
					Num = 21,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -15,
				},
			},
		},
		{
			Level = 8,
			Info = 920274,
			Ability = {
				{
					Value = 200001,
					Num = 336,
				},
				{
					Value = 200007,
					Num = 24,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -15,
				},
			},
		},
		{
			Level = 9,
			Info = 920274,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200007,
					Num = 27,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -15,
				},
			},
		},
		{
			Level = 10,
			Info = 920274,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
				{
					Value = 200007,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -15,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id245] =
{
	Character = 220307,
	Rarity = 2,
	UpgradeId = 930005,
	LevelList = {
		{
			Level = 1,
			Info = 920275,
			Ability = {
				{
					Value = 200002,
					Num = 33,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920275,
			Ability = {
				{
					Value = 200002,
					Num = 66,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920275,
			Ability = {
				{
					Value = 200002,
					Num = 99,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920275,
			Ability = {
				{
					Value = 200002,
					Num = 132,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920275,
			Ability = {
				{
					Value = 200002,
					Num = 165,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920275,
			Ability = {
				{
					Value = 200002,
					Num = 198,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920275,
			Ability = {
				{
					Value = 200002,
					Num = 231,
				},
				{
					Value = 200005,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920275,
			Ability = {
				{
					Value = 200002,
					Num = 264,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 7,
				},
			},
		},
		{
			Level = 9,
			Info = 920275,
			Ability = {
				{
					Value = 200002,
					Num = 297,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 7,
				},
			},
		},
		{
			Level = 10,
			Info = 920275,
			Ability = {
				{
					Value = 200002,
					Num = 330,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 7,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id246] =
{
	Character = 220307,
	Rarity = 2,
	NeedChallenge = 145099,
	UpgradeId = 930026,
	LevelList = {
		{
			Level = 1,
			Info = 920276,
			Ability = {
				{
					Value = 200001,
					Num = 42,
				},
				{
					Value = 200006,
					Num = 3,
				},
			},
		},
		{
			Level = 2,
			Info = 920276,
			Ability = {
				{
					Value = 200001,
					Num = 84,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 3,
			Info = 920276,
			Ability = {
				{
					Value = 200001,
					Num = 126,
				},
				{
					Value = 200006,
					Num = 9,
				},
			},
		},
		{
			Level = 4,
			Info = 920276,
			Ability = {
				{
					Value = 200001,
					Num = 168,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 5,
			Info = 920276,
			Ability = {
				{
					Value = 200001,
					Num = 210,
				},
				{
					Value = 200006,
					Num = 15,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920276,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920276,
			Ability = {
				{
					Value = 200001,
					Num = 294,
				},
				{
					Value = 200006,
					Num = 21,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920276,
			Ability = {
				{
					Value = 200001,
					Num = 336,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920276,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200006,
					Num = 27,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920276,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id247] =
{
	Character = 220308,
	Rarity = 2,
	UpgradeId = 930005,
	LevelList = {
		{
			Level = 1,
			Info = 920277,
			Ability = {
				{
					Value = 200002,
					Num = 33,
				},
				{
					Value = 200008,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920277,
			Ability = {
				{
					Value = 200002,
					Num = 66,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920277,
			Ability = {
				{
					Value = 200002,
					Num = 99,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920277,
			Ability = {
				{
					Value = 200002,
					Num = 132,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920277,
			Ability = {
				{
					Value = 200002,
					Num = 165,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920277,
			Ability = {
				{
					Value = 200002,
					Num = 198,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920277,
			Ability = {
				{
					Value = 200002,
					Num = 231,
				},
				{
					Value = 200008,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920277,
			Ability = {
				{
					Value = 200002,
					Num = 264,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 7,
				},
			},
		},
		{
			Level = 9,
			Info = 920277,
			Ability = {
				{
					Value = 200002,
					Num = 297,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 7,
				},
			},
		},
		{
			Level = 10,
			Info = 920277,
			Ability = {
				{
					Value = 200002,
					Num = 330,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 7,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id248] =
{
	Character = 220308,
	Rarity = 2,
	NeedChallenge = 145100,
	UpgradeId = 930026,
	LevelList = {
		{
			Level = 1,
			Info = 920278,
			Ability = {
				{
					Value = 200001,
					Num = 42,
				},
				{
					Value = 200006,
					Num = 3,
				},
			},
		},
		{
			Level = 2,
			Info = 920278,
			Ability = {
				{
					Value = 200001,
					Num = 84,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 3,
			Info = 920278,
			Ability = {
				{
					Value = 200001,
					Num = 126,
				},
				{
					Value = 200006,
					Num = 9,
				},
			},
		},
		{
			Level = 4,
			Info = 920278,
			Ability = {
				{
					Value = 200001,
					Num = 168,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 5,
			Info = 920278,
			Ability = {
				{
					Value = 200001,
					Num = 210,
				},
				{
					Value = 200006,
					Num = 15,
				},
			},
			SkillList = {
				{
					Id = 100221,
					Value = 15,
				},
			},
		},
		{
			Level = 6,
			Info = 920278,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
			SkillList = {
				{
					Id = 100221,
					Value = 15,
				},
			},
		},
		{
			Level = 7,
			Info = 920278,
			Ability = {
				{
					Value = 200001,
					Num = 294,
				},
				{
					Value = 200006,
					Num = 21,
				},
			},
			SkillList = {
				{
					Id = 100221,
					Value = 15,
				},
			},
		},
		{
			Level = 8,
			Info = 920278,
			Ability = {
				{
					Value = 200001,
					Num = 336,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
			SkillList = {
				{
					Id = 100221,
					Value = 15,
				},
			},
		},
		{
			Level = 9,
			Info = 920278,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200006,
					Num = 27,
				},
			},
			SkillList = {
				{
					Id = 100221,
					Value = 15,
				},
			},
		},
		{
			Level = 10,
			Info = 920278,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100221,
					Value = 15,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id249] =
{
	Character = 220309,
	Rarity = 2,
	UpgradeId = 930025,
	LevelList = {
		{
			Level = 1,
			Info = 920279,
			Ability = {
				{
					Value = 200001,
					Num = 42,
				},
				{
					Value = 200008,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920279,
			Ability = {
				{
					Value = 200001,
					Num = 84,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920279,
			Ability = {
				{
					Value = 200001,
					Num = 126,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920279,
			Ability = {
				{
					Value = 200001,
					Num = 168,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920279,
			Ability = {
				{
					Value = 200001,
					Num = 210,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920279,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920279,
			Ability = {
				{
					Value = 200001,
					Num = 294,
				},
				{
					Value = 200008,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920279,
			Ability = {
				{
					Value = 200001,
					Num = 336,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 12,
				},
			},
		},
		{
			Level = 9,
			Info = 920279,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 12,
				},
			},
		},
		{
			Level = 10,
			Info = 920279,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 12,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id250] =
{
	Character = 220309,
	Rarity = 2,
	NeedChallenge = 145101,
	UpgradeId = 930006,
	LevelList = {
		{
			Level = 1,
			Info = 920280,
			Ability = {
				{
					Value = 200002,
					Num = 33,
				},
				{
					Value = 200005,
					Num = 3,
				},
			},
		},
		{
			Level = 2,
			Info = 920280,
			Ability = {
				{
					Value = 200002,
					Num = 66,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 3,
			Info = 920280,
			Ability = {
				{
					Value = 200002,
					Num = 99,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 4,
			Info = 920280,
			Ability = {
				{
					Value = 200002,
					Num = 132,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 5,
			Info = 920280,
			Ability = {
				{
					Value = 200002,
					Num = 165,
				},
				{
					Value = 200005,
					Num = 15,
				},
			},
			SkillList = {
				{
					Id = 100746,
					Value = 9,
				},
			},
		},
		{
			Level = 6,
			Info = 920280,
			Ability = {
				{
					Value = 200002,
					Num = 198,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
			SkillList = {
				{
					Id = 100746,
					Value = 9,
				},
			},
		},
		{
			Level = 7,
			Info = 920280,
			Ability = {
				{
					Value = 200002,
					Num = 231,
				},
				{
					Value = 200005,
					Num = 21,
				},
			},
			SkillList = {
				{
					Id = 100746,
					Value = 9,
				},
			},
		},
		{
			Level = 8,
			Info = 920280,
			Ability = {
				{
					Value = 200002,
					Num = 264,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
			SkillList = {
				{
					Id = 100746,
					Value = 9,
				},
			},
		},
		{
			Level = 9,
			Info = 920280,
			Ability = {
				{
					Value = 200002,
					Num = 297,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
			SkillList = {
				{
					Id = 100746,
					Value = 9,
				},
			},
		},
		{
			Level = 10,
			Info = 920280,
			Ability = {
				{
					Value = 200002,
					Num = 330,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100746,
					Value = 9,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id251] =
{
	Character = 220310,
	Rarity = 2,
	UpgradeId = 930025,
	LevelList = {
		{
			Level = 1,
			Info = 920281,
			Ability = {
				{
					Value = 200001,
					Num = 42,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920281,
			Ability = {
				{
					Value = 200001,
					Num = 84,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920281,
			Ability = {
				{
					Value = 200001,
					Num = 126,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920281,
			Ability = {
				{
					Value = 200001,
					Num = 168,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920281,
			Ability = {
				{
					Value = 200001,
					Num = 210,
				},
				{
					Value = 200008,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920281,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920281,
			Ability = {
				{
					Value = 200001,
					Num = 294,
				},
				{
					Value = 200008,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920281,
			Ability = {
				{
					Value = 200001,
					Num = 336,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920281,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200008,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920281,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
				{
					Value = 200008,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id252] =
{
	Character = 220310,
	Rarity = 2,
	NeedChallenge = 145102,
	UpgradeId = 930026,
	LevelList = {
		{
			Level = 1,
			Info = 920282,
			Ability = {
				{
					Value = 200001,
					Num = 42,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920282,
			Ability = {
				{
					Value = 200001,
					Num = 84,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920282,
			Ability = {
				{
					Value = 200001,
					Num = 126,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920282,
			Ability = {
				{
					Value = 200001,
					Num = 168,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920282,
			Ability = {
				{
					Value = 200001,
					Num = 210,
				},
				{
					Value = 200008,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920282,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920282,
			Ability = {
				{
					Value = 200001,
					Num = 294,
				},
				{
					Value = 200008,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920282,
			Ability = {
				{
					Value = 200001,
					Num = 336,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100666,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920282,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200008,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100666,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920282,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
				{
					Value = 200008,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100666,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id253] =
{
	Character = 220311,
	Rarity = 2,
	UpgradeId = 930025,
	LevelList = {
		{
			Level = 1,
			Info = 920283,
			Ability = {
				{
					Value = 200001,
					Num = 45,
				},
				{
					Value = 200007,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920283,
			Ability = {
				{
					Value = 200001,
					Num = 90,
				},
				{
					Value = 200007,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920283,
			Ability = {
				{
					Value = 200001,
					Num = 135,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920283,
			Ability = {
				{
					Value = 200001,
					Num = 180,
				},
				{
					Value = 200007,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920283,
			Ability = {
				{
					Value = 200001,
					Num = 225,
				},
				{
					Value = 200007,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920283,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920283,
			Ability = {
				{
					Value = 200001,
					Num = 315,
				},
				{
					Value = 200007,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920283,
			Ability = {
				{
					Value = 200001,
					Num = 360,
				},
				{
					Value = 200007,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920283,
			Ability = {
				{
					Value = 200001,
					Num = 405,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920283,
			Ability = {
				{
					Value = 200001,
					Num = 450,
				},
				{
					Value = 200007,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id254] =
{
	Character = 220311,
	Rarity = 2,
	NeedChallenge = 145103,
	UpgradeId = 930026,
	LevelList = {
		{
			Level = 1,
			Info = 920284,
			Ability = {
				{
					Value = 200001,
					Num = 45,
				},
				{
					Value = 200006,
					Num = 3,
				},
			},
		},
		{
			Level = 2,
			Info = 920284,
			Ability = {
				{
					Value = 200001,
					Num = 90,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 3,
			Info = 920284,
			Ability = {
				{
					Value = 200001,
					Num = 135,
				},
				{
					Value = 200006,
					Num = 9,
				},
			},
		},
		{
			Level = 4,
			Info = 920284,
			Ability = {
				{
					Value = 200001,
					Num = 180,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 5,
			Info = 920284,
			Ability = {
				{
					Value = 200001,
					Num = 225,
				},
				{
					Value = 200006,
					Num = 15,
				},
			},
		},
		{
			Level = 6,
			Info = 920284,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 7,
			Info = 920284,
			Ability = {
				{
					Value = 200001,
					Num = 315,
				},
				{
					Value = 200006,
					Num = 21,
				},
			},
		},
		{
			Level = 8,
			Info = 920284,
			Ability = {
				{
					Value = 200001,
					Num = 360,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
			SkillList = {
				{
					Id = 100015,
					Value = -25,
				},
			},
		},
		{
			Level = 9,
			Info = 920284,
			Ability = {
				{
					Value = 200001,
					Num = 405,
				},
				{
					Value = 200006,
					Num = 27,
				},
			},
			SkillList = {
				{
					Id = 100015,
					Value = -25,
				},
			},
		},
		{
			Level = 10,
			Info = 920284,
			Ability = {
				{
					Value = 200001,
					Num = 450,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100015,
					Value = -25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id255] =
{
	Character = 220312,
	Rarity = 2,
	UpgradeId = 930005,
	LevelList = {
		{
			Level = 1,
			Info = 920285,
			Ability = {
				{
					Value = 200002,
					Num = 36,
				},
				{
					Value = 200008,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920285,
			Ability = {
				{
					Value = 200002,
					Num = 72,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920285,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920285,
			Ability = {
				{
					Value = 200002,
					Num = 144,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920285,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920285,
			Ability = {
				{
					Value = 200002,
					Num = 216,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920285,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200008,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920285,
			Ability = {
				{
					Value = 200002,
					Num = 288,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920285,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920285,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id256] =
{
	Character = 220312,
	Rarity = 2,
	NeedChallenge = 145104,
	UpgradeId = 930006,
	LevelList = {
		{
			Level = 1,
			Info = 920286,
			Ability = {
				{
					Value = 200002,
					Num = 36,
				},
				{
					Value = 200005,
					Num = 3,
				},
			},
		},
		{
			Level = 2,
			Info = 920286,
			Ability = {
				{
					Value = 200002,
					Num = 72,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 3,
			Info = 920286,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 4,
			Info = 920286,
			Ability = {
				{
					Value = 200002,
					Num = 144,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 5,
			Info = 920286,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
				{
					Value = 200005,
					Num = 15,
				},
			},
			SkillList = {
				{
					Id = 100201,
					Value = 15,
				},
			},
		},
		{
			Level = 6,
			Info = 920286,
			Ability = {
				{
					Value = 200002,
					Num = 216,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
			SkillList = {
				{
					Id = 100201,
					Value = 15,
				},
			},
		},
		{
			Level = 7,
			Info = 920286,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200005,
					Num = 21,
				},
			},
			SkillList = {
				{
					Id = 100201,
					Value = 15,
				},
			},
		},
		{
			Level = 8,
			Info = 920286,
			Ability = {
				{
					Value = 200002,
					Num = 288,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
			SkillList = {
				{
					Id = 100201,
					Value = 15,
				},
			},
		},
		{
			Level = 9,
			Info = 920286,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
			SkillList = {
				{
					Id = 100201,
					Value = 15,
				},
			},
		},
		{
			Level = 10,
			Info = 920286,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100201,
					Value = 15,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id257] =
{
	Character = 220313,
	Rarity = 2,
	UpgradeId = 930025,
	LevelList = {
		{
			Level = 1,
			Info = 920287,
			Ability = {
				{
					Value = 200001,
					Num = 42,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920287,
			Ability = {
				{
					Value = 200001,
					Num = 84,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920287,
			Ability = {
				{
					Value = 200001,
					Num = 126,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920287,
			Ability = {
				{
					Value = 200001,
					Num = 168,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920287,
			Ability = {
				{
					Value = 200001,
					Num = 210,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920287,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920287,
			Ability = {
				{
					Value = 200001,
					Num = 294,
				},
				{
					Value = 200006,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920287,
			Ability = {
				{
					Value = 200001,
					Num = 336,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920287,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920287,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id258] =
{
	Character = 220313,
	Rarity = 2,
	NeedChallenge = 145105,
	UpgradeId = 930006,
	LevelList = {
		{
			Level = 1,
			Info = 920288,
			Ability = {
				{
					Value = 200002,
					Num = 33,
				},
				{
					Value = 200005,
					Num = 3,
				},
			},
		},
		{
			Level = 2,
			Info = 920288,
			Ability = {
				{
					Value = 200002,
					Num = 66,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 3,
			Info = 920288,
			Ability = {
				{
					Value = 200002,
					Num = 99,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 4,
			Info = 920288,
			Ability = {
				{
					Value = 200002,
					Num = 132,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 5,
			Info = 920288,
			Ability = {
				{
					Value = 200002,
					Num = 165,
				},
				{
					Value = 200005,
					Num = 15,
				},
			},
		},
		{
			Level = 6,
			Info = 920288,
			Ability = {
				{
					Value = 200002,
					Num = 198,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 7,
			Info = 920288,
			Ability = {
				{
					Value = 200002,
					Num = 231,
				},
				{
					Value = 200005,
					Num = 21,
				},
			},
		},
		{
			Level = 8,
			Info = 920288,
			Ability = {
				{
					Value = 200002,
					Num = 264,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
			SkillList = {
				{
					Id = 100205,
					Value = 6,
				},
			},
		},
		{
			Level = 9,
			Info = 920288,
			Ability = {
				{
					Value = 200002,
					Num = 297,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
			SkillList = {
				{
					Id = 100205,
					Value = 6,
				},
			},
		},
		{
			Level = 10,
			Info = 920288,
			Ability = {
				{
					Value = 200002,
					Num = 330,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100205,
					Value = 6,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id259] =
{
	Character = 220314,
	Rarity = 2,
	UpgradeId = 930005,
	LevelList = {
		{
			Level = 1,
			Info = 920289,
			Ability = {
				{
					Value = 200002,
					Num = 36,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920289,
			Ability = {
				{
					Value = 200002,
					Num = 72,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920289,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920289,
			Ability = {
				{
					Value = 200002,
					Num = 144,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920289,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920289,
			Ability = {
				{
					Value = 200002,
					Num = 216,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920289,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200005,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920289,
			Ability = {
				{
					Value = 200002,
					Num = 288,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920289,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920289,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id260] =
{
	Character = 220314,
	Rarity = 2,
	NeedChallenge = 145106,
	UpgradeId = 930006,
	LevelList = {
		{
			Level = 1,
			Info = 920290,
			Ability = {
				{
					Value = 200002,
					Num = 36,
				},
				{
					Value = 200006,
					Num = 3,
				},
			},
		},
		{
			Level = 2,
			Info = 920290,
			Ability = {
				{
					Value = 200002,
					Num = 72,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 3,
			Info = 920290,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
				{
					Value = 200006,
					Num = 9,
				},
			},
		},
		{
			Level = 4,
			Info = 920290,
			Ability = {
				{
					Value = 200002,
					Num = 144,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 5,
			Info = 920290,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
				{
					Value = 200006,
					Num = 15,
				},
			},
			SkillList = {
				{
					Id = 100759,
					Value = 3,
				},
			},
		},
		{
			Level = 6,
			Info = 920290,
			Ability = {
				{
					Value = 200002,
					Num = 216,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
			SkillList = {
				{
					Id = 100759,
					Value = 3,
				},
			},
		},
		{
			Level = 7,
			Info = 920290,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200006,
					Num = 21,
				},
			},
			SkillList = {
				{
					Id = 100759,
					Value = 3,
				},
			},
		},
		{
			Level = 8,
			Info = 920290,
			Ability = {
				{
					Value = 200002,
					Num = 288,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
			SkillList = {
				{
					Id = 100759,
					Value = 3,
				},
			},
		},
		{
			Level = 9,
			Info = 920290,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
				{
					Value = 200006,
					Num = 27,
				},
			},
			SkillList = {
				{
					Id = 100759,
					Value = 3,
				},
			},
		},
		{
			Level = 10,
			Info = 920290,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100759,
					Value = 3,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id261] =
{
	Character = 220315,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920291,
			Ability = {
				{
					Value = 200001,
					Num = 57,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920291,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920291,
			Ability = {
				{
					Value = 200001,
					Num = 171,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920291,
			Ability = {
				{
					Value = 200001,
					Num = 228,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920291,
			Ability = {
				{
					Value = 200001,
					Num = 285,
				},
				{
					Value = 200008,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920291,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920291,
			Ability = {
				{
					Value = 200001,
					Num = 399,
				},
				{
					Value = 200008,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920291,
			Ability = {
				{
					Value = 200001,
					Num = 456,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920291,
			Ability = {
				{
					Value = 200001,
					Num = 513,
				},
				{
					Value = 200008,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920291,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200008,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id262] =
{
	Character = 220315,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920292,
			Ability = {
				{
					Value = 200001,
					Num = 57,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920292,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920292,
			Ability = {
				{
					Value = 200001,
					Num = 171,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920292,
			Ability = {
				{
					Value = 200001,
					Num = 228,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920292,
			Ability = {
				{
					Value = 200001,
					Num = 285,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920292,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920292,
			Ability = {
				{
					Value = 200001,
					Num = 399,
				},
				{
					Value = 200005,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920292,
			Ability = {
				{
					Value = 200001,
					Num = 456,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 101731,
					Value = 720,
				},
			},
		},
		{
			Level = 9,
			Info = 920292,
			Ability = {
				{
					Value = 200001,
					Num = 513,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 101731,
					Value = 720,
				},
			},
		},
		{
			Level = 10,
			Info = 920292,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 101731,
					Value = 720,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id263] =
{
	Character = 220315,
	Rarity = 3,
	NeedChallenge = 145107,
	UpgradeId = 930031,
	LevelList = {
		{
			Level = 1,
			Info = 920293,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
			},
		},
		{
			Level = 2,
			Info = 920293,
			Ability = {
				{
					Value = 200001,
					Num = 190,
				},
			},
		},
		{
			Level = 3,
			Info = 920293,
			Ability = {
				{
					Value = 200001,
					Num = 266,
				},
			},
		},
		{
			Level = 4,
			Info = 920293,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
			},
		},
		{
			Level = 5,
			Info = 920293,
			Ability = {
				{
					Value = 200001,
					Num = 418,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
			SkillList = {
				{
					Id = 100605,
					Value = 24,
				},
			},
		},
		{
			Level = 6,
			Info = 920293,
			Ability = {
				{
					Value = 200001,
					Num = 494,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100605,
					Value = 24,
				},
			},
		},
		{
			Level = 7,
			Info = 920293,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
			SkillList = {
				{
					Id = 100605,
					Value = 24,
				},
			},
		},
		{
			Level = 8,
			Info = 920293,
			Ability = {
				{
					Value = 200001,
					Num = 646,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100605,
					Value = 24,
				},
			},
		},
		{
			Level = 9,
			Info = 920293,
			Ability = {
				{
					Value = 200001,
					Num = 722,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100605,
					Value = 24,
				},
			},
		},
		{
			Level = 10,
			Info = 920293,
			Ability = {
				{
					Value = 200001,
					Num = 798,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100605,
					Value = 24,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id264] =
{
	Character = 220316,
	Rarity = 3,
	UpgradeId = 930009,
	LevelList = {
		{
			Level = 1,
			Info = 920294,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200007,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920294,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920294,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200007,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920294,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920294,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200007,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920294,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920294,
			Ability = {
				{
					Value = 200002,
					Num = 294,
				},
				{
					Value = 200007,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920294,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
				{
					Value = 200007,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920294,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200007,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920294,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200007,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id265] =
{
	Character = 220316,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920295,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
			},
		},
		{
			Level = 2,
			Info = 920295,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
			},
		},
		{
			Level = 3,
			Info = 920295,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
			},
		},
		{
			Level = 4,
			Info = 920295,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
			},
		},
		{
			Level = 5,
			Info = 920295,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
			},
			SkillList = {
				{
					Id = 100015,
					Value = -15,
				},
			},
		},
		{
			Level = 6,
			Info = 920295,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
			},
			SkillList = {
				{
					Id = 100015,
					Value = -15,
				},
			},
		},
		{
			Level = 7,
			Info = 920295,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
			},
			SkillList = {
				{
					Id = 100015,
					Value = -15,
				},
			},
		},
		{
			Level = 8,
			Info = 920295,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
			},
			SkillList = {
				{
					Id = 100015,
					Value = -15,
				},
			},
		},
		{
			Level = 9,
			Info = 920295,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
			},
			SkillList = {
				{
					Id = 100015,
					Value = -15,
				},
			},
		},
		{
			Level = 10,
			Info = 920295,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
			},
			SkillList = {
				{
					Id = 100015,
					Value = -15,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id266] =
{
	Character = 220316,
	Rarity = 3,
	NeedChallenge = 145108,
	UpgradeId = 930031,
	LevelList = {
		{
			Level = 1,
			Info = 920296,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
			},
		},
		{
			Level = 2,
			Info = 920296,
			Ability = {
				{
					Value = 200001,
					Num = 180,
				},
			},
		},
		{
			Level = 3,
			Info = 920296,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
			},
		},
		{
			Level = 4,
			Info = 920296,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
			},
		},
		{
			Level = 5,
			Info = 920296,
			Ability = {
				{
					Value = 200001,
					Num = 396,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920296,
			Ability = {
				{
					Value = 200001,
					Num = 468,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920296,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920296,
			Ability = {
				{
					Value = 200001,
					Num = 612,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
		{
			Level = 9,
			Info = 920296,
			Ability = {
				{
					Value = 200001,
					Num = 684,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
		{
			Level = 10,
			Info = 920296,
			Ability = {
				{
					Value = 200001,
					Num = 756,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id267] =
{
	Character = 220317,
	Rarity = 3,
	UpgradeId = 930009,
	LevelList = {
		{
			Level = 1,
			Info = 920297,
			Ability = {
				{
					Value = 200002,
					Num = 45,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920297,
			Ability = {
				{
					Value = 200002,
					Num = 90,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920297,
			Ability = {
				{
					Value = 200002,
					Num = 135,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920297,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920297,
			Ability = {
				{
					Value = 200002,
					Num = 225,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920297,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920297,
			Ability = {
				{
					Value = 200002,
					Num = 315,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920297,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920297,
			Ability = {
				{
					Value = 200002,
					Num = 405,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920297,
			Ability = {
				{
					Value = 200002,
					Num = 450,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id268] =
{
	Character = 220317,
	Rarity = 3,
	UpgradeId = 930010,
	LevelList = {
		{
			Level = 1,
			Info = 920298,
			Ability = {
				{
					Value = 200002,
					Num = 45,
				},
				{
					Value = 200008,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920298,
			Ability = {
				{
					Value = 200002,
					Num = 90,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920298,
			Ability = {
				{
					Value = 200002,
					Num = 135,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920298,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920298,
			Ability = {
				{
					Value = 200002,
					Num = 225,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920298,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920298,
			Ability = {
				{
					Value = 200002,
					Num = 315,
				},
				{
					Value = 200008,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920298,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 101736,
					Value = 190,
				},
			},
		},
		{
			Level = 9,
			Info = 920298,
			Ability = {
				{
					Value = 200002,
					Num = 405,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 101736,
					Value = 210,
				},
			},
		},
		{
			Level = 10,
			Info = 920298,
			Ability = {
				{
					Value = 200002,
					Num = 450,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 101736,
					Value = 230,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id269] =
{
	Character = 220317,
	Rarity = 3,
	NeedChallenge = 145109,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920299,
			Ability = {
				{
					Value = 200002,
					Num = 90,
				},
			},
		},
		{
			Level = 2,
			Info = 920299,
			Ability = {
				{
					Value = 200002,
					Num = 150,
				},
			},
		},
		{
			Level = 3,
			Info = 920299,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
			},
		},
		{
			Level = 4,
			Info = 920299,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
			},
		},
		{
			Level = 5,
			Info = 920299,
			Ability = {
				{
					Value = 200002,
					Num = 330,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920299,
			Ability = {
				{
					Value = 200002,
					Num = 390,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920299,
			Ability = {
				{
					Value = 200002,
					Num = 450,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920299,
			Ability = {
				{
					Value = 200002,
					Num = 510,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101738,
					Value = 15,
				},
			},
		},
		{
			Level = 9,
			Info = 920299,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101738,
					Value = 15,
				},
			},
		},
		{
			Level = 10,
			Info = 920299,
			Ability = {
				{
					Value = 200002,
					Num = 630,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101738,
					Value = 15,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id270] =
{
	Character = 220318,
	Rarity = 3,
	UpgradeId = 930009,
	LevelList = {
		{
			Level = 1,
			Info = 920300,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920300,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920300,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920300,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920300,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920300,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920300,
			Ability = {
				{
					Value = 200002,
					Num = 294,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920300,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100555,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920300,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100555,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920300,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100555,
					Value = 25,
				},
			},
		},
	},
}
