require "FreakPlanet/Design/MiscConfig"
TokenConfig ={};
TokenID = 
{
	Id001 = 330001,
	Id002 = 330002,
	Id003 = 330003,
}
TokenConfig[TokenID.Id001] =
{
	Id = 1,
	Name = "初级奖券",
	Rarity = 2,
	Icon = "RPG_Token_Gold1",
	Desc = "可以在不夜城中进行一次免费的初级金币池抽卡",
	SummonPool = 500001,
}
TokenConfig[TokenID.Id002] =
{
	Id = 2,
	Name = "中级奖券",
	Rarity = 3,
	Icon = "RPG_Token_Gold2",
	Desc = "可以在不夜城中进行一次免费的超级金币池抽卡",
	SummonPool = 500002,
}
TokenConfig[TokenID.Id003] =
{
	Id = 3,
	Name = "玉璧券",
	Rarity = 4,
	Icon = "RPG_Token_Diamond",
	Desc = "可以在不夜城中进行一次免费的玉璧池抽卡",
	SummonPool = 500003,
}

