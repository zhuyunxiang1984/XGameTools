SpaceTravelGoalConfig ={};
SpaceTravelGoalID = 
{
	Id001 = 870001,
	Id002 = 870002,
	Id003 = 870003,
	Id004 = 870004,
	Id005 = 870005,
	Id006 = 870006,
	Id007 = 870007,
	Id008 = 870008,
	Id009 = 870009,
	Id010 = 870010,
	Id011 = 870011,
	Id012 = 870012,
	Id013 = 870013,
	Id014 = 870014,
	Id015 = 870015,
	Id016 = 870016,
	Id017 = 870017,
	Id018 = 870018,
	Id019 = 870019,
	Id020 = 870020,
	Id021 = 870021,
	Id022 = 870022,
	Id023 = 870023,
	Id024 = 870024,
	Id025 = 870025,
}
SpaceTravelGoalConfig[SpaceTravelGoalID.Id001] =
{
	Id = 1,
	Name = "与魔王集团交易",
	GoalTrigger = 
	{
		TriggerType.Choice,
	},
	GoalCondition = 
	{
		{
			Name = "与魔王集团交易 2次",
			Type = ItemType.SpaceTravelChoice,
			CountType = GoalCountType.StartNow,
			Num = 2,
			TagList = 
			{
				567005,
				567085,
				567005,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 101,
			Num = 150,
		},
		{
			Value = 106,
			Num = 150,
		},
		{
			Value = 780001,
			Num = 100,
		},
	},
}
SpaceTravelGoalConfig[SpaceTravelGoalID.Id002] =
{
	Id = 2,
	Name = "魔王集团竞答",
	GoalTrigger = 
	{
		TriggerType.Choice,
	},
	GoalCondition = 
	{
		{
			Name = "正确回答魔王集团竞答 3次",
			Type = ItemType.SpaceTravelChoice,
			CountType = GoalCountType.StartNow,
			Num = 3,
			TagList = 
			{
				567085,
				567087,
				567088,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 101,
			Num = 100,
		},
		{
			Value = 106,
			Num = 100,
		},
		{
			Value = 780001,
			Num = 50,
		},
	},
}
SpaceTravelGoalConfig[SpaceTravelGoalID.Id003] =
{
	Id = 3,
	Name = "与海盗战斗",
	GoalTrigger = 
	{
		TriggerType.Choice,
	},
	GoalCondition = 
	{
		{
			Name = "与海盗战斗 10次",
			Type = ItemType.SpaceTravelChoice,
			CountType = GoalCountType.StartNow,
			Num = 10,
			TagList = 
			{
				567003,
				567089,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 101,
			Num = 150,
		},
		{
			Value = 106,
			Num = 150,
		},
		{
			Value = 770001,
			Num = 20,
		},
	},
}
SpaceTravelGoalConfig[SpaceTravelGoalID.Id004] =
{
	Id = 4,
	Name = "登陆发现",
	GoalTrigger = 
	{
		TriggerType.Choice,
	},
	GoalCondition = 
	{
		{
			Name = "登陆探索 3次",
			Type = ItemType.SpaceTravelChoice,
			CountType = GoalCountType.StartNow,
			Num = 3,
			TagList = 
			{
				567006,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 101,
			Num = 150,
		},
		{
			Value = 106,
			Num = 150,
		},
		{
			Value = 771017,
			Num = 2,
		},
	},
}
SpaceTravelGoalConfig[SpaceTravelGoalID.Id005] =
{
	Id = 5,
	Name = "整理船舱",
	GoalTrigger = 
	{
		TriggerType.Choice,
	},
	GoalCondition = 
	{
		{
			Name = "整理船舱 3次",
			Type = ItemType.SpaceTravelChoice,
			CountType = GoalCountType.StartNow,
			Num = 3,
			TagList = 
			{
				567012,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 101,
			Num = 150,
		},
		{
			Value = 106,
			Num = 150,
		},
	},
}
SpaceTravelGoalConfig[SpaceTravelGoalID.Id006] =
{
	Id = 6,
	Name = "战斗考验",
	GoalTrigger = 
	{
		TriggerType.Choice,
	},
	GoalCondition = 
	{
		{
			Name = "进行任意战斗 10次",
			Type = ItemType.SpaceTravelChoice,
			CountType = GoalCountType.StartNow,
			Num = 10,
			TagList = 
			{
				567003,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 101,
			Num = 150,
		},
		{
			Value = 106,
			Num = 150,
		},
		{
			Value = 770001,
			Num = 20,
		},
	},
}
SpaceTravelGoalConfig[SpaceTravelGoalID.Id007] =
{
	Id = 7,
	Name = "驱赶海盗",
	GoalTrigger = 
	{
		TriggerType.ChoiceWin,
	},
	GoalCondition = 
	{
		{
			Name = "与海盗战斗获胜 3次",
			Type = ItemType.SpaceTravelChoice,
			CountType = GoalCountType.StartNow,
			Num = 3,
			TagList = 
			{
				567003,
				567089,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 106,
			Num = 300,
		},
		{
			Value = 770001,
			Num = 30,
		},
	},
}
SpaceTravelGoalConfig[SpaceTravelGoalID.Id008] =
{
	Id = 8,
	Name = "谈判专家",
	GoalTrigger = 
	{
		TriggerType.ChoiceWin,
	},
	GoalCondition = 
	{
		{
			Name = "进行任意谈判获胜 5次",
			Type = ItemType.SpaceTravelChoice,
			CountType = GoalCountType.StartNow,
			Num = 5,
			TagList = 
			{
				567004,
				567004,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 103,
			Num = 150,
		},
		{
			Value = 106,
			Num = 300,
		},
	},
}
SpaceTravelGoalConfig[SpaceTravelGoalID.Id009] =
{
	Id = 9,
	Name = "矿石收集",
	GoalTrigger = 
	{
		TriggerType.Discovery,
	},
	GoalCondition = 
	{
		{
			Name = "登陆探索并获得任意矿石 10个",
			Type = ItemType.SpaceTravelGoods,
			CountType = GoalCountType.StartNow,
			Num = 10,
			TagList = 
			{
				561647,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 101,
			Num = 300,
		},
		{
			Value = 106,
			Num = 300,
		},
	},
}
SpaceTravelGoalConfig[SpaceTravelGoalID.Id010] =
{
	Id = 10,
	Name = "矿石丰收",
	GoalTrigger = 
	{
		TriggerType.Discovery,
	},
	GoalCondition = 
	{
		{
			Name = "一次性登陆探索并获得任意矿石 5个",
			Type = ItemType.SpaceTravelGoods,
			CountType = GoalCountType.OneShot,
			Num = 5,
			TagList = 
			{
				561647,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 101,
			Num = 300,
		},
		{
			Value = 106,
			Num = 300,
		},
	},
}
SpaceTravelGoalConfig[SpaceTravelGoalID.Id011] =
{
	Id = 11,
	Name = "圆锯爱好者",
	GoalTrigger = 
	{
		TriggerType.DiscoveryCost,
	},
	GoalCondition = 
	{
		{
			Name = "登陆探索并使用圆锯 5个",
			Type = ItemType.SpaceTravelGoods,
			CountType = GoalCountType.StartNow,
			Num = 5,
			TagList = 
			{
				567094,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 101,
			Num = 300,
		},
		{
			Value = 106,
			Num = 300,
		},
	},
}
SpaceTravelGoalConfig[SpaceTravelGoalID.Id012] =
{
	Id = 12,
	Name = "圆锯大师",
	GoalTrigger = 
	{
		TriggerType.DiscoveryCost,
	},
	GoalCondition = 
	{
		{
			Name = "一次性登陆探索并使用圆锯 2个",
			Type = ItemType.SpaceTravelGoods,
			CountType = GoalCountType.OneShot,
			Num = 2,
			TagList = 
			{
				567094,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 101,
			Num = 300,
		},
		{
			Value = 106,
			Num = 300,
		},
	},
}
SpaceTravelGoalConfig[SpaceTravelGoalID.Id013] =
{
	Id = 13,
	Name = "购买补给",
	GoalTrigger = 
	{
		TriggerType.Deal,
	},
	GoalCondition = 
	{
		{
			Name = "在商店购买任意燃料补充剂 3个",
			Type = ItemType.SpaceTravelGoods,
			CountType = GoalCountType.StartNow,
			Num = 3,
			TagList = 
			{
				567095,
				567097,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 101,
			Num = 300,
		},
		{
			Value = 106,
			Num = 300,
		},
	},
}
SpaceTravelGoalConfig[SpaceTravelGoalID.Id014] =
{
	Id = 14,
	Name = "补给抄底",
	GoalTrigger = 
	{
		TriggerType.Deal,
	},
	GoalCondition = 
	{
		{
			Name = "一次性在商店购买任意燃料补充剂 2个",
			Type = ItemType.SpaceTravelGoods,
			CountType = GoalCountType.OneShot,
			Num = 2,
			TagList = 
			{
				567095,
				567097,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 101,
			Num = 300,
		},
		{
			Value = 106,
			Num = 300,
		},
	},
}
SpaceTravelGoalConfig[SpaceTravelGoalID.Id015] =
{
	Id = 15,
	Name = "出售发条",
	GoalTrigger = 
	{
		TriggerType.DealCost,
	},
	GoalCondition = 
	{
		{
			Name = "在商店花费发条 20个",
			Type = ItemType.SpaceTravelGoods,
			CountType = GoalCountType.StartNow,
			Num = 20,
			TagList = 
			{
				567096,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 101,
			Num = 300,
		},
		{
			Value = 106,
			Num = 300,
		},
	},
}
SpaceTravelGoalConfig[SpaceTravelGoalID.Id016] =
{
	Id = 16,
	Name = "发条抛售",
	GoalTrigger = 
	{
		TriggerType.DealCost,
	},
	GoalCondition = 
	{
		{
			Name = "一次性在商店花费发条 8个",
			Type = ItemType.SpaceTravelGoods,
			CountType = GoalCountType.OneShot,
			Num = 8,
			TagList = 
			{
				567096,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 101,
			Num = 300,
		},
		{
			Value = 106,
			Num = 300,
		},
	},
}
SpaceTravelGoalConfig[SpaceTravelGoalID.Id017] =
{
	Id = 17,
	Name = "提交矿石",
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "提交陨铁 5个",
			Type = ItemType.SpaceTravelGoods,
			CountType = GoalCountType.Current,
			Num = 5,
			Value = 771001,
		},
	},
	Reward = {
		{
			Value = 101,
			Num = 150,
		},
		{
			Value = 106,
			Num = 150,
		},
	},
}
SpaceTravelGoalConfig[SpaceTravelGoalID.Id018] =
{
	Id = 18,
	Name = "使用补给",
	GoalTrigger = 
	{
		TriggerType.UseItem,
	},
	GoalCondition = 
	{
		{
			Name = "使用任意燃料补充剂 3次",
			Type = ItemType.SpaceTravelGoods,
			CountType = GoalCountType.StartNow,
			Num = 3,
			TagList = 
			{
				567095,
				567097,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 101,
			Num = 50,
		},
		{
			Value = 106,
			Num = 50,
		},
	},
}
SpaceTravelGoalConfig[SpaceTravelGoalID.Id019] =
{
	Id = 19,
	Name = "艺术品",
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有艺术品真品 2个",
			Type = ItemType.SpaceTravelGoods,
			CountType = GoalCountType.Current,
			Num = 2,
			TagList = 
			{
				561651,
				561652,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 101,
			Num = 200,
		},
		{
			Value = 106,
			Num = 400,
		},
	},
}
SpaceTravelGoalConfig[SpaceTravelGoalID.Id020] =
{
	Id = 20,
	Name = "星海航行",
	GoalTrigger = 
	{
		TriggerType.Forward,
	},
	GoalCondition = 
	{
		{
			Name = "前进30个路点",
			Type = ItemType.Node,
			CountType = GoalCountType.StartNow,
			Num = 30,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 101,
			Num = 50,
		},
		{
			Value = 106,
			Num = 50,
		},
	},
}
SpaceTravelGoalConfig[SpaceTravelGoalID.Id021] =
{
	Id = 21,
	Name = "快速航行",
	GoalTrigger = 
	{
		TriggerType.UseDice,
	},
	GoalCondition = 
	{
		{
			Name = "投骰子获得6点及以上 3次（含定点推进装置）",
			Type = ItemType.DicePoint,
			CountType = GoalCountType.StartNow,
			Num = 3,
			Value = -1,
			DicePoints = 
			{
				6,7,8,9,10,
			},
		},
	},
	Reward = {
		{
			Value = 101,
			Num = 150,
		},
		{
			Value = 106,
			Num = 150,
		},
	},
}
SpaceTravelGoalConfig[SpaceTravelGoalID.Id022] =
{
	Id = 22,
	Name = "魔王集团友好度",
	GoalTrigger = 
	{
		TriggerType.Friendliness,
	},
	GoalCondition = 
	{
		{
			Name = "魔王集团声望达到2400点",
			Type = ItemType.SpaceTravelFriendliness,
			CountType = GoalCountType.Current,
			Num = 2400,
			Value = 780001,
		},
	},
	Reward = {
		{
			Value = 106,
			Num = 300,
		},
	},
}
SpaceTravelGoalConfig[SpaceTravelGoalID.Id023] =
{
	Id = 23,
	Name = "提升魔王集团友好度",
	GoalTrigger = 
	{
		TriggerType.FriendlinessUp,
	},
	GoalCondition = 
	{
		{
			Name = "魔王集团声望提升50点(记录任务接取后的声望变化，加减都计)",
			Type = ItemType.SpaceTravelFriendliness,
			CountType = GoalCountType.StartNow,
			Num = 50,
			Value = 780001,
		},
	},
	Reward = {
		{
			Value = 101,
			Num = 150,
		},
		{
			Value = 106,
			Num = 150,
		},
	},
}
SpaceTravelGoalConfig[SpaceTravelGoalID.Id024] =
{
	Id = 24,
	Name = "合成补给",
	GoalTrigger = 
	{
		TriggerType.Craft,
	},
	GoalCondition = 
	{
		{
			Name = "合成任意燃料补充道具 2次",
			Type = ItemType.LabRecipe,
			CountType = GoalCountType.StartNow,
			Num = 2,
			TagList = 
			{
				567095,
				567097,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 101,
			Num = 150,
		},
		{
			Value = 106,
			Num = 150,
		},
	},
}
SpaceTravelGoalConfig[SpaceTravelGoalID.Id025] =
{
	Id = 25,
	Name = "星海航行",
	GoalTrigger = 
	{
		TriggerType.Forward,
	},
	GoalCondition = 
	{
		{
			Name = "前进路点1个",
			Type = ItemType.Node,
			CountType = GoalCountType.StartNow,
			Num = 1,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 101,
			Num = 50,
		},
		{
			Value = 106,
			Num = 50,
		},
	},
}
