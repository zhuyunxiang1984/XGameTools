
AreaConfig[AreaID.Id151] =
{
	Id = 151,
	Name = "着陆点",
	Planet = 120004,
	Level = 82,
	AreaElement = 210002,
	NumCap = 5,
	Map = "SUS_map_01",
	LevelIcon = "Icon_SUSBG01",
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "SUS_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140601,
			Enemy = {
				{
					Value = 242084,
					Level = 165,
					Weight = 1000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 10900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242084,
					Level = 165,
					Weight = 1000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 200,
					FightPower = 10900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
	},
	Challenge = {
		140601,
	},
}
AreaConfig[AreaID.Id152] =
{
	Id = 152,
	Name = "甜心街",
	Planet = 120004,
	Level = 85,
	AreaElement = 210001,
	NumCap = 5,
	Map = "SUS_map_02",
	LevelIcon = "Icon_SUSBG01",
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "SUS_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140605,
			Enemy = {
				{
					Value = 242084,
					Level = 166,
					Weight = 192,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 10900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242087,
					Level = 168,
					Weight = 230,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 13800,
				},
				{
					Value = 242088,
					Level = 172,
					Weight = 230,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 14200,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242089,
					Level = 172,
					Weight = 346,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 16300,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140604,
			Enemy = {
				{
					Value = 242084,
					Level = 166,
					Weight = 192,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 10900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242087,
					Level = 168,
					Weight = 230,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 13800,
				},
				{
					Value = 242088,
					Level = 172,
					Weight = 230,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 14200,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242089,
					Level = 172,
					Weight = 346,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 16300,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140603,
			Enemy = {
				{
					Value = 242084,
					Level = 166,
					Weight = 192,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 10900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242087,
					Level = 168,
					Weight = 230,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 13800,
				},
				{
					Value = 242088,
					Level = 172,
					Weight = 230,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 14200,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140602,
			Enemy = {
				{
					Value = 242084,
					Level = 166,
					Weight = 192,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 10900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242087,
					Level = 168,
					Weight = 230,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 13800,
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242084,
					Level = 166,
					Weight = 192,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 10900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
	},
	Challenge = {
		140602,
		140603,
		140604,
		140605,
	},
	EventList = {
		310601,
		310602,
		310603,
		310604,
	},
}
AreaConfig[AreaID.Id153] =
{
	Id = 153,
	Name = "咖啡馆",
	Planet = 120004,
	Level = 96,
	AreaElement = 210005,
	NumCap = 5,
	Map = "SUS_map_03",
	LevelIcon = "Icon_SUSBG01",
	LevelBG = "SUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "SUS_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140608,
			Enemy = {
				{
					Value = 242084,
					Level = 186,
					Weight = 113,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 10900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242087,
					Level = 187,
					Weight = 136,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 13800,
				},
				{
					Value = 242089,
					Level = 188,
					Weight = 204,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 16300,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
				{
					Value = 242090,
					Level = 190,
					Weight = 136,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 15600,
				},
				{
					Value = 242091,
					Level = 194,
					Weight = 204,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 18300,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 242085,
					Level = 200,
					Weight = 204,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 18400,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140607,
			Enemy = {
				{
					Value = 242084,
					Level = 186,
					Weight = 113,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 10900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242087,
					Level = 187,
					Weight = 136,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 13800,
				},
				{
					Value = 242089,
					Level = 188,
					Weight = 204,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 16300,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
				{
					Value = 242090,
					Level = 190,
					Weight = 136,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 15600,
				},
				{
					Value = 242091,
					Level = 194,
					Weight = 204,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 18300,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 242085,
					Level = 200,
					Weight = 204,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 18400,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140606,
			Enemy = {
				{
					Value = 242084,
					Level = 186,
					Weight = 113,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 10900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242087,
					Level = 187,
					Weight = 136,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 13800,
				},
				{
					Value = 242089,
					Level = 188,
					Weight = 204,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 16300,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
				{
					Value = 242090,
					Level = 190,
					Weight = 136,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 15600,
				},
				{
					Value = 242085,
					Level = 200,
					Weight = 204,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 18400,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242084,
					Level = 186,
					Weight = 113,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 10900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242087,
					Level = 187,
					Weight = 136,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 13800,
				},
				{
					Value = 242089,
					Level = 188,
					Weight = 204,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 16300,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
				{
					Value = 242085,
					Level = 200,
					Weight = 204,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 18400,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
			},
		},
	},
	Challenge = {
		140606,
		140607,
		140608,
	},
	EventList = {
		310605,
		310606,
		310607,
		310608,
	},
}
AreaConfig[AreaID.Id154] =
{
	Id = 154,
	Name = "邮局",
	Planet = 120004,
	Level = 88,
	AreaElement = 210005,
	NumCap = 5,
	Map = "SUS_map_04",
	LevelIcon = "Icon_SUSBG02",
	LevelBG = "SUSBG02",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "SUS_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140612,
			Enemy = {
				{
					Value = 242084,
					Level = 169,
					Weight = 156,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 10900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242087,
					Level = 171,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 13800,
				},
				{
					Value = 242092,
					Level = 175,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 14400,
				},
				{
					Value = 242093,
					Level = 180,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 14800,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242094,
					Level = 180,
					Weight = 281,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 17000,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140611,
			Enemy = {
				{
					Value = 242084,
					Level = 169,
					Weight = 156,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 10900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242087,
					Level = 171,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 13800,
				},
				{
					Value = 242092,
					Level = 175,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 14400,
				},
				{
					Value = 242093,
					Level = 180,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 14800,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242094,
					Level = 180,
					Weight = 281,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 17000,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140610,
			Enemy = {
				{
					Value = 242084,
					Level = 169,
					Weight = 156,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 10900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242087,
					Level = 171,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 13800,
				},
				{
					Value = 242092,
					Level = 175,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 14400,
				},
				{
					Value = 242093,
					Level = 180,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 14800,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140609,
			Enemy = {
				{
					Value = 242084,
					Level = 169,
					Weight = 156,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 10900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242087,
					Level = 171,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 13800,
				},
				{
					Value = 242092,
					Level = 175,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 14400,
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242084,
					Level = 169,
					Weight = 156,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 10900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242087,
					Level = 171,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 13800,
				},
			},
		},
	},
	Challenge = {
		140609,
		140610,
		140611,
		140612,
	},
	EventList = {
		310609,
		310610,
		310611,
		310612,
	},
}
AreaConfig[AreaID.Id155] =
{
	Id = 155,
	Name = "冷清街",
	Planet = 120004,
	Level = 95,
	AreaElement = 210005,
	NumCap = 5,
	Map = "SUS_map_05",
	LevelIcon = "Icon_SUSBG03",
	LevelBG = "SUSBG03",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "SUS_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140616,
			Enemy = {
				{
					Value = 242084,
					Level = 183,
					Weight = 142,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 10900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242095,
					Level = 185,
					Weight = 171,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 15200,
				},
				{
					Value = 242096,
					Level = 190,
					Weight = 171,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 15600,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242085,
					Level = 195,
					Weight = 257,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 18400,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242097,
					Level = 200,
					Weight = 257,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 18800,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140615,
			Enemy = {
				{
					Value = 242084,
					Level = 183,
					Weight = 142,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 10900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242095,
					Level = 185,
					Weight = 171,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 15200,
				},
				{
					Value = 242096,
					Level = 190,
					Weight = 171,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 15600,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242085,
					Level = 195,
					Weight = 257,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 18400,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140614,
			Enemy = {
				{
					Value = 242084,
					Level = 183,
					Weight = 142,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 10900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242095,
					Level = 185,
					Weight = 171,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 15200,
				},
				{
					Value = 242096,
					Level = 190,
					Weight = 171,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 15600,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140613,
			Enemy = {
				{
					Value = 242084,
					Level = 183,
					Weight = 142,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 10900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242095,
					Level = 185,
					Weight = 171,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 15200,
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242084,
					Level = 183,
					Weight = 142,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 10900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
	},
	Challenge = {
		140613,
		140614,
		140615,
		140616,
	},
	EventList = {
		310613,
		310614,
		310615,
		310616,
		310617,
		310618,
	},
}
AreaConfig[AreaID.Id156] =
{
	Id = 156,
	Name = "现场",
	Planet = 120004,
	Level = 102,
	AreaElement = 210005,
	NumCap = 5,
	Map = "SUS_map_06",
	LevelIcon = "Icon_SUSBG03",
	LevelBG = "SUSBG03",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "SUS_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140620,
			Enemy = {
				{
					Value = 242084,
					Level = 196,
					Weight = 103,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 10900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242096,
					Level = 198,
					Weight = 123,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 15600,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242098,
					Level = 205,
					Weight = 123,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 16800,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242099,
					Level = 205,
					Weight = 185,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 19300,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242100,
					Level = 205,
					Weight = 371,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 3600,
					FightPower = 21800,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242086,
					Level = 210,
					Weight = 92,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 26700,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140619,
			Enemy = {
				{
					Value = 242084,
					Level = 196,
					Weight = 103,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 10900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242096,
					Level = 198,
					Weight = 123,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 15600,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242098,
					Level = 205,
					Weight = 123,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 16800,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242099,
					Level = 205,
					Weight = 185,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 19300,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242100,
					Level = 205,
					Weight = 371,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 3600,
					FightPower = 21800,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242086,
					Level = 210,
					Weight = 92,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 26700,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140618,
			Enemy = {
				{
					Value = 242084,
					Level = 196,
					Weight = 103,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 10900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242096,
					Level = 198,
					Weight = 123,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 15600,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242098,
					Level = 205,
					Weight = 123,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 16800,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242099,
					Level = 205,
					Weight = 185,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 19300,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242086,
					Level = 210,
					Weight = 92,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 26700,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140617,
			Enemy = {
				{
					Value = 242084,
					Level = 196,
					Weight = 103,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 10900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242096,
					Level = 198,
					Weight = 123,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 15600,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242098,
					Level = 205,
					Weight = 123,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 16800,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242086,
					Level = 210,
					Weight = 92,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 26700,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242084,
					Level = 196,
					Weight = 103,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 10900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242096,
					Level = 198,
					Weight = 123,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 15600,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242086,
					Level = 210,
					Weight = 92,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 26700,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
			},
		},
	},
	Challenge = {
		140617,
		140618,
		140619,
		140620,
	},
	EventList = {
		310619,
		310620,
		310621,
		310622,
	},
}
AreaConfig[AreaID.Id157] =
{
	Id = 157,
	Name = "警局",
	Planet = 120004,
	Level = 103,
	AreaElement = 210005,
	NumCap = 5,
	Map = "SUS_map_07",
	LevelIcon = "Icon_SUSBG03",
	LevelBG = "SUSBG03",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "SUS_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140624,
			Enemy = {
				{
					Value = 242084,
					Level = 202,
					Weight = 131,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 10900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242095,
					Level = 204,
					Weight = 157,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 15200,
				},
				{
					Value = 242090,
					Level = 206,
					Weight = 157,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 15600,
				},
				{
					Value = 242101,
					Level = 208,
					Weight = 157,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 17000,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 242102,
					Level = 208,
					Weight = 157,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 17000,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242103,
					Level = 208,
					Weight = 236,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 19600,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140623,
			Enemy = {
				{
					Value = 242084,
					Level = 202,
					Weight = 131,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 10900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242095,
					Level = 204,
					Weight = 157,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 15200,
				},
				{
					Value = 242090,
					Level = 206,
					Weight = 157,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 15600,
				},
				{
					Value = 242101,
					Level = 208,
					Weight = 157,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 17000,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 242102,
					Level = 208,
					Weight = 157,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 17000,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242103,
					Level = 208,
					Weight = 236,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 19600,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140622,
			Enemy = {
				{
					Value = 242084,
					Level = 202,
					Weight = 131,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 10900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242095,
					Level = 204,
					Weight = 157,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 15200,
				},
				{
					Value = 242090,
					Level = 206,
					Weight = 157,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 15600,
				},
				{
					Value = 242101,
					Level = 208,
					Weight = 157,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 17000,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 242102,
					Level = 208,
					Weight = 157,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 17000,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140621,
			Enemy = {
				{
					Value = 242084,
					Level = 202,
					Weight = 131,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 10900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242095,
					Level = 204,
					Weight = 157,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 15200,
				},
				{
					Value = 242090,
					Level = 206,
					Weight = 157,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 15600,
				},
				{
					Value = 242101,
					Level = 208,
					Weight = 157,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 17000,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242084,
					Level = 202,
					Weight = 131,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 10900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242095,
					Level = 204,
					Weight = 157,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 15200,
				},
				{
					Value = 242090,
					Level = 206,
					Weight = 157,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 15600,
				},
			},
		},
	},
	Challenge = {
		140621,
		140622,
		140623,
		140624,
	},
	EventList = {
		310623,
		310624,
		310625,
		310626,
	},
}
AreaConfig[AreaID.Id158] =
{
	Id = 158,
	Name = "证物仓库",
	Planet = 120004,
	Level = 109,
	AreaElement = 210005,
	NumCap = 5,
	Map = "SUS_map_08",
	LevelIcon = "Icon_SUSBG04",
	LevelBG = "SUSBG04",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "SUS_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140628,
			Enemy = {
				{
					Value = 242084,
					Level = 209,
					Weight = 100,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 10900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242093,
					Level = 211,
					Weight = 120,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 14800,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242104,
					Level = 210,
					Weight = 120,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 17200,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 242105,
					Level = 218,
					Weight = 120,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 17800,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242106,
					Level = 226,
					Weight = 180,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 21300,
					NeedElementList = {
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 242107,
					Level = 240,
					Weight = 360,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 3600,
					FightPower = 25500,
					NeedElementList = {
						{
							Element = 210005,
							Count = 2,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140627,
			Enemy = {
				{
					Value = 242084,
					Level = 209,
					Weight = 100,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 10900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242093,
					Level = 211,
					Weight = 120,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 14800,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242104,
					Level = 210,
					Weight = 120,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 17200,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 242105,
					Level = 218,
					Weight = 120,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 17800,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242106,
					Level = 226,
					Weight = 180,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 21300,
					NeedElementList = {
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140626,
			Enemy = {
				{
					Value = 242084,
					Level = 209,
					Weight = 100,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 10900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242093,
					Level = 211,
					Weight = 120,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 14800,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242104,
					Level = 210,
					Weight = 120,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 17200,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 242105,
					Level = 218,
					Weight = 120,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 17800,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140625,
			Enemy = {
				{
					Value = 242084,
					Level = 209,
					Weight = 100,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 10900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242093,
					Level = 211,
					Weight = 120,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 14800,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242104,
					Level = 210,
					Weight = 120,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 17200,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242084,
					Level = 209,
					Weight = 100,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 10900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242093,
					Level = 211,
					Weight = 120,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 14800,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
	},
	Challenge = {
		140625,
		140626,
		140627,
		140628,
	},
	EventList = {
		310627,
		310628,
		310629,
	},
}
AreaConfig[AreaID.Id159] =
{
	Id = 159,
	Name = "审讯大厅",
	Planet = 120004,
	Level = 113,
	AreaElement = 210005,
	NumCap = 5,
	Map = "SUS_map_09",
	LevelIcon = "Icon_SUSBG04",
	LevelBG = "SUSBG04",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "SUS_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140631,
			Enemy = {
				{
					Value = 242092,
					Level = 212,
					Weight = 181,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 14400,
				},
				{
					Value = 242101,
					Level = 214,
					Weight = 181,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 17000,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 242104,
					Level = 216,
					Weight = 181,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 17200,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 242108,
					Level = 235,
					Weight = 181,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 19200,
					NeedElementList = {
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 242109,
					Level = 240,
					Weight = 272,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 22500,
					NeedElementList = {
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140630,
			Enemy = {
				{
					Value = 242092,
					Level = 212,
					Weight = 181,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 14400,
				},
				{
					Value = 242101,
					Level = 214,
					Weight = 181,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 17000,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 242104,
					Level = 216,
					Weight = 181,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 17200,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 242108,
					Level = 235,
					Weight = 181,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 19200,
					NeedElementList = {
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 242109,
					Level = 240,
					Weight = 272,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 22500,
					NeedElementList = {
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140629,
			Enemy = {
				{
					Value = 242092,
					Level = 212,
					Weight = 181,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 14400,
				},
				{
					Value = 242101,
					Level = 214,
					Weight = 181,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 17000,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 242104,
					Level = 216,
					Weight = 181,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 17200,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 242108,
					Level = 235,
					Weight = 181,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 19200,
					NeedElementList = {
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242092,
					Level = 212,
					Weight = 181,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 14400,
				},
				{
					Value = 242101,
					Level = 214,
					Weight = 181,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 17000,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 242104,
					Level = 216,
					Weight = 181,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 17200,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
			},
		},
	},
	Challenge = {
		140629,
		140630,
		140631,
	},
	EventList = {
		310630,
		310631,
		310632,
		310633,
		310634,
	},
}
AreaConfig[AreaID.Id160] =
{
	Id = 160,
	Name = "失物招领局",
	Planet = 120004,
	Level = 124,
	AreaElement = 210005,
	NumCap = 5,
	Map = "SUS_map_10",
	LevelIcon = "Icon_SUSBG02",
	LevelBG = "SUSBG02",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "SUS_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140633,
			Enemy = {
				{
					Value = 242084,
					Level = 244,
					Weight = 121,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 10900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242087,
					Level = 246,
					Weight = 146,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 13800,
				},
				{
					Value = 242098,
					Level = 248,
					Weight = 146,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 16800,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242110,
					Level = 250,
					Weight = 146,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 20400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242111,
					Level = 255,
					Weight = 439,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 3600,
					FightPower = 27000,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140632,
			Enemy = {
				{
					Value = 242084,
					Level = 244,
					Weight = 121,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 10900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242087,
					Level = 246,
					Weight = 146,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 13800,
				},
				{
					Value = 242098,
					Level = 248,
					Weight = 146,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 16800,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242110,
					Level = 250,
					Weight = 146,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 20400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242084,
					Level = 244,
					Weight = 121,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 10900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242087,
					Level = 246,
					Weight = 146,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 13800,
				},
				{
					Value = 242098,
					Level = 248,
					Weight = 146,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 16800,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
			},
		},
	},
	Challenge = {
		140632,
		140633,
	},
	EventList = {
		310635,
		310636,
		310637,
		310638,
	},
}
AreaConfig[AreaID.Id161] =
{
	Id = 161,
	Name = "编辑部",
	Planet = 120004,
	Level = 119,
	AreaElement = 210005,
	NumCap = 5,
	Map = "SUS_map_11",
	LevelIcon = "Icon_SUSBG04",
	LevelBG = "SUSBG04",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "SUS_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140636,
			Enemy = {
				{
					Value = 242090,
					Level = 227,
					Weight = 181,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 15600,
				},
				{
					Value = 242101,
					Level = 229,
					Weight = 181,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 17000,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 242108,
					Level = 231,
					Weight = 181,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 19200,
					NeedElementList = {
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 242112,
					Level = 242,
					Weight = 181,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 19800,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242113,
					Level = 248,
					Weight = 272,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 23300,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140635,
			Enemy = {
				{
					Value = 242090,
					Level = 227,
					Weight = 181,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 15600,
				},
				{
					Value = 242101,
					Level = 229,
					Weight = 181,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 17000,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 242108,
					Level = 231,
					Weight = 181,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 19200,
					NeedElementList = {
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 242112,
					Level = 242,
					Weight = 181,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 19800,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242113,
					Level = 248,
					Weight = 272,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 23300,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140634,
			Enemy = {
				{
					Value = 242090,
					Level = 227,
					Weight = 181,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 15600,
				},
				{
					Value = 242101,
					Level = 229,
					Weight = 181,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 17000,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 242108,
					Level = 231,
					Weight = 181,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 19200,
					NeedElementList = {
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 242112,
					Level = 242,
					Weight = 181,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 19800,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242090,
					Level = 227,
					Weight = 181,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 15600,
				},
				{
					Value = 242101,
					Level = 229,
					Weight = 181,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 17000,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 242108,
					Level = 231,
					Weight = 181,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 19200,
					NeedElementList = {
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
			},
		},
	},
	Challenge = {
		140634,
		140635,
		140636,
	},
	EventList = {
		310639,
		310640,
		310641,
		310642,
		310643,
		310644,
	},
}
AreaConfig[AreaID.Id162] =
{
	Id = 162,
	Name = "侦探街",
	Planet = 120004,
	Level = 123,
	AreaElement = 210005,
	NumCap = 5,
	Map = "SUS_map_12",
	LevelIcon = "Icon_SUSBG02",
	LevelBG = "SUSBG02",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "SUS_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140640,
			Enemy = {
				{
					Value = 242092,
					Level = 232,
					Weight = 142,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 14400,
				},
				{
					Value = 242085,
					Level = 234,
					Weight = 214,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 18400,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242098,
					Level = 236,
					Weight = 142,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 16800,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242114,
					Level = 250,
					Weight = 142,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 20400,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242115,
					Level = 254,
					Weight = 142,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 20700,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242116,
					Level = 258,
					Weight = 214,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 24200,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140639,
			Enemy = {
				{
					Value = 242092,
					Level = 232,
					Weight = 142,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 14400,
				},
				{
					Value = 242085,
					Level = 234,
					Weight = 214,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 18400,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242098,
					Level = 236,
					Weight = 142,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 16800,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242114,
					Level = 250,
					Weight = 142,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 20400,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242115,
					Level = 254,
					Weight = 142,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 20700,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242116,
					Level = 258,
					Weight = 214,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 24200,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140638,
			Enemy = {
				{
					Value = 242092,
					Level = 232,
					Weight = 142,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 14400,
				},
				{
					Value = 242085,
					Level = 234,
					Weight = 214,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 18400,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242098,
					Level = 236,
					Weight = 142,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 16800,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242114,
					Level = 250,
					Weight = 142,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 20400,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242115,
					Level = 254,
					Weight = 142,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 20700,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140637,
			Enemy = {
				{
					Value = 242092,
					Level = 232,
					Weight = 142,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 14400,
				},
				{
					Value = 242085,
					Level = 234,
					Weight = 214,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 18400,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242098,
					Level = 236,
					Weight = 142,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 16800,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242114,
					Level = 250,
					Weight = 142,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 20400,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242092,
					Level = 232,
					Weight = 142,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 14400,
				},
				{
					Value = 242085,
					Level = 234,
					Weight = 214,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 18400,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242098,
					Level = 236,
					Weight = 142,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 16800,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
			},
		},
	},
	Challenge = {
		140637,
		140638,
		140639,
		140640,
	},
	EventList = {
		310645,
		310646,
		310647,
		310648,
		310649,
		310650,
	},
}
AreaConfig[AreaID.Id163] =
{
	Id = 163,
	Name = "实验室",
	Planet = 120004,
	Level = 143,
	AreaElement = 210005,
	NumCap = 5,
	Map = "SUS_map_13",
	LevelIcon = "Icon_SUSBG04",
	LevelBG = "SUSBG04",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "SUS_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140644,
			Enemy = {
				{
					Value = 242114,
					Level = 280,
					Weight = 117,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 20400,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242112,
					Level = 283,
					Weight = 117,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 19800,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242110,
					Level = 285,
					Weight = 117,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 20400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242117,
					Level = 275,
					Weight = 117,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 22400,
				},
				{
					Value = 242086,
					Level = 285,
					Weight = 176,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 26700,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 242118,
					Level = 299,
					Weight = 352,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 3600,
					FightPower = 31600,
					NeedElementList = {
						{
							Element = 210001,
							Count = 2,
						},
						{
							Element = 210004,
							Count = 1,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140643,
			Enemy = {
				{
					Value = 242114,
					Level = 280,
					Weight = 117,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 20400,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242112,
					Level = 283,
					Weight = 117,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 19800,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242110,
					Level = 285,
					Weight = 117,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 20400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242117,
					Level = 275,
					Weight = 117,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 22400,
				},
				{
					Value = 242086,
					Level = 285,
					Weight = 176,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 26700,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 242118,
					Level = 299,
					Weight = 352,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 3600,
					FightPower = 31600,
					NeedElementList = {
						{
							Element = 210001,
							Count = 2,
						},
						{
							Element = 210004,
							Count = 1,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140642,
			Enemy = {
				{
					Value = 242114,
					Level = 280,
					Weight = 117,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 20400,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242112,
					Level = 283,
					Weight = 117,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 19800,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242110,
					Level = 285,
					Weight = 117,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 20400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242117,
					Level = 275,
					Weight = 117,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 22400,
				},
				{
					Value = 242086,
					Level = 285,
					Weight = 176,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 26700,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140641,
			Enemy = {
				{
					Value = 242114,
					Level = 280,
					Weight = 117,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 20400,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242112,
					Level = 283,
					Weight = 117,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 19800,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242110,
					Level = 285,
					Weight = 117,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 20400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242117,
					Level = 275,
					Weight = 117,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 22400,
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242114,
					Level = 280,
					Weight = 117,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 20400,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242112,
					Level = 283,
					Weight = 117,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 19800,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242110,
					Level = 285,
					Weight = 117,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 20400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
			},
		},
	},
	Challenge = {
		140641,
		140642,
		140643,
		140644,
	},
	EventList = {
		310651,
		310652,
		310653,
		310654,
	},
}
