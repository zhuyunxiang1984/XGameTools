PetConfig ={};
PetID = 
{
	Id001 = 250001,
	Id002 = 250002,
	Id003 = 250003,
	Id004 = 250004,
	Id005 = 250005,
	Id006 = 250006,
	Id007 = 250007,
	Id008 = 250008,
	Id009 = 250009,
	Id010 = 250010,
	Id011 = 250011,
	Id012 = 250012,
	Id013 = 250013,
	Id014 = 250014,
	Id015 = 250015,
	Id016 = 250016,
	Id017 = 250017,
	Id018 = 250018,
	Id019 = 250019,
	Id020 = 250020,
	Id021 = 250021,
	Id022 = 250022,
	Id023 = 250023,
	Id024 = 250024,
	Id025 = 250025,
	Id026 = 250026,
	Id027 = 250027,
	Id028 = 250028,
	Id029 = 250029,
	Id030 = 250030,
	Id031 = 250031,
	Id032 = 250032,
	Id033 = 250033,
	Id034 = 250034,
	Id035 = 250035,
	Id036 = 250036,
	Id037 = 250037,
	Id038 = 250038,
	Id039 = 250039,
	Id040 = 250040,
	Id041 = 250041,
	Id042 = 250042,
	Id043 = 250043,
	Id044 = 250044,
	Id045 = 250045,
	Id046 = 250046,
	Id047 = 250047,
	Id048 = 250048,
	Id049 = 250049,
	Id050 = 250050,
	Id051 = 250051,
	Id052 = 250052,
	Id053 = 250053,
	Id054 = 250054,
	Id055 = 250055,
	Id056 = 250056,
	Id057 = 250057,
	Id058 = 250058,
	Id059 = 250059,
	Id060 = 250060,
	Id061 = 250061,
	Id062 = 250062,
	Id063 = 250063,
	Id064 = 250064,
	Id065 = 250065,
	Id066 = 250066,
	Id067 = 250067,
	Id068 = 250068,
	Id069 = 250069,
	Id070 = 250070,
	Id071 = 250071,
	Id072 = 250072,
	Id073 = 250073,
	Id074 = 250074,
	Id075 = 250075,
	Id076 = 250076,
	Id077 = 250077,
	Id078 = 250078,
	Id079 = 250079,
	Id080 = 250080,
	Id081 = 250081,
	Id082 = 250082,
	Id083 = 250083,
	Id084 = 250084,
	Id085 = 250085,
	Id086 = 250086,
	Id087 = 250087,
	Id088 = 250088,
	Id089 = 250089,
	Id090 = 250090,
	Id091 = 250091,
	Id092 = 250092,
	Id093 = 250093,
	Id094 = 250094,
	Id095 = 250095,
	Id096 = 250096,
	Id097 = 250097,
	Id098 = 250098,
	Id099 = 250099,
	Id100 = 250100,
	Id101 = 250101,
	Id102 = 250102,
	Id103 = 250103,
	Id104 = 250104,
	Id105 = 250105,
	Id106 = 250106,
	Id107 = 250107,
	Id108 = 250108,
	Id109 = 250109,
	Id110 = 250110,
	Id111 = 250111,
	Id112 = 250112,
	Id113 = 250113,
	Id114 = 250114,
	Id115 = 250115,
	Id116 = 250116,
	Id117 = 250117,
	Id118 = 250118,
	Id119 = 250119,
	Id120 = 250120,
	Id121 = 250121,
	Id122 = 250122,
	Id123 = 250123,
	Id124 = 250124,
	Id125 = 250125,
	Id126 = 250126,
	Id127 = 250127,
	Id128 = 250128,
	Id129 = 250129,
	Id130 = 250130,
	Id131 = 250131,
	Id132 = 250132,
	Id133 = 250133,
	Id134 = 250134,
	Id135 = 250135,
	Id136 = 250136,
	Id137 = 250137,
	Id138 = 250138,
	Id139 = 250139,
	Id140 = 250140,
	Id141 = 250141,
	Id142 = 250142,
	Id143 = 250143,
	Id144 = 250144,
	Id145 = 250145,
	Id146 = 250146,
	Id147 = 250147,
	Id148 = 250148,
	Id149 = 250149,
	Id150 = 250150,
	Id501 = 250501,
	Id502 = 250502,
	Id503 = 250503,
	Id504 = 250504,
	Id505 = 250505,
	Id506 = 250506,
	Id507 = 250507,
	Id508 = 250508,
	Id509 = 250509,
	Id510 = 250510,
	Id511 = 250511,
	Id512 = 250512,
	Id513 = 250513,
	Id514 = 250514,
	Id515 = 250515,
	Id516 = 250516,
	Id517 = 250517,
	Id518 = 250518,
	Id519 = 250519,
	Id520 = 250520,
	Id521 = 250521,
	Id522 = 250522,
	Id523 = 250523,
	Id524 = 250524,
	Id525 = 250525,
	Id526 = 250526,
	Id527 = 250527,
	Id528 = 250528,
	Id529 = 250529,
	Id530 = 250530,
	Id531 = 250531,
	Id1001 = 251001,
	Id1002 = 251002,
	Id1003 = 251003,
	Id1201 = 251201,
	Id1202 = 251202,
	Id1401 = 251401,
	Id1402 = 251402,
	Id1601 = 251601,
	Id1602 = 251602,
	Id1801 = 251801,
	Id1802 = 251802,
	Id1803 = 251803,
	Id1804 = 251804,
	Id2001 = 252001,
	Id2002 = 252002,
}
PetConfig[PetID.Id001] =
{
	Id = 1,
	Name = "绿色史莱姆",
	Area = 
	{
		130001,
		130004,
		130003,
		130002,
	},
	Rarity = 1,
	Element = 210003,
	Gallery = 950001,
	Desc = "体内带有大量绿色素的小精灵，喜欢捡冒险者丢掉的东西，被它碰到的东西就会被染成绿色，不要丢下帽子。",
	LevelUp = 910001,
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_green",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_green",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 35, Gain = 140},
		{Value = 200004, Base = 0, Gain = 0},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102001,
					Value = 6,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102001,
					Value = 9,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102001,
					Value = 12,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102001,
					Value = 15,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102001,
					Value = 18,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102001,
					Value = 21,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102001,
					Value = 24,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102001,
					Value = 27,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102001,
					Value = 30,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102001,
					Value = 33,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102001,
					Value = 36,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102001,
					Value = 39,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102001,
					Value = 42,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320301,
			CatchChance = 50,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560022,
		560042,
		560043,
		560044,
		560045,
		560046,
		560032,
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561204,
		561305,
		561323,
		563102,
		563203,
		563620,
		563708,
		563805,
		563305,
		563403,
		563502,
		563939,
		564020,
		564012,
		564143,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id002] =
{
	Id = 2,
	Name = "蓝色史莱姆",
	Area = 
	{
		130005,
		130006,
	},
	Rarity = 1,
	Element = 210001,
	Gallery = 950001,
	Desc = "体内带有大量蓝色素的小精灵，喜欢捡冒险者丢掉的东西，被它碰到的东西就会被染成蓝色。",
	LevelUp = 910001,
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_blue",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_blue",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWater",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 35, Gain = 140},
		{Value = 200004, Base = 0, Gain = 0},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102002,
					Value = 6,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102002,
					Value = 9,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102002,
					Value = 12,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102002,
					Value = 15,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102002,
					Value = 18,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102002,
					Value = 21,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102002,
					Value = 24,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102002,
					Value = 27,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102002,
					Value = 30,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102002,
					Value = 33,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102002,
					Value = 36,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102002,
					Value = 39,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102002,
					Value = 42,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320301,
			CatchChance = 50,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560022,
		560042,
		560043,
		560044,
		560045,
		560046,
		560032,
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561202,
		561305,
		561323,
		563102,
		563203,
		563620,
		563708,
		563805,
		563305,
		563402,
		563502,
		563934,
		564020,
		564012,
		564119,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id003] =
{
	Id = 3,
	Name = "紫色史莱姆",
	Area = 
	{
		130007,
		130008,
	},
	Rarity = 1,
	Element = 210005,
	Gallery = 950001,
	Desc = "体内带有大量紫色素的小精灵，喜欢捡冒险者丢掉的东西，被它碰到的东西就会被染成紫色。",
	LevelUp = 910001,
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_purple",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_purple",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectDark",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 35, Gain = 140},
		{Value = 200004, Base = 0, Gain = 0},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102003,
					Value = 6,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102003,
					Value = 9,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102003,
					Value = 12,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102003,
					Value = 15,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102003,
					Value = 18,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102003,
					Value = 21,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102003,
					Value = 24,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102003,
					Value = 27,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102003,
					Value = 30,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102003,
					Value = 33,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102003,
					Value = 36,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102003,
					Value = 39,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102003,
					Value = 42,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320301,
			CatchChance = 50,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560022,
		560042,
		560043,
		560044,
		560045,
		560046,
		560032,
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561206,
		561305,
		561323,
		563102,
		563203,
		563620,
		563708,
		563805,
		563305,
		563403,
		563502,
		563949,
		564020,
		564012,
		564129,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id004] =
{
	Id = 4,
	Name = "红色史莱姆",
	Area = 
	{
		130009,
		130011,
		130010,
	},
	Rarity = 1,
	Element = 210002,
	Gallery = 950001,
	Desc = "体内带有大量红色素的小精灵，喜欢捡冒险者丢掉的东西，被它碰到的东西就会被染成红色，但如果碰到蓝色史莱姆就会染成紫色。",
	LevelUp = 910001,
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_red",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_red",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectFire",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 35, Gain = 140},
		{Value = 200004, Base = 0, Gain = 0},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102004,
					Value = 6,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102004,
					Value = 9,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102004,
					Value = 12,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102004,
					Value = 15,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102004,
					Value = 18,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102004,
					Value = 21,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102004,
					Value = 24,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102004,
					Value = 27,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102004,
					Value = 30,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102004,
					Value = 33,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102004,
					Value = 36,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102004,
					Value = 39,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102004,
					Value = 42,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320301,
			CatchChance = 50,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560022,
		560042,
		560043,
		560044,
		560045,
		560046,
		560032,
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561203,
		561305,
		561323,
		563102,
		563203,
		563620,
		563708,
		563805,
		563305,
		563405,
		563502,
		563919,
		564020,
		564033,
		564012,
		564114,
		564204,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id005] =
{
	Id = 5,
	Name = "花丛",
	Area = 
	{
		130002,
		130003,
	},
	Rarity = 2,
	Element = 210003,
	Gallery = 950001,
	Desc = "潜伏在路边的小花丛，以绊倒路人取乐，让对方只能忍气吞声。\n拜托，你不会是想对一朵花发火吧？",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_huacong",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_huacong",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 52, Gain = 208},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102005,
					Value = 2,
				},
			},
		},
		{
			Stage = 2,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102005,
					Value = 3,
				},
			},
		},
		{
			Stage = 3,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102005,
					Value = 4,
				},
			},
		},
		{
			Stage = 4,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102005,
					Value = 5,
				},
			},
		},
		{
			Stage = 5,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102005,
					Value = 6,
				},
			},
		},
		{
			Stage = 6,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102005,
					Value = 7,
				},
			},
		},
		{
			Stage = 7,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102005,
					Value = 8,
				},
			},
		},
		{
			Stage = 8,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102005,
					Value = 9,
				},
			},
		},
		{
			Stage = 9,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102005,
					Value = 10,
				},
			},
		},
		{
			Stage = 10,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102005,
					Value = 11,
				},
			},
		},
		{
			Stage = 11,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102005,
					Value = 12,
				},
			},
		},
		{
			Stage = 12,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102005,
					Value = 13,
				},
			},
		},
		{
			Stage = 13,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102005,
					Value = 14,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320301,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320302,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561204,
		561320,
		563102,
		563203,
		563829,
		563305,
		563403,
		563503,
		563939,
		563924,
		564050,
		564017,
		564145,
		564203,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id006] =
{
	Id = 6,
	Name = "小花球",
	Area = 
	{
		130002,
		130004,
	},
	Rarity = 2,
	Element = 210003,
	Gallery = 950001,
	Desc = "活泼好动的小花球，有时候会溜进人类的城镇里探险。不喜欢自己的名字，正在努力减肥，希望能被人叫做小花干。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_xiaohuaqiu",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_xiaohuaqiu",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 52, Gain = 208},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "风元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102006,
					Value = 3,
				},
			},
		},
		{
			Stage = 2,
			Desc = "风元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102006,
					Value = 4,
				},
			},
		},
		{
			Stage = 3,
			Desc = "风元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102006,
					Value = 5,
				},
			},
		},
		{
			Stage = 4,
			Desc = "风元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102006,
					Value = 6,
				},
			},
		},
		{
			Stage = 5,
			Desc = "风元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102006,
					Value = 7,
				},
			},
		},
		{
			Stage = 6,
			Desc = "风元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102006,
					Value = 8,
				},
			},
		},
		{
			Stage = 7,
			Desc = "风元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102006,
					Value = 9,
				},
			},
		},
		{
			Stage = 8,
			Desc = "风元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102006,
					Value = 10,
				},
			},
		},
		{
			Stage = 9,
			Desc = "风元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102006,
					Value = 11,
				},
			},
		},
		{
			Stage = 10,
			Desc = "风元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102006,
					Value = 12,
				},
			},
		},
		{
			Stage = 11,
			Desc = "风元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102006,
					Value = 13,
				},
			},
		},
		{
			Stage = 12,
			Desc = "风元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102006,
					Value = 14,
				},
			},
		},
		{
			Stage = 13,
			Desc = "风元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102006,
					Value = 15,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320301,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320302,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561204,
		561320,
		563102,
		563203,
		563619,
		563824,
		563304,
		563403,
		563503,
		563939,
		563923,
		564019,
		564014,
		564049,
		564144,
		564203,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id007] =
{
	Id = 7,
	Name = "大树怪",
	Area = 
	{
		130003,
		130004,
	},
	Rarity = 2,
	Element = 210003,
	Gallery = 950001,
	Desc = "憨直的大树怪，结出的果实美味可口，听说还帮助科学家发现了万有引力。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_dashu",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_dashu",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 52, Gain = 208},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得木材 {Value1Divide}个",
			Skill = {
				{
					Id = 102007,
					Value = 150,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得木材 {Value1Divide}个",
			Skill = {
				{
					Id = 102007,
					Value = 225,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得木材 {Value1Divide}个",
			Skill = {
				{
					Id = 102007,
					Value = 300,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得木材 {Value1Divide}个",
			Skill = {
				{
					Id = 102007,
					Value = 375,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得木材 {Value1Divide}个",
			Skill = {
				{
					Id = 102007,
					Value = 450,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得木材 {Value1Divide}个",
			Skill = {
				{
					Id = 102007,
					Value = 525,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得木材 {Value1Divide}个",
			Skill = {
				{
					Id = 102007,
					Value = 600,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得木材 {Value1Divide}个",
			Skill = {
				{
					Id = 102007,
					Value = 675,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得木材 {Value1Divide}个",
			Skill = {
				{
					Id = 102007,
					Value = 750,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得木材 {Value1Divide}个",
			Skill = {
				{
					Id = 102007,
					Value = 825,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得木材 {Value1Divide}个",
			Skill = {
				{
					Id = 102007,
					Value = 900,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得木材 {Value1Divide}个",
			Skill = {
				{
					Id = 102007,
					Value = 975,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得木材 {Value1Divide}个",
			Skill = {
				{
					Id = 102007,
					Value = 1050,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320301,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320302,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561204,
		561320,
		563102,
		563202,
		563624,
		563814,
		563304,
		563403,
		563503,
		563939,
		563943,
		564050,
		564028,
		564057,
		564146,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id008] =
{
	Id = 8,
	Name = "树桩猴",
	Area = 
	{
		130003,
		130006,
	},
	Rarity = 2,
	Element = 210003,
	Gallery = 950001,
	Desc = "生命力旺盛的树桩猴，扎在土里能长成大树，但是非常好动，根本坐不住，经常把自己连根拔起。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_shuzhuangguai",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_shuzhuangguai",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 52, Gain = 208},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "风元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102008,
					Value = 3,
				},
			},
		},
		{
			Stage = 2,
			Desc = "风元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102008,
					Value = 4,
				},
			},
		},
		{
			Stage = 3,
			Desc = "风元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102008,
					Value = 5,
				},
			},
		},
		{
			Stage = 4,
			Desc = "风元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102008,
					Value = 6,
				},
			},
		},
		{
			Stage = 5,
			Desc = "风元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102008,
					Value = 7,
				},
			},
		},
		{
			Stage = 6,
			Desc = "风元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102008,
					Value = 8,
				},
			},
		},
		{
			Stage = 7,
			Desc = "风元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102008,
					Value = 9,
				},
			},
		},
		{
			Stage = 8,
			Desc = "风元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102008,
					Value = 10,
				},
			},
		},
		{
			Stage = 9,
			Desc = "风元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102008,
					Value = 11,
				},
			},
		},
		{
			Stage = 10,
			Desc = "风元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102008,
					Value = 12,
				},
			},
		},
		{
			Stage = 11,
			Desc = "风元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102008,
					Value = 13,
				},
			},
		},
		{
			Stage = 12,
			Desc = "风元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102008,
					Value = 14,
				},
			},
		},
		{
			Stage = 13,
			Desc = "风元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102008,
					Value = 15,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320301,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320302,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561204,
		561320,
		563102,
		563205,
		563613,
		563814,
		563302,
		563403,
		563503,
		563944,
		563902,
		564014,
		564034,
		564144,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id009] =
{
	Id = 9,
	Name = "野狼",
	Area = 
	{
		130004,
		130006,
		130005,
	},
	Rarity = 2,
	Element = 210001,
	Gallery = 950001,
	Desc = "经常成群袭击路人的野兽，非常凶猛，可以用骨头引开它的注意力。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Wolf",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Wolf",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWater",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 52, Gain = 208},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "水元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102009,
					Value = 3,
				},
			},
		},
		{
			Stage = 2,
			Desc = "水元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102009,
					Value = 4,
				},
			},
		},
		{
			Stage = 3,
			Desc = "水元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102009,
					Value = 5,
				},
			},
		},
		{
			Stage = 4,
			Desc = "水元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102009,
					Value = 6,
				},
			},
		},
		{
			Stage = 5,
			Desc = "水元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102009,
					Value = 7,
				},
			},
		},
		{
			Stage = 6,
			Desc = "水元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102009,
					Value = 8,
				},
			},
		},
		{
			Stage = 7,
			Desc = "水元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102009,
					Value = 9,
				},
			},
		},
		{
			Stage = 8,
			Desc = "水元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102009,
					Value = 10,
				},
			},
		},
		{
			Stage = 9,
			Desc = "水元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102009,
					Value = 11,
				},
			},
		},
		{
			Stage = 10,
			Desc = "水元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102009,
					Value = 12,
				},
			},
		},
		{
			Stage = 11,
			Desc = "水元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102009,
					Value = 13,
				},
			},
		},
		{
			Stage = 12,
			Desc = "水元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102009,
					Value = 14,
				},
			},
		},
		{
			Stage = 13,
			Desc = "水元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102009,
					Value = 15,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320301,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320302,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561202,
		561303,
		561349,
		563102,
		563205,
		563603,
		563704,
		563823,
		563303,
		563404,
		563502,
		563929,
		564039,
		564033,
		564155,
		564204,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id010] =
{
	Id = 10,
	Name = "白狼",
	Area = 
	{
		130004,
	},
	Rarity = 3,
	Element = 210004,
	Gallery = 950001,
	Desc = "狼群的领袖，与众不同的颜色给人以强烈的压迫感。比较挑食，只接受带肉的骨头。",
	LevelUp = 910003,
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_WhiteWolf",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_WhiteWolf",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectLight",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 91, Gain = 364},
		{Value = 200004, Base = 10, Gain = 2},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "对暗元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102010,
					Value = 50,
				},
			},
		},
		{
			Stage = 2,
			Desc = "对暗元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102010,
					Value = 75,
				},
			},
		},
		{
			Stage = 3,
			Desc = "对暗元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102010,
					Value = 100,
				},
			},
		},
		{
			Stage = 4,
			Desc = "对暗元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102010,
					Value = 125,
				},
			},
		},
		{
			Stage = 5,
			Desc = "对暗元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102010,
					Value = 150,
				},
			},
		},
		{
			Stage = 6,
			Desc = "对暗元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102010,
					Value = 175,
				},
			},
		},
		{
			Stage = 7,
			Desc = "对暗元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102010,
					Value = 200,
				},
			},
		},
		{
			Stage = 8,
			Desc = "对暗元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102010,
					Value = 225,
				},
			},
		},
		{
			Stage = 9,
			Desc = "对暗元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102010,
					Value = 250,
				},
			},
		},
		{
			Stage = 10,
			Desc = "对暗元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102010,
					Value = 275,
				},
			},
		},
		{
			Stage = 11,
			Desc = "对暗元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102010,
					Value = 300,
				},
			},
		},
		{
			Stage = 12,
			Desc = "对暗元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102010,
					Value = 325,
				},
			},
		},
		{
			Stage = 13,
			Desc = "对暗元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102010,
					Value = 350,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320302,
			CatchChance = 30,
			CatchChanceGain = 5,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 25,
			SuccessChanceGain = 2,
			SuccessChanceMax = 100,
		},
		{
			Value = 320303,
			CatchChance = 50,
			CatchChanceGain = 10,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561205,
		561303,
		561349,
		563102,
		563205,
		563705,
		563824,
		563302,
		563404,
		563502,
		563905,
		564040,
		564029,
		564009,
		564154,
		564204,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id011] =
{
	Id = 11,
	Name = "祭祀石",
	Area = 
	{
		130005,
		130008,
	},
	Rarity = 2,
	Element = 210004,
	Gallery = 950001,
	Desc = "古代神庙祭祀用的大石头，能够驱邪，家里如果闹鬼，可以搬一块回家。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_dashitou",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_dashitou",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectLight",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 52, Gain = 208},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102011,
					Value = -10,
				},
			},
		},
		{
			Stage = 2,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102011,
					Value = -15,
				},
			},
		},
		{
			Stage = 3,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102011,
					Value = -20,
				},
			},
		},
		{
			Stage = 4,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102011,
					Value = -25,
				},
			},
		},
		{
			Stage = 5,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102011,
					Value = -30,
				},
			},
		},
		{
			Stage = 6,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102011,
					Value = -35,
				},
			},
		},
		{
			Stage = 7,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102011,
					Value = -40,
				},
			},
		},
		{
			Stage = 8,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102011,
					Value = -45,
				},
			},
		},
		{
			Stage = 9,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102011,
					Value = -50,
				},
			},
		},
		{
			Stage = 10,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102011,
					Value = -55,
				},
			},
		},
		{
			Stage = 11,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102011,
					Value = -60,
				},
			},
		},
		{
			Stage = 12,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102011,
					Value = -65,
				},
			},
		},
		{
			Stage = 13,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102011,
					Value = -70,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320301,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320302,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561205,
		561321,
		561325,
		563102,
		563202,
		563620,
		563815,
		563304,
		563403,
		563502,
		563929,
		564029,
		564057,
		564114,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id012] =
{
	Id = 12,
	Name = "小石怪",
	Area = 
	{
		130005,
	},
	Rarity = 2,
	Element = 210004,
	Gallery = 950001,
	Desc = "出没在山地的石怪，喜欢躲在暗处听冒险者讲传奇故事，被发现的话就会害羞得装成石头。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_xiaoshiguai",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_xiaoshiguai",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectLight",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 52, Gain = 208},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得矿石 {Value1Divide}个",
			Skill = {
				{
					Id = 102012,
					Value = 140,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得矿石 {Value1Divide}个",
			Skill = {
				{
					Id = 102012,
					Value = 210,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得矿石 {Value1Divide}个",
			Skill = {
				{
					Id = 102012,
					Value = 280,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得矿石 {Value1Divide}个",
			Skill = {
				{
					Id = 102012,
					Value = 350,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得矿石 {Value1Divide}个",
			Skill = {
				{
					Id = 102012,
					Value = 420,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得矿石 {Value1Divide}个",
			Skill = {
				{
					Id = 102012,
					Value = 490,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得矿石 {Value1Divide}个",
			Skill = {
				{
					Id = 102012,
					Value = 560,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得矿石 {Value1Divide}个",
			Skill = {
				{
					Id = 102012,
					Value = 630,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得矿石 {Value1Divide}个",
			Skill = {
				{
					Id = 102012,
					Value = 700,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得矿石 {Value1Divide}个",
			Skill = {
				{
					Id = 102012,
					Value = 770,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得矿石 {Value1Divide}个",
			Skill = {
				{
					Id = 102012,
					Value = 840,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得矿石 {Value1Divide}个",
			Skill = {
				{
					Id = 102012,
					Value = 910,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得矿石 {Value1Divide}个",
			Skill = {
				{
					Id = 102012,
					Value = 980,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320301,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320302,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561205,
		561321,
		561325,
		563102,
		563203,
		563619,
		563815,
		563303,
		563402,
		563502,
		563929,
		564029,
		564023,
		564114,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id013] =
{
	Id = 13,
	Name = "石巨人",
	Area = 
	{
		130005,
	},
	Rarity = 3,
	Element = 210004,
	Gallery = 950001,
	Desc = "平原的守护者，对其他生物很不友好。其实是个慢性子，说话结巴，最大的梦想是有人能听完它的自我介绍。",
	LevelUp = 910003,
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Stoneman",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Stoneman",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectLight",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 91, Gain = 364},
		{Value = 200004, Base = 10, Gain = 2},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102013,
					Value = 5,
				},
			},
		},
		{
			Stage = 2,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102013,
					Value = 7,
				},
			},
		},
		{
			Stage = 3,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102013,
					Value = 9,
				},
			},
		},
		{
			Stage = 4,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102013,
					Value = 11,
				},
			},
		},
		{
			Stage = 5,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102013,
					Value = 13,
				},
			},
		},
		{
			Stage = 6,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102013,
					Value = 15,
				},
			},
		},
		{
			Stage = 7,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102013,
					Value = 17,
				},
			},
		},
		{
			Stage = 8,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102013,
					Value = 19,
				},
			},
		},
		{
			Stage = 9,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102013,
					Value = 21,
				},
			},
		},
		{
			Stage = 10,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102013,
					Value = 23,
				},
			},
		},
		{
			Stage = 11,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102013,
					Value = 25,
				},
			},
		},
		{
			Stage = 12,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102013,
					Value = 27,
				},
			},
		},
		{
			Stage = 13,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102013,
					Value = 29,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320302,
			CatchChance = 30,
			CatchChanceGain = 5,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 25,
			SuccessChanceGain = 2,
			SuccessChanceMax = 100,
		},
		{
			Value = 320303,
			CatchChance = 50,
			CatchChanceGain = 10,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561205,
		561321,
		561325,
		563102,
		563202,
		563615,
		563815,
		563303,
		563402,
		563503,
		563929,
		563938,
		564030,
		564050,
		564057,
		564114,
		564143,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id014] =
{
	Id = 14,
	Name = "小土包",
	Area = 
	{
		130006,
		130007,
	},
	Rarity = 2,
	Element = 210003,
	Gallery = 950001,
	Desc = "最恨人说烂泥扶不上墙，一旦听到就会发飙。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_ruannidui",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_ruannidui",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 52, Gain = 208},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得地图 {Value1Divide}个",
			Skill = {
				{
					Id = 102014,
					Value = 130,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得地图 {Value1Divide}个",
			Skill = {
				{
					Id = 102014,
					Value = 195,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得地图 {Value1Divide}个",
			Skill = {
				{
					Id = 102014,
					Value = 260,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得地图 {Value1Divide}个",
			Skill = {
				{
					Id = 102014,
					Value = 325,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得地图 {Value1Divide}个",
			Skill = {
				{
					Id = 102014,
					Value = 390,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得地图 {Value1Divide}个",
			Skill = {
				{
					Id = 102014,
					Value = 455,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得地图 {Value1Divide}个",
			Skill = {
				{
					Id = 102014,
					Value = 520,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得地图 {Value1Divide}个",
			Skill = {
				{
					Id = 102014,
					Value = 585,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得地图 {Value1Divide}个",
			Skill = {
				{
					Id = 102014,
					Value = 650,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得地图 {Value1Divide}个",
			Skill = {
				{
					Id = 102014,
					Value = 715,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得地图 {Value1Divide}个",
			Skill = {
				{
					Id = 102014,
					Value = 780,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得地图 {Value1Divide}个",
			Skill = {
				{
					Id = 102014,
					Value = 845,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得地图 {Value1Divide}个",
			Skill = {
				{
					Id = 102014,
					Value = 910,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320305,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320306,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561204,
		561321,
		561326,
		563103,
		563203,
		563618,
		563813,
		563303,
		563404,
		563502,
		563944,
		564150,
		564143,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id015] =
{
	Id = 15,
	Name = "地缚灵",
	Area = 
	{
		130006,
	},
	Rarity = 2,
	Element = 210005,
	Gallery = 950001,
	Desc = "出没在遗迹附近的精灵，以死去之人残存的气息为食，如果惹到了它，它会偷偷跟在你后面，找机会绊你一跤。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_chouniguai",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_chouniguai",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectDark",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 52, Gain = 208},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，暗元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102015,
					Value = 3,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，暗元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102015,
					Value = 4,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，暗元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102015,
					Value = 5,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，暗元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102015,
					Value = 6,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，暗元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102015,
					Value = 7,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，暗元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102015,
					Value = 8,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，暗元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102015,
					Value = 9,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，暗元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102015,
					Value = 10,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，暗元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102015,
					Value = 11,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，暗元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102015,
					Value = 12,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，暗元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102015,
					Value = 13,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，暗元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102015,
					Value = 14,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，暗元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102015,
					Value = 15,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320305,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320306,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561206,
		561305,
		561326,
		563103,
		563203,
		563618,
		563813,
		563303,
		563404,
		563503,
		563944,
		563912,
		564004,
		564024,
		564057,
		564150,
		564105,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id016] =
{
	Id = 16,
	Name = "沼泽地",
	Area = 
	{
		130007,
		130010,
		130008,
	},
	Rarity = 2,
	Element = 210001,
	Gallery = 950001,
	Desc = "躲在沼泽地区不起眼的怪物，只顾看攻略没看路的冒险者踩上去后会被快速吞没。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_zhaozedi",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_zhaozedi",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWater",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 52, Gain = 208},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102016,
					Value = 2,
				},
			},
		},
		{
			Stage = 2,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102016,
					Value = 3,
				},
			},
		},
		{
			Stage = 3,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102016,
					Value = 4,
				},
			},
		},
		{
			Stage = 4,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102016,
					Value = 5,
				},
			},
		},
		{
			Stage = 5,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102016,
					Value = 6,
				},
			},
		},
		{
			Stage = 6,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102016,
					Value = 7,
				},
			},
		},
		{
			Stage = 7,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102016,
					Value = 8,
				},
			},
		},
		{
			Stage = 8,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102016,
					Value = 9,
				},
			},
		},
		{
			Stage = 9,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102016,
					Value = 10,
				},
			},
		},
		{
			Stage = 10,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102016,
					Value = 11,
				},
			},
		},
		{
			Stage = 11,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102016,
					Value = 12,
				},
			},
		},
		{
			Stage = 12,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102016,
					Value = 13,
				},
			},
		},
		{
			Stage = 13,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102016,
					Value = 14,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320305,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320306,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561202,
		561321,
		561326,
		563103,
		563203,
		563609,
		563709,
		563804,
		563303,
		563404,
		563502,
		563949,
		564149,
		564104,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id017] =
{
	Id = 17,
	Name = "泥怪",
	Area = 
	{
		130007,
	},
	Rarity = 2,
	Element = 210001,
	Gallery = 950001,
	Desc = "拥有很强粘性的魔物，即使是凶猛的野兽，如果被它困住，最后也难逃厄运。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_niannianguai",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_niannianguai",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWater",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 52, Gain = 208},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得粘液 {Value1Divide}个",
			Skill = {
				{
					Id = 102017,
					Value = 130,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得粘液 {Value1Divide}个",
			Skill = {
				{
					Id = 102017,
					Value = 195,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得粘液 {Value1Divide}个",
			Skill = {
				{
					Id = 102017,
					Value = 260,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得粘液 {Value1Divide}个",
			Skill = {
				{
					Id = 102017,
					Value = 325,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得粘液 {Value1Divide}个",
			Skill = {
				{
					Id = 102017,
					Value = 390,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得粘液 {Value1Divide}个",
			Skill = {
				{
					Id = 102017,
					Value = 455,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得粘液 {Value1Divide}个",
			Skill = {
				{
					Id = 102017,
					Value = 520,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得粘液 {Value1Divide}个",
			Skill = {
				{
					Id = 102017,
					Value = 585,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得粘液 {Value1Divide}个",
			Skill = {
				{
					Id = 102017,
					Value = 650,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得粘液 {Value1Divide}个",
			Skill = {
				{
					Id = 102017,
					Value = 715,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得粘液 {Value1Divide}个",
			Skill = {
				{
					Id = 102017,
					Value = 780,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得粘液 {Value1Divide}个",
			Skill = {
				{
					Id = 102017,
					Value = 845,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得粘液 {Value1Divide}个",
			Skill = {
				{
					Id = 102017,
					Value = 910,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320305,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320306,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561202,
		561321,
		561326,
		563103,
		563203,
		563609,
		563710,
		563819,
		563303,
		563404,
		563502,
		563950,
		564004,
		564150,
		564104,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id018] =
{
	Id = 18,
	Name = "沼泽树精",
	Area = 
	{
		130007,
	},
	Rarity = 3,
	Element = 210003,
	Gallery = 950001,
	Desc = "吸取树木精华为生的精灵，说不清是植物还是精灵，负责净化沼泽地区的空气质量。",
	LevelUp = 910003,
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_xiaoshuyang",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_xiaoshuyang",
	PrefabScale = 60,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 91, Gain = 364},
		{Value = 200004, Base = 10, Gain = 2},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102018,
					Value = -3,
				},
			},
		},
		{
			Stage = 2,
			Desc = "敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102018,
					Value = -4,
				},
			},
		},
		{
			Stage = 3,
			Desc = "敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102018,
					Value = -5,
				},
			},
		},
		{
			Stage = 4,
			Desc = "敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102018,
					Value = -6,
				},
			},
		},
		{
			Stage = 5,
			Desc = "敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102018,
					Value = -7,
				},
			},
		},
		{
			Stage = 6,
			Desc = "敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102018,
					Value = -8,
				},
			},
		},
		{
			Stage = 7,
			Desc = "敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102018,
					Value = -9,
				},
			},
		},
		{
			Stage = 8,
			Desc = "敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102018,
					Value = -10,
				},
			},
		},
		{
			Stage = 9,
			Desc = "敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102018,
					Value = -11,
				},
			},
		},
		{
			Stage = 10,
			Desc = "敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102018,
					Value = -12,
				},
			},
		},
		{
			Stage = 11,
			Desc = "敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102018,
					Value = -13,
				},
			},
		},
		{
			Stage = 12,
			Desc = "敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102018,
					Value = -14,
				},
			},
		},
		{
			Stage = 13,
			Desc = "敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102018,
					Value = -15,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320302,
			CatchChance = 30,
			CatchChanceGain = 5,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 25,
			SuccessChanceGain = 2,
			SuccessChanceMax = 100,
		},
		{
			Value = 320303,
			CatchChance = 50,
			CatchChanceGain = 10,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561204,
		561320,
		561305,
		563102,
		563203,
		563614,
		563808,
		563303,
		563403,
		563503,
		563939,
		563944,
		564024,
		564048,
		564057,
		564149,
		564145,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id019] =
{
	Id = 19,
	Name = "刺毛怪",
	Area = 
	{
		130008,
		130009,
	},
	Rarity = 2,
	Element = 210005,
	Gallery = 950001,
	Desc = "在任何地区都能悠闲漫步的魔物。遇到危险时，就会竖起身上的钢针进行抵御。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_SeaUrchin",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_SeaUrchin",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectDark",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 52, Gain = 208},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得钢刺 {Value1Divide}个",
			Skill = {
				{
					Id = 102019,
					Value = 120,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得钢刺 {Value1Divide}个",
			Skill = {
				{
					Id = 102019,
					Value = 180,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得钢刺 {Value1Divide}个",
			Skill = {
				{
					Id = 102019,
					Value = 240,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得钢刺 {Value1Divide}个",
			Skill = {
				{
					Id = 102019,
					Value = 300,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得钢刺 {Value1Divide}个",
			Skill = {
				{
					Id = 102019,
					Value = 360,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得钢刺 {Value1Divide}个",
			Skill = {
				{
					Id = 102019,
					Value = 420,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得钢刺 {Value1Divide}个",
			Skill = {
				{
					Id = 102019,
					Value = 480,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得钢刺 {Value1Divide}个",
			Skill = {
				{
					Id = 102019,
					Value = 540,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得钢刺 {Value1Divide}个",
			Skill = {
				{
					Id = 102019,
					Value = 600,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得钢刺 {Value1Divide}个",
			Skill = {
				{
					Id = 102019,
					Value = 660,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得钢刺 {Value1Divide}个",
			Skill = {
				{
					Id = 102019,
					Value = 720,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得钢刺 {Value1Divide}个",
			Skill = {
				{
					Id = 102019,
					Value = 780,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得钢刺 {Value1Divide}个",
			Skill = {
				{
					Id = 102019,
					Value = 840,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320301,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320302,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561206,
		561303,
		561327,
		563102,
		563203,
		563809,
		563303,
		563403,
		563503,
		563919,
		563922,
		564039,
		564154,
		564114,
		564204,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id020] =
{
	Id = 20,
	Name = "钢铁刺毛怪",
	Area = 
	{
		130008,
	},
	Rarity = 4,
	Element = 210005,
	Gallery = 950001,
	Desc = "年龄超过两百岁的超级刺毛怪，身上的钢针带有令人麻痹的毒液，是令人无法靠近的存在。",
	LevelUp = 910004,
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_BigSeaUrchin",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_BigSeaUrchin",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectDark",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 140, Gain = 560},
		{Value = 200004, Base = 15, Gain = 3},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102020,
					Value = 4,
				},
			},
		},
		{
			Stage = 2,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102020,
					Value = 6,
				},
			},
		},
		{
			Stage = 3,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102020,
					Value = 8,
				},
			},
		},
		{
			Stage = 4,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102020,
					Value = 10,
				},
			},
		},
		{
			Stage = 5,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102020,
					Value = 12,
				},
			},
		},
		{
			Stage = 6,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102020,
					Value = 14,
				},
			},
		},
		{
			Stage = 7,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102020,
					Value = 16,
				},
			},
		},
		{
			Stage = 8,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102020,
					Value = 18,
				},
			},
		},
		{
			Stage = 9,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102020,
					Value = 20,
				},
			},
		},
		{
			Stage = 10,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102020,
					Value = 22,
				},
			},
		},
		{
			Stage = 11,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102020,
					Value = 24,
				},
			},
		},
		{
			Stage = 12,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102020,
					Value = 26,
				},
			},
		},
		{
			Stage = 13,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102020,
					Value = 28,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320302,
			CatchChance = 5,
			CatchChanceGain = 12,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 5,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
		{
			Value = 320303,
			CatchChance = 33,
			CatchChanceGain = 25,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 33,
			SuccessChanceGain = 4,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560025,
		560045,
		560046,
		560032,
		560033,
		560034,
		560035,
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561206,
		561303,
		561327,
		563102,
		563203,
		563810,
		563302,
		563403,
		563503,
		563914,
		563923,
		564040,
		564029,
		564154,
		564114,
		564204,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id021] =
{
	Id = 21,
	Name = "火喷泉",
	Area = 
	{
		130009,
		130010,
	},
	Rarity = 2,
	Element = 210002,
	Gallery = 950001,
	Desc = "无论快乐或悲伤，都会通过喷发岩浆来宣泄情绪。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_FireFountain",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_FireFountain",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectFire",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 52, Gain = 208},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得沙堆 {Value1Divide}个",
			Skill = {
				{
					Id = 102021,
					Value = 110,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得沙堆 {Value1Divide}个",
			Skill = {
				{
					Id = 102021,
					Value = 165,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得沙堆 {Value1Divide}个",
			Skill = {
				{
					Id = 102021,
					Value = 220,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得沙堆 {Value1Divide}个",
			Skill = {
				{
					Id = 102021,
					Value = 275,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得沙堆 {Value1Divide}个",
			Skill = {
				{
					Id = 102021,
					Value = 330,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得沙堆 {Value1Divide}个",
			Skill = {
				{
					Id = 102021,
					Value = 385,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得沙堆 {Value1Divide}个",
			Skill = {
				{
					Id = 102021,
					Value = 440,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得沙堆 {Value1Divide}个",
			Skill = {
				{
					Id = 102021,
					Value = 495,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得沙堆 {Value1Divide}个",
			Skill = {
				{
					Id = 102021,
					Value = 550,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得沙堆 {Value1Divide}个",
			Skill = {
				{
					Id = 102021,
					Value = 605,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得沙堆 {Value1Divide}个",
			Skill = {
				{
					Id = 102021,
					Value = 660,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得沙堆 {Value1Divide}个",
			Skill = {
				{
					Id = 102021,
					Value = 715,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得沙堆 {Value1Divide}个",
			Skill = {
				{
					Id = 102021,
					Value = 770,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320305,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320306,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561203,
		561321,
		561351,
		561326,
		563103,
		563203,
		563609,
		563809,
		563303,
		563405,
		563502,
		563919,
		564114,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id022] =
{
	Id = 22,
	Name = "小火山",
	Area = 
	{
		130009,
	},
	Rarity = 2,
	Element = 210004,
	Gallery = 950001,
	Desc = "只想做一个安静美男子的景观类魔物，火山口的熔岩刘海经常引来300%的回头率。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Volcano",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Volcano",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectLight",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 52, Gain = 208},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "光元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102022,
					Value = 3,
				},
			},
		},
		{
			Stage = 2,
			Desc = "光元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102022,
					Value = 4,
				},
			},
		},
		{
			Stage = 3,
			Desc = "光元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102022,
					Value = 5,
				},
			},
		},
		{
			Stage = 4,
			Desc = "光元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102022,
					Value = 6,
				},
			},
		},
		{
			Stage = 5,
			Desc = "光元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102022,
					Value = 7,
				},
			},
		},
		{
			Stage = 6,
			Desc = "光元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102022,
					Value = 8,
				},
			},
		},
		{
			Stage = 7,
			Desc = "光元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102022,
					Value = 9,
				},
			},
		},
		{
			Stage = 8,
			Desc = "光元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102022,
					Value = 10,
				},
			},
		},
		{
			Stage = 9,
			Desc = "光元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102022,
					Value = 11,
				},
			},
		},
		{
			Stage = 10,
			Desc = "光元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102022,
					Value = 12,
				},
			},
		},
		{
			Stage = 11,
			Desc = "光元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102022,
					Value = 13,
				},
			},
		},
		{
			Stage = 12,
			Desc = "光元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102022,
					Value = 14,
				},
			},
		},
		{
			Stage = 13,
			Desc = "光元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102022,
					Value = 15,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320305,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320306,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561205,
		561321,
		561351,
		563103,
		563203,
		563623,
		563809,
		563304,
		563405,
		563503,
		563919,
		563944,
		564029,
		564114,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id023] =
{
	Id = 23,
	Name = "小火球",
	Area = 
	{
		130010,
		130011,
	},
	Rarity = 2,
	Element = 210002,
	Gallery = 950001,
	Desc = "数据证明，百分之九十九的冒险家无法分清不同的小火球。\n它从岩浆里跳了起来，它掉了下去。\n它的兄弟从岩浆里跳了起来。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Fireball",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Fireball",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectFire",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 52, Gain = 208},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102023,
					Value = 3,
				},
			},
		},
		{
			Stage = 2,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102023,
					Value = 4,
				},
			},
		},
		{
			Stage = 3,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102023,
					Value = 5,
				},
			},
		},
		{
			Stage = 4,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102023,
					Value = 6,
				},
			},
		},
		{
			Stage = 5,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102023,
					Value = 7,
				},
			},
		},
		{
			Stage = 6,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102023,
					Value = 8,
				},
			},
		},
		{
			Stage = 7,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102023,
					Value = 9,
				},
			},
		},
		{
			Stage = 8,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102023,
					Value = 10,
				},
			},
		},
		{
			Stage = 9,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102023,
					Value = 11,
				},
			},
		},
		{
			Stage = 10,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102023,
					Value = 12,
				},
			},
		},
		{
			Stage = 11,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102023,
					Value = 13,
				},
			},
		},
		{
			Stage = 12,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102023,
					Value = 14,
				},
			},
		},
		{
			Stage = 13,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102023,
					Value = 15,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320305,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320306,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561203,
		561305,
		561351,
		563103,
		563205,
		563620,
		563809,
		563303,
		563405,
		563502,
		563919,
		564020,
		564033,
		564113,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id024] =
{
	Id = 24,
	Name = "熔岩猪",
	Area = 
	{
		130010,
		130011,
	},
	Rarity = 2,
	Element = 210002,
	Gallery = 950001,
	Desc = "被魔王收养的宠物猪，在高热的情况下会发出肉香，用来诱惑来到火山地区的冒险家分泌口水，使其加速脱水而失去战斗能力。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_LavaPig",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_LavaPig",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectFire",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 52, Gain = 208},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得炭石 {Value1Divide}个",
			Skill = {
				{
					Id = 102024,
					Value = 110,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得炭石 {Value1Divide}个",
			Skill = {
				{
					Id = 102024,
					Value = 165,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得炭石 {Value1Divide}个",
			Skill = {
				{
					Id = 102024,
					Value = 220,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得炭石 {Value1Divide}个",
			Skill = {
				{
					Id = 102024,
					Value = 275,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得炭石 {Value1Divide}个",
			Skill = {
				{
					Id = 102024,
					Value = 330,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得炭石 {Value1Divide}个",
			Skill = {
				{
					Id = 102024,
					Value = 385,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得炭石 {Value1Divide}个",
			Skill = {
				{
					Id = 102024,
					Value = 440,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得炭石 {Value1Divide}个",
			Skill = {
				{
					Id = 102024,
					Value = 495,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得炭石 {Value1Divide}个",
			Skill = {
				{
					Id = 102024,
					Value = 550,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得炭石 {Value1Divide}个",
			Skill = {
				{
					Id = 102024,
					Value = 605,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得炭石 {Value1Divide}个",
			Skill = {
				{
					Id = 102024,
					Value = 660,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得炭石 {Value1Divide}个",
			Skill = {
				{
					Id = 102024,
					Value = 715,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得炭石 {Value1Divide}个",
			Skill = {
				{
					Id = 102024,
					Value = 770,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320301,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320302,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561203,
		561303,
		561351,
		561329,
		563102,
		563204,
		563603,
		563809,
		563305,
		563405,
		563503,
		563919,
		563922,
		564004,
		564154,
		564124,
		564204,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id025] =
{
	Id = 25,
	Name = "火山巨蟹",
	Area = 
	{
		130010,
	},
	Rarity = 3,
	Element = 210004,
	Gallery = 950001,
	Desc = "挥舞着两只强力巨钳的高级魔物，不过更出名的是其鲜美的肉质，是美食家们梦寐以求的高级海鲜。常与熔岩猪一起出马，加速冒险家的脱水危机。",
	LevelUp = 910003,
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Firecrab",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Firecrab",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectLight",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 91, Gain = 364},
		{Value = 200004, Base = 10, Gain = 2},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102025,
					Value = 4,
				},
			},
		},
		{
			Stage = 2,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102025,
					Value = 6,
				},
			},
		},
		{
			Stage = 3,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102025,
					Value = 8,
				},
			},
		},
		{
			Stage = 4,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102025,
					Value = 10,
				},
			},
		},
		{
			Stage = 5,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102025,
					Value = 12,
				},
			},
		},
		{
			Stage = 6,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102025,
					Value = 14,
				},
			},
		},
		{
			Stage = 7,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102025,
					Value = 16,
				},
			},
		},
		{
			Stage = 8,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102025,
					Value = 18,
				},
			},
		},
		{
			Stage = 9,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102025,
					Value = 20,
				},
			},
		},
		{
			Stage = 10,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102025,
					Value = 22,
				},
			},
		},
		{
			Stage = 11,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102025,
					Value = 24,
				},
			},
		},
		{
			Stage = 12,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102025,
					Value = 26,
				},
			},
		},
		{
			Stage = 13,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102025,
					Value = 28,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320302,
			CatchChance = 30,
			CatchChanceGain = 5,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 25,
			SuccessChanceGain = 2,
			SuccessChanceMax = 100,
		},
		{
			Value = 320303,
			CatchChance = 50,
			CatchChanceGain = 10,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561205,
		561303,
		561351,
		561330,
		563102,
		563203,
		563810,
		563304,
		563405,
		563503,
		563919,
		563944,
		564029,
		564004,
		564109,
		564114,
		564205,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id026] =
{
	Id = 26,
	Name = "火精灵",
	Area = 
	{
		130011,
	},
	Rarity = 2,
	Element = 210002,
	Gallery = 950001,
	Desc = "以矿石为食的精灵，体内有大量燃烧结晶。吃矿石的时候喜欢放凉再吃，它怕烫。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Salamander",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Salamander",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectFire",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 52, Gain = 208},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得火焰结晶 {Value1Divide}个",
			Skill = {
				{
					Id = 102026,
					Value = 90,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得火焰结晶 {Value1Divide}个",
			Skill = {
				{
					Id = 102026,
					Value = 135,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得火焰结晶 {Value1Divide}个",
			Skill = {
				{
					Id = 102026,
					Value = 180,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得火焰结晶 {Value1Divide}个",
			Skill = {
				{
					Id = 102026,
					Value = 225,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得火焰结晶 {Value1Divide}个",
			Skill = {
				{
					Id = 102026,
					Value = 270,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得火焰结晶 {Value1Divide}个",
			Skill = {
				{
					Id = 102026,
					Value = 315,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得火焰结晶 {Value1Divide}个",
			Skill = {
				{
					Id = 102026,
					Value = 360,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得火焰结晶 {Value1Divide}个",
			Skill = {
				{
					Id = 102026,
					Value = 405,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得火焰结晶 {Value1Divide}个",
			Skill = {
				{
					Id = 102026,
					Value = 450,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得火焰结晶 {Value1Divide}个",
			Skill = {
				{
					Id = 102026,
					Value = 495,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得火焰结晶 {Value1Divide}个",
			Skill = {
				{
					Id = 102026,
					Value = 540,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得火焰结晶 {Value1Divide}个",
			Skill = {
				{
					Id = 102026,
					Value = 585,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得火焰结晶 {Value1Divide}个",
			Skill = {
				{
					Id = 102026,
					Value = 630,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320305,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320306,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561203,
		561305,
		561351,
		563103,
		563205,
		563615,
		563810,
		563303,
		563405,
		563503,
		563919,
		563912,
		564004,
		564014,
		564024,
		564113,
		564203,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id027] =
{
	Id = 27,
	Name = "火焰巨人",
	Area = 
	{
		130011,
	},
	Rarity = 4,
	Element = 210002,
	Gallery = 950001,
	Desc = "火山的可怕魔物，喷吐的烈焰可以融化矿石，是魔王城堡当之无愧的强者。",
	LevelUp = 910004,
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_GiantFire",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_GiantFire",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectFire",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 140, Gain = 560},
		{Value = 200004, Base = 15, Gain = 3},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "暴率 +{Value1}%，暴击伤害 +{Value2}%",
			Skill = {
				{
					Id = 102027,
					Value = 20,
				},
				{
					Id = 102028,
					Value = 50,
				},
			},
		},
		{
			Stage = 2,
			Desc = "暴率 +{Value1}%，暴击伤害 +{Value2}%",
			Skill = {
				{
					Id = 102027,
					Value = 30,
				},
				{
					Id = 102028,
					Value = 75,
				},
			},
		},
		{
			Stage = 3,
			Desc = "暴率 +{Value1}%，暴击伤害 +{Value2}%",
			Skill = {
				{
					Id = 102027,
					Value = 40,
				},
				{
					Id = 102028,
					Value = 100,
				},
			},
		},
		{
			Stage = 4,
			Desc = "暴率 +{Value1}%，暴击伤害 +{Value2}%",
			Skill = {
				{
					Id = 102027,
					Value = 50,
				},
				{
					Id = 102028,
					Value = 125,
				},
			},
		},
		{
			Stage = 5,
			Desc = "暴率 +{Value1}%，暴击伤害 +{Value2}%",
			Skill = {
				{
					Id = 102027,
					Value = 60,
				},
				{
					Id = 102028,
					Value = 150,
				},
			},
		},
		{
			Stage = 6,
			Desc = "暴率 +{Value1}%，暴击伤害 +{Value2}%",
			Skill = {
				{
					Id = 102027,
					Value = 70,
				},
				{
					Id = 102028,
					Value = 175,
				},
			},
		},
		{
			Stage = 7,
			Desc = "暴率 +{Value1}%，暴击伤害 +{Value2}%",
			Skill = {
				{
					Id = 102027,
					Value = 80,
				},
				{
					Id = 102028,
					Value = 200,
				},
			},
		},
		{
			Stage = 8,
			Desc = "暴率 +{Value1}%，暴击伤害 +{Value2}%",
			Skill = {
				{
					Id = 102027,
					Value = 90,
				},
				{
					Id = 102028,
					Value = 225,
				},
			},
		},
		{
			Stage = 9,
			Desc = "暴率 +{Value1}%，暴击伤害 +{Value2}%",
			Skill = {
				{
					Id = 102027,
					Value = 100,
				},
				{
					Id = 102028,
					Value = 250,
				},
			},
		},
		{
			Stage = 10,
			Desc = "暴率 +{Value1}%，暴击伤害 +{Value2}%",
			Skill = {
				{
					Id = 102027,
					Value = 110,
				},
				{
					Id = 102028,
					Value = 275,
				},
			},
		},
		{
			Stage = 11,
			Desc = "暴率 +{Value1}%，暴击伤害 +{Value2}%",
			Skill = {
				{
					Id = 102027,
					Value = 120,
				},
				{
					Id = 102028,
					Value = 300,
				},
			},
		},
		{
			Stage = 12,
			Desc = "暴率 +{Value1}%，暴击伤害 +{Value2}%",
			Skill = {
				{
					Id = 102027,
					Value = 130,
				},
				{
					Id = 102028,
					Value = 325,
				},
			},
		},
		{
			Stage = 13,
			Desc = "暴率 +{Value1}%，暴击伤害 +{Value2}%",
			Skill = {
				{
					Id = 102027,
					Value = 140,
				},
				{
					Id = 102028,
					Value = 350,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320306,
			CatchChance = 5,
			CatchChanceGain = 12,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 5,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
		{
			Value = 320307,
			CatchChance = 33,
			CatchChanceGain = 25,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 33,
			SuccessChanceGain = 4,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560025,
		560045,
		560046,
		560032,
		560033,
		560034,
		560035,
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561203,
		561305,
		561351,
		563103,
		563203,
		563615,
		563810,
		563302,
		563406,
		563503,
		563914,
		563919,
		564031,
		564035,
		564115,
		564204,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id028] =
{
	Id = 28,
	Name = "草莓",
	Area = 
	{
		130051,
		130055,
		130054,
		130053,
		130052,
	},
	Rarity = 1,
	Element = 210003,
	Gallery = 950002,
	Desc = "味道酸甜清爽的草莓，经常作为甜点的装饰品出现。因为大部分冒险家不想弄一手黏黏的汁水，所以某些程度上也是个棘手的敌人。",
	LevelUp = 910001,
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_Strawberry",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_Strawberry",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 40, Gain = 160},
		{Value = 200004, Base = 0, Gain = 0},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "水元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102029,
					Value = -3,
				},
			},
		},
		{
			Stage = 2,
			Desc = "水元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102029,
					Value = -4,
				},
			},
		},
		{
			Stage = 3,
			Desc = "水元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102029,
					Value = -5,
				},
			},
		},
		{
			Stage = 4,
			Desc = "水元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102029,
					Value = -6,
				},
			},
		},
		{
			Stage = 5,
			Desc = "水元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102029,
					Value = -7,
				},
			},
		},
		{
			Stage = 6,
			Desc = "水元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102029,
					Value = -8,
				},
			},
		},
		{
			Stage = 7,
			Desc = "水元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102029,
					Value = -9,
				},
			},
		},
		{
			Stage = 8,
			Desc = "水元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102029,
					Value = -10,
				},
			},
		},
		{
			Stage = 9,
			Desc = "水元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102029,
					Value = -11,
				},
			},
		},
		{
			Stage = 10,
			Desc = "水元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102029,
					Value = -12,
				},
			},
		},
		{
			Stage = 11,
			Desc = "水元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102029,
					Value = -13,
				},
			},
		},
		{
			Stage = 12,
			Desc = "水元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102029,
					Value = -14,
				},
			},
		},
		{
			Stage = 13,
			Desc = "水元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102029,
					Value = -15,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320305,
			CatchChance = 50,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560022,
		560042,
		560043,
		560044,
		560045,
		560046,
		560032,
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561204,
		561320,
		561331,
		563103,
		563203,
		563619,
		563803,
		563305,
		563403,
		563502,
		563919,
		564020,
		564012,
		564130,
		564143,
		564203,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id029] =
{
	Id = 29,
	Name = "梨几",
	Area = 
	{
		130056,
	},
	Rarity = 1,
	Element = 210003,
	Gallery = 950002,
	Desc = "口感爽脆的梨几，身上长着大量雀斑，但是水分充足，十分解渴。有人听到它的名字后会误认成肉类魔物。",
	LevelUp = 910001,
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_Pear",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_Pear",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 40, Gain = 160},
		{Value = 200004, Base = 0, Gain = 0},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "全队攻击 +{Value1}%",
			Skill = {
				{
					Id = 102030,
					Value = 2,
				},
			},
		},
		{
			Stage = 2,
			Desc = "全队攻击 +{Value1}%",
			Skill = {
				{
					Id = 102030,
					Value = 3,
				},
			},
		},
		{
			Stage = 3,
			Desc = "全队攻击 +{Value1}%",
			Skill = {
				{
					Id = 102030,
					Value = 4,
				},
			},
		},
		{
			Stage = 4,
			Desc = "全队攻击 +{Value1}%",
			Skill = {
				{
					Id = 102030,
					Value = 5,
				},
			},
		},
		{
			Stage = 5,
			Desc = "全队攻击 +{Value1}%",
			Skill = {
				{
					Id = 102030,
					Value = 6,
				},
			},
		},
		{
			Stage = 6,
			Desc = "全队攻击 +{Value1}%",
			Skill = {
				{
					Id = 102030,
					Value = 7,
				},
			},
		},
		{
			Stage = 7,
			Desc = "全队攻击 +{Value1}%",
			Skill = {
				{
					Id = 102030,
					Value = 8,
				},
			},
		},
		{
			Stage = 8,
			Desc = "全队攻击 +{Value1}%",
			Skill = {
				{
					Id = 102030,
					Value = 9,
				},
			},
		},
		{
			Stage = 9,
			Desc = "全队攻击 +{Value1}%",
			Skill = {
				{
					Id = 102030,
					Value = 10,
				},
			},
		},
		{
			Stage = 10,
			Desc = "全队攻击 +{Value1}%",
			Skill = {
				{
					Id = 102030,
					Value = 11,
				},
			},
		},
		{
			Stage = 11,
			Desc = "全队攻击 +{Value1}%",
			Skill = {
				{
					Id = 102030,
					Value = 12,
				},
			},
		},
		{
			Stage = 12,
			Desc = "全队攻击 +{Value1}%",
			Skill = {
				{
					Id = 102030,
					Value = 13,
				},
			},
		},
		{
			Stage = 13,
			Desc = "全队攻击 +{Value1}%",
			Skill = {
				{
					Id = 102030,
					Value = 14,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320305,
			CatchChance = 50,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560022,
		560042,
		560043,
		560044,
		560045,
		560046,
		560032,
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561204,
		561320,
		561331,
		563103,
		563203,
		563619,
		563803,
		563305,
		563403,
		563502,
		563924,
		564020,
		564012,
		564120,
		564143,
		564203,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id030] =
{
	Id = 30,
	Name = "桃几",
	Area = 
	{
		130057,
		130059,
		130058,
	},
	Rarity = 1,
	Element = 210003,
	Gallery = 950002,
	Desc = "水分充足的蜜桃，虽然身上长着细细的绒毛，但是依然十分讨人喜爱。外表看上去软软的，其实内在是个硬汉。",
	LevelUp = 910001,
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_Peach",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_Peach",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 40, Gain = 160},
		{Value = 200004, Base = 0, Gain = 0},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "打得过的怪物出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102031,
					Value = 10,
				},
			},
		},
		{
			Stage = 2,
			Desc = "打得过的怪物出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102031,
					Value = 15,
				},
			},
		},
		{
			Stage = 3,
			Desc = "打得过的怪物出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102031,
					Value = 20,
				},
			},
		},
		{
			Stage = 4,
			Desc = "打得过的怪物出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102031,
					Value = 25,
				},
			},
		},
		{
			Stage = 5,
			Desc = "打得过的怪物出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102031,
					Value = 30,
				},
			},
		},
		{
			Stage = 6,
			Desc = "打得过的怪物出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102031,
					Value = 35,
				},
			},
		},
		{
			Stage = 7,
			Desc = "打得过的怪物出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102031,
					Value = 40,
				},
			},
		},
		{
			Stage = 8,
			Desc = "打得过的怪物出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102031,
					Value = 45,
				},
			},
		},
		{
			Stage = 9,
			Desc = "打得过的怪物出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102031,
					Value = 50,
				},
			},
		},
		{
			Stage = 10,
			Desc = "打得过的怪物出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102031,
					Value = 55,
				},
			},
		},
		{
			Stage = 11,
			Desc = "打得过的怪物出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102031,
					Value = 60,
				},
			},
		},
		{
			Stage = 12,
			Desc = "打得过的怪物出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102031,
					Value = 65,
				},
			},
		},
		{
			Stage = 13,
			Desc = "打得过的怪物出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102031,
					Value = 70,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320305,
			CatchChance = 50,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560022,
		560042,
		560043,
		560044,
		560045,
		560046,
		560032,
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561204,
		561320,
		561331,
		563103,
		563203,
		563620,
		563703,
		563803,
		563305,
		563403,
		563502,
		563909,
		564020,
		564012,
		564135,
		564143,
		564203,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id031] =
{
	Id = 31,
	Name = "苹狗",
	Area = 
	{
		130060,
		130061,
	},
	Rarity = 1,
	Element = 210003,
	Gallery = 950002,
	Desc = "营养丰富的苹狗，身体是健康的红色。最大的梦想是进化成传说中的物种——芒狗。",
	LevelUp = 910001,
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_Apple",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_Apple",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 40, Gain = 160},
		{Value = 200004, Base = 0, Gain = 0},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102032,
					Value = 2,
				},
			},
		},
		{
			Stage = 2,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102032,
					Value = 3,
				},
			},
		},
		{
			Stage = 3,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102032,
					Value = 4,
				},
			},
		},
		{
			Stage = 4,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102032,
					Value = 5,
				},
			},
		},
		{
			Stage = 5,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102032,
					Value = 6,
				},
			},
		},
		{
			Stage = 6,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102032,
					Value = 7,
				},
			},
		},
		{
			Stage = 7,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102032,
					Value = 8,
				},
			},
		},
		{
			Stage = 8,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102032,
					Value = 9,
				},
			},
		},
		{
			Stage = 9,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102032,
					Value = 10,
				},
			},
		},
		{
			Stage = 10,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102032,
					Value = 11,
				},
			},
		},
		{
			Stage = 11,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102032,
					Value = 12,
				},
			},
		},
		{
			Stage = 12,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102032,
					Value = 13,
				},
			},
		},
		{
			Stage = 13,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102032,
					Value = 14,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320305,
			CatchChance = 50,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560022,
		560042,
		560043,
		560044,
		560045,
		560046,
		560032,
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561204,
		561320,
		561331,
		563103,
		563203,
		563620,
		563813,
		563305,
		563403,
		563502,
		563919,
		564020,
		564012,
		564130,
		564143,
		564203,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id032] =
{
	Id = 32,
	Name = "阿头",
	Area = 
	{
		130052,
		130054,
		130053,
	},
	Rarity = 2,
	Element = 210002,
	Gallery = 950002,
	Desc = "非常可口的甜点，整份很难吃完，所以头部会切下来单卖。但总有客人抱怨头部的馅料太少了。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_FishHead",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_FishHead",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectFire",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 60, Gain = 240},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "火元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102033,
					Value = 3,
				},
			},
		},
		{
			Stage = 2,
			Desc = "火元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102033,
					Value = 4,
				},
			},
		},
		{
			Stage = 3,
			Desc = "火元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102033,
					Value = 5,
				},
			},
		},
		{
			Stage = 4,
			Desc = "火元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102033,
					Value = 6,
				},
			},
		},
		{
			Stage = 5,
			Desc = "火元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102033,
					Value = 7,
				},
			},
		},
		{
			Stage = 6,
			Desc = "火元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102033,
					Value = 8,
				},
			},
		},
		{
			Stage = 7,
			Desc = "火元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102033,
					Value = 9,
				},
			},
		},
		{
			Stage = 8,
			Desc = "火元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102033,
					Value = 10,
				},
			},
		},
		{
			Stage = 9,
			Desc = "火元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102033,
					Value = 11,
				},
			},
		},
		{
			Stage = 10,
			Desc = "火元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102033,
					Value = 12,
				},
			},
		},
		{
			Stage = 11,
			Desc = "火元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102033,
					Value = 13,
				},
			},
		},
		{
			Stage = 12,
			Desc = "火元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102033,
					Value = 14,
				},
			},
		},
		{
			Stage = 13,
			Desc = "火元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102033,
					Value = 15,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320309,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320310,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561203,
		561306,
		561332,
		563104,
		563203,
		563824,
		563304,
		563405,
		563503,
		563924,
		563913,
		564005,
		564135,
		564205,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id033] =
{
	Id = 33,
	Name = "阿尾",
	Area = 
	{
		130052,
	},
	Rarity = 2,
	Element = 210002,
	Gallery = 950002,
	Desc = "非常可口的甜点，整份很难吃完，所以尾巴会切下来单卖。但总有客人抱怨尾部的馅料太少了。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_FishTail",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_FishTail",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectFire",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 60, Gain = 240},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得豆沙 {Value1Divide}个",
			Skill = {
				{
					Id = 102034,
					Value = 110,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得豆沙 {Value1Divide}个",
			Skill = {
				{
					Id = 102034,
					Value = 165,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得豆沙 {Value1Divide}个",
			Skill = {
				{
					Id = 102034,
					Value = 220,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得豆沙 {Value1Divide}个",
			Skill = {
				{
					Id = 102034,
					Value = 275,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得豆沙 {Value1Divide}个",
			Skill = {
				{
					Id = 102034,
					Value = 330,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得豆沙 {Value1Divide}个",
			Skill = {
				{
					Id = 102034,
					Value = 385,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得豆沙 {Value1Divide}个",
			Skill = {
				{
					Id = 102034,
					Value = 440,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得豆沙 {Value1Divide}个",
			Skill = {
				{
					Id = 102034,
					Value = 495,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得豆沙 {Value1Divide}个",
			Skill = {
				{
					Id = 102034,
					Value = 550,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得豆沙 {Value1Divide}个",
			Skill = {
				{
					Id = 102034,
					Value = 605,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得豆沙 {Value1Divide}个",
			Skill = {
				{
					Id = 102034,
					Value = 660,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得豆沙 {Value1Divide}个",
			Skill = {
				{
					Id = 102034,
					Value = 715,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得豆沙 {Value1Divide}个",
			Skill = {
				{
					Id = 102034,
					Value = 770,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320309,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320310,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561203,
		561306,
		561332,
		563104,
		563203,
		563824,
		563304,
		563405,
		563503,
		563924,
		563913,
		564005,
		564135,
		564205,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id034] =
{
	Id = 34,
	Name = "克林姆",
	Area = 
	{
		130053,
	},
	Rarity = 2,
	Element = 210001,
	Gallery = 950002,
	Desc = "香草味的冰淇淋，加入了牛奶和香草粉制作而成，即使化开来味道也依然很好。性格热情开朗，一直渴望着一份火热的爱情。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_IceCream",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_IceCream",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWater",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 60, Gain = 240},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，水元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102035,
					Value = 3,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，水元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102035,
					Value = 4,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，水元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102035,
					Value = 5,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，水元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102035,
					Value = 6,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，水元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102035,
					Value = 7,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，水元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102035,
					Value = 8,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，水元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102035,
					Value = 9,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，水元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102035,
					Value = 10,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，水元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102035,
					Value = 11,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，水元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102035,
					Value = 12,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，水元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102035,
					Value = 13,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，水元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102035,
					Value = 14,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，水元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102035,
					Value = 15,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320305,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320306,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561202,
		561306,
		561334,
		563103,
		563203,
		563609,
		563709,
		563828,
		563304,
		563402,
		563503,
		563923,
		563909,
		564019,
		564004,
		564134,
		564205,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id035] =
{
	Id = 35,
	Name = "巧克林姆",
	Area = 
	{
		130053,
	},
	Rarity = 2,
	Element = 210001,
	Gallery = 950002,
	Desc = "巧克力味的冰淇淋，加入了牛奶和可可粉制作而成，即使化开来味道也依然很好。性格冷酷孤僻，最讨厌傻白甜。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_ChocolateIceCream",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_ChocolateIceCream",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWater",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 60, Gain = 240},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，暗元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102036,
					Value = 3,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，暗元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102036,
					Value = 4,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，暗元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102036,
					Value = 5,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，暗元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102036,
					Value = 6,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，暗元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102036,
					Value = 7,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，暗元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102036,
					Value = 8,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，暗元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102036,
					Value = 9,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，暗元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102036,
					Value = 10,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，暗元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102036,
					Value = 11,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，暗元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102036,
					Value = 12,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，暗元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102036,
					Value = 13,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，暗元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102036,
					Value = 14,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，暗元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102036,
					Value = 15,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320305,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320306,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561202,
		561306,
		561334,
		563103,
		563203,
		563609,
		563709,
		563828,
		563304,
		563402,
		563503,
		563923,
		563914,
		564019,
		564004,
		564134,
		564205,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id036] =
{
	Id = 36,
	Name = "茶克林姆",
	Area = 
	{
		130053,
		130056,
	},
	Rarity = 2,
	Element = 210001,
	Gallery = 950002,
	Desc = "抹茶味的冰淇淋，加入了牛奶和抹茶粉制作而成，即使化开来味道也依然很好。性格温文尔雅，最喜欢的是原谅别人。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_GreenTeaIceCream",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_GreenTeaIceCream",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWater",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 60, Gain = 240},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，光元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102037,
					Value = 3,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，光元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102037,
					Value = 4,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，光元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102037,
					Value = 5,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，光元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102037,
					Value = 6,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，光元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102037,
					Value = 7,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，光元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102037,
					Value = 8,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，光元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102037,
					Value = 9,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，光元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102037,
					Value = 10,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，光元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102037,
					Value = 11,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，光元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102037,
					Value = 12,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，光元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102037,
					Value = 13,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，光元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102037,
					Value = 14,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，光元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102037,
					Value = 15,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320305,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320306,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561202,
		561306,
		561334,
		563103,
		563203,
		563609,
		563709,
		563828,
		563304,
		563402,
		563503,
		563923,
		563939,
		564019,
		564004,
		564134,
		564205,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id037] =
{
	Id = 37,
	Name = "水果小糖",
	Area = 
	{
		130054,
		130055,
	},
	Rarity = 2,
	Element = 210003,
	Gallery = 950002,
	Desc = "用可食薄膜包裹的硬糖，含在嘴里可以长时间感受到酸酸甜甜的果味。对喜欢咬碎吃糖的人总是很鄙夷。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_LaffyTaffy",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_LaffyTaffy",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 60, Gain = 240},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "每3回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102038,
					Value = 6,
				},
			},
		},
		{
			Stage = 2,
			Desc = "每3回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102038,
					Value = 9,
				},
			},
		},
		{
			Stage = 3,
			Desc = "每3回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102038,
					Value = 12,
				},
			},
		},
		{
			Stage = 4,
			Desc = "每3回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102038,
					Value = 15,
				},
			},
		},
		{
			Stage = 5,
			Desc = "每3回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102038,
					Value = 18,
				},
			},
		},
		{
			Stage = 6,
			Desc = "每3回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102038,
					Value = 21,
				},
			},
		},
		{
			Stage = 7,
			Desc = "每3回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102038,
					Value = 24,
				},
			},
		},
		{
			Stage = 8,
			Desc = "每3回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102038,
					Value = 27,
				},
			},
		},
		{
			Stage = 9,
			Desc = "每3回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102038,
					Value = 30,
				},
			},
		},
		{
			Stage = 10,
			Desc = "每3回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102038,
					Value = 33,
				},
			},
		},
		{
			Stage = 11,
			Desc = "每3回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102038,
					Value = 36,
				},
			},
		},
		{
			Stage = 12,
			Desc = "每3回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102038,
					Value = 39,
				},
			},
		},
		{
			Stage = 13,
			Desc = "每3回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102038,
					Value = 42,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320305,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320306,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561204,
		561306,
		561333,
		563103,
		563203,
		563620,
		563814,
		563304,
		563403,
		563503,
		563909,
		563903,
		564020,
		564015,
		564130,
		564204,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id038] =
{
	Id = 38,
	Name = "奶小糖",
	Area = 
	{
		130054,
	},
	Rarity = 3,
	Element = 210003,
	Gallery = 950002,
	Desc = "用可食薄膜包裹的奶糖，有非常浓郁的奶香，不过含糖量非常高。自称含奶量高达百分之八十，其实是骗人的。",
	LevelUp = 910003,
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_Toffee",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_Toffee",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 102, Gain = 408},
		{Value = 200004, Base = 10, Gain = 2},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得牛奶 {Value1Divide}个",
			Skill = {
				{
					Id = 102039,
					Value = 130,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得牛奶 {Value1Divide}个",
			Skill = {
				{
					Id = 102039,
					Value = 195,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得牛奶 {Value1Divide}个",
			Skill = {
				{
					Id = 102039,
					Value = 260,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得牛奶 {Value1Divide}个",
			Skill = {
				{
					Id = 102039,
					Value = 325,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得牛奶 {Value1Divide}个",
			Skill = {
				{
					Id = 102039,
					Value = 390,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得牛奶 {Value1Divide}个",
			Skill = {
				{
					Id = 102039,
					Value = 455,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得牛奶 {Value1Divide}个",
			Skill = {
				{
					Id = 102039,
					Value = 520,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得牛奶 {Value1Divide}个",
			Skill = {
				{
					Id = 102039,
					Value = 585,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得牛奶 {Value1Divide}个",
			Skill = {
				{
					Id = 102039,
					Value = 650,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得牛奶 {Value1Divide}个",
			Skill = {
				{
					Id = 102039,
					Value = 715,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得牛奶 {Value1Divide}个",
			Skill = {
				{
					Id = 102039,
					Value = 780,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得牛奶 {Value1Divide}个",
			Skill = {
				{
					Id = 102039,
					Value = 845,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得牛奶 {Value1Divide}个",
			Skill = {
				{
					Id = 102039,
					Value = 910,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320306,
			CatchChance = 30,
			CatchChanceGain = 5,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 25,
			SuccessChanceGain = 2,
			SuccessChanceMax = 100,
		},
		{
			Value = 320307,
			CatchChance = 50,
			CatchChanceGain = 10,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561204,
		561306,
		561333,
		563103,
		563203,
		563620,
		563814,
		563303,
		563403,
		563503,
		563914,
		563903,
		564020,
		564015,
		564135,
		564204,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id039] =
{
	Id = 39,
	Name = "芒果滋",
	Area = 
	{
		130055,
		130057,
	},
	Rarity = 2,
	Element = 210005,
	Gallery = 950002,
	Desc = "浇上了调味芒果浓浆的甜甜圈，撒有饼干脆片，咬下去的第一口就会在嘴里绽放出恶魔般的甜度。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_MangoDoughnut",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_MangoDoughnut",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectDark",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 60, Gain = 240},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102040,
					Value = 4,
				},
			},
		},
		{
			Stage = 2,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102040,
					Value = 6,
				},
			},
		},
		{
			Stage = 3,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102040,
					Value = 8,
				},
			},
		},
		{
			Stage = 4,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102040,
					Value = 10,
				},
			},
		},
		{
			Stage = 5,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102040,
					Value = 12,
				},
			},
		},
		{
			Stage = 6,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102040,
					Value = 14,
				},
			},
		},
		{
			Stage = 7,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102040,
					Value = 16,
				},
			},
		},
		{
			Stage = 8,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102040,
					Value = 18,
				},
			},
		},
		{
			Stage = 9,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102040,
					Value = 20,
				},
			},
		},
		{
			Stage = 10,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102040,
					Value = 22,
				},
			},
		},
		{
			Stage = 11,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102040,
					Value = 24,
				},
			},
		},
		{
			Stage = 12,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102040,
					Value = 26,
				},
			},
		},
		{
			Stage = 13,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102040,
					Value = 28,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320309,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320310,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561206,
		561306,
		561332,
		563104,
		563205,
		563620,
		563824,
		563304,
		563403,
		563503,
		563944,
		563923,
		564033,
		564028,
		564135,
		564205,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id040] =
{
	Id = 40,
	Name = "多拿滋",
	Area = 
	{
		130055,
		130056,
	},
	Rarity = 2,
	Element = 210005,
	Gallery = 950002,
	Desc = "非常甜腻的甜甜圈，撒有饼干脆片。瞧不起芒果滋，认为借用果味力量的甜腻是异端，糖浆才是最正宗的力量。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_Doughnut",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_Doughnut",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectDark",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 60, Gain = 240},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得高标蛋 {Value1Divide}个",
			Skill = {
				{
					Id = 102041,
					Value = 100,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得高标蛋 {Value1Divide}个",
			Skill = {
				{
					Id = 102041,
					Value = 150,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得高标蛋 {Value1Divide}个",
			Skill = {
				{
					Id = 102041,
					Value = 200,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得高标蛋 {Value1Divide}个",
			Skill = {
				{
					Id = 102041,
					Value = 250,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得高标蛋 {Value1Divide}个",
			Skill = {
				{
					Id = 102041,
					Value = 300,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得高标蛋 {Value1Divide}个",
			Skill = {
				{
					Id = 102041,
					Value = 350,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得高标蛋 {Value1Divide}个",
			Skill = {
				{
					Id = 102041,
					Value = 400,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得高标蛋 {Value1Divide}个",
			Skill = {
				{
					Id = 102041,
					Value = 450,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得高标蛋 {Value1Divide}个",
			Skill = {
				{
					Id = 102041,
					Value = 500,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得高标蛋 {Value1Divide}个",
			Skill = {
				{
					Id = 102041,
					Value = 550,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得高标蛋 {Value1Divide}个",
			Skill = {
				{
					Id = 102041,
					Value = 600,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得高标蛋 {Value1Divide}个",
			Skill = {
				{
					Id = 102041,
					Value = 650,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得高标蛋 {Value1Divide}个",
			Skill = {
				{
					Id = 102041,
					Value = 700,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320309,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320310,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561206,
		561306,
		561332,
		563104,
		563206,
		563620,
		563824,
		563304,
		563403,
		563503,
		563909,
		563913,
		564033,
		564027,
		564135,
		564205,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id041] =
{
	Id = 41,
	Name = "布丁呆",
	Area = 
	{
		130055,
	},
	Rarity = 3,
	Element = 210004,
	Gallery = 950002,
	Desc = "撒上了特制焦糖的布丁，走过的地方都会有布丁的香气。在此地居住的居民需要常备胰岛素。",
	LevelUp = 910003,
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_Pudding",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_Pudding",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectLight",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 102, Gain = 408},
		{Value = 200004, Base = 10, Gain = 2},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102042,
					Value = 4,
				},
			},
		},
		{
			Stage = 2,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102042,
					Value = 6,
				},
			},
		},
		{
			Stage = 3,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102042,
					Value = 8,
				},
			},
		},
		{
			Stage = 4,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102042,
					Value = 10,
				},
			},
		},
		{
			Stage = 5,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102042,
					Value = 12,
				},
			},
		},
		{
			Stage = 6,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102042,
					Value = 14,
				},
			},
		},
		{
			Stage = 7,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102042,
					Value = 16,
				},
			},
		},
		{
			Stage = 8,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102042,
					Value = 18,
				},
			},
		},
		{
			Stage = 9,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102042,
					Value = 20,
				},
			},
		},
		{
			Stage = 10,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102042,
					Value = 22,
				},
			},
		},
		{
			Stage = 11,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102042,
					Value = 24,
				},
			},
		},
		{
			Stage = 12,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102042,
					Value = 26,
				},
			},
		},
		{
			Stage = 13,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102042,
					Value = 28,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320310,
			CatchChance = 30,
			CatchChanceGain = 5,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 25,
			SuccessChanceGain = 2,
			SuccessChanceMax = 100,
		},
		{
			Value = 320311,
			CatchChance = 50,
			CatchChanceGain = 10,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561205,
		561306,
		561332,
		563104,
		563203,
		563620,
		563709,
		563804,
		563304,
		563403,
		563504,
		563924,
		563913,
		563917,
		564005,
		564022,
		564135,
		564206,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id042] =
{
	Id = 42,
	Name = "黑脸鱼子军舰",
	Area = 
	{
		130056,
		130059,
		130058,
	},
	Rarity = 2,
	Element = 210005,
	Gallery = 950002,
	Desc = "分量十足的主食，用海苔包裹了全身，头上顶着新鲜饱满的鱼子，那也是它的假发。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_FishRoeWarshipSushi",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_FishRoeWarshipSushi",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectDark",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 60, Gain = 240},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得鱼肉 {Value1Divide}个",
			Skill = {
				{
					Id = 102043,
					Value = 80,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得鱼肉 {Value1Divide}个",
			Skill = {
				{
					Id = 102043,
					Value = 120,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得鱼肉 {Value1Divide}个",
			Skill = {
				{
					Id = 102043,
					Value = 160,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得鱼肉 {Value1Divide}个",
			Skill = {
				{
					Id = 102043,
					Value = 200,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得鱼肉 {Value1Divide}个",
			Skill = {
				{
					Id = 102043,
					Value = 240,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得鱼肉 {Value1Divide}个",
			Skill = {
				{
					Id = 102043,
					Value = 280,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得鱼肉 {Value1Divide}个",
			Skill = {
				{
					Id = 102043,
					Value = 320,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得鱼肉 {Value1Divide}个",
			Skill = {
				{
					Id = 102043,
					Value = 360,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得鱼肉 {Value1Divide}个",
			Skill = {
				{
					Id = 102043,
					Value = 400,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得鱼肉 {Value1Divide}个",
			Skill = {
				{
					Id = 102043,
					Value = 440,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得鱼肉 {Value1Divide}个",
			Skill = {
				{
					Id = 102043,
					Value = 480,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得鱼肉 {Value1Divide}个",
			Skill = {
				{
					Id = 102043,
					Value = 520,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得鱼肉 {Value1Divide}个",
			Skill = {
				{
					Id = 102043,
					Value = 560,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320301,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320302,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561206,
		561306,
		561319,
		563102,
		563203,
		563623,
		563804,
		563304,
		563403,
		563503,
		563915,
		563918,
		564024,
		564008,
		564110,
		564204,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id043] =
{
	Id = 43,
	Name = "塔可桑",
	Area = 
	{
		130056,
	},
	Rarity = 4,
	Element = 210004,
	Gallery = 950002,
	Desc = "每个塔可桑中都包裹了一块鲜美的鱿鱼块，拥有海洋的气味，对于喜欢鱿鱼的人来说是莫大的惊喜，但对于海鲜过敏的人来说则是噩梦。",
	LevelUp = 910004,
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_Takesan",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_Takesan",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectLight",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 153, Gain = 612},
		{Value = 200004, Base = 15, Gain = 3},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102044,
					Value = 6,
				},
			},
		},
		{
			Stage = 2,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102044,
					Value = 9,
				},
			},
		},
		{
			Stage = 3,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102044,
					Value = 12,
				},
			},
		},
		{
			Stage = 4,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102044,
					Value = 15,
				},
			},
		},
		{
			Stage = 5,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102044,
					Value = 18,
				},
			},
		},
		{
			Stage = 6,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102044,
					Value = 21,
				},
			},
		},
		{
			Stage = 7,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102044,
					Value = 24,
				},
			},
		},
		{
			Stage = 8,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102044,
					Value = 27,
				},
			},
		},
		{
			Stage = 9,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102044,
					Value = 30,
				},
			},
		},
		{
			Stage = 10,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102044,
					Value = 33,
				},
			},
		},
		{
			Stage = 11,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102044,
					Value = 36,
				},
			},
		},
		{
			Stage = 12,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102044,
					Value = 39,
				},
			},
		},
		{
			Stage = 13,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102044,
					Value = 42,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320310,
			CatchChance = 5,
			CatchChanceGain = 12,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 5,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
		{
			Value = 320311,
			CatchChance = 33,
			CatchChanceGain = 25,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 33,
			SuccessChanceGain = 4,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560025,
		560045,
		560046,
		560032,
		560033,
		560034,
		560035,
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561205,
		561306,
		561332,
		563104,
		563203,
		563620,
		563824,
		563305,
		563405,
		563504,
		563924,
		563903,
		563918,
		564021,
		564110,
		564139,
		564205,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id044] =
{
	Id = 44,
	Name = "饭团",
	Area = 
	{
		130057,
		130058,
	},
	Rarity = 2,
	Element = 210005,
	Gallery = 950002,
	Desc = "分量充足的主食，采用白米制作，且撒上了黑芝麻丰富口感，需要配合芥末食用。\n嘿，那是抹茶酱！",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_RiceBall",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_RiceBall",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectDark",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 60, Gain = 240},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "光元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102045,
					Value = 3,
				},
			},
		},
		{
			Stage = 2,
			Desc = "光元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102045,
					Value = 4,
				},
			},
		},
		{
			Stage = 3,
			Desc = "光元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102045,
					Value = 5,
				},
			},
		},
		{
			Stage = 4,
			Desc = "光元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102045,
					Value = 6,
				},
			},
		},
		{
			Stage = 5,
			Desc = "光元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102045,
					Value = 7,
				},
			},
		},
		{
			Stage = 6,
			Desc = "光元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102045,
					Value = 8,
				},
			},
		},
		{
			Stage = 7,
			Desc = "光元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102045,
					Value = 9,
				},
			},
		},
		{
			Stage = 8,
			Desc = "光元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102045,
					Value = 10,
				},
			},
		},
		{
			Stage = 9,
			Desc = "光元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102045,
					Value = 11,
				},
			},
		},
		{
			Stage = 10,
			Desc = "光元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102045,
					Value = 12,
				},
			},
		},
		{
			Stage = 11,
			Desc = "光元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102045,
					Value = 13,
				},
			},
		},
		{
			Stage = 12,
			Desc = "光元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102045,
					Value = 14,
				},
			},
		},
		{
			Stage = 13,
			Desc = "光元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102045,
					Value = 15,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320309,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320310,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561206,
		561306,
		561319,
		561357,
		563104,
		563203,
		563617,
		563819,
		563303,
		563404,
		563503,
		563905,
		563913,
		564004,
		564107,
		564138,
		564205,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id045] =
{
	Id = 45,
	Name = "黑米团",
	Area = 
	{
		130057,
		130059,
	},
	Rarity = 2,
	Element = 210005,
	Gallery = 950002,
	Desc = "分量充足的主食，采用血糯米制作，口感非常筋道。\n不，不是巧克力味的，别想了。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_BlackRiceBall",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_BlackRiceBall",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectDark",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 60, Gain = 240},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得米饭 {Value1Divide}个",
			Skill = {
				{
					Id = 102046,
					Value = 90,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得米饭 {Value1Divide}个",
			Skill = {
				{
					Id = 102046,
					Value = 135,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得米饭 {Value1Divide}个",
			Skill = {
				{
					Id = 102046,
					Value = 180,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得米饭 {Value1Divide}个",
			Skill = {
				{
					Id = 102046,
					Value = 225,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得米饭 {Value1Divide}个",
			Skill = {
				{
					Id = 102046,
					Value = 270,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得米饭 {Value1Divide}个",
			Skill = {
				{
					Id = 102046,
					Value = 315,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得米饭 {Value1Divide}个",
			Skill = {
				{
					Id = 102046,
					Value = 360,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得米饭 {Value1Divide}个",
			Skill = {
				{
					Id = 102046,
					Value = 405,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得米饭 {Value1Divide}个",
			Skill = {
				{
					Id = 102046,
					Value = 450,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得米饭 {Value1Divide}个",
			Skill = {
				{
					Id = 102046,
					Value = 495,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得米饭 {Value1Divide}个",
			Skill = {
				{
					Id = 102046,
					Value = 540,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得米饭 {Value1Divide}个",
			Skill = {
				{
					Id = 102046,
					Value = 585,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得米饭 {Value1Divide}个",
			Skill = {
				{
					Id = 102046,
					Value = 630,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320309,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320310,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561206,
		561306,
		561319,
		561357,
		563104,
		563203,
		563617,
		563819,
		563304,
		563404,
		563502,
		563916,
		564004,
		564023,
		564107,
		564118,
		564205,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id046] =
{
	Id = 46,
	Name = "泡菜团",
	Area = 
	{
		130057,
	},
	Rarity = 2,
	Element = 210005,
	Gallery = 950002,
	Desc = "分量充足的主食，对于想要吃清淡食物的食客具有开胃效果。\n明明是辣的，怎么会清淡呢？",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_CabbageRiceBall",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_CabbageRiceBall",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectDark",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 60, Gain = 240},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "光元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102047,
					Value = -4,
				},
			},
		},
		{
			Stage = 2,
			Desc = "光元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102047,
					Value = -6,
				},
			},
		},
		{
			Stage = 3,
			Desc = "光元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102047,
					Value = -8,
				},
			},
		},
		{
			Stage = 4,
			Desc = "光元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102047,
					Value = -10,
				},
			},
		},
		{
			Stage = 5,
			Desc = "光元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102047,
					Value = -12,
				},
			},
		},
		{
			Stage = 6,
			Desc = "光元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102047,
					Value = -14,
				},
			},
		},
		{
			Stage = 7,
			Desc = "光元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102047,
					Value = -16,
				},
			},
		},
		{
			Stage = 8,
			Desc = "光元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102047,
					Value = -18,
				},
			},
		},
		{
			Stage = 9,
			Desc = "光元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102047,
					Value = -20,
				},
			},
		},
		{
			Stage = 10,
			Desc = "光元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102047,
					Value = -22,
				},
			},
		},
		{
			Stage = 11,
			Desc = "光元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102047,
					Value = -24,
				},
			},
		},
		{
			Stage = 12,
			Desc = "光元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102047,
					Value = -26,
				},
			},
		},
		{
			Stage = 13,
			Desc = "光元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102047,
					Value = -28,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320309,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320310,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561206,
		561306,
		561319,
		561357,
		563104,
		563203,
		563617,
		563819,
		563304,
		563404,
		563503,
		563925,
		563913,
		564004,
		564107,
		564163,
		564205,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id047] =
{
	Id = 47,
	Name = "夹心肉球",
	Area = 
	{
		130058,
		130060,
	},
	Rarity = 2,
	Element = 210002,
	Gallery = 950002,
	Desc = "不添加任何面粉的纯肉丸子，内部有特制的肉馅作为馅料，温度很高，很容易烫伤食客们。对此它毫无自觉，总是劝大家趁热吃。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_MeatBalls",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_MeatBalls",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectFire",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 60, Gain = 240},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得料酒 {Value1Divide}个",
			Skill = {
				{
					Id = 102048,
					Value = 80,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得料酒 {Value1Divide}个",
			Skill = {
				{
					Id = 102048,
					Value = 120,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得料酒 {Value1Divide}个",
			Skill = {
				{
					Id = 102048,
					Value = 160,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得料酒 {Value1Divide}个",
			Skill = {
				{
					Id = 102048,
					Value = 200,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得料酒 {Value1Divide}个",
			Skill = {
				{
					Id = 102048,
					Value = 240,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得料酒 {Value1Divide}个",
			Skill = {
				{
					Id = 102048,
					Value = 280,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得料酒 {Value1Divide}个",
			Skill = {
				{
					Id = 102048,
					Value = 320,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得料酒 {Value1Divide}个",
			Skill = {
				{
					Id = 102048,
					Value = 360,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得料酒 {Value1Divide}个",
			Skill = {
				{
					Id = 102048,
					Value = 400,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得料酒 {Value1Divide}个",
			Skill = {
				{
					Id = 102048,
					Value = 440,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得料酒 {Value1Divide}个",
			Skill = {
				{
					Id = 102048,
					Value = 480,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得料酒 {Value1Divide}个",
			Skill = {
				{
					Id = 102048,
					Value = 520,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得料酒 {Value1Divide}个",
			Skill = {
				{
					Id = 102048,
					Value = 560,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320305,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320306,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561203,
		561306,
		561312,
		563103,
		563203,
		563620,
		563819,
		563304,
		563405,
		563502,
		563946,
		564015,
		564139,
		564205,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id048] =
{
	Id = 48,
	Name = "铛噗灵",
	Area = 
	{
		130058,
	},
	Rarity = 3,
	Element = 210001,
	Gallery = 950002,
	Desc = "薄薄的皮料包裹着各种食材的主食，搭配调料后，会在嘴中爆发出难以言喻的美味。\n经过星际翻译法的协调，现在统一规定叫饺子。",
	LevelUp = 910003,
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_Dumplings",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_Dumplings",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWater",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 102, Gain = 408},
		{Value = 200004, Base = 10, Gain = 2},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "火元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102049,
					Value = 10,
				},
			},
		},
		{
			Stage = 2,
			Desc = "火元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102049,
					Value = 15,
				},
			},
		},
		{
			Stage = 3,
			Desc = "火元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102049,
					Value = 20,
				},
			},
		},
		{
			Stage = 4,
			Desc = "火元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102049,
					Value = 25,
				},
			},
		},
		{
			Stage = 5,
			Desc = "火元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102049,
					Value = 30,
				},
			},
		},
		{
			Stage = 6,
			Desc = "火元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102049,
					Value = 35,
				},
			},
		},
		{
			Stage = 7,
			Desc = "火元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102049,
					Value = 40,
				},
			},
		},
		{
			Stage = 8,
			Desc = "火元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102049,
					Value = 45,
				},
			},
		},
		{
			Stage = 9,
			Desc = "火元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102049,
					Value = 50,
				},
			},
		},
		{
			Stage = 10,
			Desc = "火元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102049,
					Value = 55,
				},
			},
		},
		{
			Stage = 11,
			Desc = "火元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102049,
					Value = 60,
				},
			},
		},
		{
			Stage = 12,
			Desc = "火元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102049,
					Value = 65,
				},
			},
		},
		{
			Stage = 13,
			Desc = "火元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102049,
					Value = 70,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320310,
			CatchChance = 30,
			CatchChanceGain = 5,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 25,
			SuccessChanceGain = 2,
			SuccessChanceMax = 100,
		},
		{
			Value = 320311,
			CatchChance = 50,
			CatchChanceGain = 10,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561202,
		561306,
		561319,
		563104,
		563203,
		563618,
		563804,
		563303,
		563405,
		563502,
		563904,
		564040,
		564139,
		564205,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id049] =
{
	Id = 49,
	Name = "玉子龟龟",
	Area = 
	{
		130059,
		130060,
	},
	Rarity = 2,
	Element = 210004,
	Gallery = 950002,
	Desc = "使用顶级匠人烹制的超美味蛋料理作为食材的寿司精灵，日常散步时经常让路人产生吃它的冲动。\n龟龟，这不就是鸡蛋吗？",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_EggSushi",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_EggSushi",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectLight",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 60, Gain = 240},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "暗元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102050,
					Value = -4,
				},
			},
		},
		{
			Stage = 2,
			Desc = "暗元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102050,
					Value = -6,
				},
			},
		},
		{
			Stage = 3,
			Desc = "暗元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102050,
					Value = -8,
				},
			},
		},
		{
			Stage = 4,
			Desc = "暗元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102050,
					Value = -10,
				},
			},
		},
		{
			Stage = 5,
			Desc = "暗元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102050,
					Value = -12,
				},
			},
		},
		{
			Stage = 6,
			Desc = "暗元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102050,
					Value = -14,
				},
			},
		},
		{
			Stage = 7,
			Desc = "暗元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102050,
					Value = -16,
				},
			},
		},
		{
			Stage = 8,
			Desc = "暗元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102050,
					Value = -18,
				},
			},
		},
		{
			Stage = 9,
			Desc = "暗元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102050,
					Value = -20,
				},
			},
		},
		{
			Stage = 10,
			Desc = "暗元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102050,
					Value = -22,
				},
			},
		},
		{
			Stage = 11,
			Desc = "暗元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102050,
					Value = -24,
				},
			},
		},
		{
			Stage = 12,
			Desc = "暗元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102050,
					Value = -26,
				},
			},
		},
		{
			Stage = 13,
			Desc = "暗元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102050,
					Value = -28,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320301,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320302,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561205,
		561306,
		561319,
		563102,
		563203,
		563622,
		563819,
		563304,
		563403,
		563504,
		563924,
		563903,
		563912,
		564005,
		564107,
		564139,
		564205,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id050] =
{
	Id = 50,
	Name = "寿司龟龟",
	Area = 
	{
		130059,
		130061,
	},
	Rarity = 2,
	Element = 210004,
	Gallery = 950002,
	Desc = "采用了最高级的鱼背肉部位作为食材的寿司精灵，日常散步时经常让路人产生吃它的冲动。\n龟龟，这不就是米饭吗？",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_SalmonSushi",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_SalmonSushi",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectLight",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 60, Gain = 240},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "暗元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102051,
					Value = 10,
				},
			},
		},
		{
			Stage = 2,
			Desc = "暗元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102051,
					Value = 15,
				},
			},
		},
		{
			Stage = 3,
			Desc = "暗元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102051,
					Value = 20,
				},
			},
		},
		{
			Stage = 4,
			Desc = "暗元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102051,
					Value = 25,
				},
			},
		},
		{
			Stage = 5,
			Desc = "暗元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102051,
					Value = 30,
				},
			},
		},
		{
			Stage = 6,
			Desc = "暗元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102051,
					Value = 35,
				},
			},
		},
		{
			Stage = 7,
			Desc = "暗元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102051,
					Value = 40,
				},
			},
		},
		{
			Stage = 8,
			Desc = "暗元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102051,
					Value = 45,
				},
			},
		},
		{
			Stage = 9,
			Desc = "暗元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102051,
					Value = 50,
				},
			},
		},
		{
			Stage = 10,
			Desc = "暗元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102051,
					Value = 55,
				},
			},
		},
		{
			Stage = 11,
			Desc = "暗元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102051,
					Value = 60,
				},
			},
		},
		{
			Stage = 12,
			Desc = "暗元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102051,
					Value = 65,
				},
			},
		},
		{
			Stage = 13,
			Desc = "暗元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102051,
					Value = 70,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320301,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320302,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561205,
		561306,
		561319,
		563102,
		563203,
		563622,
		563819,
		563304,
		563403,
		563504,
		563919,
		563903,
		563912,
		564005,
		564110,
		564139,
		564205,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id051] =
{
	Id = 51,
	Name = "甜虾龟龟",
	Area = 
	{
		130059,
	},
	Rarity = 2,
	Element = 210004,
	Gallery = 950002,
	Desc = "采用了鲜甜肥美的深海大虾作为食材的寿司，日常散步时经常让路人产生吃它的冲动。\n龟龟，这哪大了？",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_ShrimpSushi",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_ShrimpSushi",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectLight",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 60, Gain = 240},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得海苔 {Value1Divide}个",
			Skill = {
				{
					Id = 102052,
					Value = 80,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得海苔 {Value1Divide}个",
			Skill = {
				{
					Id = 102052,
					Value = 120,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得海苔 {Value1Divide}个",
			Skill = {
				{
					Id = 102052,
					Value = 160,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得海苔 {Value1Divide}个",
			Skill = {
				{
					Id = 102052,
					Value = 200,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得海苔 {Value1Divide}个",
			Skill = {
				{
					Id = 102052,
					Value = 240,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得海苔 {Value1Divide}个",
			Skill = {
				{
					Id = 102052,
					Value = 280,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得海苔 {Value1Divide}个",
			Skill = {
				{
					Id = 102052,
					Value = 320,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得海苔 {Value1Divide}个",
			Skill = {
				{
					Id = 102052,
					Value = 360,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得海苔 {Value1Divide}个",
			Skill = {
				{
					Id = 102052,
					Value = 400,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得海苔 {Value1Divide}个",
			Skill = {
				{
					Id = 102052,
					Value = 440,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得海苔 {Value1Divide}个",
			Skill = {
				{
					Id = 102052,
					Value = 480,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得海苔 {Value1Divide}个",
			Skill = {
				{
					Id = 102052,
					Value = 520,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得海苔 {Value1Divide}个",
			Skill = {
				{
					Id = 102052,
					Value = 560,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320301,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320302,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561205,
		561306,
		561319,
		563102,
		563203,
		563622,
		563819,
		563304,
		563403,
		563504,
		563909,
		563903,
		563912,
		564005,
		564110,
		564139,
		564205,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id052] =
{
	Id = 52,
	Name = "培根",
	Area = 
	{
		130060,
		130061,
	},
	Rarity = 2,
	Element = 210002,
	Gallery = 950002,
	Desc = "星际著名的哲学家、科学家，在诸多学科都有很大贡献，为星际居民所敬仰……然而这跟我培根有什么关系呢？",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_Bacon",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_Bacon",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectFire",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 60, Gain = 240},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得五花肉 {Value1Divide}个",
			Skill = {
				{
					Id = 102053,
					Value = 80,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得五花肉 {Value1Divide}个",
			Skill = {
				{
					Id = 102053,
					Value = 120,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得五花肉 {Value1Divide}个",
			Skill = {
				{
					Id = 102053,
					Value = 160,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得五花肉 {Value1Divide}个",
			Skill = {
				{
					Id = 102053,
					Value = 200,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得五花肉 {Value1Divide}个",
			Skill = {
				{
					Id = 102053,
					Value = 240,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得五花肉 {Value1Divide}个",
			Skill = {
				{
					Id = 102053,
					Value = 280,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得五花肉 {Value1Divide}个",
			Skill = {
				{
					Id = 102053,
					Value = 320,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得五花肉 {Value1Divide}个",
			Skill = {
				{
					Id = 102053,
					Value = 360,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得五花肉 {Value1Divide}个",
			Skill = {
				{
					Id = 102053,
					Value = 400,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得五花肉 {Value1Divide}个",
			Skill = {
				{
					Id = 102053,
					Value = 440,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得五花肉 {Value1Divide}个",
			Skill = {
				{
					Id = 102053,
					Value = 480,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得五花肉 {Value1Divide}个",
			Skill = {
				{
					Id = 102053,
					Value = 520,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得五花肉 {Value1Divide}个",
			Skill = {
				{
					Id = 102053,
					Value = 560,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320309,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320310,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561203,
		561306,
		561312,
		563104,
		563203,
		563819,
		563304,
		563404,
		563503,
		563920,
		563902,
		564014,
		564139,
		564205,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id053] =
{
	Id = 53,
	Name = "火腿猪",
	Area = 
	{
		130060,
	},
	Rarity = 3,
	Element = 210002,
	Gallery = 950002,
	Desc = "美食星特有的豚类，会定时产出美味的腌制火腿，很受烤肉店欢迎，至于产出过程……",
	LevelUp = 910003,
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_HamPig",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_HamPig",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectFire",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 102, Gain = 408},
		{Value = 200004, Base = 10, Gain = 2},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102054,
					Value = 3,
				},
			},
		},
		{
			Stage = 2,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102054,
					Value = 4,
				},
			},
		},
		{
			Stage = 3,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102054,
					Value = 5,
				},
			},
		},
		{
			Stage = 4,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102054,
					Value = 6,
				},
			},
		},
		{
			Stage = 5,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102054,
					Value = 7,
				},
			},
		},
		{
			Stage = 6,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102054,
					Value = 8,
				},
			},
		},
		{
			Stage = 7,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102054,
					Value = 9,
				},
			},
		},
		{
			Stage = 8,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102054,
					Value = 10,
				},
			},
		},
		{
			Stage = 9,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102054,
					Value = 11,
				},
			},
		},
		{
			Stage = 10,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102054,
					Value = 12,
				},
			},
		},
		{
			Stage = 11,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102054,
					Value = 13,
				},
			},
		},
		{
			Stage = 12,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102054,
					Value = 14,
				},
			},
		},
		{
			Stage = 13,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102054,
					Value = 15,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320302,
			CatchChance = 30,
			CatchChanceGain = 5,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 25,
			SuccessChanceGain = 2,
			SuccessChanceMax = 100,
		},
		{
			Value = 320303,
			CatchChance = 50,
			CatchChanceGain = 10,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561203,
		561306,
		561312,
		563102,
		563203,
		563617,
		563819,
		563304,
		563404,
		563502,
		563920,
		564005,
		564139,
		564205,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id054] =
{
	Id = 54,
	Name = "芝士软泥",
	Area = 
	{
		130061,
	},
	Rarity = 2,
	Element = 210002,
	Gallery = 950002,
	Desc = "用精品土豆研磨而成的细滑豆泥，拌入芝士后味道将更加浓郁。\n没加泥。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_Cheese",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_Cheese",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectFire",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 60, Gain = 240},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得芝士 {Value1Divide}个",
			Skill = {
				{
					Id = 102055,
					Value = 70,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得芝士 {Value1Divide}个",
			Skill = {
				{
					Id = 102055,
					Value = 105,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得芝士 {Value1Divide}个",
			Skill = {
				{
					Id = 102055,
					Value = 140,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得芝士 {Value1Divide}个",
			Skill = {
				{
					Id = 102055,
					Value = 175,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得芝士 {Value1Divide}个",
			Skill = {
				{
					Id = 102055,
					Value = 210,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得芝士 {Value1Divide}个",
			Skill = {
				{
					Id = 102055,
					Value = 245,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得芝士 {Value1Divide}个",
			Skill = {
				{
					Id = 102055,
					Value = 280,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得芝士 {Value1Divide}个",
			Skill = {
				{
					Id = 102055,
					Value = 315,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得芝士 {Value1Divide}个",
			Skill = {
				{
					Id = 102055,
					Value = 350,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得芝士 {Value1Divide}个",
			Skill = {
				{
					Id = 102055,
					Value = 385,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得芝士 {Value1Divide}个",
			Skill = {
				{
					Id = 102055,
					Value = 420,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得芝士 {Value1Divide}个",
			Skill = {
				{
					Id = 102055,
					Value = 455,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得芝士 {Value1Divide}个",
			Skill = {
				{
					Id = 102055,
					Value = 490,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320305,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320306,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561203,
		561306,
		561332,
		563103,
		563203,
		563610,
		563709,
		563824,
		563304,
		563405,
		563502,
		563926,
		564005,
		564139,
		564206,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id055] =
{
	Id = 55,
	Name = "比撒",
	Area = 
	{
		130061,
	},
	Rarity = 4,
	Element = 210002,
	Gallery = 950002,
	Desc = "包裹了香浓芝士的披萨，表面挂着各种食材，无论是作为点心或是正餐都是很棒的选择。\n没在骂人。",
	LevelUp = 910004,
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_Pizza",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_Pizza",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectFire",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 153, Gain = 612},
		{Value = 200004, Base = 15, Gain = 3},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102056,
					Value = 5,
				},
			},
		},
		{
			Stage = 2,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102056,
					Value = 7,
				},
			},
		},
		{
			Stage = 3,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102056,
					Value = 9,
				},
			},
		},
		{
			Stage = 4,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102056,
					Value = 11,
				},
			},
		},
		{
			Stage = 5,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102056,
					Value = 13,
				},
			},
		},
		{
			Stage = 6,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102056,
					Value = 15,
				},
			},
		},
		{
			Stage = 7,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102056,
					Value = 17,
				},
			},
		},
		{
			Stage = 8,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102056,
					Value = 19,
				},
			},
		},
		{
			Stage = 9,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102056,
					Value = 21,
				},
			},
		},
		{
			Stage = 10,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102056,
					Value = 23,
				},
			},
		},
		{
			Stage = 11,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102056,
					Value = 25,
				},
			},
		},
		{
			Stage = 12,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102056,
					Value = 27,
				},
			},
		},
		{
			Stage = 13,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102056,
					Value = 29,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320310,
			CatchChance = 5,
			CatchChanceGain = 12,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 5,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
		{
			Value = 320311,
			CatchChance = 33,
			CatchChanceGain = 25,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 33,
			SuccessChanceGain = 4,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560025,
		560045,
		560046,
		560032,
		560033,
		560034,
		560035,
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561203,
		561306,
		561319,
		563104,
		563203,
		563617,
		563709,
		563824,
		563304,
		563405,
		563504,
		563925,
		563917,
		563937,
		564031,
		564019,
		564139,
		564206,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id056] =
{
	Id = 56,
	Name = "左半碗",
	Area = 
	{
		130101,
		130106,
		130104,
		130103,
		130102,
	},
	Rarity = 1,
	Element = 210001,
	Gallery = 950003,
	Desc = "活跃在博物馆各大角落的碎瓷，出自某朝左姓大官家中，大官家道中落后也遭遇事故碎成两半，目前流落民间，以左为姓。",
	LevelUp = 910001,
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_GreenBowlLeft",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_GreenBowlLeft",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWater",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 46, Gain = 184},
		{Value = 200004, Base = 0, Gain = 0},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "水元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102057,
					Value = 3,
				},
			},
		},
		{
			Stage = 2,
			Desc = "水元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102057,
					Value = 4,
				},
			},
		},
		{
			Stage = 3,
			Desc = "水元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102057,
					Value = 5,
				},
			},
		},
		{
			Stage = 4,
			Desc = "水元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102057,
					Value = 6,
				},
			},
		},
		{
			Stage = 5,
			Desc = "水元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102057,
					Value = 7,
				},
			},
		},
		{
			Stage = 6,
			Desc = "水元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102057,
					Value = 8,
				},
			},
		},
		{
			Stage = 7,
			Desc = "水元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102057,
					Value = 9,
				},
			},
		},
		{
			Stage = 8,
			Desc = "水元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102057,
					Value = 10,
				},
			},
		},
		{
			Stage = 9,
			Desc = "水元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102057,
					Value = 11,
				},
			},
		},
		{
			Stage = 10,
			Desc = "水元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102057,
					Value = 12,
				},
			},
		},
		{
			Stage = 11,
			Desc = "水元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102057,
					Value = 13,
				},
			},
		},
		{
			Stage = 12,
			Desc = "水元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102057,
					Value = 14,
				},
			},
		},
		{
			Stage = 13,
			Desc = "水元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102057,
					Value = 15,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320317,
			CatchChance = 50,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560022,
		560042,
		560043,
		560044,
		560045,
		560046,
		560032,
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561202,
		561321,
		561336,
		561339,
		563106,
		563203,
		563618,
		563813,
		563305,
		563402,
		563503,
		563935,
		563902,
		564044,
		564007,
		564057,
		564149,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id057] =
{
	Id = 57,
	Name = "右半碗",
	Area = 
	{
		130107,
		130112,
		130111,
		130110,
		130109,
		130108,
	},
	Rarity = 1,
	Element = 210001,
	Gallery = 950003,
	Desc = "活跃在博物馆各大角落的碎瓷，出自某朝右姓豪族家中，大官家道中落后也遭遇事故碎成两半，目前流落民间，以右为姓。",
	LevelUp = 910001,
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_GreenBowlRight",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_GreenBowlRight",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWater",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 46, Gain = 184},
		{Value = 200004, Base = 0, Gain = 0},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "水元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102058,
					Value = 3,
				},
			},
		},
		{
			Stage = 2,
			Desc = "水元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102058,
					Value = 4,
				},
			},
		},
		{
			Stage = 3,
			Desc = "水元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102058,
					Value = 5,
				},
			},
		},
		{
			Stage = 4,
			Desc = "水元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102058,
					Value = 6,
				},
			},
		},
		{
			Stage = 5,
			Desc = "水元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102058,
					Value = 7,
				},
			},
		},
		{
			Stage = 6,
			Desc = "水元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102058,
					Value = 8,
				},
			},
		},
		{
			Stage = 7,
			Desc = "水元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102058,
					Value = 9,
				},
			},
		},
		{
			Stage = 8,
			Desc = "水元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102058,
					Value = 10,
				},
			},
		},
		{
			Stage = 9,
			Desc = "水元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102058,
					Value = 11,
				},
			},
		},
		{
			Stage = 10,
			Desc = "水元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102058,
					Value = 12,
				},
			},
		},
		{
			Stage = 11,
			Desc = "水元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102058,
					Value = 13,
				},
			},
		},
		{
			Stage = 12,
			Desc = "水元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102058,
					Value = 14,
				},
			},
		},
		{
			Stage = 13,
			Desc = "水元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102058,
					Value = 15,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320317,
			CatchChance = 50,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560022,
		560042,
		560043,
		560044,
		560045,
		560046,
		560032,
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561202,
		561321,
		561336,
		561339,
		563106,
		563203,
		563618,
		563813,
		563305,
		563402,
		563503,
		563935,
		563902,
		564044,
		564007,
		564057,
		564149,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id058] =
{
	Id = 58,
	Name = "入口",
	Area = 
	{
		130102,
		130103,
	},
	Rarity = 2,
	Element = 210004,
	Gallery = 950003,
	Desc = "指引游客进入博物馆的工作人员，如果游客固执地想从入口出去，它会很认真地阻止对方。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_Entrance",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_Enter",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectLight",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 68, Gain = 272},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得入场券 {Value1Divide}个",
			Skill = {
				{
					Id = 102059,
					Value = 80,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得入场券 {Value1Divide}个",
			Skill = {
				{
					Id = 102059,
					Value = 120,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得入场券 {Value1Divide}个",
			Skill = {
				{
					Id = 102059,
					Value = 160,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得入场券 {Value1Divide}个",
			Skill = {
				{
					Id = 102059,
					Value = 200,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得入场券 {Value1Divide}个",
			Skill = {
				{
					Id = 102059,
					Value = 240,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得入场券 {Value1Divide}个",
			Skill = {
				{
					Id = 102059,
					Value = 280,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得入场券 {Value1Divide}个",
			Skill = {
				{
					Id = 102059,
					Value = 320,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得入场券 {Value1Divide}个",
			Skill = {
				{
					Id = 102059,
					Value = 360,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得入场券 {Value1Divide}个",
			Skill = {
				{
					Id = 102059,
					Value = 400,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得入场券 {Value1Divide}个",
			Skill = {
				{
					Id = 102059,
					Value = 440,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得入场券 {Value1Divide}个",
			Skill = {
				{
					Id = 102059,
					Value = 480,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得入场券 {Value1Divide}个",
			Skill = {
				{
					Id = 102059,
					Value = 520,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得入场券 {Value1Divide}个",
			Skill = {
				{
					Id = 102059,
					Value = 560,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320313,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320314,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561205,
		561321,
		561335,
		563105,
		563203,
		563604,
		563814,
		563303,
		563402,
		563504,
		563935,
		563903,
		563922,
		564029,
		564038,
		564052,
		564159,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id059] =
{
	Id = 59,
	Name = "红外线探测",
	Area = 
	{
		130102,
	},
	Rarity = 2,
	Element = 210004,
	Gallery = 950003,
	Desc = "躲在暗处监视走道情况的机械设备，如果有人入侵会用红外线照对方眼睛。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_InfraredDetector",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_InfraredDetector",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectLight",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 68, Gain = 272},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102060,
					Value = -10,
				},
			},
		},
		{
			Stage = 2,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102060,
					Value = -15,
				},
			},
		},
		{
			Stage = 3,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102060,
					Value = -20,
				},
			},
		},
		{
			Stage = 4,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102060,
					Value = -25,
				},
			},
		},
		{
			Stage = 5,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102060,
					Value = -30,
				},
			},
		},
		{
			Stage = 6,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102060,
					Value = -35,
				},
			},
		},
		{
			Stage = 7,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102060,
					Value = -40,
				},
			},
		},
		{
			Stage = 8,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102060,
					Value = -45,
				},
			},
		},
		{
			Stage = 9,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102060,
					Value = -50,
				},
			},
		},
		{
			Stage = 10,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102060,
					Value = -55,
				},
			},
		},
		{
			Stage = 11,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102060,
					Value = -60,
				},
			},
		},
		{
			Stage = 12,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102060,
					Value = -65,
				},
			},
		},
		{
			Stage = 13,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102060,
					Value = -70,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320313,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320314,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561205,
		561321,
		561353,
		561322,
		563105,
		563203,
		563604,
		563814,
		563303,
		563403,
		563503,
		563905,
		563913,
		564030,
		564055,
		564038,
		564160,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id060] =
{
	Id = 60,
	Name = "围观陶",
	Area = 
	{
		130103,
		130104,
	},
	Rarity = 2,
	Element = 210002,
	Gallery = 950003,
	Desc = "整天无所事事的文物，到处瞎逛看热闹，爱占小便宜，喜欢碰瓷，因为瓷没它硬。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_Pottery",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_Pottery",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectFire",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 68, Gain = 272},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得考古刷 {Value1Divide}个",
			Skill = {
				{
					Id = 102061,
					Value = 70,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得考古刷 {Value1Divide}个",
			Skill = {
				{
					Id = 102061,
					Value = 105,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得考古刷 {Value1Divide}个",
			Skill = {
				{
					Id = 102061,
					Value = 140,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得考古刷 {Value1Divide}个",
			Skill = {
				{
					Id = 102061,
					Value = 175,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得考古刷 {Value1Divide}个",
			Skill = {
				{
					Id = 102061,
					Value = 210,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得考古刷 {Value1Divide}个",
			Skill = {
				{
					Id = 102061,
					Value = 245,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得考古刷 {Value1Divide}个",
			Skill = {
				{
					Id = 102061,
					Value = 280,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得考古刷 {Value1Divide}个",
			Skill = {
				{
					Id = 102061,
					Value = 315,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得考古刷 {Value1Divide}个",
			Skill = {
				{
					Id = 102061,
					Value = 350,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得考古刷 {Value1Divide}个",
			Skill = {
				{
					Id = 102061,
					Value = 385,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得考古刷 {Value1Divide}个",
			Skill = {
				{
					Id = 102061,
					Value = 420,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得考古刷 {Value1Divide}个",
			Skill = {
				{
					Id = 102061,
					Value = 455,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得考古刷 {Value1Divide}个",
			Skill = {
				{
					Id = 102061,
					Value = 490,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320317,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320318,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561203,
		561321,
		561336,
		563106,
		563203,
		563612,
		563829,
		563303,
		563402,
		563502,
		563920,
		564004,
		564059,
		564149,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id061] =
{
	Id = 61,
	Name = "陶面人",
	Area = 
	{
		130103,
	},
	Rarity = 3,
	Element = 210005,
	Gallery = 950003,
	Desc = "神秘的古代陶土工艺品，脸上写着难以言喻的表情，不太受人欢迎。",
	LevelUp = 910003,
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_QuestionMark",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_QuestionMark",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectDark",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 112, Gain = 448},
		{Value = 200004, Base = 10, Gain = 2},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102062,
					Value = -3,
				},
			},
		},
		{
			Stage = 2,
			Desc = "敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102062,
					Value = -4,
				},
			},
		},
		{
			Stage = 3,
			Desc = "敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102062,
					Value = -5,
				},
			},
		},
		{
			Stage = 4,
			Desc = "敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102062,
					Value = -6,
				},
			},
		},
		{
			Stage = 5,
			Desc = "敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102062,
					Value = -7,
				},
			},
		},
		{
			Stage = 6,
			Desc = "敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102062,
					Value = -8,
				},
			},
		},
		{
			Stage = 7,
			Desc = "敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102062,
					Value = -9,
				},
			},
		},
		{
			Stage = 8,
			Desc = "敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102062,
					Value = -10,
				},
			},
		},
		{
			Stage = 9,
			Desc = "敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102062,
					Value = -11,
				},
			},
		},
		{
			Stage = 10,
			Desc = "敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102062,
					Value = -12,
				},
			},
		},
		{
			Stage = 11,
			Desc = "敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102062,
					Value = -13,
				},
			},
		},
		{
			Stage = 12,
			Desc = "敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102062,
					Value = -14,
				},
			},
		},
		{
			Stage = 13,
			Desc = "敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102062,
					Value = -15,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320306,
			CatchChance = 30,
			CatchChanceGain = 5,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 25,
			SuccessChanceGain = 2,
			SuccessChanceMax = 100,
		},
		{
			Value = 320307,
			CatchChance = 50,
			CatchChanceGain = 10,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561206,
		561321,
		561336,
		563103,
		563203,
		563612,
		563829,
		563303,
		563402,
		563502,
		563945,
		564026,
		564060,
		564149,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id062] =
{
	Id = 62,
	Name = "编钟",
	Area = 
	{
		130104,
		130106,
	},
	Rarity = 2,
	Element = 210003,
	Gallery = 950003,
	Desc = "古代的乐器，能够敲击出悠扬空灵的声响，喜欢说大话，经常炫耀自己见多识广，对此大家总是表示“你就编吧”。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_Chimes",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_Chimes",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 68, Gain = 272},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "水元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102063,
					Value = 6,
				},
			},
		},
		{
			Stage = 2,
			Desc = "水元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102063,
					Value = 9,
				},
			},
		},
		{
			Stage = 3,
			Desc = "水元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102063,
					Value = 12,
				},
			},
		},
		{
			Stage = 4,
			Desc = "水元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102063,
					Value = 15,
				},
			},
		},
		{
			Stage = 5,
			Desc = "水元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102063,
					Value = 18,
				},
			},
		},
		{
			Stage = 6,
			Desc = "水元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102063,
					Value = 21,
				},
			},
		},
		{
			Stage = 7,
			Desc = "水元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102063,
					Value = 24,
				},
			},
		},
		{
			Stage = 8,
			Desc = "水元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102063,
					Value = 27,
				},
			},
		},
		{
			Stage = 9,
			Desc = "水元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102063,
					Value = 30,
				},
			},
		},
		{
			Stage = 10,
			Desc = "水元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102063,
					Value = 33,
				},
			},
		},
		{
			Stage = 11,
			Desc = "水元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102063,
					Value = 36,
				},
			},
		},
		{
			Stage = 12,
			Desc = "水元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102063,
					Value = 39,
				},
			},
		},
		{
			Stage = 13,
			Desc = "水元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102063,
					Value = 42,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320317,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320318,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561204,
		561321,
		561336,
		563106,
		563203,
		563612,
		563814,
		563303,
		563402,
		563502,
		563940,
		564044,
		564004,
		564057,
		564149,
		564114,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id063] =
{
	Id = 63,
	Name = "兽面鼎",
	Area = 
	{
		130104,
		130108,
	},
	Rarity = 2,
	Element = 210005,
	Gallery = 950003,
	Desc = "在古代祭祀典礼上经常出现的器皿，用来插仪式用的焚香，因为样貌有些吓人，有时会吓到前来祭祀的人。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_BeastFaceTripod",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_BeastFaceTripod",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectDark",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 68, Gain = 272},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得焚香 {Value1Divide}个",
			Skill = {
				{
					Id = 102064,
					Value = 70,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得焚香 {Value1Divide}个",
			Skill = {
				{
					Id = 102064,
					Value = 105,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得焚香 {Value1Divide}个",
			Skill = {
				{
					Id = 102064,
					Value = 140,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得焚香 {Value1Divide}个",
			Skill = {
				{
					Id = 102064,
					Value = 175,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得焚香 {Value1Divide}个",
			Skill = {
				{
					Id = 102064,
					Value = 210,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得焚香 {Value1Divide}个",
			Skill = {
				{
					Id = 102064,
					Value = 245,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得焚香 {Value1Divide}个",
			Skill = {
				{
					Id = 102064,
					Value = 280,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得焚香 {Value1Divide}个",
			Skill = {
				{
					Id = 102064,
					Value = 315,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得焚香 {Value1Divide}个",
			Skill = {
				{
					Id = 102064,
					Value = 350,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得焚香 {Value1Divide}个",
			Skill = {
				{
					Id = 102064,
					Value = 385,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得焚香 {Value1Divide}个",
			Skill = {
				{
					Id = 102064,
					Value = 420,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得焚香 {Value1Divide}个",
			Skill = {
				{
					Id = 102064,
					Value = 455,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得焚香 {Value1Divide}个",
			Skill = {
				{
					Id = 102064,
					Value = 490,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320301,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320302,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561206,
		561321,
		561336,
		563102,
		563203,
		563814,
		563303,
		563403,
		563502,
		563945,
		564044,
		564024,
		564149,
		564114,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id064] =
{
	Id = 64,
	Name = "猪罐",
	Area = 
	{
		130104,
	},
	Rarity = 3,
	Element = 210002,
	Gallery = 950003,
	Desc = "从遗迹里挖出来的猪形瓷罐，上方的小孔刚好够塞进去一枚铜币，但里面却是空的。",
	LevelUp = 910003,
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_PigJar",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_PigJar",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectFire",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 112, Gain = 448},
		{Value = 200004, Base = 10, Gain = 2},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102065,
					Value = 10,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102065,
					Value = 15,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102065,
					Value = 20,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102065,
					Value = 25,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102065,
					Value = 30,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102065,
					Value = 35,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102065,
					Value = 40,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102065,
					Value = 45,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102065,
					Value = 50,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102065,
					Value = 55,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102065,
					Value = 60,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102065,
					Value = 65,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102065,
					Value = 70,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320302,
			CatchChance = 30,
			CatchChanceGain = 5,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 25,
			SuccessChanceGain = 2,
			SuccessChanceMax = 100,
		},
		{
			Value = 320303,
			CatchChance = 50,
			CatchChanceGain = 10,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561203,
		561321,
		561336,
		561329,
		563102,
		563203,
		563618,
		563828,
		563303,
		563403,
		563502,
		563911,
		564005,
		564018,
		564149,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id065] =
{
	Id = 65,
	Name = "左半瓷",
	Area = 
	{
		130105,
	},
	Rarity = 2,
	Element = 210003,
	Gallery = 950003,
	Desc = "活跃在博物馆各大角落的碎瓷片，过去是在皇宫里当差的，碎了以后就回到了民间，因为碎裂的关系已经认不出右半瓷了。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_BlueBowlLeft",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_BlueBowlLeft",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 68, Gain = 272},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "水元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102066,
					Value = 10,
				},
			},
		},
		{
			Stage = 2,
			Desc = "水元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102066,
					Value = 15,
				},
			},
		},
		{
			Stage = 3,
			Desc = "水元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102066,
					Value = 20,
				},
			},
		},
		{
			Stage = 4,
			Desc = "水元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102066,
					Value = 25,
				},
			},
		},
		{
			Stage = 5,
			Desc = "水元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102066,
					Value = 30,
				},
			},
		},
		{
			Stage = 6,
			Desc = "水元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102066,
					Value = 35,
				},
			},
		},
		{
			Stage = 7,
			Desc = "水元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102066,
					Value = 40,
				},
			},
		},
		{
			Stage = 8,
			Desc = "水元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102066,
					Value = 45,
				},
			},
		},
		{
			Stage = 9,
			Desc = "水元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102066,
					Value = 50,
				},
			},
		},
		{
			Stage = 10,
			Desc = "水元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102066,
					Value = 55,
				},
			},
		},
		{
			Stage = 11,
			Desc = "水元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102066,
					Value = 60,
				},
			},
		},
		{
			Stage = 12,
			Desc = "水元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102066,
					Value = 65,
				},
			},
		},
		{
			Stage = 13,
			Desc = "水元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102066,
					Value = 70,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320317,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320318,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561204,
		561321,
		561336,
		561339,
		563106,
		563203,
		563618,
		563813,
		563305,
		563402,
		563503,
		563940,
		563902,
		564044,
		564007,
		564057,
		564149,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id066] =
{
	Id = 66,
	Name = "右半瓷",
	Area = 
	{
		130105,
	},
	Rarity = 2,
	Element = 210003,
	Gallery = 950003,
	Desc = "活跃在博物馆各大角落的碎瓷片，过去是在皇宫里当差的，碎了以后就回到了民间，还记得左半瓷但是老是装不认识。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_BlueBowlRight",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_BlueBowlRight",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 68, Gain = 272},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "全队攻击 +{Value1}%",
			Skill = {
				{
					Id = 102067,
					Value = 2,
				},
			},
		},
		{
			Stage = 2,
			Desc = "全队攻击 +{Value1}%",
			Skill = {
				{
					Id = 102067,
					Value = 3,
				},
			},
		},
		{
			Stage = 3,
			Desc = "全队攻击 +{Value1}%",
			Skill = {
				{
					Id = 102067,
					Value = 4,
				},
			},
		},
		{
			Stage = 4,
			Desc = "全队攻击 +{Value1}%",
			Skill = {
				{
					Id = 102067,
					Value = 5,
				},
			},
		},
		{
			Stage = 5,
			Desc = "全队攻击 +{Value1}%",
			Skill = {
				{
					Id = 102067,
					Value = 6,
				},
			},
		},
		{
			Stage = 6,
			Desc = "全队攻击 +{Value1}%",
			Skill = {
				{
					Id = 102067,
					Value = 7,
				},
			},
		},
		{
			Stage = 7,
			Desc = "全队攻击 +{Value1}%",
			Skill = {
				{
					Id = 102067,
					Value = 8,
				},
			},
		},
		{
			Stage = 8,
			Desc = "全队攻击 +{Value1}%",
			Skill = {
				{
					Id = 102067,
					Value = 9,
				},
			},
		},
		{
			Stage = 9,
			Desc = "全队攻击 +{Value1}%",
			Skill = {
				{
					Id = 102067,
					Value = 10,
				},
			},
		},
		{
			Stage = 10,
			Desc = "全队攻击 +{Value1}%",
			Skill = {
				{
					Id = 102067,
					Value = 11,
				},
			},
		},
		{
			Stage = 11,
			Desc = "全队攻击 +{Value1}%",
			Skill = {
				{
					Id = 102067,
					Value = 12,
				},
			},
		},
		{
			Stage = 12,
			Desc = "全队攻击 +{Value1}%",
			Skill = {
				{
					Id = 102067,
					Value = 13,
				},
			},
		},
		{
			Stage = 13,
			Desc = "全队攻击 +{Value1}%",
			Skill = {
				{
					Id = 102067,
					Value = 14,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320317,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320318,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561204,
		561321,
		561336,
		561339,
		563106,
		563203,
		563618,
		563829,
		563305,
		563402,
		563503,
		563940,
		563902,
		564044,
		564007,
		564057,
		564149,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id067] =
{
	Id = 67,
	Name = "碰碰瓷",
	Area = 
	{
		130105,
		130109,
		130107,
	},
	Rarity = 2,
	Element = 210004,
	Gallery = 950003,
	Desc = "毫无节操的前文物，会在游客密集的地方突然躺倒，向附近的游客索要巨额赔偿。天敌是围观陶，因为碰不过。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_Porcelain",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_Porcelain",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectLight",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 68, Gain = 272},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得碎瓷片 {Value1Divide}个",
			Skill = {
				{
					Id = 102068,
					Value = 60,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得碎瓷片 {Value1Divide}个",
			Skill = {
				{
					Id = 102068,
					Value = 90,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得碎瓷片 {Value1Divide}个",
			Skill = {
				{
					Id = 102068,
					Value = 120,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得碎瓷片 {Value1Divide}个",
			Skill = {
				{
					Id = 102068,
					Value = 150,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得碎瓷片 {Value1Divide}个",
			Skill = {
				{
					Id = 102068,
					Value = 180,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得碎瓷片 {Value1Divide}个",
			Skill = {
				{
					Id = 102068,
					Value = 210,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得碎瓷片 {Value1Divide}个",
			Skill = {
				{
					Id = 102068,
					Value = 240,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得碎瓷片 {Value1Divide}个",
			Skill = {
				{
					Id = 102068,
					Value = 270,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得碎瓷片 {Value1Divide}个",
			Skill = {
				{
					Id = 102068,
					Value = 300,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得碎瓷片 {Value1Divide}个",
			Skill = {
				{
					Id = 102068,
					Value = 330,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得碎瓷片 {Value1Divide}个",
			Skill = {
				{
					Id = 102068,
					Value = 360,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得碎瓷片 {Value1Divide}个",
			Skill = {
				{
					Id = 102068,
					Value = 390,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得碎瓷片 {Value1Divide}个",
			Skill = {
				{
					Id = 102068,
					Value = 420,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320317,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320318,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561205,
		561321,
		561336,
		561339,
		563106,
		563203,
		563612,
		563830,
		563303,
		563402,
		563503,
		563904,
		563934,
		564035,
		564015,
		564149,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id068] =
{
	Id = 68,
	Name = "警戒线",
	Area = 
	{
		130105,
	},
	Rarity = 3,
	Element = 210005,
	Gallery = 950003,
	Desc = "经常被无视的保安设备，有人想穿过去时，它就会一直盯着对方。",
	LevelUp = 910003,
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_Cordon",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_Cordon",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectDark",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 112, Gain = 448},
		{Value = 200004, Base = 10, Gain = 2},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "光元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102069,
					Value = 10,
				},
			},
		},
		{
			Stage = 2,
			Desc = "光元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102069,
					Value = 15,
				},
			},
		},
		{
			Stage = 3,
			Desc = "光元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102069,
					Value = 20,
				},
			},
		},
		{
			Stage = 4,
			Desc = "光元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102069,
					Value = 25,
				},
			},
		},
		{
			Stage = 5,
			Desc = "光元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102069,
					Value = 30,
				},
			},
		},
		{
			Stage = 6,
			Desc = "光元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102069,
					Value = 35,
				},
			},
		},
		{
			Stage = 7,
			Desc = "光元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102069,
					Value = 40,
				},
			},
		},
		{
			Stage = 8,
			Desc = "光元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102069,
					Value = 45,
				},
			},
		},
		{
			Stage = 9,
			Desc = "光元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102069,
					Value = 50,
				},
			},
		},
		{
			Stage = 10,
			Desc = "光元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102069,
					Value = 55,
				},
			},
		},
		{
			Stage = 11,
			Desc = "光元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102069,
					Value = 60,
				},
			},
		},
		{
			Stage = 12,
			Desc = "光元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102069,
					Value = 65,
				},
			},
		},
		{
			Stage = 13,
			Desc = "光元素敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102069,
					Value = 70,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320314,
			CatchChance = 30,
			CatchChanceGain = 5,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 25,
			SuccessChanceGain = 2,
			SuccessChanceMax = 100,
		},
		{
			Value = 320315,
			CatchChance = 50,
			CatchChanceGain = 10,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561206,
		561321,
		561337,
		563105,
		563203,
		563625,
		563815,
		563303,
		563402,
		563503,
		563929,
		563918,
		564030,
		564052,
		564159,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id069] =
{
	Id = 69,
	Name = "雨林快走龙",
	Area = 
	{
		130106,
		130107,
	},
	Rarity = 2,
	Element = 210003,
	Gallery = 950003,
	Desc = "第二世代时生活在雨林地区的双足龙，走起来速度十分惊人，但是因为名字而不能奔跑。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_DinosaurEgg",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_DinosaurEgg",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 68, Gain = 272},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得绿蛋壳 {Value1Divide}个",
			Skill = {
				{
					Id = 102070,
					Value = 70,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得绿蛋壳 {Value1Divide}个",
			Skill = {
				{
					Id = 102070,
					Value = 105,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得绿蛋壳 {Value1Divide}个",
			Skill = {
				{
					Id = 102070,
					Value = 140,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得绿蛋壳 {Value1Divide}个",
			Skill = {
				{
					Id = 102070,
					Value = 175,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得绿蛋壳 {Value1Divide}个",
			Skill = {
				{
					Id = 102070,
					Value = 210,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得绿蛋壳 {Value1Divide}个",
			Skill = {
				{
					Id = 102070,
					Value = 245,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得绿蛋壳 {Value1Divide}个",
			Skill = {
				{
					Id = 102070,
					Value = 280,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得绿蛋壳 {Value1Divide}个",
			Skill = {
				{
					Id = 102070,
					Value = 315,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得绿蛋壳 {Value1Divide}个",
			Skill = {
				{
					Id = 102070,
					Value = 350,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得绿蛋壳 {Value1Divide}个",
			Skill = {
				{
					Id = 102070,
					Value = 385,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得绿蛋壳 {Value1Divide}个",
			Skill = {
				{
					Id = 102070,
					Value = 420,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得绿蛋壳 {Value1Divide}个",
			Skill = {
				{
					Id = 102070,
					Value = 455,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得绿蛋壳 {Value1Divide}个",
			Skill = {
				{
					Id = 102070,
					Value = 490,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320301,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320302,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561204,
		561303,
		561340,
		561338,
		563102,
		563205,
		563612,
		563813,
		563303,
		563403,
		563503,
		563940,
		563903,
		564019,
		564014,
		564154,
		564204,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id070] =
{
	Id = 70,
	Name = "沙漠快走龙",
	Area = 
	{
		130106,
		130111,
	},
	Rarity = 2,
	Element = 210002,
	Gallery = 950003,
	Desc = "虽然和雨林快走龙很像，却是来自第三世代的生物。叫这个名字并不是因为走得快，而是为了纪念它在危难之中保护了自己的朋友沙漠。\n沙漠快走！！！！",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_GoldenDinosaurEgg",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_GoldenDinosaurEgg",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectFire",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 68, Gain = 272},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102071,
					Value = -3,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102071,
					Value = -4,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102071,
					Value = -5,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102071,
					Value = -6,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102071,
					Value = -7,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102071,
					Value = -8,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102071,
					Value = -9,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102071,
					Value = -10,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102071,
					Value = -11,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102071,
					Value = -12,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102071,
					Value = -13,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102071,
					Value = -14,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102071,
					Value = -15,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320301,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320302,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561203,
		561303,
		561340,
		561338,
		563102,
		563205,
		563612,
		563813,
		563303,
		563403,
		563503,
		563925,
		563903,
		564019,
		564014,
		564154,
		564204,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id071] =
{
	Id = 71,
	Name = "恐龙化石",
	Area = 
	{
		130106,
	},
	Rarity = 3,
	Element = 210005,
	Gallery = 950003,
	Desc = "通过基因技术复活的恐龙化石，复活后却成了博物馆有名的捣蛋鬼。\n你不能因为自己没有蛋就捣别人的啊。",
	LevelUp = 910003,
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_DinosaurFossils",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_DinosaurFossils",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectDark",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 112, Gain = 448},
		{Value = 200004, Base = 10, Gain = 2},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "暗元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102072,
					Value = 4,
				},
			},
		},
		{
			Stage = 2,
			Desc = "暗元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102072,
					Value = 6,
				},
			},
		},
		{
			Stage = 3,
			Desc = "暗元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102072,
					Value = 8,
				},
			},
		},
		{
			Stage = 4,
			Desc = "暗元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102072,
					Value = 10,
				},
			},
		},
		{
			Stage = 5,
			Desc = "暗元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102072,
					Value = 12,
				},
			},
		},
		{
			Stage = 6,
			Desc = "暗元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102072,
					Value = 14,
				},
			},
		},
		{
			Stage = 7,
			Desc = "暗元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102072,
					Value = 16,
				},
			},
		},
		{
			Stage = 8,
			Desc = "暗元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102072,
					Value = 18,
				},
			},
		},
		{
			Stage = 9,
			Desc = "暗元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102072,
					Value = 20,
				},
			},
		},
		{
			Stage = 10,
			Desc = "暗元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102072,
					Value = 22,
				},
			},
		},
		{
			Stage = 11,
			Desc = "暗元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102072,
					Value = 24,
				},
			},
		},
		{
			Stage = 12,
			Desc = "暗元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102072,
					Value = 26,
				},
			},
		},
		{
			Stage = 13,
			Desc = "暗元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102072,
					Value = 28,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320318,
			CatchChance = 30,
			CatchChanceGain = 5,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 25,
			SuccessChanceGain = 2,
			SuccessChanceMax = 100,
		},
		{
			Value = 320319,
			CatchChance = 50,
			CatchChanceGain = 10,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561206,
		561303,
		561340,
		561338,
		563106,
		563204,
		563612,
		563813,
		563303,
		563402,
		563503,
		563928,
		563914,
		564024,
		564029,
		564154,
		564149,
		564203,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id072] =
{
	Id = 72,
	Name = "摄像头",
	Area = 
	{
		130107,
		130112,
		130110,
		130108,
	},
	Rarity = 2,
	Element = 210005,
	Gallery = 950003,
	Desc = "配合保安负责安保工作的机械设备，只记录画面，不记录声音，因此他们又在旁边配了一台录音机。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_BlackCamera",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_BlackCamera",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectDark",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 68, Gain = 272},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得监控录像 {Value1Divide}个",
			Skill = {
				{
					Id = 102073,
					Value = 60,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得监控录像 {Value1Divide}个",
			Skill = {
				{
					Id = 102073,
					Value = 90,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得监控录像 {Value1Divide}个",
			Skill = {
				{
					Id = 102073,
					Value = 120,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得监控录像 {Value1Divide}个",
			Skill = {
				{
					Id = 102073,
					Value = 150,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得监控录像 {Value1Divide}个",
			Skill = {
				{
					Id = 102073,
					Value = 180,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得监控录像 {Value1Divide}个",
			Skill = {
				{
					Id = 102073,
					Value = 210,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得监控录像 {Value1Divide}个",
			Skill = {
				{
					Id = 102073,
					Value = 240,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得监控录像 {Value1Divide}个",
			Skill = {
				{
					Id = 102073,
					Value = 270,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得监控录像 {Value1Divide}个",
			Skill = {
				{
					Id = 102073,
					Value = 300,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得监控录像 {Value1Divide}个",
			Skill = {
				{
					Id = 102073,
					Value = 330,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得监控录像 {Value1Divide}个",
			Skill = {
				{
					Id = 102073,
					Value = 360,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得监控录像 {Value1Divide}个",
			Skill = {
				{
					Id = 102073,
					Value = 390,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得监控录像 {Value1Divide}个",
			Skill = {
				{
					Id = 102073,
					Value = 420,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320313,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320314,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561206,
		561321,
		561322,
		563105,
		563203,
		563604,
		563814,
		563303,
		563403,
		563503,
		563931,
		563912,
		564055,
		564029,
		564039,
		564160,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id073] =
{
	Id = 73,
	Name = "高清摄像头",
	Area = 
	{
		130107,
	},
	Rarity = 4,
	Element = 210004,
	Gallery = 950003,
	Desc = "能够把路人脸上的毛孔都拍得一清二楚的高级摄像头，可他们又忘了加麦克风。",
	LevelUp = 910004,
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_Camera",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_Camera",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectLight",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 166, Gain = 664},
		{Value = 200004, Base = 15, Gain = 3},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "紫色及以上品质敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102074,
					Value = 15,
				},
			},
		},
		{
			Stage = 2,
			Desc = "紫色及以上品质敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102074,
					Value = 22,
				},
			},
		},
		{
			Stage = 3,
			Desc = "紫色及以上品质敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102074,
					Value = 29,
				},
			},
		},
		{
			Stage = 4,
			Desc = "紫色及以上品质敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102074,
					Value = 36,
				},
			},
		},
		{
			Stage = 5,
			Desc = "紫色及以上品质敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102074,
					Value = 43,
				},
			},
		},
		{
			Stage = 6,
			Desc = "紫色及以上品质敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102074,
					Value = 50,
				},
			},
		},
		{
			Stage = 7,
			Desc = "紫色及以上品质敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102074,
					Value = 57,
				},
			},
		},
		{
			Stage = 8,
			Desc = "紫色及以上品质敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102074,
					Value = 64,
				},
			},
		},
		{
			Stage = 9,
			Desc = "紫色及以上品质敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102074,
					Value = 71,
				},
			},
		},
		{
			Stage = 10,
			Desc = "紫色及以上品质敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102074,
					Value = 78,
				},
			},
		},
		{
			Stage = 11,
			Desc = "紫色及以上品质敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102074,
					Value = 85,
				},
			},
		},
		{
			Stage = 12,
			Desc = "紫色及以上品质敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102074,
					Value = 92,
				},
			},
		},
		{
			Stage = 13,
			Desc = "紫色及以上品质敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102074,
					Value = 99,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320314,
			CatchChance = 5,
			CatchChanceGain = 12,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 5,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
		{
			Value = 320315,
			CatchChance = 33,
			CatchChanceGain = 25,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 33,
			SuccessChanceGain = 4,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560025,
		560045,
		560046,
		560032,
		560033,
		560034,
		560035,
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561205,
		561321,
		561322,
		563105,
		563203,
		563604,
		563815,
		563303,
		563403,
		563503,
		563906,
		563912,
		564056,
		564030,
		564040,
		564160,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id074] =
{
	Id = 74,
	Name = "鸮卣",
	Area = 
	{
		130108,
		130109,
	},
	Rarity = 2,
	Element = 210003,
	Gallery = 950003,
	Desc = "大型青铜鼎，上面贴着古代大法师施咒的封条，里面可能藏着不得了的妖怪。\n你才是号卤！",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_WineJar",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_WineJar",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 68, Gain = 272},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102075,
					Value = 2,
				},
			},
		},
		{
			Stage = 2,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102075,
					Value = 3,
				},
			},
		},
		{
			Stage = 3,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102075,
					Value = 4,
				},
			},
		},
		{
			Stage = 4,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102075,
					Value = 5,
				},
			},
		},
		{
			Stage = 5,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102075,
					Value = 6,
				},
			},
		},
		{
			Stage = 6,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102075,
					Value = 7,
				},
			},
		},
		{
			Stage = 7,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102075,
					Value = 8,
				},
			},
		},
		{
			Stage = 8,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102075,
					Value = 9,
				},
			},
		},
		{
			Stage = 9,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102075,
					Value = 10,
				},
			},
		},
		{
			Stage = 10,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102075,
					Value = 11,
				},
			},
		},
		{
			Stage = 11,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102075,
					Value = 12,
				},
			},
		},
		{
			Stage = 12,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102075,
					Value = 13,
				},
			},
		},
		{
			Stage = 13,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102075,
					Value = 14,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320317,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320318,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561204,
		561321,
		561336,
		563106,
		563203,
		563617,
		563815,
		563303,
		563402,
		563502,
		563941,
		564025,
		564057,
		564149,
		564114,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id075] =
{
	Id = 75,
	Name = "金鸮卣",
	Area = 
	{
		130108,
	},
	Rarity = 4,
	Element = 210004,
	Gallery = 950003,
	Desc = "使用贵重的黄金制成的大鼎，只是靠近都能感到鼎内散发出不祥的气息。\n你才是金鸟回！",
	LevelUp = 910004,
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_GoldenWineJar",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_GoldenWineJar",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectLight",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 166, Gain = 664},
		{Value = 200004, Base = 15, Gain = 3},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102076,
					Value = 6,
				},
			},
		},
		{
			Stage = 2,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102076,
					Value = 9,
				},
			},
		},
		{
			Stage = 3,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102076,
					Value = 12,
				},
			},
		},
		{
			Stage = 4,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102076,
					Value = 15,
				},
			},
		},
		{
			Stage = 5,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102076,
					Value = 18,
				},
			},
		},
		{
			Stage = 6,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102076,
					Value = 21,
				},
			},
		},
		{
			Stage = 7,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102076,
					Value = 24,
				},
			},
		},
		{
			Stage = 8,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102076,
					Value = 27,
				},
			},
		},
		{
			Stage = 9,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102076,
					Value = 30,
				},
			},
		},
		{
			Stage = 10,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102076,
					Value = 33,
				},
			},
		},
		{
			Stage = 11,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102076,
					Value = 36,
				},
			},
		},
		{
			Stage = 12,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102076,
					Value = 39,
				},
			},
		},
		{
			Stage = 13,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102076,
					Value = 42,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320318,
			CatchChance = 5,
			CatchChanceGain = 12,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 5,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
		{
			Value = 320319,
			CatchChance = 33,
			CatchChanceGain = 25,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 33,
			SuccessChanceGain = 4,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560025,
		560045,
		560046,
		560032,
		560033,
		560034,
		560035,
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561205,
		561321,
		561336,
		563106,
		563203,
		563617,
		563815,
		563303,
		563402,
		563502,
		563926,
		564026,
		564058,
		564149,
		564114,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id076] =
{
	Id = 76,
	Name = "鱼化石",
	Area = 
	{
		130109,
		130110,
	},
	Rarity = 2,
	Element = 210001,
	Gallery = 950003,
	Desc = "来自海洋的古代鱼化石，关于上面的鱼是什么品种生物学家们至今也没有定论，所以仍然不知道到底能不能吃。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_FishboneFossils",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_FishboneFossils",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWater",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 68, Gain = 272},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "火元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102077,
					Value = -4,
				},
			},
		},
		{
			Stage = 2,
			Desc = "火元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102077,
					Value = -6,
				},
			},
		},
		{
			Stage = 3,
			Desc = "火元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102077,
					Value = -8,
				},
			},
		},
		{
			Stage = 4,
			Desc = "火元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102077,
					Value = -10,
				},
			},
		},
		{
			Stage = 5,
			Desc = "火元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102077,
					Value = -12,
				},
			},
		},
		{
			Stage = 6,
			Desc = "火元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102077,
					Value = -14,
				},
			},
		},
		{
			Stage = 7,
			Desc = "火元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102077,
					Value = -16,
				},
			},
		},
		{
			Stage = 8,
			Desc = "火元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102077,
					Value = -18,
				},
			},
		},
		{
			Stage = 9,
			Desc = "火元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102077,
					Value = -20,
				},
			},
		},
		{
			Stage = 10,
			Desc = "火元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102077,
					Value = -22,
				},
			},
		},
		{
			Stage = 11,
			Desc = "火元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102077,
					Value = -24,
				},
			},
		},
		{
			Stage = 12,
			Desc = "火元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102077,
					Value = -26,
				},
			},
		},
		{
			Stage = 13,
			Desc = "火元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102077,
					Value = -28,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320305,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320306,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561202,
		561321,
		561340,
		561341,
		563103,
		563203,
		563815,
		563303,
		563402,
		563503,
		563945,
		563918,
		564019,
		564004,
		564057,
		564149,
		564110,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id077] =
{
	Id = 77,
	Name = "乌龟化石",
	Area = 
	{
		130109,
	},
	Rarity = 2,
	Element = 210001,
	Gallery = 950003,
	Desc = "来自海洋的古代乌龟化石，关于它的真实年龄，科学家们至今也没有定论。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_TortoiseFossils",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_TortoiseFossils",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWater",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 68, Gain = 272},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "水元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102078,
					Value = 3,
				},
			},
		},
		{
			Stage = 2,
			Desc = "水元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102078,
					Value = 4,
				},
			},
		},
		{
			Stage = 3,
			Desc = "水元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102078,
					Value = 5,
				},
			},
		},
		{
			Stage = 4,
			Desc = "水元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102078,
					Value = 6,
				},
			},
		},
		{
			Stage = 5,
			Desc = "水元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102078,
					Value = 7,
				},
			},
		},
		{
			Stage = 6,
			Desc = "水元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102078,
					Value = 8,
				},
			},
		},
		{
			Stage = 7,
			Desc = "水元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102078,
					Value = 9,
				},
			},
		},
		{
			Stage = 8,
			Desc = "水元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102078,
					Value = 10,
				},
			},
		},
		{
			Stage = 9,
			Desc = "水元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102078,
					Value = 11,
				},
			},
		},
		{
			Stage = 10,
			Desc = "水元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102078,
					Value = 12,
				},
			},
		},
		{
			Stage = 11,
			Desc = "水元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102078,
					Value = 13,
				},
			},
		},
		{
			Stage = 12,
			Desc = "水元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102078,
					Value = 14,
				},
			},
		},
		{
			Stage = 13,
			Desc = "水元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102078,
					Value = 15,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320305,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320306,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561202,
		561321,
		561340,
		561341,
		563103,
		563203,
		563815,
		563303,
		563402,
		563503,
		563930,
		563918,
		564019,
		564004,
		564057,
		564149,
		564110,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id078] =
{
	Id = 78,
	Name = "碧鱬",
	Area = 
	{
		130110,
		130111,
	},
	Rarity = 2,
	Element = 210001,
	Gallery = 950003,
	Desc = "古代艺术家按照某种古生物的外形制作的泥塑，听老一辈说，这种生物有时候会被误认为是美人鱼，看见的人会连续一周发生与水有关的灾祸。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_GreenMermaid",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_GreenMermaid",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWater",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 68, Gain = 272},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得青面具 {Value1Divide}个",
			Skill = {
				{
					Id = 102079,
					Value = 60,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得青面具 {Value1Divide}个",
			Skill = {
				{
					Id = 102079,
					Value = 90,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得青面具 {Value1Divide}个",
			Skill = {
				{
					Id = 102079,
					Value = 120,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得青面具 {Value1Divide}个",
			Skill = {
				{
					Id = 102079,
					Value = 150,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得青面具 {Value1Divide}个",
			Skill = {
				{
					Id = 102079,
					Value = 180,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得青面具 {Value1Divide}个",
			Skill = {
				{
					Id = 102079,
					Value = 210,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得青面具 {Value1Divide}个",
			Skill = {
				{
					Id = 102079,
					Value = 240,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得青面具 {Value1Divide}个",
			Skill = {
				{
					Id = 102079,
					Value = 270,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得青面具 {Value1Divide}个",
			Skill = {
				{
					Id = 102079,
					Value = 300,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得青面具 {Value1Divide}个",
			Skill = {
				{
					Id = 102079,
					Value = 330,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得青面具 {Value1Divide}个",
			Skill = {
				{
					Id = 102079,
					Value = 360,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得青面具 {Value1Divide}个",
			Skill = {
				{
					Id = 102079,
					Value = 390,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得青面具 {Value1Divide}个",
			Skill = {
				{
					Id = 102079,
					Value = 420,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320305,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320306,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561202,
		561321,
		561340,
		561342,
		563103,
		563203,
		563709,
		563823,
		563303,
		563403,
		563502,
		563920,
		564004,
		564150,
		564108,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id079] =
{
	Id = 79,
	Name = "赤鱬",
	Area = 
	{
		130110,
	},
	Rarity = 2,
	Element = 210002,
	Gallery = 950003,
	Desc = "古代艺术家按照某种古生物的外形制作的泥塑，听老一辈说，这种生物是生活在极深的海底的，看见的人一旦出海就会遇到风暴。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_RedMermaid",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_RedMermaid",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectFire",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 68, Gain = 272},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "火元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102080,
					Value = 6,
				},
			},
		},
		{
			Stage = 2,
			Desc = "火元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102080,
					Value = 9,
				},
			},
		},
		{
			Stage = 3,
			Desc = "火元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102080,
					Value = 12,
				},
			},
		},
		{
			Stage = 4,
			Desc = "火元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102080,
					Value = 15,
				},
			},
		},
		{
			Stage = 5,
			Desc = "火元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102080,
					Value = 18,
				},
			},
		},
		{
			Stage = 6,
			Desc = "火元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102080,
					Value = 21,
				},
			},
		},
		{
			Stage = 7,
			Desc = "火元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102080,
					Value = 24,
				},
			},
		},
		{
			Stage = 8,
			Desc = "火元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102080,
					Value = 27,
				},
			},
		},
		{
			Stage = 9,
			Desc = "火元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102080,
					Value = 30,
				},
			},
		},
		{
			Stage = 10,
			Desc = "火元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102080,
					Value = 33,
				},
			},
		},
		{
			Stage = 11,
			Desc = "火元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102080,
					Value = 36,
				},
			},
		},
		{
			Stage = 12,
			Desc = "火元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102080,
					Value = 39,
				},
			},
		},
		{
			Stage = 13,
			Desc = "火元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102080,
					Value = 42,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320305,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320306,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561203,
		561321,
		561340,
		561342,
		563103,
		563203,
		563709,
		563823,
		563303,
		563403,
		563502,
		563920,
		564004,
		564150,
		564108,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id080] =
{
	Id = 80,
	Name = "寒带一角龙",
	Area = 
	{
		130111,
		130112,
	},
	Rarity = 2,
	Element = 210001,
	Gallery = 950003,
	Desc = "拥有厚实的皮层，不畏严寒的杂食性恐龙，愤怒时会喷吐寒流冻结目标。胃寒，不能喝冷饮。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_BlueDinosaur",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_BlueDinosaur",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWater",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 68, Gain = 272},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得龙角 {Value1Divide}个",
			Skill = {
				{
					Id = 102081,
					Value = 60,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得龙角 {Value1Divide}个",
			Skill = {
				{
					Id = 102081,
					Value = 90,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得龙角 {Value1Divide}个",
			Skill = {
				{
					Id = 102081,
					Value = 120,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得龙角 {Value1Divide}个",
			Skill = {
				{
					Id = 102081,
					Value = 150,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得龙角 {Value1Divide}个",
			Skill = {
				{
					Id = 102081,
					Value = 180,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得龙角 {Value1Divide}个",
			Skill = {
				{
					Id = 102081,
					Value = 210,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得龙角 {Value1Divide}个",
			Skill = {
				{
					Id = 102081,
					Value = 240,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得龙角 {Value1Divide}个",
			Skill = {
				{
					Id = 102081,
					Value = 270,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得龙角 {Value1Divide}个",
			Skill = {
				{
					Id = 102081,
					Value = 300,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得龙角 {Value1Divide}个",
			Skill = {
				{
					Id = 102081,
					Value = 330,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得龙角 {Value1Divide}个",
			Skill = {
				{
					Id = 102081,
					Value = 360,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得龙角 {Value1Divide}个",
			Skill = {
				{
					Id = 102081,
					Value = 390,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得龙角 {Value1Divide}个",
			Skill = {
				{
					Id = 102081,
					Value = 420,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320301,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320302,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561202,
		561303,
		561340,
		561338,
		563102,
		563203,
		563813,
		563303,
		563402,
		563503,
		563935,
		563903,
		564039,
		564028,
		564154,
		564204,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id081] =
{
	Id = 81,
	Name = "热带一角龙",
	Area = 
	{
		130111,
	},
	Rarity = 3,
	Element = 210002,
	Gallery = 950003,
	Desc = "拥有厚实的皮层，不畏高温的肉食性恐龙，愤怒时会喷吐岩浆融化目标。上火，不能吃辣的。",
	LevelUp = 910003,
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_RedDinosaur",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_RedDinosaur",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectFire",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 112, Gain = 448},
		{Value = 200004, Base = 10, Gain = 2},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "对风元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102082,
					Value = 50,
				},
			},
		},
		{
			Stage = 2,
			Desc = "对风元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102082,
					Value = 75,
				},
			},
		},
		{
			Stage = 3,
			Desc = "对风元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102082,
					Value = 100,
				},
			},
		},
		{
			Stage = 4,
			Desc = "对风元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102082,
					Value = 125,
				},
			},
		},
		{
			Stage = 5,
			Desc = "对风元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102082,
					Value = 150,
				},
			},
		},
		{
			Stage = 6,
			Desc = "对风元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102082,
					Value = 175,
				},
			},
		},
		{
			Stage = 7,
			Desc = "对风元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102082,
					Value = 200,
				},
			},
		},
		{
			Stage = 8,
			Desc = "对风元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102082,
					Value = 225,
				},
			},
		},
		{
			Stage = 9,
			Desc = "对风元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102082,
					Value = 250,
				},
			},
		},
		{
			Stage = 10,
			Desc = "对风元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102082,
					Value = 275,
				},
			},
		},
		{
			Stage = 11,
			Desc = "对风元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102082,
					Value = 300,
				},
			},
		},
		{
			Stage = 12,
			Desc = "对风元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102082,
					Value = 325,
				},
			},
		},
		{
			Stage = 13,
			Desc = "对风元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102082,
					Value = 350,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320302,
			CatchChance = 30,
			CatchChanceGain = 5,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 25,
			SuccessChanceGain = 2,
			SuccessChanceMax = 100,
		},
		{
			Value = 320303,
			CatchChance = 50,
			CatchChanceGain = 10,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561203,
		561303,
		561340,
		561338,
		563102,
		563203,
		563813,
		563303,
		563405,
		563503,
		563920,
		563903,
		564039,
		564028,
		564154,
		564204,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id082] =
{
	Id = 82,
	Name = "安全出口",
	Area = 
	{
		130112,
	},
	Rarity = 2,
	Element = 210005,
	Gallery = 950003,
	Desc = "指引游客离开博物馆的工作人员，什么叫安全呢？就是这个怪比较菜，新手也能打过。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_Exit",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_Exit",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectDark",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 68, Gain = 272},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得箭头 {Value1Divide}个",
			Skill = {
				{
					Id = 102083,
					Value = 60,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得箭头 {Value1Divide}个",
			Skill = {
				{
					Id = 102083,
					Value = 90,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得箭头 {Value1Divide}个",
			Skill = {
				{
					Id = 102083,
					Value = 120,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得箭头 {Value1Divide}个",
			Skill = {
				{
					Id = 102083,
					Value = 150,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得箭头 {Value1Divide}个",
			Skill = {
				{
					Id = 102083,
					Value = 180,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得箭头 {Value1Divide}个",
			Skill = {
				{
					Id = 102083,
					Value = 210,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得箭头 {Value1Divide}个",
			Skill = {
				{
					Id = 102083,
					Value = 240,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得箭头 {Value1Divide}个",
			Skill = {
				{
					Id = 102083,
					Value = 270,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得箭头 {Value1Divide}个",
			Skill = {
				{
					Id = 102083,
					Value = 300,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得箭头 {Value1Divide}个",
			Skill = {
				{
					Id = 102083,
					Value = 330,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得箭头 {Value1Divide}个",
			Skill = {
				{
					Id = 102083,
					Value = 360,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得箭头 {Value1Divide}个",
			Skill = {
				{
					Id = 102083,
					Value = 390,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得箭头 {Value1Divide}个",
			Skill = {
				{
					Id = 102083,
					Value = 420,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320313,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320314,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561206,
		561321,
		561335,
		563105,
		563203,
		563604,
		563814,
		563303,
		563402,
		563503,
		563940,
		563903,
		564029,
		564038,
		564052,
		564159,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id083] =
{
	Id = 83,
	Name = "快陶鸭",
	Area = 
	{
		130112,
	},
	Rarity = 4,
	Element = 210003,
	Gallery = 950003,
	Desc = "速度超快的陶土鸭，只要发现情况不妙，就会立刻逃跑，非常难捕捉。",
	LevelUp = 910004,
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_WoodenDuck",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_WoodenDuck",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 166, Gain = 664},
		{Value = 200004, Base = 15, Gain = 3},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "首位队员{Value1}%概率闪避攻击",
			Skill = {
				{
					Id = 102084,
					Value = 4,
				},
			},
		},
		{
			Stage = 2,
			Desc = "首位队员{Value1}%概率闪避攻击",
			Skill = {
				{
					Id = 102084,
					Value = 6,
				},
			},
		},
		{
			Stage = 3,
			Desc = "首位队员{Value1}%概率闪避攻击",
			Skill = {
				{
					Id = 102084,
					Value = 8,
				},
			},
		},
		{
			Stage = 4,
			Desc = "首位队员{Value1}%概率闪避攻击",
			Skill = {
				{
					Id = 102084,
					Value = 10,
				},
			},
		},
		{
			Stage = 5,
			Desc = "首位队员{Value1}%概率闪避攻击",
			Skill = {
				{
					Id = 102084,
					Value = 12,
				},
			},
		},
		{
			Stage = 6,
			Desc = "首位队员{Value1}%概率闪避攻击",
			Skill = {
				{
					Id = 102084,
					Value = 14,
				},
			},
		},
		{
			Stage = 7,
			Desc = "首位队员{Value1}%概率闪避攻击",
			Skill = {
				{
					Id = 102084,
					Value = 16,
				},
			},
		},
		{
			Stage = 8,
			Desc = "首位队员{Value1}%概率闪避攻击",
			Skill = {
				{
					Id = 102084,
					Value = 18,
				},
			},
		},
		{
			Stage = 9,
			Desc = "首位队员{Value1}%概率闪避攻击",
			Skill = {
				{
					Id = 102084,
					Value = 20,
				},
			},
		},
		{
			Stage = 10,
			Desc = "首位队员{Value1}%概率闪避攻击",
			Skill = {
				{
					Id = 102084,
					Value = 22,
				},
			},
		},
		{
			Stage = 11,
			Desc = "首位队员{Value1}%概率闪避攻击",
			Skill = {
				{
					Id = 102084,
					Value = 24,
				},
			},
		},
		{
			Stage = 12,
			Desc = "首位队员{Value1}%概率闪避攻击",
			Skill = {
				{
					Id = 102084,
					Value = 26,
				},
			},
		},
		{
			Stage = 13,
			Desc = "首位队员{Value1}%概率闪避攻击",
			Skill = {
				{
					Id = 102084,
					Value = 28,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320318,
			CatchChance = 5,
			CatchChanceGain = 12,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 5,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
		{
			Value = 320319,
			CatchChance = 33,
			CatchChanceGain = 25,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 33,
			SuccessChanceGain = 4,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560025,
		560045,
		560046,
		560032,
		560033,
		560034,
		560035,
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561204,
		561303,
		561340,
		563106,
		563206,
		563829,
		563303,
		563403,
		563502,
		563946,
		564016,
		564005,
		564150,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id084] =
{
	Id = 84,
	Name = "三花猫",
	Area = 
	{
		130151,
		130158,
		130157,
		130156,
		130155,
		130154,
		130153,
		130152,
	},
	Rarity = 1,
	Element = 210003,
	Gallery = 950004,
	Desc = "活跃在悬疑星的花猫，喜欢在安全的地方散步，如果路上发生状况，就会蹲在一边舔着舌头看热闹。\n它的舌头并没有三种花色。",
	LevelUp = 910001,
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_ColorfulCat",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_ColourfulCat",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 51, Gain = 204},
		{Value = 200004, Base = 0, Gain = 0},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102085,
					Value = 2,
				},
			},
		},
		{
			Stage = 2,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102085,
					Value = 3,
				},
			},
		},
		{
			Stage = 3,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102085,
					Value = 4,
				},
			},
		},
		{
			Stage = 4,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102085,
					Value = 5,
				},
			},
		},
		{
			Stage = 5,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102085,
					Value = 6,
				},
			},
		},
		{
			Stage = 6,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102085,
					Value = 7,
				},
			},
		},
		{
			Stage = 7,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102085,
					Value = 8,
				},
			},
		},
		{
			Stage = 8,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102085,
					Value = 9,
				},
			},
		},
		{
			Stage = 9,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102085,
					Value = 10,
				},
			},
		},
		{
			Stage = 10,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102085,
					Value = 11,
				},
			},
		},
		{
			Stage = 11,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102085,
					Value = 12,
				},
			},
		},
		{
			Stage = 12,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102085,
					Value = 13,
				},
			},
		},
		{
			Stage = 13,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102085,
					Value = 14,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320317,
			CatchChance = 50,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560022,
		560042,
		560043,
		560044,
		560045,
		560046,
		560032,
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561204,
		561303,
		561346,
		563106,
		563205,
		563704,
		563824,
		563303,
		563404,
		563505,
		563905,
		563924,
		563929,
		564015,
		564019,
		564154,
		564204,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id085] =
{
	Id = 85,
	Name = "白猫",
	Area = 
	{
		130153,
		130162,
		130155,
	},
	Rarity = 3,
	Element = 210004,
	Gallery = 950004,
	Desc = "行动非常敏捷的白色猫咪，经常在悬疑星各大咖啡馆出没，偶尔也会出现在无人的街道上。",
	LevelUp = 910003,
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_WhiteCat",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_WhiteCat",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectLight",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 123, Gain = 492},
		{Value = 200004, Base = 10, Gain = 2},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "末位队员{Value1}%概率无视敌人闪避",
			Skill = {
				{
					Id = 102086,
					Value = 4,
				},
			},
		},
		{
			Stage = 2,
			Desc = "末位队员{Value1}%概率无视敌人闪避",
			Skill = {
				{
					Id = 102086,
					Value = 6,
				},
			},
		},
		{
			Stage = 3,
			Desc = "末位队员{Value1}%概率无视敌人闪避",
			Skill = {
				{
					Id = 102086,
					Value = 8,
				},
			},
		},
		{
			Stage = 4,
			Desc = "末位队员{Value1}%概率无视敌人闪避",
			Skill = {
				{
					Id = 102086,
					Value = 10,
				},
			},
		},
		{
			Stage = 5,
			Desc = "末位队员{Value1}%概率无视敌人闪避",
			Skill = {
				{
					Id = 102086,
					Value = 12,
				},
			},
		},
		{
			Stage = 6,
			Desc = "末位队员{Value1}%概率无视敌人闪避",
			Skill = {
				{
					Id = 102086,
					Value = 14,
				},
			},
		},
		{
			Stage = 7,
			Desc = "末位队员{Value1}%概率无视敌人闪避",
			Skill = {
				{
					Id = 102086,
					Value = 16,
				},
			},
		},
		{
			Stage = 8,
			Desc = "末位队员{Value1}%概率无视敌人闪避",
			Skill = {
				{
					Id = 102086,
					Value = 18,
				},
			},
		},
		{
			Stage = 9,
			Desc = "末位队员{Value1}%概率无视敌人闪避",
			Skill = {
				{
					Id = 102086,
					Value = 20,
				},
			},
		},
		{
			Stage = 10,
			Desc = "末位队员{Value1}%概率无视敌人闪避",
			Skill = {
				{
					Id = 102086,
					Value = 22,
				},
			},
		},
		{
			Stage = 11,
			Desc = "末位队员{Value1}%概率无视敌人闪避",
			Skill = {
				{
					Id = 102086,
					Value = 24,
				},
			},
		},
		{
			Stage = 12,
			Desc = "末位队员{Value1}%概率无视敌人闪避",
			Skill = {
				{
					Id = 102086,
					Value = 26,
				},
			},
		},
		{
			Stage = 13,
			Desc = "末位队员{Value1}%概率无视敌人闪避",
			Skill = {
				{
					Id = 102086,
					Value = 28,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320318,
			CatchChance = 30,
			CatchChanceGain = 5,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 25,
			SuccessChanceGain = 2,
			SuccessChanceMax = 100,
		},
		{
			Value = 320319,
			CatchChance = 50,
			CatchChanceGain = 10,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561205,
		561303,
		561346,
		563106,
		563206,
		563704,
		563824,
		563303,
		563404,
		563503,
		563906,
		563943,
		564015,
		564019,
		564154,
		564204,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id086] =
{
	Id = 86,
	Name = "黑猫",
	Area = 
	{
		130156,
		130163,
	},
	Rarity = 3,
	Element = 210005,
	Gallery = 950004,
	Desc = "神秘的黑色猫咪，经常出现在事故现场，会不会是死神的凡间化身呢？",
	LevelUp = 910003,
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_BlackCat",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_BlackCat",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectDark",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 123, Gain = 492},
		{Value = 200004, Base = 10, Gain = 2},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "末位队员{Value1}%概率额外攻击1次",
			Skill = {
				{
					Id = 102087,
					Value = 6,
				},
			},
		},
		{
			Stage = 2,
			Desc = "末位队员{Value1}%概率额外攻击1次",
			Skill = {
				{
					Id = 102087,
					Value = 9,
				},
			},
		},
		{
			Stage = 3,
			Desc = "末位队员{Value1}%概率额外攻击1次",
			Skill = {
				{
					Id = 102087,
					Value = 12,
				},
			},
		},
		{
			Stage = 4,
			Desc = "末位队员{Value1}%概率额外攻击1次",
			Skill = {
				{
					Id = 102087,
					Value = 15,
				},
			},
		},
		{
			Stage = 5,
			Desc = "末位队员{Value1}%概率额外攻击1次",
			Skill = {
				{
					Id = 102087,
					Value = 18,
				},
			},
		},
		{
			Stage = 6,
			Desc = "末位队员{Value1}%概率额外攻击1次",
			Skill = {
				{
					Id = 102087,
					Value = 21,
				},
			},
		},
		{
			Stage = 7,
			Desc = "末位队员{Value1}%概率额外攻击1次",
			Skill = {
				{
					Id = 102087,
					Value = 24,
				},
			},
		},
		{
			Stage = 8,
			Desc = "末位队员{Value1}%概率额外攻击1次",
			Skill = {
				{
					Id = 102087,
					Value = 27,
				},
			},
		},
		{
			Stage = 9,
			Desc = "末位队员{Value1}%概率额外攻击1次",
			Skill = {
				{
					Id = 102087,
					Value = 30,
				},
			},
		},
		{
			Stage = 10,
			Desc = "末位队员{Value1}%概率额外攻击1次",
			Skill = {
				{
					Id = 102087,
					Value = 33,
				},
			},
		},
		{
			Stage = 11,
			Desc = "末位队员{Value1}%概率额外攻击1次",
			Skill = {
				{
					Id = 102087,
					Value = 36,
				},
			},
		},
		{
			Stage = 12,
			Desc = "末位队员{Value1}%概率额外攻击1次",
			Skill = {
				{
					Id = 102087,
					Value = 39,
				},
			},
		},
		{
			Stage = 13,
			Desc = "末位队员{Value1}%概率额外攻击1次",
			Skill = {
				{
					Id = 102087,
					Value = 42,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320318,
			CatchChance = 30,
			CatchChanceGain = 5,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 25,
			SuccessChanceGain = 2,
			SuccessChanceMax = 100,
		},
		{
			Value = 320319,
			CatchChance = 50,
			CatchChanceGain = 10,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561206,
		561303,
		561346,
		563106,
		563205,
		563704,
		563824,
		563303,
		563404,
		563503,
		563916,
		563943,
		564015,
		564024,
		564154,
		564204,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id087] =
{
	Id = 87,
	Name = "情书",
	Area = 
	{
		130152,
		130160,
		130154,
		130153,
	},
	Rarity = 2,
	Element = 210003,
	Gallery = 950004,
	Desc = "为人们传递情意的信件，读的时候会起一身的鸡皮疙瘩，因此很棘手。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_LoveLetter",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_LoveLetter",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 76, Gain = 304},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得暗恋 {Value1Divide}个",
			Skill = {
				{
					Id = 102088,
					Value = 60,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得暗恋 {Value1Divide}个",
			Skill = {
				{
					Id = 102088,
					Value = 90,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得暗恋 {Value1Divide}个",
			Skill = {
				{
					Id = 102088,
					Value = 120,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得暗恋 {Value1Divide}个",
			Skill = {
				{
					Id = 102088,
					Value = 150,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得暗恋 {Value1Divide}个",
			Skill = {
				{
					Id = 102088,
					Value = 180,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得暗恋 {Value1Divide}个",
			Skill = {
				{
					Id = 102088,
					Value = 210,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得暗恋 {Value1Divide}个",
			Skill = {
				{
					Id = 102088,
					Value = 240,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得暗恋 {Value1Divide}个",
			Skill = {
				{
					Id = 102088,
					Value = 270,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得暗恋 {Value1Divide}个",
			Skill = {
				{
					Id = 102088,
					Value = 300,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得暗恋 {Value1Divide}个",
			Skill = {
				{
					Id = 102088,
					Value = 330,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得暗恋 {Value1Divide}个",
			Skill = {
				{
					Id = 102088,
					Value = 360,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得暗恋 {Value1Divide}个",
			Skill = {
				{
					Id = 102088,
					Value = 390,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得暗恋 {Value1Divide}个",
			Skill = {
				{
					Id = 102088,
					Value = 420,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320305,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320306,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561204,
		561321,
		561343,
		563103,
		563203,
		563604,
		563817,
		563303,
		563402,
		563503,
		563910,
		563917,
		564019,
		564012,
		564058,
		564158,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id088] =
{
	Id = 88,
	Name = "粉红帽",
	Area = 
	{
		130152,
	},
	Rarity = 2,
	Element = 210001,
	Gallery = 950004,
	Desc = "喜欢下午和好朋友一起去逛街的帽子小姐，经常会卷入案件中。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_PinkHat",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_PinkHat",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWater",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 76, Gain = 304},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "风元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102089,
					Value = -4,
				},
			},
		},
		{
			Stage = 2,
			Desc = "风元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102089,
					Value = -6,
				},
			},
		},
		{
			Stage = 3,
			Desc = "风元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102089,
					Value = -8,
				},
			},
		},
		{
			Stage = 4,
			Desc = "风元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102089,
					Value = -10,
				},
			},
		},
		{
			Stage = 5,
			Desc = "风元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102089,
					Value = -12,
				},
			},
		},
		{
			Stage = 6,
			Desc = "风元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102089,
					Value = -14,
				},
			},
		},
		{
			Stage = 7,
			Desc = "风元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102089,
					Value = -16,
				},
			},
		},
		{
			Stage = 8,
			Desc = "风元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102089,
					Value = -18,
				},
			},
		},
		{
			Stage = 9,
			Desc = "风元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102089,
					Value = -20,
				},
			},
		},
		{
			Stage = 10,
			Desc = "风元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102089,
					Value = -22,
				},
			},
		},
		{
			Stage = 11,
			Desc = "风元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102089,
					Value = -24,
				},
			},
		},
		{
			Stage = 12,
			Desc = "风元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102089,
					Value = -26,
				},
			},
		},
		{
			Stage = 13,
			Desc = "风元素敌人战力 -{Value1}%",
			Skill = {
				{
					Id = 102089,
					Value = -28,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320309,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320310,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561202,
		561344,
		561345,
		561703,
		563104,
		563203,
		563613,
		563824,
		563305,
		563403,
		563503,
		563911,
		563902,
		564019,
		564158,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id089] =
{
	Id = 89,
	Name = "邮筒",
	Area = 
	{
		130152,
		130153,
	},
	Rarity = 3,
	Element = 210002,
	Gallery = 950004,
	Desc = "帮助附近居民寄出邮件的重要设施，最讨厌被人骂邮筒腰。",
	LevelUp = 910003,
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_MailBox",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_MailBox",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectFire",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 123, Gain = 492},
		{Value = 200004, Base = 10, Gain = 2},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "火元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102090,
					Value = 4,
				},
			},
		},
		{
			Stage = 2,
			Desc = "火元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102090,
					Value = 6,
				},
			},
		},
		{
			Stage = 3,
			Desc = "火元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102090,
					Value = 8,
				},
			},
		},
		{
			Stage = 4,
			Desc = "火元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102090,
					Value = 10,
				},
			},
		},
		{
			Stage = 5,
			Desc = "火元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102090,
					Value = 12,
				},
			},
		},
		{
			Stage = 6,
			Desc = "火元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102090,
					Value = 14,
				},
			},
		},
		{
			Stage = 7,
			Desc = "火元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102090,
					Value = 16,
				},
			},
		},
		{
			Stage = 8,
			Desc = "火元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102090,
					Value = 18,
				},
			},
		},
		{
			Stage = 9,
			Desc = "火元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102090,
					Value = 20,
				},
			},
		},
		{
			Stage = 10,
			Desc = "火元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102090,
					Value = 22,
				},
			},
		},
		{
			Stage = 11,
			Desc = "火元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102090,
					Value = 24,
				},
			},
		},
		{
			Stage = 12,
			Desc = "火元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102090,
					Value = 26,
				},
			},
		},
		{
			Stage = 13,
			Desc = "火元素队员战力 +{Value1}%",
			Skill = {
				{
					Id = 102090,
					Value = 28,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320314,
			CatchChance = 30,
			CatchChanceGain = 5,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 25,
			SuccessChanceGain = 2,
			SuccessChanceMax = 100,
		},
		{
			Value = 320315,
			CatchChance = 50,
			CatchChanceGain = 10,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561203,
		561344,
		561345,
		563105,
		563203,
		563624,
		563814,
		563305,
		563402,
		563502,
		563920,
		564029,
		564052,
		564058,
		564159,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id090] =
{
	Id = 90,
	Name = "报纸",
	Area = 
	{
		130153,
		130161,
		130157,
	},
	Rarity = 2,
	Element = 210003,
	Gallery = 950004,
	Desc = "常驻咖啡馆的报纸先生，会把今天的新闻登在身上，让别人阅读。\n有没有人提醒一下，他拿反了。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Newspaper",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Newspaper",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 76, Gain = 304},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得新闻 {Value1Divide}个",
			Skill = {
				{
					Id = 102091,
					Value = 50,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得新闻 {Value1Divide}个",
			Skill = {
				{
					Id = 102091,
					Value = 75,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得新闻 {Value1Divide}个",
			Skill = {
				{
					Id = 102091,
					Value = 100,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得新闻 {Value1Divide}个",
			Skill = {
				{
					Id = 102091,
					Value = 125,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得新闻 {Value1Divide}个",
			Skill = {
				{
					Id = 102091,
					Value = 150,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得新闻 {Value1Divide}个",
			Skill = {
				{
					Id = 102091,
					Value = 175,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得新闻 {Value1Divide}个",
			Skill = {
				{
					Id = 102091,
					Value = 200,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得新闻 {Value1Divide}个",
			Skill = {
				{
					Id = 102091,
					Value = 225,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得新闻 {Value1Divide}个",
			Skill = {
				{
					Id = 102091,
					Value = 250,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得新闻 {Value1Divide}个",
			Skill = {
				{
					Id = 102091,
					Value = 275,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得新闻 {Value1Divide}个",
			Skill = {
				{
					Id = 102091,
					Value = 300,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得新闻 {Value1Divide}个",
			Skill = {
				{
					Id = 102091,
					Value = 325,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得新闻 {Value1Divide}个",
			Skill = {
				{
					Id = 102091,
					Value = 350,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320305,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320306,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561204,
		561321,
		561343,
		563103,
		563203,
		563604,
		563829,
		563305,
		563402,
		563502,
		563945,
		564004,
		564013,
		564060,
		564158,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id091] =
{
	Id = 91,
	Name = "礼帽",
	Area = 
	{
		130153,
	},
	Rarity = 3,
	Element = 210001,
	Gallery = 950004,
	Desc = "喜欢下午独自一人去咖啡店的帽子先生，非常绅士，会替女性遮挡阳光。",
	LevelUp = 910003,
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_BlackHat",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_BlackHat",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWater",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 123, Gain = 492},
		{Value = 200004, Base = 10, Gain = 2},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "暗元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102092,
					Value = 4,
				},
			},
		},
		{
			Stage = 2,
			Desc = "暗元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102092,
					Value = 6,
				},
			},
		},
		{
			Stage = 3,
			Desc = "暗元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102092,
					Value = 8,
				},
			},
		},
		{
			Stage = 4,
			Desc = "暗元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102092,
					Value = 10,
				},
			},
		},
		{
			Stage = 5,
			Desc = "暗元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102092,
					Value = 12,
				},
			},
		},
		{
			Stage = 6,
			Desc = "暗元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102092,
					Value = 14,
				},
			},
		},
		{
			Stage = 7,
			Desc = "暗元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102092,
					Value = 16,
				},
			},
		},
		{
			Stage = 8,
			Desc = "暗元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102092,
					Value = 18,
				},
			},
		},
		{
			Stage = 9,
			Desc = "暗元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102092,
					Value = 20,
				},
			},
		},
		{
			Stage = 10,
			Desc = "暗元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102092,
					Value = 22,
				},
			},
		},
		{
			Stage = 11,
			Desc = "暗元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102092,
					Value = 24,
				},
			},
		},
		{
			Stage = 12,
			Desc = "暗元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102092,
					Value = 26,
				},
			},
		},
		{
			Stage = 13,
			Desc = "暗元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102092,
					Value = 28,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320310,
			CatchChance = 30,
			CatchChanceGain = 5,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 25,
			SuccessChanceGain = 2,
			SuccessChanceMax = 100,
		},
		{
			Value = 320311,
			CatchChance = 50,
			CatchChanceGain = 10,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561202,
		561344,
		561345,
		561702,
		563104,
		563203,
		563613,
		563824,
		563303,
		563403,
		563503,
		563935,
		563914,
		564009,
		564060,
		564158,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id092] =
{
	Id = 92,
	Name = "羽毛笔",
	Area = 
	{
		130154,
		130162,
		130159,
	},
	Rarity = 2,
	Element = 210003,
	Gallery = 950004,
	Desc = "羽毛笔很喜欢现在的工作，在从鸟身上掉下来之前，它并没有想到自己的人生还能有第二春。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_FeatherPen",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_FeatherPen",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 76, Gain = 304},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "光元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102093,
					Value = 3,
				},
			},
		},
		{
			Stage = 2,
			Desc = "光元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102093,
					Value = 4,
				},
			},
		},
		{
			Stage = 3,
			Desc = "光元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102093,
					Value = 5,
				},
			},
		},
		{
			Stage = 4,
			Desc = "光元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102093,
					Value = 6,
				},
			},
		},
		{
			Stage = 5,
			Desc = "光元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102093,
					Value = 7,
				},
			},
		},
		{
			Stage = 6,
			Desc = "光元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102093,
					Value = 8,
				},
			},
		},
		{
			Stage = 7,
			Desc = "光元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102093,
					Value = 9,
				},
			},
		},
		{
			Stage = 8,
			Desc = "光元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102093,
					Value = 10,
				},
			},
		},
		{
			Stage = 9,
			Desc = "光元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102093,
					Value = 11,
				},
			},
		},
		{
			Stage = 10,
			Desc = "光元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102093,
					Value = 12,
				},
			},
		},
		{
			Stage = 11,
			Desc = "光元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102093,
					Value = 13,
				},
			},
		},
		{
			Stage = 12,
			Desc = "光元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102093,
					Value = 14,
				},
			},
		},
		{
			Stage = 13,
			Desc = "光元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102093,
					Value = 15,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320309,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320310,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561204,
		561321,
		561348,
		563104,
		563203,
		563622,
		563824,
		563305,
		563402,
		563502,
		563905,
		564014,
		564060,
		564158,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id093] =
{
	Id = 93,
	Name = "邮票",
	Area = 
	{
		130154,
		130158,
	},
	Rarity = 2,
	Element = 210001,
	Gallery = 950004,
	Desc = "性格强硬，坚持把每一个舔它的人都以性骚扰的罪名告上了法庭。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Stamp",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Stamp",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWater",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 76, Gain = 304},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得羽毛 {Value1Divide}个",
			Skill = {
				{
					Id = 102094,
					Value = 60,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得羽毛 {Value1Divide}个",
			Skill = {
				{
					Id = 102094,
					Value = 90,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得羽毛 {Value1Divide}个",
			Skill = {
				{
					Id = 102094,
					Value = 120,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得羽毛 {Value1Divide}个",
			Skill = {
				{
					Id = 102094,
					Value = 150,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得羽毛 {Value1Divide}个",
			Skill = {
				{
					Id = 102094,
					Value = 180,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得羽毛 {Value1Divide}个",
			Skill = {
				{
					Id = 102094,
					Value = 210,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得羽毛 {Value1Divide}个",
			Skill = {
				{
					Id = 102094,
					Value = 240,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得羽毛 {Value1Divide}个",
			Skill = {
				{
					Id = 102094,
					Value = 270,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得羽毛 {Value1Divide}个",
			Skill = {
				{
					Id = 102094,
					Value = 300,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得羽毛 {Value1Divide}个",
			Skill = {
				{
					Id = 102094,
					Value = 330,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得羽毛 {Value1Divide}个",
			Skill = {
				{
					Id = 102094,
					Value = 360,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得羽毛 {Value1Divide}个",
			Skill = {
				{
					Id = 102094,
					Value = 390,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得羽毛 {Value1Divide}个",
			Skill = {
				{
					Id = 102094,
					Value = 420,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320309,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320310,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561202,
		561321,
		561343,
		563104,
		563203,
		563604,
		563812,
		563303,
		563402,
		563504,
		563904,
		563917,
		563932,
		564019,
		564058,
		564158,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id094] =
{
	Id = 94,
	Name = "信封",
	Area = 
	{
		130154,
	},
	Rarity = 3,
	Element = 210003,
	Gallery = 950004,
	Desc = "性格有些古怪，经常自言自语，会被周围的人所害怕。\n哦，想出来吗？哈哈！真可惜啊，你是绝对不可能突破我的封锁的！信！",
	LevelUp = 910003,
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Letter",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Letter",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 123, Gain = 492},
		{Value = 200004, Base = 10, Gain = 2},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "全队暴击 +{Value1}",
			Skill = {
				{
					Id = 102095,
					Value = 3,
				},
			},
		},
		{
			Stage = 2,
			Desc = "全队暴击 +{Value1}",
			Skill = {
				{
					Id = 102095,
					Value = 4,
				},
			},
		},
		{
			Stage = 3,
			Desc = "全队暴击 +{Value1}",
			Skill = {
				{
					Id = 102095,
					Value = 5,
				},
			},
		},
		{
			Stage = 4,
			Desc = "全队暴击 +{Value1}",
			Skill = {
				{
					Id = 102095,
					Value = 6,
				},
			},
		},
		{
			Stage = 5,
			Desc = "全队暴击 +{Value1}",
			Skill = {
				{
					Id = 102095,
					Value = 7,
				},
			},
		},
		{
			Stage = 6,
			Desc = "全队暴击 +{Value1}",
			Skill = {
				{
					Id = 102095,
					Value = 8,
				},
			},
		},
		{
			Stage = 7,
			Desc = "全队暴击 +{Value1}",
			Skill = {
				{
					Id = 102095,
					Value = 9,
				},
			},
		},
		{
			Stage = 8,
			Desc = "全队暴击 +{Value1}",
			Skill = {
				{
					Id = 102095,
					Value = 10,
				},
			},
		},
		{
			Stage = 9,
			Desc = "全队暴击 +{Value1}",
			Skill = {
				{
					Id = 102095,
					Value = 11,
				},
			},
		},
		{
			Stage = 10,
			Desc = "全队暴击 +{Value1}",
			Skill = {
				{
					Id = 102095,
					Value = 12,
				},
			},
		},
		{
			Stage = 11,
			Desc = "全队暴击 +{Value1}",
			Skill = {
				{
					Id = 102095,
					Value = 13,
				},
			},
		},
		{
			Stage = 12,
			Desc = "全队暴击 +{Value1}",
			Skill = {
				{
					Id = 102095,
					Value = 14,
				},
			},
		},
		{
			Stage = 13,
			Desc = "全队暴击 +{Value1}",
			Skill = {
				{
					Id = 102095,
					Value = 15,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320306,
			CatchChance = 30,
			CatchChanceGain = 5,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 25,
			SuccessChanceGain = 2,
			SuccessChanceMax = 100,
		},
		{
			Value = 320307,
			CatchChance = 50,
			CatchChanceGain = 10,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561204,
		561321,
		561343,
		563103,
		563203,
		563604,
		563812,
		563303,
		563402,
		563504,
		563905,
		563917,
		563932,
		564019,
		564013,
		564058,
		564158,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id095] =
{
	Id = 95,
	Name = "门牌",
	Area = 
	{
		130155,
		130157,
	},
	Rarity = 2,
	Element = 210003,
	Gallery = 950004,
	Desc = "经常溜到案件现场看热闹的门牌先生，有时候会发表自己的高见,由于顶着自己的住址而总是会泄露个人信息。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_NumberPlate",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_NumberPlate",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 76, Gain = 304},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得钥匙 {Value1Divide}个",
			Skill = {
				{
					Id = 102096,
					Value = 50,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得钥匙 {Value1Divide}个",
			Skill = {
				{
					Id = 102096,
					Value = 75,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得钥匙 {Value1Divide}个",
			Skill = {
				{
					Id = 102096,
					Value = 100,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得钥匙 {Value1Divide}个",
			Skill = {
				{
					Id = 102096,
					Value = 125,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得钥匙 {Value1Divide}个",
			Skill = {
				{
					Id = 102096,
					Value = 150,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得钥匙 {Value1Divide}个",
			Skill = {
				{
					Id = 102096,
					Value = 175,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得钥匙 {Value1Divide}个",
			Skill = {
				{
					Id = 102096,
					Value = 200,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得钥匙 {Value1Divide}个",
			Skill = {
				{
					Id = 102096,
					Value = 225,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得钥匙 {Value1Divide}个",
			Skill = {
				{
					Id = 102096,
					Value = 250,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得钥匙 {Value1Divide}个",
			Skill = {
				{
					Id = 102096,
					Value = 275,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得钥匙 {Value1Divide}个",
			Skill = {
				{
					Id = 102096,
					Value = 300,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得钥匙 {Value1Divide}个",
			Skill = {
				{
					Id = 102096,
					Value = 325,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得钥匙 {Value1Divide}个",
			Skill = {
				{
					Id = 102096,
					Value = 350,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320313,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320314,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561204,
		561321,
		561335,
		563105,
		563203,
		563604,
		563815,
		563303,
		563402,
		563503,
		563940,
		563923,
		564028,
		564052,
		564159,
		564114,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id096] =
{
	Id = 96,
	Name = "工地路障",
	Area = 
	{
		130155,
		130156,
	},
	Rarity = 2,
	Element = 210005,
	Gallery = 950004,
	Desc = "经常被放置在工地使用的黄黑警用路障，因为颜色本身就比较脏的关系，所以很耐脏。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_YellowBarrier",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_YellowBarrier",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectDark",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 76, Gain = 304},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "光元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102097,
					Value = 6,
				},
			},
		},
		{
			Stage = 2,
			Desc = "光元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102097,
					Value = 9,
				},
			},
		},
		{
			Stage = 3,
			Desc = "光元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102097,
					Value = 12,
				},
			},
		},
		{
			Stage = 4,
			Desc = "光元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102097,
					Value = 15,
				},
			},
		},
		{
			Stage = 5,
			Desc = "光元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102097,
					Value = 18,
				},
			},
		},
		{
			Stage = 6,
			Desc = "光元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102097,
					Value = 21,
				},
			},
		},
		{
			Stage = 7,
			Desc = "光元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102097,
					Value = 24,
				},
			},
		},
		{
			Stage = 8,
			Desc = "光元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102097,
					Value = 27,
				},
			},
		},
		{
			Stage = 9,
			Desc = "光元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102097,
					Value = 30,
				},
			},
		},
		{
			Stage = 10,
			Desc = "光元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102097,
					Value = 33,
				},
			},
		},
		{
			Stage = 11,
			Desc = "光元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102097,
					Value = 36,
				},
			},
		},
		{
			Stage = 12,
			Desc = "光元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102097,
					Value = 39,
				},
			},
		},
		{
			Stage = 13,
			Desc = "光元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102097,
					Value = 42,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320317,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320318,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561206,
		561321,
		561337,
		563106,
		563203,
		563625,
		563813,
		563303,
		563402,
		563503,
		563925,
		563913,
		564029,
		564159,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id097] =
{
	Id = 97,
	Name = "煤气灯",
	Area = 
	{
		130155,
	},
	Rarity = 3,
	Element = 210002,
	Gallery = 950004,
	Desc = "安装在大街上提供行人照明的设施，性格火爆，一点就炸。\n然后就没有然后了。",
	LevelUp = 910003,
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_StreetLamp",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_StreetLamp",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectFire",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 123, Gain = 492},
		{Value = 200004, Base = 10, Gain = 2},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102098,
					Value = 4,
				},
			},
		},
		{
			Stage = 2,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102098,
					Value = 6,
				},
			},
		},
		{
			Stage = 3,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102098,
					Value = 8,
				},
			},
		},
		{
			Stage = 4,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102098,
					Value = 10,
				},
			},
		},
		{
			Stage = 5,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102098,
					Value = 12,
				},
			},
		},
		{
			Stage = 6,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102098,
					Value = 14,
				},
			},
		},
		{
			Stage = 7,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102098,
					Value = 16,
				},
			},
		},
		{
			Stage = 8,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102098,
					Value = 18,
				},
			},
		},
		{
			Stage = 9,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102098,
					Value = 20,
				},
			},
		},
		{
			Stage = 10,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102098,
					Value = 22,
				},
			},
		},
		{
			Stage = 11,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102098,
					Value = 24,
				},
			},
		},
		{
			Stage = 12,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102098,
					Value = 26,
				},
			},
		},
		{
			Stage = 13,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102098,
					Value = 28,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320314,
			CatchChance = 30,
			CatchChanceGain = 5,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 25,
			SuccessChanceGain = 2,
			SuccessChanceMax = 100,
		},
		{
			Value = 320315,
			CatchChance = 50,
			CatchChanceGain = 10,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561203,
		561321,
		561353,
		561322,
		563105,
		563203,
		563625,
		563815,
		563303,
		563404,
		563503,
		563941,
		563923,
		564005,
		564054,
		564159,
		564114,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id098] =
{
	Id = 98,
	Name = "窨井盖",
	Area = 
	{
		130156,
		130162,
		130160,
	},
	Rarity = 2,
	Element = 210005,
	Gallery = 950004,
	Desc = "勤恳踏实的底层员工，最大的梦想是有朝一日不被人踩在脸上。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_ManholeCover",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_ManholeCover",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectDark",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 76, Gain = 304},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得脚印 {Value1Divide}个",
			Skill = {
				{
					Id = 102099,
					Value = 50,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得脚印 {Value1Divide}个",
			Skill = {
				{
					Id = 102099,
					Value = 75,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得脚印 {Value1Divide}个",
			Skill = {
				{
					Id = 102099,
					Value = 100,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得脚印 {Value1Divide}个",
			Skill = {
				{
					Id = 102099,
					Value = 125,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得脚印 {Value1Divide}个",
			Skill = {
				{
					Id = 102099,
					Value = 150,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得脚印 {Value1Divide}个",
			Skill = {
				{
					Id = 102099,
					Value = 175,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得脚印 {Value1Divide}个",
			Skill = {
				{
					Id = 102099,
					Value = 200,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得脚印 {Value1Divide}个",
			Skill = {
				{
					Id = 102099,
					Value = 225,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得脚印 {Value1Divide}个",
			Skill = {
				{
					Id = 102099,
					Value = 250,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得脚印 {Value1Divide}个",
			Skill = {
				{
					Id = 102099,
					Value = 275,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得脚印 {Value1Divide}个",
			Skill = {
				{
					Id = 102099,
					Value = 300,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得脚印 {Value1Divide}个",
			Skill = {
				{
					Id = 102099,
					Value = 325,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得脚印 {Value1Divide}个",
			Skill = {
				{
					Id = 102099,
					Value = 350,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320313,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320314,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561206,
		561321,
		561354,
		563105,
		563205,
		563621,
		563815,
		563302,
		563402,
		563502,
		563915,
		564039,
		564160,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id099] =
{
	Id = 99,
	Name = "警用路障",
	Area = 
	{
		130156,
	},
	Rarity = 3,
	Element = 210002,
	Gallery = 950004,
	Desc = "警方设置在禁行区的路障，有时会被不知从何处来的僵尸偷走。",
	LevelUp = 910003,
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_RedBarrier",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_RedBarrier",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectFire",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 123, Gain = 492},
		{Value = 200004, Base = 10, Gain = 2},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102100,
					Value = 3,
				},
			},
		},
		{
			Stage = 2,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102100,
					Value = 4,
				},
			},
		},
		{
			Stage = 3,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102100,
					Value = 5,
				},
			},
		},
		{
			Stage = 4,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102100,
					Value = 6,
				},
			},
		},
		{
			Stage = 5,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102100,
					Value = 7,
				},
			},
		},
		{
			Stage = 6,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102100,
					Value = 8,
				},
			},
		},
		{
			Stage = 7,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102100,
					Value = 9,
				},
			},
		},
		{
			Stage = 8,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102100,
					Value = 10,
				},
			},
		},
		{
			Stage = 9,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102100,
					Value = 11,
				},
			},
		},
		{
			Stage = 10,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102100,
					Value = 12,
				},
			},
		},
		{
			Stage = 11,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102100,
					Value = 13,
				},
			},
		},
		{
			Stage = 12,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102100,
					Value = 14,
				},
			},
		},
		{
			Stage = 13,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102100,
					Value = 15,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320318,
			CatchChance = 30,
			CatchChanceGain = 5,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 25,
			SuccessChanceGain = 2,
			SuccessChanceMax = 100,
		},
		{
			Value = 320319,
			CatchChance = 50,
			CatchChanceGain = 10,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561203,
		561321,
		561337,
		563106,
		563203,
		563625,
		563813,
		563303,
		563402,
		563503,
		563920,
		563903,
		564030,
		564159,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id100] =
{
	Id = 100,
	Name = "消防栓",
	Area = 
	{
		130156,
	},
	Rarity = 4,
	Element = 210001,
	Gallery = 950004,
	Desc = "只要简单操作就能为外接设备持续供水的设施，是街道消防必不可少的好伙伴。",
	LevelUp = 910004,
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Hydrant",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Hydrant",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWater",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 179, Gain = 716},
		{Value = 200004, Base = 15, Gain = 3},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "对火元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102101,
					Value = 50,
				},
			},
		},
		{
			Stage = 2,
			Desc = "对火元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102101,
					Value = 75,
				},
			},
		},
		{
			Stage = 3,
			Desc = "对火元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102101,
					Value = 100,
				},
			},
		},
		{
			Stage = 4,
			Desc = "对火元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102101,
					Value = 125,
				},
			},
		},
		{
			Stage = 5,
			Desc = "对火元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102101,
					Value = 150,
				},
			},
		},
		{
			Stage = 6,
			Desc = "对火元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102101,
					Value = 175,
				},
			},
		},
		{
			Stage = 7,
			Desc = "对火元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102101,
					Value = 200,
				},
			},
		},
		{
			Stage = 8,
			Desc = "对火元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102101,
					Value = 225,
				},
			},
		},
		{
			Stage = 9,
			Desc = "对火元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102101,
					Value = 250,
				},
			},
		},
		{
			Stage = 10,
			Desc = "对火元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102101,
					Value = 275,
				},
			},
		},
		{
			Stage = 11,
			Desc = "对火元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102101,
					Value = 300,
				},
			},
		},
		{
			Stage = 12,
			Desc = "对火元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102101,
					Value = 325,
				},
			},
		},
		{
			Stage = 13,
			Desc = "对火元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102101,
					Value = 350,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320314,
			CatchChance = 5,
			CatchChanceGain = 12,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 5,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
		{
			Value = 320315,
			CatchChance = 33,
			CatchChanceGain = 25,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 33,
			SuccessChanceGain = 4,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560025,
		560045,
		560046,
		560032,
		560033,
		560034,
		560035,
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561202,
		561321,
		561337,
		561322,
		563105,
		563203,
		563624,
		563815,
		563303,
		563402,
		563503,
		563920,
		563903,
		564029,
		564054,
		564160,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id101] =
{
	Id = 101,
	Name = "烟灰缸",
	Area = 
	{
		130157,
		130161,
		130159,
	},
	Rarity = 2,
	Element = 210003,
	Gallery = 950004,
	Desc = "城市的治安有多大压力，烟灰缸中就有多少烟头。在这座城市的警局中，烟灰缸也用自己的方式维持着治安。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Ashtray",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Ashtray",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 76, Gain = 304},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得烟头 {Value1Divide}个",
			Skill = {
				{
					Id = 102102,
					Value = 50,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得烟头 {Value1Divide}个",
			Skill = {
				{
					Id = 102102,
					Value = 75,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得烟头 {Value1Divide}个",
			Skill = {
				{
					Id = 102102,
					Value = 100,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得烟头 {Value1Divide}个",
			Skill = {
				{
					Id = 102102,
					Value = 125,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得烟头 {Value1Divide}个",
			Skill = {
				{
					Id = 102102,
					Value = 150,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得烟头 {Value1Divide}个",
			Skill = {
				{
					Id = 102102,
					Value = 175,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得烟头 {Value1Divide}个",
			Skill = {
				{
					Id = 102102,
					Value = 200,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得烟头 {Value1Divide}个",
			Skill = {
				{
					Id = 102102,
					Value = 225,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得烟头 {Value1Divide}个",
			Skill = {
				{
					Id = 102102,
					Value = 250,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得烟头 {Value1Divide}个",
			Skill = {
				{
					Id = 102102,
					Value = 275,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得烟头 {Value1Divide}个",
			Skill = {
				{
					Id = 102102,
					Value = 300,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得烟头 {Value1Divide}个",
			Skill = {
				{
					Id = 102102,
					Value = 325,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得烟头 {Value1Divide}个",
			Skill = {
				{
					Id = 102102,
					Value = 350,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320317,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320318,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561204,
		561321,
		561348,
		563106,
		563203,
		563620,
		563815,
		563303,
		563403,
		563503,
		563944,
		563922,
		564039,
		564159,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id102] =
{
	Id = 102,
	Name = "手铐",
	Area = 
	{
		130157,
	},
	Rarity = 2,
	Element = 210004,
	Gallery = 950004,
	Desc = "对于一名罪犯来说，手腕粗得铐不住是一件很丢脸的事。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Handcuffs",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Handcuffs",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectLight",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 76, Gain = 304},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "暗元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102103,
					Value = 6,
				},
			},
		},
		{
			Stage = 2,
			Desc = "暗元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102103,
					Value = 9,
				},
			},
		},
		{
			Stage = 3,
			Desc = "暗元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102103,
					Value = 12,
				},
			},
		},
		{
			Stage = 4,
			Desc = "暗元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102103,
					Value = 15,
				},
			},
		},
		{
			Stage = 5,
			Desc = "暗元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102103,
					Value = 18,
				},
			},
		},
		{
			Stage = 6,
			Desc = "暗元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102103,
					Value = 21,
				},
			},
		},
		{
			Stage = 7,
			Desc = "暗元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102103,
					Value = 24,
				},
			},
		},
		{
			Stage = 8,
			Desc = "暗元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102103,
					Value = 27,
				},
			},
		},
		{
			Stage = 9,
			Desc = "暗元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102103,
					Value = 30,
				},
			},
		},
		{
			Stage = 10,
			Desc = "暗元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102103,
					Value = 33,
				},
			},
		},
		{
			Stage = 11,
			Desc = "暗元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102103,
					Value = 36,
				},
			},
		},
		{
			Stage = 12,
			Desc = "暗元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102103,
					Value = 39,
				},
			},
		},
		{
			Stage = 13,
			Desc = "暗元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102103,
					Value = 42,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320317,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320318,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561205,
		561321,
		561348,
		563106,
		563203,
		563604,
		563815,
		563303,
		563402,
		563502,
		563931,
		564029,
		564053,
		564159,
		564114,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id103] =
{
	Id = 103,
	Name = "打火机",
	Area = 
	{
		130157,
	},
	Rarity = 3,
	Element = 210002,
	Gallery = 950004,
	Desc = "成功取代了火柴的新型点火装置，是烟草爱好者必不可少的道具。经常被设计成各种形状，枪械、钟表、乐器，还有香烟。",
	LevelUp = 910003,
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_CigaretteLighter",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_CigaretteLighter",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectFire",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 123, Gain = 492},
		{Value = 200004, Base = 10, Gain = 2},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "火元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102104,
					Value = 4,
				},
			},
		},
		{
			Stage = 2,
			Desc = "火元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102104,
					Value = 6,
				},
			},
		},
		{
			Stage = 3,
			Desc = "火元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102104,
					Value = 8,
				},
			},
		},
		{
			Stage = 4,
			Desc = "火元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102104,
					Value = 10,
				},
			},
		},
		{
			Stage = 5,
			Desc = "火元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102104,
					Value = 12,
				},
			},
		},
		{
			Stage = 6,
			Desc = "火元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102104,
					Value = 14,
				},
			},
		},
		{
			Stage = 7,
			Desc = "火元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102104,
					Value = 16,
				},
			},
		},
		{
			Stage = 8,
			Desc = "火元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102104,
					Value = 18,
				},
			},
		},
		{
			Stage = 9,
			Desc = "火元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102104,
					Value = 20,
				},
			},
		},
		{
			Stage = 10,
			Desc = "火元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102104,
					Value = 22,
				},
			},
		},
		{
			Stage = 11,
			Desc = "火元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102104,
					Value = 24,
				},
			},
		},
		{
			Stage = 12,
			Desc = "火元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102104,
					Value = 26,
				},
			},
		},
		{
			Stage = 13,
			Desc = "火元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102104,
					Value = 28,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320318,
			CatchChance = 30,
			CatchChanceGain = 5,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 25,
			SuccessChanceGain = 2,
			SuccessChanceMax = 100,
		},
		{
			Value = 320319,
			CatchChance = 50,
			CatchChanceGain = 10,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561203,
		561321,
		561348,
		563106,
		563203,
		563604,
		563814,
		563303,
		563405,
		563502,
		563924,
		564055,
		564029,
		564159,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id104] =
{
	Id = 104,
	Name = "相片",
	Area = 
	{
		130158,
		130159,
	},
	Rarity = 2,
	Element = 210003,
	Gallery = 950004,
	Desc = "只是用来记录某一时刻湖面的相片，在悬疑星却往往能将深藏多年的某段关系揭示出来。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Photo",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Photo",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 76, Gain = 304},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "全队暴击 +{Value1}",
			Skill = {
				{
					Id = 102105,
					Value = 3,
				},
			},
		},
		{
			Stage = 2,
			Desc = "全队暴击 +{Value1}",
			Skill = {
				{
					Id = 102105,
					Value = 4,
				},
			},
		},
		{
			Stage = 3,
			Desc = "全队暴击 +{Value1}",
			Skill = {
				{
					Id = 102105,
					Value = 5,
				},
			},
		},
		{
			Stage = 4,
			Desc = "全队暴击 +{Value1}",
			Skill = {
				{
					Id = 102105,
					Value = 6,
				},
			},
		},
		{
			Stage = 5,
			Desc = "全队暴击 +{Value1}",
			Skill = {
				{
					Id = 102105,
					Value = 7,
				},
			},
		},
		{
			Stage = 6,
			Desc = "全队暴击 +{Value1}",
			Skill = {
				{
					Id = 102105,
					Value = 8,
				},
			},
		},
		{
			Stage = 7,
			Desc = "全队暴击 +{Value1}",
			Skill = {
				{
					Id = 102105,
					Value = 9,
				},
			},
		},
		{
			Stage = 8,
			Desc = "全队暴击 +{Value1}",
			Skill = {
				{
					Id = 102105,
					Value = 10,
				},
			},
		},
		{
			Stage = 9,
			Desc = "全队暴击 +{Value1}",
			Skill = {
				{
					Id = 102105,
					Value = 11,
				},
			},
		},
		{
			Stage = 10,
			Desc = "全队暴击 +{Value1}",
			Skill = {
				{
					Id = 102105,
					Value = 12,
				},
			},
		},
		{
			Stage = 11,
			Desc = "全队暴击 +{Value1}",
			Skill = {
				{
					Id = 102105,
					Value = 13,
				},
			},
		},
		{
			Stage = 12,
			Desc = "全队暴击 +{Value1}",
			Skill = {
				{
					Id = 102105,
					Value = 14,
				},
			},
		},
		{
			Stage = 13,
			Desc = "全队暴击 +{Value1}",
			Skill = {
				{
					Id = 102105,
					Value = 15,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320309,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320310,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561204,
		561321,
		561343,
		563104,
		563203,
		563604,
		563812,
		563303,
		563402,
		563504,
		563944,
		563924,
		563918,
		564040,
		564158,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id105] =
{
	Id = 105,
	Name = "报警器",
	Area = 
	{
		130158,
	},
	Rarity = 2,
	Element = 210004,
	Gallery = 950004,
	Desc = "警笛鸣起时，治安官们将迅速通过拥挤路段，直达罪案发生的所在，而鸣响的正义之音也将使罪恶无所遁形。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Alarm",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Alarm",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectLight",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 76, Gain = 304},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "紫色及以上品质敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102106,
					Value = 10,
				},
			},
		},
		{
			Stage = 2,
			Desc = "紫色及以上品质敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102106,
					Value = 15,
				},
			},
		},
		{
			Stage = 3,
			Desc = "紫色及以上品质敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102106,
					Value = 20,
				},
			},
		},
		{
			Stage = 4,
			Desc = "紫色及以上品质敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102106,
					Value = 25,
				},
			},
		},
		{
			Stage = 5,
			Desc = "紫色及以上品质敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102106,
					Value = 30,
				},
			},
		},
		{
			Stage = 6,
			Desc = "紫色及以上品质敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102106,
					Value = 35,
				},
			},
		},
		{
			Stage = 7,
			Desc = "紫色及以上品质敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102106,
					Value = 40,
				},
			},
		},
		{
			Stage = 8,
			Desc = "紫色及以上品质敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102106,
					Value = 45,
				},
			},
		},
		{
			Stage = 9,
			Desc = "紫色及以上品质敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102106,
					Value = 50,
				},
			},
		},
		{
			Stage = 10,
			Desc = "紫色及以上品质敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102106,
					Value = 55,
				},
			},
		},
		{
			Stage = 11,
			Desc = "紫色及以上品质敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102106,
					Value = 60,
				},
			},
		},
		{
			Stage = 12,
			Desc = "紫色及以上品质敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102106,
					Value = 65,
				},
			},
		},
		{
			Stage = 13,
			Desc = "紫色及以上品质敌人出现概率 +{Value1}%",
			Skill = {
				{
					Id = 102106,
					Value = 70,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320317,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320318,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561205,
		561321,
		561322,
		561348,
		563106,
		563203,
		563618,
		563813,
		563303,
		563402,
		563503,
		563920,
		563903,
		564030,
		564055,
		564014,
		564160,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id106] =
{
	Id = 106,
	Name = "证物手机",
	Area = 
	{
		130158,
	},
	Rarity = 3,
	Element = 210005,
	Gallery = 950004,
	Desc = "犯罪现场遗留下来的手机，被害人还来不及翻开盖子就遇害了。这个教训告诉我们要买智能机。",
	LevelUp = 910003,
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_MobilePhone",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_MobilePhone",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectDark",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 123, Gain = 492},
		{Value = 200004, Base = 10, Gain = 2},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得指纹 {Value1Divide}个",
			Skill = {
				{
					Id = 102107,
					Value = 60,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得指纹 {Value1Divide}个",
			Skill = {
				{
					Id = 102107,
					Value = 90,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得指纹 {Value1Divide}个",
			Skill = {
				{
					Id = 102107,
					Value = 120,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得指纹 {Value1Divide}个",
			Skill = {
				{
					Id = 102107,
					Value = 150,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得指纹 {Value1Divide}个",
			Skill = {
				{
					Id = 102107,
					Value = 180,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得指纹 {Value1Divide}个",
			Skill = {
				{
					Id = 102107,
					Value = 210,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得指纹 {Value1Divide}个",
			Skill = {
				{
					Id = 102107,
					Value = 240,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得指纹 {Value1Divide}个",
			Skill = {
				{
					Id = 102107,
					Value = 270,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得指纹 {Value1Divide}个",
			Skill = {
				{
					Id = 102107,
					Value = 300,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得指纹 {Value1Divide}个",
			Skill = {
				{
					Id = 102107,
					Value = 330,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得指纹 {Value1Divide}个",
			Skill = {
				{
					Id = 102107,
					Value = 360,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得指纹 {Value1Divide}个",
			Skill = {
				{
					Id = 102107,
					Value = 390,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得指纹 {Value1Divide}个",
			Skill = {
				{
					Id = 102107,
					Value = 420,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320318,
			CatchChance = 30,
			CatchChanceGain = 5,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 25,
			SuccessChanceGain = 2,
			SuccessChanceMax = 100,
		},
		{
			Value = 320319,
			CatchChance = 50,
			CatchChanceGain = 10,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561206,
		561321,
		561322,
		561348,
		563106,
		563203,
		563604,
		563814,
		563303,
		563402,
		563502,
		563935,
		564056,
		564004,
		564059,
		564160,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id107] =
{
	Id = 107,
	Name = "勒索信",
	Area = 
	{
		130158,
	},
	Rarity = 4,
	Element = 210005,
	Gallery = 950004,
	Desc = "当这封充满恶意的信件出现在家里时，往往说明你珍爱的某件东西可能落到别人手中。",
	LevelUp = 910004,
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_ExtortionMail",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_ExtortionMail",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectDark",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 179, Gain = 716},
		{Value = 200004, Base = 15, Gain = 3},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "对光元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102108,
					Value = 50,
				},
			},
		},
		{
			Stage = 2,
			Desc = "对光元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102108,
					Value = 75,
				},
			},
		},
		{
			Stage = 3,
			Desc = "对光元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102108,
					Value = 100,
				},
			},
		},
		{
			Stage = 4,
			Desc = "对光元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102108,
					Value = 125,
				},
			},
		},
		{
			Stage = 5,
			Desc = "对光元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102108,
					Value = 150,
				},
			},
		},
		{
			Stage = 6,
			Desc = "对光元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102108,
					Value = 175,
				},
			},
		},
		{
			Stage = 7,
			Desc = "对光元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102108,
					Value = 200,
				},
			},
		},
		{
			Stage = 8,
			Desc = "对光元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102108,
					Value = 225,
				},
			},
		},
		{
			Stage = 9,
			Desc = "对光元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102108,
					Value = 250,
				},
			},
		},
		{
			Stage = 10,
			Desc = "对光元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102108,
					Value = 275,
				},
			},
		},
		{
			Stage = 11,
			Desc = "对光元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102108,
					Value = 300,
				},
			},
		},
		{
			Stage = 12,
			Desc = "对光元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102108,
					Value = 325,
				},
			},
		},
		{
			Stage = 13,
			Desc = "对光元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102108,
					Value = 350,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320306,
			CatchChance = 5,
			CatchChanceGain = 12,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 5,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
		{
			Value = 320307,
			CatchChance = 33,
			CatchChanceGain = 25,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 33,
			SuccessChanceGain = 4,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560025,
		560045,
		560046,
		560032,
		560033,
		560034,
		560035,
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561206,
		561321,
		561343,
		563103,
		563203,
		563604,
		563817,
		563303,
		563402,
		563503,
		563945,
		563913,
		564041,
		564057,
		564158,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id108] =
{
	Id = 108,
	Name = "蓝墨水",
	Area = 
	{
		130159,
		130161,
	},
	Rarity = 2,
	Element = 210001,
	Gallery = 950004,
	Desc = "使用贝壳和藻类制成的蓝色液体，通常用来记录信息类的文字，对海鲜过敏的人请务必谨慎使用。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_BlueInk",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_BlueInk",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWater",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 76, Gain = 304},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得墨水 {Value1Divide}个",
			Skill = {
				{
					Id = 102109,
					Value = 50,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得墨水 {Value1Divide}个",
			Skill = {
				{
					Id = 102109,
					Value = 75,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得墨水 {Value1Divide}个",
			Skill = {
				{
					Id = 102109,
					Value = 100,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得墨水 {Value1Divide}个",
			Skill = {
				{
					Id = 102109,
					Value = 125,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得墨水 {Value1Divide}个",
			Skill = {
				{
					Id = 102109,
					Value = 150,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得墨水 {Value1Divide}个",
			Skill = {
				{
					Id = 102109,
					Value = 175,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得墨水 {Value1Divide}个",
			Skill = {
				{
					Id = 102109,
					Value = 200,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得墨水 {Value1Divide}个",
			Skill = {
				{
					Id = 102109,
					Value = 225,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得墨水 {Value1Divide}个",
			Skill = {
				{
					Id = 102109,
					Value = 250,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得墨水 {Value1Divide}个",
			Skill = {
				{
					Id = 102109,
					Value = 275,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得墨水 {Value1Divide}个",
			Skill = {
				{
					Id = 102109,
					Value = 300,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得墨水 {Value1Divide}个",
			Skill = {
				{
					Id = 102109,
					Value = 325,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得墨水 {Value1Divide}个",
			Skill = {
				{
					Id = 102109,
					Value = 350,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320305,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320306,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561202,
		561321,
		561350,
		561347,
		563103,
		563203,
		563625,
		563814,
		563303,
		563402,
		563502,
		563936,
		564059,
		564019,
		564159,
		564114,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id109] =
{
	Id = 109,
	Name = "红墨水",
	Area = 
	{
		130159,
	},
	Rarity = 3,
	Element = 210001,
	Gallery = 950004,
	Desc = "使用花卉和矿石制成的红色液体，通常用来书写警示类的文字，有时会在杀手游戏中被当作鲜血道具使用。",
	LevelUp = 910003,
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_RedInk",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_RedInk",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWater",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 123, Gain = 492},
		{Value = 200004, Base = 10, Gain = 2},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "暗元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102110,
					Value = 4,
				},
			},
		},
		{
			Stage = 2,
			Desc = "暗元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102110,
					Value = 6,
				},
			},
		},
		{
			Stage = 3,
			Desc = "暗元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102110,
					Value = 8,
				},
			},
		},
		{
			Stage = 4,
			Desc = "暗元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102110,
					Value = 10,
				},
			},
		},
		{
			Stage = 5,
			Desc = "暗元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102110,
					Value = 12,
				},
			},
		},
		{
			Stage = 6,
			Desc = "暗元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102110,
					Value = 14,
				},
			},
		},
		{
			Stage = 7,
			Desc = "暗元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102110,
					Value = 16,
				},
			},
		},
		{
			Stage = 8,
			Desc = "暗元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102110,
					Value = 18,
				},
			},
		},
		{
			Stage = 9,
			Desc = "暗元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102110,
					Value = 20,
				},
			},
		},
		{
			Stage = 10,
			Desc = "暗元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102110,
					Value = 22,
				},
			},
		},
		{
			Stage = 11,
			Desc = "暗元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102110,
					Value = 24,
				},
			},
		},
		{
			Stage = 12,
			Desc = "暗元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102110,
					Value = 26,
				},
			},
		},
		{
			Stage = 13,
			Desc = "暗元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102110,
					Value = 28,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320306,
			CatchChance = 30,
			CatchChanceGain = 5,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 25,
			SuccessChanceGain = 2,
			SuccessChanceMax = 100,
		},
		{
			Value = 320307,
			CatchChance = 50,
			CatchChanceGain = 10,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561202,
		561321,
		561350,
		561347,
		563103,
		563203,
		563625,
		563814,
		563303,
		563402,
		563502,
		563921,
		564060,
		564019,
		564159,
		564113,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id110] =
{
	Id = 110,
	Name = "豹纹手铐",
	Area = 
	{
		130160,
		130163,
	},
	Rarity = 2,
	Element = 210005,
	Gallery = 950004,
	Desc = "本来是逮捕罪犯的工具，但是它却经常出现在莫名其妙的地方……\n我们这是全年龄向游戏。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_PatternHandcuffs",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_PatternHandcuffs",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectDark",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 76, Gain = 304},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得皮鞭 {Value1Divide}个",
			Skill = {
				{
					Id = 102111,
					Value = 40,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得皮鞭 {Value1Divide}个",
			Skill = {
				{
					Id = 102111,
					Value = 60,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得皮鞭 {Value1Divide}个",
			Skill = {
				{
					Id = 102111,
					Value = 80,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得皮鞭 {Value1Divide}个",
			Skill = {
				{
					Id = 102111,
					Value = 100,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得皮鞭 {Value1Divide}个",
			Skill = {
				{
					Id = 102111,
					Value = 120,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得皮鞭 {Value1Divide}个",
			Skill = {
				{
					Id = 102111,
					Value = 140,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得皮鞭 {Value1Divide}个",
			Skill = {
				{
					Id = 102111,
					Value = 160,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得皮鞭 {Value1Divide}个",
			Skill = {
				{
					Id = 102111,
					Value = 180,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得皮鞭 {Value1Divide}个",
			Skill = {
				{
					Id = 102111,
					Value = 200,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得皮鞭 {Value1Divide}个",
			Skill = {
				{
					Id = 102111,
					Value = 220,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得皮鞭 {Value1Divide}个",
			Skill = {
				{
					Id = 102111,
					Value = 240,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得皮鞭 {Value1Divide}个",
			Skill = {
				{
					Id = 102111,
					Value = 260,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得皮鞭 {Value1Divide}个",
			Skill = {
				{
					Id = 102111,
					Value = 280,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320317,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320318,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561206,
		561321,
		561348,
		563106,
		563203,
		563619,
		563814,
		563303,
		563402,
		563503,
		563925,
		563913,
		564024,
		564053,
		564159,
		564114,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id111] =
{
	Id = 111,
	Name = "行李车",
	Area = 
	{
		130160,
	},
	Rarity = 4,
	Element = 210002,
	Gallery = 950004,
	Desc = "旅店运送行李的工具，这辆车本身并不是行李。",
	LevelUp = 910004,
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Luggage",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Luggage",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectFire",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 179, Gain = 716},
		{Value = 200004, Base = 15, Gain = 3},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102112,
					Value = -5,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102112,
					Value = -7,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102112,
					Value = -9,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102112,
					Value = -11,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102112,
					Value = -13,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102112,
					Value = -15,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102112,
					Value = -17,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102112,
					Value = -19,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102112,
					Value = -21,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102112,
					Value = -23,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102112,
					Value = -25,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102112,
					Value = -27,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102112,
					Value = -29,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320314,
			CatchChance = 5,
			CatchChanceGain = 12,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 5,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
		{
			Value = 320315,
			CatchChance = 33,
			CatchChanceGain = 25,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 33,
			SuccessChanceGain = 4,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560025,
		560045,
		560046,
		560032,
		560033,
		560034,
		560035,
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561203,
		561321,
		561348,
		563105,
		563205,
		563617,
		563814,
		563303,
		563402,
		563503,
		563926,
		563943,
		564030,
		564053,
		564159,
		564114,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id112] =
{
	Id = 112,
	Name = "水果笔记",
	Area = 
	{
		130161,
		130163,
	},
	Rarity = 2,
	Element = 210003,
	Gallery = 950004,
	Desc = "记录着大量水果资料的笔记本，不知道打算用来做什么用。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_BrownNoteBook",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_BrownNoteBook",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 76, Gain = 304},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得黄瓜马赛克 {Value1Divide}个",
			Skill = {
				{
					Id = 102113,
					Value = 40,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得黄瓜马赛克 {Value1Divide}个",
			Skill = {
				{
					Id = 102113,
					Value = 60,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得黄瓜马赛克 {Value1Divide}个",
			Skill = {
				{
					Id = 102113,
					Value = 80,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得黄瓜马赛克 {Value1Divide}个",
			Skill = {
				{
					Id = 102113,
					Value = 100,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得黄瓜马赛克 {Value1Divide}个",
			Skill = {
				{
					Id = 102113,
					Value = 120,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得黄瓜马赛克 {Value1Divide}个",
			Skill = {
				{
					Id = 102113,
					Value = 140,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得黄瓜马赛克 {Value1Divide}个",
			Skill = {
				{
					Id = 102113,
					Value = 160,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得黄瓜马赛克 {Value1Divide}个",
			Skill = {
				{
					Id = 102113,
					Value = 180,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得黄瓜马赛克 {Value1Divide}个",
			Skill = {
				{
					Id = 102113,
					Value = 200,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得黄瓜马赛克 {Value1Divide}个",
			Skill = {
				{
					Id = 102113,
					Value = 220,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得黄瓜马赛克 {Value1Divide}个",
			Skill = {
				{
					Id = 102113,
					Value = 240,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得黄瓜马赛克 {Value1Divide}个",
			Skill = {
				{
					Id = 102113,
					Value = 260,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得黄瓜马赛克 {Value1Divide}个",
			Skill = {
				{
					Id = 102113,
					Value = 280,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320317,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320318,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561204,
		561321,
		561343,
		563106,
		563203,
		563604,
		563818,
		563303,
		563402,
		563502,
		563946,
		564044,
		564060,
		564158,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id113] =
{
	Id = 113,
	Name = "蔬菜笔记",
	Area = 
	{
		130161,
	},
	Rarity = 3,
	Element = 210002,
	Gallery = 950004,
	Desc = "记录着大量蔬菜资料的笔记本，不知道打算用来做什么用。",
	LevelUp = 910003,
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_RedNotebook",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_RedNotebook",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectFire",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 123, Gain = 492},
		{Value = 200004, Base = 10, Gain = 2},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "风元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102114,
					Value = 8,
				},
			},
		},
		{
			Stage = 2,
			Desc = "风元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102114,
					Value = 12,
				},
			},
		},
		{
			Stage = 3,
			Desc = "风元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102114,
					Value = 16,
				},
			},
		},
		{
			Stage = 4,
			Desc = "风元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102114,
					Value = 20,
				},
			},
		},
		{
			Stage = 5,
			Desc = "风元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102114,
					Value = 24,
				},
			},
		},
		{
			Stage = 6,
			Desc = "风元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102114,
					Value = 28,
				},
			},
		},
		{
			Stage = 7,
			Desc = "风元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102114,
					Value = 32,
				},
			},
		},
		{
			Stage = 8,
			Desc = "风元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102114,
					Value = 36,
				},
			},
		},
		{
			Stage = 9,
			Desc = "风元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102114,
					Value = 40,
				},
			},
		},
		{
			Stage = 10,
			Desc = "风元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102114,
					Value = 44,
				},
			},
		},
		{
			Stage = 11,
			Desc = "风元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102114,
					Value = 48,
				},
			},
		},
		{
			Stage = 12,
			Desc = "风元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102114,
					Value = 52,
				},
			},
		},
		{
			Stage = 13,
			Desc = "风元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102114,
					Value = 56,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320318,
			CatchChance = 30,
			CatchChanceGain = 5,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 25,
			SuccessChanceGain = 2,
			SuccessChanceMax = 100,
		},
		{
			Value = 320319,
			CatchChance = 50,
			CatchChanceGain = 10,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561203,
		561321,
		561343,
		563106,
		563203,
		563604,
		563818,
		563303,
		563402,
		563502,
		563921,
		564044,
		564060,
		564158,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id114] =
{
	Id = 114,
	Name = "放大镜",
	Area = 
	{
		130162,
		130163,
	},
	Rarity = 2,
	Element = 210004,
	Gallery = 950004,
	Desc = "侦探们的好朋友，有时候没什么用，但是拿出来会让人觉得很有侦探的派头。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Magnifier",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Magnifier",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectLight",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 76, Gain = 304},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得灵感 {Value1Divide}个",
			Skill = {
				{
					Id = 102115,
					Value = 40,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得灵感 {Value1Divide}个",
			Skill = {
				{
					Id = 102115,
					Value = 60,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得灵感 {Value1Divide}个",
			Skill = {
				{
					Id = 102115,
					Value = 80,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得灵感 {Value1Divide}个",
			Skill = {
				{
					Id = 102115,
					Value = 100,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得灵感 {Value1Divide}个",
			Skill = {
				{
					Id = 102115,
					Value = 120,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得灵感 {Value1Divide}个",
			Skill = {
				{
					Id = 102115,
					Value = 140,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得灵感 {Value1Divide}个",
			Skill = {
				{
					Id = 102115,
					Value = 160,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得灵感 {Value1Divide}个",
			Skill = {
				{
					Id = 102115,
					Value = 180,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得灵感 {Value1Divide}个",
			Skill = {
				{
					Id = 102115,
					Value = 200,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得灵感 {Value1Divide}个",
			Skill = {
				{
					Id = 102115,
					Value = 220,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得灵感 {Value1Divide}个",
			Skill = {
				{
					Id = 102115,
					Value = 240,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得灵感 {Value1Divide}个",
			Skill = {
				{
					Id = 102115,
					Value = 260,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得灵感 {Value1Divide}个",
			Skill = {
				{
					Id = 102115,
					Value = 280,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320317,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320318,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561205,
		561321,
		561353,
		561348,
		563106,
		563203,
		563619,
		563813,
		563303,
		563402,
		563503,
		563925,
		563943,
		564060,
		564014,
		564053,
		564159,
		564114,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id115] =
{
	Id = 115,
	Name = "怀表",
	Area = 
	{
		130162,
	},
	Rarity = 2,
	Element = 210003,
	Gallery = 950004,
	Desc = "很有绅士风度的怀表，对时间的准头很讲究，具有催眠效果，可以让老板觉得自己没有迟到。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_PocketWatch",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_PocketWatch",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 76, Gain = 304},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102116,
					Value = -3,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102116,
					Value = -4,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102116,
					Value = -5,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102116,
					Value = -6,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102116,
					Value = -7,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102116,
					Value = -8,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102116,
					Value = -9,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102116,
					Value = -10,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102116,
					Value = -11,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102116,
					Value = -12,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102116,
					Value = -13,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102116,
					Value = -14,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102116,
					Value = -15,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320317,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320318,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561204,
		561321,
		561348,
		561322,
		563106,
		563203,
		563620,
		563814,
		563303,
		563402,
		563503,
		563925,
		563903,
		564056,
		564019,
		564058,
		564160,
		564114,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id116] =
{
	Id = 116,
	Name = "烟斗",
	Area = 
	{
		130162,
	},
	Rarity = 3,
	Element = 210002,
	Gallery = 950004,
	Desc = "很喜欢和路人聊天攀谈的烟斗，如果聊天对象是侦探们的话，会开心得冒起烟来。",
	LevelUp = 910003,
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Pipe",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Pipe",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectFire",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 123, Gain = 492},
		{Value = 200004, Base = 10, Gain = 2},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "光元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102117,
					Value = 4,
				},
			},
		},
		{
			Stage = 2,
			Desc = "光元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102117,
					Value = 6,
				},
			},
		},
		{
			Stage = 3,
			Desc = "光元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102117,
					Value = 8,
				},
			},
		},
		{
			Stage = 4,
			Desc = "光元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102117,
					Value = 10,
				},
			},
		},
		{
			Stage = 5,
			Desc = "光元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102117,
					Value = 12,
				},
			},
		},
		{
			Stage = 6,
			Desc = "光元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102117,
					Value = 14,
				},
			},
		},
		{
			Stage = 7,
			Desc = "光元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102117,
					Value = 16,
				},
			},
		},
		{
			Stage = 8,
			Desc = "光元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102117,
					Value = 18,
				},
			},
		},
		{
			Stage = 9,
			Desc = "光元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102117,
					Value = 20,
				},
			},
		},
		{
			Stage = 10,
			Desc = "光元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102117,
					Value = 22,
				},
			},
		},
		{
			Stage = 11,
			Desc = "光元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102117,
					Value = 24,
				},
			},
		},
		{
			Stage = 12,
			Desc = "光元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102117,
					Value = 26,
				},
			},
		},
		{
			Stage = 13,
			Desc = "光元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102117,
					Value = 28,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320318,
			CatchChance = 30,
			CatchChanceGain = 5,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 25,
			SuccessChanceGain = 2,
			SuccessChanceMax = 100,
		},
		{
			Value = 320319,
			CatchChance = 50,
			CatchChanceGain = 10,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561203,
		561321,
		561348,
		563106,
		563203,
		563814,
		563303,
		563405,
		563503,
		563945,
		563903,
		564060,
		564019,
		564158,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id117] =
{
	Id = 117,
	Name = "血迹",
	Area = 
	{
		130163,
	},
	Rarity = 2,
	Element = 210005,
	Gallery = 950004,
	Desc = "生物身体中必不可少的关键液体，不过有些生物个体看到它时会不自觉地晕倒。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Blood",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Blood",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectDark",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 76, Gain = 304},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得营养液 {Value1Divide}个",
			Skill = {
				{
					Id = 102118,
					Value = 40,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得营养液 {Value1Divide}个",
			Skill = {
				{
					Id = 102118,
					Value = 60,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得营养液 {Value1Divide}个",
			Skill = {
				{
					Id = 102118,
					Value = 80,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得营养液 {Value1Divide}个",
			Skill = {
				{
					Id = 102118,
					Value = 100,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得营养液 {Value1Divide}个",
			Skill = {
				{
					Id = 102118,
					Value = 120,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得营养液 {Value1Divide}个",
			Skill = {
				{
					Id = 102118,
					Value = 140,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得营养液 {Value1Divide}个",
			Skill = {
				{
					Id = 102118,
					Value = 160,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得营养液 {Value1Divide}个",
			Skill = {
				{
					Id = 102118,
					Value = 180,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得营养液 {Value1Divide}个",
			Skill = {
				{
					Id = 102118,
					Value = 200,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得营养液 {Value1Divide}个",
			Skill = {
				{
					Id = 102118,
					Value = 220,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得营养液 {Value1Divide}个",
			Skill = {
				{
					Id = 102118,
					Value = 240,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得营养液 {Value1Divide}个",
			Skill = {
				{
					Id = 102118,
					Value = 260,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得营养液 {Value1Divide}个",
			Skill = {
				{
					Id = 102118,
					Value = 280,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320305,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320306,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561206,
		561321,
		561340,
		563103,
		563203,
		563610,
		563709,
		563305,
		563404,
		563502,
		563921,
		564104,
		564114,
		564203,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id118] =
{
	Id = 118,
	Name = "瓶中脑",
	Area = 
	{
		130163,
	},
	Rarity = 4,
	Element = 210001,
	Gallery = 950004,
	Desc = "实验室特别存保存下来的生物大脑，其中存储着大量重要的信息。",
	LevelUp = 910004,
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_Brain",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_Brain",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWater",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 179, Gain = 716},
		{Value = 200004, Base = 15, Gain = 3},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "每3回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102119,
					Value = 8,
				},
			},
		},
		{
			Stage = 2,
			Desc = "每3回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102119,
					Value = 12,
				},
			},
		},
		{
			Stage = 3,
			Desc = "每3回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102119,
					Value = 16,
				},
			},
		},
		{
			Stage = 4,
			Desc = "每3回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102119,
					Value = 20,
				},
			},
		},
		{
			Stage = 5,
			Desc = "每3回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102119,
					Value = 24,
				},
			},
		},
		{
			Stage = 6,
			Desc = "每3回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102119,
					Value = 28,
				},
			},
		},
		{
			Stage = 7,
			Desc = "每3回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102119,
					Value = 32,
				},
			},
		},
		{
			Stage = 8,
			Desc = "每3回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102119,
					Value = 36,
				},
			},
		},
		{
			Stage = 9,
			Desc = "每3回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102119,
					Value = 40,
				},
			},
		},
		{
			Stage = 10,
			Desc = "每3回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102119,
					Value = 44,
				},
			},
		},
		{
			Stage = 11,
			Desc = "每3回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102119,
					Value = 48,
				},
			},
		},
		{
			Stage = 12,
			Desc = "每3回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102119,
					Value = 52,
				},
			},
		},
		{
			Stage = 13,
			Desc = "每3回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102119,
					Value = 56,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320318,
			CatchChance = 5,
			CatchChanceGain = 12,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 5,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
		{
			Value = 320319,
			CatchChance = 33,
			CatchChanceGain = 25,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 33,
			SuccessChanceGain = 4,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560025,
		560045,
		560046,
		560032,
		560033,
		560034,
		560035,
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561202,
		561321,
		561350,
		561340,
		563106,
		563203,
		563618,
		563709,
		563815,
		563303,
		563404,
		563504,
		563949,
		563943,
		563902,
		564026,
		564061,
		564105,
		564204,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id119] =
{
	Id = 119,
	Name = "绿草草",
	Area = 
	{
		130201,
		130208,
		130206,
		130205,
		130203,
		130202,
	},
	Rarity = 1,
	Element = 210003,
	Gallery = 950005,
	Desc = "完全没有一点主见的绿色海草，别人说什么就是什么，因此常常被其他鱼吐槽“绿草草，随风倒”。",
	LevelUp = 910001,
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Laminria1",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Laminria1",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 54, Gain = 216},
		{Value = 200004, Base = 0, Gain = 0},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102138,
					Value = 4,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102138,
					Value = 6,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102138,
					Value = 8,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102138,
					Value = 10,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102138,
					Value = 12,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102138,
					Value = 14,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102138,
					Value = 16,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102138,
					Value = 18,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102138,
					Value = 20,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102138,
					Value = 22,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102138,
					Value = 24,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102138,
					Value = 26,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102138,
					Value = 28,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320301,
			CatchChance = 50,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560022,
		560042,
		560043,
		560044,
		560045,
		560046,
		560032,
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561204,
		561355,
		561358,
		563102,
		563203,
		563613,
		563824,
		563304,
		563402,
		563502,
		563940,
		564013,
		564049,
		564144,
		564109,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id120] =
{
	Id = 120,
	Name = "珊瑚红",
	Area = 
	{
		130202,
		130204,
		130203,
	},
	Rarity = 2,
	Element = 210002,
	Gallery = 950005,
	Desc = "海底自助化妆师，只要摸摸TA的头，TA就会突然窜出来，并迅速完成一套珊瑚红系的完美妆容，一次只要100海洋币。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Coral2",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Coral2",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectFire",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 81, Gain = 324},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得珊瑚 {Value1Divide}个",
			Skill = {
				{
					Id = 102139,
					Value = 40,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得珊瑚 {Value1Divide}个",
			Skill = {
				{
					Id = 102139,
					Value = 60,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得珊瑚 {Value1Divide}个",
			Skill = {
				{
					Id = 102139,
					Value = 80,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得珊瑚 {Value1Divide}个",
			Skill = {
				{
					Id = 102139,
					Value = 100,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得珊瑚 {Value1Divide}个",
			Skill = {
				{
					Id = 102139,
					Value = 120,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得珊瑚 {Value1Divide}个",
			Skill = {
				{
					Id = 102139,
					Value = 140,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得珊瑚 {Value1Divide}个",
			Skill = {
				{
					Id = 102139,
					Value = 160,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得珊瑚 {Value1Divide}个",
			Skill = {
				{
					Id = 102139,
					Value = 180,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得珊瑚 {Value1Divide}个",
			Skill = {
				{
					Id = 102139,
					Value = 200,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得珊瑚 {Value1Divide}个",
			Skill = {
				{
					Id = 102139,
					Value = 220,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得珊瑚 {Value1Divide}个",
			Skill = {
				{
					Id = 102139,
					Value = 240,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得珊瑚 {Value1Divide}个",
			Skill = {
				{
					Id = 102139,
					Value = 260,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得珊瑚 {Value1Divide}个",
			Skill = {
				{
					Id = 102139,
					Value = 280,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320309,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320310,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561203,
		561355,
		561359,
		563104,
		563202,
		563624,
		563814,
		563304,
		563402,
		563502,
		563921,
		564004,
		564049,
		564144,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id121] =
{
	Id = 121,
	Name = "梅子紫",
	Area = 
	{
		130202,
		130205,
	},
	Rarity = 2,
	Element = 210001,
	Gallery = 950005,
	Desc = "海底自助化妆师，珊瑚红的同事，不过TA带来的是梅子紫系的全套妆容，一次150海洋币。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Coral1",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Coral1",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWater",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 81, Gain = 324},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "水元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102140,
					Value = 4,
				},
			},
		},
		{
			Stage = 2,
			Desc = "水元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102140,
					Value = 6,
				},
			},
		},
		{
			Stage = 3,
			Desc = "水元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102140,
					Value = 8,
				},
			},
		},
		{
			Stage = 4,
			Desc = "水元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102140,
					Value = 10,
				},
			},
		},
		{
			Stage = 5,
			Desc = "水元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102140,
					Value = 12,
				},
			},
		},
		{
			Stage = 6,
			Desc = "水元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102140,
					Value = 14,
				},
			},
		},
		{
			Stage = 7,
			Desc = "水元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102140,
					Value = 16,
				},
			},
		},
		{
			Stage = 8,
			Desc = "水元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102140,
					Value = 18,
				},
			},
		},
		{
			Stage = 9,
			Desc = "水元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102140,
					Value = 20,
				},
			},
		},
		{
			Stage = 10,
			Desc = "水元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102140,
					Value = 22,
				},
			},
		},
		{
			Stage = 11,
			Desc = "水元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102140,
					Value = 24,
				},
			},
		},
		{
			Stage = 12,
			Desc = "水元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102140,
					Value = 26,
				},
			},
		},
		{
			Stage = 13,
			Desc = "水元素队员生命 +{Value1}%",
			Skill = {
				{
					Id = 102140,
					Value = 28,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320309,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320310,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561202,
		561355,
		561359,
		563104,
		563202,
		563624,
		563814,
		563304,
		563402,
		563502,
		563951,
		564004,
		564049,
		564144,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id122] =
{
	Id = 122,
	Name = "红贝壳",
	Area = 
	{
		130203,
		130206,
	},
	Rarity = 2,
	Element = 210002,
	Gallery = 950005,
	Desc = "据说是海底世界的百事通，被评价为“海里的全知道，海外的知道一半”，不过，这真的是客观评价吗？",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Pectinid2",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Pectinid2",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectFire",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 81, Gain = 324},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得黑珍珠 {Value1Divide}个",
			Skill = {
				{
					Id = 102141,
					Value = 40,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得黑珍珠 {Value1Divide}个",
			Skill = {
				{
					Id = 102141,
					Value = 60,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得黑珍珠 {Value1Divide}个",
			Skill = {
				{
					Id = 102141,
					Value = 80,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得黑珍珠 {Value1Divide}个",
			Skill = {
				{
					Id = 102141,
					Value = 100,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得黑珍珠 {Value1Divide}个",
			Skill = {
				{
					Id = 102141,
					Value = 120,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得黑珍珠 {Value1Divide}个",
			Skill = {
				{
					Id = 102141,
					Value = 140,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得黑珍珠 {Value1Divide}个",
			Skill = {
				{
					Id = 102141,
					Value = 160,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得黑珍珠 {Value1Divide}个",
			Skill = {
				{
					Id = 102141,
					Value = 180,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得黑珍珠 {Value1Divide}个",
			Skill = {
				{
					Id = 102141,
					Value = 200,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得黑珍珠 {Value1Divide}个",
			Skill = {
				{
					Id = 102141,
					Value = 220,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得黑珍珠 {Value1Divide}个",
			Skill = {
				{
					Id = 102141,
					Value = 240,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得黑珍珠 {Value1Divide}个",
			Skill = {
				{
					Id = 102141,
					Value = 260,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得黑珍珠 {Value1Divide}个",
			Skill = {
				{
					Id = 102141,
					Value = 280,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320309,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320310,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561203,
		561355,
		561360,
		563104,
		563202,
		563619,
		563814,
		563304,
		563402,
		563503,
		563919,
		563922,
		564024,
		564049,
		564109,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id123] =
{
	Id = 123,
	Name = "黄贝壳",
	Area = 
	{
		130203,
	},
	Rarity = 3,
	Element = 210004,
	Gallery = 950005,
	Desc = "红贝壳的好友，当红贝壳的坑蒙拐骗被拆穿时，TA就负责出来收拾残局。",
	LevelUp = 910003,
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Pectinid1",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Pectinid1",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectLight",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 130, Gain = 520},
		{Value = 200004, Base = 10, Gain = 2},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "暗元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102142,
					Value = 8,
				},
			},
		},
		{
			Stage = 2,
			Desc = "暗元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102142,
					Value = 12,
				},
			},
		},
		{
			Stage = 3,
			Desc = "暗元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102142,
					Value = 16,
				},
			},
		},
		{
			Stage = 4,
			Desc = "暗元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102142,
					Value = 20,
				},
			},
		},
		{
			Stage = 5,
			Desc = "暗元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102142,
					Value = 24,
				},
			},
		},
		{
			Stage = 6,
			Desc = "暗元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102142,
					Value = 28,
				},
			},
		},
		{
			Stage = 7,
			Desc = "暗元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102142,
					Value = 32,
				},
			},
		},
		{
			Stage = 8,
			Desc = "暗元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102142,
					Value = 36,
				},
			},
		},
		{
			Stage = 9,
			Desc = "暗元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102142,
					Value = 40,
				},
			},
		},
		{
			Stage = 10,
			Desc = "暗元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102142,
					Value = 44,
				},
			},
		},
		{
			Stage = 11,
			Desc = "暗元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102142,
					Value = 48,
				},
			},
		},
		{
			Stage = 12,
			Desc = "暗元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102142,
					Value = 52,
				},
			},
		},
		{
			Stage = 13,
			Desc = "暗元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102142,
					Value = 56,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320310,
			CatchChance = 30,
			CatchChanceGain = 5,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 25,
			SuccessChanceGain = 2,
			SuccessChanceMax = 100,
		},
		{
			Value = 320311,
			CatchChance = 50,
			CatchChanceGain = 10,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561205,
		561355,
		561360,
		563104,
		563202,
		563619,
		563814,
		563304,
		563402,
		563503,
		563924,
		563947,
		564024,
		564049,
		564109,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id124] =
{
	Id = 124,
	Name = "鱿鱼",
	Area = 
	{
		130204,
		130207,
	},
	Rarity = 2,
	Element = 210001,
	Gallery = 950005,
	Desc = "具有八条长腿，能狠狠吸住休息厅的地毯，谁都不能把TA拖走。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Inkfish",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Inkfish",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWater",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 81, Gain = 324},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得怪物触手 {Value1Divide}个",
			Skill = {
				{
					Id = 102143,
					Value = 130,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得怪物触手 {Value1Divide}个",
			Skill = {
				{
					Id = 102143,
					Value = 195,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得怪物触手 {Value1Divide}个",
			Skill = {
				{
					Id = 102143,
					Value = 260,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得怪物触手 {Value1Divide}个",
			Skill = {
				{
					Id = 102143,
					Value = 325,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得怪物触手 {Value1Divide}个",
			Skill = {
				{
					Id = 102143,
					Value = 390,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得怪物触手 {Value1Divide}个",
			Skill = {
				{
					Id = 102143,
					Value = 455,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得怪物触手 {Value1Divide}个",
			Skill = {
				{
					Id = 102143,
					Value = 520,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得怪物触手 {Value1Divide}个",
			Skill = {
				{
					Id = 102143,
					Value = 585,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得怪物触手 {Value1Divide}个",
			Skill = {
				{
					Id = 102143,
					Value = 650,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得怪物触手 {Value1Divide}个",
			Skill = {
				{
					Id = 102143,
					Value = 715,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得怪物触手 {Value1Divide}个",
			Skill = {
				{
					Id = 102143,
					Value = 780,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得怪物触手 {Value1Divide}个",
			Skill = {
				{
					Id = 102143,
					Value = 845,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得怪物触手 {Value1Divide}个",
			Skill = {
				{
					Id = 102143,
					Value = 910,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320301,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320302,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561202,
		561356,
		561361,
		563102,
		563204,
		563607,
		563708,
		563824,
		563304,
		563402,
		563502,
		563909,
		564020,
		564110,
		564203,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id125] =
{
	Id = 125,
	Name = "章鱼",
	Area = 
	{
		130204,
	},
	Rarity = 4,
	Element = 210005,
	Gallery = 950005,
	Desc = "精通伪装，不仅可以伪装自己的形态，还能把别人的声音模仿得惟妙惟肖。",
	LevelUp = 910004,
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Octupas1",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Octupas1",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectDark",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 188, Gain = 752},
		{Value = 200004, Base = 15, Gain = 3},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "有{Value1}%概率额外攻击2次",
			Skill = {
				{
					Id = 102144,
					Value = 8,
				},
			},
		},
		{
			Stage = 2,
			Desc = "有{Value1}%概率额外攻击2次",
			Skill = {
				{
					Id = 102144,
					Value = 12,
				},
			},
		},
		{
			Stage = 3,
			Desc = "有{Value1}%概率额外攻击2次",
			Skill = {
				{
					Id = 102144,
					Value = 16,
				},
			},
		},
		{
			Stage = 4,
			Desc = "有{Value1}%概率额外攻击2次",
			Skill = {
				{
					Id = 102144,
					Value = 20,
				},
			},
		},
		{
			Stage = 5,
			Desc = "有{Value1}%概率额外攻击2次",
			Skill = {
				{
					Id = 102144,
					Value = 24,
				},
			},
		},
		{
			Stage = 6,
			Desc = "有{Value1}%概率额外攻击2次",
			Skill = {
				{
					Id = 102144,
					Value = 28,
				},
			},
		},
		{
			Stage = 7,
			Desc = "有{Value1}%概率额外攻击2次",
			Skill = {
				{
					Id = 102144,
					Value = 32,
				},
			},
		},
		{
			Stage = 8,
			Desc = "有{Value1}%概率额外攻击2次",
			Skill = {
				{
					Id = 102144,
					Value = 36,
				},
			},
		},
		{
			Stage = 9,
			Desc = "有{Value1}%概率额外攻击2次",
			Skill = {
				{
					Id = 102144,
					Value = 40,
				},
			},
		},
		{
			Stage = 10,
			Desc = "有{Value1}%概率额外攻击2次",
			Skill = {
				{
					Id = 102144,
					Value = 44,
				},
			},
		},
		{
			Stage = 11,
			Desc = "有{Value1}%概率额外攻击2次",
			Skill = {
				{
					Id = 102144,
					Value = 48,
				},
			},
		},
		{
			Stage = 12,
			Desc = "有{Value1}%概率额外攻击2次",
			Skill = {
				{
					Id = 102144,
					Value = 52,
				},
			},
		},
		{
			Stage = 13,
			Desc = "有{Value1}%概率额外攻击2次",
			Skill = {
				{
					Id = 102144,
					Value = 56,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320302,
			CatchChance = 5,
			CatchChanceGain = 12,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 5,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
		{
			Value = 320303,
			CatchChance = 33,
			CatchChanceGain = 25,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 33,
			SuccessChanceGain = 4,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560025,
		560045,
		560046,
		560032,
		560033,
		560034,
		560035,
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561206,
		561356,
		561361,
		563102,
		563204,
		563608,
		563708,
		563824,
		563302,
		563402,
		563503,
		563919,
		563922,
		564024,
		564039,
		564110,
		564204,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id126] =
{
	Id = 126,
	Name = "红草草",
	Area = 
	{
		130205,
		130210,
		130209,
		130207,
		130206,
	},
	Rarity = 1,
	Element = 210002,
	Gallery = 950005,
	Desc = "一颗毫无主见的红色海草，随波飘摇，虽然没有依据，但很多人坚信TA和绿草草是一家人。",
	LevelUp = 910001,
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Laminria2",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Laminria2",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectFire",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 54, Gain = 216},
		{Value = 200004, Base = 0, Gain = 0},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得海草 {Value1Divide}个",
			Skill = {
				{
					Id = 102145,
					Value = 150,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得海草 {Value1Divide}个",
			Skill = {
				{
					Id = 102145,
					Value = 225,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得海草 {Value1Divide}个",
			Skill = {
				{
					Id = 102145,
					Value = 300,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得海草 {Value1Divide}个",
			Skill = {
				{
					Id = 102145,
					Value = 375,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得海草 {Value1Divide}个",
			Skill = {
				{
					Id = 102145,
					Value = 450,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得海草 {Value1Divide}个",
			Skill = {
				{
					Id = 102145,
					Value = 525,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得海草 {Value1Divide}个",
			Skill = {
				{
					Id = 102145,
					Value = 600,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得海草 {Value1Divide}个",
			Skill = {
				{
					Id = 102145,
					Value = 675,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得海草 {Value1Divide}个",
			Skill = {
				{
					Id = 102145,
					Value = 750,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得海草 {Value1Divide}个",
			Skill = {
				{
					Id = 102145,
					Value = 825,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得海草 {Value1Divide}个",
			Skill = {
				{
					Id = 102145,
					Value = 900,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得海草 {Value1Divide}个",
			Skill = {
				{
					Id = 102145,
					Value = 975,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得海草 {Value1Divide}个",
			Skill = {
				{
					Id = 102145,
					Value = 1050,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320301,
			CatchChance = 50,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560022,
		560042,
		560043,
		560044,
		560045,
		560046,
		560032,
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561203,
		561355,
		561358,
		563102,
		563203,
		563613,
		563824,
		563304,
		563402,
		563502,
		563920,
		564013,
		564049,
		564144,
		564109,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id127] =
{
	Id = 127,
	Name = "海参",
	Area = 
	{
		130205,
		130208,
	},
	Rarity = 2,
	Element = 210001,
	Gallery = 950005,
	Desc = "热爱和同伴玩喷水游戏，但总是会喷出一些奇怪的东西。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_SeaCucumber1",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_SeaCucumber1",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWater",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 81, Gain = 324},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得应援毛巾 {Value1Divide}个",
			Skill = {
				{
					Id = 102146,
					Value = 40,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得应援毛巾 {Value1Divide}个",
			Skill = {
				{
					Id = 102146,
					Value = 60,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得应援毛巾 {Value1Divide}个",
			Skill = {
				{
					Id = 102146,
					Value = 80,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得应援毛巾 {Value1Divide}个",
			Skill = {
				{
					Id = 102146,
					Value = 100,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得应援毛巾 {Value1Divide}个",
			Skill = {
				{
					Id = 102146,
					Value = 120,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得应援毛巾 {Value1Divide}个",
			Skill = {
				{
					Id = 102146,
					Value = 140,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得应援毛巾 {Value1Divide}个",
			Skill = {
				{
					Id = 102146,
					Value = 160,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得应援毛巾 {Value1Divide}个",
			Skill = {
				{
					Id = 102146,
					Value = 180,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得应援毛巾 {Value1Divide}个",
			Skill = {
				{
					Id = 102146,
					Value = 200,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得应援毛巾 {Value1Divide}个",
			Skill = {
				{
					Id = 102146,
					Value = 220,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得应援毛巾 {Value1Divide}个",
			Skill = {
				{
					Id = 102146,
					Value = 240,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得应援毛巾 {Value1Divide}个",
			Skill = {
				{
					Id = 102146,
					Value = 260,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得应援毛巾 {Value1Divide}个",
			Skill = {
				{
					Id = 102146,
					Value = 280,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320301,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320302,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561202,
		561355,
		561361,
		563102,
		563202,
		563623,
		563824,
		563305,
		563402,
		563502,
		563940,
		564004,
		564024,
		564108,
		564205,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id128] =
{
	Id = 128,
	Name = "火山海参",
	Area = 
	{
		130205,
	},
	Rarity = 3,
	Element = 210002,
	Gallery = 950005,
	Desc = "是海参中的奇异物种，紧张或过于兴奋时会喷射出岩浆，一到冬天，许多鱼都会慕名过来取暖。",
	LevelUp = 910003,
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_SeaCucumber2",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_SeaCucumber2",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectFire",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 130, Gain = 520},
		{Value = 200004, Base = 10, Gain = 2},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "对风元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102147,
					Value = 50,
				},
			},
		},
		{
			Stage = 2,
			Desc = "对风元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102147,
					Value = 75,
				},
			},
		},
		{
			Stage = 3,
			Desc = "对风元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102147,
					Value = 100,
				},
			},
		},
		{
			Stage = 4,
			Desc = "对风元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102147,
					Value = 125,
				},
			},
		},
		{
			Stage = 5,
			Desc = "对风元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102147,
					Value = 150,
				},
			},
		},
		{
			Stage = 6,
			Desc = "对风元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102147,
					Value = 175,
				},
			},
		},
		{
			Stage = 7,
			Desc = "对风元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102147,
					Value = 200,
				},
			},
		},
		{
			Stage = 8,
			Desc = "对风元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102147,
					Value = 225,
				},
			},
		},
		{
			Stage = 9,
			Desc = "对风元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102147,
					Value = 250,
				},
			},
		},
		{
			Stage = 10,
			Desc = "对风元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102147,
					Value = 275,
				},
			},
		},
		{
			Stage = 11,
			Desc = "对风元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102147,
					Value = 300,
				},
			},
		},
		{
			Stage = 12,
			Desc = "对风元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102147,
					Value = 325,
				},
			},
		},
		{
			Stage = 13,
			Desc = "对风元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102147,
					Value = 350,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320302,
			CatchChance = 30,
			CatchChanceGain = 5,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 25,
			SuccessChanceGain = 2,
			SuccessChanceMax = 100,
		},
		{
			Value = 320303,
			CatchChance = 50,
			CatchChanceGain = 10,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561203,
		561355,
		561361,
		563102,
		563202,
		563623,
		563824,
		563305,
		563404,
		563502,
		563920,
		564004,
		564024,
		564109,
		564205,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id129] =
{
	Id = 129,
	Name = "绿礁保安",
	Area = 
	{
		130206,
		130212,
		130211,
		130208,
	},
	Rarity = 2,
	Element = 210003,
	Gallery = 950005,
	Desc = "穿着绿色制服的保安，保卫礁石区一方平安，会对危害公共安全的危险分子，会毫不留情发射藤壶。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Ston1",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Stone1",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 81, Gain = 324},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得礁石 {Value1Divide}个",
			Skill = {
				{
					Id = 102148,
					Value = 40,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得礁石 {Value1Divide}个",
			Skill = {
				{
					Id = 102148,
					Value = 60,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得礁石 {Value1Divide}个",
			Skill = {
				{
					Id = 102148,
					Value = 80,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得礁石 {Value1Divide}个",
			Skill = {
				{
					Id = 102148,
					Value = 100,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得礁石 {Value1Divide}个",
			Skill = {
				{
					Id = 102148,
					Value = 120,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得礁石 {Value1Divide}个",
			Skill = {
				{
					Id = 102148,
					Value = 140,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得礁石 {Value1Divide}个",
			Skill = {
				{
					Id = 102148,
					Value = 160,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得礁石 {Value1Divide}个",
			Skill = {
				{
					Id = 102148,
					Value = 180,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得礁石 {Value1Divide}个",
			Skill = {
				{
					Id = 102148,
					Value = 200,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得礁石 {Value1Divide}个",
			Skill = {
				{
					Id = 102148,
					Value = 220,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得礁石 {Value1Divide}个",
			Skill = {
				{
					Id = 102148,
					Value = 240,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得礁石 {Value1Divide}个",
			Skill = {
				{
					Id = 102148,
					Value = 260,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得礁石 {Value1Divide}个",
			Skill = {
				{
					Id = 102148,
					Value = 280,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320313,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320314,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561204,
		561356,
		561325,
		563105,
		563202,
		563619,
		563815,
		563303,
		563402,
		563502,
		563940,
		564029,
		564114,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id130] =
{
	Id = 130,
	Name = "蓝礁保安",
	Area = 
	{
		130206,
	},
	Rarity = 3,
	Element = 210001,
	Gallery = 950005,
	Desc = "穿着蓝色制服的保安，比起发射远程武器，更喜欢用喇叭大喊大叫，用声波击退敌人。",
	LevelUp = 910003,
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Stone2",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Stone2",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWater",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 130, Gain = 520},
		{Value = 200004, Base = 10, Gain = 2},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102149,
					Value = 2,
				},
			},
		},
		{
			Stage = 2,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102149,
					Value = 3,
				},
			},
		},
		{
			Stage = 3,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102149,
					Value = 4,
				},
			},
		},
		{
			Stage = 4,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102149,
					Value = 5,
				},
			},
		},
		{
			Stage = 5,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102149,
					Value = 6,
				},
			},
		},
		{
			Stage = 6,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102149,
					Value = 7,
				},
			},
		},
		{
			Stage = 7,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102149,
					Value = 8,
				},
			},
		},
		{
			Stage = 8,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102149,
					Value = 9,
				},
			},
		},
		{
			Stage = 9,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102149,
					Value = 10,
				},
			},
		},
		{
			Stage = 10,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102149,
					Value = 11,
				},
			},
		},
		{
			Stage = 11,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102149,
					Value = 12,
				},
			},
		},
		{
			Stage = 12,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102149,
					Value = 13,
				},
			},
		},
		{
			Stage = 13,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102149,
					Value = 14,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320314,
			CatchChance = 30,
			CatchChanceGain = 5,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 25,
			SuccessChanceGain = 2,
			SuccessChanceMax = 100,
		},
		{
			Value = 320315,
			CatchChance = 50,
			CatchChanceGain = 10,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561202,
		561356,
		561325,
		563105,
		563202,
		563619,
		563815,
		563303,
		563402,
		563502,
		563935,
		564029,
		564114,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id131] =
{
	Id = 131,
	Name = "比目司机",
	Area = 
	{
		130207,
		130209,
	},
	Rarity = 2,
	Element = 210003,
	Gallery = 950005,
	Desc = "常年行驶在星光小道的司机，因为两只眼睛都长在左边，所以只能看到左边的路。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Flatfish",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Flatfish",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 81, Gain = 324},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102150,
					Value = -3,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102150,
					Value = -4,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102150,
					Value = -5,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102150,
					Value = -6,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102150,
					Value = -7,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102150,
					Value = -8,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102150,
					Value = -9,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102150,
					Value = -10,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102150,
					Value = -11,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102150,
					Value = -12,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102150,
					Value = -13,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102150,
					Value = -14,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102150,
					Value = -15,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320309,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320310,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561204,
		561355,
		561328,
		563104,
		563205,
		563613,
		563824,
		563304,
		563402,
		563503,
		563940,
		563912,
		564004,
		564110,
		564204,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id132] =
{
	Id = 132,
	Name = "小丑司机",
	Area = 
	{
		130207,
		130212,
	},
	Rarity = 3,
	Element = 210001,
	Gallery = 950005,
	Desc = "星光小道的司机，有时候无法控制自己的行动，会下意识把乘客带去海葵的区域。",
	LevelUp = 910003,
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Nemo",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Nemo",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWater",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 130, Gain = 520},
		{Value = 200004, Base = 10, Gain = 2},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得鱼鳞 {Value1Divide}个",
			Skill = {
				{
					Id = 102151,
					Value = 40,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得鱼鳞 {Value1Divide}个",
			Skill = {
				{
					Id = 102151,
					Value = 60,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得鱼鳞 {Value1Divide}个",
			Skill = {
				{
					Id = 102151,
					Value = 80,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得鱼鳞 {Value1Divide}个",
			Skill = {
				{
					Id = 102151,
					Value = 100,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得鱼鳞 {Value1Divide}个",
			Skill = {
				{
					Id = 102151,
					Value = 120,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得鱼鳞 {Value1Divide}个",
			Skill = {
				{
					Id = 102151,
					Value = 140,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得鱼鳞 {Value1Divide}个",
			Skill = {
				{
					Id = 102151,
					Value = 160,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得鱼鳞 {Value1Divide}个",
			Skill = {
				{
					Id = 102151,
					Value = 180,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得鱼鳞 {Value1Divide}个",
			Skill = {
				{
					Id = 102151,
					Value = 200,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得鱼鳞 {Value1Divide}个",
			Skill = {
				{
					Id = 102151,
					Value = 220,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得鱼鳞 {Value1Divide}个",
			Skill = {
				{
					Id = 102151,
					Value = 240,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得鱼鳞 {Value1Divide}个",
			Skill = {
				{
					Id = 102151,
					Value = 260,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得鱼鳞 {Value1Divide}个",
			Skill = {
				{
					Id = 102151,
					Value = 280,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320310,
			CatchChance = 30,
			CatchChanceGain = 5,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 25,
			SuccessChanceGain = 2,
			SuccessChanceMax = 100,
		},
		{
			Value = 320311,
			CatchChance = 50,
			CatchChanceGain = 10,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561202,
		561355,
		561328,
		563104,
		563205,
		563613,
		563824,
		563304,
		563402,
		563504,
		563919,
		563903,
		563912,
		564004,
		564110,
		564204,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id133] =
{
	Id = 133,
	Name = "神仙司机",
	Area = 
	{
		130207,
	},
	Rarity = 4,
	Element = 210004,
	Gallery = 950005,
	Desc = "星光小道的神仙司机，能把准确地把乘客带去目的地，但是要坐上TA的车，并不是一件容易的事。",
	LevelUp = 910004,
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_TropicalFish",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_TropicalFish",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectLight",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 188, Gain = 752},
		{Value = 200004, Base = 15, Gain = 3},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102152,
					Value = -5,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102152,
					Value = -7,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102152,
					Value = -9,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102152,
					Value = -11,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102152,
					Value = -13,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102152,
					Value = -15,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102152,
					Value = -17,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102152,
					Value = -19,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102152,
					Value = -21,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102152,
					Value = -23,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102152,
					Value = -25,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102152,
					Value = -27,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102152,
					Value = -29,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320310,
			CatchChance = 5,
			CatchChanceGain = 12,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 5,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
		{
			Value = 320311,
			CatchChance = 33,
			CatchChanceGain = 25,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 33,
			SuccessChanceGain = 4,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560025,
		560045,
		560046,
		560032,
		560033,
		560034,
		560035,
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561205,
		561355,
		561328,
		563104,
		563205,
		563613,
		563824,
		563304,
		563402,
		563503,
		563924,
		563914,
		564004,
		564110,
		564204,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id134] =
{
	Id = 134,
	Name = "蓝记水母",
	Area = 
	{
		130208,
		130211,
		130210,
	},
	Rarity = 2,
	Element = 210001,
	Gallery = 950005,
	Desc = "鱼乐日报记者，又名皮埃斯，擅长图片编辑，有伪造图片被艺人告上法庭的经历。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Jellyfish1",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Jellyfish1",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWater",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 81, Gain = 324},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102153,
					Value = 8,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102153,
					Value = 12,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102153,
					Value = 16,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102153,
					Value = 20,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102153,
					Value = 24,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102153,
					Value = 28,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102153,
					Value = 32,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102153,
					Value = 36,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102153,
					Value = 40,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102153,
					Value = 44,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102153,
					Value = 48,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102153,
					Value = 52,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102153,
					Value = 56,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320305,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320306,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561202,
		561355,
		561362,
		563103,
		563203,
		563619,
		563708,
		563825,
		563304,
		563402,
		563502,
		563936,
		564020,
		564013,
		564110,
		564203,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id135] =
{
	Id = 135,
	Name = "紫记水母",
	Area = 
	{
		130208,
	},
	Rarity = 3,
	Element = 210005,
	Gallery = 950005,
	Desc = "鱼乐日报记者，公认的标题党，因为标题过于猎奇，在读者中已经失去了可信度。",
	LevelUp = 910003,
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Jellyfish3",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Jellyfish3",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectDark",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 130, Gain = 520},
		{Value = 200004, Base = 10, Gain = 2},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得防水相机 {Value1Divide}个",
			Skill = {
				{
					Id = 102154,
					Value = 120,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得防水相机 {Value1Divide}个",
			Skill = {
				{
					Id = 102154,
					Value = 180,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得防水相机 {Value1Divide}个",
			Skill = {
				{
					Id = 102154,
					Value = 240,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得防水相机 {Value1Divide}个",
			Skill = {
				{
					Id = 102154,
					Value = 300,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得防水相机 {Value1Divide}个",
			Skill = {
				{
					Id = 102154,
					Value = 360,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得防水相机 {Value1Divide}个",
			Skill = {
				{
					Id = 102154,
					Value = 420,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得防水相机 {Value1Divide}个",
			Skill = {
				{
					Id = 102154,
					Value = 480,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得防水相机 {Value1Divide}个",
			Skill = {
				{
					Id = 102154,
					Value = 540,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得防水相机 {Value1Divide}个",
			Skill = {
				{
					Id = 102154,
					Value = 600,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得防水相机 {Value1Divide}个",
			Skill = {
				{
					Id = 102154,
					Value = 660,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得防水相机 {Value1Divide}个",
			Skill = {
				{
					Id = 102154,
					Value = 720,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得防水相机 {Value1Divide}个",
			Skill = {
				{
					Id = 102154,
					Value = 780,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得防水相机 {Value1Divide}个",
			Skill = {
				{
					Id = 102154,
					Value = 840,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320306,
			CatchChance = 30,
			CatchChanceGain = 5,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 25,
			SuccessChanceGain = 2,
			SuccessChanceMax = 100,
		},
		{
			Value = 320307,
			CatchChance = 50,
			CatchChanceGain = 10,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561206,
		561355,
		561362,
		563103,
		563203,
		563619,
		563708,
		563825,
		563304,
		563402,
		563502,
		563951,
		564020,
		564013,
		564110,
		564203,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id136] =
{
	Id = 136,
	Name = "黄记水母",
	Area = 
	{
		130208,
	},
	Rarity = 4,
	Element = 210004,
	Gallery = 950005,
	Desc = "鱼乐日报记者，常用黄色的纸笔，写下带颜色的文章，迄今为止已收到了2356份律师函。",
	LevelUp = 910004,
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Jellyfish2",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Jellyfish2",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectLight",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 188, Gain = 752},
		{Value = 200004, Base = 15, Gain = 3},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102155,
					Value = 7,
				},
			},
		},
		{
			Stage = 2,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102155,
					Value = 10,
				},
			},
		},
		{
			Stage = 3,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102155,
					Value = 13,
				},
			},
		},
		{
			Stage = 4,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102155,
					Value = 16,
				},
			},
		},
		{
			Stage = 5,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102155,
					Value = 19,
				},
			},
		},
		{
			Stage = 6,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102155,
					Value = 22,
				},
			},
		},
		{
			Stage = 7,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102155,
					Value = 25,
				},
			},
		},
		{
			Stage = 8,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102155,
					Value = 28,
				},
			},
		},
		{
			Stage = 9,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102155,
					Value = 31,
				},
			},
		},
		{
			Stage = 10,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102155,
					Value = 34,
				},
			},
		},
		{
			Stage = 11,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102155,
					Value = 37,
				},
			},
		},
		{
			Stage = 12,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102155,
					Value = 40,
				},
			},
		},
		{
			Stage = 13,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102155,
					Value = 43,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320306,
			CatchChance = 5,
			CatchChanceGain = 12,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 5,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
		{
			Value = 320307,
			CatchChance = 33,
			CatchChanceGain = 25,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 33,
			SuccessChanceGain = 4,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560025,
		560045,
		560046,
		560032,
		560033,
		560034,
		560035,
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561205,
		561355,
		561362,
		563103,
		563203,
		563619,
		563708,
		563825,
		563304,
		563402,
		563502,
		563926,
		564020,
		564013,
		564110,
		564203,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id137] =
{
	Id = 137,
	Name = "海蛇",
	Area = 
	{
		130209,
		130210,
	},
	Rarity = 2,
	Element = 210003,
	Gallery = 950005,
	Desc = "地下乐队的组织者，死亡重金属爱好者，据说曾是海蛇莱斯莉的队友。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Snake1",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Snake1",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 81, Gain = 324},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得摇滚耳机 {Value1Divide}个",
			Skill = {
				{
					Id = 102156,
					Value = 40,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得摇滚耳机 {Value1Divide}个",
			Skill = {
				{
					Id = 102156,
					Value = 60,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得摇滚耳机 {Value1Divide}个",
			Skill = {
				{
					Id = 102156,
					Value = 80,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得摇滚耳机 {Value1Divide}个",
			Skill = {
				{
					Id = 102156,
					Value = 100,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得摇滚耳机 {Value1Divide}个",
			Skill = {
				{
					Id = 102156,
					Value = 120,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得摇滚耳机 {Value1Divide}个",
			Skill = {
				{
					Id = 102156,
					Value = 140,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得摇滚耳机 {Value1Divide}个",
			Skill = {
				{
					Id = 102156,
					Value = 160,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得摇滚耳机 {Value1Divide}个",
			Skill = {
				{
					Id = 102156,
					Value = 180,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得摇滚耳机 {Value1Divide}个",
			Skill = {
				{
					Id = 102156,
					Value = 200,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得摇滚耳机 {Value1Divide}个",
			Skill = {
				{
					Id = 102156,
					Value = 220,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得摇滚耳机 {Value1Divide}个",
			Skill = {
				{
					Id = 102156,
					Value = 240,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得摇滚耳机 {Value1Divide}个",
			Skill = {
				{
					Id = 102156,
					Value = 260,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得摇滚耳机 {Value1Divide}个",
			Skill = {
				{
					Id = 102156,
					Value = 280,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320305,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320306,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561204,
		561356,
		561363,
		563103,
		563205,
		563824,
		563302,
		563402,
		563503,
		563905,
		563914,
		564038,
		564033,
		564111,
		564205,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id138] =
{
	Id = 138,
	Name = "闪电海蛇",
	Area = 
	{
		130209,
	},
	Rarity = 4,
	Element = 210003,
	Gallery = 950005,
	Desc = "曾是海蛇莱斯莉的队友，产出了许多重金属风格的demo，最近在尝试新的音乐风格。",
	LevelUp = 910004,
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Snake2",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Snake2",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 188, Gain = 752},
		{Value = 200004, Base = 15, Gain = 3},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102157,
					Value = -5,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102157,
					Value = -7,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102157,
					Value = -9,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102157,
					Value = -11,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102157,
					Value = -13,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102157,
					Value = -15,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102157,
					Value = -17,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102157,
					Value = -19,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102157,
					Value = -21,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102157,
					Value = -23,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102157,
					Value = -25,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102157,
					Value = -27,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索等待时间 -{Value1}%",
			Skill = {
				{
					Id = 102157,
					Value = -29,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320306,
			CatchChance = 5,
			CatchChanceGain = 12,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 5,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
		{
			Value = 320307,
			CatchChance = 33,
			CatchChanceGain = 25,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 33,
			SuccessChanceGain = 4,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560025,
		560045,
		560046,
		560032,
		560033,
		560034,
		560035,
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561204,
		561356,
		561363,
		563103,
		563205,
		563824,
		563302,
		563402,
		563503,
		563925,
		563944,
		564039,
		564035,
		564111,
		564205,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id139] =
{
	Id = 139,
	Name = "海星星",
	Area = 
	{
		130210,
		130213,
	},
	Rarity = 2,
	Element = 210001,
	Gallery = 950005,
	Desc = "天鱼公司的初级经纪，主要负责面试艺人，在工作中兢兢业业，希望通过自己的努力升职加薪。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_SeaStar",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_SeaStar",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWater",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 81, Gain = 324},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得队员服 {Value1Divide}个",
			Skill = {
				{
					Id = 102158,
					Value = 30,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得队员服 {Value1Divide}个",
			Skill = {
				{
					Id = 102158,
					Value = 45,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得队员服 {Value1Divide}个",
			Skill = {
				{
					Id = 102158,
					Value = 60,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得队员服 {Value1Divide}个",
			Skill = {
				{
					Id = 102158,
					Value = 75,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得队员服 {Value1Divide}个",
			Skill = {
				{
					Id = 102158,
					Value = 90,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得队员服 {Value1Divide}个",
			Skill = {
				{
					Id = 102158,
					Value = 105,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得队员服 {Value1Divide}个",
			Skill = {
				{
					Id = 102158,
					Value = 120,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得队员服 {Value1Divide}个",
			Skill = {
				{
					Id = 102158,
					Value = 135,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得队员服 {Value1Divide}个",
			Skill = {
				{
					Id = 102158,
					Value = 150,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得队员服 {Value1Divide}个",
			Skill = {
				{
					Id = 102158,
					Value = 165,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得队员服 {Value1Divide}个",
			Skill = {
				{
					Id = 102158,
					Value = 180,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得队员服 {Value1Divide}个",
			Skill = {
				{
					Id = 102158,
					Value = 195,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得队员服 {Value1Divide}个",
			Skill = {
				{
					Id = 102158,
					Value = 210,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320301,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320302,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561202,
		561356,
		561364,
		563102,
		563203,
		563603,
		563823,
		563303,
		563402,
		563503,
		563935,
		563913,
		564009,
		564023,
		564109,
		564113,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id140] =
{
	Id = 140,
	Name = "皇冠星探",
	Area = 
	{
		130210,
	},
	Rarity = 4,
	Element = 210001,
	Gallery = 950005,
	Desc = "天鱼公司的高级经纪，业务能力了得，就连公司boss帝王蟹老板也非常尊敬TA。",
	LevelUp = 910004,
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_KingSeaStar",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_KingSeaStar",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWater",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 188, Gain = 752},
		{Value = 200004, Base = 15, Gain = 3},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102159,
					Value = 4,
				},
			},
		},
		{
			Stage = 2,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102159,
					Value = 6,
				},
			},
		},
		{
			Stage = 3,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102159,
					Value = 8,
				},
			},
		},
		{
			Stage = 4,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102159,
					Value = 10,
				},
			},
		},
		{
			Stage = 5,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102159,
					Value = 12,
				},
			},
		},
		{
			Stage = 6,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102159,
					Value = 14,
				},
			},
		},
		{
			Stage = 7,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102159,
					Value = 16,
				},
			},
		},
		{
			Stage = 8,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102159,
					Value = 18,
				},
			},
		},
		{
			Stage = 9,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102159,
					Value = 20,
				},
			},
		},
		{
			Stage = 10,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102159,
					Value = 22,
				},
			},
		},
		{
			Stage = 11,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102159,
					Value = 24,
				},
			},
		},
		{
			Stage = 12,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102159,
					Value = 26,
				},
			},
		},
		{
			Stage = 13,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102159,
					Value = 28,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320302,
			CatchChance = 5,
			CatchChanceGain = 12,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 5,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
		{
			Value = 320303,
			CatchChance = 33,
			CatchChanceGain = 25,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 33,
			SuccessChanceGain = 4,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560025,
		560045,
		560046,
		560032,
		560033,
		560034,
		560035,
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561202,
		561356,
		561364,
		563102,
		563203,
		563603,
		563823,
		563303,
		563402,
		563504,
		563950,
		563923,
		563912,
		564010,
		564035,
		564109,
		564113,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id141] =
{
	Id = 141,
	Name = "水熊虫",
	Area = 
	{
		130211,
		130214,
		130213,
		130212,
	},
	Rarity = 1,
	Element = 210001,
	Gallery = 950005,
	Desc = "海底世界的厕所管理员，对于那些想进入未成年厕所的家伙，一定要仔细检查TA们的身体。",
	LevelUp = 910001,
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_WaterBear",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_WaterBear",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWater",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 54, Gain = 216},
		{Value = 200004, Base = 0, Gain = 0},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102160,
					Value = 6,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102160,
					Value = 9,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102160,
					Value = 12,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102160,
					Value = 15,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102160,
					Value = 18,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102160,
					Value = 21,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102160,
					Value = 24,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102160,
					Value = 27,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102160,
					Value = 30,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102160,
					Value = 33,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102160,
					Value = 36,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102160,
					Value = 39,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102160,
					Value = 42,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320305,
			CatchChance = 50,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560022,
		560042,
		560043,
		560044,
		560045,
		560046,
		560032,
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561202,
		561355,
		561365,
		563103,
		563203,
		563303,
		563402,
		563502,
		563946,
		564025,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id142] =
{
	Id = 142,
	Name = "绿绵宝宝",
	Area = 
	{
		130211,
	},
	Rarity = 2,
	Element = 210003,
	Gallery = 950005,
	Desc = "蟹老板雇来抹黑海豚凛的水军，给钱就办事，非常好说话。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_CoralReef2",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_CoralReef2",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 81, Gain = 324},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得强力海绵 {Value1Divide}个",
			Skill = {
				{
					Id = 102161,
					Value = 30,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得强力海绵 {Value1Divide}个",
			Skill = {
				{
					Id = 102161,
					Value = 45,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得强力海绵 {Value1Divide}个",
			Skill = {
				{
					Id = 102161,
					Value = 60,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得强力海绵 {Value1Divide}个",
			Skill = {
				{
					Id = 102161,
					Value = 75,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得强力海绵 {Value1Divide}个",
			Skill = {
				{
					Id = 102161,
					Value = 90,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得强力海绵 {Value1Divide}个",
			Skill = {
				{
					Id = 102161,
					Value = 105,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得强力海绵 {Value1Divide}个",
			Skill = {
				{
					Id = 102161,
					Value = 120,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得强力海绵 {Value1Divide}个",
			Skill = {
				{
					Id = 102161,
					Value = 135,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得强力海绵 {Value1Divide}个",
			Skill = {
				{
					Id = 102161,
					Value = 150,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得强力海绵 {Value1Divide}个",
			Skill = {
				{
					Id = 102161,
					Value = 165,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得强力海绵 {Value1Divide}个",
			Skill = {
				{
					Id = 102161,
					Value = 180,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得强力海绵 {Value1Divide}个",
			Skill = {
				{
					Id = 102161,
					Value = 195,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得强力海绵 {Value1Divide}个",
			Skill = {
				{
					Id = 102161,
					Value = 210,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320309,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320310,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561204,
		561355,
		561325,
		563104,
		563203,
		563619,
		563708,
		563823,
		563303,
		563402,
		563503,
		563940,
		563942,
		564049,
		564114,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id143] =
{
	Id = 143,
	Name = "红绵宝宝",
	Area = 
	{
		130211,
	},
	Rarity = 3,
	Element = 210002,
	Gallery = 950005,
	Desc = "蟹老板雇来抹黑海豚凛的水军，什么？除了现场闹事，还要去其他地方散播要钱？可以，但得加钱。",
	LevelUp = 910003,
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_CoralReef1",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_CoralReef1",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectFire",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 130, Gain = 520},
		{Value = 200004, Base = 10, Gain = 2},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102162,
					Value = 3,
				},
			},
		},
		{
			Stage = 2,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102162,
					Value = 4,
				},
			},
		},
		{
			Stage = 3,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102162,
					Value = 5,
				},
			},
		},
		{
			Stage = 4,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102162,
					Value = 6,
				},
			},
		},
		{
			Stage = 5,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102162,
					Value = 7,
				},
			},
		},
		{
			Stage = 6,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102162,
					Value = 8,
				},
			},
		},
		{
			Stage = 7,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102162,
					Value = 9,
				},
			},
		},
		{
			Stage = 8,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102162,
					Value = 10,
				},
			},
		},
		{
			Stage = 9,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102162,
					Value = 11,
				},
			},
		},
		{
			Stage = 10,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102162,
					Value = 12,
				},
			},
		},
		{
			Stage = 11,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102162,
					Value = 13,
				},
			},
		},
		{
			Stage = 12,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102162,
					Value = 14,
				},
			},
		},
		{
			Stage = 13,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102162,
					Value = 15,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320310,
			CatchChance = 30,
			CatchChanceGain = 5,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 25,
			SuccessChanceGain = 2,
			SuccessChanceMax = 100,
		},
		{
			Value = 320311,
			CatchChance = 50,
			CatchChanceGain = 10,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561203,
		561355,
		561325,
		563104,
		563203,
		563619,
		563708,
		563823,
		563303,
		563402,
		563503,
		563920,
		563942,
		564049,
		564114,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id144] =
{
	Id = 144,
	Name = "红海葵",
	Area = 
	{
		130212,
	},
	Rarity = 2,
	Element = 210002,
	Gallery = 950005,
	Desc = "天鱼公司的星探之一，曾哄骗许多艺人签下不公平合同，在鱼乐圈中臭名昭著，但总会骗到一些初入圈子的小白。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Actinian2",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Actinian2",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectFire",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 81, Gain = 324},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得应援棒 {Value1Divide}个",
			Skill = {
				{
					Id = 102163,
					Value = 30,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得应援棒 {Value1Divide}个",
			Skill = {
				{
					Id = 102163,
					Value = 45,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得应援棒 {Value1Divide}个",
			Skill = {
				{
					Id = 102163,
					Value = 60,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得应援棒 {Value1Divide}个",
			Skill = {
				{
					Id = 102163,
					Value = 75,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得应援棒 {Value1Divide}个",
			Skill = {
				{
					Id = 102163,
					Value = 90,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得应援棒 {Value1Divide}个",
			Skill = {
				{
					Id = 102163,
					Value = 105,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得应援棒 {Value1Divide}个",
			Skill = {
				{
					Id = 102163,
					Value = 120,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得应援棒 {Value1Divide}个",
			Skill = {
				{
					Id = 102163,
					Value = 135,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得应援棒 {Value1Divide}个",
			Skill = {
				{
					Id = 102163,
					Value = 150,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得应援棒 {Value1Divide}个",
			Skill = {
				{
					Id = 102163,
					Value = 165,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得应援棒 {Value1Divide}个",
			Skill = {
				{
					Id = 102163,
					Value = 180,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得应援棒 {Value1Divide}个",
			Skill = {
				{
					Id = 102163,
					Value = 195,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得应援棒 {Value1Divide}个",
			Skill = {
				{
					Id = 102163,
					Value = 210,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320317,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320318,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561203,
		561355,
		561366,
		563106,
		563202,
		563623,
		563823,
		563304,
		563402,
		563503,
		563919,
		563913,
		564004,
		564048,
		564109,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id145] =
{
	Id = 145,
	Name = "蓝海葵",
	Area = 
	{
		130212,
		130213,
	},
	Rarity = 2,
	Element = 210001,
	Gallery = 950005,
	Desc = "天鱼公司的星探之一，除了小丑鱼，不会考虑和其他种族的任何艺人签约，因此业绩一直平平。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Actinian1",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Actinian1",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWater",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 81, Gain = 324},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102164,
					Value = -10,
				},
			},
		},
		{
			Stage = 2,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102164,
					Value = -15,
				},
			},
		},
		{
			Stage = 3,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102164,
					Value = -20,
				},
			},
		},
		{
			Stage = 4,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102164,
					Value = -25,
				},
			},
		},
		{
			Stage = 5,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102164,
					Value = -30,
				},
			},
		},
		{
			Stage = 6,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102164,
					Value = -35,
				},
			},
		},
		{
			Stage = 7,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102164,
					Value = -40,
				},
			},
		},
		{
			Stage = 8,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102164,
					Value = -45,
				},
			},
		},
		{
			Stage = 9,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102164,
					Value = -50,
				},
			},
		},
		{
			Stage = 10,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102164,
					Value = -55,
				},
			},
		},
		{
			Stage = 11,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102164,
					Value = -60,
				},
			},
		},
		{
			Stage = 12,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102164,
					Value = -65,
				},
			},
		},
		{
			Stage = 13,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102164,
					Value = -70,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320317,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320318,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561202,
		561355,
		561366,
		563106,
		563202,
		563623,
		563823,
		563304,
		563402,
		563503,
		563934,
		563913,
		564004,
		564048,
		564109,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id146] =
{
	Id = 146,
	Name = "蟹经理",
	Area = 
	{
		130213,
		130214,
	},
	Rarity = 3,
	Element = 210003,
	Gallery = 950005,
	Desc = "天鱼公司总经理，唯董事长马首是瞻。",
	LevelUp = 910003,
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Crab",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Crab",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 130, Gain = 520},
		{Value = 200004, Base = 10, Gain = 2},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得尖叫 {Value1Divide}个",
			Skill = {
				{
					Id = 102165,
					Value = 40,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得尖叫 {Value1Divide}个",
			Skill = {
				{
					Id = 102165,
					Value = 60,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得尖叫 {Value1Divide}个",
			Skill = {
				{
					Id = 102165,
					Value = 80,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得尖叫 {Value1Divide}个",
			Skill = {
				{
					Id = 102165,
					Value = 100,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得尖叫 {Value1Divide}个",
			Skill = {
				{
					Id = 102165,
					Value = 120,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得尖叫 {Value1Divide}个",
			Skill = {
				{
					Id = 102165,
					Value = 140,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得尖叫 {Value1Divide}个",
			Skill = {
				{
					Id = 102165,
					Value = 160,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得尖叫 {Value1Divide}个",
			Skill = {
				{
					Id = 102165,
					Value = 180,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得尖叫 {Value1Divide}个",
			Skill = {
				{
					Id = 102165,
					Value = 200,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得尖叫 {Value1Divide}个",
			Skill = {
				{
					Id = 102165,
					Value = 220,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得尖叫 {Value1Divide}个",
			Skill = {
				{
					Id = 102165,
					Value = 240,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得尖叫 {Value1Divide}个",
			Skill = {
				{
					Id = 102165,
					Value = 260,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得尖叫 {Value1Divide}个",
			Skill = {
				{
					Id = 102165,
					Value = 280,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320314,
			CatchChance = 30,
			CatchChanceGain = 5,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 25,
			SuccessChanceGain = 2,
			SuccessChanceMax = 100,
		},
		{
			Value = 320315,
			CatchChance = 50,
			CatchChanceGain = 10,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561204,
		561356,
		561367,
		563105,
		563204,
		563809,
		563302,
		563402,
		563503,
		563940,
		563903,
		564030,
		564035,
		564111,
		564205,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id147] =
{
	Id = 147,
	Name = "蟹董事",
	Area = 
	{
		130213,
	},
	Rarity = 4,
	Element = 210002,
	Gallery = 950005,
	Desc = "天鱼公司董事长，被别人称为蟹老板，然而TA对此表示非常不满，并要求大家称呼自己为“帝王蟹董事”。",
	LevelUp = 910004,
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_KingCrab",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_KingCrab",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectFire",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 188, Gain = 752},
		{Value = 200004, Base = 15, Gain = 3},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "{Value1}%概率无视敌人的闪避，1回合后攻击时无视敌人{Value2}%忍耐",
			Skill = {
				{
					Id = 102166,
					Value = 20,
				},
				{
					Id = 102167,
					Value = 20,
				},
			},
		},
		{
			Stage = 2,
			Desc = "{Value1}%概率无视敌人的闪避，1回合后攻击时无视敌人{Value2}%忍耐",
			Skill = {
				{
					Id = 102166,
					Value = 30,
				},
				{
					Id = 102167,
					Value = 30,
				},
			},
		},
		{
			Stage = 3,
			Desc = "{Value1}%概率无视敌人的闪避，1回合后攻击时无视敌人{Value2}%忍耐",
			Skill = {
				{
					Id = 102166,
					Value = 40,
				},
				{
					Id = 102167,
					Value = 40,
				},
			},
		},
		{
			Stage = 4,
			Desc = "{Value1}%概率无视敌人的闪避，1回合后攻击时无视敌人{Value2}%忍耐",
			Skill = {
				{
					Id = 102166,
					Value = 50,
				},
				{
					Id = 102167,
					Value = 50,
				},
			},
		},
		{
			Stage = 5,
			Desc = "{Value1}%概率无视敌人的闪避，1回合后攻击时无视敌人{Value2}%忍耐",
			Skill = {
				{
					Id = 102166,
					Value = 60,
				},
				{
					Id = 102167,
					Value = 60,
				},
			},
		},
		{
			Stage = 6,
			Desc = "{Value1}%概率无视敌人的闪避，1回合后攻击时无视敌人{Value2}%忍耐",
			Skill = {
				{
					Id = 102166,
					Value = 70,
				},
				{
					Id = 102167,
					Value = 70,
				},
			},
		},
		{
			Stage = 7,
			Desc = "{Value1}%概率无视敌人的闪避，1回合后攻击时无视敌人{Value2}%忍耐",
			Skill = {
				{
					Id = 102166,
					Value = 80,
				},
				{
					Id = 102167,
					Value = 80,
				},
			},
		},
		{
			Stage = 8,
			Desc = "{Value1}%概率无视敌人的闪避，1回合后攻击时无视敌人{Value2}%忍耐",
			Skill = {
				{
					Id = 102166,
					Value = 90,
				},
				{
					Id = 102167,
					Value = 90,
				},
			},
		},
		{
			Stage = 9,
			Desc = "{Value1}%概率无视敌人的闪避，1回合后攻击时无视敌人{Value2}%忍耐",
			Skill = {
				{
					Id = 102166,
					Value = 100,
				},
				{
					Id = 102167,
					Value = 100,
				},
			},
		},
		{
			Stage = 10,
			Desc = "{Value1}%概率无视敌人的闪避，1回合后攻击时无视敌人{Value2}%忍耐",
			Skill = {
				{
					Id = 102166,
					Value = 110,
				},
				{
					Id = 102167,
					Value = 110,
				},
			},
		},
		{
			Stage = 11,
			Desc = "{Value1}%概率无视敌人的闪避，1回合后攻击时无视敌人{Value2}%忍耐",
			Skill = {
				{
					Id = 102166,
					Value = 120,
				},
				{
					Id = 102167,
					Value = 120,
				},
			},
		},
		{
			Stage = 12,
			Desc = "{Value1}%概率无视敌人的闪避，1回合后攻击时无视敌人{Value2}%忍耐",
			Skill = {
				{
					Id = 102166,
					Value = 130,
				},
				{
					Id = 102167,
					Value = 130,
				},
			},
		},
		{
			Stage = 13,
			Desc = "{Value1}%概率无视敌人的闪避，1回合后攻击时无视敌人{Value2}%忍耐",
			Skill = {
				{
					Id = 102166,
					Value = 140,
				},
				{
					Id = 102167,
					Value = 140,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320314,
			CatchChance = 5,
			CatchChanceGain = 12,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 5,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
		{
			Value = 320315,
			CatchChance = 33,
			CatchChanceGain = 25,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 33,
			SuccessChanceGain = 4,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560025,
		560045,
		560046,
		560032,
		560033,
		560034,
		560035,
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561203,
		561356,
		561367,
		563105,
		563204,
		563809,
		563302,
		563402,
		563503,
		563920,
		563903,
		564030,
		564036,
		564111,
		564205,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id148] =
{
	Id = 148,
	Name = "绵羊海兔",
	Area = 
	{
		130214,
	},
	Rarity = 2,
	Element = 210003,
	Gallery = 950005,
	Desc = "绿色的海兔，每天除了吃喝玩乐，就是吃喝玩乐。",
	LevelUp = 910002,
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Aplysia3",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Aplysia3",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 81, Gain = 324},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102168,
					Value = 8,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102168,
					Value = 12,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102168,
					Value = 16,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102168,
					Value = 20,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102168,
					Value = 24,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102168,
					Value = 28,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102168,
					Value = 32,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102168,
					Value = 36,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102168,
					Value = 40,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102168,
					Value = 44,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102168,
					Value = 48,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102168,
					Value = 52,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索金币数量 +{Value1}%",
			Skill = {
				{
					Id = 102168,
					Value = 56,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320317,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320318,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561204,
		561355,
		561368,
		563106,
		563203,
		563704,
		563824,
		563305,
		563402,
		563503,
		563940,
		563928,
		564019,
		564049,
		564108,
		564143,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id149] =
{
	Id = 149,
	Name = "粉红海兔",
	Area = 
	{
		130214,
	},
	Rarity = 3,
	Element = 210002,
	Gallery = 950005,
	Desc = "粉红色的海兔，玩“叠罗汉”的时候，最喜欢在中间的位置。",
	LevelUp = 910003,
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Aplysia1",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Aplysia1",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectFire",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 130, Gain = 520},
		{Value = 200004, Base = 10, Gain = 2},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索中，每小时获得深海泡沫 {Value1Divide}个",
			Skill = {
				{
					Id = 102169,
					Value = 40,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索中，每小时获得深海泡沫 {Value1Divide}个",
			Skill = {
				{
					Id = 102169,
					Value = 60,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索中，每小时获得深海泡沫 {Value1Divide}个",
			Skill = {
				{
					Id = 102169,
					Value = 80,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索中，每小时获得深海泡沫 {Value1Divide}个",
			Skill = {
				{
					Id = 102169,
					Value = 100,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索中，每小时获得深海泡沫 {Value1Divide}个",
			Skill = {
				{
					Id = 102169,
					Value = 120,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索中，每小时获得深海泡沫 {Value1Divide}个",
			Skill = {
				{
					Id = 102169,
					Value = 140,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索中，每小时获得深海泡沫 {Value1Divide}个",
			Skill = {
				{
					Id = 102169,
					Value = 160,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索中，每小时获得深海泡沫 {Value1Divide}个",
			Skill = {
				{
					Id = 102169,
					Value = 180,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索中，每小时获得深海泡沫 {Value1Divide}个",
			Skill = {
				{
					Id = 102169,
					Value = 200,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索中，每小时获得深海泡沫 {Value1Divide}个",
			Skill = {
				{
					Id = 102169,
					Value = 220,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索中，每小时获得深海泡沫 {Value1Divide}个",
			Skill = {
				{
					Id = 102169,
					Value = 240,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索中，每小时获得深海泡沫 {Value1Divide}个",
			Skill = {
				{
					Id = 102169,
					Value = 260,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索中，每小时获得深海泡沫 {Value1Divide}个",
			Skill = {
				{
					Id = 102169,
					Value = 280,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320318,
			CatchChance = 30,
			CatchChanceGain = 5,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 25,
			SuccessChanceGain = 2,
			SuccessChanceMax = 100,
		},
		{
			Value = 320319,
			CatchChance = 50,
			CatchChanceGain = 10,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561203,
		561355,
		561368,
		563106,
		563203,
		563704,
		563824,
		563304,
		563402,
		563504,
		563909,
		563923,
		563902,
		564020,
		564023,
		564108,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id150] =
{
	Id = 150,
	Name = "蓝海兔",
	Area = 
	{
		130214,
	},
	Rarity = 4,
	Element = 210001,
	Gallery = 950005,
	Desc = "蓝色海兔，生命中只有吃饭、睡觉、叠兔兔。",
	LevelUp = 910004,
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "Sea",
	IconName = "SEA_Aplysia2",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Aplysia2",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWater",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 188, Gain = 752},
		{Value = 200004, Base = 15, Gain = 3},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "4回合后，每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102170,
					Value = 8,
				},
			},
		},
		{
			Stage = 2,
			Desc = "4回合后，每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102170,
					Value = 12,
				},
			},
		},
		{
			Stage = 3,
			Desc = "4回合后，每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102170,
					Value = 16,
				},
			},
		},
		{
			Stage = 4,
			Desc = "4回合后，每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102170,
					Value = 20,
				},
			},
		},
		{
			Stage = 5,
			Desc = "4回合后，每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102170,
					Value = 24,
				},
			},
		},
		{
			Stage = 6,
			Desc = "4回合后，每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102170,
					Value = 28,
				},
			},
		},
		{
			Stage = 7,
			Desc = "4回合后，每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102170,
					Value = 32,
				},
			},
		},
		{
			Stage = 8,
			Desc = "4回合后，每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102170,
					Value = 36,
				},
			},
		},
		{
			Stage = 9,
			Desc = "4回合后，每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102170,
					Value = 40,
				},
			},
		},
		{
			Stage = 10,
			Desc = "4回合后，每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102170,
					Value = 44,
				},
			},
		},
		{
			Stage = 11,
			Desc = "4回合后，每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102170,
					Value = 48,
				},
			},
		},
		{
			Stage = 12,
			Desc = "4回合后，每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102170,
					Value = 52,
				},
			},
		},
		{
			Stage = 13,
			Desc = "4回合后，每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102170,
					Value = 56,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320318,
			CatchChance = 5,
			CatchChanceGain = 12,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 5,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
		{
			Value = 320319,
			CatchChance = 33,
			CatchChanceGain = 25,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 33,
			SuccessChanceGain = 4,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560025,
		560045,
		560046,
		560032,
		560033,
		560034,
		560035,
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561202,
		561355,
		561368,
		563106,
		563203,
		563704,
		563824,
		563304,
		563402,
		563504,
		563934,
		563923,
		563912,
		564020,
		564059,
		564108,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id501] =
{
	Id = 501,
	Name = "木制宝箱怪",
	ActivityExplore = 
	{
		630002,
	},
	Rarity = 2,
	Element = 210003,
	Gallery = 950001,
	Desc = "活跃于野外地区的初级宝箱，通过其极具迷惑性的外表引诱冒险者靠近，然后“啊呜”一口吃掉。",
	LevelUp = 910202,
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_NormalChest",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_NormalChest",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 63, Gain = 252},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "光元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102135,
					Value = 6,
				},
			},
		},
		{
			Stage = 2,
			Desc = "光元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102135,
					Value = 9,
				},
			},
		},
		{
			Stage = 3,
			Desc = "光元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102135,
					Value = 12,
				},
			},
		},
		{
			Stage = 4,
			Desc = "光元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102135,
					Value = 15,
				},
			},
		},
		{
			Stage = 5,
			Desc = "光元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102135,
					Value = 18,
				},
			},
		},
		{
			Stage = 6,
			Desc = "光元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102135,
					Value = 21,
				},
			},
		},
		{
			Stage = 7,
			Desc = "光元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102135,
					Value = 24,
				},
			},
		},
		{
			Stage = 8,
			Desc = "光元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102135,
					Value = 27,
				},
			},
		},
		{
			Stage = 9,
			Desc = "光元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102135,
					Value = 30,
				},
			},
		},
		{
			Stage = 10,
			Desc = "光元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102135,
					Value = 33,
				},
			},
		},
		{
			Stage = 11,
			Desc = "光元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102135,
					Value = 36,
				},
			},
		},
		{
			Stage = 12,
			Desc = "光元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102135,
					Value = 39,
				},
			},
		},
		{
			Stage = 13,
			Desc = "光元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102135,
					Value = 42,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320317,
			CatchChance = 30,
			CatchChanceGain = 3,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320318,
			CatchChance = 50,
			CatchChanceGain = 7,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561204,
		561321,
		561348,
		563106,
		563203,
		563606,
		563814,
		563302,
		563402,
		563503,
		563925,
		563917,
		564040,
		564054,
		564160,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id502] =
{
	Id = 502,
	Name = "稀有宝箱怪",
	ActivityExplore = 
	{
		630002,
	},
	Rarity = 3,
	Element = 210005,
	Gallery = 950001,
	Desc = "活跃于危险地区的中级宝箱，金色的光芒会让老练的冒险者忘乎所以地靠近，在他打开宝箱的一刹那，就把对方吃掉。",
	LevelUp = 910203,
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_RareChest",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_RareChest",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectDark",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 105, Gain = 105},
		{Value = 200004, Base = 10, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102136,
					Value = 6,
				},
			},
		},
		{
			Stage = 2,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102136,
					Value = 9,
				},
			},
		},
		{
			Stage = 3,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102136,
					Value = 12,
				},
			},
		},
		{
			Stage = 4,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102136,
					Value = 15,
				},
			},
		},
		{
			Stage = 5,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102136,
					Value = 18,
				},
			},
		},
		{
			Stage = 6,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102136,
					Value = 21,
				},
			},
		},
		{
			Stage = 7,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102136,
					Value = 24,
				},
			},
		},
		{
			Stage = 8,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102136,
					Value = 27,
				},
			},
		},
		{
			Stage = 9,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102136,
					Value = 30,
				},
			},
		},
		{
			Stage = 10,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102136,
					Value = 33,
				},
			},
		},
		{
			Stage = 11,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102136,
					Value = 36,
				},
			},
		},
		{
			Stage = 12,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102136,
					Value = 39,
				},
			},
		},
		{
			Stage = 13,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102136,
					Value = 42,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320314,
			CatchChance = 30,
			CatchChanceGain = 10,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 25,
			SuccessChanceGain = 2,
			SuccessChanceMax = 100,
		},
		{
			Value = 320315,
			CatchChance = 50,
			CatchChanceGain = 20,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561206,
		561321,
		561348,
		563105,
		563203,
		563605,
		563814,
		563302,
		563402,
		563504,
		563925,
		563950,
		564040,
		564054,
		564160,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id503] =
{
	Id = 503,
	Name = "传奇宝箱怪",
	ActivityExplore = 
	{
		630002,
	},
	Rarity = 4,
	Element = 210004,
	Gallery = 950001,
	Desc = "深藏于顶级副本的史诗宝箱，再警惕的冒险者也无法抗拒他的璀璨光辉。而那些靠近的冒险者就再也回不来了。",
	LevelUp = 910204,
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_EpicChest",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_EpicChest",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectLight",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 157, Gain = 157},
		{Value = 200004, Base = 15, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "全队战力 +{Value1}%",
			Skill = {
				{
					Id = 102137,
					Value = 3,
				},
			},
		},
		{
			Stage = 2,
			Desc = "全队战力 +{Value1}%",
			Skill = {
				{
					Id = 102137,
					Value = 4,
				},
			},
		},
		{
			Stage = 3,
			Desc = "全队战力 +{Value1}%",
			Skill = {
				{
					Id = 102137,
					Value = 5,
				},
			},
		},
		{
			Stage = 4,
			Desc = "全队战力 +{Value1}%",
			Skill = {
				{
					Id = 102137,
					Value = 6,
				},
			},
		},
		{
			Stage = 5,
			Desc = "全队战力 +{Value1}%",
			Skill = {
				{
					Id = 102137,
					Value = 7,
				},
			},
		},
		{
			Stage = 6,
			Desc = "全队战力 +{Value1}%",
			Skill = {
				{
					Id = 102137,
					Value = 8,
				},
			},
		},
		{
			Stage = 7,
			Desc = "全队战力 +{Value1}%",
			Skill = {
				{
					Id = 102137,
					Value = 9,
				},
			},
		},
		{
			Stage = 8,
			Desc = "全队战力 +{Value1}%",
			Skill = {
				{
					Id = 102137,
					Value = 10,
				},
			},
		},
		{
			Stage = 9,
			Desc = "全队战力 +{Value1}%",
			Skill = {
				{
					Id = 102137,
					Value = 11,
				},
			},
		},
		{
			Stage = 10,
			Desc = "全队战力 +{Value1}%",
			Skill = {
				{
					Id = 102137,
					Value = 12,
				},
			},
		},
		{
			Stage = 11,
			Desc = "全队战力 +{Value1}%",
			Skill = {
				{
					Id = 102137,
					Value = 13,
				},
			},
		},
		{
			Stage = 12,
			Desc = "全队战力 +{Value1}%",
			Skill = {
				{
					Id = 102137,
					Value = 14,
				},
			},
		},
		{
			Stage = 13,
			Desc = "全队战力 +{Value1}%",
			Skill = {
				{
					Id = 102137,
					Value = 15,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320314,
			CatchChance = 5,
			CatchChanceGain = 12,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 5,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
		{
			Value = 320315,
			CatchChance = 33,
			CatchChanceGain = 25,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 33,
			SuccessChanceGain = 4,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560025,
		560045,
		560046,
		560032,
		560033,
		560034,
		560035,
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561205,
		561321,
		561348,
		563105,
		563203,
		563605,
		563814,
		563302,
		563402,
		563505,
		563925,
		563919,
		563948,
		564040,
		564054,
		564160,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id504] =
{
	Id = 504,
	Name = "橘大大",
	ActivityExplore = 
	{
		630001,
	},
	Rarity = 1,
	Element = 210002,
	Gallery = 950101,
	Desc = "“哟，这橘子上面还贴了个‘火’字，红橘贴火，红红火火，真是好寓意啊！”\n系统提示：您的好友“橘大大”已经退出了群聊。",
	LevelUp = 910101,
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_OrangeBig",
	PrefabBundle = "character_enemy",
	PrefabName = "All_OrangeBig",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectFire",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 42, Gain = 42},
		{Value = 200004, Base = 0, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102176,
					Value = 6,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102176,
					Value = 9,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102176,
					Value = 12,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102176,
					Value = 15,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102176,
					Value = 18,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102176,
					Value = 21,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102176,
					Value = 24,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102176,
					Value = 27,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102176,
					Value = 30,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102176,
					Value = 33,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102176,
					Value = 36,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102176,
					Value = 39,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102176,
					Value = 42,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320301,
			CatchChance = 50,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560022,
		560042,
		560043,
		560044,
		560045,
		560046,
		560032,
		560202,
		560203,
		560204,
		560205,
		560206,
		560207,
		560209,
		560110,
		560211,
		561203,
		561320,
		561331,
		563102,
		563204,
		563620,
		563803,
		563305,
		563403,
		563505,
		563925,
		563919,
		563938,
		564065,
		564038,
		564018,
		564129,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id505] =
{
	Id = 505,
	Name = "阿吉",
	ActivityExplore = 
	{
		630001,
	},
	Rarity = 1,
	Element = 210002,
	Gallery = 950101,
	Desc = "和橘大大是亲兄弟，本名“吉大大”，但因童年过得非常不开心遂而改名。\n原因么……橘大大小时候经常被人喊“小橘橘”。",
	LevelUp = 910101,
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_OrangeLucky",
	PrefabBundle = "character_enemy",
	PrefabName = "All_OrangeLucky",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectFire",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 42, Gain = 42},
		{Value = 200004, Base = 0, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102177,
					Value = 6,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102177,
					Value = 9,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102177,
					Value = 12,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102177,
					Value = 15,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102177,
					Value = 18,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102177,
					Value = 21,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102177,
					Value = 24,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102177,
					Value = 27,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102177,
					Value = 30,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102177,
					Value = 33,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102177,
					Value = 36,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102177,
					Value = 39,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102177,
					Value = 42,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320301,
			CatchChance = 50,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560022,
		560042,
		560043,
		560044,
		560045,
		560046,
		560032,
		560202,
		560203,
		560204,
		560205,
		560206,
		560207,
		560209,
		560110,
		560211,
		561203,
		561320,
		561331,
		563102,
		563204,
		563620,
		563803,
		563305,
		563403,
		563505,
		563925,
		563919,
		563938,
		564065,
		564038,
		564018,
		564129,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id506] =
{
	Id = 506,
	Name = "寒梅梅",
	ActivityExplore = 
	{
		630001,
	},
	Rarity = 2,
	Element = 210001,
	Gallery = 950101,
	Desc = "买楠木椅子寒梅梅，我只要楠木——据说去了趟蓝星回来后，无时无刻不在重复着这句话，大家都以为她疯了……",
	LevelUp = 910102,
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_PlumBlossom",
	PrefabBundle = "character_enemy",
	PrefabName = "All_PlumBlossom",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWater",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 63, Gain = 63},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "对火元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102178,
					Value = 50,
				},
			},
		},
		{
			Stage = 2,
			Desc = "对火元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102178,
					Value = 75,
				},
			},
		},
		{
			Stage = 3,
			Desc = "对火元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102178,
					Value = 100,
				},
			},
		},
		{
			Stage = 4,
			Desc = "对火元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102178,
					Value = 125,
				},
			},
		},
		{
			Stage = 5,
			Desc = "对火元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102178,
					Value = 150,
				},
			},
		},
		{
			Stage = 6,
			Desc = "对火元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102178,
					Value = 175,
				},
			},
		},
		{
			Stage = 7,
			Desc = "对火元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102178,
					Value = 200,
				},
			},
		},
		{
			Stage = 8,
			Desc = "对火元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102178,
					Value = 225,
				},
			},
		},
		{
			Stage = 9,
			Desc = "对火元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102178,
					Value = 250,
				},
			},
		},
		{
			Stage = 10,
			Desc = "对火元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102178,
					Value = 275,
				},
			},
		},
		{
			Stage = 11,
			Desc = "对火元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102178,
					Value = 300,
				},
			},
		},
		{
			Stage = 12,
			Desc = "对火元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102178,
					Value = 325,
				},
			},
		},
		{
			Stage = 13,
			Desc = "对火元素敌人伤害 +{Value1}%",
			Skill = {
				{
					Id = 102178,
					Value = 350,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320305,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320306,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560205,
		560206,
		560207,
		560209,
		560110,
		560211,
		561202,
		561305,
		561334,
		563103,
		563205,
		563620,
		563829,
		563305,
		563402,
		563503,
		563920,
		563924,
		564065,
		564018,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id507] =
{
	Id = 507,
	Name = "宏大锤",
	ActivityExplore = 
	{
		630001,
	},
	Rarity = 2,
	Element = 210004,
	Gallery = 950101,
	Desc = "据说还有个兄弟叫“宏小锤”，两人身手不错，经常被人雇作打手。两兄弟虽然不学无术，但明码标价，童叟无欺：大锤80，小锤40。",
	LevelUp = 910102,
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_Drumstick",
	PrefabBundle = "character_enemy",
	PrefabName = "All_Drumstick",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectLight",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 63, Gain = 63},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "全队攻击 +{Value1}%",
			Skill = {
				{
					Id = 102179,
					Value = 2,
				},
			},
		},
		{
			Stage = 2,
			Desc = "全队攻击 +{Value1}%",
			Skill = {
				{
					Id = 102179,
					Value = 3,
				},
			},
		},
		{
			Stage = 3,
			Desc = "全队攻击 +{Value1}%",
			Skill = {
				{
					Id = 102179,
					Value = 4,
				},
			},
		},
		{
			Stage = 4,
			Desc = "全队攻击 +{Value1}%",
			Skill = {
				{
					Id = 102179,
					Value = 5,
				},
			},
		},
		{
			Stage = 5,
			Desc = "全队攻击 +{Value1}%",
			Skill = {
				{
					Id = 102179,
					Value = 6,
				},
			},
		},
		{
			Stage = 6,
			Desc = "全队攻击 +{Value1}%",
			Skill = {
				{
					Id = 102179,
					Value = 7,
				},
			},
		},
		{
			Stage = 7,
			Desc = "全队攻击 +{Value1}%",
			Skill = {
				{
					Id = 102179,
					Value = 8,
				},
			},
		},
		{
			Stage = 8,
			Desc = "全队攻击 +{Value1}%",
			Skill = {
				{
					Id = 102179,
					Value = 9,
				},
			},
		},
		{
			Stage = 9,
			Desc = "全队攻击 +{Value1}%",
			Skill = {
				{
					Id = 102179,
					Value = 10,
				},
			},
		},
		{
			Stage = 10,
			Desc = "全队攻击 +{Value1}%",
			Skill = {
				{
					Id = 102179,
					Value = 11,
				},
			},
		},
		{
			Stage = 11,
			Desc = "全队攻击 +{Value1}%",
			Skill = {
				{
					Id = 102179,
					Value = 12,
				},
			},
		},
		{
			Stage = 12,
			Desc = "全队攻击 +{Value1}%",
			Skill = {
				{
					Id = 102179,
					Value = 13,
				},
			},
		},
		{
			Stage = 13,
			Desc = "全队攻击 +{Value1}%",
			Skill = {
				{
					Id = 102179,
					Value = 14,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320309,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320310,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560205,
		560206,
		560207,
		560209,
		560110,
		560211,
		561205,
		561321,
		561348,
		563104,
		563203,
		563619,
		563820,
		563303,
		563403,
		563503,
		563920,
		563924,
		564065,
		564029,
		564159,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id508] =
{
	Id = 508,
	Name = "气鼓鼓",
	ActivityExplore = 
	{
		630001,
	},
	Rarity = 3,
	Element = 210003,
	Gallery = 950101,
	Desc = "和宏大锤两兄弟是对头，一见面就打架。号称是：春风吹，战鼓擂，气鼓鼓，怕过谁！",
	LevelUp = 910103,
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_Drum",
	PrefabBundle = "character_enemy",
	PrefabName = "All_Drum",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 105, Gain = 105},
		{Value = 200004, Base = 10, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "每回合全队攻击 +{Value1}%，最多3次",
			Skill = {
				{
					Id = 102180,
					Value = 1,
				},
			},
		},
		{
			Stage = 2,
			Desc = "每回合全队攻击 +{Value1}%，最多3次",
			Skill = {
				{
					Id = 102180,
					Value = 2,
				},
			},
		},
		{
			Stage = 3,
			Desc = "每回合全队攻击 +{Value1}%，最多3次",
			Skill = {
				{
					Id = 102180,
					Value = 3,
				},
			},
		},
		{
			Stage = 4,
			Desc = "每回合全队攻击 +{Value1}%，最多3次",
			Skill = {
				{
					Id = 102180,
					Value = 4,
				},
			},
		},
		{
			Stage = 5,
			Desc = "每回合全队攻击 +{Value1}%，最多3次",
			Skill = {
				{
					Id = 102180,
					Value = 5,
				},
			},
		},
		{
			Stage = 6,
			Desc = "每回合全队攻击 +{Value1}%，最多3次",
			Skill = {
				{
					Id = 102180,
					Value = 6,
				},
			},
		},
		{
			Stage = 7,
			Desc = "每回合全队攻击 +{Value1}%，最多3次",
			Skill = {
				{
					Id = 102180,
					Value = 7,
				},
			},
		},
		{
			Stage = 8,
			Desc = "每回合全队攻击 +{Value1}%，最多3次",
			Skill = {
				{
					Id = 102180,
					Value = 8,
				},
			},
		},
		{
			Stage = 9,
			Desc = "每回合全队攻击 +{Value1}%，最多3次",
			Skill = {
				{
					Id = 102180,
					Value = 9,
				},
			},
		},
		{
			Stage = 10,
			Desc = "每回合全队攻击 +{Value1}%，最多3次",
			Skill = {
				{
					Id = 102180,
					Value = 10,
				},
			},
		},
		{
			Stage = 11,
			Desc = "每回合全队攻击 +{Value1}%，最多3次",
			Skill = {
				{
					Id = 102180,
					Value = 11,
				},
			},
		},
		{
			Stage = 12,
			Desc = "每回合全队攻击 +{Value1}%，最多3次",
			Skill = {
				{
					Id = 102180,
					Value = 12,
				},
			},
		},
		{
			Stage = 13,
			Desc = "每回合全队攻击 +{Value1}%，最多3次",
			Skill = {
				{
					Id = 102180,
					Value = 13,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320314,
			CatchChance = 30,
			CatchChanceGain = 5,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 25,
			SuccessChanceGain = 2,
			SuccessChanceMax = 100,
		},
		{
			Value = 320315,
			CatchChance = 50,
			CatchChanceGain = 10,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560203,
		560204,
		560205,
		560206,
		560207,
		560209,
		560110,
		560211,
		561204,
		561321,
		561348,
		563105,
		563202,
		563620,
		563805,
		563302,
		563403,
		563503,
		563920,
		563924,
		564065,
		564040,
		564159,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id509] =
{
	Id = 509,
	Name = "胡呆呆",
	ActivityExplore = 
	{
		630001,
	},
	Rarity = 3,
	Element = 210003,
	Gallery = 950101,
	Desc = "据说打败胡呆呆后有概率掉落福袋，而蓝星的人们最喜欢将福袋带在身上出门，能保一路平安。后来就形成了一个品牌：一袋一路。",
	LevelUp = 910103,
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_LuckyPocket",
	PrefabBundle = "character_enemy",
	PrefabName = "All_LuckyPocket",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 105, Gain = 105},
		{Value = 200004, Base = 10, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "全队受到暴击伤害 -{Value1}%",
			Skill = {
				{
					Id = 102181,
					Value = -3,
				},
			},
		},
		{
			Stage = 2,
			Desc = "全队受到暴击伤害 -{Value1}%",
			Skill = {
				{
					Id = 102181,
					Value = -4,
				},
			},
		},
		{
			Stage = 3,
			Desc = "全队受到暴击伤害 -{Value1}%",
			Skill = {
				{
					Id = 102181,
					Value = -5,
				},
			},
		},
		{
			Stage = 4,
			Desc = "全队受到暴击伤害 -{Value1}%",
			Skill = {
				{
					Id = 102181,
					Value = -6,
				},
			},
		},
		{
			Stage = 5,
			Desc = "全队受到暴击伤害 -{Value1}%",
			Skill = {
				{
					Id = 102181,
					Value = -7,
				},
			},
		},
		{
			Stage = 6,
			Desc = "全队受到暴击伤害 -{Value1}%",
			Skill = {
				{
					Id = 102181,
					Value = -8,
				},
			},
		},
		{
			Stage = 7,
			Desc = "全队受到暴击伤害 -{Value1}%",
			Skill = {
				{
					Id = 102181,
					Value = -9,
				},
			},
		},
		{
			Stage = 8,
			Desc = "全队受到暴击伤害 -{Value1}%",
			Skill = {
				{
					Id = 102181,
					Value = -10,
				},
			},
		},
		{
			Stage = 9,
			Desc = "全队受到暴击伤害 -{Value1}%",
			Skill = {
				{
					Id = 102181,
					Value = -11,
				},
			},
		},
		{
			Stage = 10,
			Desc = "全队受到暴击伤害 -{Value1}%",
			Skill = {
				{
					Id = 102181,
					Value = -12,
				},
			},
		},
		{
			Stage = 11,
			Desc = "全队受到暴击伤害 -{Value1}%",
			Skill = {
				{
					Id = 102181,
					Value = -13,
				},
			},
		},
		{
			Stage = 12,
			Desc = "全队受到暴击伤害 -{Value1}%",
			Skill = {
				{
					Id = 102181,
					Value = -14,
				},
			},
		},
		{
			Stage = 13,
			Desc = "全队受到暴击伤害 -{Value1}%",
			Skill = {
				{
					Id = 102181,
					Value = -15,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320318,
			CatchChance = 30,
			CatchChanceGain = 5,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 25,
			SuccessChanceGain = 2,
			SuccessChanceMax = 100,
		},
		{
			Value = 320319,
			CatchChance = 50,
			CatchChanceGain = 10,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560203,
		560204,
		560205,
		560206,
		560207,
		560209,
		560110,
		560211,
		561204,
		561344,
		561348,
		563106,
		563203,
		563620,
		563825,
		563304,
		563403,
		563503,
		563920,
		563924,
		564065,
		564005,
		564158,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id510] =
{
	Id = 510,
	Name = "粉色史莱姆",
	ActivityExplore = 
	{
		630002,
	},
	Rarity = 1,
	Element = 210001,
	Gallery = 950001,
	Desc = "史莱姆家族中的小妹，幼年女性成员，酷爱甜食。平时受到哥哥们的保护，很少去危险地区，主要在宝箱谷地区活动。",
	LevelUp = 910201,
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_Pink",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_Pink",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWater",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 42, Gain = 42},
		{Value = 200004, Base = 0, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "3回合后，全队每回合回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102182,
					Value = 4,
				},
			},
		},
		{
			Stage = 2,
			Desc = "3回合后，全队每回合回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102182,
					Value = 6,
				},
			},
		},
		{
			Stage = 3,
			Desc = "3回合后，全队每回合回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102182,
					Value = 8,
				},
			},
		},
		{
			Stage = 4,
			Desc = "3回合后，全队每回合回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102182,
					Value = 10,
				},
			},
		},
		{
			Stage = 5,
			Desc = "3回合后，全队每回合回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102182,
					Value = 12,
				},
			},
		},
		{
			Stage = 6,
			Desc = "3回合后，全队每回合回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102182,
					Value = 14,
				},
			},
		},
		{
			Stage = 7,
			Desc = "3回合后，全队每回合回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102182,
					Value = 16,
				},
			},
		},
		{
			Stage = 8,
			Desc = "3回合后，全队每回合回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102182,
					Value = 18,
				},
			},
		},
		{
			Stage = 9,
			Desc = "3回合后，全队每回合回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102182,
					Value = 20,
				},
			},
		},
		{
			Stage = 10,
			Desc = "3回合后，全队每回合回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102182,
					Value = 22,
				},
			},
		},
		{
			Stage = 11,
			Desc = "3回合后，全队每回合回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102182,
					Value = 24,
				},
			},
		},
		{
			Stage = 12,
			Desc = "3回合后，全队每回合回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102182,
					Value = 26,
				},
			},
		},
		{
			Stage = 13,
			Desc = "3回合后，全队每回合回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102182,
					Value = 28,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320301,
			CatchChance = 50,
			CatchChanceGain = 3,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560022,
		560042,
		560043,
		560044,
		560045,
		560046,
		560032,
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561202,
		561305,
		561323,
		561703,
		563102,
		563203,
		563619,
		563709,
		563805,
		563306,
		563403,
		563502,
		563911,
		564021,
		564013,
		564135,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id511] =
{
	Id = 511,
	Name = "金色史莱姆",
	ActivityExplore = 
	{
		630002,
	},
	Rarity = 3,
	Element = 210004,
	Gallery = 950001,
	Desc = "史莱姆一族中的稀有品种，对自我的定位是「金英怪」或「黄金史莱姆」。一旦听到有人喊它「黄色史莱姆」，就会陷入无法抑制的狂暴状态。",
	LevelUp = 910203,
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Slime_Gold",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Slime_Gold",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectLight",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 105, Gain = 105},
		{Value = 200004, Base = 10, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102183,
					Value = 10,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102183,
					Value = 15,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102183,
					Value = 20,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102183,
					Value = 25,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102183,
					Value = 30,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102183,
					Value = 35,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102183,
					Value = 40,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102183,
					Value = 45,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102183,
					Value = 50,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102183,
					Value = 55,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102183,
					Value = 60,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102183,
					Value = 65,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102183,
					Value = 70,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320302,
			CatchChance = 30,
			CatchChanceGain = 10,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 25,
			SuccessChanceGain = 2,
			SuccessChanceMax = 100,
		},
		{
			Value = 320303,
			CatchChance = 50,
			CatchChanceGain = 20,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561205,
		561305,
		561323,
		563102,
		563203,
		563620,
		563708,
		563805,
		563305,
		563403,
		563502,
		563955,
		564020,
		564013,
		564143,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id512] =
{
	Id = 512,
	Name = "麻醉花椒",
	ActivityExplore = 
	{
		630003,
	},
	Rarity = 1,
	Element = 210003,
	Gallery = 950002,
	Desc = "花椒中的稀有品种，凡是接触到它的人，都会出现短暂的麻痹现象。",
	LevelUp = 910201,
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_SichuanPepper",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_SichuanPepper",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 42, Gain = 42},
		{Value = 200004, Base = 0, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "风元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102184,
					Value = 4,
				},
			},
		},
		{
			Stage = 2,
			Desc = "风元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102184,
					Value = 6,
				},
			},
		},
		{
			Stage = 3,
			Desc = "风元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102184,
					Value = 8,
				},
			},
		},
		{
			Stage = 4,
			Desc = "风元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102184,
					Value = 10,
				},
			},
		},
		{
			Stage = 5,
			Desc = "风元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102184,
					Value = 12,
				},
			},
		},
		{
			Stage = 6,
			Desc = "风元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102184,
					Value = 14,
				},
			},
		},
		{
			Stage = 7,
			Desc = "风元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102184,
					Value = 16,
				},
			},
		},
		{
			Stage = 8,
			Desc = "风元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102184,
					Value = 18,
				},
			},
		},
		{
			Stage = 9,
			Desc = "风元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102184,
					Value = 20,
				},
			},
		},
		{
			Stage = 10,
			Desc = "风元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102184,
					Value = 22,
				},
			},
		},
		{
			Stage = 11,
			Desc = "风元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102184,
					Value = 24,
				},
			},
		},
		{
			Stage = 12,
			Desc = "风元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102184,
					Value = 26,
				},
			},
		},
		{
			Stage = 13,
			Desc = "风元素队员暴击 +{Value1}",
			Skill = {
				{
					Id = 102184,
					Value = 28,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320301,
			CatchChance = 50,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560022,
		560042,
		560043,
		560044,
		560045,
		560046,
		560032,
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561204,
		561306,
		563102,
		563204,
		563621,
		563808,
		563305,
		563403,
		563503,
		563939,
		563913,
		564003,
		564033,
		564171,
		564164,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id513] =
{
	Id = 513,
	Name = "臭小白",
	ActivityExplore = 
	{
		630003,
	},
	Rarity = 2,
	Element = 210004,
	Gallery = 950002,
	Desc = "软软的白色豆腐，梦想是可以移民美食星，就算被拒绝了近100次，也仍然没有放弃。",
	LevelUp = 910202,
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_StinkyTofuWhite",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_StinkyTofuWhite",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectLight",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 63, Gain = 63},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "光元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102185,
					Value = 6,
				},
			},
		},
		{
			Stage = 2,
			Desc = "光元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102185,
					Value = 9,
				},
			},
		},
		{
			Stage = 3,
			Desc = "光元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102185,
					Value = 12,
				},
			},
		},
		{
			Stage = 4,
			Desc = "光元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102185,
					Value = 15,
				},
			},
		},
		{
			Stage = 5,
			Desc = "光元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102185,
					Value = 18,
				},
			},
		},
		{
			Stage = 6,
			Desc = "光元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102185,
					Value = 21,
				},
			},
		},
		{
			Stage = 7,
			Desc = "光元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102185,
					Value = 24,
				},
			},
		},
		{
			Stage = 8,
			Desc = "光元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102185,
					Value = 27,
				},
			},
		},
		{
			Stage = 9,
			Desc = "光元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102185,
					Value = 30,
				},
			},
		},
		{
			Stage = 10,
			Desc = "光元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102185,
					Value = 33,
				},
			},
		},
		{
			Stage = 11,
			Desc = "光元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102185,
					Value = 36,
				},
			},
		},
		{
			Stage = 12,
			Desc = "光元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102185,
					Value = 39,
				},
			},
		},
		{
			Stage = 13,
			Desc = "光元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102185,
					Value = 42,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320309,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320310,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561205,
		561306,
		561332,
		563104,
		563203,
		563605,
		563708,
		563829,
		563305,
		563406,
		563504,
		563925,
		563917,
		563937,
		564004,
		564033,
		564106,
		564140,
		564205,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id514] =
{
	Id = 514,
	Name = "臭小黑",
	ActivityExplore = 
	{
		630003,
	},
	Rarity = 2,
	Element = 210005,
	Gallery = 950002,
	Desc = "软软的黑色豆腐，梦想是可以移民美食星，对于美食星近100次的拒绝，表示非常气愤，并多次联系星球媒体寻求帮助。",
	LevelUp = 910202,
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_StinkyTofuBlack",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_StinkyTofuBlack",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectDark",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 63, Gain = 63},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "暗元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102186,
					Value = 6,
				},
			},
		},
		{
			Stage = 2,
			Desc = "暗元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102186,
					Value = 9,
				},
			},
		},
		{
			Stage = 3,
			Desc = "暗元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102186,
					Value = 12,
				},
			},
		},
		{
			Stage = 4,
			Desc = "暗元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102186,
					Value = 15,
				},
			},
		},
		{
			Stage = 5,
			Desc = "暗元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102186,
					Value = 18,
				},
			},
		},
		{
			Stage = 6,
			Desc = "暗元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102186,
					Value = 21,
				},
			},
		},
		{
			Stage = 7,
			Desc = "暗元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102186,
					Value = 24,
				},
			},
		},
		{
			Stage = 8,
			Desc = "暗元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102186,
					Value = 27,
				},
			},
		},
		{
			Stage = 9,
			Desc = "暗元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102186,
					Value = 30,
				},
			},
		},
		{
			Stage = 10,
			Desc = "暗元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102186,
					Value = 33,
				},
			},
		},
		{
			Stage = 11,
			Desc = "暗元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102186,
					Value = 36,
				},
			},
		},
		{
			Stage = 12,
			Desc = "暗元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102186,
					Value = 39,
				},
			},
		},
		{
			Stage = 13,
			Desc = "暗元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102186,
					Value = 42,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320309,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320310,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561206,
		561306,
		561332,
		563104,
		563203,
		563605,
		563708,
		563829,
		563305,
		563406,
		563504,
		563916,
		563917,
		563937,
		564004,
		564033,
		564106,
		564140,
		564205,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id515] =
{
	Id = 515,
	Name = "仰望星空",
	ActivityExplore = 
	{
		630003,
	},
	Rarity = 3,
	Element = 210001,
	Gallery = 950002,
	Desc = "脑袋上有三只望向天空的鱼，因此拥有了一个诗意的名字，然而见到它的人，时常被鱼的模样吓跑，这不禁让它非常苦恼。",
	LevelUp = 910203,
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_BreadFish",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_BreadFish",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWater",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 105, Gain = 105},
		{Value = 200004, Base = 10, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "水元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102187,
					Value = 4,
				},
			},
		},
		{
			Stage = 2,
			Desc = "水元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102187,
					Value = 6,
				},
			},
		},
		{
			Stage = 3,
			Desc = "水元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102187,
					Value = 8,
				},
			},
		},
		{
			Stage = 4,
			Desc = "水元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102187,
					Value = 10,
				},
			},
		},
		{
			Stage = 5,
			Desc = "水元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102187,
					Value = 12,
				},
			},
		},
		{
			Stage = 6,
			Desc = "水元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102187,
					Value = 14,
				},
			},
		},
		{
			Stage = 7,
			Desc = "水元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102187,
					Value = 16,
				},
			},
		},
		{
			Stage = 8,
			Desc = "水元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102187,
					Value = 18,
				},
			},
		},
		{
			Stage = 9,
			Desc = "水元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102187,
					Value = 20,
				},
			},
		},
		{
			Stage = 10,
			Desc = "水元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102187,
					Value = 22,
				},
			},
		},
		{
			Stage = 11,
			Desc = "水元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102187,
					Value = 24,
				},
			},
		},
		{
			Stage = 12,
			Desc = "水元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102187,
					Value = 26,
				},
			},
		},
		{
			Stage = 13,
			Desc = "水元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102187,
					Value = 28,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320306,
			CatchChance = 30,
			CatchChanceGain = 90,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 25,
			SuccessChanceGain = 2,
			SuccessChanceMax = 100,
		},
		{
			Value = 320307,
			CatchChance = 50,
			CatchChanceGain = 180,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561202,
		561306,
		561332,
		563103,
		563203,
		563619,
		563709,
		563810,
		563304,
		563405,
		563504,
		563933,
		563929,
		563924,
		564025,
		564038,
		564104,
		564138,
		564204,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id516] =
{
	Id = 516,
	Name = "钢化大列巴",
	ActivityExplore = 
	{
		630003,
	},
	Rarity = 4,
	Element = 210002,
	Gallery = 950002,
	Desc = "乍看之下非常可爱的小面包，然而拥有钢铁一般坚硬的躯壳，让那些想要拥抱它的人都望而却步。",
	LevelUp = 910204,
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_GreatLeba",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_GreatLeba",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectFire",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 157, Gain = 157},
		{Value = 200004, Base = 15, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102188,
					Value = 4,
				},
			},
		},
		{
			Stage = 2,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102188,
					Value = 6,
				},
			},
		},
		{
			Stage = 3,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102188,
					Value = 8,
				},
			},
		},
		{
			Stage = 4,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102188,
					Value = 10,
				},
			},
		},
		{
			Stage = 5,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102188,
					Value = 12,
				},
			},
		},
		{
			Stage = 6,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102188,
					Value = 14,
				},
			},
		},
		{
			Stage = 7,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102188,
					Value = 16,
				},
			},
		},
		{
			Stage = 8,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102188,
					Value = 18,
				},
			},
		},
		{
			Stage = 9,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102188,
					Value = 20,
				},
			},
		},
		{
			Stage = 10,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102188,
					Value = 22,
				},
			},
		},
		{
			Stage = 11,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102188,
					Value = 24,
				},
			},
		},
		{
			Stage = 12,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102188,
					Value = 26,
				},
			},
		},
		{
			Stage = 13,
			Desc = "全队生命 +{Value1}%",
			Skill = {
				{
					Id = 102188,
					Value = 28,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320314,
			CatchChance = 5,
			CatchChanceGain = 48,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 5,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
		{
			Value = 320315,
			CatchChance = 33,
			CatchChanceGain = 100,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 33,
			SuccessChanceGain = 4,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560025,
		560045,
		560046,
		560032,
		560033,
		560034,
		560035,
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561203,
		561306,
		561332,
		563105,
		563203,
		563620,
		563816,
		563302,
		563403,
		563502,
		563929,
		564030,
		564204,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id517] =
{
	Id = 517,
	Name = "绿豆正方糕",
	ActivityExplore = 
	{
		630004,
	},
	Rarity = 1,
	Element = 210003,
	Gallery = 950101,
	Desc = "软软糯糯的绿豆糕，非常脆弱，只要碰到其他物品，身体就会散架。",
	LevelUp = 910201,
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_LvDouGao",
	PrefabBundle = "character_enemy",
	PrefabName = "All_LvDouGao",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 42, Gain = 42},
		{Value = 200004, Base = 0, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "每回合风元素队员攻击 +{Value1}%，最多5次",
			Skill = {
				{
					Id = 102189,
					Value = 2,
				},
			},
		},
		{
			Stage = 2,
			Desc = "每回合风元素队员攻击 +{Value1}%，最多5次",
			Skill = {
				{
					Id = 102189,
					Value = 3,
				},
			},
		},
		{
			Stage = 3,
			Desc = "每回合风元素队员攻击 +{Value1}%，最多5次",
			Skill = {
				{
					Id = 102189,
					Value = 4,
				},
			},
		},
		{
			Stage = 4,
			Desc = "每回合风元素队员攻击 +{Value1}%，最多5次",
			Skill = {
				{
					Id = 102189,
					Value = 5,
				},
			},
		},
		{
			Stage = 5,
			Desc = "每回合风元素队员攻击 +{Value1}%，最多5次",
			Skill = {
				{
					Id = 102189,
					Value = 6,
				},
			},
		},
		{
			Stage = 6,
			Desc = "每回合风元素队员攻击 +{Value1}%，最多5次",
			Skill = {
				{
					Id = 102189,
					Value = 7,
				},
			},
		},
		{
			Stage = 7,
			Desc = "每回合风元素队员攻击 +{Value1}%，最多5次",
			Skill = {
				{
					Id = 102189,
					Value = 8,
				},
			},
		},
		{
			Stage = 8,
			Desc = "每回合风元素队员攻击 +{Value1}%，最多5次",
			Skill = {
				{
					Id = 102189,
					Value = 9,
				},
			},
		},
		{
			Stage = 9,
			Desc = "每回合风元素队员攻击 +{Value1}%，最多5次",
			Skill = {
				{
					Id = 102189,
					Value = 10,
				},
			},
		},
		{
			Stage = 10,
			Desc = "每回合风元素队员攻击 +{Value1}%，最多5次",
			Skill = {
				{
					Id = 102189,
					Value = 11,
				},
			},
		},
		{
			Stage = 11,
			Desc = "每回合风元素队员攻击 +{Value1}%，最多5次",
			Skill = {
				{
					Id = 102189,
					Value = 12,
				},
			},
		},
		{
			Stage = 12,
			Desc = "每回合风元素队员攻击 +{Value1}%，最多5次",
			Skill = {
				{
					Id = 102189,
					Value = 13,
				},
			},
		},
		{
			Stage = 13,
			Desc = "每回合风元素队员攻击 +{Value1}%，最多5次",
			Skill = {
				{
					Id = 102189,
					Value = 14,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320301,
			CatchChance = 50,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560022,
		560042,
		560043,
		560044,
		560045,
		560046,
		560032,
		560202,
		560203,
		560204,
		560205,
		560206,
		560207,
		560209,
		560110,
		560211,
		561204,
		561306,
		563102,
		563204,
		563605,
		563824,
		563305,
		563403,
		563502,
		563940,
		564003,
		564135,
		564205,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id518] =
{
	Id = 518,
	Name = "顶个枣粽",
	ActivityExplore = 
	{
		630004,
	},
	Rarity = 2,
	Element = 210004,
	Gallery = 950101,
	Desc = "粽子家族的成员，体型呈现出三角形的模样，为了防止裤子掉下来，总是勒紧裤腰带行事。",
	LevelUp = 910202,
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_TianZongZi",
	PrefabBundle = "character_enemy",
	PrefabName = "All_TianZongZi",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectLight",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 63, Gain = 63},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "每2回合，光元素队员回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102190,
					Value = 5,
				},
			},
		},
		{
			Stage = 2,
			Desc = "每2回合，光元素队员回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102190,
					Value = 7,
				},
			},
		},
		{
			Stage = 3,
			Desc = "每2回合，光元素队员回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102190,
					Value = 9,
				},
			},
		},
		{
			Stage = 4,
			Desc = "每2回合，光元素队员回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102190,
					Value = 11,
				},
			},
		},
		{
			Stage = 5,
			Desc = "每2回合，光元素队员回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102190,
					Value = 13,
				},
			},
		},
		{
			Stage = 6,
			Desc = "每2回合，光元素队员回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102190,
					Value = 15,
				},
			},
		},
		{
			Stage = 7,
			Desc = "每2回合，光元素队员回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102190,
					Value = 17,
				},
			},
		},
		{
			Stage = 8,
			Desc = "每2回合，光元素队员回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102190,
					Value = 19,
				},
			},
		},
		{
			Stage = 9,
			Desc = "每2回合，光元素队员回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102190,
					Value = 21,
				},
			},
		},
		{
			Stage = 10,
			Desc = "每2回合，光元素队员回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102190,
					Value = 23,
				},
			},
		},
		{
			Stage = 11,
			Desc = "每2回合，光元素队员回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102190,
					Value = 25,
				},
			},
		},
		{
			Stage = 12,
			Desc = "每2回合，光元素队员回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102190,
					Value = 27,
				},
			},
		},
		{
			Stage = 13,
			Desc = "每2回合，光元素队员回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102190,
					Value = 29,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320309,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320310,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560205,
		560206,
		560207,
		560209,
		560110,
		560211,
		561205,
		561306,
		561332,
		563104,
		563203,
		563604,
		563708,
		563819,
		563304,
		563404,
		563504,
		563939,
		563903,
		563917,
		564004,
		564018,
		564134,
		564144,
		564205,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id519] =
{
	Id = 519,
	Name = "蛋皇粽",
	ActivityExplore = 
	{
		630004,
	},
	Rarity = 2,
	Element = 210005,
	Gallery = 950101,
	Desc = "粽子家族的成员，自诩为有内涵的食物，并自称是美食星编外人员。",
	LevelUp = 910202,
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_DanHuangZongZi",
	PrefabBundle = "character_enemy",
	PrefabName = "All_DanHuangZongZi",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectDark",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 63, Gain = 63},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "每2回合，暗元素队员回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102191,
					Value = 5,
				},
			},
		},
		{
			Stage = 2,
			Desc = "每2回合，暗元素队员回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102191,
					Value = 7,
				},
			},
		},
		{
			Stage = 3,
			Desc = "每2回合，暗元素队员回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102191,
					Value = 9,
				},
			},
		},
		{
			Stage = 4,
			Desc = "每2回合，暗元素队员回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102191,
					Value = 11,
				},
			},
		},
		{
			Stage = 5,
			Desc = "每2回合，暗元素队员回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102191,
					Value = 13,
				},
			},
		},
		{
			Stage = 6,
			Desc = "每2回合，暗元素队员回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102191,
					Value = 15,
				},
			},
		},
		{
			Stage = 7,
			Desc = "每2回合，暗元素队员回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102191,
					Value = 17,
				},
			},
		},
		{
			Stage = 8,
			Desc = "每2回合，暗元素队员回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102191,
					Value = 19,
				},
			},
		},
		{
			Stage = 9,
			Desc = "每2回合，暗元素队员回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102191,
					Value = 21,
				},
			},
		},
		{
			Stage = 10,
			Desc = "每2回合，暗元素队员回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102191,
					Value = 23,
				},
			},
		},
		{
			Stage = 11,
			Desc = "每2回合，暗元素队员回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102191,
					Value = 25,
				},
			},
		},
		{
			Stage = 12,
			Desc = "每2回合，暗元素队员回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102191,
					Value = 27,
				},
			},
		},
		{
			Stage = 13,
			Desc = "每2回合，暗元素队员回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102191,
					Value = 29,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320309,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320310,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560205,
		560206,
		560207,
		560209,
		560110,
		560211,
		561206,
		561306,
		561332,
		563104,
		563203,
		563604,
		563708,
		563819,
		563304,
		563406,
		563504,
		563939,
		563903,
		563922,
		564004,
		564023,
		564139,
		564144,
		564205,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id520] =
{
	Id = 520,
	Name = "熊老九",
	ActivityExplore = 
	{
		630004,
	},
	Rarity = 3,
	Element = 210001,
	Gallery = 950101,
	Desc = "粽子家族的好友，据说只要掀开他的帽子，就能体会到他自己所谓的“内在美”。",
	LevelUp = 910203,
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_XiongHuangJiu",
	PrefabBundle = "character_enemy",
	PrefabName = "All_XiongHuangJiu",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWater",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 105, Gain = 105},
		{Value = 200004, Base = 10, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "敌人等级 -{Value1}",
			Skill = {
				{
					Id = 102192,
					Value = -6,
				},
			},
		},
		{
			Stage = 2,
			Desc = "敌人等级 -{Value1}",
			Skill = {
				{
					Id = 102192,
					Value = -9,
				},
			},
		},
		{
			Stage = 3,
			Desc = "敌人等级 -{Value1}",
			Skill = {
				{
					Id = 102192,
					Value = -12,
				},
			},
		},
		{
			Stage = 4,
			Desc = "敌人等级 -{Value1}",
			Skill = {
				{
					Id = 102192,
					Value = -15,
				},
			},
		},
		{
			Stage = 5,
			Desc = "敌人等级 -{Value1}",
			Skill = {
				{
					Id = 102192,
					Value = -18,
				},
			},
		},
		{
			Stage = 6,
			Desc = "敌人等级 -{Value1}",
			Skill = {
				{
					Id = 102192,
					Value = -21,
				},
			},
		},
		{
			Stage = 7,
			Desc = "敌人等级 -{Value1}",
			Skill = {
				{
					Id = 102192,
					Value = -24,
				},
			},
		},
		{
			Stage = 8,
			Desc = "敌人等级 -{Value1}",
			Skill = {
				{
					Id = 102192,
					Value = -27,
				},
			},
		},
		{
			Stage = 9,
			Desc = "敌人等级 -{Value1}",
			Skill = {
				{
					Id = 102192,
					Value = -30,
				},
			},
		},
		{
			Stage = 10,
			Desc = "敌人等级 -{Value1}",
			Skill = {
				{
					Id = 102192,
					Value = -33,
				},
			},
		},
		{
			Stage = 11,
			Desc = "敌人等级 -{Value1}",
			Skill = {
				{
					Id = 102192,
					Value = -36,
				},
			},
		},
		{
			Stage = 12,
			Desc = "敌人等级 -{Value1}",
			Skill = {
				{
					Id = 102192,
					Value = -39,
				},
			},
		},
		{
			Stage = 13,
			Desc = "敌人等级 -{Value1}",
			Skill = {
				{
					Id = 102192,
					Value = -42,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320306,
			CatchChance = 30,
			CatchChanceGain = 90,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 25,
			SuccessChanceGain = 2,
			SuccessChanceMax = 100,
		},
		{
			Value = 320307,
			CatchChance = 50,
			CatchChanceGain = 180,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560203,
		560204,
		560205,
		560206,
		560207,
		560209,
		560110,
		560211,
		561202,
		561306,
		563103,
		563203,
		563619,
		563302,
		563404,
		563504,
		563913,
		563920,
		563922,
		564029,
		564033,
		564139,
		564204,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id521] =
{
	Id = 521,
	Name = "纸飞飞",
	ActivityExplore = 
	{
		630004,
	},
	Rarity = 4,
	Element = 210003,
	Gallery = 950101,
	Desc = "模样酷似大雁的风筝，坚定不移地相信着，迟早有一天，自己可以凭借一双翅膀在天空中自由飞翔。",
	LevelUp = 910204,
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_FengZheng",
	PrefabBundle = "character_enemy",
	PrefabName = "All_FengZheng",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 157, Gain = 157},
		{Value = 200004, Base = 15, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "全队{Value1}%概率无视敌人闪避",
			Skill = {
				{
					Id = 102193,
					Value = 3,
				},
			},
		},
		{
			Stage = 2,
			Desc = "全队{Value1}%概率无视敌人闪避",
			Skill = {
				{
					Id = 102193,
					Value = 4,
				},
			},
		},
		{
			Stage = 3,
			Desc = "全队{Value1}%概率无视敌人闪避",
			Skill = {
				{
					Id = 102193,
					Value = 5,
				},
			},
		},
		{
			Stage = 4,
			Desc = "全队{Value1}%概率无视敌人闪避",
			Skill = {
				{
					Id = 102193,
					Value = 6,
				},
			},
		},
		{
			Stage = 5,
			Desc = "全队{Value1}%概率无视敌人闪避",
			Skill = {
				{
					Id = 102193,
					Value = 7,
				},
			},
		},
		{
			Stage = 6,
			Desc = "全队{Value1}%概率无视敌人闪避",
			Skill = {
				{
					Id = 102193,
					Value = 8,
				},
			},
		},
		{
			Stage = 7,
			Desc = "全队{Value1}%概率无视敌人闪避",
			Skill = {
				{
					Id = 102193,
					Value = 9,
				},
			},
		},
		{
			Stage = 8,
			Desc = "全队{Value1}%概率无视敌人闪避",
			Skill = {
				{
					Id = 102193,
					Value = 10,
				},
			},
		},
		{
			Stage = 9,
			Desc = "全队{Value1}%概率无视敌人闪避",
			Skill = {
				{
					Id = 102193,
					Value = 11,
				},
			},
		},
		{
			Stage = 10,
			Desc = "全队{Value1}%概率无视敌人闪避",
			Skill = {
				{
					Id = 102193,
					Value = 12,
				},
			},
		},
		{
			Stage = 11,
			Desc = "全队{Value1}%概率无视敌人闪避",
			Skill = {
				{
					Id = 102193,
					Value = 13,
				},
			},
		},
		{
			Stage = 12,
			Desc = "全队{Value1}%概率无视敌人闪避",
			Skill = {
				{
					Id = 102193,
					Value = 14,
				},
			},
		},
		{
			Stage = 13,
			Desc = "全队{Value1}%概率无视敌人闪避",
			Skill = {
				{
					Id = 102193,
					Value = 15,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320318,
			CatchChance = 5,
			CatchChanceGain = 48,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 5,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
		{
			Value = 320319,
			CatchChance = 33,
			CatchChanceGain = 100,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 33,
			SuccessChanceGain = 4,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560025,
		560045,
		560046,
		560032,
		560033,
		560034,
		560035,
		560202,
		560203,
		560204,
		560205,
		560206,
		560207,
		560209,
		560110,
		560211,
		561204,
		561321,
		561343,
		563106,
		563206,
		563605,
		563829,
		563304,
		563403,
		563504,
		563934,
		563904,
		563918,
		564029,
		564008,
		564158,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id522] =
{
	Id = 522,
	Name = "皮卡皮卡",
	ActivityExplore = 
	{
		630005,
	},
	Rarity = 1,
	Element = 210001,
	Gallery = 950101,
	Desc = "七织的好朋友，从遥远的星球飞来流亡街寻找她，躲弹弓是必备技能。",
	LevelUp = 910201,
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_PiKaPiKa",
	PrefabBundle = "character_enemy",
	PrefabName = "All_PiKaPiKa",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWater",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 42, Gain = 42},
		{Value = 200004, Base = 0, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102194,
					Value = 6,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102194,
					Value = 9,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102194,
					Value = 12,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102194,
					Value = 15,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102194,
					Value = 18,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102194,
					Value = 21,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102194,
					Value = 24,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102194,
					Value = 27,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102194,
					Value = 30,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102194,
					Value = 33,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102194,
					Value = 36,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102194,
					Value = 39,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索获得的金币 +{Value1}%",
			Skill = {
				{
					Id = 102194,
					Value = 42,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320301,
			CatchChance = 50,
			CatchChanceGain = 0,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560022,
		560042,
		560043,
		560044,
		560045,
		560046,
		560032,
		560202,
		560203,
		560204,
		560205,
		560206,
		560207,
		560209,
		560110,
		560211,
		561202,
		561303,
		563102,
		563206,
		563704,
		563824,
		563303,
		563405,
		563505,
		563934,
		563904,
		563914,
		564040,
		564154,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id523] =
{
	Id = 523,
	Name = "布茎云",
	ActivityExplore = 
	{
		630005,
	},
	Rarity = 2,
	Element = 210003,
	Gallery = 950101,
	Desc = "手感极好的布，亲近人类，但被人类强行拿捏时，头发会变成乱糟糟的爆炸头，脾气也会暴躁起来。",
	LevelUp = 910202,
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_BuJingYun",
	PrefabBundle = "character_enemy",
	PrefabName = "All_BuJingYun",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 63, Gain = 63},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "风元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102195,
					Value = 6,
				},
			},
		},
		{
			Stage = 2,
			Desc = "风元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102195,
					Value = 9,
				},
			},
		},
		{
			Stage = 3,
			Desc = "风元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102195,
					Value = 12,
				},
			},
		},
		{
			Stage = 4,
			Desc = "风元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102195,
					Value = 15,
				},
			},
		},
		{
			Stage = 5,
			Desc = "风元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102195,
					Value = 18,
				},
			},
		},
		{
			Stage = 6,
			Desc = "风元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102195,
					Value = 21,
				},
			},
		},
		{
			Stage = 7,
			Desc = "风元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102195,
					Value = 24,
				},
			},
		},
		{
			Stage = 8,
			Desc = "风元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102195,
					Value = 27,
				},
			},
		},
		{
			Stage = 9,
			Desc = "风元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102195,
					Value = 30,
				},
			},
		},
		{
			Stage = 10,
			Desc = "风元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102195,
					Value = 33,
				},
			},
		},
		{
			Stage = 11,
			Desc = "风元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102195,
					Value = 36,
				},
			},
		},
		{
			Stage = 12,
			Desc = "风元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102195,
					Value = 39,
				},
			},
		},
		{
			Stage = 13,
			Desc = "风元素队员忍耐 +{Value1}",
			Skill = {
				{
					Id = 102195,
					Value = 42,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320301,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320302,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560205,
		560206,
		560207,
		560209,
		560110,
		560211,
		561204,
		561344,
		563102,
		563203,
		563625,
		563805,
		563306,
		563403,
		563504,
		563934,
		563904,
		563918,
		564019,
		564008,
		564158,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id524] =
{
	Id = 524,
	Name = "七夕果子",
	ActivityExplore = 
	{
		630005,
	},
	Rarity = 2,
	Element = 210004,
	Gallery = 950101,
	Desc = "甜甜的果子，曾在某年七夕节中，为了哄抬果价，自称是不老仙药，后来被有关部门以“虚假宣传”为罪名流放。",
	LevelUp = 910202,
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_QiXiGuoZi",
	PrefabBundle = "character_enemy",
	PrefabName = "All_QiXiGuoZi",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectLight",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 63, Gain = 63},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "每2回合，全队回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102196,
					Value = 5,
				},
			},
		},
		{
			Stage = 2,
			Desc = "每2回合，全队回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102196,
					Value = 7,
				},
			},
		},
		{
			Stage = 3,
			Desc = "每2回合，全队回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102196,
					Value = 9,
				},
			},
		},
		{
			Stage = 4,
			Desc = "每2回合，全队回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102196,
					Value = 11,
				},
			},
		},
		{
			Stage = 5,
			Desc = "每2回合，全队回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102196,
					Value = 13,
				},
			},
		},
		{
			Stage = 6,
			Desc = "每2回合，全队回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102196,
					Value = 15,
				},
			},
		},
		{
			Stage = 7,
			Desc = "每2回合，全队回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102196,
					Value = 17,
				},
			},
		},
		{
			Stage = 8,
			Desc = "每2回合，全队回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102196,
					Value = 19,
				},
			},
		},
		{
			Stage = 9,
			Desc = "每2回合，全队回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102196,
					Value = 21,
				},
			},
		},
		{
			Stage = 10,
			Desc = "每2回合，全队回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102196,
					Value = 23,
				},
			},
		},
		{
			Stage = 11,
			Desc = "每2回合，全队回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102196,
					Value = 25,
				},
			},
		},
		{
			Stage = 12,
			Desc = "每2回合，全队回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102196,
					Value = 27,
				},
			},
		},
		{
			Stage = 13,
			Desc = "每2回合，全队回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102196,
					Value = 29,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320305,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320306,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560205,
		560206,
		560207,
		560209,
		560110,
		560211,
		561205,
		561306,
		561331,
		561332,
		563103,
		563203,
		563619,
		563708,
		563829,
		563305,
		563404,
		563504,
		563934,
		563904,
		563918,
		564019,
		564008,
		564119,
		564203,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id525] =
{
	Id = 525,
	Name = "针不戳",
	ActivityExplore = 
	{
		630005,
	},
	Rarity = 3,
	Element = 210005,
	Gallery = 950101,
	Desc = "织布工具人，但织出来的作品往往和手艺人脑中的不同，这都是因为针不戳有他自己的想法。",
	LevelUp = 910203,
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_ZhenBuChuo",
	PrefabBundle = "character_enemy",
	PrefabName = "All_ZhenBuChuo",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectDark",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 105, Gain = 105},
		{Value = 200004, Base = 10, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "敌人忍耐-{Value1}",
			Skill = {
				{
					Id = 102197,
					Value = -20,
				},
			},
		},
		{
			Stage = 2,
			Desc = "敌人忍耐-{Value1}",
			Skill = {
				{
					Id = 102197,
					Value = -30,
				},
			},
		},
		{
			Stage = 3,
			Desc = "敌人忍耐-{Value1}",
			Skill = {
				{
					Id = 102197,
					Value = -40,
				},
			},
		},
		{
			Stage = 4,
			Desc = "敌人忍耐-{Value1}",
			Skill = {
				{
					Id = 102197,
					Value = -50,
				},
			},
		},
		{
			Stage = 5,
			Desc = "敌人忍耐-{Value1}",
			Skill = {
				{
					Id = 102197,
					Value = -60,
				},
			},
		},
		{
			Stage = 6,
			Desc = "敌人忍耐-{Value1}",
			Skill = {
				{
					Id = 102197,
					Value = -70,
				},
			},
		},
		{
			Stage = 7,
			Desc = "敌人忍耐-{Value1}",
			Skill = {
				{
					Id = 102197,
					Value = -80,
				},
			},
		},
		{
			Stage = 8,
			Desc = "敌人忍耐-{Value1}",
			Skill = {
				{
					Id = 102197,
					Value = -90,
				},
			},
		},
		{
			Stage = 9,
			Desc = "敌人忍耐-{Value1}",
			Skill = {
				{
					Id = 102197,
					Value = -100,
				},
			},
		},
		{
			Stage = 10,
			Desc = "敌人忍耐-{Value1}",
			Skill = {
				{
					Id = 102197,
					Value = -110,
				},
			},
		},
		{
			Stage = 11,
			Desc = "敌人忍耐-{Value1}",
			Skill = {
				{
					Id = 102197,
					Value = -120,
				},
			},
		},
		{
			Stage = 12,
			Desc = "敌人忍耐-{Value1}",
			Skill = {
				{
					Id = 102197,
					Value = -130,
				},
			},
		},
		{
			Stage = 13,
			Desc = "敌人忍耐-{Value1}",
			Skill = {
				{
					Id = 102197,
					Value = -140,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320314,
			CatchChance = 30,
			CatchChanceGain = 10,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 25,
			SuccessChanceGain = 2,
			SuccessChanceMax = 100,
		},
		{
			Value = 320315,
			CatchChance = 50,
			CatchChanceGain = 20,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560203,
		560204,
		560205,
		560206,
		560207,
		560209,
		560110,
		560211,
		561206,
		561344,
		563105,
		563203,
		563605,
		563814,
		563305,
		563403,
		563505,
		563951,
		563924,
		563904,
		564038,
		564054,
		564158,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id526] =
{
	Id = 526,
	Name = "石榴香囊",
	ActivityExplore = 
	{
		630005,
	},
	Rarity = 4,
	Element = 210002,
	Gallery = 950101,
	Desc = "因为形似石榴而得名，特技是舞蹈，自从曾经疯狂旋转，导致结绳脱落、身体散架后，起舞时便再也不复往日英姿。",
	LevelUp = 910204,
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_ShiLiuXiangNiang",
	PrefabBundle = "character_enemy",
	PrefabName = "All_ShiLiuXiangNiang",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectFire",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 157, Gain = 157},
		{Value = 200004, Base = 15, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "全队暴击+{Value1}",
			Skill = {
				{
					Id = 102198,
					Value = 4,
				},
			},
		},
		{
			Stage = 2,
			Desc = "全队暴击+{Value1}",
			Skill = {
				{
					Id = 102198,
					Value = 6,
				},
			},
		},
		{
			Stage = 3,
			Desc = "全队暴击+{Value1}",
			Skill = {
				{
					Id = 102198,
					Value = 8,
				},
			},
		},
		{
			Stage = 4,
			Desc = "全队暴击+{Value1}",
			Skill = {
				{
					Id = 102198,
					Value = 10,
				},
			},
		},
		{
			Stage = 5,
			Desc = "全队暴击+{Value1}",
			Skill = {
				{
					Id = 102198,
					Value = 12,
				},
			},
		},
		{
			Stage = 6,
			Desc = "全队暴击+{Value1}",
			Skill = {
				{
					Id = 102198,
					Value = 14,
				},
			},
		},
		{
			Stage = 7,
			Desc = "全队暴击+{Value1}",
			Skill = {
				{
					Id = 102198,
					Value = 16,
				},
			},
		},
		{
			Stage = 8,
			Desc = "全队暴击+{Value1}",
			Skill = {
				{
					Id = 102198,
					Value = 18,
				},
			},
		},
		{
			Stage = 9,
			Desc = "全队暴击+{Value1}",
			Skill = {
				{
					Id = 102198,
					Value = 20,
				},
			},
		},
		{
			Stage = 10,
			Desc = "全队暴击+{Value1}",
			Skill = {
				{
					Id = 102198,
					Value = 22,
				},
			},
		},
		{
			Stage = 11,
			Desc = "全队暴击+{Value1}",
			Skill = {
				{
					Id = 102198,
					Value = 24,
				},
			},
		},
		{
			Stage = 12,
			Desc = "全队暴击+{Value1}",
			Skill = {
				{
					Id = 102198,
					Value = 26,
				},
			},
		},
		{
			Stage = 13,
			Desc = "全队暴击+{Value1}",
			Skill = {
				{
					Id = 102198,
					Value = 28,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320318,
			CatchChance = 5,
			CatchChanceGain = 48,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 5,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
		{
			Value = 320319,
			CatchChance = 33,
			CatchChanceGain = 100,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 33,
			SuccessChanceGain = 4,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560025,
		560045,
		560046,
		560032,
		560033,
		560034,
		560035,
		560202,
		560203,
		560204,
		560205,
		560206,
		560207,
		560209,
		560110,
		560211,
		561203,
		561344,
		563106,
		563203,
		563620,
		563708,
		563824,
		563305,
		563403,
		563504,
		563909,
		563903,
		563918,
		564044,
		564004,
		564119,
		564203,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id527] =
{
	Id = 527,
	Name = "刘磺先生",
	ActivityExplore = 
	{
		630006,
	},
	Rarity = 2,
	Element = 210005,
	Gallery = 950101,
	Desc = "在温泉别墅中打工的硫磺皂，多亏了他的无私奉献，温泉中才会有硫磺的味道。不过这是一份非常辛苦的工作，因此，温泉成为了刘先生第一不喜欢的东西。",
	LevelUp = 910202,
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_LiuHuangXianSheng",
	PrefabBundle = "character_enemy",
	PrefabName = "All_LiuHuangXianSheng",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectDark",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 63, Gain = 63},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102200,
					Value = 4,
				},
			},
		},
		{
			Stage = 2,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102200,
					Value = 6,
				},
			},
		},
		{
			Stage = 3,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102200,
					Value = 8,
				},
			},
		},
		{
			Stage = 4,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102200,
					Value = 10,
				},
			},
		},
		{
			Stage = 5,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102200,
					Value = 12,
				},
			},
		},
		{
			Stage = 6,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102200,
					Value = 14,
				},
			},
		},
		{
			Stage = 7,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102200,
					Value = 16,
				},
			},
		},
		{
			Stage = 8,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102200,
					Value = 18,
				},
			},
		},
		{
			Stage = 9,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102200,
					Value = 20,
				},
			},
		},
		{
			Stage = 10,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102200,
					Value = 22,
				},
			},
		},
		{
			Stage = 11,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102200,
					Value = 24,
				},
			},
		},
		{
			Stage = 12,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102200,
					Value = 26,
				},
			},
		},
		{
			Stage = 13,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102200,
					Value = 28,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320309,
			CatchChance = 30,
			CatchChanceGain = 1,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 40,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
		{
			Value = 320310,
			CatchChance = 50,
			CatchChanceGain = 2,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560205,
		560206,
		560207,
		560209,
		560110,
		560211,
		561206,
		561321,
		563104,
		563203,
		563606,
		563708,
		563814,
		563304,
		563403,
		563504,
		563925,
		563904,
		563917,
		564019,
		564159,
		564204,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id528] =
{
	Id = 528,
	Name = "冰冰杆",
	ActivityExplore = 
	{
		630006,
	},
	Rarity = 3,
	Element = 210001,
	Gallery = 950101,
	Desc = "在风吹日晒下伫立一根栏杆，从不旷工缺席，但每到冬季就会冬眠，冰雪是她的保护层。\n听说她的表面是甜的，但用舌头去舔的话，会发生非常不好的事情。",
	LevelUp = 910203,
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_BingBingGang",
	PrefabBundle = "character_enemy",
	PrefabName = "All_BingBingGang",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWater",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 105, Gain = 105},
		{Value = 200004, Base = 10, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "敌人忍耐 -{Value1}",
			Skill = {
				{
					Id = 102201,
					Value = -20,
				},
			},
		},
		{
			Stage = 2,
			Desc = "敌人忍耐 -{Value1}",
			Skill = {
				{
					Id = 102201,
					Value = -30,
				},
			},
		},
		{
			Stage = 3,
			Desc = "敌人忍耐 -{Value1}",
			Skill = {
				{
					Id = 102201,
					Value = -40,
				},
			},
		},
		{
			Stage = 4,
			Desc = "敌人忍耐 -{Value1}",
			Skill = {
				{
					Id = 102201,
					Value = -50,
				},
			},
		},
		{
			Stage = 5,
			Desc = "敌人忍耐 -{Value1}",
			Skill = {
				{
					Id = 102201,
					Value = -60,
				},
			},
		},
		{
			Stage = 6,
			Desc = "敌人忍耐 -{Value1}",
			Skill = {
				{
					Id = 102201,
					Value = -70,
				},
			},
		},
		{
			Stage = 7,
			Desc = "敌人忍耐 -{Value1}",
			Skill = {
				{
					Id = 102201,
					Value = -80,
				},
			},
		},
		{
			Stage = 8,
			Desc = "敌人忍耐 -{Value1}",
			Skill = {
				{
					Id = 102201,
					Value = -90,
				},
			},
		},
		{
			Stage = 9,
			Desc = "敌人忍耐 -{Value1}",
			Skill = {
				{
					Id = 102201,
					Value = -100,
				},
			},
		},
		{
			Stage = 10,
			Desc = "敌人忍耐 -{Value1}",
			Skill = {
				{
					Id = 102201,
					Value = -110,
				},
			},
		},
		{
			Stage = 11,
			Desc = "敌人忍耐 -{Value1}",
			Skill = {
				{
					Id = 102201,
					Value = -120,
				},
			},
		},
		{
			Stage = 12,
			Desc = "敌人忍耐 -{Value1}",
			Skill = {
				{
					Id = 102201,
					Value = -130,
				},
			},
		},
		{
			Stage = 13,
			Desc = "敌人忍耐 -{Value1}",
			Skill = {
				{
					Id = 102201,
					Value = -140,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320314,
			CatchChance = 30,
			CatchChanceGain = 10,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 25,
			SuccessChanceGain = 2,
			SuccessChanceMax = 100,
		},
		{
			Value = 320315,
			CatchChance = 50,
			CatchChanceGain = 20,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560203,
		560204,
		560205,
		560206,
		560207,
		560209,
		560110,
		560211,
		561202,
		561321,
		563105,
		563203,
		563605,
		563814,
		563304,
		563402,
		563503,
		563935,
		563904,
		564049,
		564019,
		564118,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id529] =
{
	Id = 529,
	Name = "温泉冷蛋",
	ActivityExplore = 
	{
		630006,
	},
	Rarity = 1,
	Element = 210004,
	Gallery = 950101,
	Desc = "一颗有梦想的蛋，目标是成为熟度最恰当的温泉蛋。但因为性格高冷，因此被称为温泉冷蛋。\n不过，她认为自己一点也不冷淡。",
	LevelUp = 910201,
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_WenQuanLengDan",
	PrefabBundle = "character_enemy",
	PrefabName = "All_WenQuanLengDan",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectLight",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 42, Gain = 42},
		{Value = 200004, Base = 0, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102202,
					Value = 4,
				},
			},
		},
		{
			Stage = 2,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102202,
					Value = 6,
				},
			},
		},
		{
			Stage = 3,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102202,
					Value = 8,
				},
			},
		},
		{
			Stage = 4,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102202,
					Value = 10,
				},
			},
		},
		{
			Stage = 5,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102202,
					Value = 12,
				},
			},
		},
		{
			Stage = 6,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102202,
					Value = 14,
				},
			},
		},
		{
			Stage = 7,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102202,
					Value = 16,
				},
			},
		},
		{
			Stage = 8,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102202,
					Value = 18,
				},
			},
		},
		{
			Stage = 9,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102202,
					Value = 20,
				},
			},
		},
		{
			Stage = 10,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102202,
					Value = 22,
				},
			},
		},
		{
			Stage = 11,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102202,
					Value = 24,
				},
			},
		},
		{
			Stage = 12,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102202,
					Value = 26,
				},
			},
		},
		{
			Stage = 13,
			Desc = "全队忍耐 +{Value1}",
			Skill = {
				{
					Id = 102202,
					Value = 28,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320305,
			CatchChance = 50,
			CatchChanceGain = 0,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 1,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560022,
		560042,
		560043,
		560044,
		560045,
		560046,
		560032,
		560202,
		560203,
		560204,
		560205,
		560206,
		560207,
		560209,
		560110,
		560211,
		561205,
		561306,
		563103,
		563202,
		563609,
		563709,
		563824,
		563304,
		563403,
		563503,
		563925,
		563904,
		564019,
		564004,
		564118,
		564203,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id530] =
{
	Id = 530,
	Name = "药剂包",
	ActivityExplore = 
	{
		630006,
	},
	Rarity = 3,
	Element = 210003,
	Gallery = 950101,
	Desc = "在温泉别墅中打工的药剂包，姓药，昵称包包，也是一位勤勤恳恳的打工人。有人对他的味道欲罢不能，但也有人对这味道嗤之以鼻。",
	LevelUp = 910203,
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_YaoJiBao",
	PrefabBundle = "character_enemy",
	PrefabName = "All_YaoJiBao",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWind",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 105, Gain = 105},
		{Value = 200004, Base = 10, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "每回合，全队回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102203,
					Value = 5,
				},
			},
		},
		{
			Stage = 2,
			Desc = "每回合，全队回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102203,
					Value = 7,
				},
			},
		},
		{
			Stage = 3,
			Desc = "每回合，全队回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102203,
					Value = 9,
				},
			},
		},
		{
			Stage = 4,
			Desc = "每回合，全队回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102203,
					Value = 11,
				},
			},
		},
		{
			Stage = 5,
			Desc = "每回合，全队回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102203,
					Value = 13,
				},
			},
		},
		{
			Stage = 6,
			Desc = "每回合，全队回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102203,
					Value = 15,
				},
			},
		},
		{
			Stage = 7,
			Desc = "每回合，全队回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102203,
					Value = 17,
				},
			},
		},
		{
			Stage = 8,
			Desc = "每回合，全队回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102203,
					Value = 19,
				},
			},
		},
		{
			Stage = 9,
			Desc = "每回合，全队回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102203,
					Value = 21,
				},
			},
		},
		{
			Stage = 10,
			Desc = "每回合，全队回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102203,
					Value = 23,
				},
			},
		},
		{
			Stage = 11,
			Desc = "每回合，全队回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102203,
					Value = 25,
				},
			},
		},
		{
			Stage = 12,
			Desc = "每回合，全队回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102203,
					Value = 27,
				},
			},
		},
		{
			Stage = 13,
			Desc = "每回合，全队回血{Value1}%，最多5次",
			Skill = {
				{
					Id = 102203,
					Value = 29,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320318,
			CatchChance = 30,
			CatchChanceGain = 5,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 25,
			SuccessChanceGain = 2,
			SuccessChanceMax = 100,
		},
		{
			Value = 320319,
			CatchChance = 50,
			CatchChanceGain = 10,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560203,
		560204,
		560205,
		560206,
		560207,
		560209,
		560110,
		560211,
		561204,
		561344,
		563106,
		563203,
		563604,
		563304,
		563403,
		563502,
		563931,
		564019,
		564004,
		564158,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id531] =
{
	Id = 531,
	Name = "猎犬旺旺",
	ActivityExplore = 
	{
		630006,
	},
	Rarity = 4,
	Element = 210002,
	Gallery = 950101,
	Desc = "雪中猎人的搭档，对于鸟雀和野鹿没有兴趣，最大的爱好是吃冰棍。吃冰棍时，会一边向前走，一边在身后留下数不清的碎冰冰。曾因为啃冰棍的模样过于滑稽，而被做成表情包。",
	LevelUp = 910204,
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_LieQuanWangWang",
	PrefabBundle = "character_enemy",
	PrefabName = "All_LieQuanWangWang",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectFire",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 157, Gain = 157},
		{Value = 200004, Base = 15, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "{Value1}%概率无视敌人闪避",
			Skill = {
				{
					Id = 102204,
					Value = 30,
				},
			},
		},
		{
			Stage = 2,
			Desc = "{Value1}%概率无视敌人闪避",
			Skill = {
				{
					Id = 102204,
					Value = 45,
				},
			},
		},
		{
			Stage = 3,
			Desc = "{Value1}%概率无视敌人闪避",
			Skill = {
				{
					Id = 102204,
					Value = 60,
				},
			},
		},
		{
			Stage = 4,
			Desc = "{Value1}%概率无视敌人闪避",
			Skill = {
				{
					Id = 102204,
					Value = 75,
				},
			},
		},
		{
			Stage = 5,
			Desc = "{Value1}%概率无视敌人闪避",
			Skill = {
				{
					Id = 102204,
					Value = 90,
				},
			},
		},
		{
			Stage = 6,
			Desc = "{Value1}%概率无视敌人闪避",
			Skill = {
				{
					Id = 102204,
					Value = 105,
				},
			},
		},
		{
			Stage = 7,
			Desc = "{Value1}%概率无视敌人闪避",
			Skill = {
				{
					Id = 102204,
					Value = 120,
				},
			},
		},
		{
			Stage = 8,
			Desc = "{Value1}%概率无视敌人闪避",
			Skill = {
				{
					Id = 102204,
					Value = 135,
				},
			},
		},
		{
			Stage = 9,
			Desc = "{Value1}%概率无视敌人闪避",
			Skill = {
				{
					Id = 102204,
					Value = 150,
				},
			},
		},
		{
			Stage = 10,
			Desc = "{Value1}%概率无视敌人闪避",
			Skill = {
				{
					Id = 102204,
					Value = 165,
				},
			},
		},
		{
			Stage = 11,
			Desc = "{Value1}%概率无视敌人闪避",
			Skill = {
				{
					Id = 102204,
					Value = 180,
				},
			},
		},
		{
			Stage = 12,
			Desc = "{Value1}%概率无视敌人闪避",
			Skill = {
				{
					Id = 102204,
					Value = 195,
				},
			},
		},
		{
			Stage = 13,
			Desc = "{Value1}%概率无视敌人闪避",
			Skill = {
				{
					Id = 102204,
					Value = 210,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320302,
			CatchChance = 5,
			CatchChanceGain = 48,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 5,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
		{
			Value = 320303,
			CatchChance = 33,
			CatchChanceGain = 100,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 33,
			SuccessChanceGain = 4,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560025,
		560045,
		560046,
		560032,
		560033,
		560034,
		560035,
		560202,
		560203,
		560204,
		560205,
		560206,
		560207,
		560209,
		560110,
		560211,
		561203,
		561303,
		563102,
		563206,
		563704,
		563813,
		563306,
		563405,
		563504,
		563925,
		563902,
		563932,
		564004,
		564019,
		564155,
		564205,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id1001] =
{
	Id = 1001,
	Name = "黑狼",
	Summon = 
	{
		500003,
	},
	Rarity = 2,
	Element = 210005,
	Gallery = 950001,
	Desc = "曾经在溪谷与白狼争夺地盘的凶悍族群，被白狼凶过以后，集体撤离了溪谷。",
	LevelUp = 910102,
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_blackWolf",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_BlackWolf",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectDark",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 63, Gain = 252},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "暗元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102120,
					Value = 3,
				},
			},
		},
		{
			Stage = 2,
			Desc = "暗元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102120,
					Value = 4,
				},
			},
		},
		{
			Stage = 3,
			Desc = "暗元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102120,
					Value = 5,
				},
			},
		},
		{
			Stage = 4,
			Desc = "暗元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102120,
					Value = 6,
				},
			},
		},
		{
			Stage = 5,
			Desc = "暗元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102120,
					Value = 7,
				},
			},
		},
		{
			Stage = 6,
			Desc = "暗元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102120,
					Value = 8,
				},
			},
		},
		{
			Stage = 7,
			Desc = "暗元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102120,
					Value = 9,
				},
			},
		},
		{
			Stage = 8,
			Desc = "暗元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102120,
					Value = 10,
				},
			},
		},
		{
			Stage = 9,
			Desc = "暗元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102120,
					Value = 11,
				},
			},
		},
		{
			Stage = 10,
			Desc = "暗元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102120,
					Value = 12,
				},
			},
		},
		{
			Stage = 11,
			Desc = "暗元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102120,
					Value = 13,
				},
			},
		},
		{
			Stage = 12,
			Desc = "暗元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102120,
					Value = 14,
				},
			},
		},
		{
			Stage = 13,
			Desc = "暗元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102120,
					Value = 15,
				},
			},
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561206,
		561303,
		561349,
		563205,
		563823,
		563302,
		563404,
		563502,
		563916,
		564035,
		564029,
		564155,
		564204,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id1002] =
{
	Id = 1002,
	Name = "水精灵",
	Summon = 
	{
		500003,
	},
	Rarity = 2,
	Element = 210001,
	Gallery = 950001,
	Desc = "居住在溪谷的水之精灵，由魔法之泉构成。",
	LevelUp = 910102,
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_Undine",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Undine",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWater",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 63, Gain = 252},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102121,
					Value = 4,
				},
			},
		},
		{
			Stage = 2,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102121,
					Value = 6,
				},
			},
		},
		{
			Stage = 3,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102121,
					Value = 8,
				},
			},
		},
		{
			Stage = 4,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102121,
					Value = 10,
				},
			},
		},
		{
			Stage = 5,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102121,
					Value = 12,
				},
			},
		},
		{
			Stage = 6,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102121,
					Value = 14,
				},
			},
		},
		{
			Stage = 7,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102121,
					Value = 16,
				},
			},
		},
		{
			Stage = 8,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102121,
					Value = 18,
				},
			},
		},
		{
			Stage = 9,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102121,
					Value = 20,
				},
			},
		},
		{
			Stage = 10,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102121,
					Value = 22,
				},
			},
		},
		{
			Stage = 11,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102121,
					Value = 24,
				},
			},
		},
		{
			Stage = 12,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102121,
					Value = 26,
				},
			},
		},
		{
			Stage = 13,
			Desc = "每回合全队回血 {Value1}%，最多5次",
			Skill = {
				{
					Id = 102121,
					Value = 28,
				},
			},
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561202,
		561305,
		561350,
		563203,
		563615,
		563824,
		563304,
		563402,
		563503,
		563935,
		563903,
		564050,
		564004,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id1003] =
{
	Id = 1003,
	Name = "火狐",
	Summon = 
	{
		500003,
	},
	Rarity = 3,
	Element = 210002,
	Gallery = 950001,
	Desc = "已经在冒险星上绝种的稀有物种，因为毛皮非常珍贵，所以遭到了大量捕杀。",
	LevelUp = 910103,
	IconBundle = "atlas_charactericon_rpg",
	IconAtlas = "RPG",
	IconName = "RPG_fox",
	PrefabBundle = "character_enemy",
	PrefabName = "RPG_Fox",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectFire",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 105, Gain = 420},
		{Value = 200004, Base = 10, Gain = 2},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102122,
					Value = 4,
				},
			},
		},
		{
			Stage = 2,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102122,
					Value = 6,
				},
			},
		},
		{
			Stage = 3,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102122,
					Value = 8,
				},
			},
		},
		{
			Stage = 4,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102122,
					Value = 10,
				},
			},
		},
		{
			Stage = 5,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102122,
					Value = 12,
				},
			},
		},
		{
			Stage = 6,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102122,
					Value = 14,
				},
			},
		},
		{
			Stage = 7,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102122,
					Value = 16,
				},
			},
		},
		{
			Stage = 8,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102122,
					Value = 18,
				},
			},
		},
		{
			Stage = 9,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102122,
					Value = 20,
				},
			},
		},
		{
			Stage = 10,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102122,
					Value = 22,
				},
			},
		},
		{
			Stage = 11,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102122,
					Value = 24,
				},
			},
		},
		{
			Stage = 12,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102122,
					Value = 26,
				},
			},
		},
		{
			Stage = 13,
			Desc = "火元素队员攻击 +{Value1}%",
			Skill = {
				{
					Id = 102122,
					Value = 28,
				},
			},
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560103,
		560204,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561203,
		561303,
		561349,
		563206,
		563825,
		563302,
		563405,
		563504,
		563921,
		563904,
		564030,
		564010,
		564152,
		564204,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id1201] =
{
	Id = 1201,
	Name = "双色克林姆",
	Summon = 
	{
		500003,
	},
	Rarity = 2,
	Element = 210001,
	Gallery = 950002,
	Desc = "同时有牛奶与巧克力口味的双色冰淇淋，既有牛奶的香甜，又有巧克力的醇香。",
	LevelUp = 910102,
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_OxalisVersicolor",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_OxalisVersicolor",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWater",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 63, Gain = 252},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "光元素队员攻击 +{Value1}%\n暗元素队员攻击 +{Value2}%",
			Skill = {
				{
					Id = 102123,
					Value = 3,
				},
				{
					Id = 102124,
					Value = 3,
				},
			},
		},
		{
			Stage = 2,
			Desc = "光元素队员攻击 +{Value1}%\n暗元素队员攻击 +{Value2}%",
			Skill = {
				{
					Id = 102123,
					Value = 4,
				},
				{
					Id = 102124,
					Value = 4,
				},
			},
		},
		{
			Stage = 3,
			Desc = "光元素队员攻击 +{Value1}%\n暗元素队员攻击 +{Value2}%",
			Skill = {
				{
					Id = 102123,
					Value = 5,
				},
				{
					Id = 102124,
					Value = 5,
				},
			},
		},
		{
			Stage = 4,
			Desc = "光元素队员攻击 +{Value1}%\n暗元素队员攻击 +{Value2}%",
			Skill = {
				{
					Id = 102123,
					Value = 6,
				},
				{
					Id = 102124,
					Value = 6,
				},
			},
		},
		{
			Stage = 5,
			Desc = "光元素队员攻击 +{Value1}%\n暗元素队员攻击 +{Value2}%",
			Skill = {
				{
					Id = 102123,
					Value = 7,
				},
				{
					Id = 102124,
					Value = 7,
				},
			},
		},
		{
			Stage = 6,
			Desc = "光元素队员攻击 +{Value1}%\n暗元素队员攻击 +{Value2}%",
			Skill = {
				{
					Id = 102123,
					Value = 8,
				},
				{
					Id = 102124,
					Value = 8,
				},
			},
		},
		{
			Stage = 7,
			Desc = "光元素队员攻击 +{Value1}%\n暗元素队员攻击 +{Value2}%",
			Skill = {
				{
					Id = 102123,
					Value = 9,
				},
				{
					Id = 102124,
					Value = 9,
				},
			},
		},
		{
			Stage = 8,
			Desc = "光元素队员攻击 +{Value1}%\n暗元素队员攻击 +{Value2}%",
			Skill = {
				{
					Id = 102123,
					Value = 10,
				},
				{
					Id = 102124,
					Value = 10,
				},
			},
		},
		{
			Stage = 9,
			Desc = "光元素队员攻击 +{Value1}%\n暗元素队员攻击 +{Value2}%",
			Skill = {
				{
					Id = 102123,
					Value = 11,
				},
				{
					Id = 102124,
					Value = 11,
				},
			},
		},
		{
			Stage = 10,
			Desc = "光元素队员攻击 +{Value1}%\n暗元素队员攻击 +{Value2}%",
			Skill = {
				{
					Id = 102123,
					Value = 12,
				},
				{
					Id = 102124,
					Value = 12,
				},
			},
		},
		{
			Stage = 11,
			Desc = "光元素队员攻击 +{Value1}%\n暗元素队员攻击 +{Value2}%",
			Skill = {
				{
					Id = 102123,
					Value = 13,
				},
				{
					Id = 102124,
					Value = 13,
				},
			},
		},
		{
			Stage = 12,
			Desc = "光元素队员攻击 +{Value1}%\n暗元素队员攻击 +{Value2}%",
			Skill = {
				{
					Id = 102123,
					Value = 14,
				},
				{
					Id = 102124,
					Value = 14,
				},
			},
		},
		{
			Stage = 13,
			Desc = "光元素队员攻击 +{Value1}%\n暗元素队员攻击 +{Value2}%",
			Skill = {
				{
					Id = 102123,
					Value = 15,
				},
				{
					Id = 102124,
					Value = 15,
				},
			},
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561202,
		561306,
		561334,
		563203,
		563609,
		563709,
		563828,
		563304,
		563402,
		563504,
		563923,
		563914,
		563904,
		564019,
		564004,
		564134,
		564205,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id1202] =
{
	Id = 1202,
	Name = "煎铛噗灵",
	Summon = 
	{
		500003,
	},
	Rarity = 3,
	Element = 210002,
	Gallery = 950002,
	Desc = "使用平底煎锅，将屁股部位炸得金黄香脆的饺子，搭配米醋食用，风味更佳。",
	LevelUp = 910103,
	IconBundle = "atlas_charactericon_fat",
	IconAtlas = "FAT",
	IconName = "FAT_FriedDumplings",
	PrefabBundle = "character_enemy",
	PrefabName = "FAT_FriedDumplings",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectFire",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 105, Gain = 420},
		{Value = 200004, Base = 10, Gain = 2},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "水元素队员暴击 +{Value1}\n火元素队员暴击 +{Value2}",
			Skill = {
				{
					Id = 102125,
					Value = 4,
				},
				{
					Id = 102126,
					Value = 4,
				},
			},
		},
		{
			Stage = 2,
			Desc = "水元素队员暴击 +{Value1}\n火元素队员暴击 +{Value2}",
			Skill = {
				{
					Id = 102125,
					Value = 6,
				},
				{
					Id = 102126,
					Value = 6,
				},
			},
		},
		{
			Stage = 3,
			Desc = "水元素队员暴击 +{Value1}\n火元素队员暴击 +{Value2}",
			Skill = {
				{
					Id = 102125,
					Value = 8,
				},
				{
					Id = 102126,
					Value = 8,
				},
			},
		},
		{
			Stage = 4,
			Desc = "水元素队员暴击 +{Value1}\n火元素队员暴击 +{Value2}",
			Skill = {
				{
					Id = 102125,
					Value = 10,
				},
				{
					Id = 102126,
					Value = 10,
				},
			},
		},
		{
			Stage = 5,
			Desc = "水元素队员暴击 +{Value1}\n火元素队员暴击 +{Value2}",
			Skill = {
				{
					Id = 102125,
					Value = 12,
				},
				{
					Id = 102126,
					Value = 12,
				},
			},
		},
		{
			Stage = 6,
			Desc = "水元素队员暴击 +{Value1}\n火元素队员暴击 +{Value2}",
			Skill = {
				{
					Id = 102125,
					Value = 14,
				},
				{
					Id = 102126,
					Value = 14,
				},
			},
		},
		{
			Stage = 7,
			Desc = "水元素队员暴击 +{Value1}\n火元素队员暴击 +{Value2}",
			Skill = {
				{
					Id = 102125,
					Value = 16,
				},
				{
					Id = 102126,
					Value = 16,
				},
			},
		},
		{
			Stage = 8,
			Desc = "水元素队员暴击 +{Value1}\n火元素队员暴击 +{Value2}",
			Skill = {
				{
					Id = 102125,
					Value = 18,
				},
				{
					Id = 102126,
					Value = 18,
				},
			},
		},
		{
			Stage = 9,
			Desc = "水元素队员暴击 +{Value1}\n火元素队员暴击 +{Value2}",
			Skill = {
				{
					Id = 102125,
					Value = 20,
				},
				{
					Id = 102126,
					Value = 20,
				},
			},
		},
		{
			Stage = 10,
			Desc = "水元素队员暴击 +{Value1}\n火元素队员暴击 +{Value2}",
			Skill = {
				{
					Id = 102125,
					Value = 22,
				},
				{
					Id = 102126,
					Value = 22,
				},
			},
		},
		{
			Stage = 11,
			Desc = "水元素队员暴击 +{Value1}\n火元素队员暴击 +{Value2}",
			Skill = {
				{
					Id = 102125,
					Value = 24,
				},
				{
					Id = 102126,
					Value = 24,
				},
			},
		},
		{
			Stage = 12,
			Desc = "水元素队员暴击 +{Value1}\n火元素队员暴击 +{Value2}",
			Skill = {
				{
					Id = 102125,
					Value = 26,
				},
				{
					Id = 102126,
					Value = 26,
				},
			},
		},
		{
			Stage = 13,
			Desc = "水元素队员暴击 +{Value1}\n火元素队员暴击 +{Value2}",
			Skill = {
				{
					Id = 102125,
					Value = 28,
				},
				{
					Id = 102126,
					Value = 28,
				},
			},
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560203,
		560104,
		560205,
		560206,
		560207,
		560209,
		560210,
		560211,
		561203,
		561306,
		561319,
		563203,
		563803,
		563303,
		563405,
		563503,
		563905,
		563922,
		564040,
		564139,
		564205,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id1401] =
{
	Id = 1401,
	Name = "禁止通行",
	Summon = 
	{
		500003,
	},
	Rarity = 2,
	Element = 210005,
	Gallery = 950003,
	Desc = "挂在工作区门口的特别路牌，闲杂人等，不得入内。",
	LevelUp = 910102,
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_NoEntry",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_NoEntry",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectDark",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 63, Gain = 252},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102127,
					Value = -10,
				},
			},
		},
		{
			Stage = 2,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102127,
					Value = -15,
				},
			},
		},
		{
			Stage = 3,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102127,
					Value = -20,
				},
			},
		},
		{
			Stage = 4,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102127,
					Value = -25,
				},
			},
		},
		{
			Stage = 5,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102127,
					Value = -30,
				},
			},
		},
		{
			Stage = 6,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102127,
					Value = -35,
				},
			},
		},
		{
			Stage = 7,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102127,
					Value = -40,
				},
			},
		},
		{
			Stage = 8,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102127,
					Value = -45,
				},
			},
		},
		{
			Stage = 9,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102127,
					Value = -50,
				},
			},
		},
		{
			Stage = 10,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102127,
					Value = -55,
				},
			},
		},
		{
			Stage = 11,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102127,
					Value = -60,
				},
			},
		},
		{
			Stage = 12,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102127,
					Value = -65,
				},
			},
		},
		{
			Stage = 13,
			Desc = "打不过的怪物出现概率 -{Value1}%",
			Skill = {
				{
					Id = 102127,
					Value = -70,
				},
			},
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561206,
		561321,
		561335,
		563203,
		563604,
		563814,
		563303,
		563402,
		563503,
		563920,
		563903,
		564040,
		564028,
		564052,
		564114,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id1402] =
{
	Id = 1402,
	Name = "温度探测器",
	Summon = 
	{
		500003,
	},
	Rarity = 2,
	Element = 210004,
	Gallery = 950003,
	Desc = "为应对感冒流行患者进入博物馆传染他人，因此特意设置的温度探测器。",
	LevelUp = 910102,
	IconBundle = "atlas_charactericon_mus",
	IconAtlas = "MUS",
	IconName = "MUS_Thermometer",
	PrefabBundle = "character_enemy",
	PrefabName = "MUS_Thermometer",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectLight",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 63, Gain = 252},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "火元素敌人战力 -{Value1}%\n水元素敌人战力 -{Value2}%",
			Skill = {
				{
					Id = 102128,
					Value = -4,
				},
				{
					Id = 102129,
					Value = -4,
				},
			},
		},
		{
			Stage = 2,
			Desc = "火元素敌人战力 -{Value1}%\n水元素敌人战力 -{Value2}%",
			Skill = {
				{
					Id = 102128,
					Value = -6,
				},
				{
					Id = 102129,
					Value = -6,
				},
			},
		},
		{
			Stage = 3,
			Desc = "火元素敌人战力 -{Value1}%\n水元素敌人战力 -{Value2}%",
			Skill = {
				{
					Id = 102128,
					Value = -8,
				},
				{
					Id = 102129,
					Value = -8,
				},
			},
		},
		{
			Stage = 4,
			Desc = "火元素敌人战力 -{Value1}%\n水元素敌人战力 -{Value2}%",
			Skill = {
				{
					Id = 102128,
					Value = -10,
				},
				{
					Id = 102129,
					Value = -10,
				},
			},
		},
		{
			Stage = 5,
			Desc = "火元素敌人战力 -{Value1}%\n水元素敌人战力 -{Value2}%",
			Skill = {
				{
					Id = 102128,
					Value = -12,
				},
				{
					Id = 102129,
					Value = -12,
				},
			},
		},
		{
			Stage = 6,
			Desc = "火元素敌人战力 -{Value1}%\n水元素敌人战力 -{Value2}%",
			Skill = {
				{
					Id = 102128,
					Value = -14,
				},
				{
					Id = 102129,
					Value = -14,
				},
			},
		},
		{
			Stage = 7,
			Desc = "火元素敌人战力 -{Value1}%\n水元素敌人战力 -{Value2}%",
			Skill = {
				{
					Id = 102128,
					Value = -16,
				},
				{
					Id = 102129,
					Value = -16,
				},
			},
		},
		{
			Stage = 8,
			Desc = "火元素敌人战力 -{Value1}%\n水元素敌人战力 -{Value2}%",
			Skill = {
				{
					Id = 102128,
					Value = -18,
				},
				{
					Id = 102129,
					Value = -18,
				},
			},
		},
		{
			Stage = 9,
			Desc = "火元素敌人战力 -{Value1}%\n水元素敌人战力 -{Value2}%",
			Skill = {
				{
					Id = 102128,
					Value = -20,
				},
				{
					Id = 102129,
					Value = -20,
				},
			},
		},
		{
			Stage = 10,
			Desc = "火元素敌人战力 -{Value1}%\n水元素敌人战力 -{Value2}%",
			Skill = {
				{
					Id = 102128,
					Value = -22,
				},
				{
					Id = 102129,
					Value = -22,
				},
			},
		},
		{
			Stage = 11,
			Desc = "火元素敌人战力 -{Value1}%\n水元素敌人战力 -{Value2}%",
			Skill = {
				{
					Id = 102128,
					Value = -24,
				},
				{
					Id = 102129,
					Value = -24,
				},
			},
		},
		{
			Stage = 12,
			Desc = "火元素敌人战力 -{Value1}%\n水元素敌人战力 -{Value2}%",
			Skill = {
				{
					Id = 102128,
					Value = -26,
				},
				{
					Id = 102129,
					Value = -26,
				},
			},
		},
		{
			Stage = 13,
			Desc = "火元素敌人战力 -{Value1}%\n水元素敌人战力 -{Value2}%",
			Skill = {
				{
					Id = 102128,
					Value = -28,
				},
				{
					Id = 102129,
					Value = -28,
				},
			},
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560105,
		560206,
		560207,
		560209,
		560210,
		560211,
		561205,
		561321,
		561353,
		561322,
		563203,
		563620,
		563814,
		563303,
		563403,
		563503,
		563905,
		563913,
		564055,
		564029,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id1601] =
{
	Id = 1601,
	Name = "警帽",
	Summon = 
	{
		500003,
	},
	Rarity = 3,
	Element = 210002,
	Gallery = 950004,
	Desc = "城市司法的象征，敢于挑战它，就是挑战整个城市的司法权威！",
	LevelUp = 910103,
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_PoliceCaps",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_PoliceCaps",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectFire",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 105, Gain = 420},
		{Value = 200004, Base = 10, Gain = 2},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "火元素队员战力 +{Value1}%\n光元素队员战力 +{Value2}%",
			Skill = {
				{
					Id = 102130,
					Value = 4,
				},
				{
					Id = 102131,
					Value = 4,
				},
			},
		},
		{
			Stage = 2,
			Desc = "火元素队员战力 +{Value1}%\n光元素队员战力 +{Value2}%",
			Skill = {
				{
					Id = 102130,
					Value = 6,
				},
				{
					Id = 102131,
					Value = 6,
				},
			},
		},
		{
			Stage = 3,
			Desc = "火元素队员战力 +{Value1}%\n光元素队员战力 +{Value2}%",
			Skill = {
				{
					Id = 102130,
					Value = 8,
				},
				{
					Id = 102131,
					Value = 8,
				},
			},
		},
		{
			Stage = 4,
			Desc = "火元素队员战力 +{Value1}%\n光元素队员战力 +{Value2}%",
			Skill = {
				{
					Id = 102130,
					Value = 10,
				},
				{
					Id = 102131,
					Value = 10,
				},
			},
		},
		{
			Stage = 5,
			Desc = "火元素队员战力 +{Value1}%\n光元素队员战力 +{Value2}%",
			Skill = {
				{
					Id = 102130,
					Value = 12,
				},
				{
					Id = 102131,
					Value = 12,
				},
			},
		},
		{
			Stage = 6,
			Desc = "火元素队员战力 +{Value1}%\n光元素队员战力 +{Value2}%",
			Skill = {
				{
					Id = 102130,
					Value = 14,
				},
				{
					Id = 102131,
					Value = 14,
				},
			},
		},
		{
			Stage = 7,
			Desc = "火元素队员战力 +{Value1}%\n光元素队员战力 +{Value2}%",
			Skill = {
				{
					Id = 102130,
					Value = 16,
				},
				{
					Id = 102131,
					Value = 16,
				},
			},
		},
		{
			Stage = 8,
			Desc = "火元素队员战力 +{Value1}%\n光元素队员战力 +{Value2}%",
			Skill = {
				{
					Id = 102130,
					Value = 18,
				},
				{
					Id = 102131,
					Value = 18,
				},
			},
		},
		{
			Stage = 9,
			Desc = "火元素队员战力 +{Value1}%\n光元素队员战力 +{Value2}%",
			Skill = {
				{
					Id = 102130,
					Value = 20,
				},
				{
					Id = 102131,
					Value = 20,
				},
			},
		},
		{
			Stage = 10,
			Desc = "火元素队员战力 +{Value1}%\n光元素队员战力 +{Value2}%",
			Skill = {
				{
					Id = 102130,
					Value = 22,
				},
				{
					Id = 102131,
					Value = 22,
				},
			},
		},
		{
			Stage = 11,
			Desc = "火元素队员战力 +{Value1}%\n光元素队员战力 +{Value2}%",
			Skill = {
				{
					Id = 102130,
					Value = 24,
				},
				{
					Id = 102131,
					Value = 24,
				},
			},
		},
		{
			Stage = 12,
			Desc = "火元素队员战力 +{Value1}%\n光元素队员战力 +{Value2}%",
			Skill = {
				{
					Id = 102130,
					Value = 26,
				},
				{
					Id = 102131,
					Value = 26,
				},
			},
		},
		{
			Stage = 13,
			Desc = "火元素队员战力 +{Value1}%\n光元素队员战力 +{Value2}%",
			Skill = {
				{
					Id = 102130,
					Value = 28,
				},
				{
					Id = 102131,
					Value = 28,
				},
			},
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561203,
		561344,
		561345,
		563203,
		563613,
		563824,
		563303,
		563403,
		563503,
		563935,
		563914,
		564030,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id1602] =
{
	Id = 1602,
	Name = "彩色墨水",
	Summon = 
	{
		500003,
	},
	Rarity = 3,
	Element = 210004,
	Gallery = 950004,
	Desc = "常用的书写墨水，不过被悬疑星黑帮垄断生产，因此成为了非常昂贵的墨水，只有非常富有的贵族才能随意使用。",
	LevelUp = 910103,
	IconBundle = "atlas_charactericon_sus",
	IconAtlas = "SUS",
	IconName = "SUS_ColourInk",
	PrefabBundle = "character_enemy",
	PrefabName = "SUS_ColourInk",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectLight",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 105, Gain = 420},
		{Value = 200004, Base = 10, Gain = 2},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "光元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102132,
					Value = 8,
				},
			},
		},
		{
			Stage = 2,
			Desc = "光元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102132,
					Value = 12,
				},
			},
		},
		{
			Stage = 3,
			Desc = "光元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102132,
					Value = 16,
				},
			},
		},
		{
			Stage = 4,
			Desc = "光元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102132,
					Value = 20,
				},
			},
		},
		{
			Stage = 5,
			Desc = "光元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102132,
					Value = 24,
				},
			},
		},
		{
			Stage = 6,
			Desc = "光元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102132,
					Value = 28,
				},
			},
		},
		{
			Stage = 7,
			Desc = "光元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102132,
					Value = 32,
				},
			},
		},
		{
			Stage = 8,
			Desc = "光元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102132,
					Value = 36,
				},
			},
		},
		{
			Stage = 9,
			Desc = "光元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102132,
					Value = 40,
				},
			},
		},
		{
			Stage = 10,
			Desc = "光元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102132,
					Value = 44,
				},
			},
		},
		{
			Stage = 11,
			Desc = "光元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102132,
					Value = 48,
				},
			},
		},
		{
			Stage = 12,
			Desc = "光元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102132,
					Value = 52,
				},
			},
		},
		{
			Stage = 13,
			Desc = "光元素敌人捕捉成功率 +{Value1}%",
			Skill = {
				{
					Id = 102132,
					Value = 56,
				},
			},
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560203,
		560204,
		560205,
		560106,
		560207,
		560209,
		560210,
		560211,
		561205,
		561321,
		561350,
		561347,
		563203,
		563625,
		563814,
		563303,
		563402,
		563506,
		563921,
		563941,
		563936,
		564019,
		564114,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id1801] =
{
	Id = 1801,
	Name = "海小螺",
	Summon = 
	{
		500007,
	},
	Rarity = 2,
	Element = 210001,
	Gallery = 950005,
	Desc = "来自浅海沙滩，放在耳边能听到海浪的声音，据说还是一种美味的食材。",
	LevelUp = 910102,
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "SEA",
	IconName = "SEA_Conch",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Conch",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWater",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 78, Gain = 312},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102171,
					Value = 4,
				},
			},
		},
		{
			Stage = 2,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102171,
					Value = 6,
				},
			},
		},
		{
			Stage = 3,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102171,
					Value = 8,
				},
			},
		},
		{
			Stage = 4,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102171,
					Value = 10,
				},
			},
		},
		{
			Stage = 5,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102171,
					Value = 12,
				},
			},
		},
		{
			Stage = 6,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102171,
					Value = 14,
				},
			},
		},
		{
			Stage = 7,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102171,
					Value = 16,
				},
			},
		},
		{
			Stage = 8,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102171,
					Value = 18,
				},
			},
		},
		{
			Stage = 9,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102171,
					Value = 20,
				},
			},
		},
		{
			Stage = 10,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102171,
					Value = 22,
				},
			},
		},
		{
			Stage = 11,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102171,
					Value = 24,
				},
			},
		},
		{
			Stage = 12,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102171,
					Value = 26,
				},
			},
		},
		{
			Stage = 13,
			Desc = "道具掉落率 +{Value1}%",
			Skill = {
				{
					Id = 102171,
					Value = 28,
				},
			},
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561202,
		561355,
		561367,
		563203,
		563618,
		563814,
		563305,
		563402,
		563503,
		563905,
		563912,
		564020,
		564014,
		564109,
		564204,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id1802] =
{
	Id = 1802,
	Name = "刺毛胆",
	Summon = 
	{
		500007,
	},
	Rarity = 2,
	Element = 210005,
	Gallery = 950005,
	Desc = "年幼的海胆，遇到危险时会虚张声势说“我要扎破你”，但其实身上只有几颗稀疏的软刺。",
	LevelUp = 910102,
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "SEA",
	IconName = "SEA_SeaUrchin",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_SeaUrchin",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectDark",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 78, Gain = 312},
		{Value = 200004, Base = 5, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "每回合暗元素队员攻击 +{Value1}%，最多5次",
			Skill = {
				{
					Id = 102172,
					Value = 3,
				},
			},
		},
		{
			Stage = 2,
			Desc = "每回合暗元素队员攻击 +{Value1}%，最多5次",
			Skill = {
				{
					Id = 102172,
					Value = 4,
				},
			},
		},
		{
			Stage = 3,
			Desc = "每回合暗元素队员攻击 +{Value1}%，最多5次",
			Skill = {
				{
					Id = 102172,
					Value = 5,
				},
			},
		},
		{
			Stage = 4,
			Desc = "每回合暗元素队员攻击 +{Value1}%，最多5次",
			Skill = {
				{
					Id = 102172,
					Value = 6,
				},
			},
		},
		{
			Stage = 5,
			Desc = "每回合暗元素队员攻击 +{Value1}%，最多5次",
			Skill = {
				{
					Id = 102172,
					Value = 7,
				},
			},
		},
		{
			Stage = 6,
			Desc = "每回合暗元素队员攻击 +{Value1}%，最多5次",
			Skill = {
				{
					Id = 102172,
					Value = 8,
				},
			},
		},
		{
			Stage = 7,
			Desc = "每回合暗元素队员攻击 +{Value1}%，最多5次",
			Skill = {
				{
					Id = 102172,
					Value = 9,
				},
			},
		},
		{
			Stage = 8,
			Desc = "每回合暗元素队员攻击 +{Value1}%，最多5次",
			Skill = {
				{
					Id = 102172,
					Value = 10,
				},
			},
		},
		{
			Stage = 9,
			Desc = "每回合暗元素队员攻击 +{Value1}%，最多5次",
			Skill = {
				{
					Id = 102172,
					Value = 11,
				},
			},
		},
		{
			Stage = 10,
			Desc = "每回合暗元素队员攻击 +{Value1}%，最多5次",
			Skill = {
				{
					Id = 102172,
					Value = 12,
				},
			},
		},
		{
			Stage = 11,
			Desc = "每回合暗元素队员攻击 +{Value1}%，最多5次",
			Skill = {
				{
					Id = 102172,
					Value = 13,
				},
			},
		},
		{
			Stage = 12,
			Desc = "每回合暗元素队员攻击 +{Value1}%，最多5次",
			Skill = {
				{
					Id = 102172,
					Value = 14,
				},
			},
		},
		{
			Stage = 13,
			Desc = "每回合暗元素队员攻击 +{Value1}%，最多5次",
			Skill = {
				{
					Id = 102172,
					Value = 15,
				},
			},
		},
	},
	TameChance = 100,
	Tags = {
		560023,
		560043,
		560044,
		560045,
		560046,
		560032,
		560033,
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561206,
		561355,
		561361,
		563202,
		563619,
		563810,
		563303,
		563402,
		563502,
		563916,
		564006,
		564110,
		564204,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id1803] =
{
	Id = 1803,
	Name = "海飞象",
	Summon = 
	{
		500007,
	},
	Rarity = 3,
	Element = 210004,
	Gallery = 950005,
	Desc = "章鱼一族中的吉祥物，当有人经过TA时，总会情不自禁地拍拍TA的脑袋。",
	LevelUp = 910103,
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "SEA",
	IconName = "SEA_Octupas2",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_Octupas2",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectLight",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 126, Gain = 504},
		{Value = 200004, Base = 10, Gain = 2},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "第3回合，前3队员{Value1}%闪避",
			Skill = {
				{
					Id = 102173,
					Value = 25,
				},
			},
		},
		{
			Stage = 2,
			Desc = "第3回合，前3队员{Value1}%闪避",
			Skill = {
				{
					Id = 102173,
					Value = 37,
				},
			},
		},
		{
			Stage = 3,
			Desc = "第3回合，前3队员{Value1}%闪避",
			Skill = {
				{
					Id = 102173,
					Value = 49,
				},
			},
		},
		{
			Stage = 4,
			Desc = "第3回合，前3队员{Value1}%闪避",
			Skill = {
				{
					Id = 102173,
					Value = 61,
				},
			},
		},
		{
			Stage = 5,
			Desc = "第3回合，前3队员{Value1}%闪避",
			Skill = {
				{
					Id = 102173,
					Value = 73,
				},
			},
		},
		{
			Stage = 6,
			Desc = "第3回合，前3队员{Value1}%闪避",
			Skill = {
				{
					Id = 102173,
					Value = 85,
				},
			},
		},
		{
			Stage = 7,
			Desc = "第3回合，前3队员{Value1}%闪避",
			Skill = {
				{
					Id = 102173,
					Value = 97,
				},
			},
		},
		{
			Stage = 8,
			Desc = "第3回合，前3队员{Value1}%闪避",
			Skill = {
				{
					Id = 102173,
					Value = 109,
				},
			},
		},
		{
			Stage = 9,
			Desc = "第3回合，前3队员{Value1}%闪避",
			Skill = {
				{
					Id = 102173,
					Value = 121,
				},
			},
		},
		{
			Stage = 10,
			Desc = "第3回合，前3队员{Value1}%闪避",
			Skill = {
				{
					Id = 102173,
					Value = 133,
				},
			},
		},
		{
			Stage = 11,
			Desc = "第3回合，前3队员{Value1}%闪避",
			Skill = {
				{
					Id = 102173,
					Value = 145,
				},
			},
		},
		{
			Stage = 12,
			Desc = "第3回合，前3队员{Value1}%闪避",
			Skill = {
				{
					Id = 102173,
					Value = 157,
				},
			},
		},
		{
			Stage = 13,
			Desc = "第3回合，前3队员{Value1}%闪避",
			Skill = {
				{
					Id = 102173,
					Value = 169,
				},
			},
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561205,
		561355,
		561361,
		563204,
		563608,
		563825,
		563304,
		563402,
		563502,
		563905,
		564021,
		564109,
		564204,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id1804] =
{
	Id = 1804,
	Name = "海王龟",
	Summon = 
	{
		500007,
	},
	Rarity = 4,
	Element = 210001,
	Gallery = 950005,
	Desc = "绿色的海龟，居民总称其为“海王”或者“龟龟”，但TA似乎对这两个名字都不满意。",
	LevelUp = 910104,
	IconBundle = "atlas_charactericon_sea",
	IconAtlas = "SEA",
	IconName = "SEA_SeaTurtle",
	PrefabBundle = "character_enemy",
	PrefabName = "SEA_SeaTurtle",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectWater",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 183, Gain = 732},
		{Value = 200004, Base = 15, Gain = 3},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "全队生命 +{Value1}%\n敌人攻击 -{Value2}%",
			Skill = {
				{
					Id = 102174,
					Value = 3,
				},
				{
					Id = 102175,
					Value = -3,
				},
			},
		},
		{
			Stage = 2,
			Desc = "全队生命 +{Value1}%\n敌人攻击 -{Value2}%",
			Skill = {
				{
					Id = 102174,
					Value = 4,
				},
				{
					Id = 102175,
					Value = -4,
				},
			},
		},
		{
			Stage = 3,
			Desc = "全队生命 +{Value1}%\n敌人攻击 -{Value2}%",
			Skill = {
				{
					Id = 102174,
					Value = 5,
				},
				{
					Id = 102175,
					Value = -5,
				},
			},
		},
		{
			Stage = 4,
			Desc = "全队生命 +{Value1}%\n敌人攻击 -{Value2}%",
			Skill = {
				{
					Id = 102174,
					Value = 6,
				},
				{
					Id = 102175,
					Value = -6,
				},
			},
		},
		{
			Stage = 5,
			Desc = "全队生命 +{Value1}%\n敌人攻击 -{Value2}%",
			Skill = {
				{
					Id = 102174,
					Value = 7,
				},
				{
					Id = 102175,
					Value = -7,
				},
			},
		},
		{
			Stage = 6,
			Desc = "全队生命 +{Value1}%\n敌人攻击 -{Value2}%",
			Skill = {
				{
					Id = 102174,
					Value = 8,
				},
				{
					Id = 102175,
					Value = -8,
				},
			},
		},
		{
			Stage = 7,
			Desc = "全队生命 +{Value1}%\n敌人攻击 -{Value2}%",
			Skill = {
				{
					Id = 102174,
					Value = 9,
				},
				{
					Id = 102175,
					Value = -9,
				},
			},
		},
		{
			Stage = 8,
			Desc = "全队生命 +{Value1}%\n敌人攻击 -{Value2}%",
			Skill = {
				{
					Id = 102174,
					Value = 10,
				},
				{
					Id = 102175,
					Value = -10,
				},
			},
		},
		{
			Stage = 9,
			Desc = "全队生命 +{Value1}%\n敌人攻击 -{Value2}%",
			Skill = {
				{
					Id = 102174,
					Value = 11,
				},
				{
					Id = 102175,
					Value = -11,
				},
			},
		},
		{
			Stage = 10,
			Desc = "全队生命 +{Value1}%\n敌人攻击 -{Value2}%",
			Skill = {
				{
					Id = 102174,
					Value = 12,
				},
				{
					Id = 102175,
					Value = -12,
				},
			},
		},
		{
			Stage = 11,
			Desc = "全队生命 +{Value1}%\n敌人攻击 -{Value2}%",
			Skill = {
				{
					Id = 102174,
					Value = 13,
				},
				{
					Id = 102175,
					Value = -13,
				},
			},
		},
		{
			Stage = 12,
			Desc = "全队生命 +{Value1}%\n敌人攻击 -{Value2}%",
			Skill = {
				{
					Id = 102174,
					Value = 14,
				},
				{
					Id = 102175,
					Value = -14,
				},
			},
		},
		{
			Stage = 13,
			Desc = "全队生命 +{Value1}%\n敌人攻击 -{Value2}%",
			Skill = {
				{
					Id = 102174,
					Value = 15,
				},
				{
					Id = 102175,
					Value = -15,
				},
			},
		},
	},
	TameChance = 100,
	Tags = {
		560025,
		560045,
		560046,
		560032,
		560033,
		560034,
		560035,
		560202,
		560203,
		560204,
		560205,
		560206,
		560107,
		560209,
		560210,
		560211,
		561202,
		561355,
		563203,
		563815,
		563304,
		563402,
		563502,
		563941,
		564030,
		564009,
		564110,
		564203,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id2001] =
{
	Id = 2001,
	Name = "打卡机",
	Rarity = 3,
	Element = 210004,
	Gallery = 950101,
	Desc = "能精确识别各种磁卡的特殊机械，平时不需要进食和休息，只要滴一下卡就会充满活力。",
	LevelUp = 911001,
	IconBundle = "atlas_charactericon_sp",
	IconAtlas = "SP",
	IconName = "SP_CardMachine",
	PrefabBundle = "character_enemy",
	PrefabName = "SP_CardMachine",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectLight",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 105, Gain = 105},
		{Value = 200004, Base = 10, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "探索获得的金币 +{Value1}%\n道具掉落率 +{Value2}%",
			Skill = {
				{
					Id = 102133,
					Value = 4,
				},
				{
					Id = 102134,
					Value = 4,
				},
			},
		},
		{
			Stage = 2,
			Desc = "探索获得的金币 +{Value1}%\n道具掉落率 +{Value2}%",
			Skill = {
				{
					Id = 102133,
					Value = 6,
				},
				{
					Id = 102134,
					Value = 6,
				},
			},
		},
		{
			Stage = 3,
			Desc = "探索获得的金币 +{Value1}%\n道具掉落率 +{Value2}%",
			Skill = {
				{
					Id = 102133,
					Value = 8,
				},
				{
					Id = 102134,
					Value = 8,
				},
			},
		},
		{
			Stage = 4,
			Desc = "探索获得的金币 +{Value1}%\n道具掉落率 +{Value2}%",
			Skill = {
				{
					Id = 102133,
					Value = 10,
				},
				{
					Id = 102134,
					Value = 10,
				},
			},
		},
		{
			Stage = 5,
			Desc = "探索获得的金币 +{Value1}%\n道具掉落率 +{Value2}%",
			Skill = {
				{
					Id = 102133,
					Value = 12,
				},
				{
					Id = 102134,
					Value = 12,
				},
			},
		},
		{
			Stage = 6,
			Desc = "探索获得的金币 +{Value1}%\n道具掉落率 +{Value2}%",
			Skill = {
				{
					Id = 102133,
					Value = 14,
				},
				{
					Id = 102134,
					Value = 14,
				},
			},
		},
		{
			Stage = 7,
			Desc = "探索获得的金币 +{Value1}%\n道具掉落率 +{Value2}%",
			Skill = {
				{
					Id = 102133,
					Value = 16,
				},
				{
					Id = 102134,
					Value = 16,
				},
			},
		},
		{
			Stage = 8,
			Desc = "探索获得的金币 +{Value1}%\n道具掉落率 +{Value2}%",
			Skill = {
				{
					Id = 102133,
					Value = 18,
				},
				{
					Id = 102134,
					Value = 18,
				},
			},
		},
		{
			Stage = 9,
			Desc = "探索获得的金币 +{Value1}%\n道具掉落率 +{Value2}%",
			Skill = {
				{
					Id = 102133,
					Value = 20,
				},
				{
					Id = 102134,
					Value = 20,
				},
			},
		},
		{
			Stage = 10,
			Desc = "探索获得的金币 +{Value1}%\n道具掉落率 +{Value2}%",
			Skill = {
				{
					Id = 102133,
					Value = 22,
				},
				{
					Id = 102134,
					Value = 22,
				},
			},
		},
		{
			Stage = 11,
			Desc = "探索获得的金币 +{Value1}%\n道具掉落率 +{Value2}%",
			Skill = {
				{
					Id = 102133,
					Value = 24,
				},
				{
					Id = 102134,
					Value = 24,
				},
			},
		},
		{
			Stage = 12,
			Desc = "探索获得的金币 +{Value1}%\n道具掉落率 +{Value2}%",
			Skill = {
				{
					Id = 102133,
					Value = 26,
				},
				{
					Id = 102134,
					Value = 26,
				},
			},
		},
		{
			Stage = 13,
			Desc = "探索获得的金币 +{Value1}%\n道具掉落率 +{Value2}%",
			Skill = {
				{
					Id = 102133,
					Value = 28,
				},
				{
					Id = 102134,
					Value = 28,
				},
			},
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560203,
		560204,
		560205,
		560206,
		560207,
		560209,
		560110,
		560211,
		561205,
		561321,
		561322,
		563203,
		563605,
		563814,
		563306,
		563402,
		563503,
		563925,
		563914,
		564055,
		564024,
		564202,
	},
	Style = "Dps",
	AttackType = "Melee",
}
PetConfig[PetID.Id2002] =
{
	Id = 2002,
	Name = "白幽灵",
	Rarity = 3,
	Element = 210005,
	Gallery = 950101,
	Desc = "宇宙间的幽灵，对于生前的记忆已经模糊了。死后的身体变得轻飘飘的，更适合自由地游历世界。\n因此他表示，对现状还挺满意的。",
	LevelUp = 911002,
	IconBundle = "atlas_activity_1",
	IconAtlas = "ActivityCharacterIcon",
	IconName = "All_Ghost",
	PrefabBundle = "character_enemy",
	PrefabName = "ALL_Ghost",
	PrefabScale = 50,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAtackAnim = "Attack_1",
		RangeAtackEffect =  {
			Prefab = "BattleEffectDark",
			Atack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200002, Base = 105, Gain = 105},
		{Value = 200004, Base = 10, Gain = 1},
	},
	SkillList = {
		{
			Stage = 1,
			Desc = "每个暗元素队员使攻击+{Value1}%",
			Skill = {
				{
					Id = 102199,
					Value = 4,
				},
			},
		},
		{
			Stage = 2,
			Desc = "每个暗元素队员使攻击+{Value1}%",
			Skill = {
				{
					Id = 102199,
					Value = 6,
				},
			},
		},
		{
			Stage = 3,
			Desc = "每个暗元素队员使攻击+{Value1}%",
			Skill = {
				{
					Id = 102199,
					Value = 8,
				},
			},
		},
		{
			Stage = 4,
			Desc = "每个暗元素队员使攻击+{Value1}%",
			Skill = {
				{
					Id = 102199,
					Value = 10,
				},
			},
		},
		{
			Stage = 5,
			Desc = "每个暗元素队员使攻击+{Value1}%",
			Skill = {
				{
					Id = 102199,
					Value = 12,
				},
			},
		},
		{
			Stage = 6,
			Desc = "每个暗元素队员使攻击+{Value1}%",
			Skill = {
				{
					Id = 102199,
					Value = 14,
				},
			},
		},
		{
			Stage = 7,
			Desc = "每个暗元素队员使攻击+{Value1}%",
			Skill = {
				{
					Id = 102199,
					Value = 16,
				},
			},
		},
		{
			Stage = 8,
			Desc = "每个暗元素队员使攻击+{Value1}%",
			Skill = {
				{
					Id = 102199,
					Value = 18,
				},
			},
		},
		{
			Stage = 9,
			Desc = "每个暗元素队员使攻击+{Value1}%",
			Skill = {
				{
					Id = 102199,
					Value = 20,
				},
			},
		},
		{
			Stage = 10,
			Desc = "每个暗元素队员使攻击+{Value1}%",
			Skill = {
				{
					Id = 102199,
					Value = 22,
				},
			},
		},
		{
			Stage = 11,
			Desc = "每个暗元素队员使攻击+{Value1}%",
			Skill = {
				{
					Id = 102199,
					Value = 24,
				},
			},
		},
		{
			Stage = 12,
			Desc = "每个暗元素队员使攻击+{Value1}%",
			Skill = {
				{
					Id = 102199,
					Value = 26,
				},
			},
		},
		{
			Stage = 13,
			Desc = "每个暗元素队员使攻击+{Value1}%",
			Skill = {
				{
					Id = 102199,
					Value = 28,
				},
			},
		},
	},
	CatchItemList = {
		{
			Value = 320306,
			CatchChance = 30,
			CatchChanceGain = 5,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 25,
			SuccessChanceGain = 2,
			SuccessChanceMax = 100,
		},
		{
			Value = 320307,
			CatchChance = 50,
			CatchChanceGain = 10,
			CatchChanceMax = 100,
			DamageChance = 100,
			SuccessChance = 100,
			SuccessChanceGain = 3,
			SuccessChanceMax = 100,
		},
	},
	TameChance = 100,
	Tags = {
		560024,
		560044,
		560045,
		560046,
		560032,
		560033,
		560034,
		560202,
		560203,
		560204,
		560205,
		560206,
		560207,
		560209,
		560110,
		560211,
		561206,
		561369,
		563103,
		563205,
		563614,
		563709,
		563825,
		563304,
		563402,
		563502,
		563906,
		564005,
		564024,
		564203,
	},
	Style = "Dps",
	AttackType = "Melee",
}

