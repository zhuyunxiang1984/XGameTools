ActivityThemeConfig ={};
ActivityThemeID = 
{
	Id001 = 610001,
	Id002 = 610002,
	Id003 = 610003,
	Id004 = 610004,
	Id005 = 610005,
	Id006 = 610006,
	Id007 = 610007,
	Id008 = 610008,
	Id009 = 610009,
	Id010 = 610010,
	Id011 = 610011,
	Id012 = 610012,
	Id013 = 610013,
	Id014 = 610014,
	Id015 = 610015,
	Id016 = 610016,
	Id017 = 610017,
	Id018 = 610018,
	Id019 = 610019,
	Id020 = 610020,
	Id021 = 610021,
	Id022 = 610022,
	Id023 = 610023,
	Id024 = 610024,
	Id025 = 610025,
	Id026 = 610026,
	Id027 = 610027,
	Id028 = 610028,
	Id029 = 610029,
	Id030 = 610030,
	Id031 = 610031,
	Id032 = 610032,
	Id033 = 610033,
	Id034 = 610034,
	Id035 = 610035,
	Id036 = 610036,
	Id037 = 610037,
	Id038 = 610038,
	Id039 = 610039,
}
ActivityThemeConfig[ActivityThemeID.Id001] =
{
	Id = 1,
	BuildingList = {
		{
			Pos = "BuildingPosUp_1",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_2",
			Prefab = "Building_ClothingStore",
		},
		{
			Pos = "BuildingPosUp_3",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_4",
			Prefab = "fangzi09",
		},
		{
			Pos = "BuildingPosDown_1",
			Prefab = "Building_ExileStreetArena",
		},
		{
			Pos = "BuildingPosDown_2",
			Prefab = "Building_ActivityRoom",
		},
		{
			Pos = "BuildingPosDown_3",
			Prefab = "fangzi03",
		},
		{
			Pos = "BuildingPosDown_4",
			Prefab = "fangzi04",
		},
		{
			Pos = "BuildingPosDown_5",
			Prefab = "fangzi05",
		},
		{
			Pos = "BuildingPosDown_6",
			Prefab = "fangzi05",
		},
	},
}
ActivityThemeConfig[ActivityThemeID.Id002] =
{
	Id = 2,
	Name = "新年大吉",
	Explore = 630001,
	BattleTitle = "这次一定要回家！",
	TextureBundle = "packed_activity_2021springfestival",
	BattleList = {
		620001,
		620002,
		620003,
		620004,
		620005,
		620006,
		620007,
		620008,
		620009,
		620010,
		620011,
		620012,
		620013,
		620014,
		620015,
		620016,
		620017,
		620018,
		620019,
		620020,
	},
	BuildingList = {
		{
			Pos = "BuildingPosUp_1",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_2",
			Prefab = "Building_ClothingStore",
		},
		{
			Pos = "BuildingPosUp_3",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_4",
			Prefab = "fangzi09",
		},
		{
			Pos = "BuildingPosDown_1",
			Prefab = "Building_ExileStreetArena",
		},
		{
			Pos = "BuildingPosDown_2",
			Prefab = "Building_ActivityRoom",
		},
		{
			Pos = "BuildingPosDown_3",
			Prefab = "fangzi03",
		},
		{
			Pos = "BuildingPosDown_4",
			Prefab = "fangzi04",
		},
		{
			Pos = "BuildingPosDown_5",
			Prefab = "fangzi05",
		},
		{
			Pos = "BuildingPosDown_6",
			Prefab = "fangzi05",
		},
	},
	ThemeRoomPrefab = "2021SpringFestival",
	ThemeRoomBundle = "activitythemeroom",
	ThemeRoomCharacter = {
		223067,
		223066,
		223061,
		223062,
		223063,
		223064,
		223065,
	},
	PackageBundle = "Activity_1",
	PackageAtlas = "Activity_1",
	PackageIcon = "ActivityPackage_All_NewYearBeast",
}
ActivityThemeConfig[ActivityThemeID.Id003] =
{
	Id = 3,
	Name = "新年大吉",
	Explore = 630001,
	BattleTitle = "这次一定要回家！",
	TextureBundle = "packed_activity_2021springfestival",
	BattleList = {
		620001,
		620002,
		620003,
		620004,
		620005,
		620006,
		620007,
		620008,
		620009,
		620010,
		620011,
		620012,
		620013,
		620014,
		620015,
		620016,
		620017,
		620018,
		620019,
		620020,
	},
	BuildingList = {
		{
			Pos = "BuildingPosUp_1",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_2",
			Prefab = "Building_ClothingStore",
		},
		{
			Pos = "BuildingPosUp_3",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_4",
			Prefab = "fangzi09",
		},
		{
			Pos = "BuildingPosDown_1",
			Prefab = "Building_ExileStreetArena",
		},
		{
			Pos = "BuildingPosDown_2",
			Prefab = "Building_ActivityRoom",
		},
		{
			Pos = "BuildingPosDown_3",
			Prefab = "fangzi03",
		},
		{
			Pos = "BuildingPosDown_4",
			Prefab = "fangzi04",
		},
		{
			Pos = "BuildingPosDown_5",
			Prefab = "fangzi05",
		},
		{
			Pos = "BuildingPosDown_6",
			Prefab = "fangzi05",
		},
	},
	ThemeRoomPrefab = "2021SpringFestival",
	ThemeRoomBundle = "activitythemeroom",
	ThemeRoomCharacter = {
		223067,
		223066,
		223061,
		223062,
		223063,
		223064,
		223065,
	},
	PackageBundle = "Activity_1",
	PackageAtlas = "Activity_1",
	PackageIcon = "ActivityPackage_All_NewYearBeast",
}
ActivityThemeConfig[ActivityThemeID.Id004] =
{
	Id = 4,
	Name = "新年大吉",
	Explore = 630001,
	BattleTitle = "这次一定要回家！",
	TextureBundle = "packed_activity_2021springfestival",
	BattleList = {
		620001,
		620002,
		620003,
		620004,
		620005,
		620006,
		620007,
		620008,
		620009,
		620010,
		620011,
		620012,
		620013,
		620014,
		620015,
		620016,
		620017,
		620018,
		620019,
		620020,
	},
	BuildingList = {
		{
			Pos = "BuildingPosUp_1",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_2",
			Prefab = "Building_ClothingStore",
		},
		{
			Pos = "BuildingPosUp_3",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_4",
			Prefab = "fangzi09",
		},
		{
			Pos = "BuildingPosDown_1",
			Prefab = "Building_ExileStreetArena",
		},
		{
			Pos = "BuildingPosDown_2",
			Prefab = "Building_ActivityRoom",
		},
		{
			Pos = "BuildingPosDown_3",
			Prefab = "fangzi03",
		},
		{
			Pos = "BuildingPosDown_4",
			Prefab = "fangzi04",
		},
		{
			Pos = "BuildingPosDown_5",
			Prefab = "fangzi05",
		},
		{
			Pos = "BuildingPosDown_6",
			Prefab = "fangzi05",
		},
	},
	ThemeRoomPrefab = "2021SpringFestival",
	ThemeRoomBundle = "activitythemeroom",
	ThemeRoomCharacter = {
		223067,
		223066,
		223061,
		223062,
		223063,
		223064,
		223065,
	},
	PackageBundle = "Activity_1",
	PackageAtlas = "Activity_1",
	PackageIcon = "ActivityPackage_All_NewYearBeast",
}
ActivityThemeConfig[ActivityThemeID.Id005] =
{
	Id = 5,
	Name = "新年大吉",
	Explore = 630001,
	BattleTitle = "这次一定要回家！",
	TextureBundle = "packed_activity_2021springfestival",
	BattleList = {
		620001,
		620002,
		620003,
		620004,
		620005,
		620006,
		620007,
		620008,
		620009,
		620010,
		620011,
		620012,
		620013,
		620014,
		620015,
		620016,
		620017,
		620018,
		620019,
		620020,
	},
	BuildingList = {
		{
			Pos = "BuildingPosUp_1",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_2",
			Prefab = "Building_ClothingStore",
		},
		{
			Pos = "BuildingPosUp_3",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_4",
			Prefab = "fangzi09",
		},
		{
			Pos = "BuildingPosDown_1",
			Prefab = "Building_ExileStreetArena",
		},
		{
			Pos = "BuildingPosDown_2",
			Prefab = "Building_ActivityRoom",
		},
		{
			Pos = "BuildingPosDown_3",
			Prefab = "fangzi03",
		},
		{
			Pos = "BuildingPosDown_4",
			Prefab = "fangzi04",
		},
		{
			Pos = "BuildingPosDown_5",
			Prefab = "fangzi05",
		},
		{
			Pos = "BuildingPosDown_6",
			Prefab = "fangzi05",
		},
	},
	ThemeRoomPrefab = "2021SpringFestival",
	ThemeRoomBundle = "activitythemeroom",
	ThemeRoomCharacter = {
		223067,
		223066,
		223061,
		223062,
		223063,
		223064,
		223065,
	},
	PackageBundle = "Activity_1",
	PackageAtlas = "Activity_1",
	PackageIcon = "ActivityPackage_All_NewYearBeast",
}
ActivityThemeConfig[ActivityThemeID.Id006] =
{
	Id = 6,
	Name = "新年大吉",
	Explore = 630001,
	BattleTitle = "这次一定要回家！",
	TextureBundle = "packed_activity_2021springfestival",
	BattleList = {
		620001,
		620002,
		620003,
		620004,
		620005,
		620006,
		620007,
		620008,
		620009,
		620010,
		620011,
		620012,
		620013,
		620014,
		620015,
		620016,
		620017,
		620018,
		620019,
		620020,
	},
	BuildingList = {
		{
			Pos = "BuildingPosUp_1",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_2",
			Prefab = "Building_ClothingStore",
		},
		{
			Pos = "BuildingPosUp_3",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_4",
			Prefab = "fangzi09",
		},
		{
			Pos = "BuildingPosDown_1",
			Prefab = "Building_ExileStreetArena",
		},
		{
			Pos = "BuildingPosDown_2",
			Prefab = "Building_ActivityRoom",
		},
		{
			Pos = "BuildingPosDown_3",
			Prefab = "fangzi03",
		},
		{
			Pos = "BuildingPosDown_4",
			Prefab = "fangzi04",
		},
		{
			Pos = "BuildingPosDown_5",
			Prefab = "fangzi05",
		},
		{
			Pos = "BuildingPosDown_6",
			Prefab = "fangzi05",
		},
	},
	ThemeRoomPrefab = "2021SpringFestival",
	ThemeRoomBundle = "activitythemeroom",
	ThemeRoomCharacter = {
		223067,
		223066,
		223061,
		223062,
		223063,
		223064,
		223065,
	},
	PackageBundle = "Activity_1",
	PackageAtlas = "Activity_1",
	PackageIcon = "ActivityPackage_All_NewYearBeast",
}
ActivityThemeConfig[ActivityThemeID.Id007] =
{
	Id = 7,
	Name = "新年大吉",
	Explore = 630001,
	BattleTitle = "这次一定要回家！",
	TextureBundle = "packed_activity_2021springfestival",
	BattleList = {
		620001,
		620002,
		620003,
		620004,
		620005,
		620006,
		620007,
		620008,
		620009,
		620010,
		620011,
		620012,
		620013,
		620014,
		620015,
		620016,
		620017,
		620018,
		620019,
		620020,
	},
	BuildingList = {
		{
			Pos = "BuildingPosUp_1",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_2",
			Prefab = "Building_ClothingStore",
		},
		{
			Pos = "BuildingPosUp_3",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_4",
			Prefab = "fangzi09",
		},
		{
			Pos = "BuildingPosDown_1",
			Prefab = "Building_ExileStreetArena",
		},
		{
			Pos = "BuildingPosDown_2",
			Prefab = "Building_ActivityRoom",
		},
		{
			Pos = "BuildingPosDown_3",
			Prefab = "fangzi03",
		},
		{
			Pos = "BuildingPosDown_4",
			Prefab = "fangzi04",
		},
		{
			Pos = "BuildingPosDown_5",
			Prefab = "fangzi05",
		},
		{
			Pos = "BuildingPosDown_6",
			Prefab = "fangzi05",
		},
	},
	ThemeRoomPrefab = "2021SpringFestival",
	ThemeRoomBundle = "activitythemeroom",
	ThemeRoomCharacter = {
		223067,
		223066,
		223061,
		223062,
		223063,
		223064,
		223065,
	},
	PackageBundle = "Activity_1",
	PackageAtlas = "Activity_1",
	PackageIcon = "ActivityPackage_All_NewYearBeast",
}
ActivityThemeConfig[ActivityThemeID.Id008] =
{
	Id = 8,
	Name = "星际冒险节",
	Explore = 630002,
	BattleTitle = "探索宝箱谷",
	TextureBundle = "packed_activity_staradventure",
	BattleList = {
		620021,
		620022,
		620023,
		620024,
		620025,
		620026,
		620027,
		620028,
		620029,
		620030,
	},
	BuildingList = {
		{
			Pos = "BuildingPosUp_1",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_2",
			Prefab = "Building_ClothingStore",
		},
		{
			Pos = "BuildingPosUp_3",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_4",
			Prefab = "fangzi09",
		},
		{
			Pos = "BuildingPosDown_1",
			Prefab = "Building_ExileStreetArena",
		},
		{
			Pos = "BuildingPosDown_2",
			Prefab = "Building_ActivityRoom",
		},
		{
			Pos = "BuildingPosDown_3",
			Prefab = "fangzi03",
		},
		{
			Pos = "BuildingPosDown_4",
			Prefab = "fangzi04",
		},
		{
			Pos = "BuildingPosDown_5",
			Prefab = "fangzi05",
		},
		{
			Pos = "BuildingPosDown_6",
			Prefab = "fangzi05",
		},
	},
	ThemeRoomPrefab = "StarAdventure",
	ThemeRoomBundle = "activitythemeroom",
	ThemeRoomCharacter = {
		223001,
		223002,
		223003,
		223004,
		223006,
		223007,
		223008,
	},
}
ActivityThemeConfig[ActivityThemeID.Id009] =
{
	Id = 9,
	Name = "星际冒险节",
	Explore = 630002,
	BattleTitle = "探索宝箱谷",
	TextureBundle = "packed_activity_staradventure",
	BattleList = {
		620021,
		620022,
		620023,
		620024,
		620025,
		620026,
		620027,
		620028,
		620029,
		620030,
	},
	BuildingList = {
		{
			Pos = "BuildingPosUp_1",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_2",
			Prefab = "Building_ClothingStore",
		},
		{
			Pos = "BuildingPosUp_3",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_4",
			Prefab = "fangzi09",
		},
		{
			Pos = "BuildingPosDown_1",
			Prefab = "Building_ExileStreetArena",
		},
		{
			Pos = "BuildingPosDown_2",
			Prefab = "Building_ActivityRoom",
		},
		{
			Pos = "BuildingPosDown_3",
			Prefab = "fangzi03",
		},
		{
			Pos = "BuildingPosDown_4",
			Prefab = "fangzi04",
		},
		{
			Pos = "BuildingPosDown_5",
			Prefab = "fangzi05",
		},
		{
			Pos = "BuildingPosDown_6",
			Prefab = "fangzi05",
		},
	},
	ThemeRoomPrefab = "StarAdventure",
	ThemeRoomBundle = "activitythemeroom",
	ThemeRoomCharacter = {
		223001,
		223002,
		223003,
		223004,
		223006,
		223007,
		223008,
	},
}
ActivityThemeConfig[ActivityThemeID.Id010] =
{
	Id = 10,
	Name = "星际冒险节",
	Explore = 630002,
	BattleTitle = "探索宝箱谷",
	TextureBundle = "packed_activity_staradventure",
	BattleList = {
		620021,
		620022,
		620023,
		620024,
		620025,
		620026,
		620027,
		620028,
		620029,
		620030,
	},
	BuildingList = {
		{
			Pos = "BuildingPosUp_1",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_2",
			Prefab = "Building_ClothingStore",
		},
		{
			Pos = "BuildingPosUp_3",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_4",
			Prefab = "fangzi09",
		},
		{
			Pos = "BuildingPosDown_1",
			Prefab = "Building_ExileStreetArena",
		},
		{
			Pos = "BuildingPosDown_2",
			Prefab = "Building_ActivityRoom",
		},
		{
			Pos = "BuildingPosDown_3",
			Prefab = "fangzi03",
		},
		{
			Pos = "BuildingPosDown_4",
			Prefab = "fangzi04",
		},
		{
			Pos = "BuildingPosDown_5",
			Prefab = "fangzi05",
		},
		{
			Pos = "BuildingPosDown_6",
			Prefab = "fangzi05",
		},
	},
	ThemeRoomPrefab = "StarAdventure",
	ThemeRoomBundle = "activitythemeroom",
	ThemeRoomCharacter = {
		223001,
		223002,
		223003,
		223004,
		223006,
		223007,
		223008,
	},
}
ActivityThemeConfig[ActivityThemeID.Id011] =
{
	Id = 11,
	Name = "星际冒险节",
	Explore = 630002,
	BattleTitle = "探索宝箱谷",
	TextureBundle = "packed_activity_staradventure",
	BattleList = {
		620021,
		620022,
		620023,
		620024,
		620025,
		620026,
		620027,
		620028,
		620029,
		620030,
	},
	BuildingList = {
		{
			Pos = "BuildingPosUp_1",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_2",
			Prefab = "Building_ClothingStore",
		},
		{
			Pos = "BuildingPosUp_3",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_4",
			Prefab = "fangzi09",
		},
		{
			Pos = "BuildingPosDown_1",
			Prefab = "Building_ExileStreetArena",
		},
		{
			Pos = "BuildingPosDown_2",
			Prefab = "Building_ActivityRoom",
		},
		{
			Pos = "BuildingPosDown_3",
			Prefab = "fangzi03",
		},
		{
			Pos = "BuildingPosDown_4",
			Prefab = "fangzi04",
		},
		{
			Pos = "BuildingPosDown_5",
			Prefab = "fangzi05",
		},
		{
			Pos = "BuildingPosDown_6",
			Prefab = "fangzi05",
		},
	},
	ThemeRoomPrefab = "StarAdventure",
	ThemeRoomBundle = "activitythemeroom",
	ThemeRoomCharacter = {
		223001,
		223002,
		223003,
		223004,
		223006,
		223007,
		223008,
	},
}
ActivityThemeConfig[ActivityThemeID.Id012] =
{
	Id = 12,
	Name = "星际冒险节",
	Explore = 630002,
	BattleTitle = "探索宝箱谷",
	TextureBundle = "packed_activity_staradventure",
	BattleList = {
		620021,
		620022,
		620023,
		620024,
		620025,
		620026,
		620027,
		620028,
		620029,
		620030,
	},
	BuildingList = {
		{
			Pos = "BuildingPosUp_1",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_2",
			Prefab = "Building_ClothingStore",
		},
		{
			Pos = "BuildingPosUp_3",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_4",
			Prefab = "fangzi09",
		},
		{
			Pos = "BuildingPosDown_1",
			Prefab = "Building_ExileStreetArena",
		},
		{
			Pos = "BuildingPosDown_2",
			Prefab = "Building_ActivityRoom",
		},
		{
			Pos = "BuildingPosDown_3",
			Prefab = "fangzi03",
		},
		{
			Pos = "BuildingPosDown_4",
			Prefab = "fangzi04",
		},
		{
			Pos = "BuildingPosDown_5",
			Prefab = "fangzi05",
		},
		{
			Pos = "BuildingPosDown_6",
			Prefab = "fangzi05",
		},
	},
	ThemeRoomPrefab = "StarAdventure",
	ThemeRoomBundle = "activitythemeroom",
	ThemeRoomCharacter = {
		223001,
		223002,
		223003,
		223004,
		223006,
		223007,
		223008,
	},
}
ActivityThemeConfig[ActivityThemeID.Id013] =
{
	Id = 13,
	Name = "星际冒险节",
	Explore = 630002,
	BattleTitle = "探索宝箱谷",
	TextureBundle = "packed_activity_staradventure",
	BattleList = {
		620021,
		620022,
		620023,
		620024,
		620025,
		620026,
		620027,
		620028,
		620029,
		620030,
	},
	BuildingList = {
		{
			Pos = "BuildingPosUp_1",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_2",
			Prefab = "Building_ClothingStore",
		},
		{
			Pos = "BuildingPosUp_3",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_4",
			Prefab = "fangzi09",
		},
		{
			Pos = "BuildingPosDown_1",
			Prefab = "Building_ExileStreetArena",
		},
		{
			Pos = "BuildingPosDown_2",
			Prefab = "Building_ActivityRoom",
		},
		{
			Pos = "BuildingPosDown_3",
			Prefab = "fangzi03",
		},
		{
			Pos = "BuildingPosDown_4",
			Prefab = "fangzi04",
		},
		{
			Pos = "BuildingPosDown_5",
			Prefab = "fangzi05",
		},
		{
			Pos = "BuildingPosDown_6",
			Prefab = "fangzi05",
		},
	},
	ThemeRoomPrefab = "StarAdventure",
	ThemeRoomBundle = "activitythemeroom",
	ThemeRoomCharacter = {
		223001,
		223002,
		223003,
		223004,
		223006,
		223007,
		223008,
	},
}
ActivityThemeConfig[ActivityThemeID.Id014] =
{
	Id = 14,
	Name = "黑料试胆大会",
	Explore = 630003,
	BattleTitle = "探索小吃街",
	TextureBundle = "packed_activity_darkfoodfestival",
	BattleList = {
		620031,
		620032,
		620033,
		620034,
		620035,
		620036,
		620037,
		620038,
		620039,
		620040,
	},
	BuildingList = {
		{
			Pos = "BuildingPosUp_1",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_2",
			Prefab = "Building_ClothingStore",
		},
		{
			Pos = "BuildingPosUp_3",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_4",
			Prefab = "fangzi09",
		},
		{
			Pos = "BuildingPosDown_1",
			Prefab = "Building_ExileStreetArena",
		},
		{
			Pos = "BuildingPosDown_2",
			Prefab = "Building_ActivityRoom",
		},
		{
			Pos = "BuildingPosDown_3",
			Prefab = "fangzi03",
		},
		{
			Pos = "BuildingPosDown_4",
			Prefab = "fangzi04",
		},
		{
			Pos = "BuildingPosDown_5",
			Prefab = "fangzi05",
		},
		{
			Pos = "BuildingPosDown_6",
			Prefab = "fangzi05",
		},
	},
	ThemeRoomPrefab = "darkfoodfestival",
	ThemeRoomBundle = "activitythemeroom",
	ThemeRoomCharacter = {
		223101,
		223102,
		223103,
		223104,
		223105,
		223106,
		223107,
	},
	PackageBundle = "Activity_1",
	PackageAtlas = "Activity_1",
	PackageIcon = "ActivityPackage_All_NewYearBeast",
}
ActivityThemeConfig[ActivityThemeID.Id015] =
{
	Id = 15,
	Name = "黑料试胆大会",
	Explore = 630003,
	BattleTitle = "探索小吃街",
	TextureBundle = "packed_activity_darkfoodfestival",
	BattleList = {
		620031,
		620032,
		620033,
		620034,
		620035,
		620036,
		620037,
		620038,
		620039,
		620040,
	},
	BuildingList = {
		{
			Pos = "BuildingPosUp_1",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_2",
			Prefab = "Building_ClothingStore",
		},
		{
			Pos = "BuildingPosUp_3",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_4",
			Prefab = "fangzi09",
		},
		{
			Pos = "BuildingPosDown_1",
			Prefab = "Building_ExileStreetArena",
		},
		{
			Pos = "BuildingPosDown_2",
			Prefab = "Building_ActivityRoom",
		},
		{
			Pos = "BuildingPosDown_3",
			Prefab = "fangzi03",
		},
		{
			Pos = "BuildingPosDown_4",
			Prefab = "fangzi04",
		},
		{
			Pos = "BuildingPosDown_5",
			Prefab = "fangzi05",
		},
		{
			Pos = "BuildingPosDown_6",
			Prefab = "fangzi05",
		},
	},
	ThemeRoomPrefab = "darkfoodfestival",
	ThemeRoomBundle = "activitythemeroom",
	ThemeRoomCharacter = {
		223101,
		223102,
		223103,
		223104,
		223105,
		223106,
		223107,
	},
	PackageBundle = "Activity_1",
	PackageAtlas = "Activity_1",
	PackageIcon = "ActivityPackage_All_NewYearBeast",
}
ActivityThemeConfig[ActivityThemeID.Id016] =
{
	Id = 16,
	Name = "黑料试胆大会",
	Explore = 630003,
	BattleTitle = "探索小吃街",
	TextureBundle = "packed_activity_darkfoodfestival",
	BattleList = {
		620031,
		620032,
		620033,
		620034,
		620035,
		620036,
		620037,
		620038,
		620039,
		620040,
	},
	BuildingList = {
		{
			Pos = "BuildingPosUp_1",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_2",
			Prefab = "Building_ClothingStore",
		},
		{
			Pos = "BuildingPosUp_3",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_4",
			Prefab = "fangzi09",
		},
		{
			Pos = "BuildingPosDown_1",
			Prefab = "Building_ExileStreetArena",
		},
		{
			Pos = "BuildingPosDown_2",
			Prefab = "Building_ActivityRoom",
		},
		{
			Pos = "BuildingPosDown_3",
			Prefab = "fangzi03",
		},
		{
			Pos = "BuildingPosDown_4",
			Prefab = "fangzi04",
		},
		{
			Pos = "BuildingPosDown_5",
			Prefab = "fangzi05",
		},
		{
			Pos = "BuildingPosDown_6",
			Prefab = "fangzi05",
		},
	},
	ThemeRoomPrefab = "darkfoodfestival",
	ThemeRoomBundle = "activitythemeroom",
	ThemeRoomCharacter = {
		223101,
		223102,
		223103,
		223104,
		223105,
		223106,
		223107,
	},
	PackageBundle = "Activity_1",
	PackageAtlas = "Activity_1",
	PackageIcon = "ActivityPackage_All_NewYearBeast",
}
ActivityThemeConfig[ActivityThemeID.Id017] =
{
	Id = 17,
	Name = "黑料试胆大会",
	Explore = 630003,
	BattleTitle = "探索小吃街",
	TextureBundle = "packed_activity_darkfoodfestival",
	BattleList = {
		620031,
		620032,
		620033,
		620034,
		620035,
		620036,
		620037,
		620038,
		620039,
		620040,
	},
	BuildingList = {
		{
			Pos = "BuildingPosUp_1",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_2",
			Prefab = "Building_ClothingStore",
		},
		{
			Pos = "BuildingPosUp_3",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_4",
			Prefab = "fangzi09",
		},
		{
			Pos = "BuildingPosDown_1",
			Prefab = "Building_ExileStreetArena",
		},
		{
			Pos = "BuildingPosDown_2",
			Prefab = "Building_ActivityRoom",
		},
		{
			Pos = "BuildingPosDown_3",
			Prefab = "fangzi03",
		},
		{
			Pos = "BuildingPosDown_4",
			Prefab = "fangzi04",
		},
		{
			Pos = "BuildingPosDown_5",
			Prefab = "fangzi05",
		},
		{
			Pos = "BuildingPosDown_6",
			Prefab = "fangzi05",
		},
	},
	ThemeRoomPrefab = "darkfoodfestival",
	ThemeRoomBundle = "activitythemeroom",
	ThemeRoomCharacter = {
		223101,
		223102,
		223103,
		223104,
		223105,
		223106,
		223107,
	},
	PackageBundle = "Activity_1",
	PackageAtlas = "Activity_1",
	PackageIcon = "ActivityPackage_All_NewYearBeast",
}
ActivityThemeConfig[ActivityThemeID.Id018] =
{
	Id = 18,
	Name = "黑料试胆大会",
	Explore = 630003,
	BattleTitle = "探索小吃街",
	TextureBundle = "packed_activity_darkfoodfestival",
	BattleList = {
		620031,
		620032,
		620033,
		620034,
		620035,
		620036,
		620037,
		620038,
		620039,
		620040,
	},
	BuildingList = {
		{
			Pos = "BuildingPosUp_1",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_2",
			Prefab = "Building_ClothingStore",
		},
		{
			Pos = "BuildingPosUp_3",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_4",
			Prefab = "fangzi09",
		},
		{
			Pos = "BuildingPosDown_1",
			Prefab = "Building_ExileStreetArena",
		},
		{
			Pos = "BuildingPosDown_2",
			Prefab = "Building_ActivityRoom",
		},
		{
			Pos = "BuildingPosDown_3",
			Prefab = "fangzi03",
		},
		{
			Pos = "BuildingPosDown_4",
			Prefab = "fangzi04",
		},
		{
			Pos = "BuildingPosDown_5",
			Prefab = "fangzi05",
		},
		{
			Pos = "BuildingPosDown_6",
			Prefab = "fangzi05",
		},
	},
	ThemeRoomPrefab = "darkfoodfestival",
	ThemeRoomBundle = "activitythemeroom",
	ThemeRoomCharacter = {
		223101,
		223102,
		223103,
		223104,
		223105,
		223106,
		223107,
	},
	PackageBundle = "Activity_1",
	PackageAtlas = "Activity_1",
	PackageIcon = "ActivityPackage_All_NewYearBeast",
}
ActivityThemeConfig[ActivityThemeID.Id019] =
{
	Id = 19,
	Name = "黑料试胆大会",
	Explore = 630003,
	BattleTitle = "探索小吃街",
	TextureBundle = "packed_activity_darkfoodfestival",
	BattleList = {
		620031,
		620032,
		620033,
		620034,
		620035,
		620036,
		620037,
		620038,
		620039,
		620040,
	},
	BuildingList = {
		{
			Pos = "BuildingPosUp_1",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_2",
			Prefab = "Building_ClothingStore",
		},
		{
			Pos = "BuildingPosUp_3",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_4",
			Prefab = "fangzi09",
		},
		{
			Pos = "BuildingPosDown_1",
			Prefab = "Building_ExileStreetArena",
		},
		{
			Pos = "BuildingPosDown_2",
			Prefab = "Building_ActivityRoom",
		},
		{
			Pos = "BuildingPosDown_3",
			Prefab = "fangzi03",
		},
		{
			Pos = "BuildingPosDown_4",
			Prefab = "fangzi04",
		},
		{
			Pos = "BuildingPosDown_5",
			Prefab = "fangzi05",
		},
		{
			Pos = "BuildingPosDown_6",
			Prefab = "fangzi05",
		},
	},
	ThemeRoomPrefab = "darkfoodfestival",
	ThemeRoomBundle = "activitythemeroom",
	ThemeRoomCharacter = {
		223101,
		223102,
		223103,
		223104,
		223105,
		223106,
		223107,
	},
	PackageBundle = "Activity_1",
	PackageAtlas = "Activity_1",
	PackageIcon = "ActivityPackage_All_NewYearBeast",
}
ActivityThemeConfig[ActivityThemeID.Id020] =
{
	Id = 20,
	Name = "星际龙舟赛",
	Explore = 630004,
	BattleTitle = "探索龙舟公园",
	TextureBundle = "packed_activity_dragonboatfestival",
	BattleList = {
		620041,
		620042,
		620043,
		620044,
		620045,
		620046,
		620047,
		620048,
		620049,
		620050,
	},
	BuildingList = {
		{
			Pos = "BuildingPosUp_1",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_2",
			Prefab = "Building_ClothingStore",
		},
		{
			Pos = "BuildingPosUp_3",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_4",
			Prefab = "fangzi09",
		},
		{
			Pos = "BuildingPosDown_1",
			Prefab = "Building_ExileStreetArena",
		},
		{
			Pos = "BuildingPosDown_2",
			Prefab = "Building_ActivityRoom",
		},
		{
			Pos = "BuildingPosDown_3",
			Prefab = "fangzi03",
		},
		{
			Pos = "BuildingPosDown_4",
			Prefab = "fangzi04",
		},
		{
			Pos = "BuildingPosDown_5",
			Prefab = "fangzi05",
		},
		{
			Pos = "BuildingPosDown_6",
			Prefab = "fangzi05",
		},
	},
	ThemeRoomPrefab = "dragonboatfestival",
	ThemeRoomBundle = "activitythemeroom",
	ThemeRoomCharacter = {
		223124,
		223125,
		223129,
		223126,
		223127,
		223127,
		223128,
	},
	PackageBundle = "Activity_1",
	PackageAtlas = "Activity_1",
	PackageIcon = "ActivityPackage_All_NewYearBeast",
}
ActivityThemeConfig[ActivityThemeID.Id021] =
{
	Id = 21,
	Name = "星际龙舟赛",
	Explore = 630004,
	BattleTitle = "探索龙舟公园",
	TextureBundle = "packed_activity_dragonboatfestival",
	BattleList = {
		620041,
		620042,
		620043,
		620044,
		620045,
		620046,
		620047,
		620048,
		620049,
		620050,
	},
	BuildingList = {
		{
			Pos = "BuildingPosUp_1",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_2",
			Prefab = "Building_ClothingStore",
		},
		{
			Pos = "BuildingPosUp_3",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_4",
			Prefab = "fangzi09",
		},
		{
			Pos = "BuildingPosDown_1",
			Prefab = "Building_ExileStreetArena",
		},
		{
			Pos = "BuildingPosDown_2",
			Prefab = "Building_ActivityRoom",
		},
		{
			Pos = "BuildingPosDown_3",
			Prefab = "fangzi03",
		},
		{
			Pos = "BuildingPosDown_4",
			Prefab = "fangzi04",
		},
		{
			Pos = "BuildingPosDown_5",
			Prefab = "fangzi05",
		},
		{
			Pos = "BuildingPosDown_6",
			Prefab = "fangzi05",
		},
	},
	ThemeRoomPrefab = "dragonboatfestival",
	ThemeRoomBundle = "activitythemeroom",
	ThemeRoomCharacter = {
		223124,
		223125,
		223129,
		223126,
		223127,
		223127,
		223128,
	},
	PackageBundle = "Activity_1",
	PackageAtlas = "Activity_1",
	PackageIcon = "ActivityPackage_All_NewYearBeast",
}
ActivityThemeConfig[ActivityThemeID.Id022] =
{
	Id = 22,
	Name = "星际龙舟赛",
	Explore = 630004,
	BattleTitle = "探索龙舟公园",
	TextureBundle = "packed_activity_dragonboatfestival",
	BattleList = {
		620041,
		620042,
		620043,
		620044,
		620045,
		620046,
		620047,
		620048,
		620049,
		620050,
	},
	BuildingList = {
		{
			Pos = "BuildingPosUp_1",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_2",
			Prefab = "Building_ClothingStore",
		},
		{
			Pos = "BuildingPosUp_3",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_4",
			Prefab = "fangzi09",
		},
		{
			Pos = "BuildingPosDown_1",
			Prefab = "Building_ExileStreetArena",
		},
		{
			Pos = "BuildingPosDown_2",
			Prefab = "Building_ActivityRoom",
		},
		{
			Pos = "BuildingPosDown_3",
			Prefab = "fangzi03",
		},
		{
			Pos = "BuildingPosDown_4",
			Prefab = "fangzi04",
		},
		{
			Pos = "BuildingPosDown_5",
			Prefab = "fangzi05",
		},
		{
			Pos = "BuildingPosDown_6",
			Prefab = "fangzi05",
		},
	},
	ThemeRoomPrefab = "dragonboatfestival",
	ThemeRoomBundle = "activitythemeroom",
	ThemeRoomCharacter = {
		223124,
		223125,
		223129,
		223126,
		223127,
		223127,
		223128,
	},
	PackageBundle = "Activity_1",
	PackageAtlas = "Activity_1",
	PackageIcon = "ActivityPackage_All_NewYearBeast",
}
ActivityThemeConfig[ActivityThemeID.Id023] =
{
	Id = 23,
	Name = "星际龙舟赛",
	Explore = 630004,
	BattleTitle = "探索龙舟公园",
	TextureBundle = "packed_activity_dragonboatfestival",
	BattleList = {
		620041,
		620042,
		620043,
		620044,
		620045,
		620046,
		620047,
		620048,
		620049,
		620050,
	},
	BuildingList = {
		{
			Pos = "BuildingPosUp_1",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_2",
			Prefab = "Building_ClothingStore",
		},
		{
			Pos = "BuildingPosUp_3",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_4",
			Prefab = "fangzi09",
		},
		{
			Pos = "BuildingPosDown_1",
			Prefab = "Building_ExileStreetArena",
		},
		{
			Pos = "BuildingPosDown_2",
			Prefab = "Building_ActivityRoom",
		},
		{
			Pos = "BuildingPosDown_3",
			Prefab = "fangzi03",
		},
		{
			Pos = "BuildingPosDown_4",
			Prefab = "fangzi04",
		},
		{
			Pos = "BuildingPosDown_5",
			Prefab = "fangzi05",
		},
		{
			Pos = "BuildingPosDown_6",
			Prefab = "fangzi05",
		},
	},
	ThemeRoomPrefab = "dragonboatfestival",
	ThemeRoomBundle = "activitythemeroom",
	ThemeRoomCharacter = {
		223124,
		223125,
		223129,
		223126,
		223127,
		223127,
		223128,
	},
	PackageBundle = "Activity_1",
	PackageAtlas = "Activity_1",
	PackageIcon = "ActivityPackage_All_NewYearBeast",
}
ActivityThemeConfig[ActivityThemeID.Id024] =
{
	Id = 24,
	Name = "星际龙舟赛",
	Explore = 630004,
	BattleTitle = "探索龙舟公园",
	TextureBundle = "packed_activity_dragonboatfestival",
	BattleList = {
		620041,
		620042,
		620043,
		620044,
		620045,
		620046,
		620047,
		620048,
		620049,
		620050,
	},
	BuildingList = {
		{
			Pos = "BuildingPosUp_1",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_2",
			Prefab = "Building_ClothingStore",
		},
		{
			Pos = "BuildingPosUp_3",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_4",
			Prefab = "fangzi09",
		},
		{
			Pos = "BuildingPosDown_1",
			Prefab = "Building_ExileStreetArena",
		},
		{
			Pos = "BuildingPosDown_2",
			Prefab = "Building_ActivityRoom",
		},
		{
			Pos = "BuildingPosDown_3",
			Prefab = "fangzi03",
		},
		{
			Pos = "BuildingPosDown_4",
			Prefab = "fangzi04",
		},
		{
			Pos = "BuildingPosDown_5",
			Prefab = "fangzi05",
		},
		{
			Pos = "BuildingPosDown_6",
			Prefab = "fangzi05",
		},
	},
	ThemeRoomPrefab = "dragonboatfestival",
	ThemeRoomBundle = "activitythemeroom",
	ThemeRoomCharacter = {
		223124,
		223125,
		223129,
		223126,
		223127,
		223127,
		223128,
	},
	PackageBundle = "Activity_1",
	PackageAtlas = "Activity_1",
	PackageIcon = "ActivityPackage_All_NewYearBeast",
}
ActivityThemeConfig[ActivityThemeID.Id025] =
{
	Id = 25,
	Name = "星际龙舟赛",
	Explore = 630004,
	BattleTitle = "探索龙舟公园",
	TextureBundle = "packed_activity_dragonboatfestival",
	BattleList = {
		620041,
		620042,
		620043,
		620044,
		620045,
		620046,
		620047,
		620048,
		620049,
		620050,
	},
	BuildingList = {
		{
			Pos = "BuildingPosUp_1",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_2",
			Prefab = "Building_ClothingStore",
		},
		{
			Pos = "BuildingPosUp_3",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_4",
			Prefab = "fangzi09",
		},
		{
			Pos = "BuildingPosDown_1",
			Prefab = "Building_ExileStreetArena",
		},
		{
			Pos = "BuildingPosDown_2",
			Prefab = "Building_ActivityRoom",
		},
		{
			Pos = "BuildingPosDown_3",
			Prefab = "fangzi03",
		},
		{
			Pos = "BuildingPosDown_4",
			Prefab = "fangzi04",
		},
		{
			Pos = "BuildingPosDown_5",
			Prefab = "fangzi05",
		},
		{
			Pos = "BuildingPosDown_6",
			Prefab = "fangzi05",
		},
	},
	ThemeRoomPrefab = "dragonboatfestival",
	ThemeRoomBundle = "activitythemeroom",
	ThemeRoomCharacter = {
		223124,
		223125,
		223129,
		223126,
		223127,
		223127,
		223128,
	},
	PackageBundle = "Activity_1",
	PackageAtlas = "Activity_1",
	PackageIcon = "ActivityPackage_All_NewYearBeast",
}
ActivityThemeConfig[ActivityThemeID.Id026] =
{
	Id = 26,
	Name = "夏日庙会",
	Explore = 630005,
	BattleTitle = "探索庙会街",
	TextureBundle = "packed_activity_templefairfestival",
	ActivityBGM = "BGM_CatchFish",
	BattleList = {
		620051,
		620052,
		620053,
		620054,
		620055,
		620056,
		620057,
		620058,
		620059,
		620060,
	},
	BuildingList = {
		{
			Pos = "BuildingPosUp_1",
			Prefab = "Building_ActivityLevelMap",
		},
		{
			Pos = "BuildingPosUp_2",
			Prefab = "Building_ClothingStore",
		},
		{
			Pos = "BuildingPosUp_3",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_4",
			Prefab = "fangzi09",
		},
		{
			Pos = "BuildingPosDown_1",
			Prefab = "Building_ExileStreetArena",
		},
		{
			Pos = "BuildingPosDown_2",
			Prefab = "Building_ActivityRoom",
		},
		{
			Pos = "BuildingPosDown_3",
			Prefab = "fangzi03",
		},
		{
			Pos = "BuildingPosDown_4",
			Prefab = "fangzi04",
		},
		{
			Pos = "BuildingPosDown_5",
			Prefab = "fangzi05",
		},
		{
			Pos = "BuildingPosDown_6",
			Prefab = "fangzi05",
		},
	},
	ThemeRoomPrefab = "templefairfestival",
	ThemeRoomBundle = "activitythemeroom",
	ThemeRoomCharacter = {
		223131,
		223132,
		223133,
		223134,
		223135,
		223136,
	},
	ActivityDailyLoginList = {
		580001,
		580002,
		580003,
		580004,
		580005,
		580006,
		580007,
		580008,
		580009,
		580010,
		580011,
		580012,
		580013,
		580014,
		580015,
		580016,
		580017,
		580018,
		580019,
		580020,
		580021,
		580022,
		580023,
		580024,
		580025,
	},
	ActivityGameModule = 1,
	ActivityPassCheck = {
		Name  = "庙会好运符",
		Desc  = "购买后，就能在庙会活动中获得神明的青睐。\n购买后立刻获得680玉璧\n每日活动签到可额外获得金鱼票及玉璧\n解锁捞金鱼比赛特殊奖励\n捞金鱼比赛挑战模式中入场消耗-50%",
		ButtonText  = "68元购买",
		IAPId  = 700008,
		ExtraActivityDailyLogin  = {
			{
				Value = 2,
				Num = 100,
			},
			{
				Value = 327314,
				Num = 10,
			},
		},
	},
}
ActivityThemeConfig[ActivityThemeID.Id027] =
{
	Id = 27,
	Name = "夏日庙会",
	Explore = 630005,
	BattleTitle = "探索庙会街",
	TextureBundle = "packed_activity_templefairfestival",
	ActivityBGM = "BGM_CatchFish",
	BattleList = {
		620051,
		620052,
		620053,
		620054,
		620055,
		620056,
		620057,
		620058,
		620059,
		620060,
	},
	BuildingList = {
		{
			Pos = "BuildingPosUp_1",
			Prefab = "Building_ActivityLevelMap",
		},
		{
			Pos = "BuildingPosUp_2",
			Prefab = "Building_ClothingStore",
		},
		{
			Pos = "BuildingPosUp_3",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_4",
			Prefab = "fangzi09",
		},
		{
			Pos = "BuildingPosDown_1",
			Prefab = "Building_ExileStreetArena",
		},
		{
			Pos = "BuildingPosDown_2",
			Prefab = "Building_ActivityRoom",
		},
		{
			Pos = "BuildingPosDown_3",
			Prefab = "fangzi03",
		},
		{
			Pos = "BuildingPosDown_4",
			Prefab = "fangzi04",
		},
		{
			Pos = "BuildingPosDown_5",
			Prefab = "fangzi05",
		},
		{
			Pos = "BuildingPosDown_6",
			Prefab = "fangzi05",
		},
	},
	ThemeRoomPrefab = "templefairfestival",
	ThemeRoomBundle = "activitythemeroom",
	ThemeRoomCharacter = {
		223131,
		223132,
		223133,
		223134,
		223135,
		223136,
	},
	ActivityGameModule = 1,
}
ActivityThemeConfig[ActivityThemeID.Id028] =
{
	Id = 28,
	Name = "夏日庙会",
	Explore = 630005,
	BattleTitle = "探索庙会街",
	TextureBundle = "packed_activity_templefairfestival",
	ActivityBGM = "BGM_CatchFish",
	BattleList = {
		620051,
		620052,
		620053,
		620054,
		620055,
		620056,
		620057,
		620058,
		620059,
		620060,
	},
	BuildingList = {
		{
			Pos = "BuildingPosUp_1",
			Prefab = "Building_ActivityLevelMap",
		},
		{
			Pos = "BuildingPosUp_2",
			Prefab = "Building_ClothingStore",
		},
		{
			Pos = "BuildingPosUp_3",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_4",
			Prefab = "fangzi09",
		},
		{
			Pos = "BuildingPosDown_1",
			Prefab = "Building_ExileStreetArena",
		},
		{
			Pos = "BuildingPosDown_2",
			Prefab = "Building_ActivityRoom",
		},
		{
			Pos = "BuildingPosDown_3",
			Prefab = "fangzi03",
		},
		{
			Pos = "BuildingPosDown_4",
			Prefab = "fangzi04",
		},
		{
			Pos = "BuildingPosDown_5",
			Prefab = "fangzi05",
		},
		{
			Pos = "BuildingPosDown_6",
			Prefab = "fangzi05",
		},
	},
	ThemeRoomPrefab = "templefairfestival",
	ThemeRoomBundle = "activitythemeroom",
	ThemeRoomCharacter = {
		223131,
		223132,
		223133,
		223134,
		223135,
		223136,
	},
	ActivityGameModule = 1,
}
ActivityThemeConfig[ActivityThemeID.Id029] =
{
	Id = 29,
	Name = "夏日庙会",
	Explore = 630005,
	BattleTitle = "探索庙会街",
	TextureBundle = "packed_activity_templefairfestival",
	ActivityBGM = "BGM_CatchFish",
	BattleList = {
		620051,
		620052,
		620053,
		620054,
		620055,
		620056,
		620057,
		620058,
		620059,
		620060,
	},
	BuildingList = {
		{
			Pos = "BuildingPosUp_1",
			Prefab = "Building_ActivityLevelMap",
		},
		{
			Pos = "BuildingPosUp_2",
			Prefab = "Building_ClothingStore",
		},
		{
			Pos = "BuildingPosUp_3",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_4",
			Prefab = "fangzi09",
		},
		{
			Pos = "BuildingPosDown_1",
			Prefab = "Building_ExileStreetArena",
		},
		{
			Pos = "BuildingPosDown_2",
			Prefab = "Building_ActivityRoom",
		},
		{
			Pos = "BuildingPosDown_3",
			Prefab = "fangzi03",
		},
		{
			Pos = "BuildingPosDown_4",
			Prefab = "fangzi04",
		},
		{
			Pos = "BuildingPosDown_5",
			Prefab = "fangzi05",
		},
		{
			Pos = "BuildingPosDown_6",
			Prefab = "fangzi05",
		},
	},
	ThemeRoomPrefab = "templefairfestival",
	ThemeRoomBundle = "activitythemeroom",
	ThemeRoomCharacter = {
		223131,
		223132,
		223133,
		223134,
		223135,
		223136,
	},
	ActivityGameModule = 1,
}
ActivityThemeConfig[ActivityThemeID.Id030] =
{
	Id = 30,
	Name = "夏日庙会",
	Explore = 630005,
	BattleTitle = "探索庙会街",
	TextureBundle = "packed_activity_templefairfestival",
	ActivityBGM = "BGM_CatchFish",
	BattleList = {
		620051,
		620052,
		620053,
		620054,
		620055,
		620056,
		620057,
		620058,
		620059,
		620060,
	},
	BuildingList = {
		{
			Pos = "BuildingPosUp_1",
			Prefab = "Building_ActivityLevelMap",
		},
		{
			Pos = "BuildingPosUp_2",
			Prefab = "Building_ClothingStore",
		},
		{
			Pos = "BuildingPosUp_3",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_4",
			Prefab = "fangzi09",
		},
		{
			Pos = "BuildingPosDown_1",
			Prefab = "Building_ExileStreetArena",
		},
		{
			Pos = "BuildingPosDown_2",
			Prefab = "Building_ActivityRoom",
		},
		{
			Pos = "BuildingPosDown_3",
			Prefab = "fangzi03",
		},
		{
			Pos = "BuildingPosDown_4",
			Prefab = "fangzi04",
		},
		{
			Pos = "BuildingPosDown_5",
			Prefab = "fangzi05",
		},
		{
			Pos = "BuildingPosDown_6",
			Prefab = "fangzi05",
		},
	},
	ThemeRoomPrefab = "templefairfestival",
	ThemeRoomBundle = "activitythemeroom",
	ThemeRoomCharacter = {
		223131,
		223132,
		223133,
		223134,
		223135,
		223136,
	},
	ActivityGameModule = 1,
}
ActivityThemeConfig[ActivityThemeID.Id031] =
{
	Id = 31,
	Name = "夏日庙会",
	Explore = 630005,
	BattleTitle = "探索庙会街",
	TextureBundle = "packed_activity_templefairfestival",
	ActivityBGM = "BGM_CatchFish",
	BattleList = {
		620051,
		620052,
		620053,
		620054,
		620055,
		620056,
		620057,
		620058,
		620059,
		620060,
	},
	BuildingList = {
		{
			Pos = "BuildingPosUp_1",
			Prefab = "Building_ActivityLevelMap",
		},
		{
			Pos = "BuildingPosUp_2",
			Prefab = "Building_ClothingStore",
		},
		{
			Pos = "BuildingPosUp_3",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_4",
			Prefab = "fangzi09",
		},
		{
			Pos = "BuildingPosDown_1",
			Prefab = "Building_ExileStreetArena",
		},
		{
			Pos = "BuildingPosDown_2",
			Prefab = "Building_ActivityRoom",
		},
		{
			Pos = "BuildingPosDown_3",
			Prefab = "fangzi03",
		},
		{
			Pos = "BuildingPosDown_4",
			Prefab = "fangzi04",
		},
		{
			Pos = "BuildingPosDown_5",
			Prefab = "fangzi05",
		},
		{
			Pos = "BuildingPosDown_6",
			Prefab = "fangzi05",
		},
	},
	ThemeRoomPrefab = "templefairfestival",
	ThemeRoomBundle = "activitythemeroom",
	ThemeRoomCharacter = {
		223131,
		223132,
		223133,
		223134,
		223135,
		223136,
	},
	ActivityGameModule = 1,
}
ActivityThemeConfig[ActivityThemeID.Id032] =
{
	Id = 32,
	Name = "2021中秋",
	ActivityBGM = "BGM_2021MidAutumn",
	BuildingList = {
		{
			Pos = "BuildingPosUp_1",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_2",
			Prefab = "Building_ClothingStore",
		},
		{
			Pos = "BuildingPosUp_3",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_4",
			Prefab = "fangzi09",
		},
		{
			Pos = "BuildingPosDown_1",
			Prefab = "Building_ExileStreetArena",
		},
		{
			Pos = "BuildingPosDown_2",
			Prefab = "Building_ActivityRoom",
		},
		{
			Pos = "BuildingPosDown_3",
			Prefab = "fangzi03",
		},
		{
			Pos = "BuildingPosDown_4",
			Prefab = "fangzi04",
		},
		{
			Pos = "BuildingPosDown_5",
			Prefab = "fangzi05",
		},
		{
			Pos = "BuildingPosDown_6",
			Prefab = "fangzi05",
		},
	},
	ActivityGameModule = 2,
	ActivityHideSeekId = 880001,
}
ActivityThemeConfig[ActivityThemeID.Id033] =
{
	Id = 33,
	Name = "2021中秋",
	ActivityBGM = "BGM_2022MidAutumn",
	BuildingList = {
		{
			Pos = "BuildingPosUp_1",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_2",
			Prefab = "Building_ClothingStore",
		},
		{
			Pos = "BuildingPosUp_3",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_4",
			Prefab = "fangzi09",
		},
		{
			Pos = "BuildingPosDown_1",
			Prefab = "Building_ExileStreetArena",
		},
		{
			Pos = "BuildingPosDown_2",
			Prefab = "Building_ActivityRoom",
		},
		{
			Pos = "BuildingPosDown_3",
			Prefab = "fangzi03",
		},
		{
			Pos = "BuildingPosDown_4",
			Prefab = "fangzi04",
		},
		{
			Pos = "BuildingPosDown_5",
			Prefab = "fangzi05",
		},
		{
			Pos = "BuildingPosDown_6",
			Prefab = "fangzi05",
		},
	},
	ActivityGameModule = 2,
	ActivityHideSeekId = 880001,
}
ActivityThemeConfig[ActivityThemeID.Id034] =
{
	Id = 34,
	Name = "2021中秋",
	ActivityBGM = "BGM_2023MidAutumn",
	BuildingList = {
		{
			Pos = "BuildingPosUp_1",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_2",
			Prefab = "Building_ClothingStore",
		},
		{
			Pos = "BuildingPosUp_3",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_4",
			Prefab = "fangzi09",
		},
		{
			Pos = "BuildingPosDown_1",
			Prefab = "Building_ExileStreetArena",
		},
		{
			Pos = "BuildingPosDown_2",
			Prefab = "Building_ActivityRoom",
		},
		{
			Pos = "BuildingPosDown_3",
			Prefab = "fangzi03",
		},
		{
			Pos = "BuildingPosDown_4",
			Prefab = "fangzi04",
		},
		{
			Pos = "BuildingPosDown_5",
			Prefab = "fangzi05",
		},
		{
			Pos = "BuildingPosDown_6",
			Prefab = "fangzi05",
		},
	},
	ActivityGameModule = 2,
	ActivityHideSeekId = 880001,
}
ActivityThemeConfig[ActivityThemeID.Id035] =
{
	Id = 35,
	Name = "2021中秋",
	ActivityBGM = "BGM_2024MidAutumn",
	BuildingList = {
		{
			Pos = "BuildingPosUp_1",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_2",
			Prefab = "Building_ClothingStore",
		},
		{
			Pos = "BuildingPosUp_3",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_4",
			Prefab = "fangzi09",
		},
		{
			Pos = "BuildingPosDown_1",
			Prefab = "Building_ExileStreetArena",
		},
		{
			Pos = "BuildingPosDown_2",
			Prefab = "Building_ActivityRoom",
		},
		{
			Pos = "BuildingPosDown_3",
			Prefab = "fangzi03",
		},
		{
			Pos = "BuildingPosDown_4",
			Prefab = "fangzi04",
		},
		{
			Pos = "BuildingPosDown_5",
			Prefab = "fangzi05",
		},
		{
			Pos = "BuildingPosDown_6",
			Prefab = "fangzi05",
		},
	},
	ActivityGameModule = 2,
	ActivityHideSeekId = 880001,
}
ActivityThemeConfig[ActivityThemeID.Id036] =
{
	Id = 36,
	Name = "2021中秋",
	ActivityBGM = "BGM_2025MidAutumn",
	BuildingList = {
		{
			Pos = "BuildingPosUp_1",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_2",
			Prefab = "Building_ClothingStore",
		},
		{
			Pos = "BuildingPosUp_3",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_4",
			Prefab = "fangzi09",
		},
		{
			Pos = "BuildingPosDown_1",
			Prefab = "Building_ExileStreetArena",
		},
		{
			Pos = "BuildingPosDown_2",
			Prefab = "Building_ActivityRoom",
		},
		{
			Pos = "BuildingPosDown_3",
			Prefab = "fangzi03",
		},
		{
			Pos = "BuildingPosDown_4",
			Prefab = "fangzi04",
		},
		{
			Pos = "BuildingPosDown_5",
			Prefab = "fangzi05",
		},
		{
			Pos = "BuildingPosDown_6",
			Prefab = "fangzi05",
		},
	},
	ActivityGameModule = 2,
	ActivityHideSeekId = 880001,
}
ActivityThemeConfig[ActivityThemeID.Id037] =
{
	Id = 37,
	Name = "2021中秋",
	ActivityBGM = "BGM_2026MidAutumn",
	BuildingList = {
		{
			Pos = "BuildingPosUp_1",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_2",
			Prefab = "Building_ClothingStore",
		},
		{
			Pos = "BuildingPosUp_3",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_4",
			Prefab = "fangzi09",
		},
		{
			Pos = "BuildingPosDown_1",
			Prefab = "Building_ExileStreetArena",
		},
		{
			Pos = "BuildingPosDown_2",
			Prefab = "Building_ActivityRoom",
		},
		{
			Pos = "BuildingPosDown_3",
			Prefab = "fangzi03",
		},
		{
			Pos = "BuildingPosDown_4",
			Prefab = "fangzi04",
		},
		{
			Pos = "BuildingPosDown_5",
			Prefab = "fangzi05",
		},
		{
			Pos = "BuildingPosDown_6",
			Prefab = "fangzi05",
		},
	},
	ActivityGameModule = 2,
	ActivityHideSeekId = 880001,
}
ActivityThemeConfig[ActivityThemeID.Id038] =
{
	Id = 38,
	Name = "黑料试胆大会",
	Explore = 630003,
	BattleTitle = "探索小吃街",
	TextureBundle = "packed_activity_darkfoodfestival",
	ActivityBGM = "BGM_Halloween",
	BattleList = {
		620031,
		620032,
		620033,
		620034,
		620035,
		620036,
		620037,
		620038,
		620039,
		620040,
	},
	BuildingList = {
		{
			Pos = "BuildingPosUp_1",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_2",
			Prefab = "Building_ClothingStore",
		},
		{
			Pos = "BuildingPosUp_3",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_4",
			Prefab = "fangzi09",
		},
		{
			Pos = "BuildingPosDown_1",
			Prefab = "Building_ExileStreetArena",
		},
		{
			Pos = "BuildingPosDown_2",
			Prefab = "Building_ActivityRoom",
		},
		{
			Pos = "BuildingPosDown_3",
			Prefab = "fangzi03",
		},
		{
			Pos = "BuildingPosDown_4",
			Prefab = "fangzi04",
		},
		{
			Pos = "BuildingPosDown_5",
			Prefab = "fangzi05",
		},
		{
			Pos = "BuildingPosDown_6",
			Prefab = "fangzi05",
		},
	},
	ThemeRoomPrefab = "darkfoodfestival",
	ThemeRoomBundle = "activitythemeroom",
	ThemeRoomCharacter = {
		223101,
		223102,
		223103,
		223104,
		223105,
		223106,
		223107,
	},
	PackageBundle = "Activity_1",
	PackageAtlas = "Activity_1",
	PackageIcon = "ActivityPackage_All_NewYearBeast",
	ActivityDailyLoginList = {
		580026,
		580027,
		580028,
		580029,
		580030,
		580031,
		580032,
		580033,
		580034,
		580035,
		580036,
		580037,
		580038,
		580039,
		580040,
		580041,
	},
	ActivityGameModule = 2,
	ActivityHideSeekId = 880002,
}
ActivityThemeConfig[ActivityThemeID.Id039] =
{
	Id = 39,
	Name = "冬日温泉",
	Explore = 630006,
	BattleTitle = "探索温泉别墅",
	TextureBundle = "packed_activity_winterfestival",
	ActivityBGM = "BGM_WinterFestival",
	BattleList = {
		620061,
		620062,
		620063,
		620064,
		620065,
		620066,
		620067,
		620068,
		620069,
		620070,
	},
	BuildingList = {
		{
			Pos = "BuildingPosUp_1",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_2",
			Prefab = "Building_ClothingStore",
		},
		{
			Pos = "BuildingPosUp_3",
			Prefab = "fangzi06",
		},
		{
			Pos = "BuildingPosUp_4",
			Prefab = "fangzi09",
		},
		{
			Pos = "BuildingPosDown_1",
			Prefab = "Building_ExileStreetArena",
		},
		{
			Pos = "BuildingPosDown_2",
			Prefab = "Building_ActivityRoom",
		},
		{
			Pos = "BuildingPosDown_3",
			Prefab = "fangzi03",
		},
		{
			Pos = "BuildingPosDown_4",
			Prefab = "fangzi04",
		},
		{
			Pos = "BuildingPosDown_5",
			Prefab = "fangzi05",
		},
		{
			Pos = "BuildingPosDown_6",
			Prefab = "fangzi05",
		},
	},
	ThemeRoomPrefab = "WinterFestival",
	ThemeRoomBundle = "activitythemeroom",
	ThemeRoomCharacter = {
		223141,
		223142,
		223143,
		223144,
		223145,
		223146,
		223147,
		223148,
	},
	ActivityDailyLoginList = {
		580042,
		580043,
		580044,
		580045,
		580046,
		580047,
		580048,
		580049,
		580050,
		580051,
		580052,
		580053,
		580054,
		580055,
		580056,
		580057,
	},
}

