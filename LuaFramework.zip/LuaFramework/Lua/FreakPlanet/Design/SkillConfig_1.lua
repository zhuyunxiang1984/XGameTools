
SkillConfig[SkillID.Id001] =
{
	Id = 1,
	Name = "探索时间+",
	Desc = "探索等待时间 +{Value}%",
	EffectModule = EffectModule.ExploreTime,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreTime",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id002] =
{
	Id = 2,
	Name = "探索时间-",
	Desc = "探索等待时间 -{Value}%",
	EffectModule = EffectModule.ExploreTime,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreTime",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id003] =
{
	Id = 3,
	Name = "头目招来",
	Desc = "紫色及以上品质敌人出现概率 +{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Rarity = 3,
		RarityOp = 0,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id004] =
{
	Id = 4,
	Name = "头目驱走",
	Desc = "紫色及以上品质敌人出现概率 -{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Rarity = 3,
		RarityOp = 0,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id005] =
{
	Id = 5,
	Name = "水的招来",
	Desc = "水元素敌人出现概率 +{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Element = 210001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id006] =
{
	Id = 6,
	Name = "火的招来",
	Desc = "火元素敌人出现概率 +{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Element = 210002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id007] =
{
	Id = 7,
	Name = "木的招来",
	Desc = "风元素敌人出现概率 +{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Element = 210003,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id008] =
{
	Id = 8,
	Name = "光的招来",
	Desc = "光元素敌人出现概率 +{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Element = 210004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id009] =
{
	Id = 9,
	Name = "暗的招来",
	Desc = "暗元素敌人出现概率 +{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Element = 210005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id010] =
{
	Id = 10,
	Name = "发现植物",
	Desc = "植物类敌人出现概率 +{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Tag = 
		{
			561320,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id011] =
{
	Id = 11,
	Name = "发现动物",
	Desc = "动物类敌人出现概率 +{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Tag = 
		{
			561303,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id012] =
{
	Id = 12,
	Name = "发现精灵",
	Desc = "精灵类敌人出现概率 +{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Tag = 
		{
			561305,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id013] =
{
	Id = 13,
	Name = "发现食物",
	Desc = "食物类敌人出现概率 +{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Tag = 
		{
			561306,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id014] =
{
	Id = 14,
	Name = "发现机械",
	Desc = "机械类敌人出现概率 +{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Tag = 
		{
			561322,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id015] =
{
	Id = 15,
	Name = "躲避强敌",
	Desc = "打不过的怪物出现概率 -{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Chance = 100,
		CompareFightPower = 1,
		EnemyWeightCondition = {
			CompareWin = 2,
		},
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id016] =
{
	Id = 16,
	Name = "发现菜鸡",
	Desc = "打得过的敌人出现概率 +{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Chance = 100,
		CompareFightPower = 2,
		EnemyWeightCondition = {
			CompareWin = 1,
		},
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id017] =
{
	Id = 17,
	Name = "史莱姆招来",
	Desc = "史莱姆出现概率 +{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Tag = 
		{
			561323,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id018] =
{
	Id = 18,
	Name = "石头族驱走",
	Desc = "石怪出现概率 -{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Tag = 
		{
			561325,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id019] =
{
	Id = 19,
	Name = "水果族驱走",
	Desc = "水果出现概率 -{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Tag = 
		{
			561331,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id020] =
{
	Id = 20,
	Name = "海草族驱走",
	Desc = "海草出现概率 -{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Tag = 
		{
			561358,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id021] =
{
	Id = 21,
	Name = "温驯海族驱走",
	Desc = "温驯海族出现概率 +{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Tag = 
		{
			561355,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id022] =
{
	Id = 22,
	Name = "凶猛海族驱走",
	Desc = "凶猛海族出现概率 +{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyWeight",
		Tag = 
		{
			561356,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id101] =
{
	Id = 101,
	Name = "压制敌人战力",
	Desc = "敌人战力 -{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyFightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id102] =
{
	Id = 102,
	Name = "水元素敌人战力+",
	Desc = "水元素敌人战力 -{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyFightPower",
		Element = 210001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id103] =
{
	Id = 103,
	Name = "火元素敌人战力+",
	Desc = "火元素敌人战力 -{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyFightPower",
		Element = 210002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id104] =
{
	Id = 104,
	Name = "风元素敌人战力+",
	Desc = "风元素敌人战力 -{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyFightPower",
		Element = 210003,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id105] =
{
	Id = 105,
	Name = "光元素敌人战力+",
	Desc = "光元素敌人战力 -{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyFightPower",
		Element = 210004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id106] =
{
	Id = 106,
	Name = "暗元素敌人战力+",
	Desc = "暗元素敌人战力 -{Value}%",
	EffectModule = EffectModule.ExploreEnemy,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyFightPower",
		Element = 210005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id201] =
{
	Id = 201,
	Name = "探索金币+",
	Desc = "探索金币数量 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id202] =
{
	Id = 202,
	Name = "每个冒险星队员提供探索金币+",
	Desc = "探索金币数量 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560103,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id203] =
{
	Id = 203,
	Name = "每个美食星队员提供探索金币+",
	Desc = "探索金币数量 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560104,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id204] =
{
	Id = 204,
	Name = "每个博物馆星队员提供探索金币+",
	Desc = "探索金币数量 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560105,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id205] =
{
	Id = 205,
	Name = "每个悬疑星队员提供探索金币+",
	Desc = "探索金币数量 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560106,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id221] =
{
	Id = 221,
	Name = "道具掉落率+",
	Desc = "道具掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropChance",
		Tag = 
		{
			564305,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id222] =
{
	Id = 222,
	Name = "搜刮头目",
	Desc = "紫色及以上品质敌人道具掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyDropChance",
		Rarity = 3,
		RarityOp = 0,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id223] =
{
	Id = 223,
	Name = "水元素敌人掉落概率+",
	Desc = "水元素敌人道具掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyDropChance",
		Element = 210001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id224] =
{
	Id = 224,
	Name = "火元素敌人掉落概率+",
	Desc = "火元素敌人道具掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyDropChance",
		Element = 210002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id225] =
{
	Id = 225,
	Name = "风元素敌人掉落概率+",
	Desc = "风元素敌人道具掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyDropChance",
		Element = 210003,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id226] =
{
	Id = 226,
	Name = "光元素敌人掉落概率+",
	Desc = "光元素敌人道具掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyDropChance",
		Element = 210004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id227] =
{
	Id = 227,
	Name = "暗元素敌人掉落概率+",
	Desc = "暗元素敌人道具掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyDropChance",
		Element = 210005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id228] =
{
	Id = 228,
	Name = "冒险星敌人掉落概率+",
	Desc = "冒险星敌人道具掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyDropChance",
		Tag = 
		{
			560103,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id229] =
{
	Id = 229,
	Name = "美食星敌人掉落概率+",
	Desc = "美食星敌人道具掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyDropChance",
		Tag = 
		{
			560104,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id230] =
{
	Id = 230,
	Name = "博物馆星敌人掉落概率+",
	Desc = "博物馆星敌人道具掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyDropChance",
		Tag = 
		{
			560105,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id231] =
{
	Id = 231,
	Name = "悬疑星敌人掉落概率+",
	Desc = "悬疑星敌人道具掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyDropChance",
		Tag = 
		{
			560106,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id232] =
{
	Id = 232,
	Name = "海洋星敌人掉落概率+",
	Desc = "海洋星敌人道具掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyDropChance",
		Tag = 
		{
			560107,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id233] =
{
	Id = 233,
	Name = "温驯海族掉落概率+",
	Desc = "温驯海族道具掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyDropChance",
		Tag = 
		{
			561355,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id234] =
{
	Id = 234,
	Name = "凶猛海族掉落概率+",
	Desc = "凶猛海族道具掉落率 +{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyDropChance",
		Tag = 
		{
			561356,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id251] =
{
	Id = 251,
	Name = "探索获得玉璧",
	Desc = "探索中获得玉璧，每小时{ValueDivide}个",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 2,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id252] =
{
	Id = 252,
	Name = "探索获得强化零件D",
	Desc = "探索中获得强化零件D，每小时{ValueDivide}个",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 320041,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id253] =
{
	Id = 253,
	Name = "探索获得强化零件C",
	Desc = "探索中获得强化零件C，每小时{ValueDivide}个",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 320042,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id254] =
{
	Id = 254,
	Name = "探索获得强化零件B",
	Desc = "探索中获得强化零件B，每小时{ValueDivide}个",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 320043,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id255] =
{
	Id = 255,
	Name = "探索获得强化零件A",
	Desc = "探索中获得强化零件A，每小时{ValueDivide}个",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 320044,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id256] =
{
	Id = 256,
	Name = "探索获得固化零件D",
	Desc = "探索中获得固化零件D，每小时{ValueDivide}个",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 320051,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id257] =
{
	Id = 257,
	Name = "探索获得固化零件C",
	Desc = "探索中获得固化零件C，每小时{ValueDivide}个",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 320052,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id258] =
{
	Id = 258,
	Name = "探索获得固化零件B",
	Desc = "探索中获得固化零件B，每小时{ValueDivide}个",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 320053,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id259] =
{
	Id = 259,
	Name = "探索获得固化零件A",
	Desc = "探索中获得固化零件A，每小时{ValueDivide}个",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 320054,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id260] =
{
	Id = 260,
	Name = "探索获得盲盒月饼",
	Desc = "探索中获得盲盒月饼，每小时{ValueDivide}个",
	EffectModule = EffectModule.ExploreDrop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreGetGoods",
		EffectValue = 320424,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id261] =
{
	Id = 261,
	Name = "探索时间-",
	Desc = "酋长在场时，探索时间-{Value}%",
	EffectModule = EffectModule.ExploreTime,
	EffectCondition = {
		Teamer = 
		{
			221004,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExploreTime",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id400] =
{
	Id = 400,
	Name = "水元素敌人捕捉率+",
	Desc = "水元素敌人捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Element = 210001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id401] =
{
	Id = 401,
	Name = "火元素敌人捕捉率+",
	Desc = "火元素敌人捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Element = 210002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id402] =
{
	Id = 402,
	Name = "风元素敌人捕捉率+",
	Desc = "风元素敌人捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Element = 210003,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id403] =
{
	Id = 403,
	Name = "光元素敌人捕捉率+",
	Desc = "光元素敌人捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Element = 210004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id404] =
{
	Id = 404,
	Name = "暗元素敌人捕捉率+",
	Desc = "暗元素敌人捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Element = 210005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id405] =
{
	Id = 405,
	Name = "植物族的敌人捕捉率+",
	Desc = "精灵类敌人捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Tag = 
		{
			561320,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id406] =
{
	Id = 406,
	Name = "动物族的敌人捕捉率+",
	Desc = "动物类敌人捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Tag = 
		{
			561303,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id407] =
{
	Id = 407,
	Name = "精灵族的敌人捕捉率+",
	Desc = "精灵类敌人捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Tag = 
		{
			561305,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id408] =
{
	Id = 408,
	Name = "食物族的敌人捕捉率+",
	Desc = "精灵类敌人捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Tag = 
		{
			561306,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id409] =
{
	Id = 409,
	Name = "机械族的敌人捕捉率+",
	Desc = "机械类敌人捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Tag = 
		{
			561322,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id410] =
{
	Id = 410,
	Name = "石头族捕捉",
	Desc = "石怪捕捉概率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Tag = 
		{
			561325,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id411] =
{
	Id = 411,
	Name = "魔王城堡捕捉",
	Desc = "魔王城堡敌人捕捉概率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Tag = 
		{
			560311,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id412] =
{
	Id = 412,
	Name = "火焰巨人捕捉",
	Desc = "火焰巨人基础捕捉概率 +{Value}",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		EffectValue = 242027,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id413] =
{
	Id = 413,
	Name = "快的敌人捕捉",
	Desc = "快的敌人捕捉概率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Tag = 
		{
			563205,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id414] =
{
	Id = 414,
	Name = "超快的敌人捕捉",
	Desc = "超快的敌人捕捉概率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Tag = 
		{
			563206,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id415] =
{
	Id = 415,
	Name = "冒险星的敌人捕捉率+",
	Desc = "冒险星敌人捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Tag = 
		{
			560103,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id416] =
{
	Id = 416,
	Name = "美食星的敌人捕捉率+",
	Desc = "美食星敌人捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Tag = 
		{
			560104,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id417] =
{
	Id = 417,
	Name = "博物馆星的敌人捕捉率+",
	Desc = "博物馆星敌人捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Tag = 
		{
			560105,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id418] =
{
	Id = 418,
	Name = "悬疑星的敌人捕捉率+",
	Desc = "悬疑星敌人捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Tag = 
		{
			560106,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id419] =
{
	Id = 419,
	Name = "海洋星的敌人捕捉率+",
	Desc = "海洋星敌人捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Tag = 
		{
			560107,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id420] =
{
	Id = 420,
	Name = "温驯海族的敌人捕捉率+",
	Desc = "温驯海族捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Tag = 
		{
			561355,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id421] =
{
	Id = 421,
	Name = "凶猛海族的敌人捕捉率+",
	Desc = "凶猛海族捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Tag = 
		{
			561356,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id481] =
{
	Id = 481,
	Name = "陷阱捕捉率+",
	Desc = "陷阱捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Tag = 
		{
			563102,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id482] =
{
	Id = 482,
	Name = "空瓶捕捉率+",
	Desc = "空瓶捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Tag = 
		{
			563103,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id483] =
{
	Id = 483,
	Name = "纸袋捕捉率+",
	Desc = "纸袋捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Tag = 
		{
			563104,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id484] =
{
	Id = 484,
	Name = "工具箱捕捉率+",
	Desc = "工具箱捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Tag = 
		{
			563105,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id485] =
{
	Id = 485,
	Name = "纸板箱捕捉率+",
	Desc = "纸板箱捕捉成功率 +{Value}%",
	EffectModule = EffectModule.ExploreCatch,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "PetCatchSuccessChance",
		Tag = 
		{
			563106,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id501] =
{
	Id = 501,
	Name = "战力+",
	Desc = "探索中，自身战力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id502] =
{
	Id = 502,
	Name = "全队战力+",
	Desc = "探索中，全队战力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id503] =
{
	Id = 503,
	Name = "每个水元素队员提供战力",
	Desc = "探索中，每个水元素队员提供战力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210001,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id504] =
{
	Id = 504,
	Name = "每个火元素队员提供战力",
	Desc = "探索中，每个火元素队员提供战力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210002,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id505] =
{
	Id = 505,
	Name = "每个风元素队员提供战力",
	Desc = "探索中，每个风元素队员提供战力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210003,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id506] =
{
	Id = 506,
	Name = "么给光元素队员提供战力",
	Desc = "探索中，每个光元素队员提供战力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210004,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id507] =
{
	Id = 507,
	Name = "每个暗元素队员提供战力",
	Desc = "探索中，每个暗元素队员提供战力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210005,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id508] =
{
	Id = 508,
	Name = "水元素队员战力+",
	Desc = "探索中，水元素队员战力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210001,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id509] =
{
	Id = 509,
	Name = "火元素队员战力+",
	Desc = "探索中，火元素队员战力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210002,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id510] =
{
	Id = 510,
	Name = "风元素队员战力+",
	Desc = "探索中，风元素队员战力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210003,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id511] =
{
	Id = 511,
	Name = "光元素队员战力+",
	Desc = "探索中，光元素队员战力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210004,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id512] =
{
	Id = 512,
	Name = "暗元素队员战力+",
	Desc = "探索中，暗元素队员战力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210005,
	},
	Effect = {
		EffectAttribute = "FightPower",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id551] =
{
	Id = 551,
	Name = "水元素打击",
	Desc = "对水元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id552] =
{
	Id = 552,
	Name = "火元素打击",
	Desc = "对火元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id553] =
{
	Id = 553,
	Name = "风元素打击",
	Desc = "对风元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210003,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id554] =
{
	Id = 554,
	Name = "光元素打击",
	Desc = "对光元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id555] =
{
	Id = 555,
	Name = "暗元素打击",
	Desc = "对暗元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id556] =
{
	Id = 556,
	Name = "全队水元素打击",
	Desc = "全队对水元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id557] =
{
	Id = 557,
	Name = "全队火元素打击",
	Desc = "全队对火元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id558] =
{
	Id = 558,
	Name = "全队风元素打击",
	Desc = "全队对风元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210003,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id559] =
{
	Id = 559,
	Name = "全队光元素打击",
	Desc = "全队对光元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id560] =
{
	Id = 560,
	Name = "全队暗元素打击",
	Desc = "全队对暗元素敌人伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "DamageToElement",
		EffectValue = 210005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id561] =
{
	Id = 561,
	Name = "水元素免伤",
	Desc = "受水元素敌人伤害 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageFromElement",
		EffectValue = 210001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id562] =
{
	Id = 562,
	Name = "火元素免伤",
	Desc = "受火元素敌人伤害 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageFromElement",
		EffectValue = 210002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id563] =
{
	Id = 563,
	Name = "木元素免伤",
	Desc = "受风元素敌人伤害 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageFromElement",
		EffectValue = 210003,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id564] =
{
	Id = 564,
	Name = "光元素免伤",
	Desc = "受光元素敌人伤害 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageFromElement",
		EffectValue = 210004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id565] =
{
	Id = 565,
	Name = "暗元素免伤",
	Desc = "受暗元素敌人伤害 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageFromElement",
		EffectValue = 210005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id566] =
{
	Id = 566,
	Name = "全队水元素免伤",
	Desc = "全队受到水元素敌人伤害 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "DamageFromElement",
		EffectValue = 210001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id567] =
{
	Id = 567,
	Name = "全队火元素免伤",
	Desc = "全队受到火元素敌人伤害 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "DamageFromElement",
		EffectValue = 210002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id568] =
{
	Id = 568,
	Name = "全队风元素免伤",
	Desc = "全队受到风元素敌人伤害 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "DamageFromElement",
		EffectValue = 210003,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id569] =
{
	Id = 569,
	Name = "全队光元素免伤",
	Desc = "全队受到光元素敌人伤害 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "DamageFromElement",
		EffectValue = 210004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id570] =
{
	Id = 570,
	Name = "全队暗元素免伤",
	Desc = "全队受到暗元素敌人伤害 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "DamageFromElement",
		EffectValue = 210005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id601] =
{
	Id = 601,
	Name = "暴率+",
	Desc = "暴率 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CritChance",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id602] =
{
	Id = 602,
	Name = "暴率-",
	Desc = "暴率 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CritChance",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id603] =
{
	Id = 603,
	Name = "全队暴率+",
	Desc = "全队暴率 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "CritChance",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id604] =
{
	Id = 604,
	Name = "全队暴率-",
	Desc = "全队暴率 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "CritChance",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id605] =
{
	Id = 605,
	Name = "暴击伤害+",
	Desc = "暴击伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CritDamage",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id606] =
{
	Id = 606,
	Name = "受到暴伤+",
	Desc = "受到的暴击伤害 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DamageFromCritDamage",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id607] =
{
	Id = 607,
	Name = "全队暴击伤害+",
	Desc = "全队暴击伤害 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "CritDamage",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id608] =
{
	Id = 608,
	Name = "全队受到暴伤+",
	Desc = "全队受到的暴击伤害 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "DamageFromCritDamage",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id651] =
{
	Id = 651,
	Name = "生命+",
	Desc = "生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id652] =
{
	Id = 652,
	Name = "攻击+",
	Desc = "攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id653] =
{
	Id = 653,
	Name = "忍耐+",
	Desc = "忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id654] =
{
	Id = 654,
	Name = "暴击+",
	Desc = "暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id655] =
{
	Id = 655,
	Name = "技巧+",
	Desc = "技巧 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id656] =
{
	Id = 656,
	Name = "亲和+",
	Desc = "亲和 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id657] =
{
	Id = 657,
	Name = "力气+",
	Desc = "力气 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id658] =
{
	Id = 658,
	Name = "智力+",
	Desc = "智力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200008,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id659] =
{
	Id = 659,
	Name = "全队生命+",
	Desc = "全队生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id660] =
{
	Id = 660,
	Name = "全队攻击+",
	Desc = "全队攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id661] =
{
	Id = 661,
	Name = "全队忍耐+",
	Desc = "全队忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id662] =
{
	Id = 662,
	Name = "全队暴击+",
	Desc = "全队暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id663] =
{
	Id = 663,
	Name = "全队技巧+",
	Desc = "全队技巧 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id664] =
{
	Id = 664,
	Name = "全队亲和+",
	Desc = "全队亲和 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id665] =
{
	Id = 665,
	Name = "全队力气+",
	Desc = "全队力气 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id666] =
{
	Id = 666,
	Name = "全队智力+",
	Desc = "全队智力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200008,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id667] =
{
	Id = 667,
	Name = "水元素队员生命+",
	Desc = "水元素队员生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210001,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id668] =
{
	Id = 668,
	Name = "水元素队员攻击+",
	Desc = "水元素队员攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210001,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id669] =
{
	Id = 669,
	Name = "水元素队员忍耐+",
	Desc = "水元素队员忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210001,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id670] =
{
	Id = 670,
	Name = "水元素队员暴击+",
	Desc = "水元素队员暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210001,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id671] =
{
	Id = 671,
	Name = "火元素队员生命+",
	Desc = "火元素队员生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210002,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id672] =
{
	Id = 672,
	Name = "火元素队员攻击+",
	Desc = "火元素队员攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210002,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id673] =
{
	Id = 673,
	Name = "火元素队员忍耐+",
	Desc = "火元素队员忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210002,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id674] =
{
	Id = 674,
	Name = "火元素队员暴击+",
	Desc = "火元素队员暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210002,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id675] =
{
	Id = 675,
	Name = "风元素队员生命+",
	Desc = "风元素队员生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210003,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id676] =
{
	Id = 676,
	Name = "风元素队员攻击+",
	Desc = "风元素队员攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210003,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id677] =
{
	Id = 677,
	Name = "风元素队员忍耐+",
	Desc = "风元素队员忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210003,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id678] =
{
	Id = 678,
	Name = "风元素队员暴击+",
	Desc = "风元素队员暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210003,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id679] =
{
	Id = 679,
	Name = "光元素队员生命+",
	Desc = "光元素队员生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210004,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id680] =
{
	Id = 680,
	Name = "光元素队员攻击+",
	Desc = "光元素队员攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210004,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id681] =
{
	Id = 681,
	Name = "光元素队员忍耐+",
	Desc = "光元素队员忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210004,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id682] =
{
	Id = 682,
	Name = "光元素队员暴击+",
	Desc = "光元素队员暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210004,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id683] =
{
	Id = 683,
	Name = "暗元素队员生命+",
	Desc = "暗元素队员生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210005,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id684] =
{
	Id = 684,
	Name = "暗元素队员攻击+",
	Desc = "暗元素队员攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210005,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id685] =
{
	Id = 685,
	Name = "暗元素队员忍耐+",
	Desc = "暗元素队员忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210005,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id686] =
{
	Id = 686,
	Name = "暗元素队员暴击+",
	Desc = "暗元素队员暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210005,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id687] =
{
	Id = 687,
	Name = "男队员生命+",
	Desc = "男队员生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561702,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id688] =
{
	Id = 688,
	Name = "男队员攻击+",
	Desc = "男队员攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561702,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id689] =
{
	Id = 689,
	Name = "男队员忍耐+",
	Desc = "男队员忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561702,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id690] =
{
	Id = 690,
	Name = "男队员暴击+",
	Desc = "男队员暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561702,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id691] =
{
	Id = 691,
	Name = "男队员技巧+",
	Desc = "男队员技巧 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561702,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id692] =
{
	Id = 692,
	Name = "男队员亲和+",
	Desc = "男队员亲和 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561702,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id693] =
{
	Id = 693,
	Name = "男队员力气+",
	Desc = "男队员力气 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561702,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id694] =
{
	Id = 694,
	Name = "男队员智力+",
	Desc = "男队员智力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561702,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200008,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id695] =
{
	Id = 695,
	Name = "女队员生命+",
	Desc = "女队员生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561703,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id696] =
{
	Id = 696,
	Name = "女队员攻击+",
	Desc = "女队员攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561703,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id697] =
{
	Id = 697,
	Name = "女队员忍耐+",
	Desc = "女队员忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561703,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id698] =
{
	Id = 698,
	Name = "女队员暴击+",
	Desc = "女队员暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561703,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id699] =
{
	Id = 699,
	Name = "女队员技巧+",
	Desc = "女队员技巧 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561703,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id700] =
{
	Id = 700,
	Name = "女队员亲和+",
	Desc = "女队员亲和 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561703,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id701] =
{
	Id = 701,
	Name = "女队员力气+",
	Desc = "女队员力气 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561703,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id702] =
{
	Id = 702,
	Name = "女队员智力+",
	Desc = "女队员智力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561703,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200008,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id703] =
{
	Id = 703,
	Name = "每个4星队员提供生命+",
	Desc = "每个金色及以上品质队员提供生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Rarity = 4,
		RarityOp = 0,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id704] =
{
	Id = 704,
	Name = "每个4星队员提供攻击+",
	Desc = "每个金色及以上品质队员提供攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Rarity = 4,
		RarityOp = 0,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id705] =
{
	Id = 705,
	Name = "每个4星队员提供忍耐+",
	Desc = "每个金色及以上品质队员提供忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Rarity = 4,
		RarityOp = 0,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id706] =
{
	Id = 706,
	Name = "每个4星队员提供暴击+",
	Desc = "每个金色及以上品质队员提供暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Rarity = 4,
		RarityOp = 0,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id707] =
{
	Id = 707,
	Name = "每个4星队员提供技巧+",
	Desc = "每个金色及以上品质队员提供技巧 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Rarity = 4,
		RarityOp = 0,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id708] =
{
	Id = 708,
	Name = "每个4星队员提供亲和+",
	Desc = "每个金色及以上品质队员提供亲和 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Rarity = 4,
		RarityOp = 0,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id709] =
{
	Id = 709,
	Name = "每个4星队员提供力气+",
	Desc = "每个金色及以上品质队员提供力气 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Rarity = 4,
		RarityOp = 0,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id710] =
{
	Id = 710,
	Name = "每个4星队员提供智力+",
	Desc = "每个金色及以上品质队员提供智力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Rarity = 4,
		RarityOp = 0,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200008,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id711] =
{
	Id = 711,
	Name = "每个水元素队员提供生命+",
	Desc = "每个水元素队员提供生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210001,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id712] =
{
	Id = 712,
	Name = "每个水元素队员提供攻击+",
	Desc = "每个水元素队员提供攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210001,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id713] =
{
	Id = 713,
	Name = "每个水元素队员提供忍耐+",
	Desc = "每个水元素队员提供忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210001,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id714] =
{
	Id = 714,
	Name = "每个水元素队员提供暴击+",
	Desc = "每个水元素队员提供暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210001,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id715] =
{
	Id = 715,
	Name = "每个火元素队员提供生命+",
	Desc = "每个火元素队员提供生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210002,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id716] =
{
	Id = 716,
	Name = "每个火元素队员提供攻击+",
	Desc = "每个火元素队员提供攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210002,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id717] =
{
	Id = 717,
	Name = "每个火元素队员提供忍耐+",
	Desc = "每个火元素队员提供忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210002,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id718] =
{
	Id = 718,
	Name = "每个火元素队员提供暴击+",
	Desc = "每个火元素队员提供暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210002,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id719] =
{
	Id = 719,
	Name = "每个风元素队员提供生命+",
	Desc = "每个风元素队员提供生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210003,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id720] =
{
	Id = 720,
	Name = "每个风元素队员提供攻击+",
	Desc = "每个风元素队员提供攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210003,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id721] =
{
	Id = 721,
	Name = "每个风元素队员提供忍耐+",
	Desc = "每个风元素队员提供忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210003,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id722] =
{
	Id = 722,
	Name = "每个风元素队员提供暴击+",
	Desc = "每个风元素队员提供暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210003,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id723] =
{
	Id = 723,
	Name = "每个光元素队员提供生命+",
	Desc = "每个光元素队员提供生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210004,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id724] =
{
	Id = 724,
	Name = "每个光元素队员提供攻击+",
	Desc = "每个光元素队员提供攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210004,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id725] =
{
	Id = 725,
	Name = "每个光元素队员提供忍耐+",
	Desc = "每个光元素队员提供忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210004,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id726] =
{
	Id = 726,
	Name = "每个光元素队员提供暴击+",
	Desc = "每个光元素队员提供暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210004,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id727] =
{
	Id = 727,
	Name = "每个暗元素队员提供生命+",
	Desc = "每个暗元素队员提供生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210005,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id728] =
{
	Id = 728,
	Name = "每个暗元素队员提供攻击+",
	Desc = "每个暗元素队员提供攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210005,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id729] =
{
	Id = 729,
	Name = "每个暗元素队员提供忍耐+",
	Desc = "每个暗元素队员提供忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210005,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id730] =
{
	Id = 730,
	Name = "每个暗元素队员提供暴击+",
	Desc = "每个暗元素队员提供暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Element = 210005,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id731] =
{
	Id = 731,
	Name = "每个冒险星队员提供生命+",
	Desc = "每个冒险星队员提供生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560103,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id732] =
{
	Id = 732,
	Name = "每个冒险星队员提供攻击+",
	Desc = "每个冒险星队员提供攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560103,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id733] =
{
	Id = 733,
	Name = "每个冒险星队员提供忍耐+",
	Desc = "每个冒险星队员提供忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560103,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id734] =
{
	Id = 734,
	Name = "每个冒险星队员提供暴击+",
	Desc = "每个冒险星队员提供暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560103,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id735] =
{
	Id = 735,
	Name = "每个美食星队员提供生命+",
	Desc = "每个美食星队员提供生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560104,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id736] =
{
	Id = 736,
	Name = "每个美食星队员提供攻击+",
	Desc = "每个美食星队员提供攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560104,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id737] =
{
	Id = 737,
	Name = "每个美食星队员提供忍耐+",
	Desc = "每个美食星队员提供忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560104,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id738] =
{
	Id = 738,
	Name = "每个美食星队员提供暴击+",
	Desc = "每个美食星队员提供暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560104,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id739] =
{
	Id = 739,
	Name = "每个博物馆星队员提供生命+",
	Desc = "每个博物馆星队员提供生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560105,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id740] =
{
	Id = 740,
	Name = "每个博物馆星队员提供攻击+",
	Desc = "每个博物馆星队员提供攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560105,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id741] =
{
	Id = 741,
	Name = "每个博物馆星队员提供忍耐+",
	Desc = "每个博物馆星队员提供忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560105,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id742] =
{
	Id = 742,
	Name = "每个博物馆星队员提供暴击+",
	Desc = "每个博物馆星队员提供暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560105,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id743] =
{
	Id = 743,
	Name = "每个悬疑星队员提供生命+",
	Desc = "每个悬疑星队员提供生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560106,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id744] =
{
	Id = 744,
	Name = "每个悬疑星队员提供攻击+",
	Desc = "每个悬疑星队员提供攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560106,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id745] =
{
	Id = 745,
	Name = "每个悬疑星队员提供忍耐+",
	Desc = "每个悬疑星队员提供忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560106,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id746] =
{
	Id = 746,
	Name = "每个悬疑星队员提供暴击+",
	Desc = "每个悬疑星队员提供暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560106,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id747] =
{
	Id = 747,
	Name = "每个男队员提供生命+",
	Desc = "每个男队员提供生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			561702,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id748] =
{
	Id = 748,
	Name = "每个男队员提供攻击+",
	Desc = "每个男队员提供攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			561702,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id749] =
{
	Id = 749,
	Name = "每个男队员提供忍耐+",
	Desc = "每个男队员提供忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			561702,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id750] =
{
	Id = 750,
	Name = "每个男队员提供暴击+",
	Desc = "每个男队员提供暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			561702,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id751] =
{
	Id = 751,
	Name = "每个男队员提供技巧+",
	Desc = "每个男队员提供技巧 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			561702,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id752] =
{
	Id = 752,
	Name = "每个男队员提供亲和+",
	Desc = "每个男队员提供亲和 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			561702,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id753] =
{
	Id = 753,
	Name = "每个男队员提供力气+",
	Desc = "每个男队员提供力气 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			561702,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id754] =
{
	Id = 754,
	Name = "每个男队员提供智力+",
	Desc = "每个男队员提供智力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			561702,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200008,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id755] =
{
	Id = 755,
	Name = "每个女队员提供生命+",
	Desc = "每个女队员提供生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			561703,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id756] =
{
	Id = 756,
	Name = "每个女队员提供攻击+",
	Desc = "每个女队员提供攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			561703,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id757] =
{
	Id = 757,
	Name = "每个女队员提供忍耐+",
	Desc = "每个女队员提供忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			561703,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id758] =
{
	Id = 758,
	Name = "每个女队员提供暴击+",
	Desc = "每个女队员提供暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			561703,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id759] =
{
	Id = 759,
	Name = "每个女队员提供技巧+",
	Desc = "每个女队员提供技巧 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			561703,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id760] =
{
	Id = 760,
	Name = "每个女队员提供亲和+",
	Desc = "每个女队员提供亲和 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			561703,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id761] =
{
	Id = 761,
	Name = "每个女队员提供力气+",
	Desc = "每个女队员提供力气 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			561703,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id762] =
{
	Id = 762,
	Name = "每个女队员提供智力+",
	Desc = "每个女队员提供智力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			561703,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200008,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id763] =
{
	Id = 763,
	Name = "每个美食王子组队员提供生命+",
	Desc = "每个美食王子组队员提供生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562907,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id764] =
{
	Id = 764,
	Name = "每个美食王子组队员提供攻击+",
	Desc = "每个美食王子组队员提供攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562907,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id765] =
{
	Id = 765,
	Name = "每个美食王子组队员提供忍耐+",
	Desc = "每个美食王子组队员提供忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562907,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id766] =
{
	Id = 766,
	Name = "每个美食王子组队员提供暴击+",
	Desc = "每个美食王子组队员提供暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562907,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id767] =
{
	Id = 767,
	Name = "每个美食王子组队员提供技巧+",
	Desc = "每个美食王子组队员提供技巧 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562907,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id768] =
{
	Id = 768,
	Name = "每个美食王子组队员提供亲和+",
	Desc = "每个美食王子组队员提供亲和 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562907,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id769] =
{
	Id = 769,
	Name = "每个美食王子组队员提供力气+",
	Desc = "每个美食王子组队员提供力气 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562907,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id770] =
{
	Id = 770,
	Name = "每个美食王子组队员提供智力+",
	Desc = "每个美食王子组队员提供智力 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562907,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200008,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id771] =
{
	Id = 771,
	Name = "每个美食公主组队员提供生命+",
	Desc = "每个美食公主组队员提供生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562908,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id772] =
{
	Id = 772,
	Name = "每个美食公主组队员提供攻击+",
	Desc = "每个美食公主组队员提供攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562908,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id773] =
{
	Id = 773,
	Name = "每个美食公主组队员提供忍耐+",
	Desc = "每个美食公主组队员提供忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562908,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id774] =
{
	Id = 774,
	Name = "每个美食公主组队员提供暴击+",
	Desc = "每个美食公主组队员提供暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562908,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id775] =
{
	Id = 775,
	Name = "每个美食公主组队员提供技巧+",
	Desc = "每个美食公主组队员提供技巧 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562908,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id776] =
{
	Id = 776,
	Name = "每个美食公主组队员提供亲和+",
	Desc = "每个美食公主组队员提供亲和 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562908,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id777] =
{
	Id = 777,
	Name = "每个美食公主组队员提供力气+",
	Desc = "每个美食公主组队员提供力气 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			562908,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id778] =
{
	Id = 778,
	Name = "全队生命+",
	Desc = "全队生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id779] =
{
	Id = 779,
	Name = "全队攻击+",
	Desc = "全队攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id780] =
{
	Id = 780,
	Name = "全队技巧+",
	Desc = "全队技巧 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200005,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id781] =
{
	Id = 781,
	Name = "全队亲和+",
	Desc = "全队亲和 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id782] =
{
	Id = 782,
	Name = "全队力气+",
	Desc = "全队力气 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200007,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id783] =
{
	Id = 783,
	Name = "全队智力+",
	Desc = "全队智力 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200008,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id784] =
{
	Id = 784,
	Name = "每个冒险星队员提供攻击+",
	Desc = "每个冒险星队员提供攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560103,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id785] =
{
	Id = 785,
	Name = "身前队员生命+",
	Desc = "自身及身前两名队员生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			-2,-1,0,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id786] =
{
	Id = 786,
	Name = "身前队员攻击+",
	Desc = "自身及身前两名队员攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			-2,-1,0,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id787] =
{
	Id = 787,
	Name = "身前队员忍耐+",
	Desc = "自身及身前两名队员忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			-2,-1,0,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id788] =
{
	Id = 788,
	Name = "身前队员暴击+",
	Desc = "自身及身前两名队员暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			-2,-1,0,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id789] =
{
	Id = 789,
	Name = "身后队员生命+",
	Desc = "自身及身后两名队员生命 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			0,1,2,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id790] =
{
	Id = 790,
	Name = "身后队员攻击+",
	Desc = "自身及身后两名队员攻击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			0,1,2,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id791] =
{
	Id = 791,
	Name = "身后队员忍耐+",
	Desc = "自身及身后两名队员忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			0,1,2,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id792] =
{
	Id = 792,
	Name = "身后队员暴击+",
	Desc = "自身及身后两名队员暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			0,1,2,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id793] =
{
	Id = 793,
	Name = "每个海洋星队员提供生命+",
	Desc = "每个海洋星队员提供生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560107,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id794] =
{
	Id = 794,
	Name = "每个海洋星队员提供攻击+",
	Desc = "每个海洋星队员提供攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560107,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id795] =
{
	Id = 795,
	Name = "每个海洋星队员提供忍耐+",
	Desc = "每个海洋星队员提供忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560107,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id796] =
{
	Id = 796,
	Name = "每个海洋星队员提供暴击+",
	Desc = "每个海洋星队员提供暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			560107,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id797] =
{
	Id = 797,
	Name = "动物族生命+",
	Desc = "动物族生命 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561303,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id798] =
{
	Id = 798,
	Name = "动物族攻击+",
	Desc = "动物族攻击 +{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561303,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id799] =
{
	Id = 799,
	Name = "动物族忍耐+",
	Desc = "动物族忍耐 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561303,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id800] =
{
	Id = 800,
	Name = "动物族暴击+",
	Desc = "动物族暴击 +{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			561303,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1501] =
{
	Id = 1501,
	Name = "压制敌人生命",
	Desc = "敌人生命 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id1502] =
{
	Id = 1502,
	Name = "压制敌人攻击",
	Desc = "敌人攻击 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id1503] =
{
	Id = 1503,
	Name = "压制敌人忍耐",
	Desc = "敌人忍耐 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id1504] =
{
	Id = 1504,
	Name = "压制敌人暴击",
	Desc = "敌人暴击 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id1505] =
{
	Id = 1505,
	Name = "压制水元素敌人生命",
	Desc = "水元素敌人生命 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200001,
		Element = 210001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id1506] =
{
	Id = 1506,
	Name = "压制水元素敌人攻击",
	Desc = "水元素敌人攻击 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200002,
		Element = 210001,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id1507] =
{
	Id = 1507,
	Name = "压制水元素敌人忍耐",
	Desc = "水元素敌人忍耐 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200003,
		Element = 210001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id1508] =
{
	Id = 1508,
	Name = "压制水元素敌人暴击",
	Desc = "水元素敌人暴击 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200004,
		Element = 210001,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id1509] =
{
	Id = 1509,
	Name = "压制火元素敌人生命",
	Desc = "火元素敌人生命 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200001,
		Element = 210002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id1510] =
{
	Id = 1510,
	Name = "压制火元素敌人攻击",
	Desc = "火元素敌人攻击 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200002,
		Element = 210002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id1511] =
{
	Id = 1511,
	Name = "压制火元素敌人忍耐",
	Desc = "火元素敌人忍耐 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200003,
		Element = 210002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id1512] =
{
	Id = 1512,
	Name = "压制火元素敌人暴击",
	Desc = "火元素敌人暴击 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200004,
		Element = 210002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id1513] =
{
	Id = 1513,
	Name = "压制风元素敌人生命",
	Desc = "风元素敌人生命 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200001,
		Element = 210003,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id1514] =
{
	Id = 1514,
	Name = "压制风元素敌人攻击",
	Desc = "风元素敌人攻击 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200002,
		Element = 210003,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id1515] =
{
	Id = 1515,
	Name = "压制风元素敌人忍耐",
	Desc = "风元素敌人忍耐 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200003,
		Element = 210003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id1516] =
{
	Id = 1516,
	Name = "压制风元素敌人暴击",
	Desc = "风元素敌人暴击 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200004,
		Element = 210003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id1517] =
{
	Id = 1517,
	Name = "压制光元素敌人生命",
	Desc = "光元素敌人生命 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200001,
		Element = 210004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id1518] =
{
	Id = 1518,
	Name = "压制光元素敌人攻击",
	Desc = "光元素敌人攻击 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200002,
		Element = 210004,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id1519] =
{
	Id = 1519,
	Name = "压制光元素敌人忍耐",
	Desc = "光元素敌人忍耐 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200003,
		Element = 210004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id1520] =
{
	Id = 1520,
	Name = "压制光元素敌人暴击",
	Desc = "光元素敌人暴击 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200004,
		Element = 210004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id1521] =
{
	Id = 1521,
	Name = "压制暗元素敌人生命",
	Desc = "暗元素敌人生命 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200001,
		Element = 210005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id1522] =
{
	Id = 1522,
	Name = "压制暗元素敌人攻击",
	Desc = "暗元素敌人攻击 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200002,
		Element = 210005,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id1523] =
{
	Id = 1523,
	Name = "压制暗元素敌人忍耐",
	Desc = "暗元素敌人忍耐 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200003,
		Element = 210005,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id1524] =
{
	Id = 1524,
	Name = "压制暗元素敌人暴击",
	Desc = "暗元素敌人暴击 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200004,
		Element = 210005,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id1525] =
{
	Id = 1525,
	Name = "压制敌人等级",
	Desc = "敌人等级 -{Value}",
	Dialog = "降智打击！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "EnemyLevel",
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id1526] =
{
	Id = 1526,
	Name = "压制会闪避的敌人生命",
	Desc = "会闪避的敌人生命 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200001,
		Tag = 
		{
			564557,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id1527] =
{
	Id = 1527,
	Name = "压制会闪避的敌人攻击",
	Desc = "会闪避的敌人攻击 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200002,
		Tag = 
		{
			564557,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id1528] =
{
	Id = 1528,
	Name = "压制会闪避的敌人忍耐",
	Desc = "会闪避的敌人忍耐 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200003,
		Tag = 
		{
			564557,
		},
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id1529] =
{
	Id = 1529,
	Name = "压制会闪避的敌人暴击",
	Desc = "会闪避的敌人暴击 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200004,
		Tag = 
		{
			564557,
		},
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id1530] =
{
	Id = 1530,
	Name = "压制会连击的敌人生命",
	Desc = "会连击的敌人生命 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200001,
		Tag = 
		{
			564558,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id1531] =
{
	Id = 1531,
	Name = "压制会连击的敌人攻击",
	Desc = "会连击的敌人攻击 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200002,
		Tag = 
		{
			564558,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id1532] =
{
	Id = 1532,
	Name = "压制会连击的敌人忍耐",
	Desc = "会连击的敌人忍耐 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200003,
		Tag = 
		{
			564558,
		},
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id1533] =
{
	Id = 1533,
	Name = "压制会连击的敌人暴击",
	Desc = "会连击的敌人暴击 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200004,
		Tag = 
		{
			564558,
		},
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id1534] =
{
	Id = 1534,
	Name = "压制会必中的敌人生命",
	Desc = "会必中的敌人生命 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200001,
		Tag = 
		{
			564559,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id1535] =
{
	Id = 1535,
	Name = "压制会必中的敌人攻击",
	Desc = "会必中的敌人攻击 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200002,
		Tag = 
		{
			564559,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id1536] =
{
	Id = 1536,
	Name = "压制会必中的敌人忍耐",
	Desc = "会必中的敌人忍耐 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200003,
		Tag = 
		{
			564559,
		},
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id1537] =
{
	Id = 1537,
	Name = "压制会必中的敌人暴击",
	Desc = "会必中的敌人暴击 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200004,
		Tag = 
		{
			564559,
		},
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id1538] =
{
	Id = 1538,
	Name = "压制会恢复的敌人生命",
	Desc = "会回血的敌人生命 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200001,
		Tag = 
		{
			564560,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id1539] =
{
	Id = 1539,
	Name = "压制会恢复的敌人攻击",
	Desc = "会回血的敌人攻击 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200002,
		Tag = 
		{
			564560,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id1540] =
{
	Id = 1540,
	Name = "压制会恢复的敌人忍耐",
	Desc = "会回血的敌人忍耐 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200003,
		Tag = 
		{
			564560,
		},
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id1541] =
{
	Id = 1541,
	Name = "压制会恢复的敌人暴击",
	Desc = "会回血的敌人暴击 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200004,
		Tag = 
		{
			564560,
		},
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id1542] =
{
	Id = 1542,
	Name = "压制会强化的敌人生命",
	Desc = "会强化的敌人生命 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200001,
		Tag = 
		{
			564561,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id1543] =
{
	Id = 1543,
	Name = "压制会强化的敌人攻击",
	Desc = "会强化的敌人攻击 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200002,
		Tag = 
		{
			564561,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id1544] =
{
	Id = 1544,
	Name = "压制会强化的敌人忍耐",
	Desc = "会强化的敌人忍耐 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200003,
		Tag = 
		{
			564561,
		},
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id1545] =
{
	Id = 1545,
	Name = "压制会强化的敌人暴击",
	Desc = "会强化的敌人暴击 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200004,
		Tag = 
		{
			564561,
		},
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id1546] =
{
	Id = 1546,
	Name = "压制会舍命的敌人生命",
	Desc = "会舍命的敌人生命 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200001,
		Tag = 
		{
			564562,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id1547] =
{
	Id = 1547,
	Name = "压制会舍命的敌人攻击",
	Desc = "会舍命的敌人攻击 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200002,
		Tag = 
		{
			564562,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id1548] =
{
	Id = 1548,
	Name = "压制会舍命的敌人忍耐",
	Desc = "会舍命的敌人忍耐 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200003,
		Tag = 
		{
			564562,
		},
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id1549] =
{
	Id = 1549,
	Name = "压制会舍命的敌人暴击",
	Desc = "会舍命的敌人暴击 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200004,
		Tag = 
		{
			564562,
		},
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id1550] =
{
	Id = 1550,
	Name = "压制会破甲的敌人生命",
	Desc = "会破甲的敌人生命 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200001,
		Tag = 
		{
			564563,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id1551] =
{
	Id = 1551,
	Name = "压制会破甲的敌人攻击",
	Desc = "会破甲的敌人攻击 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200002,
		Tag = 
		{
			564563,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id1552] =
{
	Id = 1552,
	Name = "压制会破甲的敌人忍耐",
	Desc = "会破甲的敌人忍耐 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200003,
		Tag = 
		{
			564563,
		},
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id1553] =
{
	Id = 1553,
	Name = "压制会破甲的敌人暴击",
	Desc = "会破甲的敌人暴击 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200004,
		Tag = 
		{
			564563,
		},
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id1554] =
{
	Id = 1554,
	Name = "压制会削弱的敌人生命",
	Desc = "会削弱的敌人生命 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200001,
		Tag = 
		{
			564564,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id1555] =
{
	Id = 1555,
	Name = "压制会削弱的敌人攻击",
	Desc = "会削弱的敌人攻击 -{Value}%",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200002,
		Tag = 
		{
			564564,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id1556] =
{
	Id = 1556,
	Name = "压制会削弱的敌人忍耐",
	Desc = "会削弱的敌人忍耐 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200003,
		Tag = 
		{
			564564,
		},
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id1557] =
{
	Id = 1557,
	Name = "压制会削弱的敌人暴击",
	Desc = "会削弱的敌人暴击 -{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "SpecificEnemyAbility",
		EffectValue = 200004,
		Tag = 
		{
			564564,
		},
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
}
SkillConfig[SkillID.Id1701] =
{
	Id = 1701,
	Name = "恢复",
	Desc = "每回合回血 {Value}，最多3次",
	Dialog = "治疗术",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1702] =
{
	Id = 1702,
	Name = "中期恢复",
	Desc = "3回合后，每回合回血 {Value}，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 1,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1703] =
{
	Id = 1703,
	Name = "战吼",
	Desc = "每回合攻击 +{Value}，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1704] =
{
	Id = 1704,
	Name = "鼓舞",
	Desc = "每回合忍耐 +{Value}，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1705] =
{
	Id = 1705,
	Name = "每回合暴击+",
	Desc = "每回合暴击 +{Value}，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1706] =
{
	Id = 1706,
	Name = "全队恢复",
	Desc = "每回合全队回血 {Value}，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1707] =
{
	Id = 1707,
	Name = "全队战吼",
	Desc = "每回合全队攻击 +{Value}，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1708] =
{
	Id = 1708,
	Name = "全队鼓舞",
	Desc = "每回合全队忍耐 +{Value}，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1709] =
{
	Id = 1709,
	Name = "每回合全队暴击+",
	Desc = "每回合全队暴击 +{Value}，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1710] =
{
	Id = 1710,
	Name = "前方恢复",
	Desc = "每回合身前2名队员回血 {Value}，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			-1,-2,
		},
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1711] =
{
	Id = 1711,
	Name = "前方战吼",
	Desc = "每回合自身及身前2名队员攻击 +{Value}，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			0,-1,-2,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1712] =
{
	Id = 1712,
	Name = "前方鼓舞",
	Desc = "每回合自身及身前2名队员忍耐 +{Value}，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			0,-1,-2,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1713] =
{
	Id = 1713,
	Name = "每回合前方暴击+",
	Desc = "每回合自身及身前2名队员攻暴击 +{Value}，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			0,-1,-2,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1714] =
{
	Id = 1714,
	Name = "大恢复",
	Desc = "每3回合回血 {Value}，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1715] =
{
	Id = 1715,
	Name = "大战吼",
	Desc = "每3回合攻击 +{Value}，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1716] =
{
	Id = 1716,
	Name = "大鼓舞",
	Desc = "每3回合忍耐 +{Value}，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1717] =
{
	Id = 1717,
	Name = "每3回合暴击+",
	Desc = "每3回合暴击 +{Value}，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1718] =
{
	Id = 1718,
	Name = "全队大恢复",
	Desc = "每3回合全队回血 {Value}，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1719] =
{
	Id = 1719,
	Name = "全队大战吼",
	Desc = "每3回合全队攻击 +{Value}，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1720] =
{
	Id = 1720,
	Name = "全队大鼓舞",
	Desc = "每3回合全队忍耐 +{Value}，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1721] =
{
	Id = 1721,
	Name = "每3回合全队暴击+",
	Desc = "每3回合全队暴击 +{Value}，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1722] =
{
	Id = 1722,
	Name = "延迟大恢复",
	Desc = "3回合后，每回合回血 {Value}，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 1,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1723] =
{
	Id = 1723,
	Name = "延迟大战吼",
	Desc = "3回合后，每回合攻击 +{Value}，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 1,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1724] =
{
	Id = 1724,
	Name = "延迟大鼓舞",
	Desc = "3回合后，每回合忍耐 +{Value}，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 1,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1725] =
{
	Id = 1725,
	Name = "3回合后，每回合暴击+",
	Desc = "3回合后，每回合暴击 +{Value}，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 1,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1726] =
{
	Id = 1726,
	Name = "延迟全队大恢复",
	Desc = "3回合后，每回合全队回血 {Value}，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 1,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1727] =
{
	Id = 1727,
	Name = "延迟全队大战吼",
	Desc = "3回合后，每回合全队攻击 +{Value}，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 1,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1728] =
{
	Id = 1728,
	Name = "延迟全队大鼓舞",
	Desc = "3回合后，每回合全队忍耐 +{Value}，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 1,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1729] =
{
	Id = 1729,
	Name = "3回合后，每回合全队暴击+",
	Desc = "3回合后，每回合全队暴击 +{Value}，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 1,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1730] =
{
	Id = 1730,
	Name = "超级恢复",
	Desc = "5回合后，回血 {Value}",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 1,
		Limited = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1731] =
{
	Id = 1731,
	Name = "超级战吼",
	Desc = "5回合后，攻击 +{Value}",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 1,
		Limited = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1732] =
{
	Id = 1732,
	Name = "超级鼓舞",
	Desc = "5回合后，忍耐 +{Value}",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 1,
		Limited = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1733] =
{
	Id = 1733,
	Name = "5回合后一次性暴击+",
	Desc = "5回合后，暴击 +{Value}",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 1,
		Limited = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1734] =
{
	Id = 1734,
	Name = "暴率升华",
	Desc = "5回合后，暴率 +{Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 1,
		Limited = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "CritChance",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1735] =
{
	Id = 1735,
	Name = "危险治疗",
	Desc = "每回合50%概率自身回血 {Value}%，最多5次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1736] =
{
	Id = 1736,
	Name = "危险治疗",
	Desc = "每个队员回合有50%概率回血 {Value}",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 50,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1737] =
{
	Id = 1737,
	Name = "危险治疗",
	Desc = "每回合33%概率自身回血 {Value}%，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1738] =
{
	Id = 1738,
	Name = "初级连击",
	Desc = "有{Value}%概率额外攻击1次",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExtraAttack",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id1739] =
{
	Id = 1739,
	Name = "中级连击",
	Desc = "有{Value}%概率额外攻击2次",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExtraAttack",
		EffectValue = 2,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id1740] =
{
	Id = 1740,
	Name = "高级连击",
	Desc = "有{Value}%概率额外攻击3次",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExtraAttack",
		EffectValue = 3,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
}
SkillConfig[SkillID.Id1741] =
{
	Id = 1741,
	Name = "面前队员初级连击",
	Desc = "身前1名队员{Value}%概率连击1次",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			-1,
		},
	},
	Effect = {
		EffectAttribute = "ExtraAttack",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1742] =
{
	Id = 1742,
	Name = "大侦探初级连击",
	Desc = "大侦探有{Value}%概率额外攻击1次",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220324,
		},
	},
	Effect = {
		EffectAttribute = "ExtraAttack",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1743] =
{
	Id = 1743,
	Name = "大侦探闪避术",
	Desc = "大侦探{Value}%概率闪避攻击",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Characters = 
		{
			220324,
		},
	},
	Effect = {
		EffectAttribute = "Dodge",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1744] =
{
	Id = 1744,
	Name = "概率闪避敌人攻击",
	Desc = "{Value}%概率闪避攻击",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Dodge",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1745] =
{
	Id = 1745,
	Name = "概率无视敌人闪避",
	Desc = "{Value}%概率无视敌人的闪避",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DodgeIgnore",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1746] =
{
	Id = 1746,
	Name = "黑暗料理恢复",
	Desc = "3回合后，非美食星队员每回合50%回血 {Value}%，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 1,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
		Tag = 
		{
			560204,
		},
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 50,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1747] =
{
	Id = 1747,
	Name = "白猫的必中",
	Desc = "最后一个队员{Value}%概率无视敌人的闪避",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.FixPosition,
		PositionValue = 
		{
			-1,
		},
	},
	Effect = {
		EffectAttribute = "DodgeIgnore",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1748] =
{
	Id = 1748,
	Name = "前方治疗",
	Desc = "每回合治疗前2队员{Value}自身攻击的生命",
	Dialog = "战斗治疗！",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			-1,-2,
		},
	},
	Effect = {
		EffectAttribute = "RecoveryWithAtk",
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1749] =
{
	Id = 1749,
	Name = "全队大治疗",
	Desc = "每3回合治疗全队{Value}%自身攻击的生命",
	Dialog = "沐浴神恩吧！",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "RecoveryWithAtk",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1750] =
{
	Id = 1750,
	Name = "“伯爵”吸血",
	Desc = "第5、6、7回合，恢复攻击{Value}%生命",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 1,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RecoveryWithAtk",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1751] =
{
	Id = 1751,
	Name = "动力心脏恢复",
	Desc = "每回合自身回血 {Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1752] =
{
	Id = 1752,
	Name = "全队闪避+",
	Desc = "全队{Value}%概率闪避攻击",
	Dialog = "你们的一举一动都在我意料之中",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Dodge",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1753] =
{
	Id = 1753,
	Name = "全队必中+",
	Desc = "全队{Value}%概率无视敌人闪避",
	Dialog = "再来一次，一定会中的！",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "DodgeIgnore",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1754] =
{
	Id = 1754,
	Name = "3星及以下队员恢复",
	Desc = "每回合紫色及以下品质队员回血 {Value}%，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
		Rarity = 4,
		RarityOp = 1,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1755] =
{
	Id = 1755,
	Name = "3星及以下队员战吼",
	Desc = "每回合紫色及以下品质队员攻击 +{Value}%，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
		Rarity = 4,
		RarityOp = 1,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1756] =
{
	Id = 1756,
	Name = "3星及以下队员鼓舞",
	Desc = "每回合紫色及以下品质队员忍耐 +{Value}，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
		Rarity = 4,
		RarityOp = 1,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1757] =
{
	Id = 1757,
	Name = "3星及以下队员暴击+",
	Desc = "每回合紫色及以下品质队员暴击 +{Value}，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
		Rarity = 4,
		RarityOp = 1,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1758] =
{
	Id = 1758,
	Name = "全队初级连击",
	Desc = "全队有{Value}%概率额外攻击1次",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "ExtraAttack",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1759] =
{
	Id = 1759,
	Name = "攻击附加损失生命%",
	Desc = "1回合后攻击附加自身损失生命{Value}%的伤害",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "HpAttackOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1760] =
{
	Id = 1760,
	Name = "无视敌人忍耐攻击",
	Desc = "1回合后攻击时无视敌人{Value}忍耐",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DefendIgnoreOnce",
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1761] =
{
	Id = 1761,
	Name = "无视敌人忍耐攻击%",
	Desc = "1回合后攻击时无视敌人{Value}%忍耐",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "DefendIgnoreOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1762] =
{
	Id = 1762,
	Name = "根据受击次数攻击+%",
	Desc = "回合中，每次受击，攻击 +{Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "AttributeWithHurt",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1763] =
{
	Id = 1763,
	Name = "根据受击次数攻击+",
	Desc = "回合中，每次受击，攻击 +{Value}",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "AttributeWithHurt",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1764] =
{
	Id = 1764,
	Name = "根据受击次数忍耐+",
	Desc = "回合中，每次受击，忍耐 +{Value}",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "AttributeWithHurt",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1765] =
{
	Id = 1765,
	Name = "根据受击次数暴击+",
	Desc = "回合中，每次受击，暴击 +{Value}",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "AttributeWithHurt",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1766] =
{
	Id = 1766,
	Name = "根据受击次数恢复",
	Desc = "回合中，每次受击，回血{Value}",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RecoveryWithHurt",
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1767] =
{
	Id = 1767,
	Name = "根据受击次数恢复%",
	Desc = "回合中，每次受击，回血{Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RecoveryWithHurt",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1768] =
{
	Id = 1768,
	Name = "恢复",
	Desc = "每回合回血 {Value}%，最多3次",
	Dialog = "喵呜~",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1769] =
{
	Id = 1769,
	Name = "5回合后单次4连击",
	Desc = "第5回合，必定4连击",
	Dialog = "叫你改！",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 4,
		IntervalRound = 1,
		Limited = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExtraAttackOnce",
		EffectValue = 3,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1770] =
{
	Id = 1770,
	Name = "前方治疗",
	Desc = "每回合治疗前2队员{Value}自身攻击的生命",
	Dialog = "战斗治疗！",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			-1,-2,
		},
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1771] =
{
	Id = 1771,
	Name = "全队大治疗",
	Desc = "每3回合治疗全队{Value}%自身攻击的生命",
	Dialog = "沐浴神恩吧！",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 3,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1772] =
{
	Id = 1772,
	Name = "延迟身前两名队员大恢复",
	Desc = "3回合后，每回合身前两名队员回血 {Value}，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 1,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			-1,-2,
		},
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1773] =
{
	Id = 1773,
	Name = "延迟身前两名队员大战吼",
	Desc = "3回合后，每回合身前两名队员攻击 +{Value}，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 1,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			-1,-2,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1774] =
{
	Id = 1774,
	Name = "延迟身前两名队员大鼓舞",
	Desc = "3回合后，每回合身前两名队员忍耐 +{Value}，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 1,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			-1,-2,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1775] =
{
	Id = 1775,
	Name = "3回合后，每回合身前两名队员暴击+",
	Desc = "3回合后，每回合身前两名队员暴击 +{Value}，最多3次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 1,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			-1,-2,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1776] =
{
	Id = 1776,
	Name = "5回合后一次性前方恢复",
	Desc = "5回合后，身前两名队员回血 {Value}",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 1,
		Limited = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			-1,-2,
		},
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1777] =
{
	Id = 1777,
	Name = "5回合后一次性前方攻击+",
	Desc = "5回合后，身前两名队员攻击 +{Value}",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 1,
		Limited = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			-1,-2,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1778] =
{
	Id = 1778,
	Name = "5回合后一次性前方忍耐+",
	Desc = "5回合后，身前两名队员忍耐 +{Value}",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 1,
		Limited = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			-1,-2,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1779] =
{
	Id = 1779,
	Name = "5回合后一次性前方暴击+",
	Desc = "5回合后，身前两名队员暴击 +{Value}",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 1,
		Limited = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.RelativePosition,
		PositionValue = 
		{
			-1,-2,
		},
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1780] =
{
	Id = 1780,
	Name = "5回合后一次性全队恢复",
	Desc = "5回合后，全队回血 {Value}",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 1,
		Limited = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1781] =
{
	Id = 1781,
	Name = "5回合后一次性全队攻击+",
	Desc = "5回合后，全队攻击 +{Value}",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 1,
		Limited = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200002,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1782] =
{
	Id = 1782,
	Name = "5回合后一次性全队忍耐+",
	Desc = "5回合后，全队忍耐 +{Value}",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 1,
		Limited = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1783] =
{
	Id = 1783,
	Name = "5回合后一次性全队暴击+",
	Desc = "5回合后，全队暴击 +{Value}",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 5,
		IntervalRound = 1,
		Limited = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1784] =
{
	Id = 1784,
	Name = "5回合后单次4连击",
	Desc = "第5回合，必定4连击",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 4,
		IntervalRound = 1,
		Limited = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExtraAttackOnce",
		EffectValue = 3,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1785] =
{
	Id = 1785,
	Name = "全队每次受击恢复",
	Desc = "队员每次受击回血 {Value}",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "RecoveryWithHurt",
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1786] =
{
	Id = 1786,
	Name = "每4回合单次闪避",
	Desc = "每4回合，{Value}%概率闪避攻击",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 4,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "DodgeOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1787] =
{
	Id = 1787,
	Name = "每回合每个男性使全队忍耐+",
	Desc = "每回合每个男性队员使全队忍耐 +{Value}，最多5次",
	EffectModule = EffectModule.Battle,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			561702,
		},
	},
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200003,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1788] =
{
	Id = 1788,
	Name = "每回合每个女性使全队暴击+",
	Desc = "每回合每个女性队员使全队暴击 +{Value}，最多5次",
	EffectModule = EffectModule.Battle,
	MultiCount = true,
	EffectCondition = {
		Tag = 
		{
			561703,
		},
	},
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Team,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200004,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1901] =
{
	Id = 1901,
	Name = "打工金币+",
	Desc = "打工金币数量 +{Value}%",
	EffectModule = EffectModule.WorkShop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "WorkShopGoodsNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1902] =
{
	Id = 1902,
	Name = "打工食物+",
	Desc = "打工食物数量 +{Value}%",
	EffectModule = EffectModule.WorkShop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "WorkShopGoodsNumber",
		Tag = 
		{
			564306,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1903] =
{
	Id = 1903,
	Name = "打工捕捉道具+",
	Desc = "打工捕捉道具数量 +{Value}%",
	EffectModule = EffectModule.WorkShop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "WorkShopGoodsNumber",
		Tag = 
		{
			564307,
		},
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1904] =
{
	Id = 1904,
	Name = "打工工时+",
	Desc = "打工中，最大工时 +{Value}%",
	EffectModule = EffectModule.WorkShop,
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "WorkShopMaxWorkTime",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1905] =
{
	Id = 1905,
	Name = "上交探索金币+",
	Desc = "原始人妈妈在场时探索金币 -{Value}%",
	EffectModule = EffectModule.ExploreDrop,
	EffectCondition = {
		Teamer = 
		{
			220215,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "GoodsDropNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1906] =
{
	Id = 1906,
	Name = "打工金币+",
	Desc = "原始人爸爸在场时打工金币 +{Value}%",
	EffectModule = EffectModule.WorkShop,
	EffectCondition = {
		Teamer = 
		{
			220214,
		},
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "WorkShopGoodsNumber",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1907] =
{
	Id = 1907,
	Name = "回合3~5，每回合可额外攻击1次",
	Desc = "第3、4、5回合，{Value}%概率连击1次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 2,
		IntervalRound = 1,
		Limited = 3,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExtraAttackOnce",
		EffectValue = 1,
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1908] =
{
	Id = 1908,
	Name = "水元素队员亲和+",
	Desc = "水元素队员亲和+{Value}",
	EffectModule = EffectModule.BuildTeam,
	EffectRange = {
		EffectScope = EffectScope.Team,
		Element = 210001,
	},
	Effect = {
		EffectAttribute = "Ability",
		EffectValue = 200006,
		Chance = 100,
		CalculateType = CalculateType.Abs,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1909] =
{
	Id = 1909,
	Name = "回合3、4受击恢复33%",
	Desc = "第3、4回合，每次受击，回血{Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 3,
		IntervalRound = 1,
		Limited = 2,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RecoveryWithHurt",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1910] =
{
	Id = 1910,
	Name = "每回合根据攻击恢复，最多5次",
	Desc = "每回合，恢复攻击{Value}%生命，最多5次",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 1,
		Limited = 5,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "RecoveryWithAtk",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1911] =
{
	Id = 1911,
	Name = "5回合后一次性恢复100%生命",
	Desc = "第5回合，回血{Value}%",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		IntervalRound = 1,
		Limited = 1,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "Recovery",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
SkillConfig[SkillID.Id1912] =
{
	Id = 1912,
	Name = "每2回合100%连击",
	Desc = "每2回合，{Value}%概率连击",
	EffectModule = EffectModule.Battle,
	BattleParameter = {
		StartRound = 1,
		IntervalRound = 2,
		Limited = 233,
	},
	EffectRange = {
		EffectScope = EffectScope.Self,
	},
	Effect = {
		EffectAttribute = "ExtraAttackOnce",
		Chance = 100,
		CalculateType = CalculateType.Percent,
	},
	EffectPrefab = "SkillEffect",
}
