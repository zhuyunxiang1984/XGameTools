AbilityConfig ={};
AbilityID = 
{
	Id001 = 200001,
	Id002 = 200002,
	Id003 = 200003,
	Id004 = 200004,
	Id005 = 200005,
	Id006 = 200006,
	Id007 = 200007,
	Id008 = 200008,
}
AbilityConfig[AbilityID.Id001] =
{
	Id = 1,
	Name = "生命",
	FightPower = 1,
	Desc = "扛揍能力，每点1战力",
	Icon = "Ability_Hp",
}
AbilityConfig[AbilityID.Id002] =
{
	Id = 2,
	Name = "攻击",
	FightPower = 1,
	Desc = "造成伤害，每点1战力",
	Icon = "Ability_Atk",
}
AbilityConfig[AbilityID.Id003] =
{
	Id = 3,
	Name = "忍耐",
	FightPower = 10,
	Desc = "减伤指数，每点10战力",
	Icon = "Ability_Def",
}
AbilityConfig[AbilityID.Id004] =
{
	Id = 4,
	Name = "暴击",
	FightPower = 10,
	Desc = "暴击指数，每点10战力",
	Icon = "Ability_Crit",
}
AbilityConfig[AbilityID.Id005] =
{
	Id = 5,
	Name = "技巧",
	FightPower = 0,
	Desc = "技巧，动手能力",
	Icon = "Ability_Technique",
}
AbilityConfig[AbilityID.Id006] =
{
	Id = 6,
	Name = "亲和",
	FightPower = 0,
	Desc = "亲和，沟通能力",
	Icon = "Ability_Lovely",
}
AbilityConfig[AbilityID.Id007] =
{
	Id = 7,
	Name = "力气",
	FightPower = 0,
	Desc = "力气，运动能力",
	Icon = "Ability_Strength",
}
AbilityConfig[AbilityID.Id008] =
{
	Id = 8,
	Name = "智力",
	FightPower = 0,
	Desc = "智力，思维能力",
	Icon = "Ability_Wisdom",
}

