ActivityDailyLoginConfig ={};
ActivityDailyLoginID = 
{
	Id001 = 580001,
	Id002 = 580002,
	Id003 = 580003,
	Id004 = 580004,
	Id005 = 580005,
	Id006 = 580006,
	Id007 = 580007,
	Id008 = 580008,
	Id009 = 580009,
	Id010 = 580010,
	Id011 = 580011,
	Id012 = 580012,
	Id013 = 580013,
	Id014 = 580014,
	Id015 = 580015,
	Id016 = 580016,
	Id017 = 580017,
	Id018 = 580018,
	Id019 = 580019,
	Id020 = 580020,
	Id021 = 580021,
	Id022 = 580022,
	Id023 = 580023,
	Id024 = 580024,
	Id025 = 580025,
	Id026 = 580026,
	Id027 = 580027,
	Id028 = 580028,
	Id029 = 580029,
	Id030 = 580030,
	Id031 = 580031,
	Id032 = 580032,
	Id033 = 580033,
	Id034 = 580034,
	Id035 = 580035,
	Id036 = 580036,
	Id037 = 580037,
	Id038 = 580038,
	Id039 = 580039,
	Id040 = 580040,
	Id041 = 580041,
	Id042 = 580042,
	Id043 = 580043,
	Id044 = 580044,
	Id045 = 580045,
	Id046 = 580046,
	Id047 = 580047,
	Id048 = 580048,
	Id049 = 580049,
	Id050 = 580050,
	Id051 = 580051,
	Id052 = 580052,
	Id053 = 580053,
	Id054 = 580054,
	Id055 = 580055,
	Id056 = 580056,
	Id057 = 580057,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id001] =
{
	Id = 1,
	Value = 327314,
	Num = 10,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id002] =
{
	Id = 2,
	Value = 327314,
	Num = 10,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id003] =
{
	Id = 3,
	Value = 2,
	Num = 100,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id004] =
{
	Id = 4,
	Value = 327314,
	Num = 10,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id005] =
{
	Id = 5,
	Value = 1,
	Num = 50000,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id006] =
{
	Id = 6,
	Value = 327314,
	Num = 10,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id007] =
{
	Id = 7,
	Value = 330003,
	Num = 5,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id008] =
{
	Id = 8,
	Value = 327314,
	Num = 12,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id009] =
{
	Id = 9,
	Value = 327314,
	Num = 12,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id010] =
{
	Id = 10,
	Value = 2,
	Num = 120,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id011] =
{
	Id = 11,
	Value = 327314,
	Num = 12,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id012] =
{
	Id = 12,
	Value = 1,
	Num = 100000,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id013] =
{
	Id = 13,
	Value = 327314,
	Num = 12,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id014] =
{
	Id = 14,
	Value = 327314,
	Num = 150,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id015] =
{
	Id = 15,
	Value = 327314,
	Num = 10,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id016] =
{
	Id = 16,
	Value = 327314,
	Num = 10,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id017] =
{
	Id = 17,
	Value = 2,
	Num = 150,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id018] =
{
	Id = 18,
	Value = 327314,
	Num = 10,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id019] =
{
	Id = 19,
	Value = 1,
	Num = 150000,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id020] =
{
	Id = 20,
	Value = 327314,
	Num = 10,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id021] =
{
	Id = 21,
	Value = 330003,
	Num = 5,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id022] =
{
	Id = 22,
	Value = 327314,
	Num = 10,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id023] =
{
	Id = 23,
	Value = 327314,
	Num = 10,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id024] =
{
	Id = 24,
	Value = 2,
	Num = 120,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id025] =
{
	Id = 25,
	Value = 2,
	Num = 100,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id026] =
{
	Id = 26,
	Value = 2,
	Num = 100,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id027] =
{
	Id = 27,
	Value = 1,
	Num = 40000,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id028] =
{
	Id = 28,
	Value = 320412,
	Num = 10,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id029] =
{
	Id = 29,
	Value = 320001,
	Num = 5,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id030] =
{
	Id = 30,
	Value = 2,
	Num = 150,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id031] =
{
	Id = 31,
	Value = 1,
	Num = 70000,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id032] =
{
	Id = 32,
	Value = 330003,
	Num = 5,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id033] =
{
	Id = 33,
	Value = 2,
	Num = 150,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id034] =
{
	Id = 34,
	Value = 1,
	Num = 100000,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id035] =
{
	Id = 35,
	Value = 320053,
	Num = 30,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id036] =
{
	Id = 36,
	Value = 320043,
	Num = 30,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id037] =
{
	Id = 37,
	Value = 2,
	Num = 200,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id038] =
{
	Id = 38,
	Value = 1,
	Num = 140000,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id039] =
{
	Id = 39,
	Value = 330003,
	Num = 5,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id040] =
{
	Id = 40,
	Value = 2,
	Num = 200,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id041] =
{
	Id = 41,
	Value = 2,
	Num = 200,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id042] =
{
	Id = 42,
	Value = 2,
	Num = 100,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id043] =
{
	Id = 43,
	Value = 327318,
	Num = 10,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id044] =
{
	Id = 44,
	Value = 1,
	Num = 40000,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id045] =
{
	Id = 45,
	Value = 327319,
	Num = 10,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id046] =
{
	Id = 46,
	Value = 2,
	Num = 150,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id047] =
{
	Id = 47,
	Value = 1,
	Num = 70000,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id048] =
{
	Id = 48,
	Value = 330003,
	Num = 5,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id049] =
{
	Id = 49,
	Value = 2,
	Num = 150,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id050] =
{
	Id = 50,
	Value = 1,
	Num = 100000,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id051] =
{
	Id = 51,
	Value = 320002,
	Num = 6,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id052] =
{
	Id = 52,
	Value = 2,
	Num = 200,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id053] =
{
	Id = 53,
	Value = 1,
	Num = 140000,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id054] =
{
	Id = 54,
	Value = 320003,
	Num = 4,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id055] =
{
	Id = 55,
	Value = 330003,
	Num = 5,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id056] =
{
	Id = 56,
	Value = 2,
	Num = 200,
}
ActivityDailyLoginConfig[ActivityDailyLoginID.Id057] =
{
	Id = 57,
	Value = 2,
	Num = 200,
}

