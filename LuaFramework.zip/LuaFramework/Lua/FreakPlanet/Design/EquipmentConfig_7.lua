
EquipmentConfig[EquipmentID.Id211] =
{
	Character = 220224,
	Rarity = 4,
	UpgradeId = 930034,
	LevelList = {
		{
			Level = 1,
			Info = 920240,
			Ability = {
				{
					Value = 200001,
					Num = 72,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920240,
			Ability = {
				{
					Value = 200001,
					Num = 144,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920240,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920240,
			Ability = {
				{
					Value = 200001,
					Num = 288,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920240,
			Ability = {
				{
					Value = 200001,
					Num = 360,
				},
				{
					Value = 200008,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920240,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920240,
			Ability = {
				{
					Value = 200001,
					Num = 504,
				},
				{
					Value = 200008,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920240,
			Ability = {
				{
					Value = 200001,
					Num = 576,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920240,
			Ability = {
				{
					Value = 200001,
					Num = 648,
				},
				{
					Value = 200008,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920240,
			Ability = {
				{
					Value = 200001,
					Num = 720,
				},
				{
					Value = 200008,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id212] =
{
	Character = 220224,
	Rarity = 4,
	NeedChallenge = 145086,
	UpgradeId = 930015,
	LevelList = {
		{
			Level = 1,
			Info = 920241,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
			},
		},
		{
			Level = 2,
			Info = 920241,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
			},
		},
		{
			Level = 3,
			Info = 920241,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
		},
		{
			Level = 4,
			Info = 920241,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
			},
		},
		{
			Level = 5,
			Info = 920241,
			Ability = {
				{
					Value = 200002,
					Num = 396,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920241,
			Ability = {
				{
					Value = 200002,
					Num = 468,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920241,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920241,
			Ability = {
				{
					Value = 200002,
					Num = 612,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101741,
					Value = 15,
				},
			},
		},
		{
			Level = 9,
			Info = 920241,
			Ability = {
				{
					Value = 200002,
					Num = 684,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101741,
					Value = 15,
				},
			},
		},
		{
			Level = 10,
			Info = 920241,
			Ability = {
				{
					Value = 200002,
					Num = 756,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101741,
					Value = 15,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id213] =
{
	Character = 220225,
	Rarity = 4,
	UpgradeId = 930033,
	LevelList = {
		{
			Level = 1,
			Info = 920242,
			Ability = {
				{
					Value = 200001,
					Num = 69,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920242,
			Ability = {
				{
					Value = 200001,
					Num = 138,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920242,
			Ability = {
				{
					Value = 200001,
					Num = 207,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920242,
			Ability = {
				{
					Value = 200001,
					Num = 276,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920242,
			Ability = {
				{
					Value = 200001,
					Num = 345,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920242,
			Ability = {
				{
					Value = 200001,
					Num = 414,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920242,
			Ability = {
				{
					Value = 200001,
					Num = 483,
				},
				{
					Value = 200008,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920242,
			Ability = {
				{
					Value = 200001,
					Num = 552,
				},
				{
					Value = 200008,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920242,
			Ability = {
				{
					Value = 200001,
					Num = 621,
				},
				{
					Value = 200008,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920242,
			Ability = {
				{
					Value = 200001,
					Num = 690,
				},
				{
					Value = 200008,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id214] =
{
	Character = 220225,
	Rarity = 4,
	UpgradeId = 930014,
	LevelList = {
		{
			Level = 1,
			Info = 920243,
			Ability = {
				{
					Value = 200002,
					Num = 57,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920243,
			Ability = {
				{
					Value = 200002,
					Num = 114,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920243,
			Ability = {
				{
					Value = 200002,
					Num = 171,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920243,
			Ability = {
				{
					Value = 200002,
					Num = 228,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920243,
			Ability = {
				{
					Value = 200002,
					Num = 285,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920243,
			Ability = {
				{
					Value = 200002,
					Num = 342,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920243,
			Ability = {
				{
					Value = 200002,
					Num = 399,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920243,
			Ability = {
				{
					Value = 200002,
					Num = 456,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920243,
			Ability = {
				{
					Value = 200002,
					Num = 513,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920243,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id215] =
{
	Character = 220225,
	Rarity = 4,
	NeedChallenge = 145087,
	UpgradeId = 930015,
	LevelList = {
		{
			Level = 1,
			Info = 920244,
			Ability = {
				{
					Value = 200002,
					Num = 114,
				},
			},
		},
		{
			Level = 2,
			Info = 920244,
			Ability = {
				{
					Value = 200002,
					Num = 190,
				},
			},
		},
		{
			Level = 3,
			Info = 920244,
			Ability = {
				{
					Value = 200002,
					Num = 266,
				},
			},
		},
		{
			Level = 4,
			Info = 920244,
			Ability = {
				{
					Value = 200002,
					Num = 342,
				},
			},
		},
		{
			Level = 5,
			Info = 920244,
			Ability = {
				{
					Value = 200002,
					Num = 418,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920244,
			Ability = {
				{
					Value = 200002,
					Num = 494,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920244,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920244,
			Ability = {
				{
					Value = 200002,
					Num = 646,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101703,
					Value = 300,
				},
			},
		},
		{
			Level = 9,
			Info = 920244,
			Ability = {
				{
					Value = 200002,
					Num = 722,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101703,
					Value = 300,
				},
			},
		},
		{
			Level = 10,
			Info = 920244,
			Ability = {
				{
					Value = 200002,
					Num = 798,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101703,
					Value = 300,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id216] =
{
	Character = 220226,
	Rarity = 4,
	UpgradeId = 930033,
	LevelList = {
		{
			Level = 1,
			Info = 920245,
			Ability = {
				{
					Value = 200001,
					Num = 69,
				},
				{
					Value = 200006,
					Num = 21,
				},
			},
		},
		{
			Level = 2,
			Info = 920245,
			Ability = {
				{
					Value = 200001,
					Num = 138,
				},
				{
					Value = 200006,
					Num = 42,
				},
			},
		},
		{
			Level = 3,
			Info = 920245,
			Ability = {
				{
					Value = 200001,
					Num = 207,
				},
				{
					Value = 200006,
					Num = 63,
				},
			},
		},
		{
			Level = 4,
			Info = 920245,
			Ability = {
				{
					Value = 200001,
					Num = 276,
				},
				{
					Value = 200006,
					Num = 84,
				},
			},
		},
		{
			Level = 5,
			Info = 920245,
			Ability = {
				{
					Value = 200001,
					Num = 345,
				},
				{
					Value = 200006,
					Num = 105,
				},
			},
		},
		{
			Level = 6,
			Info = 920245,
			Ability = {
				{
					Value = 200001,
					Num = 414,
				},
				{
					Value = 200006,
					Num = 126,
				},
			},
		},
		{
			Level = 7,
			Info = 920245,
			Ability = {
				{
					Value = 200001,
					Num = 483,
				},
				{
					Value = 200006,
					Num = 147,
				},
			},
		},
		{
			Level = 8,
			Info = 920245,
			Ability = {
				{
					Value = 200001,
					Num = 552,
				},
				{
					Value = 200006,
					Num = 168,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920245,
			Ability = {
				{
					Value = 200001,
					Num = 621,
				},
				{
					Value = 200006,
					Num = 189,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920245,
			Ability = {
				{
					Value = 200001,
					Num = 690,
				},
				{
					Value = 200006,
					Num = 210,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id217] =
{
	Character = 220226,
	Rarity = 4,
	UpgradeId = 930014,
	LevelList = {
		{
			Level = 1,
			Info = 920246,
			Ability = {
				{
					Value = 200002,
					Num = 57,
				},
			},
			SkillList = {
				{
					Id = 100781,
					Value = 13,
				},
			},
		},
		{
			Level = 2,
			Info = 920246,
			Ability = {
				{
					Value = 200002,
					Num = 114,
				},
			},
			SkillList = {
				{
					Id = 100781,
					Value = 15,
				},
			},
		},
		{
			Level = 3,
			Info = 920246,
			Ability = {
				{
					Value = 200002,
					Num = 171,
				},
			},
			SkillList = {
				{
					Id = 100781,
					Value = 17,
				},
			},
		},
		{
			Level = 4,
			Info = 920246,
			Ability = {
				{
					Value = 200002,
					Num = 228,
				},
			},
			SkillList = {
				{
					Id = 100781,
					Value = 19,
				},
			},
		},
		{
			Level = 5,
			Info = 920246,
			Ability = {
				{
					Value = 200002,
					Num = 285,
				},
			},
			SkillList = {
				{
					Id = 100781,
					Value = 21,
				},
			},
		},
		{
			Level = 6,
			Info = 920246,
			Ability = {
				{
					Value = 200002,
					Num = 342,
				},
			},
			SkillList = {
				{
					Id = 100781,
					Value = 23,
				},
			},
		},
		{
			Level = 7,
			Info = 920246,
			Ability = {
				{
					Value = 200002,
					Num = 399,
				},
			},
			SkillList = {
				{
					Id = 100781,
					Value = 25,
				},
			},
		},
		{
			Level = 8,
			Info = 920246,
			Ability = {
				{
					Value = 200002,
					Num = 456,
				},
			},
			SkillList = {
				{
					Id = 100781,
					Value = 27,
				},
				{
					Id = 100555,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920246,
			Ability = {
				{
					Value = 200002,
					Num = 513,
				},
			},
			SkillList = {
				{
					Id = 100781,
					Value = 29,
				},
				{
					Id = 100555,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920246,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
			},
			SkillList = {
				{
					Id = 100781,
					Value = 31,
				},
				{
					Id = 100555,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id218] =
{
	Character = 220226,
	Rarity = 4,
	NeedChallenge = 145088,
	UpgradeId = 930015,
	LevelList = {
		{
			Level = 1,
			Info = 920247,
			Ability = {
				{
					Value = 200002,
					Num = 114,
				},
			},
		},
		{
			Level = 2,
			Info = 920247,
			Ability = {
				{
					Value = 200002,
					Num = 190,
				},
			},
		},
		{
			Level = 3,
			Info = 920247,
			Ability = {
				{
					Value = 200002,
					Num = 266,
				},
			},
		},
		{
			Level = 4,
			Info = 920247,
			Ability = {
				{
					Value = 200002,
					Num = 342,
				},
			},
		},
		{
			Level = 5,
			Info = 920247,
			Ability = {
				{
					Value = 200002,
					Num = 418,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920247,
			Ability = {
				{
					Value = 200002,
					Num = 494,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920247,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920247,
			Ability = {
				{
					Value = 200002,
					Num = 646,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101745,
					Value = 60,
				},
			},
		},
		{
			Level = 9,
			Info = 920247,
			Ability = {
				{
					Value = 200002,
					Num = 722,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101745,
					Value = 60,
				},
			},
		},
		{
			Level = 10,
			Info = 920247,
			Ability = {
				{
					Value = 200002,
					Num = 798,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101745,
					Value = 60,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id219] =
{
	Character = 220227,
	Rarity = 4,
	UpgradeId = 930013,
	LevelList = {
		{
			Level = 1,
			Info = 920248,
			Ability = {
				{
					Value = 200002,
					Num = 60,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920248,
			Ability = {
				{
					Value = 200002,
					Num = 120,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920248,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920248,
			Ability = {
				{
					Value = 200002,
					Num = 240,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920248,
			Ability = {
				{
					Value = 200002,
					Num = 300,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920248,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920248,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200008,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920248,
			Ability = {
				{
					Value = 200002,
					Num = 480,
				},
				{
					Value = 200008,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920248,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200008,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920248,
			Ability = {
				{
					Value = 200002,
					Num = 600,
				},
				{
					Value = 200008,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id220] =
{
	Character = 220227,
	Rarity = 4,
	UpgradeId = 930034,
	LevelList = {
		{
			Level = 1,
			Info = 920249,
			Ability = {
				{
					Value = 200001,
					Num = 69,
				},
				{
					Value = 200006,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920249,
			Ability = {
				{
					Value = 200001,
					Num = 138,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920249,
			Ability = {
				{
					Value = 200001,
					Num = 207,
				},
				{
					Value = 200006,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920249,
			Ability = {
				{
					Value = 200001,
					Num = 276,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920249,
			Ability = {
				{
					Value = 200001,
					Num = 345,
				},
				{
					Value = 200006,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920249,
			Ability = {
				{
					Value = 200001,
					Num = 414,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920249,
			Ability = {
				{
					Value = 200001,
					Num = 483,
				},
				{
					Value = 200006,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920249,
			Ability = {
				{
					Value = 200001,
					Num = 552,
				},
				{
					Value = 200006,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920249,
			Ability = {
				{
					Value = 200001,
					Num = 621,
				},
				{
					Value = 200006,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920249,
			Ability = {
				{
					Value = 200001,
					Num = 690,
				},
				{
					Value = 200006,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id221] =
{
	Character = 220227,
	Rarity = 4,
	NeedChallenge = 145089,
	UpgradeId = 930015,
	LevelList = {
		{
			Level = 1,
			Info = 920251,
			Ability = {
				{
					Value = 200002,
					Num = 120,
				},
			},
		},
		{
			Level = 2,
			Info = 920251,
			Ability = {
				{
					Value = 200002,
					Num = 200,
				},
			},
		},
		{
			Level = 3,
			Info = 920251,
			Ability = {
				{
					Value = 200002,
					Num = 280,
				},
			},
		},
		{
			Level = 4,
			Info = 920251,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
			},
		},
		{
			Level = 5,
			Info = 920251,
			Ability = {
				{
					Value = 200002,
					Num = 440,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920251,
			Ability = {
				{
					Value = 200002,
					Num = 520,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920251,
			Ability = {
				{
					Value = 200002,
					Num = 600,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920251,
			Ability = {
				{
					Value = 200002,
					Num = 680,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 7,
				},
			},
		},
		{
			Level = 9,
			Info = 920251,
			Ability = {
				{
					Value = 200002,
					Num = 760,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 7,
				},
			},
		},
		{
			Level = 10,
			Info = 920251,
			Ability = {
				{
					Value = 200002,
					Num = 840,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 7,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id222] =
{
	Character = 220228,
	Rarity = 4,
	UpgradeId = 930033,
	LevelList = {
		{
			Level = 1,
			Info = 920252,
			Ability = {
				{
					Value = 200001,
					Num = 72,
				},
				{
					Value = 200007,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920252,
			Ability = {
				{
					Value = 200001,
					Num = 144,
				},
				{
					Value = 200007,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920252,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920252,
			Ability = {
				{
					Value = 200001,
					Num = 288,
				},
				{
					Value = 200007,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920252,
			Ability = {
				{
					Value = 200001,
					Num = 360,
				},
				{
					Value = 200007,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920252,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200007,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920252,
			Ability = {
				{
					Value = 200001,
					Num = 504,
				},
				{
					Value = 200007,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920252,
			Ability = {
				{
					Value = 200001,
					Num = 576,
				},
				{
					Value = 200007,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920252,
			Ability = {
				{
					Value = 200001,
					Num = 648,
				},
				{
					Value = 200007,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920252,
			Ability = {
				{
					Value = 200001,
					Num = 720,
				},
				{
					Value = 200007,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id223] =
{
	Character = 220228,
	Rarity = 4,
	UpgradeId = 930034,
	LevelList = {
		{
			Level = 1,
			Info = 920253,
			Ability = {
				{
					Value = 200001,
					Num = 72,
				},
			},
		},
		{
			Level = 2,
			Info = 920253,
			Ability = {
				{
					Value = 200001,
					Num = 144,
				},
			},
		},
		{
			Level = 3,
			Info = 920253,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
			},
		},
		{
			Level = 4,
			Info = 920253,
			Ability = {
				{
					Value = 200001,
					Num = 288,
				},
			},
		},
		{
			Level = 5,
			Info = 920253,
			Ability = {
				{
					Value = 200001,
					Num = 360,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920253,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920253,
			Ability = {
				{
					Value = 200001,
					Num = 504,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920253,
			Ability = {
				{
					Value = 200001,
					Num = 576,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 5,
				},
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920253,
			Ability = {
				{
					Value = 200001,
					Num = 648,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 5,
				},
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920253,
			Ability = {
				{
					Value = 200001,
					Num = 720,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 5,
				},
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id224] =
{
	Character = 220228,
	Rarity = 4,
	NeedChallenge = 145090,
	UpgradeId = 930015,
	LevelList = {
		{
			Level = 1,
			Info = 920254,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
			},
		},
		{
			Level = 2,
			Info = 920254,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
			},
		},
		{
			Level = 3,
			Info = 920254,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
		},
		{
			Level = 4,
			Info = 920254,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
			},
		},
		{
			Level = 5,
			Info = 920254,
			Ability = {
				{
					Value = 200002,
					Num = 396,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920254,
			Ability = {
				{
					Value = 200002,
					Num = 468,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920254,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920254,
			Ability = {
				{
					Value = 200002,
					Num = 612,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100605,
					Value = 36,
				},
			},
		},
		{
			Level = 9,
			Info = 920254,
			Ability = {
				{
					Value = 200002,
					Num = 684,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100605,
					Value = 36,
				},
			},
		},
		{
			Level = 10,
			Info = 920254,
			Ability = {
				{
					Value = 200002,
					Num = 756,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100605,
					Value = 36,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id225] =
{
	Character = 220229,
	Rarity = 5,
	UpgradeId = 930017,
	LevelList = {
		{
			Level = 1,
			Info = 920255,
			Ability = {
				{
					Value = 200002,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100782,
					Value = 16,
				},
			},
		},
		{
			Level = 2,
			Info = 920255,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
			},
			SkillList = {
				{
					Id = 100782,
					Value = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920255,
			Ability = {
				{
					Value = 200002,
					Num = 189,
				},
			},
			SkillList = {
				{
					Id = 100782,
					Value = 20,
				},
			},
		},
		{
			Level = 4,
			Info = 920255,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
			SkillList = {
				{
					Id = 100782,
					Value = 22,
				},
			},
		},
		{
			Level = 5,
			Info = 920255,
			Ability = {
				{
					Value = 200002,
					Num = 315,
				},
			},
			SkillList = {
				{
					Id = 100782,
					Value = 24,
				},
			},
		},
		{
			Level = 6,
			Info = 920255,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
			},
			SkillList = {
				{
					Id = 100782,
					Value = 26,
				},
			},
		},
		{
			Level = 7,
			Info = 920255,
			Ability = {
				{
					Value = 200002,
					Num = 441,
				},
			},
			SkillList = {
				{
					Id = 100782,
					Value = 28,
				},
			},
		},
		{
			Level = 8,
			Info = 920255,
			Ability = {
				{
					Value = 200002,
					Num = 504,
				},
			},
			SkillList = {
				{
					Id = 100782,
					Value = 30,
				},
				{
					Id = 100552,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920255,
			Ability = {
				{
					Value = 200002,
					Num = 567,
				},
			},
			SkillList = {
				{
					Id = 100782,
					Value = 32,
				},
				{
					Id = 100552,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920255,
			Ability = {
				{
					Value = 200002,
					Num = 630,
				},
			},
			SkillList = {
				{
					Id = 100782,
					Value = 34,
				},
				{
					Id = 100552,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id226] =
{
	Character = 220229,
	Rarity = 5,
	UpgradeId = 930038,
	LevelList = {
		{
			Level = 1,
			Info = 920256,
			Ability = {
				{
					Value = 200001,
					Num = 87,
				},
			},
			SkillList = {
				{
					Id = 100780,
					Value = 16,
				},
			},
		},
		{
			Level = 2,
			Info = 920256,
			Ability = {
				{
					Value = 200001,
					Num = 174,
				},
			},
			SkillList = {
				{
					Id = 100780,
					Value = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920256,
			Ability = {
				{
					Value = 200001,
					Num = 261,
				},
			},
			SkillList = {
				{
					Id = 100780,
					Value = 20,
				},
			},
		},
		{
			Level = 4,
			Info = 920256,
			Ability = {
				{
					Value = 200001,
					Num = 348,
				},
			},
			SkillList = {
				{
					Id = 100780,
					Value = 22,
				},
			},
		},
		{
			Level = 5,
			Info = 920256,
			Ability = {
				{
					Value = 200001,
					Num = 435,
				},
			},
			SkillList = {
				{
					Id = 100780,
					Value = 24,
				},
			},
		},
		{
			Level = 6,
			Info = 920256,
			Ability = {
				{
					Value = 200001,
					Num = 522,
				},
			},
			SkillList = {
				{
					Id = 100780,
					Value = 26,
				},
			},
		},
		{
			Level = 7,
			Info = 920256,
			Ability = {
				{
					Value = 200001,
					Num = 609,
				},
			},
			SkillList = {
				{
					Id = 100780,
					Value = 28,
				},
			},
		},
		{
			Level = 8,
			Info = 920256,
			Ability = {
				{
					Value = 200001,
					Num = 696,
				},
			},
			SkillList = {
				{
					Id = 100780,
					Value = 30,
				},
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920256,
			Ability = {
				{
					Value = 200001,
					Num = 783,
				},
			},
			SkillList = {
				{
					Id = 100780,
					Value = 32,
				},
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920256,
			Ability = {
				{
					Value = 200001,
					Num = 870,
				},
			},
			SkillList = {
				{
					Id = 100780,
					Value = 34,
				},
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id227] =
{
	Character = 220229,
	Rarity = 5,
	NeedChallenge = 145091,
	UpgradeId = 930019,
	LevelList = {
		{
			Level = 1,
			Info = 920257,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
			},
		},
		{
			Level = 2,
			Info = 920257,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
			},
		},
		{
			Level = 3,
			Info = 920257,
			Ability = {
				{
					Value = 200002,
					Num = 294,
				},
			},
		},
		{
			Level = 4,
			Info = 920257,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
			},
		},
		{
			Level = 5,
			Info = 920257,
			Ability = {
				{
					Value = 200002,
					Num = 462,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920257,
			Ability = {
				{
					Value = 200002,
					Num = 546,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920257,
			Ability = {
				{
					Value = 200002,
					Num = 630,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920257,
			Ability = {
				{
					Value = 200002,
					Num = 714,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101525,
					Value = -12,
				},
			},
		},
		{
			Level = 9,
			Info = 920257,
			Ability = {
				{
					Value = 200002,
					Num = 798,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101525,
					Value = -12,
				},
			},
		},
		{
			Level = 10,
			Info = 920257,
			Ability = {
				{
					Value = 200002,
					Num = 882,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101525,
					Value = -12,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id228] =
{
	Character = 220229,
	Rarity = 5,
	NeedChallenge = 145092,
	UpgradeId = 930040,
	LevelList = {
		{
			Level = 1,
			Info = 920258,
			Ability = {
				{
					Value = 200001,
					Num = 261,
				},
			},
		},
		{
			Level = 2,
			Info = 920258,
			Ability = {
				{
					Value = 200001,
					Num = 406,
				},
			},
		},
		{
			Level = 3,
			Info = 920258,
			Ability = {
				{
					Value = 200001,
					Num = 551,
				},
			},
		},
		{
			Level = 4,
			Info = 920258,
			Ability = {
				{
					Value = 200001,
					Num = 696,
				},
			},
		},
		{
			Level = 5,
			Info = 920258,
			Ability = {
				{
					Value = 200001,
					Num = 841,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920258,
			Ability = {
				{
					Value = 200001,
					Num = 986,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920258,
			Ability = {
				{
					Value = 200001,
					Num = 1131,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920258,
			Ability = {
				{
					Value = 200001,
					Num = 1276,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
		{
			Level = 9,
			Info = 920258,
			Ability = {
				{
					Value = 200001,
					Num = 1421,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
		{
			Level = 10,
			Info = 920258,
			Ability = {
				{
					Value = 200001,
					Num = 1566,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id229] =
{
	Character = 220301,
	Rarity = 1,
	UpgradeId = 930001,
	LevelList = {
		{
			Level = 1,
			Info = 920271,
			Ability = {
				{
					Value = 200002,
					Num = 21,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920271,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920271,
			Ability = {
				{
					Value = 200002,
					Num = 63,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920271,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920271,
			Ability = {
				{
					Value = 200002,
					Num = 105,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920271,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920271,
			Ability = {
				{
					Value = 200002,
					Num = 147,
				},
				{
					Value = 200006,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920271,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920271,
			Ability = {
				{
					Value = 200002,
					Num = 189,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920271,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id230] =
{
	Character = 220301,
	Rarity = 1,
	NeedChallenge = 145093,
	UpgradeId = 930002,
	LevelList = {
		{
			Level = 1,
			Info = 920272,
			Ability = {
				{
					Value = 200002,
					Num = 21,
				},
				{
					Value = 200008,
					Num = 3,
				},
			},
		},
		{
			Level = 2,
			Info = 920272,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200008,
					Num = 6,
				},
			},
		},
		{
			Level = 3,
			Info = 920272,
			Ability = {
				{
					Value = 200002,
					Num = 63,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 4,
			Info = 920272,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 5,
			Info = 920272,
			Ability = {
				{
					Value = 200002,
					Num = 105,
				},
				{
					Value = 200008,
					Num = 15,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 6,
			Info = 920272,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 7,
			Info = 920272,
			Ability = {
				{
					Value = 200002,
					Num = 147,
				},
				{
					Value = 200008,
					Num = 21,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 8,
			Info = 920272,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 9,
			Info = 920272,
			Ability = {
				{
					Value = 200002,
					Num = 189,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 10,
			Info = 920272,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id231] =
{
	Character = 220302,
	Rarity = 3,
	UpgradeId = 930009,
	LevelList = {
		{
			Level = 1,
			Info = 920259,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920259,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920259,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920259,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920259,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920259,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920259,
			Ability = {
				{
					Value = 200002,
					Num = 294,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920259,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920259,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920259,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id232] =
{
	Character = 220302,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920260,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200008,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920260,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920260,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920260,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920260,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920260,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920260,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200008,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920260,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920260,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920260,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id233] =
{
	Character = 220302,
	Rarity = 3,
	NeedChallenge = 145094,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920261,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
			},
		},
		{
			Level = 2,
			Info = 920261,
			Ability = {
				{
					Value = 200002,
					Num = 140,
				},
			},
		},
		{
			Level = 3,
			Info = 920261,
			Ability = {
				{
					Value = 200002,
					Num = 196,
				},
			},
		},
		{
			Level = 4,
			Info = 920261,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
		},
		{
			Level = 5,
			Info = 920261,
			Ability = {
				{
					Value = 200002,
					Num = 308,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
			SkillList = {
				{
					Id = 101501,
					Value = -3,
				},
			},
		},
		{
			Level = 6,
			Info = 920261,
			Ability = {
				{
					Value = 200002,
					Num = 364,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 101501,
					Value = -3,
				},
			},
		},
		{
			Level = 7,
			Info = 920261,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
			SkillList = {
				{
					Id = 101501,
					Value = -3,
				},
			},
		},
		{
			Level = 8,
			Info = 920261,
			Ability = {
				{
					Value = 200002,
					Num = 476,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101501,
					Value = -3,
				},
			},
		},
		{
			Level = 9,
			Info = 920261,
			Ability = {
				{
					Value = 200002,
					Num = 532,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101501,
					Value = -3,
				},
			},
		},
		{
			Level = 10,
			Info = 920261,
			Ability = {
				{
					Value = 200002,
					Num = 588,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101501,
					Value = -3,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id234] =
{
	Character = 220303,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920262,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200006,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920262,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920262,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200006,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920262,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920262,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200006,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920262,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920262,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200006,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920262,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200006,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920262,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200006,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920262,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200006,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id235] =
{
	Character = 220303,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920263,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920263,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920263,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920263,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920263,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920263,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920263,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200005,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920263,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 7,
				},
			},
		},
		{
			Level = 9,
			Info = 920263,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 7,
				},
			},
		},
		{
			Level = 10,
			Info = 920263,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 7,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id236] =
{
	Character = 220303,
	Rarity = 3,
	NeedChallenge = 145095,
	UpgradeId = 930031,
	LevelList = {
		{
			Level = 1,
			Info = 920264,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
			},
		},
		{
			Level = 2,
			Info = 920264,
			Ability = {
				{
					Value = 200001,
					Num = 180,
				},
			},
		},
		{
			Level = 3,
			Info = 920264,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
			},
		},
		{
			Level = 4,
			Info = 920264,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
			},
		},
		{
			Level = 5,
			Info = 920264,
			Ability = {
				{
					Value = 200001,
					Num = 396,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920264,
			Ability = {
				{
					Value = 200001,
					Num = 468,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920264,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920264,
			Ability = {
				{
					Value = 200001,
					Num = 612,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101737,
					Value = 33,
				},
			},
		},
		{
			Level = 9,
			Info = 920264,
			Ability = {
				{
					Value = 200001,
					Num = 684,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101737,
					Value = 33,
				},
			},
		},
		{
			Level = 10,
			Info = 920264,
			Ability = {
				{
					Value = 200001,
					Num = 756,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101737,
					Value = 33,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id237] =
{
	Character = 220304,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920265,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200007,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920265,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920265,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200007,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920265,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920265,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200007,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920265,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920265,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200007,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920265,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200007,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920265,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200007,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920265,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200007,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id238] =
{
	Character = 220304,
	Rarity = 3,
	UpgradeId = 930010,
	LevelList = {
		{
			Level = 1,
			Info = 920266,
			Ability = {
				{
					Value = 200002,
					Num = 48,
				},
				{
					Value = 200008,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920266,
			Ability = {
				{
					Value = 200002,
					Num = 96,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920266,
			Ability = {
				{
					Value = 200002,
					Num = 144,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920266,
			Ability = {
				{
					Value = 200002,
					Num = 192,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920266,
			Ability = {
				{
					Value = 200002,
					Num = 240,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920266,
			Ability = {
				{
					Value = 200002,
					Num = 288,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920266,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
				{
					Value = 200008,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920266,
			Ability = {
				{
					Value = 200002,
					Num = 384,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920266,
			Ability = {
				{
					Value = 200002,
					Num = 432,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920266,
			Ability = {
				{
					Value = 200002,
					Num = 480,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id239] =
{
	Character = 220304,
	Rarity = 3,
	NeedChallenge = 145096,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920267,
			Ability = {
				{
					Value = 200002,
					Num = 96,
				},
			},
		},
		{
			Level = 2,
			Info = 920267,
			Ability = {
				{
					Value = 200002,
					Num = 160,
				},
			},
		},
		{
			Level = 3,
			Info = 920267,
			Ability = {
				{
					Value = 200002,
					Num = 224,
				},
			},
		},
		{
			Level = 4,
			Info = 920267,
			Ability = {
				{
					Value = 200002,
					Num = 288,
				},
			},
		},
		{
			Level = 5,
			Info = 920267,
			Ability = {
				{
					Value = 200002,
					Num = 352,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920267,
			Ability = {
				{
					Value = 200002,
					Num = 416,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920267,
			Ability = {
				{
					Value = 200002,
					Num = 480,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920267,
			Ability = {
				{
					Value = 200002,
					Num = 544,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100744,
					Value = 2,
				},
			},
		},
		{
			Level = 9,
			Info = 920267,
			Ability = {
				{
					Value = 200002,
					Num = 608,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100744,
					Value = 2,
				},
			},
		},
		{
			Level = 10,
			Info = 920267,
			Ability = {
				{
					Value = 200002,
					Num = 672,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100744,
					Value = 2,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id240] =
{
	Character = 220305,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920268,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200007,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920268,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920268,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200007,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920268,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920268,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200007,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920268,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920268,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200007,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920268,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200007,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920268,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200007,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920268,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200007,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
