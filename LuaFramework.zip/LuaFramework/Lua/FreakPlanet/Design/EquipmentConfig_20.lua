
EquipmentConfig[EquipmentID.Id603] =
{
	Character = 223065,
	Rarity = 4,
	NeedChallenge = 145239,
	UpgradeId = 930015,
	LevelList = {
		{
			Level = 1,
			Info = 920654,
			Ability = {
				{
					Value = 200002,
					Num = 114,
				},
			},
		},
		{
			Level = 2,
			Info = 920654,
			Ability = {
				{
					Value = 200002,
					Num = 190,
				},
			},
		},
		{
			Level = 3,
			Info = 920654,
			Ability = {
				{
					Value = 200002,
					Num = 266,
				},
			},
		},
		{
			Level = 4,
			Info = 920654,
			Ability = {
				{
					Value = 200002,
					Num = 342,
				},
			},
		},
		{
			Level = 5,
			Info = 920654,
			Ability = {
				{
					Value = 200002,
					Num = 418,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920654,
			Ability = {
				{
					Value = 200002,
					Num = 494,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920654,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920654,
			Ability = {
				{
					Value = 200002,
					Num = 646,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101738,
					Value = 15,
				},
			},
		},
		{
			Level = 9,
			Info = 920654,
			Ability = {
				{
					Value = 200002,
					Num = 722,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101738,
					Value = 15,
				},
			},
		},
		{
			Level = 10,
			Info = 920654,
			Ability = {
				{
					Value = 200002,
					Num = 798,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101738,
					Value = 15,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id604] =
{
	Character = 223065,
	Rarity = 4,
	NeedChallenge = 145240,
	UpgradeId = 930016,
	LevelList = {
		{
			Level = 1,
			Info = 920655,
			Ability = {
				{
					Value = 200002,
					Num = 114,
				},
			},
		},
		{
			Level = 2,
			Info = 920655,
			Ability = {
				{
					Value = 200002,
					Num = 190,
				},
			},
		},
		{
			Level = 3,
			Info = 920655,
			Ability = {
				{
					Value = 200002,
					Num = 266,
				},
			},
		},
		{
			Level = 4,
			Info = 920655,
			Ability = {
				{
					Value = 200002,
					Num = 342,
				},
			},
		},
		{
			Level = 5,
			Info = 920655,
			Ability = {
				{
					Value = 200002,
					Num = 418,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920655,
			Ability = {
				{
					Value = 200002,
					Num = 494,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920655,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920655,
			Ability = {
				{
					Value = 200002,
					Num = 646,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101784,
					Value = 100,
				},
			},
		},
		{
			Level = 9,
			Info = 920655,
			Ability = {
				{
					Value = 200002,
					Num = 722,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101784,
					Value = 100,
				},
			},
		},
		{
			Level = 10,
			Info = 920655,
			Ability = {
				{
					Value = 200002,
					Num = 798,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101784,
					Value = 100,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id605] =
{
	Character = 223066,
	Rarity = 4,
	UpgradeId = 930033,
	LevelList = {
		{
			Level = 1,
			Info = 920656,
			Ability = {
				{
					Value = 200001,
					Num = 69,
				},
				{
					Value = 200006,
					Num = 21,
				},
			},
		},
		{
			Level = 2,
			Info = 920656,
			Ability = {
				{
					Value = 200001,
					Num = 138,
				},
				{
					Value = 200006,
					Num = 42,
				},
			},
		},
		{
			Level = 3,
			Info = 920656,
			Ability = {
				{
					Value = 200001,
					Num = 207,
				},
				{
					Value = 200006,
					Num = 63,
				},
			},
		},
		{
			Level = 4,
			Info = 920656,
			Ability = {
				{
					Value = 200001,
					Num = 276,
				},
				{
					Value = 200006,
					Num = 84,
				},
			},
		},
		{
			Level = 5,
			Info = 920656,
			Ability = {
				{
					Value = 200001,
					Num = 345,
				},
				{
					Value = 200006,
					Num = 105,
				},
			},
		},
		{
			Level = 6,
			Info = 920656,
			Ability = {
				{
					Value = 200001,
					Num = 414,
				},
				{
					Value = 200006,
					Num = 126,
				},
			},
		},
		{
			Level = 7,
			Info = 920656,
			Ability = {
				{
					Value = 200001,
					Num = 483,
				},
				{
					Value = 200006,
					Num = 147,
				},
			},
		},
		{
			Level = 8,
			Info = 920656,
			Ability = {
				{
					Value = 200001,
					Num = 552,
				},
				{
					Value = 200006,
					Num = 168,
				},
			},
			SkillList = {
				{
					Id = 101708,
					Value = 8,
				},
			},
		},
		{
			Level = 9,
			Info = 920656,
			Ability = {
				{
					Value = 200001,
					Num = 621,
				},
				{
					Value = 200006,
					Num = 189,
				},
			},
			SkillList = {
				{
					Id = 101708,
					Value = 8,
				},
			},
		},
		{
			Level = 10,
			Info = 920656,
			Ability = {
				{
					Value = 200001,
					Num = 690,
				},
				{
					Value = 200006,
					Num = 210,
				},
			},
			SkillList = {
				{
					Id = 101708,
					Value = 8,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id606] =
{
	Character = 223066,
	Rarity = 4,
	UpgradeId = 930014,
	LevelList = {
		{
			Level = 1,
			Info = 920657,
			Ability = {
				{
					Value = 200002,
					Num = 57,
				},
				{
					Value = 200006,
					Num = 21,
				},
			},
		},
		{
			Level = 2,
			Info = 920657,
			Ability = {
				{
					Value = 200002,
					Num = 114,
				},
				{
					Value = 200006,
					Num = 42,
				},
			},
		},
		{
			Level = 3,
			Info = 920657,
			Ability = {
				{
					Value = 200002,
					Num = 171,
				},
				{
					Value = 200006,
					Num = 63,
				},
			},
		},
		{
			Level = 4,
			Info = 920657,
			Ability = {
				{
					Value = 200002,
					Num = 228,
				},
				{
					Value = 200006,
					Num = 84,
				},
			},
		},
		{
			Level = 5,
			Info = 920657,
			Ability = {
				{
					Value = 200002,
					Num = 285,
				},
				{
					Value = 200006,
					Num = 105,
				},
			},
		},
		{
			Level = 6,
			Info = 920657,
			Ability = {
				{
					Value = 200002,
					Num = 342,
				},
				{
					Value = 200006,
					Num = 126,
				},
			},
		},
		{
			Level = 7,
			Info = 920657,
			Ability = {
				{
					Value = 200002,
					Num = 399,
				},
				{
					Value = 200006,
					Num = 147,
				},
			},
		},
		{
			Level = 8,
			Info = 920657,
			Ability = {
				{
					Value = 200002,
					Num = 456,
				},
				{
					Value = 200006,
					Num = 168,
				},
			},
			SkillList = {
				{
					Id = 101709,
					Value = 8,
				},
			},
		},
		{
			Level = 9,
			Info = 920657,
			Ability = {
				{
					Value = 200002,
					Num = 513,
				},
				{
					Value = 200006,
					Num = 189,
				},
			},
			SkillList = {
				{
					Id = 101709,
					Value = 8,
				},
			},
		},
		{
			Level = 10,
			Info = 920657,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200006,
					Num = 210,
				},
			},
			SkillList = {
				{
					Id = 101709,
					Value = 8,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id607] =
{
	Character = 223066,
	Rarity = 4,
	NeedChallenge = 145241,
	UpgradeId = 930015,
	LevelList = {
		{
			Level = 1,
			Info = 920658,
			Ability = {
				{
					Value = 200002,
					Num = 114,
				},
			},
		},
		{
			Level = 2,
			Info = 920658,
			Ability = {
				{
					Value = 200002,
					Num = 190,
				},
			},
		},
		{
			Level = 3,
			Info = 920658,
			Ability = {
				{
					Value = 200002,
					Num = 266,
				},
			},
		},
		{
			Level = 4,
			Info = 920658,
			Ability = {
				{
					Value = 200002,
					Num = 342,
				},
			},
		},
		{
			Level = 5,
			Info = 920658,
			Ability = {
				{
					Value = 200002,
					Num = 418,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920658,
			Ability = {
				{
					Value = 200002,
					Num = 494,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920658,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920658,
			Ability = {
				{
					Value = 200002,
					Num = 646,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100552,
					Value = 33,
				},
			},
		},
		{
			Level = 9,
			Info = 920658,
			Ability = {
				{
					Value = 200002,
					Num = 722,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100552,
					Value = 33,
				},
			},
		},
		{
			Level = 10,
			Info = 920658,
			Ability = {
				{
					Value = 200002,
					Num = 798,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100552,
					Value = 33,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id608] =
{
	Character = 223067,
	Rarity = 5,
	UpgradeId = 930037,
	LevelList = {
		{
			Level = 1,
			Info = 920659,
			Ability = {
				{
					Value = 200001,
					Num = 84,
				},
				{
					Value = 200007,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920659,
			Ability = {
				{
					Value = 200001,
					Num = 168,
				},
				{
					Value = 200007,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920659,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920659,
			Ability = {
				{
					Value = 200001,
					Num = 336,
				},
				{
					Value = 200007,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920659,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
				{
					Value = 200007,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920659,
			Ability = {
				{
					Value = 200001,
					Num = 504,
				},
				{
					Value = 200007,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920659,
			Ability = {
				{
					Value = 200001,
					Num = 588,
				},
				{
					Value = 200007,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920659,
			Ability = {
				{
					Value = 200001,
					Num = 672,
				},
				{
					Value = 200007,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920659,
			Ability = {
				{
					Value = 200001,
					Num = 756,
				},
				{
					Value = 200007,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920659,
			Ability = {
				{
					Value = 200001,
					Num = 840,
				},
				{
					Value = 200007,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id609] =
{
	Character = 223067,
	Rarity = 5,
	UpgradeId = 930018,
	LevelList = {
		{
			Level = 1,
			Info = 920660,
			Ability = {
				{
					Value = 200002,
					Num = 69,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920660,
			Ability = {
				{
					Value = 200002,
					Num = 138,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920660,
			Ability = {
				{
					Value = 200002,
					Num = 207,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920660,
			Ability = {
				{
					Value = 200002,
					Num = 276,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920660,
			Ability = {
				{
					Value = 200002,
					Num = 345,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920660,
			Ability = {
				{
					Value = 200002,
					Num = 414,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920660,
			Ability = {
				{
					Value = 200002,
					Num = 483,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920660,
			Ability = {
				{
					Value = 200002,
					Num = 552,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100554,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920660,
			Ability = {
				{
					Value = 200002,
					Num = 621,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100554,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920660,
			Ability = {
				{
					Value = 200002,
					Num = 690,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100554,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id610] =
{
	Character = 223067,
	Rarity = 5,
	NeedChallenge = 145242,
	UpgradeId = 930019,
	LevelList = {
		{
			Level = 1,
			Info = 920661,
			Ability = {
				{
					Value = 200002,
					Num = 138,
				},
			},
		},
		{
			Level = 2,
			Info = 920661,
			Ability = {
				{
					Value = 200002,
					Num = 230,
				},
			},
		},
		{
			Level = 3,
			Info = 920661,
			Ability = {
				{
					Value = 200002,
					Num = 322,
				},
			},
		},
		{
			Level = 4,
			Info = 920661,
			Ability = {
				{
					Value = 200002,
					Num = 414,
				},
			},
		},
		{
			Level = 5,
			Info = 920661,
			Ability = {
				{
					Value = 200002,
					Num = 506,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920661,
			Ability = {
				{
					Value = 200002,
					Num = 598,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920661,
			Ability = {
				{
					Value = 200002,
					Num = 690,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920661,
			Ability = {
				{
					Value = 200002,
					Num = 782,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100552,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920661,
			Ability = {
				{
					Value = 200002,
					Num = 874,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100552,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920661,
			Ability = {
				{
					Value = 200002,
					Num = 966,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100552,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id611] =
{
	Character = 223067,
	Rarity = 5,
	NeedChallenge = 145243,
	UpgradeId = 930020,
	LevelList = {
		{
			Level = 1,
			Info = 920662,
			Ability = {
				{
					Value = 200002,
					Num = 207,
				},
			},
		},
		{
			Level = 2,
			Info = 920662,
			Ability = {
				{
					Value = 200002,
					Num = 322,
				},
			},
		},
		{
			Level = 3,
			Info = 920662,
			Ability = {
				{
					Value = 200002,
					Num = 437,
				},
			},
		},
		{
			Level = 4,
			Info = 920662,
			Ability = {
				{
					Value = 200002,
					Num = 552,
				},
			},
		},
		{
			Level = 5,
			Info = 920662,
			Ability = {
				{
					Value = 200002,
					Num = 667,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920662,
			Ability = {
				{
					Value = 200002,
					Num = 782,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920662,
			Ability = {
				{
					Value = 200002,
					Num = 897,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920662,
			Ability = {
				{
					Value = 200002,
					Num = 1012,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101731,
					Value = 1080,
				},
			},
		},
		{
			Level = 9,
			Info = 920662,
			Ability = {
				{
					Value = 200002,
					Num = 1127,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101731,
					Value = 1080,
				},
			},
		},
		{
			Level = 10,
			Info = 920662,
			Ability = {
				{
					Value = 200002,
					Num = 1242,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101731,
					Value = 1080,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id612] =
{
	Character = 223007,
	Rarity = 4,
	UpgradeId = 930013,
	LevelList = {
		{
			Level = 1,
			Info = 920587,
			Ability = {
				{
					Value = 200002,
					Num = 57,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920587,
			Ability = {
				{
					Value = 200002,
					Num = 114,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920587,
			Ability = {
				{
					Value = 200002,
					Num = 171,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920587,
			Ability = {
				{
					Value = 200002,
					Num = 228,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920587,
			Ability = {
				{
					Value = 200002,
					Num = 285,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920587,
			Ability = {
				{
					Value = 200002,
					Num = 342,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920587,
			Ability = {
				{
					Value = 200002,
					Num = 399,
				},
				{
					Value = 200008,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920587,
			Ability = {
				{
					Value = 200002,
					Num = 456,
				},
				{
					Value = 200008,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100552,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920587,
			Ability = {
				{
					Value = 200002,
					Num = 513,
				},
				{
					Value = 200008,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100552,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920587,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200008,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100552,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id613] =
{
	Character = 223007,
	Rarity = 4,
	UpgradeId = 930014,
	LevelList = {
		{
			Level = 1,
			Info = 920588,
			Ability = {
				{
					Value = 200002,
					Num = 57,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920588,
			Ability = {
				{
					Value = 200002,
					Num = 114,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920588,
			Ability = {
				{
					Value = 200002,
					Num = 171,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920588,
			Ability = {
				{
					Value = 200002,
					Num = 228,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920588,
			Ability = {
				{
					Value = 200002,
					Num = 285,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100684,
					Value = 2,
				},
			},
		},
		{
			Level = 6,
			Info = 920588,
			Ability = {
				{
					Value = 200002,
					Num = 342,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100684,
					Value = 2,
				},
			},
		},
		{
			Level = 7,
			Info = 920588,
			Ability = {
				{
					Value = 200002,
					Num = 399,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100684,
					Value = 2,
				},
			},
		},
		{
			Level = 8,
			Info = 920588,
			Ability = {
				{
					Value = 200002,
					Num = 456,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100684,
					Value = 2,
				},
			},
		},
		{
			Level = 9,
			Info = 920588,
			Ability = {
				{
					Value = 200002,
					Num = 513,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100684,
					Value = 2,
				},
			},
		},
		{
			Level = 10,
			Info = 920588,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100684,
					Value = 2,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id614] =
{
	Character = 223007,
	Rarity = 4,
	NeedChallenge = 145244,
	UpgradeId = 930015,
	LevelList = {
		{
			Level = 1,
			Info = 920589,
			Ability = {
				{
					Value = 200002,
					Num = 114,
				},
			},
		},
		{
			Level = 2,
			Info = 920589,
			Ability = {
				{
					Value = 200002,
					Num = 190,
				},
			},
		},
		{
			Level = 3,
			Info = 920589,
			Ability = {
				{
					Value = 200002,
					Num = 266,
				},
			},
		},
		{
			Level = 4,
			Info = 920589,
			Ability = {
				{
					Value = 200002,
					Num = 342,
				},
			},
		},
		{
			Level = 5,
			Info = 920589,
			Ability = {
				{
					Value = 200002,
					Num = 418,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920589,
			Ability = {
				{
					Value = 200002,
					Num = 494,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920589,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920589,
			Ability = {
				{
					Value = 200002,
					Num = 646,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100605,
					Value = 36,
				},
			},
		},
		{
			Level = 9,
			Info = 920589,
			Ability = {
				{
					Value = 200002,
					Num = 722,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100605,
					Value = 36,
				},
			},
		},
		{
			Level = 10,
			Info = 920589,
			Ability = {
				{
					Value = 200002,
					Num = 798,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100605,
					Value = 36,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id615] =
{
	Character = 223008,
	Rarity = 5,
	UpgradeId = 930037,
	LevelList = {
		{
			Level = 1,
			Info = 920590,
			Ability = {
				{
					Value = 200001,
					Num = 84,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920590,
			Ability = {
				{
					Value = 200001,
					Num = 168,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920590,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920590,
			Ability = {
				{
					Value = 200001,
					Num = 336,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920590,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920590,
			Ability = {
				{
					Value = 200001,
					Num = 504,
				},
				{
					Value = 200006,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920590,
			Ability = {
				{
					Value = 200001,
					Num = 588,
				},
				{
					Value = 200006,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920590,
			Ability = {
				{
					Value = 200001,
					Num = 672,
				},
				{
					Value = 200006,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 7,
				},
			},
		},
		{
			Level = 9,
			Info = 920590,
			Ability = {
				{
					Value = 200001,
					Num = 756,
				},
				{
					Value = 200006,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 7,
				},
			},
		},
		{
			Level = 10,
			Info = 920590,
			Ability = {
				{
					Value = 200001,
					Num = 840,
				},
				{
					Value = 200006,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 7,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id616] =
{
	Character = 223008,
	Rarity = 5,
	UpgradeId = 930018,
	LevelList = {
		{
			Level = 1,
			Info = 920592,
			Ability = {
				{
					Value = 200002,
					Num = 63,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920592,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920592,
			Ability = {
				{
					Value = 200002,
					Num = 189,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920592,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920592,
			Ability = {
				{
					Value = 200002,
					Num = 315,
				},
				{
					Value = 200008,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920592,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920592,
			Ability = {
				{
					Value = 200002,
					Num = 441,
				},
				{
					Value = 200008,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920592,
			Ability = {
				{
					Value = 200002,
					Num = 504,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100722,
					Value = 13,
				},
			},
		},
		{
			Level = 9,
			Info = 920592,
			Ability = {
				{
					Value = 200002,
					Num = 567,
				},
				{
					Value = 200008,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100722,
					Value = 13,
				},
			},
		},
		{
			Level = 10,
			Info = 920592,
			Ability = {
				{
					Value = 200002,
					Num = 630,
				},
				{
					Value = 200008,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100722,
					Value = 13,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id617] =
{
	Character = 223008,
	Rarity = 5,
	NeedChallenge = 145245,
	UpgradeId = 930039,
	LevelList = {
		{
			Level = 1,
			Info = 920591,
			Ability = {
				{
					Value = 200001,
					Num = 168,
				},
			},
		},
		{
			Level = 2,
			Info = 920591,
			Ability = {
				{
					Value = 200001,
					Num = 280,
				},
			},
		},
		{
			Level = 3,
			Info = 920591,
			Ability = {
				{
					Value = 200001,
					Num = 392,
				},
			},
		},
		{
			Level = 4,
			Info = 920591,
			Ability = {
				{
					Value = 200001,
					Num = 504,
				},
			},
		},
		{
			Level = 5,
			Info = 920591,
			Ability = {
				{
					Value = 200001,
					Num = 616,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920591,
			Ability = {
				{
					Value = 200001,
					Num = 728,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920591,
			Ability = {
				{
					Value = 200001,
					Num = 840,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920591,
			Ability = {
				{
					Value = 200001,
					Num = 952,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100721,
					Value = 13,
				},
			},
		},
		{
			Level = 9,
			Info = 920591,
			Ability = {
				{
					Value = 200001,
					Num = 1064,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100721,
					Value = 13,
				},
			},
		},
		{
			Level = 10,
			Info = 920591,
			Ability = {
				{
					Value = 200001,
					Num = 1176,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100721,
					Value = 13,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id618] =
{
	Character = 223008,
	Rarity = 5,
	NeedChallenge = 145246,
	UpgradeId = 930020,
	LevelList = {
		{
			Level = 1,
			Info = 920593,
			Ability = {
				{
					Value = 200002,
					Num = 189,
				},
			},
		},
		{
			Level = 2,
			Info = 920593,
			Ability = {
				{
					Value = 200002,
					Num = 294,
				},
			},
		},
		{
			Level = 3,
			Info = 920593,
			Ability = {
				{
					Value = 200002,
					Num = 399,
				},
			},
		},
		{
			Level = 4,
			Info = 920593,
			Ability = {
				{
					Value = 200002,
					Num = 504,
				},
			},
		},
		{
			Level = 5,
			Info = 920593,
			Ability = {
				{
					Value = 200002,
					Num = 609,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920593,
			Ability = {
				{
					Value = 200002,
					Num = 714,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920593,
			Ability = {
				{
					Value = 200002,
					Num = 819,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920593,
			Ability = {
				{
					Value = 200002,
					Num = 924,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101785,
					Value = 80,
				},
			},
		},
		{
			Level = 9,
			Info = 920593,
			Ability = {
				{
					Value = 200002,
					Num = 1029,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101785,
					Value = 95,
				},
			},
		},
		{
			Level = 10,
			Info = 920593,
			Ability = {
				{
					Value = 200002,
					Num = 1134,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101785,
					Value = 110,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id619] =
{
	Character = 223081,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920663,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200006,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920663,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920663,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200006,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920663,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920663,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200006,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920663,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920663,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200006,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920663,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200006,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100781,
					Value = 19,
				},
			},
		},
		{
			Level = 9,
			Info = 920663,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200006,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100781,
					Value = 19,
				},
			},
		},
		{
			Level = 10,
			Info = 920663,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200006,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100781,
					Value = 19,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id620] =
{
	Character = 223081,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920664,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200008,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920664,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920664,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920664,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920664,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920664,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920664,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200008,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920664,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100608,
					Value = -6,
				},
			},
		},
		{
			Level = 9,
			Info = 920664,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100608,
					Value = -6,
				},
			},
		},
		{
			Level = 10,
			Info = 920664,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100608,
					Value = -6,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id621] =
{
	Character = 223081,
	Rarity = 3,
	NeedChallenge = 145247,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920665,
			Ability = {
				{
					Value = 200002,
					Num = 90,
				},
			},
		},
		{
			Level = 2,
			Info = 920665,
			Ability = {
				{
					Value = 200002,
					Num = 150,
				},
			},
		},
		{
			Level = 3,
			Info = 920665,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
			},
		},
		{
			Level = 4,
			Info = 920665,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
			},
		},
		{
			Level = 5,
			Info = 920665,
			Ability = {
				{
					Value = 200002,
					Num = 330,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920665,
			Ability = {
				{
					Value = 200002,
					Num = 390,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920665,
			Ability = {
				{
					Value = 200002,
					Num = 450,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920665,
			Ability = {
				{
					Value = 200002,
					Num = 510,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101902,
					Value = 12,
				},
			},
		},
		{
			Level = 9,
			Info = 920665,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101902,
					Value = 12,
				},
			},
		},
		{
			Level = 10,
			Info = 920665,
			Ability = {
				{
					Value = 200002,
					Num = 630,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101902,
					Value = 12,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id622] =
{
	Character = 223082,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920666,
			Ability = {
				{
					Value = 200001,
					Num = 60,
				},
				{
					Value = 200007,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920666,
			Ability = {
				{
					Value = 200001,
					Num = 120,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920666,
			Ability = {
				{
					Value = 200001,
					Num = 180,
				},
				{
					Value = 200007,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920666,
			Ability = {
				{
					Value = 200001,
					Num = 240,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920666,
			Ability = {
				{
					Value = 200001,
					Num = 300,
				},
				{
					Value = 200007,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920666,
			Ability = {
				{
					Value = 200001,
					Num = 360,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920666,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
				{
					Value = 200007,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920666,
			Ability = {
				{
					Value = 200001,
					Num = 480,
				},
				{
					Value = 200007,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 7,
				},
			},
		},
		{
			Level = 9,
			Info = 920666,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200007,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 7,
				},
			},
		},
		{
			Level = 10,
			Info = 920666,
			Ability = {
				{
					Value = 200001,
					Num = 600,
				},
				{
					Value = 200007,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 7,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id623] =
{
	Character = 223082,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920667,
			Ability = {
				{
					Value = 200001,
					Num = 60,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920667,
			Ability = {
				{
					Value = 200001,
					Num = 120,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920667,
			Ability = {
				{
					Value = 200001,
					Num = 180,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920667,
			Ability = {
				{
					Value = 200001,
					Num = 240,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920667,
			Ability = {
				{
					Value = 200001,
					Num = 300,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920667,
			Ability = {
				{
					Value = 200001,
					Num = 360,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920667,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
				{
					Value = 200006,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920667,
			Ability = {
				{
					Value = 200001,
					Num = 480,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100666,
					Value = 2,
				},
			},
		},
		{
			Level = 9,
			Info = 920667,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100666,
					Value = 2,
				},
			},
		},
		{
			Level = 10,
			Info = 920667,
			Ability = {
				{
					Value = 200001,
					Num = 600,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100666,
					Value = 2,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id624] =
{
	Character = 223082,
	Rarity = 3,
	NeedChallenge = 145248,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920668,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
			},
		},
		{
			Level = 2,
			Info = 920668,
			Ability = {
				{
					Value = 200002,
					Num = 140,
				},
			},
		},
		{
			Level = 3,
			Info = 920668,
			Ability = {
				{
					Value = 200002,
					Num = 196,
				},
			},
		},
		{
			Level = 4,
			Info = 920668,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
		},
		{
			Level = 5,
			Info = 920668,
			Ability = {
				{
					Value = 200002,
					Num = 308,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920668,
			Ability = {
				{
					Value = 200002,
					Num = 364,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920668,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920668,
			Ability = {
				{
					Value = 200002,
					Num = 476,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101705,
					Value = 30,
				},
			},
		},
		{
			Level = 9,
			Info = 920668,
			Ability = {
				{
					Value = 200002,
					Num = 532,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101705,
					Value = 30,
				},
			},
		},
		{
			Level = 10,
			Info = 920668,
			Ability = {
				{
					Value = 200002,
					Num = 588,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101705,
					Value = 30,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id625] =
{
	Character = 220431,
	Rarity = 5,
	UpgradeId = 930017,
	LevelList = {
		{
			Level = 1,
			Info = 920418,
			Ability = {
				{
					Value = 200002,
					Num = 69,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920418,
			Ability = {
				{
					Value = 200002,
					Num = 138,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920418,
			Ability = {
				{
					Value = 200002,
					Num = 207,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920418,
			Ability = {
				{
					Value = 200002,
					Num = 276,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920418,
			Ability = {
				{
					Value = 200002,
					Num = 345,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920418,
			Ability = {
				{
					Value = 200002,
					Num = 414,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920418,
			Ability = {
				{
					Value = 200002,
					Num = 483,
				},
				{
					Value = 200008,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920418,
			Ability = {
				{
					Value = 200002,
					Num = 552,
				},
				{
					Value = 200008,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920418,
			Ability = {
				{
					Value = 200002,
					Num = 621,
				},
				{
					Value = 200008,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920418,
			Ability = {
				{
					Value = 200002,
					Num = 690,
				},
				{
					Value = 200008,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id626] =
{
	Character = 220431,
	Rarity = 5,
	UpgradeId = 930038,
	LevelList = {
		{
			Level = 1,
			Info = 920419,
			Ability = {
				{
					Value = 200001,
					Num = 84,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920419,
			Ability = {
				{
					Value = 200001,
					Num = 168,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920419,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920419,
			Ability = {
				{
					Value = 200001,
					Num = 336,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920419,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920419,
			Ability = {
				{
					Value = 200001,
					Num = 504,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920419,
			Ability = {
				{
					Value = 200001,
					Num = 588,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920419,
			Ability = {
				{
					Value = 200001,
					Num = 672,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -50,
				},
			},
		},
		{
			Level = 9,
			Info = 920419,
			Ability = {
				{
					Value = 200001,
					Num = 756,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -50,
				},
			},
		},
		{
			Level = 10,
			Info = 920419,
			Ability = {
				{
					Value = 200001,
					Num = 840,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -50,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id627] =
{
	Character = 220431,
	Rarity = 5,
	NeedChallenge = 145261,
	UpgradeId = 930019,
	LevelList = {
		{
			Level = 1,
			Info = 920420,
			Ability = {
				{
					Value = 200002,
					Num = 138,
				},
			},
		},
		{
			Level = 2,
			Info = 920420,
			Ability = {
				{
					Value = 200002,
					Num = 230,
				},
			},
		},
		{
			Level = 3,
			Info = 920420,
			Ability = {
				{
					Value = 200002,
					Num = 322,
				},
			},
		},
		{
			Level = 4,
			Info = 920420,
			Ability = {
				{
					Value = 200002,
					Num = 414,
				},
			},
		},
		{
			Level = 5,
			Info = 920420,
			Ability = {
				{
					Value = 200002,
					Num = 506,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920420,
			Ability = {
				{
					Value = 200002,
					Num = 598,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920420,
			Ability = {
				{
					Value = 200002,
					Num = 690,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920420,
			Ability = {
				{
					Value = 200002,
					Num = 782,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101761,
					Value = 75,
				},
			},
		},
		{
			Level = 9,
			Info = 920420,
			Ability = {
				{
					Value = 200002,
					Num = 874,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101761,
					Value = 75,
				},
			},
		},
		{
			Level = 10,
			Info = 920420,
			Ability = {
				{
					Value = 200002,
					Num = 966,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101761,
					Value = 75,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id628] =
{
	Character = 220431,
	Rarity = 5,
	NeedChallenge = 145262,
	UpgradeId = 930020,
	LevelList = {
		{
			Level = 1,
			Info = 920421,
			Ability = {
				{
					Value = 200002,
					Num = 207,
				},
			},
		},
		{
			Level = 2,
			Info = 920421,
			Ability = {
				{
					Value = 200002,
					Num = 322,
				},
			},
		},
		{
			Level = 3,
			Info = 920421,
			Ability = {
				{
					Value = 200002,
					Num = 437,
				},
			},
		},
		{
			Level = 4,
			Info = 920421,
			Ability = {
				{
					Value = 200002,
					Num = 552,
				},
			},
		},
		{
			Level = 5,
			Info = 920421,
			Ability = {
				{
					Value = 200002,
					Num = 667,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920421,
			Ability = {
				{
					Value = 200002,
					Num = 782,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920421,
			Ability = {
				{
					Value = 200002,
					Num = 897,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920421,
			Ability = {
				{
					Value = 200002,
					Num = 1012,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101714,
					Value = 432,
				},
			},
		},
		{
			Level = 9,
			Info = 920421,
			Ability = {
				{
					Value = 200002,
					Num = 1127,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101714,
					Value = 432,
				},
			},
		},
		{
			Level = 10,
			Info = 920421,
			Ability = {
				{
					Value = 200002,
					Num = 1242,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101714,
					Value = 432,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id629] =
{
	Character = 220404,
	Rarity = 3,
	NeedChallenge = 145153,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920337,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
			},
		},
		{
			Level = 2,
			Info = 920337,
			Ability = {
				{
					Value = 200002,
					Num = 140,
				},
			},
		},
		{
			Level = 3,
			Info = 920337,
			Ability = {
				{
					Value = 200002,
					Num = 196,
				},
			},
		},
		{
			Level = 4,
			Info = 920337,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
		},
		{
			Level = 5,
			Info = 920337,
			Ability = {
				{
					Value = 200002,
					Num = 308,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920337,
			Ability = {
				{
					Value = 200002,
					Num = 364,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920337,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920337,
			Ability = {
				{
					Value = 200002,
					Num = 476,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101730,
					Value = 648,
				},
			},
		},
		{
			Level = 9,
			Info = 920337,
			Ability = {
				{
					Value = 200002,
					Num = 532,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101730,
					Value = 648,
				},
			},
		},
		{
			Level = 10,
			Info = 920337,
			Ability = {
				{
					Value = 200002,
					Num = 588,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101730,
					Value = 648,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id630] =
{
	Character = 220409,
	Rarity = 3,
	NeedChallenge = 145154,
	UpgradeId = 930031,
	LevelList = {
		{
			Level = 1,
			Info = 920352,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
			},
		},
		{
			Level = 2,
			Info = 920352,
			Ability = {
				{
					Value = 200001,
					Num = 190,
				},
			},
		},
		{
			Level = 3,
			Info = 920352,
			Ability = {
				{
					Value = 200001,
					Num = 266,
				},
			},
		},
		{
			Level = 4,
			Info = 920352,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
			},
		},
		{
			Level = 5,
			Info = 920352,
			Ability = {
				{
					Value = 200001,
					Num = 418,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920352,
			Ability = {
				{
					Value = 200001,
					Num = 494,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920352,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920352,
			Ability = {
				{
					Value = 200001,
					Num = 646,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101901,
					Value = 12,
				},
			},
		},
		{
			Level = 9,
			Info = 920352,
			Ability = {
				{
					Value = 200001,
					Num = 722,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101901,
					Value = 12,
				},
			},
		},
		{
			Level = 10,
			Info = 920352,
			Ability = {
				{
					Value = 200001,
					Num = 798,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101901,
					Value = 12,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id631] =
{
	Character = 220410,
	Rarity = 3,
	NeedChallenge = 145155,
	UpgradeId = 930031,
	LevelList = {
		{
			Level = 1,
			Info = 920355,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
			},
		},
		{
			Level = 2,
			Info = 920355,
			Ability = {
				{
					Value = 200001,
					Num = 190,
				},
			},
		},
		{
			Level = 3,
			Info = 920355,
			Ability = {
				{
					Value = 200001,
					Num = 266,
				},
			},
		},
		{
			Level = 4,
			Info = 920355,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
			},
		},
		{
			Level = 5,
			Info = 920355,
			Ability = {
				{
					Value = 200001,
					Num = 418,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920355,
			Ability = {
				{
					Value = 200001,
					Num = 494,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920355,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920355,
			Ability = {
				{
					Value = 200001,
					Num = 646,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920355,
			Ability = {
				{
					Value = 200001,
					Num = 722,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920355,
			Ability = {
				{
					Value = 200001,
					Num = 798,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id632] =
{
	Character = 220411,
	Rarity = 3,
	NeedChallenge = 145156,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920358,
			Ability = {
				{
					Value = 200002,
					Num = 90,
				},
			},
		},
		{
			Level = 2,
			Info = 920358,
			Ability = {
				{
					Value = 200002,
					Num = 150,
				},
			},
		},
		{
			Level = 3,
			Info = 920358,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
			},
		},
		{
			Level = 4,
			Info = 920358,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
			},
		},
		{
			Level = 5,
			Info = 920358,
			Ability = {
				{
					Value = 200002,
					Num = 330,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920358,
			Ability = {
				{
					Value = 200002,
					Num = 390,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920358,
			Ability = {
				{
					Value = 200002,
					Num = 450,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920358,
			Ability = {
				{
					Value = 200002,
					Num = 510,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101738,
					Value = 15,
				},
			},
		},
		{
			Level = 9,
			Info = 920358,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101738,
					Value = 15,
				},
			},
		},
		{
			Level = 10,
			Info = 920358,
			Ability = {
				{
					Value = 200002,
					Num = 630,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101738,
					Value = 15,
				},
			},
		},
	},
}
