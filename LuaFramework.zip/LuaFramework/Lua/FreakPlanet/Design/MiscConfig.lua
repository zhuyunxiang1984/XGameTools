------------------------------------------------------------------------
Misc = {}

--warning 这里在定义table前赋值,都是nil,有什么意义? add by ggyy
Misc.GoalType						= GoalType
Misc.LabRecipeType					= LabRecipeType
Misc.LabRecipeSubType				= LabRecipeSubType
Misc.TriggerType					= TriggerType
Misc.GoalCountType					= GoalCountType
Misc.ItemType						= ItemType
Misc.GoodsSubType					= GoodsSubType
Misc.SpaceTravelGoodsSubType		= SpaceTravelGoodsSubType
Misc.SpaceTravelChoiceType			= SpaceTravelChoiceType
Misc.SkipCost						= SkipCost
Misc.SourceType						= SourceType
Misc.EffectModule					= EffectModule
Misc.EffectScope					= EffectScope
Misc.EffectAttribute				= EffectAttribute
Misc.CalculateType					= CalculateType
Misc.GamePlatform					= GamePlatform
Misc.GameChannels					= GameChannels
Misc.AbilityType					= AbilityType
Misc.ElementType					= ElementType
Misc.StyleType						= StyleType
Misc.BattleFactor					= BattleFactor
Misc.ExploreRuleType				= ExploreRuleType
Misc.ModuleNames					= ModuleNames
Misc.CollectionWeight				= CollectionWeight
Misc.FightPowerMultiWithAreaElement	= FightPowerMultiWithAreaElement
Misc.WorkShopQuickExchangeCost		= WorkShopQuickExchangeCost
Misc.RarityOp						= RarityOp
Misc.DemandGroupParameter 			= DemandGroupParameter
Misc.ExploreTeamLimit   			= ExploreTeamLimit
Misc.TeamUnlockGoldCost 			= TeamUnlockGoldCost
Misc.TouristOpenDays				= TouristOpenDays
Misc.ExploreCancelTime				= ExploreCancelTime
Misc.ExploreCancelCostDiamond		= ExploreCancelCostDiamond
Misc.MonthCardPurchaseLimit	 		= MonthCardPurchaseLimit
Misc.PackageCondition				= PackageCondition
Misc.SpaceTravelCareerType			= SpaceTravelCareerType
Misc.SpaceTravelSeasonGameCount		= SpaceTravelSeasonGameCount
Misc.SpaceTravelRegisterEarlyTime	= SpaceTravelRegisterEarlyTime
Misc.DiamondToGold					= DiamondToGold
Misc.WeeklyDemandDiamond			= WeeklyDemandDiamond
Misc.CustomDemandDailyRefresh		= CustomDemandDailyRefresh
Misc.CustomDemandRefreshLimit		= CustomDemandRefreshLimit
Misc.CustomDemandUnlockGoal 		= CustomDemandUnlockGoal
Misc.AccountRenameDiamond			= AccountRenameDiamond
Misc.UnderAgeAvailableDay			= UnderAgeAvailableDay
Misc.SummonExchange					= SummonExchange
Misc.EnumHomeFurnitureCategory		= EnumHomeFurnitureCategory
Misc.EnumHomeFurnitureType			= EnumHomeFurnitureType
Misc.HomeFurnitureSell				= HomeFurnitureSell
Misc.WeeklyGoal						= WeeklyGoal
------------------------------------------------------------------------
GoalType = {
	Main = "Main",
	Achievement = "Achievement",
	Challenge = "Challenge",
	Activity = "Activity",
	Newbie = "Newbie",
	Weekly = "Weekly",
	HomeAchievement = "HomeAchievement",
}

LabRecipeType = {
	Normal = "Normal",
	HomeFurniture = "HomeFurniture",
	SpaceTravel = "SpaceTravel"
}

LabRecipeSubType = {
	Object = "Object",
	Supply = "Supply",
	Artwork = "Artwork"
}

TriggerType = {
	Explore = "Explore",						-- 探索：时间，获得物品，击败敌人，获得宠物
	StartExplore = "StartExplore",
	ExploreCost = "ExploreCost",				-- 探索消耗物品
	ExploreEnemyGroup = "ExploreEnemyGroup",    -- 探索击败怪物种类
	CollectItem = "CollectItem",				-- 收集物品, ItemType: Character, Planet, Goods, Equipment, WorkShop, Skin
	WorkShop = "WorkShop",						-- 打工获得物品
	WorkShopRank = "WorkShopRank",              -- 打工评价品级
	Challenge = "Challenge",					-- 挑战
	CharacterChallenge = "CharacterChallenge",	-- 角色挑战
	ActivityChallenge = "ActivityChallenge",	-- 活动挑战
	UsingCostume = "UsingCostume",				-- 换装
	UpgradeEquipment = "UpgradeEquipment",		-- 升级装备次数
	SubmitGoods = "SubmitGoods",				-- 提交物品, ItemType: Goods
	Craft = "Craft",							-- 合成获得物品
	CraftUse = "CraftUse",						-- 合成消耗物品
	UnlockSkill = "UnlockSkill",				-- 解锁角色技能, ItemType: Character
	Arena = "Arena",							-- 流亡街挑战
	CompleteDemand = "CompleteDemand",          -- 完成订单
	DemandReward = "DemandReward",				-- 获得订单奖励
	DemandCost = "DemandCost",					-- 订单中消耗物品
	
	Choice = "Choice",							-- 进行星际选项
	ChoiceWin = "ChoiceWin",					-- 进行星际选项并胜利
	Discovery = "Discovery",					-- 进行星际探索并获得
	DiscoveryCost = "DiscoveryCost",			-- 进行星际探索并消耗
	Deal = "Deal",								-- 进行星际交易并获得
	DealCost = "DealCost",						-- 进行星际交易并消耗
	UseItem = "UseItem",						-- 使用星际道具
	Forward = "Forward",						-- 前进路点
	UseDice = "UseDice",						-- 投骰子（含遥控骰子）
	Friendliness = "Friendliness",				-- 友好度达到
	FriendlinessUp = "FriendlinessUp",			-- 友好度提升

	ActivityExplore = "ActivityExplore",         -- 活动探索
	ActivityExploreCost = "ActivityExploreCost", -- 活动探索消耗
	ActivityBattle = "ActivityBattle",           -- 活动挑战
	
	Signin = "Signin",							 		-- 签到
	ClearObstacle = "ClearObstacle",             		-- 清理家园障碍
	ArrangeHomeFurniture = "ArrangeHomeFurniture", 		--布置家具
	HomeFurnitureSell = "HomeFurnitureSell",      		--购买家具
	HomeFurnitureSellCost = "HomeFurnitureSellCost", 	-- 家具购买消耗
	HomeFurnitureGashapon = "HomeFurnitureGashapon",  	--家具扭蛋
	CraftUse = "CraftUse",								--合成消耗
}

GoalCountType = {
	StartNow = "StartNow",  --接收到任务后计数
	Current = "Current",	--历史存档数据
	OneShot = "OneShot",	--接收到任务后计数(一次性 仅针对探索)
	Weekly = "Weekly",		--每周零点数据重置
}

IAPType = {
	None = 0,
	Normal 			 = 1, --1普通内购
	MonthCard 		 = 2, --2月卡
	ActivityPassport = 3, --3活动通行证
}

ItemType = {
	Gold = 1,
	Diamond = 2,
	Time = 6,				-- 时间
	Card = 7,				-- 呜呜月卡
	ActivityPassport = 8,	-- 活动通行证
	Card2 = 9,  			-- 漆漆月卡

	Skill = 10,
	Planet = 12,
	PlanetArea = 13,
	Challenge = 14,
	
	WorkShop = 16,
	
	Ability = 20,
	Element = 21,
	Character = 22,
	Skin = 23,
	Enemy = 24,
	Pet = 25,
	Couple = 26,
	
	Goal = 30,
	Event = 31,
	Goods = 32,
	Token = 33,
	Equipment = 34,
	
	LabRecipe = 36,
	Postcard = 37,
	Arena = 38,
	ArenaBattle = 39,
	AreneShop = 40,
	Demand = 41,
	DemandGroup = 42,
	Tourist = 43,
	RoomPiece = 44,
	
	Summon = 50,				--奖池
	Tag = 56,
	ActivityDailyLogin = 58,	--活动签到
	
	ArenaTheme = 61,
	ActivityBattle = 62,
	ActivityExplore = 63,
	ClothesShopItem = 64,	--服装店商品
	ClothesShop = 65,		--服装店

	IAP = 70,				--普通玉璧礼包,月卡
	IAPPackage = 71,		--每周
	CustomPackage = 72,		--限购礼包
	--ActivityPackage = 73,	--活动礼包
	
	SpaceTravelSeason = 74,
	SpaceTravelScoreCap = 75,
	SpaceTravelShip = 76,
	SpaceTravelGoods = 77,
	SpaceTravelFriendliness = 78,
	SpaceTravelMap = 80,
	SpaceTravelEventPool = 81,
	SpaceTravelEvent = 82,
	SpaceTravelChoice = 83,
	SpaceTravelChat = 84,
	SpaceTravelDeal = 85,
	SpaceTravelDiscovery = 86,
	SpaceTravelGoal = 87,
	HideSeek = 88,
	HideSeekObject = 89,
	
	CharacterLevelUp = 90,
	PetLevelUp = 91,
	EquipmentInfo = 92,
	EquipmentUpgrade = 93,
	
	Gallery = 95,
	FishPool = 96,          		--鱼塘关卡
	MiniGameStarReward = 97,		--小游戏奖励
	AppMenuId = 98,

	Fuel = 101,
	FuelMax = 102,
	Food = 103,
	FoodMax = 104,
	CapacityMax = 105,
	SpaceTravelScore = 106,
	Node = 111,						--星际航行中前进的路点
	DicePoint = 112,				--星际航行中投掷的点数

	--Furniture = 121,

	HomeFurniture = 121,			--家园家具
	HomeFurnitureSell = 122,		--家园销售
	HomeFurnitureGashapon = 123,	--家园扭蛋
	HomeObstacle = 124,				--家园障碍
	
	WeeklyGoal = 131,				--每周任务
	
	CatchFishPoint = 151,			--捞金鱼能量
}

GoodsSubType = {
	Object = "Object",
	CatchItem = "CatchItem",
	EventItem = "EventItem",
	Food = "Food",
	Chip = "Chip",
}

SpaceTravelGoodsSubType = {
	SupplyFuel = "SupplyFuel",
	SupplyFood = "SupplyFood",
	FuelLimit = "FuelLimit",
	FoodLimit = "FoodLimit",
	Dice = "Dice",
	Object = "Object",
	Relic = "Relic",
	Artwork = "Artwork",
}

SpaceTravelChoiceType = {
	Command = "Command",
	Deal = "Deal",
	Challenge = "Challenge",
	Chat = "Chat",
	Discovery = "Discovery",
	Goal = "Goal",
}

SkipCost = {
	CountDownM = 3,
	CountDownH = 1.5, 	-- 1
	CountDownD = 2, 	-- 0.8
	CountDownW = 1, 	-- 0.5
	PayPerday = 1,
	GameTime = 180,
}

WorkShopQuickExchangeCost = {
	CountDownM = 1,
	CountDownH = 0.8,
	CountDownD = 0.6,
	CountDownW = 0.4,
	PayPerday = 1,
	GameTime = 180,
}

SourceType = {
	Explore					= "Explore",				-- 探索获得
	Mission					= "Mission",				-- 任务获得
	Summon					= "Summon",					-- 抽卡获得
	Craft					= "Craft",					-- 合成获得
	WorkShop				= "WorkShop",				-- 打工获得
	Challenge				= "Challenge",				-- 挑战获得
	SignIn					= "SignIn",					-- 登录获得
	Event					= "Event",					-- 探索事件获得
	Arena					= "Arena", 					-- 流亡街竞技场获得
	ArenaMarket				= "ArenaMarket", 			-- 流亡街商店
	Demand					= "Demand", 				-- 订单获得
	HomeFurnitureSell		= "HomeFurnitureSell", 		-- 家园销售获得
	HomeFurnitureGashapon	= "HomeFurnitureGashapon", 	-- 家园扭蛋获得
	ClearObstacle 			= "ClearObstacle", 			-- 清理障碍获得
}

ModuleNames = {
	Explore = "Explore",
	Lab = "Lab",
	Upgrade = "Upgrade",
	CharacterList = "CharacterList",
	Warehouse = "Warehouse",
	Mission = "Mission",
	Summon = "Summon",
	Gallery = "Gallery",
	Arena = "Arena",
	WorkShop = "WorkShop",
	WorkShopUpgrade = "WorkShopUpgrade",
	BattleFast = "BattleFast",
	BattleQuit = "BattleQuit",
	Tourist = "Tourist",
	Demand = "Demand",
	CustomDemand = "CustomDemand",
	Activity = "Activity",
	SpaceTravel = "SpaceTravel",
	Newbie = "Newbie",
	CharacterSkin = "CharacterSkin",
	ExploreCancel = "ExploreCancel",
	HideSeek = "HideSeek",

	Setting = "Setting",
	Notice = "Notice",
	Mail = "Mail",
	Newspaper = "Newspaper",
	Weekly = "Weekly", -- 每周任务
	HomeFurnitureShop = "HomeFurnitureShop",
	HomeAchievement = "HomeAchievement",   -- 家园成就
	IAP = "IAP",
	Signin = "Signin",
}

EMallModuleNames = {
	RecommendGift = "RecommendGift",
	WeeklyGift = "WeeklyGift",
	MonthlyGift = "MonthlyGift",
	CharacterGift = "CharacterGift",
	MonthCardGift = "MonthCardGift",
	DiamondGift = "DiamondGift",
}

EMallIapPurchaseStatus = {
	HasBought = 0,  --已购买
	PreSell = 1,	--预售
	CanBuy = 2,		--可购买
	OutDate = 3,    -- 过期
	HasBoughtInServer = 4,  -- 服务的购买状态的标识
}

EFurnitureDeliveryStatus = {
	Empty = 0,
	Arrived = 1,
	Transporting = 2,
}

EffectModule = {
	ExploreTime = "ExploreTime",
	ExploreDrop = "ExploreDrop",
	ExploreEnemy = "ExploreEnemy",
	ExploreCatch = "ExploreCatch",
	BuildTeam = "BuildTeam",
	Battle = "Battle",
	CharacterLevelUp = "CharacterLevelUp",
	WorkShop = "WorkShop",
}

EffectScope = {
	Self = "Self",
	Team = "Team",
	RelativePosition = "RelativePosition",
	FixPosition = "FixPosition",
}

EffectAttribute = {
	-- 探索时间
	ExploreTime = "ExploreTime",
	-- 敌人物品掉落概率
	EnemyDropChance = "EnemyDropChance",
	-- 物品掉落概率
	GoodsDropChance = "GoodsDropChance",
	-- 物品掉落数量
	GoodsDropNumber = "GoodsDropNumber",
	-- 敌人出现概率
	EnemyWeight = "EnemyWeight",
	-- 敌人战斗力
	EnemyFightPower = "EnemyFightPower",
	-- 宠物抓捕成功概率
	PetCatchSuccessChance = "PetCatchSuccessChance",
	-- 抓捕宠物毁坏道具概率
	PetCatchDamageChance = "PetCatchDamageChance",
	-- 角色队伍战斗力
	FightPower = "FightPower",
	-- 角色能力值 
	-- EffectValue - ability id, -1或者空对所有能力有加成
	Ability = "Ability",
	--------------------------------------------------------------------
	-- 角色暴击概率
	CritChance = "CritChance",
	-- 角色暴击伤害
	CritDamage = "CritDamage",
	-- 连击概率
	ExtraAttack = "ExtraAttack",
	-- 闪避概率
	Dodge = "Dodge",
	-- 无视闪避概率
	DodgeIgnore = "DodgeIgnore",
	-- 暴击伤害减免
	DamageFromCritDamage = "DamageFromCritDamage",
	--------------------------------------------------------------------
	-- 角色暴击概率，只生效一回合
	CritChanceOnce = "CritChanceOnce",
	-- 角色暴击伤害，只生效一回合
	CritDamageOnce = "CritDamageOnce",
	-- 连击概率，只生效一回合
	ExtraAttackOnce = "ExtraAttackOnce",
	-- 闪避概率，只生效一回合
	DodgeOnce = "DodgeOnce",
	-- 无视闪避概率，只生效一回合
	DodgeIgnoreOnce = "DodgeIgnoreOnce",
	-- 暴击伤害减免，只生效一回合
	DamageFromCritDamageOnce = "DamageFromCritDamageOnce",
	--------------------------------------------------------------------
	-- 攻击附加已损失生命的伤害，只生效一回合
	HpAttackOnce = "HpAttackOnce",
	-- 攻击时无视敌人忍耐，只生效一回合
	DefendIgnoreOnce = "DefendIgnoreOnce",
	-- 回合结束时，根据本回合受击次数+能力
	AttributeWithHurt = "AttributeWithHurt",
	-- 回合结束时，根据本回合受击次数回血
	RecoveryWithHurt = "RecoveryWithHurt",
	--------------------------------------------------------------------
	-- 元素伤害加成
	DamageToElement = "DamageToElement",
	-- 元素伤害减免
	DamageFromElement = "DamageFromElement",
	-- 敌人能力值
	EnemyAbility = "EnemyAbility",
	-- 敌人等级
	EnemyLevel = "EnemyLevel",
	-- 敌人无视减等级
	EnemyLevelIgnore = "EnemyLevelIgnore",
	-- 特定敌人能力值
	SpecificEnemyAbility = "SpecificEnemyAbility",
	-- 特定敌人等级
	SpecificEnemyLevel = "SpecificEnemyLevel",
	-- 战斗回复
	Recovery = "Recovery",
	-- 战斗回复 - 回复量与攻击成正比
	RecoveryWithAtk = "RecoveryWithAtk",
	-- 升级金币消耗
	CharacterLevelUpCost = "CharacterLevelUpCost",
	-- 打工存储时间
	WorkShopMaxWorkTime = "WorkShopMaxWorkTime",
	-- 打工掉落
	WorkShopGoodsNumber = "WorkShopGoodsNumber",
	-- 元素更改
	-- SkillValue - element id, -1随机变成任何元素
	ChangeElement = "ChangeElement",
	-- 范围攻击
	-- EffectValue - num, 大于0对前几个角色，小于0对后几个角色
	-- SkillValue - 伤害系数
	RangeAttack = "RangeAttack",
	-- 探索过程中获得EffectValue指定的道具，数量 = 探索时间-秒*Value/3600/100
	ExploreGetGoods = "ExploreGetGoods",
	-- 削弱 Recovery
	ReduceRecoveryOnce = "ReduceRecoveryOnce",
	-- 削弱 Ability
	ReduceAbilityOnce = "ReduceAbilityOnce",
}

CalculateType = {
	Percent = "Percent",
	Abs = "Abs",
}

AbilityType = {
	HP = 200001,	-- 战斗属性-生命，探索、挑战生效，战斗中直接使用
	ATK = 200002,	-- 战斗属性-攻击，探索、挑战生效，战斗中直接使用
	DEF = 200003,	-- 战斗属性-忍耐，探索、挑战生效，免伤 = DEF/(DEF+VALUE1)
	LUK = 200004,	-- 战斗属性-暴击，探索、挑战生效，暴率 = LUK/(LUK+VALUE2)
	CRA = 200005,	-- 打工属性-技巧，打工生效
	AFF = 200006,	-- 打工属性-亲和，打工生效
	STR = 200007,	-- 打工属性-力气，打工生效
	INT = 200008,	-- 打工属性-智力，打工生效
}

ElementType = {
	Water = 210001,	-- 水
	Fire = 210002,	-- 火
	Wind = 210003,	-- 木
	Light = 210004,	-- 光
	Dark = 210005,	-- 暗
}

StyleType = {
	Tank = "Tank",	-- 肉盾
	Dps = "Dps",	-- 输出
	Work = "Work",	-- 打工
}

AttackType = {
	Melee = "Melee",	-- 近战攻击
	Magic = "Magic",	-- 远程攻击
}

BattleFactor = {
	Value1 = 200.0,		--防御常数  伤害减免 = 防御/(防御 + Value1)
	Value2 = 200.0,		--暴击常数  暴击概率 = 幸运/(幸运 + Value2)
}

ExploreRuleType = {
	NeedTagAnd = "NeedTagAnd",                         -- 队员需要的标签组
	NeedTagOr = "NeedTagOr",                           -- 队员需要的标签
	BanTagAnd = "BanTagAnd",                           -- 队员没有的标签组
	BanTagOr = "BanTagOr",                             -- 队员没有的标签
	TeamFightPower = "TeamFightPower",                 -- 队伍总战力
	TeamerCount = "TeamerCount",                       -- 队员数量,
	NeedCharacterLevel = "NeedCharacterLevel",         -- 队员必须达到等级
	TeamLeaderLevel = "TeamLeaderLevel",               -- 队员至少包含一名角色达到等级
	NeedCharacterIdOr = "NeedCharacterIdOr",           -- 队员只能是其中之一
	TeamCharacterIdOr = "TeamCharacterIdOr",           -- 队伍中必须包含其中一名角色
	TeamCharacterIdAnd = "TeamCharacterIdAnd",         -- 队伍中必须包含所有角色
	TeamCharacterSkinOr = "TeamCharacterSkinOr",       -- 队伍中必须包含其中一个皮肤
	TeamCharacterSkinAnd = "TeamCharacterSkinAnd",     -- 队伍中必须包含所有的皮肤
	-------------------------------------------------------------------------------
	-- 服务器用于触发事件
	TeamItemIdOr = "TeamItemIdOr",                     -- 背包中必须包含其中之一的道具
	TeamItemIdAnd = "TeamItemIdAnd",                   -- 背包中必须包含所有的道具
	-------------------------------------------------------------------------------
}

CoupleNodeKey = {
	Explore = "Explore",
	Challenge = "Challenge",
	WorkShop = "WorkShop", -- 打工,捞鱼共用WorkShop 2021/08/02 @lz
}

CollectionWeight = {
	Character = 3,
	Skin = 3,
	Equipment = 1,
	Goods = 1,
	Postcard = 3,
	Pet = 2,
	Event = 2,
	RoomPiece = 2,
	Couple = 1,
}

RarityOp = {
	GE = 0,   -- 大于等于
	LE = 1,   -- 小于等于
}

ArenaShopType = {
	Normal = "Normal",
	Character = "Character",
}

DemandGroupParameter = {
	--本周已刷新玉璧数 <= DiamondValueBase 时，weight *= 1
	DiamondValueBase = 100,	
	--本周已刷新玉璧数  > DiamondValueBase 时，奖励的weight *= (100-(已刷新玉璧数-DiamondValueBase)/Value1*Value2)/100
	--仅对RewardList中DiamondCount>0的奖励生效
	DiamondValue1 = 20,
	DiamondValue2 = 10,
	--删除任务后等待时间
	DemandRefreshTime = {120,120,120,120,120,120,120,120,120,120,120,120,120,120,120,120,120,120,120,120,120,120,120,120,120,120,120,120,120,120},
	ActivityDemandRefreshTime = {120,120,120,120,120,120,120,120,120,120,120,120,120,120,120,120,120,120,120,120,120,120,120,120,120,120,120,120},
}

--打工对话存在时间， {最小值，最大值}
WorkShopDialogTime = {10, 20}
ExploreDialogTime = {2, 3}
FightPowerMultiWithAreaElement = 200
ExchangeCharacterId = 221004
ExploreTeamLimit = 4

-- 队伍解锁金币消耗
TeamUnlockGoldCost = {
	500,
	6000,
	42000,
	350000,
}

--动物园观光团日程安排，安排日程 = {本星期第一次到来日，本星期第二次到来日...}
TouristOpenDays = {1,3,5}

--探索撤回合法时间，该秒数内，允许玩家无损耗撤回已出发的探索队伍。
ExploreCancelTime = 900
--探索撤回扣取玉璧
ExploreCancelCostDiamond = 1

--评价弹出，以下事件玩家获得后，弹出评价页面
ReviewEventId = 310200

--当前月卡剩余天数小于等于下列字段值时可购买月卡
MonthCardPurchaseLimit = 30

--礼包前置枚举
PackageCondition = {
	LoginDays					= 1,	--登录天数
	BuyPackage					= 2,	--已购买礼包，Value=礼包idValue=礼包id
	NotBuyPackage				= 3,	--未购买礼包，Value=礼包idValue=礼包id
	ShowPackage					= 4,	--礼包已展示，Value=礼包idValue=礼包id
	SumPay						= 5,	--账户总支付
	DrawCount					= 6,	--抽卡次数，Value=奖池idValue=奖池id
	DrawCost					= 7,	--抽卡消耗资产，ValueId = 玉璧、金币、代金券idValue=玉璧、金币、代金券id
	CharacterNum				= 8,	--拥有角色数量，满足Rarity区间且Level区间内的装备数量
	CompleteChallenge			= 9,	--完成挑战，Value=挑战idValue=挑战id
	CompleteGoal				= 10,	--完成任务，Value=任务idValue=任务id
	OwnAssets					= 11,	--账户拥有资产，ValueId = 玉璧、金币、道具、代金券idValue=玉璧、金币、道具、代金券id
	EquipmentNum				= 12,	--拥有装备数量，满足Rarity区间且Level区间内的装备数量
	OwnEquipment				= 13,	--指定装备等级，Value，LevelMin，LevelMaxValue=装备id
	OwnCharacter				= 14,	--指定角色等级Value=角色id

	HomeEventNum				= 15,	--本次拜访-事件id触发次数，Value=Value=家园事件id
	HomeEventTagNum				= 16,	--本次拜访-事件tag触发次数[]，ValueList={TagId1,TagId2,…}
	HomeChoiceNum				= 17,	--本次拜访-选项id触发次数，Value=家园事件id
	HomeChoiceTagNum			= 18,	--本次拜访-选项tag触发次数[]，ValueList={TagId1,TagId2,…}
	VisitorFriendShip			= 19,	--本次拜访-客人id好感增加，Value=家园事件id
	HomeEventNumCareer			= 20,	--事件id触发次数，Value=家园事件id
	HomeEventTagNumCareer		= 21,	--事件tag触发次数[]，ValueList={TagId1,TagId2,…}
	HomeChoiceNumCareer			= 22,	--选项id触发次数，Value=家园事件id
	HomeChoiceTagNumCareer		= 23,	--选项tag触发次数[]，ValueList={TagId1,TagId2,…}
	VisitorFriendShipCareer		= 24,	--客人好感值，Value=家园事件id
	HomeFurnitureNum			= 25,	--家具id拥有数，Value=家园事件id
	HomeFurnitureTagNum			= 26,	--家具tag拥有数[]，ValueList={TagId1,TagId2,…}
	ArrangeHomeFurnitureNum		= 27,	--家具id布置数，Value=家园事件id
	ArrangeHomeFurnitureTagNum	= 28,	--家具tag布置数[]，ValueList={TagId1,TagId2,…}
	LabRecipeCheck				= 29,	--配方id拥有，Value=家园事件id
	LabRecipeTagNum				= 30,	--配方tag拥有数[]，ValueList={TagId1,TagId2,…}
	AreaCheck					= 31,	--地区id拥有，Value=家园事件id
	AreaTagNum					= 32,	--地区tag拥有[]，ValueList={TagId1,TagId2,…}
	InMonthCard					= 33,	--当前购买月卡，Value=月卡id
}


-- special goal id
SPECIFIC_GOAL_ID = 300004

SpaceTravelCareerType = {
	SeasonCount			= 1,		--玩家累计参加赛季数，每周首次报名，记录+1
	HighestScore		= 2,		--玩家历史最高单场比赛分数（不区分赛季）
	HighestNodeNum		= 3,		--历史最高单场比赛通过路点数
	TotalNodeNum		= 4,		--累计前进步数：初始=0，玩家每前进1个路点则记录+1。
	DealCount			= 5,		--累计交易成交次数：初始=0，玩家每次“成交”则记录+1。
	ChallengeWinCount	= 6,		--累计战斗胜利次数：初始=0，玩家每次在星际航行中战斗胜利，记录+1
	ChatWinCount		= 7,		--累计谈判胜利次数：初始=0，玩家每次在星际航行中谈判胜利，记录+1
	DiscoveryPrice		= 8,		--累计探索价值：初始=0，每次“探索”，记录 + 增加所有探索物品.Price * Num 之和
	WorldCompleteCount	= 9,		--累计战胜世界Boss次数：初始=0，每次战胜世界Boss，记录+1
	GoalCompleteCount	= 10,		--累计完成任务次数：初始=0，每次完成任务，记录+1
}

SpaceTravelSeasonGameCount = 999		--每赛季（每周）星际航行允许游玩次数

SpaceTravelRegisterEarlyTime = 0*8	--星际航行赛季结束前8小时报名截止

--玉璧兑换金币
DiamondToGold = {
	Diamond = 10,
	Gold = 1000,
	ExchangeDesc = "换一次",
	FastExchangeDesc = "换十次",
	FastExchangeCount = 10
}

--每周完成订单奖励玉璧
WeeklyDemandDiamond = {
	{
		CompleteDemandNum = 10,
		RewardDiamond = 50
	},
	{
		CompleteDemandNum = 30,
		RewardDiamond = 100
	},
	{
		CompleteDemandNum = 60,
		RewardDiamond = 150
	}
}

--每日定制订单刷新次数
CustomDemandDailyRefresh = 12
--定制订单最大累计次数
CustomDemandRefreshLimit = 30
--定制订单系统解锁前置任务，-1 = 无前置条件
CustomDemandUnlockGoal = 300354

--账户重命名消耗玉璧
AccountRenameDiamond = 100

---活动小游戏枚举---------------------------------------
EnumMiniGameModule = {
	None = 0,
	CatchFish = 1,
	HideSeek = 2,
}

---服装店枚举---------------------------------------
EnumClothesShopType = {
	None = 0,
	Clothes = 1,--服装店
	Present = 2,--礼品店
}

EnumClothesShopProductType = {
	None = 0,
	Item = 1, --道具
	Skin = 2, --皮肤
	Character = 3,--扭蛋
}

---捞金鱼枚举---------------------------------------
EnumCatchFishStageType = {
	None = 0,
	Normal 		= 1,--普通关
	Challenge 	= 2,--挑战关
}

EnumCatchFishFishType = {
	None = 0,
	Normal = 1,
	Gold   = 2,
}

---资源名字-----------------------------------------------
EnumPrefabName = {

	CatchFish_Fish1_1 = "CatchFish_Fish1_1",
	CatchFish_Fish2_1 = "CatchFish_Fish2_1",
	CatchFish_Fish2_2 = "CatchFish_Fish2_2",
	CatchFish_Fish3_1 = "CatchFish_Fish3_1",
	CatchFish_Fish3_2 = "CatchFish_Fish3_2",
	CatchFish_Fish3_3 = "CatchFish_Fish3_3",
	CatchFish_Fish4_1 = "CatchFish_Fish4_1",
	CatchFish_GoldFish_1 = "CatchFish_GoldFish_1",

	CatchFish_Net1 = "CatchFish_Net1",
	CatchFish_Net2 = "CatchFish_Net2",
	CatchFish_Net3 = "CatchFish_Net3",
	CatchFish_Net4 = "CatchFish_Net4",

	CatchFish_Arrow = "CatchFish_Arrow",
	CatchFish_Score = "CatchFish_Score",

	CatchFish_ScoreAnim = "CatchFish_ScoreAnim",
	CatchFish_SpecialScoreAnim = "CatchFish_SpecialScoreAnim",
	CatchFish_EffectRipple = "CatchFish_EffectRipple",
}

---未成年作息表-------------------------------------------------
UnderAgeAvailableDay =
{
	--每日合法时间段
	HoursOfDayBegin = {20,0},
	HoursOfDayEnd 	= {21,0},
	--每周合法日
	DaysOfWeek = {5,6,0},
	--白名单
	WhiteList = {
		[2021]={
			--空表示本月无白名单
			--0表示全月都是白名单
			--非空非0表示填写日为白名单日
			[1]={1},
			[2]={11,12,15,16,17},
			[3]={},
			[4]={5},
			[5]={3,4,5},
			[6]={14},
			[7]={0},
			[8]={0},
			[9]={21},
			[10]={},
			[11]={},
			[12]={},
		}
	},
	--黑名单
	BlackList = {
		[2021]={
			--空表示本月无黑名单
			--0表示全月都是黑名单
			--非空非0表示填写日为黑名单日
			[1]={},
			[2]={7,20},
			[3]={},
			[4]={25},
			[5]={8},
			[6]={},
			[7]={},
			[8]={},
			[9]={},
			[10]={},
			[11]={},
			[12]={},
		}
	},
}

SummonExchange = {
	221004,
	221007,
}


EnumHomeFurnitureCategory = {
	None 		= 0,	--空
	Cabinet 	= 1,	--柜子
	Table 		= 2,	--桌子
	Chair 		= 3,	--椅子
	Orn 		= 4,	--摆件
	Other 		= 5,	--装饰
	Ele 		= 6,	--电器
	Whanging 	= 7,	--壁挂
	Rug 		= 8,	--地毯
	Plant 		= 9,	--植物
	Wall 		= 10,	--壁纸
	Floor 		= 11,	--地板
}

EnumHomeFurnitureType = {
	Normal 			= 0,	--普通家具
	WangYuanJing	= 1,	--望远镜
	BiLu			= 2,	--壁炉
	JuXingHuaXiang	= 3,	--巨型画像
	LanGan			= 4,	--栏杆
}

HomeFurnitureSell = {
	DeliveryTimeRate = 50,								--家具送货时间减免，最终送达时间 = int(家具.DeliveryTime * DeliveryTimeRate / 100)
	DeliveryTimeRateNeedMonthCard = ItemType.Card2,		--家具送货时间减免需要激活月卡id
	ShowSellCurrencyId = 320001,
	ShowGashaponCurrencyId = 320002,
	--家具销售网站，下方广告链接
	AdsImage = {
		"Home_buy_ad",
		"Home_buy_ad",
		"Home_buy_ad"
	}
}

WeeklyGoal = {
	ExtraReward = {
		{
			Id = 1,
			Max = 1000,
		},
		{
			Id = 2,
			Max = 1000,
		}
	},
	WeeklyGoalRewardExtraRate = 50,						--每周任务额外奖励
	SavingsBankReceiveNeedMonthCard = ItemType.Card2,	--每周任务奖励储蓄罐需要激活月卡id

}