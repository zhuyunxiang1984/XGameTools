SpaceTravelMapConfig ={};
SpaceTravelMapID = 
{
	Id001 = 800001,
	Id002 = 800002,
	Id003 = 800003,
	Id004 = 800004,
	Id005 = 800005,
	Id006 = 800006,
	Id007 = 800007,
}
SpaceTravelMapConfig[SpaceTravelMapID.Id001] =
{
	Id = 1,
	WorldIndex = 1,
	Name = "冒险的宙域",
	FirstNode = "World1_Path1_Branch1_Node1",
	LastNodeList = {
		"World1_Path6_Branch1_Node20",
		"World1_Path6_Branch2_Node20",
	},
	RoundScore = 0,
	StepScore = 10,
	RoundFuelCost = 30,
	StepFuelCost = 0,
	RoundFoodCost = 0,
	StepFoodCost = 0,
	Nodes = {
		World1_Path1_Branch1_Node1 = {
			BranchRoot = "World1_Path1_Branch1_Node1",
			Seed = 1011,
			ChildIdList = {
				"World1_Path1_Branch1_Node2",
			},
			EventPool = 810001,
		},
		World1_Path1_Branch1_Node2 = {
			BranchRoot = "World1_Path1_Branch1_Node1",
			Seed = 1011,
			ChildIdList = {
				"World1_Path1_Branch1_Node3",
			},
			EventPool = 810001,
		},
		World1_Path1_Branch1_Node3 = {
			BranchRoot = "World1_Path1_Branch1_Node1",
			Seed = 1011,
			ChildIdList = {
				"World1_Path1_Branch1_Node4",
			},
			EventPool = 810001,
		},
		World1_Path1_Branch1_Node4 = {
			BranchRoot = "World1_Path1_Branch1_Node1",
			Seed = 1011,
			ChildIdList = {
				"World1_Path1_Branch1_Node5",
			},
			EventPool = 810002,
		},
		World1_Path1_Branch1_Node5 = {
			BranchRoot = "World1_Path1_Branch1_Node1",
			StepScore = 50,
			Seed = 1011,
			ChildIdList = {
				"World1_Path1_Branch1_Node6",
			},
			EventPool = 810006,
		},
		World1_Path1_Branch1_Node6 = {
			BranchRoot = "World1_Path1_Branch1_Node1",
			Seed = 1011,
			ChildIdList = {
				"World1_Path1_Branch1_Node7",
			},
			EventPool = 810008,
		},
		World1_Path1_Branch1_Node7 = {
			BranchRoot = "World1_Path1_Branch1_Node1",
			Seed = 1011,
			ChildIdList = {
				"World1_Path1_Branch1_Node8",
			},
			EventPool = 810008,
		},
		World1_Path1_Branch1_Node8 = {
			BranchRoot = "World1_Path1_Branch1_Node1",
			Seed = 1011,
			ChildIdList = {
				"World1_Path1_Branch1_Node9",
			},
			EventPool = 810003,
		},
		World1_Path1_Branch1_Node9 = {
			BranchRoot = "World1_Path1_Branch1_Node1",
			Seed = 1011,
			ChildIdList = {
				"World1_Path1_Branch1_Node10",
			},
			EventPool = 810012,
		},
		World1_Path1_Branch1_Node10 = {
			BranchRoot = "World1_Path1_Branch1_Node1",
			Seed = 1011,
			ChildIdList = {
				"World1_Path1_Branch1_Node11",
			},
			EventPool = 810001,
		},
		World1_Path1_Branch1_Node11 = {
			BranchRoot = "World1_Path1_Branch1_Node1",
			Seed = 1011,
			ChildIdList = {
				"World1_Path1_Branch1_Node12",
			},
			EventPool = 810003,
		},
		World1_Path1_Branch1_Node12 = {
			BranchRoot = "World1_Path1_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 1011,
			ChildIdList = {
				"World1_Path1_Branch1_Node13",
			},
			EventPool = 810004,
		},
		World1_Path1_Branch1_Node13 = {
			BranchRoot = "World1_Path1_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 1011,
			ChildIdList = {
				"World1_Path1_Branch1_Node14",
			},
			EventPool = 810004,
		},
		World1_Path1_Branch1_Node14 = {
			BranchRoot = "World1_Path1_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 1011,
			ChildIdList = {
				"World1_Path1_Branch1_Node15",
			},
			EventPool = 810004,
		},
		World1_Path1_Branch1_Node15 = {
			BranchRoot = "World1_Path1_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 1011,
			ChildIdList = {
				"World1_Path1_Branch1_Node16",
			},
			EventPool = 810004,
		},
		World1_Path1_Branch1_Node16 = {
			BranchRoot = "World1_Path1_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 1011,
			ChildIdList = {
				"World1_Path1_Branch1_Node17",
			},
			EventPool = 810004,
		},
		World1_Path1_Branch1_Node17 = {
			BranchRoot = "World1_Path1_Branch1_Node1",
			Seed = 1011,
			ChildIdList = {
				"World1_Path1_Branch1_Node18",
			},
			EventPool = 810002,
		},
		World1_Path1_Branch1_Node18 = {
			BranchRoot = "World1_Path1_Branch1_Node1",
			Seed = 1011,
			ChildIdList = {
				"World1_Path1_Branch1_Node19",
			},
			EventPool = 810002,
		},
		World1_Path1_Branch1_Node19 = {
			BranchRoot = "World1_Path1_Branch1_Node1",
			Seed = 1011,
			ChildIdList = {
				"World1_Path1_Branch1_Node20",
			},
			EventPool = 810012,
		},
		World1_Path1_Branch1_Node20 = {
			BranchRoot = "World1_Path1_Branch1_Node1",
			Seed = 1011,
			ChildIdList = {
				"World1_Path2_Branch1_Node1",
				"World1_Path2_Branch2_Node1",
			},
			EventPool = 810008,
		},
		World1_Path2_Branch1_Node1 = {
			BranchRoot = "World1_Path2_Branch1_Node1",
			Seed = 1021,
			ChildIdList = {
				"World1_Path2_Branch1_Node2",
			},
			EventPool = 810001,
		},
		World1_Path2_Branch1_Node2 = {
			BranchRoot = "World1_Path2_Branch1_Node1",
			Seed = 1021,
			ChildIdList = {
				"World1_Path2_Branch1_Node3",
			},
			EventPool = 810002,
		},
		World1_Path2_Branch1_Node3 = {
			BranchRoot = "World1_Path2_Branch1_Node1",
			Seed = 1021,
			ChildIdList = {
				"World1_Path2_Branch1_Node4",
			},
			EventPool = 810007,
		},
		World1_Path2_Branch1_Node4 = {
			BranchRoot = "World1_Path2_Branch1_Node1",
			Seed = 1021,
			ChildIdList = {
				"World1_Path2_Branch1_Node5",
			},
			EventPool = 810008,
		},
		World1_Path2_Branch1_Node5 = {
			BranchRoot = "World1_Path2_Branch1_Node1",
			Seed = 1021,
			ChildIdList = {
				"World1_Path2_Branch1_Node6",
			},
			EventPool = 810008,
		},
		World1_Path2_Branch1_Node6 = {
			BranchRoot = "World1_Path2_Branch1_Node1",
			Seed = 1021,
			ChildIdList = {
				"World1_Path2_Branch1_Node7",
			},
			EventPool = 810009,
		},
		World1_Path2_Branch1_Node7 = {
			BranchRoot = "World1_Path2_Branch1_Node1",
			Seed = 1021,
			ChildIdList = {
				"World1_Path2_Branch1_Node8",
			},
			EventPool = 810003,
		},
		World1_Path2_Branch1_Node8 = {
			BranchRoot = "World1_Path2_Branch1_Node1",
			Seed = 1021,
			ChildIdList = {
				"World1_Path2_Branch1_Node9",
			},
			EventPool = 810001,
		},
		World1_Path2_Branch1_Node9 = {
			BranchRoot = "World1_Path2_Branch1_Node1",
			Seed = 1021,
			ChildIdList = {
				"World1_Path2_Branch1_Node10",
			},
			EventPool = 810012,
		},
		World1_Path2_Branch1_Node10 = {
			BranchRoot = "World1_Path2_Branch1_Node1",
			Seed = 1021,
			ChildIdList = {
				"World1_Path2_Branch1_Node11",
			},
			EventPool = 810007,
		},
		World1_Path2_Branch1_Node11 = {
			BranchRoot = "World1_Path2_Branch1_Node1",
			Seed = 1021,
			ChildIdList = {
				"World1_Path2_Branch1_Node12",
			},
			EventPool = 810007,
		},
		World1_Path2_Branch1_Node12 = {
			BranchRoot = "World1_Path2_Branch1_Node1",
			StepScore = 50,
			Seed = 1021,
			ChildIdList = {
				"World1_Path2_Branch1_Node13",
			},
			EventPool = 810006,
		},
		World1_Path2_Branch1_Node13 = {
			BranchRoot = "World1_Path2_Branch1_Node1",
			Seed = 1021,
			ChildIdList = {
				"World1_Path2_Branch1_Node14",
			},
			EventPool = 810007,
		},
		World1_Path2_Branch1_Node14 = {
			BranchRoot = "World1_Path2_Branch1_Node1",
			Seed = 1021,
			ChildIdList = {
				"World1_Path2_Branch1_Node15",
			},
			EventPool = 810008,
		},
		World1_Path2_Branch1_Node15 = {
			BranchRoot = "World1_Path2_Branch1_Node1",
			Seed = 1021,
			ChildIdList = {
				"World1_Path2_Branch1_Node16",
			},
			EventPool = 810013,
		},
		World1_Path2_Branch1_Node16 = {
			BranchRoot = "World1_Path2_Branch1_Node1",
			Seed = 1021,
			ChildIdList = {
				"World1_Path2_Branch1_Node17",
			},
			EventPool = 810008,
		},
		World1_Path2_Branch1_Node17 = {
			BranchRoot = "World1_Path2_Branch1_Node1",
			Seed = 1021,
			ChildIdList = {
				"World1_Path2_Branch1_Node18",
			},
			EventPool = 810007,
		},
		World1_Path2_Branch1_Node18 = {
			BranchRoot = "World1_Path2_Branch1_Node1",
			Seed = 1021,
			ChildIdList = {
				"World1_Path2_Branch1_Node19",
			},
			EventPool = 810008,
		},
		World1_Path2_Branch1_Node19 = {
			BranchRoot = "World1_Path2_Branch1_Node1",
			Seed = 1021,
			ChildIdList = {
				"World1_Path2_Branch1_Node20",
			},
			EventPool = 810012,
		},
		World1_Path2_Branch1_Node20 = {
			BranchRoot = "World1_Path2_Branch1_Node1",
			Seed = 1021,
			ChildIdList = {
				"World1_Path3_Branch1_Node1",
				"World1_Path3_Branch2_Node1",
			},
			EventPool = 810008,
		},
		World1_Path3_Branch1_Node1 = {
			BranchRoot = "World1_Path3_Branch1_Node1",
			Seed = 1031,
			ChildIdList = {
				"World1_Path3_Branch1_Node2",
			},
			EventPool = 810009,
		},
		World1_Path3_Branch1_Node2 = {
			BranchRoot = "World1_Path3_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 1031,
			ChildIdList = {
				"World1_Path3_Branch1_Node3",
			},
			EventPool = 810004,
		},
		World1_Path3_Branch1_Node3 = {
			BranchRoot = "World1_Path3_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 1031,
			ChildIdList = {
				"World1_Path3_Branch1_Node4",
			},
			EventPool = 810004,
		},
		World1_Path3_Branch1_Node4 = {
			BranchRoot = "World1_Path3_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 1031,
			ChildIdList = {
				"World1_Path3_Branch1_Node5",
			},
			EventPool = 810004,
		},
		World1_Path3_Branch1_Node5 = {
			BranchRoot = "World1_Path3_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 1031,
			ChildIdList = {
				"World1_Path3_Branch1_Node6",
			},
			EventPool = 810004,
		},
		World1_Path3_Branch1_Node6 = {
			BranchRoot = "World1_Path3_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 1031,
			ChildIdList = {
				"World1_Path3_Branch1_Node7",
			},
			EventPool = 810004,
		},
		World1_Path3_Branch1_Node7 = {
			BranchRoot = "World1_Path3_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 1031,
			ChildIdList = {
				"World1_Path3_Branch1_Node8",
			},
			EventPool = 810004,
		},
		World1_Path3_Branch1_Node8 = {
			BranchRoot = "World1_Path3_Branch1_Node1",
			Seed = 1031,
			ChildIdList = {
				"World1_Path3_Branch1_Node9",
			},
			EventPool = 810002,
		},
		World1_Path3_Branch1_Node9 = {
			BranchRoot = "World1_Path3_Branch1_Node1",
			Seed = 1031,
			ChildIdList = {
				"World1_Path3_Branch1_Node10",
			},
			EventPool = 810011,
		},
		World1_Path3_Branch1_Node10 = {
			BranchRoot = "World1_Path3_Branch1_Node1",
			Seed = 1031,
			ChildIdList = {
				"World1_Path3_Branch1_Node11",
			},
			EventPool = 810007,
		},
		World1_Path3_Branch1_Node11 = {
			BranchRoot = "World1_Path3_Branch1_Node1",
			Seed = 1031,
			ChildIdList = {
				"World1_Path3_Branch1_Node12",
			},
			EventPool = 810013,
		},
		World1_Path3_Branch1_Node12 = {
			BranchRoot = "World1_Path3_Branch1_Node1",
			Seed = 1031,
			ChildIdList = {
				"World1_Path3_Branch1_Node13",
			},
			EventPool = 810007,
		},
		World1_Path3_Branch1_Node13 = {
			BranchRoot = "World1_Path3_Branch1_Node1",
			StepScore = 50,
			Seed = 1031,
			ChildIdList = {
				"World1_Path3_Branch1_Node14",
			},
			EventPool = 810006,
		},
		World1_Path3_Branch1_Node14 = {
			BranchRoot = "World1_Path3_Branch1_Node1",
			Seed = 1031,
			ChildIdList = {
				"World1_Path3_Branch1_Node15",
			},
			EventPool = 810013,
		},
		World1_Path3_Branch1_Node15 = {
			BranchRoot = "World1_Path3_Branch1_Node1",
			Seed = 1031,
			ChildIdList = {
				"World1_Path3_Branch1_Node16",
			},
			EventPool = 810013,
		},
		World1_Path3_Branch1_Node16 = {
			BranchRoot = "World1_Path3_Branch1_Node1",
			Seed = 1031,
			ChildIdList = {
				"World1_Path3_Branch1_Node17",
			},
			EventPool = 810003,
		},
		World1_Path3_Branch1_Node17 = {
			BranchRoot = "World1_Path3_Branch1_Node1",
			Seed = 1031,
			ChildIdList = {
				"World1_Path3_Branch1_Node18",
			},
			EventPool = 810008,
		},
		World1_Path3_Branch1_Node18 = {
			BranchRoot = "World1_Path3_Branch1_Node1",
			Seed = 1031,
			ChildIdList = {
				"World1_Path3_Branch1_Node19",
			},
			EventPool = 810003,
		},
		World1_Path3_Branch1_Node19 = {
			BranchRoot = "World1_Path3_Branch1_Node1",
			Seed = 1031,
			ChildIdList = {
				"World1_Path3_Branch1_Node20",
			},
			EventPool = 810011,
		},
		World1_Path3_Branch1_Node20 = {
			BranchRoot = "World1_Path3_Branch1_Node1",
			Seed = 1031,
			ChildIdList = {
				"World1_Path4_Branch1_Node1",
				"World1_Path4_Branch2_Node1",
			},
			EventPool = 810007,
		},
		World1_Path4_Branch1_Node1 = {
			BranchRoot = "World1_Path4_Branch1_Node1",
			Seed = 1041,
			ChildIdList = {
				"World1_Path4_Branch1_Node2",
			},
			EventPool = 810003,
		},
		World1_Path4_Branch1_Node2 = {
			BranchRoot = "World1_Path4_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 1041,
			ChildIdList = {
				"World1_Path4_Branch1_Node3",
			},
			EventPool = 810005,
		},
		World1_Path4_Branch1_Node3 = {
			BranchRoot = "World1_Path4_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 1041,
			ChildIdList = {
				"World1_Path4_Branch1_Node4",
			},
			EventPool = 810005,
		},
		World1_Path4_Branch1_Node4 = {
			BranchRoot = "World1_Path4_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 1041,
			ChildIdList = {
				"World1_Path4_Branch1_Node5",
			},
			EventPool = 810005,
		},
		World1_Path4_Branch1_Node5 = {
			BranchRoot = "World1_Path4_Branch1_Node1",
			Seed = 1041,
			ChildIdList = {
				"World1_Path4_Branch1_Node6",
			},
			EventPool = 810002,
		},
		World1_Path4_Branch1_Node6 = {
			BranchRoot = "World1_Path4_Branch1_Node1",
			Seed = 1041,
			ChildIdList = {
				"World1_Path4_Branch1_Node7",
			},
			EventPool = 810013,
		},
		World1_Path4_Branch1_Node7 = {
			BranchRoot = "World1_Path4_Branch1_Node1",
			Seed = 1041,
			ChildIdList = {
				"World1_Path4_Branch1_Node8",
			},
			EventPool = 810002,
		},
		World1_Path4_Branch1_Node8 = {
			BranchRoot = "World1_Path4_Branch1_Node1",
			Seed = 1041,
			ChildIdList = {
				"World1_Path4_Branch1_Node9",
			},
			EventPool = 810009,
		},
		World1_Path4_Branch1_Node9 = {
			BranchRoot = "World1_Path4_Branch1_Node1",
			Seed = 1041,
			ChildIdList = {
				"World1_Path4_Branch1_Node10",
			},
			EventPool = 810012,
		},
		World1_Path4_Branch1_Node10 = {
			BranchRoot = "World1_Path4_Branch1_Node1",
			Seed = 1041,
			ChildIdList = {
				"World1_Path4_Branch1_Node11",
			},
			EventPool = 810003,
		},
		World1_Path4_Branch1_Node11 = {
			BranchRoot = "World1_Path4_Branch1_Node1",
			Seed = 1041,
			ChildIdList = {
				"World1_Path4_Branch1_Node12",
			},
			EventPool = 810009,
		},
		World1_Path4_Branch1_Node12 = {
			BranchRoot = "World1_Path4_Branch1_Node1",
			Seed = 1041,
			ChildIdList = {
				"World1_Path4_Branch1_Node13",
			},
			EventPool = 810001,
		},
		World1_Path4_Branch1_Node13 = {
			BranchRoot = "World1_Path4_Branch1_Node1",
			StepScore = 50,
			Seed = 1041,
			ChildIdList = {
				"World1_Path4_Branch1_Node14",
			},
			EventPool = 810006,
		},
		World1_Path4_Branch1_Node14 = {
			BranchRoot = "World1_Path4_Branch1_Node1",
			Seed = 1041,
			ChildIdList = {
				"World1_Path4_Branch1_Node15",
			},
			EventPool = 810013,
		},
		World1_Path4_Branch1_Node15 = {
			BranchRoot = "World1_Path4_Branch1_Node1",
			Seed = 1041,
			ChildIdList = {
				"World1_Path4_Branch1_Node16",
			},
			EventPool = 810007,
		},
		World1_Path4_Branch1_Node16 = {
			BranchRoot = "World1_Path4_Branch1_Node1",
			Seed = 1041,
			ChildIdList = {
				"World1_Path4_Branch1_Node17",
			},
			EventPool = 810008,
		},
		World1_Path4_Branch1_Node17 = {
			BranchRoot = "World1_Path4_Branch1_Node1",
			Seed = 1041,
			ChildIdList = {
				"World1_Path4_Branch1_Node18",
			},
			EventPool = 810002,
		},
		World1_Path4_Branch1_Node18 = {
			BranchRoot = "World1_Path4_Branch1_Node1",
			Seed = 1041,
			ChildIdList = {
				"World1_Path4_Branch1_Node19",
			},
			EventPool = 810001,
		},
		World1_Path4_Branch1_Node19 = {
			BranchRoot = "World1_Path4_Branch1_Node1",
			Seed = 1041,
			ChildIdList = {
				"World1_Path4_Branch1_Node20",
			},
			EventPool = 810011,
		},
		World1_Path4_Branch1_Node20 = {
			BranchRoot = "World1_Path4_Branch1_Node1",
			Seed = 1041,
			ChildIdList = {
				"World1_Path5_Branch1_Node1",
				"World1_Path5_Branch2_Node1",
			},
			EventPool = 810001,
		},
		World1_Path5_Branch1_Node1 = {
			BranchRoot = "World1_Path5_Branch1_Node1",
			Seed = 1051,
			ChildIdList = {
				"World1_Path5_Branch1_Node2",
			},
			EventPool = 810003,
		},
		World1_Path5_Branch1_Node2 = {
			BranchRoot = "World1_Path5_Branch1_Node1",
			Seed = 1051,
			ChildIdList = {
				"World1_Path5_Branch1_Node3",
			},
			EventPool = 810008,
		},
		World1_Path5_Branch1_Node3 = {
			BranchRoot = "World1_Path5_Branch1_Node1",
			Seed = 1051,
			ChildIdList = {
				"World1_Path5_Branch1_Node4",
			},
			EventPool = 810009,
		},
		World1_Path5_Branch1_Node4 = {
			BranchRoot = "World1_Path5_Branch1_Node1",
			Seed = 1051,
			ChildIdList = {
				"World1_Path5_Branch1_Node5",
			},
			EventPool = 810013,
		},
		World1_Path5_Branch1_Node5 = {
			BranchRoot = "World1_Path5_Branch1_Node1",
			Seed = 1051,
			ChildIdList = {
				"World1_Path5_Branch1_Node6",
			},
			EventPool = 810002,
		},
		World1_Path5_Branch1_Node6 = {
			BranchRoot = "World1_Path5_Branch1_Node1",
			Seed = 1051,
			ChildIdList = {
				"World1_Path5_Branch1_Node7",
			},
			EventPool = 810007,
		},
		World1_Path5_Branch1_Node7 = {
			BranchRoot = "World1_Path5_Branch1_Node1",
			Seed = 1051,
			ChildIdList = {
				"World1_Path5_Branch1_Node8",
			},
			EventPool = 810003,
		},
		World1_Path5_Branch1_Node8 = {
			BranchRoot = "World1_Path5_Branch1_Node1",
			Seed = 1051,
			ChildIdList = {
				"World1_Path5_Branch1_Node9",
			},
			EventPool = 810013,
		},
		World1_Path5_Branch1_Node9 = {
			BranchRoot = "World1_Path5_Branch1_Node1",
			Seed = 1051,
			ChildIdList = {
				"World1_Path5_Branch1_Node10",
			},
			EventPool = 810012,
		},
		World1_Path5_Branch1_Node10 = {
			BranchRoot = "World1_Path5_Branch1_Node1",
			Seed = 1051,
			ChildIdList = {
				"World1_Path5_Branch1_Node11",
			},
			EventPool = 810003,
		},
		World1_Path5_Branch1_Node11 = {
			BranchRoot = "World1_Path5_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 1051,
			ChildIdList = {
				"World1_Path5_Branch1_Node12",
			},
			EventPool = 810004,
		},
		World1_Path5_Branch1_Node12 = {
			BranchRoot = "World1_Path5_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 1051,
			ChildIdList = {
				"World1_Path5_Branch1_Node13",
			},
			EventPool = 810004,
		},
		World1_Path5_Branch1_Node13 = {
			BranchRoot = "World1_Path5_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 1051,
			ChildIdList = {
				"World1_Path5_Branch1_Node14",
			},
			EventPool = 810004,
		},
		World1_Path5_Branch1_Node14 = {
			BranchRoot = "World1_Path5_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 1051,
			ChildIdList = {
				"World1_Path5_Branch1_Node15",
			},
			EventPool = 810004,
		},
		World1_Path5_Branch1_Node15 = {
			BranchRoot = "World1_Path5_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 1051,
			ChildIdList = {
				"World1_Path5_Branch1_Node16",
			},
			EventPool = 810004,
		},
		World1_Path5_Branch1_Node16 = {
			BranchRoot = "World1_Path5_Branch1_Node1",
			Seed = 1051,
			ChildIdList = {
				"World1_Path5_Branch1_Node17",
			},
			EventPool = 810002,
		},
		World1_Path5_Branch1_Node17 = {
			BranchRoot = "World1_Path5_Branch1_Node1",
			Seed = 1051,
			ChildIdList = {
				"World1_Path5_Branch1_Node18",
			},
			EventPool = 810007,
		},
		World1_Path5_Branch1_Node18 = {
			BranchRoot = "World1_Path5_Branch1_Node1",
			Seed = 1051,
			ChildIdList = {
				"World1_Path5_Branch1_Node19",
			},
			EventPool = 810007,
		},
		World1_Path5_Branch1_Node19 = {
			BranchRoot = "World1_Path5_Branch1_Node1",
			Seed = 1051,
			ChildIdList = {
				"World1_Path5_Branch1_Node20",
			},
			EventPool = 810012,
		},
		World1_Path5_Branch1_Node20 = {
			BranchRoot = "World1_Path5_Branch1_Node1",
			Seed = 1051,
			ChildIdList = {
				"World1_Path6_Branch1_Node1",
				"World1_Path6_Branch2_Node1",
			},
			EventPool = 810008,
		},
		World1_Path6_Branch1_Node1 = {
			BranchRoot = "World1_Path6_Branch1_Node1",
			Seed = 1061,
			ChildIdList = {
				"World1_Path6_Branch1_Node2",
			},
			EventPool = 810007,
		},
		World1_Path6_Branch1_Node2 = {
			BranchRoot = "World1_Path6_Branch1_Node1",
			Seed = 1061,
			ChildIdList = {
				"World1_Path6_Branch1_Node3",
			},
			EventPool = 810007,
		},
		World1_Path6_Branch1_Node3 = {
			BranchRoot = "World1_Path6_Branch1_Node1",
			Seed = 1061,
			ChildIdList = {
				"World1_Path6_Branch1_Node4",
			},
			EventPool = 810002,
		},
		World1_Path6_Branch1_Node4 = {
			BranchRoot = "World1_Path6_Branch1_Node1",
			Seed = 1061,
			ChildIdList = {
				"World1_Path6_Branch1_Node5",
			},
			EventPool = 810002,
		},
		World1_Path6_Branch1_Node5 = {
			BranchRoot = "World1_Path6_Branch1_Node1",
			Seed = 1061,
			ChildIdList = {
				"World1_Path6_Branch1_Node6",
			},
			EventPool = 810001,
		},
		World1_Path6_Branch1_Node6 = {
			BranchRoot = "World1_Path6_Branch1_Node1",
			Seed = 1061,
			ChildIdList = {
				"World1_Path6_Branch1_Node7",
			},
			EventPool = 810002,
		},
		World1_Path6_Branch1_Node7 = {
			BranchRoot = "World1_Path6_Branch1_Node1",
			Seed = 1061,
			ChildIdList = {
				"World1_Path6_Branch1_Node8",
			},
			EventPool = 810001,
		},
		World1_Path6_Branch1_Node8 = {
			BranchRoot = "World1_Path6_Branch1_Node1",
			Seed = 1061,
			ChildIdList = {
				"World1_Path6_Branch1_Node9",
			},
			EventPool = 810007,
		},
		World1_Path6_Branch1_Node9 = {
			BranchRoot = "World1_Path6_Branch1_Node1",
			Seed = 1061,
			ChildIdList = {
				"World1_Path6_Branch1_Node10",
			},
			EventPool = 810012,
		},
		World1_Path6_Branch1_Node10 = {
			BranchRoot = "World1_Path6_Branch1_Node1",
			Seed = 1061,
			ChildIdList = {
				"World1_Path6_Branch1_Node11",
			},
			EventPool = 810003,
		},
		World1_Path6_Branch1_Node11 = {
			BranchRoot = "World1_Path6_Branch1_Node1",
			Seed = 1061,
			ChildIdList = {
				"World1_Path6_Branch1_Node12",
			},
			EventPool = 810013,
		},
		World1_Path6_Branch1_Node12 = {
			BranchRoot = "World1_Path6_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 1061,
			ChildIdList = {
				"World1_Path6_Branch1_Node13",
			},
			EventPool = 810004,
		},
		World1_Path6_Branch1_Node13 = {
			BranchRoot = "World1_Path6_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 1061,
			ChildIdList = {
				"World1_Path6_Branch1_Node14",
			},
			EventPool = 810004,
		},
		World1_Path6_Branch1_Node14 = {
			BranchRoot = "World1_Path6_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 1061,
			ChildIdList = {
				"World1_Path6_Branch1_Node15",
			},
			EventPool = 810004,
		},
		World1_Path6_Branch1_Node15 = {
			BranchRoot = "World1_Path6_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 1061,
			ChildIdList = {
				"World1_Path6_Branch1_Node16",
			},
			EventPool = 810004,
		},
		World1_Path6_Branch1_Node16 = {
			BranchRoot = "World1_Path6_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 1061,
			ChildIdList = {
				"World1_Path6_Branch1_Node17",
			},
			EventPool = 810004,
		},
		World1_Path6_Branch1_Node17 = {
			BranchRoot = "World1_Path6_Branch1_Node1",
			Seed = 1061,
			ChildIdList = {
				"World1_Path6_Branch1_Node18",
			},
			EventPool = 810009,
		},
		World1_Path6_Branch1_Node18 = {
			BranchRoot = "World1_Path6_Branch1_Node1",
			Seed = 1061,
			ChildIdList = {
				"World1_Path6_Branch1_Node19",
			},
			EventPool = 810002,
		},
		World1_Path6_Branch1_Node19 = {
			BranchRoot = "World1_Path6_Branch1_Node1",
			Seed = 1061,
			ChildIdList = {
				"World1_Path6_Branch1_Node20",
			},
			EventPool = 810007,
		},
		World1_Path6_Branch1_Node20 = {
			BranchRoot = "World1_Path6_Branch1_Node1",
			Seed = 1061,
			EventPool = 810010,
		},
		World1_Path2_Branch2_Node1 = {
			BranchRoot = "World1_Path2_Branch2_Node1",
			Seed = 1022,
			ChildIdList = {
				"World1_Path2_Branch2_Node2",
			},
			EventPool = 810013,
		},
		World1_Path2_Branch2_Node2 = {
			BranchRoot = "World1_Path2_Branch2_Node1",
			Seed = 1022,
			ChildIdList = {
				"World1_Path2_Branch2_Node3",
			},
			EventPool = 810003,
		},
		World1_Path2_Branch2_Node3 = {
			BranchRoot = "World1_Path2_Branch2_Node1",
			Seed = 1022,
			ChildIdList = {
				"World1_Path2_Branch2_Node4",
			},
			EventPool = 810003,
		},
		World1_Path2_Branch2_Node4 = {
			BranchRoot = "World1_Path2_Branch2_Node1",
			StepScore = 50,
			Seed = 1022,
			ChildIdList = {
				"World1_Path2_Branch2_Node5",
			},
			EventPool = 810006,
		},
		World1_Path2_Branch2_Node5 = {
			BranchRoot = "World1_Path2_Branch2_Node1",
			Seed = 1022,
			ChildIdList = {
				"World1_Path2_Branch2_Node6",
			},
			EventPool = 810003,
		},
		World1_Path2_Branch2_Node6 = {
			BranchRoot = "World1_Path2_Branch2_Node1",
			Seed = 1022,
			ChildIdList = {
				"World1_Path2_Branch2_Node7",
			},
			EventPool = 810007,
		},
		World1_Path2_Branch2_Node7 = {
			BranchRoot = "World1_Path2_Branch2_Node1",
			Seed = 1022,
			ChildIdList = {
				"World1_Path2_Branch2_Node8",
			},
			EventPool = 810007,
		},
		World1_Path2_Branch2_Node8 = {
			BranchRoot = "World1_Path2_Branch2_Node1",
			Seed = 1022,
			ChildIdList = {
				"World1_Path2_Branch2_Node9",
			},
			EventPool = 810001,
		},
		World1_Path2_Branch2_Node9 = {
			BranchRoot = "World1_Path2_Branch2_Node1",
			Seed = 1022,
			ChildIdList = {
				"World1_Path2_Branch2_Node10",
			},
			EventPool = 810012,
		},
		World1_Path2_Branch2_Node10 = {
			BranchRoot = "World1_Path2_Branch2_Node1",
			Seed = 1022,
			ChildIdList = {
				"World1_Path2_Branch2_Node11",
			},
			EventPool = 810008,
		},
		World1_Path2_Branch2_Node11 = {
			BranchRoot = "World1_Path2_Branch2_Node1",
			Seed = 1022,
			ChildIdList = {
				"World1_Path2_Branch2_Node12",
			},
			EventPool = 810009,
		},
		World1_Path2_Branch2_Node12 = {
			BranchRoot = "World1_Path2_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 1022,
			ChildIdList = {
				"World1_Path2_Branch2_Node13",
			},
			EventPool = 810005,
		},
		World1_Path2_Branch2_Node13 = {
			BranchRoot = "World1_Path2_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 1022,
			ChildIdList = {
				"World1_Path2_Branch2_Node14",
			},
			EventPool = 810005,
		},
		World1_Path2_Branch2_Node14 = {
			BranchRoot = "World1_Path2_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 1022,
			ChildIdList = {
				"World1_Path2_Branch2_Node15",
			},
			EventPool = 810005,
		},
		World1_Path2_Branch2_Node15 = {
			BranchRoot = "World1_Path2_Branch2_Node1",
			Seed = 1022,
			ChildIdList = {
				"World1_Path2_Branch2_Node16",
			},
			EventPool = 810001,
		},
		World1_Path2_Branch2_Node16 = {
			BranchRoot = "World1_Path2_Branch2_Node1",
			Seed = 1022,
			ChildIdList = {
				"World1_Path2_Branch2_Node17",
			},
			EventPool = 810001,
		},
		World1_Path2_Branch2_Node17 = {
			BranchRoot = "World1_Path2_Branch2_Node1",
			Seed = 1022,
			ChildIdList = {
				"World1_Path2_Branch2_Node18",
			},
			EventPool = 810007,
		},
		World1_Path2_Branch2_Node18 = {
			BranchRoot = "World1_Path2_Branch2_Node1",
			Seed = 1022,
			ChildIdList = {
				"World1_Path2_Branch2_Node19",
			},
			EventPool = 810009,
		},
		World1_Path2_Branch2_Node19 = {
			BranchRoot = "World1_Path2_Branch2_Node1",
			Seed = 1022,
			ChildIdList = {
				"World1_Path2_Branch2_Node20",
			},
			EventPool = 810011,
		},
		World1_Path2_Branch2_Node20 = {
			BranchRoot = "World1_Path2_Branch2_Node1",
			Seed = 1022,
			ChildIdList = {
				"World1_Path3_Branch1_Node1",
				"World1_Path3_Branch2_Node1",
			},
			EventPool = 810001,
		},
		World1_Path3_Branch2_Node1 = {
			BranchRoot = "World1_Path3_Branch2_Node1",
			Seed = 1032,
			ChildIdList = {
				"World1_Path3_Branch2_Node2",
			},
			EventPool = 810003,
		},
		World1_Path3_Branch2_Node2 = {
			BranchRoot = "World1_Path3_Branch2_Node1",
			Seed = 1032,
			ChildIdList = {
				"World1_Path3_Branch2_Node3",
			},
			EventPool = 810003,
		},
		World1_Path3_Branch2_Node3 = {
			BranchRoot = "World1_Path3_Branch2_Node1",
			Seed = 1032,
			ChildIdList = {
				"World1_Path3_Branch2_Node4",
			},
			EventPool = 810007,
		},
		World1_Path3_Branch2_Node4 = {
			BranchRoot = "World1_Path3_Branch2_Node1",
			Seed = 1032,
			ChildIdList = {
				"World1_Path3_Branch2_Node5",
			},
			EventPool = 810007,
		},
		World1_Path3_Branch2_Node5 = {
			BranchRoot = "World1_Path3_Branch2_Node1",
			Seed = 1032,
			ChildIdList = {
				"World1_Path3_Branch2_Node6",
			},
			EventPool = 810003,
		},
		World1_Path3_Branch2_Node6 = {
			BranchRoot = "World1_Path3_Branch2_Node1",
			Seed = 1032,
			ChildIdList = {
				"World1_Path3_Branch2_Node7",
			},
			EventPool = 810001,
		},
		World1_Path3_Branch2_Node7 = {
			BranchRoot = "World1_Path3_Branch2_Node1",
			Seed = 1032,
			ChildIdList = {
				"World1_Path3_Branch2_Node8",
			},
			EventPool = 810007,
		},
		World1_Path3_Branch2_Node8 = {
			BranchRoot = "World1_Path3_Branch2_Node1",
			Seed = 1032,
			ChildIdList = {
				"World1_Path3_Branch2_Node9",
			},
			EventPool = 810013,
		},
		World1_Path3_Branch2_Node9 = {
			BranchRoot = "World1_Path3_Branch2_Node1",
			Seed = 1032,
			ChildIdList = {
				"World1_Path3_Branch2_Node10",
			},
			EventPool = 810011,
		},
		World1_Path3_Branch2_Node10 = {
			BranchRoot = "World1_Path3_Branch2_Node1",
			Seed = 1032,
			ChildIdList = {
				"World1_Path3_Branch2_Node11",
			},
			EventPool = 810002,
		},
		World1_Path3_Branch2_Node11 = {
			BranchRoot = "World1_Path3_Branch2_Node1",
			Seed = 1032,
			ChildIdList = {
				"World1_Path3_Branch2_Node12",
			},
			EventPool = 810008,
		},
		World1_Path3_Branch2_Node12 = {
			BranchRoot = "World1_Path3_Branch2_Node1",
			Seed = 1032,
			ChildIdList = {
				"World1_Path3_Branch2_Node13",
			},
			EventPool = 810007,
		},
		World1_Path3_Branch2_Node13 = {
			BranchRoot = "World1_Path3_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 1032,
			ChildIdList = {
				"World1_Path3_Branch2_Node14",
			},
			EventPool = 810004,
		},
		World1_Path3_Branch2_Node14 = {
			BranchRoot = "World1_Path3_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 1032,
			ChildIdList = {
				"World1_Path3_Branch2_Node15",
			},
			EventPool = 810004,
		},
		World1_Path3_Branch2_Node15 = {
			BranchRoot = "World1_Path3_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 1032,
			ChildIdList = {
				"World1_Path3_Branch2_Node16",
			},
			EventPool = 810004,
		},
		World1_Path3_Branch2_Node16 = {
			BranchRoot = "World1_Path3_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 1032,
			ChildIdList = {
				"World1_Path3_Branch2_Node17",
			},
			EventPool = 810004,
		},
		World1_Path3_Branch2_Node17 = {
			BranchRoot = "World1_Path3_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 1032,
			ChildIdList = {
				"World1_Path3_Branch2_Node18",
			},
			EventPool = 810004,
		},
		World1_Path3_Branch2_Node18 = {
			BranchRoot = "World1_Path3_Branch2_Node1",
			Seed = 1032,
			ChildIdList = {
				"World1_Path3_Branch2_Node19",
			},
			EventPool = 810002,
		},
		World1_Path3_Branch2_Node19 = {
			BranchRoot = "World1_Path3_Branch2_Node1",
			Seed = 1032,
			ChildIdList = {
				"World1_Path3_Branch2_Node20",
			},
			EventPool = 810011,
		},
		World1_Path3_Branch2_Node20 = {
			BranchRoot = "World1_Path3_Branch2_Node1",
			Seed = 1032,
			ChildIdList = {
				"World1_Path4_Branch1_Node1",
				"World1_Path4_Branch2_Node1",
			},
			EventPool = 810002,
		},
		World1_Path4_Branch2_Node1 = {
			BranchRoot = "World1_Path4_Branch2_Node1",
			Seed = 1042,
			ChildIdList = {
				"World1_Path4_Branch2_Node2",
			},
			EventPool = 810008,
		},
		World1_Path4_Branch2_Node2 = {
			BranchRoot = "World1_Path4_Branch2_Node1",
			Seed = 1042,
			ChildIdList = {
				"World1_Path4_Branch2_Node3",
			},
			EventPool = 810008,
		},
		World1_Path4_Branch2_Node3 = {
			BranchRoot = "World1_Path4_Branch2_Node1",
			Seed = 1042,
			ChildIdList = {
				"World1_Path4_Branch2_Node4",
			},
			EventPool = 810007,
		},
		World1_Path4_Branch2_Node4 = {
			BranchRoot = "World1_Path4_Branch2_Node1",
			Seed = 1042,
			ChildIdList = {
				"World1_Path4_Branch2_Node5",
			},
			EventPool = 810003,
		},
		World1_Path4_Branch2_Node5 = {
			BranchRoot = "World1_Path4_Branch2_Node1",
			Seed = 1042,
			ChildIdList = {
				"World1_Path4_Branch2_Node6",
			},
			EventPool = 810013,
		},
		World1_Path4_Branch2_Node6 = {
			BranchRoot = "World1_Path4_Branch2_Node1",
			Seed = 1042,
			ChildIdList = {
				"World1_Path4_Branch2_Node7",
			},
			EventPool = 810009,
		},
		World1_Path4_Branch2_Node7 = {
			BranchRoot = "World1_Path4_Branch2_Node1",
			Seed = 1042,
			ChildIdList = {
				"World1_Path4_Branch2_Node8",
			},
			EventPool = 810003,
		},
		World1_Path4_Branch2_Node8 = {
			BranchRoot = "World1_Path4_Branch2_Node1",
			Seed = 1042,
			ChildIdList = {
				"World1_Path4_Branch2_Node9",
			},
			EventPool = 810008,
		},
		World1_Path4_Branch2_Node9 = {
			BranchRoot = "World1_Path4_Branch2_Node1",
			Seed = 1042,
			ChildIdList = {
				"World1_Path4_Branch2_Node10",
			},
			EventPool = 810012,
		},
		World1_Path4_Branch2_Node10 = {
			BranchRoot = "World1_Path4_Branch2_Node1",
			Seed = 1042,
			ChildIdList = {
				"World1_Path4_Branch2_Node11",
			},
			EventPool = 810007,
		},
		World1_Path4_Branch2_Node11 = {
			BranchRoot = "World1_Path4_Branch2_Node1",
			Seed = 1042,
			ChildIdList = {
				"World1_Path4_Branch2_Node12",
			},
			EventPool = 810003,
		},
		World1_Path4_Branch2_Node12 = {
			BranchRoot = "World1_Path4_Branch2_Node1",
			Seed = 1042,
			ChildIdList = {
				"World1_Path4_Branch2_Node13",
			},
			EventPool = 810002,
		},
		World1_Path4_Branch2_Node13 = {
			BranchRoot = "World1_Path4_Branch2_Node1",
			StepScore = 50,
			Seed = 1042,
			ChildIdList = {
				"World1_Path4_Branch2_Node14",
			},
			EventPool = 810006,
		},
		World1_Path4_Branch2_Node14 = {
			BranchRoot = "World1_Path4_Branch2_Node1",
			Seed = 1042,
			ChildIdList = {
				"World1_Path4_Branch2_Node15",
			},
			EventPool = 810003,
		},
		World1_Path4_Branch2_Node15 = {
			BranchRoot = "World1_Path4_Branch2_Node1",
			Seed = 1042,
			ChildIdList = {
				"World1_Path4_Branch2_Node16",
			},
			EventPool = 810009,
		},
		World1_Path4_Branch2_Node16 = {
			BranchRoot = "World1_Path4_Branch2_Node1",
			Seed = 1042,
			ChildIdList = {
				"World1_Path4_Branch2_Node17",
			},
			EventPool = 810001,
		},
		World1_Path4_Branch2_Node17 = {
			BranchRoot = "World1_Path4_Branch2_Node1",
			Seed = 1042,
			ChildIdList = {
				"World1_Path4_Branch2_Node18",
			},
			EventPool = 810001,
		},
		World1_Path4_Branch2_Node18 = {
			BranchRoot = "World1_Path4_Branch2_Node1",
			Seed = 1042,
			ChildIdList = {
				"World1_Path4_Branch2_Node19",
			},
			EventPool = 810013,
		},
		World1_Path4_Branch2_Node19 = {
			BranchRoot = "World1_Path4_Branch2_Node1",
			Seed = 1042,
			ChildIdList = {
				"World1_Path4_Branch2_Node20",
			},
			EventPool = 810012,
		},
		World1_Path4_Branch2_Node20 = {
			BranchRoot = "World1_Path4_Branch2_Node1",
			Seed = 1042,
			ChildIdList = {
				"World1_Path5_Branch1_Node1",
				"World1_Path5_Branch2_Node1",
			},
			EventPool = 810009,
		},
		World1_Path5_Branch2_Node1 = {
			BranchRoot = "World1_Path5_Branch2_Node1",
			Seed = 1052,
			ChildIdList = {
				"World1_Path5_Branch2_Node2",
			},
			EventPool = 810008,
		},
		World1_Path5_Branch2_Node2 = {
			BranchRoot = "World1_Path5_Branch2_Node1",
			Seed = 1052,
			ChildIdList = {
				"World1_Path5_Branch2_Node3",
			},
			EventPool = 810003,
		},
		World1_Path5_Branch2_Node3 = {
			BranchRoot = "World1_Path5_Branch2_Node1",
			Seed = 1052,
			ChildIdList = {
				"World1_Path5_Branch2_Node4",
			},
			EventPool = 810002,
		},
		World1_Path5_Branch2_Node4 = {
			BranchRoot = "World1_Path5_Branch2_Node1",
			Seed = 1052,
			ChildIdList = {
				"World1_Path5_Branch2_Node5",
			},
			EventPool = 810003,
		},
		World1_Path5_Branch2_Node5 = {
			BranchRoot = "World1_Path5_Branch2_Node1",
			Seed = 1052,
			ChildIdList = {
				"World1_Path5_Branch2_Node6",
			},
			EventPool = 810003,
		},
		World1_Path5_Branch2_Node6 = {
			BranchRoot = "World1_Path5_Branch2_Node1",
			Seed = 1052,
			ChildIdList = {
				"World1_Path5_Branch2_Node7",
			},
			EventPool = 810009,
		},
		World1_Path5_Branch2_Node7 = {
			BranchRoot = "World1_Path5_Branch2_Node1",
			Seed = 1052,
			ChildIdList = {
				"World1_Path5_Branch2_Node8",
			},
			EventPool = 810003,
		},
		World1_Path5_Branch2_Node8 = {
			BranchRoot = "World1_Path5_Branch2_Node1",
			Seed = 1052,
			ChildIdList = {
				"World1_Path5_Branch2_Node9",
			},
			EventPool = 810009,
		},
		World1_Path5_Branch2_Node9 = {
			BranchRoot = "World1_Path5_Branch2_Node1",
			Seed = 1052,
			ChildIdList = {
				"World1_Path5_Branch2_Node10",
			},
			EventPool = 810012,
		},
		World1_Path5_Branch2_Node10 = {
			BranchRoot = "World1_Path5_Branch2_Node1",
			Seed = 1052,
			ChildIdList = {
				"World1_Path5_Branch2_Node11",
			},
			EventPool = 810003,
		},
		World1_Path5_Branch2_Node11 = {
			BranchRoot = "World1_Path5_Branch2_Node1",
			Seed = 1052,
			ChildIdList = {
				"World1_Path5_Branch2_Node12",
			},
			EventPool = 810001,
		},
		World1_Path5_Branch2_Node12 = {
			BranchRoot = "World1_Path5_Branch2_Node1",
			Seed = 1052,
			ChildIdList = {
				"World1_Path5_Branch2_Node13",
			},
			EventPool = 810009,
		},
		World1_Path5_Branch2_Node13 = {
			BranchRoot = "World1_Path5_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 1052,
			ChildIdList = {
				"World1_Path5_Branch2_Node14",
			},
			EventPool = 810005,
		},
		World1_Path5_Branch2_Node14 = {
			BranchRoot = "World1_Path5_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 1052,
			ChildIdList = {
				"World1_Path5_Branch2_Node15",
			},
			EventPool = 810005,
		},
		World1_Path5_Branch2_Node15 = {
			BranchRoot = "World1_Path5_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 1052,
			ChildIdList = {
				"World1_Path5_Branch2_Node16",
			},
			EventPool = 810005,
		},
		World1_Path5_Branch2_Node16 = {
			BranchRoot = "World1_Path5_Branch2_Node1",
			Seed = 1052,
			ChildIdList = {
				"World1_Path5_Branch2_Node17",
			},
			EventPool = 810013,
		},
		World1_Path5_Branch2_Node17 = {
			BranchRoot = "World1_Path5_Branch2_Node1",
			Seed = 1052,
			ChildIdList = {
				"World1_Path5_Branch2_Node18",
			},
			EventPool = 810003,
		},
		World1_Path5_Branch2_Node18 = {
			BranchRoot = "World1_Path5_Branch2_Node1",
			Seed = 1052,
			ChildIdList = {
				"World1_Path5_Branch2_Node19",
			},
			EventPool = 810001,
		},
		World1_Path5_Branch2_Node19 = {
			BranchRoot = "World1_Path5_Branch2_Node1",
			Seed = 1052,
			ChildIdList = {
				"World1_Path5_Branch2_Node20",
			},
			EventPool = 810012,
		},
		World1_Path5_Branch2_Node20 = {
			BranchRoot = "World1_Path5_Branch2_Node1",
			Seed = 1052,
			ChildIdList = {
				"World1_Path6_Branch1_Node1",
				"World1_Path6_Branch2_Node1",
			},
			EventPool = 810003,
		},
		World1_Path6_Branch2_Node1 = {
			BranchRoot = "World1_Path6_Branch2_Node1",
			Seed = 1062,
			ChildIdList = {
				"World1_Path6_Branch2_Node2",
			},
			EventPool = 810013,
		},
		World1_Path6_Branch2_Node2 = {
			BranchRoot = "World1_Path6_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 1062,
			ChildIdList = {
				"World1_Path6_Branch2_Node3",
			},
			EventPool = 810004,
		},
		World1_Path6_Branch2_Node3 = {
			BranchRoot = "World1_Path6_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 1062,
			ChildIdList = {
				"World1_Path6_Branch2_Node4",
			},
			EventPool = 810004,
		},
		World1_Path6_Branch2_Node4 = {
			BranchRoot = "World1_Path6_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 1062,
			ChildIdList = {
				"World1_Path6_Branch2_Node5",
			},
			EventPool = 810004,
		},
		World1_Path6_Branch2_Node5 = {
			BranchRoot = "World1_Path6_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 1062,
			ChildIdList = {
				"World1_Path6_Branch2_Node6",
			},
			EventPool = 810004,
		},
		World1_Path6_Branch2_Node6 = {
			BranchRoot = "World1_Path6_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 1062,
			ChildIdList = {
				"World1_Path6_Branch2_Node7",
			},
			EventPool = 810004,
		},
		World1_Path6_Branch2_Node7 = {
			BranchRoot = "World1_Path6_Branch2_Node1",
			Seed = 1062,
			ChildIdList = {
				"World1_Path6_Branch2_Node8",
			},
			EventPool = 810003,
		},
		World1_Path6_Branch2_Node8 = {
			BranchRoot = "World1_Path6_Branch2_Node1",
			Seed = 1062,
			ChildIdList = {
				"World1_Path6_Branch2_Node9",
			},
			EventPool = 810013,
		},
		World1_Path6_Branch2_Node9 = {
			BranchRoot = "World1_Path6_Branch2_Node1",
			Seed = 1062,
			ChildIdList = {
				"World1_Path6_Branch2_Node10",
			},
			EventPool = 810012,
		},
		World1_Path6_Branch2_Node10 = {
			BranchRoot = "World1_Path6_Branch2_Node1",
			Seed = 1062,
			ChildIdList = {
				"World1_Path6_Branch2_Node11",
			},
			EventPool = 810001,
		},
		World1_Path6_Branch2_Node11 = {
			BranchRoot = "World1_Path6_Branch2_Node1",
			Seed = 1062,
			ChildIdList = {
				"World1_Path6_Branch2_Node12",
			},
			EventPool = 810013,
		},
		World1_Path6_Branch2_Node12 = {
			BranchRoot = "World1_Path6_Branch2_Node1",
			Seed = 1062,
			ChildIdList = {
				"World1_Path6_Branch2_Node13",
			},
			EventPool = 810001,
		},
		World1_Path6_Branch2_Node13 = {
			BranchRoot = "World1_Path6_Branch2_Node1",
			Seed = 1062,
			ChildIdList = {
				"World1_Path6_Branch2_Node14",
			},
			EventPool = 810008,
		},
		World1_Path6_Branch2_Node14 = {
			BranchRoot = "World1_Path6_Branch2_Node1",
			StepScore = 50,
			Seed = 1062,
			ChildIdList = {
				"World1_Path6_Branch2_Node15",
			},
			EventPool = 810006,
		},
		World1_Path6_Branch2_Node15 = {
			BranchRoot = "World1_Path6_Branch2_Node1",
			Seed = 1062,
			ChildIdList = {
				"World1_Path6_Branch2_Node16",
			},
			EventPool = 810001,
		},
		World1_Path6_Branch2_Node16 = {
			BranchRoot = "World1_Path6_Branch2_Node1",
			Seed = 1062,
			ChildIdList = {
				"World1_Path6_Branch2_Node17",
			},
			EventPool = 810008,
		},
		World1_Path6_Branch2_Node17 = {
			BranchRoot = "World1_Path6_Branch2_Node1",
			Seed = 1062,
			ChildIdList = {
				"World1_Path6_Branch2_Node18",
			},
			EventPool = 810009,
		},
		World1_Path6_Branch2_Node18 = {
			BranchRoot = "World1_Path6_Branch2_Node1",
			Seed = 1062,
			ChildIdList = {
				"World1_Path6_Branch2_Node19",
			},
			EventPool = 810009,
		},
		World1_Path6_Branch2_Node19 = {
			BranchRoot = "World1_Path6_Branch2_Node1",
			Seed = 1062,
			ChildIdList = {
				"World1_Path6_Branch2_Node20",
			},
			EventPool = 810003,
		},
		World1_Path6_Branch2_Node20 = {
			BranchRoot = "World1_Path6_Branch2_Node1",
			Seed = 1062,
			EventPool = 810010,
		},
	},
}
SpaceTravelMapConfig[SpaceTravelMapID.Id002] =
{
	Id = 2,
	WorldIndex = 2,
	Name = "传输的宙域",
	FirstNode = "World2_Path1_Branch1_Node1",
	LastNodeList = {
		"World2_Path6_Branch1_Node20",
		"World2_Path6_Branch2_Node20",
	},
	RoundScore = 0,
	StepScore = 15,
	RoundFuelCost = 45,
	StepFuelCost = 0,
	RoundFoodCost = 0,
	StepFoodCost = 0,
	Nodes = {
		World2_Path1_Branch1_Node1 = {
			BranchRoot = "World2_Path1_Branch1_Node1",
			Seed = 2011,
			ChildIdList = {
				"World2_Path1_Branch1_Node2",
			},
			EventPool = 810016,
		},
		World2_Path1_Branch1_Node2 = {
			BranchRoot = "World2_Path1_Branch1_Node1",
			Seed = 2011,
			ChildIdList = {
				"World2_Path1_Branch1_Node3",
			},
			EventPool = 810016,
		},
		World2_Path1_Branch1_Node3 = {
			BranchRoot = "World2_Path1_Branch1_Node1",
			Seed = 2011,
			ChildIdList = {
				"World2_Path1_Branch1_Node4",
			},
			EventPool = 810020,
		},
		World2_Path1_Branch1_Node4 = {
			BranchRoot = "World2_Path1_Branch1_Node1",
			Seed = 2011,
			ChildIdList = {
				"World2_Path1_Branch1_Node5",
			},
			EventPool = 810016,
		},
		World2_Path1_Branch1_Node5 = {
			BranchRoot = "World2_Path1_Branch1_Node1",
			Seed = 2011,
			ChildIdList = {
				"World2_Path1_Branch1_Node6",
			},
			EventPool = 810015,
		},
		World2_Path1_Branch1_Node6 = {
			BranchRoot = "World2_Path1_Branch1_Node1",
			Seed = 2011,
			ChildIdList = {
				"World2_Path1_Branch1_Node7",
			},
			EventPool = 810020,
		},
		World2_Path1_Branch1_Node7 = {
			BranchRoot = "World2_Path1_Branch1_Node1",
			Seed = 2011,
			ChildIdList = {
				"World2_Path1_Branch1_Node8",
			},
			EventPool = 810015,
		},
		World2_Path1_Branch1_Node8 = {
			BranchRoot = "World2_Path1_Branch1_Node1",
			Seed = 2011,
			ChildIdList = {
				"World2_Path1_Branch1_Node9",
			},
			EventPool = 810016,
		},
		World2_Path1_Branch1_Node9 = {
			BranchRoot = "World2_Path1_Branch1_Node1",
			Seed = 2011,
			ChildIdList = {
				"World2_Path1_Branch1_Node10",
			},
			EventPool = 810024,
		},
		World2_Path1_Branch1_Node10 = {
			BranchRoot = "World2_Path1_Branch1_Node1",
			Seed = 2011,
			ChildIdList = {
				"World2_Path1_Branch1_Node11",
			},
			EventPool = 810016,
		},
		World2_Path1_Branch1_Node11 = {
			BranchRoot = "World2_Path1_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 2011,
			ChildIdList = {
				"World2_Path1_Branch1_Node12",
			},
			EventPool = 810004,
		},
		World2_Path1_Branch1_Node12 = {
			BranchRoot = "World2_Path1_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 2011,
			ChildIdList = {
				"World2_Path1_Branch1_Node13",
			},
			EventPool = 810004,
		},
		World2_Path1_Branch1_Node13 = {
			BranchRoot = "World2_Path1_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 2011,
			ChildIdList = {
				"World2_Path1_Branch1_Node14",
			},
			EventPool = 810004,
		},
		World2_Path1_Branch1_Node14 = {
			BranchRoot = "World2_Path1_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 2011,
			ChildIdList = {
				"World2_Path1_Branch1_Node15",
			},
			EventPool = 810004,
		},
		World2_Path1_Branch1_Node15 = {
			BranchRoot = "World2_Path1_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 2011,
			ChildIdList = {
				"World2_Path1_Branch1_Node16",
			},
			EventPool = 810004,
		},
		World2_Path1_Branch1_Node16 = {
			BranchRoot = "World2_Path1_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 2011,
			ChildIdList = {
				"World2_Path1_Branch1_Node17",
			},
			EventPool = 810004,
		},
		World2_Path1_Branch1_Node17 = {
			BranchRoot = "World2_Path1_Branch1_Node1",
			Seed = 2011,
			ChildIdList = {
				"World2_Path1_Branch1_Node18",
			},
			EventPool = 810020,
		},
		World2_Path1_Branch1_Node18 = {
			BranchRoot = "World2_Path1_Branch1_Node1",
			Seed = 2011,
			ChildIdList = {
				"World2_Path1_Branch1_Node19",
			},
			EventPool = 810015,
		},
		World2_Path1_Branch1_Node19 = {
			BranchRoot = "World2_Path1_Branch1_Node1",
			Seed = 2011,
			ChildIdList = {
				"World2_Path1_Branch1_Node20",
			},
			EventPool = 810024,
		},
		World2_Path1_Branch1_Node20 = {
			BranchRoot = "World2_Path1_Branch1_Node1",
			Seed = 2011,
			ChildIdList = {
				"World2_Path2_Branch1_Node1",
				"World2_Path2_Branch2_Node1",
			},
			EventPool = 810022,
		},
		World2_Path2_Branch1_Node1 = {
			BranchRoot = "World2_Path2_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 2021,
			ChildIdList = {
				"World2_Path2_Branch1_Node2",
			},
			EventPool = 810005,
		},
		World2_Path2_Branch1_Node2 = {
			BranchRoot = "World2_Path2_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 2021,
			ChildIdList = {
				"World2_Path2_Branch1_Node3",
			},
			EventPool = 810005,
		},
		World2_Path2_Branch1_Node3 = {
			BranchRoot = "World2_Path2_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 2021,
			ChildIdList = {
				"World2_Path2_Branch1_Node4",
			},
			EventPool = 810005,
		},
		World2_Path2_Branch1_Node4 = {
			BranchRoot = "World2_Path2_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 2021,
			ChildIdList = {
				"World2_Path2_Branch1_Node5",
			},
			EventPool = 810005,
		},
		World2_Path2_Branch1_Node5 = {
			BranchRoot = "World2_Path2_Branch1_Node1",
			Seed = 2021,
			ChildIdList = {
				"World2_Path2_Branch1_Node6",
			},
			EventPool = 810015,
		},
		World2_Path2_Branch1_Node6 = {
			BranchRoot = "World2_Path2_Branch1_Node1",
			Seed = 2021,
			ChildIdList = {
				"World2_Path2_Branch1_Node7",
			},
			EventPool = 810026,
		},
		World2_Path2_Branch1_Node7 = {
			BranchRoot = "World2_Path2_Branch1_Node1",
			Seed = 2021,
			ChildIdList = {
				"World2_Path2_Branch1_Node8",
			},
			EventPool = 810021,
		},
		World2_Path2_Branch1_Node8 = {
			BranchRoot = "World2_Path2_Branch1_Node1",
			Seed = 2021,
			ChildIdList = {
				"World2_Path2_Branch1_Node9",
			},
			EventPool = 810026,
		},
		World2_Path2_Branch1_Node9 = {
			BranchRoot = "World2_Path2_Branch1_Node1",
			Seed = 2021,
			ChildIdList = {
				"World2_Path2_Branch1_Node10",
			},
			EventPool = 810025,
		},
		World2_Path2_Branch1_Node10 = {
			BranchRoot = "World2_Path2_Branch1_Node1",
			Seed = 2021,
			ChildIdList = {
				"World2_Path2_Branch1_Node11",
			},
			EventPool = 810022,
		},
		World2_Path2_Branch1_Node11 = {
			BranchRoot = "World2_Path2_Branch1_Node1",
			Seed = 2021,
			ChildIdList = {
				"World2_Path2_Branch1_Node12",
			},
			EventPool = 810015,
		},
		World2_Path2_Branch1_Node12 = {
			BranchRoot = "World2_Path2_Branch1_Node1",
			Seed = 2021,
			ChildIdList = {
				"World2_Path2_Branch1_Node13",
			},
			EventPool = 810021,
		},
		World2_Path2_Branch1_Node13 = {
			BranchRoot = "World2_Path2_Branch1_Node1",
			Seed = 2021,
			ChildIdList = {
				"World2_Path2_Branch1_Node14",
			},
			EventPool = 810014,
		},
		World2_Path2_Branch1_Node14 = {
			BranchRoot = "World2_Path2_Branch1_Node1",
			StepScore = 50,
			Seed = 2021,
			ChildIdList = {
				"World2_Path2_Branch1_Node15",
			},
			EventPool = 810006,
		},
		World2_Path2_Branch1_Node15 = {
			BranchRoot = "World2_Path2_Branch1_Node1",
			Seed = 2021,
			ChildIdList = {
				"World2_Path2_Branch1_Node16",
			},
			EventPool = 810015,
		},
		World2_Path2_Branch1_Node16 = {
			BranchRoot = "World2_Path2_Branch1_Node1",
			Seed = 2021,
			ChildIdList = {
				"World2_Path2_Branch1_Node17",
			},
			EventPool = 810016,
		},
		World2_Path2_Branch1_Node17 = {
			BranchRoot = "World2_Path2_Branch1_Node1",
			Seed = 2021,
			ChildIdList = {
				"World2_Path2_Branch1_Node18",
			},
			EventPool = 810016,
		},
		World2_Path2_Branch1_Node18 = {
			BranchRoot = "World2_Path2_Branch1_Node1",
			Seed = 2021,
			ChildIdList = {
				"World2_Path2_Branch1_Node19",
			},
			EventPool = 810021,
		},
		World2_Path2_Branch1_Node19 = {
			BranchRoot = "World2_Path2_Branch1_Node1",
			Seed = 2021,
			ChildIdList = {
				"World2_Path2_Branch1_Node20",
			},
			EventPool = 810024,
		},
		World2_Path2_Branch1_Node20 = {
			BranchRoot = "World2_Path2_Branch1_Node1",
			Seed = 2021,
			ChildIdList = {
				"World2_Path3_Branch1_Node1",
				"World2_Path3_Branch2_Node1",
			},
			EventPool = 810015,
		},
		World2_Path3_Branch1_Node1 = {
			BranchRoot = "World2_Path3_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 2031,
			ChildIdList = {
				"World2_Path3_Branch1_Node2",
			},
			EventPool = 810004,
		},
		World2_Path3_Branch1_Node2 = {
			BranchRoot = "World2_Path3_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 2031,
			ChildIdList = {
				"World2_Path3_Branch1_Node3",
			},
			EventPool = 810004,
		},
		World2_Path3_Branch1_Node3 = {
			BranchRoot = "World2_Path3_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 2031,
			ChildIdList = {
				"World2_Path3_Branch1_Node4",
			},
			EventPool = 810004,
		},
		World2_Path3_Branch1_Node4 = {
			BranchRoot = "World2_Path3_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 2031,
			ChildIdList = {
				"World2_Path3_Branch1_Node5",
			},
			EventPool = 810004,
		},
		World2_Path3_Branch1_Node5 = {
			BranchRoot = "World2_Path3_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 2031,
			ChildIdList = {
				"World2_Path3_Branch1_Node6",
			},
			EventPool = 810004,
		},
		World2_Path3_Branch1_Node6 = {
			BranchRoot = "World2_Path3_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 2031,
			ChildIdList = {
				"World2_Path3_Branch1_Node7",
			},
			EventPool = 810004,
		},
		World2_Path3_Branch1_Node7 = {
			BranchRoot = "World2_Path3_Branch1_Node1",
			Seed = 2031,
			ChildIdList = {
				"World2_Path3_Branch1_Node8",
			},
			EventPool = 810022,
		},
		World2_Path3_Branch1_Node8 = {
			BranchRoot = "World2_Path3_Branch1_Node1",
			Seed = 2031,
			ChildIdList = {
				"World2_Path3_Branch1_Node9",
			},
			EventPool = 810020,
		},
		World2_Path3_Branch1_Node9 = {
			BranchRoot = "World2_Path3_Branch1_Node1",
			Seed = 2031,
			ChildIdList = {
				"World2_Path3_Branch1_Node10",
			},
			EventPool = 810025,
		},
		World2_Path3_Branch1_Node10 = {
			BranchRoot = "World2_Path3_Branch1_Node1",
			Seed = 2031,
			ChildIdList = {
				"World2_Path3_Branch1_Node11",
			},
			EventPool = 810015,
		},
		World2_Path3_Branch1_Node11 = {
			BranchRoot = "World2_Path3_Branch1_Node1",
			Seed = 2031,
			ChildIdList = {
				"World2_Path3_Branch1_Node12",
			},
			EventPool = 810014,
		},
		World2_Path3_Branch1_Node12 = {
			BranchRoot = "World2_Path3_Branch1_Node1",
			Seed = 2031,
			ChildIdList = {
				"World2_Path3_Branch1_Node13",
			},
			EventPool = 810016,
		},
		World2_Path3_Branch1_Node13 = {
			BranchRoot = "World2_Path3_Branch1_Node1",
			Seed = 2031,
			ChildIdList = {
				"World2_Path3_Branch1_Node14",
			},
			EventPool = 810020,
		},
		World2_Path3_Branch1_Node14 = {
			BranchRoot = "World2_Path3_Branch1_Node1",
			Seed = 2031,
			ChildIdList = {
				"World2_Path3_Branch1_Node15",
			},
			EventPool = 810022,
		},
		World2_Path3_Branch1_Node15 = {
			BranchRoot = "World2_Path3_Branch1_Node1",
			Seed = 2031,
			ChildIdList = {
				"World2_Path3_Branch1_Node16",
			},
			EventPool = 810016,
		},
		World2_Path3_Branch1_Node16 = {
			BranchRoot = "World2_Path3_Branch1_Node1",
			Seed = 2031,
			ChildIdList = {
				"World2_Path3_Branch1_Node17",
			},
			EventPool = 810016,
		},
		World2_Path3_Branch1_Node17 = {
			BranchRoot = "World2_Path3_Branch1_Node1",
			Seed = 2031,
			ChildIdList = {
				"World2_Path3_Branch1_Node18",
			},
			EventPool = 810015,
		},
		World2_Path3_Branch1_Node18 = {
			BranchRoot = "World2_Path3_Branch1_Node1",
			Seed = 2031,
			ChildIdList = {
				"World2_Path3_Branch1_Node19",
			},
			EventPool = 810020,
		},
		World2_Path3_Branch1_Node19 = {
			BranchRoot = "World2_Path3_Branch1_Node1",
			Seed = 2031,
			ChildIdList = {
				"World2_Path3_Branch1_Node20",
			},
			EventPool = 810025,
		},
		World2_Path3_Branch1_Node20 = {
			BranchRoot = "World2_Path3_Branch1_Node1",
			Seed = 2031,
			ChildIdList = {
				"World2_Path4_Branch1_Node1",
				"World2_Path4_Branch2_Node1",
			},
			EventPool = 810022,
		},
		World2_Path4_Branch1_Node1 = {
			BranchRoot = "World2_Path4_Branch1_Node1",
			Seed = 2041,
			ChildIdList = {
				"World2_Path4_Branch1_Node2",
			},
			EventPool = 810015,
		},
		World2_Path4_Branch1_Node2 = {
			BranchRoot = "World2_Path4_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 2041,
			ChildIdList = {
				"World2_Path4_Branch1_Node3",
			},
			EventPool = 810005,
		},
		World2_Path4_Branch1_Node3 = {
			BranchRoot = "World2_Path4_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 2041,
			ChildIdList = {
				"World2_Path4_Branch1_Node4",
			},
			EventPool = 810005,
		},
		World2_Path4_Branch1_Node4 = {
			BranchRoot = "World2_Path4_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 2041,
			ChildIdList = {
				"World2_Path4_Branch1_Node5",
			},
			EventPool = 810005,
		},
		World2_Path4_Branch1_Node5 = {
			BranchRoot = "World2_Path4_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 2041,
			ChildIdList = {
				"World2_Path4_Branch1_Node6",
			},
			EventPool = 810005,
		},
		World2_Path4_Branch1_Node6 = {
			BranchRoot = "World2_Path4_Branch1_Node1",
			Seed = 2041,
			ChildIdList = {
				"World2_Path4_Branch1_Node7",
			},
			EventPool = 810020,
		},
		World2_Path4_Branch1_Node7 = {
			BranchRoot = "World2_Path4_Branch1_Node1",
			Seed = 2041,
			ChildIdList = {
				"World2_Path4_Branch1_Node8",
			},
			EventPool = 810014,
		},
		World2_Path4_Branch1_Node8 = {
			BranchRoot = "World2_Path4_Branch1_Node1",
			Seed = 2041,
			ChildIdList = {
				"World2_Path4_Branch1_Node9",
			},
			EventPool = 810022,
		},
		World2_Path4_Branch1_Node9 = {
			BranchRoot = "World2_Path4_Branch1_Node1",
			Seed = 2041,
			ChildIdList = {
				"World2_Path4_Branch1_Node10",
			},
			EventPool = 810025,
		},
		World2_Path4_Branch1_Node10 = {
			BranchRoot = "World2_Path4_Branch1_Node1",
			Seed = 2041,
			ChildIdList = {
				"World2_Path4_Branch1_Node11",
			},
			EventPool = 810022,
		},
		World2_Path4_Branch1_Node11 = {
			BranchRoot = "World2_Path4_Branch1_Node1",
			Seed = 2041,
			ChildIdList = {
				"World2_Path4_Branch1_Node12",
			},
			EventPool = 810016,
		},
		World2_Path4_Branch1_Node12 = {
			BranchRoot = "World2_Path4_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 2041,
			ChildIdList = {
				"World2_Path4_Branch1_Node13",
			},
			EventPool = 810004,
		},
		World2_Path4_Branch1_Node13 = {
			BranchRoot = "World2_Path4_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 2041,
			ChildIdList = {
				"World2_Path4_Branch1_Node14",
			},
			EventPool = 810004,
		},
		World2_Path4_Branch1_Node14 = {
			BranchRoot = "World2_Path4_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 2041,
			ChildIdList = {
				"World2_Path4_Branch1_Node15",
			},
			EventPool = 810004,
		},
		World2_Path4_Branch1_Node15 = {
			BranchRoot = "World2_Path4_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 2041,
			ChildIdList = {
				"World2_Path4_Branch1_Node16",
			},
			EventPool = 810004,
		},
		World2_Path4_Branch1_Node16 = {
			BranchRoot = "World2_Path4_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 2041,
			ChildIdList = {
				"World2_Path4_Branch1_Node17",
			},
			EventPool = 810004,
		},
		World2_Path4_Branch1_Node17 = {
			BranchRoot = "World2_Path4_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 2041,
			ChildIdList = {
				"World2_Path4_Branch1_Node18",
			},
			EventPool = 810004,
		},
		World2_Path4_Branch1_Node18 = {
			BranchRoot = "World2_Path4_Branch1_Node1",
			Seed = 2041,
			ChildIdList = {
				"World2_Path4_Branch1_Node19",
			},
			EventPool = 810016,
		},
		World2_Path4_Branch1_Node19 = {
			BranchRoot = "World2_Path4_Branch1_Node1",
			Seed = 2041,
			ChildIdList = {
				"World2_Path4_Branch1_Node20",
			},
			EventPool = 810025,
		},
		World2_Path4_Branch1_Node20 = {
			BranchRoot = "World2_Path4_Branch1_Node1",
			Seed = 2041,
			ChildIdList = {
				"World2_Path5_Branch1_Node1",
				"World2_Path5_Branch2_Node1",
			},
			EventPool = 810020,
		},
		World2_Path5_Branch1_Node1 = {
			BranchRoot = "World2_Path5_Branch1_Node1",
			Seed = 2051,
			ChildIdList = {
				"World2_Path5_Branch1_Node2",
			},
			EventPool = 810015,
		},
		World2_Path5_Branch1_Node2 = {
			BranchRoot = "World2_Path5_Branch1_Node1",
			Seed = 2051,
			ChildIdList = {
				"World2_Path5_Branch1_Node3",
			},
			EventPool = 810021,
		},
		World2_Path5_Branch1_Node3 = {
			BranchRoot = "World2_Path5_Branch1_Node1",
			StepScore = 50,
			Seed = 2051,
			ChildIdList = {
				"World2_Path5_Branch1_Node4",
			},
			EventPool = 810006,
		},
		World2_Path5_Branch1_Node4 = {
			BranchRoot = "World2_Path5_Branch1_Node1",
			Seed = 2051,
			ChildIdList = {
				"World2_Path5_Branch1_Node5",
			},
			EventPool = 810014,
		},
		World2_Path5_Branch1_Node5 = {
			BranchRoot = "World2_Path5_Branch1_Node1",
			Seed = 2051,
			ChildIdList = {
				"World2_Path5_Branch1_Node6",
			},
			EventPool = 810016,
		},
		World2_Path5_Branch1_Node6 = {
			BranchRoot = "World2_Path5_Branch1_Node1",
			Seed = 2051,
			ChildIdList = {
				"World2_Path5_Branch1_Node7",
			},
			EventPool = 810020,
		},
		World2_Path5_Branch1_Node7 = {
			BranchRoot = "World2_Path5_Branch1_Node1",
			Seed = 2051,
			ChildIdList = {
				"World2_Path5_Branch1_Node8",
			},
			EventPool = 810020,
		},
		World2_Path5_Branch1_Node8 = {
			BranchRoot = "World2_Path5_Branch1_Node1",
			Seed = 2051,
			ChildIdList = {
				"World2_Path5_Branch1_Node9",
			},
			EventPool = 810021,
		},
		World2_Path5_Branch1_Node9 = {
			BranchRoot = "World2_Path5_Branch1_Node1",
			Seed = 2051,
			ChildIdList = {
				"World2_Path5_Branch1_Node10",
			},
			EventPool = 810025,
		},
		World2_Path5_Branch1_Node10 = {
			BranchRoot = "World2_Path5_Branch1_Node1",
			Seed = 2051,
			ChildIdList = {
				"World2_Path5_Branch1_Node11",
			},
			EventPool = 810014,
		},
		World2_Path5_Branch1_Node11 = {
			BranchRoot = "World2_Path5_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 2051,
			ChildIdList = {
				"World2_Path5_Branch1_Node12",
			},
			EventPool = 810005,
		},
		World2_Path5_Branch1_Node12 = {
			BranchRoot = "World2_Path5_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 2051,
			ChildIdList = {
				"World2_Path5_Branch1_Node13",
			},
			EventPool = 810005,
		},
		World2_Path5_Branch1_Node13 = {
			BranchRoot = "World2_Path5_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 2051,
			ChildIdList = {
				"World2_Path5_Branch1_Node14",
			},
			EventPool = 810005,
		},
		World2_Path5_Branch1_Node14 = {
			BranchRoot = "World2_Path5_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 2051,
			ChildIdList = {
				"World2_Path5_Branch1_Node15",
			},
			EventPool = 810005,
		},
		World2_Path5_Branch1_Node15 = {
			BranchRoot = "World2_Path5_Branch1_Node1",
			Seed = 2051,
			ChildIdList = {
				"World2_Path5_Branch1_Node16",
			},
			EventPool = 810020,
		},
		World2_Path5_Branch1_Node16 = {
			BranchRoot = "World2_Path5_Branch1_Node1",
			Seed = 2051,
			ChildIdList = {
				"World2_Path5_Branch1_Node17",
			},
			EventPool = 810015,
		},
		World2_Path5_Branch1_Node17 = {
			BranchRoot = "World2_Path5_Branch1_Node1",
			Seed = 2051,
			ChildIdList = {
				"World2_Path5_Branch1_Node18",
			},
			EventPool = 810014,
		},
		World2_Path5_Branch1_Node18 = {
			BranchRoot = "World2_Path5_Branch1_Node1",
			Seed = 2051,
			ChildIdList = {
				"World2_Path5_Branch1_Node19",
			},
			EventPool = 810014,
		},
		World2_Path5_Branch1_Node19 = {
			BranchRoot = "World2_Path5_Branch1_Node1",
			Seed = 2051,
			ChildIdList = {
				"World2_Path5_Branch1_Node20",
			},
			EventPool = 810025,
		},
		World2_Path5_Branch1_Node20 = {
			BranchRoot = "World2_Path5_Branch1_Node1",
			Seed = 2051,
			ChildIdList = {
				"World2_Path6_Branch1_Node1",
				"World2_Path6_Branch2_Node1",
			},
			EventPool = 810026,
		},
		World2_Path6_Branch1_Node1 = {
			BranchRoot = "World2_Path6_Branch1_Node1",
			Seed = 2061,
			ChildIdList = {
				"World2_Path6_Branch1_Node2",
			},
			EventPool = 810020,
		},
		World2_Path6_Branch1_Node2 = {
			BranchRoot = "World2_Path6_Branch1_Node1",
			Seed = 2061,
			ChildIdList = {
				"World2_Path6_Branch1_Node3",
			},
			EventPool = 810022,
		},
		World2_Path6_Branch1_Node3 = {
			BranchRoot = "World2_Path6_Branch1_Node1",
			Seed = 2061,
			ChildIdList = {
				"World2_Path6_Branch1_Node4",
			},
			EventPool = 810021,
		},
		World2_Path6_Branch1_Node4 = {
			BranchRoot = "World2_Path6_Branch1_Node1",
			Seed = 2061,
			ChildIdList = {
				"World2_Path6_Branch1_Node5",
			},
			EventPool = 810021,
		},
		World2_Path6_Branch1_Node5 = {
			BranchRoot = "World2_Path6_Branch1_Node1",
			Seed = 2061,
			ChildIdList = {
				"World2_Path6_Branch1_Node6",
			},
			EventPool = 810014,
		},
		World2_Path6_Branch1_Node6 = {
			BranchRoot = "World2_Path6_Branch1_Node1",
			Seed = 2061,
			ChildIdList = {
				"World2_Path6_Branch1_Node7",
			},
			EventPool = 810020,
		},
		World2_Path6_Branch1_Node7 = {
			BranchRoot = "World2_Path6_Branch1_Node1",
			Seed = 2061,
			ChildIdList = {
				"World2_Path6_Branch1_Node8",
			},
			EventPool = 810015,
		},
		World2_Path6_Branch1_Node8 = {
			BranchRoot = "World2_Path6_Branch1_Node1",
			Seed = 2061,
			ChildIdList = {
				"World2_Path6_Branch1_Node9",
			},
			EventPool = 810014,
		},
		World2_Path6_Branch1_Node9 = {
			BranchRoot = "World2_Path6_Branch1_Node1",
			Seed = 2061,
			ChildIdList = {
				"World2_Path6_Branch1_Node10",
			},
			EventPool = 810025,
		},
		World2_Path6_Branch1_Node10 = {
			BranchRoot = "World2_Path6_Branch1_Node1",
			Seed = 2061,
			ChildIdList = {
				"World2_Path6_Branch1_Node11",
			},
			EventPool = 810014,
		},
		World2_Path6_Branch1_Node11 = {
			BranchRoot = "World2_Path6_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 2061,
			ChildIdList = {
				"World2_Path6_Branch1_Node12",
			},
			EventPool = 810004,
		},
		World2_Path6_Branch1_Node12 = {
			BranchRoot = "World2_Path6_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 2061,
			ChildIdList = {
				"World2_Path6_Branch1_Node13",
			},
			EventPool = 810004,
		},
		World2_Path6_Branch1_Node13 = {
			BranchRoot = "World2_Path6_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 2061,
			ChildIdList = {
				"World2_Path6_Branch1_Node14",
			},
			EventPool = 810004,
		},
		World2_Path6_Branch1_Node14 = {
			BranchRoot = "World2_Path6_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 2061,
			ChildIdList = {
				"World2_Path6_Branch1_Node15",
			},
			EventPool = 810004,
		},
		World2_Path6_Branch1_Node15 = {
			BranchRoot = "World2_Path6_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 2061,
			ChildIdList = {
				"World2_Path6_Branch1_Node16",
			},
			EventPool = 810004,
		},
		World2_Path6_Branch1_Node16 = {
			BranchRoot = "World2_Path6_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 2061,
			ChildIdList = {
				"World2_Path6_Branch1_Node17",
			},
			EventPool = 810004,
		},
		World2_Path6_Branch1_Node17 = {
			BranchRoot = "World2_Path6_Branch1_Node1",
			Seed = 2061,
			ChildIdList = {
				"World2_Path6_Branch1_Node18",
			},
			EventPool = 810015,
		},
		World2_Path6_Branch1_Node18 = {
			BranchRoot = "World2_Path6_Branch1_Node1",
			Seed = 2061,
			ChildIdList = {
				"World2_Path6_Branch1_Node19",
			},
			EventPool = 810014,
		},
		World2_Path6_Branch1_Node19 = {
			BranchRoot = "World2_Path6_Branch1_Node1",
			Seed = 2061,
			ChildIdList = {
				"World2_Path6_Branch1_Node20",
			},
			EventPool = 810014,
		},
		World2_Path6_Branch1_Node20 = {
			BranchRoot = "World2_Path6_Branch1_Node1",
			Seed = 2061,
			EventPool = 810023,
		},
		World2_Path2_Branch2_Node1 = {
			BranchRoot = "World2_Path2_Branch2_Node1",
			Seed = 2022,
			ChildIdList = {
				"World2_Path2_Branch2_Node2",
			},
			EventPool = 810015,
		},
		World2_Path2_Branch2_Node2 = {
			BranchRoot = "World2_Path2_Branch2_Node1",
			Seed = 2022,
			ChildIdList = {
				"World2_Path2_Branch2_Node3",
			},
			EventPool = 810020,
		},
		World2_Path2_Branch2_Node3 = {
			BranchRoot = "World2_Path2_Branch2_Node1",
			Seed = 2022,
			ChildIdList = {
				"World2_Path2_Branch2_Node4",
			},
			EventPool = 810014,
		},
		World2_Path2_Branch2_Node4 = {
			BranchRoot = "World2_Path2_Branch2_Node1",
			Seed = 2022,
			ChildIdList = {
				"World2_Path2_Branch2_Node5",
			},
			EventPool = 810016,
		},
		World2_Path2_Branch2_Node5 = {
			BranchRoot = "World2_Path2_Branch2_Node1",
			StepScore = 50,
			Seed = 2022,
			ChildIdList = {
				"World2_Path2_Branch2_Node6",
			},
			EventPool = 810006,
		},
		World2_Path2_Branch2_Node6 = {
			BranchRoot = "World2_Path2_Branch2_Node1",
			Seed = 2022,
			ChildIdList = {
				"World2_Path2_Branch2_Node7",
			},
			EventPool = 810016,
		},
		World2_Path2_Branch2_Node7 = {
			BranchRoot = "World2_Path2_Branch2_Node1",
			Seed = 2022,
			ChildIdList = {
				"World2_Path2_Branch2_Node8",
			},
			EventPool = 810026,
		},
		World2_Path2_Branch2_Node8 = {
			BranchRoot = "World2_Path2_Branch2_Node1",
			Seed = 2022,
			ChildIdList = {
				"World2_Path2_Branch2_Node9",
			},
			EventPool = 810021,
		},
		World2_Path2_Branch2_Node9 = {
			BranchRoot = "World2_Path2_Branch2_Node1",
			Seed = 2022,
			ChildIdList = {
				"World2_Path2_Branch2_Node10",
			},
			EventPool = 810025,
		},
		World2_Path2_Branch2_Node10 = {
			BranchRoot = "World2_Path2_Branch2_Node1",
			Seed = 2022,
			ChildIdList = {
				"World2_Path2_Branch2_Node11",
			},
			EventPool = 810021,
		},
		World2_Path2_Branch2_Node11 = {
			BranchRoot = "World2_Path2_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 2022,
			ChildIdList = {
				"World2_Path2_Branch2_Node12",
			},
			EventPool = 810005,
		},
		World2_Path2_Branch2_Node12 = {
			BranchRoot = "World2_Path2_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 2022,
			ChildIdList = {
				"World2_Path2_Branch2_Node13",
			},
			EventPool = 810005,
		},
		World2_Path2_Branch2_Node13 = {
			BranchRoot = "World2_Path2_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 2022,
			ChildIdList = {
				"World2_Path2_Branch2_Node14",
			},
			EventPool = 810005,
		},
		World2_Path2_Branch2_Node14 = {
			BranchRoot = "World2_Path2_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 2022,
			ChildIdList = {
				"World2_Path2_Branch2_Node15",
			},
			EventPool = 810005,
		},
		World2_Path2_Branch2_Node15 = {
			BranchRoot = "World2_Path2_Branch2_Node1",
			Seed = 2022,
			ChildIdList = {
				"World2_Path2_Branch2_Node16",
			},
			EventPool = 810016,
		},
		World2_Path2_Branch2_Node16 = {
			BranchRoot = "World2_Path2_Branch2_Node1",
			Seed = 2022,
			ChildIdList = {
				"World2_Path2_Branch2_Node17",
			},
			EventPool = 810016,
		},
		World2_Path2_Branch2_Node17 = {
			BranchRoot = "World2_Path2_Branch2_Node1",
			Seed = 2022,
			ChildIdList = {
				"World2_Path2_Branch2_Node18",
			},
			EventPool = 810014,
		},
		World2_Path2_Branch2_Node18 = {
			BranchRoot = "World2_Path2_Branch2_Node1",
			Seed = 2022,
			ChildIdList = {
				"World2_Path2_Branch2_Node19",
			},
			EventPool = 810015,
		},
		World2_Path2_Branch2_Node19 = {
			BranchRoot = "World2_Path2_Branch2_Node1",
			Seed = 2022,
			ChildIdList = {
				"World2_Path2_Branch2_Node20",
			},
			EventPool = 810024,
		},
		World2_Path2_Branch2_Node20 = {
			BranchRoot = "World2_Path2_Branch2_Node1",
			Seed = 2022,
			ChildIdList = {
				"World2_Path3_Branch1_Node1",
				"World2_Path3_Branch2_Node1",
			},
			EventPool = 810014,
		},
		World2_Path3_Branch2_Node1 = {
			BranchRoot = "World2_Path3_Branch2_Node1",
			Seed = 2032,
			ChildIdList = {
				"World2_Path3_Branch2_Node2",
			},
			EventPool = 810016,
		},
		World2_Path3_Branch2_Node2 = {
			BranchRoot = "World2_Path3_Branch2_Node1",
			Seed = 2032,
			ChildIdList = {
				"World2_Path3_Branch2_Node3",
			},
			EventPool = 810016,
		},
		World2_Path3_Branch2_Node3 = {
			BranchRoot = "World2_Path3_Branch2_Node1",
			Seed = 2032,
			ChildIdList = {
				"World2_Path3_Branch2_Node4",
			},
			EventPool = 810026,
		},
		World2_Path3_Branch2_Node4 = {
			BranchRoot = "World2_Path3_Branch2_Node1",
			StepScore = 50,
			Seed = 2032,
			ChildIdList = {
				"World2_Path3_Branch2_Node5",
			},
			EventPool = 810006,
		},
		World2_Path3_Branch2_Node5 = {
			BranchRoot = "World2_Path3_Branch2_Node1",
			Seed = 2032,
			ChildIdList = {
				"World2_Path3_Branch2_Node6",
			},
			EventPool = 810014,
		},
		World2_Path3_Branch2_Node6 = {
			BranchRoot = "World2_Path3_Branch2_Node1",
			Seed = 2032,
			ChildIdList = {
				"World2_Path3_Branch2_Node7",
			},
			EventPool = 810021,
		},
		World2_Path3_Branch2_Node7 = {
			BranchRoot = "World2_Path3_Branch2_Node1",
			Seed = 2032,
			ChildIdList = {
				"World2_Path3_Branch2_Node8",
			},
			EventPool = 810016,
		},
		World2_Path3_Branch2_Node8 = {
			BranchRoot = "World2_Path3_Branch2_Node1",
			Seed = 2032,
			ChildIdList = {
				"World2_Path3_Branch2_Node9",
			},
			EventPool = 810016,
		},
		World2_Path3_Branch2_Node9 = {
			BranchRoot = "World2_Path3_Branch2_Node1",
			Seed = 2032,
			ChildIdList = {
				"World2_Path3_Branch2_Node10",
			},
			EventPool = 810025,
		},
		World2_Path3_Branch2_Node10 = {
			BranchRoot = "World2_Path3_Branch2_Node1",
			Seed = 2032,
			ChildIdList = {
				"World2_Path3_Branch2_Node11",
			},
			EventPool = 810015,
		},
		World2_Path3_Branch2_Node11 = {
			BranchRoot = "World2_Path3_Branch2_Node1",
			Seed = 2032,
			ChildIdList = {
				"World2_Path3_Branch2_Node12",
			},
			EventPool = 810026,
		},
		World2_Path3_Branch2_Node12 = {
			BranchRoot = "World2_Path3_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 2032,
			ChildIdList = {
				"World2_Path3_Branch2_Node13",
			},
			EventPool = 810004,
		},
		World2_Path3_Branch2_Node13 = {
			BranchRoot = "World2_Path3_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 2032,
			ChildIdList = {
				"World2_Path3_Branch2_Node14",
			},
			EventPool = 810004,
		},
		World2_Path3_Branch2_Node14 = {
			BranchRoot = "World2_Path3_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 2032,
			ChildIdList = {
				"World2_Path3_Branch2_Node15",
			},
			EventPool = 810004,
		},
		World2_Path3_Branch2_Node15 = {
			BranchRoot = "World2_Path3_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 2032,
			ChildIdList = {
				"World2_Path3_Branch2_Node16",
			},
			EventPool = 810004,
		},
		World2_Path3_Branch2_Node16 = {
			BranchRoot = "World2_Path3_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 2032,
			ChildIdList = {
				"World2_Path3_Branch2_Node17",
			},
			EventPool = 810004,
		},
		World2_Path3_Branch2_Node17 = {
			BranchRoot = "World2_Path3_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 2032,
			ChildIdList = {
				"World2_Path3_Branch2_Node18",
			},
			EventPool = 810004,
		},
		World2_Path3_Branch2_Node18 = {
			BranchRoot = "World2_Path3_Branch2_Node1",
			Seed = 2032,
			ChildIdList = {
				"World2_Path3_Branch2_Node19",
			},
			EventPool = 810015,
		},
		World2_Path3_Branch2_Node19 = {
			BranchRoot = "World2_Path3_Branch2_Node1",
			Seed = 2032,
			ChildIdList = {
				"World2_Path3_Branch2_Node20",
			},
			EventPool = 810024,
		},
		World2_Path3_Branch2_Node20 = {
			BranchRoot = "World2_Path3_Branch2_Node1",
			Seed = 2032,
			ChildIdList = {
				"World2_Path4_Branch1_Node1",
				"World2_Path4_Branch2_Node1",
			},
			EventPool = 810015,
		},
		World2_Path4_Branch2_Node1 = {
			BranchRoot = "World2_Path4_Branch2_Node1",
			Seed = 2042,
			ChildIdList = {
				"World2_Path4_Branch2_Node2",
			},
			EventPool = 810014,
		},
		World2_Path4_Branch2_Node2 = {
			BranchRoot = "World2_Path4_Branch2_Node1",
			Seed = 2042,
			ChildIdList = {
				"World2_Path4_Branch2_Node3",
			},
			EventPool = 810016,
		},
		World2_Path4_Branch2_Node3 = {
			BranchRoot = "World2_Path4_Branch2_Node1",
			Seed = 2042,
			ChildIdList = {
				"World2_Path4_Branch2_Node4",
			},
			EventPool = 810015,
		},
		World2_Path4_Branch2_Node4 = {
			BranchRoot = "World2_Path4_Branch2_Node1",
			Seed = 2042,
			ChildIdList = {
				"World2_Path4_Branch2_Node5",
			},
			EventPool = 810016,
		},
		World2_Path4_Branch2_Node5 = {
			BranchRoot = "World2_Path4_Branch2_Node1",
			Seed = 2042,
			ChildIdList = {
				"World2_Path4_Branch2_Node6",
			},
			EventPool = 810016,
		},
		World2_Path4_Branch2_Node6 = {
			BranchRoot = "World2_Path4_Branch2_Node1",
			Seed = 2042,
			ChildIdList = {
				"World2_Path4_Branch2_Node7",
			},
			EventPool = 810015,
		},
		World2_Path4_Branch2_Node7 = {
			BranchRoot = "World2_Path4_Branch2_Node1",
			Seed = 2042,
			ChildIdList = {
				"World2_Path4_Branch2_Node8",
			},
			EventPool = 810020,
		},
		World2_Path4_Branch2_Node8 = {
			BranchRoot = "World2_Path4_Branch2_Node1",
			Seed = 2042,
			ChildIdList = {
				"World2_Path4_Branch2_Node9",
			},
			EventPool = 810014,
		},
		World2_Path4_Branch2_Node9 = {
			BranchRoot = "World2_Path4_Branch2_Node1",
			Seed = 2042,
			ChildIdList = {
				"World2_Path4_Branch2_Node10",
			},
			EventPool = 810024,
		},
		World2_Path4_Branch2_Node10 = {
			BranchRoot = "World2_Path4_Branch2_Node1",
			Seed = 2042,
			ChildIdList = {
				"World2_Path4_Branch2_Node11",
			},
			EventPool = 810020,
		},
		World2_Path4_Branch2_Node11 = {
			BranchRoot = "World2_Path4_Branch2_Node1",
			Seed = 2042,
			ChildIdList = {
				"World2_Path4_Branch2_Node12",
			},
			EventPool = 810021,
		},
		World2_Path4_Branch2_Node12 = {
			BranchRoot = "World2_Path4_Branch2_Node1",
			Seed = 2042,
			ChildIdList = {
				"World2_Path4_Branch2_Node13",
			},
			EventPool = 810014,
		},
		World2_Path4_Branch2_Node13 = {
			BranchRoot = "World2_Path4_Branch2_Node1",
			Seed = 2042,
			ChildIdList = {
				"World2_Path4_Branch2_Node14",
			},
			EventPool = 810015,
		},
		World2_Path4_Branch2_Node14 = {
			BranchRoot = "World2_Path4_Branch2_Node1",
			Seed = 2042,
			ChildIdList = {
				"World2_Path4_Branch2_Node15",
			},
			EventPool = 810016,
		},
		World2_Path4_Branch2_Node15 = {
			BranchRoot = "World2_Path4_Branch2_Node1",
			Seed = 2042,
			ChildIdList = {
				"World2_Path4_Branch2_Node16",
			},
			EventPool = 810015,
		},
		World2_Path4_Branch2_Node16 = {
			BranchRoot = "World2_Path4_Branch2_Node1",
			Seed = 2042,
			ChildIdList = {
				"World2_Path4_Branch2_Node17",
			},
			EventPool = 810021,
		},
		World2_Path4_Branch2_Node17 = {
			BranchRoot = "World2_Path4_Branch2_Node1",
			Seed = 2042,
			ChildIdList = {
				"World2_Path4_Branch2_Node18",
			},
			EventPool = 810020,
		},
		World2_Path4_Branch2_Node18 = {
			BranchRoot = "World2_Path4_Branch2_Node1",
			Seed = 2042,
			ChildIdList = {
				"World2_Path4_Branch2_Node19",
			},
			EventPool = 810015,
		},
		World2_Path4_Branch2_Node19 = {
			BranchRoot = "World2_Path4_Branch2_Node1",
			Seed = 2042,
			ChildIdList = {
				"World2_Path4_Branch2_Node20",
			},
			EventPool = 810024,
		},
		World2_Path4_Branch2_Node20 = {
			BranchRoot = "World2_Path4_Branch2_Node1",
			Seed = 2042,
			ChildIdList = {
				"World2_Path5_Branch1_Node1",
				"World2_Path5_Branch2_Node1",
			},
			EventPool = 810015,
		},
		World2_Path5_Branch2_Node1 = {
			BranchRoot = "World2_Path5_Branch2_Node1",
			Seed = 2052,
			ChildIdList = {
				"World2_Path5_Branch2_Node2",
			},
			EventPool = 810020,
		},
		World2_Path5_Branch2_Node2 = {
			BranchRoot = "World2_Path5_Branch2_Node1",
			Seed = 2052,
			ChildIdList = {
				"World2_Path5_Branch2_Node3",
			},
			EventPool = 810026,
		},
		World2_Path5_Branch2_Node3 = {
			BranchRoot = "World2_Path5_Branch2_Node1",
			Seed = 2052,
			ChildIdList = {
				"World2_Path5_Branch2_Node4",
			},
			EventPool = 810016,
		},
		World2_Path5_Branch2_Node4 = {
			BranchRoot = "World2_Path5_Branch2_Node1",
			StepScore = 50,
			Seed = 2052,
			ChildIdList = {
				"World2_Path5_Branch2_Node5",
			},
			EventPool = 810006,
		},
		World2_Path5_Branch2_Node5 = {
			BranchRoot = "World2_Path5_Branch2_Node1",
			Seed = 2052,
			ChildIdList = {
				"World2_Path5_Branch2_Node6",
			},
			EventPool = 810014,
		},
		World2_Path5_Branch2_Node6 = {
			BranchRoot = "World2_Path5_Branch2_Node1",
			Seed = 2052,
			ChildIdList = {
				"World2_Path5_Branch2_Node7",
			},
			EventPool = 810026,
		},
		World2_Path5_Branch2_Node7 = {
			BranchRoot = "World2_Path5_Branch2_Node1",
			Seed = 2052,
			ChildIdList = {
				"World2_Path5_Branch2_Node8",
			},
			EventPool = 810020,
		},
		World2_Path5_Branch2_Node8 = {
			BranchRoot = "World2_Path5_Branch2_Node1",
			Seed = 2052,
			ChildIdList = {
				"World2_Path5_Branch2_Node9",
			},
			EventPool = 810016,
		},
		World2_Path5_Branch2_Node9 = {
			BranchRoot = "World2_Path5_Branch2_Node1",
			Seed = 2052,
			ChildIdList = {
				"World2_Path5_Branch2_Node10",
			},
			EventPool = 810025,
		},
		World2_Path5_Branch2_Node10 = {
			BranchRoot = "World2_Path5_Branch2_Node1",
			Seed = 2052,
			ChildIdList = {
				"World2_Path5_Branch2_Node11",
			},
			EventPool = 810016,
		},
		World2_Path5_Branch2_Node11 = {
			BranchRoot = "World2_Path5_Branch2_Node1",
			Seed = 2052,
			ChildIdList = {
				"World2_Path5_Branch2_Node12",
			},
			EventPool = 810021,
		},
		World2_Path5_Branch2_Node12 = {
			BranchRoot = "World2_Path5_Branch2_Node1",
			Seed = 2052,
			ChildIdList = {
				"World2_Path5_Branch2_Node13",
			},
			EventPool = 810014,
		},
		World2_Path5_Branch2_Node13 = {
			BranchRoot = "World2_Path5_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 2052,
			ChildIdList = {
				"World2_Path5_Branch2_Node14",
			},
			EventPool = 810005,
		},
		World2_Path5_Branch2_Node14 = {
			BranchRoot = "World2_Path5_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 2052,
			ChildIdList = {
				"World2_Path5_Branch2_Node15",
			},
			EventPool = 810005,
		},
		World2_Path5_Branch2_Node15 = {
			BranchRoot = "World2_Path5_Branch2_Node1",
			StepScore = 50,
			Seed = 2052,
			ChildIdList = {
				"World2_Path5_Branch2_Node16",
			},
			EventPool = 810006,
		},
		World2_Path5_Branch2_Node16 = {
			BranchRoot = "World2_Path5_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 2052,
			ChildIdList = {
				"World2_Path5_Branch2_Node17",
			},
			EventPool = 810005,
		},
		World2_Path5_Branch2_Node17 = {
			BranchRoot = "World2_Path5_Branch2_Node1",
			Seed = 2052,
			ChildIdList = {
				"World2_Path5_Branch2_Node18",
			},
			EventPool = 810015,
		},
		World2_Path5_Branch2_Node18 = {
			BranchRoot = "World2_Path5_Branch2_Node1",
			Seed = 2052,
			ChildIdList = {
				"World2_Path5_Branch2_Node19",
			},
			EventPool = 810016,
		},
		World2_Path5_Branch2_Node19 = {
			BranchRoot = "World2_Path5_Branch2_Node1",
			Seed = 2052,
			ChildIdList = {
				"World2_Path5_Branch2_Node20",
			},
			EventPool = 810025,
		},
		World2_Path5_Branch2_Node20 = {
			BranchRoot = "World2_Path5_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 2052,
			ChildIdList = {
				"World2_Path6_Branch1_Node1",
				"World2_Path6_Branch2_Node1",
			},
			EventPool = 810004,
		},
		World2_Path6_Branch2_Node1 = {
			BranchRoot = "World2_Path6_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 2062,
			ChildIdList = {
				"World2_Path6_Branch2_Node2",
			},
			EventPool = 810004,
		},
		World2_Path6_Branch2_Node2 = {
			BranchRoot = "World2_Path6_Branch2_Node1",
			StepScore = 50,
			Seed = 2062,
			ChildIdList = {
				"World2_Path6_Branch2_Node3",
			},
			EventPool = 810006,
		},
		World2_Path6_Branch2_Node3 = {
			BranchRoot = "World2_Path6_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 2062,
			ChildIdList = {
				"World2_Path6_Branch2_Node4",
			},
			EventPool = 810004,
		},
		World2_Path6_Branch2_Node4 = {
			BranchRoot = "World2_Path6_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 2062,
			ChildIdList = {
				"World2_Path6_Branch2_Node5",
			},
			EventPool = 810004,
		},
		World2_Path6_Branch2_Node5 = {
			BranchRoot = "World2_Path6_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 2062,
			ChildIdList = {
				"World2_Path6_Branch2_Node6",
			},
			EventPool = 810004,
		},
		World2_Path6_Branch2_Node6 = {
			BranchRoot = "World2_Path6_Branch2_Node1",
			Seed = 2062,
			ChildIdList = {
				"World2_Path6_Branch2_Node7",
			},
			EventPool = 810015,
		},
		World2_Path6_Branch2_Node7 = {
			BranchRoot = "World2_Path6_Branch2_Node1",
			Seed = 2062,
			ChildIdList = {
				"World2_Path6_Branch2_Node8",
			},
			EventPool = 810021,
		},
		World2_Path6_Branch2_Node8 = {
			BranchRoot = "World2_Path6_Branch2_Node1",
			Seed = 2062,
			ChildIdList = {
				"World2_Path6_Branch2_Node9",
			},
			EventPool = 810014,
		},
		World2_Path6_Branch2_Node9 = {
			BranchRoot = "World2_Path6_Branch2_Node1",
			Seed = 2062,
			ChildIdList = {
				"World2_Path6_Branch2_Node10",
			},
			EventPool = 810025,
		},
		World2_Path6_Branch2_Node10 = {
			BranchRoot = "World2_Path6_Branch2_Node1",
			Seed = 2062,
			ChildIdList = {
				"World2_Path6_Branch2_Node11",
			},
			EventPool = 810014,
		},
		World2_Path6_Branch2_Node11 = {
			BranchRoot = "World2_Path6_Branch2_Node1",
			Seed = 2062,
			ChildIdList = {
				"World2_Path6_Branch2_Node12",
			},
			EventPool = 810022,
		},
		World2_Path6_Branch2_Node12 = {
			BranchRoot = "World2_Path6_Branch2_Node1",
			Seed = 2062,
			ChildIdList = {
				"World2_Path6_Branch2_Node13",
			},
			EventPool = 810021,
		},
		World2_Path6_Branch2_Node13 = {
			BranchRoot = "World2_Path6_Branch2_Node1",
			Seed = 2062,
			ChildIdList = {
				"World2_Path6_Branch2_Node14",
			},
			EventPool = 810016,
		},
		World2_Path6_Branch2_Node14 = {
			BranchRoot = "World2_Path6_Branch2_Node1",
			Seed = 2062,
			ChildIdList = {
				"World2_Path6_Branch2_Node15",
			},
			EventPool = 810015,
		},
		World2_Path6_Branch2_Node15 = {
			BranchRoot = "World2_Path6_Branch2_Node1",
			Seed = 2062,
			ChildIdList = {
				"World2_Path6_Branch2_Node16",
			},
			EventPool = 810015,
		},
		World2_Path6_Branch2_Node16 = {
			BranchRoot = "World2_Path6_Branch2_Node1",
			Seed = 2062,
			ChildIdList = {
				"World2_Path6_Branch2_Node17",
			},
			EventPool = 810014,
		},
		World2_Path6_Branch2_Node17 = {
			BranchRoot = "World2_Path6_Branch2_Node1",
			Seed = 2062,
			ChildIdList = {
				"World2_Path6_Branch2_Node18",
			},
			EventPool = 810021,
		},
		World2_Path6_Branch2_Node18 = {
			BranchRoot = "World2_Path6_Branch2_Node1",
			Seed = 2062,
			ChildIdList = {
				"World2_Path6_Branch2_Node19",
			},
			EventPool = 810016,
		},
		World2_Path6_Branch2_Node19 = {
			BranchRoot = "World2_Path6_Branch2_Node1",
			Seed = 2062,
			ChildIdList = {
				"World2_Path6_Branch2_Node20",
			},
			EventPool = 810022,
		},
		World2_Path6_Branch2_Node20 = {
			BranchRoot = "World2_Path6_Branch2_Node1",
			Seed = 2062,
			EventPool = 810023,
		},
	},
}
SpaceTravelMapConfig[SpaceTravelMapID.Id003] =
{
	Id = 3,
	WorldIndex = 3,
	Name = "美食的宙域",
	FirstNode = "World3_Path1_Branch1_Node1",
	LastNodeList = {
		"World3_Path6_Branch1_Node20",
		"World3_Path6_Branch2_Node20",
	},
	RoundScore = 0,
	StepScore = 20,
	RoundFuelCost = 60,
	StepFuelCost = 0,
	RoundFoodCost = 0,
	StepFoodCost = 0,
	Nodes = {
		World3_Path1_Branch1_Node1 = {
			BranchRoot = "World3_Path1_Branch1_Node1",
			Seed = 3011,
			ChildIdList = {
				"World3_Path1_Branch1_Node2",
			},
			EventPool = 810016,
		},
		World3_Path1_Branch1_Node2 = {
			BranchRoot = "World3_Path1_Branch1_Node1",
			Seed = 3011,
			ChildIdList = {
				"World3_Path1_Branch1_Node3",
			},
			EventPool = 810016,
		},
		World3_Path1_Branch1_Node3 = {
			BranchRoot = "World3_Path1_Branch1_Node1",
			Seed = 3011,
			ChildIdList = {
				"World3_Path1_Branch1_Node4",
			},
			EventPool = 810026,
		},
		World3_Path1_Branch1_Node4 = {
			BranchRoot = "World3_Path1_Branch1_Node1",
			Seed = 3011,
			ChildIdList = {
				"World3_Path1_Branch1_Node5",
			},
			EventPool = 810014,
		},
		World3_Path1_Branch1_Node5 = {
			BranchRoot = "World3_Path1_Branch1_Node1",
			Seed = 3011,
			ChildIdList = {
				"World3_Path1_Branch1_Node6",
			},
			EventPool = 810021,
		},
		World3_Path1_Branch1_Node6 = {
			BranchRoot = "World3_Path1_Branch1_Node1",
			Seed = 3011,
			ChildIdList = {
				"World3_Path1_Branch1_Node7",
			},
			EventPool = 810014,
		},
		World3_Path1_Branch1_Node7 = {
			BranchRoot = "World3_Path1_Branch1_Node1",
			Seed = 3011,
			ChildIdList = {
				"World3_Path1_Branch1_Node8",
			},
			EventPool = 810026,
		},
		World3_Path1_Branch1_Node8 = {
			BranchRoot = "World3_Path1_Branch1_Node1",
			Seed = 3011,
			ChildIdList = {
				"World3_Path1_Branch1_Node9",
			},
			EventPool = 810020,
		},
		World3_Path1_Branch1_Node9 = {
			BranchRoot = "World3_Path1_Branch1_Node1",
			Seed = 3011,
			ChildIdList = {
				"World3_Path1_Branch1_Node10",
			},
			EventPool = 810024,
		},
		World3_Path1_Branch1_Node10 = {
			BranchRoot = "World3_Path1_Branch1_Node1",
			Seed = 3011,
			ChildIdList = {
				"World3_Path1_Branch1_Node11",
			},
			EventPool = 810016,
		},
		World3_Path1_Branch1_Node11 = {
			BranchRoot = "World3_Path1_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 3011,
			ChildIdList = {
				"World3_Path1_Branch1_Node12",
			},
			EventPool = 810004,
		},
		World3_Path1_Branch1_Node12 = {
			BranchRoot = "World3_Path1_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 3011,
			ChildIdList = {
				"World3_Path1_Branch1_Node13",
			},
			EventPool = 810004,
		},
		World3_Path1_Branch1_Node13 = {
			BranchRoot = "World3_Path1_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 3011,
			ChildIdList = {
				"World3_Path1_Branch1_Node14",
			},
			EventPool = 810004,
		},
		World3_Path1_Branch1_Node14 = {
			BranchRoot = "World3_Path1_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 3011,
			ChildIdList = {
				"World3_Path1_Branch1_Node15",
			},
			EventPool = 810004,
		},
		World3_Path1_Branch1_Node15 = {
			BranchRoot = "World3_Path1_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 3011,
			ChildIdList = {
				"World3_Path1_Branch1_Node16",
			},
			EventPool = 810004,
		},
		World3_Path1_Branch1_Node16 = {
			BranchRoot = "World3_Path1_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 3011,
			ChildIdList = {
				"World3_Path1_Branch1_Node17",
			},
			EventPool = 810004,
		},
		World3_Path1_Branch1_Node17 = {
			BranchRoot = "World3_Path1_Branch1_Node1",
			Seed = 3011,
			ChildIdList = {
				"World3_Path1_Branch1_Node18",
			},
			EventPool = 810015,
		},
		World3_Path1_Branch1_Node18 = {
			BranchRoot = "World3_Path1_Branch1_Node1",
			Seed = 3011,
			ChildIdList = {
				"World3_Path1_Branch1_Node19",
			},
			EventPool = 810014,
		},
		World3_Path1_Branch1_Node19 = {
			BranchRoot = "World3_Path1_Branch1_Node1",
			Seed = 3011,
			ChildIdList = {
				"World3_Path1_Branch1_Node20",
			},
			EventPool = 810024,
		},
		World3_Path1_Branch1_Node20 = {
			BranchRoot = "World3_Path1_Branch1_Node1",
			Seed = 3011,
			ChildIdList = {
				"World3_Path2_Branch1_Node1",
				"World3_Path2_Branch2_Node1",
			},
			EventPool = 810026,
		},
		World3_Path2_Branch1_Node1 = {
			BranchRoot = "World3_Path2_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 3021,
			ChildIdList = {
				"World3_Path2_Branch1_Node2",
			},
			EventPool = 810005,
		},
		World3_Path2_Branch1_Node2 = {
			BranchRoot = "World3_Path2_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 3021,
			ChildIdList = {
				"World3_Path2_Branch1_Node3",
			},
			EventPool = 810005,
		},
		World3_Path2_Branch1_Node3 = {
			BranchRoot = "World3_Path2_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 3021,
			ChildIdList = {
				"World3_Path2_Branch1_Node4",
			},
			EventPool = 810005,
		},
		World3_Path2_Branch1_Node4 = {
			BranchRoot = "World3_Path2_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 3021,
			ChildIdList = {
				"World3_Path2_Branch1_Node5",
			},
			EventPool = 810005,
		},
		World3_Path2_Branch1_Node5 = {
			BranchRoot = "World3_Path2_Branch1_Node1",
			Seed = 3021,
			ChildIdList = {
				"World3_Path2_Branch1_Node6",
			},
			EventPool = 810016,
		},
		World3_Path2_Branch1_Node6 = {
			BranchRoot = "World3_Path2_Branch1_Node1",
			Seed = 3021,
			ChildIdList = {
				"World3_Path2_Branch1_Node7",
			},
			EventPool = 810016,
		},
		World3_Path2_Branch1_Node7 = {
			BranchRoot = "World3_Path2_Branch1_Node1",
			Seed = 3021,
			ChildIdList = {
				"World3_Path2_Branch1_Node8",
			},
			EventPool = 810026,
		},
		World3_Path2_Branch1_Node8 = {
			BranchRoot = "World3_Path2_Branch1_Node1",
			Seed = 3021,
			ChildIdList = {
				"World3_Path2_Branch1_Node9",
			},
			EventPool = 810016,
		},
		World3_Path2_Branch1_Node9 = {
			BranchRoot = "World3_Path2_Branch1_Node1",
			Seed = 3021,
			ChildIdList = {
				"World3_Path2_Branch1_Node10",
			},
			EventPool = 810025,
		},
		World3_Path2_Branch1_Node10 = {
			BranchRoot = "World3_Path2_Branch1_Node1",
			Seed = 3021,
			ChildIdList = {
				"World3_Path2_Branch1_Node11",
			},
			EventPool = 810016,
		},
		World3_Path2_Branch1_Node11 = {
			BranchRoot = "World3_Path2_Branch1_Node1",
			Seed = 3021,
			ChildIdList = {
				"World3_Path2_Branch1_Node12",
			},
			EventPool = 810021,
		},
		World3_Path2_Branch1_Node12 = {
			BranchRoot = "World3_Path2_Branch1_Node1",
			Seed = 3021,
			ChildIdList = {
				"World3_Path2_Branch1_Node13",
			},
			EventPool = 810015,
		},
		World3_Path2_Branch1_Node13 = {
			BranchRoot = "World3_Path2_Branch1_Node1",
			Seed = 3021,
			ChildIdList = {
				"World3_Path2_Branch1_Node14",
			},
			EventPool = 810022,
		},
		World3_Path2_Branch1_Node14 = {
			BranchRoot = "World3_Path2_Branch1_Node1",
			StepScore = 50,
			Seed = 3021,
			ChildIdList = {
				"World3_Path2_Branch1_Node15",
			},
			EventPool = 810006,
		},
		World3_Path2_Branch1_Node15 = {
			BranchRoot = "World3_Path2_Branch1_Node1",
			Seed = 3021,
			ChildIdList = {
				"World3_Path2_Branch1_Node16",
			},
			EventPool = 810021,
		},
		World3_Path2_Branch1_Node16 = {
			BranchRoot = "World3_Path2_Branch1_Node1",
			Seed = 3021,
			ChildIdList = {
				"World3_Path2_Branch1_Node17",
			},
			EventPool = 810021,
		},
		World3_Path2_Branch1_Node17 = {
			BranchRoot = "World3_Path2_Branch1_Node1",
			Seed = 3021,
			ChildIdList = {
				"World3_Path2_Branch1_Node18",
			},
			EventPool = 810020,
		},
		World3_Path2_Branch1_Node18 = {
			BranchRoot = "World3_Path2_Branch1_Node1",
			Seed = 3021,
			ChildIdList = {
				"World3_Path2_Branch1_Node19",
			},
			EventPool = 810016,
		},
		World3_Path2_Branch1_Node19 = {
			BranchRoot = "World3_Path2_Branch1_Node1",
			Seed = 3021,
			ChildIdList = {
				"World3_Path2_Branch1_Node20",
			},
			EventPool = 810024,
		},
		World3_Path2_Branch1_Node20 = {
			BranchRoot = "World3_Path2_Branch1_Node1",
			Seed = 3021,
			ChildIdList = {
				"World3_Path3_Branch1_Node1",
				"World3_Path3_Branch2_Node1",
			},
			EventPool = 810015,
		},
		World3_Path3_Branch1_Node1 = {
			BranchRoot = "World3_Path3_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 3031,
			ChildIdList = {
				"World3_Path3_Branch1_Node2",
			},
			EventPool = 810004,
		},
		World3_Path3_Branch1_Node2 = {
			BranchRoot = "World3_Path3_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 3031,
			ChildIdList = {
				"World3_Path3_Branch1_Node3",
			},
			EventPool = 810004,
		},
		World3_Path3_Branch1_Node3 = {
			BranchRoot = "World3_Path3_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 3031,
			ChildIdList = {
				"World3_Path3_Branch1_Node4",
			},
			EventPool = 810004,
		},
		World3_Path3_Branch1_Node4 = {
			BranchRoot = "World3_Path3_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 3031,
			ChildIdList = {
				"World3_Path3_Branch1_Node5",
			},
			EventPool = 810004,
		},
		World3_Path3_Branch1_Node5 = {
			BranchRoot = "World3_Path3_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 3031,
			ChildIdList = {
				"World3_Path3_Branch1_Node6",
			},
			EventPool = 810004,
		},
		World3_Path3_Branch1_Node6 = {
			BranchRoot = "World3_Path3_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 3031,
			ChildIdList = {
				"World3_Path3_Branch1_Node7",
			},
			EventPool = 810004,
		},
		World3_Path3_Branch1_Node7 = {
			BranchRoot = "World3_Path3_Branch1_Node1",
			Seed = 3031,
			ChildIdList = {
				"World3_Path3_Branch1_Node8",
			},
			EventPool = 810016,
		},
		World3_Path3_Branch1_Node8 = {
			BranchRoot = "World3_Path3_Branch1_Node1",
			Seed = 3031,
			ChildIdList = {
				"World3_Path3_Branch1_Node9",
			},
			EventPool = 810021,
		},
		World3_Path3_Branch1_Node9 = {
			BranchRoot = "World3_Path3_Branch1_Node1",
			Seed = 3031,
			ChildIdList = {
				"World3_Path3_Branch1_Node10",
			},
			EventPool = 810025,
		},
		World3_Path3_Branch1_Node10 = {
			BranchRoot = "World3_Path3_Branch1_Node1",
			Seed = 3031,
			ChildIdList = {
				"World3_Path3_Branch1_Node11",
			},
			EventPool = 810021,
		},
		World3_Path3_Branch1_Node11 = {
			BranchRoot = "World3_Path3_Branch1_Node1",
			Seed = 3031,
			ChildIdList = {
				"World3_Path3_Branch1_Node12",
			},
			EventPool = 810021,
		},
		World3_Path3_Branch1_Node12 = {
			BranchRoot = "World3_Path3_Branch1_Node1",
			Seed = 3031,
			ChildIdList = {
				"World3_Path3_Branch1_Node13",
			},
			EventPool = 810016,
		},
		World3_Path3_Branch1_Node13 = {
			BranchRoot = "World3_Path3_Branch1_Node1",
			Seed = 3031,
			ChildIdList = {
				"World3_Path3_Branch1_Node14",
			},
			EventPool = 810014,
		},
		World3_Path3_Branch1_Node14 = {
			BranchRoot = "World3_Path3_Branch1_Node1",
			Seed = 3031,
			ChildIdList = {
				"World3_Path3_Branch1_Node15",
			},
			EventPool = 810015,
		},
		World3_Path3_Branch1_Node15 = {
			BranchRoot = "World3_Path3_Branch1_Node1",
			Seed = 3031,
			ChildIdList = {
				"World3_Path3_Branch1_Node16",
			},
			EventPool = 810016,
		},
		World3_Path3_Branch1_Node16 = {
			BranchRoot = "World3_Path3_Branch1_Node1",
			Seed = 3031,
			ChildIdList = {
				"World3_Path3_Branch1_Node17",
			},
			EventPool = 810020,
		},
		World3_Path3_Branch1_Node17 = {
			BranchRoot = "World3_Path3_Branch1_Node1",
			Seed = 3031,
			ChildIdList = {
				"World3_Path3_Branch1_Node18",
			},
			EventPool = 810014,
		},
		World3_Path3_Branch1_Node18 = {
			BranchRoot = "World3_Path3_Branch1_Node1",
			Seed = 3031,
			ChildIdList = {
				"World3_Path3_Branch1_Node19",
			},
			EventPool = 810014,
		},
		World3_Path3_Branch1_Node19 = {
			BranchRoot = "World3_Path3_Branch1_Node1",
			Seed = 3031,
			ChildIdList = {
				"World3_Path3_Branch1_Node20",
			},
			EventPool = 810025,
		},
		World3_Path3_Branch1_Node20 = {
			BranchRoot = "World3_Path3_Branch1_Node1",
			Seed = 3031,
			ChildIdList = {
				"World3_Path4_Branch1_Node1",
				"World3_Path4_Branch2_Node1",
			},
			EventPool = 810021,
		},
		World3_Path4_Branch1_Node1 = {
			BranchRoot = "World3_Path4_Branch1_Node1",
			Seed = 3041,
			ChildIdList = {
				"World3_Path4_Branch1_Node2",
			},
			EventPool = 810020,
		},
		World3_Path4_Branch1_Node2 = {
			BranchRoot = "World3_Path4_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 3041,
			ChildIdList = {
				"World3_Path4_Branch1_Node3",
			},
			EventPool = 810005,
		},
		World3_Path4_Branch1_Node3 = {
			BranchRoot = "World3_Path4_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 3041,
			ChildIdList = {
				"World3_Path4_Branch1_Node4",
			},
			EventPool = 810005,
		},
		World3_Path4_Branch1_Node4 = {
			BranchRoot = "World3_Path4_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 3041,
			ChildIdList = {
				"World3_Path4_Branch1_Node5",
			},
			EventPool = 810005,
		},
		World3_Path4_Branch1_Node5 = {
			BranchRoot = "World3_Path4_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 3041,
			ChildIdList = {
				"World3_Path4_Branch1_Node6",
			},
			EventPool = 810005,
		},
		World3_Path4_Branch1_Node6 = {
			BranchRoot = "World3_Path4_Branch1_Node1",
			Seed = 3041,
			ChildIdList = {
				"World3_Path4_Branch1_Node7",
			},
			EventPool = 810015,
		},
		World3_Path4_Branch1_Node7 = {
			BranchRoot = "World3_Path4_Branch1_Node1",
			Seed = 3041,
			ChildIdList = {
				"World3_Path4_Branch1_Node8",
			},
			EventPool = 810026,
		},
		World3_Path4_Branch1_Node8 = {
			BranchRoot = "World3_Path4_Branch1_Node1",
			Seed = 3041,
			ChildIdList = {
				"World3_Path4_Branch1_Node9",
			},
			EventPool = 810021,
		},
		World3_Path4_Branch1_Node9 = {
			BranchRoot = "World3_Path4_Branch1_Node1",
			Seed = 3041,
			ChildIdList = {
				"World3_Path4_Branch1_Node10",
			},
			EventPool = 810024,
		},
		World3_Path4_Branch1_Node10 = {
			BranchRoot = "World3_Path4_Branch1_Node1",
			Seed = 3041,
			ChildIdList = {
				"World3_Path4_Branch1_Node11",
			},
			EventPool = 810022,
		},
		World3_Path4_Branch1_Node11 = {
			BranchRoot = "World3_Path4_Branch1_Node1",
			Seed = 3041,
			ChildIdList = {
				"World3_Path4_Branch1_Node12",
			},
			EventPool = 810016,
		},
		World3_Path4_Branch1_Node12 = {
			BranchRoot = "World3_Path4_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 3041,
			ChildIdList = {
				"World3_Path4_Branch1_Node13",
			},
			EventPool = 810004,
		},
		World3_Path4_Branch1_Node13 = {
			BranchRoot = "World3_Path4_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 3041,
			ChildIdList = {
				"World3_Path4_Branch1_Node14",
			},
			EventPool = 810004,
		},
		World3_Path4_Branch1_Node14 = {
			BranchRoot = "World3_Path4_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 3041,
			ChildIdList = {
				"World3_Path4_Branch1_Node15",
			},
			EventPool = 810004,
		},
		World3_Path4_Branch1_Node15 = {
			BranchRoot = "World3_Path4_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 3041,
			ChildIdList = {
				"World3_Path4_Branch1_Node16",
			},
			EventPool = 810004,
		},
		World3_Path4_Branch1_Node16 = {
			BranchRoot = "World3_Path4_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 3041,
			ChildIdList = {
				"World3_Path4_Branch1_Node17",
			},
			EventPool = 810004,
		},
		World3_Path4_Branch1_Node17 = {
			BranchRoot = "World3_Path4_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 3041,
			ChildIdList = {
				"World3_Path4_Branch1_Node18",
			},
			EventPool = 810004,
		},
		World3_Path4_Branch1_Node18 = {
			BranchRoot = "World3_Path4_Branch1_Node1",
			Seed = 3041,
			ChildIdList = {
				"World3_Path4_Branch1_Node19",
			},
			EventPool = 810014,
		},
		World3_Path4_Branch1_Node19 = {
			BranchRoot = "World3_Path4_Branch1_Node1",
			Seed = 3041,
			ChildIdList = {
				"World3_Path4_Branch1_Node20",
			},
			EventPool = 810024,
		},
		World3_Path4_Branch1_Node20 = {
			BranchRoot = "World3_Path4_Branch1_Node1",
			Seed = 3041,
			ChildIdList = {
				"World3_Path5_Branch1_Node1",
				"World3_Path5_Branch2_Node1",
			},
			EventPool = 810016,
		},
		World3_Path5_Branch1_Node1 = {
			BranchRoot = "World3_Path5_Branch1_Node1",
			Seed = 3051,
			ChildIdList = {
				"World3_Path5_Branch1_Node2",
			},
			EventPool = 810016,
		},
		World3_Path5_Branch1_Node2 = {
			BranchRoot = "World3_Path5_Branch1_Node1",
			Seed = 3051,
			ChildIdList = {
				"World3_Path5_Branch1_Node3",
			},
			EventPool = 810014,
		},
		World3_Path5_Branch1_Node3 = {
			BranchRoot = "World3_Path5_Branch1_Node1",
			StepScore = 50,
			Seed = 3051,
			ChildIdList = {
				"World3_Path5_Branch1_Node4",
			},
			EventPool = 810006,
		},
		World3_Path5_Branch1_Node4 = {
			BranchRoot = "World3_Path5_Branch1_Node1",
			Seed = 3051,
			ChildIdList = {
				"World3_Path5_Branch1_Node5",
			},
			EventPool = 810016,
		},
		World3_Path5_Branch1_Node5 = {
			BranchRoot = "World3_Path5_Branch1_Node1",
			Seed = 3051,
			ChildIdList = {
				"World3_Path5_Branch1_Node6",
			},
			EventPool = 810014,
		},
		World3_Path5_Branch1_Node6 = {
			BranchRoot = "World3_Path5_Branch1_Node1",
			Seed = 3051,
			ChildIdList = {
				"World3_Path5_Branch1_Node7",
			},
			EventPool = 810014,
		},
		World3_Path5_Branch1_Node7 = {
			BranchRoot = "World3_Path5_Branch1_Node1",
			Seed = 3051,
			ChildIdList = {
				"World3_Path5_Branch1_Node8",
			},
			EventPool = 810014,
		},
		World3_Path5_Branch1_Node8 = {
			BranchRoot = "World3_Path5_Branch1_Node1",
			Seed = 3051,
			ChildIdList = {
				"World3_Path5_Branch1_Node9",
			},
			EventPool = 810022,
		},
		World3_Path5_Branch1_Node9 = {
			BranchRoot = "World3_Path5_Branch1_Node1",
			Seed = 3051,
			ChildIdList = {
				"World3_Path5_Branch1_Node10",
			},
			EventPool = 810025,
		},
		World3_Path5_Branch1_Node10 = {
			BranchRoot = "World3_Path5_Branch1_Node1",
			Seed = 3051,
			ChildIdList = {
				"World3_Path5_Branch1_Node11",
			},
			EventPool = 810022,
		},
		World3_Path5_Branch1_Node11 = {
			BranchRoot = "World3_Path5_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 3051,
			ChildIdList = {
				"World3_Path5_Branch1_Node12",
			},
			EventPool = 810005,
		},
		World3_Path5_Branch1_Node12 = {
			BranchRoot = "World3_Path5_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 3051,
			ChildIdList = {
				"World3_Path5_Branch1_Node13",
			},
			EventPool = 810005,
		},
		World3_Path5_Branch1_Node13 = {
			BranchRoot = "World3_Path5_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 3051,
			ChildIdList = {
				"World3_Path5_Branch1_Node14",
			},
			EventPool = 810005,
		},
		World3_Path5_Branch1_Node14 = {
			BranchRoot = "World3_Path5_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 3051,
			ChildIdList = {
				"World3_Path5_Branch1_Node15",
			},
			EventPool = 810005,
		},
		World3_Path5_Branch1_Node15 = {
			BranchRoot = "World3_Path5_Branch1_Node1",
			Seed = 3051,
			ChildIdList = {
				"World3_Path5_Branch1_Node16",
			},
			EventPool = 810016,
		},
		World3_Path5_Branch1_Node16 = {
			BranchRoot = "World3_Path5_Branch1_Node1",
			Seed = 3051,
			ChildIdList = {
				"World3_Path5_Branch1_Node17",
			},
			EventPool = 810016,
		},
		World3_Path5_Branch1_Node17 = {
			BranchRoot = "World3_Path5_Branch1_Node1",
			Seed = 3051,
			ChildIdList = {
				"World3_Path5_Branch1_Node18",
			},
			EventPool = 810016,
		},
		World3_Path5_Branch1_Node18 = {
			BranchRoot = "World3_Path5_Branch1_Node1",
			Seed = 3051,
			ChildIdList = {
				"World3_Path5_Branch1_Node19",
			},
			EventPool = 810026,
		},
		World3_Path5_Branch1_Node19 = {
			BranchRoot = "World3_Path5_Branch1_Node1",
			Seed = 3051,
			ChildIdList = {
				"World3_Path5_Branch1_Node20",
			},
			EventPool = 810025,
		},
		World3_Path5_Branch1_Node20 = {
			BranchRoot = "World3_Path5_Branch1_Node1",
			Seed = 3051,
			ChildIdList = {
				"World3_Path6_Branch1_Node1",
				"World3_Path6_Branch2_Node1",
			},
			EventPool = 810016,
		},
		World3_Path6_Branch1_Node1 = {
			BranchRoot = "World3_Path6_Branch1_Node1",
			Seed = 3061,
			ChildIdList = {
				"World3_Path6_Branch1_Node2",
			},
			EventPool = 810021,
		},
		World3_Path6_Branch1_Node2 = {
			BranchRoot = "World3_Path6_Branch1_Node1",
			Seed = 3061,
			ChildIdList = {
				"World3_Path6_Branch1_Node3",
			},
			EventPool = 810020,
		},
		World3_Path6_Branch1_Node3 = {
			BranchRoot = "World3_Path6_Branch1_Node1",
			Seed = 3061,
			ChildIdList = {
				"World3_Path6_Branch1_Node4",
			},
			EventPool = 810021,
		},
		World3_Path6_Branch1_Node4 = {
			BranchRoot = "World3_Path6_Branch1_Node1",
			Seed = 3061,
			ChildIdList = {
				"World3_Path6_Branch1_Node5",
			},
			EventPool = 810016,
		},
		World3_Path6_Branch1_Node5 = {
			BranchRoot = "World3_Path6_Branch1_Node1",
			Seed = 3061,
			ChildIdList = {
				"World3_Path6_Branch1_Node6",
			},
			EventPool = 810016,
		},
		World3_Path6_Branch1_Node6 = {
			BranchRoot = "World3_Path6_Branch1_Node1",
			Seed = 3061,
			ChildIdList = {
				"World3_Path6_Branch1_Node7",
			},
			EventPool = 810014,
		},
		World3_Path6_Branch1_Node7 = {
			BranchRoot = "World3_Path6_Branch1_Node1",
			Seed = 3061,
			ChildIdList = {
				"World3_Path6_Branch1_Node8",
			},
			EventPool = 810026,
		},
		World3_Path6_Branch1_Node8 = {
			BranchRoot = "World3_Path6_Branch1_Node1",
			Seed = 3061,
			ChildIdList = {
				"World3_Path6_Branch1_Node9",
			},
			EventPool = 810021,
		},
		World3_Path6_Branch1_Node9 = {
			BranchRoot = "World3_Path6_Branch1_Node1",
			Seed = 3061,
			ChildIdList = {
				"World3_Path6_Branch1_Node10",
			},
			EventPool = 810024,
		},
		World3_Path6_Branch1_Node10 = {
			BranchRoot = "World3_Path6_Branch1_Node1",
			Seed = 3061,
			ChildIdList = {
				"World3_Path6_Branch1_Node11",
			},
			EventPool = 810021,
		},
		World3_Path6_Branch1_Node11 = {
			BranchRoot = "World3_Path6_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 3061,
			ChildIdList = {
				"World3_Path6_Branch1_Node12",
			},
			EventPool = 810004,
		},
		World3_Path6_Branch1_Node12 = {
			BranchRoot = "World3_Path6_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 3061,
			ChildIdList = {
				"World3_Path6_Branch1_Node13",
			},
			EventPool = 810004,
		},
		World3_Path6_Branch1_Node13 = {
			BranchRoot = "World3_Path6_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 3061,
			ChildIdList = {
				"World3_Path6_Branch1_Node14",
			},
			EventPool = 810004,
		},
		World3_Path6_Branch1_Node14 = {
			BranchRoot = "World3_Path6_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 3061,
			ChildIdList = {
				"World3_Path6_Branch1_Node15",
			},
			EventPool = 810004,
		},
		World3_Path6_Branch1_Node15 = {
			BranchRoot = "World3_Path6_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 3061,
			ChildIdList = {
				"World3_Path6_Branch1_Node16",
			},
			EventPool = 810004,
		},
		World3_Path6_Branch1_Node16 = {
			BranchRoot = "World3_Path6_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 3061,
			ChildIdList = {
				"World3_Path6_Branch1_Node17",
			},
			EventPool = 810004,
		},
		World3_Path6_Branch1_Node17 = {
			BranchRoot = "World3_Path6_Branch1_Node1",
			Seed = 3061,
			ChildIdList = {
				"World3_Path6_Branch1_Node18",
			},
			EventPool = 810016,
		},
		World3_Path6_Branch1_Node18 = {
			BranchRoot = "World3_Path6_Branch1_Node1",
			Seed = 3061,
			ChildIdList = {
				"World3_Path6_Branch1_Node19",
			},
			EventPool = 810015,
		},
		World3_Path6_Branch1_Node19 = {
			BranchRoot = "World3_Path6_Branch1_Node1",
			Seed = 3061,
			ChildIdList = {
				"World3_Path6_Branch1_Node20",
			},
			EventPool = 810026,
		},
		World3_Path6_Branch1_Node20 = {
			BranchRoot = "World3_Path6_Branch1_Node1",
			Seed = 3061,
			EventPool = 810023,
		},
		World3_Path2_Branch2_Node1 = {
			BranchRoot = "World3_Path2_Branch2_Node1",
			Seed = 3022,
			ChildIdList = {
				"World3_Path2_Branch2_Node2",
			},
			EventPool = 810016,
		},
		World3_Path2_Branch2_Node2 = {
			BranchRoot = "World3_Path2_Branch2_Node1",
			Seed = 3022,
			ChildIdList = {
				"World3_Path2_Branch2_Node3",
			},
			EventPool = 810016,
		},
		World3_Path2_Branch2_Node3 = {
			BranchRoot = "World3_Path2_Branch2_Node1",
			Seed = 3022,
			ChildIdList = {
				"World3_Path2_Branch2_Node4",
			},
			EventPool = 810026,
		},
		World3_Path2_Branch2_Node4 = {
			BranchRoot = "World3_Path2_Branch2_Node1",
			Seed = 3022,
			ChildIdList = {
				"World3_Path2_Branch2_Node5",
			},
			EventPool = 810016,
		},
		World3_Path2_Branch2_Node5 = {
			BranchRoot = "World3_Path2_Branch2_Node1",
			StepScore = 50,
			Seed = 3022,
			ChildIdList = {
				"World3_Path2_Branch2_Node6",
			},
			EventPool = 810006,
		},
		World3_Path2_Branch2_Node6 = {
			BranchRoot = "World3_Path2_Branch2_Node1",
			Seed = 3022,
			ChildIdList = {
				"World3_Path2_Branch2_Node7",
			},
			EventPool = 810022,
		},
		World3_Path2_Branch2_Node7 = {
			BranchRoot = "World3_Path2_Branch2_Node1",
			Seed = 3022,
			ChildIdList = {
				"World3_Path2_Branch2_Node8",
			},
			EventPool = 810020,
		},
		World3_Path2_Branch2_Node8 = {
			BranchRoot = "World3_Path2_Branch2_Node1",
			Seed = 3022,
			ChildIdList = {
				"World3_Path2_Branch2_Node9",
			},
			EventPool = 810026,
		},
		World3_Path2_Branch2_Node9 = {
			BranchRoot = "World3_Path2_Branch2_Node1",
			Seed = 3022,
			ChildIdList = {
				"World3_Path2_Branch2_Node10",
			},
			EventPool = 810025,
		},
		World3_Path2_Branch2_Node10 = {
			BranchRoot = "World3_Path2_Branch2_Node1",
			Seed = 3022,
			ChildIdList = {
				"World3_Path2_Branch2_Node11",
			},
			EventPool = 810026,
		},
		World3_Path2_Branch2_Node11 = {
			BranchRoot = "World3_Path2_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 3022,
			ChildIdList = {
				"World3_Path2_Branch2_Node12",
			},
			EventPool = 810005,
		},
		World3_Path2_Branch2_Node12 = {
			BranchRoot = "World3_Path2_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 3022,
			ChildIdList = {
				"World3_Path2_Branch2_Node13",
			},
			EventPool = 810005,
		},
		World3_Path2_Branch2_Node13 = {
			BranchRoot = "World3_Path2_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 3022,
			ChildIdList = {
				"World3_Path2_Branch2_Node14",
			},
			EventPool = 810005,
		},
		World3_Path2_Branch2_Node14 = {
			BranchRoot = "World3_Path2_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 3022,
			ChildIdList = {
				"World3_Path2_Branch2_Node15",
			},
			EventPool = 810005,
		},
		World3_Path2_Branch2_Node15 = {
			BranchRoot = "World3_Path2_Branch2_Node1",
			Seed = 3022,
			ChildIdList = {
				"World3_Path2_Branch2_Node16",
			},
			EventPool = 810026,
		},
		World3_Path2_Branch2_Node16 = {
			BranchRoot = "World3_Path2_Branch2_Node1",
			Seed = 3022,
			ChildIdList = {
				"World3_Path2_Branch2_Node17",
			},
			EventPool = 810022,
		},
		World3_Path2_Branch2_Node17 = {
			BranchRoot = "World3_Path2_Branch2_Node1",
			Seed = 3022,
			ChildIdList = {
				"World3_Path2_Branch2_Node18",
			},
			EventPool = 810026,
		},
		World3_Path2_Branch2_Node18 = {
			BranchRoot = "World3_Path2_Branch2_Node1",
			Seed = 3022,
			ChildIdList = {
				"World3_Path2_Branch2_Node19",
			},
			EventPool = 810014,
		},
		World3_Path2_Branch2_Node19 = {
			BranchRoot = "World3_Path2_Branch2_Node1",
			Seed = 3022,
			ChildIdList = {
				"World3_Path2_Branch2_Node20",
			},
			EventPool = 810024,
		},
		World3_Path2_Branch2_Node20 = {
			BranchRoot = "World3_Path2_Branch2_Node1",
			Seed = 3022,
			ChildIdList = {
				"World3_Path3_Branch1_Node1",
				"World3_Path3_Branch2_Node1",
			},
			EventPool = 810016,
		},
		World3_Path3_Branch2_Node1 = {
			BranchRoot = "World3_Path3_Branch2_Node1",
			Seed = 3032,
			ChildIdList = {
				"World3_Path3_Branch2_Node2",
			},
			EventPool = 810022,
		},
		World3_Path3_Branch2_Node2 = {
			BranchRoot = "World3_Path3_Branch2_Node1",
			Seed = 3032,
			ChildIdList = {
				"World3_Path3_Branch2_Node3",
			},
			EventPool = 810016,
		},
		World3_Path3_Branch2_Node3 = {
			BranchRoot = "World3_Path3_Branch2_Node1",
			Seed = 3032,
			ChildIdList = {
				"World3_Path3_Branch2_Node4",
			},
			EventPool = 810015,
		},
		World3_Path3_Branch2_Node4 = {
			BranchRoot = "World3_Path3_Branch2_Node1",
			StepScore = 50,
			Seed = 3032,
			ChildIdList = {
				"World3_Path3_Branch2_Node5",
			},
			EventPool = 810006,
		},
		World3_Path3_Branch2_Node5 = {
			BranchRoot = "World3_Path3_Branch2_Node1",
			Seed = 3032,
			ChildIdList = {
				"World3_Path3_Branch2_Node6",
			},
			EventPool = 810014,
		},
		World3_Path3_Branch2_Node6 = {
			BranchRoot = "World3_Path3_Branch2_Node1",
			Seed = 3032,
			ChildIdList = {
				"World3_Path3_Branch2_Node7",
			},
			EventPool = 810021,
		},
		World3_Path3_Branch2_Node7 = {
			BranchRoot = "World3_Path3_Branch2_Node1",
			Seed = 3032,
			ChildIdList = {
				"World3_Path3_Branch2_Node8",
			},
			EventPool = 810026,
		},
		World3_Path3_Branch2_Node8 = {
			BranchRoot = "World3_Path3_Branch2_Node1",
			Seed = 3032,
			ChildIdList = {
				"World3_Path3_Branch2_Node9",
			},
			EventPool = 810022,
		},
		World3_Path3_Branch2_Node9 = {
			BranchRoot = "World3_Path3_Branch2_Node1",
			Seed = 3032,
			ChildIdList = {
				"World3_Path3_Branch2_Node10",
			},
			EventPool = 810025,
		},
		World3_Path3_Branch2_Node10 = {
			BranchRoot = "World3_Path3_Branch2_Node1",
			Seed = 3032,
			ChildIdList = {
				"World3_Path3_Branch2_Node11",
			},
			EventPool = 810016,
		},
		World3_Path3_Branch2_Node11 = {
			BranchRoot = "World3_Path3_Branch2_Node1",
			Seed = 3032,
			ChildIdList = {
				"World3_Path3_Branch2_Node12",
			},
			EventPool = 810026,
		},
		World3_Path3_Branch2_Node12 = {
			BranchRoot = "World3_Path3_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 3032,
			ChildIdList = {
				"World3_Path3_Branch2_Node13",
			},
			EventPool = 810004,
		},
		World3_Path3_Branch2_Node13 = {
			BranchRoot = "World3_Path3_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 3032,
			ChildIdList = {
				"World3_Path3_Branch2_Node14",
			},
			EventPool = 810004,
		},
		World3_Path3_Branch2_Node14 = {
			BranchRoot = "World3_Path3_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 3032,
			ChildIdList = {
				"World3_Path3_Branch2_Node15",
			},
			EventPool = 810004,
		},
		World3_Path3_Branch2_Node15 = {
			BranchRoot = "World3_Path3_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 3032,
			ChildIdList = {
				"World3_Path3_Branch2_Node16",
			},
			EventPool = 810004,
		},
		World3_Path3_Branch2_Node16 = {
			BranchRoot = "World3_Path3_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 3032,
			ChildIdList = {
				"World3_Path3_Branch2_Node17",
			},
			EventPool = 810004,
		},
		World3_Path3_Branch2_Node17 = {
			BranchRoot = "World3_Path3_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 3032,
			ChildIdList = {
				"World3_Path3_Branch2_Node18",
			},
			EventPool = 810004,
		},
		World3_Path3_Branch2_Node18 = {
			BranchRoot = "World3_Path3_Branch2_Node1",
			Seed = 3032,
			ChildIdList = {
				"World3_Path3_Branch2_Node19",
			},
			EventPool = 810014,
		},
		World3_Path3_Branch2_Node19 = {
			BranchRoot = "World3_Path3_Branch2_Node1",
			Seed = 3032,
			ChildIdList = {
				"World3_Path3_Branch2_Node20",
			},
			EventPool = 810024,
		},
		World3_Path3_Branch2_Node20 = {
			BranchRoot = "World3_Path3_Branch2_Node1",
			Seed = 3032,
			ChildIdList = {
				"World3_Path4_Branch1_Node1",
				"World3_Path4_Branch2_Node1",
			},
			EventPool = 810021,
		},
		World3_Path4_Branch2_Node1 = {
			BranchRoot = "World3_Path4_Branch2_Node1",
			Seed = 3042,
			ChildIdList = {
				"World3_Path4_Branch2_Node2",
			},
			EventPool = 810015,
		},
		World3_Path4_Branch2_Node2 = {
			BranchRoot = "World3_Path4_Branch2_Node1",
			Seed = 3042,
			ChildIdList = {
				"World3_Path4_Branch2_Node3",
			},
			EventPool = 810026,
		},
		World3_Path4_Branch2_Node3 = {
			BranchRoot = "World3_Path4_Branch2_Node1",
			Seed = 3042,
			ChildIdList = {
				"World3_Path4_Branch2_Node4",
			},
			EventPool = 810021,
		},
		World3_Path4_Branch2_Node4 = {
			BranchRoot = "World3_Path4_Branch2_Node1",
			Seed = 3042,
			ChildIdList = {
				"World3_Path4_Branch2_Node5",
			},
			EventPool = 810020,
		},
		World3_Path4_Branch2_Node5 = {
			BranchRoot = "World3_Path4_Branch2_Node1",
			Seed = 3042,
			ChildIdList = {
				"World3_Path4_Branch2_Node6",
			},
			EventPool = 810026,
		},
		World3_Path4_Branch2_Node6 = {
			BranchRoot = "World3_Path4_Branch2_Node1",
			Seed = 3042,
			ChildIdList = {
				"World3_Path4_Branch2_Node7",
			},
			EventPool = 810016,
		},
		World3_Path4_Branch2_Node7 = {
			BranchRoot = "World3_Path4_Branch2_Node1",
			Seed = 3042,
			ChildIdList = {
				"World3_Path4_Branch2_Node8",
			},
			EventPool = 810026,
		},
		World3_Path4_Branch2_Node8 = {
			BranchRoot = "World3_Path4_Branch2_Node1",
			Seed = 3042,
			ChildIdList = {
				"World3_Path4_Branch2_Node9",
			},
			EventPool = 810022,
		},
		World3_Path4_Branch2_Node9 = {
			BranchRoot = "World3_Path4_Branch2_Node1",
			Seed = 3042,
			ChildIdList = {
				"World3_Path4_Branch2_Node10",
			},
			EventPool = 810024,
		},
		World3_Path4_Branch2_Node10 = {
			BranchRoot = "World3_Path4_Branch2_Node1",
			Seed = 3042,
			ChildIdList = {
				"World3_Path4_Branch2_Node11",
			},
			EventPool = 810020,
		},
		World3_Path4_Branch2_Node11 = {
			BranchRoot = "World3_Path4_Branch2_Node1",
			Seed = 3042,
			ChildIdList = {
				"World3_Path4_Branch2_Node12",
			},
			EventPool = 810026,
		},
		World3_Path4_Branch2_Node12 = {
			BranchRoot = "World3_Path4_Branch2_Node1",
			Seed = 3042,
			ChildIdList = {
				"World3_Path4_Branch2_Node13",
			},
			EventPool = 810014,
		},
		World3_Path4_Branch2_Node13 = {
			BranchRoot = "World3_Path4_Branch2_Node1",
			Seed = 3042,
			ChildIdList = {
				"World3_Path4_Branch2_Node14",
			},
			EventPool = 810022,
		},
		World3_Path4_Branch2_Node14 = {
			BranchRoot = "World3_Path4_Branch2_Node1",
			Seed = 3042,
			ChildIdList = {
				"World3_Path4_Branch2_Node15",
			},
			EventPool = 810016,
		},
		World3_Path4_Branch2_Node15 = {
			BranchRoot = "World3_Path4_Branch2_Node1",
			Seed = 3042,
			ChildIdList = {
				"World3_Path4_Branch2_Node16",
			},
			EventPool = 810015,
		},
		World3_Path4_Branch2_Node16 = {
			BranchRoot = "World3_Path4_Branch2_Node1",
			Seed = 3042,
			ChildIdList = {
				"World3_Path4_Branch2_Node17",
			},
			EventPool = 810020,
		},
		World3_Path4_Branch2_Node17 = {
			BranchRoot = "World3_Path4_Branch2_Node1",
			Seed = 3042,
			ChildIdList = {
				"World3_Path4_Branch2_Node18",
			},
			EventPool = 810014,
		},
		World3_Path4_Branch2_Node18 = {
			BranchRoot = "World3_Path4_Branch2_Node1",
			Seed = 3042,
			ChildIdList = {
				"World3_Path4_Branch2_Node19",
			},
			EventPool = 810026,
		},
		World3_Path4_Branch2_Node19 = {
			BranchRoot = "World3_Path4_Branch2_Node1",
			Seed = 3042,
			ChildIdList = {
				"World3_Path4_Branch2_Node20",
			},
			EventPool = 810024,
		},
		World3_Path4_Branch2_Node20 = {
			BranchRoot = "World3_Path4_Branch2_Node1",
			Seed = 3042,
			ChildIdList = {
				"World3_Path5_Branch1_Node1",
				"World3_Path5_Branch2_Node1",
			},
			EventPool = 810026,
		},
		World3_Path5_Branch2_Node1 = {
			BranchRoot = "World3_Path5_Branch2_Node1",
			Seed = 3052,
			ChildIdList = {
				"World3_Path5_Branch2_Node2",
			},
			EventPool = 810022,
		},
		World3_Path5_Branch2_Node2 = {
			BranchRoot = "World3_Path5_Branch2_Node1",
			Seed = 3052,
			ChildIdList = {
				"World3_Path5_Branch2_Node3",
			},
			EventPool = 810022,
		},
		World3_Path5_Branch2_Node3 = {
			BranchRoot = "World3_Path5_Branch2_Node1",
			Seed = 3052,
			ChildIdList = {
				"World3_Path5_Branch2_Node4",
			},
			EventPool = 810016,
		},
		World3_Path5_Branch2_Node4 = {
			BranchRoot = "World3_Path5_Branch2_Node1",
			StepScore = 50,
			Seed = 3052,
			ChildIdList = {
				"World3_Path5_Branch2_Node5",
			},
			EventPool = 810006,
		},
		World3_Path5_Branch2_Node5 = {
			BranchRoot = "World3_Path5_Branch2_Node1",
			Seed = 3052,
			ChildIdList = {
				"World3_Path5_Branch2_Node6",
			},
			EventPool = 810021,
		},
		World3_Path5_Branch2_Node6 = {
			BranchRoot = "World3_Path5_Branch2_Node1",
			Seed = 3052,
			ChildIdList = {
				"World3_Path5_Branch2_Node7",
			},
			EventPool = 810020,
		},
		World3_Path5_Branch2_Node7 = {
			BranchRoot = "World3_Path5_Branch2_Node1",
			Seed = 3052,
			ChildIdList = {
				"World3_Path5_Branch2_Node8",
			},
			EventPool = 810021,
		},
		World3_Path5_Branch2_Node8 = {
			BranchRoot = "World3_Path5_Branch2_Node1",
			Seed = 3052,
			ChildIdList = {
				"World3_Path5_Branch2_Node9",
			},
			EventPool = 810020,
		},
		World3_Path5_Branch2_Node9 = {
			BranchRoot = "World3_Path5_Branch2_Node1",
			Seed = 3052,
			ChildIdList = {
				"World3_Path5_Branch2_Node10",
			},
			EventPool = 810025,
		},
		World3_Path5_Branch2_Node10 = {
			BranchRoot = "World3_Path5_Branch2_Node1",
			Seed = 3052,
			ChildIdList = {
				"World3_Path5_Branch2_Node11",
			},
			EventPool = 810016,
		},
		World3_Path5_Branch2_Node11 = {
			BranchRoot = "World3_Path5_Branch2_Node1",
			Seed = 3052,
			ChildIdList = {
				"World3_Path5_Branch2_Node12",
			},
			EventPool = 810020,
		},
		World3_Path5_Branch2_Node12 = {
			BranchRoot = "World3_Path5_Branch2_Node1",
			Seed = 3052,
			ChildIdList = {
				"World3_Path5_Branch2_Node13",
			},
			EventPool = 810015,
		},
		World3_Path5_Branch2_Node13 = {
			BranchRoot = "World3_Path5_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 3052,
			ChildIdList = {
				"World3_Path5_Branch2_Node14",
			},
			EventPool = 810005,
		},
		World3_Path5_Branch2_Node14 = {
			BranchRoot = "World3_Path5_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 3052,
			ChildIdList = {
				"World3_Path5_Branch2_Node15",
			},
			EventPool = 810005,
		},
		World3_Path5_Branch2_Node15 = {
			BranchRoot = "World3_Path5_Branch2_Node1",
			StepScore = 50,
			Seed = 3052,
			ChildIdList = {
				"World3_Path5_Branch2_Node16",
			},
			EventPool = 810006,
		},
		World3_Path5_Branch2_Node16 = {
			BranchRoot = "World3_Path5_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 3052,
			ChildIdList = {
				"World3_Path5_Branch2_Node17",
			},
			EventPool = 810005,
		},
		World3_Path5_Branch2_Node17 = {
			BranchRoot = "World3_Path5_Branch2_Node1",
			Seed = 3052,
			ChildIdList = {
				"World3_Path5_Branch2_Node18",
			},
			EventPool = 810015,
		},
		World3_Path5_Branch2_Node18 = {
			BranchRoot = "World3_Path5_Branch2_Node1",
			Seed = 3052,
			ChildIdList = {
				"World3_Path5_Branch2_Node19",
			},
			EventPool = 810022,
		},
		World3_Path5_Branch2_Node19 = {
			BranchRoot = "World3_Path5_Branch2_Node1",
			Seed = 3052,
			ChildIdList = {
				"World3_Path5_Branch2_Node20",
			},
			EventPool = 810024,
		},
		World3_Path5_Branch2_Node20 = {
			BranchRoot = "World3_Path5_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 3052,
			ChildIdList = {
				"World3_Path6_Branch1_Node1",
				"World3_Path6_Branch2_Node1",
			},
			EventPool = 810004,
		},
		World3_Path6_Branch2_Node1 = {
			BranchRoot = "World3_Path6_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 3062,
			ChildIdList = {
				"World3_Path6_Branch2_Node2",
			},
			EventPool = 810004,
		},
		World3_Path6_Branch2_Node2 = {
			BranchRoot = "World3_Path6_Branch2_Node1",
			StepScore = 50,
			Seed = 3062,
			ChildIdList = {
				"World3_Path6_Branch2_Node3",
			},
			EventPool = 810006,
		},
		World3_Path6_Branch2_Node3 = {
			BranchRoot = "World3_Path6_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 3062,
			ChildIdList = {
				"World3_Path6_Branch2_Node4",
			},
			EventPool = 810004,
		},
		World3_Path6_Branch2_Node4 = {
			BranchRoot = "World3_Path6_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 3062,
			ChildIdList = {
				"World3_Path6_Branch2_Node5",
			},
			EventPool = 810004,
		},
		World3_Path6_Branch2_Node5 = {
			BranchRoot = "World3_Path6_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 3062,
			ChildIdList = {
				"World3_Path6_Branch2_Node6",
			},
			EventPool = 810004,
		},
		World3_Path6_Branch2_Node6 = {
			BranchRoot = "World3_Path6_Branch2_Node1",
			Seed = 3062,
			ChildIdList = {
				"World3_Path6_Branch2_Node7",
			},
			EventPool = 810015,
		},
		World3_Path6_Branch2_Node7 = {
			BranchRoot = "World3_Path6_Branch2_Node1",
			Seed = 3062,
			ChildIdList = {
				"World3_Path6_Branch2_Node8",
			},
			EventPool = 810022,
		},
		World3_Path6_Branch2_Node8 = {
			BranchRoot = "World3_Path6_Branch2_Node1",
			Seed = 3062,
			ChildIdList = {
				"World3_Path6_Branch2_Node9",
			},
			EventPool = 810014,
		},
		World3_Path6_Branch2_Node9 = {
			BranchRoot = "World3_Path6_Branch2_Node1",
			Seed = 3062,
			ChildIdList = {
				"World3_Path6_Branch2_Node10",
			},
			EventPool = 810025,
		},
		World3_Path6_Branch2_Node10 = {
			BranchRoot = "World3_Path6_Branch2_Node1",
			Seed = 3062,
			ChildIdList = {
				"World3_Path6_Branch2_Node11",
			},
			EventPool = 810016,
		},
		World3_Path6_Branch2_Node11 = {
			BranchRoot = "World3_Path6_Branch2_Node1",
			Seed = 3062,
			ChildIdList = {
				"World3_Path6_Branch2_Node12",
			},
			EventPool = 810015,
		},
		World3_Path6_Branch2_Node12 = {
			BranchRoot = "World3_Path6_Branch2_Node1",
			Seed = 3062,
			ChildIdList = {
				"World3_Path6_Branch2_Node13",
			},
			EventPool = 810015,
		},
		World3_Path6_Branch2_Node13 = {
			BranchRoot = "World3_Path6_Branch2_Node1",
			Seed = 3062,
			ChildIdList = {
				"World3_Path6_Branch2_Node14",
			},
			EventPool = 810014,
		},
		World3_Path6_Branch2_Node14 = {
			BranchRoot = "World3_Path6_Branch2_Node1",
			Seed = 3062,
			ChildIdList = {
				"World3_Path6_Branch2_Node15",
			},
			EventPool = 810016,
		},
		World3_Path6_Branch2_Node15 = {
			BranchRoot = "World3_Path6_Branch2_Node1",
			Seed = 3062,
			ChildIdList = {
				"World3_Path6_Branch2_Node16",
			},
			EventPool = 810020,
		},
		World3_Path6_Branch2_Node16 = {
			BranchRoot = "World3_Path6_Branch2_Node1",
			Seed = 3062,
			ChildIdList = {
				"World3_Path6_Branch2_Node17",
			},
			EventPool = 810016,
		},
		World3_Path6_Branch2_Node17 = {
			BranchRoot = "World3_Path6_Branch2_Node1",
			Seed = 3062,
			ChildIdList = {
				"World3_Path6_Branch2_Node18",
			},
			EventPool = 810020,
		},
		World3_Path6_Branch2_Node18 = {
			BranchRoot = "World3_Path6_Branch2_Node1",
			Seed = 3062,
			ChildIdList = {
				"World3_Path6_Branch2_Node19",
			},
			EventPool = 810020,
		},
		World3_Path6_Branch2_Node19 = {
			BranchRoot = "World3_Path6_Branch2_Node1",
			Seed = 3062,
			ChildIdList = {
				"World3_Path6_Branch2_Node20",
			},
			EventPool = 810021,
		},
		World3_Path6_Branch2_Node20 = {
			BranchRoot = "World3_Path6_Branch2_Node1",
			Seed = 3062,
			EventPool = 810023,
		},
	},
}
SpaceTravelMapConfig[SpaceTravelMapID.Id004] =
{
	Id = 4,
	WorldIndex = 4,
	Name = "实验室的宙域",
	FirstNode = "World4_Path1_Branch1_Node1",
	LastNodeList = {
		"World4_Path6_Branch1_Node20",
		"World4_Path6_Branch2_Node20",
	},
	RoundScore = 0,
	StepScore = 25,
	RoundFuelCost = 75,
	StepFuelCost = 0,
	RoundFoodCost = 0,
	StepFoodCost = 0,
	Nodes = {
		World4_Path1_Branch1_Node1 = {
			BranchRoot = "World4_Path1_Branch1_Node1",
			Seed = 4011,
			ChildIdList = {
				"World4_Path1_Branch1_Node2",
			},
			EventPool = 810016,
		},
		World4_Path1_Branch1_Node2 = {
			BranchRoot = "World4_Path1_Branch1_Node1",
			Seed = 4011,
			ChildIdList = {
				"World4_Path1_Branch1_Node3",
			},
			EventPool = 810016,
		},
		World4_Path1_Branch1_Node3 = {
			BranchRoot = "World4_Path1_Branch1_Node1",
			Seed = 4011,
			ChildIdList = {
				"World4_Path1_Branch1_Node4",
			},
			EventPool = 810026,
		},
		World4_Path1_Branch1_Node4 = {
			BranchRoot = "World4_Path1_Branch1_Node1",
			Seed = 4011,
			ChildIdList = {
				"World4_Path1_Branch1_Node5",
			},
			EventPool = 810014,
		},
		World4_Path1_Branch1_Node5 = {
			BranchRoot = "World4_Path1_Branch1_Node1",
			Seed = 4011,
			ChildIdList = {
				"World4_Path1_Branch1_Node6",
			},
			EventPool = 810021,
		},
		World4_Path1_Branch1_Node6 = {
			BranchRoot = "World4_Path1_Branch1_Node1",
			Seed = 4011,
			ChildIdList = {
				"World4_Path1_Branch1_Node7",
			},
			EventPool = 810014,
		},
		World4_Path1_Branch1_Node7 = {
			BranchRoot = "World4_Path1_Branch1_Node1",
			Seed = 4011,
			ChildIdList = {
				"World4_Path1_Branch1_Node8",
			},
			EventPool = 810026,
		},
		World4_Path1_Branch1_Node8 = {
			BranchRoot = "World4_Path1_Branch1_Node1",
			Seed = 4011,
			ChildIdList = {
				"World4_Path1_Branch1_Node9",
			},
			EventPool = 810020,
		},
		World4_Path1_Branch1_Node9 = {
			BranchRoot = "World4_Path1_Branch1_Node1",
			Seed = 4011,
			ChildIdList = {
				"World4_Path1_Branch1_Node10",
			},
			EventPool = 810024,
		},
		World4_Path1_Branch1_Node10 = {
			BranchRoot = "World4_Path1_Branch1_Node1",
			Seed = 4011,
			ChildIdList = {
				"World4_Path1_Branch1_Node11",
			},
			EventPool = 810016,
		},
		World4_Path1_Branch1_Node11 = {
			BranchRoot = "World4_Path1_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 4011,
			ChildIdList = {
				"World4_Path1_Branch1_Node12",
			},
			EventPool = 810004,
		},
		World4_Path1_Branch1_Node12 = {
			BranchRoot = "World4_Path1_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 4011,
			ChildIdList = {
				"World4_Path1_Branch1_Node13",
			},
			EventPool = 810004,
		},
		World4_Path1_Branch1_Node13 = {
			BranchRoot = "World4_Path1_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 4011,
			ChildIdList = {
				"World4_Path1_Branch1_Node14",
			},
			EventPool = 810004,
		},
		World4_Path1_Branch1_Node14 = {
			BranchRoot = "World4_Path1_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 4011,
			ChildIdList = {
				"World4_Path1_Branch1_Node15",
			},
			EventPool = 810004,
		},
		World4_Path1_Branch1_Node15 = {
			BranchRoot = "World4_Path1_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 4011,
			ChildIdList = {
				"World4_Path1_Branch1_Node16",
			},
			EventPool = 810004,
		},
		World4_Path1_Branch1_Node16 = {
			BranchRoot = "World4_Path1_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 4011,
			ChildIdList = {
				"World4_Path1_Branch1_Node17",
			},
			EventPool = 810004,
		},
		World4_Path1_Branch1_Node17 = {
			BranchRoot = "World4_Path1_Branch1_Node1",
			Seed = 4011,
			ChildIdList = {
				"World4_Path1_Branch1_Node18",
			},
			EventPool = 810015,
		},
		World4_Path1_Branch1_Node18 = {
			BranchRoot = "World4_Path1_Branch1_Node1",
			Seed = 4011,
			ChildIdList = {
				"World4_Path1_Branch1_Node19",
			},
			EventPool = 810014,
		},
		World4_Path1_Branch1_Node19 = {
			BranchRoot = "World4_Path1_Branch1_Node1",
			Seed = 4011,
			ChildIdList = {
				"World4_Path1_Branch1_Node20",
			},
			EventPool = 810024,
		},
		World4_Path1_Branch1_Node20 = {
			BranchRoot = "World4_Path1_Branch1_Node1",
			Seed = 4011,
			ChildIdList = {
				"World4_Path2_Branch1_Node1",
				"World4_Path2_Branch2_Node1",
			},
			EventPool = 810026,
		},
		World4_Path2_Branch1_Node1 = {
			BranchRoot = "World4_Path2_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 4021,
			ChildIdList = {
				"World4_Path2_Branch1_Node2",
			},
			EventPool = 810005,
		},
		World4_Path2_Branch1_Node2 = {
			BranchRoot = "World4_Path2_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 4021,
			ChildIdList = {
				"World4_Path2_Branch1_Node3",
			},
			EventPool = 810005,
		},
		World4_Path2_Branch1_Node3 = {
			BranchRoot = "World4_Path2_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 4021,
			ChildIdList = {
				"World4_Path2_Branch1_Node4",
			},
			EventPool = 810005,
		},
		World4_Path2_Branch1_Node4 = {
			BranchRoot = "World4_Path2_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 4021,
			ChildIdList = {
				"World4_Path2_Branch1_Node5",
			},
			EventPool = 810005,
		},
		World4_Path2_Branch1_Node5 = {
			BranchRoot = "World4_Path2_Branch1_Node1",
			Seed = 4021,
			ChildIdList = {
				"World4_Path2_Branch1_Node6",
			},
			EventPool = 810016,
		},
		World4_Path2_Branch1_Node6 = {
			BranchRoot = "World4_Path2_Branch1_Node1",
			Seed = 4021,
			ChildIdList = {
				"World4_Path2_Branch1_Node7",
			},
			EventPool = 810016,
		},
		World4_Path2_Branch1_Node7 = {
			BranchRoot = "World4_Path2_Branch1_Node1",
			Seed = 4021,
			ChildIdList = {
				"World4_Path2_Branch1_Node8",
			},
			EventPool = 810026,
		},
		World4_Path2_Branch1_Node8 = {
			BranchRoot = "World4_Path2_Branch1_Node1",
			Seed = 4021,
			ChildIdList = {
				"World4_Path2_Branch1_Node9",
			},
			EventPool = 810016,
		},
		World4_Path2_Branch1_Node9 = {
			BranchRoot = "World4_Path2_Branch1_Node1",
			Seed = 4021,
			ChildIdList = {
				"World4_Path2_Branch1_Node10",
			},
			EventPool = 810025,
		},
		World4_Path2_Branch1_Node10 = {
			BranchRoot = "World4_Path2_Branch1_Node1",
			Seed = 4021,
			ChildIdList = {
				"World4_Path2_Branch1_Node11",
			},
			EventPool = 810016,
		},
		World4_Path2_Branch1_Node11 = {
			BranchRoot = "World4_Path2_Branch1_Node1",
			Seed = 4021,
			ChildIdList = {
				"World4_Path2_Branch1_Node12",
			},
			EventPool = 810021,
		},
		World4_Path2_Branch1_Node12 = {
			BranchRoot = "World4_Path2_Branch1_Node1",
			Seed = 4021,
			ChildIdList = {
				"World4_Path2_Branch1_Node13",
			},
			EventPool = 810015,
		},
		World4_Path2_Branch1_Node13 = {
			BranchRoot = "World4_Path2_Branch1_Node1",
			Seed = 4021,
			ChildIdList = {
				"World4_Path2_Branch1_Node14",
			},
			EventPool = 810022,
		},
		World4_Path2_Branch1_Node14 = {
			BranchRoot = "World4_Path2_Branch1_Node1",
			StepScore = 50,
			Seed = 4021,
			ChildIdList = {
				"World4_Path2_Branch1_Node15",
			},
			EventPool = 810006,
		},
		World4_Path2_Branch1_Node15 = {
			BranchRoot = "World4_Path2_Branch1_Node1",
			Seed = 4021,
			ChildIdList = {
				"World4_Path2_Branch1_Node16",
			},
			EventPool = 810021,
		},
		World4_Path2_Branch1_Node16 = {
			BranchRoot = "World4_Path2_Branch1_Node1",
			Seed = 4021,
			ChildIdList = {
				"World4_Path2_Branch1_Node17",
			},
			EventPool = 810021,
		},
		World4_Path2_Branch1_Node17 = {
			BranchRoot = "World4_Path2_Branch1_Node1",
			Seed = 4021,
			ChildIdList = {
				"World4_Path2_Branch1_Node18",
			},
			EventPool = 810020,
		},
		World4_Path2_Branch1_Node18 = {
			BranchRoot = "World4_Path2_Branch1_Node1",
			Seed = 4021,
			ChildIdList = {
				"World4_Path2_Branch1_Node19",
			},
			EventPool = 810016,
		},
		World4_Path2_Branch1_Node19 = {
			BranchRoot = "World4_Path2_Branch1_Node1",
			Seed = 4021,
			ChildIdList = {
				"World4_Path2_Branch1_Node20",
			},
			EventPool = 810024,
		},
		World4_Path2_Branch1_Node20 = {
			BranchRoot = "World4_Path2_Branch1_Node1",
			Seed = 4021,
			ChildIdList = {
				"World4_Path3_Branch1_Node1",
				"World4_Path3_Branch2_Node1",
			},
			EventPool = 810015,
		},
		World4_Path3_Branch1_Node1 = {
			BranchRoot = "World4_Path3_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 4031,
			ChildIdList = {
				"World4_Path3_Branch1_Node2",
			},
			EventPool = 810004,
		},
		World4_Path3_Branch1_Node2 = {
			BranchRoot = "World4_Path3_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 4031,
			ChildIdList = {
				"World4_Path3_Branch1_Node3",
			},
			EventPool = 810004,
		},
		World4_Path3_Branch1_Node3 = {
			BranchRoot = "World4_Path3_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 4031,
			ChildIdList = {
				"World4_Path3_Branch1_Node4",
			},
			EventPool = 810004,
		},
		World4_Path3_Branch1_Node4 = {
			BranchRoot = "World4_Path3_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 4031,
			ChildIdList = {
				"World4_Path3_Branch1_Node5",
			},
			EventPool = 810004,
		},
		World4_Path3_Branch1_Node5 = {
			BranchRoot = "World4_Path3_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 4031,
			ChildIdList = {
				"World4_Path3_Branch1_Node6",
			},
			EventPool = 810004,
		},
		World4_Path3_Branch1_Node6 = {
			BranchRoot = "World4_Path3_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 4031,
			ChildIdList = {
				"World4_Path3_Branch1_Node7",
			},
			EventPool = 810004,
		},
		World4_Path3_Branch1_Node7 = {
			BranchRoot = "World4_Path3_Branch1_Node1",
			Seed = 4031,
			ChildIdList = {
				"World4_Path3_Branch1_Node8",
			},
			EventPool = 810016,
		},
		World4_Path3_Branch1_Node8 = {
			BranchRoot = "World4_Path3_Branch1_Node1",
			Seed = 4031,
			ChildIdList = {
				"World4_Path3_Branch1_Node9",
			},
			EventPool = 810021,
		},
		World4_Path3_Branch1_Node9 = {
			BranchRoot = "World4_Path3_Branch1_Node1",
			Seed = 4031,
			ChildIdList = {
				"World4_Path3_Branch1_Node10",
			},
			EventPool = 810025,
		},
		World4_Path3_Branch1_Node10 = {
			BranchRoot = "World4_Path3_Branch1_Node1",
			Seed = 4031,
			ChildIdList = {
				"World4_Path3_Branch1_Node11",
			},
			EventPool = 810021,
		},
		World4_Path3_Branch1_Node11 = {
			BranchRoot = "World4_Path3_Branch1_Node1",
			Seed = 4031,
			ChildIdList = {
				"World4_Path3_Branch1_Node12",
			},
			EventPool = 810021,
		},
		World4_Path3_Branch1_Node12 = {
			BranchRoot = "World4_Path3_Branch1_Node1",
			Seed = 4031,
			ChildIdList = {
				"World4_Path3_Branch1_Node13",
			},
			EventPool = 810016,
		},
		World4_Path3_Branch1_Node13 = {
			BranchRoot = "World4_Path3_Branch1_Node1",
			Seed = 4031,
			ChildIdList = {
				"World4_Path3_Branch1_Node14",
			},
			EventPool = 810014,
		},
		World4_Path3_Branch1_Node14 = {
			BranchRoot = "World4_Path3_Branch1_Node1",
			Seed = 4031,
			ChildIdList = {
				"World4_Path3_Branch1_Node15",
			},
			EventPool = 810015,
		},
		World4_Path3_Branch1_Node15 = {
			BranchRoot = "World4_Path3_Branch1_Node1",
			Seed = 4031,
			ChildIdList = {
				"World4_Path3_Branch1_Node16",
			},
			EventPool = 810016,
		},
		World4_Path3_Branch1_Node16 = {
			BranchRoot = "World4_Path3_Branch1_Node1",
			Seed = 4031,
			ChildIdList = {
				"World4_Path3_Branch1_Node17",
			},
			EventPool = 810020,
		},
		World4_Path3_Branch1_Node17 = {
			BranchRoot = "World4_Path3_Branch1_Node1",
			Seed = 4031,
			ChildIdList = {
				"World4_Path3_Branch1_Node18",
			},
			EventPool = 810014,
		},
		World4_Path3_Branch1_Node18 = {
			BranchRoot = "World4_Path3_Branch1_Node1",
			Seed = 4031,
			ChildIdList = {
				"World4_Path3_Branch1_Node19",
			},
			EventPool = 810014,
		},
		World4_Path3_Branch1_Node19 = {
			BranchRoot = "World4_Path3_Branch1_Node1",
			Seed = 4031,
			ChildIdList = {
				"World4_Path3_Branch1_Node20",
			},
			EventPool = 810025,
		},
		World4_Path3_Branch1_Node20 = {
			BranchRoot = "World4_Path3_Branch1_Node1",
			Seed = 4031,
			ChildIdList = {
				"World4_Path4_Branch1_Node1",
				"World4_Path4_Branch2_Node1",
			},
			EventPool = 810021,
		},
		World4_Path4_Branch1_Node1 = {
			BranchRoot = "World4_Path4_Branch1_Node1",
			Seed = 4041,
			ChildIdList = {
				"World4_Path4_Branch1_Node2",
			},
			EventPool = 810020,
		},
		World4_Path4_Branch1_Node2 = {
			BranchRoot = "World4_Path4_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 4041,
			ChildIdList = {
				"World4_Path4_Branch1_Node3",
			},
			EventPool = 810005,
		},
		World4_Path4_Branch1_Node3 = {
			BranchRoot = "World4_Path4_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 4041,
			ChildIdList = {
				"World4_Path4_Branch1_Node4",
			},
			EventPool = 810005,
		},
		World4_Path4_Branch1_Node4 = {
			BranchRoot = "World4_Path4_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 4041,
			ChildIdList = {
				"World4_Path4_Branch1_Node5",
			},
			EventPool = 810005,
		},
		World4_Path4_Branch1_Node5 = {
			BranchRoot = "World4_Path4_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 4041,
			ChildIdList = {
				"World4_Path4_Branch1_Node6",
			},
			EventPool = 810005,
		},
		World4_Path4_Branch1_Node6 = {
			BranchRoot = "World4_Path4_Branch1_Node1",
			Seed = 4041,
			ChildIdList = {
				"World4_Path4_Branch1_Node7",
			},
			EventPool = 810015,
		},
		World4_Path4_Branch1_Node7 = {
			BranchRoot = "World4_Path4_Branch1_Node1",
			Seed = 4041,
			ChildIdList = {
				"World4_Path4_Branch1_Node8",
			},
			EventPool = 810026,
		},
		World4_Path4_Branch1_Node8 = {
			BranchRoot = "World4_Path4_Branch1_Node1",
			Seed = 4041,
			ChildIdList = {
				"World4_Path4_Branch1_Node9",
			},
			EventPool = 810021,
		},
		World4_Path4_Branch1_Node9 = {
			BranchRoot = "World4_Path4_Branch1_Node1",
			Seed = 4041,
			ChildIdList = {
				"World4_Path4_Branch1_Node10",
			},
			EventPool = 810024,
		},
		World4_Path4_Branch1_Node10 = {
			BranchRoot = "World4_Path4_Branch1_Node1",
			Seed = 4041,
			ChildIdList = {
				"World4_Path4_Branch1_Node11",
			},
			EventPool = 810022,
		},
		World4_Path4_Branch1_Node11 = {
			BranchRoot = "World4_Path4_Branch1_Node1",
			Seed = 4041,
			ChildIdList = {
				"World4_Path4_Branch1_Node12",
			},
			EventPool = 810016,
		},
		World4_Path4_Branch1_Node12 = {
			BranchRoot = "World4_Path4_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 4041,
			ChildIdList = {
				"World4_Path4_Branch1_Node13",
			},
			EventPool = 810004,
		},
		World4_Path4_Branch1_Node13 = {
			BranchRoot = "World4_Path4_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 4041,
			ChildIdList = {
				"World4_Path4_Branch1_Node14",
			},
			EventPool = 810004,
		},
		World4_Path4_Branch1_Node14 = {
			BranchRoot = "World4_Path4_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 4041,
			ChildIdList = {
				"World4_Path4_Branch1_Node15",
			},
			EventPool = 810004,
		},
		World4_Path4_Branch1_Node15 = {
			BranchRoot = "World4_Path4_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 4041,
			ChildIdList = {
				"World4_Path4_Branch1_Node16",
			},
			EventPool = 810004,
		},
		World4_Path4_Branch1_Node16 = {
			BranchRoot = "World4_Path4_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 4041,
			ChildIdList = {
				"World4_Path4_Branch1_Node17",
			},
			EventPool = 810004,
		},
		World4_Path4_Branch1_Node17 = {
			BranchRoot = "World4_Path4_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 4041,
			ChildIdList = {
				"World4_Path4_Branch1_Node18",
			},
			EventPool = 810004,
		},
		World4_Path4_Branch1_Node18 = {
			BranchRoot = "World4_Path4_Branch1_Node1",
			Seed = 4041,
			ChildIdList = {
				"World4_Path4_Branch1_Node19",
			},
			EventPool = 810014,
		},
		World4_Path4_Branch1_Node19 = {
			BranchRoot = "World4_Path4_Branch1_Node1",
			Seed = 4041,
			ChildIdList = {
				"World4_Path4_Branch1_Node20",
			},
			EventPool = 810024,
		},
		World4_Path4_Branch1_Node20 = {
			BranchRoot = "World4_Path4_Branch1_Node1",
			Seed = 4041,
			ChildIdList = {
				"World4_Path5_Branch1_Node1",
				"World4_Path5_Branch2_Node1",
			},
			EventPool = 810016,
		},
		World4_Path5_Branch1_Node1 = {
			BranchRoot = "World4_Path5_Branch1_Node1",
			Seed = 4051,
			ChildIdList = {
				"World4_Path5_Branch1_Node2",
			},
			EventPool = 810016,
		},
		World4_Path5_Branch1_Node2 = {
			BranchRoot = "World4_Path5_Branch1_Node1",
			Seed = 4051,
			ChildIdList = {
				"World4_Path5_Branch1_Node3",
			},
			EventPool = 810014,
		},
		World4_Path5_Branch1_Node3 = {
			BranchRoot = "World4_Path5_Branch1_Node1",
			StepScore = 50,
			Seed = 4051,
			ChildIdList = {
				"World4_Path5_Branch1_Node4",
			},
			EventPool = 810006,
		},
		World4_Path5_Branch1_Node4 = {
			BranchRoot = "World4_Path5_Branch1_Node1",
			Seed = 4051,
			ChildIdList = {
				"World4_Path5_Branch1_Node5",
			},
			EventPool = 810016,
		},
		World4_Path5_Branch1_Node5 = {
			BranchRoot = "World4_Path5_Branch1_Node1",
			Seed = 4051,
			ChildIdList = {
				"World4_Path5_Branch1_Node6",
			},
			EventPool = 810014,
		},
		World4_Path5_Branch1_Node6 = {
			BranchRoot = "World4_Path5_Branch1_Node1",
			Seed = 4051,
			ChildIdList = {
				"World4_Path5_Branch1_Node7",
			},
			EventPool = 810014,
		},
		World4_Path5_Branch1_Node7 = {
			BranchRoot = "World4_Path5_Branch1_Node1",
			Seed = 4051,
			ChildIdList = {
				"World4_Path5_Branch1_Node8",
			},
			EventPool = 810014,
		},
		World4_Path5_Branch1_Node8 = {
			BranchRoot = "World4_Path5_Branch1_Node1",
			Seed = 4051,
			ChildIdList = {
				"World4_Path5_Branch1_Node9",
			},
			EventPool = 810022,
		},
		World4_Path5_Branch1_Node9 = {
			BranchRoot = "World4_Path5_Branch1_Node1",
			Seed = 4051,
			ChildIdList = {
				"World4_Path5_Branch1_Node10",
			},
			EventPool = 810025,
		},
		World4_Path5_Branch1_Node10 = {
			BranchRoot = "World4_Path5_Branch1_Node1",
			Seed = 4051,
			ChildIdList = {
				"World4_Path5_Branch1_Node11",
			},
			EventPool = 810022,
		},
		World4_Path5_Branch1_Node11 = {
			BranchRoot = "World4_Path5_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 4051,
			ChildIdList = {
				"World4_Path5_Branch1_Node12",
			},
			EventPool = 810005,
		},
		World4_Path5_Branch1_Node12 = {
			BranchRoot = "World4_Path5_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 4051,
			ChildIdList = {
				"World4_Path5_Branch1_Node13",
			},
			EventPool = 810005,
		},
		World4_Path5_Branch1_Node13 = {
			BranchRoot = "World4_Path5_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 4051,
			ChildIdList = {
				"World4_Path5_Branch1_Node14",
			},
			EventPool = 810005,
		},
		World4_Path5_Branch1_Node14 = {
			BranchRoot = "World4_Path5_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 4051,
			ChildIdList = {
				"World4_Path5_Branch1_Node15",
			},
			EventPool = 810005,
		},
		World4_Path5_Branch1_Node15 = {
			BranchRoot = "World4_Path5_Branch1_Node1",
			Seed = 4051,
			ChildIdList = {
				"World4_Path5_Branch1_Node16",
			},
			EventPool = 810016,
		},
		World4_Path5_Branch1_Node16 = {
			BranchRoot = "World4_Path5_Branch1_Node1",
			Seed = 4051,
			ChildIdList = {
				"World4_Path5_Branch1_Node17",
			},
			EventPool = 810016,
		},
		World4_Path5_Branch1_Node17 = {
			BranchRoot = "World4_Path5_Branch1_Node1",
			Seed = 4051,
			ChildIdList = {
				"World4_Path5_Branch1_Node18",
			},
			EventPool = 810016,
		},
		World4_Path5_Branch1_Node18 = {
			BranchRoot = "World4_Path5_Branch1_Node1",
			Seed = 4051,
			ChildIdList = {
				"World4_Path5_Branch1_Node19",
			},
			EventPool = 810026,
		},
		World4_Path5_Branch1_Node19 = {
			BranchRoot = "World4_Path5_Branch1_Node1",
			Seed = 4051,
			ChildIdList = {
				"World4_Path5_Branch1_Node20",
			},
			EventPool = 810025,
		},
		World4_Path5_Branch1_Node20 = {
			BranchRoot = "World4_Path5_Branch1_Node1",
			Seed = 4051,
			ChildIdList = {
				"World4_Path6_Branch1_Node1",
				"World4_Path6_Branch2_Node1",
			},
			EventPool = 810016,
		},
		World4_Path6_Branch1_Node1 = {
			BranchRoot = "World4_Path6_Branch1_Node1",
			Seed = 4061,
			ChildIdList = {
				"World4_Path6_Branch1_Node2",
			},
			EventPool = 810021,
		},
		World4_Path6_Branch1_Node2 = {
			BranchRoot = "World4_Path6_Branch1_Node1",
			Seed = 4061,
			ChildIdList = {
				"World4_Path6_Branch1_Node3",
			},
			EventPool = 810020,
		},
		World4_Path6_Branch1_Node3 = {
			BranchRoot = "World4_Path6_Branch1_Node1",
			Seed = 4061,
			ChildIdList = {
				"World4_Path6_Branch1_Node4",
			},
			EventPool = 810021,
		},
		World4_Path6_Branch1_Node4 = {
			BranchRoot = "World4_Path6_Branch1_Node1",
			Seed = 4061,
			ChildIdList = {
				"World4_Path6_Branch1_Node5",
			},
			EventPool = 810016,
		},
		World4_Path6_Branch1_Node5 = {
			BranchRoot = "World4_Path6_Branch1_Node1",
			Seed = 4061,
			ChildIdList = {
				"World4_Path6_Branch1_Node6",
			},
			EventPool = 810016,
		},
		World4_Path6_Branch1_Node6 = {
			BranchRoot = "World4_Path6_Branch1_Node1",
			Seed = 4061,
			ChildIdList = {
				"World4_Path6_Branch1_Node7",
			},
			EventPool = 810014,
		},
		World4_Path6_Branch1_Node7 = {
			BranchRoot = "World4_Path6_Branch1_Node1",
			Seed = 4061,
			ChildIdList = {
				"World4_Path6_Branch1_Node8",
			},
			EventPool = 810026,
		},
		World4_Path6_Branch1_Node8 = {
			BranchRoot = "World4_Path6_Branch1_Node1",
			Seed = 4061,
			ChildIdList = {
				"World4_Path6_Branch1_Node9",
			},
			EventPool = 810021,
		},
		World4_Path6_Branch1_Node9 = {
			BranchRoot = "World4_Path6_Branch1_Node1",
			Seed = 4061,
			ChildIdList = {
				"World4_Path6_Branch1_Node10",
			},
			EventPool = 810024,
		},
		World4_Path6_Branch1_Node10 = {
			BranchRoot = "World4_Path6_Branch1_Node1",
			Seed = 4061,
			ChildIdList = {
				"World4_Path6_Branch1_Node11",
			},
			EventPool = 810021,
		},
		World4_Path6_Branch1_Node11 = {
			BranchRoot = "World4_Path6_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 4061,
			ChildIdList = {
				"World4_Path6_Branch1_Node12",
			},
			EventPool = 810004,
		},
		World4_Path6_Branch1_Node12 = {
			BranchRoot = "World4_Path6_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 4061,
			ChildIdList = {
				"World4_Path6_Branch1_Node13",
			},
			EventPool = 810004,
		},
		World4_Path6_Branch1_Node13 = {
			BranchRoot = "World4_Path6_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 4061,
			ChildIdList = {
				"World4_Path6_Branch1_Node14",
			},
			EventPool = 810004,
		},
		World4_Path6_Branch1_Node14 = {
			BranchRoot = "World4_Path6_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 4061,
			ChildIdList = {
				"World4_Path6_Branch1_Node15",
			},
			EventPool = 810004,
		},
		World4_Path6_Branch1_Node15 = {
			BranchRoot = "World4_Path6_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 4061,
			ChildIdList = {
				"World4_Path6_Branch1_Node16",
			},
			EventPool = 810004,
		},
		World4_Path6_Branch1_Node16 = {
			BranchRoot = "World4_Path6_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 4061,
			ChildIdList = {
				"World4_Path6_Branch1_Node17",
			},
			EventPool = 810004,
		},
		World4_Path6_Branch1_Node17 = {
			BranchRoot = "World4_Path6_Branch1_Node1",
			Seed = 4061,
			ChildIdList = {
				"World4_Path6_Branch1_Node18",
			},
			EventPool = 810016,
		},
		World4_Path6_Branch1_Node18 = {
			BranchRoot = "World4_Path6_Branch1_Node1",
			Seed = 4061,
			ChildIdList = {
				"World4_Path6_Branch1_Node19",
			},
			EventPool = 810015,
		},
		World4_Path6_Branch1_Node19 = {
			BranchRoot = "World4_Path6_Branch1_Node1",
			Seed = 4061,
			ChildIdList = {
				"World4_Path6_Branch1_Node20",
			},
			EventPool = 810026,
		},
		World4_Path6_Branch1_Node20 = {
			BranchRoot = "World4_Path6_Branch1_Node1",
			Seed = 4061,
			EventPool = 810023,
		},
		World4_Path2_Branch2_Node1 = {
			BranchRoot = "World4_Path2_Branch2_Node1",
			Seed = 4022,
			ChildIdList = {
				"World4_Path2_Branch2_Node2",
			},
			EventPool = 810016,
		},
		World4_Path2_Branch2_Node2 = {
			BranchRoot = "World4_Path2_Branch2_Node1",
			Seed = 4022,
			ChildIdList = {
				"World4_Path2_Branch2_Node3",
			},
			EventPool = 810016,
		},
		World4_Path2_Branch2_Node3 = {
			BranchRoot = "World4_Path2_Branch2_Node1",
			Seed = 4022,
			ChildIdList = {
				"World4_Path2_Branch2_Node4",
			},
			EventPool = 810026,
		},
		World4_Path2_Branch2_Node4 = {
			BranchRoot = "World4_Path2_Branch2_Node1",
			Seed = 4022,
			ChildIdList = {
				"World4_Path2_Branch2_Node5",
			},
			EventPool = 810016,
		},
		World4_Path2_Branch2_Node5 = {
			BranchRoot = "World4_Path2_Branch2_Node1",
			StepScore = 50,
			Seed = 4022,
			ChildIdList = {
				"World4_Path2_Branch2_Node6",
			},
			EventPool = 810006,
		},
		World4_Path2_Branch2_Node6 = {
			BranchRoot = "World4_Path2_Branch2_Node1",
			Seed = 4022,
			ChildIdList = {
				"World4_Path2_Branch2_Node7",
			},
			EventPool = 810022,
		},
		World4_Path2_Branch2_Node7 = {
			BranchRoot = "World4_Path2_Branch2_Node1",
			Seed = 4022,
			ChildIdList = {
				"World4_Path2_Branch2_Node8",
			},
			EventPool = 810020,
		},
		World4_Path2_Branch2_Node8 = {
			BranchRoot = "World4_Path2_Branch2_Node1",
			Seed = 4022,
			ChildIdList = {
				"World4_Path2_Branch2_Node9",
			},
			EventPool = 810026,
		},
		World4_Path2_Branch2_Node9 = {
			BranchRoot = "World4_Path2_Branch2_Node1",
			Seed = 4022,
			ChildIdList = {
				"World4_Path2_Branch2_Node10",
			},
			EventPool = 810025,
		},
		World4_Path2_Branch2_Node10 = {
			BranchRoot = "World4_Path2_Branch2_Node1",
			Seed = 4022,
			ChildIdList = {
				"World4_Path2_Branch2_Node11",
			},
			EventPool = 810026,
		},
		World4_Path2_Branch2_Node11 = {
			BranchRoot = "World4_Path2_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 4022,
			ChildIdList = {
				"World4_Path2_Branch2_Node12",
			},
			EventPool = 810005,
		},
		World4_Path2_Branch2_Node12 = {
			BranchRoot = "World4_Path2_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 4022,
			ChildIdList = {
				"World4_Path2_Branch2_Node13",
			},
			EventPool = 810005,
		},
		World4_Path2_Branch2_Node13 = {
			BranchRoot = "World4_Path2_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 4022,
			ChildIdList = {
				"World4_Path2_Branch2_Node14",
			},
			EventPool = 810005,
		},
		World4_Path2_Branch2_Node14 = {
			BranchRoot = "World4_Path2_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 4022,
			ChildIdList = {
				"World4_Path2_Branch2_Node15",
			},
			EventPool = 810005,
		},
		World4_Path2_Branch2_Node15 = {
			BranchRoot = "World4_Path2_Branch2_Node1",
			Seed = 4022,
			ChildIdList = {
				"World4_Path2_Branch2_Node16",
			},
			EventPool = 810026,
		},
		World4_Path2_Branch2_Node16 = {
			BranchRoot = "World4_Path2_Branch2_Node1",
			Seed = 4022,
			ChildIdList = {
				"World4_Path2_Branch2_Node17",
			},
			EventPool = 810022,
		},
		World4_Path2_Branch2_Node17 = {
			BranchRoot = "World4_Path2_Branch2_Node1",
			Seed = 4022,
			ChildIdList = {
				"World4_Path2_Branch2_Node18",
			},
			EventPool = 810026,
		},
		World4_Path2_Branch2_Node18 = {
			BranchRoot = "World4_Path2_Branch2_Node1",
			Seed = 4022,
			ChildIdList = {
				"World4_Path2_Branch2_Node19",
			},
			EventPool = 810014,
		},
		World4_Path2_Branch2_Node19 = {
			BranchRoot = "World4_Path2_Branch2_Node1",
			Seed = 4022,
			ChildIdList = {
				"World4_Path2_Branch2_Node20",
			},
			EventPool = 810024,
		},
		World4_Path2_Branch2_Node20 = {
			BranchRoot = "World4_Path2_Branch2_Node1",
			Seed = 4022,
			ChildIdList = {
				"World4_Path3_Branch1_Node1",
				"World4_Path3_Branch2_Node1",
			},
			EventPool = 810016,
		},
		World4_Path3_Branch2_Node1 = {
			BranchRoot = "World4_Path3_Branch2_Node1",
			Seed = 4032,
			ChildIdList = {
				"World4_Path3_Branch2_Node2",
			},
			EventPool = 810022,
		},
		World4_Path3_Branch2_Node2 = {
			BranchRoot = "World4_Path3_Branch2_Node1",
			Seed = 4032,
			ChildIdList = {
				"World4_Path3_Branch2_Node3",
			},
			EventPool = 810016,
		},
		World4_Path3_Branch2_Node3 = {
			BranchRoot = "World4_Path3_Branch2_Node1",
			Seed = 4032,
			ChildIdList = {
				"World4_Path3_Branch2_Node4",
			},
			EventPool = 810015,
		},
		World4_Path3_Branch2_Node4 = {
			BranchRoot = "World4_Path3_Branch2_Node1",
			StepScore = 50,
			Seed = 4032,
			ChildIdList = {
				"World4_Path3_Branch2_Node5",
			},
			EventPool = 810006,
		},
		World4_Path3_Branch2_Node5 = {
			BranchRoot = "World4_Path3_Branch2_Node1",
			Seed = 4032,
			ChildIdList = {
				"World4_Path3_Branch2_Node6",
			},
			EventPool = 810014,
		},
		World4_Path3_Branch2_Node6 = {
			BranchRoot = "World4_Path3_Branch2_Node1",
			Seed = 4032,
			ChildIdList = {
				"World4_Path3_Branch2_Node7",
			},
			EventPool = 810021,
		},
		World4_Path3_Branch2_Node7 = {
			BranchRoot = "World4_Path3_Branch2_Node1",
			Seed = 4032,
			ChildIdList = {
				"World4_Path3_Branch2_Node8",
			},
			EventPool = 810026,
		},
		World4_Path3_Branch2_Node8 = {
			BranchRoot = "World4_Path3_Branch2_Node1",
			Seed = 4032,
			ChildIdList = {
				"World4_Path3_Branch2_Node9",
			},
			EventPool = 810022,
		},
		World4_Path3_Branch2_Node9 = {
			BranchRoot = "World4_Path3_Branch2_Node1",
			Seed = 4032,
			ChildIdList = {
				"World4_Path3_Branch2_Node10",
			},
			EventPool = 810025,
		},
		World4_Path3_Branch2_Node10 = {
			BranchRoot = "World4_Path3_Branch2_Node1",
			Seed = 4032,
			ChildIdList = {
				"World4_Path3_Branch2_Node11",
			},
			EventPool = 810016,
		},
		World4_Path3_Branch2_Node11 = {
			BranchRoot = "World4_Path3_Branch2_Node1",
			Seed = 4032,
			ChildIdList = {
				"World4_Path3_Branch2_Node12",
			},
			EventPool = 810026,
		},
		World4_Path3_Branch2_Node12 = {
			BranchRoot = "World4_Path3_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 4032,
			ChildIdList = {
				"World4_Path3_Branch2_Node13",
			},
			EventPool = 810004,
		},
		World4_Path3_Branch2_Node13 = {
			BranchRoot = "World4_Path3_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 4032,
			ChildIdList = {
				"World4_Path3_Branch2_Node14",
			},
			EventPool = 810004,
		},
		World4_Path3_Branch2_Node14 = {
			BranchRoot = "World4_Path3_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 4032,
			ChildIdList = {
				"World4_Path3_Branch2_Node15",
			},
			EventPool = 810004,
		},
		World4_Path3_Branch2_Node15 = {
			BranchRoot = "World4_Path3_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 4032,
			ChildIdList = {
				"World4_Path3_Branch2_Node16",
			},
			EventPool = 810004,
		},
		World4_Path3_Branch2_Node16 = {
			BranchRoot = "World4_Path3_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 4032,
			ChildIdList = {
				"World4_Path3_Branch2_Node17",
			},
			EventPool = 810004,
		},
		World4_Path3_Branch2_Node17 = {
			BranchRoot = "World4_Path3_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 4032,
			ChildIdList = {
				"World4_Path3_Branch2_Node18",
			},
			EventPool = 810004,
		},
		World4_Path3_Branch2_Node18 = {
			BranchRoot = "World4_Path3_Branch2_Node1",
			Seed = 4032,
			ChildIdList = {
				"World4_Path3_Branch2_Node19",
			},
			EventPool = 810014,
		},
		World4_Path3_Branch2_Node19 = {
			BranchRoot = "World4_Path3_Branch2_Node1",
			Seed = 4032,
			ChildIdList = {
				"World4_Path3_Branch2_Node20",
			},
			EventPool = 810024,
		},
		World4_Path3_Branch2_Node20 = {
			BranchRoot = "World4_Path3_Branch2_Node1",
			Seed = 4032,
			ChildIdList = {
				"World4_Path4_Branch1_Node1",
				"World4_Path4_Branch2_Node1",
			},
			EventPool = 810021,
		},
		World4_Path4_Branch2_Node1 = {
			BranchRoot = "World4_Path4_Branch2_Node1",
			Seed = 4042,
			ChildIdList = {
				"World4_Path4_Branch2_Node2",
			},
			EventPool = 810015,
		},
		World4_Path4_Branch2_Node2 = {
			BranchRoot = "World4_Path4_Branch2_Node1",
			Seed = 4042,
			ChildIdList = {
				"World4_Path4_Branch2_Node3",
			},
			EventPool = 810026,
		},
		World4_Path4_Branch2_Node3 = {
			BranchRoot = "World4_Path4_Branch2_Node1",
			Seed = 4042,
			ChildIdList = {
				"World4_Path4_Branch2_Node4",
			},
			EventPool = 810021,
		},
		World4_Path4_Branch2_Node4 = {
			BranchRoot = "World4_Path4_Branch2_Node1",
			Seed = 4042,
			ChildIdList = {
				"World4_Path4_Branch2_Node5",
			},
			EventPool = 810020,
		},
		World4_Path4_Branch2_Node5 = {
			BranchRoot = "World4_Path4_Branch2_Node1",
			Seed = 4042,
			ChildIdList = {
				"World4_Path4_Branch2_Node6",
			},
			EventPool = 810026,
		},
		World4_Path4_Branch2_Node6 = {
			BranchRoot = "World4_Path4_Branch2_Node1",
			Seed = 4042,
			ChildIdList = {
				"World4_Path4_Branch2_Node7",
			},
			EventPool = 810016,
		},
		World4_Path4_Branch2_Node7 = {
			BranchRoot = "World4_Path4_Branch2_Node1",
			Seed = 4042,
			ChildIdList = {
				"World4_Path4_Branch2_Node8",
			},
			EventPool = 810026,
		},
		World4_Path4_Branch2_Node8 = {
			BranchRoot = "World4_Path4_Branch2_Node1",
			Seed = 4042,
			ChildIdList = {
				"World4_Path4_Branch2_Node9",
			},
			EventPool = 810022,
		},
		World4_Path4_Branch2_Node9 = {
			BranchRoot = "World4_Path4_Branch2_Node1",
			Seed = 4042,
			ChildIdList = {
				"World4_Path4_Branch2_Node10",
			},
			EventPool = 810024,
		},
		World4_Path4_Branch2_Node10 = {
			BranchRoot = "World4_Path4_Branch2_Node1",
			Seed = 4042,
			ChildIdList = {
				"World4_Path4_Branch2_Node11",
			},
			EventPool = 810020,
		},
		World4_Path4_Branch2_Node11 = {
			BranchRoot = "World4_Path4_Branch2_Node1",
			Seed = 4042,
			ChildIdList = {
				"World4_Path4_Branch2_Node12",
			},
			EventPool = 810026,
		},
		World4_Path4_Branch2_Node12 = {
			BranchRoot = "World4_Path4_Branch2_Node1",
			Seed = 4042,
			ChildIdList = {
				"World4_Path4_Branch2_Node13",
			},
			EventPool = 810014,
		},
		World4_Path4_Branch2_Node13 = {
			BranchRoot = "World4_Path4_Branch2_Node1",
			Seed = 4042,
			ChildIdList = {
				"World4_Path4_Branch2_Node14",
			},
			EventPool = 810022,
		},
		World4_Path4_Branch2_Node14 = {
			BranchRoot = "World4_Path4_Branch2_Node1",
			Seed = 4042,
			ChildIdList = {
				"World4_Path4_Branch2_Node15",
			},
			EventPool = 810016,
		},
		World4_Path4_Branch2_Node15 = {
			BranchRoot = "World4_Path4_Branch2_Node1",
			Seed = 4042,
			ChildIdList = {
				"World4_Path4_Branch2_Node16",
			},
			EventPool = 810015,
		},
		World4_Path4_Branch2_Node16 = {
			BranchRoot = "World4_Path4_Branch2_Node1",
			Seed = 4042,
			ChildIdList = {
				"World4_Path4_Branch2_Node17",
			},
			EventPool = 810020,
		},
		World4_Path4_Branch2_Node17 = {
			BranchRoot = "World4_Path4_Branch2_Node1",
			Seed = 4042,
			ChildIdList = {
				"World4_Path4_Branch2_Node18",
			},
			EventPool = 810014,
		},
		World4_Path4_Branch2_Node18 = {
			BranchRoot = "World4_Path4_Branch2_Node1",
			Seed = 4042,
			ChildIdList = {
				"World4_Path4_Branch2_Node19",
			},
			EventPool = 810026,
		},
		World4_Path4_Branch2_Node19 = {
			BranchRoot = "World4_Path4_Branch2_Node1",
			Seed = 4042,
			ChildIdList = {
				"World4_Path4_Branch2_Node20",
			},
			EventPool = 810024,
		},
		World4_Path4_Branch2_Node20 = {
			BranchRoot = "World4_Path4_Branch2_Node1",
			Seed = 4042,
			ChildIdList = {
				"World4_Path5_Branch1_Node1",
				"World4_Path5_Branch2_Node1",
			},
			EventPool = 810026,
		},
		World4_Path5_Branch2_Node1 = {
			BranchRoot = "World4_Path5_Branch2_Node1",
			Seed = 4052,
			ChildIdList = {
				"World4_Path5_Branch2_Node2",
			},
			EventPool = 810022,
		},
		World4_Path5_Branch2_Node2 = {
			BranchRoot = "World4_Path5_Branch2_Node1",
			Seed = 4052,
			ChildIdList = {
				"World4_Path5_Branch2_Node3",
			},
			EventPool = 810022,
		},
		World4_Path5_Branch2_Node3 = {
			BranchRoot = "World4_Path5_Branch2_Node1",
			Seed = 4052,
			ChildIdList = {
				"World4_Path5_Branch2_Node4",
			},
			EventPool = 810016,
		},
		World4_Path5_Branch2_Node4 = {
			BranchRoot = "World4_Path5_Branch2_Node1",
			StepScore = 50,
			Seed = 4052,
			ChildIdList = {
				"World4_Path5_Branch2_Node5",
			},
			EventPool = 810006,
		},
		World4_Path5_Branch2_Node5 = {
			BranchRoot = "World4_Path5_Branch2_Node1",
			Seed = 4052,
			ChildIdList = {
				"World4_Path5_Branch2_Node6",
			},
			EventPool = 810021,
		},
		World4_Path5_Branch2_Node6 = {
			BranchRoot = "World4_Path5_Branch2_Node1",
			Seed = 4052,
			ChildIdList = {
				"World4_Path5_Branch2_Node7",
			},
			EventPool = 810020,
		},
		World4_Path5_Branch2_Node7 = {
			BranchRoot = "World4_Path5_Branch2_Node1",
			Seed = 4052,
			ChildIdList = {
				"World4_Path5_Branch2_Node8",
			},
			EventPool = 810021,
		},
		World4_Path5_Branch2_Node8 = {
			BranchRoot = "World4_Path5_Branch2_Node1",
			Seed = 4052,
			ChildIdList = {
				"World4_Path5_Branch2_Node9",
			},
			EventPool = 810020,
		},
		World4_Path5_Branch2_Node9 = {
			BranchRoot = "World4_Path5_Branch2_Node1",
			Seed = 4052,
			ChildIdList = {
				"World4_Path5_Branch2_Node10",
			},
			EventPool = 810025,
		},
		World4_Path5_Branch2_Node10 = {
			BranchRoot = "World4_Path5_Branch2_Node1",
			Seed = 4052,
			ChildIdList = {
				"World4_Path5_Branch2_Node11",
			},
			EventPool = 810016,
		},
		World4_Path5_Branch2_Node11 = {
			BranchRoot = "World4_Path5_Branch2_Node1",
			Seed = 4052,
			ChildIdList = {
				"World4_Path5_Branch2_Node12",
			},
			EventPool = 810020,
		},
		World4_Path5_Branch2_Node12 = {
			BranchRoot = "World4_Path5_Branch2_Node1",
			Seed = 4052,
			ChildIdList = {
				"World4_Path5_Branch2_Node13",
			},
			EventPool = 810015,
		},
		World4_Path5_Branch2_Node13 = {
			BranchRoot = "World4_Path5_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 4052,
			ChildIdList = {
				"World4_Path5_Branch2_Node14",
			},
			EventPool = 810005,
		},
		World4_Path5_Branch2_Node14 = {
			BranchRoot = "World4_Path5_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 4052,
			ChildIdList = {
				"World4_Path5_Branch2_Node15",
			},
			EventPool = 810005,
		},
		World4_Path5_Branch2_Node15 = {
			BranchRoot = "World4_Path5_Branch2_Node1",
			StepScore = 50,
			Seed = 4052,
			ChildIdList = {
				"World4_Path5_Branch2_Node16",
			},
			EventPool = 810006,
		},
		World4_Path5_Branch2_Node16 = {
			BranchRoot = "World4_Path5_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 4052,
			ChildIdList = {
				"World4_Path5_Branch2_Node17",
			},
			EventPool = 810005,
		},
		World4_Path5_Branch2_Node17 = {
			BranchRoot = "World4_Path5_Branch2_Node1",
			Seed = 4052,
			ChildIdList = {
				"World4_Path5_Branch2_Node18",
			},
			EventPool = 810015,
		},
		World4_Path5_Branch2_Node18 = {
			BranchRoot = "World4_Path5_Branch2_Node1",
			Seed = 4052,
			ChildIdList = {
				"World4_Path5_Branch2_Node19",
			},
			EventPool = 810022,
		},
		World4_Path5_Branch2_Node19 = {
			BranchRoot = "World4_Path5_Branch2_Node1",
			Seed = 4052,
			ChildIdList = {
				"World4_Path5_Branch2_Node20",
			},
			EventPool = 810024,
		},
		World4_Path5_Branch2_Node20 = {
			BranchRoot = "World4_Path5_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 4052,
			ChildIdList = {
				"World4_Path6_Branch1_Node1",
				"World4_Path6_Branch2_Node1",
			},
			EventPool = 810004,
		},
		World4_Path6_Branch2_Node1 = {
			BranchRoot = "World4_Path6_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 4062,
			ChildIdList = {
				"World4_Path6_Branch2_Node2",
			},
			EventPool = 810004,
		},
		World4_Path6_Branch2_Node2 = {
			BranchRoot = "World4_Path6_Branch2_Node1",
			StepScore = 50,
			Seed = 4062,
			ChildIdList = {
				"World4_Path6_Branch2_Node3",
			},
			EventPool = 810006,
		},
		World4_Path6_Branch2_Node3 = {
			BranchRoot = "World4_Path6_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 4062,
			ChildIdList = {
				"World4_Path6_Branch2_Node4",
			},
			EventPool = 810004,
		},
		World4_Path6_Branch2_Node4 = {
			BranchRoot = "World4_Path6_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 4062,
			ChildIdList = {
				"World4_Path6_Branch2_Node5",
			},
			EventPool = 810004,
		},
		World4_Path6_Branch2_Node5 = {
			BranchRoot = "World4_Path6_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 4062,
			ChildIdList = {
				"World4_Path6_Branch2_Node6",
			},
			EventPool = 810004,
		},
		World4_Path6_Branch2_Node6 = {
			BranchRoot = "World4_Path6_Branch2_Node1",
			Seed = 4062,
			ChildIdList = {
				"World4_Path6_Branch2_Node7",
			},
			EventPool = 810015,
		},
		World4_Path6_Branch2_Node7 = {
			BranchRoot = "World4_Path6_Branch2_Node1",
			Seed = 4062,
			ChildIdList = {
				"World4_Path6_Branch2_Node8",
			},
			EventPool = 810022,
		},
		World4_Path6_Branch2_Node8 = {
			BranchRoot = "World4_Path6_Branch2_Node1",
			Seed = 4062,
			ChildIdList = {
				"World4_Path6_Branch2_Node9",
			},
			EventPool = 810014,
		},
		World4_Path6_Branch2_Node9 = {
			BranchRoot = "World4_Path6_Branch2_Node1",
			Seed = 4062,
			ChildIdList = {
				"World4_Path6_Branch2_Node10",
			},
			EventPool = 810025,
		},
		World4_Path6_Branch2_Node10 = {
			BranchRoot = "World4_Path6_Branch2_Node1",
			Seed = 4062,
			ChildIdList = {
				"World4_Path6_Branch2_Node11",
			},
			EventPool = 810016,
		},
		World4_Path6_Branch2_Node11 = {
			BranchRoot = "World4_Path6_Branch2_Node1",
			Seed = 4062,
			ChildIdList = {
				"World4_Path6_Branch2_Node12",
			},
			EventPool = 810015,
		},
		World4_Path6_Branch2_Node12 = {
			BranchRoot = "World4_Path6_Branch2_Node1",
			Seed = 4062,
			ChildIdList = {
				"World4_Path6_Branch2_Node13",
			},
			EventPool = 810015,
		},
		World4_Path6_Branch2_Node13 = {
			BranchRoot = "World4_Path6_Branch2_Node1",
			Seed = 4062,
			ChildIdList = {
				"World4_Path6_Branch2_Node14",
			},
			EventPool = 810014,
		},
		World4_Path6_Branch2_Node14 = {
			BranchRoot = "World4_Path6_Branch2_Node1",
			Seed = 4062,
			ChildIdList = {
				"World4_Path6_Branch2_Node15",
			},
			EventPool = 810016,
		},
		World4_Path6_Branch2_Node15 = {
			BranchRoot = "World4_Path6_Branch2_Node1",
			Seed = 4062,
			ChildIdList = {
				"World4_Path6_Branch2_Node16",
			},
			EventPool = 810020,
		},
		World4_Path6_Branch2_Node16 = {
			BranchRoot = "World4_Path6_Branch2_Node1",
			Seed = 4062,
			ChildIdList = {
				"World4_Path6_Branch2_Node17",
			},
			EventPool = 810016,
		},
		World4_Path6_Branch2_Node17 = {
			BranchRoot = "World4_Path6_Branch2_Node1",
			Seed = 4062,
			ChildIdList = {
				"World4_Path6_Branch2_Node18",
			},
			EventPool = 810020,
		},
		World4_Path6_Branch2_Node18 = {
			BranchRoot = "World4_Path6_Branch2_Node1",
			Seed = 4062,
			ChildIdList = {
				"World4_Path6_Branch2_Node19",
			},
			EventPool = 810020,
		},
		World4_Path6_Branch2_Node19 = {
			BranchRoot = "World4_Path6_Branch2_Node1",
			Seed = 4062,
			ChildIdList = {
				"World4_Path6_Branch2_Node20",
			},
			EventPool = 810021,
		},
		World4_Path6_Branch2_Node20 = {
			BranchRoot = "World4_Path6_Branch2_Node1",
			Seed = 4062,
			EventPool = 810023,
		},
	},
}
SpaceTravelMapConfig[SpaceTravelMapID.Id005] =
{
	Id = 5,
	WorldIndex = 5,
	Name = "博物的宙域",
	FirstNode = "World5_Path1_Branch1_Node1",
	LastNodeList = {
		"World5_Path6_Branch1_Node20",
		"World5_Path6_Branch2_Node20",
	},
	RoundScore = 0,
	StepScore = 30,
	RoundFuelCost = 90,
	StepFuelCost = 0,
	RoundFoodCost = 0,
	StepFoodCost = 0,
	Nodes = {
		World5_Path1_Branch1_Node1 = {
			BranchRoot = "World5_Path1_Branch1_Node1",
			Seed = 5011,
			ChildIdList = {
				"World5_Path1_Branch1_Node2",
			},
			EventPool = 810016,
		},
		World5_Path1_Branch1_Node2 = {
			BranchRoot = "World5_Path1_Branch1_Node1",
			Seed = 5011,
			ChildIdList = {
				"World5_Path1_Branch1_Node3",
			},
			EventPool = 810016,
		},
		World5_Path1_Branch1_Node3 = {
			BranchRoot = "World5_Path1_Branch1_Node1",
			Seed = 5011,
			ChildIdList = {
				"World5_Path1_Branch1_Node4",
			},
			EventPool = 810026,
		},
		World5_Path1_Branch1_Node4 = {
			BranchRoot = "World5_Path1_Branch1_Node1",
			Seed = 5011,
			ChildIdList = {
				"World5_Path1_Branch1_Node5",
			},
			EventPool = 810014,
		},
		World5_Path1_Branch1_Node5 = {
			BranchRoot = "World5_Path1_Branch1_Node1",
			Seed = 5011,
			ChildIdList = {
				"World5_Path1_Branch1_Node6",
			},
			EventPool = 810021,
		},
		World5_Path1_Branch1_Node6 = {
			BranchRoot = "World5_Path1_Branch1_Node1",
			Seed = 5011,
			ChildIdList = {
				"World5_Path1_Branch1_Node7",
			},
			EventPool = 810014,
		},
		World5_Path1_Branch1_Node7 = {
			BranchRoot = "World5_Path1_Branch1_Node1",
			Seed = 5011,
			ChildIdList = {
				"World5_Path1_Branch1_Node8",
			},
			EventPool = 810026,
		},
		World5_Path1_Branch1_Node8 = {
			BranchRoot = "World5_Path1_Branch1_Node1",
			Seed = 5011,
			ChildIdList = {
				"World5_Path1_Branch1_Node9",
			},
			EventPool = 810020,
		},
		World5_Path1_Branch1_Node9 = {
			BranchRoot = "World5_Path1_Branch1_Node1",
			Seed = 5011,
			ChildIdList = {
				"World5_Path1_Branch1_Node10",
			},
			EventPool = 810024,
		},
		World5_Path1_Branch1_Node10 = {
			BranchRoot = "World5_Path1_Branch1_Node1",
			Seed = 5011,
			ChildIdList = {
				"World5_Path1_Branch1_Node11",
			},
			EventPool = 810016,
		},
		World5_Path1_Branch1_Node11 = {
			BranchRoot = "World5_Path1_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 5011,
			ChildIdList = {
				"World5_Path1_Branch1_Node12",
			},
			EventPool = 810004,
		},
		World5_Path1_Branch1_Node12 = {
			BranchRoot = "World5_Path1_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 5011,
			ChildIdList = {
				"World5_Path1_Branch1_Node13",
			},
			EventPool = 810004,
		},
		World5_Path1_Branch1_Node13 = {
			BranchRoot = "World5_Path1_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 5011,
			ChildIdList = {
				"World5_Path1_Branch1_Node14",
			},
			EventPool = 810004,
		},
		World5_Path1_Branch1_Node14 = {
			BranchRoot = "World5_Path1_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 5011,
			ChildIdList = {
				"World5_Path1_Branch1_Node15",
			},
			EventPool = 810004,
		},
		World5_Path1_Branch1_Node15 = {
			BranchRoot = "World5_Path1_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 5011,
			ChildIdList = {
				"World5_Path1_Branch1_Node16",
			},
			EventPool = 810004,
		},
		World5_Path1_Branch1_Node16 = {
			BranchRoot = "World5_Path1_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 5011,
			ChildIdList = {
				"World5_Path1_Branch1_Node17",
			},
			EventPool = 810004,
		},
		World5_Path1_Branch1_Node17 = {
			BranchRoot = "World5_Path1_Branch1_Node1",
			Seed = 5011,
			ChildIdList = {
				"World5_Path1_Branch1_Node18",
			},
			EventPool = 810015,
		},
		World5_Path1_Branch1_Node18 = {
			BranchRoot = "World5_Path1_Branch1_Node1",
			Seed = 5011,
			ChildIdList = {
				"World5_Path1_Branch1_Node19",
			},
			EventPool = 810014,
		},
		World5_Path1_Branch1_Node19 = {
			BranchRoot = "World5_Path1_Branch1_Node1",
			Seed = 5011,
			ChildIdList = {
				"World5_Path1_Branch1_Node20",
			},
			EventPool = 810024,
		},
		World5_Path1_Branch1_Node20 = {
			BranchRoot = "World5_Path1_Branch1_Node1",
			Seed = 5011,
			ChildIdList = {
				"World5_Path2_Branch1_Node1",
				"World5_Path2_Branch2_Node1",
			},
			EventPool = 810026,
		},
		World5_Path2_Branch1_Node1 = {
			BranchRoot = "World5_Path2_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 5021,
			ChildIdList = {
				"World5_Path2_Branch1_Node2",
			},
			EventPool = 810005,
		},
		World5_Path2_Branch1_Node2 = {
			BranchRoot = "World5_Path2_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 5021,
			ChildIdList = {
				"World5_Path2_Branch1_Node3",
			},
			EventPool = 810005,
		},
		World5_Path2_Branch1_Node3 = {
			BranchRoot = "World5_Path2_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 5021,
			ChildIdList = {
				"World5_Path2_Branch1_Node4",
			},
			EventPool = 810005,
		},
		World5_Path2_Branch1_Node4 = {
			BranchRoot = "World5_Path2_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 5021,
			ChildIdList = {
				"World5_Path2_Branch1_Node5",
			},
			EventPool = 810005,
		},
		World5_Path2_Branch1_Node5 = {
			BranchRoot = "World5_Path2_Branch1_Node1",
			Seed = 5021,
			ChildIdList = {
				"World5_Path2_Branch1_Node6",
			},
			EventPool = 810016,
		},
		World5_Path2_Branch1_Node6 = {
			BranchRoot = "World5_Path2_Branch1_Node1",
			Seed = 5021,
			ChildIdList = {
				"World5_Path2_Branch1_Node7",
			},
			EventPool = 810016,
		},
		World5_Path2_Branch1_Node7 = {
			BranchRoot = "World5_Path2_Branch1_Node1",
			Seed = 5021,
			ChildIdList = {
				"World5_Path2_Branch1_Node8",
			},
			EventPool = 810026,
		},
		World5_Path2_Branch1_Node8 = {
			BranchRoot = "World5_Path2_Branch1_Node1",
			Seed = 5021,
			ChildIdList = {
				"World5_Path2_Branch1_Node9",
			},
			EventPool = 810016,
		},
		World5_Path2_Branch1_Node9 = {
			BranchRoot = "World5_Path2_Branch1_Node1",
			Seed = 5021,
			ChildIdList = {
				"World5_Path2_Branch1_Node10",
			},
			EventPool = 810025,
		},
		World5_Path2_Branch1_Node10 = {
			BranchRoot = "World5_Path2_Branch1_Node1",
			Seed = 5021,
			ChildIdList = {
				"World5_Path2_Branch1_Node11",
			},
			EventPool = 810016,
		},
		World5_Path2_Branch1_Node11 = {
			BranchRoot = "World5_Path2_Branch1_Node1",
			Seed = 5021,
			ChildIdList = {
				"World5_Path2_Branch1_Node12",
			},
			EventPool = 810021,
		},
		World5_Path2_Branch1_Node12 = {
			BranchRoot = "World5_Path2_Branch1_Node1",
			Seed = 5021,
			ChildIdList = {
				"World5_Path2_Branch1_Node13",
			},
			EventPool = 810015,
		},
		World5_Path2_Branch1_Node13 = {
			BranchRoot = "World5_Path2_Branch1_Node1",
			Seed = 5021,
			ChildIdList = {
				"World5_Path2_Branch1_Node14",
			},
			EventPool = 810022,
		},
		World5_Path2_Branch1_Node14 = {
			BranchRoot = "World5_Path2_Branch1_Node1",
			StepScore = 50,
			Seed = 5021,
			ChildIdList = {
				"World5_Path2_Branch1_Node15",
			},
			EventPool = 810006,
		},
		World5_Path2_Branch1_Node15 = {
			BranchRoot = "World5_Path2_Branch1_Node1",
			Seed = 5021,
			ChildIdList = {
				"World5_Path2_Branch1_Node16",
			},
			EventPool = 810021,
		},
		World5_Path2_Branch1_Node16 = {
			BranchRoot = "World5_Path2_Branch1_Node1",
			Seed = 5021,
			ChildIdList = {
				"World5_Path2_Branch1_Node17",
			},
			EventPool = 810021,
		},
		World5_Path2_Branch1_Node17 = {
			BranchRoot = "World5_Path2_Branch1_Node1",
			Seed = 5021,
			ChildIdList = {
				"World5_Path2_Branch1_Node18",
			},
			EventPool = 810020,
		},
		World5_Path2_Branch1_Node18 = {
			BranchRoot = "World5_Path2_Branch1_Node1",
			Seed = 5021,
			ChildIdList = {
				"World5_Path2_Branch1_Node19",
			},
			EventPool = 810016,
		},
		World5_Path2_Branch1_Node19 = {
			BranchRoot = "World5_Path2_Branch1_Node1",
			Seed = 5021,
			ChildIdList = {
				"World5_Path2_Branch1_Node20",
			},
			EventPool = 810024,
		},
		World5_Path2_Branch1_Node20 = {
			BranchRoot = "World5_Path2_Branch1_Node1",
			Seed = 5021,
			ChildIdList = {
				"World5_Path3_Branch1_Node1",
				"World5_Path3_Branch2_Node1",
			},
			EventPool = 810015,
		},
		World5_Path3_Branch1_Node1 = {
			BranchRoot = "World5_Path3_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 5031,
			ChildIdList = {
				"World5_Path3_Branch1_Node2",
			},
			EventPool = 810004,
		},
		World5_Path3_Branch1_Node2 = {
			BranchRoot = "World5_Path3_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 5031,
			ChildIdList = {
				"World5_Path3_Branch1_Node3",
			},
			EventPool = 810004,
		},
		World5_Path3_Branch1_Node3 = {
			BranchRoot = "World5_Path3_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 5031,
			ChildIdList = {
				"World5_Path3_Branch1_Node4",
			},
			EventPool = 810004,
		},
		World5_Path3_Branch1_Node4 = {
			BranchRoot = "World5_Path3_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 5031,
			ChildIdList = {
				"World5_Path3_Branch1_Node5",
			},
			EventPool = 810004,
		},
		World5_Path3_Branch1_Node5 = {
			BranchRoot = "World5_Path3_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 5031,
			ChildIdList = {
				"World5_Path3_Branch1_Node6",
			},
			EventPool = 810004,
		},
		World5_Path3_Branch1_Node6 = {
			BranchRoot = "World5_Path3_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 5031,
			ChildIdList = {
				"World5_Path3_Branch1_Node7",
			},
			EventPool = 810004,
		},
		World5_Path3_Branch1_Node7 = {
			BranchRoot = "World5_Path3_Branch1_Node1",
			Seed = 5031,
			ChildIdList = {
				"World5_Path3_Branch1_Node8",
			},
			EventPool = 810016,
		},
		World5_Path3_Branch1_Node8 = {
			BranchRoot = "World5_Path3_Branch1_Node1",
			Seed = 5031,
			ChildIdList = {
				"World5_Path3_Branch1_Node9",
			},
			EventPool = 810021,
		},
		World5_Path3_Branch1_Node9 = {
			BranchRoot = "World5_Path3_Branch1_Node1",
			Seed = 5031,
			ChildIdList = {
				"World5_Path3_Branch1_Node10",
			},
			EventPool = 810025,
		},
		World5_Path3_Branch1_Node10 = {
			BranchRoot = "World5_Path3_Branch1_Node1",
			Seed = 5031,
			ChildIdList = {
				"World5_Path3_Branch1_Node11",
			},
			EventPool = 810021,
		},
		World5_Path3_Branch1_Node11 = {
			BranchRoot = "World5_Path3_Branch1_Node1",
			Seed = 5031,
			ChildIdList = {
				"World5_Path3_Branch1_Node12",
			},
			EventPool = 810021,
		},
		World5_Path3_Branch1_Node12 = {
			BranchRoot = "World5_Path3_Branch1_Node1",
			Seed = 5031,
			ChildIdList = {
				"World5_Path3_Branch1_Node13",
			},
			EventPool = 810016,
		},
		World5_Path3_Branch1_Node13 = {
			BranchRoot = "World5_Path3_Branch1_Node1",
			Seed = 5031,
			ChildIdList = {
				"World5_Path3_Branch1_Node14",
			},
			EventPool = 810014,
		},
		World5_Path3_Branch1_Node14 = {
			BranchRoot = "World5_Path3_Branch1_Node1",
			Seed = 5031,
			ChildIdList = {
				"World5_Path3_Branch1_Node15",
			},
			EventPool = 810015,
		},
		World5_Path3_Branch1_Node15 = {
			BranchRoot = "World5_Path3_Branch1_Node1",
			Seed = 5031,
			ChildIdList = {
				"World5_Path3_Branch1_Node16",
			},
			EventPool = 810016,
		},
		World5_Path3_Branch1_Node16 = {
			BranchRoot = "World5_Path3_Branch1_Node1",
			Seed = 5031,
			ChildIdList = {
				"World5_Path3_Branch1_Node17",
			},
			EventPool = 810020,
		},
		World5_Path3_Branch1_Node17 = {
			BranchRoot = "World5_Path3_Branch1_Node1",
			Seed = 5031,
			ChildIdList = {
				"World5_Path3_Branch1_Node18",
			},
			EventPool = 810014,
		},
		World5_Path3_Branch1_Node18 = {
			BranchRoot = "World5_Path3_Branch1_Node1",
			Seed = 5031,
			ChildIdList = {
				"World5_Path3_Branch1_Node19",
			},
			EventPool = 810014,
		},
		World5_Path3_Branch1_Node19 = {
			BranchRoot = "World5_Path3_Branch1_Node1",
			Seed = 5031,
			ChildIdList = {
				"World5_Path3_Branch1_Node20",
			},
			EventPool = 810025,
		},
		World5_Path3_Branch1_Node20 = {
			BranchRoot = "World5_Path3_Branch1_Node1",
			Seed = 5031,
			ChildIdList = {
				"World5_Path4_Branch1_Node1",
				"World5_Path4_Branch2_Node1",
			},
			EventPool = 810021,
		},
		World5_Path4_Branch1_Node1 = {
			BranchRoot = "World5_Path4_Branch1_Node1",
			Seed = 5041,
			ChildIdList = {
				"World5_Path4_Branch1_Node2",
			},
			EventPool = 810020,
		},
		World5_Path4_Branch1_Node2 = {
			BranchRoot = "World5_Path4_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 5041,
			ChildIdList = {
				"World5_Path4_Branch1_Node3",
			},
			EventPool = 810005,
		},
		World5_Path4_Branch1_Node3 = {
			BranchRoot = "World5_Path4_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 5041,
			ChildIdList = {
				"World5_Path4_Branch1_Node4",
			},
			EventPool = 810005,
		},
		World5_Path4_Branch1_Node4 = {
			BranchRoot = "World5_Path4_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 5041,
			ChildIdList = {
				"World5_Path4_Branch1_Node5",
			},
			EventPool = 810005,
		},
		World5_Path4_Branch1_Node5 = {
			BranchRoot = "World5_Path4_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 5041,
			ChildIdList = {
				"World5_Path4_Branch1_Node6",
			},
			EventPool = 810005,
		},
		World5_Path4_Branch1_Node6 = {
			BranchRoot = "World5_Path4_Branch1_Node1",
			Seed = 5041,
			ChildIdList = {
				"World5_Path4_Branch1_Node7",
			},
			EventPool = 810015,
		},
		World5_Path4_Branch1_Node7 = {
			BranchRoot = "World5_Path4_Branch1_Node1",
			Seed = 5041,
			ChildIdList = {
				"World5_Path4_Branch1_Node8",
			},
			EventPool = 810026,
		},
		World5_Path4_Branch1_Node8 = {
			BranchRoot = "World5_Path4_Branch1_Node1",
			Seed = 5041,
			ChildIdList = {
				"World5_Path4_Branch1_Node9",
			},
			EventPool = 810021,
		},
		World5_Path4_Branch1_Node9 = {
			BranchRoot = "World5_Path4_Branch1_Node1",
			Seed = 5041,
			ChildIdList = {
				"World5_Path4_Branch1_Node10",
			},
			EventPool = 810024,
		},
		World5_Path4_Branch1_Node10 = {
			BranchRoot = "World5_Path4_Branch1_Node1",
			Seed = 5041,
			ChildIdList = {
				"World5_Path4_Branch1_Node11",
			},
			EventPool = 810022,
		},
		World5_Path4_Branch1_Node11 = {
			BranchRoot = "World5_Path4_Branch1_Node1",
			Seed = 5041,
			ChildIdList = {
				"World5_Path4_Branch1_Node12",
			},
			EventPool = 810016,
		},
		World5_Path4_Branch1_Node12 = {
			BranchRoot = "World5_Path4_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 5041,
			ChildIdList = {
				"World5_Path4_Branch1_Node13",
			},
			EventPool = 810004,
		},
		World5_Path4_Branch1_Node13 = {
			BranchRoot = "World5_Path4_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 5041,
			ChildIdList = {
				"World5_Path4_Branch1_Node14",
			},
			EventPool = 810004,
		},
		World5_Path4_Branch1_Node14 = {
			BranchRoot = "World5_Path4_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 5041,
			ChildIdList = {
				"World5_Path4_Branch1_Node15",
			},
			EventPool = 810004,
		},
		World5_Path4_Branch1_Node15 = {
			BranchRoot = "World5_Path4_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 5041,
			ChildIdList = {
				"World5_Path4_Branch1_Node16",
			},
			EventPool = 810004,
		},
		World5_Path4_Branch1_Node16 = {
			BranchRoot = "World5_Path4_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 5041,
			ChildIdList = {
				"World5_Path4_Branch1_Node17",
			},
			EventPool = 810004,
		},
		World5_Path4_Branch1_Node17 = {
			BranchRoot = "World5_Path4_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 5041,
			ChildIdList = {
				"World5_Path4_Branch1_Node18",
			},
			EventPool = 810004,
		},
		World5_Path4_Branch1_Node18 = {
			BranchRoot = "World5_Path4_Branch1_Node1",
			Seed = 5041,
			ChildIdList = {
				"World5_Path4_Branch1_Node19",
			},
			EventPool = 810014,
		},
		World5_Path4_Branch1_Node19 = {
			BranchRoot = "World5_Path4_Branch1_Node1",
			Seed = 5041,
			ChildIdList = {
				"World5_Path4_Branch1_Node20",
			},
			EventPool = 810024,
		},
		World5_Path4_Branch1_Node20 = {
			BranchRoot = "World5_Path4_Branch1_Node1",
			Seed = 5041,
			ChildIdList = {
				"World5_Path5_Branch1_Node1",
				"World5_Path5_Branch2_Node1",
			},
			EventPool = 810016,
		},
		World5_Path5_Branch1_Node1 = {
			BranchRoot = "World5_Path5_Branch1_Node1",
			Seed = 5051,
			ChildIdList = {
				"World5_Path5_Branch1_Node2",
			},
			EventPool = 810016,
		},
		World5_Path5_Branch1_Node2 = {
			BranchRoot = "World5_Path5_Branch1_Node1",
			Seed = 5051,
			ChildIdList = {
				"World5_Path5_Branch1_Node3",
			},
			EventPool = 810014,
		},
		World5_Path5_Branch1_Node3 = {
			BranchRoot = "World5_Path5_Branch1_Node1",
			StepScore = 50,
			Seed = 5051,
			ChildIdList = {
				"World5_Path5_Branch1_Node4",
			},
			EventPool = 810006,
		},
		World5_Path5_Branch1_Node4 = {
			BranchRoot = "World5_Path5_Branch1_Node1",
			Seed = 5051,
			ChildIdList = {
				"World5_Path5_Branch1_Node5",
			},
			EventPool = 810016,
		},
		World5_Path5_Branch1_Node5 = {
			BranchRoot = "World5_Path5_Branch1_Node1",
			Seed = 5051,
			ChildIdList = {
				"World5_Path5_Branch1_Node6",
			},
			EventPool = 810014,
		},
		World5_Path5_Branch1_Node6 = {
			BranchRoot = "World5_Path5_Branch1_Node1",
			Seed = 5051,
			ChildIdList = {
				"World5_Path5_Branch1_Node7",
			},
			EventPool = 810014,
		},
		World5_Path5_Branch1_Node7 = {
			BranchRoot = "World5_Path5_Branch1_Node1",
			Seed = 5051,
			ChildIdList = {
				"World5_Path5_Branch1_Node8",
			},
			EventPool = 810014,
		},
		World5_Path5_Branch1_Node8 = {
			BranchRoot = "World5_Path5_Branch1_Node1",
			Seed = 5051,
			ChildIdList = {
				"World5_Path5_Branch1_Node9",
			},
			EventPool = 810022,
		},
		World5_Path5_Branch1_Node9 = {
			BranchRoot = "World5_Path5_Branch1_Node1",
			Seed = 5051,
			ChildIdList = {
				"World5_Path5_Branch1_Node10",
			},
			EventPool = 810025,
		},
		World5_Path5_Branch1_Node10 = {
			BranchRoot = "World5_Path5_Branch1_Node1",
			Seed = 5051,
			ChildIdList = {
				"World5_Path5_Branch1_Node11",
			},
			EventPool = 810022,
		},
		World5_Path5_Branch1_Node11 = {
			BranchRoot = "World5_Path5_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 5051,
			ChildIdList = {
				"World5_Path5_Branch1_Node12",
			},
			EventPool = 810005,
		},
		World5_Path5_Branch1_Node12 = {
			BranchRoot = "World5_Path5_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 5051,
			ChildIdList = {
				"World5_Path5_Branch1_Node13",
			},
			EventPool = 810005,
		},
		World5_Path5_Branch1_Node13 = {
			BranchRoot = "World5_Path5_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 5051,
			ChildIdList = {
				"World5_Path5_Branch1_Node14",
			},
			EventPool = 810005,
		},
		World5_Path5_Branch1_Node14 = {
			BranchRoot = "World5_Path5_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 5051,
			ChildIdList = {
				"World5_Path5_Branch1_Node15",
			},
			EventPool = 810005,
		},
		World5_Path5_Branch1_Node15 = {
			BranchRoot = "World5_Path5_Branch1_Node1",
			Seed = 5051,
			ChildIdList = {
				"World5_Path5_Branch1_Node16",
			},
			EventPool = 810016,
		},
		World5_Path5_Branch1_Node16 = {
			BranchRoot = "World5_Path5_Branch1_Node1",
			Seed = 5051,
			ChildIdList = {
				"World5_Path5_Branch1_Node17",
			},
			EventPool = 810016,
		},
		World5_Path5_Branch1_Node17 = {
			BranchRoot = "World5_Path5_Branch1_Node1",
			Seed = 5051,
			ChildIdList = {
				"World5_Path5_Branch1_Node18",
			},
			EventPool = 810016,
		},
		World5_Path5_Branch1_Node18 = {
			BranchRoot = "World5_Path5_Branch1_Node1",
			Seed = 5051,
			ChildIdList = {
				"World5_Path5_Branch1_Node19",
			},
			EventPool = 810026,
		},
		World5_Path5_Branch1_Node19 = {
			BranchRoot = "World5_Path5_Branch1_Node1",
			Seed = 5051,
			ChildIdList = {
				"World5_Path5_Branch1_Node20",
			},
			EventPool = 810025,
		},
		World5_Path5_Branch1_Node20 = {
			BranchRoot = "World5_Path5_Branch1_Node1",
			Seed = 5051,
			ChildIdList = {
				"World5_Path6_Branch1_Node1",
				"World5_Path6_Branch2_Node1",
			},
			EventPool = 810016,
		},
		World5_Path6_Branch1_Node1 = {
			BranchRoot = "World5_Path6_Branch1_Node1",
			Seed = 5061,
			ChildIdList = {
				"World5_Path6_Branch1_Node2",
			},
			EventPool = 810021,
		},
		World5_Path6_Branch1_Node2 = {
			BranchRoot = "World5_Path6_Branch1_Node1",
			Seed = 5061,
			ChildIdList = {
				"World5_Path6_Branch1_Node3",
			},
			EventPool = 810020,
		},
		World5_Path6_Branch1_Node3 = {
			BranchRoot = "World5_Path6_Branch1_Node1",
			Seed = 5061,
			ChildIdList = {
				"World5_Path6_Branch1_Node4",
			},
			EventPool = 810021,
		},
		World5_Path6_Branch1_Node4 = {
			BranchRoot = "World5_Path6_Branch1_Node1",
			Seed = 5061,
			ChildIdList = {
				"World5_Path6_Branch1_Node5",
			},
			EventPool = 810016,
		},
		World5_Path6_Branch1_Node5 = {
			BranchRoot = "World5_Path6_Branch1_Node1",
			Seed = 5061,
			ChildIdList = {
				"World5_Path6_Branch1_Node6",
			},
			EventPool = 810016,
		},
		World5_Path6_Branch1_Node6 = {
			BranchRoot = "World5_Path6_Branch1_Node1",
			Seed = 5061,
			ChildIdList = {
				"World5_Path6_Branch1_Node7",
			},
			EventPool = 810014,
		},
		World5_Path6_Branch1_Node7 = {
			BranchRoot = "World5_Path6_Branch1_Node1",
			Seed = 5061,
			ChildIdList = {
				"World5_Path6_Branch1_Node8",
			},
			EventPool = 810026,
		},
		World5_Path6_Branch1_Node8 = {
			BranchRoot = "World5_Path6_Branch1_Node1",
			Seed = 5061,
			ChildIdList = {
				"World5_Path6_Branch1_Node9",
			},
			EventPool = 810021,
		},
		World5_Path6_Branch1_Node9 = {
			BranchRoot = "World5_Path6_Branch1_Node1",
			Seed = 5061,
			ChildIdList = {
				"World5_Path6_Branch1_Node10",
			},
			EventPool = 810024,
		},
		World5_Path6_Branch1_Node10 = {
			BranchRoot = "World5_Path6_Branch1_Node1",
			Seed = 5061,
			ChildIdList = {
				"World5_Path6_Branch1_Node11",
			},
			EventPool = 810021,
		},
		World5_Path6_Branch1_Node11 = {
			BranchRoot = "World5_Path6_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 5061,
			ChildIdList = {
				"World5_Path6_Branch1_Node12",
			},
			EventPool = 810004,
		},
		World5_Path6_Branch1_Node12 = {
			BranchRoot = "World5_Path6_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 5061,
			ChildIdList = {
				"World5_Path6_Branch1_Node13",
			},
			EventPool = 810004,
		},
		World5_Path6_Branch1_Node13 = {
			BranchRoot = "World5_Path6_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 5061,
			ChildIdList = {
				"World5_Path6_Branch1_Node14",
			},
			EventPool = 810004,
		},
		World5_Path6_Branch1_Node14 = {
			BranchRoot = "World5_Path6_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 5061,
			ChildIdList = {
				"World5_Path6_Branch1_Node15",
			},
			EventPool = 810004,
		},
		World5_Path6_Branch1_Node15 = {
			BranchRoot = "World5_Path6_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 5061,
			ChildIdList = {
				"World5_Path6_Branch1_Node16",
			},
			EventPool = 810004,
		},
		World5_Path6_Branch1_Node16 = {
			BranchRoot = "World5_Path6_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 5061,
			ChildIdList = {
				"World5_Path6_Branch1_Node17",
			},
			EventPool = 810004,
		},
		World5_Path6_Branch1_Node17 = {
			BranchRoot = "World5_Path6_Branch1_Node1",
			Seed = 5061,
			ChildIdList = {
				"World5_Path6_Branch1_Node18",
			},
			EventPool = 810016,
		},
		World5_Path6_Branch1_Node18 = {
			BranchRoot = "World5_Path6_Branch1_Node1",
			Seed = 5061,
			ChildIdList = {
				"World5_Path6_Branch1_Node19",
			},
			EventPool = 810015,
		},
		World5_Path6_Branch1_Node19 = {
			BranchRoot = "World5_Path6_Branch1_Node1",
			Seed = 5061,
			ChildIdList = {
				"World5_Path6_Branch1_Node20",
			},
			EventPool = 810026,
		},
		World5_Path6_Branch1_Node20 = {
			BranchRoot = "World5_Path6_Branch1_Node1",
			Seed = 5061,
			EventPool = 810023,
		},
		World5_Path2_Branch2_Node1 = {
			BranchRoot = "World5_Path2_Branch2_Node1",
			Seed = 5022,
			ChildIdList = {
				"World5_Path2_Branch2_Node2",
			},
			EventPool = 810016,
		},
		World5_Path2_Branch2_Node2 = {
			BranchRoot = "World5_Path2_Branch2_Node1",
			Seed = 5022,
			ChildIdList = {
				"World5_Path2_Branch2_Node3",
			},
			EventPool = 810016,
		},
		World5_Path2_Branch2_Node3 = {
			BranchRoot = "World5_Path2_Branch2_Node1",
			Seed = 5022,
			ChildIdList = {
				"World5_Path2_Branch2_Node4",
			},
			EventPool = 810026,
		},
		World5_Path2_Branch2_Node4 = {
			BranchRoot = "World5_Path2_Branch2_Node1",
			Seed = 5022,
			ChildIdList = {
				"World5_Path2_Branch2_Node5",
			},
			EventPool = 810016,
		},
		World5_Path2_Branch2_Node5 = {
			BranchRoot = "World5_Path2_Branch2_Node1",
			StepScore = 50,
			Seed = 5022,
			ChildIdList = {
				"World5_Path2_Branch2_Node6",
			},
			EventPool = 810006,
		},
		World5_Path2_Branch2_Node6 = {
			BranchRoot = "World5_Path2_Branch2_Node1",
			Seed = 5022,
			ChildIdList = {
				"World5_Path2_Branch2_Node7",
			},
			EventPool = 810022,
		},
		World5_Path2_Branch2_Node7 = {
			BranchRoot = "World5_Path2_Branch2_Node1",
			Seed = 5022,
			ChildIdList = {
				"World5_Path2_Branch2_Node8",
			},
			EventPool = 810020,
		},
		World5_Path2_Branch2_Node8 = {
			BranchRoot = "World5_Path2_Branch2_Node1",
			Seed = 5022,
			ChildIdList = {
				"World5_Path2_Branch2_Node9",
			},
			EventPool = 810026,
		},
		World5_Path2_Branch2_Node9 = {
			BranchRoot = "World5_Path2_Branch2_Node1",
			Seed = 5022,
			ChildIdList = {
				"World5_Path2_Branch2_Node10",
			},
			EventPool = 810025,
		},
		World5_Path2_Branch2_Node10 = {
			BranchRoot = "World5_Path2_Branch2_Node1",
			Seed = 5022,
			ChildIdList = {
				"World5_Path2_Branch2_Node11",
			},
			EventPool = 810026,
		},
		World5_Path2_Branch2_Node11 = {
			BranchRoot = "World5_Path2_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 5022,
			ChildIdList = {
				"World5_Path2_Branch2_Node12",
			},
			EventPool = 810005,
		},
		World5_Path2_Branch2_Node12 = {
			BranchRoot = "World5_Path2_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 5022,
			ChildIdList = {
				"World5_Path2_Branch2_Node13",
			},
			EventPool = 810005,
		},
		World5_Path2_Branch2_Node13 = {
			BranchRoot = "World5_Path2_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 5022,
			ChildIdList = {
				"World5_Path2_Branch2_Node14",
			},
			EventPool = 810005,
		},
		World5_Path2_Branch2_Node14 = {
			BranchRoot = "World5_Path2_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 5022,
			ChildIdList = {
				"World5_Path2_Branch2_Node15",
			},
			EventPool = 810005,
		},
		World5_Path2_Branch2_Node15 = {
			BranchRoot = "World5_Path2_Branch2_Node1",
			Seed = 5022,
			ChildIdList = {
				"World5_Path2_Branch2_Node16",
			},
			EventPool = 810026,
		},
		World5_Path2_Branch2_Node16 = {
			BranchRoot = "World5_Path2_Branch2_Node1",
			Seed = 5022,
			ChildIdList = {
				"World5_Path2_Branch2_Node17",
			},
			EventPool = 810022,
		},
		World5_Path2_Branch2_Node17 = {
			BranchRoot = "World5_Path2_Branch2_Node1",
			Seed = 5022,
			ChildIdList = {
				"World5_Path2_Branch2_Node18",
			},
			EventPool = 810026,
		},
		World5_Path2_Branch2_Node18 = {
			BranchRoot = "World5_Path2_Branch2_Node1",
			Seed = 5022,
			ChildIdList = {
				"World5_Path2_Branch2_Node19",
			},
			EventPool = 810014,
		},
		World5_Path2_Branch2_Node19 = {
			BranchRoot = "World5_Path2_Branch2_Node1",
			Seed = 5022,
			ChildIdList = {
				"World5_Path2_Branch2_Node20",
			},
			EventPool = 810024,
		},
		World5_Path2_Branch2_Node20 = {
			BranchRoot = "World5_Path2_Branch2_Node1",
			Seed = 5022,
			ChildIdList = {
				"World5_Path3_Branch1_Node1",
				"World5_Path3_Branch2_Node1",
			},
			EventPool = 810016,
		},
		World5_Path3_Branch2_Node1 = {
			BranchRoot = "World5_Path3_Branch2_Node1",
			Seed = 5032,
			ChildIdList = {
				"World5_Path3_Branch2_Node2",
			},
			EventPool = 810022,
		},
		World5_Path3_Branch2_Node2 = {
			BranchRoot = "World5_Path3_Branch2_Node1",
			Seed = 5032,
			ChildIdList = {
				"World5_Path3_Branch2_Node3",
			},
			EventPool = 810016,
		},
		World5_Path3_Branch2_Node3 = {
			BranchRoot = "World5_Path3_Branch2_Node1",
			Seed = 5032,
			ChildIdList = {
				"World5_Path3_Branch2_Node4",
			},
			EventPool = 810015,
		},
		World5_Path3_Branch2_Node4 = {
			BranchRoot = "World5_Path3_Branch2_Node1",
			StepScore = 50,
			Seed = 5032,
			ChildIdList = {
				"World5_Path3_Branch2_Node5",
			},
			EventPool = 810006,
		},
		World5_Path3_Branch2_Node5 = {
			BranchRoot = "World5_Path3_Branch2_Node1",
			Seed = 5032,
			ChildIdList = {
				"World5_Path3_Branch2_Node6",
			},
			EventPool = 810014,
		},
		World5_Path3_Branch2_Node6 = {
			BranchRoot = "World5_Path3_Branch2_Node1",
			Seed = 5032,
			ChildIdList = {
				"World5_Path3_Branch2_Node7",
			},
			EventPool = 810021,
		},
		World5_Path3_Branch2_Node7 = {
			BranchRoot = "World5_Path3_Branch2_Node1",
			Seed = 5032,
			ChildIdList = {
				"World5_Path3_Branch2_Node8",
			},
			EventPool = 810026,
		},
		World5_Path3_Branch2_Node8 = {
			BranchRoot = "World5_Path3_Branch2_Node1",
			Seed = 5032,
			ChildIdList = {
				"World5_Path3_Branch2_Node9",
			},
			EventPool = 810022,
		},
		World5_Path3_Branch2_Node9 = {
			BranchRoot = "World5_Path3_Branch2_Node1",
			Seed = 5032,
			ChildIdList = {
				"World5_Path3_Branch2_Node10",
			},
			EventPool = 810025,
		},
		World5_Path3_Branch2_Node10 = {
			BranchRoot = "World5_Path3_Branch2_Node1",
			Seed = 5032,
			ChildIdList = {
				"World5_Path3_Branch2_Node11",
			},
			EventPool = 810016,
		},
		World5_Path3_Branch2_Node11 = {
			BranchRoot = "World5_Path3_Branch2_Node1",
			Seed = 5032,
			ChildIdList = {
				"World5_Path3_Branch2_Node12",
			},
			EventPool = 810026,
		},
		World5_Path3_Branch2_Node12 = {
			BranchRoot = "World5_Path3_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 5032,
			ChildIdList = {
				"World5_Path3_Branch2_Node13",
			},
			EventPool = 810004,
		},
		World5_Path3_Branch2_Node13 = {
			BranchRoot = "World5_Path3_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 5032,
			ChildIdList = {
				"World5_Path3_Branch2_Node14",
			},
			EventPool = 810004,
		},
		World5_Path3_Branch2_Node14 = {
			BranchRoot = "World5_Path3_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 5032,
			ChildIdList = {
				"World5_Path3_Branch2_Node15",
			},
			EventPool = 810004,
		},
		World5_Path3_Branch2_Node15 = {
			BranchRoot = "World5_Path3_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 5032,
			ChildIdList = {
				"World5_Path3_Branch2_Node16",
			},
			EventPool = 810004,
		},
		World5_Path3_Branch2_Node16 = {
			BranchRoot = "World5_Path3_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 5032,
			ChildIdList = {
				"World5_Path3_Branch2_Node17",
			},
			EventPool = 810004,
		},
		World5_Path3_Branch2_Node17 = {
			BranchRoot = "World5_Path3_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 5032,
			ChildIdList = {
				"World5_Path3_Branch2_Node18",
			},
			EventPool = 810004,
		},
		World5_Path3_Branch2_Node18 = {
			BranchRoot = "World5_Path3_Branch2_Node1",
			Seed = 5032,
			ChildIdList = {
				"World5_Path3_Branch2_Node19",
			},
			EventPool = 810014,
		},
		World5_Path3_Branch2_Node19 = {
			BranchRoot = "World5_Path3_Branch2_Node1",
			Seed = 5032,
			ChildIdList = {
				"World5_Path3_Branch2_Node20",
			},
			EventPool = 810024,
		},
		World5_Path3_Branch2_Node20 = {
			BranchRoot = "World5_Path3_Branch2_Node1",
			Seed = 5032,
			ChildIdList = {
				"World5_Path4_Branch1_Node1",
				"World5_Path4_Branch2_Node1",
			},
			EventPool = 810021,
		},
		World5_Path4_Branch2_Node1 = {
			BranchRoot = "World5_Path4_Branch2_Node1",
			Seed = 5042,
			ChildIdList = {
				"World5_Path4_Branch2_Node2",
			},
			EventPool = 810015,
		},
		World5_Path4_Branch2_Node2 = {
			BranchRoot = "World5_Path4_Branch2_Node1",
			Seed = 5042,
			ChildIdList = {
				"World5_Path4_Branch2_Node3",
			},
			EventPool = 810026,
		},
		World5_Path4_Branch2_Node3 = {
			BranchRoot = "World5_Path4_Branch2_Node1",
			Seed = 5042,
			ChildIdList = {
				"World5_Path4_Branch2_Node4",
			},
			EventPool = 810021,
		},
		World5_Path4_Branch2_Node4 = {
			BranchRoot = "World5_Path4_Branch2_Node1",
			Seed = 5042,
			ChildIdList = {
				"World5_Path4_Branch2_Node5",
			},
			EventPool = 810020,
		},
		World5_Path4_Branch2_Node5 = {
			BranchRoot = "World5_Path4_Branch2_Node1",
			Seed = 5042,
			ChildIdList = {
				"World5_Path4_Branch2_Node6",
			},
			EventPool = 810026,
		},
		World5_Path4_Branch2_Node6 = {
			BranchRoot = "World5_Path4_Branch2_Node1",
			Seed = 5042,
			ChildIdList = {
				"World5_Path4_Branch2_Node7",
			},
			EventPool = 810016,
		},
		World5_Path4_Branch2_Node7 = {
			BranchRoot = "World5_Path4_Branch2_Node1",
			Seed = 5042,
			ChildIdList = {
				"World5_Path4_Branch2_Node8",
			},
			EventPool = 810026,
		},
		World5_Path4_Branch2_Node8 = {
			BranchRoot = "World5_Path4_Branch2_Node1",
			Seed = 5042,
			ChildIdList = {
				"World5_Path4_Branch2_Node9",
			},
			EventPool = 810022,
		},
		World5_Path4_Branch2_Node9 = {
			BranchRoot = "World5_Path4_Branch2_Node1",
			Seed = 5042,
			ChildIdList = {
				"World5_Path4_Branch2_Node10",
			},
			EventPool = 810024,
		},
		World5_Path4_Branch2_Node10 = {
			BranchRoot = "World5_Path4_Branch2_Node1",
			Seed = 5042,
			ChildIdList = {
				"World5_Path4_Branch2_Node11",
			},
			EventPool = 810020,
		},
		World5_Path4_Branch2_Node11 = {
			BranchRoot = "World5_Path4_Branch2_Node1",
			Seed = 5042,
			ChildIdList = {
				"World5_Path4_Branch2_Node12",
			},
			EventPool = 810026,
		},
		World5_Path4_Branch2_Node12 = {
			BranchRoot = "World5_Path4_Branch2_Node1",
			Seed = 5042,
			ChildIdList = {
				"World5_Path4_Branch2_Node13",
			},
			EventPool = 810014,
		},
		World5_Path4_Branch2_Node13 = {
			BranchRoot = "World5_Path4_Branch2_Node1",
			Seed = 5042,
			ChildIdList = {
				"World5_Path4_Branch2_Node14",
			},
			EventPool = 810022,
		},
		World5_Path4_Branch2_Node14 = {
			BranchRoot = "World5_Path4_Branch2_Node1",
			Seed = 5042,
			ChildIdList = {
				"World5_Path4_Branch2_Node15",
			},
			EventPool = 810016,
		},
		World5_Path4_Branch2_Node15 = {
			BranchRoot = "World5_Path4_Branch2_Node1",
			Seed = 5042,
			ChildIdList = {
				"World5_Path4_Branch2_Node16",
			},
			EventPool = 810015,
		},
		World5_Path4_Branch2_Node16 = {
			BranchRoot = "World5_Path4_Branch2_Node1",
			Seed = 5042,
			ChildIdList = {
				"World5_Path4_Branch2_Node17",
			},
			EventPool = 810020,
		},
		World5_Path4_Branch2_Node17 = {
			BranchRoot = "World5_Path4_Branch2_Node1",
			Seed = 5042,
			ChildIdList = {
				"World5_Path4_Branch2_Node18",
			},
			EventPool = 810014,
		},
		World5_Path4_Branch2_Node18 = {
			BranchRoot = "World5_Path4_Branch2_Node1",
			Seed = 5042,
			ChildIdList = {
				"World5_Path4_Branch2_Node19",
			},
			EventPool = 810026,
		},
		World5_Path4_Branch2_Node19 = {
			BranchRoot = "World5_Path4_Branch2_Node1",
			Seed = 5042,
			ChildIdList = {
				"World5_Path4_Branch2_Node20",
			},
			EventPool = 810024,
		},
		World5_Path4_Branch2_Node20 = {
			BranchRoot = "World5_Path4_Branch2_Node1",
			Seed = 5042,
			ChildIdList = {
				"World5_Path5_Branch1_Node1",
				"World5_Path5_Branch2_Node1",
			},
			EventPool = 810026,
		},
		World5_Path5_Branch2_Node1 = {
			BranchRoot = "World5_Path5_Branch2_Node1",
			Seed = 5052,
			ChildIdList = {
				"World5_Path5_Branch2_Node2",
			},
			EventPool = 810022,
		},
		World5_Path5_Branch2_Node2 = {
			BranchRoot = "World5_Path5_Branch2_Node1",
			Seed = 5052,
			ChildIdList = {
				"World5_Path5_Branch2_Node3",
			},
			EventPool = 810022,
		},
		World5_Path5_Branch2_Node3 = {
			BranchRoot = "World5_Path5_Branch2_Node1",
			Seed = 5052,
			ChildIdList = {
				"World5_Path5_Branch2_Node4",
			},
			EventPool = 810016,
		},
		World5_Path5_Branch2_Node4 = {
			BranchRoot = "World5_Path5_Branch2_Node1",
			StepScore = 50,
			Seed = 5052,
			ChildIdList = {
				"World5_Path5_Branch2_Node5",
			},
			EventPool = 810006,
		},
		World5_Path5_Branch2_Node5 = {
			BranchRoot = "World5_Path5_Branch2_Node1",
			Seed = 5052,
			ChildIdList = {
				"World5_Path5_Branch2_Node6",
			},
			EventPool = 810021,
		},
		World5_Path5_Branch2_Node6 = {
			BranchRoot = "World5_Path5_Branch2_Node1",
			Seed = 5052,
			ChildIdList = {
				"World5_Path5_Branch2_Node7",
			},
			EventPool = 810020,
		},
		World5_Path5_Branch2_Node7 = {
			BranchRoot = "World5_Path5_Branch2_Node1",
			Seed = 5052,
			ChildIdList = {
				"World5_Path5_Branch2_Node8",
			},
			EventPool = 810021,
		},
		World5_Path5_Branch2_Node8 = {
			BranchRoot = "World5_Path5_Branch2_Node1",
			Seed = 5052,
			ChildIdList = {
				"World5_Path5_Branch2_Node9",
			},
			EventPool = 810020,
		},
		World5_Path5_Branch2_Node9 = {
			BranchRoot = "World5_Path5_Branch2_Node1",
			Seed = 5052,
			ChildIdList = {
				"World5_Path5_Branch2_Node10",
			},
			EventPool = 810025,
		},
		World5_Path5_Branch2_Node10 = {
			BranchRoot = "World5_Path5_Branch2_Node1",
			Seed = 5052,
			ChildIdList = {
				"World5_Path5_Branch2_Node11",
			},
			EventPool = 810016,
		},
		World5_Path5_Branch2_Node11 = {
			BranchRoot = "World5_Path5_Branch2_Node1",
			Seed = 5052,
			ChildIdList = {
				"World5_Path5_Branch2_Node12",
			},
			EventPool = 810020,
		},
		World5_Path5_Branch2_Node12 = {
			BranchRoot = "World5_Path5_Branch2_Node1",
			Seed = 5052,
			ChildIdList = {
				"World5_Path5_Branch2_Node13",
			},
			EventPool = 810015,
		},
		World5_Path5_Branch2_Node13 = {
			BranchRoot = "World5_Path5_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 5052,
			ChildIdList = {
				"World5_Path5_Branch2_Node14",
			},
			EventPool = 810005,
		},
		World5_Path5_Branch2_Node14 = {
			BranchRoot = "World5_Path5_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 5052,
			ChildIdList = {
				"World5_Path5_Branch2_Node15",
			},
			EventPool = 810005,
		},
		World5_Path5_Branch2_Node15 = {
			BranchRoot = "World5_Path5_Branch2_Node1",
			StepScore = 50,
			Seed = 5052,
			ChildIdList = {
				"World5_Path5_Branch2_Node16",
			},
			EventPool = 810006,
		},
		World5_Path5_Branch2_Node16 = {
			BranchRoot = "World5_Path5_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 5052,
			ChildIdList = {
				"World5_Path5_Branch2_Node17",
			},
			EventPool = 810005,
		},
		World5_Path5_Branch2_Node17 = {
			BranchRoot = "World5_Path5_Branch2_Node1",
			Seed = 5052,
			ChildIdList = {
				"World5_Path5_Branch2_Node18",
			},
			EventPool = 810015,
		},
		World5_Path5_Branch2_Node18 = {
			BranchRoot = "World5_Path5_Branch2_Node1",
			Seed = 5052,
			ChildIdList = {
				"World5_Path5_Branch2_Node19",
			},
			EventPool = 810022,
		},
		World5_Path5_Branch2_Node19 = {
			BranchRoot = "World5_Path5_Branch2_Node1",
			Seed = 5052,
			ChildIdList = {
				"World5_Path5_Branch2_Node20",
			},
			EventPool = 810024,
		},
		World5_Path5_Branch2_Node20 = {
			BranchRoot = "World5_Path5_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 5052,
			ChildIdList = {
				"World5_Path6_Branch1_Node1",
				"World5_Path6_Branch2_Node1",
			},
			EventPool = 810004,
		},
		World5_Path6_Branch2_Node1 = {
			BranchRoot = "World5_Path6_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 5062,
			ChildIdList = {
				"World5_Path6_Branch2_Node2",
			},
			EventPool = 810004,
		},
		World5_Path6_Branch2_Node2 = {
			BranchRoot = "World5_Path6_Branch2_Node1",
			StepScore = 50,
			Seed = 5062,
			ChildIdList = {
				"World5_Path6_Branch2_Node3",
			},
			EventPool = 810006,
		},
		World5_Path6_Branch2_Node3 = {
			BranchRoot = "World5_Path6_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 5062,
			ChildIdList = {
				"World5_Path6_Branch2_Node4",
			},
			EventPool = 810004,
		},
		World5_Path6_Branch2_Node4 = {
			BranchRoot = "World5_Path6_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 5062,
			ChildIdList = {
				"World5_Path6_Branch2_Node5",
			},
			EventPool = 810004,
		},
		World5_Path6_Branch2_Node5 = {
			BranchRoot = "World5_Path6_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 5062,
			ChildIdList = {
				"World5_Path6_Branch2_Node6",
			},
			EventPool = 810004,
		},
		World5_Path6_Branch2_Node6 = {
			BranchRoot = "World5_Path6_Branch2_Node1",
			Seed = 5062,
			ChildIdList = {
				"World5_Path6_Branch2_Node7",
			},
			EventPool = 810015,
		},
		World5_Path6_Branch2_Node7 = {
			BranchRoot = "World5_Path6_Branch2_Node1",
			Seed = 5062,
			ChildIdList = {
				"World5_Path6_Branch2_Node8",
			},
			EventPool = 810022,
		},
		World5_Path6_Branch2_Node8 = {
			BranchRoot = "World5_Path6_Branch2_Node1",
			Seed = 5062,
			ChildIdList = {
				"World5_Path6_Branch2_Node9",
			},
			EventPool = 810014,
		},
		World5_Path6_Branch2_Node9 = {
			BranchRoot = "World5_Path6_Branch2_Node1",
			Seed = 5062,
			ChildIdList = {
				"World5_Path6_Branch2_Node10",
			},
			EventPool = 810025,
		},
		World5_Path6_Branch2_Node10 = {
			BranchRoot = "World5_Path6_Branch2_Node1",
			Seed = 5062,
			ChildIdList = {
				"World5_Path6_Branch2_Node11",
			},
			EventPool = 810016,
		},
		World5_Path6_Branch2_Node11 = {
			BranchRoot = "World5_Path6_Branch2_Node1",
			Seed = 5062,
			ChildIdList = {
				"World5_Path6_Branch2_Node12",
			},
			EventPool = 810015,
		},
		World5_Path6_Branch2_Node12 = {
			BranchRoot = "World5_Path6_Branch2_Node1",
			Seed = 5062,
			ChildIdList = {
				"World5_Path6_Branch2_Node13",
			},
			EventPool = 810015,
		},
		World5_Path6_Branch2_Node13 = {
			BranchRoot = "World5_Path6_Branch2_Node1",
			Seed = 5062,
			ChildIdList = {
				"World5_Path6_Branch2_Node14",
			},
			EventPool = 810014,
		},
		World5_Path6_Branch2_Node14 = {
			BranchRoot = "World5_Path6_Branch2_Node1",
			Seed = 5062,
			ChildIdList = {
				"World5_Path6_Branch2_Node15",
			},
			EventPool = 810016,
		},
		World5_Path6_Branch2_Node15 = {
			BranchRoot = "World5_Path6_Branch2_Node1",
			Seed = 5062,
			ChildIdList = {
				"World5_Path6_Branch2_Node16",
			},
			EventPool = 810020,
		},
		World5_Path6_Branch2_Node16 = {
			BranchRoot = "World5_Path6_Branch2_Node1",
			Seed = 5062,
			ChildIdList = {
				"World5_Path6_Branch2_Node17",
			},
			EventPool = 810016,
		},
		World5_Path6_Branch2_Node17 = {
			BranchRoot = "World5_Path6_Branch2_Node1",
			Seed = 5062,
			ChildIdList = {
				"World5_Path6_Branch2_Node18",
			},
			EventPool = 810020,
		},
		World5_Path6_Branch2_Node18 = {
			BranchRoot = "World5_Path6_Branch2_Node1",
			Seed = 5062,
			ChildIdList = {
				"World5_Path6_Branch2_Node19",
			},
			EventPool = 810020,
		},
		World5_Path6_Branch2_Node19 = {
			BranchRoot = "World5_Path6_Branch2_Node1",
			Seed = 5062,
			ChildIdList = {
				"World5_Path6_Branch2_Node20",
			},
			EventPool = 810021,
		},
		World5_Path6_Branch2_Node20 = {
			BranchRoot = "World5_Path6_Branch2_Node1",
			Seed = 5062,
			EventPool = 810023,
		},
	},
}
SpaceTravelMapConfig[SpaceTravelMapID.Id006] =
{
	Id = 6,
	WorldIndex = 6,
	Name = "联邦的宙域",
	FirstNode = "World6_Path1_Branch1_Node1",
	LastNodeList = {
		"World6_Path6_Branch1_Node20",
		"World6_Path6_Branch2_Node20",
	},
	RoundScore = 0,
	StepScore = 35,
	RoundFuelCost = 105,
	StepFuelCost = 0,
	RoundFoodCost = 0,
	StepFoodCost = 0,
	Nodes = {
		World6_Path1_Branch1_Node1 = {
			BranchRoot = "World6_Path1_Branch1_Node1",
			Seed = 6011,
			ChildIdList = {
				"World6_Path1_Branch1_Node2",
			},
			EventPool = 810016,
		},
		World6_Path1_Branch1_Node2 = {
			BranchRoot = "World6_Path1_Branch1_Node1",
			Seed = 6011,
			ChildIdList = {
				"World6_Path1_Branch1_Node3",
			},
			EventPool = 810016,
		},
		World6_Path1_Branch1_Node3 = {
			BranchRoot = "World6_Path1_Branch1_Node1",
			Seed = 6011,
			ChildIdList = {
				"World6_Path1_Branch1_Node4",
			},
			EventPool = 810026,
		},
		World6_Path1_Branch1_Node4 = {
			BranchRoot = "World6_Path1_Branch1_Node1",
			Seed = 6011,
			ChildIdList = {
				"World6_Path1_Branch1_Node5",
			},
			EventPool = 810014,
		},
		World6_Path1_Branch1_Node5 = {
			BranchRoot = "World6_Path1_Branch1_Node1",
			Seed = 6011,
			ChildIdList = {
				"World6_Path1_Branch1_Node6",
			},
			EventPool = 810021,
		},
		World6_Path1_Branch1_Node6 = {
			BranchRoot = "World6_Path1_Branch1_Node1",
			Seed = 6011,
			ChildIdList = {
				"World6_Path1_Branch1_Node7",
			},
			EventPool = 810014,
		},
		World6_Path1_Branch1_Node7 = {
			BranchRoot = "World6_Path1_Branch1_Node1",
			Seed = 6011,
			ChildIdList = {
				"World6_Path1_Branch1_Node8",
			},
			EventPool = 810026,
		},
		World6_Path1_Branch1_Node8 = {
			BranchRoot = "World6_Path1_Branch1_Node1",
			Seed = 6011,
			ChildIdList = {
				"World6_Path1_Branch1_Node9",
			},
			EventPool = 810020,
		},
		World6_Path1_Branch1_Node9 = {
			BranchRoot = "World6_Path1_Branch1_Node1",
			Seed = 6011,
			ChildIdList = {
				"World6_Path1_Branch1_Node10",
			},
			EventPool = 810024,
		},
		World6_Path1_Branch1_Node10 = {
			BranchRoot = "World6_Path1_Branch1_Node1",
			Seed = 6011,
			ChildIdList = {
				"World6_Path1_Branch1_Node11",
			},
			EventPool = 810016,
		},
		World6_Path1_Branch1_Node11 = {
			BranchRoot = "World6_Path1_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 6011,
			ChildIdList = {
				"World6_Path1_Branch1_Node12",
			},
			EventPool = 810004,
		},
		World6_Path1_Branch1_Node12 = {
			BranchRoot = "World6_Path1_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 6011,
			ChildIdList = {
				"World6_Path1_Branch1_Node13",
			},
			EventPool = 810004,
		},
		World6_Path1_Branch1_Node13 = {
			BranchRoot = "World6_Path1_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 6011,
			ChildIdList = {
				"World6_Path1_Branch1_Node14",
			},
			EventPool = 810004,
		},
		World6_Path1_Branch1_Node14 = {
			BranchRoot = "World6_Path1_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 6011,
			ChildIdList = {
				"World6_Path1_Branch1_Node15",
			},
			EventPool = 810004,
		},
		World6_Path1_Branch1_Node15 = {
			BranchRoot = "World6_Path1_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 6011,
			ChildIdList = {
				"World6_Path1_Branch1_Node16",
			},
			EventPool = 810004,
		},
		World6_Path1_Branch1_Node16 = {
			BranchRoot = "World6_Path1_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 6011,
			ChildIdList = {
				"World6_Path1_Branch1_Node17",
			},
			EventPool = 810004,
		},
		World6_Path1_Branch1_Node17 = {
			BranchRoot = "World6_Path1_Branch1_Node1",
			Seed = 6011,
			ChildIdList = {
				"World6_Path1_Branch1_Node18",
			},
			EventPool = 810015,
		},
		World6_Path1_Branch1_Node18 = {
			BranchRoot = "World6_Path1_Branch1_Node1",
			Seed = 6011,
			ChildIdList = {
				"World6_Path1_Branch1_Node19",
			},
			EventPool = 810014,
		},
		World6_Path1_Branch1_Node19 = {
			BranchRoot = "World6_Path1_Branch1_Node1",
			Seed = 6011,
			ChildIdList = {
				"World6_Path1_Branch1_Node20",
			},
			EventPool = 810024,
		},
		World6_Path1_Branch1_Node20 = {
			BranchRoot = "World6_Path1_Branch1_Node1",
			Seed = 6011,
			ChildIdList = {
				"World6_Path2_Branch1_Node1",
				"World6_Path2_Branch2_Node1",
			},
			EventPool = 810026,
		},
		World6_Path2_Branch1_Node1 = {
			BranchRoot = "World6_Path2_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 6021,
			ChildIdList = {
				"World6_Path2_Branch1_Node2",
			},
			EventPool = 810005,
		},
		World6_Path2_Branch1_Node2 = {
			BranchRoot = "World6_Path2_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 6021,
			ChildIdList = {
				"World6_Path2_Branch1_Node3",
			},
			EventPool = 810005,
		},
		World6_Path2_Branch1_Node3 = {
			BranchRoot = "World6_Path2_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 6021,
			ChildIdList = {
				"World6_Path2_Branch1_Node4",
			},
			EventPool = 810005,
		},
		World6_Path2_Branch1_Node4 = {
			BranchRoot = "World6_Path2_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 6021,
			ChildIdList = {
				"World6_Path2_Branch1_Node5",
			},
			EventPool = 810005,
		},
		World6_Path2_Branch1_Node5 = {
			BranchRoot = "World6_Path2_Branch1_Node1",
			Seed = 6021,
			ChildIdList = {
				"World6_Path2_Branch1_Node6",
			},
			EventPool = 810016,
		},
		World6_Path2_Branch1_Node6 = {
			BranchRoot = "World6_Path2_Branch1_Node1",
			Seed = 6021,
			ChildIdList = {
				"World6_Path2_Branch1_Node7",
			},
			EventPool = 810016,
		},
		World6_Path2_Branch1_Node7 = {
			BranchRoot = "World6_Path2_Branch1_Node1",
			Seed = 6021,
			ChildIdList = {
				"World6_Path2_Branch1_Node8",
			},
			EventPool = 810026,
		},
		World6_Path2_Branch1_Node8 = {
			BranchRoot = "World6_Path2_Branch1_Node1",
			Seed = 6021,
			ChildIdList = {
				"World6_Path2_Branch1_Node9",
			},
			EventPool = 810016,
		},
		World6_Path2_Branch1_Node9 = {
			BranchRoot = "World6_Path2_Branch1_Node1",
			Seed = 6021,
			ChildIdList = {
				"World6_Path2_Branch1_Node10",
			},
			EventPool = 810025,
		},
		World6_Path2_Branch1_Node10 = {
			BranchRoot = "World6_Path2_Branch1_Node1",
			Seed = 6021,
			ChildIdList = {
				"World6_Path2_Branch1_Node11",
			},
			EventPool = 810016,
		},
		World6_Path2_Branch1_Node11 = {
			BranchRoot = "World6_Path2_Branch1_Node1",
			Seed = 6021,
			ChildIdList = {
				"World6_Path2_Branch1_Node12",
			},
			EventPool = 810021,
		},
		World6_Path2_Branch1_Node12 = {
			BranchRoot = "World6_Path2_Branch1_Node1",
			Seed = 6021,
			ChildIdList = {
				"World6_Path2_Branch1_Node13",
			},
			EventPool = 810015,
		},
		World6_Path2_Branch1_Node13 = {
			BranchRoot = "World6_Path2_Branch1_Node1",
			Seed = 6021,
			ChildIdList = {
				"World6_Path2_Branch1_Node14",
			},
			EventPool = 810022,
		},
		World6_Path2_Branch1_Node14 = {
			BranchRoot = "World6_Path2_Branch1_Node1",
			StepScore = 50,
			Seed = 6021,
			ChildIdList = {
				"World6_Path2_Branch1_Node15",
			},
			EventPool = 810006,
		},
		World6_Path2_Branch1_Node15 = {
			BranchRoot = "World6_Path2_Branch1_Node1",
			Seed = 6021,
			ChildIdList = {
				"World6_Path2_Branch1_Node16",
			},
			EventPool = 810021,
		},
		World6_Path2_Branch1_Node16 = {
			BranchRoot = "World6_Path2_Branch1_Node1",
			Seed = 6021,
			ChildIdList = {
				"World6_Path2_Branch1_Node17",
			},
			EventPool = 810021,
		},
		World6_Path2_Branch1_Node17 = {
			BranchRoot = "World6_Path2_Branch1_Node1",
			Seed = 6021,
			ChildIdList = {
				"World6_Path2_Branch1_Node18",
			},
			EventPool = 810020,
		},
		World6_Path2_Branch1_Node18 = {
			BranchRoot = "World6_Path2_Branch1_Node1",
			Seed = 6021,
			ChildIdList = {
				"World6_Path2_Branch1_Node19",
			},
			EventPool = 810016,
		},
		World6_Path2_Branch1_Node19 = {
			BranchRoot = "World6_Path2_Branch1_Node1",
			Seed = 6021,
			ChildIdList = {
				"World6_Path2_Branch1_Node20",
			},
			EventPool = 810024,
		},
		World6_Path2_Branch1_Node20 = {
			BranchRoot = "World6_Path2_Branch1_Node1",
			Seed = 6021,
			ChildIdList = {
				"World6_Path3_Branch1_Node1",
				"World6_Path3_Branch2_Node1",
			},
			EventPool = 810015,
		},
		World6_Path3_Branch1_Node1 = {
			BranchRoot = "World6_Path3_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 6031,
			ChildIdList = {
				"World6_Path3_Branch1_Node2",
			},
			EventPool = 810004,
		},
		World6_Path3_Branch1_Node2 = {
			BranchRoot = "World6_Path3_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 6031,
			ChildIdList = {
				"World6_Path3_Branch1_Node3",
			},
			EventPool = 810004,
		},
		World6_Path3_Branch1_Node3 = {
			BranchRoot = "World6_Path3_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 6031,
			ChildIdList = {
				"World6_Path3_Branch1_Node4",
			},
			EventPool = 810004,
		},
		World6_Path3_Branch1_Node4 = {
			BranchRoot = "World6_Path3_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 6031,
			ChildIdList = {
				"World6_Path3_Branch1_Node5",
			},
			EventPool = 810004,
		},
		World6_Path3_Branch1_Node5 = {
			BranchRoot = "World6_Path3_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 6031,
			ChildIdList = {
				"World6_Path3_Branch1_Node6",
			},
			EventPool = 810004,
		},
		World6_Path3_Branch1_Node6 = {
			BranchRoot = "World6_Path3_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 6031,
			ChildIdList = {
				"World6_Path3_Branch1_Node7",
			},
			EventPool = 810004,
		},
		World6_Path3_Branch1_Node7 = {
			BranchRoot = "World6_Path3_Branch1_Node1",
			Seed = 6031,
			ChildIdList = {
				"World6_Path3_Branch1_Node8",
			},
			EventPool = 810016,
		},
		World6_Path3_Branch1_Node8 = {
			BranchRoot = "World6_Path3_Branch1_Node1",
			Seed = 6031,
			ChildIdList = {
				"World6_Path3_Branch1_Node9",
			},
			EventPool = 810021,
		},
		World6_Path3_Branch1_Node9 = {
			BranchRoot = "World6_Path3_Branch1_Node1",
			Seed = 6031,
			ChildIdList = {
				"World6_Path3_Branch1_Node10",
			},
			EventPool = 810025,
		},
		World6_Path3_Branch1_Node10 = {
			BranchRoot = "World6_Path3_Branch1_Node1",
			Seed = 6031,
			ChildIdList = {
				"World6_Path3_Branch1_Node11",
			},
			EventPool = 810021,
		},
		World6_Path3_Branch1_Node11 = {
			BranchRoot = "World6_Path3_Branch1_Node1",
			Seed = 6031,
			ChildIdList = {
				"World6_Path3_Branch1_Node12",
			},
			EventPool = 810021,
		},
		World6_Path3_Branch1_Node12 = {
			BranchRoot = "World6_Path3_Branch1_Node1",
			Seed = 6031,
			ChildIdList = {
				"World6_Path3_Branch1_Node13",
			},
			EventPool = 810016,
		},
		World6_Path3_Branch1_Node13 = {
			BranchRoot = "World6_Path3_Branch1_Node1",
			Seed = 6031,
			ChildIdList = {
				"World6_Path3_Branch1_Node14",
			},
			EventPool = 810014,
		},
		World6_Path3_Branch1_Node14 = {
			BranchRoot = "World6_Path3_Branch1_Node1",
			Seed = 6031,
			ChildIdList = {
				"World6_Path3_Branch1_Node15",
			},
			EventPool = 810015,
		},
		World6_Path3_Branch1_Node15 = {
			BranchRoot = "World6_Path3_Branch1_Node1",
			Seed = 6031,
			ChildIdList = {
				"World6_Path3_Branch1_Node16",
			},
			EventPool = 810016,
		},
		World6_Path3_Branch1_Node16 = {
			BranchRoot = "World6_Path3_Branch1_Node1",
			Seed = 6031,
			ChildIdList = {
				"World6_Path3_Branch1_Node17",
			},
			EventPool = 810020,
		},
		World6_Path3_Branch1_Node17 = {
			BranchRoot = "World6_Path3_Branch1_Node1",
			Seed = 6031,
			ChildIdList = {
				"World6_Path3_Branch1_Node18",
			},
			EventPool = 810014,
		},
		World6_Path3_Branch1_Node18 = {
			BranchRoot = "World6_Path3_Branch1_Node1",
			Seed = 6031,
			ChildIdList = {
				"World6_Path3_Branch1_Node19",
			},
			EventPool = 810014,
		},
		World6_Path3_Branch1_Node19 = {
			BranchRoot = "World6_Path3_Branch1_Node1",
			Seed = 6031,
			ChildIdList = {
				"World6_Path3_Branch1_Node20",
			},
			EventPool = 810025,
		},
		World6_Path3_Branch1_Node20 = {
			BranchRoot = "World6_Path3_Branch1_Node1",
			Seed = 6031,
			ChildIdList = {
				"World6_Path4_Branch1_Node1",
				"World6_Path4_Branch2_Node1",
			},
			EventPool = 810021,
		},
		World6_Path4_Branch1_Node1 = {
			BranchRoot = "World6_Path4_Branch1_Node1",
			Seed = 6041,
			ChildIdList = {
				"World6_Path4_Branch1_Node2",
			},
			EventPool = 810020,
		},
		World6_Path4_Branch1_Node2 = {
			BranchRoot = "World6_Path4_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 6041,
			ChildIdList = {
				"World6_Path4_Branch1_Node3",
			},
			EventPool = 810005,
		},
		World6_Path4_Branch1_Node3 = {
			BranchRoot = "World6_Path4_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 6041,
			ChildIdList = {
				"World6_Path4_Branch1_Node4",
			},
			EventPool = 810005,
		},
		World6_Path4_Branch1_Node4 = {
			BranchRoot = "World6_Path4_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 6041,
			ChildIdList = {
				"World6_Path4_Branch1_Node5",
			},
			EventPool = 810005,
		},
		World6_Path4_Branch1_Node5 = {
			BranchRoot = "World6_Path4_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 6041,
			ChildIdList = {
				"World6_Path4_Branch1_Node6",
			},
			EventPool = 810005,
		},
		World6_Path4_Branch1_Node6 = {
			BranchRoot = "World6_Path4_Branch1_Node1",
			Seed = 6041,
			ChildIdList = {
				"World6_Path4_Branch1_Node7",
			},
			EventPool = 810015,
		},
		World6_Path4_Branch1_Node7 = {
			BranchRoot = "World6_Path4_Branch1_Node1",
			Seed = 6041,
			ChildIdList = {
				"World6_Path4_Branch1_Node8",
			},
			EventPool = 810026,
		},
		World6_Path4_Branch1_Node8 = {
			BranchRoot = "World6_Path4_Branch1_Node1",
			Seed = 6041,
			ChildIdList = {
				"World6_Path4_Branch1_Node9",
			},
			EventPool = 810021,
		},
		World6_Path4_Branch1_Node9 = {
			BranchRoot = "World6_Path4_Branch1_Node1",
			Seed = 6041,
			ChildIdList = {
				"World6_Path4_Branch1_Node10",
			},
			EventPool = 810024,
		},
		World6_Path4_Branch1_Node10 = {
			BranchRoot = "World6_Path4_Branch1_Node1",
			Seed = 6041,
			ChildIdList = {
				"World6_Path4_Branch1_Node11",
			},
			EventPool = 810022,
		},
		World6_Path4_Branch1_Node11 = {
			BranchRoot = "World6_Path4_Branch1_Node1",
			Seed = 6041,
			ChildIdList = {
				"World6_Path4_Branch1_Node12",
			},
			EventPool = 810016,
		},
		World6_Path4_Branch1_Node12 = {
			BranchRoot = "World6_Path4_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 6041,
			ChildIdList = {
				"World6_Path4_Branch1_Node13",
			},
			EventPool = 810004,
		},
		World6_Path4_Branch1_Node13 = {
			BranchRoot = "World6_Path4_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 6041,
			ChildIdList = {
				"World6_Path4_Branch1_Node14",
			},
			EventPool = 810004,
		},
		World6_Path4_Branch1_Node14 = {
			BranchRoot = "World6_Path4_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 6041,
			ChildIdList = {
				"World6_Path4_Branch1_Node15",
			},
			EventPool = 810004,
		},
		World6_Path4_Branch1_Node15 = {
			BranchRoot = "World6_Path4_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 6041,
			ChildIdList = {
				"World6_Path4_Branch1_Node16",
			},
			EventPool = 810004,
		},
		World6_Path4_Branch1_Node16 = {
			BranchRoot = "World6_Path4_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 6041,
			ChildIdList = {
				"World6_Path4_Branch1_Node17",
			},
			EventPool = 810004,
		},
		World6_Path4_Branch1_Node17 = {
			BranchRoot = "World6_Path4_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 6041,
			ChildIdList = {
				"World6_Path4_Branch1_Node18",
			},
			EventPool = 810004,
		},
		World6_Path4_Branch1_Node18 = {
			BranchRoot = "World6_Path4_Branch1_Node1",
			Seed = 6041,
			ChildIdList = {
				"World6_Path4_Branch1_Node19",
			},
			EventPool = 810014,
		},
		World6_Path4_Branch1_Node19 = {
			BranchRoot = "World6_Path4_Branch1_Node1",
			Seed = 6041,
			ChildIdList = {
				"World6_Path4_Branch1_Node20",
			},
			EventPool = 810024,
		},
		World6_Path4_Branch1_Node20 = {
			BranchRoot = "World6_Path4_Branch1_Node1",
			Seed = 6041,
			ChildIdList = {
				"World6_Path5_Branch1_Node1",
				"World6_Path5_Branch2_Node1",
			},
			EventPool = 810016,
		},
		World6_Path5_Branch1_Node1 = {
			BranchRoot = "World6_Path5_Branch1_Node1",
			Seed = 6051,
			ChildIdList = {
				"World6_Path5_Branch1_Node2",
			},
			EventPool = 810016,
		},
		World6_Path5_Branch1_Node2 = {
			BranchRoot = "World6_Path5_Branch1_Node1",
			Seed = 6051,
			ChildIdList = {
				"World6_Path5_Branch1_Node3",
			},
			EventPool = 810014,
		},
		World6_Path5_Branch1_Node3 = {
			BranchRoot = "World6_Path5_Branch1_Node1",
			StepScore = 50,
			Seed = 6051,
			ChildIdList = {
				"World6_Path5_Branch1_Node4",
			},
			EventPool = 810006,
		},
		World6_Path5_Branch1_Node4 = {
			BranchRoot = "World6_Path5_Branch1_Node1",
			Seed = 6051,
			ChildIdList = {
				"World6_Path5_Branch1_Node5",
			},
			EventPool = 810016,
		},
		World6_Path5_Branch1_Node5 = {
			BranchRoot = "World6_Path5_Branch1_Node1",
			Seed = 6051,
			ChildIdList = {
				"World6_Path5_Branch1_Node6",
			},
			EventPool = 810014,
		},
		World6_Path5_Branch1_Node6 = {
			BranchRoot = "World6_Path5_Branch1_Node1",
			Seed = 6051,
			ChildIdList = {
				"World6_Path5_Branch1_Node7",
			},
			EventPool = 810014,
		},
		World6_Path5_Branch1_Node7 = {
			BranchRoot = "World6_Path5_Branch1_Node1",
			Seed = 6051,
			ChildIdList = {
				"World6_Path5_Branch1_Node8",
			},
			EventPool = 810014,
		},
		World6_Path5_Branch1_Node8 = {
			BranchRoot = "World6_Path5_Branch1_Node1",
			Seed = 6051,
			ChildIdList = {
				"World6_Path5_Branch1_Node9",
			},
			EventPool = 810022,
		},
		World6_Path5_Branch1_Node9 = {
			BranchRoot = "World6_Path5_Branch1_Node1",
			Seed = 6051,
			ChildIdList = {
				"World6_Path5_Branch1_Node10",
			},
			EventPool = 810025,
		},
		World6_Path5_Branch1_Node10 = {
			BranchRoot = "World6_Path5_Branch1_Node1",
			Seed = 6051,
			ChildIdList = {
				"World6_Path5_Branch1_Node11",
			},
			EventPool = 810022,
		},
		World6_Path5_Branch1_Node11 = {
			BranchRoot = "World6_Path5_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 6051,
			ChildIdList = {
				"World6_Path5_Branch1_Node12",
			},
			EventPool = 810005,
		},
		World6_Path5_Branch1_Node12 = {
			BranchRoot = "World6_Path5_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 6051,
			ChildIdList = {
				"World6_Path5_Branch1_Node13",
			},
			EventPool = 810005,
		},
		World6_Path5_Branch1_Node13 = {
			BranchRoot = "World6_Path5_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 6051,
			ChildIdList = {
				"World6_Path5_Branch1_Node14",
			},
			EventPool = 810005,
		},
		World6_Path5_Branch1_Node14 = {
			BranchRoot = "World6_Path5_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 6051,
			ChildIdList = {
				"World6_Path5_Branch1_Node15",
			},
			EventPool = 810005,
		},
		World6_Path5_Branch1_Node15 = {
			BranchRoot = "World6_Path5_Branch1_Node1",
			Seed = 6051,
			ChildIdList = {
				"World6_Path5_Branch1_Node16",
			},
			EventPool = 810016,
		},
		World6_Path5_Branch1_Node16 = {
			BranchRoot = "World6_Path5_Branch1_Node1",
			Seed = 6051,
			ChildIdList = {
				"World6_Path5_Branch1_Node17",
			},
			EventPool = 810016,
		},
		World6_Path5_Branch1_Node17 = {
			BranchRoot = "World6_Path5_Branch1_Node1",
			Seed = 6051,
			ChildIdList = {
				"World6_Path5_Branch1_Node18",
			},
			EventPool = 810016,
		},
		World6_Path5_Branch1_Node18 = {
			BranchRoot = "World6_Path5_Branch1_Node1",
			Seed = 6051,
			ChildIdList = {
				"World6_Path5_Branch1_Node19",
			},
			EventPool = 810026,
		},
		World6_Path5_Branch1_Node19 = {
			BranchRoot = "World6_Path5_Branch1_Node1",
			Seed = 6051,
			ChildIdList = {
				"World6_Path5_Branch1_Node20",
			},
			EventPool = 810025,
		},
		World6_Path5_Branch1_Node20 = {
			BranchRoot = "World6_Path5_Branch1_Node1",
			Seed = 6051,
			ChildIdList = {
				"World6_Path6_Branch1_Node1",
				"World6_Path6_Branch2_Node1",
			},
			EventPool = 810016,
		},
		World6_Path6_Branch1_Node1 = {
			BranchRoot = "World6_Path6_Branch1_Node1",
			Seed = 6061,
			ChildIdList = {
				"World6_Path6_Branch1_Node2",
			},
			EventPool = 810021,
		},
		World6_Path6_Branch1_Node2 = {
			BranchRoot = "World6_Path6_Branch1_Node1",
			Seed = 6061,
			ChildIdList = {
				"World6_Path6_Branch1_Node3",
			},
			EventPool = 810020,
		},
		World6_Path6_Branch1_Node3 = {
			BranchRoot = "World6_Path6_Branch1_Node1",
			Seed = 6061,
			ChildIdList = {
				"World6_Path6_Branch1_Node4",
			},
			EventPool = 810021,
		},
		World6_Path6_Branch1_Node4 = {
			BranchRoot = "World6_Path6_Branch1_Node1",
			Seed = 6061,
			ChildIdList = {
				"World6_Path6_Branch1_Node5",
			},
			EventPool = 810016,
		},
		World6_Path6_Branch1_Node5 = {
			BranchRoot = "World6_Path6_Branch1_Node1",
			Seed = 6061,
			ChildIdList = {
				"World6_Path6_Branch1_Node6",
			},
			EventPool = 810016,
		},
		World6_Path6_Branch1_Node6 = {
			BranchRoot = "World6_Path6_Branch1_Node1",
			Seed = 6061,
			ChildIdList = {
				"World6_Path6_Branch1_Node7",
			},
			EventPool = 810014,
		},
		World6_Path6_Branch1_Node7 = {
			BranchRoot = "World6_Path6_Branch1_Node1",
			Seed = 6061,
			ChildIdList = {
				"World6_Path6_Branch1_Node8",
			},
			EventPool = 810026,
		},
		World6_Path6_Branch1_Node8 = {
			BranchRoot = "World6_Path6_Branch1_Node1",
			Seed = 6061,
			ChildIdList = {
				"World6_Path6_Branch1_Node9",
			},
			EventPool = 810021,
		},
		World6_Path6_Branch1_Node9 = {
			BranchRoot = "World6_Path6_Branch1_Node1",
			Seed = 6061,
			ChildIdList = {
				"World6_Path6_Branch1_Node10",
			},
			EventPool = 810024,
		},
		World6_Path6_Branch1_Node10 = {
			BranchRoot = "World6_Path6_Branch1_Node1",
			Seed = 6061,
			ChildIdList = {
				"World6_Path6_Branch1_Node11",
			},
			EventPool = 810021,
		},
		World6_Path6_Branch1_Node11 = {
			BranchRoot = "World6_Path6_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 6061,
			ChildIdList = {
				"World6_Path6_Branch1_Node12",
			},
			EventPool = 810004,
		},
		World6_Path6_Branch1_Node12 = {
			BranchRoot = "World6_Path6_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 6061,
			ChildIdList = {
				"World6_Path6_Branch1_Node13",
			},
			EventPool = 810004,
		},
		World6_Path6_Branch1_Node13 = {
			BranchRoot = "World6_Path6_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 6061,
			ChildIdList = {
				"World6_Path6_Branch1_Node14",
			},
			EventPool = 810004,
		},
		World6_Path6_Branch1_Node14 = {
			BranchRoot = "World6_Path6_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 6061,
			ChildIdList = {
				"World6_Path6_Branch1_Node15",
			},
			EventPool = 810004,
		},
		World6_Path6_Branch1_Node15 = {
			BranchRoot = "World6_Path6_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 6061,
			ChildIdList = {
				"World6_Path6_Branch1_Node16",
			},
			EventPool = 810004,
		},
		World6_Path6_Branch1_Node16 = {
			BranchRoot = "World6_Path6_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 6061,
			ChildIdList = {
				"World6_Path6_Branch1_Node17",
			},
			EventPool = 810004,
		},
		World6_Path6_Branch1_Node17 = {
			BranchRoot = "World6_Path6_Branch1_Node1",
			Seed = 6061,
			ChildIdList = {
				"World6_Path6_Branch1_Node18",
			},
			EventPool = 810016,
		},
		World6_Path6_Branch1_Node18 = {
			BranchRoot = "World6_Path6_Branch1_Node1",
			Seed = 6061,
			ChildIdList = {
				"World6_Path6_Branch1_Node19",
			},
			EventPool = 810015,
		},
		World6_Path6_Branch1_Node19 = {
			BranchRoot = "World6_Path6_Branch1_Node1",
			Seed = 6061,
			ChildIdList = {
				"World6_Path6_Branch1_Node20",
			},
			EventPool = 810026,
		},
		World6_Path6_Branch1_Node20 = {
			BranchRoot = "World6_Path6_Branch1_Node1",
			Seed = 6061,
			EventPool = 810023,
		},
		World6_Path2_Branch2_Node1 = {
			BranchRoot = "World6_Path2_Branch2_Node1",
			Seed = 6022,
			ChildIdList = {
				"World6_Path2_Branch2_Node2",
			},
			EventPool = 810016,
		},
		World6_Path2_Branch2_Node2 = {
			BranchRoot = "World6_Path2_Branch2_Node1",
			Seed = 6022,
			ChildIdList = {
				"World6_Path2_Branch2_Node3",
			},
			EventPool = 810016,
		},
		World6_Path2_Branch2_Node3 = {
			BranchRoot = "World6_Path2_Branch2_Node1",
			Seed = 6022,
			ChildIdList = {
				"World6_Path2_Branch2_Node4",
			},
			EventPool = 810026,
		},
		World6_Path2_Branch2_Node4 = {
			BranchRoot = "World6_Path2_Branch2_Node1",
			Seed = 6022,
			ChildIdList = {
				"World6_Path2_Branch2_Node5",
			},
			EventPool = 810016,
		},
		World6_Path2_Branch2_Node5 = {
			BranchRoot = "World6_Path2_Branch2_Node1",
			StepScore = 50,
			Seed = 6022,
			ChildIdList = {
				"World6_Path2_Branch2_Node6",
			},
			EventPool = 810006,
		},
		World6_Path2_Branch2_Node6 = {
			BranchRoot = "World6_Path2_Branch2_Node1",
			Seed = 6022,
			ChildIdList = {
				"World6_Path2_Branch2_Node7",
			},
			EventPool = 810022,
		},
		World6_Path2_Branch2_Node7 = {
			BranchRoot = "World6_Path2_Branch2_Node1",
			Seed = 6022,
			ChildIdList = {
				"World6_Path2_Branch2_Node8",
			},
			EventPool = 810020,
		},
		World6_Path2_Branch2_Node8 = {
			BranchRoot = "World6_Path2_Branch2_Node1",
			Seed = 6022,
			ChildIdList = {
				"World6_Path2_Branch2_Node9",
			},
			EventPool = 810026,
		},
		World6_Path2_Branch2_Node9 = {
			BranchRoot = "World6_Path2_Branch2_Node1",
			Seed = 6022,
			ChildIdList = {
				"World6_Path2_Branch2_Node10",
			},
			EventPool = 810025,
		},
		World6_Path2_Branch2_Node10 = {
			BranchRoot = "World6_Path2_Branch2_Node1",
			Seed = 6022,
			ChildIdList = {
				"World6_Path2_Branch2_Node11",
			},
			EventPool = 810026,
		},
		World6_Path2_Branch2_Node11 = {
			BranchRoot = "World6_Path2_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 6022,
			ChildIdList = {
				"World6_Path2_Branch2_Node12",
			},
			EventPool = 810005,
		},
		World6_Path2_Branch2_Node12 = {
			BranchRoot = "World6_Path2_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 6022,
			ChildIdList = {
				"World6_Path2_Branch2_Node13",
			},
			EventPool = 810005,
		},
		World6_Path2_Branch2_Node13 = {
			BranchRoot = "World6_Path2_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 6022,
			ChildIdList = {
				"World6_Path2_Branch2_Node14",
			},
			EventPool = 810005,
		},
		World6_Path2_Branch2_Node14 = {
			BranchRoot = "World6_Path2_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 6022,
			ChildIdList = {
				"World6_Path2_Branch2_Node15",
			},
			EventPool = 810005,
		},
		World6_Path2_Branch2_Node15 = {
			BranchRoot = "World6_Path2_Branch2_Node1",
			Seed = 6022,
			ChildIdList = {
				"World6_Path2_Branch2_Node16",
			},
			EventPool = 810026,
		},
		World6_Path2_Branch2_Node16 = {
			BranchRoot = "World6_Path2_Branch2_Node1",
			Seed = 6022,
			ChildIdList = {
				"World6_Path2_Branch2_Node17",
			},
			EventPool = 810022,
		},
		World6_Path2_Branch2_Node17 = {
			BranchRoot = "World6_Path2_Branch2_Node1",
			Seed = 6022,
			ChildIdList = {
				"World6_Path2_Branch2_Node18",
			},
			EventPool = 810026,
		},
		World6_Path2_Branch2_Node18 = {
			BranchRoot = "World6_Path2_Branch2_Node1",
			Seed = 6022,
			ChildIdList = {
				"World6_Path2_Branch2_Node19",
			},
			EventPool = 810014,
		},
		World6_Path2_Branch2_Node19 = {
			BranchRoot = "World6_Path2_Branch2_Node1",
			Seed = 6022,
			ChildIdList = {
				"World6_Path2_Branch2_Node20",
			},
			EventPool = 810024,
		},
		World6_Path2_Branch2_Node20 = {
			BranchRoot = "World6_Path2_Branch2_Node1",
			Seed = 6022,
			ChildIdList = {
				"World6_Path3_Branch1_Node1",
				"World6_Path3_Branch2_Node1",
			},
			EventPool = 810016,
		},
		World6_Path3_Branch2_Node1 = {
			BranchRoot = "World6_Path3_Branch2_Node1",
			Seed = 6032,
			ChildIdList = {
				"World6_Path3_Branch2_Node2",
			},
			EventPool = 810022,
		},
		World6_Path3_Branch2_Node2 = {
			BranchRoot = "World6_Path3_Branch2_Node1",
			Seed = 6032,
			ChildIdList = {
				"World6_Path3_Branch2_Node3",
			},
			EventPool = 810016,
		},
		World6_Path3_Branch2_Node3 = {
			BranchRoot = "World6_Path3_Branch2_Node1",
			Seed = 6032,
			ChildIdList = {
				"World6_Path3_Branch2_Node4",
			},
			EventPool = 810015,
		},
		World6_Path3_Branch2_Node4 = {
			BranchRoot = "World6_Path3_Branch2_Node1",
			StepScore = 50,
			Seed = 6032,
			ChildIdList = {
				"World6_Path3_Branch2_Node5",
			},
			EventPool = 810006,
		},
		World6_Path3_Branch2_Node5 = {
			BranchRoot = "World6_Path3_Branch2_Node1",
			Seed = 6032,
			ChildIdList = {
				"World6_Path3_Branch2_Node6",
			},
			EventPool = 810014,
		},
		World6_Path3_Branch2_Node6 = {
			BranchRoot = "World6_Path3_Branch2_Node1",
			Seed = 6032,
			ChildIdList = {
				"World6_Path3_Branch2_Node7",
			},
			EventPool = 810021,
		},
		World6_Path3_Branch2_Node7 = {
			BranchRoot = "World6_Path3_Branch2_Node1",
			Seed = 6032,
			ChildIdList = {
				"World6_Path3_Branch2_Node8",
			},
			EventPool = 810026,
		},
		World6_Path3_Branch2_Node8 = {
			BranchRoot = "World6_Path3_Branch2_Node1",
			Seed = 6032,
			ChildIdList = {
				"World6_Path3_Branch2_Node9",
			},
			EventPool = 810022,
		},
		World6_Path3_Branch2_Node9 = {
			BranchRoot = "World6_Path3_Branch2_Node1",
			Seed = 6032,
			ChildIdList = {
				"World6_Path3_Branch2_Node10",
			},
			EventPool = 810025,
		},
		World6_Path3_Branch2_Node10 = {
			BranchRoot = "World6_Path3_Branch2_Node1",
			Seed = 6032,
			ChildIdList = {
				"World6_Path3_Branch2_Node11",
			},
			EventPool = 810016,
		},
		World6_Path3_Branch2_Node11 = {
			BranchRoot = "World6_Path3_Branch2_Node1",
			Seed = 6032,
			ChildIdList = {
				"World6_Path3_Branch2_Node12",
			},
			EventPool = 810026,
		},
		World6_Path3_Branch2_Node12 = {
			BranchRoot = "World6_Path3_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 6032,
			ChildIdList = {
				"World6_Path3_Branch2_Node13",
			},
			EventPool = 810004,
		},
		World6_Path3_Branch2_Node13 = {
			BranchRoot = "World6_Path3_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 6032,
			ChildIdList = {
				"World6_Path3_Branch2_Node14",
			},
			EventPool = 810004,
		},
		World6_Path3_Branch2_Node14 = {
			BranchRoot = "World6_Path3_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 6032,
			ChildIdList = {
				"World6_Path3_Branch2_Node15",
			},
			EventPool = 810004,
		},
		World6_Path3_Branch2_Node15 = {
			BranchRoot = "World6_Path3_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 6032,
			ChildIdList = {
				"World6_Path3_Branch2_Node16",
			},
			EventPool = 810004,
		},
		World6_Path3_Branch2_Node16 = {
			BranchRoot = "World6_Path3_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 6032,
			ChildIdList = {
				"World6_Path3_Branch2_Node17",
			},
			EventPool = 810004,
		},
		World6_Path3_Branch2_Node17 = {
			BranchRoot = "World6_Path3_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 6032,
			ChildIdList = {
				"World6_Path3_Branch2_Node18",
			},
			EventPool = 810004,
		},
		World6_Path3_Branch2_Node18 = {
			BranchRoot = "World6_Path3_Branch2_Node1",
			Seed = 6032,
			ChildIdList = {
				"World6_Path3_Branch2_Node19",
			},
			EventPool = 810014,
		},
		World6_Path3_Branch2_Node19 = {
			BranchRoot = "World6_Path3_Branch2_Node1",
			Seed = 6032,
			ChildIdList = {
				"World6_Path3_Branch2_Node20",
			},
			EventPool = 810024,
		},
		World6_Path3_Branch2_Node20 = {
			BranchRoot = "World6_Path3_Branch2_Node1",
			Seed = 6032,
			ChildIdList = {
				"World6_Path4_Branch1_Node1",
				"World6_Path4_Branch2_Node1",
			},
			EventPool = 810021,
		},
		World6_Path4_Branch2_Node1 = {
			BranchRoot = "World6_Path4_Branch2_Node1",
			Seed = 6042,
			ChildIdList = {
				"World6_Path4_Branch2_Node2",
			},
			EventPool = 810015,
		},
		World6_Path4_Branch2_Node2 = {
			BranchRoot = "World6_Path4_Branch2_Node1",
			Seed = 6042,
			ChildIdList = {
				"World6_Path4_Branch2_Node3",
			},
			EventPool = 810026,
		},
		World6_Path4_Branch2_Node3 = {
			BranchRoot = "World6_Path4_Branch2_Node1",
			Seed = 6042,
			ChildIdList = {
				"World6_Path4_Branch2_Node4",
			},
			EventPool = 810021,
		},
		World6_Path4_Branch2_Node4 = {
			BranchRoot = "World6_Path4_Branch2_Node1",
			Seed = 6042,
			ChildIdList = {
				"World6_Path4_Branch2_Node5",
			},
			EventPool = 810020,
		},
		World6_Path4_Branch2_Node5 = {
			BranchRoot = "World6_Path4_Branch2_Node1",
			Seed = 6042,
			ChildIdList = {
				"World6_Path4_Branch2_Node6",
			},
			EventPool = 810026,
		},
		World6_Path4_Branch2_Node6 = {
			BranchRoot = "World6_Path4_Branch2_Node1",
			Seed = 6042,
			ChildIdList = {
				"World6_Path4_Branch2_Node7",
			},
			EventPool = 810016,
		},
		World6_Path4_Branch2_Node7 = {
			BranchRoot = "World6_Path4_Branch2_Node1",
			Seed = 6042,
			ChildIdList = {
				"World6_Path4_Branch2_Node8",
			},
			EventPool = 810026,
		},
		World6_Path4_Branch2_Node8 = {
			BranchRoot = "World6_Path4_Branch2_Node1",
			Seed = 6042,
			ChildIdList = {
				"World6_Path4_Branch2_Node9",
			},
			EventPool = 810022,
		},
		World6_Path4_Branch2_Node9 = {
			BranchRoot = "World6_Path4_Branch2_Node1",
			Seed = 6042,
			ChildIdList = {
				"World6_Path4_Branch2_Node10",
			},
			EventPool = 810024,
		},
		World6_Path4_Branch2_Node10 = {
			BranchRoot = "World6_Path4_Branch2_Node1",
			Seed = 6042,
			ChildIdList = {
				"World6_Path4_Branch2_Node11",
			},
			EventPool = 810020,
		},
		World6_Path4_Branch2_Node11 = {
			BranchRoot = "World6_Path4_Branch2_Node1",
			Seed = 6042,
			ChildIdList = {
				"World6_Path4_Branch2_Node12",
			},
			EventPool = 810026,
		},
		World6_Path4_Branch2_Node12 = {
			BranchRoot = "World6_Path4_Branch2_Node1",
			Seed = 6042,
			ChildIdList = {
				"World6_Path4_Branch2_Node13",
			},
			EventPool = 810014,
		},
		World6_Path4_Branch2_Node13 = {
			BranchRoot = "World6_Path4_Branch2_Node1",
			Seed = 6042,
			ChildIdList = {
				"World6_Path4_Branch2_Node14",
			},
			EventPool = 810022,
		},
		World6_Path4_Branch2_Node14 = {
			BranchRoot = "World6_Path4_Branch2_Node1",
			Seed = 6042,
			ChildIdList = {
				"World6_Path4_Branch2_Node15",
			},
			EventPool = 810016,
		},
		World6_Path4_Branch2_Node15 = {
			BranchRoot = "World6_Path4_Branch2_Node1",
			Seed = 6042,
			ChildIdList = {
				"World6_Path4_Branch2_Node16",
			},
			EventPool = 810015,
		},
		World6_Path4_Branch2_Node16 = {
			BranchRoot = "World6_Path4_Branch2_Node1",
			Seed = 6042,
			ChildIdList = {
				"World6_Path4_Branch2_Node17",
			},
			EventPool = 810020,
		},
		World6_Path4_Branch2_Node17 = {
			BranchRoot = "World6_Path4_Branch2_Node1",
			Seed = 6042,
			ChildIdList = {
				"World6_Path4_Branch2_Node18",
			},
			EventPool = 810014,
		},
		World6_Path4_Branch2_Node18 = {
			BranchRoot = "World6_Path4_Branch2_Node1",
			Seed = 6042,
			ChildIdList = {
				"World6_Path4_Branch2_Node19",
			},
			EventPool = 810026,
		},
		World6_Path4_Branch2_Node19 = {
			BranchRoot = "World6_Path4_Branch2_Node1",
			Seed = 6042,
			ChildIdList = {
				"World6_Path4_Branch2_Node20",
			},
			EventPool = 810024,
		},
		World6_Path4_Branch2_Node20 = {
			BranchRoot = "World6_Path4_Branch2_Node1",
			Seed = 6042,
			ChildIdList = {
				"World6_Path5_Branch1_Node1",
				"World6_Path5_Branch2_Node1",
			},
			EventPool = 810026,
		},
		World6_Path5_Branch2_Node1 = {
			BranchRoot = "World6_Path5_Branch2_Node1",
			Seed = 6052,
			ChildIdList = {
				"World6_Path5_Branch2_Node2",
			},
			EventPool = 810022,
		},
		World6_Path5_Branch2_Node2 = {
			BranchRoot = "World6_Path5_Branch2_Node1",
			Seed = 6052,
			ChildIdList = {
				"World6_Path5_Branch2_Node3",
			},
			EventPool = 810022,
		},
		World6_Path5_Branch2_Node3 = {
			BranchRoot = "World6_Path5_Branch2_Node1",
			Seed = 6052,
			ChildIdList = {
				"World6_Path5_Branch2_Node4",
			},
			EventPool = 810016,
		},
		World6_Path5_Branch2_Node4 = {
			BranchRoot = "World6_Path5_Branch2_Node1",
			StepScore = 50,
			Seed = 6052,
			ChildIdList = {
				"World6_Path5_Branch2_Node5",
			},
			EventPool = 810006,
		},
		World6_Path5_Branch2_Node5 = {
			BranchRoot = "World6_Path5_Branch2_Node1",
			Seed = 6052,
			ChildIdList = {
				"World6_Path5_Branch2_Node6",
			},
			EventPool = 810021,
		},
		World6_Path5_Branch2_Node6 = {
			BranchRoot = "World6_Path5_Branch2_Node1",
			Seed = 6052,
			ChildIdList = {
				"World6_Path5_Branch2_Node7",
			},
			EventPool = 810020,
		},
		World6_Path5_Branch2_Node7 = {
			BranchRoot = "World6_Path5_Branch2_Node1",
			Seed = 6052,
			ChildIdList = {
				"World6_Path5_Branch2_Node8",
			},
			EventPool = 810021,
		},
		World6_Path5_Branch2_Node8 = {
			BranchRoot = "World6_Path5_Branch2_Node1",
			Seed = 6052,
			ChildIdList = {
				"World6_Path5_Branch2_Node9",
			},
			EventPool = 810020,
		},
		World6_Path5_Branch2_Node9 = {
			BranchRoot = "World6_Path5_Branch2_Node1",
			Seed = 6052,
			ChildIdList = {
				"World6_Path5_Branch2_Node10",
			},
			EventPool = 810025,
		},
		World6_Path5_Branch2_Node10 = {
			BranchRoot = "World6_Path5_Branch2_Node1",
			Seed = 6052,
			ChildIdList = {
				"World6_Path5_Branch2_Node11",
			},
			EventPool = 810016,
		},
		World6_Path5_Branch2_Node11 = {
			BranchRoot = "World6_Path5_Branch2_Node1",
			Seed = 6052,
			ChildIdList = {
				"World6_Path5_Branch2_Node12",
			},
			EventPool = 810020,
		},
		World6_Path5_Branch2_Node12 = {
			BranchRoot = "World6_Path5_Branch2_Node1",
			Seed = 6052,
			ChildIdList = {
				"World6_Path5_Branch2_Node13",
			},
			EventPool = 810015,
		},
		World6_Path5_Branch2_Node13 = {
			BranchRoot = "World6_Path5_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 6052,
			ChildIdList = {
				"World6_Path5_Branch2_Node14",
			},
			EventPool = 810005,
		},
		World6_Path5_Branch2_Node14 = {
			BranchRoot = "World6_Path5_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 6052,
			ChildIdList = {
				"World6_Path5_Branch2_Node15",
			},
			EventPool = 810005,
		},
		World6_Path5_Branch2_Node15 = {
			BranchRoot = "World6_Path5_Branch2_Node1",
			StepScore = 50,
			Seed = 6052,
			ChildIdList = {
				"World6_Path5_Branch2_Node16",
			},
			EventPool = 810006,
		},
		World6_Path5_Branch2_Node16 = {
			BranchRoot = "World6_Path5_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 6052,
			ChildIdList = {
				"World6_Path5_Branch2_Node17",
			},
			EventPool = 810005,
		},
		World6_Path5_Branch2_Node17 = {
			BranchRoot = "World6_Path5_Branch2_Node1",
			Seed = 6052,
			ChildIdList = {
				"World6_Path5_Branch2_Node18",
			},
			EventPool = 810015,
		},
		World6_Path5_Branch2_Node18 = {
			BranchRoot = "World6_Path5_Branch2_Node1",
			Seed = 6052,
			ChildIdList = {
				"World6_Path5_Branch2_Node19",
			},
			EventPool = 810022,
		},
		World6_Path5_Branch2_Node19 = {
			BranchRoot = "World6_Path5_Branch2_Node1",
			Seed = 6052,
			ChildIdList = {
				"World6_Path5_Branch2_Node20",
			},
			EventPool = 810024,
		},
		World6_Path5_Branch2_Node20 = {
			BranchRoot = "World6_Path5_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 6052,
			ChildIdList = {
				"World6_Path6_Branch1_Node1",
				"World6_Path6_Branch2_Node1",
			},
			EventPool = 810004,
		},
		World6_Path6_Branch2_Node1 = {
			BranchRoot = "World6_Path6_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 6062,
			ChildIdList = {
				"World6_Path6_Branch2_Node2",
			},
			EventPool = 810004,
		},
		World6_Path6_Branch2_Node2 = {
			BranchRoot = "World6_Path6_Branch2_Node1",
			StepScore = 50,
			Seed = 6062,
			ChildIdList = {
				"World6_Path6_Branch2_Node3",
			},
			EventPool = 810006,
		},
		World6_Path6_Branch2_Node3 = {
			BranchRoot = "World6_Path6_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 6062,
			ChildIdList = {
				"World6_Path6_Branch2_Node4",
			},
			EventPool = 810004,
		},
		World6_Path6_Branch2_Node4 = {
			BranchRoot = "World6_Path6_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 6062,
			ChildIdList = {
				"World6_Path6_Branch2_Node5",
			},
			EventPool = 810004,
		},
		World6_Path6_Branch2_Node5 = {
			BranchRoot = "World6_Path6_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 6062,
			ChildIdList = {
				"World6_Path6_Branch2_Node6",
			},
			EventPool = 810004,
		},
		World6_Path6_Branch2_Node6 = {
			BranchRoot = "World6_Path6_Branch2_Node1",
			Seed = 6062,
			ChildIdList = {
				"World6_Path6_Branch2_Node7",
			},
			EventPool = 810015,
		},
		World6_Path6_Branch2_Node7 = {
			BranchRoot = "World6_Path6_Branch2_Node1",
			Seed = 6062,
			ChildIdList = {
				"World6_Path6_Branch2_Node8",
			},
			EventPool = 810022,
		},
		World6_Path6_Branch2_Node8 = {
			BranchRoot = "World6_Path6_Branch2_Node1",
			Seed = 6062,
			ChildIdList = {
				"World6_Path6_Branch2_Node9",
			},
			EventPool = 810014,
		},
		World6_Path6_Branch2_Node9 = {
			BranchRoot = "World6_Path6_Branch2_Node1",
			Seed = 6062,
			ChildIdList = {
				"World6_Path6_Branch2_Node10",
			},
			EventPool = 810025,
		},
		World6_Path6_Branch2_Node10 = {
			BranchRoot = "World6_Path6_Branch2_Node1",
			Seed = 6062,
			ChildIdList = {
				"World6_Path6_Branch2_Node11",
			},
			EventPool = 810016,
		},
		World6_Path6_Branch2_Node11 = {
			BranchRoot = "World6_Path6_Branch2_Node1",
			Seed = 6062,
			ChildIdList = {
				"World6_Path6_Branch2_Node12",
			},
			EventPool = 810015,
		},
		World6_Path6_Branch2_Node12 = {
			BranchRoot = "World6_Path6_Branch2_Node1",
			Seed = 6062,
			ChildIdList = {
				"World6_Path6_Branch2_Node13",
			},
			EventPool = 810015,
		},
		World6_Path6_Branch2_Node13 = {
			BranchRoot = "World6_Path6_Branch2_Node1",
			Seed = 6062,
			ChildIdList = {
				"World6_Path6_Branch2_Node14",
			},
			EventPool = 810014,
		},
		World6_Path6_Branch2_Node14 = {
			BranchRoot = "World6_Path6_Branch2_Node1",
			Seed = 6062,
			ChildIdList = {
				"World6_Path6_Branch2_Node15",
			},
			EventPool = 810016,
		},
		World6_Path6_Branch2_Node15 = {
			BranchRoot = "World6_Path6_Branch2_Node1",
			Seed = 6062,
			ChildIdList = {
				"World6_Path6_Branch2_Node16",
			},
			EventPool = 810020,
		},
		World6_Path6_Branch2_Node16 = {
			BranchRoot = "World6_Path6_Branch2_Node1",
			Seed = 6062,
			ChildIdList = {
				"World6_Path6_Branch2_Node17",
			},
			EventPool = 810016,
		},
		World6_Path6_Branch2_Node17 = {
			BranchRoot = "World6_Path6_Branch2_Node1",
			Seed = 6062,
			ChildIdList = {
				"World6_Path6_Branch2_Node18",
			},
			EventPool = 810020,
		},
		World6_Path6_Branch2_Node18 = {
			BranchRoot = "World6_Path6_Branch2_Node1",
			Seed = 6062,
			ChildIdList = {
				"World6_Path6_Branch2_Node19",
			},
			EventPool = 810020,
		},
		World6_Path6_Branch2_Node19 = {
			BranchRoot = "World6_Path6_Branch2_Node1",
			Seed = 6062,
			ChildIdList = {
				"World6_Path6_Branch2_Node20",
			},
			EventPool = 810021,
		},
		World6_Path6_Branch2_Node20 = {
			BranchRoot = "World6_Path6_Branch2_Node1",
			Seed = 6062,
			EventPool = 810023,
		},
	},
}
SpaceTravelMapConfig[SpaceTravelMapID.Id007] =
{
	Id = 7,
	WorldIndex = 7,
	Name = "悬疑的宙域",
	FirstNode = "World7_Path1_Branch1_Node1",
	LastNodeList = {
		"World7_Path6_Branch1_Node20",
		"World7_Path6_Branch2_Node20",
	},
	RoundScore = 0,
	StepScore = 40,
	RoundFuelCost = 120,
	StepFuelCost = 0,
	RoundFoodCost = 0,
	StepFoodCost = 0,
	Nodes = {
		World7_Path1_Branch1_Node1 = {
			BranchRoot = "World7_Path1_Branch1_Node1",
			Seed = 7011,
			ChildIdList = {
				"World7_Path1_Branch1_Node2",
			},
			EventPool = 810016,
		},
		World7_Path1_Branch1_Node2 = {
			BranchRoot = "World7_Path1_Branch1_Node1",
			Seed = 7011,
			ChildIdList = {
				"World7_Path1_Branch1_Node3",
			},
			EventPool = 810016,
		},
		World7_Path1_Branch1_Node3 = {
			BranchRoot = "World7_Path1_Branch1_Node1",
			Seed = 7011,
			ChildIdList = {
				"World7_Path1_Branch1_Node4",
			},
			EventPool = 810026,
		},
		World7_Path1_Branch1_Node4 = {
			BranchRoot = "World7_Path1_Branch1_Node1",
			Seed = 7011,
			ChildIdList = {
				"World7_Path1_Branch1_Node5",
			},
			EventPool = 810014,
		},
		World7_Path1_Branch1_Node5 = {
			BranchRoot = "World7_Path1_Branch1_Node1",
			Seed = 7011,
			ChildIdList = {
				"World7_Path1_Branch1_Node6",
			},
			EventPool = 810021,
		},
		World7_Path1_Branch1_Node6 = {
			BranchRoot = "World7_Path1_Branch1_Node1",
			Seed = 7011,
			ChildIdList = {
				"World7_Path1_Branch1_Node7",
			},
			EventPool = 810014,
		},
		World7_Path1_Branch1_Node7 = {
			BranchRoot = "World7_Path1_Branch1_Node1",
			Seed = 7011,
			ChildIdList = {
				"World7_Path1_Branch1_Node8",
			},
			EventPool = 810026,
		},
		World7_Path1_Branch1_Node8 = {
			BranchRoot = "World7_Path1_Branch1_Node1",
			Seed = 7011,
			ChildIdList = {
				"World7_Path1_Branch1_Node9",
			},
			EventPool = 810020,
		},
		World7_Path1_Branch1_Node9 = {
			BranchRoot = "World7_Path1_Branch1_Node1",
			Seed = 7011,
			ChildIdList = {
				"World7_Path1_Branch1_Node10",
			},
			EventPool = 810024,
		},
		World7_Path1_Branch1_Node10 = {
			BranchRoot = "World7_Path1_Branch1_Node1",
			Seed = 7011,
			ChildIdList = {
				"World7_Path1_Branch1_Node11",
			},
			EventPool = 810016,
		},
		World7_Path1_Branch1_Node11 = {
			BranchRoot = "World7_Path1_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 7011,
			ChildIdList = {
				"World7_Path1_Branch1_Node12",
			},
			EventPool = 810004,
		},
		World7_Path1_Branch1_Node12 = {
			BranchRoot = "World7_Path1_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 7011,
			ChildIdList = {
				"World7_Path1_Branch1_Node13",
			},
			EventPool = 810004,
		},
		World7_Path1_Branch1_Node13 = {
			BranchRoot = "World7_Path1_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 7011,
			ChildIdList = {
				"World7_Path1_Branch1_Node14",
			},
			EventPool = 810004,
		},
		World7_Path1_Branch1_Node14 = {
			BranchRoot = "World7_Path1_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 7011,
			ChildIdList = {
				"World7_Path1_Branch1_Node15",
			},
			EventPool = 810004,
		},
		World7_Path1_Branch1_Node15 = {
			BranchRoot = "World7_Path1_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 7011,
			ChildIdList = {
				"World7_Path1_Branch1_Node16",
			},
			EventPool = 810004,
		},
		World7_Path1_Branch1_Node16 = {
			BranchRoot = "World7_Path1_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 7011,
			ChildIdList = {
				"World7_Path1_Branch1_Node17",
			},
			EventPool = 810004,
		},
		World7_Path1_Branch1_Node17 = {
			BranchRoot = "World7_Path1_Branch1_Node1",
			Seed = 7011,
			ChildIdList = {
				"World7_Path1_Branch1_Node18",
			},
			EventPool = 810015,
		},
		World7_Path1_Branch1_Node18 = {
			BranchRoot = "World7_Path1_Branch1_Node1",
			Seed = 7011,
			ChildIdList = {
				"World7_Path1_Branch1_Node19",
			},
			EventPool = 810014,
		},
		World7_Path1_Branch1_Node19 = {
			BranchRoot = "World7_Path1_Branch1_Node1",
			Seed = 7011,
			ChildIdList = {
				"World7_Path1_Branch1_Node20",
			},
			EventPool = 810024,
		},
		World7_Path1_Branch1_Node20 = {
			BranchRoot = "World7_Path1_Branch1_Node1",
			Seed = 7011,
			ChildIdList = {
				"World7_Path2_Branch1_Node1",
				"World7_Path2_Branch2_Node1",
			},
			EventPool = 810026,
		},
		World7_Path2_Branch1_Node1 = {
			BranchRoot = "World7_Path2_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 7021,
			ChildIdList = {
				"World7_Path2_Branch1_Node2",
			},
			EventPool = 810005,
		},
		World7_Path2_Branch1_Node2 = {
			BranchRoot = "World7_Path2_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 7021,
			ChildIdList = {
				"World7_Path2_Branch1_Node3",
			},
			EventPool = 810005,
		},
		World7_Path2_Branch1_Node3 = {
			BranchRoot = "World7_Path2_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 7021,
			ChildIdList = {
				"World7_Path2_Branch1_Node4",
			},
			EventPool = 810005,
		},
		World7_Path2_Branch1_Node4 = {
			BranchRoot = "World7_Path2_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 7021,
			ChildIdList = {
				"World7_Path2_Branch1_Node5",
			},
			EventPool = 810005,
		},
		World7_Path2_Branch1_Node5 = {
			BranchRoot = "World7_Path2_Branch1_Node1",
			Seed = 7021,
			ChildIdList = {
				"World7_Path2_Branch1_Node6",
			},
			EventPool = 810016,
		},
		World7_Path2_Branch1_Node6 = {
			BranchRoot = "World7_Path2_Branch1_Node1",
			Seed = 7021,
			ChildIdList = {
				"World7_Path2_Branch1_Node7",
			},
			EventPool = 810016,
		},
		World7_Path2_Branch1_Node7 = {
			BranchRoot = "World7_Path2_Branch1_Node1",
			Seed = 7021,
			ChildIdList = {
				"World7_Path2_Branch1_Node8",
			},
			EventPool = 810026,
		},
		World7_Path2_Branch1_Node8 = {
			BranchRoot = "World7_Path2_Branch1_Node1",
			Seed = 7021,
			ChildIdList = {
				"World7_Path2_Branch1_Node9",
			},
			EventPool = 810016,
		},
		World7_Path2_Branch1_Node9 = {
			BranchRoot = "World7_Path2_Branch1_Node1",
			Seed = 7021,
			ChildIdList = {
				"World7_Path2_Branch1_Node10",
			},
			EventPool = 810025,
		},
		World7_Path2_Branch1_Node10 = {
			BranchRoot = "World7_Path2_Branch1_Node1",
			Seed = 7021,
			ChildIdList = {
				"World7_Path2_Branch1_Node11",
			},
			EventPool = 810016,
		},
		World7_Path2_Branch1_Node11 = {
			BranchRoot = "World7_Path2_Branch1_Node1",
			Seed = 7021,
			ChildIdList = {
				"World7_Path2_Branch1_Node12",
			},
			EventPool = 810021,
		},
		World7_Path2_Branch1_Node12 = {
			BranchRoot = "World7_Path2_Branch1_Node1",
			Seed = 7021,
			ChildIdList = {
				"World7_Path2_Branch1_Node13",
			},
			EventPool = 810015,
		},
		World7_Path2_Branch1_Node13 = {
			BranchRoot = "World7_Path2_Branch1_Node1",
			Seed = 7021,
			ChildIdList = {
				"World7_Path2_Branch1_Node14",
			},
			EventPool = 810022,
		},
		World7_Path2_Branch1_Node14 = {
			BranchRoot = "World7_Path2_Branch1_Node1",
			StepScore = 50,
			Seed = 7021,
			ChildIdList = {
				"World7_Path2_Branch1_Node15",
			},
			EventPool = 810006,
		},
		World7_Path2_Branch1_Node15 = {
			BranchRoot = "World7_Path2_Branch1_Node1",
			Seed = 7021,
			ChildIdList = {
				"World7_Path2_Branch1_Node16",
			},
			EventPool = 810021,
		},
		World7_Path2_Branch1_Node16 = {
			BranchRoot = "World7_Path2_Branch1_Node1",
			Seed = 7021,
			ChildIdList = {
				"World7_Path2_Branch1_Node17",
			},
			EventPool = 810021,
		},
		World7_Path2_Branch1_Node17 = {
			BranchRoot = "World7_Path2_Branch1_Node1",
			Seed = 7021,
			ChildIdList = {
				"World7_Path2_Branch1_Node18",
			},
			EventPool = 810020,
		},
		World7_Path2_Branch1_Node18 = {
			BranchRoot = "World7_Path2_Branch1_Node1",
			Seed = 7021,
			ChildIdList = {
				"World7_Path2_Branch1_Node19",
			},
			EventPool = 810016,
		},
		World7_Path2_Branch1_Node19 = {
			BranchRoot = "World7_Path2_Branch1_Node1",
			Seed = 7021,
			ChildIdList = {
				"World7_Path2_Branch1_Node20",
			},
			EventPool = 810024,
		},
		World7_Path2_Branch1_Node20 = {
			BranchRoot = "World7_Path2_Branch1_Node1",
			Seed = 7021,
			ChildIdList = {
				"World7_Path3_Branch1_Node1",
				"World7_Path3_Branch2_Node1",
			},
			EventPool = 810015,
		},
		World7_Path3_Branch1_Node1 = {
			BranchRoot = "World7_Path3_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 7031,
			ChildIdList = {
				"World7_Path3_Branch1_Node2",
			},
			EventPool = 810004,
		},
		World7_Path3_Branch1_Node2 = {
			BranchRoot = "World7_Path3_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 7031,
			ChildIdList = {
				"World7_Path3_Branch1_Node3",
			},
			EventPool = 810004,
		},
		World7_Path3_Branch1_Node3 = {
			BranchRoot = "World7_Path3_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 7031,
			ChildIdList = {
				"World7_Path3_Branch1_Node4",
			},
			EventPool = 810004,
		},
		World7_Path3_Branch1_Node4 = {
			BranchRoot = "World7_Path3_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 7031,
			ChildIdList = {
				"World7_Path3_Branch1_Node5",
			},
			EventPool = 810004,
		},
		World7_Path3_Branch1_Node5 = {
			BranchRoot = "World7_Path3_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 7031,
			ChildIdList = {
				"World7_Path3_Branch1_Node6",
			},
			EventPool = 810004,
		},
		World7_Path3_Branch1_Node6 = {
			BranchRoot = "World7_Path3_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 7031,
			ChildIdList = {
				"World7_Path3_Branch1_Node7",
			},
			EventPool = 810004,
		},
		World7_Path3_Branch1_Node7 = {
			BranchRoot = "World7_Path3_Branch1_Node1",
			Seed = 7031,
			ChildIdList = {
				"World7_Path3_Branch1_Node8",
			},
			EventPool = 810016,
		},
		World7_Path3_Branch1_Node8 = {
			BranchRoot = "World7_Path3_Branch1_Node1",
			Seed = 7031,
			ChildIdList = {
				"World7_Path3_Branch1_Node9",
			},
			EventPool = 810021,
		},
		World7_Path3_Branch1_Node9 = {
			BranchRoot = "World7_Path3_Branch1_Node1",
			Seed = 7031,
			ChildIdList = {
				"World7_Path3_Branch1_Node10",
			},
			EventPool = 810025,
		},
		World7_Path3_Branch1_Node10 = {
			BranchRoot = "World7_Path3_Branch1_Node1",
			Seed = 7031,
			ChildIdList = {
				"World7_Path3_Branch1_Node11",
			},
			EventPool = 810021,
		},
		World7_Path3_Branch1_Node11 = {
			BranchRoot = "World7_Path3_Branch1_Node1",
			Seed = 7031,
			ChildIdList = {
				"World7_Path3_Branch1_Node12",
			},
			EventPool = 810021,
		},
		World7_Path3_Branch1_Node12 = {
			BranchRoot = "World7_Path3_Branch1_Node1",
			Seed = 7031,
			ChildIdList = {
				"World7_Path3_Branch1_Node13",
			},
			EventPool = 810016,
		},
		World7_Path3_Branch1_Node13 = {
			BranchRoot = "World7_Path3_Branch1_Node1",
			Seed = 7031,
			ChildIdList = {
				"World7_Path3_Branch1_Node14",
			},
			EventPool = 810014,
		},
		World7_Path3_Branch1_Node14 = {
			BranchRoot = "World7_Path3_Branch1_Node1",
			Seed = 7031,
			ChildIdList = {
				"World7_Path3_Branch1_Node15",
			},
			EventPool = 810015,
		},
		World7_Path3_Branch1_Node15 = {
			BranchRoot = "World7_Path3_Branch1_Node1",
			Seed = 7031,
			ChildIdList = {
				"World7_Path3_Branch1_Node16",
			},
			EventPool = 810016,
		},
		World7_Path3_Branch1_Node16 = {
			BranchRoot = "World7_Path3_Branch1_Node1",
			Seed = 7031,
			ChildIdList = {
				"World7_Path3_Branch1_Node17",
			},
			EventPool = 810020,
		},
		World7_Path3_Branch1_Node17 = {
			BranchRoot = "World7_Path3_Branch1_Node1",
			Seed = 7031,
			ChildIdList = {
				"World7_Path3_Branch1_Node18",
			},
			EventPool = 810014,
		},
		World7_Path3_Branch1_Node18 = {
			BranchRoot = "World7_Path3_Branch1_Node1",
			Seed = 7031,
			ChildIdList = {
				"World7_Path3_Branch1_Node19",
			},
			EventPool = 810014,
		},
		World7_Path3_Branch1_Node19 = {
			BranchRoot = "World7_Path3_Branch1_Node1",
			Seed = 7031,
			ChildIdList = {
				"World7_Path3_Branch1_Node20",
			},
			EventPool = 810025,
		},
		World7_Path3_Branch1_Node20 = {
			BranchRoot = "World7_Path3_Branch1_Node1",
			Seed = 7031,
			ChildIdList = {
				"World7_Path4_Branch1_Node1",
				"World7_Path4_Branch2_Node1",
			},
			EventPool = 810021,
		},
		World7_Path4_Branch1_Node1 = {
			BranchRoot = "World7_Path4_Branch1_Node1",
			Seed = 7041,
			ChildIdList = {
				"World7_Path4_Branch1_Node2",
			},
			EventPool = 810020,
		},
		World7_Path4_Branch1_Node2 = {
			BranchRoot = "World7_Path4_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 7041,
			ChildIdList = {
				"World7_Path4_Branch1_Node3",
			},
			EventPool = 810005,
		},
		World7_Path4_Branch1_Node3 = {
			BranchRoot = "World7_Path4_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 7041,
			ChildIdList = {
				"World7_Path4_Branch1_Node4",
			},
			EventPool = 810005,
		},
		World7_Path4_Branch1_Node4 = {
			BranchRoot = "World7_Path4_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 7041,
			ChildIdList = {
				"World7_Path4_Branch1_Node5",
			},
			EventPool = 810005,
		},
		World7_Path4_Branch1_Node5 = {
			BranchRoot = "World7_Path4_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 7041,
			ChildIdList = {
				"World7_Path4_Branch1_Node6",
			},
			EventPool = 810005,
		},
		World7_Path4_Branch1_Node6 = {
			BranchRoot = "World7_Path4_Branch1_Node1",
			Seed = 7041,
			ChildIdList = {
				"World7_Path4_Branch1_Node7",
			},
			EventPool = 810015,
		},
		World7_Path4_Branch1_Node7 = {
			BranchRoot = "World7_Path4_Branch1_Node1",
			Seed = 7041,
			ChildIdList = {
				"World7_Path4_Branch1_Node8",
			},
			EventPool = 810026,
		},
		World7_Path4_Branch1_Node8 = {
			BranchRoot = "World7_Path4_Branch1_Node1",
			Seed = 7041,
			ChildIdList = {
				"World7_Path4_Branch1_Node9",
			},
			EventPool = 810021,
		},
		World7_Path4_Branch1_Node9 = {
			BranchRoot = "World7_Path4_Branch1_Node1",
			Seed = 7041,
			ChildIdList = {
				"World7_Path4_Branch1_Node10",
			},
			EventPool = 810024,
		},
		World7_Path4_Branch1_Node10 = {
			BranchRoot = "World7_Path4_Branch1_Node1",
			Seed = 7041,
			ChildIdList = {
				"World7_Path4_Branch1_Node11",
			},
			EventPool = 810022,
		},
		World7_Path4_Branch1_Node11 = {
			BranchRoot = "World7_Path4_Branch1_Node1",
			Seed = 7041,
			ChildIdList = {
				"World7_Path4_Branch1_Node12",
			},
			EventPool = 810016,
		},
		World7_Path4_Branch1_Node12 = {
			BranchRoot = "World7_Path4_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 7041,
			ChildIdList = {
				"World7_Path4_Branch1_Node13",
			},
			EventPool = 810004,
		},
		World7_Path4_Branch1_Node13 = {
			BranchRoot = "World7_Path4_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 7041,
			ChildIdList = {
				"World7_Path4_Branch1_Node14",
			},
			EventPool = 810004,
		},
		World7_Path4_Branch1_Node14 = {
			BranchRoot = "World7_Path4_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 7041,
			ChildIdList = {
				"World7_Path4_Branch1_Node15",
			},
			EventPool = 810004,
		},
		World7_Path4_Branch1_Node15 = {
			BranchRoot = "World7_Path4_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 7041,
			ChildIdList = {
				"World7_Path4_Branch1_Node16",
			},
			EventPool = 810004,
		},
		World7_Path4_Branch1_Node16 = {
			BranchRoot = "World7_Path4_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 7041,
			ChildIdList = {
				"World7_Path4_Branch1_Node17",
			},
			EventPool = 810004,
		},
		World7_Path4_Branch1_Node17 = {
			BranchRoot = "World7_Path4_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 7041,
			ChildIdList = {
				"World7_Path4_Branch1_Node18",
			},
			EventPool = 810004,
		},
		World7_Path4_Branch1_Node18 = {
			BranchRoot = "World7_Path4_Branch1_Node1",
			Seed = 7041,
			ChildIdList = {
				"World7_Path4_Branch1_Node19",
			},
			EventPool = 810014,
		},
		World7_Path4_Branch1_Node19 = {
			BranchRoot = "World7_Path4_Branch1_Node1",
			Seed = 7041,
			ChildIdList = {
				"World7_Path4_Branch1_Node20",
			},
			EventPool = 810024,
		},
		World7_Path4_Branch1_Node20 = {
			BranchRoot = "World7_Path4_Branch1_Node1",
			Seed = 7041,
			ChildIdList = {
				"World7_Path5_Branch1_Node1",
				"World7_Path5_Branch2_Node1",
			},
			EventPool = 810016,
		},
		World7_Path5_Branch1_Node1 = {
			BranchRoot = "World7_Path5_Branch1_Node1",
			Seed = 7051,
			ChildIdList = {
				"World7_Path5_Branch1_Node2",
			},
			EventPool = 810016,
		},
		World7_Path5_Branch1_Node2 = {
			BranchRoot = "World7_Path5_Branch1_Node1",
			Seed = 7051,
			ChildIdList = {
				"World7_Path5_Branch1_Node3",
			},
			EventPool = 810014,
		},
		World7_Path5_Branch1_Node3 = {
			BranchRoot = "World7_Path5_Branch1_Node1",
			StepScore = 50,
			Seed = 7051,
			ChildIdList = {
				"World7_Path5_Branch1_Node4",
			},
			EventPool = 810006,
		},
		World7_Path5_Branch1_Node4 = {
			BranchRoot = "World7_Path5_Branch1_Node1",
			Seed = 7051,
			ChildIdList = {
				"World7_Path5_Branch1_Node5",
			},
			EventPool = 810016,
		},
		World7_Path5_Branch1_Node5 = {
			BranchRoot = "World7_Path5_Branch1_Node1",
			Seed = 7051,
			ChildIdList = {
				"World7_Path5_Branch1_Node6",
			},
			EventPool = 810014,
		},
		World7_Path5_Branch1_Node6 = {
			BranchRoot = "World7_Path5_Branch1_Node1",
			Seed = 7051,
			ChildIdList = {
				"World7_Path5_Branch1_Node7",
			},
			EventPool = 810014,
		},
		World7_Path5_Branch1_Node7 = {
			BranchRoot = "World7_Path5_Branch1_Node1",
			Seed = 7051,
			ChildIdList = {
				"World7_Path5_Branch1_Node8",
			},
			EventPool = 810014,
		},
		World7_Path5_Branch1_Node8 = {
			BranchRoot = "World7_Path5_Branch1_Node1",
			Seed = 7051,
			ChildIdList = {
				"World7_Path5_Branch1_Node9",
			},
			EventPool = 810022,
		},
		World7_Path5_Branch1_Node9 = {
			BranchRoot = "World7_Path5_Branch1_Node1",
			Seed = 7051,
			ChildIdList = {
				"World7_Path5_Branch1_Node10",
			},
			EventPool = 810025,
		},
		World7_Path5_Branch1_Node10 = {
			BranchRoot = "World7_Path5_Branch1_Node1",
			Seed = 7051,
			ChildIdList = {
				"World7_Path5_Branch1_Node11",
			},
			EventPool = 810022,
		},
		World7_Path5_Branch1_Node11 = {
			BranchRoot = "World7_Path5_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 7051,
			ChildIdList = {
				"World7_Path5_Branch1_Node12",
			},
			EventPool = 810005,
		},
		World7_Path5_Branch1_Node12 = {
			BranchRoot = "World7_Path5_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 7051,
			ChildIdList = {
				"World7_Path5_Branch1_Node13",
			},
			EventPool = 810005,
		},
		World7_Path5_Branch1_Node13 = {
			BranchRoot = "World7_Path5_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 7051,
			ChildIdList = {
				"World7_Path5_Branch1_Node14",
			},
			EventPool = 810005,
		},
		World7_Path5_Branch1_Node14 = {
			BranchRoot = "World7_Path5_Branch1_Node1",
			StepFoodCost = 10,
			Seed = 7051,
			ChildIdList = {
				"World7_Path5_Branch1_Node15",
			},
			EventPool = 810005,
		},
		World7_Path5_Branch1_Node15 = {
			BranchRoot = "World7_Path5_Branch1_Node1",
			Seed = 7051,
			ChildIdList = {
				"World7_Path5_Branch1_Node16",
			},
			EventPool = 810016,
		},
		World7_Path5_Branch1_Node16 = {
			BranchRoot = "World7_Path5_Branch1_Node1",
			Seed = 7051,
			ChildIdList = {
				"World7_Path5_Branch1_Node17",
			},
			EventPool = 810016,
		},
		World7_Path5_Branch1_Node17 = {
			BranchRoot = "World7_Path5_Branch1_Node1",
			Seed = 7051,
			ChildIdList = {
				"World7_Path5_Branch1_Node18",
			},
			EventPool = 810016,
		},
		World7_Path5_Branch1_Node18 = {
			BranchRoot = "World7_Path5_Branch1_Node1",
			Seed = 7051,
			ChildIdList = {
				"World7_Path5_Branch1_Node19",
			},
			EventPool = 810026,
		},
		World7_Path5_Branch1_Node19 = {
			BranchRoot = "World7_Path5_Branch1_Node1",
			Seed = 7051,
			ChildIdList = {
				"World7_Path5_Branch1_Node20",
			},
			EventPool = 810025,
		},
		World7_Path5_Branch1_Node20 = {
			BranchRoot = "World7_Path5_Branch1_Node1",
			Seed = 7051,
			ChildIdList = {
				"World7_Path6_Branch1_Node1",
				"World7_Path6_Branch2_Node1",
			},
			EventPool = 810016,
		},
		World7_Path6_Branch1_Node1 = {
			BranchRoot = "World7_Path6_Branch1_Node1",
			Seed = 7061,
			ChildIdList = {
				"World7_Path6_Branch1_Node2",
			},
			EventPool = 810021,
		},
		World7_Path6_Branch1_Node2 = {
			BranchRoot = "World7_Path6_Branch1_Node1",
			Seed = 7061,
			ChildIdList = {
				"World7_Path6_Branch1_Node3",
			},
			EventPool = 810020,
		},
		World7_Path6_Branch1_Node3 = {
			BranchRoot = "World7_Path6_Branch1_Node1",
			Seed = 7061,
			ChildIdList = {
				"World7_Path6_Branch1_Node4",
			},
			EventPool = 810021,
		},
		World7_Path6_Branch1_Node4 = {
			BranchRoot = "World7_Path6_Branch1_Node1",
			Seed = 7061,
			ChildIdList = {
				"World7_Path6_Branch1_Node5",
			},
			EventPool = 810016,
		},
		World7_Path6_Branch1_Node5 = {
			BranchRoot = "World7_Path6_Branch1_Node1",
			Seed = 7061,
			ChildIdList = {
				"World7_Path6_Branch1_Node6",
			},
			EventPool = 810016,
		},
		World7_Path6_Branch1_Node6 = {
			BranchRoot = "World7_Path6_Branch1_Node1",
			Seed = 7061,
			ChildIdList = {
				"World7_Path6_Branch1_Node7",
			},
			EventPool = 810014,
		},
		World7_Path6_Branch1_Node7 = {
			BranchRoot = "World7_Path6_Branch1_Node1",
			Seed = 7061,
			ChildIdList = {
				"World7_Path6_Branch1_Node8",
			},
			EventPool = 810026,
		},
		World7_Path6_Branch1_Node8 = {
			BranchRoot = "World7_Path6_Branch1_Node1",
			Seed = 7061,
			ChildIdList = {
				"World7_Path6_Branch1_Node9",
			},
			EventPool = 810021,
		},
		World7_Path6_Branch1_Node9 = {
			BranchRoot = "World7_Path6_Branch1_Node1",
			Seed = 7061,
			ChildIdList = {
				"World7_Path6_Branch1_Node10",
			},
			EventPool = 810024,
		},
		World7_Path6_Branch1_Node10 = {
			BranchRoot = "World7_Path6_Branch1_Node1",
			Seed = 7061,
			ChildIdList = {
				"World7_Path6_Branch1_Node11",
			},
			EventPool = 810021,
		},
		World7_Path6_Branch1_Node11 = {
			BranchRoot = "World7_Path6_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 7061,
			ChildIdList = {
				"World7_Path6_Branch1_Node12",
			},
			EventPool = 810004,
		},
		World7_Path6_Branch1_Node12 = {
			BranchRoot = "World7_Path6_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 7061,
			ChildIdList = {
				"World7_Path6_Branch1_Node13",
			},
			EventPool = 810004,
		},
		World7_Path6_Branch1_Node13 = {
			BranchRoot = "World7_Path6_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 7061,
			ChildIdList = {
				"World7_Path6_Branch1_Node14",
			},
			EventPool = 810004,
		},
		World7_Path6_Branch1_Node14 = {
			BranchRoot = "World7_Path6_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 7061,
			ChildIdList = {
				"World7_Path6_Branch1_Node15",
			},
			EventPool = 810004,
		},
		World7_Path6_Branch1_Node15 = {
			BranchRoot = "World7_Path6_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 7061,
			ChildIdList = {
				"World7_Path6_Branch1_Node16",
			},
			EventPool = 810004,
		},
		World7_Path6_Branch1_Node16 = {
			BranchRoot = "World7_Path6_Branch1_Node1",
			StepFuelCost = 10,
			Seed = 7061,
			ChildIdList = {
				"World7_Path6_Branch1_Node17",
			},
			EventPool = 810004,
		},
		World7_Path6_Branch1_Node17 = {
			BranchRoot = "World7_Path6_Branch1_Node1",
			Seed = 7061,
			ChildIdList = {
				"World7_Path6_Branch1_Node18",
			},
			EventPool = 810016,
		},
		World7_Path6_Branch1_Node18 = {
			BranchRoot = "World7_Path6_Branch1_Node1",
			Seed = 7061,
			ChildIdList = {
				"World7_Path6_Branch1_Node19",
			},
			EventPool = 810015,
		},
		World7_Path6_Branch1_Node19 = {
			BranchRoot = "World7_Path6_Branch1_Node1",
			Seed = 7061,
			ChildIdList = {
				"World7_Path6_Branch1_Node20",
			},
			EventPool = 810026,
		},
		World7_Path6_Branch1_Node20 = {
			BranchRoot = "World7_Path6_Branch1_Node1",
			Seed = 7061,
			EventPool = 810023,
		},
		World7_Path2_Branch2_Node1 = {
			BranchRoot = "World7_Path2_Branch2_Node1",
			Seed = 7022,
			ChildIdList = {
				"World7_Path2_Branch2_Node2",
			},
			EventPool = 810016,
		},
		World7_Path2_Branch2_Node2 = {
			BranchRoot = "World7_Path2_Branch2_Node1",
			Seed = 7022,
			ChildIdList = {
				"World7_Path2_Branch2_Node3",
			},
			EventPool = 810016,
		},
		World7_Path2_Branch2_Node3 = {
			BranchRoot = "World7_Path2_Branch2_Node1",
			Seed = 7022,
			ChildIdList = {
				"World7_Path2_Branch2_Node4",
			},
			EventPool = 810026,
		},
		World7_Path2_Branch2_Node4 = {
			BranchRoot = "World7_Path2_Branch2_Node1",
			Seed = 7022,
			ChildIdList = {
				"World7_Path2_Branch2_Node5",
			},
			EventPool = 810016,
		},
		World7_Path2_Branch2_Node5 = {
			BranchRoot = "World7_Path2_Branch2_Node1",
			StepScore = 50,
			Seed = 7022,
			ChildIdList = {
				"World7_Path2_Branch2_Node6",
			},
			EventPool = 810006,
		},
		World7_Path2_Branch2_Node6 = {
			BranchRoot = "World7_Path2_Branch2_Node1",
			Seed = 7022,
			ChildIdList = {
				"World7_Path2_Branch2_Node7",
			},
			EventPool = 810022,
		},
		World7_Path2_Branch2_Node7 = {
			BranchRoot = "World7_Path2_Branch2_Node1",
			Seed = 7022,
			ChildIdList = {
				"World7_Path2_Branch2_Node8",
			},
			EventPool = 810020,
		},
		World7_Path2_Branch2_Node8 = {
			BranchRoot = "World7_Path2_Branch2_Node1",
			Seed = 7022,
			ChildIdList = {
				"World7_Path2_Branch2_Node9",
			},
			EventPool = 810026,
		},
		World7_Path2_Branch2_Node9 = {
			BranchRoot = "World7_Path2_Branch2_Node1",
			Seed = 7022,
			ChildIdList = {
				"World7_Path2_Branch2_Node10",
			},
			EventPool = 810025,
		},
		World7_Path2_Branch2_Node10 = {
			BranchRoot = "World7_Path2_Branch2_Node1",
			Seed = 7022,
			ChildIdList = {
				"World7_Path2_Branch2_Node11",
			},
			EventPool = 810026,
		},
		World7_Path2_Branch2_Node11 = {
			BranchRoot = "World7_Path2_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 7022,
			ChildIdList = {
				"World7_Path2_Branch2_Node12",
			},
			EventPool = 810005,
		},
		World7_Path2_Branch2_Node12 = {
			BranchRoot = "World7_Path2_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 7022,
			ChildIdList = {
				"World7_Path2_Branch2_Node13",
			},
			EventPool = 810005,
		},
		World7_Path2_Branch2_Node13 = {
			BranchRoot = "World7_Path2_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 7022,
			ChildIdList = {
				"World7_Path2_Branch2_Node14",
			},
			EventPool = 810005,
		},
		World7_Path2_Branch2_Node14 = {
			BranchRoot = "World7_Path2_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 7022,
			ChildIdList = {
				"World7_Path2_Branch2_Node15",
			},
			EventPool = 810005,
		},
		World7_Path2_Branch2_Node15 = {
			BranchRoot = "World7_Path2_Branch2_Node1",
			Seed = 7022,
			ChildIdList = {
				"World7_Path2_Branch2_Node16",
			},
			EventPool = 810026,
		},
		World7_Path2_Branch2_Node16 = {
			BranchRoot = "World7_Path2_Branch2_Node1",
			Seed = 7022,
			ChildIdList = {
				"World7_Path2_Branch2_Node17",
			},
			EventPool = 810022,
		},
		World7_Path2_Branch2_Node17 = {
			BranchRoot = "World7_Path2_Branch2_Node1",
			Seed = 7022,
			ChildIdList = {
				"World7_Path2_Branch2_Node18",
			},
			EventPool = 810026,
		},
		World7_Path2_Branch2_Node18 = {
			BranchRoot = "World7_Path2_Branch2_Node1",
			Seed = 7022,
			ChildIdList = {
				"World7_Path2_Branch2_Node19",
			},
			EventPool = 810014,
		},
		World7_Path2_Branch2_Node19 = {
			BranchRoot = "World7_Path2_Branch2_Node1",
			Seed = 7022,
			ChildIdList = {
				"World7_Path2_Branch2_Node20",
			},
			EventPool = 810024,
		},
		World7_Path2_Branch2_Node20 = {
			BranchRoot = "World7_Path2_Branch2_Node1",
			Seed = 7022,
			ChildIdList = {
				"World7_Path3_Branch1_Node1",
				"World7_Path3_Branch2_Node1",
			},
			EventPool = 810016,
		},
		World7_Path3_Branch2_Node1 = {
			BranchRoot = "World7_Path3_Branch2_Node1",
			Seed = 7032,
			ChildIdList = {
				"World7_Path3_Branch2_Node2",
			},
			EventPool = 810022,
		},
		World7_Path3_Branch2_Node2 = {
			BranchRoot = "World7_Path3_Branch2_Node1",
			Seed = 7032,
			ChildIdList = {
				"World7_Path3_Branch2_Node3",
			},
			EventPool = 810016,
		},
		World7_Path3_Branch2_Node3 = {
			BranchRoot = "World7_Path3_Branch2_Node1",
			Seed = 7032,
			ChildIdList = {
				"World7_Path3_Branch2_Node4",
			},
			EventPool = 810015,
		},
		World7_Path3_Branch2_Node4 = {
			BranchRoot = "World7_Path3_Branch2_Node1",
			StepScore = 50,
			Seed = 7032,
			ChildIdList = {
				"World7_Path3_Branch2_Node5",
			},
			EventPool = 810006,
		},
		World7_Path3_Branch2_Node5 = {
			BranchRoot = "World7_Path3_Branch2_Node1",
			Seed = 7032,
			ChildIdList = {
				"World7_Path3_Branch2_Node6",
			},
			EventPool = 810014,
		},
		World7_Path3_Branch2_Node6 = {
			BranchRoot = "World7_Path3_Branch2_Node1",
			Seed = 7032,
			ChildIdList = {
				"World7_Path3_Branch2_Node7",
			},
			EventPool = 810021,
		},
		World7_Path3_Branch2_Node7 = {
			BranchRoot = "World7_Path3_Branch2_Node1",
			Seed = 7032,
			ChildIdList = {
				"World7_Path3_Branch2_Node8",
			},
			EventPool = 810026,
		},
		World7_Path3_Branch2_Node8 = {
			BranchRoot = "World7_Path3_Branch2_Node1",
			Seed = 7032,
			ChildIdList = {
				"World7_Path3_Branch2_Node9",
			},
			EventPool = 810022,
		},
		World7_Path3_Branch2_Node9 = {
			BranchRoot = "World7_Path3_Branch2_Node1",
			Seed = 7032,
			ChildIdList = {
				"World7_Path3_Branch2_Node10",
			},
			EventPool = 810025,
		},
		World7_Path3_Branch2_Node10 = {
			BranchRoot = "World7_Path3_Branch2_Node1",
			Seed = 7032,
			ChildIdList = {
				"World7_Path3_Branch2_Node11",
			},
			EventPool = 810016,
		},
		World7_Path3_Branch2_Node11 = {
			BranchRoot = "World7_Path3_Branch2_Node1",
			Seed = 7032,
			ChildIdList = {
				"World7_Path3_Branch2_Node12",
			},
			EventPool = 810026,
		},
		World7_Path3_Branch2_Node12 = {
			BranchRoot = "World7_Path3_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 7032,
			ChildIdList = {
				"World7_Path3_Branch2_Node13",
			},
			EventPool = 810004,
		},
		World7_Path3_Branch2_Node13 = {
			BranchRoot = "World7_Path3_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 7032,
			ChildIdList = {
				"World7_Path3_Branch2_Node14",
			},
			EventPool = 810004,
		},
		World7_Path3_Branch2_Node14 = {
			BranchRoot = "World7_Path3_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 7032,
			ChildIdList = {
				"World7_Path3_Branch2_Node15",
			},
			EventPool = 810004,
		},
		World7_Path3_Branch2_Node15 = {
			BranchRoot = "World7_Path3_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 7032,
			ChildIdList = {
				"World7_Path3_Branch2_Node16",
			},
			EventPool = 810004,
		},
		World7_Path3_Branch2_Node16 = {
			BranchRoot = "World7_Path3_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 7032,
			ChildIdList = {
				"World7_Path3_Branch2_Node17",
			},
			EventPool = 810004,
		},
		World7_Path3_Branch2_Node17 = {
			BranchRoot = "World7_Path3_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 7032,
			ChildIdList = {
				"World7_Path3_Branch2_Node18",
			},
			EventPool = 810004,
		},
		World7_Path3_Branch2_Node18 = {
			BranchRoot = "World7_Path3_Branch2_Node1",
			Seed = 7032,
			ChildIdList = {
				"World7_Path3_Branch2_Node19",
			},
			EventPool = 810014,
		},
		World7_Path3_Branch2_Node19 = {
			BranchRoot = "World7_Path3_Branch2_Node1",
			Seed = 7032,
			ChildIdList = {
				"World7_Path3_Branch2_Node20",
			},
			EventPool = 810024,
		},
		World7_Path3_Branch2_Node20 = {
			BranchRoot = "World7_Path3_Branch2_Node1",
			Seed = 7032,
			ChildIdList = {
				"World7_Path4_Branch1_Node1",
				"World7_Path4_Branch2_Node1",
			},
			EventPool = 810021,
		},
		World7_Path4_Branch2_Node1 = {
			BranchRoot = "World7_Path4_Branch2_Node1",
			Seed = 7042,
			ChildIdList = {
				"World7_Path4_Branch2_Node2",
			},
			EventPool = 810015,
		},
		World7_Path4_Branch2_Node2 = {
			BranchRoot = "World7_Path4_Branch2_Node1",
			Seed = 7042,
			ChildIdList = {
				"World7_Path4_Branch2_Node3",
			},
			EventPool = 810026,
		},
		World7_Path4_Branch2_Node3 = {
			BranchRoot = "World7_Path4_Branch2_Node1",
			Seed = 7042,
			ChildIdList = {
				"World7_Path4_Branch2_Node4",
			},
			EventPool = 810021,
		},
		World7_Path4_Branch2_Node4 = {
			BranchRoot = "World7_Path4_Branch2_Node1",
			Seed = 7042,
			ChildIdList = {
				"World7_Path4_Branch2_Node5",
			},
			EventPool = 810020,
		},
		World7_Path4_Branch2_Node5 = {
			BranchRoot = "World7_Path4_Branch2_Node1",
			Seed = 7042,
			ChildIdList = {
				"World7_Path4_Branch2_Node6",
			},
			EventPool = 810026,
		},
		World7_Path4_Branch2_Node6 = {
			BranchRoot = "World7_Path4_Branch2_Node1",
			Seed = 7042,
			ChildIdList = {
				"World7_Path4_Branch2_Node7",
			},
			EventPool = 810016,
		},
		World7_Path4_Branch2_Node7 = {
			BranchRoot = "World7_Path4_Branch2_Node1",
			Seed = 7042,
			ChildIdList = {
				"World7_Path4_Branch2_Node8",
			},
			EventPool = 810026,
		},
		World7_Path4_Branch2_Node8 = {
			BranchRoot = "World7_Path4_Branch2_Node1",
			Seed = 7042,
			ChildIdList = {
				"World7_Path4_Branch2_Node9",
			},
			EventPool = 810022,
		},
		World7_Path4_Branch2_Node9 = {
			BranchRoot = "World7_Path4_Branch2_Node1",
			Seed = 7042,
			ChildIdList = {
				"World7_Path4_Branch2_Node10",
			},
			EventPool = 810024,
		},
		World7_Path4_Branch2_Node10 = {
			BranchRoot = "World7_Path4_Branch2_Node1",
			Seed = 7042,
			ChildIdList = {
				"World7_Path4_Branch2_Node11",
			},
			EventPool = 810020,
		},
		World7_Path4_Branch2_Node11 = {
			BranchRoot = "World7_Path4_Branch2_Node1",
			Seed = 7042,
			ChildIdList = {
				"World7_Path4_Branch2_Node12",
			},
			EventPool = 810026,
		},
		World7_Path4_Branch2_Node12 = {
			BranchRoot = "World7_Path4_Branch2_Node1",
			Seed = 7042,
			ChildIdList = {
				"World7_Path4_Branch2_Node13",
			},
			EventPool = 810014,
		},
		World7_Path4_Branch2_Node13 = {
			BranchRoot = "World7_Path4_Branch2_Node1",
			Seed = 7042,
			ChildIdList = {
				"World7_Path4_Branch2_Node14",
			},
			EventPool = 810022,
		},
		World7_Path4_Branch2_Node14 = {
			BranchRoot = "World7_Path4_Branch2_Node1",
			Seed = 7042,
			ChildIdList = {
				"World7_Path4_Branch2_Node15",
			},
			EventPool = 810016,
		},
		World7_Path4_Branch2_Node15 = {
			BranchRoot = "World7_Path4_Branch2_Node1",
			Seed = 7042,
			ChildIdList = {
				"World7_Path4_Branch2_Node16",
			},
			EventPool = 810015,
		},
		World7_Path4_Branch2_Node16 = {
			BranchRoot = "World7_Path4_Branch2_Node1",
			Seed = 7042,
			ChildIdList = {
				"World7_Path4_Branch2_Node17",
			},
			EventPool = 810020,
		},
		World7_Path4_Branch2_Node17 = {
			BranchRoot = "World7_Path4_Branch2_Node1",
			Seed = 7042,
			ChildIdList = {
				"World7_Path4_Branch2_Node18",
			},
			EventPool = 810014,
		},
		World7_Path4_Branch2_Node18 = {
			BranchRoot = "World7_Path4_Branch2_Node1",
			Seed = 7042,
			ChildIdList = {
				"World7_Path4_Branch2_Node19",
			},
			EventPool = 810026,
		},
		World7_Path4_Branch2_Node19 = {
			BranchRoot = "World7_Path4_Branch2_Node1",
			Seed = 7042,
			ChildIdList = {
				"World7_Path4_Branch2_Node20",
			},
			EventPool = 810024,
		},
		World7_Path4_Branch2_Node20 = {
			BranchRoot = "World7_Path4_Branch2_Node1",
			Seed = 7042,
			ChildIdList = {
				"World7_Path5_Branch1_Node1",
				"World7_Path5_Branch2_Node1",
			},
			EventPool = 810026,
		},
		World7_Path5_Branch2_Node1 = {
			BranchRoot = "World7_Path5_Branch2_Node1",
			Seed = 7052,
			ChildIdList = {
				"World7_Path5_Branch2_Node2",
			},
			EventPool = 810022,
		},
		World7_Path5_Branch2_Node2 = {
			BranchRoot = "World7_Path5_Branch2_Node1",
			Seed = 7052,
			ChildIdList = {
				"World7_Path5_Branch2_Node3",
			},
			EventPool = 810022,
		},
		World7_Path5_Branch2_Node3 = {
			BranchRoot = "World7_Path5_Branch2_Node1",
			Seed = 7052,
			ChildIdList = {
				"World7_Path5_Branch2_Node4",
			},
			EventPool = 810016,
		},
		World7_Path5_Branch2_Node4 = {
			BranchRoot = "World7_Path5_Branch2_Node1",
			StepScore = 50,
			Seed = 7052,
			ChildIdList = {
				"World7_Path5_Branch2_Node5",
			},
			EventPool = 810006,
		},
		World7_Path5_Branch2_Node5 = {
			BranchRoot = "World7_Path5_Branch2_Node1",
			Seed = 7052,
			ChildIdList = {
				"World7_Path5_Branch2_Node6",
			},
			EventPool = 810021,
		},
		World7_Path5_Branch2_Node6 = {
			BranchRoot = "World7_Path5_Branch2_Node1",
			Seed = 7052,
			ChildIdList = {
				"World7_Path5_Branch2_Node7",
			},
			EventPool = 810020,
		},
		World7_Path5_Branch2_Node7 = {
			BranchRoot = "World7_Path5_Branch2_Node1",
			Seed = 7052,
			ChildIdList = {
				"World7_Path5_Branch2_Node8",
			},
			EventPool = 810021,
		},
		World7_Path5_Branch2_Node8 = {
			BranchRoot = "World7_Path5_Branch2_Node1",
			Seed = 7052,
			ChildIdList = {
				"World7_Path5_Branch2_Node9",
			},
			EventPool = 810020,
		},
		World7_Path5_Branch2_Node9 = {
			BranchRoot = "World7_Path5_Branch2_Node1",
			Seed = 7052,
			ChildIdList = {
				"World7_Path5_Branch2_Node10",
			},
			EventPool = 810025,
		},
		World7_Path5_Branch2_Node10 = {
			BranchRoot = "World7_Path5_Branch2_Node1",
			Seed = 7052,
			ChildIdList = {
				"World7_Path5_Branch2_Node11",
			},
			EventPool = 810016,
		},
		World7_Path5_Branch2_Node11 = {
			BranchRoot = "World7_Path5_Branch2_Node1",
			Seed = 7052,
			ChildIdList = {
				"World7_Path5_Branch2_Node12",
			},
			EventPool = 810020,
		},
		World7_Path5_Branch2_Node12 = {
			BranchRoot = "World7_Path5_Branch2_Node1",
			Seed = 7052,
			ChildIdList = {
				"World7_Path5_Branch2_Node13",
			},
			EventPool = 810015,
		},
		World7_Path5_Branch2_Node13 = {
			BranchRoot = "World7_Path5_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 7052,
			ChildIdList = {
				"World7_Path5_Branch2_Node14",
			},
			EventPool = 810005,
		},
		World7_Path5_Branch2_Node14 = {
			BranchRoot = "World7_Path5_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 7052,
			ChildIdList = {
				"World7_Path5_Branch2_Node15",
			},
			EventPool = 810005,
		},
		World7_Path5_Branch2_Node15 = {
			BranchRoot = "World7_Path5_Branch2_Node1",
			StepScore = 50,
			Seed = 7052,
			ChildIdList = {
				"World7_Path5_Branch2_Node16",
			},
			EventPool = 810006,
		},
		World7_Path5_Branch2_Node16 = {
			BranchRoot = "World7_Path5_Branch2_Node1",
			StepFoodCost = 10,
			Seed = 7052,
			ChildIdList = {
				"World7_Path5_Branch2_Node17",
			},
			EventPool = 810005,
		},
		World7_Path5_Branch2_Node17 = {
			BranchRoot = "World7_Path5_Branch2_Node1",
			Seed = 7052,
			ChildIdList = {
				"World7_Path5_Branch2_Node18",
			},
			EventPool = 810015,
		},
		World7_Path5_Branch2_Node18 = {
			BranchRoot = "World7_Path5_Branch2_Node1",
			Seed = 7052,
			ChildIdList = {
				"World7_Path5_Branch2_Node19",
			},
			EventPool = 810022,
		},
		World7_Path5_Branch2_Node19 = {
			BranchRoot = "World7_Path5_Branch2_Node1",
			Seed = 7052,
			ChildIdList = {
				"World7_Path5_Branch2_Node20",
			},
			EventPool = 810024,
		},
		World7_Path5_Branch2_Node20 = {
			BranchRoot = "World7_Path5_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 7052,
			ChildIdList = {
				"World7_Path6_Branch1_Node1",
				"World7_Path6_Branch2_Node1",
			},
			EventPool = 810004,
		},
		World7_Path6_Branch2_Node1 = {
			BranchRoot = "World7_Path6_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 7062,
			ChildIdList = {
				"World7_Path6_Branch2_Node2",
			},
			EventPool = 810004,
		},
		World7_Path6_Branch2_Node2 = {
			BranchRoot = "World7_Path6_Branch2_Node1",
			StepScore = 50,
			Seed = 7062,
			ChildIdList = {
				"World7_Path6_Branch2_Node3",
			},
			EventPool = 810006,
		},
		World7_Path6_Branch2_Node3 = {
			BranchRoot = "World7_Path6_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 7062,
			ChildIdList = {
				"World7_Path6_Branch2_Node4",
			},
			EventPool = 810004,
		},
		World7_Path6_Branch2_Node4 = {
			BranchRoot = "World7_Path6_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 7062,
			ChildIdList = {
				"World7_Path6_Branch2_Node5",
			},
			EventPool = 810004,
		},
		World7_Path6_Branch2_Node5 = {
			BranchRoot = "World7_Path6_Branch2_Node1",
			StepFuelCost = 10,
			Seed = 7062,
			ChildIdList = {
				"World7_Path6_Branch2_Node6",
			},
			EventPool = 810004,
		},
		World7_Path6_Branch2_Node6 = {
			BranchRoot = "World7_Path6_Branch2_Node1",
			Seed = 7062,
			ChildIdList = {
				"World7_Path6_Branch2_Node7",
			},
			EventPool = 810015,
		},
		World7_Path6_Branch2_Node7 = {
			BranchRoot = "World7_Path6_Branch2_Node1",
			Seed = 7062,
			ChildIdList = {
				"World7_Path6_Branch2_Node8",
			},
			EventPool = 810022,
		},
		World7_Path6_Branch2_Node8 = {
			BranchRoot = "World7_Path6_Branch2_Node1",
			Seed = 7062,
			ChildIdList = {
				"World7_Path6_Branch2_Node9",
			},
			EventPool = 810014,
		},
		World7_Path6_Branch2_Node9 = {
			BranchRoot = "World7_Path6_Branch2_Node1",
			Seed = 7062,
			ChildIdList = {
				"World7_Path6_Branch2_Node10",
			},
			EventPool = 810025,
		},
		World7_Path6_Branch2_Node10 = {
			BranchRoot = "World7_Path6_Branch2_Node1",
			Seed = 7062,
			ChildIdList = {
				"World7_Path6_Branch2_Node11",
			},
			EventPool = 810016,
		},
		World7_Path6_Branch2_Node11 = {
			BranchRoot = "World7_Path6_Branch2_Node1",
			Seed = 7062,
			ChildIdList = {
				"World7_Path6_Branch2_Node12",
			},
			EventPool = 810015,
		},
		World7_Path6_Branch2_Node12 = {
			BranchRoot = "World7_Path6_Branch2_Node1",
			Seed = 7062,
			ChildIdList = {
				"World7_Path6_Branch2_Node13",
			},
			EventPool = 810015,
		},
		World7_Path6_Branch2_Node13 = {
			BranchRoot = "World7_Path6_Branch2_Node1",
			Seed = 7062,
			ChildIdList = {
				"World7_Path6_Branch2_Node14",
			},
			EventPool = 810014,
		},
		World7_Path6_Branch2_Node14 = {
			BranchRoot = "World7_Path6_Branch2_Node1",
			Seed = 7062,
			ChildIdList = {
				"World7_Path6_Branch2_Node15",
			},
			EventPool = 810016,
		},
		World7_Path6_Branch2_Node15 = {
			BranchRoot = "World7_Path6_Branch2_Node1",
			Seed = 7062,
			ChildIdList = {
				"World7_Path6_Branch2_Node16",
			},
			EventPool = 810020,
		},
		World7_Path6_Branch2_Node16 = {
			BranchRoot = "World7_Path6_Branch2_Node1",
			Seed = 7062,
			ChildIdList = {
				"World7_Path6_Branch2_Node17",
			},
			EventPool = 810016,
		},
		World7_Path6_Branch2_Node17 = {
			BranchRoot = "World7_Path6_Branch2_Node1",
			Seed = 7062,
			ChildIdList = {
				"World7_Path6_Branch2_Node18",
			},
			EventPool = 810020,
		},
		World7_Path6_Branch2_Node18 = {
			BranchRoot = "World7_Path6_Branch2_Node1",
			Seed = 7062,
			ChildIdList = {
				"World7_Path6_Branch2_Node19",
			},
			EventPool = 810020,
		},
		World7_Path6_Branch2_Node19 = {
			BranchRoot = "World7_Path6_Branch2_Node1",
			Seed = 7062,
			ChildIdList = {
				"World7_Path6_Branch2_Node20",
			},
			EventPool = 810021,
		},
		World7_Path6_Branch2_Node20 = {
			BranchRoot = "World7_Path6_Branch2_Node1",
			Seed = 7062,
			EventPool = 810023,
		},
	},
}
