HomeFurnitureConfig ={};
HomeFurnitureID = 
{
	Id001 = 1210001,
	Id002 = 1210002,
	Id003 = 1210003,
	Id004 = 1210004,
	Id005 = 1210005,
	Id006 = 1210006,
	Id007 = 1210007,
	Id008 = 1210008,
	Id009 = 1210009,
	Id010 = 1210010,
	Id011 = 1210011,
	Id012 = 1210012,
	Id013 = 1210013,
	Id014 = 1210014,
	Id015 = 1210015,
	Id016 = 1210016,
	Id017 = 1210017,
	Id018 = 1210018,
	Id019 = 1210019,
	Id020 = 1210020,
	Id021 = 1210021,
	Id022 = 1210022,
	Id023 = 1210023,
	Id024 = 1210024,
	Id025 = 1210025,
	Id026 = 1210026,
	Id027 = 1210027,
	Id028 = 1210028,
	Id029 = 1210029,
	Id030 = 1210030,
	Id031 = 1210031,
	Id032 = 1210032,
	Id033 = 1210033,
	Id034 = 1210034,
	Id035 = 1210035,
	Id036 = 1210036,
	Id037 = 1210037,
	Id038 = 1210038,
	Id039 = 1210039,
	Id040 = 1210040,
	Id041 = 1210041,
	Id042 = 1210042,
	Id043 = 1210043,
	Id044 = 1210044,
	Id045 = 1210045,
	Id046 = 1210046,
	Id047 = 1210047,
	Id048 = 1210048,
	Id049 = 1210049,
	Id050 = 1210050,
	Id051 = 1210051,
	Id052 = 1210052,
	Id053 = 1210053,
	Id054 = 1210054,
	Id055 = 1210055,
	Id056 = 1210056,
	Id057 = 1210057,
	Id058 = 1210058,
	Id059 = 1210059,
	Id060 = 1210060,
	Id061 = 1210061,
	Id062 = 1210062,
	Id063 = 1210063,
	Id064 = 1210064,
	Id065 = 1210065,
	Id066 = 1210066,
	Id067 = 1210067,
	Id068 = 1210068,
	Id069 = 1210069,
	Id070 = 1210070,
	Id071 = 1210071,
	Id072 = 1210072,
	Id073 = 1210073,
	Id074 = 1210074,
	Id075 = 1210075,
	Id076 = 1210076,
	Id077 = 1210077,
	Id078 = 1210078,
	Id079 = 1210079,
	Id080 = 1210080,
	Id081 = 1210081,
	Id082 = 1210082,
	Id083 = 1210083,
	Id084 = 1210084,
	Id085 = 1210085,
	Id086 = 1210086,
	Id087 = 1210087,
	Id088 = 1210088,
	Id089 = 1210089,
	Id090 = 1210090,
	Id091 = 1210091,
	Id092 = 1210092,
	Id093 = 1210093,
	Id094 = 1210094,
	Id095 = 1210095,
	Id096 = 1210096,
	Id097 = 1210097,
	Id098 = 1210098,
	Id099 = 1210099,
	Id100 = 1210100,
	Id101 = 1210101,
	Id102 = 1210102,
	Id103 = 1210103,
	Id104 = 1210104,
	Id105 = 1210105,
	Id106 = 1210106,
	Id107 = 1210107,
	Id108 = 1210108,
	Id109 = 1210109,
	Id110 = 1210110,
	Id111 = 1210111,
	Id112 = 1210112,
	Id113 = 1210113,
	Id114 = 1210114,
	Id115 = 1210115,
	Id116 = 1210116,
	Id117 = 1210117,
	Id118 = 1210118,
	Id119 = 1210119,
	Id120 = 1210120,
	Id121 = 1210121,
	Id122 = 1210122,
	Id123 = 1210123,
	Id124 = 1210124,
	Id125 = 1210125,
	Id126 = 1210126,
	Id127 = 1210127,
	Id128 = 1210128,
	Id129 = 1210129,
	Id130 = 1210130,
	Id131 = 1210131,
	Id132 = 1210132,
	Id133 = 1210133,
	Id134 = 1210134,
	Id135 = 1210135,
	Id136 = 1210136,
	Id137 = 1210137,
	Id138 = 1210138,
	Id139 = 1210139,
	Id140 = 1210140,
	Id141 = 1210141,
	Id142 = 1210142,
	Id143 = 1210143,
	Id144 = 1210144,
	Id145 = 1210145,
	Id146 = 1210146,
	Id147 = 1210147,
	Id148 = 1210148,
	Id149 = 1210149,
	Id150 = 1210150,
	Id151 = 1210151,
	Id152 = 1210152,
	Id153 = 1210153,
	Id154 = 1210154,
	Id155 = 1210155,
	Id156 = 1210156,
	Id157 = 1210157,
	Id158 = 1210158,
	Id159 = 1210159,
	Id160 = 1210160,
	Id161 = 1210161,
	Id162 = 1210162,
	Id163 = 1210163,
	Id164 = 1210164,
	Id165 = 1210165,
	Id166 = 1210166,
	Id167 = 1210167,
	Id168 = 1210168,
	Id169 = 1210169,
	Id170 = 1210170,
	Id171 = 1210171,
	Id172 = 1210172,
	Id173 = 1210173,
	Id174 = 1210174,
	Id175 = 1210175,
	Id176 = 1210176,
	Id177 = 1210177,
	Id178 = 1210178,
	Id179 = 1210179,
	Id180 = 1210180,
	Id181 = 1210181,
	Id182 = 1210182,
	Id183 = 1210183,
	Id184 = 1210184,
	Id185 = 1210185,
	Id186 = 1210186,
	Id187 = 1210187,
	Id188 = 1210188,
	Id189 = 1210189,
	Id190 = 1210190,
	Id191 = 1210191,
	Id192 = 1210192,
	Id193 = 1210193,
	Id194 = 1210194,
	Id195 = 1210195,
	Id196 = 1210196,
	Id197 = 1210197,
	Id198 = 1210198,
	Id199 = 1210199,
	Id200 = 1210200,
	Id201 = 1210201,
	Id202 = 1210202,
	Id203 = 1210203,
	Id204 = 1210204,
	Id205 = 1210205,
	Id206 = 1210206,
	Id207 = 1210207,
	Id208 = 1210208,
	Id209 = 1210209,
	Id210 = 1210210,
	Id211 = 1210211,
	Id212 = 1210212,
	Id213 = 1210213,
	Id214 = 1210214,
	Id215 = 1210215,
	Id216 = 1210216,
	Id217 = 1210217,
	Id218 = 1210218,
	Id219 = 1210219,
	Id220 = 1210220,
	Id221 = 1210221,
	Id222 = 1210222,
	Id223 = 1210223,
	Id224 = 1210224,
	Id225 = 1210225,
	Id226 = 1210226,
	Id227 = 1210227,
	Id228 = 1210228,
	Id229 = 1210229,
	Id230 = 1210230,
	Id231 = 1210231,
	Id232 = 1210232,
	Id233 = 1210233,
	Id234 = 1210234,
	Id235 = 1210235,
	Id236 = 1210236,
	Id237 = 1210237,
	Id238 = 1210238,
	Id239 = 1210239,
	Id240 = 1210240,
	Id241 = 1210241,
	Id242 = 1210242,
	Id243 = 1210243,
	Id244 = 1210244,
	Id245 = 1210245,
	Id246 = 1210246,
	Id247 = 1210247,
	Id248 = 1210248,
	Id249 = 1210249,
	Id250 = 1210250,
	Id251 = 1210251,
	Id252 = 1210252,
	Id253 = 1210253,
	Id254 = 1210254,
	Id255 = 1210255,
	Id256 = 1210256,
	Id257 = 1210257,
	Id258 = 1210258,
	Id259 = 1210259,
	Id260 = 1210260,
	Id261 = 1210261,
	Id262 = 1210262,
	Id263 = 1210263,
	Id264 = 1210264,
	Id265 = 1210265,
	Id266 = 1210266,
	Id267 = 1210267,
	Id268 = 1210268,
	Id269 = 1210269,
	Id270 = 1210270,
	Id271 = 1210271,
	Id272 = 1210272,
	Id273 = 1210273,
	Id274 = 1210274,
	Id275 = 1210275,
	Id276 = 1210276,
	Id277 = 1210277,
	Id278 = 1210278,
	Id279 = 1210279,
	Id280 = 1210280,
	Id281 = 1210281,
	Id282 = 1210282,
	Id283 = 1210283,
	Id284 = 1210284,
	Id285 = 1210285,
	Id286 = 1210286,
	Id287 = 1210287,
	Id288 = 1210288,
	Id289 = 1210289,
	Id290 = 1210290,
	Id291 = 1210291,
	Id292 = 1210292,
	Id293 = 1210293,
	Id294 = 1210294,
	Id295 = 1210295,
	Id296 = 1210296,
	Id297 = 1210297,
	Id298 = 1210298,
	Id299 = 1210299,
	Id300 = 1210300,
	Id301 = 1210301,
	Id302 = 1210302,
	Id303 = 1210303,
	Id304 = 1210304,
	Id305 = 1210305,
	Id306 = 1210306,
	Id307 = 1210307,
	Id308 = 1210308,
	Id309 = 1210309,
	Id310 = 1210310,
	Id311 = 1210311,
	Id312 = 1210312,
	Id313 = 1210313,
	Id314 = 1210314,
	Id315 = 1210315,
	Id316 = 1210316,
	Id317 = 1210317,
	Id318 = 1210318,
	Id319 = 1210319,
	Id320 = 1210320,
	Id321 = 1210321,
	Id322 = 1210322,
	Id323 = 1210323,
	Id324 = 1210324,
	Id325 = 1210325,
	Id326 = 1210326,
	Id327 = 1210327,
	Id328 = 1210328,
	Id329 = 1210329,
	Id330 = 1210330,
	Id331 = 1210331,
	Id332 = 1210332,
	Id333 = 1210333,
	Id334 = 1210334,
	Id335 = 1210335,
	Id336 = 1210336,
	Id337 = 1210337,
	Id338 = 1210338,
	Id339 = 1210339,
	Id340 = 1210340,
	Id341 = 1210341,
	Id342 = 1210342,
	Id343 = 1210343,
	Id344 = 1210344,
	Id345 = 1210345,
	Id346 = 1210346,
}
HomeFurnitureConfig[HomeFurnitureID.Id001] =
{
	Id = 1,
	Name = "壁挂1",
	Index = 1210001,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_BiGua001",
	Prefab = "Default_BiGua001",
	Category = 7,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id002] =
{
	Id = 2,
	Name = "壁挂2",
	Index = 1210002,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_BiGua002",
	Prefab = "Default_BiGua002",
	Category = 7,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id003] =
{
	Id = 3,
	Name = "壁挂3",
	Index = 1210003,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_BiGua003",
	Prefab = "Default_BiGua003",
	Category = 7,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id004] =
{
	Id = 4,
	Name = "壁挂4",
	Index = 1210004,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_BiGua004",
	Prefab = "Default_BiGua004",
	Category = 7,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id005] =
{
	Id = 5,
	Name = "壁挂5",
	Index = 1210005,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_BiGua005",
	Prefab = "Default_BiGua005",
	Category = 7,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id006] =
{
	Id = 6,
	Name = "壁挂6",
	Index = 1210006,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_BiGua006",
	Prefab = "Default_BiGua006",
	Category = 7,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id007] =
{
	Id = 7,
	Name = "壁挂7",
	Index = 1210007,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_BiGua007",
	Prefab = "Default_BiGua007",
	Category = 7,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id008] =
{
	Id = 8,
	Name = "冰箱1",
	Index = 1210008,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_BingXiang001",
	Prefab = "Default_BingXiang001",
	Category = 6,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id009] =
{
	Id = 9,
	Name = "电脑1",
	Index = 1210009,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_DianNao001",
	Prefab = "Default_DianNao001",
	Category = 6,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id010] =
{
	Id = 10,
	Name = "电器1",
	Index = 1210010,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_DianQi001",
	Prefab = "Default_DianQi001",
	Category = 6,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id011] =
{
	Id = 11,
	Name = "电视1",
	Index = 1210011,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_DianShi001",
	Prefab = "Default_DianShi001",
	Category = 6,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id012] =
{
	Id = 12,
	Name = "垫子1",
	Index = 1210012,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_DianZi001",
	Prefab = "Default_DianZi001",
	Category = 4,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id013] =
{
	Id = 13,
	Name = "垫子2",
	Index = 1210013,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_DianZi002",
	Prefab = "Default_DianZi002",
	Category = 4,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id014] =
{
	Id = 14,
	Name = "垫子3",
	Index = 1210014,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_DianZi003",
	Prefab = "Default_DianZi003",
	Category = 4,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id015] =
{
	Id = 15,
	Name = "垫子4",
	Index = 1210015,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_DianZi004",
	Prefab = "Default_DianZi004",
	Category = 4,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id016] =
{
	Id = 16,
	Name = "雕像1",
	Index = 1210016,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_DiaoXiang001",
	Prefab = "Default_DiaoXiang001",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id017] =
{
	Id = 17,
	Name = "柜子1",
	Index = 1210017,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_GuiZi001",
	Prefab = "Default_GuiZi001",
	Category = 1,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id018] =
{
	Id = 18,
	Name = "锅1",
	Index = 1210018,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_Guo001",
	Prefab = "Default_Guo001",
	Category = 4,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id019] =
{
	Id = 19,
	Name = "黑板1",
	Index = 1210019,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_HeiBan001",
	Prefab = "Default_HeiBan001",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id020] =
{
	Id = 20,
	Name = "艺术画1",
	Index = 1210020,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_Hua001",
	Prefab = "Default_Hua001",
	Category = 5,
	Type = 3,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id021] =
{
	Id = 21,
	Name = "键盘1",
	Index = 1210021,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_JianPan001",
	Prefab = "Default_JianPan001",
	Category = 6,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id022] =
{
	Id = 22,
	Name = "栏杆1",
	Index = 1210022,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_LanGan002",
	Prefab = "Default_LanGan002",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id023] =
{
	Id = 23,
	Name = "PlayStation51",
	Index = 1210023,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_PS5001",
	Prefab = "Default_PS5001",
	Category = 6,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id024] =
{
	Id = 24,
	Name = "沙发1",
	Index = 1210024,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ShaFa001",
	Prefab = "Default_ShaFa001",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id025] =
{
	Id = 25,
	Name = "沙发2",
	Index = 1210025,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ShaFa002",
	Prefab = "Default_ShaFa002",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id026] =
{
	Id = 26,
	Name = "沙发3",
	Index = 1210026,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ShaFa003",
	Prefab = "Default_ShaFa003",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id027] =
{
	Id = 27,
	Name = "试管1",
	Index = 1210027,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ShiGuang001",
	Prefab = "Default_ShiGuang001",
	Category = 4,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id028] =
{
	Id = 28,
	Name = "试管2",
	Index = 1210028,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ShiGuang002",
	Prefab = "Default_ShiGuang002",
	Category = 4,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id029] =
{
	Id = 29,
	Name = "试管3",
	Index = 1210029,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ShiGuang003",
	Prefab = "Default_ShiGuang003",
	Category = 4,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id030] =
{
	Id = 30,
	Name = "试管4",
	Index = 1210030,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ShiGuang004",
	Prefab = "Default_ShiGuang004",
	Category = 4,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id031] =
{
	Id = 31,
	Name = "食物1",
	Index = 1210031,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ShiWu001",
	Prefab = "Default_ShiWu001",
	Category = 4,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id032] =
{
	Id = 32,
	Name = "食物2",
	Index = 1210032,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ShiWu002",
	Prefab = "Default_ShiWu002",
	Category = 4,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id033] =
{
	Id = 33,
	Name = "鼠标1",
	Index = 1210033,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ShuBiao001",
	Prefab = "Default_ShuBiao001",
	Category = 6,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id034] =
{
	Id = 34,
	Name = "毯子1",
	Index = 1210034,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_TanZi001",
	Prefab = "Default_TanZi001",
	Category = 8,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id035] =
{
	Id = 35,
	Name = "毯子2",
	Index = 1210035,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_TanZi002",
	Prefab = "Default_TanZi002",
	Category = 8,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id036] =
{
	Id = 36,
	Name = "毯子3",
	Index = 1210036,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_TanZi003",
	Prefab = "Default_TanZi003",
	Category = 8,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id037] =
{
	Id = 37,
	Name = "毯子4",
	Index = 1210037,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_TanZi004",
	Prefab = "Default_TanZi004",
	Category = 8,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id038] =
{
	Id = 38,
	Name = "毯子5",
	Index = 1210038,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_TanZi005",
	Prefab = "Default_TanZi005",
	Category = 8,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id039] =
{
	Id = 39,
	Name = "毯子6",
	Index = 1210039,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_TanZi006",
	Prefab = "Default_TanZi006",
	Category = 8,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id040] =
{
	Id = 40,
	Name = "毯子7",
	Index = 1210040,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_TanZi007",
	Prefab = "Default_TanZi007",
	Category = 8,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id041] =
{
	Id = 41,
	Name = "望远镜1",
	Index = 1210041,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_WangYuanJing001",
	Prefab = "Default_WangYuanJing001",
	Category = 5,
	Type = 1,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id042] =
{
	Id = 42,
	Name = "玩偶1",
	Index = 1210042,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_WanOu001",
	Prefab = "Default_WanOu001",
	Category = 4,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id043] =
{
	Id = 43,
	Name = "箱子1",
	Index = 1210043,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_XiangZi001",
	Prefab = "Default_XiangZi001",
	Category = 1,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id044] =
{
	Id = 44,
	Name = "箱子2",
	Index = 1210044,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_XiangZi002",
	Prefab = "Default_XiangZi002",
	Category = 1,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id045] =
{
	Id = 45,
	Name = "音响1",
	Index = 1210045,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_YinXiang001",
	Prefab = "Default_YinXiang001",
	Category = 6,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id046] =
{
	Id = 46,
	Name = "音响2",
	Index = 1210046,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_YinXiang002",
	Prefab = "Default_YinXiang002",
	Category = 6,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id047] =
{
	Id = 47,
	Name = "音响3",
	Index = 1210047,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_YinXiang003",
	Prefab = "Default_YinXiang003",
	Category = 6,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id048] =
{
	Id = 48,
	Name = "音响4",
	Index = 1210048,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_YinXiang005",
	Prefab = "Default_YinXiang005",
	Category = 6,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id049] =
{
	Id = 49,
	Name = "椅子1",
	Index = 1210049,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_YiZi001",
	Prefab = "Default_YiZi001",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id050] =
{
	Id = 50,
	Name = "椅子2",
	Index = 1210050,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_YiZi002",
	Prefab = "Default_YiZi002",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id051] =
{
	Id = 51,
	Name = "椅子3",
	Index = 1210051,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_YiZi003",
	Prefab = "Default_YiZi003",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id052] =
{
	Id = 52,
	Name = "椅子4",
	Index = 1210052,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_YiZi004",
	Prefab = "Default_YiZi004",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id053] =
{
	Id = 53,
	Name = "椅子5",
	Index = 1210053,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_YiZi005",
	Prefab = "Default_YiZi005",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id054] =
{
	Id = 54,
	Name = "椅子6",
	Index = 1210054,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_YiZi006",
	Prefab = "Default_YiZi006",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id055] =
{
	Id = 55,
	Name = "椅子7",
	Index = 1210055,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_YiZi007",
	Prefab = "Default_YiZi007",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id056] =
{
	Id = 56,
	Name = "游戏机1",
	Index = 1210056,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_YouXiJi001",
	Prefab = "Default_YouXiJi001",
	Category = 6,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id057] =
{
	Id = 57,
	Name = "植物1",
	Index = 1210057,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhiWu001",
	Prefab = "Default_ZhiWu001",
	Category = 9,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id058] =
{
	Id = 58,
	Name = "植物2",
	Index = 1210058,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhiWu002",
	Prefab = "Default_ZhiWu002",
	Category = 9,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id059] =
{
	Id = 59,
	Name = "植物3",
	Index = 1210059,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhiWu003",
	Prefab = "Default_ZhiWu003",
	Category = 9,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id060] =
{
	Id = 60,
	Name = "植物4",
	Index = 1210060,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhiWu004",
	Prefab = "Default_ZhiWu004",
	Category = 9,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id061] =
{
	Id = 61,
	Name = "植物5",
	Index = 1210061,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_Zhiwu005",
	Prefab = "Default_Zhiwu005",
	Category = 9,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id062] =
{
	Id = 62,
	Name = "植物6",
	Index = 1210062,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_Zhiwu006",
	Prefab = "Default_Zhiwu006",
	Category = 9,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id063] =
{
	Id = 63,
	Name = "植物7",
	Index = 1210063,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_Zhiwu007",
	Prefab = "Default_Zhiwu007",
	Category = 9,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id064] =
{
	Id = 64,
	Name = "植物8",
	Index = 1210064,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhiWu008",
	Prefab = "Default_ZhiWu008",
	Category = 9,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id065] =
{
	Id = 65,
	Name = "植物9",
	Index = 1210065,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhiWu009",
	Prefab = "Default_ZhiWu009",
	Category = 9,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id066] =
{
	Id = 66,
	Name = "植物10",
	Index = 1210066,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhiWu010",
	Prefab = "Default_ZhiWu010",
	Category = 9,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id067] =
{
	Id = 67,
	Name = "植物11",
	Index = 1210067,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhiWu011",
	Prefab = "Default_ZhiWu011",
	Category = 9,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id068] =
{
	Id = 68,
	Name = "装饰1",
	Index = 1210068,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhuangShi001",
	Prefab = "Default_ZhuangShi001",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id069] =
{
	Id = 69,
	Name = "装饰2",
	Index = 1210069,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhuangShi002",
	Prefab = "Default_ZhuangShi002",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id070] =
{
	Id = 70,
	Name = "装饰3",
	Index = 1210070,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhuangShi003",
	Prefab = "Default_ZhuangShi003",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id071] =
{
	Id = 71,
	Name = "装饰4",
	Index = 1210071,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhuangShi004",
	Prefab = "Default_ZhuangShi004",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id072] =
{
	Id = 72,
	Name = "装饰5",
	Index = 1210072,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhuangShi005",
	Prefab = "Default_ZhuangShi005",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id073] =
{
	Id = 73,
	Name = "装饰6",
	Index = 1210073,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhuangShi006",
	Prefab = "Default_ZhuangShi006",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id074] =
{
	Id = 74,
	Name = "装饰7",
	Index = 1210074,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhuangShi007",
	Prefab = "Default_ZhuangShi007",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id075] =
{
	Id = 75,
	Name = "装饰8",
	Index = 1210075,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhuangShi008",
	Prefab = "Default_ZhuangShi008",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id076] =
{
	Id = 76,
	Name = "装饰9",
	Index = 1210076,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhuangShi010",
	Prefab = "Default_ZhuangShi010",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id077] =
{
	Id = 77,
	Name = "装饰10",
	Index = 1210077,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhuangShi011",
	Prefab = "Default_ZhuangShi011",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id078] =
{
	Id = 78,
	Name = "装饰11",
	Index = 1210078,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhuangShi012",
	Prefab = "Default_ZhuangShi012",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id079] =
{
	Id = 79,
	Name = "装饰12",
	Index = 1210079,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhuangShi014",
	Prefab = "Default_ZhuangShi014",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id080] =
{
	Id = 80,
	Name = "装饰13",
	Index = 1210080,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhuangShi016",
	Prefab = "Default_ZhuangShi016",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id081] =
{
	Id = 81,
	Name = "装饰14",
	Index = 1210081,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhuangShi017",
	Prefab = "Default_ZhuangShi017",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id082] =
{
	Id = 82,
	Name = "装饰15",
	Index = 1210082,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhuangShi018",
	Prefab = "Default_ZhuangShi018",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id083] =
{
	Id = 83,
	Name = "装饰16",
	Index = 1210083,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhuangShi019",
	Prefab = "Default_ZhuangShi019",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id084] =
{
	Id = 84,
	Name = "装饰17",
	Index = 1210084,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhuangShi020",
	Prefab = "Default_ZhuangShi020",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 100,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 25,
		},
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id085] =
{
	Id = 85,
	Name = "装饰18",
	Index = 1210085,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhuangShi021",
	Prefab = "Default_ZhuangShi021",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 100,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 25,
		},
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id086] =
{
	Id = 86,
	Name = "装饰19",
	Index = 1210086,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhuangShi022",
	Prefab = "Default_ZhuangShi022",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id087] =
{
	Id = 87,
	Name = "装饰20",
	Index = 1210087,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhuangShi023",
	Prefab = "Default_ZhuangShi023",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id088] =
{
	Id = 88,
	Name = "装饰21",
	Index = 1210088,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhuangShi024",
	Prefab = "Default_ZhuangShi024",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id089] =
{
	Id = 89,
	Name = "装饰22",
	Index = 1210089,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhuangShi025",
	Prefab = "Default_ZhuangShi025",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id090] =
{
	Id = 90,
	Name = "装饰23",
	Index = 1210090,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhuangShi026",
	Prefab = "Default_ZhuangShi026",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id091] =
{
	Id = 91,
	Name = "装饰24",
	Index = 1210091,
	Rarity = 1,
	SortId = 1,
	Layer = 1,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhuangShi027",
	Prefab = "Default_ZhuangShi027",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id092] =
{
	Id = 92,
	Name = "装饰25",
	Index = 1210092,
	Rarity = 1,
	SortId = 1,
	Layer = 1,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhuangShi028",
	Prefab = "Default_ZhuangShi028",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id093] =
{
	Id = 93,
	Name = "装饰26",
	Index = 1210093,
	Rarity = 1,
	SortId = 1,
	Layer = 1,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhuangShi030",
	Prefab = "Default_ZhuangShi030",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id094] =
{
	Id = 94,
	Name = "装饰27",
	Index = 1210094,
	Rarity = 1,
	SortId = 1,
	Layer = 1,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhuangShi031",
	Prefab = "Default_ZhuangShi031",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id095] =
{
	Id = 95,
	Name = "主机1",
	Index = 1210095,
	Rarity = 1,
	SortId = 1,
	Layer = 1,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhuJi001",
	Prefab = "Default_ZhuJi001",
	Category = 6,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id096] =
{
	Id = 96,
	Name = "桌子1",
	Index = 1210096,
	Rarity = 1,
	SortId = 1,
	Layer = 1,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhuoZi001",
	Prefab = "Default_ZhuoZi001",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id097] =
{
	Id = 97,
	Name = "桌子2",
	Index = 1210097,
	Rarity = 1,
	SortId = 1,
	Layer = 1,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhuoZi002",
	Prefab = "Default_ZhuoZi002",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id098] =
{
	Id = 98,
	Name = "桌子3",
	Index = 1210098,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhuoZi003",
	Prefab = "Default_ZhuoZi003",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id099] =
{
	Id = 99,
	Name = "桌子4",
	Index = 1210099,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhuoZi005",
	Prefab = "Default_ZhuoZi005",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id100] =
{
	Id = 100,
	Name = "桌子5",
	Index = 1210100,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhuoZi006",
	Prefab = "Default_ZhuoZi006",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id101] =
{
	Id = 101,
	Name = "桌子6",
	Index = 1210101,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhuoZi007",
	Prefab = "Default_ZhuoZi007",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id102] =
{
	Id = 102,
	Name = "桌子7",
	Index = 1210102,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhuoZi008",
	Prefab = "Default_ZhuoZi008",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id103] =
{
	Id = 103,
	Name = "桌子8",
	Index = 1210103,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhuoZi009",
	Prefab = "Default_ZhuoZi009",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id104] =
{
	Id = 104,
	Name = "桌子9",
	Index = 1210104,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhuoZi010",
	Prefab = "Default_ZhuoZi010",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id105] =
{
	Id = 105,
	Name = "桌子10",
	Index = 1210105,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhuoZi011",
	Prefab = "Default_ZhuoZi011",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id106] =
{
	Id = 106,
	Name = "桌子11",
	Index = 1210106,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhuoZi013",
	Prefab = "Default_ZhuoZi013",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id107] =
{
	Id = 107,
	Name = "冰箱2",
	Index = 1210107,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_BingXiang001",
	Prefab = "Default2_BingXiang001",
	Category = 6,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id108] =
{
	Id = 108,
	Name = "电脑2",
	Index = 1210108,
	Rarity = 1,
	SortId = 1,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_DianNao001",
	Prefab = "Default2_DianNao001",
	Category = 6,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id109] =
{
	Id = 109,
	Name = "电器-粉1",
	Index = 1210109,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_DianQi001",
	Prefab = "Default2_DianQi001",
	Category = 6,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id110] =
{
	Id = 110,
	Name = "电视-粉1",
	Index = 1210110,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_DianShi001",
	Prefab = "Default2_DianShi001",
	Category = 6,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id111] =
{
	Id = 111,
	Name = "垫子-粉1",
	Index = 1210111,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_DianZi001",
	Prefab = "Default2_DianZi001",
	Category = 4,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id112] =
{
	Id = 112,
	Name = "垫子-粉2",
	Index = 1210112,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_DianZi002",
	Prefab = "Default2_DianZi002",
	Category = 4,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id113] =
{
	Id = 113,
	Name = "垫子-粉3",
	Index = 1210113,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_DianZi003",
	Prefab = "Default2_DianZi003",
	Category = 4,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id114] =
{
	Id = 114,
	Name = "垫子-粉4",
	Index = 1210114,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_DianZi004",
	Prefab = "Default2_DianZi004",
	Category = 4,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id115] =
{
	Id = 115,
	Name = "柜子-粉1",
	Index = 1210115,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_GuiZi001",
	Prefab = "Default2_GuiZi001",
	Category = 1,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id116] =
{
	Id = 116,
	Name = "锅-粉1",
	Index = 1210116,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_Guo001",
	Prefab = "Default2_Guo001",
	Category = 4,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id117] =
{
	Id = 117,
	Name = "黑板-粉1",
	Index = 1210117,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_HeiBan001",
	Prefab = "Default2_HeiBan001",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id118] =
{
	Id = 118,
	Name = "键盘-粉1",
	Index = 1210118,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_JianPan001",
	Prefab = "Default2_JianPan001",
	Category = 6,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id119] =
{
	Id = 119,
	Name = "栏杆-粉1",
	Index = 1210119,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_LanGan002",
	Prefab = "Default2_LanGan002",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id120] =
{
	Id = 120,
	Name = "沙发-粉1",
	Index = 1210120,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_ShaFa001",
	Prefab = "Default2_ShaFa001",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id121] =
{
	Id = 121,
	Name = "沙发-粉2",
	Index = 1210121,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_ShaFa002",
	Prefab = "Default2_ShaFa002",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id122] =
{
	Id = 122,
	Name = "沙发-粉3",
	Index = 1210122,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_ShaFa003",
	Prefab = "Default2_ShaFa003",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id123] =
{
	Id = 123,
	Name = "鼠标-粉1",
	Index = 1210123,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_ShuBiao001",
	Prefab = "Default2_ShuBiao001",
	Category = 6,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id124] =
{
	Id = 124,
	Name = "毯子-粉1",
	Index = 1210124,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_TanZi002",
	Prefab = "Default2_TanZi002",
	Category = 8,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id125] =
{
	Id = 125,
	Name = "毯子-粉2",
	Index = 1210125,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_TanZi004",
	Prefab = "Default2_TanZi004",
	Category = 8,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id126] =
{
	Id = 126,
	Name = "毯子-粉3",
	Index = 1210126,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_TanZi005",
	Prefab = "Default2_TanZi005",
	Category = 8,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id127] =
{
	Id = 127,
	Name = "毯子-粉4",
	Index = 1210127,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_TanZi007",
	Prefab = "Default2_TanZi007",
	Category = 8,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id128] =
{
	Id = 128,
	Name = "音响-粉1",
	Index = 1210128,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_YinXiang001",
	Prefab = "Default2_YinXiang001",
	Category = 6,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id129] =
{
	Id = 129,
	Name = "音响-粉2",
	Index = 1210129,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_YinXiang002",
	Prefab = "Default2_YinXiang002",
	Category = 6,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id130] =
{
	Id = 130,
	Name = "音响-粉3",
	Index = 1210130,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_YinXiang003",
	Prefab = "Default2_YinXiang003",
	Category = 6,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id131] =
{
	Id = 131,
	Name = "椅子-粉1",
	Index = 1210131,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_YiZi001",
	Prefab = "Default2_YiZi001",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id132] =
{
	Id = 132,
	Name = "椅子-粉2",
	Index = 1210132,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_YiZi002",
	Prefab = "Default2_YiZi002",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id133] =
{
	Id = 133,
	Name = "椅子-粉3",
	Index = 1210133,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_YiZi003",
	Prefab = "Default2_YiZi003",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id134] =
{
	Id = 134,
	Name = "椅子-粉4",
	Index = 1210134,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_YiZi004",
	Prefab = "Default2_YiZi004",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id135] =
{
	Id = 135,
	Name = "椅子-粉5",
	Index = 1210135,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_YiZi005",
	Prefab = "Default2_YiZi005",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id136] =
{
	Id = 136,
	Name = "椅子-粉6",
	Index = 1210136,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_YiZi006",
	Prefab = "Default2_YiZi006",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id137] =
{
	Id = 137,
	Name = "椅子-粉7",
	Index = 1210137,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_YiZi007",
	Prefab = "Default2_YiZi007",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id138] =
{
	Id = 138,
	Name = "植物-粉1",
	Index = 1210138,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_ZhiWu002",
	Prefab = "Default2_ZhiWu002",
	Category = 9,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id139] =
{
	Id = 139,
	Name = "植物-粉2",
	Index = 1210139,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_Zhiwu006",
	Prefab = "Default2_Zhiwu006",
	Category = 9,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id140] =
{
	Id = 140,
	Name = "植物-粉3",
	Index = 1210140,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_ZhiWu008",
	Prefab = "Default2_ZhiWu008",
	Category = 9,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id141] =
{
	Id = 141,
	Name = "装饰-粉1",
	Index = 1210141,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_ZhuangShi001",
	Prefab = "Default2_ZhuangShi001",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id142] =
{
	Id = 142,
	Name = "装饰-粉2",
	Index = 1210142,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_ZhuangShi012",
	Prefab = "Default2_ZhuangShi012",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id143] =
{
	Id = 143,
	Name = "装饰-粉3",
	Index = 1210143,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_ZhuangShi014",
	Prefab = "Default2_ZhuangShi014",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id144] =
{
	Id = 144,
	Name = "装饰-粉4",
	Index = 1210144,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_ZhuangShi017",
	Prefab = "Default2_ZhuangShi017",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id145] =
{
	Id = 145,
	Name = "装饰-粉5",
	Index = 1210145,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_ZhuangShi025",
	Prefab = "Default2_ZhuangShi025",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id146] =
{
	Id = 146,
	Name = "桌子-粉1",
	Index = 1210146,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_ZhuoZi001",
	Prefab = "Default2_ZhuoZi001",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id147] =
{
	Id = 147,
	Name = "桌子-粉2",
	Index = 1210147,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_ZhuoZi002",
	Prefab = "Default2_ZhuoZi002",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id148] =
{
	Id = 148,
	Name = "桌子-粉3",
	Index = 1210148,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_ZhuoZi003",
	Prefab = "Default2_ZhuoZi003",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id149] =
{
	Id = 149,
	Name = "桌子-粉4",
	Index = 1210149,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_ZhuoZi005",
	Prefab = "Default2_ZhuoZi005",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id150] =
{
	Id = 150,
	Name = "桌子-粉5",
	Index = 1210150,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_ZhuoZi006",
	Prefab = "Default2_ZhuoZi006",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id151] =
{
	Id = 151,
	Name = "桌子-粉6",
	Index = 1210151,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_ZhuoZi007",
	Prefab = "Default2_ZhuoZi007",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id152] =
{
	Id = 152,
	Name = "桌子-粉7",
	Index = 1210152,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_ZhuoZi008",
	Prefab = "Default2_ZhuoZi008",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id153] =
{
	Id = 153,
	Name = "桌子-粉8",
	Index = 1210153,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_ZhuoZi009",
	Prefab = "Default2_ZhuoZi009",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id154] =
{
	Id = 154,
	Name = "桌子-粉9",
	Index = 1210154,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_ZhuoZi010",
	Prefab = "Default2_ZhuoZi010",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id155] =
{
	Id = 155,
	Name = "桌子-粉10",
	Index = 1210155,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_ZhuoZi011",
	Prefab = "Default2_ZhuoZi011",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id156] =
{
	Id = 156,
	Name = "桌子-粉11",
	Index = 1210156,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General2",
	Icon = "Default2_ZhuoZi013",
	Prefab = "Default2_ZhuoZi013",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id157] =
{
	Id = 157,
	Name = "冰箱-紫1",
	Index = 1210157,
	Rarity = 1,
	SortId = 2,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_BingXiang001",
	Prefab = "Default3_BingXiang001",
	Category = 6,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id158] =
{
	Id = 158,
	Name = "电脑-紫1",
	Index = 1210158,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_DianNao001",
	Prefab = "Default3_DianNao001",
	Category = 6,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id159] =
{
	Id = 159,
	Name = "电器-紫1",
	Index = 1210159,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_DianQi001",
	Prefab = "Default3_DianQi001",
	Category = 6,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id160] =
{
	Id = 160,
	Name = "电视-紫1",
	Index = 1210160,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_DianShi001",
	Prefab = "Default3_DianShi001",
	Category = 6,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id161] =
{
	Id = 161,
	Name = "垫子-紫1",
	Index = 1210161,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_DianZi001",
	Prefab = "Default3_DianZi001",
	Category = 4,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id162] =
{
	Id = 162,
	Name = "垫子-紫2",
	Index = 1210162,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_DianZi002_z",
	Prefab = "Default3_DianZi002_z",
	Category = 4,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id163] =
{
	Id = 163,
	Name = "垫子-紫3",
	Index = 1210163,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_DianZi003",
	Prefab = "Default3_DianZi003",
	Category = 4,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id164] =
{
	Id = 164,
	Name = "垫子-紫4",
	Index = 1210164,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_DianZi004",
	Prefab = "Default3_DianZi004",
	Category = 4,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id165] =
{
	Id = 165,
	Name = "柜子-紫1",
	Index = 1210165,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_GuiZi001",
	Prefab = "Default3_GuiZi001",
	Category = 1,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id166] =
{
	Id = 166,
	Name = "锅-紫1",
	Index = 1210166,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_Guo001",
	Prefab = "Default3_Guo001",
	Category = 4,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id167] =
{
	Id = 167,
	Name = "黑板-紫1",
	Index = 1210167,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_HeiBan001",
	Prefab = "Default3_HeiBan001",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id168] =
{
	Id = 168,
	Name = "键盘-紫1",
	Index = 1210168,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_JianPan001",
	Prefab = "Default3_JianPan001",
	Category = 6,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id169] =
{
	Id = 169,
	Name = "沙发-紫1",
	Index = 1210169,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_ShaFa001",
	Prefab = "Default3_ShaFa001",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id170] =
{
	Id = 170,
	Name = "沙发-紫2",
	Index = 1210170,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_ShaFa002",
	Prefab = "Default3_ShaFa002",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id171] =
{
	Id = 171,
	Name = "沙发-紫3",
	Index = 1210171,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_ShaFa003",
	Prefab = "Default3_ShaFa003",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id172] =
{
	Id = 172,
	Name = "鼠标-紫1",
	Index = 1210172,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_ShuBiao001",
	Prefab = "Default3_ShuBiao001",
	Category = 6,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id173] =
{
	Id = 173,
	Name = "毯子-紫1",
	Index = 1210173,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_TanZi002",
	Prefab = "Default3_TanZi002",
	Category = 8,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id174] =
{
	Id = 174,
	Name = "毯子-紫2",
	Index = 1210174,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_TanZi004",
	Prefab = "Default3_TanZi004",
	Category = 8,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id175] =
{
	Id = 175,
	Name = "毯子-紫3",
	Index = 1210175,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_TanZi005",
	Prefab = "Default3_TanZi005",
	Category = 8,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id176] =
{
	Id = 176,
	Name = "毯子-紫4",
	Index = 1210176,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_TanZi007",
	Prefab = "Default3_TanZi007",
	Category = 8,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id177] =
{
	Id = 177,
	Name = "音响-紫1",
	Index = 1210177,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_YinXiang001",
	Prefab = "Default3_YinXiang001",
	Category = 6,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id178] =
{
	Id = 178,
	Name = "音响-紫2",
	Index = 1210178,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_YinXiang002",
	Prefab = "Default3_YinXiang002",
	Category = 6,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id179] =
{
	Id = 179,
	Name = "音响-紫3",
	Index = 1210179,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_YinXiang003",
	Prefab = "Default3_YinXiang003",
	Category = 6,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id180] =
{
	Id = 180,
	Name = "椅子-紫1",
	Index = 1210180,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_YiZi001",
	Prefab = "Default3_YiZi001",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id181] =
{
	Id = 181,
	Name = "椅子-紫2",
	Index = 1210181,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_YiZi002",
	Prefab = "Default3_YiZi002",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id182] =
{
	Id = 182,
	Name = "椅子-紫3",
	Index = 1210182,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_YiZi003",
	Prefab = "Default3_YiZi003",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id183] =
{
	Id = 183,
	Name = "椅子-紫4",
	Index = 1210183,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_YiZi004",
	Prefab = "Default3_YiZi004",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id184] =
{
	Id = 184,
	Name = "椅子-紫5",
	Index = 1210184,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_YiZi005",
	Prefab = "Default3_YiZi005",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id185] =
{
	Id = 185,
	Name = "椅子-紫6",
	Index = 1210185,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_YiZi006",
	Prefab = "Default3_YiZi006",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id186] =
{
	Id = 186,
	Name = "椅子-紫7",
	Index = 1210186,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_YiZi007",
	Prefab = "Default3_YiZi007",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id187] =
{
	Id = 187,
	Name = "植物-紫1",
	Index = 1210187,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_Zhiwu006",
	Prefab = "Default3_Zhiwu006",
	Category = 9,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id188] =
{
	Id = 188,
	Name = "植物-紫2",
	Index = 1210188,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_ZhiWu008",
	Prefab = "Default3_ZhiWu008",
	Category = 9,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id189] =
{
	Id = 189,
	Name = "装饰-紫1",
	Index = 1210189,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_ZhuangShi001",
	Prefab = "Default3_ZhuangShi001",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id190] =
{
	Id = 190,
	Name = "装饰-紫2",
	Index = 1210190,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_ZhuangShi012",
	Prefab = "Default3_ZhuangShi012",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id191] =
{
	Id = 191,
	Name = "装饰-紫3",
	Index = 1210191,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_ZhuangShi014",
	Prefab = "Default3_ZhuangShi014",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id192] =
{
	Id = 192,
	Name = "装饰-紫4",
	Index = 1210192,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_ZhuangShi017",
	Prefab = "Default3_ZhuangShi017",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id193] =
{
	Id = 193,
	Name = "装饰-紫5",
	Index = 1210193,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_ZhuangShi025",
	Prefab = "Default3_ZhuangShi025",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id194] =
{
	Id = 194,
	Name = "桌子-紫1",
	Index = 1210194,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_ZhuoZi001",
	Prefab = "Default3_ZhuoZi001",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id195] =
{
	Id = 195,
	Name = "桌子-紫2",
	Index = 1210195,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_ZhuoZi002",
	Prefab = "Default3_ZhuoZi002",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id196] =
{
	Id = 196,
	Name = "桌子-紫3",
	Index = 1210196,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_ZhuoZi003",
	Prefab = "Default3_ZhuoZi003",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id197] =
{
	Id = 197,
	Name = "桌子-紫4",
	Index = 1210197,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_ZhuoZi005",
	Prefab = "Default3_ZhuoZi005",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id198] =
{
	Id = 198,
	Name = "桌子-紫5",
	Index = 1210198,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_ZhuoZi006",
	Prefab = "Default3_ZhuoZi006",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id199] =
{
	Id = 199,
	Name = "桌子-紫6",
	Index = 1210199,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_ZhuoZi007",
	Prefab = "Default3_ZhuoZi007",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id200] =
{
	Id = 200,
	Name = "桌子-紫7",
	Index = 1210200,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_ZhuoZi008",
	Prefab = "Default3_ZhuoZi008",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id201] =
{
	Id = 201,
	Name = "桌子-紫8",
	Index = 1210201,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_ZhuoZi009",
	Prefab = "Default3_ZhuoZi009",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id202] =
{
	Id = 202,
	Name = "桌子-紫9",
	Index = 1210202,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_ZhuoZi010",
	Prefab = "Default3_ZhuoZi010",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id203] =
{
	Id = 203,
	Name = "桌子-紫10",
	Index = 1210203,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General3",
	Icon = "Default3_ZhuoZi011",
	Prefab = "Default3_ZhuoZi011",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id204] =
{
	Id = 204,
	Name = "冰箱-蓝1",
	Index = 1210204,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_BingXiang001",
	Prefab = "Default4_BingXiang001",
	Category = 6,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id205] =
{
	Id = 205,
	Name = "电脑-蓝1",
	Index = 1210205,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_DianNao001",
	Prefab = "Default4_DianNao001",
	Category = 6,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id206] =
{
	Id = 206,
	Name = "电器-蓝1",
	Index = 1210206,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_DianQi001",
	Prefab = "Default4_DianQi001",
	Category = 6,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id207] =
{
	Id = 207,
	Name = "电视-蓝1",
	Index = 1210207,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_DianShi001",
	Prefab = "Default4_DianShi001",
	Category = 6,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id208] =
{
	Id = 208,
	Name = "垫子-蓝1",
	Index = 1210208,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_DianZi001",
	Prefab = "Default4_DianZi001",
	Category = 4,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id209] =
{
	Id = 209,
	Name = "垫子-蓝2",
	Index = 1210209,
	Rarity = 1,
	SortId = 3,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_DianZi002",
	Prefab = "Default4_DianZi002",
	Category = 4,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id210] =
{
	Id = 210,
	Name = "垫子-蓝3",
	Index = 1210210,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_DianZi003",
	Prefab = "Default4_DianZi003",
	Category = 4,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id211] =
{
	Id = 211,
	Name = "垫子-蓝4",
	Index = 1210211,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_DianZi004",
	Prefab = "Default4_DianZi004",
	Category = 4,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id212] =
{
	Id = 212,
	Name = "柜子-蓝1",
	Index = 1210212,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_GuiZi001",
	Prefab = "Default4_GuiZi001",
	Category = 1,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id213] =
{
	Id = 213,
	Name = "锅-蓝1",
	Index = 1210213,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_Guo001",
	Prefab = "Default4_Guo001",
	Category = 4,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id214] =
{
	Id = 214,
	Name = "黑板-蓝1",
	Index = 1210214,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_HeiBan001",
	Prefab = "Default4_HeiBan001",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id215] =
{
	Id = 215,
	Name = "键盘-蓝1",
	Index = 1210215,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_JianPan001",
	Prefab = "Default4_JianPan001",
	Category = 6,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id216] =
{
	Id = 216,
	Name = "栏杆-蓝1",
	Index = 1210216,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_LanGan002",
	Prefab = "Default4_LanGan002",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id217] =
{
	Id = 217,
	Name = "沙发-蓝1",
	Index = 1210217,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_ShaFa001",
	Prefab = "Default4_ShaFa001",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id218] =
{
	Id = 218,
	Name = "沙发-蓝2",
	Index = 1210218,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_ShaFa002",
	Prefab = "Default4_ShaFa002",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id219] =
{
	Id = 219,
	Name = "沙发-蓝3",
	Index = 1210219,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_ShaFa003",
	Prefab = "Default4_ShaFa003",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id220] =
{
	Id = 220,
	Name = "鼠标-蓝1",
	Index = 1210220,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_ShuBiao001",
	Prefab = "Default4_ShuBiao001",
	Category = 6,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id221] =
{
	Id = 221,
	Name = "毯子-蓝1",
	Index = 1210221,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_TanZi002",
	Prefab = "Default4_TanZi002",
	Category = 8,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id222] =
{
	Id = 222,
	Name = "毯子-蓝2",
	Index = 1210222,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_TanZi007",
	Prefab = "Default4_TanZi007",
	Category = 8,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id223] =
{
	Id = 223,
	Name = "音响-蓝1",
	Index = 1210223,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_YinXiang001",
	Prefab = "Default4_YinXiang001",
	Category = 6,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id224] =
{
	Id = 224,
	Name = "音响-蓝2",
	Index = 1210224,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_YinXiang003",
	Prefab = "Default4_YinXiang003",
	Category = 6,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id225] =
{
	Id = 225,
	Name = "音响-蓝3",
	Index = 1210225,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_YinXiang005",
	Prefab = "Default4_YinXiang005",
	Category = 6,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id226] =
{
	Id = 226,
	Name = "椅子-蓝1",
	Index = 1210226,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_YiZi001",
	Prefab = "Default4_YiZi001",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id227] =
{
	Id = 227,
	Name = "椅子-蓝2",
	Index = 1210227,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_YiZi002",
	Prefab = "Default4_YiZi002",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id228] =
{
	Id = 228,
	Name = "椅子-蓝3",
	Index = 1210228,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_YiZi003",
	Prefab = "Default4_YiZi003",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id229] =
{
	Id = 229,
	Name = "椅子-蓝4",
	Index = 1210229,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_YiZi004",
	Prefab = "Default4_YiZi004",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id230] =
{
	Id = 230,
	Name = "椅子-蓝5",
	Index = 1210230,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_YiZi005",
	Prefab = "Default4_YiZi005",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id231] =
{
	Id = 231,
	Name = "椅子-蓝6",
	Index = 1210231,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_YiZi006",
	Prefab = "Default4_YiZi006",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id232] =
{
	Id = 232,
	Name = "椅子-蓝7",
	Index = 1210232,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_YiZi007",
	Prefab = "Default4_YiZi007",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id233] =
{
	Id = 233,
	Name = "植物-蓝1",
	Index = 1210233,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_ZhiWu002",
	Prefab = "Default4_ZhiWu002",
	Category = 9,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id234] =
{
	Id = 234,
	Name = "植物-蓝2",
	Index = 1210234,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_Zhiwu006",
	Prefab = "Default4_Zhiwu006",
	Category = 9,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id235] =
{
	Id = 235,
	Name = "植物-蓝3",
	Index = 1210235,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_ZhiWu008",
	Prefab = "Default4_ZhiWu008",
	Category = 9,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id236] =
{
	Id = 236,
	Name = "装饰-蓝1",
	Index = 1210236,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_ZhuangShi001",
	Prefab = "Default4_ZhuangShi001",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id237] =
{
	Id = 237,
	Name = "装饰-蓝2",
	Index = 1210237,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_ZhuangShi012",
	Prefab = "Default4_ZhuangShi012",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id238] =
{
	Id = 238,
	Name = "装饰-蓝3",
	Index = 1210238,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_ZhuangShi014",
	Prefab = "Default4_ZhuangShi014",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id239] =
{
	Id = 239,
	Name = "装饰-蓝4",
	Index = 1210239,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_ZhuangShi017",
	Prefab = "Default4_ZhuangShi017",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id240] =
{
	Id = 240,
	Name = "装饰-蓝5",
	Index = 1210240,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_ZhuangShi025",
	Prefab = "Default4_ZhuangShi025",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id241] =
{
	Id = 241,
	Name = "桌子-蓝1",
	Index = 1210241,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_ZhuoZi001",
	Prefab = "Default4_ZhuoZi001",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id242] =
{
	Id = 242,
	Name = "桌子-蓝2",
	Index = 1210242,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_ZhuoZi002",
	Prefab = "Default4_ZhuoZi002",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id243] =
{
	Id = 243,
	Name = "桌子-蓝3",
	Index = 1210243,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_ZhuoZi003",
	Prefab = "Default4_ZhuoZi003",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id244] =
{
	Id = 244,
	Name = "桌子-蓝4",
	Index = 1210244,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_ZhuoZi005",
	Prefab = "Default4_ZhuoZi005",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id245] =
{
	Id = 245,
	Name = "桌子-蓝5",
	Index = 1210245,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_ZhuoZi006",
	Prefab = "Default4_ZhuoZi006",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id246] =
{
	Id = 246,
	Name = "桌子-蓝6",
	Index = 1210246,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_ZhuoZi007",
	Prefab = "Default4_ZhuoZi007",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id247] =
{
	Id = 247,
	Name = "桌子-蓝7",
	Index = 1210247,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_ZhuoZi008",
	Prefab = "Default4_ZhuoZi008",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id248] =
{
	Id = 248,
	Name = "桌子-蓝8",
	Index = 1210248,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_ZhuoZi009",
	Prefab = "Default4_ZhuoZi009",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id249] =
{
	Id = 249,
	Name = "桌子-蓝9",
	Index = 1210249,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_ZhuoZi010",
	Prefab = "Default4_ZhuoZi010",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id250] =
{
	Id = 250,
	Name = "桌子-蓝10",
	Index = 1210250,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_ZhuoZi011",
	Prefab = "Default4_ZhuoZi011",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id251] =
{
	Id = 251,
	Name = "桌子-蓝11",
	Index = 1210251,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_General4",
	Icon = "Default4_ZhuoZi013",
	Prefab = "Default4_ZhuoZi013",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id252] =
{
	Id = 252,
	Name = "壁挂-冒险星1",
	Index = 1210252,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_BiGua001",
	Prefab = "RPG_BiGua001",
	Category = 7,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id253] =
{
	Id = 253,
	Name = "壁挂-冒险星2",
	Index = 1210253,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_BiGua002",
	Prefab = "RPG_BiGua002",
	Category = 6,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id254] =
{
	Id = 254,
	Name = "壁挂-冒险星3",
	Index = 1210254,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_BiGua003",
	Prefab = "RPG_BiGua003",
	Category = 6,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id255] =
{
	Id = 255,
	Name = "地板-冒险星1",
	Index = 1210255,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_BiGua004",
	Prefab = "RPG_BiGua004",
	Category = 7,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id256] =
{
	Id = 256,
	Name = "地板-冒险星2",
	Index = 1210256,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_BiGua005",
	Prefab = "RPG_BiGua005",
	Category = 7,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id257] =
{
	Id = 257,
	Name = "垫子-冒险星1",
	Index = 1210257,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_DianZi001",
	Prefab = "RPG_DianZi001",
	Category = 4,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id258] =
{
	Id = 258,
	Name = "柜子-冒险星1",
	Index = 1210258,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_GuiZi001",
	Prefab = "RPG_GuiZi001",
	Category = 1,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id259] =
{
	Id = 259,
	Name = "柜子-冒险星2",
	Index = 1210259,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_GuiZi002",
	Prefab = "RPG_GuiZi002",
	Category = 1,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id260] =
{
	Id = 260,
	Name = "柜子-冒险星3",
	Index = 1210260,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_GuiZi003",
	Prefab = "RPG_GuiZi003",
	Category = 1,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id261] =
{
	Id = 261,
	Name = "柜子-冒险星4",
	Index = 1210261,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_GuiZi004",
	Prefab = "RPG_GuiZi004",
	Category = 1,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id262] =
{
	Id = 262,
	Name = "柜子-冒险星5",
	Index = 1210262,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_GuiZi005",
	Prefab = "RPG_GuiZi005",
	Category = 1,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id263] =
{
	Id = 263,
	Name = "柜子-冒险星6",
	Index = 1210263,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_GuiZi006",
	Prefab = "RPG_GuiZi006",
	Category = 1,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id264] =
{
	Id = 264,
	Name = "柜子-冒险星7",
	Index = 1210264,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_GuiZi007",
	Prefab = "RPG_GuiZi007",
	Category = 1,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id265] =
{
	Id = 265,
	Name = "柜子-冒险星8",
	Index = 1210265,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_GuiZi008",
	Prefab = "RPG_GuiZi008",
	Category = 1,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id266] =
{
	Id = 266,
	Name = "毯子-冒险星1",
	Index = 1210266,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_Tanzi001",
	Prefab = "RPG_Tanzi001",
	Category = 8,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id267] =
{
	Id = 267,
	Name = "毯子-冒险星2",
	Index = 1210267,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_TanZi002",
	Prefab = "RPG_TanZi002",
	Category = 8,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id268] =
{
	Id = 268,
	Name = "毯子-冒险星3",
	Index = 1210268,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_TanZi004",
	Prefab = "RPG_TanZi004",
	Category = 8,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id269] =
{
	Id = 269,
	Name = "毯子-冒险星4",
	Index = 1210269,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_TanZi005",
	Prefab = "RPG_TanZi005",
	Category = 8,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id270] =
{
	Id = 270,
	Name = "椅子-冒险星1",
	Index = 1210270,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_YiZi001",
	Prefab = "RPG_YiZi001",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id271] =
{
	Id = 271,
	Name = "椅子-冒险星2",
	Index = 1210271,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_YiZi002",
	Prefab = "RPG_YiZi002",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id272] =
{
	Id = 272,
	Name = "椅子-冒险星3",
	Index = 1210272,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_YiZi003",
	Prefab = "RPG_YiZi003",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id273] =
{
	Id = 273,
	Name = "椅子-冒险星4",
	Index = 1210273,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_YiZi004",
	Prefab = "RPG_YiZi004",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id274] =
{
	Id = 274,
	Name = "椅子-冒险星5",
	Index = 1210274,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_YiZi005",
	Prefab = "RPG_YiZi005",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id275] =
{
	Id = 275,
	Name = "椅子-冒险星6",
	Index = 1210275,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_YiZi006",
	Prefab = "RPG_YiZi006",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id276] =
{
	Id = 276,
	Name = "椅子-冒险星7",
	Index = 1210276,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_YiZi007",
	Prefab = "RPG_YiZi007",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id277] =
{
	Id = 277,
	Name = "椅子-冒险星8",
	Index = 1210277,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_YiZi008",
	Prefab = "RPG_YiZi008",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id278] =
{
	Id = 278,
	Name = "椅子-冒险星9",
	Index = 1210278,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_YiZi009",
	Prefab = "RPG_YiZi009",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id279] =
{
	Id = 279,
	Name = "椅子-冒险星10",
	Index = 1210279,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_YiZi010",
	Prefab = "RPG_YiZi010",
	Category = 3,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id280] =
{
	Id = 280,
	Name = "装饰-冒险星1",
	Index = 1210280,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi001",
	Prefab = "RPG_ZhuangShi001",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id281] =
{
	Id = 281,
	Name = "装饰-冒险星2",
	Index = 1210281,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi002",
	Prefab = "RPG_ZhuangShi002",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id282] =
{
	Id = 282,
	Name = "装饰-冒险星3",
	Index = 1210282,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi003",
	Prefab = "RPG_ZhuangShi003",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id283] =
{
	Id = 283,
	Name = "装饰-冒险星4",
	Index = 1210283,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi004",
	Prefab = "RPG_ZhuangShi004",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id284] =
{
	Id = 284,
	Name = "装饰-冒险星5",
	Index = 1210284,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi006",
	Prefab = "RPG_ZhuangShi006",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id285] =
{
	Id = 285,
	Name = "装饰-冒险星6",
	Index = 1210285,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi007",
	Prefab = "RPG_ZhuangShi007",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id286] =
{
	Id = 286,
	Name = "装饰-冒险星7",
	Index = 1210286,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi008",
	Prefab = "RPG_ZhuangShi008",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id287] =
{
	Id = 287,
	Name = "装饰-冒险星8",
	Index = 1210287,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi009",
	Prefab = "RPG_ZhuangShi009",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id288] =
{
	Id = 288,
	Name = "装饰-冒险星9",
	Index = 1210288,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi010",
	Prefab = "RPG_ZhuangShi010",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id289] =
{
	Id = 289,
	Name = "装饰-冒险星10",
	Index = 1210289,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi011",
	Prefab = "RPG_ZhuangShi011",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id290] =
{
	Id = 290,
	Name = "装饰-冒险星11",
	Index = 1210290,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi012",
	Prefab = "RPG_ZhuangShi012",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id291] =
{
	Id = 291,
	Name = "装饰-冒险星12",
	Index = 1210291,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi013",
	Prefab = "RPG_ZhuangShi013",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id292] =
{
	Id = 292,
	Name = "装饰-冒险星13",
	Index = 1210292,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi014",
	Prefab = "RPG_ZhuangShi014",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id293] =
{
	Id = 293,
	Name = "装饰-冒险星14",
	Index = 1210293,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi015",
	Prefab = "RPG_ZhuangShi015",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id294] =
{
	Id = 294,
	Name = "装饰-冒险星15",
	Index = 1210294,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi016",
	Prefab = "RPG_ZhuangShi016",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id295] =
{
	Id = 295,
	Name = "装饰-冒险星16",
	Index = 1210295,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi017",
	Prefab = "RPG_ZhuangShi017",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id296] =
{
	Id = 296,
	Name = "装饰-冒险星17",
	Index = 1210296,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi018",
	Prefab = "RPG_ZhuangShi018",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id297] =
{
	Id = 297,
	Name = "装饰-冒险星18",
	Index = 1210297,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi019",
	Prefab = "RPG_ZhuangShi019",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id298] =
{
	Id = 298,
	Name = "装饰-冒险星19",
	Index = 1210298,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi020",
	Prefab = "RPG_ZhuangShi020",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id299] =
{
	Id = 299,
	Name = "装饰-冒险星20",
	Index = 1210299,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi021",
	Prefab = "RPG_ZhuangShi021",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id300] =
{
	Id = 300,
	Name = "装饰-冒险星21",
	Index = 1210300,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi022",
	Prefab = "RPG_ZhuangShi022",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id301] =
{
	Id = 301,
	Name = "装饰-冒险星22",
	Index = 1210301,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi023",
	Prefab = "RPG_ZhuangShi023",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id302] =
{
	Id = 302,
	Name = "装饰-冒险星23",
	Index = 1210302,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi024",
	Prefab = "RPG_ZhuangShi024",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id303] =
{
	Id = 303,
	Name = "装饰-冒险星24",
	Index = 1210303,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi025",
	Prefab = "RPG_ZhuangShi025",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id304] =
{
	Id = 304,
	Name = "装饰-冒险星25",
	Index = 1210304,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi026",
	Prefab = "RPG_ZhuangShi026",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id305] =
{
	Id = 305,
	Name = "装饰-冒险星26",
	Index = 1210305,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi027",
	Prefab = "RPG_ZhuangShi027",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id306] =
{
	Id = 306,
	Name = "装饰-冒险星27",
	Index = 1210306,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi028",
	Prefab = "RPG_ZhuangShi028",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id307] =
{
	Id = 307,
	Name = "装饰-冒险星28",
	Index = 1210307,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi030",
	Prefab = "RPG_ZhuangShi030",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id308] =
{
	Id = 308,
	Name = "装饰-冒险星29",
	Index = 1210308,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi031",
	Prefab = "RPG_ZhuangShi031",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id309] =
{
	Id = 309,
	Name = "装饰-冒险星30",
	Index = 1210309,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi032",
	Prefab = "RPG_ZhuangShi032",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id310] =
{
	Id = 310,
	Name = "装饰-冒险星31",
	Index = 1210310,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi033",
	Prefab = "RPG_ZhuangShi033",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id311] =
{
	Id = 311,
	Name = "装饰-冒险星32",
	Index = 1210311,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi034",
	Prefab = "RPG_ZhuangShi034",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id312] =
{
	Id = 312,
	Name = "装饰-冒险星33",
	Index = 1210312,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi035",
	Prefab = "RPG_ZhuangShi035",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id313] =
{
	Id = 313,
	Name = "装饰-冒险星34",
	Index = 1210313,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi036",
	Prefab = "RPG_ZhuangShi036",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id314] =
{
	Id = 314,
	Name = "装饰-冒险星35",
	Index = 1210314,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi038",
	Prefab = "RPG_ZhuangShi038",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id315] =
{
	Id = 315,
	Name = "装饰-冒险星36",
	Index = 1210315,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi039",
	Prefab = "RPG_ZhuangShi039",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id316] =
{
	Id = 316,
	Name = "装饰-冒险星37",
	Index = 1210316,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi040",
	Prefab = "RPG_ZhuangShi040",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id317] =
{
	Id = 317,
	Name = "装饰-冒险星38",
	Index = 1210317,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi041",
	Prefab = "RPG_ZhuangShi041",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id318] =
{
	Id = 318,
	Name = "装饰-冒险星39",
	Index = 1210318,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi042",
	Prefab = "RPG_ZhuangShi042",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id319] =
{
	Id = 319,
	Name = "装饰-冒险星40",
	Index = 1210319,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi043",
	Prefab = "RPG_ZhuangShi043",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id320] =
{
	Id = 320,
	Name = "装饰-冒险星41",
	Index = 1210320,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi044",
	Prefab = "RPG_ZhuangShi044",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id321] =
{
	Id = 321,
	Name = "装饰-冒险星42",
	Index = 1210321,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi045",
	Prefab = "RPG_ZhuangShi045",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id322] =
{
	Id = 322,
	Name = "装饰-冒险星43",
	Index = 1210322,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi046",
	Prefab = "RPG_ZhuangShi046",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id323] =
{
	Id = 323,
	Name = "装饰-冒险星44",
	Index = 1210323,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi047",
	Prefab = "RPG_ZhuangShi047",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id324] =
{
	Id = 324,
	Name = "装饰-冒险星45",
	Index = 1210324,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi048",
	Prefab = "RPG_ZhuangShi048",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id325] =
{
	Id = 325,
	Name = "装饰-冒险星46",
	Index = 1210325,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi049",
	Prefab = "RPG_ZhuangShi049",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id326] =
{
	Id = 326,
	Name = "装饰-冒险星47",
	Index = 1210326,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi050",
	Prefab = "RPG_ZhuangShi050",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id327] =
{
	Id = 327,
	Name = "装饰-冒险星48",
	Index = 1210327,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi051",
	Prefab = "RPG_ZhuangShi051",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id328] =
{
	Id = 328,
	Name = "装饰-冒险星49",
	Index = 1210328,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi052",
	Prefab = "RPG_ZhuangShi052",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id329] =
{
	Id = 329,
	Name = "装饰-冒险星50",
	Index = 1210329,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi053",
	Prefab = "RPG_ZhuangShi053",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id330] =
{
	Id = 330,
	Name = "装饰-冒险星51",
	Index = 1210330,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi055",
	Prefab = "RPG_ZhuangShi055",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id331] =
{
	Id = 331,
	Name = "装饰-冒险星52",
	Index = 1210331,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi056",
	Prefab = "RPG_ZhuangShi056",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id332] =
{
	Id = 332,
	Name = "装饰-冒险星53",
	Index = 1210332,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi057",
	Prefab = "RPG_ZhuangShi057",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id333] =
{
	Id = 333,
	Name = "装饰-冒险星54",
	Index = 1210333,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi058",
	Prefab = "RPG_ZhuangShi058",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id334] =
{
	Id = 334,
	Name = "装饰-冒险星55",
	Index = 1210334,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi059",
	Prefab = "RPG_ZhuangShi059",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id335] =
{
	Id = 335,
	Name = "装饰-冒险星56",
	Index = 1210335,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi060",
	Prefab = "RPG_ZhuangShi060",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id336] =
{
	Id = 336,
	Name = "装饰-冒险星57",
	Index = 1210336,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi061",
	Prefab = "RPG_ZhuangShi061",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id337] =
{
	Id = 337,
	Name = "装饰-冒险星58",
	Index = 1210337,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi062",
	Prefab = "RPG_ZhuangShi062",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id338] =
{
	Id = 338,
	Name = "装饰-冒险星59",
	Index = 1210338,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi063",
	Prefab = "RPG_ZhuangShi063",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id339] =
{
	Id = 339,
	Name = "装饰-冒险星60",
	Index = 1210339,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi064",
	Prefab = "RPG_ZhuangShi064",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id340] =
{
	Id = 340,
	Name = "装饰-冒险星61",
	Index = 1210340,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi065",
	Prefab = "RPG_ZhuangShi065",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id341] =
{
	Id = 341,
	Name = "装饰-冒险星62",
	Index = 1210341,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi066",
	Prefab = "RPG_ZhuangShi066",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id342] =
{
	Id = 342,
	Name = "装饰-冒险星63",
	Index = 1210342,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuangShi067",
	Prefab = "RPG_ZhuangShi067",
	Category = 5,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id343] =
{
	Id = 343,
	Name = "桌子-冒险星1",
	Index = 1210343,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuoZi001",
	Prefab = "RPG_ZhuoZi001",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id344] =
{
	Id = 344,
	Name = "桌子-冒险星2",
	Index = 1210344,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuoZi002",
	Prefab = "RPG_ZhuoZi002",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id345] =
{
	Id = 345,
	Name = "桌子-冒险星3",
	Index = 1210345,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuoZi003",
	Prefab = "RPG_ZhuoZi003",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}
HomeFurnitureConfig[HomeFurnitureID.Id346] =
{
	Id = 346,
	Name = "桌子-冒险星4",
	Index = 1210346,
	Rarity = 1,
	SortId = 4,
	Layer = 2,
	IconAtlas = "HomeFurnitureIcon_RPG",
	Icon = "RPG_ZhuoZi004",
	Prefab = "RPG_ZhuoZi004",
	Category = 2,
	Type = 0,
	DeliveryTime = 300,
	CostList = {
		{
			Id = 321001,
			Num = 500,
		},
	},
	SellingTime = 3600,
	SellList = {
		{
			Id = 321001,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
	From = {
		{
			SourceType  = SourceType.HomeFurnitureSell,
		},
		{
			SourceType  = SourceType.HomeFurnitureGashapon,
		},
		{
			SourceType  = SourceType.ClearObstacle,
		},
	},
}

