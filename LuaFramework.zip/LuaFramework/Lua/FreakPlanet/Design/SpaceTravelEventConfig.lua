SpaceTravelEventConfig ={};
SpaceTravelEventID = 
{
	Id001 = 820001,
	Id002 = 820002,
	Id003 = 820003,
	Id004 = 820004,
	Id005 = 820005,
	Id006 = 820006,
	Id007 = 820007,
	Id008 = 820008,
	Id009 = 820009,
	Id010 = 820010,
	Id011 = 820011,
	Id012 = 820012,
	Id013 = 820013,
	Id014 = 820014,
	Id015 = 820015,
	Id016 = 820016,
	Id017 = 820017,
	Id018 = 820018,
	Id019 = 820019,
	Id020 = 820020,
	Id021 = 820021,
	Id022 = 820022,
	Id023 = 820023,
	Id024 = 820024,
	Id025 = 820025,
	Id026 = 820026,
	Id027 = 820027,
	Id028 = 820028,
	Id029 = 820029,
	Id030 = 820030,
	Id031 = 820031,
	Id032 = 820032,
	Id033 = 820033,
	Id034 = 820034,
	Id035 = 820035,
	Id036 = 820036,
	Id037 = 820037,
	Id038 = 820038,
	Id039 = 820039,
	Id040 = 820040,
	Id041 = 820041,
	Id042 = 820042,
	Id043 = 820043,
	Id044 = 820044,
	Id045 = 820045,
	Id046 = 820046,
	Id047 = 820047,
	Id048 = 820048,
	Id049 = 820049,
	Id050 = 820050,
	Id051 = 820051,
	Id052 = 820052,
	Id053 = 820053,
	Id054 = 820054,
	Id055 = 820055,
	Id056 = 820056,
	Id057 = 820057,
	Id058 = 820058,
	Id059 = 820059,
	Id060 = 820060,
	Id061 = 820061,
	Id062 = 820062,
	Id063 = 820063,
	Id064 = 820064,
	Id065 = 820065,
	Id066 = 820066,
	Id067 = 820067,
	Id068 = 820068,
	Id069 = 820069,
	Id070 = 820070,
	Id071 = 820071,
	Id072 = 820072,
	Id073 = 820073,
	Id074 = 820074,
	Id075 = 820075,
	Id076 = 820076,
	Id077 = 820077,
	Id078 = 820078,
	Id079 = 820079,
	Id080 = 820080,
	Id081 = 820081,
	Id082 = 820082,
	Id083 = 820083,
	Id084 = 820084,
	Id085 = 820085,
	Id086 = 820086,
	Id087 = 820087,
	Id088 = 820088,
	Id089 = 820089,
	Id090 = 820090,
	Id091 = 820091,
	Id092 = 820092,
	Id093 = 820093,
	Id094 = 820094,
	Id095 = 820095,
	Id096 = 820096,
	Id097 = 820097,
	Id098 = 820098,
	Id099 = 820099,
	Id100 = 820100,
	Id101 = 820101,
	Id102 = 820102,
	Id103 = 820103,
	Id104 = 820104,
	Id105 = 820105,
	Id106 = 820106,
	Id107 = 820107,
	Id108 = 820108,
	Id109 = 820109,
	Id110 = 820110,
	Id111 = 820111,
	Id112 = 820112,
	Id113 = 820113,
	Id114 = 820114,
	Id115 = 820115,
	Id116 = 820116,
	Id117 = 820117,
	Id118 = 820118,
	Id119 = 820119,
	Id120 = 820120,
	Id121 = 820121,
	Id122 = 820122,
	Id123 = 820123,
	Id124 = 820124,
	Id125 = 820125,
	Id126 = 820126,
	Id127 = 820127,
	Id128 = 820128,
	Id129 = 820129,
	Id130 = 820130,
	Id131 = 820131,
	Id132 = 820132,
	Id133 = 820133,
	Id134 = 820134,
	Id135 = 820135,
	Id136 = 820136,
	Id137 = 820137,
	Id138 = 820138,
	Id139 = 820139,
	Id140 = 820140,
	Id141 = 820141,
	Id142 = 820142,
	Id143 = 820143,
	Id144 = 820144,
	Id145 = 820145,
	Id146 = 820146,
	Id147 = 820147,
	Id148 = 820148,
	Id149 = 820149,
	Id150 = 820150,
	Id151 = 820151,
	Id152 = 820152,
	Id153 = 820153,
	Id154 = 820154,
	Id155 = 820155,
}
SpaceTravelEventConfig[SpaceTravelEventID.Id001] =
{
	Id = 1,
	Name = "loc_ItemName_242",
	Desc = "抵达目标，当前为无人区。",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830001,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 0,
							NumMax = 10,
						},
					},
				},
				{
					Id = 830002,
					Weight = 100,
					PreCondition = {
						 {
							Value = 101,
							NumMin = 1,
							NumMax = 100,
						},
					},
				},
				{
					Id = 830003,
					Weight = 100,
					PreCondition = {
						 {
							Value = 103,
							NumMin = 1,
							NumMax = 100,
						},
					},
				},
				{
					Id = 830004,
					Weight = 50,
					PreCondition = {
						 {
							Value = 106,
							NumMin = 500,
							NumMax = 99999,
						},
					},
				},
				{
					Id = 830005,
					Weight = 10,
				},
				{
					Id = 830006,
					Weight = 10,
				},
				{
					Id = 830007,
					Weight = 10,
				},
				{
					Id = 830008,
					Weight = 5,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830009,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id002] =
{
	Id = 2,
	Name = "劫掠事件",
	Desc = "收到来自观光飞船的求救信号，希望帮助驱赶海盗。",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830010,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830011,
					Weight = 75,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830012,
					Weight = 50,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id003] =
{
	Id = 3,
	Name = "物资转卖站",
	Desc = "客人，这里是正规的联邦补给站点，请问你需要什么服务吗？",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_3",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830013,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830014,
					Weight = 75,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830015,
					Weight = 50,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id004] =
{
	Id = 4,
	Name = "推进器营销中心",
	Desc = "这位外星的朋友，我这里有原厂直销全新未拆的定点推进装置，现在只要5个发条，来一个吗？",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_9",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830016,
					Weight = 100,
				},
				{
					Id = 830017,
					Weight = 100,
				},
				{
					Id = 830018,
					Weight = 100,
				},
				{
					Id = 830019,
					Weight = 100,
				},
				{
					Id = 830020,
					Weight = 100,
				},
				{
					Id = 830021,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830022,
					Weight = 75,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id005] =
{
	Id = 5,
	Name = "熄火的飞船",
	Desc = "前方发现熄火飞船，对方向我们请求工具或技术支援。",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830023,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830024,
					Weight = 75,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830025,
					Weight = 50,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id006] =
{
	Id = 6,
	Name = "求救信号",
	Desc = "收到隶属魔王集团的飞船求救信号。一伙宇宙海盗正试图登陆他们飞船。",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830037,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830038,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830039,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id007] =
{
	Id = 7,
	Name = "求救信号",
	Desc = "大人好，小的们是魔王集团的员工，飞船遭遇陨石雨，燃料泄露，能借些燃料给小的们吗？",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_1",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830040,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830041,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830042,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id008] =
{
	Id = 8,
	Name = "求救信号",
	Desc = "我是冒险家协会的负责人，目前正在追击海盗，愿意协助我们吗？",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_2",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830043,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830044,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830045,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id009] =
{
	Id = 9,
	Name = "求救信号",
	Desc = "（对方前行登录我方飞船）我们是冒险家协会成员，飘荡很久了，可以给我们些食物吗？",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_2",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830046,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830047,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830048,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id010] =
{
	Id = 10,
	Name = "星际追尾事故",
	Desc = "前方路段发生事故，一艘勇者飞船追尾了魔王集团飞船，是否帮助其中一方？",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830049,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830050,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830051,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id011] =
{
	Id = 11,
	Name = "星际械斗事故",
	Desc = "前方路段发生斗殴事件，与事双方为魔王集团骨头兵与冒险家协会成员，是否介入？",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830052,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830053,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830054,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id012] =
{
	Id = 12,
	Name = "陨石地带",
	Desc = "进入了陨石带，前方有大量障碍物，飞船很难顺利通过。",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830026,
					Weight = 100,
				},
				{
					Id = 830027,
					Weight = 75,
				},
				{
					Id = 830028,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830029,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id013] =
{
	Id = 13,
	Name = "太阳耀斑",
	Desc = "该地区受到太阳耀斑影响，飞船电子设备故障中。",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830030,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771002,
							NumMin = 3,
							NumMax = 9999,
						},
					},
				},
				{
					Id = 830031,
					Weight = 1,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830032,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id014] =
{
	Id = 14,
	Name = "曲率空间",
	Desc = "进入曲速空间，附近漂浮着定点前进装置。",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830033,
					Weight = 100,
				},
				{
					Id = 830034,
					Weight = 75,
				},
				{
					Id = 830035,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830036,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id015] =
{
	Id = 15,
	Name = "魔王集团竞答",
	Desc = "欢迎来到魔王竞答！以下哪条不是魔王集团始终受到大众推崇的理由？",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_1",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830055,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830056,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830057,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id016] =
{
	Id = 16,
	Name = "魔王集团竞答",
	Desc = "欢迎来到魔王竞答！问，小魔王大人是什么属性的？",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_1",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830058,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830059,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id017] =
{
	Id = 17,
	Name = "魔王集团竞答",
	Desc = "欢迎来到魔王竞答！问，魔王集团打算推出付费复活服务，你认为？",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_1",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830060,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830061,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830062,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id018] =
{
	Id = 18,
	Name = "冒险家协会竞答",
	Desc = "这里是冒险家竞答！问，勇者连续征讨魔王失败，你认为？",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_2",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830063,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830064,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830065,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id019] =
{
	Id = 19,
	Name = "冒险家协会竞答",
	Desc = "这里是冒险家竞答！问，世界是被什么人保护着的？",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_2",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830066,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830067,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id020] =
{
	Id = 20,
	Name = "冒险家协会竞答",
	Desc = "这里是冒险家竞答！问，魔王集团打算推出付费复活服务，你认为？",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_2",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830068,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830069,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830070,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id021] =
{
	Id = 21,
	Name = "漂浮的宝箱",
	Desc = "发现宝箱空间站，是否要登陆探索？",
	IconBG = "SpaceTravel_Null_EventBG_3",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830071,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830072,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id022] =
{
	Id = 22,
	Name = "漂浮的宝箱",
	Desc = "发现宝箱空间站，探测器发现特殊信号，是否要登陆探索？",
	IconBG = "SpaceTravel_Null_EventBG_3",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830073,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830074,
					Weight = 100,
				},
				{
					Id = 830075,
					Weight = 100,
				},
				{
					Id = 830076,
					Weight = 100,
				},
				{
					Id = 830077,
					Weight = 100,
				},
				{
					Id = 830078,
					Weight = 100,
				},
				{
					Id = 830079,
					Weight = 100,
				},
				{
					Id = 830080,
					Weight = 100,
				},
				{
					Id = 830081,
					Weight = 100,
				},
				{
					Id = 830082,
					Weight = 100,
				},
				{
					Id = 830083,
					Weight = 100,
				},
				{
					Id = 830084,
					Weight = 100,
				},
				{
					Id = 830085,
					Weight = 100,
				},
				{
					Id = 830086,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830087,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id023] =
{
	Id = 23,
	Name = "遭遇海盗了",
	Desc = "喂！小子，我们是星际海盗，乖乖把钱交出来，否则就狠狠修理你们！",
	IconBG = "SpaceTravel_Battle_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_6",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830088,
					Weight = 100,
				},
				{
					Id = 830089,
					Weight = 100,
				},
				{
					Id = 830090,
					Weight = 100,
				},
				{
					Id = 830091,
					Weight = 100,
				},
				{
					Id = 830092,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830093,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id024] =
{
	Id = 24,
	Name = "星际加油站",
	Desc = "欢迎光临联邦补给中心，请问需要什么服务？",
	IconBG = "SpaceTravel_Explore_EventBG_4",
	Icon = "SpaceTravel_CampEnemy_4",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830094,
					Weight = 100,
				},
			},
		},
		{
			Prop = 75,
			ChoiceList = {
				{
					Id = 830095,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830096,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id025] =
{
	Id = 25,
	Name = "星际美食城",
	Desc = "欢迎光临星际美食站，请问客人需要吃点什么？",
	IconBG = "SpaceTravel_Explore_EventBG_9",
	Icon = "SpaceTravel_CampEnemy_11",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830097,
					Weight = 100,
				},
			},
		},
		{
			Prop = 75,
			ChoiceList = {
				{
					Id = 830098,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830099,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id026] =
{
	Id = 26,
	Name = "地区-交易",
	Desc = "你好，朋友，小店提供回收及出售必需品服务，要看下吗？",
	IconBG = "SpaceTravel_Exchange_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_9",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830100,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830101,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830102,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771008,
							NumMin = 1,
							NumMax = 9999,
						},
					},
				},
				{
					Id = 830103,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771009,
							NumMin = 1,
							NumMax = 9999,
						},
					},
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id027] =
{
	Id = 27,
	Name = "宝石加工商",
	Desc = "尊敬的客人，小店有大量高档宝石，有什么需要只管吩咐。",
	IconBG = "SpaceTravel_Explore_EventBG_11",
	Icon = "SpaceTravel_CampEnemy_3",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830104,
					Weight = 100,
				},
				{
					Id = 830105,
					Weight = 100,
				},
				{
					Id = 830106,
					Weight = 100,
				},
				{
					Id = 830107,
					Weight = 100,
				},
				{
					Id = 830108,
					Weight = 100,
				},
				{
					Id = 830109,
					Weight = 100,
				},
				{
					Id = 830110,
					Weight = 100,
				},
				{
					Id = 830111,
					Weight = 100,
				},
				{
					Id = 830112,
					Weight = 100,
				},
				{
					Id = 830113,
					Weight = 100,
				},
				{
					Id = 830114,
					Weight = 100,
				},
				{
					Id = 830115,
					Weight = 100,
				},
				{
					Id = 830116,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830117,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773001,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830118,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773006,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830119,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773011,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830120,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773016,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830121,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773021,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830122,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773026,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830123,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773031,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830124,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773036,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830125,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773041,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830126,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773046,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830127,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773051,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830128,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773056,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830129,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773061,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830130,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773001,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830131,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773006,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830132,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773011,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830133,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773016,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830134,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773021,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830135,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773026,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830136,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773031,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830137,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773036,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830138,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773041,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830139,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773046,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830140,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773051,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830141,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773056,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830142,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773061,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830143,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773001,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830144,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773006,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830145,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773011,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830146,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773016,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830147,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773021,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830148,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773026,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830149,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773031,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830150,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773036,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830151,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773041,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830152,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773046,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830153,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773051,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830154,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773056,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830155,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773061,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830156,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773001,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830157,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773006,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830158,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773011,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830159,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773016,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830160,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773021,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830161,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773026,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830162,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773031,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830163,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773036,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830164,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773041,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830165,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773046,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830166,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773051,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830167,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773056,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830168,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773061,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830169,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773066,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830170,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773071,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830171,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773076,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830172,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773081,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830173,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773086,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830174,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773091,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830175,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773096,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830176,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773101,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830177,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773106,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830178,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773111,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830179,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773116,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830180,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773121,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830181,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773126,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830182,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773131,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830183,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773136,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830184,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773141,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830185,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773146,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830186,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773151,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830187,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773156,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830188,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773161,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830189,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773166,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830190,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773171,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830191,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773176,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830192,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773181,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830193,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773186,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830194,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773191,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830195,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773196,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830196,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773201,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830197,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773206,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830198,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773211,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830199,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773216,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830200,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773221,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830201,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773226,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830202,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773231,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830203,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773236,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830204,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773241,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830205,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773246,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830206,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773251,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830207,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773256,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830208,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id028] =
{
	Id = 28,
	Name = "地区-Boss点",
	Desc = "欢迎来到中转中心，系统目前出现重大霸格，请问客人能帮助我们吗？",
	IconBG = "SpaceTravel_Boss_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830209,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830210,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830211,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id029] =
{
	Id = 29,
	Name = "魔王集团分部",
	Desc = "抱歉，大人！上头有令，见您一次就得打您一次，请大人别怪小的！",
	FriendlinessId = 780001,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_1",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830212,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830213,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830214,
					Weight = 1,
				},
				{
					Id = 830215,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771001,
							NumMin = 15,
							NumMax = 9999,
						},
					},
				},
				{
					Id = 830216,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771002,
							NumMin = 10,
							NumMax = 9999,
						},
					},
				},
				{
					Id = 830217,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771004,
							NumMin = 5,
							NumMax = 9999,
						},
					},
				},
				{
					Id = 830218,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771005,
							NumMin = 8,
							NumMax = 9999,
						},
					},
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id030] =
{
	Id = 30,
	Name = "魔王集团分部",
	Desc = "大人，这里不欢迎您，请您不要再来找我们了！",
	FriendlinessId = 780001,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_1",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830219,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830220,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830221,
					Weight = 100,
				},
				{
					Id = 830222,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771001,
							NumMin = 12,
							NumMax = 9999,
						},
					},
				},
				{
					Id = 830223,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771002,
							NumMin = 8,
							NumMax = 9999,
						},
					},
				},
				{
					Id = 830224,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771004,
							NumMin = 4,
							NumMax = 9999,
						},
					},
				},
				{
					Id = 830225,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771005,
							NumMin = 6,
							NumMax = 9999,
						},
					},
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id031] =
{
	Id = 31,
	Name = "魔王集团分部",
	Desc = "请问这位客人需要什么服务？",
	FriendlinessId = 780001,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_1",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830226,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830227,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830228,
					Weight = 100,
				},
				{
					Id = 830229,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771001,
							NumMin = 9,
							NumMax = 9999,
						},
					},
				},
				{
					Id = 830230,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771002,
							NumMin = 6,
							NumMax = 9999,
						},
					},
				},
				{
					Id = 830231,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771004,
							NumMin = 3,
							NumMax = 9999,
						},
					},
				},
				{
					Id = 830232,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771005,
							NumMin = 5,
							NumMax = 9999,
						},
					},
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id032] =
{
	Id = 32,
	Name = "魔王集团分部",
	Desc = "请问这位客人需要什么服务？",
	FriendlinessId = 780001,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_1",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830233,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830234,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830235,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 8,
							NumMax = 99999,
						},
					},
				},
				{
					Id = 830236,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 8,
							NumMax = 99999,
						},
					},
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id033] =
{
	Id = 33,
	Name = "魔王集团分部",
	Desc = "请问这位客人需要什么服务？",
	FriendlinessId = 780001,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_1",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830237,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830238,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830239,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 8,
							NumMax = 99999,
						},
					},
				},
				{
					Id = 830240,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 8,
							NumMax = 99999,
						},
					},
				},
				{
					Id = 830241,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 13,
							NumMax = 99999,
						},
					},
				},
				{
					Id = 830242,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 13,
							NumMax = 99999,
						},
					},
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id034] =
{
	Id = 34,
	Name = "魔王集团分部",
	Desc = "啊，大人终于来了，这次是要去很远的地方吧？",
	FriendlinessId = 780001,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_1",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830243,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830244,
					Weight = 100,
				},
			},
		},
		{
			Prop = 70,
			ChoiceList = {
				{
					Id = 830245,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 8,
							NumMax = 99999,
						},
					},
				},
				{
					Id = 830246,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 8,
							NumMax = 99999,
						},
					},
				},
			},
		},
		{
			Prop = 30,
			ChoiceList = {
				{
					Id = 830247,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 11,
							NumMax = 99999,
						},
					},
				},
				{
					Id = 830248,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 11,
							NumMax = 99999,
						},
					},
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id035] =
{
	Id = 35,
	Name = "魔王集团分部",
	Desc = "啊，大人终于来了，有什么是小的们可以提供的请尽管开口。",
	FriendlinessId = 780001,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_1",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830249,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830250,
					Weight = 100,
				},
			},
		},
		{
			Prop = 70,
			ChoiceList = {
				{
					Id = 830251,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 200,
							NumMax = 99999,
						},
					},
				},
				{
					Id = 830252,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 200,
							NumMax = 99999,
						},
					},
				},
			},
		},
		{
			Prop = 30,
			ChoiceList = {
				{
					Id = 830253,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 8,
							NumMax = 99999,
						},
					},
				},
				{
					Id = 830254,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 8,
							NumMax = 99999,
						},
					},
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id036] =
{
	Id = 36,
	Name = "协会分部",
	Desc = "贼人落网了！来人哪！关门放狗！",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_2",
	Icon = "SpaceTravel_CampEnemy_2",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830257,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830258,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830259,
					Weight = 1,
				},
				{
					Id = 830260,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771001,
							NumMin = 15,
							NumMax = 9999,
						},
					},
				},
				{
					Id = 830261,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771002,
							NumMin = 10,
							NumMax = 9999,
						},
					},
				},
				{
					Id = 830262,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771004,
							NumMin = 5,
							NumMax = 9999,
						},
					},
				},
				{
					Id = 830263,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771005,
							NumMin = 8,
							NumMax = 9999,
						},
					},
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id037] =
{
	Id = 37,
	Name = "协会分部",
	Desc = "你如果想来找事的话，我们一定会让你吃不了兜着走的！",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_2",
	Icon = "SpaceTravel_CampEnemy_2",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830264,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830265,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830266,
					Weight = 100,
				},
				{
					Id = 830267,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771001,
							NumMin = 12,
							NumMax = 9999,
						},
					},
				},
				{
					Id = 830268,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771002,
							NumMin = 8,
							NumMax = 9999,
						},
					},
				},
				{
					Id = 830269,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771004,
							NumMin = 4,
							NumMax = 9999,
						},
					},
				},
				{
					Id = 830270,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771005,
							NumMin = 6,
							NumMax = 9999,
						},
					},
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id038] =
{
	Id = 38,
	Name = "协会分部",
	Desc = "请问这位客人需要什么服务？",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_2",
	Icon = "SpaceTravel_CampEnemy_2",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830271,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830272,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830273,
					Weight = 100,
				},
				{
					Id = 830274,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771001,
							NumMin = 9,
							NumMax = 9999,
						},
					},
				},
				{
					Id = 830275,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771002,
							NumMin = 6,
							NumMax = 9999,
						},
					},
				},
				{
					Id = 830276,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771004,
							NumMin = 3,
							NumMax = 9999,
						},
					},
				},
				{
					Id = 830277,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771005,
							NumMin = 5,
							NumMax = 9999,
						},
					},
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id039] =
{
	Id = 39,
	Name = "协会分部",
	Desc = "请问这位客人需要什么服务？",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_2",
	Icon = "SpaceTravel_CampEnemy_2",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830278,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830279,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830280,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 8,
							NumMax = 99999,
						},
					},
				},
				{
					Id = 830281,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 8,
							NumMax = 99999,
						},
					},
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id040] =
{
	Id = 40,
	Name = "协会分部",
	Desc = "请问这位客人需要什么服务？",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_2",
	Icon = "SpaceTravel_CampEnemy_2",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830282,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830283,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830284,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 8,
							NumMax = 99999,
						},
					},
				},
				{
					Id = 830285,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 8,
							NumMax = 99999,
						},
					},
				},
				{
					Id = 830286,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 13,
							NumMax = 99999,
						},
					},
				},
				{
					Id = 830287,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 13,
							NumMax = 99999,
						},
					},
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id041] =
{
	Id = 41,
	Name = "协会分部",
	Desc = "好朋友！你怎么来了，需要什么帮助赶紧说。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_2",
	Icon = "SpaceTravel_CampEnemy_2",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830288,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830289,
					Weight = 100,
				},
			},
		},
		{
			Prop = 70,
			ChoiceList = {
				{
					Id = 830290,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 8,
							NumMax = 99999,
						},
					},
				},
				{
					Id = 830291,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 8,
							NumMax = 99999,
						},
					},
				},
			},
		},
		{
			Prop = 30,
			ChoiceList = {
				{
					Id = 830292,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 11,
							NumMax = 99999,
						},
					},
				},
				{
					Id = 830293,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 11,
							NumMax = 99999,
						},
					},
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id042] =
{
	Id = 42,
	Name = "协会分部",
	Desc = "好兄弟，你可来了！怎么样，需要什么尽管说！",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_2",
	Icon = "SpaceTravel_CampEnemy_2",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830294,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830295,
					Weight = 100,
				},
			},
		},
		{
			Prop = 70,
			ChoiceList = {
				{
					Id = 830296,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 200,
							NumMax = 99999,
						},
					},
				},
				{
					Id = 830297,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 200,
							NumMax = 99999,
						},
					},
				},
			},
		},
		{
			Prop = 30,
			ChoiceList = {
				{
					Id = 830298,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 8,
							NumMax = 99999,
						},
					},
				},
				{
					Id = 830299,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 8,
							NumMax = 99999,
						},
					},
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id043] =
{
	Id = 43,
	Name = "任务：与魔王集团交易",
	Desc = "收到了魔王集团的交易邀请函。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830302,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830303,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id044] =
{
	Id = 44,
	Name = "任务：魔王集团竞答",
	Desc = "收到了魔王集团的竞答邀请函。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830304,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830305,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id045] =
{
	Id = 45,
	Name = "任务：与海盗战斗",
	Desc = "收到了星际联邦发布的通缉令。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830306,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830307,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id046] =
{
	Id = 46,
	Name = "任务：登陆发现",
	Desc = "收到了“发现者协会”提交的委托。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830308,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830309,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id047] =
{
	Id = 47,
	Name = "任务：整理船舱",
	Desc = "收到了“船舱清理委员会”提交的委托。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830310,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830311,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id048] =
{
	Id = 48,
	Name = "任务：战斗考验",
	Desc = "收到了冒险家协会发出的委托。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830312,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830313,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id049] =
{
	Id = 49,
	Name = "任务：驱赶海盗",
	Desc = "收到了冒险家协会发出的委托。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830314,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830315,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id050] =
{
	Id = 50,
	Name = "任务：谈判专家",
	Desc = "收到了“谈判协会”提出的委托。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830316,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830317,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id051] =
{
	Id = 51,
	Name = "任务：矿石收集",
	Desc = "收到了“发现者协会”提交的委托。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830318,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830319,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id052] =
{
	Id = 52,
	Name = "任务：矿石丰收",
	Desc = "收到了“发现者协会”提交的委托。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830320,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830321,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id053] =
{
	Id = 53,
	Name = "任务：圆锯爱好者",
	Desc = "收到了“发现者协会”提交的委托。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830322,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830323,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id054] =
{
	Id = 54,
	Name = "任务：圆锯大师",
	Desc = "收到了“发现者协会”提交的委托。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830324,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830325,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id055] =
{
	Id = 55,
	Name = "任务：购买补给",
	Desc = "收到了“贸易协会”提交的委托。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830326,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830327,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id056] =
{
	Id = 56,
	Name = "任务：补给抄底",
	Desc = "收到了“贸易协会”提交的委托。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830328,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830329,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id057] =
{
	Id = 57,
	Name = "任务：出售发条",
	Desc = "收到了“贸易协会”提交的委托。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830330,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830331,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id058] =
{
	Id = 58,
	Name = "任务：发条抛售",
	Desc = "收到了“贸易协会”提交的委托。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830332,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830333,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id059] =
{
	Id = 59,
	Name = "任务：提交矿石",
	Desc = "收到了魔王集团提交的委托。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830334,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830335,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id060] =
{
	Id = 60,
	Name = "任务：使用补给",
	Desc = "收到了道具测试公司提交的委托。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830336,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830337,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id061] =
{
	Id = 61,
	Name = "任务：艺术品",
	Desc = "收到了博物馆星提交的委托。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830338,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830339,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id062] =
{
	Id = 62,
	Name = "任务：星海航行",
	Desc = "收到了星际航行主办发提交的委托。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830340,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830341,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id063] =
{
	Id = 63,
	Name = "任务：快速航行",
	Desc = "收到了星际航行主办发提交的委托。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830342,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830343,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id064] =
{
	Id = 64,
	Name = "任务：魔王集团友好度",
	Desc = "收到了星际航行主办发提交的委托。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830344,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830345,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id065] =
{
	Id = 65,
	Name = "任务：提升魔王集团友好度",
	Desc = "收到了星际航行主办发提交的委托。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830346,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830347,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id066] =
{
	Id = 66,
	Name = "任务：合成补给",
	Desc = "收到了飞船制造公司提交的委托。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830348,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830349,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id067] =
{
	Id = 67,
	Name = "loc_ItemName_242",
	Desc = "抵达目标，当前为无人区。",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830350,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 0,
							NumMax = 10,
						},
					},
				},
				{
					Id = 830351,
					Weight = 100,
					PreCondition = {
						 {
							Value = 101,
							NumMin = 1,
							NumMax = 100,
						},
					},
				},
				{
					Id = 830352,
					Weight = 100,
					PreCondition = {
						 {
							Value = 103,
							NumMin = 1,
							NumMax = 100,
						},
					},
				},
				{
					Id = 830353,
					Weight = 50,
					PreCondition = {
						 {
							Value = 106,
							NumMin = 500,
							NumMax = 99999,
						},
					},
				},
				{
					Id = 830354,
					Weight = 10,
				},
				{
					Id = 830355,
					Weight = 10,
				},
				{
					Id = 830356,
					Weight = 10,
				},
				{
					Id = 830357,
					Weight = 5,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830358,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id068] =
{
	Id = 68,
	Name = "诡异的信号",
	Desc = "当前为无人区，雷达探测到不明信号！",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830359,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830360,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id069] =
{
	Id = 69,
	Name = "信号来源",
	Desc = "已抵达信号来源地，发现还在工作的老旧信号站。",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 0,
			ChoiceList = {
				{
					Id = 830361,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771017,
							NumMin = 1,
							NumMax = 999,
						},
					},
				},
				{
					Id = 830362,
					Weight = 50,
					PreCondition = {
						 {
							Value = 771014,
							NumMin = 1,
							NumMax = 999,
						},
					},
				},
				{
					Id = 830363,
					Weight = 10,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830364,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id070] =
{
	Id = 70,
	Name = "信号来源",
	Desc = "已抵达信号来源地，发现了正在进行爆破作业的海盗。",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830365,
					Weight = 100,
				},
				{
					Id = 830366,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830367,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id071] =
{
	Id = 71,
	Name = "信号来源",
	Desc = "已抵达信号来源地，发现原石矿区。",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 1,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830368,
					Weight = 100,
				},
				{
					Id = 830369,
					Weight = 100,
				},
				{
					Id = 830370,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id072] =
{
	Id = 72,
	Name = "魔王集团乐透开奖",
	Desc = "收到了来自魔王集团的本次乐透中奖名单。",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830371,
					Weight = 10,
					PreCondition = {
						 {
							Value = 770301,
							NumMin = 1,
							NumMax = 999,
						},
					},
				},
				{
					Id = 830372,
					Weight = 90,
					PreCondition = {
						 {
							Value = 770301,
							NumMin = 1,
							NumMax = 999,
						},
					},
				},
				{
					Id = 830373,
					Weight = 900,
					PreCondition = {
						 {
							Value = 770301,
							NumMin = 1,
							NumMax = 999,
						},
					},
				},
				{
					Id = 830374,
					Weight = 9000,
					PreCondition = {
						 {
							Value = 770301,
							NumMin = 1,
							NumMax = 999,
						},
					},
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830375,
					Weight = 5,
					PreCondition = {
						 {
							Value = 770301,
							NumMin = 1,
							NumMax = 999,
						},
					},
				},
				{
					Id = 830376,
					Weight = 145,
					PreCondition = {
						 {
							Value = 770301,
							NumMin = 1,
							NumMax = 999,
						},
					},
				},
				{
					Id = 830377,
					Weight = 850,
					PreCondition = {
						 {
							Value = 770301,
							NumMin = 1,
							NumMax = 999,
						},
					},
				},
				{
					Id = 830378,
					Weight = 9000,
					PreCondition = {
						 {
							Value = 770301,
							NumMin = 1,
							NumMax = 999,
						},
					},
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830379,
					Weight = 10,
					PreCondition = {
						 {
							Value = 770301,
							NumMin = 1,
							NumMax = 999,
						},
					},
				},
				{
					Id = 830380,
					Weight = 90,
					PreCondition = {
						 {
							Value = 770301,
							NumMin = 1,
							NumMax = 999,
						},
					},
				},
				{
					Id = 830381,
					Weight = 1000,
					PreCondition = {
						 {
							Value = 770301,
							NumMin = 1,
							NumMax = 999,
						},
					},
				},
				{
					Id = 830382,
					Weight = 8900,
					PreCondition = {
						 {
							Value = 770301,
							NumMin = 1,
							NumMax = 999,
						},
					},
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id073] =
{
	Id = 73,
	Name = "冒险家协会乐透开奖",
	Desc = "收到了来自冒险家协会的本次乐透中奖名单。",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830383,
					Weight = 10,
					PreCondition = {
						 {
							Value = 770304,
							NumMin = 1,
							NumMax = 999,
						},
					},
				},
				{
					Id = 830384,
					Weight = 90,
					PreCondition = {
						 {
							Value = 770304,
							NumMin = 1,
							NumMax = 999,
						},
					},
				},
				{
					Id = 830385,
					Weight = 900,
					PreCondition = {
						 {
							Value = 770304,
							NumMin = 1,
							NumMax = 999,
						},
					},
				},
				{
					Id = 830386,
					Weight = 9000,
					PreCondition = {
						 {
							Value = 770304,
							NumMin = 1,
							NumMax = 999,
						},
					},
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830387,
					Weight = 5,
					PreCondition = {
						 {
							Value = 770304,
							NumMin = 1,
							NumMax = 999,
						},
					},
				},
				{
					Id = 830388,
					Weight = 145,
					PreCondition = {
						 {
							Value = 770304,
							NumMin = 1,
							NumMax = 999,
						},
					},
				},
				{
					Id = 830389,
					Weight = 850,
					PreCondition = {
						 {
							Value = 770304,
							NumMin = 1,
							NumMax = 999,
						},
					},
				},
				{
					Id = 830390,
					Weight = 9000,
					PreCondition = {
						 {
							Value = 770304,
							NumMin = 1,
							NumMax = 999,
						},
					},
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830391,
					Weight = 10,
					PreCondition = {
						 {
							Value = 770304,
							NumMin = 1,
							NumMax = 999,
						},
					},
				},
				{
					Id = 830392,
					Weight = 90,
					PreCondition = {
						 {
							Value = 770304,
							NumMin = 1,
							NumMax = 999,
						},
					},
				},
				{
					Id = 830393,
					Weight = 1000,
					PreCondition = {
						 {
							Value = 770304,
							NumMin = 1,
							NumMax = 999,
						},
					},
				},
				{
					Id = 830394,
					Weight = 8900,
					PreCondition = {
						 {
							Value = 770304,
							NumMin = 1,
							NumMax = 999,
						},
					},
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id074] =
{
	Id = 74,
	Name = "劫掠事件",
	Desc = "收到来自观光飞船的求救信号，希望帮助驱赶海盗。",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830395,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830396,
					Weight = 75,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830397,
					Weight = 50,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id075] =
{
	Id = 75,
	Name = "物资转卖站",
	Desc = "客人，这里是正规的联邦补给站点，请问你需要什么服务吗？",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_3",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830398,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830399,
					Weight = 75,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830400,
					Weight = 50,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id076] =
{
	Id = 76,
	Name = "推进器营销中心",
	Desc = "这位外星的朋友，我这里有原厂直销全新未拆的定点推进装置，现在只要5个发条，来一个吗？",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_9",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830401,
					Weight = 100,
				},
				{
					Id = 830402,
					Weight = 100,
				},
				{
					Id = 830403,
					Weight = 100,
				},
				{
					Id = 830404,
					Weight = 100,
				},
				{
					Id = 830405,
					Weight = 100,
				},
				{
					Id = 830406,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830407,
					Weight = 75,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id077] =
{
	Id = 77,
	Name = "熄火的飞船",
	Desc = "前方发现熄火飞船，对方向我们请求工具或技术支援。",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830408,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830409,
					Weight = 75,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830410,
					Weight = 50,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id078] =
{
	Id = 78,
	Name = "被困的工程师",
	Desc = "前方求救信号，一名工程师被锁在了飞船外，急需帮助。",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830411,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830412,
					Weight = 75,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830413,
					Weight = 50,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id079] =
{
	Id = 79,
	Name = "求救信号",
	Desc = "收到隶属魔王集团的飞船求救信号。一伙宇宙海盗正试图登陆他们飞船。",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830425,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830426,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830427,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id080] =
{
	Id = 80,
	Name = "求救信号",
	Desc = "大人好，小的们是魔王集团的员工，飞船遭遇陨石雨，燃料泄露，能借些燃料给小的们吗？",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_1",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830428,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830429,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830430,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id081] =
{
	Id = 81,
	Name = "求救信号",
	Desc = "我是冒险家协会的负责人，目前正在追击海盗，愿意协助我们吗？",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_2",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830431,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830432,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830433,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id082] =
{
	Id = 82,
	Name = "求救信号",
	Desc = "（对方前行登录我方飞船）我们是冒险家协会成员，飘荡很久了，可以给我们些食物吗？",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_2",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830434,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830435,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830436,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id083] =
{
	Id = 83,
	Name = "星际追尾事故",
	Desc = "前方路段发生事故，一艘勇者飞船追尾了魔王集团飞船，是否帮助其中一方？",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830437,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830438,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830439,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id084] =
{
	Id = 84,
	Name = "星际械斗事故",
	Desc = "前方路段发生斗殴事件，与事双方为魔王集团骨头兵与冒险家协会成员，是否介入？",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830440,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830441,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830442,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id085] =
{
	Id = 85,
	Name = "陨石地带",
	Desc = "进入了陨石带，前方有大量障碍物，飞船很难顺利通过。",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830414,
					Weight = 100,
				},
				{
					Id = 830415,
					Weight = 75,
				},
				{
					Id = 830416,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830417,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id086] =
{
	Id = 86,
	Name = "太阳耀斑",
	Desc = "该地区受到太阳耀斑影响，飞船电子设备故障中。",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830418,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771002,
							NumMin = 3,
							NumMax = 9999,
						},
					},
				},
				{
					Id = 830419,
					Weight = 1,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830420,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id087] =
{
	Id = 87,
	Name = "曲率空间",
	Desc = "进入曲速空间，附近漂浮着定点前进装置。",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830421,
					Weight = 100,
				},
				{
					Id = 830422,
					Weight = 75,
				},
				{
					Id = 830423,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830424,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id088] =
{
	Id = 88,
	Name = "魔王集团竞答",
	Desc = "欢迎来到魔王竞答！以下哪条不是魔王集团始终受到大众推崇的理由？",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_1",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830443,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830444,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830445,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id089] =
{
	Id = 89,
	Name = "魔王集团竞答",
	Desc = "欢迎来到魔王竞答！问，小魔王大人是什么属性的？",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_1",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830446,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830447,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id090] =
{
	Id = 90,
	Name = "魔王集团竞答",
	Desc = "欢迎来到魔王竞答！问，魔王集团打算推出付费复活服务，你认为？",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_1",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830448,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830449,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830450,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id091] =
{
	Id = 91,
	Name = "恶人守则竞答",
	Desc = "在海滩中看到正在堆沙堡的小朋友，应该怎么做呢？",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_2",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830451,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830452,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830453,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id092] =
{
	Id = 92,
	Name = "恶人守则竞答",
	Desc = "航行中遇到了呼救的冒险者！要怎么做？",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_2",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830454,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830455,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830456,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id093] =
{
	Id = 93,
	Name = "恶人守则竞答",
	Desc = "在被联邦追捕时打算拐弯，遇到红灯，应该怎么做？",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_2",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830457,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830458,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830459,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id094] =
{
	Id = 94,
	Name = "魔王集团竞答",
	Desc = "下面哪个角色不是大坏蛋？",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_2",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830460,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830461,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830462,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id095] =
{
	Id = 95,
	Name = "魔王集团竞答",
	Desc = "以下哪首是帅气的大反派才拥有的BGM？",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_2",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830463,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830464,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830465,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id096] =
{
	Id = 96,
	Name = "魔王集团竞答",
	Desc = "知名的超级大反派库巴的英文名字是？",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_2",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830466,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830467,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830468,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id097] =
{
	Id = 97,
	Name = "魔王集团竞答",
	Desc = "魔王城堡正在考虑乔迁新址，你有什么好建议吗？",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_2",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830469,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830470,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830471,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id098] =
{
	Id = 98,
	Name = "冒险家协会竞答",
	Desc = "这里是冒险家竞答！问，勇者连续征讨魔王失败，你认为？",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_2",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830472,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830473,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830474,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id099] =
{
	Id = 99,
	Name = "冒险家协会竞答",
	Desc = "这里是冒险家竞答！问，世界是被什么人保护着的？",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_2",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830475,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830476,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id100] =
{
	Id = 100,
	Name = "冒险家协会竞答",
	Desc = "这里是冒险家竞答！问，魔王集团打算推出付费复活服务，你认为？",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_2",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830477,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830478,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830479,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id101] =
{
	Id = 101,
	Name = "联邦常识竞答",
	Desc = "飞船在无人的空间路口右转时，应该注意什么？",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_2",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830480,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830481,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830482,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id102] =
{
	Id = 102,
	Name = "联邦常识竞答",
	Desc = "飞船遇到陨石雨临时停车时，应该开什么灯？",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_2",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830483,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830484,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830485,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id103] =
{
	Id = 103,
	Name = "联邦常识竞答",
	Desc = "飞船在主干道行驶，在路口交汇处时，为了防止与支路驶入的飞船相撞，应该怎么做？",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_2",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830486,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830487,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830488,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id104] =
{
	Id = 104,
	Name = "冒险家协会竞答",
	Desc = "《塞尔达传说》系列的主角——伟大的冒险家是？",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_2",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830489,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830490,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id105] =
{
	Id = 105,
	Name = "冒险家协会竞答",
	Desc = "当冒险家在冒险过程中遇到了打不过的魔王首领该怎么办？",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_2",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830491,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830492,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830493,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id106] =
{
	Id = 106,
	Name = "冒险家协会竞答",
	Desc = "冒险家捡到了一把神器大剑却无法使用，最可能是因为什么数值不够？",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_2",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830494,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830495,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830496,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id107] =
{
	Id = 107,
	Name = "冒险家协会竞答",
	Desc = "关于属性克制，在游戏中至关重要，那么土属性克制哪个属性？",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_2",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830497,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830498,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830499,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id108] =
{
	Id = 108,
	Name = "冒险家协会竞答",
	Desc = "在星际旅行时发现了失传的珍宝，应该怎么做？",
	IconBG = "SpaceTravel_Null_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_2",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830500,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830501,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830502,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id109] =
{
	Id = 109,
	Name = "漂浮的宝箱",
	Desc = "发现宝箱空间站，是否要登陆探索？",
	IconBG = "SpaceTravel_Null_EventBG_3",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830503,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830504,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id110] =
{
	Id = 110,
	Name = "漂浮的宝箱",
	Desc = "发现宝箱空间站，探测器发现特殊信号，是否要登陆探索？",
	IconBG = "SpaceTravel_Null_EventBG_3",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830505,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830506,
					Weight = 100,
				},
				{
					Id = 830507,
					Weight = 100,
				},
				{
					Id = 830508,
					Weight = 100,
				},
				{
					Id = 830509,
					Weight = 100,
				},
				{
					Id = 830510,
					Weight = 100,
				},
				{
					Id = 830511,
					Weight = 100,
				},
				{
					Id = 830512,
					Weight = 100,
				},
				{
					Id = 830513,
					Weight = 100,
				},
				{
					Id = 830514,
					Weight = 100,
				},
				{
					Id = 830515,
					Weight = 100,
				},
				{
					Id = 830516,
					Weight = 100,
				},
				{
					Id = 830517,
					Weight = 100,
				},
				{
					Id = 830518,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830519,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id111] =
{
	Id = 111,
	Name = "遭遇海盗了",
	Desc = "喂！小子，我们是星际海盗，乖乖把钱交出来，否则就狠狠修理你们！",
	IconBG = "SpaceTravel_Battle_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_6",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 66,
			ChoiceList = {
				{
					Id = 830520,
					Weight = 100,
				},
				{
					Id = 830521,
					Weight = 100,
				},
				{
					Id = 830522,
					Weight = 100,
				},
				{
					Id = 830523,
					Weight = 100,
				},
				{
					Id = 830524,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830530,
					Weight = 100,
				},
				{
					Id = 830525,
					Weight = 100,
				},
				{
					Id = 830526,
					Weight = 100,
				},
				{
					Id = 830527,
					Weight = 100,
				},
				{
					Id = 830528,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830529,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id112] =
{
	Id = 112,
	Name = "星际加油站",
	Desc = "欢迎光临联邦补给中心，请问需要什么服务？",
	IconBG = "SpaceTravel_Explore_EventBG_4",
	Icon = "SpaceTravel_CampEnemy_4",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830531,
					Weight = 100,
				},
			},
		},
		{
			Prop = 75,
			ChoiceList = {
				{
					Id = 830532,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830533,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id113] =
{
	Id = 113,
	Name = "星际美食城",
	Desc = "欢迎光临星际美食站，请问客人需要吃点什么？",
	IconBG = "SpaceTravel_Explore_EventBG_9",
	Icon = "SpaceTravel_CampEnemy_11",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830534,
					Weight = 100,
				},
			},
		},
		{
			Prop = 75,
			ChoiceList = {
				{
					Id = 830535,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830536,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id114] =
{
	Id = 114,
	Name = "地区-交易",
	Desc = "你好，朋友，小店提供回收及出售必需品服务，要看下吗？",
	IconBG = "SpaceTravel_Exchange_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_9",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830537,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830538,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830539,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771008,
							NumMin = 1,
							NumMax = 9999,
						},
					},
				},
				{
					Id = 830540,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771009,
							NumMin = 1,
							NumMax = 9999,
						},
					},
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id115] =
{
	Id = 115,
	Name = "飞船强化中心",
	Desc = "本店专注飞船强化30年，有什么需要请大声说出来！",
	IconBG = "SpaceTravel_Explore_EventBG_11",
	Icon = "SpaceTravel_CampEnemy_3",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830541,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830542,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830543,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id116] =
{
	Id = 116,
	Name = "宝石加工商",
	Desc = "尊敬的客人，小店有大量高档宝石，有什么需要只管吩咐。",
	IconBG = "SpaceTravel_Explore_EventBG_11",
	Icon = "SpaceTravel_CampEnemy_3",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830544,
					Weight = 100,
				},
				{
					Id = 830545,
					Weight = 100,
				},
				{
					Id = 830546,
					Weight = 100,
				},
				{
					Id = 830547,
					Weight = 100,
				},
				{
					Id = 830548,
					Weight = 100,
				},
				{
					Id = 830549,
					Weight = 100,
				},
				{
					Id = 830550,
					Weight = 100,
				},
				{
					Id = 830551,
					Weight = 100,
				},
				{
					Id = 830552,
					Weight = 100,
				},
				{
					Id = 830553,
					Weight = 100,
				},
				{
					Id = 830554,
					Weight = 100,
				},
				{
					Id = 830555,
					Weight = 100,
				},
				{
					Id = 830556,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830557,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773001,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830558,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773006,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830559,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773011,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830560,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773016,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830561,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773021,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830562,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773026,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830563,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773031,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830564,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773036,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830565,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773041,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830566,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773046,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830567,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773051,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830568,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773056,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830569,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773061,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830570,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773001,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830571,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773006,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830572,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773011,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830573,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773016,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830574,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773021,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830575,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773026,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830576,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773031,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830577,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773036,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830578,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773041,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830579,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773046,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830580,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773051,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830581,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773056,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830582,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773061,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830583,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773001,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830584,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773006,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830585,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773011,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830586,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773016,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830587,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773021,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830588,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773026,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830589,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773031,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830590,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773036,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830591,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773041,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830592,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773046,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830593,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773051,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830594,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773056,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830595,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773061,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830596,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773001,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830597,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773006,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830598,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773011,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830599,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773016,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830600,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773021,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830601,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773026,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830602,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773031,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830603,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773036,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830604,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773041,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830605,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773046,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830606,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773051,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830607,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773056,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830608,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773061,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830609,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773066,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830610,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773071,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830611,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773076,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830612,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773081,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830613,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773086,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830614,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773091,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830615,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773096,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830616,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773101,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830617,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773106,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830618,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773111,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830619,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773116,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830620,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773121,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830621,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773126,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830622,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773131,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830623,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773136,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830624,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773141,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830625,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773146,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830626,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773151,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830627,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773156,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830628,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773161,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830629,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773166,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830630,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773171,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830631,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773176,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830632,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773181,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830633,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773186,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830634,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773191,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830635,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773196,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830636,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773201,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830637,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773206,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830638,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773211,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830639,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773216,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830640,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773221,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830641,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773226,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830642,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773231,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830643,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773236,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830644,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773241,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830645,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773246,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830646,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773251,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
				{
					Id = 830647,
					Weight = 100,
					PreCondition = {
						 {
							Value = 773256,
							NumMin = 1,
							NumMax = 99,
						},
					},
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830648,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id117] =
{
	Id = 117,
	Name = "地区-Boss点",
	Desc = "欢迎来到中转中心，系统目前出现重大霸格，请问客人能帮助我们吗？",
	IconBG = "SpaceTravel_Boss_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830649,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830650,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830651,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id118] =
{
	Id = 118,
	Name = "魔王集团分部",
	Desc = "抱歉，大人！上头有令，见您一次就得打您一次，请大人别怪小的！",
	FriendlinessId = 780001,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_1",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830652,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830653,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830654,
					Weight = 1,
				},
				{
					Id = 830655,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771001,
							NumMin = 15,
							NumMax = 9999,
						},
					},
				},
				{
					Id = 830656,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771002,
							NumMin = 10,
							NumMax = 9999,
						},
					},
				},
				{
					Id = 830657,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771004,
							NumMin = 5,
							NumMax = 9999,
						},
					},
				},
				{
					Id = 830658,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771005,
							NumMin = 8,
							NumMax = 9999,
						},
					},
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id119] =
{
	Id = 119,
	Name = "魔王集团分部",
	Desc = "大人，这里不欢迎您，请您不要再来找我们了！",
	FriendlinessId = 780001,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_1",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830659,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830660,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830661,
					Weight = 100,
				},
				{
					Id = 830662,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771001,
							NumMin = 12,
							NumMax = 9999,
						},
					},
				},
				{
					Id = 830663,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771002,
							NumMin = 8,
							NumMax = 9999,
						},
					},
				},
				{
					Id = 830664,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771004,
							NumMin = 4,
							NumMax = 9999,
						},
					},
				},
				{
					Id = 830665,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771005,
							NumMin = 6,
							NumMax = 9999,
						},
					},
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id120] =
{
	Id = 120,
	Name = "魔王集团分部",
	Desc = "请问这位客人需要什么服务？",
	FriendlinessId = 780001,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_1",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830666,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830667,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830668,
					Weight = 100,
				},
				{
					Id = 830669,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771001,
							NumMin = 9,
							NumMax = 9999,
						},
					},
				},
				{
					Id = 830670,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771002,
							NumMin = 6,
							NumMax = 9999,
						},
					},
				},
				{
					Id = 830671,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771004,
							NumMin = 3,
							NumMax = 9999,
						},
					},
				},
				{
					Id = 830672,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771005,
							NumMin = 5,
							NumMax = 9999,
						},
					},
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id121] =
{
	Id = 121,
	Name = "魔王集团分部",
	Desc = "请问这位客人需要什么服务？",
	FriendlinessId = 780001,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_1",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830673,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830674,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830675,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 8,
							NumMax = 99999,
						},
					},
				},
				{
					Id = 830676,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 8,
							NumMax = 99999,
						},
					},
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id122] =
{
	Id = 122,
	Name = "魔王集团分部",
	Desc = "请问这位客人需要什么服务？",
	FriendlinessId = 780001,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_1",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830677,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830678,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830679,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 8,
							NumMax = 99999,
						},
					},
				},
				{
					Id = 830680,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 8,
							NumMax = 99999,
						},
					},
				},
				{
					Id = 830681,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 13,
							NumMax = 99999,
						},
					},
				},
				{
					Id = 830682,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 13,
							NumMax = 99999,
						},
					},
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id123] =
{
	Id = 123,
	Name = "魔王集团分部",
	Desc = "啊，大人终于来了，这次是要去很远的地方吧？",
	FriendlinessId = 780001,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_1",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830683,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830684,
					Weight = 100,
				},
			},
		},
		{
			Prop = 70,
			ChoiceList = {
				{
					Id = 830685,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 8,
							NumMax = 99999,
						},
					},
				},
				{
					Id = 830686,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 8,
							NumMax = 99999,
						},
					},
				},
			},
		},
		{
			Prop = 30,
			ChoiceList = {
				{
					Id = 830687,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 11,
							NumMax = 99999,
						},
					},
				},
				{
					Id = 830688,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 11,
							NumMax = 99999,
						},
					},
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id124] =
{
	Id = 124,
	Name = "魔王集团分部",
	Desc = "啊，大人终于来了，有什么是小的们可以提供的请尽管开口。",
	FriendlinessId = 780001,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_1",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830689,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830690,
					Weight = 100,
				},
			},
		},
		{
			Prop = 70,
			ChoiceList = {
				{
					Id = 830691,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 200,
							NumMax = 99999,
						},
					},
				},
				{
					Id = 830692,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 200,
							NumMax = 99999,
						},
					},
				},
			},
		},
		{
			Prop = 30,
			ChoiceList = {
				{
					Id = 830693,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 8,
							NumMax = 99999,
						},
					},
				},
				{
					Id = 830694,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 8,
							NumMax = 99999,
						},
					},
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id125] =
{
	Id = 125,
	Name = "协会分部",
	Desc = "贼人落网了！来人哪！关门放狗！",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_2",
	Icon = "SpaceTravel_CampEnemy_2",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830697,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830698,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830699,
					Weight = 1,
				},
				{
					Id = 830700,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771001,
							NumMin = 15,
							NumMax = 9999,
						},
					},
				},
				{
					Id = 830701,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771002,
							NumMin = 10,
							NumMax = 9999,
						},
					},
				},
				{
					Id = 830702,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771004,
							NumMin = 5,
							NumMax = 9999,
						},
					},
				},
				{
					Id = 830703,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771005,
							NumMin = 8,
							NumMax = 9999,
						},
					},
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id126] =
{
	Id = 126,
	Name = "协会分部",
	Desc = "你如果想来找事的话，我们一定会让你吃不了兜着走的！",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_2",
	Icon = "SpaceTravel_CampEnemy_2",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830704,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830705,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830706,
					Weight = 100,
				},
				{
					Id = 830707,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771001,
							NumMin = 12,
							NumMax = 9999,
						},
					},
				},
				{
					Id = 830708,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771002,
							NumMin = 8,
							NumMax = 9999,
						},
					},
				},
				{
					Id = 830709,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771004,
							NumMin = 4,
							NumMax = 9999,
						},
					},
				},
				{
					Id = 830710,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771005,
							NumMin = 6,
							NumMax = 9999,
						},
					},
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id127] =
{
	Id = 127,
	Name = "协会分部",
	Desc = "请问这位客人需要什么服务？",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_2",
	Icon = "SpaceTravel_CampEnemy_2",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830711,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830712,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830713,
					Weight = 100,
				},
				{
					Id = 830714,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771001,
							NumMin = 9,
							NumMax = 9999,
						},
					},
				},
				{
					Id = 830715,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771002,
							NumMin = 6,
							NumMax = 9999,
						},
					},
				},
				{
					Id = 830716,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771004,
							NumMin = 3,
							NumMax = 9999,
						},
					},
				},
				{
					Id = 830717,
					Weight = 100,
					PreCondition = {
						 {
							Value = 771005,
							NumMin = 5,
							NumMax = 9999,
						},
					},
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id128] =
{
	Id = 128,
	Name = "协会分部",
	Desc = "请问这位客人需要什么服务？",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_2",
	Icon = "SpaceTravel_CampEnemy_2",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830718,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830719,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830720,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 8,
							NumMax = 99999,
						},
					},
				},
				{
					Id = 830721,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 8,
							NumMax = 99999,
						},
					},
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id129] =
{
	Id = 129,
	Name = "协会分部",
	Desc = "请问这位客人需要什么服务？",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_2",
	Icon = "SpaceTravel_CampEnemy_2",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830722,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830723,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830724,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 8,
							NumMax = 99999,
						},
					},
				},
				{
					Id = 830725,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 8,
							NumMax = 99999,
						},
					},
				},
				{
					Id = 830726,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 13,
							NumMax = 99999,
						},
					},
				},
				{
					Id = 830727,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 13,
							NumMax = 99999,
						},
					},
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id130] =
{
	Id = 130,
	Name = "协会分部",
	Desc = "好朋友！你怎么来了，需要什么帮助赶紧说。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_2",
	Icon = "SpaceTravel_CampEnemy_2",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830728,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830729,
					Weight = 100,
				},
			},
		},
		{
			Prop = 70,
			ChoiceList = {
				{
					Id = 830730,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 8,
							NumMax = 99999,
						},
					},
				},
				{
					Id = 830731,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 8,
							NumMax = 99999,
						},
					},
				},
			},
		},
		{
			Prop = 30,
			ChoiceList = {
				{
					Id = 830732,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 11,
							NumMax = 99999,
						},
					},
				},
				{
					Id = 830733,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 11,
							NumMax = 99999,
						},
					},
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id131] =
{
	Id = 131,
	Name = "协会分部",
	Desc = "好兄弟，你可来了！怎么样，需要什么尽管说！",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_2",
	Icon = "SpaceTravel_CampEnemy_2",
	ChoiceNum = 3,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830734,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830735,
					Weight = 100,
				},
			},
		},
		{
			Prop = 70,
			ChoiceList = {
				{
					Id = 830736,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 200,
							NumMax = 99999,
						},
					},
				},
				{
					Id = 830737,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 200,
							NumMax = 99999,
						},
					},
				},
			},
		},
		{
			Prop = 30,
			ChoiceList = {
				{
					Id = 830738,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 8,
							NumMax = 99999,
						},
					},
				},
				{
					Id = 830739,
					Weight = 100,
					PreCondition = {
						 {
							Value = 770001,
							NumMin = 8,
							NumMax = 99999,
						},
					},
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id132] =
{
	Id = 132,
	Name = "任务：与魔王集团交易",
	Desc = "收到了魔王集团的交易邀请函。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830742,
					Weight = 100,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830743,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id133] =
{
	Id = 133,
	Name = "任务：魔王集团竞答",
	Desc = "收到了魔王集团的竞答邀请函。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830744,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830745,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id134] =
{
	Id = 134,
	Name = "任务：与海盗战斗",
	Desc = "收到了星际联邦发布的通缉令。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830746,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830747,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id135] =
{
	Id = 135,
	Name = "任务：登陆发现",
	Desc = "收到了“发现者协会”提交的委托。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830748,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830749,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id136] =
{
	Id = 136,
	Name = "任务：整理船舱",
	Desc = "收到了“船舱清理委员会”提交的委托。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830750,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830751,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id137] =
{
	Id = 137,
	Name = "任务：战斗考验",
	Desc = "收到了冒险家协会发出的委托。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830752,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830753,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id138] =
{
	Id = 138,
	Name = "任务：驱赶海盗",
	Desc = "收到了冒险家协会发出的委托。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830754,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830755,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id139] =
{
	Id = 139,
	Name = "任务：谈判专家",
	Desc = "收到了“谈判协会”提出的委托。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830756,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830757,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id140] =
{
	Id = 140,
	Name = "任务：矿石收集",
	Desc = "收到了“发现者协会”提交的委托。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830758,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830759,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id141] =
{
	Id = 141,
	Name = "任务：矿石丰收",
	Desc = "收到了“发现者协会”提交的委托。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830760,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830761,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id142] =
{
	Id = 142,
	Name = "任务：圆锯爱好者",
	Desc = "收到了“发现者协会”提交的委托。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830762,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830763,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id143] =
{
	Id = 143,
	Name = "任务：圆锯大师",
	Desc = "收到了“发现者协会”提交的委托。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830764,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830765,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id144] =
{
	Id = 144,
	Name = "任务：购买补给",
	Desc = "收到了“贸易协会”提交的委托。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830766,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830767,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id145] =
{
	Id = 145,
	Name = "任务：补给抄底",
	Desc = "收到了“贸易协会”提交的委托。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830768,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830769,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id146] =
{
	Id = 146,
	Name = "任务：出售发条",
	Desc = "收到了“贸易协会”提交的委托。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830770,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830771,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id147] =
{
	Id = 147,
	Name = "任务：发条抛售",
	Desc = "收到了“贸易协会”提交的委托。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830772,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830773,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id148] =
{
	Id = 148,
	Name = "任务：提交矿石",
	Desc = "收到了魔王集团提交的委托。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830774,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830775,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id149] =
{
	Id = 149,
	Name = "任务：使用补给",
	Desc = "收到了道具测试公司提交的委托。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830776,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830777,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id150] =
{
	Id = 150,
	Name = "任务：艺术品",
	Desc = "收到了博物馆星提交的委托。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830778,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830779,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id151] =
{
	Id = 151,
	Name = "任务：星海航行",
	Desc = "收到了星际航行主办发提交的委托。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830780,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830781,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id152] =
{
	Id = 152,
	Name = "任务：快速航行",
	Desc = "收到了星际航行主办发提交的委托。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830782,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830783,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id153] =
{
	Id = 153,
	Name = "任务：魔王集团友好度",
	Desc = "收到了星际航行主办发提交的委托。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830784,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830785,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id154] =
{
	Id = 154,
	Name = "任务：提升魔王集团友好度",
	Desc = "收到了星际航行主办发提交的委托。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830786,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830787,
					Weight = 100,
				},
			},
		},
	},
}
SpaceTravelEventConfig[SpaceTravelEventID.Id155] =
{
	Id = 155,
	Name = "任务：合成补给",
	Desc = "收到了飞船制造公司提交的委托。",
	FriendlinessId = 780002,
	IconBG = "SpaceTravel_Camp_EventBG_1",
	Icon = "SpaceTravel_CampEnemy_10",
	ChoiceNum = 2,
	ChoiceGroupList = {
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830788,
					Weight = 50,
				},
			},
		},
		{
			Prop = 100,
			ChoiceList = {
				{
					Id = 830789,
					Weight = 100,
				},
			},
		},
	},
}
