IAPPackageConfig ={};
IAPPackageID = 
{
	Id001 = 710001,
	Id002 = 710002,
	Id003 = 710003,
	Id004 = 710004,
	Id005 = 710005,
	Id006 = 710006,
	Id007 = 710007,
	Id008 = 710008,
	Id009 = 710009,
	Id010 = 710010,
	Id011 = 710011,
}
IAPPackageConfig[IAPPackageID.Id001] =
{
	Id = 1,
	Price = 6,
	StoreId = {
		ios = "ios.miaoqixingqiu.package.6",
		tencent = "1061058",
	},
}
IAPPackageConfig[IAPPackageID.Id002] =
{
	Id = 2,
	Price = 12,
	StoreId = {
		ios = "ios.miaoqixingqiu.package.12",
		tencent = "1061059",
	},
}
IAPPackageConfig[IAPPackageID.Id003] =
{
	Id = 3,
	Price = 18,
	StoreId = {
		ios = "ios.miaoqixingqiu.package.18",
		tencent = "1061060",
	},
}
IAPPackageConfig[IAPPackageID.Id004] =
{
	Id = 4,
	Price = 30,
	StoreId = {
		ios = "ios.miaoqixingqiu.package.30",
		tencent = "1061061",
	},
}
IAPPackageConfig[IAPPackageID.Id005] =
{
	Id = 5,
	Price = 60,
	StoreId = {
		ios = "ios.miaoqixingqiu.package.60",
		tencent = "1061062",
	},
}
IAPPackageConfig[IAPPackageID.Id006] =
{
	Id = 6,
	Price = 68,
	StoreId = {
		ios = "ios.miaoqixingqiu.package.68",
		tencent = "1061063",
	},
}
IAPPackageConfig[IAPPackageID.Id007] =
{
	Id = 7,
	Price = 88,
	StoreId = {
		ios = "ios.miaoqixingqiu.package.88",
		tencent = "1061064",
	},
}
IAPPackageConfig[IAPPackageID.Id008] =
{
	Id = 8,
	Price = 128,
	StoreId = {
		ios = "ios.miaoqixingqiu.package.128",
		tencent = "1061065",
	},
}
IAPPackageConfig[IAPPackageID.Id009] =
{
	Id = 9,
	Price = 198,
	StoreId = {
		ios = "ios.miaoqixingqiu.package.198",
		tencent = "1061066",
	},
}
IAPPackageConfig[IAPPackageID.Id010] =
{
	Id = 10,
	Price = 328,
	StoreId = {
		ios = "ios.miaoqixingqiu.package.328",
		tencent = "1061067",
	},
}
IAPPackageConfig[IAPPackageID.Id011] =
{
	Id = 11,
	Price = 648,
	StoreId = {
		ios = "ios.miaoqixingqiu.package.648",
		tencent = "1061068",
	},
}

