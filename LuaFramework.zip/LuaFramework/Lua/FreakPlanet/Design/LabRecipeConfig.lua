LabRecipeConfig ={};
LabRecipeID = 
{
	Id001 = 360001,
	Id002 = 360002,
	Id003 = 360003,
	Id004 = 360004,
	Id005 = 360005,
	Id006 = 360006,
	Id007 = 360007,
	Id008 = 360008,
	Id009 = 360009,
	Id010 = 360010,
	Id011 = 360011,
	Id012 = 360012,
	Id013 = 360013,
	Id101 = 360101,
	Id102 = 360102,
	Id103 = 360103,
	Id104 = 360104,
	Id105 = 360105,
	Id106 = 360106,
	Id107 = 360107,
	Id108 = 360108,
	Id109 = 360109,
	Id110 = 360110,
	Id111 = 360111,
	Id112 = 360112,
	Id113 = 360113,
	Id114 = 360114,
	Id115 = 360115,
	Id116 = 360116,
	Id117 = 360117,
	Id118 = 360118,
	Id119 = 360119,
	Id120 = 360120,
	Id201 = 360201,
	Id202 = 360202,
	Id203 = 360203,
	Id204 = 360204,
	Id251 = 360251,
	Id252 = 360252,
	Id253 = 360253,
	Id254 = 360254,
	Id301 = 360301,
	Id302 = 360302,
	Id303 = 360303,
	Id304 = 360304,
	Id351 = 360351,
	Id352 = 360352,
	Id353 = 360353,
	Id354 = 360354,
	Id401 = 360401,
	Id402 = 360402,
	Id403 = 360403,
	Id404 = 360404,
	Id6001 = 366001,
	Id6002 = 366002,
	Id6003 = 366003,
	Id6004 = 366004,
	Id6005 = 366005,
	Id6006 = 366006,
	Id6007 = 366007,
	Id6008 = 366008,
	Id6009 = 366009,
	Id6010 = 366010,
	Id6011 = 366011,
	Id6012 = 366012,
	Id6013 = 366013,
	Id6014 = 366014,
	Id6201 = 366201,
	Id6202 = 366202,
	Id6203 = 366203,
	Id6204 = 366204,
	Id6205 = 366205,
	Id6206 = 366206,
	Id6207 = 366207,
	Id6208 = 366208,
	Id6209 = 366209,
	Id6210 = 366210,
	Id6211 = 366211,
	Id6212 = 366212,
	Id6213 = 366213,
	Id6214 = 366214,
	Id6215 = 366215,
	Id6216 = 366216,
	Id6217 = 366217,
	Id6218 = 366218,
	Id6219 = 366219,
	Id6220 = 366220,
	Id6401 = 366401,
	Id6402 = 366402,
	Id6403 = 366403,
	Id6404 = 366404,
	Id6405 = 366405,
	Id6406 = 366406,
	Id6407 = 366407,
}
LabRecipeConfig[LabRecipeID.Id001] =
{
	Id = 1,
	Name = "简单口粮制作",
	SortId = 101,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "FoodItem_Cookie_1",
	Desc = "卡兹星速食品，时间久了会又硬又干，难以下咽。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 321001,
			Num = 1,
		},
	},
	CraftResult = {
		{
			Value = 320401,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id002] =
{
	Id = 2,
	Name = "小血瓶制作",
	SortId = 92,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "FoodItem_Potion_1",
	Desc = "道具店打工生产。补充体力的冒险伙伴。虽然名字叫血瓶，不过里面装的其实是特浓红茶。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 320402,
			Num = 1,
		},
	},
	CraftResult = {
		{
			Value = 320402,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id003] =
{
	Id = 3,
	Name = "大血瓶制作",
	SortId = 89,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "FoodItem_Potion_2",
	Desc = "大号的冒险伙伴，修复了吨吨吨之后就见底的BUG，可以吨三口。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 320402,
			Num = 6,
		},
	},
	CraftResult = {
		{
			Value = 320403,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id004] =
{
	Id = 4,
	Name = "特大血瓶制作",
	SortId = 82,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "FoodItem_Potion_3",
	Desc = "特大号的冒险伙伴，分享装，当然也可以一个人喝。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 320403,
			Num = 4,
		},
	},
	CraftResult = {
		{
			Value = 320404,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id005] =
{
	Id = 5,
	Name = "超级大血瓶制作",
	SortId = 78,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "FoodItem_Potion_3",
	Desc = "0",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 320404,
			Num = 3,
		},
	},
	CraftResult = {
		{
			Value = 320405,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id006] =
{
	Id = 6,
	Name = "鸡腿制作",
	SortId = 91,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "FoodItem_Leg_1",
	Desc = "超市打工生产。在各地都非常流行的经典美食，除了热量高之外没有任何缺点。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 320406,
			Num = 1,
		},
	},
	CraftResult = {
		{
			Value = 320406,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id007] =
{
	Id = 7,
	Name = "纷享桶制作",
	SortId = 83,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "FoodItem_Leg_2",
	Desc = "装满鸡腿的纸盒，虽然叫纷享，到底会不会分享你心里没数吗？",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 320406,
			Num = 4,
		},
	},
	CraftResult = {
		{
			Value = 320407,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id008] =
{
	Id = 8,
	Name = "全家桶制作",
	SortId = 79,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "FoodItem_Leg_3",
	Desc = "装满鸡腿的纸桶，适合只有一口人的家庭享用。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 320407,
			Num = 5,
		},
	},
	CraftResult = {
		{
			Value = 320408,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id009] =
{
	Id = 9,
	Name = "超级全家桶制作",
	SortId = 81,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "FoodItem_Leg_3",
	Desc = "0",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 320408,
			Num = 3,
		},
	},
	CraftResult = {
		{
			Value = 320409,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id010] =
{
	Id = 10,
	Name = "小便当制作",
	SortId = 89,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "FoodItem_Bento_1",
	Desc = "警局打工生产。批量订购的员工餐，但因为迷信原因，冒险的人都不是很喜欢带这玩意。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 320410,
			Num = 1,
		},
	},
	CraftResult = {
		{
			Value = 320410,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id011] =
{
	Id = 11,
	Name = "大便当制作",
	SortId = 81,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "FoodItem_Bento_2",
	Desc = "经过定制的套餐，看着让人咽唾沫，或者是因为害怕？",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 320410,
			Num = 6,
		},
	},
	CraftResult = {
		{
			Value = 320411,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id012] =
{
	Id = 12,
	Name = "豪华便当制作",
	SortId = 76,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "FoodItem_Bento_3",
	Desc = "精心料理的套餐，一口下去非常满足，让吃到的人不禁流泪大喊“领便当啦！”",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 320411,
			Num = 4,
		},
	},
	CraftResult = {
		{
			Value = 320412,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id013] =
{
	Id = 13,
	Name = "超豪华便当制作",
	SortId = 73,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "FoodItem_Bento_3",
	Desc = "0",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 320412,
			Num = 3,
		},
	},
	CraftResult = {
		{
			Value = 320413,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id101] =
{
	Id = 101,
	Name = "简单陷阱制作",
	SortId = 201,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "CatchItem_Trap1",
	Desc = "道具店老板亲手编织的魔物捕捉陷阱。探索中携带可捕捉宠物，或者被对方当成玩具弄坏。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 320301,
			Num = 1,
		},
	},
	CraftResult = {
		{
			Value = 320301,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id102] =
{
	Id = 102,
	Name = "复合陷阱制作",
	SortId = 200,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "CatchItem_Trap2",
	Desc = "复合材料制作的陷阱，牢固度大幅提升。探索中携带可捕捉宠物，被套住的怪物很难逃脱。\n完成道具店装修4任务后解锁配方。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 320301,
			Num = 3,
		},
		{
			Value = 320406,
			Num = 8,
		},
	},
	CraftResult = {
		{
			Value = 320302,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id103] =
{
	Id = 103,
	Name = "合金陷阱制作",
	SortId = 199,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "CatchItem_Trap3",
	Desc = "使用新型金属制作的强力陷阱，通风性相当理想。探索中携带可捕捉宠物，被套住的怪物就不想跑了。\n完成道具店装修6任务后解锁配方。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 320302,
			Num = 3,
		},
		{
			Value = 320407,
			Num = 6,
		},
	},
	CraftResult = {
		{
			Value = 320303,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id104] =
{
	Id = 104,
	Name = "顶级陷阱制作",
	SortId = 198,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "CatchItem_Trap3",
	Desc = "顶级陷阱，陷阱界的CBD，尊贵身份的象征。带在身上要小心不要被怪物主动钻进去。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 320303,
			Num = 3,
		},
		{
			Value = 320408,
			Num = 4,
		},
	},
	CraftResult = {
		{
			Value = 320304,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id105] =
{
	Id = 105,
	Name = "脏脏的瓶子制作",
	SortId = 191,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "CatchItem_Bottle1",
	Desc = "超市回收机里的饮料空瓶，还有饮料残留。探索中携带可捕捉宠物，但被这东西抓到的怪物会看不起你。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 320305,
			Num = 1,
		},
	},
	CraftResult = {
		{
			Value = 320305,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id106] =
{
	Id = 106,
	Name = "玻璃瓶制作",
	SortId = 190,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "CatchItem_Bottle2",
	Desc = "经杀菌处理的再生空瓶，在里面能享受安静时光。探索中携带可捕捉宠物，怪物普遍表示还不错。\n完成超市装修4任务后解锁配方。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 320305,
			Num = 3,
		},
		{
			Value = 320402,
			Num = 20,
		},
	},
	CraftResult = {
		{
			Value = 320306,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id107] =
{
	Id = 107,
	Name = "精灵瓶制作",
	SortId = 189,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "CatchItem_Bottle3",
	Desc = "遮挡紫外线并调节气流的空瓶，冬暖夏凉。探索中携带可捕捉宠物，不过它们该怎么出来呢？\n完成超市装修6任务后解锁配方。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 320306,
			Num = 3,
		},
		{
			Value = 320403,
			Num = 10,
		},
	},
	CraftResult = {
		{
			Value = 320307,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id108] =
{
	Id = 108,
	Name = "顶级空瓶制作",
	SortId = 188,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "CatchItem_Bottle3",
	Desc = "顶级空瓶，空瓶界的贵族城堡，尊贵身份的象征。\n怪物需要刷卡才能被抓住。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 320307,
			Num = 3,
		},
		{
			Value = 320404,
			Num = 7,
		},
	},
	CraftResult = {
		{
			Value = 320308,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id109] =
{
	Id = 109,
	Name = "简易纸袋制作",
	SortId = 181,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "CatchItem_PaperBag1",
	Desc = "警察局附近小饭店送来的外卖纸袋。探索中携带可捕捉宠物，也有不少人会跟吃的弄混。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 320309,
			Num = 1,
		},
	},
	CraftResult = {
		{
			Value = 320309,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id110] =
{
	Id = 110,
	Name = "保温纸袋制作",
	SortId = 180,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "CatchItem_PaperBag2",
	Desc = "设计考究的保温纸袋，印着饭店LOGO。探索中携带可捕捉宠物，要撕下小票，否则会泄露地址噢。\n完成警察局装修4任务后解锁配方。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 320309,
			Num = 3,
		},
		{
			Value = 320410,
			Num = 4,
		},
	},
	CraftResult = {
		{
			Value = 320310,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id111] =
{
	Id = 111,
	Name = "恒温纸袋制作",
	SortId = 179,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "CatchItem_PaperBag3",
	Desc = "专供VIP客户的恒温纸袋，完美保留温度和水分。探索中携带可捕捉宠物，然后它们就赖着不走了。\n完成警察局装修6任务后解锁配方。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 320310,
			Num = 3,
		},
		{
			Value = 320411,
			Num = 3,
		},
	},
	CraftResult = {
		{
			Value = 320311,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id112] =
{
	Id = 112,
	Name = "顶级纸袋制作",
	SortId = 178,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "CatchItem_PaperBag3",
	Desc = "顶级纸袋，纸袋界的私人岛屿，尊贵身份的象征。\n申请入住的怪物已经排到五年后了。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 320311,
			Num = 3,
		},
		{
			Value = 320412,
			Num = 2,
		},
	},
	CraftResult = {
		{
			Value = 320312,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id113] =
{
	Id = 113,
	Name = "简易工具箱制作",
	SortId = 171,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "CatchItem_ToolCase1",
	Desc = "事务所储物间里的工具袋子。探索中携带可捕捉宠物，被星际警察看到的话会被以虐待动物罪罚款。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 320313,
			Num = 1,
		},
	},
	CraftResult = {
		{
			Value = 320313,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id114] =
{
	Id = 114,
	Name = "标准工具箱制作",
	SortId = 170,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "CatchItem_ToolCase2",
	Desc = "高级材料打造的箱子，内置了两层储物空间。探索中携带可捕捉宠物，怪物表示上铺睡着还行。\n完成事务所装修5任务后解锁配方。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 320313,
			Num = 3,
		},
		{
			Value = 320041,
			Num = 15,
		},
	},
	CraftResult = {
		{
			Value = 320314,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id115] =
{
	Id = 115,
	Name = "专业工具箱制作",
	SortId = 169,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "CatchItem_ToolCase3",
	Desc = "内置无线充电的高科技工具箱。探索中携带可捕捉宠物，据说告诉它们WIFI密码成功率还能增加。\n完成事务所装修7任务后解锁配方。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 320314,
			Num = 3,
		},
		{
			Value = 320041,
			Num = 45,
		},
	},
	CraftResult = {
		{
			Value = 320315,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id116] =
{
	Id = 116,
	Name = "顶级工具箱制作",
	SortId = 168,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "CatchItem_ToolCase3",
	Desc = "顶级工具箱，工具箱界的未来之城，尊贵身份的象征。\n主要还是网速比较快。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 320315,
			Num = 3,
		},
		{
			Value = 320041,
			Num = 120,
		},
	},
	CraftResult = {
		{
			Value = 320316,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id117] =
{
	Id = 117,
	Name = "旧纸板箱制作",
	SortId = 161,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "CatchItem_ExpressBox1",
	Desc = "事务所储物间里的纸板箱。探索中携带可捕捉宠物，只要别下雨。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 320317,
			Num = 1,
		},
	},
	CraftResult = {
		{
			Value = 320317,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id118] =
{
	Id = 118,
	Name = "新纸板箱制作",
	SortId = 160,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "CatchItem_ExpressBox2",
	Desc = "全新纸板箱，突发情况可以主动躲进去躲避危险。探索中携带可捕捉宠物，只要别下冰雹。\n完成事务所装修4任务后解锁配方。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 320317,
			Num = 3,
		},
		{
			Value = 320051,
			Num = 15,
		},
	},
	CraftResult = {
		{
			Value = 320318,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id119] =
{
	Id = 119,
	Name = "加固纸板箱制作",
	SortId = 159,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "CatchItem_ExpressBox3",
	Desc = "具有避震功能的高级纸箱，提供高质量睡眠。探索中携带可捕捉宠物，下冰雹也没事。\n完成事务所装修6任务后解锁配方。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 320318,
			Num = 3,
		},
		{
			Value = 320051,
			Num = 45,
		},
	},
	CraftResult = {
		{
			Value = 320319,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id120] =
{
	Id = 120,
	Name = "顶级纸板箱制作",
	SortId = 158,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "CatchItem_ExpressBox3",
	Desc = "顶级纸板箱，纸板箱界的乐园，尊贵身份的象征。地震也没事。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 320319,
			Num = 3,
		},
		{
			Value = 320051,
			Num = 120,
		},
	},
	CraftResult = {
		{
			Value = 320320,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id201] =
{
	Id = 201,
	Name = "头骨制作",
	SortId = 1799,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "RPG_Material_012",
	Desc = "经过骨头碎片复原而成的素材，长时间在野外而风化，生前应该是很大只的怪物。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 321003,
			Num = 5,
		},
		{
			Value = 321004,
			Num = 5,
		},
	},
	CraftResult = {
		{
			Value = 321051,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id202] =
{
	Id = 202,
	Name = "攻略制作",
	SortId = 1798,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "RPG_Material_001",
	Desc = "能够帮助人们摆脱困境的素材，记录了各种通关技巧的书籍，配有图片，但是总是会有错别字。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 321005,
			Num = 5,
		},
		{
			Value = 321006,
			Num = 5,
		},
	},
	CraftResult = {
		{
			Value = 321052,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id203] =
{
	Id = 203,
	Name = "沙漏制作",
	SortId = 1797,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "RPG_Material_022",
	Desc = "充满着神秘气息的素材，似乎预示着即将发生什么，稳定的计时功能也被冒险者用来计算技能冷却时间。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 321008,
			Num = 6,
		},
		{
			Value = 320305,
			Num = 1,
		},
	},
	CraftResult = {
		{
			Value = 321053,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id204] =
{
	Id = 204,
	Name = "火把制作",
	SortId = 1796,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "RPG_Material_003",
	Desc = "探索洞穴必备的素材，热乎乎的火焰能给人以安全感，然而实际上也经常会引来怪物。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 321009,
			Num = 8,
		},
		{
			Value = 321002,
			Num = 2,
		},
	},
	CraftResult = {
		{
			Value = 321054,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id251] =
{
	Id = 251,
	Name = "红豆冰制作",
	SortId = 1749,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "FAT_Material_027",
	Desc = "拥有冰爽口感又能让人感到甜蜜的高级素材，在炎炎夏日来上一份，立刻就能驱走暑气。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 321201,
			Num = 6,
		},
		{
			Value = 321202,
			Num = 3,
		},
	},
	CraftResult = {
		{
			Value = 321251,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id252] =
{
	Id = 252,
	Name = "蛋糕制作",
	SortId = 1748,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "FAT_Material_028",
	Desc = "能让人充满元气的高级素材，口感松软，搭配模具可以制作成各种形状，是节日上很受欢迎的食物。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 321203,
			Num = 5,
		},
		{
			Value = 321204,
			Num = 5,
		},
	},
	CraftResult = {
		{
			Value = 321252,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id253] =
{
	Id = 253,
	Name = "米醋制作",
	SortId = 1747,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "FAT_Material_013",
	Desc = "凝聚了劳动智慧的高级素材，谷类经过发酵才能制成，酸爽的味道能够很好地缓解食物油腻的口感。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 321206,
			Num = 5,
		},
		{
			Value = 321207,
			Num = 4,
		},
	},
	CraftResult = {
		{
			Value = 321253,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id254] =
{
	Id = 254,
	Name = "海鲜酱制作",
	SortId = 1746,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "FAT_Material_022",
	Desc = "拥有海洋气息的高级素材，选用各类海鲜研磨而成，独特的咸腥味能够使食物的口感层次更丰富。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 321205,
			Num = 5,
		},
		{
			Value = 321208,
			Num = 5,
		},
	},
	CraftResult = {
		{
			Value = 321254,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id301] =
{
	Id = 301,
	Name = "黄蛋壳制作",
	SortId = 1699,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "MUS_Material_014",
	Desc = "古老的化石素材，长着黄色斑点，因此科学家认为里面会孵化出沙漠地区的小恐龙，当然也有可能是油漆。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 321402,
			Num = 4,
		},
		{
			Value = 321405,
			Num = 4,
		},
	},
	CraftResult = {
		{
			Value = 321451,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id302] =
{
	Id = 302,
	Name = "黄面具制作",
	SortId = 1698,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "MUS_Material_019",
	Desc = "神秘的祭祀素材，不知是以什么动物为原型制作的古老面具，相传戴上后可以避免邪灵的侵袭，也会吸引邪灵。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 321407,
			Num = 5,
		},
		{
			Value = 321409,
			Num = 3,
		},
	},
	CraftResult = {
		{
			Value = 321452,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id303] =
{
	Id = 303,
	Name = "化石骨制作",
	SortId = 1697,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "MUS_Material_016",
	Desc = "古老的化石素材，通过基因模拟合成技术制作的恐龙化石，如果数据够全面，就能拼出完整的恐龙。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 321408,
			Num = 5,
		},
		{
			Value = 321410,
			Num = 4,
		},
	},
	CraftResult = {
		{
			Value = 321453,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id304] =
{
	Id = 304,
	Name = "导览图制作",
	SortId = 1696,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "MUS_Material_002",
	Desc = "官方发布的地图素材，记录了游客感兴趣的地点及前往路线，避开了官方感兴趣的陷阱。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 321401,
			Num = 1,
		},
		{
			Value = 321411,
			Num = 8,
		},
	},
	CraftResult = {
		{
			Value = 321454,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id351] =
{
	Id = 351,
	Name = "谣言制作",
	SortId = 1649,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "SUS_Material_029",
	Desc = "集结了大量传闻的信息素材，读起来非常通顺流畅，语言充满逻辑，结构严谨，唯一的缺点是它是假的。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 321602,
			Num = 4,
		},
		{
			Value = 321603,
			Num = 4,
		},
	},
	CraftResult = {
		{
			Value = 321651,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id352] =
{
	Id = 352,
	Name = "肖像侧写制作",
	SortId = 1648,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "SUS_Material_030",
	Desc = "根据环境证据制成的信息素材，从犯罪痕迹推断得到的案犯信息，方便通缉。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 321605,
			Num = 7,
		},
		{
			Value = 321606,
			Num = 3,
		},
	},
	CraftResult = {
		{
			Value = 321652,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id353] =
{
	Id = 353,
	Name = "欠条制作",
	SortId = 1647,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "SUS_Material_031",
	Desc = "记录了财务来往的信息素材，因为是金额来往的关键证明，所以需要借款人按下手印，或者手指。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 321607,
			Num = 4,
		},
		{
			Value = 321608,
			Num = 6,
		},
	},
	CraftResult = {
		{
			Value = 321653,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id354] =
{
	Id = 354,
	Name = "18X制作",
	SortId = 1646,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "SUS_Material_032",
	Desc = "记录了无法理解的画面和文字的信息素材，这其实是个路牌，限速十八迈，别想多了。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 321609,
			Num = 5,
		},
		{
			Value = 321610,
			Num = 5,
		},
	},
	CraftResult = {
		{
			Value = 321654,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id401] =
{
	Id = 401,
	Name = "正式队服制作",
	SortId = 1599,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "SEA_Material_015",
	Desc = "人气偶像的正式队服，穿着身上金光闪闪，仿佛自己也在发光。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 321807,
			Num = 6,
		},
		{
			Value = 321810,
			Num = 3,
		},
	},
	CraftResult = {
		{
			Value = 321851,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id402] =
{
	Id = 402,
	Name = "璀璨珍珠制作",
	SortId = 1598,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "SEA_Material_017",
	Desc = "洁白无暇，甚至可以在珍珠上清晰地看到自己的倒影。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 321803,
			Num = 6,
		},
		{
			Value = 321811,
			Num = 4,
		},
	},
	CraftResult = {
		{
			Value = 321852,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id403] =
{
	Id = 403,
	Name = "典藏签名照制作",
	SortId = 1597,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "SEA_Material_018",
	Desc = "偶像的签名照，价值不菲，被许多海底黄牛竞相争夺。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 321805,
			Num = 6,
		},
		{
			Value = 321808,
			Num = 1,
		},
		{
			Value = 321812,
			Num = 4,
		},
	},
	CraftResult = {
		{
			Value = 321853,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id404] =
{
	Id = 404,
	Name = "架子鼓制作",
	SortId = 1596,
	Bundle = "atlas_goods",
	IconAtlas = "Goods",
	Icon = "SEA_Material_016",
	Desc = "舞台必备的乐器，可以完美调动舞台上的气氛。",
	Type = LabRecipeType.Normal,
	CraftSource = {
		{
			Value = 321806,
			Num = 6,
		},
		{
			Value = 321809,
			Num = 2,
		},
		{
			Value = 321813,
			Num = 3,
		},
	},
	CraftResult = {
		{
			Value = 321854,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id6001] =
{
	Id = 6001,
	Name = "基础柜子1制作",
	SortId = 10000,
	Bundle = "atlas_p_homefurnitureicon_general",
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_GuiZi001",
	Desc = "家具合成测试1",
	Type = LabRecipeType.HomeFurniture,
	Score = 0,
	CraftSource = {
		{
			Value = 1210001,
			Num = 2,
		},
	},
	CraftResult = {
		{
			Value = 1210109,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id6002] =
{
	Id = 6002,
	Name = "基础箱子1制作",
	SortId = 10000,
	Bundle = "atlas_p_homefurnitureicon_general",
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_XiangZi001",
	Desc = "家具合成测试2",
	Type = LabRecipeType.HomeFurniture,
	Score = 0,
	CraftSource = {
		{
			Value = 1210001,
			Num = 1,
		},
		{
			Value = 321001,
			Num = 1,
		},
	},
	CraftResult = {
		{
			Value = 1210110,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id6003] =
{
	Id = 6003,
	Name = "基础箱子2制作",
	SortId = 10000,
	Bundle = "atlas_p_homefurnitureicon_general",
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_XiangZi002",
	Desc = "家具合成测试3",
	Type = LabRecipeType.HomeFurniture,
	Score = 0,
	CraftSource = {
		{
			Value = 1210001,
			Num = 1,
		},
		{
			Value = 1,
			Num = 500,
		},
	},
	CraftResult = {
		{
			Value = 1210111,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id6004] =
{
	Id = 6004,
	Name = "基础桌子1制作",
	SortId = 10000,
	Bundle = "atlas_p_homefurnitureicon_general",
	IconAtlas = "HomeFurnitureIcon_General",
	Icon = "Default_ZhuoZi001",
	Desc = "家具合成测试4",
	Type = LabRecipeType.HomeFurniture,
	Score = 0,
	CraftSource = {
		{
			Value = 1210001,
			Num = 3,
		},
		{
			Value = 2,
			Num = 100,
		},
	},
	CraftResult = {
		{
			Value = 1210112,
			Weight = 20,
		},
	},
}
LabRecipeConfig[LabRecipeID.Id6005] =
{
	Id = 6005,
	Name = "小型食物包制作",
	SortId = 10000,
	Bundle = "atlas_spacetravelgoods",
	IconAtlas = "SpaceTravelGoods",
	Icon = "SpaceTravel_Goods_Food_1",
	Desc = "合成小型食物包\n食物 + 100",
	Type = LabRecipeType.SpaceTravel,
	SubType = LabRecipeSubType.Supply,
	Score = 0,
}
LabRecipeConfig[LabRecipeID.Id6006] =
{
	Id = 6006,
	Name = "中型食物包制作",
	SortId = 10000,
	Bundle = "atlas_spacetravelgoods",
	IconAtlas = "SpaceTravelGoods",
	Icon = "SpaceTravel_Goods_Food_2",
	Desc = "合成中型食物包\n食物 + 200",
	Type = LabRecipeType.SpaceTravel,
	SubType = LabRecipeSubType.Supply,
	Score = 0,
}
LabRecipeConfig[LabRecipeID.Id6007] =
{
	Id = 6007,
	Name = "大型食物包制作",
	SortId = 10000,
	Bundle = "atlas_spacetravelgoods",
	IconAtlas = "SpaceTravelGoods",
	Icon = "SpaceTravel_Goods_Food_3",
	Desc = "合成大型食物包\n食物 + 300",
	Type = LabRecipeType.SpaceTravel,
	SubType = LabRecipeSubType.Supply,
	Score = 0,
}
LabRecipeConfig[LabRecipeID.Id6008] =
{
	Id = 6008,
	Name = "巨型食物包制作",
	SortId = 10000,
	Bundle = "atlas_spacetravelgoods",
	IconAtlas = "SpaceTravelGoods",
	Icon = "SpaceTravel_Goods_Food_4",
	Desc = "合成巨型食物包\n食物 + 400",
	Type = LabRecipeType.SpaceTravel,
	SubType = LabRecipeSubType.Supply,
	Score = 0,
}
LabRecipeConfig[LabRecipeID.Id6009] =
{
	Id = 6009,
	Name = "定点导航1型制作",
	SortId = 10000,
	Bundle = "atlas_spacetravelgoods",
	IconAtlas = "SpaceTravelGoods",
	Icon = "SpaceTravel_Goods_Dice_1",
	Desc = "合成定点导航1型\n由宇宙工坊制作的定点导航器-1型。使用后，可以使飞船稳定前进1个路点。",
	Type = LabRecipeType.SpaceTravel,
	SubType = LabRecipeSubType.Supply,
	Score = 0,
}
LabRecipeConfig[LabRecipeID.Id6010] =
{
	Id = 6010,
	Name = "定点导航2型制作",
	SortId = 10000,
	Bundle = "atlas_spacetravelgoods",
	IconAtlas = "SpaceTravelGoods",
	Icon = "SpaceTravel_Goods_Dice_2",
	Desc = "合成定点导航2型\n由宇宙工坊制作的定点导航器-2型，是1型的改良型号，推力更强。使用后，可以使飞船稳定前进2个路点。",
	Type = LabRecipeType.SpaceTravel,
	SubType = LabRecipeSubType.Supply,
	Score = 0,
}
LabRecipeConfig[LabRecipeID.Id6011] =
{
	Id = 6011,
	Name = "定点导航3型制作",
	SortId = 10000,
	Bundle = "atlas_spacetravelgoods",
	IconAtlas = "SpaceTravelGoods",
	Icon = "SpaceTravel_Goods_Dice_3",
	Desc = "合成定点导航3型\n由宇宙工坊制作的定点导航器-3型，是2型的改良型号，推力更强。使用后，可以使飞船稳定前进3个路点。",
	Type = LabRecipeType.SpaceTravel,
	SubType = LabRecipeSubType.Supply,
	Score = 0,
}
LabRecipeConfig[LabRecipeID.Id6012] =
{
	Id = 6012,
	Name = "定点导航4型制作",
	SortId = 10000,
	Bundle = "atlas_spacetravelgoods",
	IconAtlas = "SpaceTravelGoods",
	Icon = "SpaceTravel_Goods_Dice_4",
	Desc = "合成定点导航4型\n由宇宙工坊制作的定点导航器-4型，是3型的改良型号，推力更强。使用后，可以使飞船稳定前进4个路点。",
	Type = LabRecipeType.SpaceTravel,
	SubType = LabRecipeSubType.Supply,
	Score = 0,
}
LabRecipeConfig[LabRecipeID.Id6013] =
{
	Id = 6013,
	Name = "定点导航5型制作",
	SortId = 10000,
	Bundle = "atlas_spacetravelgoods",
	IconAtlas = "SpaceTravelGoods",
	Icon = "SpaceTravel_Goods_Dice_5",
	Desc = "合成定点导航5型\n由宇宙工坊制作的定点导航器-5型，是4型的改良型号，推力更强。使用后，可以使飞船稳定前进5个路点。",
	Type = LabRecipeType.SpaceTravel,
	SubType = LabRecipeSubType.Supply,
	Score = 0,
}
LabRecipeConfig[LabRecipeID.Id6014] =
{
	Id = 6014,
	Name = "定点导航6型制作",
	SortId = 10000,
	Bundle = "atlas_spacetravelgoods",
	IconAtlas = "SpaceTravelGoods",
	Icon = "SpaceTravel_Goods_Dice_6",
	Desc = "合成定点导航6型\n由宇宙工坊制作的定点导航器-6型，是5型的改良型号，推力更强。使用后，可以使飞船稳定前进6个路点。",
	Type = LabRecipeType.SpaceTravel,
	SubType = LabRecipeSubType.Supply,
	Score = 0,
}
LabRecipeConfig[LabRecipeID.Id6201] =
{
	Id = 6201,
	Name = "陨铁制作",
	SortId = 10000,
	Bundle = "atlas_spacetravelgoods",
	IconAtlas = "SpaceTravelGoods",
	Icon = "SpaceTravel_Goods_Stone_1",
	Desc = "合成陨铁\n来自外太空的矿石，提炼后可以制作成拥有优秀硬度及韧性的金属，受到铁匠们的广泛欢迎。",
	Type = LabRecipeType.SpaceTravel,
	SubType = LabRecipeSubType.Object,
	Score = 0,
}
LabRecipeConfig[LabRecipeID.Id6202] =
{
	Id = 6202,
	Name = "贝壳石制作",
	SortId = 10000,
	Bundle = "atlas_spacetravelgoods",
	IconAtlas = "SpaceTravelGoods",
	Icon = "SpaceTravel_Goods_Stone_2",
	Desc = "合成贝壳石\n来自外星海域的深海矿石，具有贝壳光泽，可以用来制作雕塑品的装饰或好看的书签。因为磁感应效果优秀，也会被拿来制作定点导航器。",
	Type = LabRecipeType.SpaceTravel,
	SubType = LabRecipeSubType.Object,
	Score = 0,
}
LabRecipeConfig[LabRecipeID.Id6203] =
{
	Id = 6203,
	Name = "外星黏土制作",
	SortId = 10000,
	Bundle = "atlas_spacetravelgoods",
	IconAtlas = "SpaceTravelGoods",
	Icon = "SpaceTravel_Goods_Stone_3",
	Desc = "合成外星黏土\n合成素材",
	Type = LabRecipeType.SpaceTravel,
	SubType = LabRecipeSubType.Object,
	Score = 0,
}
LabRecipeConfig[LabRecipeID.Id6204] =
{
	Id = 6204,
	Name = "高能矿石制作",
	SortId = 10000,
	Bundle = "atlas_spacetravelgoods",
	IconAtlas = "SpaceTravelGoods",
	Icon = "SpaceTravel_Goods_Stone_4",
	Desc = "合成高能矿石\n合成素材",
	Type = LabRecipeType.SpaceTravel,
	SubType = LabRecipeSubType.Object,
	Score = 0,
}
LabRecipeConfig[LabRecipeID.Id6205] =
{
	Id = 6205,
	Name = "元素石制作",
	SortId = 10000,
	Bundle = "atlas_spacetravelgoods",
	IconAtlas = "SpaceTravelGoods",
	Icon = "SpaceTravel_Goods_Stone_5",
	Desc = "合成元素石\n合成素材",
	Type = LabRecipeType.SpaceTravel,
	SubType = LabRecipeSubType.Object,
	Score = 0,
}
LabRecipeConfig[LabRecipeID.Id6206] =
{
	Id = 6206,
	Name = "斑点浆果制作",
	SortId = 10000,
	Bundle = "atlas_spacetravelgoods",
	IconAtlas = "SpaceTravelGoods",
	Icon = "SpaceTravel_Goods_Botany_1",
	Desc = "合成斑点浆果\n合成素材",
	Type = LabRecipeType.SpaceTravel,
	SubType = LabRecipeSubType.Object,
	Score = 0,
}
LabRecipeConfig[LabRecipeID.Id6207] =
{
	Id = 6207,
	Name = "摇滚草制作",
	SortId = 10000,
	Bundle = "atlas_spacetravelgoods",
	IconAtlas = "SpaceTravelGoods",
	Icon = "SpaceTravel_Goods_Botany_2",
	Desc = "合成摇滚草\n合成素材",
	Type = LabRecipeType.SpaceTravel,
	SubType = LabRecipeSubType.Object,
	Score = 0,
}
LabRecipeConfig[LabRecipeID.Id6208] =
{
	Id = 6208,
	Name = "能量果实制作",
	SortId = 10000,
	Bundle = "atlas_spacetravelgoods",
	IconAtlas = "SpaceTravelGoods",
	Icon = "SpaceTravel_Goods_Botany_3",
	Desc = "合成能量果实\n兑换高级宝石",
	Type = LabRecipeType.SpaceTravel,
	SubType = LabRecipeSubType.Object,
	Score = 0,
}
LabRecipeConfig[LabRecipeID.Id6209] =
{
	Id = 6209,
	Name = "生命果实制作",
	SortId = 10000,
	Bundle = "atlas_spacetravelgoods",
	IconAtlas = "SpaceTravelGoods",
	Icon = "SpaceTravel_Goods_Botany_4",
	Desc = "合成生命果实\n兑换高级宝石",
	Type = LabRecipeType.SpaceTravel,
	SubType = LabRecipeSubType.Object,
	Score = 0,
}
LabRecipeConfig[LabRecipeID.Id6210] =
{
	Id = 6210,
	Name = "黄金花制作",
	SortId = 10000,
	Bundle = "atlas_spacetravelgoods",
	IconAtlas = "SpaceTravelGoods",
	Icon = "SpaceTravel_Goods_Botany_5",
	Desc = "合成黄金花\n制作艺术品",
	Type = LabRecipeType.SpaceTravel,
	SubType = LabRecipeSubType.Object,
	Score = 0,
}
LabRecipeConfig[LabRecipeID.Id6211] =
{
	Id = 6211,
	Name = "色素虫制作",
	SortId = 10000,
	Bundle = "atlas_spacetravelgoods",
	IconAtlas = "SpaceTravelGoods",
	Icon = "SpaceTravel_Goods_Insect_1",
	Desc = "合成色素虫\n合成素材",
	Type = LabRecipeType.SpaceTravel,
	SubType = LabRecipeSubType.Object,
	Score = 0,
}
LabRecipeConfig[LabRecipeID.Id6212] =
{
	Id = 6212,
	Name = "高蛋白虫制作",
	SortId = 10000,
	Bundle = "atlas_spacetravelgoods",
	IconAtlas = "SpaceTravelGoods",
	Icon = "SpaceTravel_Goods_Insect_2",
	Desc = "合成高蛋白虫\n合成素材",
	Type = LabRecipeType.SpaceTravel,
	SubType = LabRecipeSubType.Object,
	Score = 0,
}
LabRecipeConfig[LabRecipeID.Id6213] =
{
	Id = 6213,
	Name = "能量虫制作",
	SortId = 10000,
	Bundle = "atlas_spacetravelgoods",
	IconAtlas = "SpaceTravelGoods",
	Icon = "SpaceTravel_Goods_Insect_3",
	Desc = "合成能量虫\n合成素材",
	Type = LabRecipeType.SpaceTravel,
	SubType = LabRecipeSubType.Object,
	Score = 0,
}
LabRecipeConfig[LabRecipeID.Id6214] =
{
	Id = 6214,
	Name = "照明虫制作",
	SortId = 10000,
	Bundle = "atlas_spacetravelgoods",
	IconAtlas = "SpaceTravelGoods",
	Icon = "SpaceTravel_Goods_Insect_4",
	Desc = "合成照明虫\n合成素材",
	Type = LabRecipeType.SpaceTravel,
	SubType = LabRecipeSubType.Object,
	Score = 0,
}
LabRecipeConfig[LabRecipeID.Id6215] =
{
	Id = 6215,
	Name = "粘液虫制作",
	SortId = 10000,
	Bundle = "atlas_spacetravelgoods",
	IconAtlas = "SpaceTravelGoods",
	Icon = "SpaceTravel_Goods_Insect_5",
	Desc = "合成粘液虫\n合成素材",
	Type = LabRecipeType.SpaceTravel,
	SubType = LabRecipeSubType.Object,
	Score = 0,
}
LabRecipeConfig[LabRecipeID.Id6216] =
{
	Id = 6216,
	Name = "氧气瓶制作",
	SortId = 10000,
	Bundle = "atlas_spacetravelgoods",
	IconAtlas = "SpaceTravelGoods",
	Icon = "SpaceTravel_Goods_Industry_1",
	Desc = "合成氧气瓶\n探索中提供氧气",
	Type = LabRecipeType.SpaceTravel,
	SubType = LabRecipeSubType.Object,
	Score = 0,
}
LabRecipeConfig[LabRecipeID.Id6217] =
{
	Id = 6217,
	Name = "圆锯制作",
	SortId = 10000,
	Bundle = "atlas_spacetravelgoods",
	IconAtlas = "SpaceTravelGoods",
	Icon = "SpaceTravel_Goods_Industry_2",
	Desc = "合成圆锯\n探索中切割物体",
	Type = LabRecipeType.SpaceTravel,
	SubType = LabRecipeSubType.Object,
	Score = 0,
}
LabRecipeConfig[LabRecipeID.Id6218] =
{
	Id = 6218,
	Name = "纸卷制作",
	SortId = 10000,
	Bundle = "atlas_spacetravelgoods",
	IconAtlas = "SpaceTravelGoods",
	Icon = "SpaceTravel_Goods_Industry_3",
	Desc = "合成纸卷\n制作艺术品",
	Type = LabRecipeType.SpaceTravel,
	SubType = LabRecipeSubType.Object,
	Score = 0,
}
LabRecipeConfig[LabRecipeID.Id6219] =
{
	Id = 6219,
	Name = "进入装置制作",
	SortId = 10000,
	Bundle = "atlas_spacetravelgoods",
	IconAtlas = "SpaceTravelGoods",
	Icon = "SpaceTravel_Goods_Industry_4",
	Desc = "合成进入装置\n探索中进入被封闭区域",
	Type = LabRecipeType.SpaceTravel,
	SubType = LabRecipeSubType.Object,
	Score = 0,
}
LabRecipeConfig[LabRecipeID.Id6220] =
{
	Id = 6220,
	Name = "万能芯片制作",
	SortId = 10000,
	Bundle = "atlas_spacetravelgoods",
	IconAtlas = "SpaceTravelGoods",
	Icon = "SpaceTravel_Goods_Industry_5",
	Desc = "合成万能芯片\n探索中打开特定宝箱",
	Type = LabRecipeType.SpaceTravel,
	SubType = LabRecipeSubType.Object,
	Score = 0,
}
LabRecipeConfig[LabRecipeID.Id6401] =
{
	Id = 6401,
	Name = "小型雕像制作",
	SortId = 10000,
	Bundle = "atlas_spacetravelgoods",
	IconAtlas = "SpaceTravelGoods",
	Icon = "SpaceTravel_Artwork_Statue",
	Desc = "制作小型雕像类艺术品，似乎一不留神就会做出劣质品来的样子。\n合成后分数+ 100",
	Type = LabRecipeType.SpaceTravel,
	SubType = LabRecipeSubType.Artwork,
	Score = 100,
}
LabRecipeConfig[LabRecipeID.Id6402] =
{
	Id = 6402,
	Name = "中型雕像制作",
	SortId = 10000,
	Bundle = "atlas_spacetravelgoods",
	IconAtlas = "SpaceTravelGoods",
	Icon = "SpaceTravel_Artwork_Statue",
	Desc = "制作中型雕像类艺术品，似乎一不留神就会做出劣质品来的样子。\n合成后分数+ 150",
	Type = LabRecipeType.SpaceTravel,
	SubType = LabRecipeSubType.Artwork,
	Score = 150,
}
LabRecipeConfig[LabRecipeID.Id6403] =
{
	Id = 6403,
	Name = "大型雕像制作",
	SortId = 10000,
	Bundle = "atlas_spacetravelgoods",
	IconAtlas = "SpaceTravelGoods",
	Icon = "SpaceTravel_Artwork_Statue",
	Desc = "制作大型雕像类艺术品，似乎一不留神就会做出劣质品来的样子。\n合成后分数+ 200",
	Type = LabRecipeType.SpaceTravel,
	SubType = LabRecipeSubType.Artwork,
	Score = 200,
}
LabRecipeConfig[LabRecipeID.Id6404] =
{
	Id = 6404,
	Name = "景物雕像制作",
	SortId = 10000,
	Bundle = "atlas_spacetravelgoods",
	IconAtlas = "SpaceTravelGoods",
	Icon = "SpaceTravel_Artwork_Statue",
	Desc = "制作小型景品类艺术品，似乎一不留神就会做出劣质品来的样子。\n合成后分数+ 100",
	Type = LabRecipeType.SpaceTravel,
	SubType = LabRecipeSubType.Artwork,
	Score = 100,
}
LabRecipeConfig[LabRecipeID.Id6405] =
{
	Id = 6405,
	Name = "地标雕像制作",
	SortId = 10000,
	Bundle = "atlas_spacetravelgoods",
	IconAtlas = "SpaceTravelGoods",
	Icon = "SpaceTravel_Artwork_Statue",
	Desc = "制作小型建筑类艺术品，似乎一不留神就会做出劣质品来的样子。\n合成后分数+ 150",
	Type = LabRecipeType.SpaceTravel,
	SubType = LabRecipeSubType.Artwork,
	Score = 150,
}
LabRecipeConfig[LabRecipeID.Id6406] =
{
	Id = 6406,
	Name = "抽象画制作",
	SortId = 10000,
	Bundle = "atlas_spacetravelgoods",
	IconAtlas = "SpaceTravelGoods",
	Icon = "SpaceTravel_Artwork_Picture",
	Desc = "制作抽象画，似乎一不留神就会做出劣质品来的样子。\n合成后分数+ 100",
	Type = LabRecipeType.SpaceTravel,
	SubType = LabRecipeSubType.Artwork,
	Score = 100,
}
LabRecipeConfig[LabRecipeID.Id6407] =
{
	Id = 6407,
	Name = "动物画制作",
	SortId = 10000,
	Bundle = "atlas_spacetravelgoods",
	IconAtlas = "SpaceTravelGoods",
	Icon = "SpaceTravel_Artwork_Picture",
	Desc = "制作动画画，似乎一不留神就会做出劣质品来的样子。\n合成后分数+ 150",
	Type = LabRecipeType.SpaceTravel,
	SubType = LabRecipeSubType.Artwork,
	Score = 150,
}

