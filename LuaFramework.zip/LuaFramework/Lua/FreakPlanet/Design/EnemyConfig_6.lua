
EnemyConfig[EnemyID.Id8001] =
{
	Id = 8001,
	Name = "重大霸格",
	Rarity = 5,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "能够直接使冒险星停止正常运作的强力霸格。是第一站的最终boss。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_Luggage",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_Luggage",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2131, Gain = 427},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id8002] =
{
	Id = 8002,
	Name = "快递机器人",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "“无论是什么我都将为您准确投递到指定地点，请放心吧！”是Ta常挂在嘴边的招牌语，不过打开评价栏，就会发现历史差评999+，不过不知道什么原因，又都被撤销了。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_Luggage",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_Luggage",
	PrefabScale = 50,
	HPBarHeight = 130,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1940, Gain = 388},
		{Value = 200002, Base = 39, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id8003] =
{
	Id = 8003,
	Name = "孤独的美食家",
	Rarity = 5,
	Element = 210003,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "一个平凡无奇的中年上班族，但是始终在寻找美食。如果说他大加赞赏的某个食物不好吃，就会被他要求去没人的地方聊聊。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_Luggage",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_Luggage",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWind",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1780, Gain = 356},
		{Value = 200002, Base = 38, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id8004] =
{
	Id = 8004,
	Name = "最高审判",
	Rarity = 5,
	Element = 210005,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "坐在审判席上的法官，所有想要通过联邦区的冒险家都必须经过他的考核！",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_Luggage",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_Luggage",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectDark",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1644, Gain = 329},
		{Value = 200002, Base = 37, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id8005] =
{
	Id = 8005,
	Name = "时空穿梭者",
	Rarity = 5,
	Element = 210004,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "高星实验室发布的第一台原型时光机，曾经拥有无数光环。不过项目在拿到了政府补助后就停止了，据说时光机什么的都是骗人的，实验室造这台机器只是为了骗钱。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_Luggage",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_Luggage",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectLight",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1528, Gain = 306},
		{Value = 200002, Base = 36, Gain = 8},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id8006] =
{
	Id = 8006,
	Name = "薛定谔的猫",
	Rarity = 5,
	Element = 210002,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "无法确定当前状态的猫，是醒着还是睡着，是挂了还是活着，都没有人知道。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_Luggage",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_Luggage",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectFire",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1427, Gain = 286},
		{Value = 200002, Base = 35, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id8007] =
{
	Id = 8007,
	Name = "伊团乱麻",
	Rarity = 5,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "面对毫无头绪的案件时人们脑中杂乱思绪的具象化。只有打败了他才能通过悬疑世界。",
	IconBundle = "atlas_charactericon_arena",
	IconAtlas = "ARENA",
	IconName = "Arena_SUS_Luggage",
	PrefabBundle = "character_arenaenemy",
	PrefabName = "Arena_SUS_Luggage",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 1338, Gain = 268},
		{Value = 200002, Base = 35, Gain = 7},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
EnemyConfig[EnemyID.Id8051] =
{
	Id = 8051,
	Name = "星际海盗",
	Rarity = 3,
	Element = 210001,
	Style = "Dps",
	AttackType = "Melee",
	Desc = "在各大宙域流窜作案的星际海盗，目前正受到联邦政府通缉，一旦被捕，将面临超过1000年的刑期。",
	IconBundle = "atlas_charactericon_st",
	IconAtlas = "ST",
	IconName = "SpaceTravel_CampEnemy_6_1",
	PrefabBundle = "character_st",
	PrefabName = "SpaceTravel_CampEnemy_6_1",
	PrefabScale = 50,
	HPBarHeight = 100,
	BattleResource =  {
		AttackAnim = 
		{
			"Attack_1","Attack_2",
		},
		CritAttackAnim = "Attack_3",
		BattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		CritBattleEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
		SkillAnim = "Cast",
		RangeAttackAnim = "Attack_1",
		RangeAttackEffect =  {
			Prefab = "BattleEffectWater",
			Attack = "Melee_Effect",
			Hit = "Hit_Melee",
		},
	},
	Ability = {
		{Value = 200001, Base = 2319, Gain = 464},
		{Value = 200002, Base = 41, Gain = 9},
		{Value = 200003, Base = 5, Gain = 1},
		{Value = 200004, Base = 5, Gain = 1},
	},
	Drop = {
	},
}
