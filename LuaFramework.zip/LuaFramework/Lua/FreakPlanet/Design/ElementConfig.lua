ElementConfig ={};
ElementID = 
{
	Id001 = 210001,
	Id002 = 210002,
	Id003 = 210003,
	Id004 = 210004,
	Id005 = 210005,
}
ElementConfig[ElementID.Id001] =
{
	Id = 1,
	Name = "水元素",
	Code = "Water",
	VS = {
		{Value = 210001, Num = 1},
		{Value = 210002, Num = 2},
		{Value = 210003, Num = 0.75},
		{Value = 210004, Num = 1},
		{Value = 210005, Num = 1},
	},
}
ElementConfig[ElementID.Id002] =
{
	Id = 2,
	Name = "火元素",
	Code = "Fire",
	VS = {
		{Value = 210001, Num = 0.75},
		{Value = 210002, Num = 1},
		{Value = 210003, Num = 2},
		{Value = 210004, Num = 1},
		{Value = 210005, Num = 1},
	},
}
ElementConfig[ElementID.Id003] =
{
	Id = 3,
	Name = "风元素",
	Code = "Wind",
	VS = {
		{Value = 210001, Num = 2},
		{Value = 210002, Num = 0.75},
		{Value = 210003, Num = 1},
		{Value = 210004, Num = 1},
		{Value = 210005, Num = 1},
	},
}
ElementConfig[ElementID.Id004] =
{
	Id = 4,
	Name = "光元素",
	Code = "Light",
	VS = {
		{Value = 210001, Num = 1},
		{Value = 210002, Num = 1},
		{Value = 210003, Num = 1},
		{Value = 210004, Num = 0.75},
		{Value = 210005, Num = 2},
	},
}
ElementConfig[ElementID.Id005] =
{
	Id = 5,
	Name = "暗元素",
	Code = "Dark",
	VS = {
		{Value = 210001, Num = 1},
		{Value = 210002, Num = 1},
		{Value = 210003, Num = 1},
		{Value = 210004, Num = 2},
		{Value = 210005, Num = 0.75},
	},
}

