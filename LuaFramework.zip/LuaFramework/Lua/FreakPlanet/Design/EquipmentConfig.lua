require "FreakPlanet/Design/MiscConfig"
EquipmentConfig ={};
EquipmentID = 
{
	Id001 = 340001,
	Id002 = 340002,
	Id003 = 340003,
	Id004 = 340004,
	Id005 = 340005,
	Id006 = 340006,
	Id007 = 340007,
	Id008 = 340008,
	Id009 = 340009,
	Id010 = 340010,
	Id011 = 340011,
	Id012 = 340012,
	Id013 = 340013,
	Id014 = 340014,
	Id015 = 340015,
	Id016 = 340016,
	Id017 = 340017,
	Id018 = 340018,
	Id019 = 340019,
	Id020 = 340020,
	Id021 = 340021,
	Id022 = 340022,
	Id023 = 340023,
	Id024 = 340024,
	Id025 = 340025,
	Id026 = 340026,
	Id027 = 340027,
	Id028 = 340028,
	Id029 = 340029,
	Id030 = 340030,
	Id031 = 340031,
	Id032 = 340032,
	Id033 = 340033,
	Id034 = 340034,
	Id035 = 340035,
	Id036 = 340036,
	Id037 = 340037,
	Id038 = 340038,
	Id039 = 340039,
	Id040 = 340040,
	Id041 = 340041,
	Id042 = 340042,
	Id043 = 340043,
	Id044 = 340044,
	Id045 = 340045,
	Id046 = 340046,
	Id047 = 340047,
	Id048 = 340048,
	Id049 = 340049,
	Id050 = 340050,
	Id051 = 340051,
	Id052 = 340052,
	Id053 = 340053,
	Id054 = 340054,
	Id055 = 340055,
	Id056 = 340056,
	Id057 = 340057,
	Id058 = 340058,
	Id059 = 340059,
	Id060 = 340060,
	Id061 = 340061,
	Id062 = 340062,
	Id063 = 340063,
	Id064 = 340064,
	Id065 = 340065,
	Id066 = 340066,
	Id067 = 340067,
	Id068 = 340068,
	Id069 = 340069,
	Id070 = 340070,
	Id071 = 340071,
	Id072 = 340072,
	Id073 = 340073,
	Id074 = 340074,
	Id075 = 340075,
	Id076 = 340076,
	Id077 = 340077,
	Id078 = 340078,
	Id079 = 340079,
	Id080 = 340080,
	Id081 = 340081,
	Id082 = 340082,
	Id083 = 340083,
	Id084 = 340084,
	Id085 = 340085,
	Id086 = 340086,
	Id087 = 340087,
	Id088 = 340088,
	Id089 = 340089,
	Id090 = 340090,
	Id091 = 340091,
	Id092 = 340092,
	Id093 = 340093,
	Id094 = 340094,
	Id095 = 340095,
	Id096 = 340096,
	Id097 = 340097,
	Id098 = 340098,
	Id099 = 340099,
	Id100 = 340100,
	Id101 = 340101,
	Id102 = 340102,
	Id103 = 340103,
	Id104 = 340104,
	Id105 = 340105,
	Id106 = 340106,
	Id107 = 340107,
	Id108 = 340108,
	Id109 = 340109,
	Id110 = 340110,
	Id111 = 340111,
	Id112 = 340112,
	Id113 = 340113,
	Id114 = 340114,
	Id115 = 340115,
	Id116 = 340116,
	Id117 = 340117,
	Id118 = 340118,
	Id119 = 340119,
	Id120 = 340120,
	Id121 = 340121,
	Id122 = 340122,
	Id123 = 340123,
	Id124 = 340124,
	Id125 = 340125,
	Id126 = 340126,
	Id127 = 340127,
	Id128 = 340128,
	Id129 = 340129,
	Id130 = 340130,
	Id131 = 340131,
	Id132 = 340132,
	Id133 = 340133,
	Id134 = 340134,
	Id135 = 340135,
	Id136 = 340136,
	Id137 = 340137,
	Id138 = 340138,
	Id139 = 340139,
	Id140 = 340140,
	Id141 = 340141,
	Id142 = 340142,
	Id143 = 340143,
	Id144 = 340144,
	Id145 = 340145,
	Id146 = 340146,
	Id147 = 340147,
	Id148 = 340148,
	Id149 = 340149,
	Id150 = 340150,
	Id151 = 340151,
	Id152 = 340152,
	Id153 = 340153,
	Id154 = 340154,
	Id155 = 340155,
	Id156 = 340156,
	Id157 = 340157,
	Id158 = 340158,
	Id159 = 340159,
	Id160 = 340160,
	Id161 = 340161,
	Id162 = 340162,
	Id163 = 340163,
	Id164 = 340164,
	Id165 = 340165,
	Id166 = 340166,
	Id167 = 340167,
	Id168 = 340168,
	Id169 = 340169,
	Id170 = 340170,
	Id171 = 340171,
	Id172 = 340172,
	Id173 = 340173,
	Id174 = 340174,
	Id175 = 340175,
	Id176 = 340176,
	Id177 = 340177,
	Id178 = 340178,
	Id179 = 340179,
	Id180 = 340180,
	Id181 = 340181,
	Id182 = 340182,
	Id183 = 340183,
	Id184 = 340184,
	Id185 = 340185,
	Id186 = 340186,
	Id187 = 340187,
	Id188 = 340188,
	Id189 = 340189,
	Id190 = 340190,
	Id191 = 340191,
	Id192 = 340192,
	Id193 = 340193,
	Id194 = 340194,
	Id195 = 340195,
	Id196 = 340196,
	Id197 = 340197,
	Id198 = 340198,
	Id199 = 340199,
	Id200 = 340200,
	Id201 = 340201,
	Id202 = 340202,
	Id203 = 340203,
	Id204 = 340204,
	Id205 = 340205,
	Id206 = 340206,
	Id207 = 340207,
	Id208 = 340208,
	Id209 = 340209,
	Id210 = 340210,
	Id211 = 340211,
	Id212 = 340212,
	Id213 = 340213,
	Id214 = 340214,
	Id215 = 340215,
	Id216 = 340216,
	Id217 = 340217,
	Id218 = 340218,
	Id219 = 340219,
	Id220 = 340220,
	Id221 = 340221,
	Id222 = 340222,
	Id223 = 340223,
	Id224 = 340224,
	Id225 = 340225,
	Id226 = 340226,
	Id227 = 340227,
	Id228 = 340228,
	Id229 = 340229,
	Id230 = 340230,
	Id231 = 340231,
	Id232 = 340232,
	Id233 = 340233,
	Id234 = 340234,
	Id235 = 340235,
	Id236 = 340236,
	Id237 = 340237,
	Id238 = 340238,
	Id239 = 340239,
	Id240 = 340240,
	Id241 = 340241,
	Id242 = 340242,
	Id243 = 340243,
	Id244 = 340244,
	Id245 = 340245,
	Id246 = 340246,
	Id247 = 340247,
	Id248 = 340248,
	Id249 = 340249,
	Id250 = 340250,
	Id251 = 340251,
	Id252 = 340252,
	Id253 = 340253,
	Id254 = 340254,
	Id255 = 340255,
	Id256 = 340256,
	Id257 = 340257,
	Id258 = 340258,
	Id259 = 340259,
	Id260 = 340260,
	Id261 = 340261,
	Id262 = 340262,
	Id263 = 340263,
	Id264 = 340264,
	Id265 = 340265,
	Id266 = 340266,
	Id267 = 340267,
	Id268 = 340268,
	Id269 = 340269,
	Id270 = 340270,
	Id271 = 340271,
	Id272 = 340272,
	Id273 = 340273,
	Id274 = 340274,
	Id275 = 340275,
	Id276 = 340276,
	Id277 = 340277,
	Id278 = 340278,
	Id279 = 340279,
	Id280 = 340280,
	Id281 = 340281,
	Id282 = 340282,
	Id283 = 340283,
	Id284 = 340284,
	Id285 = 340285,
	Id286 = 340286,
	Id287 = 340287,
	Id288 = 340288,
	Id289 = 340289,
	Id290 = 340290,
	Id291 = 340291,
	Id292 = 340292,
	Id293 = 340293,
	Id294 = 340294,
	Id295 = 340295,
	Id296 = 340296,
	Id297 = 340297,
	Id298 = 340298,
	Id299 = 340299,
	Id300 = 340300,
	Id301 = 340301,
	Id302 = 340302,
	Id303 = 340303,
	Id304 = 340304,
	Id305 = 340305,
	Id306 = 340306,
	Id307 = 340307,
	Id308 = 340308,
	Id309 = 340309,
	Id310 = 340310,
	Id312 = 340312,
	Id313 = 340313,
	Id315 = 340315,
	Id316 = 340316,
	Id317 = 340317,
	Id318 = 340318,
	Id319 = 340319,
	Id320 = 340320,
	Id321 = 340321,
	Id322 = 340322,
	Id323 = 340323,
	Id324 = 340324,
	Id325 = 340325,
	Id326 = 340326,
	Id327 = 340327,
	Id328 = 340328,
	Id329 = 340329,
	Id330 = 340330,
	Id331 = 340331,
	Id332 = 340332,
	Id333 = 340333,
	Id334 = 340334,
	Id335 = 340335,
	Id336 = 340336,
	Id337 = 340337,
	Id338 = 340338,
	Id339 = 340339,
	Id340 = 340340,
	Id341 = 340341,
	Id342 = 340342,
	Id343 = 340343,
	Id344 = 340344,
	Id345 = 340345,
	Id346 = 340346,
	Id347 = 340347,
	Id348 = 340348,
	Id349 = 340349,
	Id350 = 340350,
	Id351 = 340351,
	Id352 = 340352,
	Id353 = 340353,
	Id354 = 340354,
	Id355 = 340355,
	Id356 = 340356,
	Id357 = 340357,
	Id358 = 340358,
	Id359 = 340359,
	Id360 = 340360,
	Id361 = 340361,
	Id362 = 340362,
	Id363 = 340363,
	Id364 = 340364,
	Id365 = 340365,
	Id366 = 340366,
	Id367 = 340367,
	Id368 = 340368,
	Id369 = 340369,
	Id370 = 340370,
	Id371 = 340371,
	Id372 = 340372,
	Id373 = 340373,
	Id374 = 340374,
	Id375 = 340375,
	Id376 = 340376,
	Id377 = 340377,
	Id378 = 340378,
	Id379 = 340379,
	Id380 = 340380,
	Id381 = 340381,
	Id382 = 340382,
	Id383 = 340383,
	Id384 = 340384,
	Id385 = 340385,
	Id386 = 340386,
	Id387 = 340387,
	Id388 = 340388,
	Id389 = 340389,
	Id390 = 340390,
	Id391 = 340391,
	Id392 = 340392,
	Id393 = 340393,
	Id394 = 340394,
	Id395 = 340395,
	Id396 = 340396,
	Id397 = 340397,
	Id398 = 340398,
	Id399 = 340399,
	Id400 = 340400,
	Id401 = 340401,
	Id402 = 340402,
	Id403 = 340403,
	Id404 = 340404,
	Id405 = 340405,
	Id406 = 340406,
	Id407 = 340407,
	Id408 = 340408,
	Id409 = 340409,
	Id410 = 340410,
	Id411 = 340411,
	Id412 = 340412,
	Id413 = 340413,
	Id414 = 340414,
	Id415 = 340415,
	Id416 = 340416,
	Id417 = 340417,
	Id418 = 340418,
	Id419 = 340419,
	Id420 = 340420,
	Id421 = 340421,
	Id422 = 340422,
	Id423 = 340423,
	Id424 = 340424,
	Id425 = 340425,
	Id426 = 340426,
	Id427 = 340427,
	Id428 = 340428,
	Id429 = 340429,
	Id430 = 340430,
	Id431 = 340431,
	Id432 = 340432,
	Id433 = 340433,
	Id434 = 340434,
	Id435 = 340435,
	Id436 = 340436,
	Id437 = 340437,
	Id438 = 340438,
	Id439 = 340439,
	Id440 = 340440,
	Id441 = 340441,
	Id442 = 340442,
	Id443 = 340443,
	Id444 = 340444,
	Id445 = 340445,
	Id446 = 340446,
	Id447 = 340447,
	Id448 = 340448,
	Id449 = 340449,
	Id450 = 340450,
	Id451 = 340451,
	Id452 = 340452,
	Id453 = 340453,
	Id454 = 340454,
	Id455 = 340455,
	Id456 = 340456,
	Id457 = 340457,
	Id458 = 340458,
	Id459 = 340459,
	Id460 = 340460,
	Id461 = 340461,
	Id462 = 340462,
	Id463 = 340463,
	Id464 = 340464,
	Id465 = 340465,
	Id466 = 340466,
	Id467 = 340467,
	Id468 = 340468,
	Id469 = 340469,
	Id470 = 340470,
	Id471 = 340471,
	Id472 = 340472,
	Id473 = 340473,
	Id474 = 340474,
	Id475 = 340475,
	Id476 = 340476,
	Id477 = 340477,
	Id478 = 340478,
	Id479 = 340479,
	Id480 = 340480,
	Id481 = 340481,
	Id482 = 340482,
	Id483 = 340483,
	Id484 = 340484,
	Id485 = 340485,
	Id486 = 340486,
	Id487 = 340487,
	Id488 = 340488,
	Id489 = 340489,
	Id490 = 340490,
	Id491 = 340491,
	Id492 = 340492,
	Id493 = 340493,
	Id494 = 340494,
	Id495 = 340495,
	Id496 = 340496,
	Id497 = 340497,
	Id498 = 340498,
	Id499 = 340499,
	Id500 = 340500,
	Id501 = 340501,
	Id502 = 340502,
	Id503 = 340503,
	Id504 = 340504,
	Id505 = 340505,
	Id506 = 340506,
	Id507 = 340507,
	Id508 = 340508,
	Id509 = 340509,
	Id510 = 340510,
	Id511 = 340511,
	Id512 = 340512,
	Id513 = 340513,
	Id514 = 340514,
	Id515 = 340515,
	Id516 = 340516,
	Id517 = 340517,
	Id518 = 340518,
	Id519 = 340519,
	Id520 = 340520,
	Id521 = 340521,
	Id522 = 340522,
	Id523 = 340523,
	Id524 = 340524,
	Id525 = 340525,
	Id526 = 340526,
	Id527 = 340527,
	Id528 = 340528,
	Id529 = 340529,
	Id530 = 340530,
	Id531 = 340531,
	Id532 = 340532,
	Id533 = 340533,
	Id534 = 340534,
	Id535 = 340535,
	Id536 = 340536,
	Id537 = 340537,
	Id538 = 340538,
	Id539 = 340539,
	Id540 = 340540,
	Id541 = 340541,
	Id542 = 340542,
	Id543 = 340543,
	Id544 = 340544,
	Id545 = 340545,
	Id546 = 340546,
	Id547 = 340547,
	Id548 = 340548,
	Id549 = 340549,
	Id550 = 340550,
	Id551 = 340551,
	Id552 = 340552,
	Id553 = 340553,
	Id554 = 340554,
	Id555 = 340555,
	Id556 = 340556,
	Id557 = 340557,
	Id558 = 340558,
	Id559 = 340559,
	Id560 = 340560,
	Id561 = 340561,
	Id562 = 340562,
	Id563 = 340563,
	Id564 = 340564,
	Id565 = 340565,
	Id566 = 340566,
	Id567 = 340567,
	Id568 = 340568,
	Id569 = 340569,
	Id570 = 340570,
	Id571 = 340571,
	Id572 = 340572,
	Id573 = 340573,
	Id574 = 340574,
	Id575 = 340575,
	Id576 = 340576,
	Id577 = 340577,
	Id578 = 340578,
	Id579 = 340579,
	Id580 = 340580,
	Id581 = 340581,
	Id582 = 340582,
	Id583 = 340583,
	Id584 = 340584,
	Id585 = 340585,
	Id586 = 340586,
	Id587 = 340587,
	Id588 = 340588,
	Id589 = 340589,
	Id590 = 340590,
	Id591 = 340591,
	Id592 = 340592,
	Id593 = 340593,
	Id594 = 340594,
	Id595 = 340595,
	Id596 = 340596,
	Id597 = 340597,
	Id598 = 340598,
	Id599 = 340599,
	Id600 = 340600,
	Id601 = 340601,
	Id602 = 340602,
	Id603 = 340603,
	Id604 = 340604,
	Id605 = 340605,
	Id606 = 340606,
	Id607 = 340607,
	Id608 = 340608,
	Id609 = 340609,
	Id610 = 340610,
	Id611 = 340611,
	Id612 = 340612,
	Id613 = 340613,
	Id614 = 340614,
	Id615 = 340615,
	Id616 = 340616,
	Id617 = 340617,
	Id618 = 340618,
	Id619 = 340619,
	Id620 = 340620,
	Id621 = 340621,
	Id622 = 340622,
	Id623 = 340623,
	Id624 = 340624,
	Id625 = 340625,
	Id626 = 340626,
	Id627 = 340627,
	Id628 = 340628,
	Id629 = 340629,
	Id630 = 340630,
	Id631 = 340631,
	Id632 = 340632,
	Id633 = 340633,
	Id634 = 340634,
	Id635 = 340635,
	Id636 = 340636,
	Id637 = 340637,
	Id638 = 340638,
	Id639 = 340639,
	Id640 = 340640,
	Id641 = 340641,
	Id642 = 340642,
	Id643 = 340643,
	Id644 = 340644,
	Id645 = 340645,
	Id646 = 340646,
	Id647 = 340647,
	Id648 = 340648,
	Id649 = 340649,
	Id650 = 340650,
	Id651 = 340651,
	Id652 = 340652,
	Id653 = 340653,
	Id654 = 340654,
	Id655 = 340655,
	Id656 = 340656,
	Id657 = 340657,
	Id658 = 340658,
	Id659 = 340659,
	Id660 = 340660,
	Id661 = 340661,
	Id662 = 340662,
	Id663 = 340663,
	Id664 = 340664,
	Id665 = 340665,
	Id666 = 340666,
	Id667 = 340667,
	Id668 = 340668,
	Id669 = 340669,
	Id670 = 340670,
	Id671 = 340671,
	Id672 = 340672,
	Id673 = 340673,
	Id674 = 340674,
	Id675 = 340675,
	Id676 = 340676,
	Id677 = 340677,
	Id678 = 340678,
	Id679 = 340679,
	Id680 = 340680,
	Id681 = 340681,
	Id682 = 340682,
	Id683 = 340683,
	Id684 = 340684,
	Id685 = 340685,
	Id686 = 340686,
	Id687 = 340687,
	Id688 = 340688,
	Id689 = 340689,
	Id690 = 340690,
	Id691 = 340691,
	Id692 = 340692,
	Id693 = 340693,
	Id694 = 340694,
	Id695 = 340695,
	Id696 = 340696,
	Id697 = 340697,
	Id698 = 340698,
	Id699 = 340699,
	Id700 = 340700,
	Id701 = 340701,
	Id702 = 340702,
	Id703 = 340703,
	Id704 = 340704,
	Id705 = 340705,
	Id706 = 340706,
	Id707 = 340707,
	Id708 = 340708,
	Id709 = 340709,
	Id710 = 340710,
	Id711 = 340711,
	Id712 = 340712,
	Id713 = 340713,
	Id714 = 340714,
	Id715 = 340715,
	Id716 = 340716,
	Id717 = 340717,
	Id718 = 340718,
	Id719 = 340719,
	Id720 = 340720,
	Id721 = 340721,
	Id722 = 340722,
	Id723 = 340723,
	Id724 = 340724,
	Id725 = 340725,
	Id726 = 340726,
	Id727 = 340727,
	Id728 = 340728,
	Id729 = 340729,
	Id730 = 340730,
	Id731 = 340731,
	Id732 = 340732,
	Id733 = 340733,
	Id734 = 340734,
	Id735 = 340735,
	Id736 = 340736,
	Id737 = 340737,
	Id738 = 340738,
	Id739 = 340739,
	Id740 = 340740,
	Id741 = 340741,
	Id742 = 340742,
	Id743 = 340743,
	Id744 = 340744,
	Id745 = 340745,
	Id746 = 340746,
	Id747 = 340747,
	Id748 = 340748,
	Id749 = 340749,
	Id750 = 340750,
}
EquipmentConfig[EquipmentID.Id001] =
{
	Character = 220001,
	Rarity = 2,
	UpgradeId = 930025,
	LevelList = {
		{
			Level = 1,
			Info = 920001,
			Ability = {
				{
					Value = 200001,
					Num = 45,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920001,
			Ability = {
				{
					Value = 200001,
					Num = 90,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920001,
			Ability = {
				{
					Value = 200001,
					Num = 135,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920001,
			Ability = {
				{
					Value = 200001,
					Num = 180,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920001,
			Ability = {
				{
					Value = 200001,
					Num = 225,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920001,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920001,
			Ability = {
				{
					Value = 200001,
					Num = 315,
				},
				{
					Value = 200006,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920001,
			Ability = {
				{
					Value = 200001,
					Num = 360,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920001,
			Ability = {
				{
					Value = 200001,
					Num = 405,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920001,
			Ability = {
				{
					Value = 200001,
					Num = 450,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id002] =
{
	Character = 220001,
	Rarity = 2,
	NeedChallenge = 145001,
	UpgradeId = 930006,
	LevelList = {
		{
			Level = 1,
			Info = 920002,
			Ability = {
				{
					Value = 200002,
					Num = 33,
				},
				{
					Value = 200007,
					Num = 3,
				},
			},
		},
		{
			Level = 2,
			Info = 920003,
			Ability = {
				{
					Value = 200002,
					Num = 66,
				},
				{
					Value = 200007,
					Num = 6,
				},
			},
		},
		{
			Level = 3,
			Info = 920004,
			Ability = {
				{
					Value = 200002,
					Num = 99,
				},
				{
					Value = 200007,
					Num = 9,
				},
			},
		},
		{
			Level = 4,
			Info = 920005,
			Ability = {
				{
					Value = 200002,
					Num = 132,
				},
				{
					Value = 200007,
					Num = 12,
				},
			},
		},
		{
			Level = 5,
			Info = 920006,
			Ability = {
				{
					Value = 200002,
					Num = 165,
				},
				{
					Value = 200007,
					Num = 15,
				},
			},
		},
		{
			Level = 6,
			Info = 920007,
			Ability = {
				{
					Value = 200002,
					Num = 198,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 7,
			Info = 920008,
			Ability = {
				{
					Value = 200002,
					Num = 231,
				},
				{
					Value = 200007,
					Num = 21,
				},
			},
		},
		{
			Level = 8,
			Info = 920009,
			Ability = {
				{
					Value = 200002,
					Num = 264,
				},
				{
					Value = 200007,
					Num = 24,
				},
			},
			SkillList = {
				{
					Id = 101768,
					Value = 33,
				},
			},
		},
		{
			Level = 9,
			Info = 920010,
			Ability = {
				{
					Value = 200002,
					Num = 297,
				},
				{
					Value = 200007,
					Num = 27,
				},
			},
			SkillList = {
				{
					Id = 101768,
					Value = 33,
				},
			},
		},
		{
			Level = 10,
			Info = 920011,
			Ability = {
				{
					Value = 200002,
					Num = 330,
				},
				{
					Value = 200007,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 101768,
					Value = 33,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id003] =
{
	Character = 220002,
	Rarity = 2,
	UpgradeId = 930025,
	LevelList = {
		{
			Level = 1,
			Info = 920012,
			Ability = {
				{
					Value = 200001,
					Num = 42,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920012,
			Ability = {
				{
					Value = 200001,
					Num = 84,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920012,
			Ability = {
				{
					Value = 200001,
					Num = 126,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920012,
			Ability = {
				{
					Value = 200001,
					Num = 168,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920012,
			Ability = {
				{
					Value = 200001,
					Num = 210,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920012,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920012,
			Ability = {
				{
					Value = 200001,
					Num = 294,
				},
				{
					Value = 200005,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920012,
			Ability = {
				{
					Value = 200001,
					Num = 336,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920012,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920012,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id004] =
{
	Character = 220002,
	Rarity = 2,
	NeedChallenge = 145002,
	UpgradeId = 930006,
	LevelList = {
		{
			Level = 1,
			Info = 920013,
			Ability = {
				{
					Value = 200002,
					Num = 33,
				},
				{
					Value = 200008,
					Num = 3,
				},
			},
		},
		{
			Level = 2,
			Info = 920014,
			Ability = {
				{
					Value = 200002,
					Num = 66,
				},
				{
					Value = 200008,
					Num = 6,
				},
			},
		},
		{
			Level = 3,
			Info = 920015,
			Ability = {
				{
					Value = 200002,
					Num = 99,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 4,
			Info = 920016,
			Ability = {
				{
					Value = 200002,
					Num = 132,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 5,
			Info = 920017,
			Ability = {
				{
					Value = 200002,
					Num = 165,
				},
				{
					Value = 200008,
					Num = 15,
				},
			},
		},
		{
			Level = 6,
			Info = 920018,
			Ability = {
				{
					Value = 200002,
					Num = 198,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 7,
			Info = 920019,
			Ability = {
				{
					Value = 200002,
					Num = 231,
				},
				{
					Value = 200008,
					Num = 21,
				},
			},
		},
		{
			Level = 8,
			Info = 920020,
			Ability = {
				{
					Value = 200002,
					Num = 264,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
			SkillList = {
				{
					Id = 101739,
					Value = 12,
				},
			},
		},
		{
			Level = 9,
			Info = 920021,
			Ability = {
				{
					Value = 200002,
					Num = 297,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
			SkillList = {
				{
					Id = 101739,
					Value = 12,
				},
			},
		},
		{
			Level = 10,
			Info = 920022,
			Ability = {
				{
					Value = 200002,
					Num = 330,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 101739,
					Value = 12,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id005] =
{
	Character = 220003,
	Rarity = 2,
	UpgradeId = 930025,
	LevelList = {
		{
			Level = 1,
			Info = 920024,
			Ability = {
				{
					Value = 200001,
					Num = 45,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920024,
			Ability = {
				{
					Value = 200001,
					Num = 90,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920024,
			Ability = {
				{
					Value = 200001,
					Num = 135,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920024,
			Ability = {
				{
					Value = 200001,
					Num = 180,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920024,
			Ability = {
				{
					Value = 200001,
					Num = 225,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920024,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920024,
			Ability = {
				{
					Value = 200001,
					Num = 315,
				},
				{
					Value = 200006,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920024,
			Ability = {
				{
					Value = 200001,
					Num = 360,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
		{
			Level = 9,
			Info = 920024,
			Ability = {
				{
					Value = 200001,
					Num = 405,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
		{
			Level = 10,
			Info = 920024,
			Ability = {
				{
					Value = 200001,
					Num = 450,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id006] =
{
	Character = 220003,
	Rarity = 2,
	NeedChallenge = 145003,
	UpgradeId = 930006,
	LevelList = {
		{
			Level = 1,
			Info = 920023,
			Ability = {
				{
					Value = 200002,
					Num = 33,
				},
				{
					Value = 200007,
					Num = 3,
				},
			},
		},
		{
			Level = 2,
			Info = 920023,
			Ability = {
				{
					Value = 200002,
					Num = 66,
				},
				{
					Value = 200007,
					Num = 6,
				},
			},
		},
		{
			Level = 3,
			Info = 920023,
			Ability = {
				{
					Value = 200002,
					Num = 99,
				},
				{
					Value = 200007,
					Num = 9,
				},
			},
		},
		{
			Level = 4,
			Info = 920023,
			Ability = {
				{
					Value = 200002,
					Num = 132,
				},
				{
					Value = 200007,
					Num = 12,
				},
			},
		},
		{
			Level = 5,
			Info = 920023,
			Ability = {
				{
					Value = 200002,
					Num = 165,
				},
				{
					Value = 200007,
					Num = 15,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920023,
			Ability = {
				{
					Value = 200002,
					Num = 198,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920023,
			Ability = {
				{
					Value = 200002,
					Num = 231,
				},
				{
					Value = 200007,
					Num = 21,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920023,
			Ability = {
				{
					Value = 200002,
					Num = 264,
				},
				{
					Value = 200007,
					Num = 24,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920023,
			Ability = {
				{
					Value = 200002,
					Num = 297,
				},
				{
					Value = 200007,
					Num = 27,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920023,
			Ability = {
				{
					Value = 200002,
					Num = 330,
				},
				{
					Value = 200007,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id007] =
{
	Character = 220004,
	Rarity = 2,
	UpgradeId = 930005,
	LevelList = {
		{
			Level = 1,
			Info = 920026,
			Ability = {
				{
					Value = 200002,
					Num = 36,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
			SkillList = {
				{
					Id = 101745,
					Value = 10,
				},
			},
		},
		{
			Level = 2,
			Info = 920026,
			Ability = {
				{
					Value = 200002,
					Num = 72,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
			SkillList = {
				{
					Id = 101745,
					Value = 20,
				},
			},
		},
		{
			Level = 3,
			Info = 920026,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
			SkillList = {
				{
					Id = 101745,
					Value = 30,
				},
			},
		},
		{
			Level = 4,
			Info = 920026,
			Ability = {
				{
					Value = 200002,
					Num = 144,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
			SkillList = {
				{
					Id = 101745,
					Value = 40,
				},
			},
		},
		{
			Level = 5,
			Info = 920026,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 101745,
					Value = 50,
				},
			},
		},
		{
			Level = 6,
			Info = 920026,
			Ability = {
				{
					Value = 200002,
					Num = 216,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 101745,
					Value = 60,
				},
			},
		},
		{
			Level = 7,
			Info = 920026,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200005,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 101745,
					Value = 70,
				},
			},
		},
		{
			Level = 8,
			Info = 920026,
			Ability = {
				{
					Value = 200002,
					Num = 288,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 101745,
					Value = 80,
				},
			},
		},
		{
			Level = 9,
			Info = 920026,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 101745,
					Value = 90,
				},
			},
		},
		{
			Level = 10,
			Info = 920026,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 101745,
					Value = 100,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id008] =
{
	Character = 220004,
	Rarity = 2,
	NeedChallenge = 145004,
	UpgradeId = 930006,
	LevelList = {
		{
			Level = 1,
			Info = 920025,
			Ability = {
				{
					Value = 200002,
					Num = 36,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920025,
			Ability = {
				{
					Value = 200002,
					Num = 72,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920025,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920025,
			Ability = {
				{
					Value = 200002,
					Num = 144,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920025,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920025,
			Ability = {
				{
					Value = 200002,
					Num = 216,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920025,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200006,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920025,
			Ability = {
				{
					Value = 200002,
					Num = 288,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 101503,
					Value = -22,
				},
			},
		},
		{
			Level = 9,
			Info = 920025,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 101503,
					Value = -22,
				},
			},
		},
		{
			Level = 10,
			Info = 920025,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 101503,
					Value = -22,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id009] =
{
	Character = 220005,
	Rarity = 2,
	UpgradeId = 930005,
	LevelList = {
		{
			Level = 1,
			Info = 920027,
			Ability = {
				{
					Value = 200002,
					Num = 33,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920027,
			Ability = {
				{
					Value = 200002,
					Num = 66,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920027,
			Ability = {
				{
					Value = 200002,
					Num = 99,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920027,
			Ability = {
				{
					Value = 200002,
					Num = 132,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920027,
			Ability = {
				{
					Value = 200002,
					Num = 165,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920027,
			Ability = {
				{
					Value = 200002,
					Num = 198,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920027,
			Ability = {
				{
					Value = 200002,
					Num = 231,
				},
				{
					Value = 200006,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920027,
			Ability = {
				{
					Value = 200002,
					Num = 264,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920027,
			Ability = {
				{
					Value = 200002,
					Num = 297,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920027,
			Ability = {
				{
					Value = 200002,
					Num = 330,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id010] =
{
	Character = 220005,
	Rarity = 2,
	NeedChallenge = 145005,
	UpgradeId = 930026,
	LevelList = {
		{
			Level = 1,
			Info = 920028,
			Ability = {
				{
					Value = 200001,
					Num = 42,
				},
				{
					Value = 200005,
					Num = 3,
				},
			},
		},
		{
			Level = 2,
			Info = 920028,
			Ability = {
				{
					Value = 200001,
					Num = 84,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 3,
			Info = 920028,
			Ability = {
				{
					Value = 200001,
					Num = 126,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 4,
			Info = 920028,
			Ability = {
				{
					Value = 200001,
					Num = 168,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 5,
			Info = 920028,
			Ability = {
				{
					Value = 200001,
					Num = 210,
				},
				{
					Value = 200005,
					Num = 15,
				},
			},
			SkillList = {
				{
					Id = 100481,
					Value = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920028,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
			SkillList = {
				{
					Id = 100481,
					Value = 25,
				},
			},
		},
		{
			Level = 7,
			Info = 920028,
			Ability = {
				{
					Value = 200001,
					Num = 294,
				},
				{
					Value = 200005,
					Num = 21,
				},
			},
			SkillList = {
				{
					Id = 100481,
					Value = 25,
				},
			},
		},
		{
			Level = 8,
			Info = 920028,
			Ability = {
				{
					Value = 200001,
					Num = 336,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
			SkillList = {
				{
					Id = 100481,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920028,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
			SkillList = {
				{
					Id = 100481,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920028,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100481,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id011] =
{
	Character = 220006,
	Rarity = 2,
	UpgradeId = 930025,
	LevelList = {
		{
			Level = 1,
			Info = 920050,
			Ability = {
				{
					Value = 200001,
					Num = 42,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920050,
			Ability = {
				{
					Value = 200001,
					Num = 84,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920050,
			Ability = {
				{
					Value = 200001,
					Num = 126,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920050,
			Ability = {
				{
					Value = 200001,
					Num = 168,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920050,
			Ability = {
				{
					Value = 200001,
					Num = 210,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920050,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920050,
			Ability = {
				{
					Value = 200001,
					Num = 294,
				},
				{
					Value = 200006,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920050,
			Ability = {
				{
					Value = 200001,
					Num = 336,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 101701,
					Value = 180,
				},
			},
		},
		{
			Level = 9,
			Info = 920050,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 101701,
					Value = 180,
				},
			},
		},
		{
			Level = 10,
			Info = 920050,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 101701,
					Value = 180,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id012] =
{
	Character = 220006,
	Rarity = 2,
	NeedChallenge = 145006,
	UpgradeId = 930026,
	LevelList = {
		{
			Level = 1,
			Info = 920051,
			Ability = {
				{
					Value = 200001,
					Num = 42,
				},
				{
					Value = 200007,
					Num = 3,
				},
			},
		},
		{
			Level = 2,
			Info = 920051,
			Ability = {
				{
					Value = 200001,
					Num = 84,
				},
				{
					Value = 200007,
					Num = 6,
				},
			},
		},
		{
			Level = 3,
			Info = 920051,
			Ability = {
				{
					Value = 200001,
					Num = 126,
				},
				{
					Value = 200007,
					Num = 9,
				},
			},
		},
		{
			Level = 4,
			Info = 920051,
			Ability = {
				{
					Value = 200001,
					Num = 168,
				},
				{
					Value = 200007,
					Num = 12,
				},
			},
		},
		{
			Level = 5,
			Info = 920051,
			Ability = {
				{
					Value = 200001,
					Num = 210,
				},
				{
					Value = 200007,
					Num = 15,
				},
			},
		},
		{
			Level = 6,
			Info = 920051,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 7,
			Info = 920051,
			Ability = {
				{
					Value = 200001,
					Num = 294,
				},
				{
					Value = 200007,
					Num = 21,
				},
			},
		},
		{
			Level = 8,
			Info = 920051,
			Ability = {
				{
					Value = 200001,
					Num = 336,
				},
				{
					Value = 200007,
					Num = 24,
				},
			},
			SkillList = {
				{
					Id = 100221,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920051,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200007,
					Num = 27,
				},
			},
			SkillList = {
				{
					Id = 100221,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920051,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
				{
					Value = 200007,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100221,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id013] =
{
	Character = 220007,
	Rarity = 2,
	UpgradeId = 930005,
	LevelList = {
		{
			Level = 1,
			Info = 920032,
			Ability = {
				{
					Value = 200002,
					Num = 33,
				},
				{
					Value = 200007,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920032,
			Ability = {
				{
					Value = 200002,
					Num = 66,
				},
				{
					Value = 200007,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920032,
			Ability = {
				{
					Value = 200002,
					Num = 99,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920032,
			Ability = {
				{
					Value = 200002,
					Num = 132,
				},
				{
					Value = 200007,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920032,
			Ability = {
				{
					Value = 200002,
					Num = 165,
				},
				{
					Value = 200007,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100003,
					Value = 15,
				},
			},
		},
		{
			Level = 6,
			Info = 920032,
			Ability = {
				{
					Value = 200002,
					Num = 198,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100003,
					Value = 15,
				},
			},
		},
		{
			Level = 7,
			Info = 920032,
			Ability = {
				{
					Value = 200002,
					Num = 231,
				},
				{
					Value = 200007,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100003,
					Value = 15,
				},
			},
		},
		{
			Level = 8,
			Info = 920032,
			Ability = {
				{
					Value = 200002,
					Num = 264,
				},
				{
					Value = 200007,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100003,
					Value = 15,
				},
			},
		},
		{
			Level = 9,
			Info = 920032,
			Ability = {
				{
					Value = 200002,
					Num = 297,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100003,
					Value = 15,
				},
			},
		},
		{
			Level = 10,
			Info = 920032,
			Ability = {
				{
					Value = 200002,
					Num = 330,
				},
				{
					Value = 200007,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100003,
					Value = 15,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id014] =
{
	Character = 220007,
	Rarity = 2,
	NeedChallenge = 145007,
	UpgradeId = 930026,
	LevelList = {
		{
			Level = 1,
			Info = 920033,
			Ability = {
				{
					Value = 200001,
					Num = 45,
				},
				{
					Value = 200006,
					Num = 3,
				},
			},
		},
		{
			Level = 2,
			Info = 920033,
			Ability = {
				{
					Value = 200001,
					Num = 90,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 3,
			Info = 920033,
			Ability = {
				{
					Value = 200001,
					Num = 135,
				},
				{
					Value = 200006,
					Num = 9,
				},
			},
		},
		{
			Level = 4,
			Info = 920033,
			Ability = {
				{
					Value = 200001,
					Num = 180,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 5,
			Info = 920033,
			Ability = {
				{
					Value = 200001,
					Num = 225,
				},
				{
					Value = 200006,
					Num = 15,
				},
			},
			SkillList = {
				{
					Id = 101701,
					Value = 135,
				},
			},
		},
		{
			Level = 6,
			Info = 920033,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
			SkillList = {
				{
					Id = 101701,
					Value = 135,
				},
			},
		},
		{
			Level = 7,
			Info = 920033,
			Ability = {
				{
					Value = 200001,
					Num = 315,
				},
				{
					Value = 200006,
					Num = 21,
				},
			},
			SkillList = {
				{
					Id = 101701,
					Value = 135,
				},
			},
		},
		{
			Level = 8,
			Info = 920033,
			Ability = {
				{
					Value = 200001,
					Num = 360,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
			SkillList = {
				{
					Id = 101701,
					Value = 135,
				},
			},
		},
		{
			Level = 9,
			Info = 920033,
			Ability = {
				{
					Value = 200001,
					Num = 405,
				},
				{
					Value = 200006,
					Num = 27,
				},
			},
			SkillList = {
				{
					Id = 101701,
					Value = 135,
				},
			},
		},
		{
			Level = 10,
			Info = 920033,
			Ability = {
				{
					Value = 200001,
					Num = 450,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 101701,
					Value = 135,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id015] =
{
	Character = 220008,
	Rarity = 2,
	UpgradeId = 930005,
	LevelList = {
		{
			Level = 1,
			Info = 920035,
			Ability = {
				{
					Value = 200002,
					Num = 33,
				},
				{
					Value = 200007,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920035,
			Ability = {
				{
					Value = 200002,
					Num = 66,
				},
				{
					Value = 200007,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920035,
			Ability = {
				{
					Value = 200002,
					Num = 99,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920035,
			Ability = {
				{
					Value = 200002,
					Num = 132,
				},
				{
					Value = 200007,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920035,
			Ability = {
				{
					Value = 200002,
					Num = 165,
				},
				{
					Value = 200007,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920035,
			Ability = {
				{
					Value = 200002,
					Num = 198,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920035,
			Ability = {
				{
					Value = 200002,
					Num = 231,
				},
				{
					Value = 200007,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920035,
			Ability = {
				{
					Value = 200002,
					Num = 264,
				},
				{
					Value = 200007,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920035,
			Ability = {
				{
					Value = 200002,
					Num = 297,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920035,
			Ability = {
				{
					Value = 200002,
					Num = 330,
				},
				{
					Value = 200007,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id016] =
{
	Character = 220008,
	Rarity = 2,
	NeedChallenge = 145008,
	UpgradeId = 930026,
	LevelList = {
		{
			Level = 1,
			Info = 920036,
			Ability = {
				{
					Value = 200001,
					Num = 42,
				},
				{
					Value = 200005,
					Num = 3,
				},
			},
		},
		{
			Level = 2,
			Info = 920036,
			Ability = {
				{
					Value = 200001,
					Num = 84,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 3,
			Info = 920036,
			Ability = {
				{
					Value = 200001,
					Num = 126,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 4,
			Info = 920036,
			Ability = {
				{
					Value = 200001,
					Num = 168,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 5,
			Info = 920036,
			Ability = {
				{
					Value = 200001,
					Num = 210,
				},
				{
					Value = 200005,
					Num = 15,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -50,
				},
			},
		},
		{
			Level = 6,
			Info = 920036,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -50,
				},
			},
		},
		{
			Level = 7,
			Info = 920036,
			Ability = {
				{
					Value = 200001,
					Num = 294,
				},
				{
					Value = 200005,
					Num = 21,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -50,
				},
			},
		},
		{
			Level = 8,
			Info = 920036,
			Ability = {
				{
					Value = 200001,
					Num = 336,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -50,
				},
			},
		},
		{
			Level = 9,
			Info = 920036,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -50,
				},
			},
		},
		{
			Level = 10,
			Info = 920036,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -50,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id017] =
{
	Character = 220009,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920038,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200007,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920038,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920038,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200007,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920038,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920038,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200007,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920038,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920038,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200007,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920038,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200007,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100565,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920038,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200007,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100565,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920038,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200007,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100565,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id018] =
{
	Character = 220009,
	Rarity = 3,
	UpgradeId = 930010,
	LevelList = {
		{
			Level = 1,
			Info = 920039,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
			},
		},
		{
			Level = 2,
			Info = 920039,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
			},
		},
		{
			Level = 3,
			Info = 920039,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
			},
		},
		{
			Level = 4,
			Info = 920039,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
			},
		},
		{
			Level = 5,
			Info = 920039,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
			},
			SkillList = {
				{
					Id = 101525,
					Value = -8,
				},
			},
		},
		{
			Level = 6,
			Info = 920039,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
			SkillList = {
				{
					Id = 101525,
					Value = -8,
				},
			},
		},
		{
			Level = 7,
			Info = 920039,
			Ability = {
				{
					Value = 200002,
					Num = 294,
				},
			},
			SkillList = {
				{
					Id = 101525,
					Value = -8,
				},
			},
		},
		{
			Level = 8,
			Info = 920039,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
			},
			SkillList = {
				{
					Id = 101525,
					Value = -8,
				},
				{
					Id = 100554,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920039,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
			},
			SkillList = {
				{
					Id = 101525,
					Value = -8,
				},
				{
					Id = 100554,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920039,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
			},
			SkillList = {
				{
					Id = 101525,
					Value = -8,
				},
				{
					Id = 100554,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id019] =
{
	Character = 220009,
	Rarity = 3,
	NeedChallenge = 145009,
	UpgradeId = 930031,
	LevelList = {
		{
			Level = 1,
			Info = 920040,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
			},
		},
		{
			Level = 2,
			Info = 920040,
			Ability = {
				{
					Value = 200001,
					Num = 180,
				},
			},
		},
		{
			Level = 3,
			Info = 920040,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
			},
		},
		{
			Level = 4,
			Info = 920040,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
			},
		},
		{
			Level = 5,
			Info = 920040,
			Ability = {
				{
					Value = 200001,
					Num = 396,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920040,
			Ability = {
				{
					Value = 200001,
					Num = 468,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920040,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920040,
			Ability = {
				{
					Value = 200001,
					Num = 612,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100784,
					Value = 100,
				},
			},
		},
		{
			Level = 9,
			Info = 920040,
			Ability = {
				{
					Value = 200001,
					Num = 684,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100784,
					Value = 100,
				},
			},
		},
		{
			Level = 10,
			Info = 920040,
			Ability = {
				{
					Value = 200001,
					Num = 756,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100784,
					Value = 100,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id020] =
{
	Character = 220010,
	Rarity = 3,
	UpgradeId = 930009,
	LevelList = {
		{
			Level = 1,
			Info = 920041,
			Ability = {
				{
					Value = 200002,
					Num = 54,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920041,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920041,
			Ability = {
				{
					Value = 200002,
					Num = 162,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920041,
			Ability = {
				{
					Value = 200002,
					Num = 216,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920041,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
				{
					Value = 200008,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920041,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920041,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200008,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920041,
			Ability = {
				{
					Value = 200002,
					Num = 432,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920041,
			Ability = {
				{
					Value = 200002,
					Num = 486,
				},
				{
					Value = 200008,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920041,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200008,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id021] =
{
	Character = 220010,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920042,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920042,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920042,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920042,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920042,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 101731,
					Value = 504,
				},
			},
		},
		{
			Level = 6,
			Info = 920042,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 101731,
					Value = 504,
				},
			},
		},
		{
			Level = 7,
			Info = 920042,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200005,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 101731,
					Value = 504,
				},
			},
		},
		{
			Level = 8,
			Info = 920042,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 101731,
					Value = 504,
				},
			},
		},
		{
			Level = 9,
			Info = 920042,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 101731,
					Value = 504,
				},
			},
		},
		{
			Level = 10,
			Info = 920042,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 101731,
					Value = 504,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id022] =
{
	Character = 220010,
	Rarity = 3,
	NeedChallenge = 145010,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920043,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
			},
		},
		{
			Level = 2,
			Info = 920043,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
			},
		},
		{
			Level = 3,
			Info = 920043,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
		},
		{
			Level = 4,
			Info = 920043,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
			},
		},
		{
			Level = 5,
			Info = 920043,
			Ability = {
				{
					Value = 200002,
					Num = 396,
				},
			},
		},
		{
			Level = 6,
			Info = 920043,
			Ability = {
				{
					Value = 200002,
					Num = 468,
				},
			},
		},
		{
			Level = 7,
			Info = 920043,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
			},
		},
		{
			Level = 8,
			Info = 920043,
			Ability = {
				{
					Value = 200002,
					Num = 612,
				},
			},
			SkillList = {
				{
					Id = 101734,
					Value = 22,
				},
			},
		},
		{
			Level = 9,
			Info = 920043,
			Ability = {
				{
					Value = 200002,
					Num = 684,
				},
			},
			SkillList = {
				{
					Id = 101734,
					Value = 22,
				},
			},
		},
		{
			Level = 10,
			Info = 920043,
			Ability = {
				{
					Value = 200002,
					Num = 756,
				},
			},
			SkillList = {
				{
					Id = 101734,
					Value = 22,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id023] =
{
	Character = 220011,
	Rarity = 1,
	UpgradeId = 930021,
	LevelList = {
		{
			Level = 1,
			Info = 920044,
			Ability = {
				{
					Value = 200001,
					Num = 27,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920044,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920044,
			Ability = {
				{
					Value = 200001,
					Num = 81,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920044,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920044,
			Ability = {
				{
					Value = 200001,
					Num = 135,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920044,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920044,
			Ability = {
				{
					Value = 200001,
					Num = 189,
				},
				{
					Value = 200005,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920044,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920044,
			Ability = {
				{
					Value = 200001,
					Num = 243,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920044,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id024] =
{
	Character = 220011,
	Rarity = 1,
	NeedChallenge = 145011,
	UpgradeId = 930022,
	LevelList = {
		{
			Level = 1,
			Info = 920045,
			Ability = {
				{
					Value = 200001,
					Num = 27,
				},
				{
					Value = 200006,
					Num = 3,
				},
			},
		},
		{
			Level = 2,
			Info = 920045,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 3,
			Info = 920045,
			Ability = {
				{
					Value = 200001,
					Num = 81,
				},
				{
					Value = 200006,
					Num = 9,
				},
			},
		},
		{
			Level = 4,
			Info = 920045,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 5,
			Info = 920045,
			Ability = {
				{
					Value = 200001,
					Num = 135,
				},
				{
					Value = 200006,
					Num = 15,
				},
			},
			SkillList = {
				{
					Id = 101901,
					Value = 8,
				},
			},
		},
		{
			Level = 6,
			Info = 920045,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
			SkillList = {
				{
					Id = 101901,
					Value = 8,
				},
			},
		},
		{
			Level = 7,
			Info = 920045,
			Ability = {
				{
					Value = 200001,
					Num = 189,
				},
				{
					Value = 200006,
					Num = 21,
				},
			},
			SkillList = {
				{
					Id = 101901,
					Value = 8,
				},
			},
		},
		{
			Level = 8,
			Info = 920045,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
			SkillList = {
				{
					Id = 101901,
					Value = 8,
				},
			},
		},
		{
			Level = 9,
			Info = 920045,
			Ability = {
				{
					Value = 200001,
					Num = 243,
				},
				{
					Value = 200006,
					Num = 27,
				},
			},
			SkillList = {
				{
					Id = 101901,
					Value = 8,
				},
			},
		},
		{
			Level = 10,
			Info = 920045,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 101901,
					Value = 8,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id025] =
{
	Character = 220012,
	Rarity = 1,
	UpgradeId = 930021,
	LevelList = {
		{
			Level = 1,
			Info = 920046,
			Ability = {
				{
					Value = 200001,
					Num = 27,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920046,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920046,
			Ability = {
				{
					Value = 200001,
					Num = 81,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920046,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920046,
			Ability = {
				{
					Value = 200001,
					Num = 135,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920046,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920046,
			Ability = {
				{
					Value = 200001,
					Num = 189,
				},
				{
					Value = 200005,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920046,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920046,
			Ability = {
				{
					Value = 200001,
					Num = 243,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920046,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id026] =
{
	Character = 220012,
	Rarity = 1,
	NeedChallenge = 145012,
	UpgradeId = 930022,
	LevelList = {
		{
			Level = 1,
			Info = 920047,
			Ability = {
				{
					Value = 200001,
					Num = 27,
				},
				{
					Value = 200006,
					Num = 3,
				},
			},
		},
		{
			Level = 2,
			Info = 920047,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 3,
			Info = 920047,
			Ability = {
				{
					Value = 200001,
					Num = 81,
				},
				{
					Value = 200006,
					Num = 9,
				},
			},
		},
		{
			Level = 4,
			Info = 920047,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 5,
			Info = 920047,
			Ability = {
				{
					Value = 200001,
					Num = 135,
				},
				{
					Value = 200006,
					Num = 15,
				},
			},
		},
		{
			Level = 6,
			Info = 920047,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 7,
			Info = 920047,
			Ability = {
				{
					Value = 200001,
					Num = 189,
				},
				{
					Value = 200006,
					Num = 21,
				},
			},
		},
		{
			Level = 8,
			Info = 920047,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
			SkillList = {
				{
					Id = 100201,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920047,
			Ability = {
				{
					Value = 200001,
					Num = 243,
				},
				{
					Value = 200006,
					Num = 27,
				},
			},
			SkillList = {
				{
					Id = 100201,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920047,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100201,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id027] =
{
	Character = 220013,
	Rarity = 1,
	UpgradeId = 930001,
	LevelList = {
		{
			Level = 1,
			Info = 920048,
			Ability = {
				{
					Value = 200002,
					Num = 21,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920048,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920048,
			Ability = {
				{
					Value = 200002,
					Num = 63,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920048,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920048,
			Ability = {
				{
					Value = 200002,
					Num = 105,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920048,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920048,
			Ability = {
				{
					Value = 200002,
					Num = 147,
				},
				{
					Value = 200006,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920048,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920048,
			Ability = {
				{
					Value = 200002,
					Num = 189,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920048,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id028] =
{
	Character = 220013,
	Rarity = 1,
	NeedChallenge = 145013,
	UpgradeId = 930002,
	LevelList = {
		{
			Level = 1,
			Info = 920049,
			Ability = {
				{
					Value = 200002,
					Num = 21,
				},
				{
					Value = 200005,
					Num = 3,
				},
			},
		},
		{
			Level = 2,
			Info = 920049,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 3,
			Info = 920049,
			Ability = {
				{
					Value = 200002,
					Num = 63,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 4,
			Info = 920049,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 5,
			Info = 920049,
			Ability = {
				{
					Value = 200002,
					Num = 105,
				},
				{
					Value = 200005,
					Num = 15,
				},
			},
		},
		{
			Level = 6,
			Info = 920049,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 7,
			Info = 920049,
			Ability = {
				{
					Value = 200002,
					Num = 147,
				},
				{
					Value = 200005,
					Num = 21,
				},
			},
		},
		{
			Level = 8,
			Info = 920049,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
			SkillList = {
				{
					Id = 100221,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920049,
			Ability = {
				{
					Value = 200002,
					Num = 189,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
			SkillList = {
				{
					Id = 100221,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920049,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100221,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id029] =
{
	Character = 220014,
	Rarity = 2,
	UpgradeId = 930025,
	LevelList = {
		{
			Level = 1,
			Info = 920030,
			Ability = {
				{
					Value = 200001,
					Num = 42,
				},
				{
					Value = 200007,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920030,
			Ability = {
				{
					Value = 200001,
					Num = 84,
				},
				{
					Value = 200007,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920030,
			Ability = {
				{
					Value = 200001,
					Num = 126,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920030,
			Ability = {
				{
					Value = 200001,
					Num = 168,
				},
				{
					Value = 200007,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920030,
			Ability = {
				{
					Value = 200001,
					Num = 210,
				},
				{
					Value = 200007,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -15,
				},
			},
		},
		{
			Level = 6,
			Info = 920030,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -15,
				},
			},
		},
		{
			Level = 7,
			Info = 920030,
			Ability = {
				{
					Value = 200001,
					Num = 294,
				},
				{
					Value = 200007,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -15,
				},
			},
		},
		{
			Level = 8,
			Info = 920030,
			Ability = {
				{
					Value = 200001,
					Num = 336,
				},
				{
					Value = 200007,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -15,
				},
			},
		},
		{
			Level = 9,
			Info = 920030,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -15,
				},
			},
		},
		{
			Level = 10,
			Info = 920030,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
				{
					Value = 200007,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -15,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id030] =
{
	Character = 220014,
	Rarity = 2,
	NeedChallenge = 145014,
	UpgradeId = 930026,
	LevelList = {
		{
			Level = 1,
			Info = 920031,
			Ability = {
				{
					Value = 200001,
					Num = 42,
				},
				{
					Value = 200006,
					Num = 3,
				},
			},
		},
		{
			Level = 2,
			Info = 920031,
			Ability = {
				{
					Value = 200001,
					Num = 84,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 3,
			Info = 920031,
			Ability = {
				{
					Value = 200001,
					Num = 126,
				},
				{
					Value = 200006,
					Num = 9,
				},
			},
		},
		{
			Level = 4,
			Info = 920031,
			Ability = {
				{
					Value = 200001,
					Num = 168,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 5,
			Info = 920031,
			Ability = {
				{
					Value = 200001,
					Num = 210,
				},
				{
					Value = 200006,
					Num = 15,
				},
			},
		},
		{
			Level = 6,
			Info = 920031,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 7,
			Info = 920031,
			Ability = {
				{
					Value = 200001,
					Num = 294,
				},
				{
					Value = 200006,
					Num = 21,
				},
			},
		},
		{
			Level = 8,
			Info = 920031,
			Ability = {
				{
					Value = 200001,
					Num = 336,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920031,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200006,
					Num = 27,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920031,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
	},
}
require "FreakPlanet/Design/EquipmentConfig_1"
require "FreakPlanet/Design/EquipmentConfig_2"
require "FreakPlanet/Design/EquipmentConfig_3"
require "FreakPlanet/Design/EquipmentConfig_4"
require "FreakPlanet/Design/EquipmentConfig_5"
require "FreakPlanet/Design/EquipmentConfig_6"
require "FreakPlanet/Design/EquipmentConfig_7"
require "FreakPlanet/Design/EquipmentConfig_8"
require "FreakPlanet/Design/EquipmentConfig_9"
require "FreakPlanet/Design/EquipmentConfig_10"
require "FreakPlanet/Design/EquipmentConfig_11"
require "FreakPlanet/Design/EquipmentConfig_12"
require "FreakPlanet/Design/EquipmentConfig_13"
require "FreakPlanet/Design/EquipmentConfig_14"
require "FreakPlanet/Design/EquipmentConfig_15"
require "FreakPlanet/Design/EquipmentConfig_16"
require "FreakPlanet/Design/EquipmentConfig_17"
require "FreakPlanet/Design/EquipmentConfig_18"
require "FreakPlanet/Design/EquipmentConfig_19"
require "FreakPlanet/Design/EquipmentConfig_20"
require "FreakPlanet/Design/EquipmentConfig_21"
require "FreakPlanet/Design/EquipmentConfig_22"
require "FreakPlanet/Design/EquipmentConfig_23"
require "FreakPlanet/Design/EquipmentConfig_24"

