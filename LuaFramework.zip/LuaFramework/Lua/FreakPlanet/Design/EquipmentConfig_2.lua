
EquipmentConfig[EquipmentID.Id061] =
{
	Character = 220026,
	Rarity = 4,
	UpgradeId = 930034,
	LevelList = {
		{
			Level = 1,
			Info = 920084,
			Ability = {
				{
					Value = 200001,
					Num = 75,
				},
				{
					Value = 200007,
					Num = 21,
				},
			},
		},
		{
			Level = 2,
			Info = 920084,
			Ability = {
				{
					Value = 200001,
					Num = 150,
				},
				{
					Value = 200007,
					Num = 42,
				},
			},
		},
		{
			Level = 3,
			Info = 920084,
			Ability = {
				{
					Value = 200001,
					Num = 225,
				},
				{
					Value = 200007,
					Num = 63,
				},
			},
		},
		{
			Level = 4,
			Info = 920084,
			Ability = {
				{
					Value = 200001,
					Num = 300,
				},
				{
					Value = 200007,
					Num = 84,
				},
			},
		},
		{
			Level = 5,
			Info = 920084,
			Ability = {
				{
					Value = 200001,
					Num = 375,
				},
				{
					Value = 200007,
					Num = 105,
				},
			},
		},
		{
			Level = 6,
			Info = 920084,
			Ability = {
				{
					Value = 200001,
					Num = 450,
				},
				{
					Value = 200007,
					Num = 126,
				},
			},
		},
		{
			Level = 7,
			Info = 920084,
			Ability = {
				{
					Value = 200001,
					Num = 525,
				},
				{
					Value = 200007,
					Num = 147,
				},
			},
		},
		{
			Level = 8,
			Info = 920084,
			Ability = {
				{
					Value = 200001,
					Num = 600,
				},
				{
					Value = 200007,
					Num = 168,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
		{
			Level = 9,
			Info = 920084,
			Ability = {
				{
					Value = 200001,
					Num = 675,
				},
				{
					Value = 200007,
					Num = 189,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
		{
			Level = 10,
			Info = 920084,
			Ability = {
				{
					Value = 200001,
					Num = 750,
				},
				{
					Value = 200007,
					Num = 210,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id062] =
{
	Character = 220026,
	Rarity = 4,
	NeedChallenge = 145026,
	UpgradeId = 930035,
	LevelList = {
		{
			Level = 1,
			Info = 920085,
			Ability = {
				{
					Value = 200001,
					Num = 150,
				},
			},
		},
		{
			Level = 2,
			Info = 920085,
			Ability = {
				{
					Value = 200001,
					Num = 250,
				},
			},
		},
		{
			Level = 3,
			Info = 920085,
			Ability = {
				{
					Value = 200001,
					Num = 350,
				},
			},
		},
		{
			Level = 4,
			Info = 920085,
			Ability = {
				{
					Value = 200001,
					Num = 450,
				},
			},
		},
		{
			Level = 5,
			Info = 920085,
			Ability = {
				{
					Value = 200001,
					Num = 550,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920085,
			Ability = {
				{
					Value = 200001,
					Num = 650,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920085,
			Ability = {
				{
					Value = 200001,
					Num = 750,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920085,
			Ability = {
				{
					Value = 200001,
					Num = 850,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100778,
					Value = 125,
				},
			},
		},
		{
			Level = 9,
			Info = 920085,
			Ability = {
				{
					Value = 200001,
					Num = 950,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100778,
					Value = 125,
				},
			},
		},
		{
			Level = 10,
			Info = 920085,
			Ability = {
				{
					Value = 200001,
					Num = 1050,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100778,
					Value = 125,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id063] =
{
	Character = 220027,
	Rarity = 4,
	UpgradeId = 930013,
	LevelList = {
		{
			Level = 1,
			Info = 920087,
			Ability = {
				{
					Value = 200002,
					Num = 54,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920087,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920087,
			Ability = {
				{
					Value = 200002,
					Num = 162,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920087,
			Ability = {
				{
					Value = 200002,
					Num = 216,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920087,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920087,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920087,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200005,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920087,
			Ability = {
				{
					Value = 200002,
					Num = 432,
				},
				{
					Value = 200005,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100554,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920087,
			Ability = {
				{
					Value = 200002,
					Num = 486,
				},
				{
					Value = 200005,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100554,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920087,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200005,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100554,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id064] =
{
	Character = 220027,
	Rarity = 4,
	UpgradeId = 930034,
	LevelList = {
		{
			Level = 1,
			Info = 920088,
			Ability = {
				{
					Value = 200001,
					Num = 75,
				},
				{
					Value = 200007,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920088,
			Ability = {
				{
					Value = 200001,
					Num = 150,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920088,
			Ability = {
				{
					Value = 200001,
					Num = 225,
				},
				{
					Value = 200007,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920088,
			Ability = {
				{
					Value = 200001,
					Num = 300,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920088,
			Ability = {
				{
					Value = 200001,
					Num = 375,
				},
				{
					Value = 200007,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920088,
			Ability = {
				{
					Value = 200001,
					Num = 450,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920088,
			Ability = {
				{
					Value = 200001,
					Num = 525,
				},
				{
					Value = 200007,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920088,
			Ability = {
				{
					Value = 200001,
					Num = 600,
				},
				{
					Value = 200007,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100565,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920088,
			Ability = {
				{
					Value = 200001,
					Num = 675,
				},
				{
					Value = 200007,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100565,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920088,
			Ability = {
				{
					Value = 200001,
					Num = 750,
				},
				{
					Value = 200007,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100565,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id065] =
{
	Character = 220027,
	Rarity = 4,
	NeedChallenge = 145027,
	UpgradeId = 930035,
	LevelList = {
		{
			Level = 1,
			Info = 920089,
			Ability = {
				{
					Value = 200001,
					Num = 150,
				},
			},
		},
		{
			Level = 2,
			Info = 920089,
			Ability = {
				{
					Value = 200001,
					Num = 250,
				},
			},
		},
		{
			Level = 3,
			Info = 920089,
			Ability = {
				{
					Value = 200001,
					Num = 350,
				},
			},
		},
		{
			Level = 4,
			Info = 920089,
			Ability = {
				{
					Value = 200001,
					Num = 450,
				},
			},
		},
		{
			Level = 5,
			Info = 920089,
			Ability = {
				{
					Value = 200001,
					Num = 550,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
			SkillList = {
				{
					Id = 101705,
					Value = 22,
				},
			},
		},
		{
			Level = 6,
			Info = 920089,
			Ability = {
				{
					Value = 200001,
					Num = 650,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 101705,
					Value = 22,
				},
			},
		},
		{
			Level = 7,
			Info = 920089,
			Ability = {
				{
					Value = 200001,
					Num = 750,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
			SkillList = {
				{
					Id = 101705,
					Value = 22,
				},
			},
		},
		{
			Level = 8,
			Info = 920089,
			Ability = {
				{
					Value = 200001,
					Num = 850,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101705,
					Value = 22,
				},
			},
		},
		{
			Level = 9,
			Info = 920089,
			Ability = {
				{
					Value = 200001,
					Num = 950,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101705,
					Value = 22,
				},
			},
		},
		{
			Level = 10,
			Info = 920089,
			Ability = {
				{
					Value = 200001,
					Num = 1050,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101705,
					Value = 22,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id066] =
{
	Character = 220028,
	Rarity = 4,
	UpgradeId = 930033,
	LevelList = {
		{
			Level = 1,
			Info = 920094,
			Ability = {
				{
					Value = 200001,
					Num = 69,
				},
				{
					Value = 200006,
					Num = 21,
				},
			},
		},
		{
			Level = 2,
			Info = 920094,
			Ability = {
				{
					Value = 200001,
					Num = 138,
				},
				{
					Value = 200006,
					Num = 42,
				},
			},
		},
		{
			Level = 3,
			Info = 920094,
			Ability = {
				{
					Value = 200001,
					Num = 207,
				},
				{
					Value = 200006,
					Num = 63,
				},
			},
		},
		{
			Level = 4,
			Info = 920094,
			Ability = {
				{
					Value = 200001,
					Num = 276,
				},
				{
					Value = 200006,
					Num = 84,
				},
			},
		},
		{
			Level = 5,
			Info = 920094,
			Ability = {
				{
					Value = 200001,
					Num = 345,
				},
				{
					Value = 200006,
					Num = 105,
				},
			},
		},
		{
			Level = 6,
			Info = 920094,
			Ability = {
				{
					Value = 200001,
					Num = 414,
				},
				{
					Value = 200006,
					Num = 126,
				},
			},
		},
		{
			Level = 7,
			Info = 920094,
			Ability = {
				{
					Value = 200001,
					Num = 483,
				},
				{
					Value = 200006,
					Num = 147,
				},
			},
		},
		{
			Level = 8,
			Info = 920094,
			Ability = {
				{
					Value = 200001,
					Num = 552,
				},
				{
					Value = 200006,
					Num = 168,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920094,
			Ability = {
				{
					Value = 200001,
					Num = 621,
				},
				{
					Value = 200006,
					Num = 189,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920094,
			Ability = {
				{
					Value = 200001,
					Num = 690,
				},
				{
					Value = 200006,
					Num = 210,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id067] =
{
	Character = 220028,
	Rarity = 4,
	UpgradeId = 930014,
	LevelList = {
		{
			Level = 1,
			Info = 920092,
			Ability = {
				{
					Value = 200002,
					Num = 57,
				},
				{
					Value = 200006,
					Num = 21,
				},
			},
		},
		{
			Level = 2,
			Info = 920092,
			Ability = {
				{
					Value = 200002,
					Num = 114,
				},
				{
					Value = 200006,
					Num = 42,
				},
			},
		},
		{
			Level = 3,
			Info = 920092,
			Ability = {
				{
					Value = 200002,
					Num = 171,
				},
				{
					Value = 200006,
					Num = 63,
				},
			},
		},
		{
			Level = 4,
			Info = 920092,
			Ability = {
				{
					Value = 200002,
					Num = 228,
				},
				{
					Value = 200006,
					Num = 84,
				},
			},
		},
		{
			Level = 5,
			Info = 920092,
			Ability = {
				{
					Value = 200002,
					Num = 285,
				},
				{
					Value = 200006,
					Num = 105,
				},
			},
		},
		{
			Level = 6,
			Info = 920092,
			Ability = {
				{
					Value = 200002,
					Num = 342,
				},
				{
					Value = 200006,
					Num = 126,
				},
			},
		},
		{
			Level = 7,
			Info = 920092,
			Ability = {
				{
					Value = 200002,
					Num = 399,
				},
				{
					Value = 200006,
					Num = 147,
				},
			},
		},
		{
			Level = 8,
			Info = 920092,
			Ability = {
				{
					Value = 200002,
					Num = 456,
				},
				{
					Value = 200006,
					Num = 168,
				},
			},
			SkillList = {
				{
					Id = 101738,
					Value = 15,
				},
			},
		},
		{
			Level = 9,
			Info = 920092,
			Ability = {
				{
					Value = 200002,
					Num = 513,
				},
				{
					Value = 200006,
					Num = 189,
				},
			},
			SkillList = {
				{
					Id = 101738,
					Value = 15,
				},
			},
		},
		{
			Level = 10,
			Info = 920092,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200006,
					Num = 210,
				},
			},
			SkillList = {
				{
					Id = 101738,
					Value = 15,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id068] =
{
	Character = 220028,
	Rarity = 4,
	NeedChallenge = 145028,
	UpgradeId = 930015,
	LevelList = {
		{
			Level = 1,
			Info = 920093,
			Ability = {
				{
					Value = 200002,
					Num = 114,
				},
			},
		},
		{
			Level = 2,
			Info = 920093,
			Ability = {
				{
					Value = 200002,
					Num = 190,
				},
			},
		},
		{
			Level = 3,
			Info = 920093,
			Ability = {
				{
					Value = 200002,
					Num = 266,
				},
			},
		},
		{
			Level = 4,
			Info = 920093,
			Ability = {
				{
					Value = 200002,
					Num = 342,
				},
			},
		},
		{
			Level = 5,
			Info = 920093,
			Ability = {
				{
					Value = 200002,
					Num = 418,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920093,
			Ability = {
				{
					Value = 200002,
					Num = 494,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920093,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920093,
			Ability = {
				{
					Value = 200002,
					Num = 646,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100407,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920093,
			Ability = {
				{
					Value = 200002,
					Num = 722,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100407,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920093,
			Ability = {
				{
					Value = 200002,
					Num = 798,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100407,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id069] =
{
	Character = 220029,
	Rarity = 5,
	UpgradeId = 930037,
	LevelList = {
		{
			Level = 1,
			Info = 920095,
			Ability = {
				{
					Value = 200001,
					Num = 87,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920095,
			Ability = {
				{
					Value = 200001,
					Num = 174,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920095,
			Ability = {
				{
					Value = 200001,
					Num = 261,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920095,
			Ability = {
				{
					Value = 200001,
					Num = 348,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920095,
			Ability = {
				{
					Value = 200001,
					Num = 435,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920095,
			Ability = {
				{
					Value = 200001,
					Num = 522,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920095,
			Ability = {
				{
					Value = 200001,
					Num = 609,
				},
				{
					Value = 200008,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920095,
			Ability = {
				{
					Value = 200001,
					Num = 696,
				},
				{
					Value = 200008,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920095,
			Ability = {
				{
					Value = 200001,
					Num = 783,
				},
				{
					Value = 200008,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920095,
			Ability = {
				{
					Value = 200001,
					Num = 870,
				},
				{
					Value = 200008,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id070] =
{
	Character = 220029,
	Rarity = 5,
	UpgradeId = 930018,
	LevelList = {
		{
			Level = 1,
			Info = 920096,
			Ability = {
				{
					Value = 200002,
					Num = 63,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920096,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920096,
			Ability = {
				{
					Value = 200002,
					Num = 189,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920096,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920096,
			Ability = {
				{
					Value = 200002,
					Num = 315,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920096,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920096,
			Ability = {
				{
					Value = 200002,
					Num = 441,
				},
				{
					Value = 200008,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920096,
			Ability = {
				{
					Value = 200002,
					Num = 504,
				},
				{
					Value = 200008,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 101761,
					Value = 75,
				},
			},
		},
		{
			Level = 9,
			Info = 920096,
			Ability = {
				{
					Value = 200002,
					Num = 567,
				},
				{
					Value = 200008,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 101761,
					Value = 75,
				},
			},
		},
		{
			Level = 10,
			Info = 920096,
			Ability = {
				{
					Value = 200002,
					Num = 630,
				},
				{
					Value = 200008,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 101761,
					Value = 75,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id071] =
{
	Character = 220029,
	Rarity = 5,
	NeedChallenge = 145029,
	UpgradeId = 930039,
	LevelList = {
		{
			Level = 1,
			Info = 920097,
			Ability = {
				{
					Value = 200001,
					Num = 174,
				},
			},
		},
		{
			Level = 2,
			Info = 920097,
			Ability = {
				{
					Value = 200001,
					Num = 290,
				},
			},
		},
		{
			Level = 3,
			Info = 920097,
			Ability = {
				{
					Value = 200001,
					Num = 406,
				},
			},
		},
		{
			Level = 4,
			Info = 920097,
			Ability = {
				{
					Value = 200001,
					Num = 522,
				},
			},
		},
		{
			Level = 5,
			Info = 920097,
			Ability = {
				{
					Value = 200001,
					Num = 638,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920097,
			Ability = {
				{
					Value = 200001,
					Num = 754,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920097,
			Ability = {
				{
					Value = 200001,
					Num = 870,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920097,
			Ability = {
				{
					Value = 200001,
					Num = 986,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101504,
					Value = -22,
				},
			},
		},
		{
			Level = 9,
			Info = 920097,
			Ability = {
				{
					Value = 200001,
					Num = 1102,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101504,
					Value = -22,
				},
			},
		},
		{
			Level = 10,
			Info = 920097,
			Ability = {
				{
					Value = 200001,
					Num = 1218,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101504,
					Value = -22,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id072] =
{
	Character = 220029,
	Rarity = 5,
	NeedChallenge = 145030,
	UpgradeId = 930020,
	LevelList = {
		{
			Level = 1,
			Info = 920098,
			Ability = {
				{
					Value = 200002,
					Num = 189,
				},
			},
		},
		{
			Level = 2,
			Info = 920098,
			Ability = {
				{
					Value = 200002,
					Num = 294,
				},
			},
		},
		{
			Level = 3,
			Info = 920098,
			Ability = {
				{
					Value = 200002,
					Num = 399,
				},
			},
		},
		{
			Level = 4,
			Info = 920098,
			Ability = {
				{
					Value = 200002,
					Num = 504,
				},
			},
		},
		{
			Level = 5,
			Info = 920098,
			Ability = {
				{
					Value = 200002,
					Num = 609,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920098,
			Ability = {
				{
					Value = 200002,
					Num = 714,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920098,
			Ability = {
				{
					Value = 200002,
					Num = 819,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920098,
			Ability = {
				{
					Value = 200002,
					Num = 924,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101503,
					Value = -22,
				},
			},
		},
		{
			Level = 9,
			Info = 920098,
			Ability = {
				{
					Value = 200002,
					Num = 1029,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101503,
					Value = -22,
				},
			},
		},
		{
			Level = 10,
			Info = 920098,
			Ability = {
				{
					Value = 200002,
					Num = 1134,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101503,
					Value = -22,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id073] =
{
	Character = 220101,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920100,
			Ability = {
				{
					Value = 200001,
					Num = 57,
				},
				{
					Value = 200007,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920100,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920100,
			Ability = {
				{
					Value = 200001,
					Num = 171,
				},
				{
					Value = 200007,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920100,
			Ability = {
				{
					Value = 200001,
					Num = 228,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920100,
			Ability = {
				{
					Value = 200001,
					Num = 285,
				},
				{
					Value = 200007,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920100,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920100,
			Ability = {
				{
					Value = 200001,
					Num = 399,
				},
				{
					Value = 200007,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920100,
			Ability = {
				{
					Value = 200001,
					Num = 456,
				},
				{
					Value = 200007,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920100,
			Ability = {
				{
					Value = 200001,
					Num = 513,
				},
				{
					Value = 200007,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920100,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200007,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id074] =
{
	Character = 220101,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920101,
			Ability = {
				{
					Value = 200001,
					Num = 57,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920101,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920101,
			Ability = {
				{
					Value = 200001,
					Num = 171,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920101,
			Ability = {
				{
					Value = 200001,
					Num = 228,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920101,
			Ability = {
				{
					Value = 200001,
					Num = 285,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920101,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920101,
			Ability = {
				{
					Value = 200001,
					Num = 399,
				},
				{
					Value = 200006,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920101,
			Ability = {
				{
					Value = 200001,
					Num = 456,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920101,
			Ability = {
				{
					Value = 200001,
					Num = 513,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920101,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id075] =
{
	Character = 220101,
	Rarity = 3,
	NeedChallenge = 145031,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920099,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
			},
		},
		{
			Level = 2,
			Info = 920099,
			Ability = {
				{
					Value = 200002,
					Num = 140,
				},
			},
		},
		{
			Level = 3,
			Info = 920099,
			Ability = {
				{
					Value = 200002,
					Num = 196,
				},
			},
		},
		{
			Level = 4,
			Info = 920099,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
		},
		{
			Level = 5,
			Info = 920099,
			Ability = {
				{
					Value = 200002,
					Num = 308,
				},
			},
			SkillList = {
				{
					Id = 100777,
					Value = 3,
				},
			},
		},
		{
			Level = 6,
			Info = 920099,
			Ability = {
				{
					Value = 200002,
					Num = 364,
				},
			},
			SkillList = {
				{
					Id = 100777,
					Value = 3,
				},
			},
		},
		{
			Level = 7,
			Info = 920099,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
			},
			SkillList = {
				{
					Id = 100777,
					Value = 3,
				},
			},
		},
		{
			Level = 8,
			Info = 920099,
			Ability = {
				{
					Value = 200002,
					Num = 476,
				},
			},
			SkillList = {
				{
					Id = 100777,
					Value = 3,
				},
				{
					Id = 100771,
					Value = 2,
				},
			},
		},
		{
			Level = 9,
			Info = 920099,
			Ability = {
				{
					Value = 200002,
					Num = 532,
				},
			},
			SkillList = {
				{
					Id = 100777,
					Value = 3,
				},
				{
					Id = 100771,
					Value = 2,
				},
			},
		},
		{
			Level = 10,
			Info = 920099,
			Ability = {
				{
					Value = 200002,
					Num = 588,
				},
			},
			SkillList = {
				{
					Id = 100777,
					Value = 3,
				},
				{
					Id = 100771,
					Value = 2,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id076] =
{
	Character = 220102,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920103,
			Ability = {
				{
					Value = 200001,
					Num = 57,
				},
				{
					Value = 200006,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920103,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920103,
			Ability = {
				{
					Value = 200001,
					Num = 171,
				},
				{
					Value = 200006,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920103,
			Ability = {
				{
					Value = 200001,
					Num = 228,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920103,
			Ability = {
				{
					Value = 200001,
					Num = 285,
				},
				{
					Value = 200006,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920103,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920103,
			Ability = {
				{
					Value = 200001,
					Num = 399,
				},
				{
					Value = 200006,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920103,
			Ability = {
				{
					Value = 200001,
					Num = 456,
				},
				{
					Value = 200006,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920103,
			Ability = {
				{
					Value = 200001,
					Num = 513,
				},
				{
					Value = 200006,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920103,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200006,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id077] =
{
	Character = 220102,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920104,
			Ability = {
				{
					Value = 200001,
					Num = 57,
				},
				{
					Value = 200007,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920104,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
				{
					Value = 200007,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920104,
			Ability = {
				{
					Value = 200001,
					Num = 171,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920104,
			Ability = {
				{
					Value = 200001,
					Num = 228,
				},
				{
					Value = 200007,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920104,
			Ability = {
				{
					Value = 200001,
					Num = 285,
				},
				{
					Value = 200007,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920104,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920104,
			Ability = {
				{
					Value = 200001,
					Num = 399,
				},
				{
					Value = 200007,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920104,
			Ability = {
				{
					Value = 200001,
					Num = 456,
				},
				{
					Value = 200007,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920104,
			Ability = {
				{
					Value = 200001,
					Num = 513,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920104,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200007,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id078] =
{
	Character = 220102,
	Rarity = 3,
	NeedChallenge = 145032,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920102,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
			},
		},
		{
			Level = 2,
			Info = 920102,
			Ability = {
				{
					Value = 200002,
					Num = 140,
				},
			},
		},
		{
			Level = 3,
			Info = 920102,
			Ability = {
				{
					Value = 200002,
					Num = 196,
				},
			},
		},
		{
			Level = 4,
			Info = 920102,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
		},
		{
			Level = 5,
			Info = 920102,
			Ability = {
				{
					Value = 200002,
					Num = 308,
				},
			},
			SkillList = {
				{
					Id = 100776,
					Value = 3,
				},
			},
		},
		{
			Level = 6,
			Info = 920102,
			Ability = {
				{
					Value = 200002,
					Num = 364,
				},
			},
			SkillList = {
				{
					Id = 100776,
					Value = 3,
				},
			},
		},
		{
			Level = 7,
			Info = 920102,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
			},
			SkillList = {
				{
					Id = 100776,
					Value = 3,
				},
			},
		},
		{
			Level = 8,
			Info = 920102,
			Ability = {
				{
					Value = 200002,
					Num = 476,
				},
			},
			SkillList = {
				{
					Id = 100776,
					Value = 3,
				},
				{
					Id = 100774,
					Value = 13,
				},
			},
		},
		{
			Level = 9,
			Info = 920102,
			Ability = {
				{
					Value = 200002,
					Num = 532,
				},
			},
			SkillList = {
				{
					Id = 100776,
					Value = 3,
				},
				{
					Id = 100774,
					Value = 13,
				},
			},
		},
		{
			Level = 10,
			Info = 920102,
			Ability = {
				{
					Value = 200002,
					Num = 588,
				},
			},
			SkillList = {
				{
					Id = 100776,
					Value = 3,
				},
				{
					Id = 100774,
					Value = 13,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id079] =
{
	Character = 220103,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920106,
			Ability = {
				{
					Value = 200001,
					Num = 57,
				},
				{
					Value = 200006,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920106,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920106,
			Ability = {
				{
					Value = 200001,
					Num = 171,
				},
				{
					Value = 200006,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920106,
			Ability = {
				{
					Value = 200001,
					Num = 228,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920106,
			Ability = {
				{
					Value = 200001,
					Num = 285,
				},
				{
					Value = 200006,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920106,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920106,
			Ability = {
				{
					Value = 200001,
					Num = 399,
				},
				{
					Value = 200006,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920106,
			Ability = {
				{
					Value = 200001,
					Num = 456,
				},
				{
					Value = 200006,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920106,
			Ability = {
				{
					Value = 200001,
					Num = 513,
				},
				{
					Value = 200006,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920106,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200006,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id080] =
{
	Character = 220103,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920107,
			Ability = {
				{
					Value = 200001,
					Num = 57,
				},
				{
					Value = 200007,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920107,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
				{
					Value = 200007,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920107,
			Ability = {
				{
					Value = 200001,
					Num = 171,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920107,
			Ability = {
				{
					Value = 200001,
					Num = 228,
				},
				{
					Value = 200007,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920107,
			Ability = {
				{
					Value = 200001,
					Num = 285,
				},
				{
					Value = 200007,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920107,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920107,
			Ability = {
				{
					Value = 200001,
					Num = 399,
				},
				{
					Value = 200007,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920107,
			Ability = {
				{
					Value = 200001,
					Num = 456,
				},
				{
					Value = 200007,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100565,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920107,
			Ability = {
				{
					Value = 200001,
					Num = 513,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100565,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920107,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200007,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100565,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id081] =
{
	Character = 220103,
	Rarity = 3,
	NeedChallenge = 145033,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920105,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
			},
		},
		{
			Level = 2,
			Info = 920105,
			Ability = {
				{
					Value = 200002,
					Num = 140,
				},
			},
		},
		{
			Level = 3,
			Info = 920105,
			Ability = {
				{
					Value = 200002,
					Num = 196,
				},
			},
		},
		{
			Level = 4,
			Info = 920105,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
		},
		{
			Level = 5,
			Info = 920105,
			Ability = {
				{
					Value = 200002,
					Num = 308,
				},
			},
			SkillList = {
				{
					Id = 100776,
					Value = 3,
				},
			},
		},
		{
			Level = 6,
			Info = 920105,
			Ability = {
				{
					Value = 200002,
					Num = 364,
				},
			},
			SkillList = {
				{
					Id = 100776,
					Value = 3,
				},
			},
		},
		{
			Level = 7,
			Info = 920105,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
			},
			SkillList = {
				{
					Id = 100776,
					Value = 3,
				},
			},
		},
		{
			Level = 8,
			Info = 920105,
			Ability = {
				{
					Value = 200002,
					Num = 476,
				},
			},
			SkillList = {
				{
					Id = 100776,
					Value = 3,
				},
				{
					Id = 100772,
					Value = 2,
				},
			},
		},
		{
			Level = 9,
			Info = 920105,
			Ability = {
				{
					Value = 200002,
					Num = 532,
				},
			},
			SkillList = {
				{
					Id = 100776,
					Value = 3,
				},
				{
					Id = 100772,
					Value = 2,
				},
			},
		},
		{
			Level = 10,
			Info = 920105,
			Ability = {
				{
					Value = 200002,
					Num = 588,
				},
			},
			SkillList = {
				{
					Id = 100776,
					Value = 3,
				},
				{
					Id = 100772,
					Value = 2,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id082] =
{
	Character = 220104,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920109,
			Ability = {
				{
					Value = 200001,
					Num = 57,
				},
				{
					Value = 200007,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920109,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920109,
			Ability = {
				{
					Value = 200001,
					Num = 171,
				},
				{
					Value = 200007,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920109,
			Ability = {
				{
					Value = 200001,
					Num = 228,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920109,
			Ability = {
				{
					Value = 200001,
					Num = 285,
				},
				{
					Value = 200007,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920109,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920109,
			Ability = {
				{
					Value = 200001,
					Num = 399,
				},
				{
					Value = 200007,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920109,
			Ability = {
				{
					Value = 200001,
					Num = 456,
				},
				{
					Value = 200007,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920109,
			Ability = {
				{
					Value = 200001,
					Num = 513,
				},
				{
					Value = 200007,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920109,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200007,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id083] =
{
	Character = 220104,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920110,
			Ability = {
				{
					Value = 200001,
					Num = 57,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920110,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920110,
			Ability = {
				{
					Value = 200001,
					Num = 171,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920110,
			Ability = {
				{
					Value = 200001,
					Num = 228,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920110,
			Ability = {
				{
					Value = 200001,
					Num = 285,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920110,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920110,
			Ability = {
				{
					Value = 200001,
					Num = 399,
				},
				{
					Value = 200006,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920110,
			Ability = {
				{
					Value = 200001,
					Num = 456,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920110,
			Ability = {
				{
					Value = 200001,
					Num = 513,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920110,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id084] =
{
	Character = 220104,
	Rarity = 3,
	NeedChallenge = 145034,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920108,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
			},
		},
		{
			Level = 2,
			Info = 920108,
			Ability = {
				{
					Value = 200002,
					Num = 140,
				},
			},
		},
		{
			Level = 3,
			Info = 920108,
			Ability = {
				{
					Value = 200002,
					Num = 196,
				},
			},
		},
		{
			Level = 4,
			Info = 920108,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
		},
		{
			Level = 5,
			Info = 920108,
			Ability = {
				{
					Value = 200002,
					Num = 308,
				},
			},
			SkillList = {
				{
					Id = 100777,
					Value = 3,
				},
			},
		},
		{
			Level = 6,
			Info = 920108,
			Ability = {
				{
					Value = 200002,
					Num = 364,
				},
			},
			SkillList = {
				{
					Id = 100777,
					Value = 3,
				},
			},
		},
		{
			Level = 7,
			Info = 920108,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
			},
			SkillList = {
				{
					Id = 100777,
					Value = 3,
				},
			},
		},
		{
			Level = 8,
			Info = 920108,
			Ability = {
				{
					Value = 200002,
					Num = 476,
				},
			},
			SkillList = {
				{
					Id = 100777,
					Value = 3,
				},
				{
					Id = 100773,
					Value = 13,
				},
			},
		},
		{
			Level = 9,
			Info = 920108,
			Ability = {
				{
					Value = 200002,
					Num = 532,
				},
			},
			SkillList = {
				{
					Id = 100777,
					Value = 3,
				},
				{
					Id = 100773,
					Value = 13,
				},
			},
		},
		{
			Level = 10,
			Info = 920108,
			Ability = {
				{
					Value = 200002,
					Num = 588,
				},
			},
			SkillList = {
				{
					Id = 100777,
					Value = 3,
				},
				{
					Id = 100773,
					Value = 13,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id085] =
{
	Character = 220105,
	Rarity = 1,
	UpgradeId = 930021,
	LevelList = {
		{
			Level = 1,
			Info = 920111,
			Ability = {
				{
					Value = 200001,
					Num = 27,
				},
				{
					Value = 200007,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920111,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200007,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920111,
			Ability = {
				{
					Value = 200001,
					Num = 81,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920111,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200007,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920111,
			Ability = {
				{
					Value = 200001,
					Num = 135,
				},
				{
					Value = 200007,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920111,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920111,
			Ability = {
				{
					Value = 200001,
					Num = 189,
				},
				{
					Value = 200007,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920111,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200007,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920111,
			Ability = {
				{
					Value = 200001,
					Num = 243,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920111,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200007,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id086] =
{
	Character = 220105,
	Rarity = 1,
	NeedChallenge = 145035,
	UpgradeId = 930022,
	LevelList = {
		{
			Level = 1,
			Info = 920112,
			Ability = {
				{
					Value = 200001,
					Num = 27,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920112,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920112,
			Ability = {
				{
					Value = 200001,
					Num = 81,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920112,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920112,
			Ability = {
				{
					Value = 200001,
					Num = 135,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 6,
			Info = 920112,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 7,
			Info = 920112,
			Ability = {
				{
					Value = 200001,
					Num = 189,
				},
				{
					Value = 200006,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 8,
			Info = 920112,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 9,
			Info = 920112,
			Ability = {
				{
					Value = 200001,
					Num = 243,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 10,
			Info = 920112,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id087] =
{
	Character = 220106,
	Rarity = 1,
	UpgradeId = 930001,
	LevelList = {
		{
			Level = 1,
			Info = 920113,
			Ability = {
				{
					Value = 200002,
					Num = 21,
				},
				{
					Value = 200007,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920113,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200007,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920113,
			Ability = {
				{
					Value = 200002,
					Num = 63,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920113,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200007,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920113,
			Ability = {
				{
					Value = 200002,
					Num = 105,
				},
				{
					Value = 200007,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920113,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920113,
			Ability = {
				{
					Value = 200002,
					Num = 147,
				},
				{
					Value = 200007,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920113,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200007,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920113,
			Ability = {
				{
					Value = 200002,
					Num = 189,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920113,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200007,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id088] =
{
	Character = 220106,
	Rarity = 1,
	NeedChallenge = 145036,
	UpgradeId = 930002,
	LevelList = {
		{
			Level = 1,
			Info = 920114,
			Ability = {
				{
					Value = 200002,
					Num = 21,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920114,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920114,
			Ability = {
				{
					Value = 200002,
					Num = 63,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920114,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920114,
			Ability = {
				{
					Value = 200002,
					Num = 105,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 6,
			Info = 920114,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 7,
			Info = 920114,
			Ability = {
				{
					Value = 200002,
					Num = 147,
				},
				{
					Value = 200005,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 8,
			Info = 920114,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 9,
			Info = 920114,
			Ability = {
				{
					Value = 200002,
					Num = 189,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 10,
			Info = 920114,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id089] =
{
	Character = 220107,
	Rarity = 1,
	UpgradeId = 930001,
	LevelList = {
		{
			Level = 1,
			Info = 920115,
			Ability = {
				{
					Value = 200002,
					Num = 21,
				},
				{
					Value = 200007,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920115,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200007,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920115,
			Ability = {
				{
					Value = 200002,
					Num = 63,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920115,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200007,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920115,
			Ability = {
				{
					Value = 200002,
					Num = 105,
				},
				{
					Value = 200007,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920115,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920115,
			Ability = {
				{
					Value = 200002,
					Num = 147,
				},
				{
					Value = 200007,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920115,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200007,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920115,
			Ability = {
				{
					Value = 200002,
					Num = 189,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920115,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200007,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id090] =
{
	Character = 220107,
	Rarity = 1,
	NeedChallenge = 145037,
	UpgradeId = 930002,
	LevelList = {
		{
			Level = 1,
			Info = 920116,
			Ability = {
				{
					Value = 200002,
					Num = 21,
				},
				{
					Value = 200008,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920116,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920116,
			Ability = {
				{
					Value = 200002,
					Num = 63,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920116,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920116,
			Ability = {
				{
					Value = 200002,
					Num = 105,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 6,
			Info = 920116,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 7,
			Info = 920116,
			Ability = {
				{
					Value = 200002,
					Num = 147,
				},
				{
					Value = 200008,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 8,
			Info = 920116,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 9,
			Info = 920116,
			Ability = {
				{
					Value = 200002,
					Num = 189,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 10,
			Info = 920116,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
	},
}
