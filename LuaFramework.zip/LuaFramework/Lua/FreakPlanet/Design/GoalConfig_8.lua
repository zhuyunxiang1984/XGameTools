
GoalConfig[GoalID.Id8801] =
{
	Id = 8801,
	Name = "探索的教学1",
	GoalType = GoalType.Newbie,
	ShowFirst = false,
	NewbieId = "Newbie_Explore",
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			300004,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ExploreEnemyGroup,
	},
	GoalCondition = 
	{
		{
			Name = "[714747]一次性探索击败[7EC739]初始城镇[-]的3种[FCA730]敌人[-]。[-]",
			Type = ItemType.Enemy,
			CountType = GoalCountType.OneShot,
			Num = 3,
			Value = -1,
			Area = 130002,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id8802] =
{
	Id = 8802,
	Name = "探索的教学2",
	GoalType = GoalType.Newbie,
	ShowFirst = false,
	NewbieId = "Newbie_Explore",
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			308801,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ExploreEnemyGroup,
	},
	GoalCondition = 
	{
		{
			Name = "[714747]一次性探索击败[7EC739]村口树林[-]的4种[FCA730]敌人[-]。[-]",
			Type = ItemType.Enemy,
			CountType = GoalCountType.OneShot,
			Num = 4,
			Value = -1,
			Area = 130003,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id8803] =
{
	Id = 8803,
	Name = "探索的教学3",
	GoalType = GoalType.Newbie,
	ShowFirst = false,
	NewbieId = "Newbie_Explore",
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			308802,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ExploreEnemyGroup,
	},
	GoalCondition = 
	{
		{
			Name = "[714747]一次性探索击败[7EC739]溪谷[-]的5种[FCA730]敌人[-]。[-]",
			Type = ItemType.Enemy,
			CountType = GoalCountType.OneShot,
			Num = 5,
			Value = -1,
			Area = 130004,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id8804] =
{
	Id = 8804,
	Name = "探索的教学4",
	GoalType = GoalType.Newbie,
	ShowFirst = false,
	NewbieId = "Newbie_Explore",
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			308803,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "[714747]拥有[7EC739]陷阱捕捉[-]的[FCA730]宠物[-]1种。[-]",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 1,
			TagList = 
			{
				563102,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id8805] =
{
	Id = 8805,
	Name = "探索的教学5",
	GoalType = GoalType.Newbie,
	ShowFirst = false,
	NewbieId = "Newbie_Explore",
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			308804,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "[714747]拥有[7EC739]空瓶捕捉[-]的[FCA730]宠物[-]1种。[-]",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 1,
			TagList = 
			{
				563103,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id8806] =
{
	Id = 8806,
	Name = "探索的教学6",
	GoalType = GoalType.Newbie,
	ShowFirst = false,
	NewbieId = "Newbie_Explore",
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			308805,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "[714747]拥有[7EC739]冒险星[-]的[FCA730]宠物[-]10种。[-]",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 10,
			TagList = 
			{
				560103,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
}
GoalConfig[GoalID.Id8807] =
{
	Id = 8807,
	Name = "挑战的教学1",
	GoalType = GoalType.Newbie,
	ShowFirst = false,
	NewbieId = "Newbie_Challenge",
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			300004,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "[714747]完成[7EC739]初始城镇[-]的[FCA730]剑士的挑战[-]。[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140004,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id8808] =
{
	Id = 8808,
	Name = "挑战的教学2",
	GoalType = GoalType.Newbie,
	ShowFirst = false,
	NewbieId = "Newbie_Challenge",
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			308807,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "[714747]完成[7EC739]村口树林[-]的[FCA730]弓箭手的挑战[-]。[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140007,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id8809] =
{
	Id = 8809,
	Name = "挑战的教学3",
	GoalType = GoalType.Newbie,
	ShowFirst = false,
	NewbieId = "Newbie_Challenge",
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			308808,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "[714747]完成[7EC739]溪谷[-]的[FCA730]猎人的挑战[-]。[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140010,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
}
GoalConfig[GoalID.Id8810] =
{
	Id = 8810,
	Name = "升级的教学1",
	GoalType = GoalType.Newbie,
	ShowFirst = false,
	NewbieId = "Newbie_CharacterLevelUp",
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			300004,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "[714747]拥有[7EC739]10级[-][FCA730]角色[-]2个。[-]",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 2,
			Value = -1,
			Level = 10,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id8811] =
{
	Id = 8811,
	Name = "升级的教学2",
	GoalType = GoalType.Newbie,
	ShowFirst = false,
	NewbieId = "Newbie_CharacterLevelUp",
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			308810,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "[714747]拥有[7EC739]20级[-][FCA730]角色[-]2个。[-]",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 2,
			Value = -1,
			Level = 20,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id8812] =
{
	Id = 8812,
	Name = "升级的教学3",
	GoalType = GoalType.Newbie,
	ShowFirst = false,
	NewbieId = "Newbie_CharacterLevelUp",
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			308811,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "[714747]拥有[7EC739]2阶[-][FCA730]角色[-]2个。[-]",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 2,
			Value = -1,
			Stage = 2,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
}
GoalConfig[GoalID.Id8813] =
{
	Id = 8813,
	Name = "打工的教学1",
	GoalType = GoalType.Newbie,
	ShowFirst = false,
	NewbieId = "Newbie_Workshop",
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			300006,
		},
	},
	GoalTrigger = 
	{
		TriggerType.WorkShopRank,
	},
	GoalCondition = 
	{
		{
			Name = "[714747]在[7EC739]任意店铺[-]打工取得[FCA730]E评价[-]。[-]",
			Type = ItemType.WorkShop,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = -1,
			Rank = 6,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id8814] =
{
	Id = 8814,
	Name = "打工的教学2",
	GoalType = GoalType.Newbie,
	ShowFirst = false,
	NewbieId = "Newbie_Workshop",
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			308813,
		},
	},
	GoalTrigger = 
	{
		TriggerType.WorkShopRank,
	},
	GoalCondition = 
	{
		{
			Name = "[714747]在[7EC739]任意店铺[-]打工取得[FCA730]D评价[-]。[-]",
			Type = ItemType.WorkShop,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = -1,
			Rank = 9,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id8815] =
{
	Id = 8815,
	Name = "打工的教学3",
	GoalType = GoalType.Newbie,
	ShowFirst = false,
	NewbieId = "Newbie_Workshop",
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			308814,
		},
	},
	GoalTrigger = 
	{
		TriggerType.WorkShopRank,
	},
	GoalCondition = 
	{
		{
			Name = "[714747]在[7EC739]任意店铺[-]打工取得[FCA730]C评价[-]。[-]",
			Type = ItemType.WorkShop,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = -1,
			Rank = 12,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
}
GoalConfig[GoalID.Id8816] =
{
	Id = 8816,
	Name = "委托的教学1",
	GoalType = GoalType.Newbie,
	ShowFirst = false,
	NewbieId = "Newbie_Demand",
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			300010,
		},
	},
	GoalTrigger = 
	{
		TriggerType.DemandReward,
	},
	GoalCondition = 
	{
		{
			Name = "[714747]完成[7EC739]委托[-]获得[FCA730]金币[-]500个。[-]",
			Type = ItemType.Gold,
			CountType = GoalCountType.StartNow,
			Num = 500,
			Value = 1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id8817] =
{
	Id = 8817,
	Name = "委托的教学2",
	GoalType = GoalType.Newbie,
	ShowFirst = false,
	NewbieId = "Newbie_Demand",
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			308816,
		},
	},
	GoalTrigger = 
	{
		TriggerType.DemandReward,
	},
	GoalCondition = 
	{
		{
			Name = "[714747]完成[7EC739]委托[-]获得[FCA730]金币[-]5000个。[-]",
			Type = ItemType.Gold,
			CountType = GoalCountType.StartNow,
			Num = 5000,
			Value = 1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id8818] =
{
	Id = 8818,
	Name = "委托的教学3",
	GoalType = GoalType.Newbie,
	ShowFirst = false,
	NewbieId = "Newbie_Demand",
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			308817,
		},
	},
	GoalTrigger = 
	{
		TriggerType.DemandReward,
	},
	GoalCondition = 
	{
		{
			Name = "[714747]完成[7EC739]委托[-]获得[FCA730]金币[-]50000个。[-]。[-]",
			Type = ItemType.Gold,
			CountType = GoalCountType.StartNow,
			Num = 50000,
			Value = 1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
}
GoalConfig[GoalID.Id8819] =
{
	Id = 8819,
	Name = "装备的教学1",
	GoalType = GoalType.Newbie,
	ShowFirst = false,
	NewbieId = "Newbie_Equipment",
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			300011,
		},
	},
	GoalTrigger = 
	{
		TriggerType.UpgradeEquipment,
	},
	GoalCondition = 
	{
		{
			Name = "[714747]累计强化[FCA730]装备[-]10次。[-]",
			Type = ItemType.Equipment,
			CountType = GoalCountType.Current,
			Num = 10,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id8820] =
{
	Id = 8820,
	Name = "装备的教学2",
	GoalType = GoalType.Newbie,
	ShowFirst = false,
	NewbieId = "Newbie_Equipment",
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			308819,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "[714747]拥有[FCA730]对讲机[-](呜呜装备)。[-]",
			Type = ItemType.Equipment,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 340002,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id8821] =
{
	Id = 8821,
	Name = "装备的教学3",
	GoalType = GoalType.Newbie,
	ShowFirst = false,
	NewbieId = "Newbie_Equipment",
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			308820,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "[714747]拥有[FCA730]魔法卷轴[-](魔法师装备)。[-]",
			Type = ItemType.Equipment,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 340022,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
}
GoalConfig[GoalID.Id8822] =
{
	Id = 8822,
	Name = "合成的教学1",
	GoalType = GoalType.Newbie,
	ShowFirst = false,
	NewbieId = "Newbie_Craft",
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			300026,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Craft,
	},
	GoalCondition = 
	{
		{
			Name = "[714747][7EC739]合成[-]获得[FCA730]大血瓶[-]3个。[-]",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 3,
			Value = 320403,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id8823] =
{
	Id = 8823,
	Name = "合成的教学2",
	GoalType = GoalType.Newbie,
	ShowFirst = false,
	NewbieId = "Newbie_Craft",
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			308822,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Craft,
	},
	GoalCondition = 
	{
		{
			Name = "[714747][7EC739]合成[-]获得[FCA730]头骨[-]3个。[-]",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 3,
			Value = 321051,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id8824] =
{
	Id = 8824,
	Name = "合成的教学3",
	GoalType = GoalType.Newbie,
	ShowFirst = false,
	NewbieId = "Newbie_Craft",
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			308823,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Craft,
	},
	GoalCondition = 
	{
		{
			Name = "[714747][7EC739]合成[-]获得[FCA730]复合陷阱[-]3个。[-]",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 3,
			Value = 320302,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
}
GoalConfig[GoalID.Id8825] =
{
	Id = 8825,
	Name = "皮肤的教学1",
	GoalType = GoalType.Newbie,
	ShowFirst = false,
	NewbieId = "Newbie_Skin",
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			300027,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "[714747][FCA730]呜呜[-]达到[7EC739]20级[-]。[-]",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220001,
			Level = 20,
		},
	},
	Reward = {
		{
			Value = 320001,
			Num = 2,
		},
	},
}
GoalConfig[GoalID.Id8826] =
{
	Id = 8826,
	Name = "皮肤的教学2",
	GoalType = GoalType.Newbie,
	ShowFirst = false,
	NewbieId = "Newbie_Skin",
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			308825,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "[714747][FCA730]呜呜[-]达到[7EC739]2阶[-]。[-]",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220001,
			Stage = 2,
		},
	},
	Reward = {
		{
			Value = 320102,
			Num = 1,
		},
	},
}
GoalConfig[GoalID.Id8827] =
{
	Id = 8827,
	Name = "皮肤的教学3",
	GoalType = GoalType.Newbie,
	ShowFirst = false,
	NewbieId = "Newbie_Skin",
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			308826,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "[714747]解锁[FCA730]探险家呜呜[-](呜呜皮肤)。[-]",
			Type = ItemType.Skin,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 232001,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
}
GoalConfig[GoalID.Id8828] =
{
	Id = 8828,
	Name = "准备出发！",
	GoalType = GoalType.Newbie,
	ShowFirst = false,
	NewbieId = "Newbie_PlanetUI",
	PreCondition = {
		PreArea = 130001,
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "[714747]笔记任务点击后可以查看功能教学笔记，试一下吧~[-]",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220001,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id8851] =
{
	Id = 8851,
	Name = "每周打卡",
	GoalType = GoalType.Weekly,
	ShowFirst = false,
	Icon = "Home_task_icon4",
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			300004,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Signin,
	},
	GoalCondition = 
	{
		{
			Name = "[62E7E7]本周内[-]登录签到[FDDE40]3天[-]",
			Type = ItemType.Time,
			CountType = GoalCountType.Weekly,
			Num = 3,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id8852] =
{
	Id = 8852,
	Name = "耐力训练1",
	GoalType = GoalType.Weekly,
	ShowFirst = false,
	Icon = "Home_task_icon11",
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			300004,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "[62E7E7]本周内[-]探索任意地区48小时",
			Type = ItemType.Time,
			CountType = GoalCountType.Weekly,
			Num = 172800,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id8853] =
{
	Id = 8853,
	Name = "乐于助人1",
	GoalType = GoalType.Weekly,
	ShowFirst = false,
	Icon = "Home_task_icon31",
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			300010,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CompleteDemand,
	},
	GoalCondition = 
	{
		{
			Name = "本周内完成[62E7E7]任意[-][FDDE40]委托[-]20次",
			Type = ItemType.Demand,
			CountType = GoalCountType.Weekly,
			Num = 20,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id8854] =
{
	Id = 8854,
	Name = "力量训练1",
	GoalType = GoalType.Weekly,
	ShowFirst = false,
	Icon = "Home_task_icon21",
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			300347,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Arena,
	},
	GoalCondition = 
	{
		{
			Name = "击败[62E7E7]本周[-]流亡街[FDDE40]5层3星难度星敌人[-]",
			Type = ItemType.ArenaBattle,
			CountType = GoalCountType.Weekly,
			Num = 3,
			Value = 5,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id8855] =
{
	Id = 8855,
	Name = "耐力训练2",
	GoalType = GoalType.Weekly,
	ShowFirst = false,
	Icon = "Home_task_icon1",
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			300103,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "[62E7E7]本周内[-]探索任意地区168小时",
			Type = ItemType.Time,
			CountType = GoalCountType.Weekly,
			Num = 604800,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id8856] =
{
	Id = 8856,
	Name = "乐于助人2",
	GoalType = GoalType.Weekly,
	ShowFirst = false,
	Icon = "Home_task_icon3",
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			300103,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CompleteDemand,
	},
	GoalCondition = 
	{
		{
			Name = "本周内完成[62E7E7]任意[-][FDDE40]委托[-]50次",
			Type = ItemType.Demand,
			CountType = GoalCountType.Weekly,
			Num = 50,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id8857] =
{
	Id = 8857,
	Name = "力量训练2",
	GoalType = GoalType.Weekly,
	ShowFirst = false,
	Icon = "Home_task_icon2",
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			308915,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Arena,
	},
	GoalCondition = 
	{
		{
			Name = "击败[62E7E7]本周[-]流亡街[FDDE40]15层3星难度星敌人[-]",
			Type = ItemType.ArenaBattle,
			CountType = GoalCountType.Weekly,
			Num = 3,
			Value = 15,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 100,
		},
	},
}
GoalConfig[GoalID.Id8901] =
{
	Id = 8901,
	Name = "生涯任务：前往流亡街1",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			300102,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Arena,
	},
	GoalCondition = 
	{
		{
			Name = "逮捕流亡街[FDDE40]1层3星难度[-]敌人（曾经逮捕过也记为完成，不限本周）",
			Type = ItemType.ArenaBattle,
			CountType = GoalCountType.Current,
			Num = 3,
			Value = 1,
		},
	},
	Reward = {
		{
			Value = 320001,
			Num = 2,
		},
		{
			Value = 1,
			Num = 1000,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id8902] =
{
	Id = 8902,
	Name = "生涯任务：前往流亡街2",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			308901,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Arena,
	},
	GoalCondition = 
	{
		{
			Name = "逮捕流亡街[FDDE40]2层3星难度[-]敌人（曾经逮捕过也记为完成，不限本周）",
			Type = ItemType.ArenaBattle,
			CountType = GoalCountType.Current,
			Num = 3,
			Value = 2,
		},
	},
	Reward = {
		{
			Value = 320001,
			Num = 2,
		},
		{
			Value = 1,
			Num = 2000,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id8903] =
{
	Id = 8903,
	Name = "生涯任务：前往流亡街3",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			308902,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Arena,
	},
	GoalCondition = 
	{
		{
			Name = "逮捕流亡街[FDDE40]3层3星难度[-]敌人（曾经逮捕过也记为完成，不限本周）",
			Type = ItemType.ArenaBattle,
			CountType = GoalCountType.Current,
			Num = 3,
			Value = 3,
		},
	},
	Reward = {
		{
			Value = 320001,
			Num = 2,
		},
		{
			Value = 1,
			Num = 3500,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id8904] =
{
	Id = 8904,
	Name = "生涯任务：前往流亡街4",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			308903,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Arena,
	},
	GoalCondition = 
	{
		{
			Name = "逮捕流亡街[FDDE40]4层3星难度[-]敌人（曾经逮捕过也记为完成，不限本周）",
			Type = ItemType.ArenaBattle,
			CountType = GoalCountType.Current,
			Num = 3,
			Value = 4,
		},
	},
	Reward = {
		{
			Value = 320001,
			Num = 2,
		},
		{
			Value = 1,
			Num = 5000,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id8905] =
{
	Id = 8905,
	Name = "生涯任务：流亡街的可怕居民！",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			308904,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Arena,
	},
	GoalCondition = 
	{
		{
			Name = "逮捕流亡街[FDDE40]5层3星难度[-]敌人（曾经逮捕过也记为完成，不限本周）",
			Type = ItemType.ArenaBattle,
			CountType = GoalCountType.Current,
			Num = 3,
			Value = 5,
		},
	},
	Reward = {
		{
			Value = 320001,
			Num = 10,
		},
		{
			Value = 1,
			Num = 15000,
		},
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id8906] =
{
	Id = 8906,
	Name = "生涯任务：深入流亡街1",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			308905,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Arena,
	},
	GoalCondition = 
	{
		{
			Name = "逮捕流亡街[FDDE40]6层3星难度[-]敌人（曾经逮捕过也记为完成，不限本周）",
			Type = ItemType.ArenaBattle,
			CountType = GoalCountType.Current,
			Num = 3,
			Value = 6,
		},
	},
	Reward = {
		{
			Value = 320002,
			Num = 2,
		},
		{
			Value = 1,
			Num = 10000,
		},
		{
			Value = 2,
			Num = 25,
		},
	},
}
GoalConfig[GoalID.Id8907] =
{
	Id = 8907,
	Name = "生涯任务：深入流亡街2",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			308906,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Arena,
	},
	GoalCondition = 
	{
		{
			Name = "逮捕流亡街[FDDE40]7层3星难度[-]敌人（曾经逮捕过也记为完成，不限本周）",
			Type = ItemType.ArenaBattle,
			CountType = GoalCountType.Current,
			Num = 3,
			Value = 7,
		},
	},
	Reward = {
		{
			Value = 320002,
			Num = 2,
		},
		{
			Value = 1,
			Num = 10000,
		},
		{
			Value = 2,
			Num = 25,
		},
	},
}
GoalConfig[GoalID.Id8908] =
{
	Id = 8908,
	Name = "生涯任务：深入流亡街3",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			308907,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Arena,
	},
	GoalCondition = 
	{
		{
			Name = "逮捕流亡街[FDDE40]8层3星难度[-]敌人（曾经逮捕过也记为完成，不限本周）",
			Type = ItemType.ArenaBattle,
			CountType = GoalCountType.Current,
			Num = 3,
			Value = 8,
		},
	},
	Reward = {
		{
			Value = 320002,
			Num = 2,
		},
		{
			Value = 1,
			Num = 10000,
		},
		{
			Value = 2,
			Num = 25,
		},
	},
}
GoalConfig[GoalID.Id8909] =
{
	Id = 8909,
	Name = "生涯任务：深入流亡街4",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			308908,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Arena,
	},
	GoalCondition = 
	{
		{
			Name = "逮捕流亡街[FDDE40]9层3星难度[-]敌人（曾经逮捕过也记为完成，不限本周）",
			Type = ItemType.ArenaBattle,
			CountType = GoalCountType.Current,
			Num = 3,
			Value = 9,
		},
	},
	Reward = {
		{
			Value = 320002,
			Num = 2,
		},
		{
			Value = 1,
			Num = 10000,
		},
		{
			Value = 2,
			Num = 25,
		},
	},
}
GoalConfig[GoalID.Id8910] =
{
	Id = 8910,
	Name = "生涯任务：流亡街的恐怖居民！",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			308909,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Arena,
	},
	GoalCondition = 
	{
		{
			Name = "逮捕流亡街[FDDE40]10层3星难度[-]敌人（曾经逮捕过也记为完成，不限本周）",
			Type = ItemType.ArenaBattle,
			CountType = GoalCountType.Current,
			Num = 3,
			Value = 10,
		},
	},
	Reward = {
		{
			Value = 320002,
			Num = 10,
		},
		{
			Value = 1,
			Num = 30000,
		},
		{
			Value = 2,
			Num = 75,
		},
	},
}
GoalConfig[GoalID.Id8911] =
{
	Id = 8911,
	Name = "生涯任务：流亡街深处1",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			308910,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Arena,
	},
	GoalCondition = 
	{
		{
			Name = "逮捕流亡街[FDDE40]11层3星难度[-]敌人（曾经逮捕过也记为完成，不限本周）",
			Type = ItemType.ArenaBattle,
			CountType = GoalCountType.Current,
			Num = 3,
			Value = 11,
		},
	},
	Reward = {
		{
			Value = 320003,
			Num = 2,
		},
		{
			Value = 1,
			Num = 20000,
		},
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id8912] =
{
	Id = 8912,
	Name = "生涯任务：流亡街深处2",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			308911,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Arena,
	},
	GoalCondition = 
	{
		{
			Name = "逮捕流亡街[FDDE40]12层3星难度[-]敌人（曾经逮捕过也记为完成，不限本周）",
			Type = ItemType.ArenaBattle,
			CountType = GoalCountType.Current,
			Num = 3,
			Value = 12,
		},
	},
	Reward = {
		{
			Value = 320003,
			Num = 2,
		},
		{
			Value = 1,
			Num = 20000,
		},
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id8913] =
{
	Id = 8913,
	Name = "生涯任务：流亡街深处3",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			308912,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Arena,
	},
	GoalCondition = 
	{
		{
			Name = "逮捕流亡街[FDDE40]13层3星难度[-]敌人（曾经逮捕过也记为完成，不限本周）",
			Type = ItemType.ArenaBattle,
			CountType = GoalCountType.Current,
			Num = 3,
			Value = 13,
		},
	},
	Reward = {
		{
			Value = 320003,
			Num = 2,
		},
		{
			Value = 1,
			Num = 20000,
		},
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id8914] =
{
	Id = 8914,
	Name = "生涯任务：流亡街深处4",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			308913,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Arena,
	},
	GoalCondition = 
	{
		{
			Name = "逮捕流亡街[FDDE40]14层3星难度[-]敌人（曾经逮捕过也记为完成，不限本周）",
			Type = ItemType.ArenaBattle,
			CountType = GoalCountType.Current,
			Num = 3,
			Value = 14,
		},
	},
	Reward = {
		{
			Value = 320003,
			Num = 2,
		},
		{
			Value = 1,
			Num = 20000,
		},
		{
			Value = 2,
			Num = 45,
		},
	},
}
GoalConfig[GoalID.Id8915] =
{
	Id = 8915,
	Name = "生涯任务：流亡街的怪人！",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130001,
		PreGoal = 
		{
			308914,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Arena,
	},
	GoalCondition = 
	{
		{
			Name = "逮捕流亡街[FDDE40]15层3星难度[-]敌人（曾经逮捕过也记为完成，不限本周）",
			Type = ItemType.ArenaBattle,
			CountType = GoalCountType.Current,
			Num = 3,
			Value = 15,
		},
	},
	Reward = {
		{
			Value = 320003,
			Num = 10,
		},
		{
			Value = 1,
			Num = 60000,
		},
		{
			Value = 2,
			Num = 150,
		},
	},
}
