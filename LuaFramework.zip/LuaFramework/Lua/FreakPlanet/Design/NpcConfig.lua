NpcConfig ={};
NpcID = 
{
	Id001 = 430001,
	Id002 = 430002,
	Id003 = 430003,
	Id004 = 430004,
	Id005 = 430005,
	Id006 = 430006,
	Id007 = 430007,
	Id008 = 430008,
	Id009 = 430009,
	Id010 = 430010,
}
NpcConfig[NpcID.Id001] =
{
	Id = 1,
	Name = "蓝发男孩",
	Atlas = "NPC",
	SkinName = "RPG_NPC1",
	NormalSpeed = 
	{
		20,30,
	},
	FinishSpeed = 
	{
		11,18,
	},
}
NpcConfig[NpcID.Id002] =
{
	Id = 2,
	Name = "黑发女孩",
	Atlas = "NPC",
	SkinName = "RPG_NPC2",
	NormalSpeed = 
	{
		20,30,
	},
	FinishSpeed = 
	{
		11,18,
	},
}
NpcConfig[NpcID.Id003] =
{
	Id = 3,
	Name = "红发男孩",
	Atlas = "NPC",
	SkinName = "RPG_NPC3",
	NormalSpeed = 
	{
		20,30,
	},
	FinishSpeed = 
	{
		11,18,
	},
}
NpcConfig[NpcID.Id004] =
{
	Id = 4,
	Name = "灰发男孩",
	Atlas = "NPC",
	SkinName = "RPG_NPC4",
	NormalSpeed = 
	{
		20,30,
	},
	FinishSpeed = 
	{
		11,18,
	},
}
NpcConfig[NpcID.Id005] =
{
	Id = 5,
	Name = "大熊猫",
	Atlas = "NPC",
	SkinName = "RPG_NPC5",
	NormalSpeed = 
	{
		33,43,
	},
	FinishSpeed = 
	{
		18,23,
	},
}
NpcConfig[NpcID.Id006] =
{
	Id = 6,
	Name = "村长夫人",
	Atlas = "NPC",
	SkinName = "RPG_NPC6",
	NormalSpeed = 
	{
		12,16,
	},
	FinishSpeed = 
	{
		6,10,
	},
}
NpcConfig[NpcID.Id007] =
{
	Id = 7,
	Name = "地精爷爷",
	Atlas = "NPC",
	SkinName = "RPG_NPC7",
	NormalSpeed = 
	{
		12,16,
	},
	FinishSpeed = 
	{
		6,10,
	},
}
NpcConfig[NpcID.Id008] =
{
	Id = 8,
	Name = "小骷髅",
	Atlas = "NPC",
	SkinName = "RPG_NPC8",
	NormalSpeed = 
	{
		35,45,
	},
	FinishSpeed = 
	{
		20,25,
	},
}
NpcConfig[NpcID.Id009] =
{
	Id = 9,
	Name = "章鱼仔",
	Atlas = "NPC",
	SkinName = "RPG_NPC9",
	NormalSpeed = 
	{
		20,30,
	},
	FinishSpeed = 
	{
		10,14,
	},
}
NpcConfig[NpcID.Id010] =
{
	Id = 10,
	Name = "双马尾",
	Atlas = "NPC",
	SkinName = "RPG_NPC10",
	NormalSpeed = 
	{
		20,30,
	},
	FinishSpeed = 
	{
		10,14,
	},
}
