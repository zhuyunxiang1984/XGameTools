PlanetCharacterConfig ={};
PlanetCharacterConfig["Rpg_09_putongcunmin_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220011,
		},
	},
	DialogList = {
		{
			{
				Text = "今天的任务是卖掉10个药水。",
				Position = 1,
			},
			{
				Text = "不过好怕碰到不肯付账的勇者大人啊…",
				Position = 1,
			},
		},
		{
			{
				Text = "好好工作，天天向上！",
				Position = 1,
			},
		},
		{
			{
				Text = "这次赚到的钱都要藏好！",
				Position = 1,
			},
			{
				Text = "嗯，藏哪里好呢？",
				Position = 1,
			},
			{
				Text = "啊，感觉无论藏哪里都会被发现啊！！",
				Position = 1,
			},
		},
		{
			{
				Text = "明年我也要去冒险家协会报考勇者。",
				Position = 1,
			},
			{
				Text = "只要成为勇者，我也可以翻其他NPC的房间了~",
				Position = 1,
			},
		},
		{
			{
				Text = "药水，新鲜的药水~大家都来看看~",
				Position = 1,
			},
			{
				Text = "不打算付账的勇者们就不要来看了噢~",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Rpg_10_buluolaoda_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220007,
		},
	},
	DialogList = {
		{
			{
				Text = "咋还没人来问俺路咧？",
				Position = 1,
			},
		},
		{
			{
				Text = "诶？怎么歪了？",
				Position = 1,
			},
		},
		{
			{
				Text = "这里的山路十八弯~",
				Position = 1,
			},
			{
				Text = "这里的水路九连环~",
				Position = 1,
			},
		},
		{
			{
				Text = "此山是俺开，此树是俺栽！",
				Position = 1,
			},
			{
				Text = "要想从此过……请往这边走~",
				Position = 1,
			},
		},
		{
			{
				Text = "哎哟！又砸手了！疼死俺了！！！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Rpg_31_tiejiang_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220008,
		},
	},
	DialogList = {
		{
			{
				Text = "还差点火候。",
				Position = 1,
			},
			{
				Text = "诶，手滑了！好像不太直了…",
				Position = 1,
			},
		},
		{
			{
				Text = "这次应该不会爆炸了吧？",
				Position = 1,
			},
		},
		{
			{
				Text = "哎！？怎么又碎了……",
				Position = 1,
			},
			{
				Text = "这可是+17的史诗啊……",
				Position = 1,
			},
			{
				Text = "……",
				Position = 1,
			},
			{
				Text = "该收拾东西跑路了……",
				Position = 1,
			},
		},
		{
			{
				Text = "陨铁、秘银、红石、火山石……",
				Position = 1,
			},
			{
				Text = "淬火——这次一定是极品——！",
				Position = 1,
			},
			{
				Text = "哎哟！怎么又炸了！？",
				Position = 1,
			},
		},
		{
			{
				Text = "I am the bone of my sword——",
				Position = 1,
			},
			{
				Text = "Steel is my body, and fire is my blood——",
				Position = 1,
			},
			{
				Text = "Unlimited Blade Works！！！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Rpg_01_chengxuyuan_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220024,
		},
	},
	DialogList = {
		{
			{
				Text = "又报错了？",
				Position = 1,
			},
			{
				Text = "太难了……",
				Position = 1,
			},
		},
		{
			{
				Text = "什么！功能又要改了！",
				Position = 1,
			},
			{
				Text = "我新订的刀应该快到了。",
				Position = 1,
			},
		},
		{
			{
				Text = "这个需求……",
				Position = 1,
			},
			{
				Text = "该杀个策划祭天了……",
				Position = 1,
			},
		},
		{
			{
				Text = "呜……什么时候下班啊……",
				Position = 1,
			},
		},
		{
			{
				Text = "php是世界上最好的语言！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Rpg_25_longqishi_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220026,
		},
		LockCharacterList = {
			220027,
		},
	},
	DialogList = {
		{
			{
				Text = "等我憋个龙心！",
				Position = 1,
			},
		},
		{
			{
				Text = "哪里有恶龙？等我吃饱了就去讨伐！",
				Position = 1,
			},
		},
		{
			{
				Text = "别戳了！妨碍我吃饭了！",
				Position = 1,
			},
		},
		{
			{
				Text = "虽然叫龙骑士，但我并没有龙骑。",
				Position = 1,
			},
		},
		{
			{
				Text = "只要是骑过龙的就能算龙骑士？当然不是！",
				Position = 1,
			},
			{
				Text = "这么说的话，那唐僧不也算龙骑士了！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Rpg_25_longqishi_2"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220026,
			220027,
		},
	},
	DialogList = {
		{
			{
				Text = "哈呜哈呜哈呜！",
				Position = 1,
			},
		},
		{
			{
				Text = "慢点吃！给我留点！",
				Position = 1,
			},
		},
		{
			{
				Text = "嗝——下次有空也要一起吃饭啊！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Rpg_23_long_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220027,
		},
		LockCharacterList = {
			220026,
		},
	},
	DialogList = {
		{
			{
				Text = "这个肉真是好吃！",
				Position = 1,
			},
			{
				Text = "是什么肉呢……什么？是龙肉！？",
				Position = 1,
			},
			{
				Text = "……",
				Position = 1,
			},
			{
				Text = "算了，太好吃了！",
				Position = 1,
			},
		},
		{
			{
				Text = "哪有龙骑士？等我吃饱了就去讨伐！",
				Position = 1,
			},
		},
		{
			{
				Text = "再戳就把你也吃了！",
				Position = 1,
			},
		},
		{
			{
				Text = "想骑在我背上？门都没有！",
				Position = 1,
			},
			{
				Text = "我可是高贵的黑龙王子，怎么可能让凡人骑！",
				Position = 1,
			},
			{
				Text = "什么？有肉吃！？",
				Position = 1,
			},
			{
				Text = "……只能骑一会儿啊！",
				Position = 1,
			},
		},
		{
			{
				Text = "吾即——小——灾——变——！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Rpg_23_long_2"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220027,
			220026,
		},
	},
	DialogList = {
		{
			{
				Text = "吼唔吼唔吼唔！",
				Position = 1,
			},
		},
		{
			{
				Text = "你先吃，吃饱了我再吃~",
				Position = 1,
			},
		},
		{
			{
				Text = "嗝——我来付账吧~",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Rpg_05_jianshi_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220003,
		},
	},
	DialogList = {
		{
			{
				Text = "准备出发！",
				Position = 1,
			},
			{
				Text = "这次一定要打败魔王！",
				Position = 1,
			},
		},
		{
			{
				Text = "每天要打够一百只怪！",
				Position = 1,
			},
			{
				Text = "再完成一百个任务！",
				Position = 1,
			},
			{
				Text = "最后搜刮一百个村民的房子！",
				Position = 1,
			},
		},
		{
			{
				Text = "保护村民，打败魔王！",
				Position = 1,
			},
			{
				Text = "希望各位NPC能支持我们冒险家的工作！",
				Position = 1,
			},
			{
				Text = "主动上交宝物！",
				Position = 1,
			},
		},
		{
			{
				Text = "STR决定一切！不要点AGI！",
				Position = 1,
			},
			{
				Text = "下个版本就加强我们了！要有信心！",
				Position = 1,
			},
			{
				Text = "让策划听到我们的声音！",
				Position = 1,
			},
		},
		{
			{
				Text = "不能用的装备不要秒！大家注意素养！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Rpg_24_gongjianshou_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220004,
		},
	},
	DialogList = {
		{
			{
				Text = "原来如此……",
				Position = 1,
			},
		},
		{
			{
				Text = "懂了，遇到人形怪物就要踢他两腿中间！",
				Position = 1,
			},
		},
		{
			{
				Text = "如果敌人按照6米每秒的速度朝正前方奔跑的话……",
				Position = 1,
			},
			{
				Text = "假设箭的速度是50米每秒……",
				Position = 1,
			},
			{
				Text = "我们之间的距离有200米左右……",
				Position = 1,
			},
			{
				Text = "那么请问——",
				Position = 1,
			},
			{
				Text = "——敌人被射中之后会有多疼呢？",
				Position = 1,
			},
		},
		{
			{
				Text = "点暴击！暴击流天下第一！",
				Position = 1,
			},
		},
		{
			{
				Text = "啊，眼睛有点累……该做眼保健操了……",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Rpg_16_lieren_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220005,
		},
	},
	DialogList = {
		{
			{
				Text = "我们别去危险的地方吧？",
				Position = 1,
			},
		},
		{
			{
				Text = "到点了，要吃药了……",
				Position = 1,
			},
		},
		{
			{
				Text = "如果子弹的速度是100米每秒……",
				Position = 1,
			},
			{
				Text = "猎枪有3发子弹……",
				Position = 1,
			},
			{
				Text = "杀死一只兔子需要2发子弹的话，那么——",
				Position = 1,
			},
			{
				Text = "——呜呜好残忍……说不下去了……",
				Position = 1,
			},
		},
		{
			{
				Text = "还、还是加一点回避吧……",
				Position = 1,
			},
		},
		{
			{
				Text = "第一节……闭目入静……",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Rpg_26_huoqiangshou_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220019,
		},
	},
	DialogList = {
		{
			{
				Text = "这块脏东西擦不掉诶…",
				Position = 1,
			},
			{
				Text = "哈口气试一试~",
				Position = 1,
			},
		},
		{
			{
				Text = "我要出圣剑！我要抢人头！",
				Position = 1,
			},
		},
		{
			{
				Text = "来局试胆游戏？剩6颗子弹，你先来吧。",
				Position = 1,
			},
		},
		{
			{
				Text = "这么擦枪，不会走走火了吧——",
				Position = 1,
			},
			{
				Text = "磅！——哎哟！吓死我了！",
				Position = 1,
			},
		},
		{
			{
				Text = "偶尔也想试试冷兵器呢……",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Rpg_08_cike_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220020,
		},
	},
	DialogList = {
		{
			{
				Text = "♪~~♪~",
				Position = 1,
			},
			{
				Text = "一时兴起……",
				Position = 1,
			},
		},
		{
			{
				Text = "无聊……",
				Position = 1,
			},
		},
		{
			{
				Text = "……从前有一位少年。",
				Position = 1,
			},
			{
				Text = "他从小就没有双亲……因为过于孤僻而被村人排斥……",
				Position = 1,
			},
			{
				Text = "直到有一天……他从怪物手中保护了村民……但还是受了很重的伤……",
				Position = 1,
			},
			{
				Text = "最终还是……",
				Position = 1,
			},
			{
				Text = "……童话故事听够了吗？别吵我了。",
				Position = 1,
			},
		},
		{
			{
				Text = "……从前有一个少年。",
				Position = 1,
			},
			{
				Text = "他……什么，这段讲过了？",
				Position = 1,
			},
			{
				Text = "……原来我说过这么多话么。",
				Position = 1,
			},
		},
		{
			{
				Text = "……所以。",
				Position = 1,
			},
			{
				Text = "你认为那个故事的结局……会是怎样的呢？",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Rpg_06_mofashi_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220010,
		},
	},
	DialogList = {
		{
			{
				Text = "好吵啊…",
				Position = 1,
			},
			{
				Text = "好想用沉默魔法…",
				Position = 1,
			},
		},
		{
			{
				Text = "那个笨蛋……",
				Position = 1,
			},
		},
		{
			{
				Text = "有点吵闹呢……用静寂魔法的话……",
				Position = 1,
			},
			{
				Text = "……",
				Position = 1,
			},
			{
				Text = "……",
				Position = 1,
			},
			{
				Text = "……",
				Position = 1,
			},
			{
				Text = "……啊，忘了给自己解除了。",
				Position = 1,
			},
		},
		{
			{
				Text = "如果在这里……修正这个公式……",
				Position = 1,
			},
			{
				Text = "但这样后面的结果会有矛盾……",
				Position = 1,
			},
			{
				Text = "……啊，原来是算错了。",
				Position = 1,
			},
		},
		{
			{
				Text = "Arcan……Alte Weisheit……",
				Position = 1,
			},
			{
				Text = "Das Feuer, das die Welt schafft……",
				Position = 1,
			},
			{
				Text = "……需要翻译一下吗？",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Rpg_07_mushi_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220021,
		},
	},
	DialogList = {
		{
			{
				Text = "我也会努力的~",
				Position = 1,
			},
		},
		{
			{
				Text = "治疗人员不能拉到仇恨……原来如此……",
				Position = 1,
			},
		},
		{
			{
				Text = "要注意不能奶到怪物身上……嗯嗯……",
				Position = 1,
			},
		},
		{
			{
				Text = "咦！？这是谁的……情书……",
				Position = 1,
			},
			{
				Text = "……",
				Position = 1,
			},
		},
		{
			{
				Text = "要不要转职成暗牧呢……？",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Rpg_03_yuanhuameizi_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220025,
		},
	},
	DialogList = {
		{
			{
				Text = "咦？感觉不太对的样子…",
				Position = 1,
			},
		},
		{
			{
				Text = "构图是不是错了……？",
				Position = 1,
			},
		},
		{
			{
				Text = "别看啦，你看着我画不出来啦！",
				Position = 1,
			},
		},
		{
			{
				Text = "这个重合度……",
				Position = 1,
			},
			{
				Text = "这是描图！这是抄袭！",
				Position = 1,
			},
		},
		{
			{
				Text = "这个地方的透视到底要怎么搞啊！！！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Rpg_21_nvwangdaren_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220028,
		},
	},
	DialogList = {
		{
			{
				Text = "旺财！来，自己坐好~",
				Position = 1,
			},
			{
				Text = "哇~旺财好棒~",
				Position = 1,
			},
		},
		{
			{
				Text = "旺财，明天去打狂犬疫苗好不好？",
				Position = 1,
			},
			{
				Text = "不疼的~",
				Position = 1,
			},
		},
		{
			{
				Text = "旺财，上次的牛排好吃吗？",
				Position = 1,
			},
		},
		{
			{
				Text = "这么不听话！今晚只有4A级牛排吃了！",
				Position = 1,
			},
		},
		{
			{
				Text = "茁壮成长吧，我的小宝贝~你可比那些男人们好多了~",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Rpg_17_chengzhenweibing_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220014,
		},
	},
	DialogList = {
		{
			{
				Text = "终于抓到鱼了！",
				Position = 1,
			},
			{
				Text = "不，不是摸鱼，是捉鱼！",
				Position = 1,
			},
		},
		{
			{
				Text = "能钓上个宝箱就可以提前退休了……",
				Position = 1,
			},
			{
				Text = "会不会有人把金子藏在池塘里呢？",
				Position = 1,
			},
		},
		{
			{
				Text = "大鱼吃小鱼，我吃大鱼~",
				Position = 1,
			},
		},
		{
			{
				Text = "鱼，好大的鱼，虎纹鲨鱼~",
				Position = 1,
			},
		},
		{
			{
				Text = "等我钓上来这条鱼，就回去工作！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Rpg_27_donghua_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220022,
		},
	},
	DialogList = {
		{
			{
				Text = "嘿嘿嘿嘿，起飞了哦！",
				Position = 1,
			},
		},
		{
			{
				Text = "不太灵活？得再加点机油…",
				Position = 1,
			},
		},
		{
			{
				Text = "还有200多个动画没做——",
				Position = 1,
			},
			{
				Text = "哎，再玩会飞机吧。",
				Position = 1,
			},
		},
		{
			{
				Text = "芜湖~起飞~",
				Position = 1,
			},
		},
		{
			{
				Text = "其实这个让飞机飞起来的动画也是我做的。",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Rpg_15_peiyinyanyuan_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220023,
		},
	},
	DialogList = {
		{
			{
				Text = "1，2，3",
				Position = 1,
			},
			{
				Text = "左边喵喵，右边喵。",
				Position = 1,
			},
			{
				Text = "小爪爪举好~",
				Position = 1,
			},
		},
		{
			{
				Text = "哼哼哼……哈哈哈哈哈——！！！",
				Position = 1,
			},
			{
				Text = "——咳咳咳！！！这么笑好累……",
				Position = 1,
			},
		},
		{
			{
				Text = "终于……你还是来到这里了吗……",
				Position = 1,
			},
			{
				Text = "我这次一定会打败你的！",
				Position = 1,
			},
			{
				Text = "呵呵……那么结果到底如何呢？",
				Position = 1,
			},
			{
				Text = "我上了……这剧本怎么回事啊！好老套！",
				Position = 1,
			},
		},
		{
			{
				Text = "自从那一夜之后……少年离开了村子……",
				Position = 1,
			},
			{
				Text = "不可思议的是……再也没有怪物来村落肆虐……",
				Position = 1,
			},
			{
				Text = "……同样的，也没有人还在村落里生活了。",
				Position = 1,
			},
			{
				Text = "嗯……这到底是什么人的剧本呢？",
				Position = 1,
			},
		},
		{
			{
				Text = "啊——今天的工作也要结束了。",
				Position = 1,
			},
			{
				Text = "要多喝水，保护喉咙~",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Rpg_18_laonainai_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220013,
		},
		LockCharacterList = {
			220012,
		},
	},
	DialogList = {
		{
			{
				Text = "死鬼又不知道去哪里了！",
				Position = 1,
			},
		},
		{
			{
				Text = "又跑出去拈花惹草！老花萝卜！",
				Position = 1,
			},
		},
		{
			{
				Text = "还一堆家务活没干呢，唉，闲不下来啊！",
				Position = 1,
			},
		},
		{
			{
				Text = "人到老了还是得经常活动一下身体啊~",
				Position = 1,
			},
		},
		{
			{
				Text = "哇，鸡蛋好像半价了！要快点去抢啊~",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Rpg_18_laonainai_2"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220013,
			220012,
		},
	},
	DialogList = {
		{
			{
				Text = "老伴别走！我再也不敢了嘛~~",
				Position = 1,
			},
			{
				Text = "不行，现在就去民政局！",
				Position = 2,
			},
			{
				Text = "再给我一个机会吧~",
				Position = 1,
			},
			{
				Text = "你别来这套！",
				Position = 2,
			},
		},
		{
			{
				Text = "老头子，你每次都骗我！",
				Position = 2,
			},
			{
				Text = "呜呜呜，我保证没有下次了——",
				Position = 1,
			},
			{
				Text = "你上次也是这么说！",
				Position = 2,
			},
		},
		{
			{
				Text = "你是拖把吗！快起来！",
				Position = 2,
			},
			{
				Text = "不嘛…你不原谅我，我就不起来……",
				Position = 1,
			},
			{
				Text = "哼！老不羞！",
				Position = 2,
			},
		},
	},
}
PlanetCharacterConfig["Rpg_28_bug_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220018,
		},
		LockCharacterList = {
			220017,
		},
	},
	DialogList = {
		{
			{
				Text = "哒哒哒哒！",
				Position = 1,
			},
		},
		{
			{
				Text = "嘻嘻，隐形装置启动！",
				Position = 1,
			},
		},
		{
			{
				Text = "我们是有职业素养的霸格！",
				Position = 1,
			},
			{
				Text = "我们只出大错！崩溃为止！",
				Position = 1,
			},
		},
		{
			{
				Text = "糟糕！除虫者来了！敌进我退！",
				Position = 1,
			},
		},
		{
			{
				Text = "这个地方居然还没有被攻陷……看我的！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Rpg_29_QA_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220017,
		},
		LockCharacterList = {
			220018,
		},
	},
	DialogList = {
		{
			{
				Text = "咦？霸格呢？",
				Position = 1,
			},
			{
				Text = "什么？又崩溃了！？",
				Position = 2,
			},
		},
		{
			{
				Text = "这些霸格！都藏到哪去！？",
				Position = 1,
			},
		},
		{
			{
				Text = "呜啊……这几个霸格要是修不好，今晚又得加班了……",
				Position = 1,
			},
		},
		{
			{
				Text = "等等……这不会进水吧……",
				Position = 1,
			},
		},
		{
			{
				Text = "……啊，拿错了！这是洗发水！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Rpg_29_QA_2"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220018,
			220017,
		},
	},
	DialogList = {
		{
			{
				Text = "哒哒哒哒！",
				Position = 1,
			},
			{
				Text = "发现目标！准备清除！",
				Position = 2,
			},
		},
		{
			{
				Text = "我们是霸格♪我们是霸格♪",
				Position = 1,
			},
			{
				Text = "正义的除虫者♪正义的除虫者♪",
				Position = 2,
			},
		},
		{
			{
				Text = "——啊！光学迷彩失灵了！！！",
				Position = 1,
			},
			{
				Text = "发现霸格！请求战略轰炸！",
				Position = 2,
			},
		},
	},
}
PlanetCharacterConfig["Rpg_30_kulou_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220006,
		},
	},
	DialogList = {
		{
			{
				Text = "能和大家组队，小的太高兴了。",
				Position = 1,
			},
		},
		{
			{
				Text = "唉哟，快散架了……",
				Position = 1,
			},
		},
		{
			{
				Text = "明天会不会长点头发出来呢……",
				Position = 1,
			},
		},
		{
			{
				Text = "小魔王大人呢……？",
				Position = 1,
			},
			{
				Text = "他点的一百个冒险者的墓碑已经做好了。",
				Position = 1,
			},
			{
				Text = "……不会在复活的CD吧……不会的！小魔王大人那么强！",
				Position = 1,
			},
		},
		{
			{
				Text = "嘿！哈！早晚有一天，小的也要当副本BOSS！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Rpg_13_dashouxiaodi_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220016,
		},
	},
	DialogList = {
		{
			{
				Text = "魔王大人！我们什么时候出发？",
				Position = 1,
			},
		},
		{
			{
				Text = "嗯……最近总有一种要长高的感觉？",
				Position = 1,
			},
		},
		{
			{
				Text = "骨头兵去给小魔王大人汇报就行了……魔王大人就由本队长来服侍！",
				Position = 1,
			},
		},
		{
			{
				Text = "狼牙棒上的牙齿有点松动了……去找骨头兵再要几颗牙好了！",
				Position = 1,
			},
		},
		{
			{
				Text = "嘿嘿~不知道什么时候才能升职成副本管理层呢~",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Rpg_11_damowang_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220029,
		},
	},
	DialogList = {
		{
			{
				Text = "不错。",
				Position = 1,
			},
		},
		{
			{
				Text = "嗯……嗯……",
				Position = 1,
			},
			{
				Text = "……好！（他刚说了什么？）",
				Position = 1,
			},
		},
		{
			{
				Text = "你这点写的不行啊，没有重点，听得人昏昏欲睡的……",
				Position = 1,
			},
		},
		{
			{
				Text = "最近掉的装备是不是太多了？有好多勇者都拿着神器来刷本。",
				Position = 1,
			},
			{
				Text = "让怪物们稍微控制一下数量啊，别那么轻易就掉装备！",
				Position = 1,
			},
		},
		{
			{
				Text = "嗯……这个问题……",
				Position = 1,
			},
			{
				Text = "跟新手村的村长交接一下吧，让他们那边想办法。",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Rpg_12_xiaomowang_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220009,
		},
	},
	DialogList = {
		{
			{
				Text = "今年业绩非常好，明年继续努力！",
				Position = 1,
			},
		},
		{
			{
				Text = "如果我们把这个地方的陷阱修得更精细一些……",
				Position = 1,
			},
		},
		{
			{
				Text = "根据数据反馈，这块区域可能需要重新评估……",
				Position = 1,
			},
		},
		{
			{
				Text = "反映有怪物们摸鱼的行为！",
				Position = 1,
			},
			{
				Text = "为了不被打的太惨，他们总是把多数的血条藏起来，只留一条在外面！",
				Position = 1,
			},
			{
				Text = "作为正规的公司，我们要杜绝这种欺诈行为！",
				Position = 1,
			},
		},
		{
			{
				Text = "最近……财政稍微有点赤字……",
				Position = 1,
			},
			{
				Text = "冒险家在副本中阵亡的情况日益减少，死亡掉落收入下降了很多……",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Rpg_14_lvxingshangren_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220015,
		},
	},
	DialogList = {
		{
			{
				Text = "新的大瓶药水~不甜不要钱。",
				Position = 1,
			},
		},
		{
			{
				Text = "屠龙宝剑，10金一把，仅拆未摆，欢迎选购。",
				Position = 1,
			},
		},
		{
			{
				Text = "银鳞胸甲，5金一件！现在购买，免费附魔！",
				Position = 1,
			},
		},
		{
			{
				Text = "货比三家，我家最好~",
				Position = 1,
			},
		},
		{
			{
				Text = "对不起，本店不支持赊账！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Fat_09_pijiu_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220104,
		},
	},
	DialogList = {
		{
			{
				Text = "女士们先生们！",
				Position = 1,
			},
			{
				Text = "很高兴为你们表演！",
				Position = 1,
			},
			{
				Text = "让我们一起再喝一杯吧~",
				Position = 1,
			},
			{
				Text = "#@！*￥#&……",
				Position = 1,
			},
		},
		{
			{
				Text = "弦乐注意！准备进和声！",
				Position = 1,
			},
		},
		{
			{
				Text = "咚擦擦、咚擦擦~",
				Position = 1,
			},
		},
		{
			{
				Text = "鼓太快了！慢一点！",
				Position = 1,
			},
		},
		{
			{
				Text = "还没完呢！别鼓掌！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Fat_28_jichi_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220129,
		},
		LockCharacterList = {
			220122,
		},
	},
	DialogList = {
		{
			{
				Text = "一二三四，\n二二三四！",
				Position = 1,
			},
		},
		{
			{
				Text = "真是美好的一天……",
				Position = 1,
			},
			{
				Text = "鸟儿在歌唱……花儿在怒放……",
				Position = 1,
			},
			{
				Text = "在这么好的天气里……像你这样的小孩应该……",
				Position = 1,
			},
			{
				Text = "……啊，我在说什么？",
				Position = 1,
			},
		},
		{
			{
				Text = "棉花糖又去哪睡觉了！？",
				Position = 1,
			},
		},
		{
			{
				Text = "呵呵……又没有邀请我去参加仪式……",
				Position = 1,
			},
		},
		{
			{
				Text = "诅咒？算了，都什么年代了，早就不流行了……",
				Position = 1,
			},
			{
				Text = "……就祝你明天水逆吧！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Fat_04_mianhuatang_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220122,
		},
		LockCharacterList = {
			220129,
		},
	},
	DialogList = {
		{
			{
				Text = "Zzz……",
				Position = 1,
			},
		},
		{
			{
				Text = "ZZZ……",
				Position = 1,
			},
		},
		{
			{
				Text = "zzz……",
				Position = 1,
			},
		},
		{
			{
				Text = "zZz……",
				Position = 1,
			},
		},
		{
			{
				Text = "ZzZ……",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Fat_04_mianhuatang_2"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220122,
			220129,
		},
	},
	DialogList = {
		{
			{
				Text = "Zzz……",
				Position = 1,
			},
			{
				Text = "咦，怎么又滑下来了？",
				Position = 2,
			},
		},
		{
			{
				Text = "Zzz……",
				Position = 1,
			},
			{
				Text = "快快睡……快快睡……",
				Position = 2,
			},
		},
		{
			{
				Text = "Zzz……",
				Position = 1,
			},
			{
				Text = "……嘻嘻，终于睡着了吗？",
				Position = 2,
			},
			{
				Text = "这下终于可以进行我的计划了",
				Position = 2,
			},
			{
				Text = "趁这小丫头睡着之际——",
				Position = 2,
			},
			{
				Text = "——往她的袜子里放圣诞礼物！哈哈哈！",
				Position = 2,
			},
		},
		{
			{
				Text = "Zzz……",
				Position = 1,
			},
			{
				Text = "……",
				Position = 2,
			},
			{
				Text = "Zzz……",
				Position = 1,
			},
			{
				Text = "……你不用非得把ZZZ读出来，大家都知道你睡着了。",
				Position = 2,
			},
			{
				Text = "……原来如此。",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Fat_11_tiantong_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220121,
		},
	},
	DialogList = {
		{
			{
				Text = "魔镜，谁是世界上最美丽的人？",
				Position = 1,
			},
			{
				Text = "当然是白…",
				Position = 2,
			},
			{
				Text = "嗯？！",
				Position = 1,
			},
			{
				Text = "是白养我这些年的皇后大人啦~",
				Position = 2,
			},
		},
		{
			{
				Text = "魔镜魔镜，谁是世界上第二美丽的人？",
				Position = 1,
			},
			{
				Text = "正是优雅的您~皇后大人。",
				Position = 2,
			},
			{
				Text = "嗯？！那第一名是谁？",
				Position = 1,
			},
			{
				Text = "诶……我只是镜子，不要问这么多吧…",
				Position = 2,
			},
		},
	},
}
PlanetCharacterConfig["Fat_08_xuebi_1"] =
{
	PreCondition = {
		LockCharacterList = {
			220102,
		},
	},
	DialogList = {
		{
			{
				Text = "还没来！等三天了！",
				Position = 1,
			},
			{
				Text = "看来今天是不会来了...",
				Position = 2,
			},
		},
		{
			{
				Text = "这已经迟到了多长时间了！？",
				Position = 1,
			},
			{
				Text = "三天零四个小时。",
				Position = 2,
			},
		},
		{
			{
				Text = "王子有这么忙吗……",
				Position = 1,
			},
			{
				Text = "据说被公主关家里跪饮料瓶了…",
				Position = 1,
			},
			{
				Text = "哇，这也太惨了！",
				Position = 1,
			},
		},
		{
			{
				Text = "你说……我们还等吗……",
				Position = 1,
			},
			{
				Text = "不等的话王子会发怒吧……？",
				Position = 2,
			},
			{
				Text = "唉……",
				Position = 1,
			},
		},
		{
			{
				Text = "……",
				Position = 1,
			},
			{
				Text = "……",
				Position = 2,
			},
		},
	},
}
PlanetCharacterConfig["Fat_08_xuebi_2"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220102,
		},
	},
	DialogList = {
		{
			{
				Text = "晶晶亮心飞扬！赶走夏天！",
				Position = 3,
			},
			{
				Text = "哇~是汽水广告吗，好想喝！",
				Position = 1,
			},
			{
				Text = "不，这次是风油精广告。",
				Position = 2,
			},
		},
		{
			{
				Text = "心动？行动吧！赶紧买！",
				Position = 3,
			},
			{
				Text = "哇，原来汽水王子大人还有如此阳光健谈的一面啊！",
				Position = 1,
			},
			{
				Text = "……拍完了。",
				Position = 3,
			},
			{
				Text = "一下就变回原状了啊！",
				Position = 2,
			},
		},
		{
			{
				Text = "王子，还要拍多久啊？",
				Position = 2,
			},
			{
				Text = "不知道。",
				Position = 3,
			},
			{
				Text = "王子王子，可以给我签个名吗？",
				Position = 1,
			},
			{
				Text = "好麻烦。",
				Position = 3,
			},
			{
				Text = "……真想把这个样子拍到镜头里。",
				Position = 2,
			},
		},
	},
}
PlanetCharacterConfig["Fat_10_naicha_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220101,
		},
	},
	DialogList = {
		{
			{
				Text = "Ok！",
				Position = 1,
			},
			{
				Text = "这个剧本很完美！",
				Position = 1,
			},
		},
		{
			{
				Text = "这个脸型……还是稍微P一下比较好。",
				Position = 1,
			},
		},
		{
			{
				Text = "再加点特效……",
				Position = 1,
			},
		},
		{
			{
				Text = "好！马上就能开拍了！",
				Position = 1,
			},
		},
		{
			{
				Text = "看看在网上的评分如何~",
				Position = 1,
			},
			{
				Text = "……怎么才这么低！？这帮人真是不懂艺术！",
				Position = 1,
			},
			{
				Text = "……",
				Position = 1,
			},
			{
				Text = "……自己刷点好评~",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Fat_31_fanqiejiang_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220128,
		},
		LockCharacterList = {
			220131,
		},
	},
	DialogList = {
		{
			{
				Text = "陛下，别闹了！快出来吧！",
				Position = 1,
			},
		},
		{
			{
				Text = "唉……陛下简直比他养的猫还难找。",
				Position = 1,
			},
		},
		{
			{
				Text = "如果你看到陛下的话，麻烦跟他说一下。",
				Position = 1,
			},
			{
				Text = "他的洗澡油已经准备好了，再等要放凉了。",
				Position = 1,
			},
		},
		{
			{
				Text = "要不造反算了……",
				Position = 1,
			},
			{
				Text = "……还是算了吧，太麻烦了。",
				Position = 1,
			},
			{
				Text = "陛下，你在哪啊——",
				Position = 1,
			},
		},
		{
			{
				Text = "等陛下回来，一定要扣他一年的工资！",
				Position = 1,
			},
			{
				Text = "……",
				Position = 1,
			},
			{
				Text = "……那这一年谁给我发工资呢？",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Fat_30_shutiao_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220131,
		},
		LockCharacterList = {
			220128,
		},
	},
	DialogList = {
		{
			{
				Text = "想摸摸我的十二块腹肌吗？",
				Position = 1,
			},
		},
		{
			{
				Text = "嘿……嘿……呼……多少个了？",
				Position = 1,
			},
			{
				Text = "哎，我的侍卫呢？怎么不在！",
				Position = 1,
			},
			{
				Text = "哎……",
				Position = 1,
			},
			{
				Text = "……你连本王都抽出来了，再加把劲把他也抽出来？",
				Position = 1,
			},
		},
		{
			{
				Text = "嗯？你问为什么本王这么强壮还需要侍卫？",
				Position = 1,
			},
			{
				Text = "因为本王要用自己的体魄激励他们锻炼身体！",
				Position = 1,
			},
			{
				Text = "……什么？你没问过?",
				Position = 1,
			},
			{
				Text = "管他呢，本王只是想说而已。",
				Position = 1,
			},
		},
		{
			{
				Text = "嗯？你问怎么才能锻炼出本王的身材?",
				Position = 1,
			},
			{
				Text = "很简单，睡眠、哑铃、纯度百分之九十五的植物油浴，缺一不可。",
				Position = 1,
			},
			{
				Text = "这样的话就能……什么？你没问过？",
				Position = 1,
			},
			{
				Text = "……就不能给本王点面子吗！",
				Position = 1,
			},
		},
		{
			{
				Text = "啊……到了泡澡时间了。",
				Position = 1,
			},
			{
				Text = "但本王的侍卫呢？本王的洗澡油呢！？",
				Position = 1,
			},
			{
				Text = "（幽怨的目光）",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Fat_30_shutiao_2"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220131,
			220128,
		},
	},
	DialogList = {
		{
			{
				Text = "已经第几个了？",
				Position = 2,
			},
			{
				Text = "啊，抱歉陛下，我忘了数了。",
				Position = 1,
			},
		},
		{
			{
				Text = "993,994,\n995,996,\n997……",
				Position = 2,
			},
			{
				Text = "陛下，您的汗蹭到我脸上了……",
				Position = 1,
			},
		},
		{
			{
				Text = "番茄酱，你也来陪本王健身吧！",
				Position = 2,
			},
			{
				Text = "容我婉拒，陛下……",
				Position = 1,
			},
			{
				Text = "连本王都比不过，你又怎么能当好侍卫呢？",
				Position = 2,
			},
			{
				Text = "请您自己保护好自己，我的职责是烧油，以及给您计数……",
				Position = 1,
			},
		},
		{
			{
				Text = "陛下，上次大臣们推荐的书单您都看了吗？",
				Position = 1,
			},
			{
				Text = "本王的头脑很好，不需要看书。",
				Position = 2,
			},
			{
				Text = "是的，陛下。",
				Position = 1,
			},
		},
		{
			{
				Text = "陛下，该泡澡了。",
				Position = 1,
			},
			{
				Text = "等等，我再练几个——",
				Position = 2,
			},
			{
				Text = "您不去的话我就进去泡了，热油不能浪费。",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Fat_25_huafubing_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220114,
		},
	},
	DialogList = {
		{
			{
				Text = "是不是快好了？",
				Position = 1,
			},
		},
		{
			{
				Text = "做的有点太多了吧。",
				Position = 1,
			},
		},
		{
			{
				Text = "等等，谁放的香菜！？",
				Position = 1,
			},
		},
		{
			{
				Text = "这……调味料加的是不是有点多了？",
				Position = 1,
			},
		},
		{
			{
				Text = "……爆米花真的是这么做的吗？",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Fat_26_tongluoshao_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220115,
		},
	},
	DialogList = {
		{
			{
				Text = "再等一会儿，就有爆米花了！",
				Position = 1,
			},
		},
		{
			{
				Text = "爆米花♪爆米花♪",
				Position = 1,
			},
		},
		{
			{
				Text = "不知道会不会有电影院来和我们合作呢？",
				Position = 1,
			},
			{
				Text = "嘿嘿……奶茶王子~",
				Position = 1,
			},
			{
				Text = "……啊，不小心放了一罐盐进去。",
				Position = 1,
			},
			{
				Text = "……应该没事吧~",
				Position = 1,
			},
		},
		{
			{
				Text = "还没好吗还没好吗？",
				Position = 1,
			},
			{
				Text = "加大点火吧！",
				Position = 1,
			},
		},
		{
			{
				Text = "呜啊……这味道有点……",
				Position = 1,
			},
			{
				Text = "……太棒了！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Fat_27_buding_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220116,
		},
	},
	DialogList = {
		{
			{
				Text = "多加点糖！",
				Position = 1,
			},
		},
		{
			{
				Text = "再来点奶油吧~",
				Position = 1,
			},
		},
		{
			{
				Text = "加点其他的佐料好像也不错！",
				Position = 1,
			},
			{
				Text = "胡椒……辣子……",
				Position = 1,
			},
			{
				Text = "再来点香菜……",
				Position = 1,
			},
		},
		{
			{
				Text = "嗯？我以前是做什么的？",
				Position = 1,
			},
			{
				Text = "我之前是厨师，在一家饭店工作~",
				Position = 1,
			},
			{
				Text = "是卖麻辣香锅的~",
				Position = 1,
			},
		},
		{
			{
				Text = "有人愿意尝尝吗？",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Fat_01_songbing_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220123,
		},
	},
	DialogList = {
		{
			{
				Text = "过马路时要注意红绿灯噢~",
				Position = 1,
			},
		},
		{
			{
				Text = "文明礼让，要让老爷爷老奶奶先走哦~",
				Position = 1,
			},
		},
		{
			{
				Text = "……红了！红了——！",
				Position = 1,
			},
			{
				Text = "……啊！不好意思……最近在炒股……",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Fat_honglvdeng1"] =
{
	DialogList = {
		{
			{
				Text = "道路千万条，\n安全第一条，\n行车不规范，\n亲人两行泪。",
				Position = 1,
			},
		},
		{
			{
				Text = "……",
				Position = 1,
			},
		},
		{
			{
				Text = "……为什么你会指望一个红绿灯说什么？",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Fat_12_xiaohong_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220105,
		},
	},
	DialogList = {
		{
			{
				Text = "最后过马路的帮大家做功课！",
				Position = 1,
			},
		},
		{
			{
				Text = "冲啊！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Fat_13_xiaocheng_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220106,
		},
	},
	DialogList = {
		{
			{
				Text = "最后过马路的把零食让给大家！",
				Position = 1,
			},
		},
		{
			{
				Text = "跑啊！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Fat_14_xiaohuang_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220107,
		},
	},
	DialogList = {
		{
			{
				Text = "最后过马路的今晚打扫寝室！",
				Position = 1,
			},
		},
		{
			{
				Text = "跳啊！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Fat_15_xiaolv_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220108,
		},
	},
	DialogList = {
		{
			{
				Text = "最后过马路的等会表演唱歌！",
				Position = 1,
			},
		},
		{
			{
				Text = "上啊！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Fat_16_xiaolan_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220109,
		},
	},
	DialogList = {
		{
			{
				Text = "最后过马路的表演后空翻！",
				Position = 1,
			},
		},
		{
			{
				Text = "快啊！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Fat_17_xiaoqing_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220110,
		},
	},
	DialogList = {
		{
			{
				Text = "最后过马路的表演倒立喝水！",
				Position = 1,
			},
		},
		{
			{
				Text = "来啊！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Fat_18_xiaozi_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220111,
		},
	},
	DialogList = {
		{
			{
				Text = "过马路的时候不要这么快啊！",
				Position = 1,
			},
		},
		{
			{
				Text = "慢点啊——！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Fat_02_dangaojuan_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220124,
		},
		LockCharacterList = {
			220125,
		},
	},
	DialogList = {
		{
			{
				Text = "咦，栗子蛋糕公主去哪儿了？",
				Position = 1,
			},
		},
		{
			{
				Text = "这块地面是不是有点脏了……",
				Position = 1,
			},
			{
				Text = "我擦擦……",
				Position = 1,
			},
			{
				Text = "我擦……我擦……",
				Position = 1,
			},
			{
				Text = "……公主不能说脏话！",
				Position = 1,
			},
		},
		{
			{
				Text = "嗯……该换个新托盘了……",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Fat_02_dangaojuan_2"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220124,
			220125,
		},
	},
	DialogList = {
		{
			{
				Text = "哇~好丝滑啊~",
				Position = 1,
			},
		},
		{
			{
				Text = "好羡慕这么柔顺的长发啊~",
				Position = 1,
			},
			{
				Text = "我的头发就只能卷起来……",
				Position = 1,
			},
		},
		{
			{
				Text = "咦？好像有脏东西……",
				Position = 1,
			},
			{
				Text = "我擦……",
				Position = 1,
			},
		},
		{
			{
				Text = "我要爱上这个手感了！",
				Position = 1,
			},
		},
		{
			{
				Text = "想要个什么发型呢？",
				Position = 1,
			},
			{
				Text = "给你扎个麻花辫吧！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Fat_03_qiaokelidan_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220125,
		},
	},
	DialogList = {
		{
			{
				Text = "今晚要和王子一起听歌剧呢，好紧张啊~",
				Position = 1,
			},
			{
				Text = "希望他不要被我的头发绊倒……",
				Position = 1,
			},
		},
		{
			{
				Text = "仔细检查人群，别放过任何一个水管工！",
				Position = 1,
			},
			{
				Text = "就是他们在我头上踩来踩去！",
				Position = 1,
			},
		},
		{
			{
				Text = "羡慕我的头发？",
				Position = 1,
			},
			{
				Text = "唉……你知道我每天要花多少功夫和奶油来打理吗？",
				Position = 1,
			},
		},
		{
			{
				Text = "快帮忙除虫！虫子们顺着奶油的香味来了！",
				Position = 1,
			},
		},
		{
			{
				Text = "唔……培根姐姐去哪了？",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Fat_23_peigen_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220119,
		},
		LockCharacterList = {
			220125,
		},
	},
	DialogList = {
		{
			{
				Text = "你看这颗栗子它又大又圆！",
				Position = 1,
			},
		},
		{
			{
				Text = "唉……看到这些栗子就又想到公主了……",
				Position = 1,
			},
			{
				Text = "……不过公主长得也不像栗子，到底为什么会联想呢？",
				Position = 1,
			},
		},
		{
			{
				Text = "我的公主……你到底在哪呢？",
				Position = 1,
			},
		},
		{
			{
				Text = "六个……七个……八个……哈哈！加到八个了！快看啊——啊……公主不在啊……",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Fat_23_peigen_2"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220119,
			220125,
		},
	},
	DialogList = {
		{
			{
				Text = "王子如果亲你，你要说，不要！",
				Position = 1,
			},
			{
				Text = "王子如果牵手，你要说，停！",
				Position = 1,
			},
		},
		{
			{
				Text = "不用再怕水管工了，公主！",
				Position = 1,
			},
			{
				Text = "他们已经被我召唤的乌龟打败了！",
				Position = 1,
			},
		},
		{
			{
				Text = "再等等啊……有点刘海还没齐……",
				Position = 1,
			},
		},
		{
			{
				Text = "如果王子敢对你不好就告诉我。",
				Position = 1,
			},
			{
				Text = "我一定会把他变成青蛙！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Fat_20_xiatiao_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220117,
		},
	},
	DialogList = {
		{
			{
				Text = "好漂亮的车啊~",
				Position = 1,
			},
		},
		{
			{
				Text = "这么漂亮的车，不知要多少钱才能买得起啊……",
				Position = 1,
			},
			{
				Text = "感觉会很贵的样子……",
				Position = 1,
			},
			{
				Text = "唉……",
				Position = 1,
			},
			{
				Text = "……只好让我妈帮我买个几辆了。",
				Position = 1,
			},
		},
		{
			{
				Text = "哇哦——！哇哦——！",
				Position = 1,
			},
			{
				Text = "……（这车到底什么时候走啊？我已经喊累了！）",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Fat_21_miaocuijiao_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220118,
		},
	},
	DialogList = {
		{
			{
				Text = "妈，我们也买新车吧~",
				Position = 1,
			},
			{
				Text = "买新车，上糖豆，3000元！",
				Position = 1,
			},
			{
				Text = "3000元♪3000元♪",
				Position = 1,
			},
		},
		{
			{
				Text = "这车一看就是高级座驾。",
				Position = 1,
			},
			{
				Text = "只有有钱人才能买得起这么高档的车！",
				Position = 1,
			},
			{
				Text = "唉……",
				Position = 1,
			},
			{
				Text = "……还好我是有钱人。",
				Position = 1,
			},
		},
		{
			{
				Text = "不知道我什么时候也能遇到自己的那位王子呢~",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Fat_19_shupian_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220120,
		},
	},
	DialogList = {
		{
			{
				Text = "我的钻戒掉进去了！有没有好心人帮帮忙啊！？",
				Position = 1,
			},
			{
				Text = "……",
				Position = 1,
			},
			{
				Text = "……算了，再买一个就是了~",
				Position = 1,
			},
		},
		{
			{
				Text = "这个池子……",
				Position = 1,
			},
			{
				Text = "……决定了，把它买下来！",
				Position = 1,
			},
		},
		{
			{
				Text = "嗯……不过买下来之后到底有什么用呢？",
				Position = 1,
			},
			{
				Text = "好像从来没思考过这个问题……",
				Position = 1,
			},
			{
				Text = "……买了就买了吧，也没什么所谓~",
				Position = 1,
			},
		},
		{
			{
				Text = "对了，用来开派对好了！",
				Position = 1,
			},
			{
				Text = "这么大个泳池，肯定很适合夏日派对！",
				Position = 1,
			},
			{
				Text = "啊，不过这样的话，还需要一片地区……",
				Position = 1,
			},
			{
				Text = "干脆把整个地方都包下来好了~",
				Position = 1,
			},
		},
		{
			{
				Text = "哎，真是朴实无华的生活啊~",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Fat_07_kele_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220103,
		},
	},
	DialogList = {
		{
			{
				Text = "各位，我的新专辑大家一定要支持啊！",
				Position = 1,
			},
		},
		{
			{
				Text = "感谢各位支持，我会更努力的！",
				Position = 1,
			},
			{
				Text = "明天我还会上新的作品，希望大家能继续购买！",
				Position = 1,
			},
			{
				Text = "连续一周都会有新作品上市！",
				Position = 1,
			},
			{
				Text = "如果可以的话，大家请努力让它们都登上榜首！",
				Position = 1,
			},
		},
		{
			{
				Text = "今年我还有32场演唱会！",
				Position = 1,
			},
		},
		{
			{
				Text = "需要签名的可以来排一下队！",
				Position = 1,
			},
			{
				Text = "……",
				Position = 1,
			},
			{
				Text = "……好吧，不排队也可以？",
				Position = 1,
			},
		},
		{
			{
				Text = "购买专辑的朋友，可以上车来和本王子同行哦~",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Fat_22_baomihua_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220130,
		},
	},
	DialogList = {
		{
			{
				Text = "我也爱你们噢，么么哒~",
				Position = 1,
			},
		},
		{
			{
				Text = "别忘了去看最近上映的大片~",
				Position = 1,
			},
			{
				Text = "有王子和公主们出演哦~",
				Position = 1,
			},
		},
		{
			{
				Text = "这是什么味道……？",
				Position = 1,
			},
			{
				Text = "……那边在干什么？",
				Position = 1,
			},
			{
				Text = "……爆米花！？",
				Position = 1,
			},
			{
				Text = "……太恐怖了。",
				Position = 1,
			},
		},
		{
			{
				Text = "……",
				Position = 1,
			},
			{
				Text = "……（保持微笑，还有人在看。）",
				Position = 1,
			},
		},
		{
			{
				Text = "……（哦？有人拍照！）",
				Position = 1,
			},
			{
				Text = "……※【摆出不经意间做出的漂亮姿势】",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Fat_05_bangbangtang_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220112,
		},
	},
	DialogList = {
		{
			{
				Text = "先生，买点棒棒糖吧！",
				Position = 1,
			},
			{
				Text = "我已经两天没有吃饭了。",
				Position = 1,
			},
		},
		{
			{
				Text = "行行好，买根棒棒糖吧。",
				Position = 1,
			},
			{
				Text = "擦一擦就可以点亮……",
				Position = 1,
			},
			{
				Text = "……啊，说错了。",
				Position = 1,
			},
		},
		{
			{
				Text = "太饿了……坚持不住了……",
				Position = 1,
			},
			{
				Text = "吃一根棒棒糖吧……就一根……",
				Position = 1,
			},
		},
		{
			{
				Text = "——哇！是食物！",
				Position = 1,
			},
			{
				Text = "烤鸡、派、蛋糕——",
				Position = 1,
			},
			{
				Text = "——呸呸呸！棒棒糖味的！",
				Position = 1,
			},
		},
		{
			{
				Text = "再来一根——！",
				Position = 1,
			},
			{
				Text = "啊——！是奶奶——！",
				Position = 1,
			},
			{
				Text = "呜呜呜……奶奶……我……",
				Position = 1,
			},
			{
				Text = "……我吃完这根会刷牙的！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Fat_06_kafei_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220113,
		},
	},
	DialogList = {
		{
			{
				Text = "先生，橙味咖啡试试看吗？",
				Position = 1,
			},
			{
				Text = "不喝的话，扫码加个好友吧？",
				Position = 1,
			},
		},
		{
			{
				Text = "小罐咖啡了解一下~",
				Position = 1,
			},
			{
				Text = "送朋友送亲人的不二之选！",
				Position = 1,
			},
		},
		{
			{
				Text = "尝尝咖啡吧，啥味的都有~",
				Position = 1,
			},
			{
				Text = "百分百健康，绝对不含咖啡因！",
				Position = 1,
			},
		},
		{
			{
				Text = "特价咖啡酬宾！买就送咖啡杯！",
				Position = 1,
			},
		},
		{
			{
				Text = "进口猫屎咖啡！",
				Position = 1,
			},
			{
				Text = "百分百猫屎！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Fat_24_regou_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220127,
		},
		LockCharacterList = {
			220126,
		},
	},
	DialogList = {
		{
			{
				Text = "我只是在等待。",
				Position = 1,
			},
			{
				Text = "等待你的爱。",
				Position = 1,
			},
		},
		{
			{
				Text = "唔……今天的发型没问题吧？",
				Position = 1,
			},
		},
		{
			{
				Text = "好漂亮的车啊……要是我也买得起……",
				Position = 1,
			},
		},
		{
			{
				Text = "天气有点冷了……该多抹点芥末了。",
				Position = 1,
			},
			{
				Text = "不知道她带没带够辣椒酱呢？",
				Position = 1,
			},
		},
		{
			{
				Text = "还没来啊……",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Fat_24_regou_2"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220127,
			220126,
		},
	},
	DialogList = {
		{
			{
				Text = "你最近一定是变胖了，在我心的分量都变重了。",
				Position = 2,
			},
			{
				Text = "我变胖是因为每天都在“吃吃”地想你啊~",
				Position = 1,
			},
			{
				Text = "啊，是这样吗？",
				Position = 2,
			},
		},
		{
			{
				Text = "热狗！我们好像挡住马路了！",
				Position = 1,
			},
			{
				Text = "哎呀，我没注意……因为我的心里只有你~",
				Position = 2,
			},
			{
				Text = "热狗~❤~",
				Position = 1,
			},
			{
				Text = "汉堡~❤~",
				Position = 2,
			},
		},
		{
			{
				Text = "哇，好大的风……你冷不冷？",
				Position = 2,
			},
			{
				Text = "你在我身边呢，不冷！",
				Position = 1,
			},
			{
				Text = "嘻嘻~",
				Position = 2,
			},
		},
		{
			{
				Text = "晚餐我们去哪里吃？",
				Position = 1,
			},
			{
				Text = "有你在身边吃什么都是甜的~",
				Position = 2,
			},
			{
				Text = "哎呀~",
				Position = 1,
			},
		},
		{
			{
				Text = "啊，又要分别了……好伤心……",
				Position = 2,
			},
			{
				Text = "和你分开的每一天我都度日如年……",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Fat_29_hanbao_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220126,
		},
		LockCharacterList = {
			220127,
		},
	},
	DialogList = {
		{
			{
				Text = "爱，真的需要勇气♪",
				Position = 1,
			},
			{
				Text = "去相信会在一起♪",
				Position = 1,
			},
		},
		{
			{
				Text = "想要问问你敢不敢♪",
				Position = 1,
			},
			{
				Text = "像你说的那样爱我♪",
				Position = 1,
			},
		},
		{
			{
				Text = "后来♪",
				Position = 1,
			},
			{
				Text = "我总算学会了如何去爱♪",
				Position = 1,
			},
		},
		{
			{
				Text = "啊——♪",
				Position = 1,
			},
			{
				Text = "想你的三百六十五天♪",
				Position = 1,
			},
		},
		{
			{
				Text = "你问我爱你有多深♪",
				Position = 1,
			},
			{
				Text = "我爱你有几分♪",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Fat_32_baiseqiaokeli_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223081,
		},
	},
	DialogList = {
		{
			{
				Text = "世界上最遥远的距离，不是生与死。",
				Position = 1,
			},
			{
				Text = "而是两人近在咫尺，Ta却不知道你爱Ta。",
				Position = 1,
			},
		},
		{
			{
				Text = "想要抱紧Ta，但是没有勇气？",
				Position = 1,
			},
			{
				Text = "只要购买酒心巧克力，一块就让你勇敢起来！",
				Position = 1,
			},
		},
		{
			{
				Text = "暗恋就是——",
				Position = 1,
			},
			{
				Text = "你或许不知道，我已属于你。",
				Position = 1,
			},
		},
		{
			{
				Text = "你知道吗？",
				Position = 1,
			},
			{
				Text = "狗尾巴草的花语是暗恋噢~",
				Position = 1,
			},
		},
		{
			{
				Text = "有人说暗恋是美丽的哑剧。",
				Position = 1,
			},
			{
				Text = "说出来或许就成为悲剧。",
				Position = 1,
			},
			{
				Text = "但是美好的爱情总是需要有人鼓起勇气的！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Fat_101_Brandy_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223108,
		},
		LockCharacterList = {
			220102,
		},
	},
	DialogList = {
		{
			{
				Text = "加一勺温馨的回忆。",
				Position = 1,
			},
			{
				Text = "再加一点甜蜜的空气。",
				Position = 1,
			},
			{
				Text = "这杯“热情似火”就完成了。",
				Position = 1,
			},
		},
		{
			{
				Text = "Bonjour~",
				Position = 1,
			},
			{
				Text = "Oh~这个星球，空气的味道……",
				Position = 1,
			},
			{
				Text = "宛如糖果一般甜蜜。",
				Position = 1,
			},
		},
		{
			{
				Text = "这杯酒还缺了什么。",
				Position = 1,
			},
			{
				Text = "缺了美丽的气泡。",
				Position = 1,
			},
			{
				Text = "缺了爱与罗曼蒂克。",
				Position = 1,
			},
			{
				Text = "还缺了……我心里的秘密。",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Fat_101_Brandy_2"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223108,
			220102,
		},
	},
	DialogList = {
		{
			{
				Text = "他在看我……",
				Position = 1,
			},
			{
				Text = "您好，请别戳我了。",
				Position = 1,
			},
			{
				Text = "我在看那边的风景。",
				Position = 1,
			},
		},
		{
			{
				Text = "这柠檬一般的清香……",
				Position = 1,
			},
			{
				Text = "热情又浪漫的气泡……",
				Position = 1,
			},
			{
				Text = "多么适合，加进我醇香的酒里。",
				Position = 1,
			},
		},
		{
			{
				Text = "Cheers~",
				Position = 1,
			},
			{
				Text = "没有人抗拒醇酒的美味。",
				Position = 1,
			},
			{
				Text = "来吧，为美人与月色干杯~",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["MUS_01_Anubis_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220223,
		},
	},
	DialogList = {
		{
			{
				Text = "不是说要1：1比例还原吗？",
				Position = 1,
			},
		},
		{
			{
				Text = "这个会磕脑袋吧……",
				Position = 1,
			},
		},
		{
			{
				Text = "有点歪了？",
				Position = 1,
			},
		},
		{
			{
				Text = "你们到底是怎么做比例尺的……",
				Position = 1,
			},
		},
		{
			{
				Text = "……能不能退货啊？",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["MUS_02_Horus_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220222,
		},
	},
	DialogList = {
		{
			{
				Text = "好像有点松了，再压压实。",
				Position = 1,
			},
		},
		{
			{
				Text = "不行，沙子还是太松了……",
				Position = 1,
			},
			{
				Text = "谁来撒泡尿？",
				Position = 1,
			},
		},
		{
			{
				Text = "这个大小……能把法老放进去吗？",
				Position = 1,
			},
		},
		{
			{
				Text = "我们再捏一个大一点的吧！",
				Position = 1,
			},
		},
		{
			{
				Text = "下次多带点沙子来。",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["MUS_03_Set_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220220,
		},
	},
	DialogList = {
		{
			{
				Text = "嗯，样子是已经很像了。",
				Position = 1,
			},
			{
				Text = "不过好像不太稳？",
				Position = 1,
			},
		},
		{
			{
				Text = "不应该啊？我平时做模型的时候就这个比例啊……",
				Position = 1,
			},
			{
				Text = "啊……原来不是模型吗？",
				Position = 1,
			},
		},
		{
			{
				Text = "嗯……不管怎么说，至少我们做的很……",
				Position = 1,
			},
			{
				Text = "……还原？",
				Position = 1,
			},
		},
		{
			{
				Text = "嗯……上热熔胶试试……",
				Position = 1,
			},
		},
		{
			{
				Text = "赶紧拼完吧……还有一堆没拼的呢。",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["MUS_04_Sobek_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220221,
		},
	},
	DialogList = {
		{
			{
				Text = "唔，再喷点水，这样就牢固了。",
				Position = 1,
			},
		},
		{
			{
				Text = "已经造成这样了，也没办法了。",
				Position = 1,
			},
		},
		{
			{
				Text = "如果倒过来放会不会好点？",
				Position = 1,
			},
		},
		{
			{
				Text = "除了稍微小一点，其他都很完美啊！",
				Position = 1,
			},
		},
		{
			{
				Text = "啊……我不想再重做了！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["MUS_05_munaiyi_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220217,
		},
	},
	DialogList = {
		{
			{
				Text = "脚麻了……",
				Position = 1,
			},
		},
		{
			{
				Text = "这漫画真有趣……",
				Position = 1,
			},
		},
		{
			{
				Text = "啊——完了！没带纸！",
				Position = 1,
			},
			{
				Text = "……",
				Position = 1,
			},
			{
				Text = "……那个，背过去一下，谢谢。",
				Position = 1,
			},
			{
				Text = "我脱下衣服……",
				Position = 1,
			},
		},
		{
			{
				Text = "嗯……到底为什么户外会有马桶呢？",
				Position = 1,
			},
			{
				Text = "现代人的思想真是让人无法理解啊。",
				Position = 1,
			},
		},
		{
			{
				Text = "听说人坐在马桶上时会思考很多问题。",
				Position = 1,
			},
			{
				Text = "……",
				Position = 1,
			},
			{
				Text = "……这个世界的本源到底是什么？",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["MUS_14_erge_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220204,
		},
	},
	DialogList = {
		{
			{
				Text = "叽？怎么不像？",
				Position = 1,
			},
		},
		{
			{
				Text = "怪了……我看大家都是这么画的……",
				Position = 1,
			},
		},
		{
			{
				Text = "叽叽！都是一支笔一只手，怎么我画的就这么丑！",
				Position = 1,
			},
		},
		{
			{
				Text = "我的才能……怎么会……",
				Position = 1,
			},
		},
		{
			{
				Text = "我懂了叽！是原作的问题！",
				Position = 1,
			},
			{
				Text = "都怪原画水平不够！我才没法临摹！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["MUS_15_xiaodi_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220205,
		},
	},
	DialogList = {
		{
			{
				Text = "这个可以当暑假日记的配图叽~",
				Position = 1,
			},
		},
		{
			{
				Text = "没有天赋就不要学人家画画叽！",
				Position = 1,
			},
		},
		{
			{
				Text = "二哥你试试拿脚画画吧，也许比现在画的好！",
				Position = 1,
			},
		},
		{
			{
				Text = "叽叽，二哥，这就是抽象派吗？",
				Position = 1,
			},
		},
		{
			{
				Text = "不知道大哥画得怎么样……",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["MUS_30_Napoleon_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220229,
		},
	},
	DialogList = {
		{
			{
				Text = "摇啊摇，摇到凯旋门~",
				Position = 1,
			},
		},
		{
			{
				Text = "前进！征服！",
				Position = 1,
			},
		},
		{
			{
				Text = "谁说我只有一米六的！？",
				Position = 1,
			},
		},
		{
			{
				Text = "巴黎！",
				Position = 1,
			},
			{
				Text = "比利时！",
				Position = 1,
			},
			{
				Text = "林尼！",
				Position = 1,
			},
			{
				Text = "——哦，滑铁卢……",
				Position = 1,
			},
		},
		{
			{
				Text = "总有军队将领会在我面前祈祷。",
				Position = 1,
			},
			{
				Text = "或是祈求我领导他们取得怎样的功绩。",
				Position = 1,
			},
			{
				Text = "嘿，对此我其实挺无奈的……",
				Position = 1,
			},
			{
				Text = "毕竟我只是个蜡像啊。",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["MUS_08_fangao_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220224,
		},
	},
	DialogList = {
		{
			{
				Text = "哇，灵感来了！",
				Position = 1,
			},
		},
		{
			{
				Text = "……在哪？",
				Position = 1,
			},
			{
				Text = "他到底在哪！？",
				Position = 1,
			},
			{
				Text = "我看到了、我看到了——！",
				Position = 1,
			},
			{
				Text = "——哦，原来是我自己……",
				Position = 1,
			},
		},
		{
			{
				Text = "我的精神状态极佳。",
				Position = 1,
			},
			{
				Text = "你无需害怕，也无需躲藏。",
				Position = 1,
			},
			{
				Text = "我说过了——不用害怕。",
				Position = 1,
			},
		},
		{
			{
				Text = "听说……在遥远的星球……",
				Position = 1,
			},
			{
				Text = "有一位独耳的琴师……",
				Position = 1,
			},
			{
				Text = "……真是有趣。",
				Position = 1,
			},
		},
		{
			{
				Text = "何时还能再见……",
				Position = 1,
			},
			{
				Text = "那位……搏斗的天使……？",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["MUS_29_folida_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220225,
		},
	},
	DialogList = {
		{
			{
				Text = "哎，没灵感...",
				Position = 1,
			},
		},
		{
			{
				Text = "无数人想要演绎我的一生，而我这一生只扮演我自己。",
				Position = 1,
			},
		},
		{
			{
				Text = "打击？哈，怎么会！",
				Position = 1,
			},
			{
				Text = "才这点小事，根本算不上什么。",
				Position = 1,
			},
			{
				Text = "相信我，如果你被电车撞碎过，你也会这么想。",
				Position = 1,
			},
		},
		{
			{
				Text = "有时你不该过于相信自己的眼睛。",
				Position = 1,
			},
			{
				Text = "也不该寄希望于那些既定好的规则。",
				Position = 1,
			},
			{
				Text = "比方说——你能看出我的性别吗？",
				Position = 1,
			},
		},
		{
			{
				Text = "到头来，所有的东西都会逝去……",
				Position = 1,
			},
			{
				Text = "……唯有艺术永存。",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["MUS_22_yadang_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220210,
		},
	},
	DialogList = {
		{
			{
				Text = "哇~~苹果树发芽了~",
				Position = 1,
			},
		},
		{
			{
				Text = "再看个十几年它就能长大了吧~",
				Position = 1,
			},
		},
		{
			{
				Text = "不知道我的另一半在哪里呢~",
				Position = 1,
			},
		},
		{
			{
				Text = "等它结果了，我也想尝尝！",
				Position = 1,
			},
		},
		{
			{
				Text = "快点长大吧~",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["MUS_23_chuangzaozhishen_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220211,
		},
	},
	DialogList = {
		{
			{
				Text = "咦，是不是少了点什么？",
				Position = 1,
			},
		},
		{
			{
				Text = "耐心点，还需要时间。",
				Position = 1,
			},
		},
		{
			{
				Text = "等到它成熟了，我就给你找个老婆！",
				Position = 1,
			},
		},
		{
			{
				Text = "记住，不准吃树上的果实！",
				Position = 1,
			},
		},
		{
			{
				Text = "好了……还该创造点什么呢？",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["MUS_17_zhentanxiaojie_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220202,
		},
	},
	DialogList = {
		{
			{
				Text = "我躲着大家看不到我吧？",
				Position = 1,
			},
		},
		{
			{
				Text = "我是根柱子……我是根柱子……",
				Position = 1,
			},
		},
		{
			{
				Text = "他们到底在说什么呢……",
				Position = 1,
			},
			{
				Text = "太远了，什么都听不到……",
				Position = 1,
			},
		},
		{
			{
				Text = "哼哼……这下被我抓住把柄了吧！",
				Position = 1,
			},
		},
		{
			{
				Text = "把内容都记下来……回来写在小说里……",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["MUS_09_ribenwushi_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220228,
		},
	},
	DialogList = {
		{
			{
				Text = "馆长说，大家努力工作，年终就去外星旅游~",
				Position = 1,
			},
		},
		{
			{
				Text = "捨——名——智——！",
				Position = 1,
			},
		},
		{
			{
				Text = "Lock On！Soiya！Kachidoki Arms！",
				Position = 1,
			},
		},
		{
			{
				Text = "二天一流——！",
				Position = 1,
			},
		},
		{
			{
				Text = "身可死——武士之名不可夺！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["MUS_18_zhenzhuerhuan_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220218,
		},
	},
	DialogList = {
		{
			{
				Text = "哇~~亮闪闪~",
				Position = 1,
			},
		},
		{
			{
				Text = "一个、两个、三个……",
				Position = 1,
			},
		},
		{
			{
				Text = "能不能全戴在耳朵上呢~",
				Position = 1,
			},
		},
		{
			{
				Text = "嘻嘻，给姐妹们也分一点~",
				Position = 1,
			},
		},
		{
			{
				Text = "kira~kira~",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["MUS_20_zhutigudong_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220219,
		},
		LockCharacterList = {
			220218,
		},
	},
	DialogList = {
		{
			{
				Text = "她应该会喜欢这个礼物吧？",
				Position = 1,
			},
		},
		{
			{
				Text = "这可是我抓了一百多个蚌才凑齐的……",
				Position = 1,
			},
		},
		{
			{
				Text = "哇——眼睛要被闪瞎了！",
				Position = 1,
			},
		},
		{
			{
				Text = "怎么还不来呢……",
				Position = 1,
			},
		},
		{
			{
				Text = "好紧张啊……",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["MUS_20_zhutigudong_2"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220219,
			220218,
		},
	},
	DialogList = {
		{
			{
				Text = "嘻嘻，你喜欢就好。",
				Position = 1,
			},
		},
		{
			{
				Text = "你笑起来就像蒙娜丽莎……",
				Position = 1,
			},
		},
		{
			{
				Text = "还、还有更多呢！喜欢的话全都给你！",
				Position = 1,
			},
		},
		{
			{
				Text = "嘿嘿……别客气~",
				Position = 1,
			},
		},
		{
			{
				Text = "真可爱啊……",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["MUS_28_kuqidenvren_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220212,
		},
	},
	DialogList = {
		{
			{
				Text = "呜呜呜呜——",
				Position = 1,
			},
			{
				Text = "呜哇————",
				Position = 1,
			},
		},
		{
			{
				Text = "呜呜呜呜呜呜——",
				Position = 1,
			},
		},
		{
			{
				Text = "呜呜——",
				Position = 1,
			},
		},
		{
			{
				Text = "呜呜呜呜呜——",
				Position = 1,
			},
		},
		{
			{
				Text = "呜呜……",
				Position = 1,
			},
			{
				Text = "……你在期待我说什么别的？",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["MUS_13_dage_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220203,
		},
	},
	DialogList = {
		{
			{
				Text = "追上我，就让你嘿嘿嘿~",
				Position = 1,
			},
		},
		{
			{
				Text = "溜了溜了~",
				Position = 1,
			},
		},
		{
			{
				Text = "叽叽！兄弟们呢？准备跑路了！",
				Position = 1,
			},
		},
		{
			{
				Text = "暮威慈畏荒井久間——",
				Position = 1,
			},
		},
		{
			{
				Text = "天上天下唯我独尊！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["MUS_27_baoan_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220201,
			220203,
		},
	},
	DialogList = {
		{
			{
				Text = "别跑啦！！我们歇会儿再跑吧。",
				Position = 1,
			},
		},
		{
			{
				Text = "不要一边跑步一边说话！会岔气的！",
				Position = 1,
			},
		},
		{
			{
				Text = "小心别摔倒了——！",
				Position = 1,
			},
		},
		{
			{
				Text = "咳咳——！咳咳咳——！",
				Position = 1,
			},
		},
		{
			{
				Text = "等、等等我啊……",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["MUS_27_baoan_2"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220201,
		},
		LockCharacterList = {
			220203,
		},
	},
	DialogList = {
		{
			{
				Text = "好困…… ",
				Position = 1,
			},
		},
		{
			{
				Text = "有没有问题啊？没有就都去睡觉吧~",
				Position = 1,
			},
		},
		{
			{
				Text = "要熄灯了——",
				Position = 1,
			},
		},
		{
			{
				Text = "有没有人丢了东西——？",
				Position = 1,
			},
			{
				Text = "我这里有穿过的袜子和内裤——",
				Position = 1,
			},
			{
				Text = "请丢了的人来这里认领——",
				Position = 1,
			},
		},
		{
			{
				Text = "早点休息了——明天还要上班的——",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["MUS_21_mengnalisha_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220226,
		},
		LockCharacterList = {
			220227,
		},
	},
	DialogList = {
		{
			{
				Text = "他会来、他不会来、他会来……",
				Position = 1,
			},
		},
		{
			{
				Text = "他喜欢我、他不喜欢我、他喜欢我……",
				Position = 1,
			},
		},
		{
			{
				Text = "他会注意我、他不会注意我、他会注意我……",
				Position = 1,
			},
		},
		{
			{
				Text = "今晚会顺利、今晚不会顺利、今晚会顺利……",
				Position = 1,
			},
		},
		{
			{
				Text = "……撕花瓣还挺好玩的。",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["MUS_16_yelifushentou_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220227,
		},
		LockCharacterList = {
			220226,
		},
	},
	DialogList = {
		{
			{
				Text = "我来变个兔子！",
				Position = 1,
			},
		},
		{
			{
				Text = "小白兔，白又白~",
				Position = 1,
			},
		},
		{
			{
				Text = "什么？变个别的？",
				Position = 1,
			},
			{
				Text = "不行，因为动画只做了兔子。",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["MUS_16_yelifushentou_2"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220227,
			220226,
		},
	},
	DialogList = {
		{
			{
				Text = "1、2、3，玫瑰！",
				Position = 2,
			},
			{
				Text = "哇——好棒哦！",
				Position = 1,
			},
		},
		{
			{
				Text = "你的兔子呢？",
				Position = 1,
			},
			{
				Text = "兔子没了……你出现后我的世界都是鲜花……",
				Position = 2,
			},
			{
				Text = "啊，其实我也喜欢兔子~",
				Position = 1,
			},
		},
		{
			{
				Text = "再多来点！好漂亮啊！",
				Position = 1,
			},
			{
				Text = "可是，再美的鲜花，也比不上你的笑颜。",
				Position = 2,
			},
		},
		{
			{
				Text = "花好月圆~",
				Position = 1,
			},
			{
				Text = "月色真美~",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["MUS_25_yuanshirenmama_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220215,
		},
	},
	DialogList = {
		{
			{
				Text = "马上就能吃了。",
				Position = 1,
			},
		},
		{
			{
				Text = "我煮的是什么？",
				Position = 1,
			},
			{
				Text = "嗯……时间太久了，我也记不清了。",
				Position = 1,
			},
			{
				Text = "反正是能吃的东西……",
				Position = 1,
			},
			{
				Text = "……吧？",
				Position = 1,
			},
		},
		{
			{
				Text = "孩子他爸呢？回来吃饭了！",
				Position = 1,
			},
			{
				Text = "老小都这么不让人省心……唉！",
				Position = 1,
			},
		},
		{
			{
				Text = "一天就知道在外面疯跑……",
				Position = 1,
			},
		},
		{
			{
				Text = "再不吃就凉了！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["MUS_24_yuanshirenbaba_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220214,
		},
	},
	DialogList = {
		{
			{
				Text = "不知道锅子底的私房钱有没有被发现……",
				Position = 1,
			},
		},
		{
			{
				Text = "快跑啊！！！我不要回家吃饭——！！！",
				Position = 1,
			},
		},
		{
			{
				Text = "那个味道——",
				Position = 1,
			},
			{
				Text = "——太恐怖了！",
				Position = 1,
			},
		},
		{
			{
				Text = "儿子呢——快回去吃你妈做的饭啊！",
				Position = 1,
			},
			{
				Text = "多吃点！别剩下！",
				Position = 1,
			},
		},
		{
			{
				Text = "哈……我的老腰……累死了……",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["MUS_26_yuanshirenerzi_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220216,
		},
	},
	DialogList = {
		{
			{
				Text = "哇~打猎去啦！",
				Position = 1,
			},
		},
		{
			{
				Text = "爸爸呢——我来啦——！！！",
				Position = 1,
			},
		},
		{
			{
				Text = "*&%*#@%#——！",
				Position = 1,
			},
			{
				Text = "——啊，忘了不能说方言。",
				Position = 1,
			},
		},
		{
			{
				Text = "好饿啊——再玩一会就回家啦——",
				Position = 1,
			},
		},
		{
			{
				Text = "噶噢噢噢——！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["MUS_19_nahan_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220213,
		},
	},
	DialogList = {
		{
			{
				Text = "啊啊啊啊——",
				Position = 1,
			},
			{
				Text = "啊啊……咳咳……咳……咳",
				Position = 1,
			},
		},
		{
			{
				Text = "啊啊啊——！！！",
				Position = 1,
			},
		},
		{
			{
				Text = "贾君鹏——！！！",
				Position = 1,
			},
			{
				Text = "你妈喊你回家吃饭——！！！",
				Position = 1,
			},
		},
		{
			{
				Text = "张士超——！！！",
				Position = 1,
			},
			{
				Text = "你到底把我家钥匙放哪里了——！！！",
				Position = 1,
			},
		},
		{
			{
				Text = "变了啊啊啊啊啊啊——！！！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["MUS_06_bingmayong_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220207,
		},
	},
	DialogList = {
		{
			{
				Text = "在下先干为敬，诸位好汉随意！",
				Position = 1,
			},
		},
		{
			{
				Text = "你怎么知道我能点！？",
				Position = 1,
			},
		},
		{
			{
				Text = "大家都是石头，应该很有共同语言吧？",
				Position = 1,
			},
		},
		{
			{
				Text = "唉，好想家乡的弟兄……",
				Position = 1,
			},
		},
		{
			{
				Text = "哦哦！你长得和我兄弟好像！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["MUS_11_banrenma_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220209,
		},
	},
	DialogList = {
		{
			{
				Text = "Cheers!",
				Position = 1,
			},
		},
		{
			{
				Text = "Exposed！！！",
				Position = 1,
			},
		},
		{
			{
				Text = "Have a good time my friends!",
				Position = 1,
			},
		},
		{
			{
				Text = "Long time no see!",
				Position = 1,
			},
		},
		{
			{
				Text = "Drink!",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["MUS_07_fuhuoshixiang_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220206,
		},
	},
	DialogList = {
		{
			{
				Text = "╰(￣▽￣)╮",
				Position = 1,
			},
		},
		{
			{
				Text = "∑(´△｀)？！",
				Position = 1,
			},
		},
		{
			{
				Text = "ヾ(ﾟ∀ﾟゞ)",
				Position = 1,
			},
		},
		{
			{
				Text = "ヽ(ﾟ∀ﾟ)ﾒ(ﾟ∀ﾟ)ﾉ ",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["MUS_10_shizhuren_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220208,
		},
	},
	DialogList = {
		{
			{
				Text = "Ζήτω!",
				Position = 1,
			},
		},
		{
			{
				Text = "Σοκαρισμένο!",
				Position = 1,
			},
		},
		{
			{
				Text = "Ωραία!",
				Position = 1,
			},
		},
		{
			{
				Text = "Καλέ μου φίλε!",
				Position = 1,
			},
		},
		{
			{
				Text = "Ευτυχισμένη!",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sus_25_xiaolei_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220306,
		},
	},
	DialogList = {
		{
			{
				Text = "我来啦！",
				Position = 1,
			},
		},
		{
			{
				Text = "我走啦！",
				Position = 1,
			},
		},
		{
			{
				Text = "我是姐姐！",
				Position = 1,
			},
		},
		{
			{
				Text = "我在右边！",
				Position = 1,
			},
		},
		{
			{
				Text = "我没词啦！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sus_26_xiaotong_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220307,
		},
	},
	DialogList = {
		{
			{
				Text = "我出现啦！",
				Position = 1,
			},
		},
		{
			{
				Text = "我消失啦！",
				Position = 1,
			},
		},
		{
			{
				Text = "我是妹妹！",
				Position = 1,
			},
		},
		{
			{
				Text = "我在左边！",
				Position = 1,
			},
		},
		{
			{
				Text = "我说完啦！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sus_27_xiaoai_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220308,
		},
	},
	DialogList = {
		{
			{
				Text = "你绝对无法在这么短的时间内以迅雷不及掩耳盗铃之势如破竹篮打水的这一大串长对话到底讲了是什么！",
				Position = 1,
			},
			{
				Text = "看完了！？",
				Position = 1,
			},
		},
		{
			{
				Text = "哈！你刚才点到观光团了吧！",
				Position = 1,
			},
		},
		{
			{
				Text = "天空一声巨响，姐姐闪亮登场！",
				Position = 1,
			},
		},
		{
			{
				Text = "我在中间！",
				Position = 1,
			},
		},
		{
			{
				Text = "别点了！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sus_29_kaitangshoujieke_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220321,
		},
		LockCharacterList = {
			220323,
		},
	},
	DialogList = {
		{
			{
				Text = "准备解剖了……新鲜的牛排！",
				Position = 1,
			},
		},
		{
			{
				Text = "我控制不住想要杀死你的欲望……可恨的苍蝇！",
				Position = 1,
			},
		},
		{
			{
				Text = "啊……我渴望鲜血……别再叮了！臭蚊子！",
				Position = 1,
			},
		},
		{
			{
				Text = "啊……克制不住想要犯罪的欲望……往路上丢香蕉皮！",
				Position = 1,
			},
		},
		{
			{
				Text = "这个星球……需要罪恶……",
				Position = 1,
			},
			{
				Text = "如果没人能完成这个使命……那么就由我来……",
				Position = 1,
			},
			{
				Text = "……赌上爷爷的名号！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sus_19_maikaofu_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220323,
		},
		LockCharacterList = {
			220321,
		},
	},
	DialogList = {
		{
			{
				Text = "我的傻弟弟又在耀武扬威了……",
				Position = 1,
			},
		},
		{
			{
				Text = "如果是我一定能更完美的解决案件！",
				Position = 1,
			},
		},
		{
			{
				Text = "你……是不是并不知道我到底是谁？",
				Position = 1,
			},
			{
				Text = "这也正常，毕竟大家更能记得住的是弟弟的名字……",
				Position = 1,
			},
			{
				Text = "谁又会记得我呢……",
				Position = 1,
			},
		},
		{
			{
				Text = "f(x)=lim(n->∞) nx/(1+nx^2)……",
				Position = 1,
			},
		},
		{
			{
				Text = "今天一定要证明哥德巴赫猜想！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sus_19_maikaofu_2"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220323,
			220321,
		},
	},
	DialogList = {
		{
			{
				Text = "好了，你输了，快去自首！",
				Position = 2,
			},
			{
				Text = "切，等我放出来再战！",
				Position = 1,
			},
		},
		{
			{
				Text = "耶，我赢了！你要帮我做无罪辩护！",
				Position = 1,
			},
			{
				Text = "嗯，再说吧。",
				Position = 2,
			},
		},
		{
			{
				Text = "竟然…平手。",
				Position = 1,
			},
			{
				Text = "那不如一起喝一杯吧~",
				Position = 2,
			},
		},
	},
}
PlanetCharacterConfig["Sus_28_heiyiren_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220305,
		},
	},
	DialogList = {
		{
			{
				Text = "怎么没人发现是我做的啊……！",
				Position = 1,
			},
		},
		{
			{
				Text = "哦，看看这惨状！我可真是太坏了！",
				Position = 1,
			},
		},
		{
			{
				Text = "被发现了吗……被发现了吗……！？",
				Position = 1,
			},
		},
		{
			{
				Text = "大侦探……你绝对想不到是我吧……嘻嘻嘻……",
				Position = 1,
			},
		},
		{
			{
				Text = "不行……还不能笑……",
				Position = 1,
			},
			{
				Text = "……计划通！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sus_01_fuermosi_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220324,
		},
		LockCharacterList = {
			220322,
		},
	},
	DialogList = {
		{
			{
				Text = "……助理，你怎么看？",
				Position = 1,
			},
		},
		{
			{
				Text = "破案了！屎一定是这只鸟拉的！",
				Position = 1,
			},
		},
		{
			{
				Text = "这个证据……",
				Position = 1,
			},
			{
				Text = "难不成是——？",
				Position = 1,
			},
			{
				Text = "可他们都有不在场证明……",
				Position = 1,
			},
			{
				Text = "……懂了！是我做的！",
				Position = 1,
			},
		},
		{
			{
				Text = "嗯……",
				Position = 1,
			},
			{
				Text = "……（快胡编不下去了，怎么办！？）",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sus_01_fuermosi_2"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220324,
			220322,
		},
	},
	DialogList = {
		{
			{
				Text = "……Zzzz",
				Position = 2,
			},
			{
				Text = "※这就是真相，一切都结束了！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sus_20_lanyixiaoxuesheng_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220322,
		},
	},
	DialogList = {
		{
			{
				Text = "※好了，事到如今，你还有什么好说的！？",
				Position = 1,
			},
		},
		{
			{
				Text = "※如果这一切都是设计好的，那……",
				Position = 1,
			},
			{
				Text = "※你的不在场证明根本不成立！",
				Position = 1,
			},
			{
				Text = "……Zzz",
				Position = 2,
			},
		},
		{
			{
				Text = "※很遗憾，那是不可能的！",
				Position = 1,
			},
			{
				Text = "※你在那个时候并没有不在场证明！",
				Position = 1,
			},
			{
				Text = "……Zzz（好像都说对了，那我再装睡一会吧。）",
				Position = 2,
			},
		},
		{
			{
				Text = "※至于手法……呃……",
				Position = 1,
			},
			{
				Text = "Zzz……咳咳……",
				Position = 2,
			},
			{
				Text = "※啊——对！你是用烟气作案的！",
				Position = 1,
			},
			{
				Text = "Zzz……（♪~）",
				Position = 2,
			},
		},
		{
			{
				Text = "※正是因为……balabala……",
				Position = 1,
			},
			{
				Text = "Zzz……（还没完吗……好想动一动……）",
				Position = 2,
			},
		},
	},
}
PlanetCharacterConfig["Sus_02_huasheng_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220320,
		},
	},
	DialogList = {
		{
			{
				Text = "原来如此！我完全理解了！",
				Position = 1,
			},
		},
		{
			{
				Text = "精彩的推理！",
				Position = 1,
			},
		},
		{
			{
				Text = "我怎么就没想到呢！",
				Position = 1,
			},
		},
		{
			{
				Text = "懂了……学到许多！",
				Position = 1,
			},
		},
		{
			{
				Text = "希望下次我也能亲自破案！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sus_04_fayi_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220317,
		},
	},
	DialogList = {
		{
			{
				Text = "死得还挺艺术的，再来一张……",
				Position = 1,
			},
			{
				Text = "坏了！忘关美颜了……",
				Position = 1,
			},
		},
		{
			{
				Text = "有趣的死法……发个朋友圈……",
				Position = 1,
			},
		},
		{
			{
				Text = "这、这是怎么死的！？",
				Position = 1,
			},
			{
				Text = "太神奇了……",
				Position = 1,
			},
		},
		{
			{
				Text = "这都能进博物馆了……",
				Position = 1,
			},
		},
		{
			{
				Text = "来，笑一个！",
				Position = 1,
			},
			{
				Text = "哦……不好意思，忘记你已经死了。",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sus_12_sizhe_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220303,
		},
	},
	DialogList = {
		{
			{
				Text = "只要我们不停下脚步……道路就会不断延伸下去……",
				Position = 1,
			},
		},
		{
			{
				Text = "……（还没弄好吗？脖子好酸啊！）",
				Position = 1,
			},
		},
		{
			{
				Text = "……（唉，今天又死了……）",
				Position = 1,
			},
		},
		{
			{
				Text = "……（怎么还不给我发便当啊，饿死了！）",
				Position = 1,
			},
		},
		{
			{
				Text = "……（不能睡……我是专业的……）",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sus_24_boshi_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220315,
		},
	},
	DialogList = {
		{
			{
				Text = "又跳闸了……",
				Position = 1,
			},
		},
		{
			{
				Text = "这能耗，牌照搞不下来啊……",
				Position = 1,
			},
		},
		{
			{
				Text = "哪里出了问题？",
				Position = 1,
			},
		},
		{
			{
				Text = "呜啊，怎么冒烟了！",
				Position = 1,
			},
			{
				Text = "我看看……谁扔的烟头！",
				Position = 1,
			},
		},
		{
			{
				Text = "好……再调试一下就可以启动了！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sus_05_jingcha_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220316,
		},
		LockCharacterList = {
			220304,
		},
	},
	DialogList = {
		{
			{
				Text = "去买个甜甜圈没人会看到吧……",
				Position = 1,
			},
		},
		{
			{
				Text = "怎么倒班的还不来？",
				Position = 1,
			},
		},
		{
			{
				Text = "今天也没什么事发生啊……",
				Position = 1,
			},
		},
		{
			{
				Text = "有人报警！？当听不见！",
				Position = 1,
			},
		},
		{
			{
				Text = "糟了，钱包丢了！",
				Position = 1,
			},
			{
				Text = "快报警……啊，我就是警察啊……",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sus_05_jingcha_2"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220316,
			220304,
		},
	},
	DialogList = {
		{
			{
				Text = "嗯，我知道了…",
				Position = 1,
			},
			{
				Text = "跟您核对一下菜单——不对，口供！",
				Position = 1,
			},
		},
		{
			{
				Text = "你确定你知道全貌吗？",
				Position = 1,
			},
			{
				Text = "是的！千真万确！",
				Position = 2,
			},
			{
				Text = "据我所知你都不在现场，你是如何了解的？",
				Position = 1,
			},
			{
				Text = "警官先生，不要小看我的想象能力！",
				Position = 2,
			},
		},
		{
			{
				Text = "你要报告什么？",
				Position = 1,
			},
			{
				Text = "诶，我想请问最近有没有事件发生？在下可以帮忙破案！",
				Position = 2,
			},
		},
		{
			{
				Text = "……也就是说，你一直在纠缠骚扰一位女性？",
				Position = 1,
			},
			{
				Text = "我那是在展现我做侦探的才能！她明显隐瞒了什么！",
				Position = 2,
			},
			{
				Text = "因为她是魔术师！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sus_08_zhenren_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220304,
		},
	},
	DialogList = {
		{
			{
				Text = "您要相信我啊，警察先生，我的证词句句属实，虽然具体情况没太看清！",
				Position = 1,
			},
		},
		{
			{
				Text = "我相信事情的真相就是我所想象的那样！",
				Position = 1,
			},
		},
		{
			{
				Text = "这个地方……有点太平淡了……这样的证词不够有趣……",
				Position = 1,
			},
			{
				Text = "好，适当添油加醋吧！",
				Position = 1,
			},
		},
		{
			{
				Text = "嗯，这里要再构思一下",
				Position = 1,
			},
		},
		{
			{
				Text = "唔，少了点张力，录口供的时候要再加强一下。",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sus_07_daomeidan_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220311,
		},
	},
	DialogList = {
		{
			{
				Text = "555~~~",
				Position = 1,
			},
			{
				Text = "那个人太黑了，我完全没看清。",
				Position = 1,
			},
		},
		{
			{
				Text = "我只不过是在路边走，就被抢劫了……",
				Position = 1,
			},
		},
		{
			{
				Text = "这已经是我这个月第五次受害了……555……",
				Position = 1,
			},
		},
		{
			{
				Text = "我太难了……",
				Position = 1,
			},
		},
		{
			{
				Text = "明天一定不会再受害了！",
				Position = 1,
			},
			{
				Text = "一定……唉，希望吧……",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sus_13_lvshi_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220312,
		},
		LockCharacterList = {
			220318,
		},
	},
	DialogList = {
		{
			{
				Text = "反对——！\n反对——\n咳咳咳——！",
				Position = 1,
			},
		},
		{
			{
				Text = "等等——！",
				Position = 1,
			},
		},
		{
			{
				Text = "看看这个——！",
				Position = 1,
			},
		},
		{
			{
				Text = "异议——！",
				Position = 1,
			},
			{
				Text = "好了……音量够大了……",
				Position = 1,
			},
			{
				Text = "这下可以虚张声势了！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sus_13_lvshi_2"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220312,
			220318,
		},
	},
	DialogList = {
		{
			{
				Text = "反对——！\n这段证词有问题！",
				Position = 1,
			},
			{
				Text = "异议！请辨方提供证据！",
				Position = 3,
			},
			{
				Text = "咳咳——肃静。",
				Position = 2,
			},
		},
		{
			{
				Text = "这件证物明显有问题！",
				Position = 1,
			},
			{
				Text = "法庭上说话是要讲证据的！",
				Position = 3,
			},
			{
				Text = "…原来你们说话都有证据的吗？",
				Position = 2,
			},
		},
		{
			{
				Text = "我要请下一个证人出庭作证了。",
				Position = 3,
			},
			{
				Text = "反对！我还没想好怎么反驳！",
				Position = 1,
			},
			{
				Text = "反对无效！",
				Position = 2,
			},
		},
		{
			{
				Text = "我要求维持原判！",
				Position = 3,
			},
			{
				Text = "我反对维持原判！",
				Position = 1,
			},
			{
				Text = "我还没判呢！",
				Position = 2,
			},
		},
		{
			{
				Text = "今天就到这里了，休庭——",
				Position = 2,
			},
			{
				Text = "反对！",
				Position = 1,
			},
			{
				Text = "反对！",
				Position = 3,
			},
			{
				Text = "……",
				Position = 2,
			},
		},
	},
}
PlanetCharacterConfig["Sus_14_faguan_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220319,
		},
		LockCharacterList = {
			220312,
			220318,
		},
	},
	DialogList = {
		{
			{
				Text = "下班去烫个头~",
				Position = 2,
			},
		},
		{
			{
				Text = "唉……今天的案子真是复杂……",
				Position = 1,
			},
		},
		{
			{
				Text = "早点搞完早点下班啦……还要回家带孙子呢……",
				Position = 2,
			},
		},
		{
			{
				Text = "咳咳……回家吃点润喉糖……",
				Position = 2,
			},
		},
	},
}
PlanetCharacterConfig["Sus_14_faguan_2"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220319,
		},
		LockCharacterList = {
			220312,
		},
	},
	DialogList = {
		{
			{
				Text = "下班去烫个头~",
				Position = 2,
			},
		},
	},
}
PlanetCharacterConfig["Sus_14_faguan_3"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220319,
		},
		LockCharacterList = {
			220318,
		},
	},
	DialogList = {
		{
			{
				Text = "下班去烫个头~",
				Position = 2,
			},
		},
	},
}
PlanetCharacterConfig["Sus_14_faguan_4"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220319,
			220312,
			220318,
		},
	},
	DialogList = {
		{
			{
				Text = "庭上禁止拍桌！",
				Position = 2,
			},
			{
				Text = "肃静！肃静！",
				Position = 2,
			},
		},
	},
}
PlanetCharacterConfig["Sus_16_yujianlianshi_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220318,
		},
		LockCharacterList = {
			220312,
		},
	},
	DialogList = {
		{
			{
				Text = "怎么还不下班……我还想回家看小将军呢……",
				Position = 3,
			},
			{
				Text = "这个月的工资评定要有好戏看了……",
				Position = 3,
			},
		},
	},
}
PlanetCharacterConfig["Sus_16_yujianlianshi_2"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220318,
			220312,
		},
	},
	DialogList = {
		{
			{
				Text = "反对——！\n如果你拿不出证据，那这一切都毫无意义！",
				Position = 3,
			},
			{
				Text = "异议！证据就是——",
				Position = 1,
			},
			{
				Text = "咳咳——肃静。",
				Position = 2,
			},
		},
	},
}
PlanetCharacterConfig["Sus_23_tiaojiushi_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220314,
		},
	},
	DialogList = {
		{
			{
				Text = "小姐，您点的八二年马蹄水。",
				Position = 1,
			},
		},
		{
			{
				Text = "您点的白酒加红酒加黄酒加啤酒加葡萄酒的混调鸡尾酒来了！",
				Position = 1,
			},
		},
		{
			{
				Text = "您点的陈年老矿泉水~",
				Position = 1,
			},
		},
		{
			{
				Text = "您点的老冰、弹簧、摇冰混合~",
				Position = 1,
			},
		},
		{
			{
				Text = "您点的……哦您什么都没点。",
				Position = 1,
			},
			{
				Text = "那给送您个空瓶子吧~",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sus_30_ajiasha_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220302,
		},
	},
	DialogList = {
		{
			{
				Text = "喂，有情况吗——",
				Position = 1,
			},
			{
				Text = "不好意思，不需要保险，谢谢……",
				Position = 1,
			},
		},
		{
			{
				Text = "我马上过去——等等，插进来个电话。",
				Position = 1,
			},
			{
				Text = "抱歉，不报班，我没有孩子……",
				Position = 1,
			},
		},
		{
			{
				Text = "喂？调查有眉目——",
				Position = 1,
			},
			{
				Text = "——好的……我回去就缴费……",
				Position = 1,
			},
		},
		{
			{
				Text = "是我，事情怎么样——",
				Position = 1,
			},
			{
				Text = "——不订报纸！",
				Position = 1,
			},
		},
		{
			{
				Text = "您好，不买保险不报班交过费了不订报纸——",
				Position = 1,
			},
			{
				Text = "——什么？案子有眉目了！？",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sus_15_fangdongtaitai_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220313,
		},
	},
	DialogList = {
		{
			{
				Text = "该交租了，这帮小鬼别又在房间里搞破坏……",
				Position = 1,
			},
		},
		{
			{
				Text = "哎，快入冬了，要注意保暖啊~",
				Position = 1,
			},
		},
		{
			{
				Text = "不知道女儿在那边过得怎么样……",
				Position = 1,
			},
			{
				Text = "……我说的是其他星球，她在那里工作，别瞎想了。",
				Position = 1,
			},
		},
		{
			{
				Text = "希望今天没啥意外发生~",
				Position = 1,
			},
		},
		{
			{
				Text = "服务员，来杯淡啤酒！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sus_22_bianji_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220309,
		},
	},
	DialogList = {
		{
			{
				Text = "哦哦！是灵感！这个月的连载有主意了！！！",
				Position = 1,
			},
		},
		{
			{
				Text = "这个月的连载……如果把他们都洗白的话……",
				Position = 1,
			},
		},
		{
			{
				Text = "啊……这里的爆点该怎么设计……",
				Position = 1,
			},
		},
		{
			{
				Text = "完了完了……这样画要被炎上了！",
				Position = 1,
			},
		},
		{
			{
				Text = "再加个女主角吧！有修罗场才有话题！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sus_21_duzhe_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220310,
		},
	},
	DialogList = {
		{
			{
				Text = "……这洗白也太强行了吧！",
				Position = 1,
			},
		},
		{
			{
				Text = "唉，战斗力崩了，真是江郎才尽……",
				Position = 1,
			},
		},
		{
			{
				Text = "这作者根本不懂漫画，还不如让我来！",
				Position = 1,
			},
		},
		{
			{
				Text = "哎，烂尾了烂尾了！",
				Position = 1,
			},
		},
		{
			{
				Text = "还搞人气投票？官方这个吃相也太恶心了！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sus_17_baotong_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220301,
		},
	},
	DialogList = {
		{
			{
				Text = "有人要买昨天的报纸吗？",
				Position = 1,
			},
		},
		{
			{
				Text = "二手新闻！错过这个村没这个店了！",
				Position = 1,
			},
		},
		{
			{
				Text = "来份报纸吧！关注时事热点！",
				Position = 1,
			},
			{
				Text = "不是时事也能当故事看！",
				Position = 1,
			},
			{
				Text = "来份故事吧！",
				Position = 1,
			},
		},
		{
			{
				Text = "啦啦啦♪啦啦啦♪",
				Position = 1,
			},
			{
				Text = "我是卖报的小行家♪",
				Position = 1,
			},
		},
		{
			{
				Text = "特价酬宾了！报纸买一送一！",
				Position = 1,
			},
			{
				Text = "买一份回家垫桌角吧！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sus_03_moliyadi_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220325,
		},
	},
	DialogList = {
		{
			{
				Text = "哈哈，这一定能给大侦探找不少乐子！",
				Position = 1,
			},
		},
		{
			{
				Text = "piu~piu~piu~",
				Position = 1,
			},
		},
		{
			{
				Text = "我们都是神枪手♪",
				Position = 1,
			},
			{
				Text = "每一个子弹消灭一个侦探♪",
				Position = 1,
			},
		},
		{
			{
				Text = "I've got you in my sight！",
				Position = 1,
			},
		},
		{
			{
				Text = "放心吧，这个是颜料弹~",
				Position = 1,
			},
			{
				Text = "但是染上了就洗不掉了哦~",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["RPG_105_Scholar_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			223005,
		},
	},
	DialogList = {
		{
			{
				Text = "所谓，勤有功，戏无益。",
				Position = 1,
			},
		},
		{
			{
				Text = "相比努力，方法更重要，比如…",
				Position = 1,
			},
			{
				Text = "能买高级装备就别刷等级了！",
				Position = 1,
			},
		},
		{
			{
				Text = "嗯？怎么就我一个了？",
				Position = 1,
			},
			{
				Text = "不是说去居酒屋吗？大家都去哪儿了？",
				Position = 1,
			},
		},
		{
			{
				Text = "这是……上古的符文！",
				Position = 1,
			},
		},
		{
			{
				Text = "如果我不认识书上的字……那我怎么才能分得清哪个是正面？",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sea_13_shayu_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220426,
		},
	},
	DialogList = {
		{
			{
				Text = "只要用麦克风挡住嘴……",
				Position = 1,
			},
			{
				Text = "就没有人能看到我的牙齿了。",
				Position = 1,
			},
			{
				Text = "糟糕，我没有麦克风。",
				Position = 1,
			},
			{
				Text = "那只好把嘴紧紧闭上……",
				Position = 1,
			},
		},
		{
			{
				Text = "这把吉他音不准。",
				Position = 1,
			},
			{
				Text = "希望演出结束后，不会收到粉丝的投诉。",
				Position = 1,
			},
		},
		{
			{
				Text = "上台前，又被经纪人叮嘱要做好表情管理了。",
				Position = 1,
			},
			{
				Text = "哼……我的表情管理，就是没有表情。",
				Position = 1,
			},
		},
		{
			{
				Text = "我也希望，有一天可以像京一样闪闪发光。",
				Position = 1,
			},
			{
				Text = "为了这个目标，我一定会努力的！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sea_12_jingsha_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220427,
		},
	},
	DialogList = {
		{
			{
				Text = "啊，粉丝好像又和经纪人吵起来了~",
				Position = 1,
			},
			{
				Text = "要不要发声，安抚一下TA们的情绪呢~",
				Position = 1,
			},
			{
				Text = "演出前又收到了2张好人卡~",
				Position = 1,
			},
			{
				Text = "加起来的话，应该有9999张了吧？",
				Position = 1,
			},
		},
		{
			{
				Text = "集齐10000张，会有什么成就吗~",
				Position = 1,
			},
			{
				Text = "束身服好像有点紧了~",
				Position = 1,
			},
			{
				Text = "下次系松一点~",
				Position = 1,
			},
			{
				Text = "看来，身材管理还要加强呀~",
				Position = 1,
			},
		},
		{
			{
				Text = "每一刻都不能放松。",
				Position = 1,
			},
			{
				Text = "加油啊，依伶，绝对不能出错！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sea_14_hujing_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220430,
		},
	},
	DialogList = {
		{
			{
				Text = "呀，我看到了熟悉的身影。",
				Position = 1,
			},
			{
				Text = "演出结束后，下去和TA打个招呼吧~",
				Position = 1,
			},
		},
		{
			{
				Text = "能站在这里唱歌，是我的荣幸。",
				Position = 1,
			},
			{
				Text = "一定要把最好的表演带给大家。",
				Position = 1,
			},
		},
		{
			{
				Text = "高一点~",
				Position = 1,
			},
			{
				Text = "蹦得再高一点~",
				Position = 1,
			},
			{
				Text = "就可以看到更多风景啦~",
				Position = 1,
			},
		},
		{
			{
				Text = "没有什么比快乐和梦想更重要~",
				Position = 1,
			},
			{
				Text = "就是因为爱与梦想……",
				Position = 1,
			},
			{
				Text = "我才能站在耀眼的舞台上！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sea_16_jingyu_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220428,
		},
		LockCharacterList = {
			220401,
		},
	},
	DialogList = {
		{
			{
				Text = "呜~~哦哦哦~~~",
				Position = 1,
			},
			{
				Text = "哇，我成功让玻璃杯碎掉了！",
				Position = 1,
			},
		},
		{
			{
				Text = "这次的目标是，不能碎！",
				Position = 1,
			},
			{
				Text = "为了达成这个目标，我已经好几天没有睡了……",
				Position = 1,
			},
		},
		{
			{
				Text = "还记得我第一次唱歌失常，震碎了评委的限量玻璃杯。",
				Position = 1,
			},
			{
				Text = "TA竟然没有向我索要赔偿……",
				Position = 1,
			},
			{
				Text = "真是善良的人呀。",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sea_16_jingyu+haitun"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220428,
			220401,
		},
	},
	DialogList = {
		{
			{
				Text = "呜~~哦哦哦~~~",
				Position = 1,
			},
			{
				Text = "哇，我成功让玻璃杯碎掉了！",
				Position = 1,
			},
		},
		{
			{
				Text = "这次的目标是，不能碎！",
				Position = 1,
			},
			{
				Text = "为了达成这个目标，我已经好几天没有睡了……",
				Position = 1,
			},
		},
		{
			{
				Text = "还记得我第一次唱歌失常，震碎了评委的限量玻璃杯。",
				Position = 1,
			},
			{
				Text = "TA竟然没有向我索要赔偿……",
				Position = 1,
			},
			{
				Text = "真是善良的人呀。",
				Position = 1,
			},
		},
		{
			{
				Text = "可以让我看看，你是怎么震碎玻璃的吗？",
				Position = 2,
			},
			{
				Text = "就是这样，拿出玻璃杯",
				Position = 1,
			},
			{
				Text = "哒哒哒滴哒~~",
				Position = 2,
			},
			{
				Text = "啊……果然碎了……",
				Position = 2,
			},
			{
				Text = "哇，好厉害！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sea_17_haitun_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220401,
		},
		LockCharacterList = {
			220428,
		},
	},
	DialogList = {
		{
			{
				Text = "呜啦啦啦啦……",
				Position = 1,
			},
			{
				Text = "啊，又碎掉了。",
				Position = 1,
			},
		},
		{
			{
				Text = "这次的目标是，不能碎！",
				Position = 1,
			},
			{
				Text = "为了达成这个目标，我已经好几天没有睡了……",
				Position = 1,
			},
		},
		{
			{
				Text = "还记得我第一次唱歌失常，震碎了评委的限量玻璃杯。",
				Position = 1,
			},
			{
				Text = "TA竟然没有向我索要赔偿……",
				Position = 1,
			},
			{
				Text = "真是善良的人呀。",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sea_01_huangshuimu_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220421,
		},
		LockCharacterList = {
			220404,
		},
	},
	DialogList = {
		{
			{
				Text = "呀！请不要用力戳我！",
				Position = 1,
			},
			{
				Text = "真对不起，我不能和别人接触的……",
				Position = 1,
			},
		},
		{
			{
				Text = "我也希望，可以用我的力量……",
				Position = 1,
			},
			{
				Text = "保护身边的人。",
				Position = 1,
			},
		},
		{
			{
				Text = "诶？你是我的粉丝吗，谢谢~",
				Position = 1,
			},
			{
				Text = "不过我不能握手~我们合个影吧？",
				Position = 1,
			},
		},
		{
			{
				Text = "我直接摆出剪刀手可以吗？",
				Position = 1,
			},
			{
				Text = "不，这个姿势太普通了。",
				Position = 1,
			},
			{
				Text = "哪个姿势好呢……哎呀！",
				Position = 1,
			},
			{
				Text = "被拍下来了……",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sea_01_huangshuimu_2"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220421,
			220404,
		},
	},
	DialogList = {
		{
			{
				Text = "呀！请不要用力戳我！",
				Position = 1,
			},
			{
				Text = "真对不起，我不能和别人接触的……",
				Position = 1,
			},
		},
		{
			{
				Text = "我也希望，可以用我的力量……",
				Position = 1,
			},
			{
				Text = "保护身边的人。",
				Position = 1,
			},
		},
		{
			{
				Text = "诶？你是我的粉丝吗，谢谢~",
				Position = 1,
			},
			{
				Text = "不过我不能握手~我们合个影吧？",
				Position = 1,
			},
		},
		{
			{
				Text = "我直接摆出剪刀手可以吗？",
				Position = 1,
			},
			{
				Text = "不，这个姿势太普通了。",
				Position = 1,
			},
			{
				Text = "哪个姿势好呢……哎呀！",
				Position = 1,
			},
			{
				Text = "被拍下来了……",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sea_20_shanhu_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220429,
		},
	},
	DialogList = {
		{
			{
				Text = "“是啊，我们不是没有明天的咸鱼……”",
				Position = 1,
			},
			{
				Text = "这不是悬疑类的剧本吗？",
				Position = 1,
			},
			{
				Text = "怎么能说出像励志片一样的话呢？",
				Position = 1,
			},
		},
		{
			{
				Text = "这句台词感觉不对……",
				Position = 1,
			},
			{
				Text = "之后再告诉编剧，让TA稍微修改一点吧。",
				Position = 1,
			},
		},
		{
			{
				Text = "听说我们家族又投资了一部电影。",
				Position = 1,
			},
			{
				Text = "真是好奇啊，是什么电影受到了他们的青睐呢？",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sea_21_haidan_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220413,
		},
	},
	DialogList = {
		{
			{
				Text = "好困，呼……",
				Position = 1,
			},
			{
				Text = "睡觉，好幸福……",
				Position = 1,
			},
		},
		{
			{
				Text = "啊呼——呼——",
				Position = 1,
			},
			{
				Text = "什么？！怎么了？",
				Position = 1,
			},
			{
				Text = "原来是被大家的歌声吵醒了啊。",
				Position = 1,
			},
		},
		{
			{
				Text = "只有好好休息，才能在舞台上元气满满。",
				Position = 1,
			},
			{
				Text = "所以，现在应该睡觉……",
				Position = 1,
			},
		},
		{
			{
				Text = "Zzzzz……",
				Position = 1,
			},
			{
				Text = "这个枕头，硬硬的，呼……",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sea_23_haikui_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220416,
		},
		LockCharacterList = {
			220412,
		},
	},
	DialogList = {
		{
			{
				Text = "再过一会儿，TA就该来了。",
				Position = 1,
			},
			{
				Text = "要在这之前化好妆……",
				Position = 1,
			},
		},
		{
			{
				Text = "今天的头发配色也很棒。",
				Position = 1,
			},
			{
				Text = "为什么粉丝会说，这个配色看上去很有食欲呢？",
				Position = 1,
			},
			{
				Text = "完全不能理解啊……",
				Position = 1,
			},
		},
		{
			{
				Text = "你有看到其他团的某位成员吗？",
				Position = 1,
			},
			{
				Text = "就是……非常可爱，会闪闪发光的那一位。",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sea_07_xiaochouyu_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220412,
		},
		LockCharacterList = {
			220416,
		},
	},
	DialogList = {
		{
			{
				Text = "再过一会儿，TA就该来了。",
				Position = 1,
			},
			{
				Text = "要在这之前化好妆……",
				Position = 1,
			},
		},
		{
			{
				Text = "今天的头发配色也很棒。",
				Position = 1,
			},
			{
				Text = "为什么粉丝会说，这个配色看上去很有食欲呢？",
				Position = 1,
			},
			{
				Text = "完全不能理解啊……",
				Position = 1,
			},
		},
		{
			{
				Text = "你有看到其他团的某位成员吗？",
				Position = 1,
			},
			{
				Text = "就是……非常可爱，会闪闪发光的那一位。",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sea_Group_haikui+xiaochouyu_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220416,
			220412,
		},
	},
	DialogList = {
		{
			{
				Text = "眼影要用这个颜色，口红……",
				Position = 1,
			},
			{
				Text = "我的口红去哪里了？",
				Position = 1,
			},
		},
		{
			{
				Text = "最近因为八卦新闻，出现了粉丝流失的现象。",
				Position = 1,
			},
			{
				Text = "要怎么才能挽救一下形象呢？",
				Position = 1,
			},
		},
		{
			{
				Text = "你有看到其他团的某位成员吗？",
				Position = 1,
			},
			{
				Text = "就是……头发非常有特色的那一位。",
				Position = 1,
			},
		},
		{
			{
				Text = "我们上次回家的时候……",
				Position = 1,
			},
			{
				Text = "啊，是这样吗，我和你讲……",
				Position = 2,
			},
			{
				Text = "真是太那个了。",
				Position = 1,
			},
			{
				Text = "就是说啊，怎么那么那个……",
				Position = 2,
			},
		},
	},
}
PlanetCharacterConfig["Sea_25_haishe_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220425,
		},
	},
	DialogList = {
		{
			{
				Text = "是不是可以改变一下风格呢？",
				Position = 1,
			},
			{
				Text = "嗯……我要犹豫一下。",
				Position = 1,
			},
		},
		{
			{
				Text = "你说，我穿粉色的衣服怎么样？",
				Position = 1,
			},
			{
				Text = "哎，不要做出那种表情啊——！",
				Position = 1,
			},
		},
		{
			{
				Text = "果然，还是黑色衣服和摇滚搭配一点啊。",
				Position = 1,
			},
			{
				Text = "但是我还是想尝试一下粉色的裙子呢。",
				Position = 1,
			},
		},
		{
			{
				Text = "我喜欢这条裙子！",
				Position = 1,
			},
			{
				Text = "决定了，这次表演就穿它了！",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sea_03_moyu_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220402,
		},
	},
	DialogList = {
		{
			{
				Text = "噗——",
				Position = 1,
			},
			{
				Text = "啊，不好意思。",
				Position = 1,
			},
			{
				Text = "又喷出墨汁了……",
				Position = 1,
			},
		},
		{
			{
				Text = "你看，这个颜色的衣服好看吗？",
				Position = 1,
			},
			{
				Text = "你更喜欢哪个颜色呢？",
				Position = 1,
			},
		},
		{
			{
				Text = "等会儿就轮到我上去表演啦。",
				Position = 1,
			},
			{
				Text = "穿哪件衣服更好看呢？",
				Position = 1,
			},
		},
		{
			{
				Text = "对了，我昨天听说了最新的八卦。",
				Position = 1,
			},
			{
				Text = "你想知道吗？",
				Position = 1,
			},
			{
				Text = "嘘，我悄悄告诉你哦……#￥&*……",
				Position = 1,
			},
			{
				Text = "是吧，完全没想到吧？",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sea_22_haisen_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220418,
		},
	},
	DialogList = {
		{
			{
				Text = "一边看着书。",
				Position = 1,
			},
			{
				Text = "一边喝着饮料。",
				Position = 1,
			},
			{
				Text = "一边晒着太阳。",
				Position = 1,
			},
			{
				Text = "一边做着头发。",
				Position = 1,
			},
			{
				Text = "啊，生活真是太美好了！",
				Position = 1,
			},
		},
		{
			{
				Text = "这本书真有意思，哈哈哈！",
				Position = 1,
			},
			{
				Text = "我和你讲，这本书讲了一个……",
				Position = 1,
			},
			{
				Text = "不行，我不能向你剧透。",
				Position = 1,
			},
		},
		{
			{
				Text = "我头上的尖刺有点多，抱歉~",
				Position = 1,
			},
			{
				Text = "但还是麻烦你，帮我修剪一下吧。",
				Position = 1,
			},
		},
		{
			{
				Text = "虽然和化妆师失之交臂，但是成为了偶像。",
				Position = 1,
			},
			{
				Text = "命运真是太神奇了~",
				Position = 1,
			},
			{
				Text = "和可爱的小偶像们在一起唱歌跳舞。",
				Position = 1,
			},
			{
				Text = "就是最快乐的事情。",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sea_26_ankang_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220419,
		},
	},
	DialogList = {
		{
			{
				Text = "这就是浅海的舞台吗？",
				Position = 1,
			},
			{
				Text = "感觉好热……",
				Position = 1,
			},
			{
				Text = "想回深海了。",
				Position = 1,
			},
		},
		{
			{
				Text = "似乎不需要打光啊……",
				Position = 1,
			},
			{
				Text = "那我在这里休息好了。",
				Position = 1,
			},
		},
		{
			{
				Text = "好困……头顶的灯泡一直亮着。",
				Position = 1,
			},
			{
				Text = "根本睡不着啊。",
				Position = 1,
			},
		},
		{
			{
				Text = "啊，请小心一点。",
				Position = 1,
			},
			{
				Text = "戳我可以，但是不要碰到灯泡哦。",
				Position = 1,
			},
			{
				Text = "会烫到手的。",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sea_28_fancheyu_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220406,
		},
	},
	DialogList = {
		{
			{
				Text = "今天的演出，也绝对不能翻车哦。",
				Position = 1,
			},
		},
		{
			{
				Text = "话筒好像有点高。",
				Position = 1,
			},
			{
				Text = "不对，是有点低。",
				Position = 1,
			},
		},
		{
			{
				Text = "等会儿就可以去舞台上唱歌了……",
				Position = 1,
			},
			{
				Text = "我也要好好表现才可以！",
				Position = 1,
			},
		},
		{
			{
				Text = "以前每次上台，都会带上我的flag。",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sea_18_hailuo_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220408,
		},
	},
	DialogList = {
		{
			{
				Text = "小螺号，嘀嘀嘀吹，海鸥听了展翅飞~",
				Position = 1,
			},
			{
				Text = "小螺号，嘀嘀嘀吹，浪花听了笑微微~",
				Position = 1,
			},
			{
				Text = "咦，怎么吹不响？",
				Position = 1,
			},
		},
		{
			{
				Text = "海螺小喇叭，一折大甩卖啦！",
				Position = 1,
			},
			{
				Text = "不要998，不要998，便宜海螺带回家！",
				Position = 1,
			},
			{
				Text = "欧买噶，买它！",
				Position = 1,
			},
		},
		{
			{
				Text = "海螺里好像有声音。",
				Position = 1,
			},
			{
				Text = "是大海的声音吗？",
				Position = 1,
			},
			{
				Text = "……原来是蚊子在嗡嗡嗡啊。",
				Position = 1,
			},
		},
		{
			{
				Text = "我是贝克街tea time成员美莎！",
				Position = 1,
			},
			{
				Text = "也是拿着海螺吹出音乐的美莎哦~",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sea_11_haima_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220415,
		},
	},
	DialogList = {
		{
			{
				Text = "动次打次~动次打次~",
				Position = 1,
			},
			{
				Text = "跟着音乐动起来~",
				Position = 1,
			},
		},
		{
			{
				Text = "今晚回去后做什么呢？",
				Position = 1,
			},
			{
				Text = "教孩子们跳舞吧？",
				Position = 1,
			},
		},
		{
			{
				Text = "看我的绝世舞功！",
				Position = 1,
			},
			{
				Text = "旋转，跳跃，我闭着眼~",
				Position = 1,
			},
		},
		{
			{
				Text = "咦？是有谁在拍我吗？",
				Position = 1,
			},
			{
				Text = "那我一定要跳得更好看才行~",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sea_30_haibao_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220420,
		},
	},
	DialogList = {
		{
			{
				Text = "欧——",
				Position = 1,
			},
			{
				Text = "欧~~",
				Position = 1,
			},
			{
				Text = "今天也是欧气满满的第一天欧~",
				Position = 1,
			},
		},
		{
			{
				Text = "你要看看我最新抽出来的卡吗？",
				Position = 1,
			},
			{
				Text = "你看，我今天又出彩啦~",
				Position = 1,
			},
		},
		{
			{
				Text = "奖池代抽~不出彩可以全部退款~",
				Position = 1,
			},
			{
				Text = "小本生意，童叟无欺。",
				Position = 1,
			},
		},
		{
			{
				Text = "不夜城的那群家伙，似乎在到处找我。",
				Position = 1,
			},
			{
				Text = "也不知道这里安不安全……",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sea_09_pangxie_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220409,
		},
	},
	DialogList = {
		{
			{
				Text = "下次的猜拳，一定要胜过伊洛……",
				Position = 1,
			},
		},
		{
			{
				Text = "铛铛铛铛——！！",
				Position = 1,
			},
			{
				Text = "这里的气氛好棒啊~！",
				Position = 1,
			},
			{
				Text = "我也要敲得更卖力才行！",
				Position = 1,
			},
		},
		{
			{
				Text = "我是Rocking Thanks的鼓手蟹香菜！",
				Position = 1,
			},
			{
				Text = "是个如假包换的有“钳”人哦！",
				Position = 1,
			},
		},
		{
			{
				Text = "这一套鼓的质量很好嘛！",
				Position = 1,
			},
			{
				Text = "这么久了，也没有被我敲破……",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sea_06_longxia_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220410,
		},
	},
	DialogList = {
		{
			{
				Text = "为什么我和香菜的猜拳，总是平局呢？",
				Position = 1,
			},
			{
				Text = "看来要多多研究《猜拳攻略》了！",
				Position = 1,
			},
		},
		{
			{
				Text = "我是Rocking Thanks的键盘手虾伊洛！",
				Position = 1,
			},
			{
				Text = "只要不手误把键盘线剪断……就能带来非常精彩的演出！",
				Position = 1,
			},
		},
		{
			{
				Text = "听说，如果练到炉火纯青，就会变成青虾。",
				Position = 1,
			},
			{
				Text = "但大家也说，青虾都是生手，熟练的虾都是红色的。",
				Position = 1,
			},
			{
				Text = "唉，颜色什么的，完全搞不懂啊。",
				Position = 1,
			},
		},
		{
			{
				Text = "说来，之前被粉丝吐槽过……",
				Position = 1,
			},
			{
				Text = "说为什么每次拍照都是剪刀手。",
				Position = 1,
			},
			{
				Text = "……到底为什么呢？",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sea_10_zhangyu_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220424,
		},
	},
	DialogList = {
		{
			{
				Text = "多么可爱的小章鱼呀。",
				Position = 1,
			},
			{
				Text = "我是说，这只蓝色的小章鱼……",
				Position = 1,
			},
			{
				Text = "不是说我自己\n(/▽＼)",
				Position = 1,
			},
		},
		{
			{
				Text = "小章鱼，让我摸摸你~",
				Position = 1,
			},
			{
				Text = "你是不是又长大啦？",
				Position = 1,
			},
		},
		{
			{
				Text = "小章鱼的体重是5磅，海的浮力是……",
				Position = 1,
			},
			{
				Text = "再加上肢体和海水的摩擦力。",
				Position = 1,
			},
			{
				Text = "诶，我是要算什么来着？",
				Position = 1,
			},
		},
		{
			{
				Text = "当我遇到危险的时候，用6m/s的速度向前跑。",
				Position = 1,
			},
			{
				Text = "同时喷出大量墨汁，对敌人成10秒视力阻碍，那么——",
				Position = 1,
			},
			{
				Text = "我当时的心理阴影面积是多少呢？",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sea_08_haixing_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220423,
		},
	},
	DialogList = {
		{
			{
				Text = "呀，不要戳我啦。",
				Position = 1,
			},
			{
				Text = "再戳下去，我的发夹就要掉了。",
				Position = 1,
			},
		},
		{
			{
				Text = "不对，发夹的尖尖，应该朝这边。",
				Position = 1,
			},
			{
				Text = "嗯，这样就好多了。",
				Position = 1,
			},
		},
		{
			{
				Text = "什么？你问我台上的表演？",
				Position = 1,
			},
			{
				Text = "海星觉得还行哦~",
				Position = 1,
			},
		},
		{
			{
				Text = "嗨，你是来看我的演出的吗？",
				Position = 1,
			},
			{
				Text = "距离我上台，还要好一会儿呢。",
				Position = 1,
			},
			{
				Text = "那要拜托你多等一会儿啦。",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sea_27_hetun_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220405,
		},
	},
	DialogList = {
		{
			{
				Text = "莫生气，莫生气，气出病来无人替。",
				Position = 1,
			},
			{
				Text = "别人生气我不气，我若气死谁如意……",
				Position = 1,
			},
		},
		{
			{
				Text = "最近又收到了粉丝投诉，说我没有进行身材管理。",
				Position = 1,
			},
			{
				Text = "……唉，好难啊。",
				Position = 1,
			},
		},
		{
			{
				Text = "要怎么才能向大家说明呢？",
				Position = 1,
			},
			{
				Text = "我是因为生气才飘起来的。",
				Position = 1,
			},
			{
				Text = "才不是因为膨胀呢。",
				Position = 1,
			},
		},
		{
			{
				Text = "虽然身体充满气体，就可以飞起来。",
				Position = 1,
			},
			{
				Text = "但是也会变胖啊，呜呜呜……",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sea_24_haiman_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220403,
		},
	},
	DialogList = {
		{
			{
				Text = "啊，这就是海底舞会吗……",
				Position = 1,
			},
			{
				Text = "千万不能电到别人呀。",
				Position = 1,
			},
		},
		{
			{
				Text = "什么时候才轮到我上场呢？",
				Position = 1,
			},
			{
				Text = "我已经迫不及待了！",
				Position = 1,
			},
		},
		{
			{
				Text = "我换上了新的演出服。",
				Position = 1,
			},
			{
				Text = "这次应该不会放电了吧？",
				Position = 1,
			},
		},
		{
			{
				Text = "今天登台上一首摇滚吧？",
				Position = 1,
			},
			{
				Text = "不知道大家会不会喜欢。",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sea_05_haitu_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220411,
		},
	},
	DialogList = {
		{
			{
				Text = "这个不好，换个颜色……",
				Position = 1,
			},
			{
				Text = "不行，再换一个。",
				Position = 1,
			},
			{
				Text = "还是不对，下一个……",
				Position = 1,
			},
		},
		{
			{
				Text = "这个颜色适合搭配什么色系的妆容呢？",
				Position = 1,
			},
			{
				Text = "如果有百搭的妆容就好了。",
				Position = 1,
			},
		},
		{
			{
				Text = "好想再吃一个罐头啊。",
				Position = 1,
			},
			{
				Text = "但又会变成奇怪的颜色。",
				Position = 1,
			},
			{
				Text = "真是让人烦恼。",
				Position = 1,
			},
		},
		{
			{
				Text = "如果只是变色还好……",
				Position = 1,
			},
			{
				Text = "但有时候，整个人会变成其他样子。",
				Position = 1,
			},
			{
				Text = "要怎么才能让大家记住两个模样的我呢？",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sea_29_hou_1"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220404,
		},
		LockCharacterList = {
			220421,
		},
	},
	DialogList = {
		{
			{
				Text = "记得上次有粉丝对我说，“你好，鳖椰子，我很喜欢你”。",
				Position = 1,
			},
			{
				Text = "可是我不姓鳖。",
				Position = 1,
			},
			{
				Text = "还有人对我说，“爱你，亲爱的鳌椰子”。",
				Position = 1,
			},
			{
				Text = "但，我也不姓鳌……",
				Position = 1,
			},
		},
		{
			{
				Text = "好想念我的村庄啊。",
				Position = 1,
			},
			{
				Text = "什么时候才能回去呢。",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sea_29_hou_2"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220404,
			220421,
		},
	},
	DialogList = {
		{
			{
				Text = "记得上次有粉丝对我说，“你好，鳖椰子，我很喜欢你”。",
				Position = 1,
			},
			{
				Text = "可是我不姓鳖。",
				Position = 1,
			},
			{
				Text = "还有人对我说，“爱你，亲爱的鳌椰子”。",
				Position = 1,
			},
			{
				Text = "但，我也不姓鳌……",
				Position = 1,
			},
		},
		{
			{
				Text = "好想念我的村庄啊。",
				Position = 1,
			},
			{
				Text = "什么时候才能回去呢。",
				Position = 1,
			},
		},
		{
			{
				Text = "我来帮忙拍照吧，看镜头~",
				Position = 1,
			},
			{
				Text = "三、二、一。",
				Position = 1,
			},
			{
				Text = "茄——子——",
				Position = 1,
			},
			{
				Text = "哎呀，好像拍糊了。",
				Position = 1,
			},
		},
		{
			{
				Text = "麻烦往左边一点~",
				Position = 1,
			},
			{
				Text = "保持微笑，不要眨眼。",
				Position = 1,
			},
			{
				Text = "好，这样就可以了。",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sea_02_douyu"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220417,
		},
	},
	DialogList = {
		{
			{
				Text = "趁着阿卡还没有来，提前练一下台词吧。",
				Position = 1,
			},
		},
		{
			{
				Text = "“如果鱼失去梦想，不就变成一条咸鱼了吗？”",
				Position = 1,
			},
			{
				Text = "嗯……这句台词还要多顺几遍。",
				Position = 1,
			},
			{
				Text = "和阿卡对戏的时候，可不能露怯啊。",
				Position = 1,
			},
		},
		{
			{
				Text = "完蛋了，如果等阿卡来了，发现我没有把台词背下来……",
				Position = 1,
			},
			{
				Text = "只好希望她也没背下来。",
				Position = 1,
			},
			{
				Text = "这样我们就能看着剧本对戏了。",
				Position = 1,
			},
		},
		{
			{
				Text = "我们……看着剧本对戏可以吗？",
				Position = 1,
			},
			{
				Text = "你没有背下来吗？",
				Position = 1,
			},
			{
				Text = "对不起！我， 啊，那个……",
				Position = 1,
			},
			{
				Text = "那太好了，我也没背下来。",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sea_04_dengtashuimu"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220422,
		},
	},
	DialogList = {
		{
			{
				Text = "为什么人都想要永生呢？",
				Position = 1,
			},
			{
				Text = "一直活下去，看着别人走向死亡。",
				Position = 1,
			},
			{
				Text = "才更痛苦吧？",
				Position = 1,
			},
		},
		{
			{
				Text = "……我并不理解。",
				Position = 1,
			},
			{
				Text = "TA们到底，喜欢我什么呢？",
				Position = 1,
			},
		},
		{
			{
				Text = "这张镜子里的脸……",
				Position = 1,
			},
			{
				Text = "还是和那时候一样。",
				Position = 1,
			},
		},
		{
			{
				Text = "等会儿要上台了。",
				Position = 1,
			},
			{
				Text = "临时补个妆吧。",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sea_19_shanbei"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220407,
		},
	},
	DialogList = {
		{
			{
				Text = "你看，这颗珍珠又大又圆，还发着光。",
				Position = 1,
			},
			{
				Text = "……观赏时间到！",
				Position = 1,
			},
			{
				Text = "不能再看了，否则会亮瞎别人的眼睛。",
				Position = 1,
			},
		},
		{
			{
				Text = "猜一猜，我身上最珍贵的东西是什么？",
				Position = 1,
			},
			{
				Text = "什么？你说这颗珍珠？",
				Position = 1,
			},
			{
				Text = "才不是呢！最珍贵的……当然是我自己啦！",
				Position = 1,
			},
		},
		{
			{
				Text = "为什么美莎想去做带货博主呢？",
				Position = 1,
			},
			{
				Text = "不过，如果我去带货售卖珍珠的话，是不是也很赚钱？",
				Position = 1,
			},
		},
		{
			{
				Text = "我是贝克街tea time成员珍！",
				Position = 1,
			},
			{
				Text = "也是拿着珍珠闪闪发光的珍哦~",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sea_15_manta"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220414,
		},
	},
	DialogList = {
		{
			{
				Text = "不翻到哪里去了？",
				Position = 1,
			},
			{
				Text = "你见到不翻了吗？",
				Position = 1,
			},
		},
		{
			{
				Text = "走两步，我就在这儿走两步……",
				Position = 1,
			},
		},
		{
			{
				Text = "这不是单纯的走路哦~",
				Position = 1,
			},
			{
				Text = "是风靡全宇宙的太空步！",
				Position = 1,
			},
		},
		{
			{
				Text = "之前看到粉丝说，我的舞步非常丝滑。",
				Position = 1,
			},
			{
				Text = "真的有那么丝滑吗？",
				Position = 1,
			},
		},
	},
}
PlanetCharacterConfig["Sea_31_meirenyu"] =
{
	PreCondition = {
		UnlockCharacterList = {
			220431,
		},
	},
	DialogList = {
		{
			{
				Text = "在海的远处，水是那么蓝。",
				Position = 1,
			},
			{
				Text = "像最美丽的矢车菊花瓣。",
				Position = 1,
			},
			{
				Text = "同时又是那么清，像最明亮的玻璃。",
				Position = 1,
			},
		},
		{
			{
				Text = "我也会有一位，命中注定的王子吗？",
				Position = 1,
			},
			{
				Text = "他会看到我，与我邂逅吗？",
				Position = 1,
			},
		},
		{
			{
				Text = "人鱼是没有不灭的灵魂的。",
				Position = 1,
			},
			{
				Text = "而且永远也不会有这样的灵魂。",
				Position = 1,
			},
			{
				Text = "除非……TA获得了一个凡人的爱情。",
				Position = 1,
			},
		},
		{
			{
				Text = "我觉得最美的事，就是停在海上。",
				Position = 1,
			},
			{
				Text = "因为可以从这里，向四周很远的地方望去。",
				Position = 1,
			},
			{
				Text = "望见整个星球上的风景。",
				Position = 1,
			},
		},
	},
}

