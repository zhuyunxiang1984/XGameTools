HomeObstacleConfig ={};
HomeObstacleID = 
{
	Id001 = 1240001,
	Id002 = 1240002,
	Id003 = 1240003,
	Id004 = 1240004,
	Id005 = 1240005,
	Id006 = 1240006,
	Id007 = 1240007,
	Id008 = 1240008,
	Id009 = 1240009,
	Id010 = 1240010,
	Id011 = 1240011,
	Id012 = 1240012,
	Id013 = 1240013,
	Id014 = 1240014,
	Id015 = 1240015,
	Id016 = 1240016,
	Id017 = 1240017,
	Id018 = 1240018,
	Id019 = 1240019,
	Id020 = 1240020,
	Id021 = 1240021,
	Id022 = 1240022,
	Id023 = 1240023,
	Id024 = 1240024,
	Id025 = 1240025,
	Id026 = 1240026,
	Id027 = 1240027,
	Id028 = 1240028,
	Id029 = 1240029,
	Id030 = 1240030,
	Id031 = 1240031,
	Id032 = 1240032,
	Id033 = 1240033,
	Id034 = 1240034,
	Id035 = 1240035,
	Id036 = 1240036,
	Id037 = 1240037,
	Id038 = 1240038,
	Id039 = 1240039,
	Id040 = 1240040,
	Id041 = 1240041,
	Id042 = 1240042,
	Id043 = 1240043,
	Id044 = 1240044,
	Id045 = 1240045,
	Id046 = 1240046,
	Id047 = 1240047,
	Id048 = 1240048,
	Id049 = 1240049,
	Id050 = 1240050,
	Id051 = 1240051,
	Id052 = 1240052,
	Id053 = 1240053,
	Id054 = 1240054,
	Id055 = 1240055,
	Id056 = 1240056,
	Id057 = 1240057,
	Id058 = 1240058,
	Id059 = 1240059,
	Id060 = 1240060,
	Id061 = 1240061,
	Id062 = 1240062,
	Id063 = 1240063,
	Id064 = 1240064,
	Id065 = 1240065,
	Id066 = 1240066,
	Id067 = 1240067,
	Id068 = 1240068,
	Id069 = 1240069,
	Id070 = 1240070,
	Id071 = 1240071,
	Id072 = 1240072,
	Id073 = 1240073,
	Id074 = 1240074,
	Id075 = 1240075,
	Id076 = 1240076,
	Id077 = 1240077,
	Id078 = 1240078,
	Id079 = 1240079,
	Id080 = 1240080,
	Id081 = 1240081,
	Id082 = 1240082,
	Id083 = 1240083,
	Id084 = 1240084,
	Id085 = 1240085,
	Id086 = 1240086,
	Id087 = 1240087,
	Id088 = 1240088,
	Id089 = 1240089,
	Id090 = 1240090,
	Id091 = 1240091,
	Id092 = 1240092,
	Id093 = 1240093,
	Id094 = 1240094,
	Id095 = 1240095,
	Id096 = 1240096,
	Id097 = 1240097,
	Id098 = 1240098,
	Id099 = 1240099,
	Id100 = 1240100,
	Id101 = 1240101,
	Id102 = 1240102,
	Id103 = 1240103,
	Id104 = 1240104,
	Id105 = 1240105,
	Id106 = 1240106,
	Id107 = 1240107,
	Id108 = 1240108,
	Id109 = 1240109,
	Id110 = 1240110,
	Id111 = 1240111,
	Id112 = 1240112,
	Id113 = 1240113,
	Id114 = 1240114,
	Id115 = 1240115,
	Id116 = 1240116,
	Id117 = 1240117,
	Id118 = 1240118,
	Id119 = 1240119,
	Id120 = 1240120,
	Id121 = 1240121,
	Id122 = 1240122,
	Id123 = 1240123,
	Id124 = 1240124,
	Id125 = 1240125,
	Id126 = 1240126,
	Id127 = 1240127,
	Id128 = 1240128,
	Id129 = 1240129,
	Id130 = 1240130,
	Id131 = 1240131,
	Id132 = 1240132,
	Id133 = 1240133,
	Id134 = 1240134,
	Id135 = 1240135,
	Id136 = 1240136,
	Id137 = 1240137,
	Id138 = 1240138,
	Id139 = 1240139,
	Id140 = 1240140,
	Id141 = 1240141,
	Id142 = 1240142,
	Id143 = 1240143,
	Id144 = 1240144,
	Id145 = 1240145,
	Id146 = 1240146,
	Id147 = 1240147,
	Id148 = 1240148,
	Id149 = 1240149,
	Id150 = 1240150,
	Id151 = 1240151,
	Id152 = 1240152,
	Id153 = 1240153,
	Id154 = 1240154,
	Id155 = 1240155,
	Id156 = 1240156,
	Id157 = 1240157,
	Id158 = 1240158,
	Id159 = 1240159,
	Id160 = 1240160,
	Id161 = 1240161,
	Id162 = 1240162,
	Id163 = 1240163,
	Id164 = 1240164,
	Id165 = 1240165,
	Id166 = 1240166,
	Id167 = 1240167,
	Id168 = 1240168,
	Id169 = 1240169,
	Id170 = 1240170,
	Id171 = 1240171,
	Id172 = 1240172,
	Id173 = 1240173,
	Id174 = 1240174,
	Id175 = 1240175,
	Id176 = 1240176,
	Id177 = 1240177,
	Id178 = 1240178,
	Id179 = 1240179,
	Id180 = 1240180,
	Id181 = 1240181,
	Id182 = 1240182,
	Id183 = 1240183,
	Id184 = 1240184,
	Id185 = 1240185,
	Id186 = 1240186,
	Id187 = 1240187,
	Id188 = 1240188,
	Id189 = 1240189,
	Id190 = 1240190,
	Id191 = 1240191,
	Id192 = 1240192,
	Id193 = 1240193,
	Id194 = 1240194,
	Id195 = 1240195,
	Id196 = 1240196,
	Id197 = 1240197,
	Id198 = 1240198,
	Id199 = 1240199,
	Id200 = 1240200,
	Id201 = 1240201,
	Id202 = 1240202,
	Id203 = 1240203,
	Id204 = 1240204,
	Id205 = 1240205,
	Id206 = 1240206,
	Id207 = 1240207,
	Id208 = 1240208,
	Id209 = 1240209,
	Id210 = 1240210,
	Id211 = 1240211,
	Id212 = 1240212,
	Id213 = 1240213,
	Id214 = 1240214,
	Id215 = 1240215,
	Id216 = 1240216,
	Id217 = 1240217,
	Id218 = 1240218,
	Id219 = 1240219,
	Id220 = 1240220,
	Id221 = 1240221,
	Id222 = 1240222,
	Id223 = 1240223,
}
HomeObstacleConfig[HomeObstacleID.Id001] =
{
	Id = 1,
	Node = "Area1_Part1_Props1",
	Name = "地板上的铁栅栏",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id002] =
{
	Id = 2,
	Node = "Area1_Part2_Props1",
	Name = "地板上的报纸",
	PreNode = {
		1240003,
		1240004,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1210016,
			Num = 1,
		},
		{
			Id = 320201,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id003] =
{
	Id = 3,
	Node = "Area1_Part2_Props2",
	Name = "报纸上的双层纸箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id004] =
{
	Id = 4,
	Node = "Area1_Part2_Props3",
	Name = "报纸上的书本",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id005] =
{
	Id = 5,
	Node = "Area1_Part3_Props1",
	Name = "地板上的报纸",
	PreNode = {
		1240006,
		1240007,
		1240008,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id006] =
{
	Id = 6,
	Node = "Area1_Part3_Props2",
	Name = "报纸上的双层纸箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id007] =
{
	Id = 7,
	Node = "Area1_Part3_Props3",
	Name = "报纸上的电力箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id008] =
{
	Id = 8,
	Node = "Area1_Part3_Props4",
	Name = "报纸上的纸板箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id009] =
{
	Id = 9,
	Node = "Area1_Part4_Props1",
	Name = "地板上的木箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id010] =
{
	Id = 10,
	Node = "Area1_Part4_Props2",
	Name = "地板上的木箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id011] =
{
	Id = 11,
	Node = "Area1_Part4_Props3",
	Name = "地板上的木箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id012] =
{
	Id = 12,
	Node = "Area1_Part4_Props4",
	Name = "地板上的长桌",
	PreNode = {
		1240013,
		1240014,
		1240015,
		1240016,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id013] =
{
	Id = 13,
	Node = "Area1_Part4_Props5",
	Name = "长桌上的老式电脑",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id014] =
{
	Id = 14,
	Node = "Area1_Part4_Props6",
	Name = "长桌上的插排",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id015] =
{
	Id = 15,
	Node = "Area1_Part4_Props7",
	Name = "长桌上的满的桶装液体",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id016] =
{
	Id = 16,
	Node = "Area1_Part4_Props8",
	Name = "长桌上的空的桶装液体",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id017] =
{
	Id = 17,
	Node = "Area1_Part5_Props1",
	Name = "地板上的书本",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id018] =
{
	Id = 18,
	Node = "Area1_Part6_Props1",
	Name = "地板上的展开的书本",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id019] =
{
	Id = 19,
	Node = "Area1_Part9_Props1",
	Name = "地板上的书本",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id020] =
{
	Id = 20,
	Node = "Area1_Part10_Props1",
	Name = "地板上的纸堆",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id021] =
{
	Id = 21,
	Node = "Area1_Part11_Props1",
	Name = "地板上的展开的书本",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id022] =
{
	Id = 22,
	Node = "Area1_Part12_Props1",
	Name = "地板上的纸团",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id023] =
{
	Id = 23,
	Node = "Area1_Part13_Props1",
	Name = "地板上的旧报纸",
	PreNode = {
		1240024,
		1240025,
		1240026,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id024] =
{
	Id = 24,
	Node = "Area1_Part13_Props2",
	Name = "旧报纸上的纸团",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id025] =
{
	Id = 25,
	Node = "Area1_Part13_Props3",
	Name = "旧报纸上的一摞书",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id026] =
{
	Id = 26,
	Node = "Area1_Part13_Props4",
	Name = "旧报纸上的大滩液体",
	PreNode = {
		1240027,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id027] =
{
	Id = 27,
	Node = "Area1_Part13_Props5",
	Name = "大滩液体上的倒下的桶装液体",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id028] =
{
	Id = 28,
	Node = "Area1_Part13_Props6",
	Name = "旧报纸上的旧花盆",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id029] =
{
	Id = 29,
	Node = "Area2_Part1_Props1",
	Name = "地板上的墙壁",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id030] =
{
	Id = 30,
	Node = "Area2_Part2_Props1",
	Name = "地板上的墙壁",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id031] =
{
	Id = 31,
	Node = "Area2_Part3_Props1",
	Name = "地板上的杂物架",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id032] =
{
	Id = 32,
	Node = "Area2_Part4_Props1",
	Name = "地板上的铁栅栏",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id033] =
{
	Id = 33,
	Node = "Area2_Part5_Props1",
	Name = "地板上的矮柜",
	PreNode = {
		1240034,
		1240035,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id034] =
{
	Id = 34,
	Node = "Area2_Part5_Props2",
	Name = "矮柜上的文件箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id035] =
{
	Id = 35,
	Node = "Area2_Part5_Props3",
	Name = "矮柜上的满的桶装液体",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id036] =
{
	Id = 36,
	Node = "Area2_Part6_Props1",
	Name = "地板上的冰箱",
	PreNode = {
		1240037,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id037] =
{
	Id = 37,
	Node = "Area2_Part6_Props2",
	Name = "冰箱上的纸堆",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id038] =
{
	Id = 38,
	Node = "Area2_Part7_Props1",
	Name = "地板上的杂物架",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id039] =
{
	Id = 39,
	Node = "Area2_Part8_Props1",
	Name = "地板上的纸堆",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id040] =
{
	Id = 40,
	Node = "Area2_Part9_Props1",
	Name = "地板上的大滩液体",
	PreNode = {
		1240041,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id041] =
{
	Id = 41,
	Node = "Area2_Part9_Props2",
	Name = "大滩液体上的纸团",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id042] =
{
	Id = 42,
	Node = "Area2_Part10_Props1",
	Name = "地板上的书本",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id043] =
{
	Id = 43,
	Node = "Area2_Part11_Props1",
	Name = "地板上的纸箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id044] =
{
	Id = 44,
	Node = "Area2_Part12_Props1",
	Name = "地板上的纸箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id045] =
{
	Id = 45,
	Node = "Area2_Part13_Props1",
	Name = "地板上的双层纸箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id046] =
{
	Id = 46,
	Node = "Area2_Part14_Props1",
	Name = "地板上的纸箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id047] =
{
	Id = 47,
	Node = "Area2_Part15_Props1",
	Name = "地板上的纸箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id048] =
{
	Id = 48,
	Node = "Area2_Part16_Props1",
	Name = "地板上的大型铁栅栏",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id049] =
{
	Id = 49,
	Node = "Area3_Part1_Props1",
	Name = "地板上的大型铁栅栏",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id050] =
{
	Id = 50,
	Node = "Area3_Part2_Props1",
	Name = "地板上的扶梯",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id051] =
{
	Id = 51,
	Node = "Area3_Part3_Props1",
	Name = "地板上的长柜",
	PreNode = {
		1240052,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id052] =
{
	Id = 52,
	Node = "Area3_Part3_Props2",
	Name = "长柜上的长柜",
	PreNode = {
		1240053,
		1240057,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id053] =
{
	Id = 53,
	Node = "Area3_Part3_Props3",
	Name = "长柜上的文件箱",
	PreNode = {
		1240054,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id054] =
{
	Id = 54,
	Node = "Area3_Part3_Props4",
	Name = "文件箱上的文件箱",
	PreNode = {
		1240055,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id055] =
{
	Id = 55,
	Node = "Area3_Part3_Props5",
	Name = "文件箱上的插排",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id056] =
{
	Id = 56,
	Node = "Area3_Part3_Props6",
	Name = "长柜上的文件箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id057] =
{
	Id = 57,
	Node = "Area3_Part4_Props1",
	Name = "地板上的破门",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id058] =
{
	Id = 58,
	Node = "Area3_Part5_Props1",
	Name = "地板上的旧报纸",
	PreNode = {
		1240059,
		1240060,
		1240061,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id059] =
{
	Id = 59,
	Node = "Area3_Part5_Props2",
	Name = "旧报纸上的文件箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id060] =
{
	Id = 60,
	Node = "Area3_Part5_Props3",
	Name = "旧报纸上的松紧带",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id061] =
{
	Id = 61,
	Node = "Area3_Part5_Props4",
	Name = "旧报纸上的破门板",
	PreNode = {
		1240062,
		1240063,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id062] =
{
	Id = 62,
	Node = "Area3_Part5_Props5",
	Name = "破门板上的文件箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id063] =
{
	Id = 63,
	Node = "Area3_Part5_Props6",
	Name = "破门板上的",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id064] =
{
	Id = 64,
	Node = "Area3_Part6_Props1",
	Name = "地板上的纸箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id065] =
{
	Id = 65,
	Node = "Area3_Part7_Props1",
	Name = "地板上的纸箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id066] =
{
	Id = 66,
	Node = "Area3_Part8_Props1",
	Name = "地板上的双层纸箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id067] =
{
	Id = 67,
	Node = "Area3_Part9_Props1",
	Name = "地板上的纸箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id068] =
{
	Id = 68,
	Node = "Area3_Part10_Props1",
	Name = "地板上的纸箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id069] =
{
	Id = 69,
	Node = "Area4_Part1_Props1",
	Name = "地板上的墙壁",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id070] =
{
	Id = 70,
	Node = "Area4_Part2_Props1",
	Name = "地板上的杂物架",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id071] =
{
	Id = 71,
	Node = "Area4_Part3_Props1",
	Name = "地板上的旧报纸",
	PreNode = {
		1240072,
		1240073,
		1240074,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id072] =
{
	Id = 72,
	Node = "Area4_Part3_Props2",
	Name = "旧报纸上的文件箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id073] =
{
	Id = 73,
	Node = "Area4_Part3_Props3",
	Name = "旧报纸上的松紧带",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id074] =
{
	Id = 74,
	Node = "Area4_Part3_Props4",
	Name = "旧报纸上的破门板",
	PreNode = {
		1240075,
		1240076,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id075] =
{
	Id = 75,
	Node = "Area4_Part3_Props5",
	Name = "破门板上的文件箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id076] =
{
	Id = 76,
	Node = "Area4_Part3_Props6",
	Name = "破门板上的",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id077] =
{
	Id = 77,
	Node = "Area4_Part4_Props1",
	Name = "地板上的杂物架",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id078] =
{
	Id = 78,
	Node = "Area5_Part1_Props1",
	Name = "地板上的铁栅栏",
	PreNode = {
		1240087,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id079] =
{
	Id = 79,
	Node = "Area5_Part2_Props1",
	Name = "地板上的大型铁栅栏",
	CostList = {
		{
			Id = 1,
			Num = 100,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id080] =
{
	Id = 80,
	Node = "Area5_Part3_Props1",
	Name = "地板上的大滩液体",
	CostList = {
		{
			Id = 1,
			Num = 100,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id081] =
{
	Id = 81,
	Node = "Area5_Part4_Props1",
	Name = "地板上的长柜",
	PreNode = {
		1240082,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id082] =
{
	Id = 82,
	Node = "Area5_Part4_Props2",
	Name = "长柜上的长柜",
	PreNode = {
		1240083,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id083] =
{
	Id = 83,
	Node = "Area5_Part4_Props3",
	Name = "长柜上的木箱",
	PreNode = {
		1240084,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id084] =
{
	Id = 84,
	Node = "Area5_Part4_Props4",
	Name = "木箱上的木箱",
	PreNode = {
		1240085,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id085] =
{
	Id = 85,
	Node = "Area5_Part4_Props5",
	Name = "木箱上的插排",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id086] =
{
	Id = 86,
	Node = "Area5_Part4_Props6",
	Name = "长柜上的木箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id087] =
{
	Id = 87,
	Node = "Area5_Part5_Props1",
	Name = "地板上的破门",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id088] =
{
	Id = 88,
	Node = "Area5_Part6_Props1",
	Name = "地板上的旧报纸",
	PreNode = {
		1240089,
		1240090,
		1240091,
		1240092,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id089] =
{
	Id = 89,
	Node = "Area5_Part6_Props2",
	Name = "旧报纸上的油漆桶",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id090] =
{
	Id = 90,
	Node = "Area5_Part6_Props3",
	Name = "旧报纸上的毛刷",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id091] =
{
	Id = 91,
	Node = "Area5_Part6_Props4",
	Name = "旧报纸上的松紧带",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id092] =
{
	Id = 92,
	Node = "Area5_Part6_Props5",
	Name = "旧报纸上的文件箱",
	PreNode = {
		1240093,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id093] =
{
	Id = 93,
	Node = "Area5_Part6_Props6",
	Name = "文件箱上的文件箱",
	PreNode = {
		1240094,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id094] =
{
	Id = 94,
	Node = "Area5_Part6_Props7",
	Name = "文件箱上的文件箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id095] =
{
	Id = 95,
	Node = "Area5_Part6_Props8",
	Name = "旧报纸上的文件箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id096] =
{
	Id = 96,
	Node = "Area5_Part6_Props9",
	Name = "旧报纸上的油漆桶",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id097] =
{
	Id = 97,
	Node = "Area5_Part6_Props10",
	Name = "旧报纸上的油漆桶",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id098] =
{
	Id = 98,
	Node = "Area5_Part6_Props11",
	Name = "旧报纸上的文件箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id099] =
{
	Id = 99,
	Node = "Area5_Part7_Props1",
	Name = "地板上的长柜",
	PreNode = {
		1240100,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id100] =
{
	Id = 100,
	Node = "Area5_Part7_Props2",
	Name = "长柜上的长柜",
	PreNode = {
		1240101,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id101] =
{
	Id = 101,
	Node = "Area5_Part7_Props3",
	Name = "长柜上的文件箱",
	PreNode = {
		1240102,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id102] =
{
	Id = 102,
	Node = "Area5_Part7_Props4",
	Name = "文件箱上的文件箱",
	PreNode = {
		1240103,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id103] =
{
	Id = 103,
	Node = "Area5_Part7_Props5",
	Name = "文件箱上的插排",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id104] =
{
	Id = 104,
	Node = "Area5_Part7_Props6",
	Name = "长柜上的文件箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id105] =
{
	Id = 105,
	Node = "Area6_Part1_Props1",
	Name = "地板上的墙壁",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id106] =
{
	Id = 106,
	Node = "Area6_Part2_Props1",
	Name = "地板上的大型铁栅栏",
	PreNode = {
		1240114,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id107] =
{
	Id = 107,
	Node = "Area6_Part3_Props1",
	Name = "地板上的铁栅栏",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id108] =
{
	Id = 108,
	Node = "Area6_Part4_Props1",
	Name = "地板上的仪器",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id109] =
{
	Id = 109,
	Node = "Area6_Part5_Props1",
	Name = "地板上的杂物架",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id110] =
{
	Id = 110,
	Node = "Area6_Part6_Props1",
	Name = "地板上的报纸",
	PreNode = {
		1240111,
		1240112,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id111] =
{
	Id = 111,
	Node = "Area6_Part6_Props2",
	Name = "报纸上的排风扇",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id112] =
{
	Id = 112,
	Node = "Area6_Part6_Props3",
	Name = "报纸上的纸堆",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id113] =
{
	Id = 113,
	Node = "Area6_Part7_Props1",
	Name = "地板上的大滩液体",
	PreNode = {
		1240114,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id114] =
{
	Id = 114,
	Node = "Area6_Part7_Props2",
	Name = "地板上的破门版",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id115] =
{
	Id = 115,
	Node = "Area6_Part8_Props1",
	Name = "地板上的纸团",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id116] =
{
	Id = 116,
	Node = "Area6_Part9_Props1",
	Name = "地板上的旧报纸",
	PreNode = {
		1240117,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id117] =
{
	Id = 117,
	Node = "Area6_Part9_Props2",
	Name = "旧报纸上的仪器",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id118] =
{
	Id = 118,
	Node = "Area6_Part10_Props1",
	Name = "地板上的大型铁栅栏",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id119] =
{
	Id = 119,
	Node = "Area7_Part1_Props1",
	Name = "地板上的",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id120] =
{
	Id = 120,
	Node = "Area7_Part2_Props1",
	Name = "地板上的长柜",
	PreNode = {
		1240121,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id121] =
{
	Id = 121,
	Node = "Area7_Part2_Props2",
	Name = "长柜上的长柜",
	PreNode = {
		1240122,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id122] =
{
	Id = 122,
	Node = "Area7_Part2_Props3",
	Name = "长柜上的文件箱",
	PreNode = {
		1240123,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id123] =
{
	Id = 123,
	Node = "Area7_Part2_Props4",
	Name = "文件箱上的文件箱",
	PreNode = {
		1240124,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id124] =
{
	Id = 124,
	Node = "Area7_Part2_Props5",
	Name = "文件箱上的插排",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id125] =
{
	Id = 125,
	Node = "Area7_Part2_Props6",
	Name = "长柜上的文件箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id126] =
{
	Id = 126,
	Node = "Area7_Part3_Props1",
	Name = "地板上的仪器",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id127] =
{
	Id = 127,
	Node = "Area7_Part4_Props1",
	Name = "地板上的纸团",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id128] =
{
	Id = 128,
	Node = "Area7_Part5_Props1",
	Name = "地板上的报纸",
	PreNode = {
		1240129,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id129] =
{
	Id = 129,
	Node = "Area7_Part5_Props2",
	Name = "报纸上的排风扇",
	PreNode = {
		1240130,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id130] =
{
	Id = 130,
	Node = "Area7_Part5_Props3",
	Name = "排风扇上的仪器",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id131] =
{
	Id = 131,
	Node = "Area7_Part5_Props4",
	Name = "报纸上的纸堆",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id132] =
{
	Id = 132,
	Node = "Area7_Part6_Props1",
	Name = "地板上的纸团",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id133] =
{
	Id = 133,
	Node = "Area7_Part7_Props1",
	Name = "地板上的望远镜",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1210042,
			Num = 1,
		},
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id134] =
{
	Id = 134,
	Node = "Area8_Part1_Props1",
	Name = "地板上的矮柜",
	PreNode = {
		1240135,
		1240136,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id135] =
{
	Id = 135,
	Node = "Area8_Part1_Props2",
	Name = "矮柜上的文件箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id136] =
{
	Id = 136,
	Node = "Area8_Part1_Props3",
	Name = "矮柜上的满的桶装液体",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id137] =
{
	Id = 137,
	Node = "Area8_Part2_Props1",
	Name = "地板上的书本",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id138] =
{
	Id = 138,
	Node = "Area8_Part3_Props1",
	Name = "地板上的展开书本",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id139] =
{
	Id = 139,
	Node = "Area8_Part4_Props1",
	Name = "地板上的壁炉",
	PreNode = {
		1240140,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id140] =
{
	Id = 140,
	Node = "Area8_Part4_Props2",
	Name = "壁炉上的大滩液体",
	PreNode = {
		1240141,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id141] =
{
	Id = 141,
	Node = "Area8_Part4_Props3",
	Name = "大滩液体上的排风扇",
	PreNode = {
		1240142,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id142] =
{
	Id = 142,
	Node = "Area8_Part4_Props4",
	Name = "排风扇上的排风扇",
	PreNode = {
		1240143,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id143] =
{
	Id = 143,
	Node = "Area8_Part4_Props5",
	Name = "排风扇上的仪器",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id144] =
{
	Id = 144,
	Node = "Area8_Part4_Props6",
	Name = "大滩液体上的排风扇",
	PreNode = {
		1240145,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id145] =
{
	Id = 145,
	Node = "Area8_Part4_Props7",
	Name = "排风扇上的挂布",
	PreNode = {
		1240146,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id146] =
{
	Id = 146,
	Node = "Area8_Part4_Props8",
	Name = "挂布上的文件箱",
	PreNode = {
		1240147,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id147] =
{
	Id = 147,
	Node = "Area8_Part4_Props9",
	Name = "文件箱上的仪器",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id148] =
{
	Id = 148,
	Node = "Area8_Part5_Props1",
	Name = "地板上的铁棍",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id149] =
{
	Id = 149,
	Node = "Area8_Part6_Props1",
	Name = "地板上的一摞书",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id150] =
{
	Id = 150,
	Node = "Area8_Part7_Props1",
	Name = "地板上的杂物架",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id151] =
{
	Id = 151,
	Node = "Area9_Part1_Props1",
	Name = "地板上的大型铁栅栏",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id152] =
{
	Id = 152,
	Node = "Area9_Part3_Props1",
	Name = "地板上的木箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id153] =
{
	Id = 153,
	Node = "Area9_Part3_Props2",
	Name = "地板上的木箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id154] =
{
	Id = 154,
	Node = "Area9_Part3_Props3",
	Name = "地板上的木箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id155] =
{
	Id = 155,
	Node = "Area9_Part3_Props4",
	Name = "地板上的长桌",
	PreNode = {
		1240156,
		1240157,
		1240158,
		1240159,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id156] =
{
	Id = 156,
	Node = "Area9_Part3_Props5",
	Name = "长桌上的老式电脑",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id157] =
{
	Id = 157,
	Node = "Area9_Part3_Props6",
	Name = "长桌上的插排",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id158] =
{
	Id = 158,
	Node = "Area9_Part3_Props7",
	Name = "长桌上的满的桶装液体",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id159] =
{
	Id = 159,
	Node = "Area9_Part3_Props8",
	Name = "长桌上的空的桶装液体",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id160] =
{
	Id = 160,
	Node = "Area9_Part5_Props1",
	Name = "地板上的纸堆",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id161] =
{
	Id = 161,
	Node = "Area9_Part6_Props1",
	Name = "地板上的书本",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id162] =
{
	Id = 162,
	Node = "Area9_Part7_Props1",
	Name = "地板上的展开书本",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id163] =
{
	Id = 163,
	Node = "Area9_Part8_Props1",
	Name = "地板上的报纸",
	PreNode = {
		1240164,
		1240165,
		1240166,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id164] =
{
	Id = 164,
	Node = "Area9_Part8_Props2",
	Name = "报纸上的双层纸箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id165] =
{
	Id = 165,
	Node = "Area9_Part8_Props3",
	Name = "报纸上的电力箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id166] =
{
	Id = 166,
	Node = "Area9_Part8_Props4",
	Name = "报纸上的纸板箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id167] =
{
	Id = 167,
	Node = "Area9_Part9_Props1",
	Name = "地板上的报纸",
	PreNode = {
		1240168,
		1240169,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id168] =
{
	Id = 168,
	Node = "Area9_Part9_Props2",
	Name = "报纸上的双层纸箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id169] =
{
	Id = 169,
	Node = "Area9_Part9_Props3",
	Name = "报纸上的书本",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id170] =
{
	Id = 170,
	Node = "Area9_Part10_Props1",
	Name = "地板上的旧报纸",
	PreNode = {
		1240171,
		1240172,
		1240173,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id171] =
{
	Id = 171,
	Node = "Area9_Part10_Props2",
	Name = "旧报纸上的纸团",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id172] =
{
	Id = 172,
	Node = "Area9_Part10_Props3",
	Name = "旧报纸上的一摞书",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id173] =
{
	Id = 173,
	Node = "Area9_Part10_Props4",
	Name = "旧报纸上的大滩液体",
	PreNode = {
		1240174,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id174] =
{
	Id = 174,
	Node = "Area9_Part10_Props5",
	Name = "大滩液体上的倒下的满的桶装液体",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id175] =
{
	Id = 175,
	Node = "Area9_Part10_Props6",
	Name = "旧报纸上的旧花盆",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id176] =
{
	Id = 176,
	Node = "Area9_Part11_Props1",
	Name = "地板上的铁栅栏",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id177] =
{
	Id = 177,
	Node = "Area10_Part1_Props1",
	Name = "地板上的墙壁",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id178] =
{
	Id = 178,
	Node = "Area10_Part2_Props1",
	Name = "地板上的冰箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id179] =
{
	Id = 179,
	Node = "Area10_Part3_Props1",
	Name = "地板上的旧报纸",
	PreNode = {
		1240180,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id180] =
{
	Id = 180,
	Node = "Area10_Part3_Props2",
	Name = "旧报纸上的破门板",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id181] =
{
	Id = 181,
	Node = "Area10_Part4_Props1",
	Name = "地板上的矮柜",
	PreNode = {
		1240182,
		1240183,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id182] =
{
	Id = 182,
	Node = "Area10_Part4_Props2",
	Name = "矮柜上的文件箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id183] =
{
	Id = 183,
	Node = "Area10_Part4_Props3",
	Name = "矮柜上的满的桶装液体",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id184] =
{
	Id = 184,
	Node = "Area10_Part6_Props1",
	Name = "地板上的报纸",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id185] =
{
	Id = 185,
	Node = "Area10_Part7_Props1",
	Name = "地板上的大滩液体",
	PreNode = {
		1240186,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id186] =
{
	Id = 186,
	Node = "Area10_Part7_Props2",
	Name = "大滩液体上的长柜",
	PreNode = {
		1240187,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id187] =
{
	Id = 187,
	Node = "Area10_Part7_Props3",
	Name = "长柜上的长柜",
	PreNode = {
		1240188,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id188] =
{
	Id = 188,
	Node = "Area10_Part7_Props4",
	Name = "长柜上的木箱",
	PreNode = {
		1240189,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id189] =
{
	Id = 189,
	Node = "Area10_Part7_Props5",
	Name = "木箱上的木箱",
	PreNode = {
		1240190,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id190] =
{
	Id = 190,
	Node = "Area10_Part7_Props6",
	Name = "木箱上的插排",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id191] =
{
	Id = 191,
	Node = "Area10_Part7_Props7",
	Name = "长柜上的木箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id192] =
{
	Id = 192,
	Node = "Area10_Part8_Props1",
	Name = "地板上的报纸",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id193] =
{
	Id = 193,
	Node = "Area10_Part9_Props1",
	Name = "地板上的纸团",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id194] =
{
	Id = 194,
	Node = "Area10_Part10_Props1",
	Name = "地板上的书本",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id195] =
{
	Id = 195,
	Node = "Area10_Part11_Props1",
	Name = "地板上的长柜",
	PreNode = {
		1240196,
		1240197,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id196] =
{
	Id = 196,
	Node = "Area10_Part11_Props2",
	Name = "长柜上的仪器",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id197] =
{
	Id = 197,
	Node = "Area10_Part11_Props3",
	Name = "长柜上的一摞书",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id198] =
{
	Id = 198,
	Node = "Area11_Part1_Props1",
	Name = "地板上的放花盆的铁桌",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id199] =
{
	Id = 199,
	Node = "Area11_Part2_Props1",
	Name = "地板上的长柜",
	PreNode = {
		1240200,
		1240201,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id200] =
{
	Id = 200,
	Node = "Area11_Part2_Props2",
	Name = "长柜上的文件箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id201] =
{
	Id = 201,
	Node = "Area11_Part2_Props3",
	Name = "长柜上的文件箱",
	PreNode = {
		1240202,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id202] =
{
	Id = 202,
	Node = "Area11_Part2_Props4",
	Name = "文件箱上的文件箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id203] =
{
	Id = 203,
	Node = "Area11_Part3_Props1",
	Name = "地板上的破门板",
	PreNode = {
		1240204,
		1240205,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id204] =
{
	Id = 204,
	Node = "Area11_Part3_Props2",
	Name = "破门板上的文件箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id205] =
{
	Id = 205,
	Node = "Area11_Part3_Props3",
	Name = "破门板上的文件箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id206] =
{
	Id = 206,
	Node = "Area11_Part4_Props1",
	Name = "地板上的旧报纸",
	PreNode = {
		1240207,
		1240208,
		1240209,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id207] =
{
	Id = 207,
	Node = "Area11_Part4_Props2",
	Name = "报纸上的开口箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id208] =
{
	Id = 208,
	Node = "Area11_Part4_Props3",
	Name = "报纸上的仪器",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id209] =
{
	Id = 209,
	Node = "Area11_Part4_Props4",
	Name = "报纸上的旧木箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id210] =
{
	Id = 210,
	Node = "Area11_Part5_Props1",
	Name = "地板上的木箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id211] =
{
	Id = 211,
	Node = "Area11_Part5_Props2",
	Name = "地板上的木箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id212] =
{
	Id = 212,
	Node = "Area11_Part5_Props3",
	Name = "地板上的木箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id213] =
{
	Id = 213,
	Node = "Area11_Part5_Props4",
	Name = "地板上的长桌",
	PreNode = {
		1240214,
		1240215,
		1240216,
		1240217,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id214] =
{
	Id = 214,
	Node = "Area11_Part5_Props5",
	Name = "长桌上的老式电脑",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id215] =
{
	Id = 215,
	Node = "Area11_Part5_Props6",
	Name = "长桌上的插排",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id216] =
{
	Id = 216,
	Node = "Area11_Part5_Props7",
	Name = "长桌上的满的桶装液体",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id217] =
{
	Id = 217,
	Node = "Area11_Part5_Props8",
	Name = "长桌上的空的桶装液体",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id218] =
{
	Id = 218,
	Node = "Area11_Part6_Props1",
	Name = "地板上的旧报纸",
	PreNode = {
		1240219,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id219] =
{
	Id = 219,
	Node = "Area11_Part6_Props2",
	Name = "旧报纸上的松紧带",
	PreNode = {
		1240220,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id220] =
{
	Id = 220,
	Node = "Area11_Part6_Props3",
	Name = "松紧带上的文件箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id221] =
{
	Id = 221,
	Node = "Area11_Part7_Props1",
	Name = "地板上的报纸",
	PreNode = {
		1240222,
		1240223,
	},
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id222] =
{
	Id = 222,
	Node = "Area11_Part7_Props2",
	Name = "报纸上的开口箱",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}
HomeObstacleConfig[HomeObstacleID.Id223] =
{
	Id = 223,
	Node = "Area11_Part7_Props3",
	Name = "报纸上的书本",
	CostList = {
		{
			Id = 1,
			Num = 500,
		},
		{
			Id = 2,
			Num = 10,
		},
	},
	RewardList = {
		{
			Id = 1,
			Num = 125,
		},
		{
			Id = 2,
			Num = 5,
		},
	},
	TagList = {
		560103,
	},
}

