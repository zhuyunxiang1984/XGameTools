SpaceTravelEventPoolConfig ={};
SpaceTravelEventPoolID = 
{
	Id001 = 810001,
	Id002 = 810002,
	Id003 = 810003,
	Id004 = 810004,
	Id005 = 810005,
	Id006 = 810006,
	Id007 = 810007,
	Id008 = 810008,
	Id009 = 810009,
	Id010 = 810010,
	Id011 = 810011,
	Id012 = 810012,
	Id013 = 810013,
	Id014 = 810014,
	Id015 = 810015,
	Id016 = 810016,
	Id017 = 810017,
	Id018 = 810018,
	Id019 = 810019,
	Id020 = 810020,
	Id021 = 810021,
	Id022 = 810022,
	Id023 = 810023,
	Id024 = 810024,
	Id025 = 810025,
	Id026 = 810026,
}
SpaceTravelEventPoolConfig[SpaceTravelEventPoolID.Id001] =
{
	Id = 1,
	PrefabName = "Normal",
	EventList = {
		{
			Id = 820001,
			Weight = 100,
		},
	},
}
SpaceTravelEventPoolConfig[SpaceTravelEventPoolID.Id002] =
{
	Id = 2,
	PrefabName = "Normal",
	EventList = {
		{
			Id = 820002,
			Weight = 100,
		},
		{
			Id = 820003,
			Weight = 100,
		},
		{
			Id = 820004,
			Weight = 100,
		},
		{
			Id = 820005,
			Weight = 100,
		},
	},
}
SpaceTravelEventPoolConfig[SpaceTravelEventPoolID.Id003] =
{
	Id = 3,
	PrefabName = "Normal",
	EventList = {
		{
			Id = 820006,
			Weight = 100,
		},
		{
			Id = 820007,
			Weight = 100,
		},
		{
			Id = 820008,
			Weight = 100,
		},
		{
			Id = 820009,
			Weight = 100,
		},
		{
			Id = 820010,
			Weight = 100,
		},
		{
			Id = 820011,
			Weight = 100,
		},
		{
			Id = 820015,
			Weight = 100,
		},
		{
			Id = 820016,
			Weight = 100,
		},
		{
			Id = 820017,
			Weight = 100,
		},
		{
			Id = 820018,
			Weight = 100,
		},
		{
			Id = 820019,
			Weight = 100,
		},
		{
			Id = 820020,
			Weight = 100,
		},
	},
}
SpaceTravelEventPoolConfig[SpaceTravelEventPoolID.Id004] =
{
	Id = 4,
	PrefabName = "Normal",
	EffectPrefab = "MeteoriteRain",
	EventList = {
		{
			Id = 820012,
			Weight = 100,
		},
	},
}
SpaceTravelEventPoolConfig[SpaceTravelEventPoolID.Id005] =
{
	Id = 5,
	PrefabName = "Normal",
	EffectPrefab = "SolarFlares",
	EventList = {
		{
			Id = 820013,
			Weight = 100,
		},
	},
}
SpaceTravelEventPoolConfig[SpaceTravelEventPoolID.Id006] =
{
	Id = 6,
	PrefabName = "Normal",
	EffectPrefab = "CurvilinearSpace",
	EventList = {
		{
			Id = 820014,
			Weight = 100,
		},
	},
}
SpaceTravelEventPoolConfig[SpaceTravelEventPoolID.Id007] =
{
	Id = 7,
	PrefabName = "Discovery",
	EventList = {
		{
			Id = 820021,
			Weight = 50,
		},
		{
			Id = 820022,
			Weight = 100,
		},
	},
}
SpaceTravelEventPoolConfig[SpaceTravelEventPoolID.Id008] =
{
	Id = 8,
	PrefabName = "Battle",
	EventList = {
		{
			Id = 820023,
			Weight = 100,
		},
	},
}
SpaceTravelEventPoolConfig[SpaceTravelEventPoolID.Id009] =
{
	Id = 9,
	PrefabName = "Deal",
	EventList = {
		{
			Id = 820024,
			Weight = 100,
		},
		{
			Id = 820025,
			Weight = 100,
		},
		{
			Id = 820026,
			Weight = 100,
		},
		{
			Id = 820027,
			Weight = 100,
		},
	},
}
SpaceTravelEventPoolConfig[SpaceTravelEventPoolID.Id010] =
{
	Id = 10,
	PrefabName = "Boss",
	EventList = {
		{
			Id = 820028,
			Weight = 100,
		},
	},
}
SpaceTravelEventPoolConfig[SpaceTravelEventPoolID.Id011] =
{
	Id = 11,
	PrefabName = "Camp1",
	EventList = {
		{
			Id = 820029,
			Weight = 100,
			PreCondition = {
				{
					Value = 780001,
					NumMin = 0,
					NumMax = 499,
				},
			},
		},
		{
			Id = 820030,
			Weight = 100,
			PreCondition = {
				{
					Value = 780001,
					NumMin = 500,
					NumMax = 999,
				},
			},
		},
		{
			Id = 820031,
			Weight = 100,
			PreCondition = {
				{
					Value = 780001,
					NumMin = 1000,
					NumMax = 1499,
				},
			},
		},
		{
			Id = 820032,
			Weight = 100,
			PreCondition = {
				{
					Value = 780001,
					NumMin = 1500,
					NumMax = 1999,
				},
			},
		},
		{
			Id = 820033,
			Weight = 100,
			PreCondition = {
				{
					Value = 780001,
					NumMin = 2000,
					NumMax = 2499,
				},
			},
		},
		{
			Id = 820034,
			Weight = 100,
			PreCondition = {
				{
					Value = 780001,
					NumMin = 2500,
					NumMax = 2999,
				},
			},
		},
		{
			Id = 820035,
			Weight = 100,
			PreCondition = {
				{
					Value = 780001,
					NumMin = 3000,
					NumMax = 9999,
				},
			},
		},
	},
}
SpaceTravelEventPoolConfig[SpaceTravelEventPoolID.Id012] =
{
	Id = 12,
	PrefabName = "Camp2",
	EventList = {
		{
			Id = 820036,
			Weight = 100,
			PreCondition = {
				{
					Value = 780002,
					NumMin = 0,
					NumMax = 499,
				},
			},
		},
		{
			Id = 820037,
			Weight = 100,
			PreCondition = {
				{
					Value = 780002,
					NumMin = 500,
					NumMax = 999,
				},
			},
		},
		{
			Id = 820038,
			Weight = 100,
			PreCondition = {
				{
					Value = 780002,
					NumMin = 1000,
					NumMax = 1499,
				},
			},
		},
		{
			Id = 820039,
			Weight = 100,
			PreCondition = {
				{
					Value = 780002,
					NumMin = 1500,
					NumMax = 1999,
				},
			},
		},
		{
			Id = 820040,
			Weight = 100,
			PreCondition = {
				{
					Value = 780002,
					NumMin = 2000,
					NumMax = 2499,
				},
			},
		},
		{
			Id = 820041,
			Weight = 100,
			PreCondition = {
				{
					Value = 780002,
					NumMin = 2500,
					NumMax = 2999,
				},
			},
		},
		{
			Id = 820042,
			Weight = 100,
			PreCondition = {
				{
					Value = 780002,
					NumMin = 3000,
					NumMax = 9999,
				},
			},
		},
	},
}
SpaceTravelEventPoolConfig[SpaceTravelEventPoolID.Id013] =
{
	Id = 13,
	PrefabName = "Normal",
	EventList = {
		{
			Id = 820043,
			Weight = 100,
		},
		{
			Id = 820044,
			Weight = 100,
		},
		{
			Id = 820045,
			Weight = 100,
		},
		{
			Id = 820046,
			Weight = 100,
		},
		{
			Id = 820047,
			Weight = 100,
		},
		{
			Id = 820048,
			Weight = 100,
		},
		{
			Id = 820049,
			Weight = 100,
		},
		{
			Id = 820050,
			Weight = 100,
		},
		{
			Id = 820051,
			Weight = 100,
		},
		{
			Id = 820052,
			Weight = 100,
		},
		{
			Id = 820053,
			Weight = 100,
		},
		{
			Id = 820054,
			Weight = 100,
		},
		{
			Id = 820055,
			Weight = 100,
		},
		{
			Id = 820056,
			Weight = 100,
		},
		{
			Id = 820057,
			Weight = 100,
		},
		{
			Id = 820058,
			Weight = 100,
		},
		{
			Id = 820059,
			Weight = 100,
		},
		{
			Id = 820060,
			Weight = 100,
		},
		{
			Id = 820061,
			Weight = 100,
		},
		{
			Id = 820062,
			Weight = 100,
		},
		{
			Id = 820063,
			Weight = 100,
		},
		{
			Id = 820064,
			Weight = 100,
		},
		{
			Id = 820065,
			Weight = 100,
		},
		{
			Id = 820066,
			Weight = 100,
		},
	},
}
SpaceTravelEventPoolConfig[SpaceTravelEventPoolID.Id014] =
{
	Id = 14,
	PrefabName = "Normal",
	EventList = {
		{
			Id = 820067,
			Weight = 100,
		},
		{
			Id = 820068,
			Weight = 100,
		},
		{
			Id = 820069,
			Weight = 100,
		},
		{
			Id = 820070,
			Weight = 100,
		},
		{
			Id = 820071,
			Weight = 100,
		},
		{
			Id = 820072,
			Weight = 100,
			PreCondition = {
				{
					Value = 770301,
					NumMin = 1,
					NumMax = 100,
				},
			},
		},
		{
			Id = 820073,
			Weight = 100,
			PreCondition = {
				{
					Value = 770304,
					NumMin = 1,
					NumMax = 100,
				},
			},
		},
	},
}
SpaceTravelEventPoolConfig[SpaceTravelEventPoolID.Id015] =
{
	Id = 15,
	PrefabName = "Normal",
	EventList = {
		{
			Id = 820074,
			Weight = 100,
		},
		{
			Id = 820075,
			Weight = 100,
		},
		{
			Id = 820076,
			Weight = 100,
		},
		{
			Id = 820077,
			Weight = 100,
		},
		{
			Id = 820078,
			Weight = 100,
		},
	},
}
SpaceTravelEventPoolConfig[SpaceTravelEventPoolID.Id016] =
{
	Id = 16,
	PrefabName = "Normal",
	EventList = {
		{
			Id = 820079,
			Weight = 100,
		},
		{
			Id = 820080,
			Weight = 100,
		},
		{
			Id = 820081,
			Weight = 100,
		},
		{
			Id = 820082,
			Weight = 100,
		},
		{
			Id = 820083,
			Weight = 100,
		},
		{
			Id = 820084,
			Weight = 100,
		},
		{
			Id = 820088,
			Weight = 100,
		},
		{
			Id = 820089,
			Weight = 100,
		},
		{
			Id = 820090,
			Weight = 100,
		},
		{
			Id = 820091,
			Weight = 100,
		},
		{
			Id = 820092,
			Weight = 100,
		},
		{
			Id = 820093,
			Weight = 100,
		},
		{
			Id = 820094,
			Weight = 100,
		},
		{
			Id = 820095,
			Weight = 0,
		},
		{
			Id = 820096,
			Weight = 0,
		},
		{
			Id = 820097,
			Weight = 0,
		},
		{
			Id = 820098,
			Weight = 100,
		},
		{
			Id = 820099,
			Weight = 100,
		},
		{
			Id = 820100,
			Weight = 100,
		},
		{
			Id = 820101,
			Weight = 100,
		},
		{
			Id = 820102,
			Weight = 100,
		},
		{
			Id = 820103,
			Weight = 100,
		},
		{
			Id = 820104,
			Weight = 100,
		},
		{
			Id = 820105,
			Weight = 100,
		},
		{
			Id = 820106,
			Weight = 100,
		},
		{
			Id = 820107,
			Weight = 100,
		},
		{
			Id = 820108,
			Weight = 100,
		},
	},
}
SpaceTravelEventPoolConfig[SpaceTravelEventPoolID.Id017] =
{
	Id = 17,
	PrefabName = "Normal",
	EffectPrefab = "MeteoriteRain",
	EventList = {
		{
			Id = 820085,
			Weight = 100,
		},
	},
}
SpaceTravelEventPoolConfig[SpaceTravelEventPoolID.Id018] =
{
	Id = 18,
	PrefabName = "Normal",
	EffectPrefab = "SolarFlares",
	EventList = {
		{
			Id = 820086,
			Weight = 100,
		},
	},
}
SpaceTravelEventPoolConfig[SpaceTravelEventPoolID.Id019] =
{
	Id = 19,
	PrefabName = "Normal",
	EffectPrefab = "CurvilinearSpace",
	EventList = {
		{
			Id = 820087,
			Weight = 100,
		},
	},
}
SpaceTravelEventPoolConfig[SpaceTravelEventPoolID.Id020] =
{
	Id = 20,
	PrefabName = "Discovery",
	EventList = {
		{
			Id = 820109,
			Weight = 50,
		},
		{
			Id = 820110,
			Weight = 100,
		},
	},
}
SpaceTravelEventPoolConfig[SpaceTravelEventPoolID.Id021] =
{
	Id = 21,
	PrefabName = "Battle",
	EventList = {
		{
			Id = 820111,
			Weight = 100,
		},
	},
}
SpaceTravelEventPoolConfig[SpaceTravelEventPoolID.Id022] =
{
	Id = 22,
	PrefabName = "Deal",
	EventList = {
		{
			Id = 820112,
			Weight = 100,
		},
		{
			Id = 820113,
			Weight = 100,
		},
		{
			Id = 820114,
			Weight = 100,
		},
		{
			Id = 820115,
			Weight = 100,
		},
		{
			Id = 820116,
			Weight = 100,
		},
	},
}
SpaceTravelEventPoolConfig[SpaceTravelEventPoolID.Id023] =
{
	Id = 23,
	PrefabName = "Boss",
	EventList = {
		{
			Id = 820117,
			Weight = 100,
		},
	},
}
SpaceTravelEventPoolConfig[SpaceTravelEventPoolID.Id024] =
{
	Id = 24,
	PrefabName = "Camp1",
	EventList = {
		{
			Id = 820118,
			Weight = 100,
			PreCondition = {
				{
					Value = 780001,
					NumMin = 0,
					NumMax = 499,
				},
			},
		},
		{
			Id = 820119,
			Weight = 100,
			PreCondition = {
				{
					Value = 780001,
					NumMin = 500,
					NumMax = 999,
				},
			},
		},
		{
			Id = 820120,
			Weight = 100,
			PreCondition = {
				{
					Value = 780001,
					NumMin = 1000,
					NumMax = 1499,
				},
			},
		},
		{
			Id = 820121,
			Weight = 100,
			PreCondition = {
				{
					Value = 780001,
					NumMin = 1500,
					NumMax = 1999,
				},
			},
		},
		{
			Id = 820122,
			Weight = 100,
			PreCondition = {
				{
					Value = 780001,
					NumMin = 2000,
					NumMax = 2499,
				},
			},
		},
		{
			Id = 820123,
			Weight = 100,
			PreCondition = {
				{
					Value = 780001,
					NumMin = 2500,
					NumMax = 2999,
				},
			},
		},
		{
			Id = 820124,
			Weight = 100,
			PreCondition = {
				{
					Value = 780001,
					NumMin = 3000,
					NumMax = 9999,
				},
			},
		},
	},
}
SpaceTravelEventPoolConfig[SpaceTravelEventPoolID.Id025] =
{
	Id = 25,
	PrefabName = "Camp2",
	EventList = {
		{
			Id = 820125,
			Weight = 100,
			PreCondition = {
				{
					Value = 780002,
					NumMin = 0,
					NumMax = 499,
				},
			},
		},
		{
			Id = 820126,
			Weight = 100,
			PreCondition = {
				{
					Value = 780002,
					NumMin = 500,
					NumMax = 999,
				},
			},
		},
		{
			Id = 820127,
			Weight = 100,
			PreCondition = {
				{
					Value = 780002,
					NumMin = 1000,
					NumMax = 1499,
				},
			},
		},
		{
			Id = 820128,
			Weight = 100,
			PreCondition = {
				{
					Value = 780002,
					NumMin = 1500,
					NumMax = 1999,
				},
			},
		},
		{
			Id = 820129,
			Weight = 100,
			PreCondition = {
				{
					Value = 780002,
					NumMin = 2000,
					NumMax = 2499,
				},
			},
		},
		{
			Id = 820130,
			Weight = 100,
			PreCondition = {
				{
					Value = 780002,
					NumMin = 2500,
					NumMax = 2999,
				},
			},
		},
		{
			Id = 820131,
			Weight = 100,
			PreCondition = {
				{
					Value = 780002,
					NumMin = 3000,
					NumMax = 9999,
				},
			},
		},
	},
}
SpaceTravelEventPoolConfig[SpaceTravelEventPoolID.Id026] =
{
	Id = 26,
	PrefabName = "Normal",
	EventList = {
		{
			Id = 820132,
			Weight = 100,
		},
		{
			Id = 820133,
			Weight = 100,
		},
		{
			Id = 820134,
			Weight = 100,
		},
		{
			Id = 820135,
			Weight = 100,
		},
		{
			Id = 820136,
			Weight = 100,
		},
		{
			Id = 820137,
			Weight = 100,
		},
		{
			Id = 820138,
			Weight = 100,
		},
		{
			Id = 820139,
			Weight = 100,
		},
		{
			Id = 820140,
			Weight = 100,
		},
		{
			Id = 820141,
			Weight = 100,
		},
		{
			Id = 820142,
			Weight = 100,
		},
		{
			Id = 820143,
			Weight = 100,
		},
		{
			Id = 820144,
			Weight = 100,
		},
		{
			Id = 820145,
			Weight = 100,
		},
		{
			Id = 820146,
			Weight = 100,
		},
		{
			Id = 820147,
			Weight = 100,
		},
		{
			Id = 820148,
			Weight = 100,
		},
		{
			Id = 820149,
			Weight = 100,
		},
		{
			Id = 820150,
			Weight = 100,
		},
		{
			Id = 820151,
			Weight = 100,
		},
		{
			Id = 820152,
			Weight = 100,
		},
		{
			Id = 820153,
			Weight = 100,
		},
		{
			Id = 820154,
			Weight = 100,
		},
		{
			Id = 820155,
			Weight = 100,
		},
	},
}
