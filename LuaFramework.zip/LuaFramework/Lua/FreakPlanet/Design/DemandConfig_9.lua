
DemandConfig[DemandID.Id901] =
{
	Id = 901,
	Name = "检验锤子",
	Desc = "我新买了一把金锤子，为了检验是否坚硬，需要一些礁石。",
	Value = 321806,
	Active = false,
	Weight = 75980,
	PreGoal = 
	{
		301655,
		301730,
	},
	GoodsId = 9101806,
	Priority = 1807170,
	Num = 85,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 205632,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 349,
				},
				{
					Value = 1,
					Num = 31132,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 349,
				},
				{
					Value = 1,
					Num = 31132,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 69,
				},
				{
					Value = 1,
					Num = 33132,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 69,
				},
				{
					Value = 1,
					Num = 33132,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 13,
				},
				{
					Value = 1,
					Num = 43132,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 13,
				},
				{
					Value = 1,
					Num = 43132,
				},
			},
		},
	},
	DemandID = 410901,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id902] =
{
	Id = 902,
	Name = "制作裙子",
	Desc = "想做一些闪闪发光的小裙子，需要鱼鳞作为素材。",
	Value = 321807,
	Active = true,
	Weight = 69620,
	PreGoal = 
	{
		301665,
	},
	CloseGoal = 
	{
		301700,
	},
	GoodsId = 9201807,
	Priority = 1808181,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 69913,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 594,
				},
				{
					Value = 1,
					Num = 10513,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 594,
				},
				{
					Value = 1,
					Num = 10513,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 118,
				},
				{
					Value = 1,
					Num = 10913,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 118,
				},
				{
					Value = 1,
					Num = 10913,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 23,
				},
				{
					Value = 1,
					Num = 12413,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 23,
				},
				{
					Value = 1,
					Num = 12413,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 19913,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 19913,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 419,
				},
				{
					Value = 320051,
					Num = 280,
				},
			},
		},
	},
	DemandID = 410902,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id903] =
{
	Id = 903,
	Name = "胶原蛋白",
	Desc = "我想补充一些胶原蛋白~可以给我一些鱼鳞作为素材吗？",
	Value = 321807,
	Active = true,
	Weight = 70800,
	PreGoal = 
	{
		301665,
		301675,
	},
	CloseGoal = 
	{
		301710,
	},
	GoodsId = 9201807,
	Priority = 1808182,
	Num = 34,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 84894,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 721,
				},
				{
					Value = 1,
					Num = 12794,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 721,
				},
				{
					Value = 1,
					Num = 12794,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 144,
				},
				{
					Value = 1,
					Num = 12894,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 144,
				},
				{
					Value = 1,
					Num = 12894,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 28,
				},
				{
					Value = 1,
					Num = 14894,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 28,
				},
				{
					Value = 1,
					Num = 14894,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 5,
				},
				{
					Value = 1,
					Num = 22394,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 5,
				},
				{
					Value = 1,
					Num = 22394,
				},
			},
		},
	},
	DemandID = 410903,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id904] =
{
	Id = 904,
	Name = "制作裙子",
	Desc = "想做一些闪闪发光的小裙子，需要鱼鳞作为素材。",
	Value = 321807,
	Active = true,
	Weight = 71980,
	PreGoal = 
	{
		301665,
		301685,
	},
	CloseGoal = 
	{
		301725,
	},
	GoodsId = 9201807,
	Priority = 1808183,
	Num = 40,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 99876,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 848,
				},
				{
					Value = 1,
					Num = 15076,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 848,
				},
				{
					Value = 1,
					Num = 15076,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 169,
				},
				{
					Value = 1,
					Num = 15376,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 169,
				},
				{
					Value = 1,
					Num = 15376,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 33,
				},
				{
					Value = 1,
					Num = 17376,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 33,
				},
				{
					Value = 1,
					Num = 17376,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 6,
				},
				{
					Value = 1,
					Num = 24876,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 6,
				},
				{
					Value = 1,
					Num = 24876,
				},
			},
		},
	},
	DemandID = 410904,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id905] =
{
	Id = 905,
	Name = "胶原蛋白",
	Desc = "我想补充一些胶原蛋白~可以给我一些鱼鳞作为素材吗？",
	Value = 321807,
	Active = true,
	Weight = 73750,
	PreGoal = 
	{
		301665,
		301700,
	},
	GoodsId = 9201807,
	Priority = 1808184,
	Num = 46,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 114857,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 976,
				},
				{
					Value = 1,
					Num = 17257,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 976,
				},
				{
					Value = 1,
					Num = 17257,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 195,
				},
				{
					Value = 1,
					Num = 17357,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 195,
				},
				{
					Value = 1,
					Num = 17357,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 39,
				},
				{
					Value = 1,
					Num = 17357,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 39,
				},
				{
					Value = 1,
					Num = 17357,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 7,
				},
				{
					Value = 1,
					Num = 27357,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 7,
				},
				{
					Value = 1,
					Num = 27357,
				},
			},
		},
	},
	DemandID = 410905,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id906] =
{
	Id = 906,
	Name = "制作裙子",
	Desc = "想做一些闪闪发光的小裙子，需要鱼鳞作为素材。",
	Value = 321807,
	Active = false,
	Weight = 75520,
	PreGoal = 
	{
		301665,
		301715,
	},
	GoodsId = 9201807,
	Priority = 1808185,
	Num = 52,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 129838,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 220,
				},
				{
					Value = 1,
					Num = 19838,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 220,
				},
				{
					Value = 1,
					Num = 19838,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 44,
				},
				{
					Value = 1,
					Num = 19838,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 44,
				},
				{
					Value = 1,
					Num = 19838,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 8,
				},
				{
					Value = 1,
					Num = 29838,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 8,
				},
				{
					Value = 1,
					Num = 29838,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 779,
				},
				{
					Value = 320051,
					Num = 519,
				},
			},
		},
	},
	DemandID = 410906,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id907] =
{
	Id = 907,
	Name = "胶原蛋白",
	Desc = "我想补充一些胶原蛋白~可以给我一些鱼鳞作为素材吗？",
	Value = 321807,
	Active = false,
	Weight = 77290,
	PreGoal = 
	{
		301665,
		301730,
	},
	GoodsId = 9201807,
	Priority = 1808186,
	Num = 58,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 144820,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 246,
				},
				{
					Value = 1,
					Num = 21820,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 246,
				},
				{
					Value = 1,
					Num = 21820,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 49,
				},
				{
					Value = 1,
					Num = 22320,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 49,
				},
				{
					Value = 1,
					Num = 22320,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 9,
				},
				{
					Value = 1,
					Num = 32320,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 9,
				},
				{
					Value = 1,
					Num = 32320,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 868,
				},
				{
					Value = 320051,
					Num = 580,
				},
			},
		},
	},
	DemandID = 410907,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id908] =
{
	Id = 908,
	Name = "制作裙子",
	Desc = "想做一些闪闪发光的小裙子，需要鱼鳞作为素材。",
	Value = 321807,
	Active = false,
	Weight = 77290,
	PreGoal = 
	{
		301665,
		301730,
	},
	GoodsId = 9201807,
	Priority = 1808187,
	Num = 66,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 164795,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 280,
				},
				{
					Value = 1,
					Num = 24795,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 280,
				},
				{
					Value = 1,
					Num = 24795,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 56,
				},
				{
					Value = 1,
					Num = 24795,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 56,
				},
				{
					Value = 1,
					Num = 24795,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 11,
				},
				{
					Value = 1,
					Num = 27295,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 11,
				},
				{
					Value = 1,
					Num = 27295,
				},
			},
		},
	},
	DemandID = 410908,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id909] =
{
	Id = 909,
	Name = "胶原蛋白",
	Desc = "我想补充一些胶原蛋白~可以给我一些鱼鳞作为素材吗？",
	Value = 321807,
	Active = false,
	Weight = 77290,
	PreGoal = 
	{
		301665,
		301730,
	},
	GoodsId = 9201807,
	Priority = 1808188,
	Num = 72,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 179776,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 305,
				},
				{
					Value = 1,
					Num = 27276,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 305,
				},
				{
					Value = 1,
					Num = 27276,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 61,
				},
				{
					Value = 1,
					Num = 27276,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 61,
				},
				{
					Value = 1,
					Num = 27276,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 12,
				},
				{
					Value = 1,
					Num = 29776,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 12,
				},
				{
					Value = 1,
					Num = 29776,
				},
			},
		},
	},
	DemandID = 410909,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id910] =
{
	Id = 910,
	Name = "制作裙子",
	Desc = "想做一些闪闪发光的小裙子，需要鱼鳞作为素材。",
	Value = 321807,
	Active = false,
	Weight = 77290,
	PreGoal = 
	{
		301665,
		301730,
	},
	GoodsId = 9201807,
	Priority = 1808189,
	Num = 78,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 194758,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 331,
				},
				{
					Value = 1,
					Num = 29258,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 331,
				},
				{
					Value = 1,
					Num = 29258,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 66,
				},
				{
					Value = 1,
					Num = 29758,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 66,
				},
				{
					Value = 1,
					Num = 29758,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 13,
				},
				{
					Value = 1,
					Num = 32258,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 13,
				},
				{
					Value = 1,
					Num = 32258,
				},
			},
		},
	},
	DemandID = 410910,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id911] =
{
	Id = 911,
	Name = "胶原蛋白",
	Desc = "我想补充一些胶原蛋白~可以给我一些鱼鳞作为素材吗？",
	Value = 321807,
	Active = false,
	Weight = 77290,
	PreGoal = 
	{
		301665,
		301730,
	},
	GoodsId = 9201807,
	Priority = 1808190,
	Num = 85,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 212236,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 360,
				},
				{
					Value = 1,
					Num = 32236,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 360,
				},
				{
					Value = 1,
					Num = 32236,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 72,
				},
				{
					Value = 1,
					Num = 32236,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 72,
				},
				{
					Value = 1,
					Num = 32236,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 14,
				},
				{
					Value = 1,
					Num = 37236,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 14,
				},
				{
					Value = 1,
					Num = 37236,
				},
			},
		},
	},
	DemandID = 410911,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id912] =
{
	Id = 912,
	Name = "海底舞会",
	Desc = "海底舞会开始了，这次一定要抓拍到偶像们的精彩瞬间。",
	Value = 321808,
	Active = true,
	Weight = 69620,
	PreGoal = 
	{
		301922,
		301665,
	},
	CloseGoal = 
	{
		301700,
	},
	GoodsId = 9301808,
	Priority = 1809181,
	Num = 76,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 69027,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 586,
				},
				{
					Value = 1,
					Num = 10427,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 586,
				},
				{
					Value = 1,
					Num = 10427,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 117,
				},
				{
					Value = 1,
					Num = 10527,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 117,
				},
				{
					Value = 1,
					Num = 10527,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 23,
				},
				{
					Value = 1,
					Num = 11527,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 23,
				},
				{
					Value = 1,
					Num = 11527,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 19027,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 19027,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 414,
				},
				{
					Value = 320051,
					Num = 276,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 82,
				},
				{
					Value = 320052,
					Num = 56,
				},
			},
		},
	},
	DemandID = 410912,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id913] =
{
	Id = 913,
	Name = "没收相机",
	Desc = "为了保证偶像的安全，请帮忙没收一下记者们的相机吧。",
	Value = 321808,
	Active = true,
	Weight = 70800,
	PreGoal = 
	{
		301922,
		301675,
	},
	CloseGoal = 
	{
		301710,
	},
	GoodsId = 9301808,
	Priority = 1809182,
	Num = 93,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 84467,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 717,
				},
				{
					Value = 1,
					Num = 12767,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 717,
				},
				{
					Value = 1,
					Num = 12767,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 143,
				},
				{
					Value = 1,
					Num = 12967,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 143,
				},
				{
					Value = 1,
					Num = 12967,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 28,
				},
				{
					Value = 1,
					Num = 14467,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 28,
				},
				{
					Value = 1,
					Num = 14467,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 5,
				},
				{
					Value = 1,
					Num = 21967,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 5,
				},
				{
					Value = 1,
					Num = 21967,
				},
			},
		},
	},
	DemandID = 410913,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id914] =
{
	Id = 914,
	Name = "海底舞会",
	Desc = "海底舞会开始了，这次一定要抓拍到偶像们的精彩瞬间。",
	Value = 321808,
	Active = true,
	Weight = 71980,
	PreGoal = 
	{
		301922,
		301685,
	},
	CloseGoal = 
	{
		301725,
	},
	GoodsId = 9301808,
	Priority = 1809183,
	Num = 111,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 100815,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 856,
				},
				{
					Value = 1,
					Num = 15215,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 856,
				},
				{
					Value = 1,
					Num = 15215,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 171,
				},
				{
					Value = 1,
					Num = 15315,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 171,
				},
				{
					Value = 1,
					Num = 15315,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 34,
				},
				{
					Value = 1,
					Num = 15815,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 34,
				},
				{
					Value = 1,
					Num = 15815,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 6,
				},
				{
					Value = 1,
					Num = 25815,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 6,
				},
				{
					Value = 1,
					Num = 25815,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 604,
				},
				{
					Value = 320051,
					Num = 404,
				},
			},
		},
	},
	DemandID = 410914,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id915] =
{
	Id = 915,
	Name = "没收相机",
	Desc = "为了保证偶像的安全，请帮忙没收一下记者们的相机吧。",
	Value = 321808,
	Active = true,
	Weight = 73750,
	PreGoal = 
	{
		301922,
		301700,
	},
	GoodsId = 9301808,
	Priority = 1809184,
	Num = 128,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 116256,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 988,
				},
				{
					Value = 1,
					Num = 17456,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 988,
				},
				{
					Value = 1,
					Num = 17456,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 197,
				},
				{
					Value = 1,
					Num = 17756,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 197,
				},
				{
					Value = 1,
					Num = 17756,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 39,
				},
				{
					Value = 1,
					Num = 18756,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 39,
				},
				{
					Value = 1,
					Num = 18756,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 7,
				},
				{
					Value = 1,
					Num = 28756,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 7,
				},
				{
					Value = 1,
					Num = 28756,
				},
			},
		},
	},
	DemandID = 410915,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id916] =
{
	Id = 916,
	Name = "海底舞会",
	Desc = "海底舞会开始了，这次一定要抓拍到偶像们的精彩瞬间。",
	Value = 321808,
	Active = false,
	Weight = 75520,
	PreGoal = 
	{
		301922,
		301715,
	},
	GoodsId = 9301808,
	Priority = 1809185,
	Num = 146,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 132604,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 225,
				},
				{
					Value = 1,
					Num = 20104,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 225,
				},
				{
					Value = 1,
					Num = 20104,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 45,
				},
				{
					Value = 1,
					Num = 20104,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 45,
				},
				{
					Value = 1,
					Num = 20104,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 9,
				},
				{
					Value = 1,
					Num = 20104,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 9,
				},
				{
					Value = 1,
					Num = 20104,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 795,
				},
				{
					Value = 320051,
					Num = 531,
				},
			},
		},
	},
	DemandID = 410916,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id917] =
{
	Id = 917,
	Name = "没收相机",
	Desc = "为了保证偶像的安全，请帮忙没收一下记者们的相机吧。",
	Value = 321808,
	Active = false,
	Weight = 77290,
	PreGoal = 
	{
		301922,
		301730,
	},
	GoodsId = 9301808,
	Priority = 1809186,
	Num = 162,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 147136,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 250,
				},
				{
					Value = 1,
					Num = 22136,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 250,
				},
				{
					Value = 1,
					Num = 22136,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 50,
				},
				{
					Value = 1,
					Num = 22136,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 50,
				},
				{
					Value = 1,
					Num = 22136,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 10,
				},
				{
					Value = 1,
					Num = 22136,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 10,
				},
				{
					Value = 1,
					Num = 22136,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 882,
				},
				{
					Value = 320051,
					Num = 589,
				},
			},
		},
	},
	DemandID = 410917,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id918] =
{
	Id = 918,
	Name = "海底舞会",
	Desc = "海底舞会开始了，这次一定要抓拍到偶像们的精彩瞬间。",
	Value = 321808,
	Active = false,
	Weight = 77290,
	PreGoal = 
	{
		301922,
		301730,
	},
	GoodsId = 9301808,
	Priority = 1809187,
	Num = 180,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 163485,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 277,
				},
				{
					Value = 1,
					Num = 24985,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 277,
				},
				{
					Value = 1,
					Num = 24985,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 55,
				},
				{
					Value = 1,
					Num = 25985,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 55,
				},
				{
					Value = 1,
					Num = 25985,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 11,
				},
				{
					Value = 1,
					Num = 25985,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 11,
				},
				{
					Value = 1,
					Num = 25985,
				},
			},
		},
	},
	DemandID = 410918,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id919] =
{
	Id = 919,
	Name = "没收相机",
	Desc = "为了保证偶像的安全，请帮忙没收一下记者们的相机吧。",
	Value = 321808,
	Active = false,
	Weight = 77290,
	PreGoal = 
	{
		301922,
		301730,
	},
	GoodsId = 9301808,
	Priority = 1809188,
	Num = 198,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 179833,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 305,
				},
				{
					Value = 1,
					Num = 27333,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 305,
				},
				{
					Value = 1,
					Num = 27333,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 61,
				},
				{
					Value = 1,
					Num = 27333,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 61,
				},
				{
					Value = 1,
					Num = 27333,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 12,
				},
				{
					Value = 1,
					Num = 29833,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 12,
				},
				{
					Value = 1,
					Num = 29833,
				},
			},
		},
	},
	DemandID = 410919,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id920] =
{
	Id = 920,
	Name = "海底舞会",
	Desc = "海底舞会开始了，这次一定要抓拍到偶像们的精彩瞬间。",
	Value = 321808,
	Active = false,
	Weight = 77290,
	PreGoal = 
	{
		301922,
		301730,
	},
	GoodsId = 9301808,
	Priority = 1809189,
	Num = 216,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 196182,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 333,
				},
				{
					Value = 1,
					Num = 29682,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 333,
				},
				{
					Value = 1,
					Num = 29682,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 66,
				},
				{
					Value = 1,
					Num = 31182,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 66,
				},
				{
					Value = 1,
					Num = 31182,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 13,
				},
				{
					Value = 1,
					Num = 33682,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 13,
				},
				{
					Value = 1,
					Num = 33682,
				},
			},
		},
	},
	DemandID = 410920,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id921] =
{
	Id = 921,
	Name = "没收相机",
	Desc = "为了保证偶像的安全，请帮忙没收一下记者们的相机吧。",
	Value = 321808,
	Active = false,
	Weight = 77290,
	PreGoal = 
	{
		301922,
		301730,
	},
	GoodsId = 9301808,
	Priority = 1809190,
	Num = 232,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 210714,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 358,
				},
				{
					Value = 1,
					Num = 31714,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 358,
				},
				{
					Value = 1,
					Num = 31714,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 71,
				},
				{
					Value = 1,
					Num = 33214,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 71,
				},
				{
					Value = 1,
					Num = 33214,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 14,
				},
				{
					Value = 1,
					Num = 35714,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 14,
				},
				{
					Value = 1,
					Num = 35714,
				},
			},
		},
	},
	DemandID = 410921,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id922] =
{
	Id = 922,
	Name = "蹦迪现场",
	Desc = "给我一些耳机吧，到时候大家就能一起蹦迪了。",
	Value = 321809,
	Active = true,
	Weight = 72000,
	PreGoal = 
	{
		301675,
	},
	CloseGoal = 
	{
		301710,
	},
	GoodsId = 9401809,
	Priority = 1810201,
	Num = 26,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 67190,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 571,
				},
				{
					Value = 1,
					Num = 10090,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 571,
				},
				{
					Value = 1,
					Num = 10090,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 114,
				},
				{
					Value = 1,
					Num = 10190,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 114,
				},
				{
					Value = 1,
					Num = 10190,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 22,
				},
				{
					Value = 1,
					Num = 12190,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 22,
				},
				{
					Value = 1,
					Num = 12190,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 17190,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 17190,
				},
			},
		},
	},
	DemandID = 410922,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id923] =
{
	Id = 923,
	Name = "让我听听",
	Desc = "大家都在听什么歌曲呢？让我也听听吧！",
	Value = 321809,
	Active = true,
	Weight = 73200,
	PreGoal = 
	{
		301675,
		301685,
	},
	CloseGoal = 
	{
		301720,
	},
	GoodsId = 9401809,
	Priority = 1810202,
	Num = 32,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 82696,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 702,
				},
				{
					Value = 1,
					Num = 12496,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 702,
				},
				{
					Value = 1,
					Num = 12496,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 140,
				},
				{
					Value = 1,
					Num = 12696,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 140,
				},
				{
					Value = 1,
					Num = 12696,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 28,
				},
				{
					Value = 1,
					Num = 12696,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 28,
				},
				{
					Value = 1,
					Num = 12696,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 5,
				},
				{
					Value = 1,
					Num = 20196,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 5,
				},
				{
					Value = 1,
					Num = 20196,
				},
			},
		},
	},
	DemandID = 410923,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id924] =
{
	Id = 924,
	Name = "蹦迪现场",
	Desc = "给我一些耳机吧，到时候大家就能一起蹦迪了。",
	Value = 321809,
	Active = true,
	Weight = 74400,
	PreGoal = 
	{
		301675,
		301695,
	},
	GoodsId = 9401809,
	Priority = 1810203,
	Num = 38,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 98201,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 834,
				},
				{
					Value = 1,
					Num = 14801,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 834,
				},
				{
					Value = 1,
					Num = 14801,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 166,
				},
				{
					Value = 1,
					Num = 15201,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 166,
				},
				{
					Value = 1,
					Num = 15201,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 33,
				},
				{
					Value = 1,
					Num = 15701,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 33,
				},
				{
					Value = 1,
					Num = 15701,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 6,
				},
				{
					Value = 1,
					Num = 23201,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 6,
				},
				{
					Value = 1,
					Num = 23201,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 589,
				},
				{
					Value = 320051,
					Num = 393,
				},
			},
		},
	},
	DemandID = 410924,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id925] =
{
	Id = 925,
	Name = "让我听听",
	Desc = "大家都在听什么歌曲呢？让我也听听吧！",
	Value = 321809,
	Active = false,
	Weight = 76200,
	PreGoal = 
	{
		301675,
		301710,
	},
	GoodsId = 9401809,
	Priority = 1810204,
	Num = 44,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 113707,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 966,
				},
				{
					Value = 1,
					Num = 17107,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 966,
				},
				{
					Value = 1,
					Num = 17107,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 193,
				},
				{
					Value = 1,
					Num = 17207,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 193,
				},
				{
					Value = 1,
					Num = 17207,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 38,
				},
				{
					Value = 1,
					Num = 18707,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 38,
				},
				{
					Value = 1,
					Num = 18707,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 7,
				},
				{
					Value = 1,
					Num = 26207,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 7,
				},
				{
					Value = 1,
					Num = 26207,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 682,
				},
				{
					Value = 320051,
					Num = 455,
				},
			},
		},
	},
	DemandID = 410925,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id926] =
{
	Id = 926,
	Name = "蹦迪现场",
	Desc = "给我一些耳机吧，到时候大家就能一起蹦迪了。",
	Value = 321809,
	Active = false,
	Weight = 78000,
	PreGoal = 
	{
		301675,
		301725,
	},
	GoodsId = 9401809,
	Priority = 1810205,
	Num = 50,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 129213,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 219,
				},
				{
					Value = 1,
					Num = 19713,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 219,
				},
				{
					Value = 1,
					Num = 19713,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 43,
				},
				{
					Value = 1,
					Num = 21713,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 43,
				},
				{
					Value = 1,
					Num = 21713,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 8,
				},
				{
					Value = 1,
					Num = 29213,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 8,
				},
				{
					Value = 1,
					Num = 29213,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 775,
				},
				{
					Value = 320051,
					Num = 517,
				},
			},
		},
	},
	DemandID = 410926,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id927] =
{
	Id = 927,
	Name = "让我听听",
	Desc = "大家都在听什么歌曲呢？让我也听听吧！",
	Value = 321809,
	Active = false,
	Weight = 78600,
	PreGoal = 
	{
		301675,
		301730,
	},
	GoodsId = 9401809,
	Priority = 1810206,
	Num = 56,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 144718,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 246,
				},
				{
					Value = 1,
					Num = 21718,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 246,
				},
				{
					Value = 1,
					Num = 21718,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 49,
				},
				{
					Value = 1,
					Num = 22218,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 49,
				},
				{
					Value = 1,
					Num = 22218,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 9,
				},
				{
					Value = 1,
					Num = 32218,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 9,
				},
				{
					Value = 1,
					Num = 32218,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 868,
				},
				{
					Value = 320051,
					Num = 579,
				},
			},
		},
	},
	DemandID = 410927,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id928] =
{
	Id = 928,
	Name = "蹦迪现场",
	Desc = "给我一些耳机吧，到时候大家就能一起蹦迪了。",
	Value = 321809,
	Active = false,
	Weight = 78600,
	PreGoal = 
	{
		301675,
		301730,
	},
	GoodsId = 9401809,
	Priority = 1810207,
	Num = 62,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 160224,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 272,
				},
				{
					Value = 1,
					Num = 24224,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 272,
				},
				{
					Value = 1,
					Num = 24224,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 54,
				},
				{
					Value = 1,
					Num = 25224,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 54,
				},
				{
					Value = 1,
					Num = 25224,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 10,
				},
				{
					Value = 1,
					Num = 35224,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 10,
				},
				{
					Value = 1,
					Num = 35224,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 961,
				},
				{
					Value = 320051,
					Num = 641,
				},
			},
		},
	},
	DemandID = 410928,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id929] =
{
	Id = 929,
	Name = "让我听听",
	Desc = "大家都在听什么歌曲呢？让我也听听吧！",
	Value = 321809,
	Active = false,
	Weight = 78600,
	PreGoal = 
	{
		301675,
		301730,
	},
	GoodsId = 9401809,
	Priority = 1810208,
	Num = 68,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 175729,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 298,
				},
				{
					Value = 1,
					Num = 26729,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 298,
				},
				{
					Value = 1,
					Num = 26729,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 59,
				},
				{
					Value = 1,
					Num = 28229,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 59,
				},
				{
					Value = 1,
					Num = 28229,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 11,
				},
				{
					Value = 1,
					Num = 38229,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 11,
				},
				{
					Value = 1,
					Num = 38229,
				},
			},
		},
	},
	DemandID = 410929,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id930] =
{
	Id = 930,
	Name = "蹦迪现场",
	Desc = "给我一些耳机吧，到时候大家就能一起蹦迪了。",
	Value = 321809,
	Active = false,
	Weight = 78600,
	PreGoal = 
	{
		301675,
		301730,
	},
	GoodsId = 9401809,
	Priority = 1810209,
	Num = 72,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 186066,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 316,
				},
				{
					Value = 1,
					Num = 28066,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 316,
				},
				{
					Value = 1,
					Num = 28066,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 63,
				},
				{
					Value = 1,
					Num = 28566,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 63,
				},
				{
					Value = 1,
					Num = 28566,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 12,
				},
				{
					Value = 1,
					Num = 36066,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 12,
				},
				{
					Value = 1,
					Num = 36066,
				},
			},
		},
	},
	DemandID = 410930,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id931] =
{
	Id = 931,
	Name = "让我听听",
	Desc = "大家都在听什么歌曲呢？让我也听听吧！",
	Value = 321809,
	Active = false,
	Weight = 78600,
	PreGoal = 
	{
		301675,
		301730,
	},
	GoodsId = 9401809,
	Priority = 1810210,
	Num = 78,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 201572,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 342,
				},
				{
					Value = 1,
					Num = 30572,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 342,
				},
				{
					Value = 1,
					Num = 30572,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 68,
				},
				{
					Value = 1,
					Num = 31572,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 68,
				},
				{
					Value = 1,
					Num = 31572,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 13,
				},
				{
					Value = 1,
					Num = 39072,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 13,
				},
				{
					Value = 1,
					Num = 39072,
				},
			},
		},
	},
	DemandID = 410931,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id932] =
{
	Id = 932,
	Name = "惊险旅行",
	Desc = "来到无人岛上旅行，暂时用队员服做一下床单吧。",
	Value = 321810,
	Active = true,
	Weight = 73205,
	PreGoal = 
	{
		301938,
		301680,
	},
	CloseGoal = 
	{
		301715,
	},
	GoodsId = 9501810,
	Priority = 1811211,
	Num = 26,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 71431,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 607,
				},
				{
					Value = 1,
					Num = 10731,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 607,
				},
				{
					Value = 1,
					Num = 10731,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 121,
				},
				{
					Value = 1,
					Num = 10931,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 121,
				},
				{
					Value = 1,
					Num = 10931,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 24,
				},
				{
					Value = 1,
					Num = 11431,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 24,
				},
				{
					Value = 1,
					Num = 11431,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 21431,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 21431,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 428,
				},
				{
					Value = 320051,
					Num = 286,
				},
			},
		},
	},
	DemandID = 410932,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id933] =
{
	Id = 933,
	Name = "奇妙尝试",
	Desc = "看到偶像们都在穿，我也想尝试一下。",
	Value = 321810,
	Active = true,
	Weight = 74415,
	PreGoal = 
	{
		301938,
		301690,
	},
	CloseGoal = 
	{
		301725,
	},
	GoodsId = 9501810,
	Priority = 1811212,
	Num = 32,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 87915,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 747,
				},
				{
					Value = 1,
					Num = 13215,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 747,
				},
				{
					Value = 1,
					Num = 13215,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 149,
				},
				{
					Value = 1,
					Num = 13415,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 149,
				},
				{
					Value = 1,
					Num = 13415,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 29,
				},
				{
					Value = 1,
					Num = 15415,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 29,
				},
				{
					Value = 1,
					Num = 15415,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 5,
				},
				{
					Value = 1,
					Num = 25415,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 5,
				},
				{
					Value = 1,
					Num = 25415,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 527,
				},
				{
					Value = 320051,
					Num = 352,
				},
			},
		},
	},
	DemandID = 410933,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id934] =
{
	Id = 934,
	Name = "惊险旅行",
	Desc = "来到无人岛上旅行，暂时用队员服做一下床单吧。",
	Value = 321810,
	Active = true,
	Weight = 75625,
	PreGoal = 
	{
		301938,
		301700,
	},
	GoodsId = 9501810,
	Priority = 1811213,
	Num = 38,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 104399,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 887,
				},
				{
					Value = 1,
					Num = 15699,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 887,
				},
				{
					Value = 1,
					Num = 15699,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 177,
				},
				{
					Value = 1,
					Num = 15899,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 177,
				},
				{
					Value = 1,
					Num = 15899,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 35,
				},
				{
					Value = 1,
					Num = 16899,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 35,
				},
				{
					Value = 1,
					Num = 16899,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 7,
				},
				{
					Value = 1,
					Num = 16899,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 7,
				},
				{
					Value = 1,
					Num = 16899,
				},
			},
		},
	},
	DemandID = 410934,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id935] =
{
	Id = 935,
	Name = "奇妙尝试",
	Desc = "看到偶像们都在穿，我也想尝试一下。",
	Value = 321810,
	Active = false,
	Weight = 77440,
	PreGoal = 
	{
		301938,
		301715,
	},
	GoodsId = 9501810,
	Priority = 1811214,
	Num = 44,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 120883,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 205,
				},
				{
					Value = 1,
					Num = 18383,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 205,
				},
				{
					Value = 1,
					Num = 18383,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 41,
				},
				{
					Value = 1,
					Num = 18383,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 41,
				},
				{
					Value = 1,
					Num = 18383,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 8,
				},
				{
					Value = 1,
					Num = 20883,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 8,
				},
				{
					Value = 1,
					Num = 20883,
				},
			},
		},
	},
	DemandID = 410935,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id936] =
{
	Id = 936,
	Name = "惊险旅行",
	Desc = "来到无人岛上旅行，暂时用队员服做一下床单吧。",
	Value = 321810,
	Active = false,
	Weight = 79255,
	PreGoal = 
	{
		301938,
		301730,
	},
	GoodsId = 9501810,
	Priority = 1811215,
	Num = 50,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 137368,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 233,
				},
				{
					Value = 1,
					Num = 20868,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 233,
				},
				{
					Value = 1,
					Num = 20868,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 46,
				},
				{
					Value = 1,
					Num = 22368,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 46,
				},
				{
					Value = 1,
					Num = 22368,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 9,
				},
				{
					Value = 1,
					Num = 24868,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 9,
				},
				{
					Value = 1,
					Num = 24868,
				},
			},
		},
	},
	DemandID = 410936,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id937] =
{
	Id = 937,
	Name = "奇妙尝试",
	Desc = "看到偶像们都在穿，我也想尝试一下。",
	Value = 321810,
	Active = false,
	Weight = 79255,
	PreGoal = 
	{
		301938,
		301730,
	},
	GoodsId = 9501810,
	Priority = 1811216,
	Num = 56,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 153852,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 261,
				},
				{
					Value = 1,
					Num = 23352,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 261,
				},
				{
					Value = 1,
					Num = 23352,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 52,
				},
				{
					Value = 1,
					Num = 23852,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 52,
				},
				{
					Value = 1,
					Num = 23852,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 10,
				},
				{
					Value = 1,
					Num = 28852,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 10,
				},
				{
					Value = 1,
					Num = 28852,
				},
			},
		},
	},
	DemandID = 410937,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id938] =
{
	Id = 938,
	Name = "惊险旅行",
	Desc = "来到无人岛上旅行，暂时用队员服做一下床单吧。",
	Value = 321810,
	Active = false,
	Weight = 79255,
	PreGoal = 
	{
		301938,
		301730,
	},
	GoodsId = 9501810,
	Priority = 1811217,
	Num = 62,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 170336,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 289,
				},
				{
					Value = 1,
					Num = 25836,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 289,
				},
				{
					Value = 1,
					Num = 25836,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 57,
				},
				{
					Value = 1,
					Num = 27836,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 57,
				},
				{
					Value = 1,
					Num = 27836,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 11,
				},
				{
					Value = 1,
					Num = 32836,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 11,
				},
				{
					Value = 1,
					Num = 32836,
				},
			},
		},
	},
	DemandID = 410938,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id939] =
{
	Id = 939,
	Name = "奇妙尝试",
	Desc = "看到偶像们都在穿，我也想尝试一下。",
	Value = 321810,
	Active = false,
	Weight = 79255,
	PreGoal = 
	{
		301938,
		301730,
	},
	GoodsId = 9501810,
	Priority = 1811218,
	Num = 68,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 186820,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 317,
				},
				{
					Value = 1,
					Num = 28320,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 317,
				},
				{
					Value = 1,
					Num = 28320,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 63,
				},
				{
					Value = 1,
					Num = 29320,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 63,
				},
				{
					Value = 1,
					Num = 29320,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 12,
				},
				{
					Value = 1,
					Num = 36820,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 12,
				},
				{
					Value = 1,
					Num = 36820,
				},
			},
		},
	},
	DemandID = 410939,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id940] =
{
	Id = 940,
	Name = "惊险旅行",
	Desc = "来到无人岛上旅行，暂时用队员服做一下床单吧。",
	Value = 321810,
	Active = false,
	Weight = 79255,
	PreGoal = 
	{
		301938,
		301730,
	},
	GoodsId = 9501810,
	Priority = 1811219,
	Num = 72,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 197809,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 336,
				},
				{
					Value = 1,
					Num = 29809,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 336,
				},
				{
					Value = 1,
					Num = 29809,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 67,
				},
				{
					Value = 1,
					Num = 30309,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 67,
				},
				{
					Value = 1,
					Num = 30309,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 13,
				},
				{
					Value = 1,
					Num = 35309,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 13,
				},
				{
					Value = 1,
					Num = 35309,
				},
			},
		},
	},
	DemandID = 410940,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id941] =
{
	Id = 941,
	Name = "奇妙尝试",
	Desc = "看到偶像们都在穿，我也想尝试一下。",
	Value = 321810,
	Active = false,
	Weight = 79255,
	PreGoal = 
	{
		301938,
		301730,
	},
	GoodsId = 9501810,
	Priority = 1811220,
	Num = 78,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 214294,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 364,
				},
				{
					Value = 1,
					Num = 32294,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 364,
				},
				{
					Value = 1,
					Num = 32294,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 72,
				},
				{
					Value = 1,
					Num = 34294,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 72,
				},
				{
					Value = 1,
					Num = 34294,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 14,
				},
				{
					Value = 1,
					Num = 39294,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 14,
				},
				{
					Value = 1,
					Num = 39294,
				},
			},
		},
	},
	DemandID = 410941,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id942] =
{
	Id = 942,
	Name = "洁厕之王",
	Desc = "厕所太脏了，需要用很多强力海绵擦干净。",
	Value = 321811,
	Active = true,
	Weight = 78125,
	PreGoal = 
	{
		301700,
	},
	GoodsId = 9601811,
	Priority = 1812251,
	Num = 26,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 69573,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 591,
				},
				{
					Value = 1,
					Num = 10473,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 591,
				},
				{
					Value = 1,
					Num = 10473,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 118,
				},
				{
					Value = 1,
					Num = 10573,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 118,
				},
				{
					Value = 1,
					Num = 10573,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 23,
				},
				{
					Value = 1,
					Num = 12073,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 23,
				},
				{
					Value = 1,
					Num = 12073,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 19573,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 19573,
				},
			},
		},
	},
	DemandID = 410942,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id943] =
{
	Id = 943,
	Name = "禁止“洗白”",
	Desc = "鱼乐公司在准备给劣迹偶像“洗白”，快阻止TA们的阴谋。",
	Value = 321811,
	Active = false,
	Weight = 79375,
	PreGoal = 
	{
		301700,
		301710,
	},
	GoodsId = 9601811,
	Priority = 1812252,
	Num = 32,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 85628,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 727,
				},
				{
					Value = 1,
					Num = 12928,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 727,
				},
				{
					Value = 1,
					Num = 12928,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 145,
				},
				{
					Value = 1,
					Num = 13128,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 145,
				},
				{
					Value = 1,
					Num = 13128,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 29,
				},
				{
					Value = 1,
					Num = 13128,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 29,
				},
				{
					Value = 1,
					Num = 13128,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 5,
				},
				{
					Value = 1,
					Num = 23128,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 5,
				},
				{
					Value = 1,
					Num = 23128,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 513,
				},
				{
					Value = 320051,
					Num = 343,
				},
			},
		},
	},
	DemandID = 410943,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id944] =
{
	Id = 944,
	Name = "洁厕之王",
	Desc = "厕所太脏了，需要用很多强力海绵擦干净。",
	Value = 321811,
	Active = false,
	Weight = 80625,
	PreGoal = 
	{
		301700,
		301720,
	},
	GoodsId = 9601811,
	Priority = 1812253,
	Num = 38,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 101683,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 864,
				},
				{
					Value = 1,
					Num = 15283,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 864,
				},
				{
					Value = 1,
					Num = 15283,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 172,
				},
				{
					Value = 1,
					Num = 15683,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 172,
				},
				{
					Value = 1,
					Num = 15683,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 34,
				},
				{
					Value = 1,
					Num = 16683,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 34,
				},
				{
					Value = 1,
					Num = 16683,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 6,
				},
				{
					Value = 1,
					Num = 26683,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 6,
				},
				{
					Value = 1,
					Num = 26683,
				},
			},
		},
	},
	DemandID = 410944,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id945] =
{
	Id = 945,
	Name = "禁止“洗白”",
	Desc = "鱼乐公司在准备给劣迹偶像“洗白”，快阻止TA们的阴谋。",
	Value = 321811,
	Active = false,
	Weight = 81875,
	PreGoal = 
	{
		301700,
		301730,
	},
	GoodsId = 9601811,
	Priority = 1812254,
	Num = 44,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 117739,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 200,
				},
				{
					Value = 1,
					Num = 17739,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 200,
				},
				{
					Value = 1,
					Num = 17739,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 40,
				},
				{
					Value = 1,
					Num = 17739,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 40,
				},
				{
					Value = 1,
					Num = 17739,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 8,
				},
				{
					Value = 1,
					Num = 17739,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 8,
				},
				{
					Value = 1,
					Num = 17739,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 706,
				},
				{
					Value = 320051,
					Num = 471,
				},
			},
		},
	},
	DemandID = 410945,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id946] =
{
	Id = 946,
	Name = "洁厕之王",
	Desc = "厕所太脏了，需要用很多强力海绵擦干净。",
	Value = 321811,
	Active = false,
	Weight = 81875,
	PreGoal = 
	{
		301700,
		301730,
	},
	GoodsId = 9601811,
	Priority = 1812255,
	Num = 50,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 133794,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 227,
				},
				{
					Value = 1,
					Num = 20294,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 227,
				},
				{
					Value = 1,
					Num = 20294,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 45,
				},
				{
					Value = 1,
					Num = 21294,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 45,
				},
				{
					Value = 1,
					Num = 21294,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 9,
				},
				{
					Value = 1,
					Num = 21294,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 9,
				},
				{
					Value = 1,
					Num = 21294,
				},
			},
		},
	},
	DemandID = 410946,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id947] =
{
	Id = 947,
	Name = "禁止“洗白”",
	Desc = "鱼乐公司在准备给劣迹偶像“洗白”，快阻止TA们的阴谋。",
	Value = 321811,
	Active = false,
	Weight = 81875,
	PreGoal = 
	{
		301700,
		301730,
	},
	GoodsId = 9601811,
	Priority = 1812256,
	Num = 56,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 149849,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 254,
				},
				{
					Value = 1,
					Num = 22849,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 254,
				},
				{
					Value = 1,
					Num = 22849,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 50,
				},
				{
					Value = 1,
					Num = 24849,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 50,
				},
				{
					Value = 1,
					Num = 24849,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 10,
				},
				{
					Value = 1,
					Num = 24849,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 10,
				},
				{
					Value = 1,
					Num = 24849,
				},
			},
		},
	},
	DemandID = 410947,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id948] =
{
	Id = 948,
	Name = "洁厕之王",
	Desc = "厕所太脏了，需要用很多强力海绵擦干净。",
	Value = 321811,
	Active = false,
	Weight = 81875,
	PreGoal = 
	{
		301700,
		301730,
	},
	GoodsId = 9601811,
	Priority = 1812257,
	Num = 62,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 165905,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 282,
				},
				{
					Value = 1,
					Num = 24905,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 282,
				},
				{
					Value = 1,
					Num = 24905,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 56,
				},
				{
					Value = 1,
					Num = 25905,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 56,
				},
				{
					Value = 1,
					Num = 25905,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 11,
				},
				{
					Value = 1,
					Num = 28405,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 11,
				},
				{
					Value = 1,
					Num = 28405,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 995,
				},
				{
					Value = 320051,
					Num = 664,
				},
			},
		},
	},
	DemandID = 410948,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id949] =
{
	Id = 949,
	Name = "禁止“洗白”",
	Desc = "鱼乐公司在准备给劣迹偶像“洗白”，快阻止TA们的阴谋。",
	Value = 321811,
	Active = false,
	Weight = 81875,
	PreGoal = 
	{
		301700,
		301730,
	},
	GoodsId = 9601811,
	Priority = 1812258,
	Num = 68,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 181960,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 309,
				},
				{
					Value = 1,
					Num = 27460,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 309,
				},
				{
					Value = 1,
					Num = 27460,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 61,
				},
				{
					Value = 1,
					Num = 29460,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 61,
				},
				{
					Value = 1,
					Num = 29460,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 12,
				},
				{
					Value = 1,
					Num = 31960,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 12,
				},
				{
					Value = 1,
					Num = 31960,
				},
			},
		},
	},
	DemandID = 410949,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id950] =
{
	Id = 950,
	Name = "洁厕之王",
	Desc = "厕所太脏了，需要用很多强力海绵擦干净。",
	Value = 321811,
	Active = false,
	Weight = 81875,
	PreGoal = 
	{
		301700,
		301730,
	},
	GoodsId = 9601811,
	Priority = 1812259,
	Num = 72,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 192664,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 327,
				},
				{
					Value = 1,
					Num = 29164,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 327,
				},
				{
					Value = 1,
					Num = 29164,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 65,
				},
				{
					Value = 1,
					Num = 30164,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 65,
				},
				{
					Value = 1,
					Num = 30164,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 13,
				},
				{
					Value = 1,
					Num = 30164,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 13,
				},
				{
					Value = 1,
					Num = 30164,
				},
			},
		},
	},
	DemandID = 410950,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id951] =
{
	Id = 951,
	Name = "禁止“洗白”",
	Desc = "鱼乐公司在准备给劣迹偶像“洗白”，快阻止TA们的阴谋。",
	Value = 321811,
	Active = false,
	Weight = 81875,
	PreGoal = 
	{
		301700,
		301730,
	},
	GoodsId = 9601811,
	Priority = 1812260,
	Num = 78,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 208719,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 354,
				},
				{
					Value = 1,
					Num = 31719,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 354,
				},
				{
					Value = 1,
					Num = 31719,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 70,
				},
				{
					Value = 1,
					Num = 33719,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 70,
				},
				{
					Value = 1,
					Num = 33719,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 14,
				},
				{
					Value = 1,
					Num = 33719,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 14,
				},
				{
					Value = 1,
					Num = 33719,
				},
			},
		},
	},
	DemandID = 410951,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id952] =
{
	Id = 952,
	Name = "偶像的魅力",
	Desc = "见面会就快到了，一定要准备好应援棒。",
	Value = 321812,
	Active = true,
	Weight = 80645,
	PreGoal = 
	{
		301710,
	},
	GoodsId = 9701812,
	Priority = 1813271,
	Num = 26,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 71751,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 609,
				},
				{
					Value = 1,
					Num = 10851,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 609,
				},
				{
					Value = 1,
					Num = 10851,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 121,
				},
				{
					Value = 1,
					Num = 11251,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 121,
				},
				{
					Value = 1,
					Num = 11251,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 24,
				},
				{
					Value = 1,
					Num = 11751,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 24,
				},
				{
					Value = 1,
					Num = 11751,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 21751,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 21751,
				},
			},
		},
	},
	DemandID = 410952,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id953] =
{
	Id = 953,
	Name = "黑暗中的光",
	Desc = "啊，竟然停电了，麻烦点亮应援棒，把这里照亮吧。",
	Value = 321812,
	Active = false,
	Weight = 81915,
	PreGoal = 
	{
		301710,
		301720,
	},
	GoodsId = 9701812,
	Priority = 1813272,
	Num = 32,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 88309,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 750,
				},
				{
					Value = 1,
					Num = 13309,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 750,
				},
				{
					Value = 1,
					Num = 13309,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 150,
				},
				{
					Value = 1,
					Num = 13309,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 150,
				},
				{
					Value = 1,
					Num = 13309,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 30,
				},
				{
					Value = 1,
					Num = 13309,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 30,
				},
				{
					Value = 1,
					Num = 13309,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 6,
				},
				{
					Value = 1,
					Num = 13309,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 6,
				},
				{
					Value = 1,
					Num = 13309,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 529,
				},
				{
					Value = 320051,
					Num = 354,
				},
			},
		},
	},
	DemandID = 410953,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id954] =
{
	Id = 954,
	Name = "偶像的魅力",
	Desc = "见面会就快到了，一定要准备好应援棒。",
	Value = 321812,
	Active = false,
	Weight = 83185,
	PreGoal = 
	{
		301710,
		301730,
	},
	GoodsId = 9701812,
	Priority = 1813273,
	Num = 38,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 104867,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 891,
				},
				{
					Value = 1,
					Num = 15767,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 891,
				},
				{
					Value = 1,
					Num = 15767,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 178,
				},
				{
					Value = 1,
					Num = 15867,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 178,
				},
				{
					Value = 1,
					Num = 15867,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 35,
				},
				{
					Value = 1,
					Num = 17367,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 35,
				},
				{
					Value = 1,
					Num = 17367,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 7,
				},
				{
					Value = 1,
					Num = 17367,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 7,
				},
				{
					Value = 1,
					Num = 17367,
				},
			},
		},
	},
	DemandID = 410954,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id955] =
{
	Id = 955,
	Name = "黑暗中的光",
	Desc = "啊，竟然停电了，麻烦点亮应援棒，把这里照亮吧。",
	Value = 321812,
	Active = false,
	Weight = 83185,
	PreGoal = 
	{
		301710,
		301730,
	},
	GoodsId = 9701812,
	Priority = 1813274,
	Num = 44,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 121425,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 206,
				},
				{
					Value = 1,
					Num = 18425,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 206,
				},
				{
					Value = 1,
					Num = 18425,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 41,
				},
				{
					Value = 1,
					Num = 18925,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 41,
				},
				{
					Value = 1,
					Num = 18925,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 8,
				},
				{
					Value = 1,
					Num = 21425,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 8,
				},
				{
					Value = 1,
					Num = 21425,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 728,
				},
				{
					Value = 320051,
					Num = 486,
				},
			},
		},
	},
	DemandID = 410955,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id956] =
{
	Id = 956,
	Name = "偶像的魅力",
	Desc = "见面会就快到了，一定要准备好应援棒。",
	Value = 321812,
	Active = false,
	Weight = 83185,
	PreGoal = 
	{
		301710,
		301730,
	},
	GoodsId = 9701812,
	Priority = 1813275,
	Num = 50,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 137984,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 234,
				},
				{
					Value = 1,
					Num = 20984,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 234,
				},
				{
					Value = 1,
					Num = 20984,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 46,
				},
				{
					Value = 1,
					Num = 22984,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 46,
				},
				{
					Value = 1,
					Num = 22984,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 9,
				},
				{
					Value = 1,
					Num = 25484,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 9,
				},
				{
					Value = 1,
					Num = 25484,
				},
			},
		},
	},
	DemandID = 410956,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id957] =
{
	Id = 957,
	Name = "黑暗中的光",
	Desc = "啊，竟然停电了，麻烦点亮应援棒，把这里照亮吧。",
	Value = 321812,
	Active = false,
	Weight = 83185,
	PreGoal = 
	{
		301710,
		301730,
	},
	GoodsId = 9701812,
	Priority = 1813276,
	Num = 56,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 154542,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 262,
				},
				{
					Value = 1,
					Num = 23542,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 262,
				},
				{
					Value = 1,
					Num = 23542,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 52,
				},
				{
					Value = 1,
					Num = 24542,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 52,
				},
				{
					Value = 1,
					Num = 24542,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 10,
				},
				{
					Value = 1,
					Num = 29542,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 10,
				},
				{
					Value = 1,
					Num = 29542,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 927,
				},
				{
					Value = 320051,
					Num = 618,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 185,
				},
				{
					Value = 320052,
					Num = 124,
				},
			},
		},
	},
	DemandID = 410957,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id958] =
{
	Id = 958,
	Name = "偶像的魅力",
	Desc = "见面会就快到了，一定要准备好应援棒。",
	Value = 321812,
	Active = false,
	Weight = 83185,
	PreGoal = 
	{
		301710,
		301730,
	},
	GoodsId = 9701812,
	Priority = 1813277,
	Num = 62,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 171100,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 290,
				},
				{
					Value = 1,
					Num = 26100,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 290,
				},
				{
					Value = 1,
					Num = 26100,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 58,
				},
				{
					Value = 1,
					Num = 26100,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 58,
				},
				{
					Value = 1,
					Num = 26100,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 11,
				},
				{
					Value = 1,
					Num = 33600,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 11,
				},
				{
					Value = 1,
					Num = 33600,
				},
			},
		},
	},
	DemandID = 410958,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id959] =
{
	Id = 959,
	Name = "黑暗中的光",
	Desc = "啊，竟然停电了，麻烦点亮应援棒，把这里照亮吧。",
	Value = 321812,
	Active = false,
	Weight = 83185,
	PreGoal = 
	{
		301710,
		301730,
	},
	GoodsId = 9701812,
	Priority = 1813278,
	Num = 68,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 187658,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 319,
				},
				{
					Value = 1,
					Num = 28158,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 319,
				},
				{
					Value = 1,
					Num = 28158,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 63,
				},
				{
					Value = 1,
					Num = 30158,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 63,
				},
				{
					Value = 1,
					Num = 30158,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 12,
				},
				{
					Value = 1,
					Num = 37658,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 12,
				},
				{
					Value = 1,
					Num = 37658,
				},
			},
		},
	},
	DemandID = 410959,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id960] =
{
	Id = 960,
	Name = "偶像的魅力",
	Desc = "见面会就快到了，一定要准备好应援棒。",
	Value = 321812,
	Active = false,
	Weight = 83185,
	PreGoal = 
	{
		301710,
		301730,
	},
	GoodsId = 9701812,
	Priority = 1813279,
	Num = 72,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 198696,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 337,
				},
				{
					Value = 1,
					Num = 30196,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 337,
				},
				{
					Value = 1,
					Num = 30196,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 67,
				},
				{
					Value = 1,
					Num = 31196,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 67,
				},
				{
					Value = 1,
					Num = 31196,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 13,
				},
				{
					Value = 1,
					Num = 36196,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 13,
				},
				{
					Value = 1,
					Num = 36196,
				},
			},
		},
	},
	DemandID = 410960,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id961] =
{
	Id = 961,
	Name = "黑暗中的光",
	Desc = "啊，竟然停电了，麻烦点亮应援棒，把这里照亮吧。",
	Value = 321812,
	Active = false,
	Weight = 83185,
	PreGoal = 
	{
		301710,
		301730,
	},
	GoodsId = 9701812,
	Priority = 1813280,
	Num = 78,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 215255,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 365,
				},
				{
					Value = 1,
					Num = 32755,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 365,
				},
				{
					Value = 1,
					Num = 32755,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 73,
				},
				{
					Value = 1,
					Num = 32755,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 73,
				},
				{
					Value = 1,
					Num = 32755,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 14,
				},
				{
					Value = 1,
					Num = 40255,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 14,
				},
				{
					Value = 1,
					Num = 40255,
				},
			},
		},
	},
	DemandID = 410961,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id962] =
{
	Id = 962,
	Name = "选拔结束",
	Desc = "今天选拔就结束了，要准备好属于正式队员们的服装！",
	Value = 321851,
	Active = true,
	Weight = 43923,
	PreGoal = 
	{
		301965,
		301680,
	},
	CloseGoal = 
	{
		301715,
	},
	GoodsId = 9801851,
	Priority = 1852211,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 278681,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 29,
				},
				{
					Value = 1,
					Num = 28121,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 9,
				},
				{
					Value = 1,
					Num = 45401,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 105881,
				},
			},
		},
	},
	DemandID = 410962,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id963] =
{
	Id = 963,
	Name = "临时撤回",
	Desc = "不好！队服上的花纹印错了，赶紧回收，连夜修改！",
	Value = 321851,
	Active = true,
	Weight = 44649,
	PreGoal = 
	{
		301965,
		301690,
	},
	CloseGoal = 
	{
		301725,
	},
	GoodsId = 9801851,
	Priority = 1852212,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 278681,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 29,
				},
				{
					Value = 1,
					Num = 28121,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 9,
				},
				{
					Value = 1,
					Num = 45401,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 105881,
				},
			},
		},
	},
	DemandID = 410963,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id964] =
{
	Id = 964,
	Name = "选拔结束",
	Desc = "今天选拔就结束了，要准备好属于正式队员们的服装！",
	Value = 321851,
	Active = true,
	Weight = 45375,
	PreGoal = 
	{
		301965,
		301700,
	},
	GoodsId = 9801851,
	Priority = 1852213,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 278681,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 29,
				},
				{
					Value = 1,
					Num = 28121,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 9,
				},
				{
					Value = 1,
					Num = 45401,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 105881,
				},
			},
		},
	},
	DemandID = 410964,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id965] =
{
	Id = 965,
	Name = "临时撤回",
	Desc = "不好！队服上的花纹印错了，赶紧回收，连夜修改！",
	Value = 321851,
	Active = false,
	Weight = 46464,
	PreGoal = 
	{
		301965,
		301715,
	},
	GoodsId = 9801851,
	Priority = 1852214,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 278681,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 29,
				},
				{
					Value = 1,
					Num = 28121,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 9,
				},
				{
					Value = 1,
					Num = 45401,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 105881,
				},
			},
		},
	},
	DemandID = 410965,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id966] =
{
	Id = 966,
	Name = "选拔结束",
	Desc = "今天选拔就结束了，要准备好属于正式队员们的服装！",
	Value = 321851,
	Active = false,
	Weight = 47553,
	PreGoal = 
	{
		301965,
		301730,
	},
	GoodsId = 9801851,
	Priority = 1852215,
	Num = 14,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 325128,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 11,
				},
				{
					Value = 1,
					Num = 40008,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 3,
				},
				{
					Value = 1,
					Num = 65928,
				},
			},
		},
	},
	DemandID = 410966,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id967] =
{
	Id = 967,
	Name = "临时撤回",
	Desc = "不好！队服上的花纹印错了，赶紧回收，连夜修改！",
	Value = 321851,
	Active = false,
	Weight = 47553,
	PreGoal = 
	{
		301965,
		301730,
	},
	GoodsId = 9801851,
	Priority = 1852216,
	Num = 14,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 325128,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 11,
				},
				{
					Value = 1,
					Num = 40008,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 3,
				},
				{
					Value = 1,
					Num = 65928,
				},
			},
		},
	},
	DemandID = 410967,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id968] =
{
	Id = 968,
	Name = "选拔结束",
	Desc = "今天选拔就结束了，要准备好属于正式队员们的服装！",
	Value = 321851,
	Active = false,
	Weight = 47553,
	PreGoal = 
	{
		301965,
		301730,
	},
	GoodsId = 9801851,
	Priority = 1852217,
	Num = 15,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 348352,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 12,
				},
				{
					Value = 1,
					Num = 37312,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 3,
				},
				{
					Value = 1,
					Num = 89152,
				},
			},
		},
	},
	DemandID = 410968,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id969] =
{
	Id = 969,
	Name = "临时撤回",
	Desc = "不好！队服上的花纹印错了，赶紧回收，连夜修改！",
	Value = 321851,
	Active = false,
	Weight = 47553,
	PreGoal = 
	{
		301965,
		301730,
	},
	GoodsId = 9801851,
	Priority = 1852218,
	Num = 15,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 348352,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 12,
				},
				{
					Value = 1,
					Num = 37312,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 3,
				},
				{
					Value = 1,
					Num = 89152,
				},
			},
		},
	},
	DemandID = 410969,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id970] =
{
	Id = 970,
	Name = "选拔结束",
	Desc = "今天选拔就结束了，要准备好属于正式队员们的服装！",
	Value = 321851,
	Active = false,
	Weight = 47553,
	PreGoal = 
	{
		301965,
		301730,
	},
	GoodsId = 9801851,
	Priority = 1852219,
	Num = 16,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 371575,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 13,
				},
				{
					Value = 1,
					Num = 34615,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 3,
				},
				{
					Value = 1,
					Num = 112375,
				},
			},
		},
	},
	DemandID = 410970,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id971] =
{
	Id = 971,
	Name = "临时撤回",
	Desc = "不好！队服上的花纹印错了，赶紧回收，连夜修改！",
	Value = 321851,
	Active = false,
	Weight = 47553,
	PreGoal = 
	{
		301965,
		301730,
	},
	GoodsId = 9801851,
	Priority = 1852220,
	Num = 16,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 371575,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 13,
				},
				{
					Value = 1,
					Num = 34615,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 3,
				},
				{
					Value = 1,
					Num = 112375,
				},
			},
		},
	},
	DemandID = 410971,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id972] =
{
	Id = 972,
	Name = "纪念礼物",
	Desc = "海洋星来了一批游客，需要准备好售卖的商品。",
	Value = 321852,
	Active = true,
	Weight = 46875,
	PreGoal = 
	{
		301967,
		301700,
	},
	GoodsId = 9901852,
	Priority = 1853251,
	Num = 10,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 241738,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 25,
				},
				{
					Value = 1,
					Num = 25738,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 8,
				},
				{
					Value = 1,
					Num = 34378,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 68938,
				},
			},
		},
	},
	DemandID = 410972,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id973] =
{
	Id = 973,
	Name = "寻回失物",
	Desc = "听说有小贼偷走了很多珍珠，麻烦帮我把它们找回来吧。",
	Value = 321852,
	Active = false,
	Weight = 47625,
	PreGoal = 
	{
		301967,
		301710,
	},
	GoodsId = 9901852,
	Priority = 1853252,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 290085,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 30,
				},
				{
					Value = 1,
					Num = 30885,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 10,
				},
				{
					Value = 1,
					Num = 30885,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 3,
				},
				{
					Value = 1,
					Num = 30885,
				},
			},
		},
	},
	DemandID = 410973,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id974] =
{
	Id = 974,
	Name = "纪念礼物",
	Desc = "海洋星来了一批游客，需要准备好售卖的商品。",
	Value = 321852,
	Active = false,
	Weight = 48375,
	PreGoal = 
	{
		301967,
		301720,
	},
	GoodsId = 9901852,
	Priority = 1853253,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 290085,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 30,
				},
				{
					Value = 1,
					Num = 30885,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 10,
				},
				{
					Value = 1,
					Num = 30885,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 3,
				},
				{
					Value = 1,
					Num = 30885,
				},
			},
		},
	},
	DemandID = 410974,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id975] =
{
	Id = 975,
	Name = "寻回失物",
	Desc = "听说有小贼偷走了很多珍珠，麻烦帮我把它们找回来吧。",
	Value = 321852,
	Active = false,
	Weight = 49125,
	PreGoal = 
	{
		301967,
		301730,
	},
	GoodsId = 9901852,
	Priority = 1853254,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 290085,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 30,
				},
				{
					Value = 1,
					Num = 30885,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 10,
				},
				{
					Value = 1,
					Num = 30885,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 3,
				},
				{
					Value = 1,
					Num = 30885,
				},
			},
		},
	},
	DemandID = 410975,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id976] =
{
	Id = 976,
	Name = "纪念礼物",
	Desc = "海洋星来了一批游客，需要准备好售卖的商品。",
	Value = 321852,
	Active = false,
	Weight = 49125,
	PreGoal = 
	{
		301967,
		301730,
	},
	GoodsId = 9901852,
	Priority = 1853255,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 290085,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 30,
				},
				{
					Value = 1,
					Num = 30885,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 10,
				},
				{
					Value = 1,
					Num = 30885,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 3,
				},
				{
					Value = 1,
					Num = 30885,
				},
			},
		},
	},
	DemandID = 410976,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id977] =
{
	Id = 977,
	Name = "寻回失物",
	Desc = "听说有小贼偷走了很多珍珠，麻烦帮我把它们找回来吧。",
	Value = 321852,
	Active = false,
	Weight = 49125,
	PreGoal = 
	{
		301967,
		301730,
	},
	GoodsId = 9901852,
	Priority = 1853256,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 290085,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 30,
				},
				{
					Value = 1,
					Num = 30885,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 10,
				},
				{
					Value = 1,
					Num = 30885,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 3,
				},
				{
					Value = 1,
					Num = 30885,
				},
			},
		},
	},
	DemandID = 410977,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id978] =
{
	Id = 978,
	Name = "纪念礼物",
	Desc = "海洋星来了一批游客，需要准备好售卖的商品。",
	Value = 321852,
	Active = false,
	Weight = 49125,
	PreGoal = 
	{
		301967,
		301730,
	},
	GoodsId = 9901852,
	Priority = 1853257,
	Num = 14,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 338433,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 11,
				},
				{
					Value = 1,
					Num = 53313,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 3,
				},
				{
					Value = 1,
					Num = 79233,
				},
			},
		},
	},
	DemandID = 410978,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id979] =
{
	Id = 979,
	Name = "寻回失物",
	Desc = "听说有小贼偷走了很多珍珠，麻烦帮我把它们找回来吧。",
	Value = 321852,
	Active = false,
	Weight = 49125,
	PreGoal = 
	{
		301967,
		301730,
	},
	GoodsId = 9901852,
	Priority = 1853258,
	Num = 14,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 338433,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 11,
				},
				{
					Value = 1,
					Num = 53313,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 3,
				},
				{
					Value = 1,
					Num = 79233,
				},
			},
		},
	},
	DemandID = 410979,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id980] =
{
	Id = 980,
	Name = "纪念礼物",
	Desc = "海洋星来了一批游客，需要准备好售卖的商品。",
	Value = 321852,
	Active = false,
	Weight = 49125,
	PreGoal = 
	{
		301967,
		301730,
	},
	GoodsId = 9901852,
	Priority = 1853259,
	Num = 15,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 362607,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 12,
				},
				{
					Value = 1,
					Num = 51567,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 3,
				},
				{
					Value = 1,
					Num = 103407,
				},
			},
		},
	},
	DemandID = 410980,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id981] =
{
	Id = 981,
	Name = "寻回失物",
	Desc = "听说有小贼偷走了很多珍珠，麻烦帮我把它们找回来吧。",
	Value = 321852,
	Active = false,
	Weight = 49125,
	PreGoal = 
	{
		301967,
		301730,
	},
	GoodsId = 9901852,
	Priority = 1853260,
	Num = 15,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 362607,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 12,
				},
				{
					Value = 1,
					Num = 51567,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 3,
				},
				{
					Value = 1,
					Num = 103407,
				},
			},
		},
	},
	DemandID = 410981,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id982] =
{
	Id = 982,
	Name = "胜利的方法",
	Desc = "和粉丝吵起来了？甩出几张签名照让TA们闭嘴吧！",
	Value = 321853,
	Active = true,
	Weight = 48387,
	PreGoal = 
	{
		301968,
		301710,
	},
	GoodsId = 10001853,
	Priority = 1854271,
	Num = 10,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 259682,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 27,
				},
				{
					Value = 1,
					Num = 26402,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 9,
				},
				{
					Value = 1,
					Num = 26402,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 86882,
				},
			},
		},
	},
	DemandID = 410982,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id983] =
{
	Id = 983,
	Name = "转卖签名",
	Desc = "听说有人在转卖签名照？那你可以……嘿嘿……",
	Value = 321853,
	Active = false,
	Weight = 49149,
	PreGoal = 
	{
		301968,
		301720,
	},
	GoodsId = 10001853,
	Priority = 1854272,
	Num = 10,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 259682,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 27,
				},
				{
					Value = 1,
					Num = 26402,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 9,
				},
				{
					Value = 1,
					Num = 26402,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 86882,
				},
			},
		},
	},
	DemandID = 410983,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id984] =
{
	Id = 984,
	Name = "胜利的方法",
	Desc = "和粉丝吵起来了？甩出几张签名照让TA们闭嘴吧！",
	Value = 321853,
	Active = false,
	Weight = 49911,
	PreGoal = 
	{
		301968,
		301730,
	},
	GoodsId = 10001853,
	Priority = 1854273,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 311619,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 10,
				},
				{
					Value = 1,
					Num = 52419,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 3,
				},
				{
					Value = 1,
					Num = 52419,
				},
			},
		},
	},
	DemandID = 410984,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id985] =
{
	Id = 985,
	Name = "转卖签名",
	Desc = "听说有人在转卖签名照？那你可以……嘿嘿……",
	Value = 321853,
	Active = false,
	Weight = 49911,
	PreGoal = 
	{
		301968,
		301730,
	},
	GoodsId = 10001853,
	Priority = 1854274,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 311619,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 10,
				},
				{
					Value = 1,
					Num = 52419,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 3,
				},
				{
					Value = 1,
					Num = 52419,
				},
			},
		},
	},
	DemandID = 410985,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id986] =
{
	Id = 986,
	Name = "胜利的方法",
	Desc = "和粉丝吵起来了？甩出几张签名照让TA们闭嘴吧！",
	Value = 321853,
	Active = false,
	Weight = 49911,
	PreGoal = 
	{
		301968,
		301730,
	},
	GoodsId = 10001853,
	Priority = 1854275,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 311619,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 10,
				},
				{
					Value = 1,
					Num = 52419,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 3,
				},
				{
					Value = 1,
					Num = 52419,
				},
			},
		},
	},
	DemandID = 410986,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id987] =
{
	Id = 987,
	Name = "转卖签名",
	Desc = "听说有人在转卖签名照？那你可以……嘿嘿……",
	Value = 321853,
	Active = false,
	Weight = 49911,
	PreGoal = 
	{
		301968,
		301730,
	},
	GoodsId = 10001853,
	Priority = 1854276,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 311619,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 10,
				},
				{
					Value = 1,
					Num = 52419,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 3,
				},
				{
					Value = 1,
					Num = 52419,
				},
			},
		},
	},
	DemandID = 410987,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id988] =
{
	Id = 988,
	Name = "胜利的方法",
	Desc = "和粉丝吵起来了？甩出几张签名照让TA们闭嘴吧！",
	Value = 321853,
	Active = false,
	Weight = 49911,
	PreGoal = 
	{
		301968,
		301730,
	},
	GoodsId = 10001853,
	Priority = 1854277,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 311619,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 10,
				},
				{
					Value = 1,
					Num = 52419,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 3,
				},
				{
					Value = 1,
					Num = 52419,
				},
			},
		},
	},
	DemandID = 410988,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id989] =
{
	Id = 989,
	Name = "转卖签名",
	Desc = "听说有人在转卖签名照？那你可以……嘿嘿……",
	Value = 321853,
	Active = false,
	Weight = 49911,
	PreGoal = 
	{
		301968,
		301730,
	},
	GoodsId = 10001853,
	Priority = 1854278,
	Num = 14,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 363555,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 12,
				},
				{
					Value = 1,
					Num = 52515,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 3,
				},
				{
					Value = 1,
					Num = 104355,
				},
			},
		},
	},
	DemandID = 410989,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id990] =
{
	Id = 990,
	Name = "胜利的方法",
	Desc = "和粉丝吵起来了？甩出几张签名照让TA们闭嘴吧！",
	Value = 321853,
	Active = false,
	Weight = 49911,
	PreGoal = 
	{
		301968,
		301730,
	},
	GoodsId = 10001853,
	Priority = 1854279,
	Num = 14,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 363555,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 12,
				},
				{
					Value = 1,
					Num = 52515,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 3,
				},
				{
					Value = 1,
					Num = 104355,
				},
			},
		},
	},
	DemandID = 410990,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id991] =
{
	Id = 991,
	Name = "转卖签名",
	Desc = "听说有人在转卖签名照？那你可以……嘿嘿……",
	Value = 321853,
	Active = false,
	Weight = 49911,
	PreGoal = 
	{
		301968,
		301730,
	},
	GoodsId = 10001853,
	Priority = 1854280,
	Num = 14,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 363555,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 12,
				},
				{
					Value = 1,
					Num = 52515,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 3,
				},
				{
					Value = 1,
					Num = 104355,
				},
			},
		},
	},
	DemandID = 410991,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id992] =
{
	Id = 992,
	Name = "保护架子鼓",
	Desc = "有人投诉练习室的声音太大，快把架子鼓们送到安全地方。",
	Value = 321854,
	Active = true,
	Weight = 50700,
	PreGoal = 
	{
		301966,
		301725,
	},
	GoodsId = 10101854,
	Priority = 1855301,
	Num = 10,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 280786,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 29,
				},
				{
					Value = 1,
					Num = 30226,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 9,
				},
				{
					Value = 1,
					Num = 47506,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 107986,
				},
			},
		},
	},
	DemandID = 410992,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id993] =
{
	Id = 993,
	Name = "音乐会准备",
	Desc = "音乐会即将开始，需要准备一些架子鼓。",
	Value = 321854,
	Active = false,
	Weight = 51090,
	PreGoal = 
	{
		301966,
		301730,
	},
	GoodsId = 10101854,
	Priority = 1855302,
	Num = 10,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 280786,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 29,
				},
				{
					Value = 1,
					Num = 30226,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 9,
				},
				{
					Value = 1,
					Num = 47506,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 107986,
				},
			},
		},
	},
	DemandID = 410993,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id994] =
{
	Id = 994,
	Name = "保护架子鼓",
	Desc = "有人投诉练习室的声音太大，快把架子鼓们送到安全地方。",
	Value = 321854,
	Active = false,
	Weight = 51090,
	PreGoal = 
	{
		301966,
		301730,
	},
	GoodsId = 10101854,
	Priority = 1855303,
	Num = 10,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 280786,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 29,
				},
				{
					Value = 1,
					Num = 30226,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 9,
				},
				{
					Value = 1,
					Num = 47506,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 107986,
				},
			},
		},
	},
	DemandID = 410994,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id995] =
{
	Id = 995,
	Name = "音乐会准备",
	Desc = "音乐会即将开始，需要准备一些架子鼓。",
	Value = 321854,
	Active = false,
	Weight = 51090,
	PreGoal = 
	{
		301966,
		301730,
	},
	GoodsId = 10101854,
	Priority = 1855304,
	Num = 10,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 280786,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 29,
				},
				{
					Value = 1,
					Num = 30226,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 9,
				},
				{
					Value = 1,
					Num = 47506,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 107986,
				},
			},
		},
	},
	DemandID = 410995,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id996] =
{
	Id = 996,
	Name = "保护架子鼓",
	Desc = "有人投诉练习室的声音太大，快把架子鼓们送到安全地方。",
	Value = 321854,
	Active = false,
	Weight = 51090,
	PreGoal = 
	{
		301966,
		301730,
	},
	GoodsId = 10101854,
	Priority = 1855305,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 336944,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 11,
				},
				{
					Value = 1,
					Num = 51824,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 3,
				},
				{
					Value = 1,
					Num = 77744,
				},
			},
		},
	},
	DemandID = 410996,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id997] =
{
	Id = 997,
	Name = "音乐会准备",
	Desc = "音乐会即将开始，需要准备一些架子鼓。",
	Value = 321854,
	Active = false,
	Weight = 51090,
	PreGoal = 
	{
		301966,
		301730,
	},
	GoodsId = 10101854,
	Priority = 1855306,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 336944,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 11,
				},
				{
					Value = 1,
					Num = 51824,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 3,
				},
				{
					Value = 1,
					Num = 77744,
				},
			},
		},
	},
	DemandID = 410997,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id998] =
{
	Id = 998,
	Name = "保护架子鼓",
	Desc = "有人投诉练习室的声音太大，快把架子鼓们送到安全地方。",
	Value = 321854,
	Active = false,
	Weight = 51090,
	PreGoal = 
	{
		301966,
		301730,
	},
	GoodsId = 10101854,
	Priority = 1855307,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 336944,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 11,
				},
				{
					Value = 1,
					Num = 51824,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 3,
				},
				{
					Value = 1,
					Num = 77744,
				},
			},
		},
	},
	DemandID = 410998,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id999] =
{
	Id = 999,
	Name = "音乐会准备",
	Desc = "音乐会即将开始，需要准备一些架子鼓。",
	Value = 321854,
	Active = false,
	Weight = 51090,
	PreGoal = 
	{
		301966,
		301730,
	},
	GoodsId = 10101854,
	Priority = 1855308,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 336944,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 11,
				},
				{
					Value = 1,
					Num = 51824,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 3,
				},
				{
					Value = 1,
					Num = 77744,
				},
			},
		},
	},
	DemandID = 410999,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id1000] =
{
	Id = 1000,
	Name = "保护架子鼓",
	Desc = "有人投诉练习室的声音太大，快把架子鼓们送到安全地方。",
	Value = 321854,
	Active = false,
	Weight = 51090,
	PreGoal = 
	{
		301966,
		301730,
	},
	GoodsId = 10101854,
	Priority = 1855309,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 336944,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 11,
				},
				{
					Value = 1,
					Num = 51824,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 3,
				},
				{
					Value = 1,
					Num = 77744,
				},
			},
		},
	},
	DemandID = 411000,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
