TagConfig ={};
TagID = 
{
	Id001 = 560001,
	Id002 = 560002,
	Id003 = 560003,
	Id004 = 560004,
	Id005 = 560005,
	Id006 = 560006,
	Id021 = 560021,
	Id022 = 560022,
	Id023 = 560023,
	Id024 = 560024,
	Id025 = 560025,
	Id026 = 560026,
	Id031 = 560031,
	Id032 = 560032,
	Id033 = 560033,
	Id034 = 560034,
	Id035 = 560035,
	Id036 = 560036,
	Id041 = 560041,
	Id042 = 560042,
	Id043 = 560043,
	Id044 = 560044,
	Id045 = 560045,
	Id046 = 560046,
	Id101 = 560101,
	Id102 = 560102,
	Id103 = 560103,
	Id104 = 560104,
	Id105 = 560105,
	Id106 = 560106,
	Id107 = 560107,
	Id108 = 560108,
	Id109 = 560109,
	Id110 = 560110,
	Id111 = 560111,
	Id201 = 560201,
	Id202 = 560202,
	Id203 = 560203,
	Id204 = 560204,
	Id205 = 560205,
	Id206 = 560206,
	Id207 = 560207,
	Id208 = 560208,
	Id209 = 560209,
	Id210 = 560210,
	Id211 = 560211,
	Id301 = 560301,
	Id302 = 560302,
	Id303 = 560303,
	Id304 = 560304,
	Id305 = 560305,
	Id306 = 560306,
	Id307 = 560307,
	Id308 = 560308,
	Id309 = 560309,
	Id310 = 560310,
	Id311 = 560311,
	Id312 = 560312,
	Id313 = 560313,
	Id314 = 560314,
	Id315 = 560315,
	Id316 = 560316,
	Id317 = 560317,
	Id318 = 560318,
	Id319 = 560319,
	Id320 = 560320,
	Id321 = 560321,
	Id322 = 560322,
	Id323 = 560323,
	Id324 = 560324,
	Id325 = 560325,
	Id326 = 560326,
	Id327 = 560327,
	Id328 = 560328,
	Id329 = 560329,
	Id330 = 560330,
	Id331 = 560331,
	Id332 = 560332,
	Id333 = 560333,
	Id334 = 560334,
	Id335 = 560335,
	Id336 = 560336,
	Id337 = 560337,
	Id338 = 560338,
	Id339 = 560339,
	Id340 = 560340,
	Id341 = 560341,
	Id342 = 560342,
	Id343 = 560343,
	Id344 = 560344,
	Id345 = 560345,
	Id346 = 560346,
	Id347 = 560347,
	Id348 = 560348,
	Id1101 = 561101,
	Id1102 = 561102,
	Id1103 = 561103,
	Id1104 = 561104,
	Id1105 = 561105,
	Id1106 = 561106,
	Id1201 = 561201,
	Id1202 = 561202,
	Id1203 = 561203,
	Id1204 = 561204,
	Id1205 = 561205,
	Id1206 = 561206,
	Id1207 = 561207,
	Id1208 = 561208,
	Id1301 = 561301,
	Id1302 = 561302,
	Id1303 = 561303,
	Id1304 = 561304,
	Id1305 = 561305,
	Id1306 = 561306,
	Id1307 = 561307,
	Id1308 = 561308,
	Id1309 = 561309,
	Id1310 = 561310,
	Id1311 = 561311,
	Id1312 = 561312,
	Id1313 = 561313,
	Id1314 = 561314,
	Id1315 = 561315,
	Id1316 = 561316,
	Id1317 = 561317,
	Id1318 = 561318,
	Id1319 = 561319,
	Id1320 = 561320,
	Id1321 = 561321,
	Id1322 = 561322,
	Id1323 = 561323,
	Id1324 = 561324,
	Id1325 = 561325,
	Id1326 = 561326,
	Id1327 = 561327,
	Id1328 = 561328,
	Id1329 = 561329,
	Id1330 = 561330,
	Id1331 = 561331,
	Id1332 = 561332,
	Id1333 = 561333,
	Id1334 = 561334,
	Id1335 = 561335,
	Id1336 = 561336,
	Id1337 = 561337,
	Id1338 = 561338,
	Id1339 = 561339,
	Id1340 = 561340,
	Id1341 = 561341,
	Id1342 = 561342,
	Id1343 = 561343,
	Id1344 = 561344,
	Id1345 = 561345,
	Id1346 = 561346,
	Id1347 = 561347,
	Id1348 = 561348,
	Id1349 = 561349,
	Id1350 = 561350,
	Id1351 = 561351,
	Id1352 = 561352,
	Id1353 = 561353,
	Id1354 = 561354,
	Id1355 = 561355,
	Id1356 = 561356,
	Id1357 = 561357,
	Id1358 = 561358,
	Id1359 = 561359,
	Id1360 = 561360,
	Id1361 = 561361,
	Id1362 = 561362,
	Id1363 = 561363,
	Id1364 = 561364,
	Id1365 = 561365,
	Id1366 = 561366,
	Id1367 = 561367,
	Id1368 = 561368,
	Id1369 = 561369,
	Id1701 = 561701,
	Id1702 = 561702,
	Id1703 = 561703,
	Id1704 = 561704,
	Id1705 = 561705,
	Id1706 = 561706,
	Id1707 = 561707,
	Id1801 = 561801,
	Id1802 = 561802,
	Id1803 = 561803,
	Id1804 = 561804,
	Id1805 = 561805,
	Id1806 = 561806,
	Id1807 = 561807,
	Id1808 = 561808,
	Id1851 = 561851,
	Id1852 = 561852,
	Id1853 = 561853,
	Id1854 = 561854,
	Id1855 = 561855,
	Id1901 = 561901,
	Id1902 = 561902,
	Id1903 = 561903,
	Id1904 = 561904,
	Id1905 = 561905,
	Id1906 = 561906,
	Id2001 = 562001,
	Id2002 = 562002,
	Id2003 = 562003,
	Id2004 = 562004,
	Id2005 = 562005,
	Id2006 = 562006,
	Id2007 = 562007,
	Id2008 = 562008,
	Id2009 = 562009,
	Id2010 = 562010,
	Id2011 = 562011,
	Id2012 = 562012,
	Id2013 = 562013,
	Id2014 = 562014,
	Id2101 = 562101,
	Id2102 = 562102,
	Id2103 = 562103,
	Id2104 = 562104,
	Id2201 = 562201,
	Id2202 = 562202,
	Id2301 = 562301,
	Id2302 = 562302,
	Id2303 = 562303,
	Id2304 = 562304,
	Id2305 = 562305,
	Id2306 = 562306,
	Id2401 = 562401,
	Id2402 = 562402,
	Id2403 = 562403,
	Id2501 = 562501,
	Id2502 = 562502,
	Id2601 = 562601,
	Id2602 = 562602,
	Id2603 = 562603,
	Id2604 = 562604,
	Id2605 = 562605,
	Id2606 = 562606,
	Id2607 = 562607,
	Id2608 = 562608,
	Id2701 = 562701,
	Id2702 = 562702,
	Id2703 = 562703,
	Id2704 = 562704,
	Id2705 = 562705,
	Id2801 = 562801,
	Id2802 = 562802,
	Id2803 = 562803,
	Id2901 = 562901,
	Id2902 = 562902,
	Id2903 = 562903,
	Id2904 = 562904,
	Id2905 = 562905,
	Id2906 = 562906,
	Id2907 = 562907,
	Id2908 = 562908,
	Id2909 = 562909,
	Id2910 = 562910,
	Id2911 = 562911,
	Id2912 = 562912,
	Id2913 = 562913,
	Id2914 = 562914,
	Id2915 = 562915,
	Id2916 = 562916,
	Id2917 = 562917,
	Id2918 = 562918,
	Id2919 = 562919,
	Id2920 = 562920,
	Id2921 = 562921,
	Id2922 = 562922,
	Id2923 = 562923,
	Id2924 = 562924,
	Id2925 = 562925,
	Id2926 = 562926,
	Id2927 = 562927,
	Id2928 = 562928,
	Id2929 = 562929,
	Id2930 = 562930,
	Id2931 = 562931,
	Id2932 = 562932,
	Id2933 = 562933,
	Id2934 = 562934,
	Id2935 = 562935,
	Id2936 = 562936,
	Id3001 = 563001,
	Id3002 = 563002,
	Id3003 = 563003,
	Id3004 = 563004,
	Id3005 = 563005,
	Id3006 = 563006,
	Id3007 = 563007,
	Id3008 = 563008,
	Id3009 = 563009,
	Id3010 = 563010,
	Id3011 = 563011,
	Id3012 = 563012,
	Id3013 = 563013,
	Id3101 = 563101,
	Id3102 = 563102,
	Id3103 = 563103,
	Id3104 = 563104,
	Id3105 = 563105,
	Id3106 = 563106,
	Id3201 = 563201,
	Id3202 = 563202,
	Id3203 = 563203,
	Id3204 = 563204,
	Id3205 = 563205,
	Id3206 = 563206,
	Id3301 = 563301,
	Id3302 = 563302,
	Id3303 = 563303,
	Id3304 = 563304,
	Id3305 = 563305,
	Id3306 = 563306,
	Id3401 = 563401,
	Id3402 = 563402,
	Id3403 = 563403,
	Id3404 = 563404,
	Id3405 = 563405,
	Id3406 = 563406,
	Id3501 = 563501,
	Id3502 = 563502,
	Id3503 = 563503,
	Id3504 = 563504,
	Id3505 = 563505,
	Id3506 = 563506,
	Id3601 = 563601,
	Id3602 = 563602,
	Id3603 = 563603,
	Id3604 = 563604,
	Id3605 = 563605,
	Id3606 = 563606,
	Id3607 = 563607,
	Id3608 = 563608,
	Id3609 = 563609,
	Id3610 = 563610,
	Id3611 = 563611,
	Id3612 = 563612,
	Id3613 = 563613,
	Id3614 = 563614,
	Id3615 = 563615,
	Id3616 = 563616,
	Id3617 = 563617,
	Id3618 = 563618,
	Id3619 = 563619,
	Id3620 = 563620,
	Id3621 = 563621,
	Id3622 = 563622,
	Id3623 = 563623,
	Id3624 = 563624,
	Id3625 = 563625,
	Id3626 = 563626,
	Id3701 = 563701,
	Id3702 = 563702,
	Id3703 = 563703,
	Id3704 = 563704,
	Id3705 = 563705,
	Id3706 = 563706,
	Id3707 = 563707,
	Id3708 = 563708,
	Id3709 = 563709,
	Id3710 = 563710,
	Id3711 = 563711,
	Id3801 = 563801,
	Id3802 = 563802,
	Id3803 = 563803,
	Id3804 = 563804,
	Id3805 = 563805,
	Id3806 = 563806,
	Id3807 = 563807,
	Id3808 = 563808,
	Id3809 = 563809,
	Id3810 = 563810,
	Id3811 = 563811,
	Id3812 = 563812,
	Id3813 = 563813,
	Id3814 = 563814,
	Id3815 = 563815,
	Id3816 = 563816,
	Id3817 = 563817,
	Id3818 = 563818,
	Id3819 = 563819,
	Id3820 = 563820,
	Id3821 = 563821,
	Id3822 = 563822,
	Id3823 = 563823,
	Id3824 = 563824,
	Id3825 = 563825,
	Id3826 = 563826,
	Id3827 = 563827,
	Id3828 = 563828,
	Id3829 = 563829,
	Id3830 = 563830,
	Id3831 = 563831,
	Id3901 = 563901,
	Id3902 = 563902,
	Id3903 = 563903,
	Id3904 = 563904,
	Id3905 = 563905,
	Id3906 = 563906,
	Id3907 = 563907,
	Id3908 = 563908,
	Id3909 = 563909,
	Id3910 = 563910,
	Id3911 = 563911,
	Id3912 = 563912,
	Id3913 = 563913,
	Id3914 = 563914,
	Id3915 = 563915,
	Id3916 = 563916,
	Id3917 = 563917,
	Id3918 = 563918,
	Id3919 = 563919,
	Id3920 = 563920,
	Id3921 = 563921,
	Id3922 = 563922,
	Id3923 = 563923,
	Id3924 = 563924,
	Id3925 = 563925,
	Id3926 = 563926,
	Id3927 = 563927,
	Id3928 = 563928,
	Id3929 = 563929,
	Id3930 = 563930,
	Id3931 = 563931,
	Id3932 = 563932,
	Id3933 = 563933,
	Id3934 = 563934,
	Id3935 = 563935,
	Id3936 = 563936,
	Id3937 = 563937,
	Id3938 = 563938,
	Id3939 = 563939,
	Id3940 = 563940,
	Id3941 = 563941,
	Id3942 = 563942,
	Id3943 = 563943,
	Id3944 = 563944,
	Id3945 = 563945,
	Id3946 = 563946,
	Id3947 = 563947,
	Id3948 = 563948,
	Id3949 = 563949,
	Id3950 = 563950,
	Id3951 = 563951,
	Id3952 = 563952,
	Id3953 = 563953,
	Id3954 = 563954,
	Id3955 = 563955,
	Id3956 = 563956,
	Id4001 = 564001,
	Id4002 = 564002,
	Id4003 = 564003,
	Id4004 = 564004,
	Id4005 = 564005,
	Id4006 = 564006,
	Id4007 = 564007,
	Id4008 = 564008,
	Id4009 = 564009,
	Id4010 = 564010,
	Id4011 = 564011,
	Id4012 = 564012,
	Id4013 = 564013,
	Id4014 = 564014,
	Id4015 = 564015,
	Id4016 = 564016,
	Id4017 = 564017,
	Id4018 = 564018,
	Id4019 = 564019,
	Id4020 = 564020,
	Id4021 = 564021,
	Id4022 = 564022,
	Id4023 = 564023,
	Id4024 = 564024,
	Id4025 = 564025,
	Id4026 = 564026,
	Id4027 = 564027,
	Id4028 = 564028,
	Id4029 = 564029,
	Id4030 = 564030,
	Id4031 = 564031,
	Id4032 = 564032,
	Id4033 = 564033,
	Id4034 = 564034,
	Id4035 = 564035,
	Id4036 = 564036,
	Id4037 = 564037,
	Id4038 = 564038,
	Id4039 = 564039,
	Id4040 = 564040,
	Id4041 = 564041,
	Id4042 = 564042,
	Id4043 = 564043,
	Id4044 = 564044,
	Id4045 = 564045,
	Id4046 = 564046,
	Id4047 = 564047,
	Id4048 = 564048,
	Id4049 = 564049,
	Id4050 = 564050,
	Id4051 = 564051,
	Id4052 = 564052,
	Id4053 = 564053,
	Id4054 = 564054,
	Id4055 = 564055,
	Id4056 = 564056,
	Id4057 = 564057,
	Id4058 = 564058,
	Id4059 = 564059,
	Id4060 = 564060,
	Id4061 = 564061,
	Id4062 = 564062,
	Id4063 = 564063,
	Id4064 = 564064,
	Id4065 = 564065,
	Id4066 = 564066,
	Id4101 = 564101,
	Id4102 = 564102,
	Id4103 = 564103,
	Id4104 = 564104,
	Id4105 = 564105,
	Id4106 = 564106,
	Id4107 = 564107,
	Id4108 = 564108,
	Id4109 = 564109,
	Id4110 = 564110,
	Id4111 = 564111,
	Id4112 = 564112,
	Id4113 = 564113,
	Id4114 = 564114,
	Id4115 = 564115,
	Id4116 = 564116,
	Id4117 = 564117,
	Id4118 = 564118,
	Id4119 = 564119,
	Id4120 = 564120,
	Id4121 = 564121,
	Id4122 = 564122,
	Id4123 = 564123,
	Id4124 = 564124,
	Id4125 = 564125,
	Id4126 = 564126,
	Id4127 = 564127,
	Id4128 = 564128,
	Id4129 = 564129,
	Id4130 = 564130,
	Id4131 = 564131,
	Id4132 = 564132,
	Id4133 = 564133,
	Id4134 = 564134,
	Id4135 = 564135,
	Id4136 = 564136,
	Id4137 = 564137,
	Id4138 = 564138,
	Id4139 = 564139,
	Id4140 = 564140,
	Id4141 = 564141,
	Id4142 = 564142,
	Id4143 = 564143,
	Id4144 = 564144,
	Id4145 = 564145,
	Id4146 = 564146,
	Id4147 = 564147,
	Id4148 = 564148,
	Id4149 = 564149,
	Id4150 = 564150,
	Id4151 = 564151,
	Id4152 = 564152,
	Id4153 = 564153,
	Id4154 = 564154,
	Id4155 = 564155,
	Id4156 = 564156,
	Id4157 = 564157,
	Id4158 = 564158,
	Id4159 = 564159,
	Id4160 = 564160,
	Id4161 = 564161,
	Id4162 = 564162,
	Id4163 = 564163,
	Id4164 = 564164,
	Id4165 = 564165,
	Id4166 = 564166,
	Id4167 = 564167,
	Id4168 = 564168,
	Id4169 = 564169,
	Id4170 = 564170,
	Id4171 = 564171,
	Id4201 = 564201,
	Id4202 = 564202,
	Id4203 = 564203,
	Id4204 = 564204,
	Id4205 = 564205,
	Id4206 = 564206,
	Id4301 = 564301,
	Id4302 = 564302,
	Id4303 = 564303,
	Id4304 = 564304,
	Id4305 = 564305,
	Id4306 = 564306,
	Id4307 = 564307,
	Id4308 = 564308,
	Id4309 = 564309,
	Id4310 = 564310,
	Id4321 = 564321,
	Id4322 = 564322,
	Id4323 = 564323,
	Id4351 = 564351,
	Id4352 = 564352,
	Id4353 = 564353,
	Id4354 = 564354,
	Id4355 = 564355,
	Id4356 = 564356,
	Id4361 = 564361,
	Id4362 = 564362,
	Id4363 = 564363,
	Id4364 = 564364,
	Id4365 = 564365,
	Id4366 = 564366,
	Id4371 = 564371,
	Id4372 = 564372,
	Id4373 = 564373,
	Id4374 = 564374,
	Id4375 = 564375,
	Id4376 = 564376,
	Id4381 = 564381,
	Id4382 = 564382,
	Id4383 = 564383,
	Id4384 = 564384,
	Id4391 = 564391,
	Id4392 = 564392,
	Id4393 = 564393,
	Id4394 = 564394,
	Id4401 = 564401,
	Id4402 = 564402,
	Id4403 = 564403,
	Id4404 = 564404,
	Id4411 = 564411,
	Id4412 = 564412,
	Id4413 = 564413,
	Id4414 = 564414,
	Id4421 = 564421,
	Id4422 = 564422,
	Id4423 = 564423,
	Id4424 = 564424,
	Id4431 = 564431,
	Id4432 = 564432,
	Id4433 = 564433,
	Id4434 = 564434,
	Id4441 = 564441,
	Id4442 = 564442,
	Id4443 = 564443,
	Id4444 = 564444,
	Id4451 = 564451,
	Id4452 = 564452,
	Id4453 = 564453,
	Id4454 = 564454,
	Id4461 = 564461,
	Id4462 = 564462,
	Id4463 = 564463,
	Id4464 = 564464,
	Id4501 = 564501,
	Id4502 = 564502,
	Id4551 = 564551,
	Id4552 = 564552,
	Id4553 = 564553,
	Id4554 = 564554,
	Id4555 = 564555,
	Id4556 = 564556,
	Id4557 = 564557,
	Id4558 = 564558,
	Id4559 = 564559,
	Id4560 = 564560,
	Id4561 = 564561,
	Id4562 = 564562,
	Id4563 = 564563,
	Id4564 = 564564,
	Id5001 = 565001,
	Id5002 = 565002,
	Id5003 = 565003,
	Id5004 = 565004,
	Id5005 = 565005,
	Id5006 = 565006,
	Id5007 = 565007,
	Id5008 = 565008,
	Id5009 = 565009,
	Id5010 = 565010,
	Id5011 = 565011,
	Id5012 = 565012,
	Id5013 = 565013,
	Id5014 = 565014,
	Id5015 = 565015,
	Id5101 = 565101,
	Id5102 = 565102,
	Id5103 = 565103,
	Id5104 = 565104,
	Id5105 = 565105,
	Id5106 = 565106,
	Id5107 = 565107,
	Id5201 = 565201,
	Id5202 = 565202,
	Id5203 = 565203,
	Id5204 = 565204,
	Id5205 = 565205,
	Id5206 = 565206,
	Id5207 = 565207,
	Id5208 = 565208,
	Id5209 = 565209,
	Id5210 = 565210,
	Id5211 = 565211,
	Id5212 = 565212,
	Id5213 = 565213,
	Id5214 = 565214,
	Id5301 = 565301,
	Id5302 = 565302,
	Id5303 = 565303,
	Id5304 = 565304,
	Id5305 = 565305,
	Id5306 = 565306,
	Id5307 = 565307,
	Id5308 = 565308,
	Id5309 = 565309,
	Id5310 = 565310,
	Id5311 = 565311,
	Id5312 = 565312,
	Id5313 = 565313,
	Id5314 = 565314,
	Id5315 = 565315,
	Id5316 = 565316,
	Id5401 = 565401,
	Id5402 = 565402,
	Id5403 = 565403,
	Id5404 = 565404,
	Id5405 = 565405,
	Id5406 = 565406,
	Id5407 = 565407,
	Id5501 = 565501,
	Id5502 = 565502,
	Id5503 = 565503,
	Id5504 = 565504,
	Id5505 = 565505,
	Id5506 = 565506,
	Id5507 = 565507,
	Id5508 = 565508,
	Id5509 = 565509,
	Id5510 = 565510,
	Id5511 = 565511,
	Id5512 = 565512,
	Id5513 = 565513,
	Id5514 = 565514,
	Id5515 = 565515,
	Id5516 = 565516,
	Id5517 = 565517,
	Id5518 = 565518,
	Id5519 = 565519,
	Id5520 = 565520,
	Id5521 = 565521,
	Id5522 = 565522,
	Id5523 = 565523,
	Id5524 = 565524,
	Id5525 = 565525,
	Id5526 = 565526,
	Id5527 = 565527,
	Id5528 = 565528,
	Id5529 = 565529,
	Id5530 = 565530,
	Id5531 = 565531,
	Id5532 = 565532,
	Id5533 = 565533,
	Id5534 = 565534,
	Id5535 = 565535,
	Id5536 = 565536,
	Id5537 = 565537,
	Id5538 = 565538,
	Id5539 = 565539,
	Id5540 = 565540,
	Id5541 = 565541,
	Id5542 = 565542,
	Id5543 = 565543,
	Id5544 = 565544,
	Id5545 = 565545,
	Id5546 = 565546,
	Id5547 = 565547,
	Id5548 = 565548,
	Id5549 = 565549,
	Id5550 = 565550,
	Id5551 = 565551,
	Id5552 = 565552,
	Id5553 = 565553,
	Id5554 = 565554,
	Id5555 = 565555,
	Id5556 = 565556,
	Id5557 = 565557,
	Id5558 = 565558,
	Id5559 = 565559,
	Id5560 = 565560,
	Id5561 = 565561,
	Id5562 = 565562,
	Id5563 = 565563,
	Id5564 = 565564,
	Id5565 = 565565,
	Id5566 = 565566,
	Id5567 = 565567,
	Id5568 = 565568,
	Id5569 = 565569,
	Id5570 = 565570,
	Id5571 = 565571,
	Id5572 = 565572,
	Id5573 = 565573,
	Id5574 = 565574,
	Id5575 = 565575,
	Id5576 = 565576,
	Id5577 = 565577,
	Id5578 = 565578,
	Id5579 = 565579,
	Id5580 = 565580,
	Id5581 = 565581,
	Id5582 = 565582,
	Id5583 = 565583,
	Id5584 = 565584,
	Id5585 = 565585,
	Id5586 = 565586,
	Id5587 = 565587,
	Id5588 = 565588,
	Id5589 = 565589,
	Id5590 = 565590,
	Id6000 = 566000,
	Id6001 = 566001,
	Id6002 = 566002,
	Id6003 = 566003,
	Id6004 = 566004,
	Id6005 = 566005,
	Id6006 = 566006,
	Id6007 = 566007,
	Id6050 = 566050,
	Id6051 = 566051,
	Id6052 = 566052,
	Id6053 = 566053,
	Id6054 = 566054,
	Id6055 = 566055,
	Id6056 = 566056,
	Id6057 = 566057,
	Id6100 = 566100,
	Id6101 = 566101,
	Id6102 = 566102,
	Id6103 = 566103,
	Id6104 = 566104,
	Id6105 = 566105,
	Id6106 = 566106,
	Id6150 = 566150,
	Id6151 = 566151,
	Id6152 = 566152,
	Id6153 = 566153,
	Id6154 = 566154,
	Id6200 = 566200,
	Id6201 = 566201,
	Id6202 = 566202,
	Id6203 = 566203,
	Id6250 = 566250,
	Id6251 = 566251,
	Id6252 = 566252,
	Id6253 = 566253,
	Id6254 = 566254,
	Id6300 = 566300,
	Id6301 = 566301,
	Id6302 = 566302,
	Id6303 = 566303,
	Id6304 = 566304,
	Id6305 = 566305,
	Id6306 = 566306,
	Id6307 = 566307,
	Id6308 = 566308,
	Id6309 = 566309,
	Id6310 = 566310,
	Id6311 = 566311,
	Id6312 = 566312,
	Id6313 = 566313,
	Id6400 = 566400,
	Id6401 = 566401,
	Id6402 = 566402,
	Id6500 = 566500,
	Id6501 = 566501,
	Id6502 = 566502,
	Id6600 = 566600,
	Id6601 = 566601,
	Id6602 = 566602,
	Id6603 = 566603,
	Id6604 = 566604,
	Id6650 = 566650,
	Id6651 = 566651,
	Id6652 = 566652,
	Id6653 = 566653,
	Id6654 = 566654,
	Id6655 = 566655,
	Id6700 = 566700,
	Id6701 = 566701,
	Id6702 = 566702,
	Id6703 = 566703,
	Id6750 = 566750,
	Id6751 = 566751,
	Id6752 = 566752,
}
TagConfig[TagID.Id001] =
{
	Id = 1,
	TAG = "——来源——",
}
TagConfig[TagID.Id002] =
{
	Id = 2,
	TAG = "礼包角色的",
}
TagConfig[TagID.Id003] =
{
	Id = 3,
	TAG = "奖池角色的",
}
TagConfig[TagID.Id004] =
{
	Id = 4,
	TAG = "主线角色的",
}
TagConfig[TagID.Id005] =
{
	Id = 5,
	TAG = "可合成的",
}
TagConfig[TagID.Id006] =
{
	Id = 6,
	TAG = "不可合成的",
}
TagConfig[TagID.Id021] =
{
	Id = 21,
	TAG = "——稀有度——",
}
TagConfig[TagID.Id022] =
{
	Id = 22,
	TAG = "1星的",
}
TagConfig[TagID.Id023] =
{
	Id = 23,
	TAG = "2星的",
}
TagConfig[TagID.Id024] =
{
	Id = 24,
	TAG = "3星的",
}
TagConfig[TagID.Id025] =
{
	Id = 25,
	TAG = "4星的",
}
TagConfig[TagID.Id026] =
{
	Id = 26,
	TAG = "5星的",
}
TagConfig[TagID.Id031] =
{
	Id = 31,
	TAG = "——稀有度大于——",
}
TagConfig[TagID.Id032] =
{
	Id = 32,
	TAG = "1星以上的",
}
TagConfig[TagID.Id033] =
{
	Id = 33,
	TAG = "2星以上的",
}
TagConfig[TagID.Id034] =
{
	Id = 34,
	TAG = "3星以上的",
}
TagConfig[TagID.Id035] =
{
	Id = 35,
	TAG = "4星以上的",
}
TagConfig[TagID.Id036] =
{
	Id = 36,
	TAG = "5星以上的",
}
TagConfig[TagID.Id041] =
{
	Id = 41,
	TAG = "——稀有度小于——",
}
TagConfig[TagID.Id042] =
{
	Id = 42,
	TAG = "1星以下的",
}
TagConfig[TagID.Id043] =
{
	Id = 43,
	TAG = "2星以下的",
}
TagConfig[TagID.Id044] =
{
	Id = 44,
	TAG = "3星以下的",
}
TagConfig[TagID.Id045] =
{
	Id = 45,
	TAG = "4星以下的",
}
TagConfig[TagID.Id046] =
{
	Id = 46,
	TAG = "5星以下的",
}
TagConfig[TagID.Id101] =
{
	Id = 101,
	TAG = "——星球——",
}
TagConfig[TagID.Id102] =
{
	Id = 102,
	TAG = "任意星球的",
}
TagConfig[TagID.Id103] =
{
	Id = 103,
	TAG = "冒险星的",
}
TagConfig[TagID.Id104] =
{
	Id = 104,
	TAG = "美食星的",
}
TagConfig[TagID.Id105] =
{
	Id = 105,
	TAG = "博物馆星的",
}
TagConfig[TagID.Id106] =
{
	Id = 106,
	TAG = "悬疑星的",
}
TagConfig[TagID.Id107] =
{
	Id = 107,
	TAG = "海洋星的",
}
TagConfig[TagID.Id108] =
{
	Id = 108,
	TAG = "沙漠星的",
}
TagConfig[TagID.Id109] =
{
	Id = 109,
	TAG = "鬼怪星的",
}
TagConfig[TagID.Id110] =
{
	Id = 110,
	TAG = "星际流民的",
}
TagConfig[TagID.Id111] =
{
	Id = 111,
	TAG = "流亡街的",
}
TagConfig[TagID.Id201] =
{
	Id = 201,
	TAG = "——非星球——",
}
TagConfig[TagID.Id202] =
{
	Id = 202,
	TAG = "非任意星球的",
}
TagConfig[TagID.Id203] =
{
	Id = 203,
	TAG = "非冒险星的",
}
TagConfig[TagID.Id204] =
{
	Id = 204,
	TAG = "非美食星的",
}
TagConfig[TagID.Id205] =
{
	Id = 205,
	TAG = "非博物馆星的",
}
TagConfig[TagID.Id206] =
{
	Id = 206,
	TAG = "非悬疑星的",
}
TagConfig[TagID.Id207] =
{
	Id = 207,
	TAG = "非海洋星的",
}
TagConfig[TagID.Id208] =
{
	Id = 208,
	TAG = "非沙漠星的",
}
TagConfig[TagID.Id209] =
{
	Id = 209,
	TAG = "非鬼怪星的",
}
TagConfig[TagID.Id210] =
{
	Id = 210,
	TAG = "非星际流民的",
}
TagConfig[TagID.Id211] =
{
	Id = 211,
	TAG = "非流亡街的",
}
TagConfig[TagID.Id301] =
{
	Id = 301,
	TAG = "——星球地区的——",
}
TagConfig[TagID.Id302] =
{
	Id = 302,
	TAG = "冒险星着陆点的",
}
TagConfig[TagID.Id303] =
{
	Id = 303,
	TAG = "初始城镇的",
}
TagConfig[TagID.Id304] =
{
	Id = 304,
	TAG = "村口树林的",
}
TagConfig[TagID.Id305] =
{
	Id = 305,
	TAG = "溪谷的",
}
TagConfig[TagID.Id306] =
{
	Id = 306,
	TAG = "魔法平原的",
}
TagConfig[TagID.Id307] =
{
	Id = 307,
	TAG = "古代遗迹的",
}
TagConfig[TagID.Id308] =
{
	Id = 308,
	TAG = "大沼泽的",
}
TagConfig[TagID.Id309] =
{
	Id = 309,
	TAG = "深坑谷的",
}
TagConfig[TagID.Id310] =
{
	Id = 310,
	TAG = "魔王火山的",
}
TagConfig[TagID.Id311] =
{
	Id = 311,
	TAG = "魔王城堡的",
}
TagConfig[TagID.Id312] =
{
	Id = 312,
	TAG = "藏宝库的",
}
TagConfig[TagID.Id313] =
{
	Id = 313,
	TAG = "美食星着陆点的",
}
TagConfig[TagID.Id314] =
{
	Id = 314,
	TAG = "鲷鱼镇的",
}
TagConfig[TagID.Id315] =
{
	Id = 315,
	TAG = "冰淇淋港的",
}
TagConfig[TagID.Id316] =
{
	Id = 316,
	TAG = "糖果镇的",
}
TagConfig[TagID.Id317] =
{
	Id = 317,
	TAG = "甜食工厂的",
}
TagConfig[TagID.Id318] =
{
	Id = 318,
	TAG = "风味镇的",
}
TagConfig[TagID.Id319] =
{
	Id = 319,
	TAG = "煮物镇的",
}
TagConfig[TagID.Id320] =
{
	Id = 320,
	TAG = "饭团镇的",
}
TagConfig[TagID.Id321] =
{
	Id = 321,
	TAG = "寿司镇的",
}
TagConfig[TagID.Id322] =
{
	Id = 322,
	TAG = "烤肉镇的",
}
TagConfig[TagID.Id323] =
{
	Id = 323,
	TAG = "香浓镇的",
}
TagConfig[TagID.Id324] =
{
	Id = 324,
	TAG = "博物馆星着陆点的",
}
TagConfig[TagID.Id325] =
{
	Id = 325,
	TAG = "入口大厅的",
}
TagConfig[TagID.Id326] =
{
	Id = 326,
	TAG = "中心广场的",
}
TagConfig[TagID.Id327] =
{
	Id = 327,
	TAG = "文物厅的",
}
TagConfig[TagID.Id328] =
{
	Id = 328,
	TAG = "修复室的",
}
TagConfig[TagID.Id329] =
{
	Id = 329,
	TAG = "生态园的",
}
TagConfig[TagID.Id330] =
{
	Id = 330,
	TAG = "监控室的",
}
TagConfig[TagID.Id331] =
{
	Id = 331,
	TAG = "古文明厅的",
}
TagConfig[TagID.Id332] =
{
	Id = 332,
	TAG = "化石厅的",
}
TagConfig[TagID.Id333] =
{
	Id = 333,
	TAG = "泥塑厅的",
}
TagConfig[TagID.Id334] =
{
	Id = 334,
	TAG = "恐龙馆的",
}
TagConfig[TagID.Id335] =
{
	Id = 335,
	TAG = "出口的",
}
TagConfig[TagID.Id336] =
{
	Id = 336,
	TAG = "悬疑星着陆点的",
}
TagConfig[TagID.Id337] =
{
	Id = 337,
	TAG = "热闹街道的",
}
TagConfig[TagID.Id338] =
{
	Id = 338,
	TAG = "咖啡馆的",
}
TagConfig[TagID.Id339] =
{
	Id = 339,
	TAG = "邮局的",
}
TagConfig[TagID.Id340] =
{
	Id = 340,
	TAG = "冷清街道的",
}
TagConfig[TagID.Id341] =
{
	Id = 341,
	TAG = "现场的",
}
TagConfig[TagID.Id342] =
{
	Id = 342,
	TAG = "警局的",
}
TagConfig[TagID.Id343] =
{
	Id = 343,
	TAG = "证物仓库的",
}
TagConfig[TagID.Id344] =
{
	Id = 344,
	TAG = "审讯大厅的",
}
TagConfig[TagID.Id345] =
{
	Id = 345,
	TAG = "失物招领局的",
}
TagConfig[TagID.Id346] =
{
	Id = 346,
	TAG = "编辑部的",
}
TagConfig[TagID.Id347] =
{
	Id = 347,
	TAG = "侦探街的",
}
TagConfig[TagID.Id348] =
{
	Id = 348,
	TAG = "实验室的",
}
TagConfig[TagID.Id1101] =
{
	Id = 1101,
	TAG = "——年龄——",
}
TagConfig[TagID.Id1102] =
{
	Id = 1102,
	TAG = "古代的",
}
TagConfig[TagID.Id1103] =
{
	Id = 1103,
	TAG = "年老的",
}
TagConfig[TagID.Id1104] =
{
	Id = 1104,
	TAG = "年轻的",
}
TagConfig[TagID.Id1105] =
{
	Id = 1105,
	TAG = "中年的",
}
TagConfig[TagID.Id1106] =
{
	Id = 1106,
	TAG = "幼年的",
}
TagConfig[TagID.Id1201] =
{
	Id = 1201,
	TAG = "——属性的——",
}
TagConfig[TagID.Id1202] =
{
	Id = 1202,
	TAG = "水元素的",
}
TagConfig[TagID.Id1203] =
{
	Id = 1203,
	TAG = "火元素的",
}
TagConfig[TagID.Id1204] =
{
	Id = 1204,
	TAG = "风元素的",
}
TagConfig[TagID.Id1205] =
{
	Id = 1205,
	TAG = "光元素的",
}
TagConfig[TagID.Id1206] =
{
	Id = 1206,
	TAG = "暗元素的",
}
TagConfig[TagID.Id1207] =
{
	Id = 1207,
	TAG = "防御型的",
}
TagConfig[TagID.Id1208] =
{
	Id = 1208,
	TAG = "攻击型的",
}
TagConfig[TagID.Id1301] =
{
	Id = 1301,
	TAG = "——种族——",
}
TagConfig[TagID.Id1302] =
{
	Id = 1302,
	TAG = "雕塑族的",
}
TagConfig[TagID.Id1303] =
{
	Id = 1303,
	TAG = "动物族的",
}
TagConfig[TagID.Id1304] =
{
	Id = 1304,
	TAG = "画像族的",
}
TagConfig[TagID.Id1305] =
{
	Id = 1305,
	TAG = "精灵族的",
}
TagConfig[TagID.Id1306] =
{
	Id = 1306,
	TAG = "食物族的",
}
TagConfig[TagID.Id1307] =
{
	Id = 1307,
	TAG = "零食族的",
}
TagConfig[TagID.Id1308] =
{
	Id = 1308,
	TAG = "龙族的",
}
TagConfig[TagID.Id1309] =
{
	Id = 1309,
	TAG = "喵星人族的",
}
TagConfig[TagID.Id1310] =
{
	Id = 1310,
	TAG = "魔族的",
}
TagConfig[TagID.Id1311] =
{
	Id = 1311,
	TAG = "人类族的",
}
TagConfig[TagID.Id1312] =
{
	Id = 1312,
	TAG = "肉食族的",
}
TagConfig[TagID.Id1313] =
{
	Id = 1313,
	TAG = "神族的",
}
TagConfig[TagID.Id1314] =
{
	Id = 1314,
	TAG = "实例化族的",
}
TagConfig[TagID.Id1315] =
{
	Id = 1315,
	TAG = "甜食族的",
}
TagConfig[TagID.Id1316] =
{
	Id = 1316,
	TAG = "调味料族的",
}
TagConfig[TagID.Id1317] =
{
	Id = 1317,
	TAG = "亡灵族的",
}
TagConfig[TagID.Id1318] =
{
	Id = 1318,
	TAG = "饮料族的",
}
TagConfig[TagID.Id1319] =
{
	Id = 1319,
	TAG = "主食族的",
}
TagConfig[TagID.Id1320] =
{
	Id = 1320,
	TAG = "植物族的",
}
TagConfig[TagID.Id1321] =
{
	Id = 1321,
	TAG = "傀儡族的",
}
TagConfig[TagID.Id1322] =
{
	Id = 1322,
	TAG = "机械族的",
}
TagConfig[TagID.Id1323] =
{
	Id = 1323,
	TAG = "史莱姆族的",
}
TagConfig[TagID.Id1324] =
{
	Id = 1324,
	TAG = "狼族的",
}
TagConfig[TagID.Id1325] =
{
	Id = 1325,
	TAG = "石头族的",
}
TagConfig[TagID.Id1326] =
{
	Id = 1326,
	TAG = "泥怪族的",
}
TagConfig[TagID.Id1327] =
{
	Id = 1327,
	TAG = "刺毛怪族的",
}
TagConfig[TagID.Id1328] =
{
	Id = 1328,
	TAG = "鱼族的",
}
TagConfig[TagID.Id1329] =
{
	Id = 1329,
	TAG = "豚族的",
}
TagConfig[TagID.Id1330] =
{
	Id = 1330,
	TAG = "水产族的",
}
TagConfig[TagID.Id1331] =
{
	Id = 1331,
	TAG = "水果族的",
}
TagConfig[TagID.Id1332] =
{
	Id = 1332,
	TAG = "点心族的",
}
TagConfig[TagID.Id1333] =
{
	Id = 1333,
	TAG = "糖果族的",
}
TagConfig[TagID.Id1334] =
{
	Id = 1334,
	TAG = "冷饮族的",
}
TagConfig[TagID.Id1335] =
{
	Id = 1335,
	TAG = "标志族的",
}
TagConfig[TagID.Id1336] =
{
	Id = 1336,
	TAG = "文物族的",
}
TagConfig[TagID.Id1337] =
{
	Id = 1337,
	TAG = "障碍族的",
}
TagConfig[TagID.Id1338] =
{
	Id = 1338,
	TAG = "恐龙族的",
}
TagConfig[TagID.Id1339] =
{
	Id = 1339,
	TAG = "瓷器族的",
}
TagConfig[TagID.Id1340] =
{
	Id = 1340,
	TAG = "标本族的",
}
TagConfig[TagID.Id1341] =
{
	Id = 1341,
	TAG = "化石族的",
}
TagConfig[TagID.Id1342] =
{
	Id = 1342,
	TAG = "人鱼族的",
}
TagConfig[TagID.Id1343] =
{
	Id = 1343,
	TAG = "纸张族的",
}
TagConfig[TagID.Id1344] =
{
	Id = 1344,
	TAG = "纺织品族的",
}
TagConfig[TagID.Id1345] =
{
	Id = 1345,
	TAG = "帽子族的",
}
TagConfig[TagID.Id1346] =
{
	Id = 1346,
	TAG = "猫族的",
}
TagConfig[TagID.Id1347] =
{
	Id = 1347,
	TAG = "墨水族的",
}
TagConfig[TagID.Id1348] =
{
	Id = 1348,
	TAG = "工具族的",
}
TagConfig[TagID.Id1349] =
{
	Id = 1349,
	TAG = "犬族的",
}
TagConfig[TagID.Id1350] =
{
	Id = 1350,
	TAG = "水族的",
}
TagConfig[TagID.Id1351] =
{
	Id = 1351,
	TAG = "火族的",
}
TagConfig[TagID.Id1352] =
{
	Id = 1352,
	TAG = "风族的",
}
TagConfig[TagID.Id1353] =
{
	Id = 1353,
	TAG = "光族的",
}
TagConfig[TagID.Id1354] =
{
	Id = 1354,
	TAG = "暗族的",
}
TagConfig[TagID.Id1355] =
{
	Id = 1355,
	TAG = "温驯海族的",
}
TagConfig[TagID.Id1356] =
{
	Id = 1356,
	TAG = "凶猛海族的",
}
TagConfig[TagID.Id1357] =
{
	Id = 1357,
	TAG = "饭团族的",
}
TagConfig[TagID.Id1358] =
{
	Id = 1358,
	TAG = "海草族的",
}
TagConfig[TagID.Id1359] =
{
	Id = 1359,
	TAG = "珊瑚族的",
}
TagConfig[TagID.Id1360] =
{
	Id = 1360,
	TAG = "贝壳族的",
}
TagConfig[TagID.Id1361] =
{
	Id = 1361,
	TAG = "软体族的",
}
TagConfig[TagID.Id1362] =
{
	Id = 1362,
	TAG = "水母族的",
}
TagConfig[TagID.Id1363] =
{
	Id = 1363,
	TAG = "海蛇族的",
}
TagConfig[TagID.Id1364] =
{
	Id = 1364,
	TAG = "海星族的",
}
TagConfig[TagID.Id1365] =
{
	Id = 1365,
	TAG = "微生物族的",
}
TagConfig[TagID.Id1366] =
{
	Id = 1366,
	TAG = "海葵族的",
}
TagConfig[TagID.Id1367] =
{
	Id = 1367,
	TAG = "甲壳族的",
}
TagConfig[TagID.Id1368] =
{
	Id = 1368,
	TAG = "海兔族的",
}
TagConfig[TagID.Id1369] =
{
	Id = 1369,
	TAG = "幽灵族的",
}
TagConfig[TagID.Id1701] =
{
	Id = 1701,
	TAG = "——主要分类——",
}
TagConfig[TagID.Id1702] =
{
	Id = 1702,
	TAG = "男的",
}
TagConfig[TagID.Id1703] =
{
	Id = 1703,
	TAG = "女的",
}
TagConfig[TagID.Id1704] =
{
	Id = 1704,
	TAG = "不男不女的",
}
TagConfig[TagID.Id1705] =
{
	Id = 1705,
	TAG = "正派的",
}
TagConfig[TagID.Id1706] =
{
	Id = 1706,
	TAG = "中立的",
}
TagConfig[TagID.Id1707] =
{
	Id = 1707,
	TAG = "反派的",
}
TagConfig[TagID.Id1801] =
{
	Id = 1801,
	TAG = "——头饰——",
}
TagConfig[TagID.Id1802] =
{
	Id = 1802,
	TAG = "有帽子的",
}
TagConfig[TagID.Id1803] =
{
	Id = 1803,
	TAG = "有动物耳朵的",
}
TagConfig[TagID.Id1804] =
{
	Id = 1804,
	TAG = "有耳机的",
}
TagConfig[TagID.Id1805] =
{
	Id = 1805,
	TAG = "有光环的",
}
TagConfig[TagID.Id1806] =
{
	Id = 1806,
	TAG = "有角的",
}
TagConfig[TagID.Id1807] =
{
	Id = 1807,
	TAG = "有头绳的",
}
TagConfig[TagID.Id1808] =
{
	Id = 1808,
	TAG = "有王冠的",
}
TagConfig[TagID.Id1851] =
{
	Id = 1851,
	TAG = "——脸部特征——",
}
TagConfig[TagID.Id1852] =
{
	Id = 1852,
	TAG = "有胡子的",
}
TagConfig[TagID.Id1853] =
{
	Id = 1853,
	TAG = "有蒙面的",
}
TagConfig[TagID.Id1854] =
{
	Id = 1854,
	TAG = "有烟斗的",
}
TagConfig[TagID.Id1855] =
{
	Id = 1855,
	TAG = "有眼镜的",
}
TagConfig[TagID.Id1901] =
{
	Id = 1901,
	TAG = "——服装——",
}
TagConfig[TagID.Id1902] =
{
	Id = 1902,
	TAG = "有便服的",
}
TagConfig[TagID.Id1903] =
{
	Id = 1903,
	TAG = "有工作服的",
}
TagConfig[TagID.Id1904] =
{
	Id = 1904,
	TAG = "有礼服的",
}
TagConfig[TagID.Id1905] =
{
	Id = 1905,
	TAG = "有奇装异服的",
}
TagConfig[TagID.Id1906] =
{
	Id = 1906,
	TAG = "有重装甲的",
}
TagConfig[TagID.Id2001] =
{
	Id = 2001,
	TAG = "——其他特征——",
}
TagConfig[TagID.Id2002] =
{
	Id = 2002,
	TAG = "辅助的",
}
TagConfig[TagID.Id2003] =
{
	Id = 2003,
	TAG = "贵族的",
}
TagConfig[TagID.Id2004] =
{
	Id = 2004,
	TAG = "好吃的",
}
TagConfig[TagID.Id2005] =
{
	Id = 2005,
	TAG = "迷糊的",
}
TagConfig[TagID.Id2006] =
{
	Id = 2006,
	TAG = "敏捷的",
}
TagConfig[TagID.Id2007] =
{
	Id = 2007,
	TAG = "魔力的",
}
TagConfig[TagID.Id2008] =
{
	Id = 2008,
	TAG = "邪恶的",
}
TagConfig[TagID.Id2009] =
{
	Id = 2009,
	TAG = "艺术的",
}
TagConfig[TagID.Id2010] =
{
	Id = 2010,
	TAG = "勇敢的",
}
TagConfig[TagID.Id2011] =
{
	Id = 2011,
	TAG = "智慧的",
}
TagConfig[TagID.Id2012] =
{
	Id = 2012,
	TAG = "和善",
}
TagConfig[TagID.Id2013] =
{
	Id = 2013,
	TAG = "严肃",
}
TagConfig[TagID.Id2014] =
{
	Id = 2014,
	TAG = "冷漠",
}
TagConfig[TagID.Id2101] =
{
	Id = 2101,
	TAG = "——表面触感——",
}
TagConfig[TagID.Id2102] =
{
	Id = 2102,
	TAG = "毛茸茸的",
}
TagConfig[TagID.Id2103] =
{
	Id = 2103,
	TAG = "软绵绵的",
}
TagConfig[TagID.Id2104] =
{
	Id = 2104,
	TAG = "硬邦邦的",
}
TagConfig[TagID.Id2201] =
{
	Id = 2201,
	TAG = "——携带宠物——",
}
TagConfig[TagID.Id2202] =
{
	Id = 2202,
	TAG = "有宠物的",
}
TagConfig[TagID.Id2301] =
{
	Id = 2301,
	TAG = "——武器——",
}
TagConfig[TagID.Id2302] =
{
	Id = 2302,
	TAG = "有工具的",
}
TagConfig[TagID.Id2303] =
{
	Id = 2303,
	TAG = "有枪械的",
}
TagConfig[TagID.Id2304] =
{
	Id = 2304,
	TAG = "有食物的",
}
TagConfig[TagID.Id2305] =
{
	Id = 2305,
	TAG = "有玩具的",
}
TagConfig[TagID.Id2306] =
{
	Id = 2306,
	TAG = "有武器的",
}
TagConfig[TagID.Id2401] =
{
	Id = 2401,
	TAG = "——背包——",
}
TagConfig[TagID.Id2402] =
{
	Id = 2402,
	TAG = "有背包的",
}
TagConfig[TagID.Id2403] =
{
	Id = 2403,
	TAG = "有翅膀的",
}
TagConfig[TagID.Id2501] =
{
	Id = 2501,
	TAG = "——腰带——",
}
TagConfig[TagID.Id2502] =
{
	Id = 2502,
	TAG = "有腰带的",
}
TagConfig[TagID.Id2601] =
{
	Id = 2601,
	TAG = "——主题元素——",
}
TagConfig[TagID.Id2602] =
{
	Id = 2602,
	TAG = "有抽象感的",
}
TagConfig[TagID.Id2603] =
{
	Id = 2603,
	TAG = "有蝴蝶结的",
}
TagConfig[TagID.Id2604] =
{
	Id = 2604,
	TAG = "有金属感的",
}
TagConfig[TagID.Id2605] =
{
	Id = 2605,
	TAG = "有科技感的",
}
TagConfig[TagID.Id2606] =
{
	Id = 2606,
	TAG = "有骷髅的",
}
TagConfig[TagID.Id2607] =
{
	Id = 2607,
	TAG = "有皮草的",
}
TagConfig[TagID.Id2608] =
{
	Id = 2608,
	TAG = "有主题色的",
}
TagConfig[TagID.Id2701] =
{
	Id = 2701,
	TAG = "——身体特征——",
}
TagConfig[TagID.Id2702] =
{
	Id = 2702,
	TAG = "卷发的",
}
TagConfig[TagID.Id2703] =
{
	Id = 2703,
	TAG = "球形的",
}
TagConfig[TagID.Id2704] =
{
	Id = 2704,
	TAG = "有尾巴的",
}
TagConfig[TagID.Id2705] =
{
	Id = 2705,
	TAG = "有纹身的",
}
TagConfig[TagID.Id2801] =
{
	Id = 2801,
	TAG = "——颜值——",
}
TagConfig[TagID.Id2802] =
{
	Id = 2802,
	TAG = "高颜值的",
}
TagConfig[TagID.Id2803] =
{
	Id = 2803,
	TAG = "没有嘴的",
}
TagConfig[TagID.Id2901] =
{
	Id = 2901,
	TAG = "——所在组织——",
}
TagConfig[TagID.Id2902] =
{
	Id = 2902,
	TAG = "经典冒险组的",
}
TagConfig[TagID.Id2903] =
{
	Id = 2903,
	TAG = "村长组的",
}
TagConfig[TagID.Id2904] =
{
	Id = 2904,
	TAG = "魔王组的",
}
TagConfig[TagID.Id2905] =
{
	Id = 2905,
	TAG = "NPC组的",
}
TagConfig[TagID.Id2906] =
{
	Id = 2906,
	TAG = "制作组的",
}
TagConfig[TagID.Id2907] =
{
	Id = 2907,
	TAG = "美食王子组的",
}
TagConfig[TagID.Id2908] =
{
	Id = 2908,
	TAG = "美食公主组的",
}
TagConfig[TagID.Id2909] =
{
	Id = 2909,
	TAG = "糖豆组的",
}
TagConfig[TagID.Id2910] =
{
	Id = 2910,
	TAG = "仙子组的",
}
TagConfig[TagID.Id2911] =
{
	Id = 2911,
	TAG = "埃及神组的",
}
TagConfig[TagID.Id2912] =
{
	Id = 2912,
	TAG = "石像组的",
}
TagConfig[TagID.Id2913] =
{
	Id = 2913,
	TAG = "侦探组的",
}
TagConfig[TagID.Id2914] =
{
	Id = 2914,
	TAG = "名画组的",
}
TagConfig[TagID.Id2915] =
{
	Id = 2915,
	TAG = "浣熊组的",
}
TagConfig[TagID.Id2916] =
{
	Id = 2916,
	TAG = "原始人组的",
}
TagConfig[TagID.Id2917] =
{
	Id = 2917,
	TAG = "公检法组的",
}
TagConfig[TagID.Id2918] =
{
	Id = 2918,
	TAG = "猫眼组的",
}
TagConfig[TagID.Id2919] =
{
	Id = 2919,
	TAG = "正义组的",
}
TagConfig[TagID.Id2920] =
{
	Id = 2920,
	TAG = "罪犯组的",
}
TagConfig[TagID.Id2921] =
{
	Id = 2921,
	TAG = "Sharkalaka组的",
}
TagConfig[TagID.Id2922] =
{
	Id = 2922,
	TAG = "海豚乙女组的",
}
TagConfig[TagID.Id2923] =
{
	Id = 2923,
	TAG = "贝壳街TeaTime组的",
}
TagConfig[TagID.Id2924] =
{
	Id = 2924,
	TAG = "RockingThanks组的",
}
TagConfig[TagID.Id2925] =
{
	Id = 2925,
	TAG = "深潜FoRever组的",
}
TagConfig[TagID.Id2926] =
{
	Id = 2926,
	TAG = "Aquarius组的",
}
TagConfig[TagID.Id2927] =
{
	Id = 2927,
	TAG = "鱼妄想组的",
}
TagConfig[TagID.Id2928] =
{
	Id = 2928,
	TAG = "SealingsVoice组的",
}
TagConfig[TagID.Id2929] =
{
	Id = 2929,
	TAG = "浅海Smily组的",
}
TagConfig[TagID.Id2930] =
{
	Id = 2930,
	TAG = "八仙组的",
}
TagConfig[TagID.Id2931] =
{
	Id = 2931,
	TAG = "国际象棋组的",
}
TagConfig[TagID.Id2932] =
{
	Id = 2932,
	TAG = "五福组的",
}
TagConfig[TagID.Id2933] =
{
	Id = 2933,
	TAG = "春节组的",
}
TagConfig[TagID.Id2934] =
{
	Id = 2934,
	TAG = "星际龙舟组的",
}
TagConfig[TagID.Id2935] =
{
	Id = 2935,
	TAG = "庙会角色的",
}
TagConfig[TagID.Id2936] =
{
	Id = 2936,
	TAG = "冬日温泉组的",
}
TagConfig[TagID.Id3001] =
{
	Id = 3001,
	TAG = "——个人特长——",
}
TagConfig[TagID.Id3002] =
{
	Id = 3002,
	TAG = "会除虫的",
}
TagConfig[TagID.Id3003] =
{
	Id = 3003,
	TAG = "会代码的",
}
TagConfig[TagID.Id3004] =
{
	Id = 3004,
	TAG = "会魔法的",
}
TagConfig[TagID.Id3005] =
{
	Id = 3005,
	TAG = "会配音的",
}
TagConfig[TagID.Id3006] =
{
	Id = 3006,
	TAG = "会破坏的",
}
TagConfig[TagID.Id3007] =
{
	Id = 3007,
	TAG = "会求助的",
}
TagConfig[TagID.Id3008] =
{
	Id = 3008,
	TAG = "会偷袭的",
}
TagConfig[TagID.Id3009] =
{
	Id = 3009,
	TAG = "会文档的",
}
TagConfig[TagID.Id3010] =
{
	Id = 3010,
	TAG = "会原画的",
}
TagConfig[TagID.Id3011] =
{
	Id = 3011,
	TAG = "会战斗的",
}
TagConfig[TagID.Id3012] =
{
	Id = 3012,
	TAG = "会指路的",
}
TagConfig[TagID.Id3013] =
{
	Id = 3013,
	TAG = "会治疗的",
}
TagConfig[TagID.Id3101] =
{
	Id = 3101,
	TAG = "——捕捉方式——",
}
TagConfig[TagID.Id3102] =
{
	Id = 3102,
	TAG = "陷阱捕捉的",
}
TagConfig[TagID.Id3103] =
{
	Id = 3103,
	TAG = "空瓶捕捉的",
}
TagConfig[TagID.Id3104] =
{
	Id = 3104,
	TAG = "纸袋捕捉的",
}
TagConfig[TagID.Id3105] =
{
	Id = 3105,
	TAG = "工具箱捕捉的",
}
TagConfig[TagID.Id3106] =
{
	Id = 3106,
	TAG = "纸板箱捕捉的",
}
TagConfig[TagID.Id3201] =
{
	Id = 3201,
	TAG = "——特性——",
}
TagConfig[TagID.Id3202] =
{
	Id = 3202,
	TAG = "速度-1",
}
TagConfig[TagID.Id3203] =
{
	Id = 3203,
	TAG = "速度-2",
}
TagConfig[TagID.Id3204] =
{
	Id = 3204,
	TAG = "速度-3",
}
TagConfig[TagID.Id3205] =
{
	Id = 3205,
	TAG = "速度-4",
}
TagConfig[TagID.Id3206] =
{
	Id = 3206,
	TAG = "速度-5",
}
TagConfig[TagID.Id3301] =
{
	Id = 3301,
	TAG = "——态度——",
}
TagConfig[TagID.Id3302] =
{
	Id = 3302,
	TAG = "驯化-1",
}
TagConfig[TagID.Id3303] =
{
	Id = 3303,
	TAG = "驯化-2",
}
TagConfig[TagID.Id3304] =
{
	Id = 3304,
	TAG = "驯化-3",
}
TagConfig[TagID.Id3305] =
{
	Id = 3305,
	TAG = "驯化-4",
}
TagConfig[TagID.Id3306] =
{
	Id = 3306,
	TAG = "驯化-5",
}
TagConfig[TagID.Id3401] =
{
	Id = 3401,
	TAG = "——温度——",
}
TagConfig[TagID.Id3402] =
{
	Id = 3402,
	TAG = "温度-1",
}
TagConfig[TagID.Id3403] =
{
	Id = 3403,
	TAG = "温度-2",
}
TagConfig[TagID.Id3404] =
{
	Id = 3404,
	TAG = "温度-3",
}
TagConfig[TagID.Id3405] =
{
	Id = 3405,
	TAG = "温度-4",
}
TagConfig[TagID.Id3406] =
{
	Id = 3406,
	TAG = "温度-5",
}
TagConfig[TagID.Id3501] =
{
	Id = 3501,
	TAG = "——多色——",
}
TagConfig[TagID.Id3502] =
{
	Id = 3502,
	TAG = "多色-1",
}
TagConfig[TagID.Id3503] =
{
	Id = 3503,
	TAG = "多色-2",
}
TagConfig[TagID.Id3504] =
{
	Id = 3504,
	TAG = "多色-3",
}
TagConfig[TagID.Id3505] =
{
	Id = 3505,
	TAG = "多色-4",
}
TagConfig[TagID.Id3506] =
{
	Id = 3506,
	TAG = "多色-5",
}
TagConfig[TagID.Id3601] =
{
	Id = 3601,
	TAG = "——形状——",
}
TagConfig[TagID.Id3602] =
{
	Id = 3602,
	TAG = "方形-1",
}
TagConfig[TagID.Id3603] =
{
	Id = 3603,
	TAG = "方形-2",
}
TagConfig[TagID.Id3604] =
{
	Id = 3604,
	TAG = "方形-3",
}
TagConfig[TagID.Id3605] =
{
	Id = 3605,
	TAG = "方形-4",
}
TagConfig[TagID.Id3606] =
{
	Id = 3606,
	TAG = "方形-5",
}
TagConfig[TagID.Id3607] =
{
	Id = 3607,
	TAG = "糊状-1",
}
TagConfig[TagID.Id3608] =
{
	Id = 3608,
	TAG = "糊状-2",
}
TagConfig[TagID.Id3609] =
{
	Id = 3609,
	TAG = "糊状-3",
}
TagConfig[TagID.Id3610] =
{
	Id = 3610,
	TAG = "糊状-4",
}
TagConfig[TagID.Id3611] =
{
	Id = 3611,
	TAG = "糊状-5",
}
TagConfig[TagID.Id3612] =
{
	Id = 3612,
	TAG = "人形-1",
}
TagConfig[TagID.Id3613] =
{
	Id = 3613,
	TAG = "人形-2",
}
TagConfig[TagID.Id3614] =
{
	Id = 3614,
	TAG = "人形-3",
}
TagConfig[TagID.Id3615] =
{
	Id = 3615,
	TAG = "人形-4",
}
TagConfig[TagID.Id3616] =
{
	Id = 3616,
	TAG = "人形-5",
}
TagConfig[TagID.Id3617] =
{
	Id = 3617,
	TAG = "圆形-1",
}
TagConfig[TagID.Id3618] =
{
	Id = 3618,
	TAG = "圆形-2",
}
TagConfig[TagID.Id3619] =
{
	Id = 3619,
	TAG = "圆形-3",
}
TagConfig[TagID.Id3620] =
{
	Id = 3620,
	TAG = "圆形-4",
}
TagConfig[TagID.Id3621] =
{
	Id = 3621,
	TAG = "圆形-5",
}
TagConfig[TagID.Id3622] =
{
	Id = 3622,
	TAG = "柱形-1",
}
TagConfig[TagID.Id3623] =
{
	Id = 3623,
	TAG = "柱形-2",
}
TagConfig[TagID.Id3624] =
{
	Id = 3624,
	TAG = "柱形-3",
}
TagConfig[TagID.Id3625] =
{
	Id = 3625,
	TAG = "柱形-4",
}
TagConfig[TagID.Id3626] =
{
	Id = 3626,
	TAG = "柱形-5",
}
TagConfig[TagID.Id3701] =
{
	Id = 3701,
	TAG = "——触感——",
}
TagConfig[TagID.Id3702] =
{
	Id = 3702,
	TAG = "毛绒-1",
}
TagConfig[TagID.Id3703] =
{
	Id = 3703,
	TAG = "毛绒-2",
}
TagConfig[TagID.Id3704] =
{
	Id = 3704,
	TAG = "毛绒-3",
}
TagConfig[TagID.Id3705] =
{
	Id = 3705,
	TAG = "毛绒-4",
}
TagConfig[TagID.Id3706] =
{
	Id = 3706,
	TAG = "毛绒-5",
}
TagConfig[TagID.Id3707] =
{
	Id = 3707,
	TAG = "粘度-1",
}
TagConfig[TagID.Id3708] =
{
	Id = 3708,
	TAG = "粘度-2",
}
TagConfig[TagID.Id3709] =
{
	Id = 3709,
	TAG = "粘度-3",
}
TagConfig[TagID.Id3710] =
{
	Id = 3710,
	TAG = "粘度-4",
}
TagConfig[TagID.Id3711] =
{
	Id = 3711,
	TAG = "粘度-5",
}
TagConfig[TagID.Id3801] =
{
	Id = 3801,
	TAG = "——质地——",
}
TagConfig[TagID.Id3802] =
{
	Id = 3802,
	TAG = "弹性-1",
}
TagConfig[TagID.Id3803] =
{
	Id = 3803,
	TAG = "弹性-2",
}
TagConfig[TagID.Id3804] =
{
	Id = 3804,
	TAG = "弹性-3",
}
TagConfig[TagID.Id3805] =
{
	Id = 3805,
	TAG = "弹性-4",
}
TagConfig[TagID.Id3806] =
{
	Id = 3806,
	TAG = "弹性-5",
}
TagConfig[TagID.Id3807] =
{
	Id = 3807,
	TAG = "硌手-1",
}
TagConfig[TagID.Id3808] =
{
	Id = 3808,
	TAG = "硌手-2",
}
TagConfig[TagID.Id3809] =
{
	Id = 3809,
	TAG = "硌手-3",
}
TagConfig[TagID.Id3810] =
{
	Id = 3810,
	TAG = "硌手-4",
}
TagConfig[TagID.Id3811] =
{
	Id = 3811,
	TAG = "硌手-5",
}
TagConfig[TagID.Id3812] =
{
	Id = 3812,
	TAG = "坚硬-1",
}
TagConfig[TagID.Id3813] =
{
	Id = 3813,
	TAG = "坚硬-2",
}
TagConfig[TagID.Id3814] =
{
	Id = 3814,
	TAG = "坚硬-3",
}
TagConfig[TagID.Id3815] =
{
	Id = 3815,
	TAG = "坚硬-4",
}
TagConfig[TagID.Id3816] =
{
	Id = 3816,
	TAG = "坚硬-5",
}
TagConfig[TagID.Id3817] =
{
	Id = 3817,
	TAG = "筋道-1",
}
TagConfig[TagID.Id3818] =
{
	Id = 3818,
	TAG = "筋道-2",
}
TagConfig[TagID.Id3819] =
{
	Id = 3819,
	TAG = "筋道-3",
}
TagConfig[TagID.Id3820] =
{
	Id = 3820,
	TAG = "筋道-4",
}
TagConfig[TagID.Id3821] =
{
	Id = 3821,
	TAG = "筋道-5",
}
TagConfig[TagID.Id3822] =
{
	Id = 3822,
	TAG = "柔软-1",
}
TagConfig[TagID.Id3823] =
{
	Id = 3823,
	TAG = "柔软-2",
}
TagConfig[TagID.Id3824] =
{
	Id = 3824,
	TAG = "柔软-3",
}
TagConfig[TagID.Id3825] =
{
	Id = 3825,
	TAG = "柔软-4",
}
TagConfig[TagID.Id3826] =
{
	Id = 3826,
	TAG = "柔软-5",
}
TagConfig[TagID.Id3827] =
{
	Id = 3827,
	TAG = "松脆-1",
}
TagConfig[TagID.Id3828] =
{
	Id = 3828,
	TAG = "松脆-2",
}
TagConfig[TagID.Id3829] =
{
	Id = 3829,
	TAG = "松脆-3",
}
TagConfig[TagID.Id3830] =
{
	Id = 3830,
	TAG = "松脆-4",
}
TagConfig[TagID.Id3831] =
{
	Id = 3831,
	TAG = "松脆-5",
}
TagConfig[TagID.Id3901] =
{
	Id = 3901,
	TAG = "——颜色1——",
}
TagConfig[TagID.Id3902] =
{
	Id = 3902,
	TAG = "白色-1",
}
TagConfig[TagID.Id3903] =
{
	Id = 3903,
	TAG = "白色-2",
}
TagConfig[TagID.Id3904] =
{
	Id = 3904,
	TAG = "白色-3",
}
TagConfig[TagID.Id3905] =
{
	Id = 3905,
	TAG = "白色-4",
}
TagConfig[TagID.Id3906] =
{
	Id = 3906,
	TAG = "白色-5",
}
TagConfig[TagID.Id3907] =
{
	Id = 3907,
	TAG = "粉色-1",
}
TagConfig[TagID.Id3908] =
{
	Id = 3908,
	TAG = "粉色-2",
}
TagConfig[TagID.Id3909] =
{
	Id = 3909,
	TAG = "粉色-3",
}
TagConfig[TagID.Id3910] =
{
	Id = 3910,
	TAG = "粉色-4",
}
TagConfig[TagID.Id3911] =
{
	Id = 3911,
	TAG = "粉色-5",
}
TagConfig[TagID.Id3912] =
{
	Id = 3912,
	TAG = "黑色-1",
}
TagConfig[TagID.Id3913] =
{
	Id = 3913,
	TAG = "黑色-2",
}
TagConfig[TagID.Id3914] =
{
	Id = 3914,
	TAG = "黑色-3",
}
TagConfig[TagID.Id3915] =
{
	Id = 3915,
	TAG = "黑色-4",
}
TagConfig[TagID.Id3916] =
{
	Id = 3916,
	TAG = "黑色-5",
}
TagConfig[TagID.Id3917] =
{
	Id = 3917,
	TAG = "红色-1",
}
TagConfig[TagID.Id3918] =
{
	Id = 3918,
	TAG = "红色-2",
}
TagConfig[TagID.Id3919] =
{
	Id = 3919,
	TAG = "红色-3",
}
TagConfig[TagID.Id3920] =
{
	Id = 3920,
	TAG = "红色-4",
}
TagConfig[TagID.Id3921] =
{
	Id = 3921,
	TAG = "红色-5",
}
TagConfig[TagID.Id3922] =
{
	Id = 3922,
	TAG = "黄色-1",
}
TagConfig[TagID.Id3923] =
{
	Id = 3923,
	TAG = "黄色-2",
}
TagConfig[TagID.Id3924] =
{
	Id = 3924,
	TAG = "黄色-3",
}
TagConfig[TagID.Id3925] =
{
	Id = 3925,
	TAG = "黄色-4",
}
TagConfig[TagID.Id3926] =
{
	Id = 3926,
	TAG = "黄色-5",
}
TagConfig[TagID.Id3927] =
{
	Id = 3927,
	TAG = "灰色-1",
}
TagConfig[TagID.Id3928] =
{
	Id = 3928,
	TAG = "灰色-2",
}
TagConfig[TagID.Id3929] =
{
	Id = 3929,
	TAG = "灰色-3",
}
TagConfig[TagID.Id3930] =
{
	Id = 3930,
	TAG = "灰色-4",
}
TagConfig[TagID.Id3931] =
{
	Id = 3931,
	TAG = "灰色-5",
}
TagConfig[TagID.Id3932] =
{
	Id = 3932,
	TAG = "蓝色-1",
}
TagConfig[TagID.Id3933] =
{
	Id = 3933,
	TAG = "蓝色-2",
}
TagConfig[TagID.Id3934] =
{
	Id = 3934,
	TAG = "蓝色-3",
}
TagConfig[TagID.Id3935] =
{
	Id = 3935,
	TAG = "蓝色-4",
}
TagConfig[TagID.Id3936] =
{
	Id = 3936,
	TAG = "蓝色-5",
}
TagConfig[TagID.Id3937] =
{
	Id = 3937,
	TAG = "绿色-1",
}
TagConfig[TagID.Id3938] =
{
	Id = 3938,
	TAG = "绿色-2",
}
TagConfig[TagID.Id3939] =
{
	Id = 3939,
	TAG = "绿色-3",
}
TagConfig[TagID.Id3940] =
{
	Id = 3940,
	TAG = "绿色-4",
}
TagConfig[TagID.Id3941] =
{
	Id = 3941,
	TAG = "绿色-5",
}
TagConfig[TagID.Id3942] =
{
	Id = 3942,
	TAG = "原色-1",
}
TagConfig[TagID.Id3943] =
{
	Id = 3943,
	TAG = "原色-2",
}
TagConfig[TagID.Id3944] =
{
	Id = 3944,
	TAG = "原色-3",
}
TagConfig[TagID.Id3945] =
{
	Id = 3945,
	TAG = "原色-4",
}
TagConfig[TagID.Id3946] =
{
	Id = 3946,
	TAG = "原色-5",
}
TagConfig[TagID.Id3947] =
{
	Id = 3947,
	TAG = "紫色-1",
}
TagConfig[TagID.Id3948] =
{
	Id = 3948,
	TAG = "紫色-2",
}
TagConfig[TagID.Id3949] =
{
	Id = 3949,
	TAG = "紫色-3",
}
TagConfig[TagID.Id3950] =
{
	Id = 3950,
	TAG = "紫色-4",
}
TagConfig[TagID.Id3951] =
{
	Id = 3951,
	TAG = "紫色-5",
}
TagConfig[TagID.Id3952] =
{
	Id = 3952,
	TAG = "金色-1",
}
TagConfig[TagID.Id3953] =
{
	Id = 3953,
	TAG = "金色-2",
}
TagConfig[TagID.Id3954] =
{
	Id = 3954,
	TAG = "金色-3",
}
TagConfig[TagID.Id3955] =
{
	Id = 3955,
	TAG = "金色-4",
}
TagConfig[TagID.Id3956] =
{
	Id = 3956,
	TAG = "金色-5",
}
TagConfig[TagID.Id4001] =
{
	Id = 4001,
	TAG = "——形象——",
}
TagConfig[TagID.Id4002] =
{
	Id = 4002,
	TAG = "呆萌-1",
}
TagConfig[TagID.Id4003] =
{
	Id = 4003,
	TAG = "呆萌-2",
}
TagConfig[TagID.Id4004] =
{
	Id = 4004,
	TAG = "呆萌-3",
}
TagConfig[TagID.Id4005] =
{
	Id = 4005,
	TAG = "呆萌-4",
}
TagConfig[TagID.Id4006] =
{
	Id = 4006,
	TAG = "呆萌-5",
}
TagConfig[TagID.Id4007] =
{
	Id = 4007,
	TAG = "高贵-1",
}
TagConfig[TagID.Id4008] =
{
	Id = 4008,
	TAG = "高贵-2",
}
TagConfig[TagID.Id4009] =
{
	Id = 4009,
	TAG = "高贵-3",
}
TagConfig[TagID.Id4010] =
{
	Id = 4010,
	TAG = "高贵-4",
}
TagConfig[TagID.Id4011] =
{
	Id = 4011,
	TAG = "高贵-5",
}
TagConfig[TagID.Id4012] =
{
	Id = 4012,
	TAG = "机灵-1",
}
TagConfig[TagID.Id4013] =
{
	Id = 4013,
	TAG = "机灵-2",
}
TagConfig[TagID.Id4014] =
{
	Id = 4014,
	TAG = "机灵-3",
}
TagConfig[TagID.Id4015] =
{
	Id = 4015,
	TAG = "机灵-4",
}
TagConfig[TagID.Id4016] =
{
	Id = 4016,
	TAG = "机灵-5",
}
TagConfig[TagID.Id4017] =
{
	Id = 4017,
	TAG = "可爱-1",
}
TagConfig[TagID.Id4018] =
{
	Id = 4018,
	TAG = "可爱-2",
}
TagConfig[TagID.Id4019] =
{
	Id = 4019,
	TAG = "可爱-3",
}
TagConfig[TagID.Id4020] =
{
	Id = 4020,
	TAG = "可爱-4",
}
TagConfig[TagID.Id4021] =
{
	Id = 4021,
	TAG = "可爱-5",
}
TagConfig[TagID.Id4022] =
{
	Id = 4022,
	TAG = "神秘-1",
}
TagConfig[TagID.Id4023] =
{
	Id = 4023,
	TAG = "神秘-2",
}
TagConfig[TagID.Id4024] =
{
	Id = 4024,
	TAG = "神秘-3",
}
TagConfig[TagID.Id4025] =
{
	Id = 4025,
	TAG = "神秘-4",
}
TagConfig[TagID.Id4026] =
{
	Id = 4026,
	TAG = "神秘-5",
}
TagConfig[TagID.Id4027] =
{
	Id = 4027,
	TAG = "威武-1",
}
TagConfig[TagID.Id4028] =
{
	Id = 4028,
	TAG = "威武-2",
}
TagConfig[TagID.Id4029] =
{
	Id = 4029,
	TAG = "威武-3",
}
TagConfig[TagID.Id4030] =
{
	Id = 4030,
	TAG = "威武-4",
}
TagConfig[TagID.Id4031] =
{
	Id = 4031,
	TAG = "威武-5",
}
TagConfig[TagID.Id4032] =
{
	Id = 4032,
	TAG = "嚣张-1",
}
TagConfig[TagID.Id4033] =
{
	Id = 4033,
	TAG = "嚣张-2",
}
TagConfig[TagID.Id4034] =
{
	Id = 4034,
	TAG = "嚣张-3",
}
TagConfig[TagID.Id4035] =
{
	Id = 4035,
	TAG = "嚣张-4",
}
TagConfig[TagID.Id4036] =
{
	Id = 4036,
	TAG = "嚣张-5",
}
TagConfig[TagID.Id4037] =
{
	Id = 4037,
	TAG = "凶恶-1",
}
TagConfig[TagID.Id4038] =
{
	Id = 4038,
	TAG = "凶恶-2",
}
TagConfig[TagID.Id4039] =
{
	Id = 4039,
	TAG = "凶恶-3",
}
TagConfig[TagID.Id4040] =
{
	Id = 4040,
	TAG = "凶恶-4",
}
TagConfig[TagID.Id4041] =
{
	Id = 4041,
	TAG = "凶恶-5",
}
TagConfig[TagID.Id4042] =
{
	Id = 4042,
	TAG = "艺术-1",
}
TagConfig[TagID.Id4043] =
{
	Id = 4043,
	TAG = "艺术-2",
}
TagConfig[TagID.Id4044] =
{
	Id = 4044,
	TAG = "艺术-3",
}
TagConfig[TagID.Id4045] =
{
	Id = 4045,
	TAG = "艺术-4",
}
TagConfig[TagID.Id4046] =
{
	Id = 4046,
	TAG = "艺术-5",
}
TagConfig[TagID.Id4047] =
{
	Id = 4047,
	TAG = "自然-1",
}
TagConfig[TagID.Id4048] =
{
	Id = 4048,
	TAG = "自然-2",
}
TagConfig[TagID.Id4049] =
{
	Id = 4049,
	TAG = "自然-3",
}
TagConfig[TagID.Id4050] =
{
	Id = 4050,
	TAG = "自然-4",
}
TagConfig[TagID.Id4051] =
{
	Id = 4051,
	TAG = "自然-5",
}
TagConfig[TagID.Id4052] =
{
	Id = 4052,
	TAG = "机械-1",
}
TagConfig[TagID.Id4053] =
{
	Id = 4053,
	TAG = "机械-2",
}
TagConfig[TagID.Id4054] =
{
	Id = 4054,
	TAG = "机械-3",
}
TagConfig[TagID.Id4055] =
{
	Id = 4055,
	TAG = "机械-4",
}
TagConfig[TagID.Id4056] =
{
	Id = 4056,
	TAG = "机械-5",
}
TagConfig[TagID.Id4057] =
{
	Id = 4057,
	TAG = "博学-1",
}
TagConfig[TagID.Id4058] =
{
	Id = 4058,
	TAG = "博学-2",
}
TagConfig[TagID.Id4059] =
{
	Id = 4059,
	TAG = "博学-3",
}
TagConfig[TagID.Id4060] =
{
	Id = 4060,
	TAG = "博学-4",
}
TagConfig[TagID.Id4061] =
{
	Id = 4061,
	TAG = "博学-5",
}
TagConfig[TagID.Id4062] =
{
	Id = 4062,
	TAG = "吉利-1",
}
TagConfig[TagID.Id4063] =
{
	Id = 4063,
	TAG = "吉利-2",
}
TagConfig[TagID.Id4064] =
{
	Id = 4064,
	TAG = "吉利-3",
}
TagConfig[TagID.Id4065] =
{
	Id = 4065,
	TAG = "吉利-4",
}
TagConfig[TagID.Id4066] =
{
	Id = 4066,
	TAG = "吉利-5",
}
TagConfig[TagID.Id4101] =
{
	Id = 4101,
	TAG = "——味道——",
}
TagConfig[TagID.Id4102] =
{
	Id = 4102,
	TAG = "腐臭-1",
}
TagConfig[TagID.Id4103] =
{
	Id = 4103,
	TAG = "腐臭-2",
}
TagConfig[TagID.Id4104] =
{
	Id = 4104,
	TAG = "腐臭-3",
}
TagConfig[TagID.Id4105] =
{
	Id = 4105,
	TAG = "腐臭-4",
}
TagConfig[TagID.Id4106] =
{
	Id = 4106,
	TAG = "腐臭-5",
}
TagConfig[TagID.Id4107] =
{
	Id = 4107,
	TAG = "海鲜-1",
}
TagConfig[TagID.Id4108] =
{
	Id = 4108,
	TAG = "海鲜-2",
}
TagConfig[TagID.Id4109] =
{
	Id = 4109,
	TAG = "海鲜-3",
}
TagConfig[TagID.Id4110] =
{
	Id = 4110,
	TAG = "海鲜-4",
}
TagConfig[TagID.Id4111] =
{
	Id = 4111,
	TAG = "海鲜-5",
}
TagConfig[TagID.Id4112] =
{
	Id = 4112,
	TAG = "矿物-1",
}
TagConfig[TagID.Id4113] =
{
	Id = 4113,
	TAG = "矿物-2",
}
TagConfig[TagID.Id4114] =
{
	Id = 4114,
	TAG = "矿物-3",
}
TagConfig[TagID.Id4115] =
{
	Id = 4115,
	TAG = "矿物-4",
}
TagConfig[TagID.Id4116] =
{
	Id = 4116,
	TAG = "矿物-5",
}
TagConfig[TagID.Id4117] =
{
	Id = 4117,
	TAG = "清甜-1",
}
TagConfig[TagID.Id4118] =
{
	Id = 4118,
	TAG = "清甜-2",
}
TagConfig[TagID.Id4119] =
{
	Id = 4119,
	TAG = "清甜-3",
}
TagConfig[TagID.Id4120] =
{
	Id = 4120,
	TAG = "清甜-4",
}
TagConfig[TagID.Id4121] =
{
	Id = 4121,
	TAG = "清甜-5",
}
TagConfig[TagID.Id4122] =
{
	Id = 4122,
	TAG = "烧烤-1",
}
TagConfig[TagID.Id4123] =
{
	Id = 4123,
	TAG = "烧烤-2",
}
TagConfig[TagID.Id4124] =
{
	Id = 4124,
	TAG = "烧烤-3",
}
TagConfig[TagID.Id4125] =
{
	Id = 4125,
	TAG = "烧烤-4",
}
TagConfig[TagID.Id4126] =
{
	Id = 4126,
	TAG = "烧烤-5",
}
TagConfig[TagID.Id4127] =
{
	Id = 4127,
	TAG = "酸甜-1",
}
TagConfig[TagID.Id4128] =
{
	Id = 4128,
	TAG = "酸甜-2",
}
TagConfig[TagID.Id4129] =
{
	Id = 4129,
	TAG = "酸甜-3",
}
TagConfig[TagID.Id4130] =
{
	Id = 4130,
	TAG = "酸甜-4",
}
TagConfig[TagID.Id4131] =
{
	Id = 4131,
	TAG = "酸甜-5",
}
TagConfig[TagID.Id4132] =
{
	Id = 4132,
	TAG = "甜蜜-1",
}
TagConfig[TagID.Id4133] =
{
	Id = 4133,
	TAG = "甜蜜-2",
}
TagConfig[TagID.Id4134] =
{
	Id = 4134,
	TAG = "甜蜜-3",
}
TagConfig[TagID.Id4135] =
{
	Id = 4135,
	TAG = "甜蜜-4",
}
TagConfig[TagID.Id4136] =
{
	Id = 4136,
	TAG = "甜蜜-5",
}
TagConfig[TagID.Id4137] =
{
	Id = 4137,
	TAG = "香浓-1",
}
TagConfig[TagID.Id4138] =
{
	Id = 4138,
	TAG = "香浓-2",
}
TagConfig[TagID.Id4139] =
{
	Id = 4139,
	TAG = "香浓-3",
}
TagConfig[TagID.Id4140] =
{
	Id = 4140,
	TAG = "香浓-4",
}
TagConfig[TagID.Id4141] =
{
	Id = 4141,
	TAG = "香浓-5",
}
TagConfig[TagID.Id4142] =
{
	Id = 4142,
	TAG = "植物-1",
}
TagConfig[TagID.Id4143] =
{
	Id = 4143,
	TAG = "植物-2",
}
TagConfig[TagID.Id4144] =
{
	Id = 4144,
	TAG = "植物-3",
}
TagConfig[TagID.Id4145] =
{
	Id = 4145,
	TAG = "植物-4",
}
TagConfig[TagID.Id4146] =
{
	Id = 4146,
	TAG = "植物-5",
}
TagConfig[TagID.Id4147] =
{
	Id = 4147,
	TAG = "泥土-1",
}
TagConfig[TagID.Id4148] =
{
	Id = 4148,
	TAG = "泥土-2",
}
TagConfig[TagID.Id4149] =
{
	Id = 4149,
	TAG = "泥土-3",
}
TagConfig[TagID.Id4150] =
{
	Id = 4150,
	TAG = "泥土-4",
}
TagConfig[TagID.Id4151] =
{
	Id = 4151,
	TAG = "泥土-5",
}
TagConfig[TagID.Id4152] =
{
	Id = 4152,
	TAG = "动物气味-1",
}
TagConfig[TagID.Id4153] =
{
	Id = 4153,
	TAG = "动物气味-2",
}
TagConfig[TagID.Id4154] =
{
	Id = 4154,
	TAG = "动物气味-3",
}
TagConfig[TagID.Id4155] =
{
	Id = 4155,
	TAG = "动物气味-4",
}
TagConfig[TagID.Id4156] =
{
	Id = 4156,
	TAG = "动物气味-5",
}
TagConfig[TagID.Id4157] =
{
	Id = 4157,
	TAG = "工坊气味-1",
}
TagConfig[TagID.Id4158] =
{
	Id = 4158,
	TAG = "工坊气味-2",
}
TagConfig[TagID.Id4159] =
{
	Id = 4159,
	TAG = "工坊气味-3",
}
TagConfig[TagID.Id4160] =
{
	Id = 4160,
	TAG = "工坊气味-4",
}
TagConfig[TagID.Id4161] =
{
	Id = 4161,
	TAG = "工坊气味-5",
}
TagConfig[TagID.Id4162] =
{
	Id = 4162,
	TAG = "辣味-1",
}
TagConfig[TagID.Id4163] =
{
	Id = 4163,
	TAG = "辣味-2",
}
TagConfig[TagID.Id4164] =
{
	Id = 4164,
	TAG = "辣味-3",
}
TagConfig[TagID.Id4165] =
{
	Id = 4165,
	TAG = "辣味-4",
}
TagConfig[TagID.Id4166] =
{
	Id = 4166,
	TAG = "辣味-5",
}
TagConfig[TagID.Id4167] =
{
	Id = 4167,
	TAG = "麻痹-1",
}
TagConfig[TagID.Id4168] =
{
	Id = 4168,
	TAG = "麻痹-2",
}
TagConfig[TagID.Id4169] =
{
	Id = 4169,
	TAG = "麻痹-3",
}
TagConfig[TagID.Id4170] =
{
	Id = 4170,
	TAG = "麻痹-4",
}
TagConfig[TagID.Id4171] =
{
	Id = 4171,
	TAG = "麻痹-5",
}
TagConfig[TagID.Id4201] =
{
	Id = 4201,
	TAG = "——热量——",
}
TagConfig[TagID.Id4202] =
{
	Id = 4202,
	TAG = "热量-1",
}
TagConfig[TagID.Id4203] =
{
	Id = 4203,
	TAG = "热量-2",
}
TagConfig[TagID.Id4204] =
{
	Id = 4204,
	TAG = "热量-3",
}
TagConfig[TagID.Id4205] =
{
	Id = 4205,
	TAG = "热量-4",
}
TagConfig[TagID.Id4206] =
{
	Id = 4206,
	TAG = "热量-5",
}
TagConfig[TagID.Id4301] =
{
	Id = 4301,
	TAG = "——道具分类——",
}
TagConfig[TagID.Id4302] =
{
	Id = 4302,
	TAG = "唯一的",
}
TagConfig[TagID.Id4303] =
{
	Id = 4303,
	TAG = "电池类的",
}
TagConfig[TagID.Id4304] =
{
	Id = 4304,
	TAG = "零件类的",
}
TagConfig[TagID.Id4305] =
{
	Id = 4305,
	TAG = "素材类的",
}
TagConfig[TagID.Id4306] =
{
	Id = 4306,
	TAG = "食物类的",
}
TagConfig[TagID.Id4307] =
{
	Id = 4307,
	TAG = "捕捉道具类的",
}
TagConfig[TagID.Id4308] =
{
	Id = 4308,
	TAG = "事件道具类的",
}
TagConfig[TagID.Id4309] =
{
	Id = 4309,
	TAG = "皮肤券类的",
}
TagConfig[TagID.Id4310] =
{
	Id = 4310,
	TAG = "货币类的",
}
TagConfig[TagID.Id4321] =
{
	Id = 4321,
	TAG = "——零件分类——",
}
TagConfig[TagID.Id4322] =
{
	Id = 4322,
	TAG = "武器点的",
}
TagConfig[TagID.Id4323] =
{
	Id = 4323,
	TAG = "防具点的",
}
TagConfig[TagID.Id4351] =
{
	Id = 4351,
	TAG = "——零件等级——",
}
TagConfig[TagID.Id4352] =
{
	Id = 4352,
	TAG = "D级零件的",
}
TagConfig[TagID.Id4353] =
{
	Id = 4353,
	TAG = "C级零件的",
}
TagConfig[TagID.Id4354] =
{
	Id = 4354,
	TAG = "B级零件的",
}
TagConfig[TagID.Id4355] =
{
	Id = 4355,
	TAG = "A级零件的",
}
TagConfig[TagID.Id4356] =
{
	Id = 4356,
	TAG = "S级零件的",
}
TagConfig[TagID.Id4361] =
{
	Id = 4361,
	TAG = "——零件等级大于——",
}
TagConfig[TagID.Id4362] =
{
	Id = 4362,
	TAG = "D级以上零件的",
}
TagConfig[TagID.Id4363] =
{
	Id = 4363,
	TAG = "C级以上零件的",
}
TagConfig[TagID.Id4364] =
{
	Id = 4364,
	TAG = "B级以上零件的",
}
TagConfig[TagID.Id4365] =
{
	Id = 4365,
	TAG = "A级以上零件的",
}
TagConfig[TagID.Id4366] =
{
	Id = 4366,
	TAG = "S级以上零件的",
}
TagConfig[TagID.Id4371] =
{
	Id = 4371,
	TAG = "——零件等级小于——",
}
TagConfig[TagID.Id4372] =
{
	Id = 4372,
	TAG = "D级以下零件的",
}
TagConfig[TagID.Id4373] =
{
	Id = 4373,
	TAG = "C级以下零件的",
}
TagConfig[TagID.Id4374] =
{
	Id = 4374,
	TAG = "B级以下零件的",
}
TagConfig[TagID.Id4375] =
{
	Id = 4375,
	TAG = "A级以下零件的",
}
TagConfig[TagID.Id4376] =
{
	Id = 4376,
	TAG = "S级以下零件的",
}
TagConfig[TagID.Id4381] =
{
	Id = 4381,
	TAG = "——电池等级——",
}
TagConfig[TagID.Id4382] =
{
	Id = 4382,
	TAG = "升阶石1的",
}
TagConfig[TagID.Id4383] =
{
	Id = 4383,
	TAG = "升阶石2的",
}
TagConfig[TagID.Id4384] =
{
	Id = 4384,
	TAG = "升阶石3的",
}
TagConfig[TagID.Id4391] =
{
	Id = 4391,
	TAG = "——电池等级大于——",
}
TagConfig[TagID.Id4392] =
{
	Id = 4392,
	TAG = "升阶石1以上的",
}
TagConfig[TagID.Id4393] =
{
	Id = 4393,
	TAG = "升阶石2以上的",
}
TagConfig[TagID.Id4394] =
{
	Id = 4394,
	TAG = "升阶石3以上的",
}
TagConfig[TagID.Id4401] =
{
	Id = 4401,
	TAG = "——电池等级小于——",
}
TagConfig[TagID.Id4402] =
{
	Id = 4402,
	TAG = "升阶石1以下的",
}
TagConfig[TagID.Id4403] =
{
	Id = 4403,
	TAG = "升阶石2以下的",
}
TagConfig[TagID.Id4404] =
{
	Id = 4404,
	TAG = "升阶石3以下的",
}
TagConfig[TagID.Id4411] =
{
	Id = 4411,
	TAG = "——食物等级——",
}
TagConfig[TagID.Id4412] =
{
	Id = 4412,
	TAG = "食物1的",
}
TagConfig[TagID.Id4413] =
{
	Id = 4413,
	TAG = "食物2的",
}
TagConfig[TagID.Id4414] =
{
	Id = 4414,
	TAG = "食物3的",
}
TagConfig[TagID.Id4421] =
{
	Id = 4421,
	TAG = "——食物等级大于——",
}
TagConfig[TagID.Id4422] =
{
	Id = 4422,
	TAG = "食物1以上的",
}
TagConfig[TagID.Id4423] =
{
	Id = 4423,
	TAG = "食物2以上的",
}
TagConfig[TagID.Id4424] =
{
	Id = 4424,
	TAG = "食物3以上的",
}
TagConfig[TagID.Id4431] =
{
	Id = 4431,
	TAG = "——食物等级小于——",
}
TagConfig[TagID.Id4432] =
{
	Id = 4432,
	TAG = "食物1以下的",
}
TagConfig[TagID.Id4433] =
{
	Id = 4433,
	TAG = "食物2以下的",
}
TagConfig[TagID.Id4434] =
{
	Id = 4434,
	TAG = "食物3以下的",
}
TagConfig[TagID.Id4441] =
{
	Id = 4441,
	TAG = "——捕捉道具等级——",
}
TagConfig[TagID.Id4442] =
{
	Id = 4442,
	TAG = "捕捉道具1的",
}
TagConfig[TagID.Id4443] =
{
	Id = 4443,
	TAG = "捕捉道具2的",
}
TagConfig[TagID.Id4444] =
{
	Id = 4444,
	TAG = "捕捉道具3的",
}
TagConfig[TagID.Id4451] =
{
	Id = 4451,
	TAG = "——捕捉道具等级大于——",
}
TagConfig[TagID.Id4452] =
{
	Id = 4452,
	TAG = "捕捉道具1以上的",
}
TagConfig[TagID.Id4453] =
{
	Id = 4453,
	TAG = "捕捉道具2以上的",
}
TagConfig[TagID.Id4454] =
{
	Id = 4454,
	TAG = "捕捉道具3以上的",
}
TagConfig[TagID.Id4461] =
{
	Id = 4461,
	TAG = "——捕捉道具等级小于——",
}
TagConfig[TagID.Id4462] =
{
	Id = 4462,
	TAG = "捕捉道具1以下的",
}
TagConfig[TagID.Id4463] =
{
	Id = 4463,
	TAG = "捕捉道具2以下的",
}
TagConfig[TagID.Id4464] =
{
	Id = 4464,
	TAG = "捕捉道具3以下的",
}
TagConfig[TagID.Id4501] =
{
	Id = 4501,
	TAG = "——特殊道具分类——",
}
TagConfig[TagID.Id4502] =
{
	Id = 4502,
	TAG = "应援类的",
}
TagConfig[TagID.Id4551] =
{
	Id = 4551,
	TAG = "——敌人特性——",
}
TagConfig[TagID.Id4552] =
{
	Id = 4552,
	TAG = "地区探索的",
}
TagConfig[TagID.Id4553] =
{
	Id = 4553,
	TAG = "活动探索的",
}
TagConfig[TagID.Id4554] =
{
	Id = 4554,
	TAG = "通缉的",
}
TagConfig[TagID.Id4555] =
{
	Id = 4555,
	TAG = "头目的",
}
TagConfig[TagID.Id4556] =
{
	Id = 4556,
	TAG = "非头目的",
}
TagConfig[TagID.Id4557] =
{
	Id = 4557,
	TAG = "会闪避的",
}
TagConfig[TagID.Id4558] =
{
	Id = 4558,
	TAG = "会连击的",
}
TagConfig[TagID.Id4559] =
{
	Id = 4559,
	TAG = "会必中的",
}
TagConfig[TagID.Id4560] =
{
	Id = 4560,
	TAG = "会恢复的",
}
TagConfig[TagID.Id4561] =
{
	Id = 4561,
	TAG = "会强化的",
}
TagConfig[TagID.Id4562] =
{
	Id = 4562,
	TAG = "会舍命的",
}
TagConfig[TagID.Id4563] =
{
	Id = 4563,
	TAG = "会破甲的",
}
TagConfig[TagID.Id4564] =
{
	Id = 4564,
	TAG = "会削弱的",
}
TagConfig[TagID.Id5001] =
{
	Id = 5001,
	TAG = "——星际航行道具分类——",
}
TagConfig[TagID.Id5002] =
{
	Id = 5002,
	TAG = "星际货币类的",
}
TagConfig[TagID.Id5003] =
{
	Id = 5003,
	TAG = "星际补给类的",
}
TagConfig[TagID.Id5004] =
{
	Id = 5004,
	TAG = "星际强化类的",
}
TagConfig[TagID.Id5005] =
{
	Id = 5005,
	TAG = "星际骰子类的",
}
TagConfig[TagID.Id5006] =
{
	Id = 5006,
	TAG = "星际素材类的",
}
TagConfig[TagID.Id5007] =
{
	Id = 5007,
	TAG = "星际艺术品类的",
}
TagConfig[TagID.Id5008] =
{
	Id = 5008,
	TAG = "星际宝石类的",
}
TagConfig[TagID.Id5009] =
{
	Id = 5009,
	TAG = "非星际货币类的",
}
TagConfig[TagID.Id5010] =
{
	Id = 5010,
	TAG = "非星际补给类的",
}
TagConfig[TagID.Id5011] =
{
	Id = 5011,
	TAG = "非星际强化类的",
}
TagConfig[TagID.Id5012] =
{
	Id = 5012,
	TAG = "非星际骰子类的",
}
TagConfig[TagID.Id5013] =
{
	Id = 5013,
	TAG = "非星际素材类的",
}
TagConfig[TagID.Id5014] =
{
	Id = 5014,
	TAG = "非星际艺术品类的",
}
TagConfig[TagID.Id5015] =
{
	Id = 5015,
	TAG = "非星际宝石类的",
}
TagConfig[TagID.Id5101] =
{
	Id = 5101,
	TAG = "——星际航行道具级别——",
}
TagConfig[TagID.Id5102] =
{
	Id = 5102,
	TAG = "星际级别1类的",
}
TagConfig[TagID.Id5103] =
{
	Id = 5103,
	TAG = "星际级别2类的",
}
TagConfig[TagID.Id5104] =
{
	Id = 5104,
	TAG = "星际级别3类的",
}
TagConfig[TagID.Id5105] =
{
	Id = 5105,
	TAG = "星际级别4类的",
}
TagConfig[TagID.Id5106] =
{
	Id = 5106,
	TAG = "星际级别5类的",
}
TagConfig[TagID.Id5107] =
{
	Id = 5107,
	TAG = "星际级别6类的",
}
TagConfig[TagID.Id5201] =
{
	Id = 5201,
	TAG = "——星际航行道具子分类——",
}
TagConfig[TagID.Id5202] =
{
	Id = 5202,
	TAG = "星际燃料补给类的",
}
TagConfig[TagID.Id5203] =
{
	Id = 5203,
	TAG = "星际食物补给类的",
}
TagConfig[TagID.Id5204] =
{
	Id = 5204,
	TAG = "星际燃料上限类的",
}
TagConfig[TagID.Id5205] =
{
	Id = 5205,
	TAG = "星际食物上限类的",
}
TagConfig[TagID.Id5206] =
{
	Id = 5206,
	TAG = "星际遥控骰子类的",
}
TagConfig[TagID.Id5207] =
{
	Id = 5207,
	TAG = "星际矿石类的",
}
TagConfig[TagID.Id5208] =
{
	Id = 5208,
	TAG = "星际植物类的",
}
TagConfig[TagID.Id5209] =
{
	Id = 5209,
	TAG = "星际昆虫类的",
}
TagConfig[TagID.Id5210] =
{
	Id = 5210,
	TAG = "星际工业类的",
}
TagConfig[TagID.Id5211] =
{
	Id = 5211,
	TAG = "星际雕塑类的",
}
TagConfig[TagID.Id5212] =
{
	Id = 5212,
	TAG = "星际真品类的",
}
TagConfig[TagID.Id5213] =
{
	Id = 5213,
	TAG = "星际赝品类的",
}
TagConfig[TagID.Id5214] =
{
	Id = 5214,
	TAG = "星际名画类的",
}
TagConfig[TagID.Id5301] =
{
	Id = 5301,
	TAG = "——星际航行发现分类——",
}
TagConfig[TagID.Id5302] =
{
	Id = 5302,
	TAG = "星际挖掘-1的",
}
TagConfig[TagID.Id5303] =
{
	Id = 5303,
	TAG = "星际挖掘-2的",
}
TagConfig[TagID.Id5304] =
{
	Id = 5304,
	TAG = "星际挖掘-3的",
}
TagConfig[TagID.Id5305] =
{
	Id = 5305,
	TAG = "星际氧气-1的",
}
TagConfig[TagID.Id5306] =
{
	Id = 5306,
	TAG = "星际氧气-2的",
}
TagConfig[TagID.Id5307] =
{
	Id = 5307,
	TAG = "星际氧气-3的",
}
TagConfig[TagID.Id5308] =
{
	Id = 5308,
	TAG = "星际照明-1的",
}
TagConfig[TagID.Id5309] =
{
	Id = 5309,
	TAG = "星际照明-2的",
}
TagConfig[TagID.Id5310] =
{
	Id = 5310,
	TAG = "星际照明-3的",
}
TagConfig[TagID.Id5311] =
{
	Id = 5311,
	TAG = "星际传送-1的",
}
TagConfig[TagID.Id5312] =
{
	Id = 5312,
	TAG = "星际传送-2的",
}
TagConfig[TagID.Id5313] =
{
	Id = 5313,
	TAG = "星际传送-3的",
}
TagConfig[TagID.Id5314] =
{
	Id = 5314,
	TAG = "星际封印-1的",
}
TagConfig[TagID.Id5315] =
{
	Id = 5315,
	TAG = "星际封印-2的",
}
TagConfig[TagID.Id5316] =
{
	Id = 5316,
	TAG = "星际封印-3的",
}
TagConfig[TagID.Id5401] =
{
	Id = 5401,
	TAG = "——星际航行_选项主类型——",
}
TagConfig[TagID.Id5402] =
{
	Id = 5402,
	TAG = "命令的",
}
TagConfig[TagID.Id5403] =
{
	Id = 5403,
	TAG = "挑战的",
}
TagConfig[TagID.Id5404] =
{
	Id = 5404,
	TAG = "谈判的",
}
TagConfig[TagID.Id5405] =
{
	Id = 5405,
	TAG = "交易的",
}
TagConfig[TagID.Id5406] =
{
	Id = 5406,
	TAG = "登陆发现的",
}
TagConfig[TagID.Id5407] =
{
	Id = 5407,
	TAG = "任务的",
}
TagConfig[TagID.Id5501] =
{
	Id = 5501,
	TAG = "——星际航行_选项次类型——",
}
TagConfig[TagID.Id5502] =
{
	Id = 5502,
	TAG = "整理船舱的",
}
TagConfig[TagID.Id5503] =
{
	Id = 5503,
	TAG = "继续航行的",
}
TagConfig[TagID.Id5504] =
{
	Id = 5504,
	TAG = "协助观光团的",
}
TagConfig[TagID.Id5505] =
{
	Id = 5505,
	TAG = "抢劫观光团的",
}
TagConfig[TagID.Id5506] =
{
	Id = 5506,
	TAG = "兑换食物的",
}
TagConfig[TagID.Id5507] =
{
	Id = 5507,
	TAG = "兑换燃料的",
}
TagConfig[TagID.Id5508] =
{
	Id = 5508,
	TAG = "购买定点装置的",
}
TagConfig[TagID.Id5509] =
{
	Id = 5509,
	TAG = "借出圆锯的",
}
TagConfig[TagID.Id5510] =
{
	Id = 5510,
	TAG = "提供氧气瓶的",
}
TagConfig[TagID.Id5511] =
{
	Id = 5511,
	TAG = "强行通过的",
}
TagConfig[TagID.Id5512] =
{
	Id = 5512,
	TAG = "静静等待的",
}
TagConfig[TagID.Id5513] =
{
	Id = 5513,
	TAG = "帮海盗助威的",
}
TagConfig[TagID.Id5514] =
{
	Id = 5514,
	TAG = "殴打海盗的",
}
TagConfig[TagID.Id5515] =
{
	Id = 5515,
	TAG = "提供燃料的",
}
TagConfig[TagID.Id5516] =
{
	Id = 5516,
	TAG = "厉声呵斥！的",
}
TagConfig[TagID.Id5517] =
{
	Id = 5517,
	TAG = "趁机打劫的",
}
TagConfig[TagID.Id5518] =
{
	Id = 5518,
	TAG = "协助勇者的",
}
TagConfig[TagID.Id5519] =
{
	Id = 5519,
	TAG = "婉言谢绝的",
}
TagConfig[TagID.Id5520] =
{
	Id = 5520,
	TAG = "燃料支援的",
}
TagConfig[TagID.Id5521] =
{
	Id = 5521,
	TAG = "提供食物的",
}
TagConfig[TagID.Id5522] =
{
	Id = 5522,
	TAG = "厉声呵斥的",
}
TagConfig[TagID.Id5523] =
{
	Id = 5523,
	TAG = "追尾不对！的",
}
TagConfig[TagID.Id5524] =
{
	Id = 5524,
	TAG = "急刹不对！的",
}
TagConfig[TagID.Id5525] =
{
	Id = 5525,
	TAG = "殴打骨头兵的",
}
TagConfig[TagID.Id5526] =
{
	Id = 5526,
	TAG = "殴打勇者的",
}
TagConfig[TagID.Id5527] =
{
	Id = 5527,
	TAG = "绕过去的",
}
TagConfig[TagID.Id5528] =
{
	Id = 5528,
	TAG = "副本非常有趣，游玩体验极佳！的",
}
TagConfig[TagID.Id5529] =
{
	Id = 5529,
	TAG = "精致的服务体验，让人欲罢不能！的",
}
TagConfig[TagID.Id5530] =
{
	Id = 5530,
	TAG = "因为太受欢迎，所以项目排队时间太长。的",
}
TagConfig[TagID.Id5531] =
{
	Id = 5531,
	TAG = "光元素！的",
}
TagConfig[TagID.Id5532] =
{
	Id = 5532,
	TAG = "神秘又惹人遐想的暗元素！的",
}
TagConfig[TagID.Id5533] =
{
	Id = 5533,
	TAG = "太合适了，完全就是用户需求！的",
}
TagConfig[TagID.Id5534] =
{
	Id = 5534,
	TAG = "价格不贵的话，我可以接受。的",
}
TagConfig[TagID.Id5535] =
{
	Id = 5535,
	TAG = "魔王集团在骗钱。的",
}
TagConfig[TagID.Id5536] =
{
	Id = 5536,
	TAG = "魔王集团作弊了！的",
}
TagConfig[TagID.Id5537] =
{
	Id = 5537,
	TAG = "居民们上贡的财物还不够多。的",
}
TagConfig[TagID.Id5538] =
{
	Id = 5538,
	TAG = "勇者的打法有问题。的",
}
TagConfig[TagID.Id5539] =
{
	Id = 5539,
	TAG = "是伟大的冒险者们！的",
}
TagConfig[TagID.Id5540] =
{
	Id = 5540,
	TAG = "不知道是谁…的",
}
TagConfig[TagID.Id5541] =
{
	Id = 5541,
	TAG = "魔王集团在骗钱！的",
}
TagConfig[TagID.Id5542] =
{
	Id = 5542,
	TAG = "虽然不清楚情况，不过我反对！的",
}
TagConfig[TagID.Id5543] =
{
	Id = 5543,
	TAG = "还是有点道理的。的",
}
TagConfig[TagID.Id5544] =
{
	Id = 5544,
	TAG = "着陆并探索的",
}
TagConfig[TagID.Id5545] =
{
	Id = 5545,
	TAG = "正面突破的",
}
TagConfig[TagID.Id5546] =
{
	Id = 5546,
	TAG = "交5个发条的",
}
TagConfig[TagID.Id5547] =
{
	Id = 5547,
	TAG = "补充燃料的",
}
TagConfig[TagID.Id5548] =
{
	Id = 5548,
	TAG = "出售燃料的",
}
TagConfig[TagID.Id5549] =
{
	Id = 5549,
	TAG = "离开的",
}
TagConfig[TagID.Id5550] =
{
	Id = 5550,
	TAG = "大吃一顿的",
}
TagConfig[TagID.Id5551] =
{
	Id = 5551,
	TAG = "帮忙洗盘子的",
}
TagConfig[TagID.Id5552] =
{
	Id = 5552,
	TAG = "进行交易的",
}
TagConfig[TagID.Id5553] =
{
	Id = 5553,
	TAG = "兑换超能物体的",
}
TagConfig[TagID.Id5554] =
{
	Id = 5554,
	TAG = "与重大霸格进行战斗的",
}
TagConfig[TagID.Id5555] =
{
	Id = 5555,
	TAG = "尝试谈判的",
}
TagConfig[TagID.Id5556] =
{
	Id = 5556,
	TAG = "贿赂重大霸格的",
}
TagConfig[TagID.Id5557] =
{
	Id = 5557,
	TAG = "进行决斗的",
}
TagConfig[TagID.Id5558] =
{
	Id = 5558,
	TAG = "赠送礼物的",
}
TagConfig[TagID.Id5559] =
{
	Id = 5559,
	TAG = "偷袭对方的",
}
TagConfig[TagID.Id5560] =
{
	Id = 5560,
	TAG = "索要补给的",
}
TagConfig[TagID.Id5561] =
{
	Id = 5561,
	TAG = "骗取补给的",
}
TagConfig[TagID.Id5562] =
{
	Id = 5562,
	TAG = "进行初级挑战的",
}
TagConfig[TagID.Id5563] =
{
	Id = 5563,
	TAG = "燃料补给的",
}
TagConfig[TagID.Id5564] =
{
	Id = 5564,
	TAG = "食物补给的",
}
TagConfig[TagID.Id5565] =
{
	Id = 5565,
	TAG = "中级挑战的",
}
TagConfig[TagID.Id5566] =
{
	Id = 5566,
	TAG = "扩建燃料舱的",
}
TagConfig[TagID.Id5567] =
{
	Id = 5567,
	TAG = "扩建食物舱的",
}
TagConfig[TagID.Id5568] =
{
	Id = 5568,
	TAG = "高级挑战的",
}
TagConfig[TagID.Id5569] =
{
	Id = 5569,
	TAG = "进行交易（高级）的",
}
TagConfig[TagID.Id5570] =
{
	Id = 5570,
	TAG = "最高级挑战(不降低声望)的",
}
TagConfig[TagID.Id5571] =
{
	Id = 5571,
	TAG = "购买超能物体信息的",
}
TagConfig[TagID.Id5572] =
{
	Id = 5572,
	TAG = "杀出重围的",
}
TagConfig[TagID.Id5573] =
{
	Id = 5573,
	TAG = "挑衅对方的",
}
TagConfig[TagID.Id5574] =
{
	Id = 5574,
	TAG = "任务测试的",
}
TagConfig[TagID.Id5575] =
{
	Id = 5575,
	TAG = "魔王集团的",
}
TagConfig[TagID.Id5576] =
{
	Id = 5576,
	TAG = "仅交易的",
}
TagConfig[TagID.Id5577] =
{
	Id = 5577,
	TAG = "竞答的",
}
TagConfig[TagID.Id5578] =
{
	Id = 5578,
	TAG = "正确的",
}
TagConfig[TagID.Id5579] =
{
	Id = 5579,
	TAG = "海盗的",
}
TagConfig[TagID.Id5580] =
{
	Id = 5580,
	TAG = "登陆探索的",
}
TagConfig[TagID.Id5581] =
{
	Id = 5581,
	TAG = "谈判或战斗的",
}
TagConfig[TagID.Id5582] =
{
	Id = 5582,
	TAG = "仅谈判的",
}
TagConfig[TagID.Id5583] =
{
	Id = 5583,
	TAG = "矿石的",
}
TagConfig[TagID.Id5584] =
{
	Id = 5584,
	TAG = "圆锯的",
}
TagConfig[TagID.Id5585] =
{
	Id = 5585,
	TAG = "燃料的",
}
TagConfig[TagID.Id5586] =
{
	Id = 5586,
	TAG = "星际发条的",
}
TagConfig[TagID.Id5587] =
{
	Id = 5587,
	TAG = "补给的",
}
TagConfig[TagID.Id5588] =
{
	Id = 5588,
	TAG = "艺术品的",
}
TagConfig[TagID.Id5589] =
{
	Id = 5589,
	TAG = "真品的",
}
TagConfig[TagID.Id5590] =
{
	Id = 5590,
	TAG = "冒险家协会的",
}
TagConfig[TagID.Id6000] =
{
	Id = 6000,
	TAG = "——客观TAG（种族）——【剧场】",
}
TagConfig[TagID.Id6001] =
{
	Id = 6001,
	TAG = "虫族",
}
TagConfig[TagID.Id6002] =
{
	Id = 6002,
	TAG = "地精族",
}
TagConfig[TagID.Id6003] =
{
	Id = 6003,
	TAG = "恶魔族",
}
TagConfig[TagID.Id6004] =
{
	Id = 6004,
	TAG = "精灵族",
}
TagConfig[TagID.Id6005] =
{
	Id = 6005,
	TAG = "龙族",
}
TagConfig[TagID.Id6006] =
{
	Id = 6006,
	TAG = "人族",
}
TagConfig[TagID.Id6007] =
{
	Id = 6007,
	TAG = "亡灵族",
}
TagConfig[TagID.Id6050] =
{
	Id = 6050,
	TAG = "——客观TAG（头戴物）——【剧场】",
}
TagConfig[TagID.Id6051] =
{
	Id = 6051,
	TAG = "头上有电子产品",
}
TagConfig[TagID.Id6052] =
{
	Id = 6052,
	TAG = "头上有发带",
}
TagConfig[TagID.Id6053] =
{
	Id = 6053,
	TAG = "头上有皇冠",
}
TagConfig[TagID.Id6054] =
{
	Id = 6054,
	TAG = "头上有角",
}
TagConfig[TagID.Id6055] =
{
	Id = 6055,
	TAG = "头上有盔甲",
}
TagConfig[TagID.Id6056] =
{
	Id = 6056,
	TAG = "头上有帽子",
}
TagConfig[TagID.Id6057] =
{
	Id = 6057,
	TAG = "头上有兽耳",
}
TagConfig[TagID.Id6100] =
{
	Id = 6100,
	TAG = "——客观TAG（发色）——【剧场】",
}
TagConfig[TagID.Id6101] =
{
	Id = 6101,
	TAG = "白色头发",
}
TagConfig[TagID.Id6102] =
{
	Id = 6102,
	TAG = "黑色头发",
}
TagConfig[TagID.Id6103] =
{
	Id = 6103,
	TAG = "红色头发",
}
TagConfig[TagID.Id6104] =
{
	Id = 6104,
	TAG = "黄色头发",
}
TagConfig[TagID.Id6105] =
{
	Id = 6105,
	TAG = "青色头发",
}
TagConfig[TagID.Id6106] =
{
	Id = 6106,
	TAG = "棕色头发",
}
TagConfig[TagID.Id6150] =
{
	Id = 6150,
	TAG = "——客观TAG（肤色）——【剧场】",
}
TagConfig[TagID.Id6151] =
{
	Id = 6151,
	TAG = "黄色皮肤",
}
TagConfig[TagID.Id6152] =
{
	Id = 6152,
	TAG = "白色皮肤",
}
TagConfig[TagID.Id6153] =
{
	Id = 6153,
	TAG = "青色皮肤",
}
TagConfig[TagID.Id6154] =
{
	Id = 6154,
	TAG = "棕色皮肤",
}
TagConfig[TagID.Id6200] =
{
	Id = 6200,
	TAG = "——客观TAG（装扮）——【剧场】",
}
TagConfig[TagID.Id6201] =
{
	Id = 6201,
	TAG = "身穿布制衣装",
}
TagConfig[TagID.Id6202] =
{
	Id = 6202,
	TAG = "身穿盔甲",
}
TagConfig[TagID.Id6203] =
{
	Id = 6203,
	TAG = "身穿皮制衣装",
}
TagConfig[TagID.Id6250] =
{
	Id = 6250,
	TAG = "——客观TAG（特征）——【剧场】",
}
TagConfig[TagID.Id6251] =
{
	Id = 6251,
	TAG = "技巧的",
}
TagConfig[TagID.Id6252] =
{
	Id = 6252,
	TAG = "亲和的",
}
TagConfig[TagID.Id6253] =
{
	Id = 6253,
	TAG = "力气的",
}
TagConfig[TagID.Id6254] =
{
	Id = 6254,
	TAG = "智力的",
}
TagConfig[TagID.Id6300] =
{
	Id = 6300,
	TAG = "——主观TAG（人物）——【剧场】",
}
TagConfig[TagID.Id6301] =
{
	Id = 6301,
	TAG = "不起眼",
}
TagConfig[TagID.Id6302] =
{
	Id = 6302,
	TAG = "丑陋",
}
TagConfig[TagID.Id6303] =
{
	Id = 6303,
	TAG = "冒险家",
}
TagConfig[TagID.Id6304] =
{
	Id = 6304,
	TAG = "平民",
}
TagConfig[TagID.Id6305] =
{
	Id = 6305,
	TAG = "强力",
}
TagConfig[TagID.Id6306] =
{
	Id = 6306,
	TAG = "睿智",
}
TagConfig[TagID.Id6307] =
{
	Id = 6307,
	TAG = "邪恶",
}
TagConfig[TagID.Id6308] =
{
	Id = 6308,
	TAG = "颜值",
}
TagConfig[TagID.Id6309] =
{
	Id = 6309,
	TAG = "艺术家",
}
TagConfig[TagID.Id6310] =
{
	Id = 6310,
	TAG = "苍老",
}
TagConfig[TagID.Id6311] =
{
	Id = 6311,
	TAG = "善良",
}
TagConfig[TagID.Id6312] =
{
	Id = 6312,
	TAG = "贪婪",
}
TagConfig[TagID.Id6313] =
{
	Id = 6313,
	TAG = "贵族",
}
TagConfig[TagID.Id6400] =
{
	Id = 6400,
	TAG = "——主观TAG（道具）——【剧场】",
}
TagConfig[TagID.Id6401] =
{
	Id = 6401,
	TAG = "体积小",
}
TagConfig[TagID.Id6402] =
{
	Id = 6402,
	TAG = "坚硬",
}
TagConfig[TagID.Id6500] =
{
	Id = 6500,
	TAG = "——主观TAG（宠物）——【剧场】",
}
TagConfig[TagID.Id6501] =
{
	Id = 6501,
	TAG = "凶狠",
}
TagConfig[TagID.Id6502] =
{
	Id = 6502,
	TAG = "善战",
}
TagConfig[TagID.Id6600] =
{
	Id = 6600,
	TAG = "——布景-客观TAG（类型）——【剧场】",
}
TagConfig[TagID.Id6601] =
{
	Id = 6601,
	TAG = "草",
}
TagConfig[TagID.Id6602] =
{
	Id = 6602,
	TAG = "树",
}
TagConfig[TagID.Id6603] =
{
	Id = 6603,
	TAG = "地毯",
}
TagConfig[TagID.Id6604] =
{
	Id = 6604,
	TAG = "马",
}
TagConfig[TagID.Id6650] =
{
	Id = 6650,
	TAG = "——布景-客观TAG（形象）——【剧场】",
}
TagConfig[TagID.Id6651] =
{
	Id = 6651,
	TAG = "高的",
}
TagConfig[TagID.Id6652] =
{
	Id = 6652,
	TAG = "巨大的",
}
TagConfig[TagID.Id6653] =
{
	Id = 6653,
	TAG = "小的",
}
TagConfig[TagID.Id6654] =
{
	Id = 6654,
	TAG = "干净的",
}
TagConfig[TagID.Id6655] =
{
	Id = 6655,
	TAG = "脏乱的",
}
TagConfig[TagID.Id6700] =
{
	Id = 6700,
	TAG = "——布景-客观TAG（触感）——【剧场】",
}
TagConfig[TagID.Id6701] =
{
	Id = 6701,
	TAG = "扎手的",
}
TagConfig[TagID.Id6702] =
{
	Id = 6702,
	TAG = "粗糙的",
}
TagConfig[TagID.Id6703] =
{
	Id = 6703,
	TAG = "柔软的",
}
TagConfig[TagID.Id6750] =
{
	Id = 6750,
	TAG = "——布景-客观TAG（擅长）——【剧场】",
}
TagConfig[TagID.Id6751] =
{
	Id = 6751,
	TAG = "善于奔跑",
}
TagConfig[TagID.Id6752] =
{
	Id = 6752,
	TAG = "善于背负",
}

