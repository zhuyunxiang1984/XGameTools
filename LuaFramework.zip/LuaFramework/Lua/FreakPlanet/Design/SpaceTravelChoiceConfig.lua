SpaceTravelChoiceConfig ={};
SpaceTravelChoiceID = 
{
	Id001 = 830001,
	Id002 = 830002,
	Id003 = 830003,
	Id004 = 830004,
	Id005 = 830005,
	Id006 = 830006,
	Id007 = 830007,
	Id008 = 830008,
	Id009 = 830009,
	Id010 = 830010,
	Id011 = 830011,
	Id012 = 830012,
	Id013 = 830013,
	Id014 = 830014,
	Id015 = 830015,
	Id016 = 830016,
	Id017 = 830017,
	Id018 = 830018,
	Id019 = 830019,
	Id020 = 830020,
	Id021 = 830021,
	Id022 = 830022,
	Id023 = 830023,
	Id024 = 830024,
	Id025 = 830025,
	Id026 = 830026,
	Id027 = 830027,
	Id028 = 830028,
	Id029 = 830029,
	Id030 = 830030,
	Id031 = 830031,
	Id032 = 830032,
	Id033 = 830033,
	Id034 = 830034,
	Id035 = 830035,
	Id036 = 830036,
	Id037 = 830037,
	Id038 = 830038,
	Id039 = 830039,
	Id040 = 830040,
	Id041 = 830041,
	Id042 = 830042,
	Id043 = 830043,
	Id044 = 830044,
	Id045 = 830045,
	Id046 = 830046,
	Id047 = 830047,
	Id048 = 830048,
	Id049 = 830049,
	Id050 = 830050,
	Id051 = 830051,
	Id052 = 830052,
	Id053 = 830053,
	Id054 = 830054,
	Id055 = 830055,
	Id056 = 830056,
	Id057 = 830057,
	Id058 = 830058,
	Id059 = 830059,
	Id060 = 830060,
	Id061 = 830061,
	Id062 = 830062,
	Id063 = 830063,
	Id064 = 830064,
	Id065 = 830065,
	Id066 = 830066,
	Id067 = 830067,
	Id068 = 830068,
	Id069 = 830069,
	Id070 = 830070,
	Id071 = 830071,
	Id072 = 830072,
	Id073 = 830073,
	Id074 = 830074,
	Id075 = 830075,
	Id076 = 830076,
	Id077 = 830077,
	Id078 = 830078,
	Id079 = 830079,
	Id080 = 830080,
	Id081 = 830081,
	Id082 = 830082,
	Id083 = 830083,
	Id084 = 830084,
	Id085 = 830085,
	Id086 = 830086,
	Id087 = 830087,
	Id088 = 830088,
	Id089 = 830089,
	Id090 = 830090,
	Id091 = 830091,
	Id092 = 830092,
	Id093 = 830093,
	Id094 = 830094,
	Id095 = 830095,
	Id096 = 830096,
	Id097 = 830097,
	Id098 = 830098,
	Id099 = 830099,
	Id100 = 830100,
	Id101 = 830101,
	Id102 = 830102,
	Id103 = 830103,
	Id104 = 830104,
	Id105 = 830105,
	Id106 = 830106,
	Id107 = 830107,
	Id108 = 830108,
	Id109 = 830109,
	Id110 = 830110,
	Id111 = 830111,
	Id112 = 830112,
	Id113 = 830113,
	Id114 = 830114,
	Id115 = 830115,
	Id116 = 830116,
	Id117 = 830117,
	Id118 = 830118,
	Id119 = 830119,
	Id120 = 830120,
	Id121 = 830121,
	Id122 = 830122,
	Id123 = 830123,
	Id124 = 830124,
	Id125 = 830125,
	Id126 = 830126,
	Id127 = 830127,
	Id128 = 830128,
	Id129 = 830129,
	Id130 = 830130,
	Id131 = 830131,
	Id132 = 830132,
	Id133 = 830133,
	Id134 = 830134,
	Id135 = 830135,
	Id136 = 830136,
	Id137 = 830137,
	Id138 = 830138,
	Id139 = 830139,
	Id140 = 830140,
	Id141 = 830141,
	Id142 = 830142,
	Id143 = 830143,
	Id144 = 830144,
	Id145 = 830145,
	Id146 = 830146,
	Id147 = 830147,
	Id148 = 830148,
	Id149 = 830149,
	Id150 = 830150,
	Id151 = 830151,
	Id152 = 830152,
	Id153 = 830153,
	Id154 = 830154,
	Id155 = 830155,
	Id156 = 830156,
	Id157 = 830157,
	Id158 = 830158,
	Id159 = 830159,
	Id160 = 830160,
	Id161 = 830161,
	Id162 = 830162,
	Id163 = 830163,
	Id164 = 830164,
	Id165 = 830165,
	Id166 = 830166,
	Id167 = 830167,
	Id168 = 830168,
	Id169 = 830169,
	Id170 = 830170,
	Id171 = 830171,
	Id172 = 830172,
	Id173 = 830173,
	Id174 = 830174,
	Id175 = 830175,
	Id176 = 830176,
	Id177 = 830177,
	Id178 = 830178,
	Id179 = 830179,
	Id180 = 830180,
	Id181 = 830181,
	Id182 = 830182,
	Id183 = 830183,
	Id184 = 830184,
	Id185 = 830185,
	Id186 = 830186,
	Id187 = 830187,
	Id188 = 830188,
	Id189 = 830189,
	Id190 = 830190,
	Id191 = 830191,
	Id192 = 830192,
	Id193 = 830193,
	Id194 = 830194,
	Id195 = 830195,
	Id196 = 830196,
	Id197 = 830197,
	Id198 = 830198,
	Id199 = 830199,
	Id200 = 830200,
	Id201 = 830201,
	Id202 = 830202,
	Id203 = 830203,
	Id204 = 830204,
	Id205 = 830205,
	Id206 = 830206,
	Id207 = 830207,
	Id208 = 830208,
	Id209 = 830209,
	Id210 = 830210,
	Id211 = 830211,
	Id212 = 830212,
	Id213 = 830213,
	Id214 = 830214,
	Id215 = 830215,
	Id216 = 830216,
	Id217 = 830217,
	Id218 = 830218,
	Id219 = 830219,
	Id220 = 830220,
	Id221 = 830221,
	Id222 = 830222,
	Id223 = 830223,
	Id224 = 830224,
	Id225 = 830225,
	Id226 = 830226,
	Id227 = 830227,
	Id228 = 830228,
	Id229 = 830229,
	Id230 = 830230,
	Id231 = 830231,
	Id232 = 830232,
	Id233 = 830233,
	Id234 = 830234,
	Id235 = 830235,
	Id236 = 830236,
	Id237 = 830237,
	Id238 = 830238,
	Id239 = 830239,
	Id240 = 830240,
	Id241 = 830241,
	Id242 = 830242,
	Id243 = 830243,
	Id244 = 830244,
	Id245 = 830245,
	Id246 = 830246,
	Id247 = 830247,
	Id248 = 830248,
	Id249 = 830249,
	Id250 = 830250,
	Id251 = 830251,
	Id252 = 830252,
	Id253 = 830253,
	Id254 = 830254,
	Id255 = 830255,
	Id256 = 830256,
	Id257 = 830257,
	Id258 = 830258,
	Id259 = 830259,
	Id260 = 830260,
	Id261 = 830261,
	Id262 = 830262,
	Id263 = 830263,
	Id264 = 830264,
	Id265 = 830265,
	Id266 = 830266,
	Id267 = 830267,
	Id268 = 830268,
	Id269 = 830269,
	Id270 = 830270,
	Id271 = 830271,
	Id272 = 830272,
	Id273 = 830273,
	Id274 = 830274,
	Id275 = 830275,
	Id276 = 830276,
	Id277 = 830277,
	Id278 = 830278,
	Id279 = 830279,
	Id280 = 830280,
	Id281 = 830281,
	Id282 = 830282,
	Id283 = 830283,
	Id284 = 830284,
	Id285 = 830285,
	Id286 = 830286,
	Id287 = 830287,
	Id288 = 830288,
	Id289 = 830289,
	Id290 = 830290,
	Id291 = 830291,
	Id292 = 830292,
	Id293 = 830293,
	Id294 = 830294,
	Id295 = 830295,
	Id296 = 830296,
	Id297 = 830297,
	Id298 = 830298,
	Id299 = 830299,
	Id300 = 830300,
	Id301 = 830301,
	Id302 = 830302,
	Id303 = 830303,
	Id304 = 830304,
	Id305 = 830305,
	Id306 = 830306,
	Id307 = 830307,
	Id308 = 830308,
	Id309 = 830309,
	Id310 = 830310,
	Id311 = 830311,
	Id312 = 830312,
	Id313 = 830313,
	Id314 = 830314,
	Id315 = 830315,
	Id316 = 830316,
	Id317 = 830317,
	Id318 = 830318,
	Id319 = 830319,
	Id320 = 830320,
	Id321 = 830321,
	Id322 = 830322,
	Id323 = 830323,
	Id324 = 830324,
	Id325 = 830325,
	Id326 = 830326,
	Id327 = 830327,
	Id328 = 830328,
	Id329 = 830329,
	Id330 = 830330,
	Id331 = 830331,
	Id332 = 830332,
	Id333 = 830333,
	Id334 = 830334,
	Id335 = 830335,
	Id336 = 830336,
	Id337 = 830337,
	Id338 = 830338,
	Id339 = 830339,
	Id340 = 830340,
	Id341 = 830341,
	Id342 = 830342,
	Id343 = 830343,
	Id344 = 830344,
	Id345 = 830345,
	Id346 = 830346,
	Id347 = 830347,
	Id348 = 830348,
	Id349 = 830349,
	Id350 = 830350,
	Id351 = 830351,
	Id352 = 830352,
	Id353 = 830353,
	Id354 = 830354,
	Id355 = 830355,
	Id356 = 830356,
	Id357 = 830357,
	Id358 = 830358,
	Id359 = 830359,
	Id360 = 830360,
	Id361 = 830361,
	Id362 = 830362,
	Id363 = 830363,
	Id364 = 830364,
	Id365 = 830365,
	Id366 = 830366,
	Id367 = 830367,
	Id368 = 830368,
	Id369 = 830369,
	Id370 = 830370,
	Id371 = 830371,
	Id372 = 830372,
	Id373 = 830373,
	Id374 = 830374,
	Id375 = 830375,
	Id376 = 830376,
	Id377 = 830377,
	Id378 = 830378,
	Id379 = 830379,
	Id380 = 830380,
	Id381 = 830381,
	Id382 = 830382,
	Id383 = 830383,
	Id384 = 830384,
	Id385 = 830385,
	Id386 = 830386,
	Id387 = 830387,
	Id388 = 830388,
	Id389 = 830389,
	Id390 = 830390,
	Id391 = 830391,
	Id392 = 830392,
	Id393 = 830393,
	Id394 = 830394,
	Id395 = 830395,
	Id396 = 830396,
	Id397 = 830397,
	Id398 = 830398,
	Id399 = 830399,
	Id400 = 830400,
	Id401 = 830401,
	Id402 = 830402,
	Id403 = 830403,
	Id404 = 830404,
	Id405 = 830405,
	Id406 = 830406,
	Id407 = 830407,
	Id408 = 830408,
	Id409 = 830409,
	Id410 = 830410,
	Id411 = 830411,
	Id412 = 830412,
	Id413 = 830413,
	Id414 = 830414,
	Id415 = 830415,
	Id416 = 830416,
	Id417 = 830417,
	Id418 = 830418,
	Id419 = 830419,
	Id420 = 830420,
	Id421 = 830421,
	Id422 = 830422,
	Id423 = 830423,
	Id424 = 830424,
	Id425 = 830425,
	Id426 = 830426,
	Id427 = 830427,
	Id428 = 830428,
	Id429 = 830429,
	Id430 = 830430,
	Id431 = 830431,
	Id432 = 830432,
	Id433 = 830433,
	Id434 = 830434,
	Id435 = 830435,
	Id436 = 830436,
	Id437 = 830437,
	Id438 = 830438,
	Id439 = 830439,
	Id440 = 830440,
	Id441 = 830441,
	Id442 = 830442,
	Id443 = 830443,
	Id444 = 830444,
	Id445 = 830445,
	Id446 = 830446,
	Id447 = 830447,
	Id448 = 830448,
	Id449 = 830449,
	Id450 = 830450,
	Id451 = 830451,
	Id452 = 830452,
	Id453 = 830453,
	Id454 = 830454,
	Id455 = 830455,
	Id456 = 830456,
	Id457 = 830457,
	Id458 = 830458,
	Id459 = 830459,
	Id460 = 830460,
	Id461 = 830461,
	Id462 = 830462,
	Id463 = 830463,
	Id464 = 830464,
	Id465 = 830465,
	Id466 = 830466,
	Id467 = 830467,
	Id468 = 830468,
	Id469 = 830469,
	Id470 = 830470,
	Id471 = 830471,
	Id472 = 830472,
	Id473 = 830473,
	Id474 = 830474,
	Id475 = 830475,
	Id476 = 830476,
	Id477 = 830477,
	Id478 = 830478,
	Id479 = 830479,
	Id480 = 830480,
	Id481 = 830481,
	Id482 = 830482,
	Id483 = 830483,
	Id484 = 830484,
	Id485 = 830485,
	Id486 = 830486,
	Id487 = 830487,
	Id488 = 830488,
	Id489 = 830489,
	Id490 = 830490,
	Id491 = 830491,
	Id492 = 830492,
	Id493 = 830493,
	Id494 = 830494,
	Id495 = 830495,
	Id496 = 830496,
	Id497 = 830497,
	Id498 = 830498,
	Id499 = 830499,
	Id500 = 830500,
	Id501 = 830501,
	Id502 = 830502,
	Id503 = 830503,
	Id504 = 830504,
	Id505 = 830505,
	Id506 = 830506,
	Id507 = 830507,
	Id508 = 830508,
	Id509 = 830509,
	Id510 = 830510,
	Id511 = 830511,
	Id512 = 830512,
	Id513 = 830513,
	Id514 = 830514,
	Id515 = 830515,
	Id516 = 830516,
	Id517 = 830517,
	Id518 = 830518,
	Id519 = 830519,
	Id520 = 830520,
	Id521 = 830521,
	Id522 = 830522,
	Id523 = 830523,
	Id524 = 830524,
	Id525 = 830525,
	Id526 = 830526,
	Id527 = 830527,
	Id528 = 830528,
	Id529 = 830529,
	Id530 = 830530,
	Id531 = 830531,
	Id532 = 830532,
	Id533 = 830533,
	Id534 = 830534,
	Id535 = 830535,
	Id536 = 830536,
	Id537 = 830537,
	Id538 = 830538,
	Id539 = 830539,
	Id540 = 830540,
	Id541 = 830541,
	Id542 = 830542,
	Id543 = 830543,
	Id544 = 830544,
	Id545 = 830545,
	Id546 = 830546,
	Id547 = 830547,
	Id548 = 830548,
	Id549 = 830549,
	Id550 = 830550,
	Id551 = 830551,
	Id552 = 830552,
	Id553 = 830553,
	Id554 = 830554,
	Id555 = 830555,
	Id556 = 830556,
	Id557 = 830557,
	Id558 = 830558,
	Id559 = 830559,
	Id560 = 830560,
	Id561 = 830561,
	Id562 = 830562,
	Id563 = 830563,
	Id564 = 830564,
	Id565 = 830565,
	Id566 = 830566,
	Id567 = 830567,
	Id568 = 830568,
	Id569 = 830569,
	Id570 = 830570,
	Id571 = 830571,
	Id572 = 830572,
	Id573 = 830573,
	Id574 = 830574,
	Id575 = 830575,
	Id576 = 830576,
	Id577 = 830577,
	Id578 = 830578,
	Id579 = 830579,
	Id580 = 830580,
	Id581 = 830581,
	Id582 = 830582,
	Id583 = 830583,
	Id584 = 830584,
	Id585 = 830585,
	Id586 = 830586,
	Id587 = 830587,
	Id588 = 830588,
	Id589 = 830589,
	Id590 = 830590,
	Id591 = 830591,
	Id592 = 830592,
	Id593 = 830593,
	Id594 = 830594,
	Id595 = 830595,
	Id596 = 830596,
	Id597 = 830597,
	Id598 = 830598,
	Id599 = 830599,
	Id600 = 830600,
	Id601 = 830601,
	Id602 = 830602,
	Id603 = 830603,
	Id604 = 830604,
	Id605 = 830605,
	Id606 = 830606,
	Id607 = 830607,
	Id608 = 830608,
	Id609 = 830609,
	Id610 = 830610,
	Id611 = 830611,
	Id612 = 830612,
	Id613 = 830613,
	Id614 = 830614,
	Id615 = 830615,
	Id616 = 830616,
	Id617 = 830617,
	Id618 = 830618,
	Id619 = 830619,
	Id620 = 830620,
	Id621 = 830621,
	Id622 = 830622,
	Id623 = 830623,
	Id624 = 830624,
	Id625 = 830625,
	Id626 = 830626,
	Id627 = 830627,
	Id628 = 830628,
	Id629 = 830629,
	Id630 = 830630,
	Id631 = 830631,
	Id632 = 830632,
	Id633 = 830633,
	Id634 = 830634,
	Id635 = 830635,
	Id636 = 830636,
	Id637 = 830637,
	Id638 = 830638,
	Id639 = 830639,
	Id640 = 830640,
	Id641 = 830641,
	Id642 = 830642,
	Id643 = 830643,
	Id644 = 830644,
	Id645 = 830645,
	Id646 = 830646,
	Id647 = 830647,
	Id648 = 830648,
	Id649 = 830649,
	Id650 = 830650,
	Id651 = 830651,
	Id652 = 830652,
	Id653 = 830653,
	Id654 = 830654,
	Id655 = 830655,
	Id656 = 830656,
	Id657 = 830657,
	Id658 = 830658,
	Id659 = 830659,
	Id660 = 830660,
	Id661 = 830661,
	Id662 = 830662,
	Id663 = 830663,
	Id664 = 830664,
	Id665 = 830665,
	Id666 = 830666,
	Id667 = 830667,
	Id668 = 830668,
	Id669 = 830669,
	Id670 = 830670,
	Id671 = 830671,
	Id672 = 830672,
	Id673 = 830673,
	Id674 = 830674,
	Id675 = 830675,
	Id676 = 830676,
	Id677 = 830677,
	Id678 = 830678,
	Id679 = 830679,
	Id680 = 830680,
	Id681 = 830681,
	Id682 = 830682,
	Id683 = 830683,
	Id684 = 830684,
	Id685 = 830685,
	Id686 = 830686,
	Id687 = 830687,
	Id688 = 830688,
	Id689 = 830689,
	Id690 = 830690,
	Id691 = 830691,
	Id692 = 830692,
	Id693 = 830693,
	Id694 = 830694,
	Id695 = 830695,
	Id696 = 830696,
	Id697 = 830697,
	Id698 = 830698,
	Id699 = 830699,
	Id700 = 830700,
	Id701 = 830701,
	Id702 = 830702,
	Id703 = 830703,
	Id704 = 830704,
	Id705 = 830705,
	Id706 = 830706,
	Id707 = 830707,
	Id708 = 830708,
	Id709 = 830709,
	Id710 = 830710,
	Id711 = 830711,
	Id712 = 830712,
	Id713 = 830713,
	Id714 = 830714,
	Id715 = 830715,
	Id716 = 830716,
	Id717 = 830717,
	Id718 = 830718,
	Id719 = 830719,
	Id720 = 830720,
	Id721 = 830721,
	Id722 = 830722,
	Id723 = 830723,
	Id724 = 830724,
	Id725 = 830725,
	Id726 = 830726,
	Id727 = 830727,
	Id728 = 830728,
	Id729 = 830729,
	Id730 = 830730,
	Id731 = 830731,
	Id732 = 830732,
	Id733 = 830733,
	Id734 = 830734,
	Id735 = 830735,
	Id736 = 830736,
	Id737 = 830737,
	Id738 = 830738,
	Id739 = 830739,
	Id740 = 830740,
	Id741 = 830741,
	Id742 = 830742,
	Id743 = 830743,
	Id744 = 830744,
	Id745 = 830745,
	Id746 = 830746,
	Id747 = 830747,
	Id748 = 830748,
	Id749 = 830749,
	Id750 = 830750,
	Id751 = 830751,
	Id752 = 830752,
	Id753 = 830753,
	Id754 = 830754,
	Id755 = 830755,
	Id756 = 830756,
	Id757 = 830757,
	Id758 = 830758,
	Id759 = 830759,
	Id760 = 830760,
	Id761 = 830761,
	Id762 = 830762,
	Id763 = 830763,
	Id764 = 830764,
	Id765 = 830765,
	Id766 = 830766,
	Id767 = 830767,
	Id768 = 830768,
	Id769 = 830769,
	Id770 = 830770,
	Id771 = 830771,
	Id772 = 830772,
	Id773 = 830773,
	Id774 = 830774,
	Id775 = 830775,
	Id776 = 830776,
	Id777 = 830777,
	Id778 = 830778,
	Id779 = 830779,
	Id780 = 830780,
	Id781 = 830781,
	Id782 = 830782,
	Id783 = 830783,
	Id784 = 830784,
	Id785 = 830785,
	Id786 = 830786,
	Id787 = 830787,
	Id788 = 830788,
	Id789 = 830789,
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id001] =
{
	Id = 1,
	Name = "整理船舱",
	Type = "Command",
	GainList = {
		{
			Value = 770001,
			Num = 2,
		},
	},
	Tags = {
		567012,
		567002,
	},
	Dialog = {
		{
			Quest = "在角落里发现了发条！",
			Answer = "捡走",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id002] =
{
	Id = 2,
	Name = "整理船舱",
	Type = "Command",
	GainList = {
		{
			Value = 101,
			Num = 20,
		},
	},
	Tags = {
		567012,
		567002,
	},
	Dialog = {
		{
			Quest = "发现了仓库里散装的燃料！",
			Answer = "加入燃料舱",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id003] =
{
	Id = 3,
	Name = "整理船舱",
	Type = "Command",
	GainList = {
		{
			Value = 103,
			Num = 20,
		},
	},
	Tags = {
		567012,
		567002,
	},
	Dialog = {
		{
			Quest = "找到了过期的饼干！",
			Answer = "大吃一顿",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id004] =
{
	Id = 4,
	Name = "整理船舱",
	Type = "Challenge",
	ChallengeId = 148091,
	Win = {
		{
			Value = 101,
			Num = 40,
		},
		{
			Value = 770001,
			Num = 2,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -40,
		},
	},
	Tags = {
		567012,
		567003,
		567089,
	},
	Dialog = {
		{
			Quest = "发现外星生物入侵飞船！",
			Answer = "准备战斗！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id005] =
{
	Id = 5,
	Name = "整理船舱",
	Type = "Command",
	GainList = {
		{
			Value = 770001,
			Num = 2,
		},
	},
	Tags = {
		567012,
		567002,
	},
	Dialog = {
		{
			Quest = "在角落里发现了发条！",
			Answer = "捡走",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id006] =
{
	Id = 6,
	Name = "整理船舱",
	Type = "Command",
	GainList = {
		{
			Value = 101,
			Num = 20,
		},
	},
	Tags = {
		567012,
		567002,
	},
	Dialog = {
		{
			Quest = "在用过的燃料罐里发现了燃料！",
			Answer = "加入燃料舱",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id007] =
{
	Id = 7,
	Name = "整理船舱",
	Type = "Command",
	GainList = {
		{
			Value = 103,
			Num = 20,
		},
	},
	Tags = {
		567012,
		567002,
	},
	Dialog = {
		{
			Quest = "在冰箱里发现了没吃完的饼干！",
			Answer = "大吃一顿",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id008] =
{
	Id = 8,
	Name = "整理船舱",
	Type = "Challenge",
	ChallengeId = 148081,
	Win = {
		{
			Value = 101,
			Num = 40,
		},
		{
			Value = 770001,
			Num = 2,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -40,
		},
	},
	Tags = {
		567012,
		567003,
		567089,
	},
	Dialog = {
		{
			Quest = "有一个外星生物入侵了飞船！",
			Answer = "准备战斗！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id009] =
{
	Id = 9,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id010] =
{
	Id = 10,
	Name = "协助观光团",
	Type = "Challenge",
	GainList = {
		{
			Value = 770001,
			Num = 5,
		},
	},
	ChallengeId = 148071,
	Win = {
		{
			Value = 101,
			Num = 40,
		},
		{
			Value = 770001,
			Num = 2,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -40,
		},
	},
	Tags = {
		567014,
		567003,
		567089,
	},
	Dialog = {
		{
			Quest = "警告！海盗已强行登陆我方战舰。",
			Answer = "好好教训他们！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id011] =
{
	Id = 11,
	Name = "抢劫观光团",
	Type = "Command",
	CostList = {
		{
			Value = 780010,
			Num = 100,
		},
	},
	GainList = {
		{
			Value = 770001,
			Num = 5,
		},
	},
	Tags = {
		567015,
		567002,
	},
	Dialog = {
		{
			Quest = "对方已将我们的行为记录并上报至联邦总局。",
			Answer = "赶紧离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id012] =
{
	Id = 12,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
	Dialog = {
		{
			Quest = "海盗战舰已取消锁定我方飞艇。",
			Answer = "立刻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id013] =
{
	Id = 13,
	Name = "兑换食物（[45FF00]食物+150[-] [FF6500]燃料-300[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 101,
			Num = 300,
			Hint = "燃料不足300，无法交换",
		},
	},
	CostList = {
		{
			Value = 101,
			Num = 300,
		},
	},
	GainList = {
		{
			Value = 103,
			Num = 150,
		},
	},
	Tags = {
		567016,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id014] =
{
	Id = 14,
	Name = "兑换燃料（[45FF00]燃料+150[-] [FF6500]食物-300[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 103,
			Num = 300,
			Hint = "食物不足300，无法交换",
		},
	},
	CostList = {
		{
			Value = 103,
			Num = 300,
		},
	},
	GainList = {
		{
			Value = 101,
			Num = 150,
		},
	},
	Tags = {
		567017,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id015] =
{
	Id = 15,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
	Dialog = {
		{
			Quest = "你打算离开时，听到流民小声嘀咕，说你真不会做生意。",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id016] =
{
	Id = 16,
	Name = "购买定点装置（[FF6500]发条-5[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 5,
			Hint = "发条不足，无法交易",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 4,
		},
	},
	GainList = {
		{
			Value = 770201,
			Num = 1,
		},
	},
	Tags = {
		567018,
		567002,
	},
	Dialog = {
		{
			Quest = "啊，盒子有点破了，不过东西还是可以用的。",
			Answer = "不是说全新未拆吗？",
		},
		{
			Quest = "那就再便宜一点，只收你4个发条就好啦。",
			Answer = "完成交易",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id017] =
{
	Id = 17,
	Name = "购买定点装置（[FF6500]发条-5[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 5,
			Hint = "发条不足，无法交易",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 4,
		},
	},
	GainList = {
		{
			Value = 770202,
			Num = 1,
		},
	},
	Tags = {
		567018,
		567002,
	},
	Dialog = {
		{
			Quest = "啊，盒子有点破了，不过东西还是可以用的。",
			Answer = "封条呢？",
		},
		{
			Quest = "那就再便宜一点，只收你4个发条就好啦。",
			Answer = "完成交易",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id018] =
{
	Id = 18,
	Name = "购买定点装置（[FF6500]发条-5[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 5,
			Hint = "发条不足，无法交易",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 4,
		},
	},
	GainList = {
		{
			Value = 770203,
			Num = 1,
		},
	},
	Tags = {
		567018,
		567002,
	},
	Dialog = {
		{
			Quest = "啊，盒子有点破了，不过东西还是可以用的。",
			Answer = "没有发票吗？",
		},
		{
			Quest = "那就再便宜一点，只收你4个发条就好啦。",
			Answer = "完成交易",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id019] =
{
	Id = 19,
	Name = "购买定点装置（[FF6500]发条-5[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 5,
			Hint = "发条不足，无法交易",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 4,
		},
	},
	GainList = {
		{
			Value = 770204,
			Num = 1,
		},
	},
	Tags = {
		567018,
		567002,
	},
	Dialog = {
		{
			Quest = "啊，盒子有点破了，不过东西还是可以用的。",
			Answer = "有防伪水印吗？",
		},
		{
			Quest = "那就再便宜一点，只收你4个发条就好啦。",
			Answer = "完成交易",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id020] =
{
	Id = 20,
	Name = "购买定点装置（[FF6500]发条-5[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 5,
			Hint = "发条不足，无法交易",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 4,
		},
	},
	GainList = {
		{
			Value = 770205,
			Num = 1,
		},
	},
	Tags = {
		567018,
		567002,
	},
	Dialog = {
		{
			Quest = "啊，盒子有点破了，不过东西还是可以用的。",
			Answer = "给我看看你的经营证？",
		},
		{
			Quest = "那就再便宜一点，只收你4个发条就好啦。",
			Answer = "完成交易",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id021] =
{
	Id = 21,
	Name = "购买定点装置（[FF6500]发条-5[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 5,
			Hint = "发条不足，无法交易",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 4,
		},
	},
	GainList = {
		{
			Value = 770206,
			Num = 1,
		},
	},
	Tags = {
		567018,
		567002,
	},
	Dialog = {
		{
			Quest = "啊，盒子有点破了，不过东西还是可以用的。",
			Answer = "盒子这么破，你不太想买",
		},
		{
			Quest = "那就再便宜一点，只收你4个发条就好啦。",
			Answer = "完成交易",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id022] =
{
	Id = 22,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id023] =
{
	Id = 23,
	Name = "借出圆锯（[45FF00]发条+1[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 771017,
			Num = 1,
			Hint = "没有圆锯，无法提供",
		},
	},
	GainList = {
		{
			Value = 771017,
			Num = 1,
		},
		{
			Value = 770001,
			Num = 2,
		},
	},
	Tags = {
		567019,
		567002,
	},
	Dialog = {
		{
			Quest = "对方已收到圆锯，不过修理失败，对方飞船已报废。",
			Answer = "…",
		},
		{
			Quest = "对方给了我们2个发条，希望我们不要把事情说出去。",
			Answer = "答应他",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id024] =
{
	Id = 24,
	Name = "提供氧气瓶（[45FF00]发条+12[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 771016,
			Num = 1,
			Hint = "没有氧气瓶，无法提供",
		},
	},
	CostList = {
		{
			Value = 771016,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 770001,
			Num = 15,
		},
	},
	Tags = {
		567020,
		567002,
	},
	Dialog = {
		{
			Quest = "对方已收到氧气瓶，正在进行舰外作业，不过修理失败，飞船彻底报废了。",
			Answer = "…",
		},
		{
			Quest = "对方给了我们15个发条，希望我们不要把事情说出去。",
			Answer = "答应他",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id025] =
{
	Id = 25,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id026] =
{
	Id = 26,
	Name = "强行通过（[FF6500]燃料-100[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 101,
			Num = 100,
		},
	},
	GainList = {
		{
			Value = 771001,
			Num = 2,
		},
	},
	Tags = {
		567021,
		567002,
	},
	Dialog = {
		{
			Quest = "已通过陨石带，飞船急需修理。",
			Answer = "修理飞船",
		},
		{
			Quest = "飞船初步修理完毕，已回收陨石碎片。",
			Answer = "回收陨铁",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id027] =
{
	Id = 27,
	Name = "强行通过（[FF6500]燃料-100[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 101,
			Num = 100,
		},
	},
	GainList = {
		{
			Value = 771001,
			Num = 4,
		},
	},
	Tags = {
		567021,
		567002,
	},
	Dialog = {
		{
			Quest = "已通过陨石带，飞船急需修理。",
			Answer = "修理飞船",
		},
		{
			Quest = "飞船初步修理完毕，已回收陨石碎片。",
			Answer = "回收陨铁",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id028] =
{
	Id = 28,
	Name = "强行通过（[FF6500]燃料-100[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 101,
			Num = 100,
		},
	},
	GainList = {
		{
			Value = 771001,
			Num = 6,
		},
	},
	Tags = {
		567021,
		567002,
	},
	Dialog = {
		{
			Quest = "已通过陨石带，飞船急需修理。",
			Answer = "修理飞船",
		},
		{
			Quest = "飞船初步修理完毕，已回收陨石碎片。",
			Answer = "回收陨铁",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id029] =
{
	Id = 29,
	Name = "静静等待（[FF6500]食物-100[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 103,
			Num = 100,
		},
	},
	Tags = {
		567022,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id030] =
{
	Id = 30,
	Name = "使设备降温（[FF6500]贝壳石-3[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 771002,
			Num = 3,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "在冷却装置中加入了贝壳石，飞船可以继续航行了。",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id031] =
{
	Id = 31,
	Name = "替换芯片（[FF6500]万能芯片-1[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 771019,
			Num = 1,
			Hint = "需要工具：万能芯片",
		},
	},
	CostList = {
		{
			Value = 771019,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "替换了故障芯片，飞船可以继续航行了。",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id032] =
{
	Id = 32,
	Name = "晒会太阳（[FF6500]食物-100[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 103,
			Num = 100,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "晒了一阵辐射风暴，大家都说头很晕。",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id033] =
{
	Id = 33,
	Name = "收集定点前进装置",
	Type = "Command",
	GainList = {
		{
			Value = 770204,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "使用机械臂抓取了道具，得到了定点前进装置4型",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id034] =
{
	Id = 34,
	Name = "收集定点前进装置",
	Type = "Command",
	GainList = {
		{
			Value = 770205,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "使用机械臂抓取了道具，得到了定点前进装置5型",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id035] =
{
	Id = 35,
	Name = "收集定点前进装置",
	Type = "Command",
	GainList = {
		{
			Value = 770206,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "使用机械臂抓取了道具，得到了定点前进装置6型",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id036] =
{
	Id = 36,
	Name = "采集空间数据",
	Type = "Command",
	GainList = {
		{
			Value = 106,
			Num = 150,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "采集了大量空间数据，不过不知道怎么用。",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id037] =
{
	Id = 37,
	Name = "帮海盗助威",
	Type = "Command",
	CostList = {
		{
			Value = 780001,
			Num = 50,
		},
	},
	Tags = {
		567023,
		567002,
	},
	Dialog = {
		{
			Quest = "海盗露出了赞许的目光，随后登上魔王飞船并反锁了门。随后，飞船内传来阵阵惨叫声。",
			Answer = "假装听不到，继续出发",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id038] =
{
	Id = 38,
	Name = "殴打海盗",
	Type = "Challenge",
	ChallengeId = 148061,
	Win = {
		{
			Value = 101,
			Num = 40,
		},
		{
			Value = 770001,
			Num = 2,
		},
		{
			Value = 780001,
			Num = 50,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -40,
		},
		{
			Value = 780001,
			Num = 30,
		},
	},
	Tags = {
		567024,
		567003,
		567089,
	},
	Dialog = {
		{
			Quest = "警告！海盗已强行登陆我方战舰。",
			Answer = "开战！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id039] =
{
	Id = 39,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id040] =
{
	Id = 40,
	Name = "提供燃料（[FF6500]燃料-100[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 101,
			Num = 100,
			Hint = "需要100个燃料",
		},
	},
	CostList = {
		{
			Value = 101,
			Num = 100,
		},
	},
	GainList = {
		{
			Value = 780001,
			Num = 50,
		},
	},
	Tags = {
		567025,
		567002,
	},
	Dialog = {
		{
			Quest = "啊，太感谢大人了，小的们终于可以回家了。",
			Answer = "安慰他们后继续出发。",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id041] =
{
	Id = 41,
	Name = "厉声呵斥！",
	Type = "Command",
	CostList = {
		{
			Value = 780001,
			Num = 50,
		},
	},
	Tags = {
		567026,
		567002,
	},
	Dialog = {
		{
			Quest = "给大人添麻烦了，那小的们先告退了。",
			Answer = "继续出发。",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id042] =
{
	Id = 42,
	Name = "趁机打劫",
	Type = "Challenge",
	ChallengeId = 148142,
	Win = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 780001,
			Num = -100,
		},
	},
	Retreat = {
		{
			Value = 101,
			Num = -100,
		},
		{
			Value = 780001,
			Num = -100,
		},
	},
	Tags = {
		567027,
		567003,
		567085,
	},
	Dialog = {
		{
			Quest = "大人这是要做什么？小的们要叫啦！",
			Answer = "你叫破喉咙也没有人会来的！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id043] =
{
	Id = 43,
	Name = "协助勇者",
	Type = "Challenge",
	ChallengeId = 148051,
	Win = {
		{
			Value = 101,
			Num = 40,
		},
		{
			Value = 770001,
			Num = 2,
		},
		{
			Value = 780002,
			Num = 50,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -40,
		},
		{
			Value = 780002,
			Num = 30,
		},
	},
	Tags = {
		567028,
		567003,
		567089,
	},
	Dialog = {
		{
			Quest = "果然是有胆有谋的好汉，那这个任务就交给你了。",
			Answer = "立刻去歼灭海盗！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id044] =
{
	Id = 44,
	Name = "婉言谢绝",
	Type = "Command",
	CostList = {
		{
			Value = 780002,
			Num = 50,
		},
	},
	Tags = {
		567029,
		567002,
	},
	Dialog = {
		{
			Quest = "真是不上路啊，那我们的作战经费你总要出点吧？",
			Answer = "再次谢绝。",
		},
		{
			Quest = "哎，最近的民众越来越不配合勇者的事业了。",
			Answer = "赶紧离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id045] =
{
	Id = 45,
	Name = "燃料支援（[FF6500]燃料-100[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 101,
			Num = 100,
			Hint = "需要100个燃料",
		},
	},
	CostList = {
		{
			Value = 101,
			Num = 100,
		},
	},
	Tags = {
		567030,
		567002,
	},
	Dialog = {
		{
			Quest = "勇者拍了拍我们的肩膀，口头表扬了我们2小时。",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id046] =
{
	Id = 46,
	Name = "提供食物（[FF6500]食物-100[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 103,
			Num = 100,
			Hint = "需要100个燃料",
		},
	},
	CostList = {
		{
			Value = 103,
			Num = 100,
		},
	},
	Tags = {
		567031,
		567002,
	},
	Dialog = {
		{
			Quest = "唔，虽然都是速冻食品，不过味道还不错。",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id047] =
{
	Id = 47,
	Name = "厉声呵斥",
	Type = "Command",
	CostList = {
		{
			Value = 780002,
			Num = 50,
		},
	},
	Tags = {
		567032,
		567002,
	},
	Dialog = {
		{
			Quest = "看在你们人多的份上，今天就算了，下次别让我遇见你！",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id048] =
{
	Id = 48,
	Name = "趁机打劫",
	Type = "Challenge",
	ChallengeId = 148172,
	Win = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 780002,
			Num = -100,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -100,
		},
		{
			Value = 780002,
			Num = -100,
		},
	},
	Tags = {
		567027,
		567003,
		567100,
	},
	Dialog = {
		{
			Quest = "嗯！光天化日你竟然敢打劫我们！",
			Answer = "速战速决！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id049] =
{
	Id = 49,
	Name = "追尾不对！（声援魔王集团）",
	Type = "Chat",
	ChatId = 840069,
	Win = {
		{
			Value = 103,
			Num = 40,
		},
		{
			Value = 780001,
			Num = 50,
		},
		{
			Value = 780002,
			Num = -50,
		},
	},
	Lose = {
		{
			Value = 101,
			Num = -40,
		},
		{
			Value = 780001,
			Num = 50,
		},
		{
			Value = 780002,
			Num = -50,
		},
	},
	Retreat = {
		{
			Value = 101,
			Num = -40,
		},
		{
			Value = 780001,
			Num = 50,
		},
		{
			Value = 780002,
			Num = -50,
		},
	},
	Tags = {
		567033,
		567004,
		567100,
	},
	Dialog = {
		{
			Quest = "勇者们很不高兴，要求与你好好讨论讨论。",
			Answer = "谈判",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id050] =
{
	Id = 50,
	Name = "急刹不对！（声援冒险家协会）",
	Type = "Chat",
	ChatId = 840010,
	Win = {
		{
			Value = 103,
			Num = 40,
		},
		{
			Value = 780002,
			Num = 50,
		},
		{
			Value = 780001,
			Num = -50,
		},
	},
	Lose = {
		{
			Value = 101,
			Num = -40,
		},
		{
			Value = 780002,
			Num = 50,
		},
		{
			Value = 780001,
			Num = -50,
		},
	},
	Retreat = {
		{
			Value = 101,
			Num = -40,
		},
		{
			Value = 780002,
			Num = 50,
		},
		{
			Value = 780001,
			Num = -50,
		},
	},
	Tags = {
		567034,
		567004,
		567085,
	},
	Dialog = {
		{
			Quest = "骨头兵们很不高兴，说今天要和你好好讨论讨论。",
			Answer = "谈判",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id051] =
{
	Id = 51,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id052] =
{
	Id = 52,
	Name = "殴打骨头兵（协助冒险家协会）",
	Type = "Challenge",
	ChallengeId = 148131,
	Win = {
		{
			Value = 101,
			Num = 40,
		},
		{
			Value = 770001,
			Num = 2,
		},
		{
			Value = 780002,
			Num = 100,
		},
		{
			Value = 780001,
			Num = -100,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -40,
		},
		{
			Value = 780002,
			Num = 50,
		},
		{
			Value = 780001,
			Num = -50,
		},
	},
	Tags = {
		567035,
		567003,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id053] =
{
	Id = 53,
	Name = "殴打勇者（协助魔王集团）",
	Type = "Challenge",
	ChallengeId = 148171,
	Win = {
		{
			Value = 101,
			Num = 40,
		},
		{
			Value = 770001,
			Num = 2,
		},
		{
			Value = 780001,
			Num = 100,
		},
		{
			Value = 780002,
			Num = -100,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -40,
		},
		{
			Value = 780001,
			Num = 50,
		},
		{
			Value = 780002,
			Num = -50,
		},
	},
	Tags = {
		567036,
		567003,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id054] =
{
	Id = 54,
	Name = "绕过去",
	Type = "Command",
	Tags = {
		567037,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id055] =
{
	Id = 55,
	Name = "副本非常有趣，游玩体验极佳！",
	Type = "Command",
	CostList = {
		{
			Value = 780001,
			Num = 20,
		},
	},
	Tags = {
		567038,
		567002,
		567087,
		567085,
	},
	Dialog = {
		{
			Quest = "回答错误…",
			Answer = "悻悻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id056] =
{
	Id = 56,
	Name = "精致的服务体验，让人欲罢不能！",
	Type = "Command",
	CostList = {
		{
			Value = 780001,
			Num = 20,
		},
	},
	Tags = {
		567039,
		567002,
		567087,
		567085,
	},
	Dialog = {
		{
			Quest = "回答错误…",
			Answer = "悻悻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id057] =
{
	Id = 57,
	Name = "因为太受欢迎，所以项目排队时间太长。",
	Type = "Command",
	GainList = {
		{
			Value = 780001,
			Num = 20,
		},
		{
			Value = 770001,
			Num = 5,
		},
	},
	Tags = {
		567040,
		567002,
		567087,
		567085,
		567088,
	},
	Dialog = {
		{
			Quest = "完全正确！",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id058] =
{
	Id = 58,
	Name = "光元素！",
	Type = "Command",
	CostList = {
		{
			Value = 780001,
			Num = 20,
		},
	},
	Tags = {
		567041,
		567002,
		567087,
		567085,
	},
	Dialog = {
		{
			Quest = "回答错误…",
			Answer = "悻悻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id059] =
{
	Id = 59,
	Name = "神秘又惹人遐想的暗元素！",
	Type = "Command",
	GainList = {
		{
			Value = 780001,
			Num = 20,
		},
		{
			Value = 770001,
			Num = 5,
		},
	},
	Tags = {
		567042,
		567002,
		567087,
		567085,
		567088,
	},
	Dialog = {
		{
			Quest = "完全正确！",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id060] =
{
	Id = 60,
	Name = "太合适了，完全就是用户需求！",
	Type = "Command",
	GainList = {
		{
			Value = 780001,
			Num = 30,
		},
		{
			Value = 770001,
			Num = 5,
		},
	},
	Tags = {
		567043,
		567002,
		567087,
		567085,
		567088,
	},
	Dialog = {
		{
			Quest = "完全正确！",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id061] =
{
	Id = 61,
	Name = "价格不贵的话，我可以接受。",
	Type = "Command",
	GainList = {
		{
			Value = 780001,
			Num = 15,
		},
		{
			Value = 770001,
			Num = 2,
		},
	},
	Tags = {
		567044,
		567002,
		567087,
		567085,
		567088,
	},
	Dialog = {
		{
			Quest = "有点道理。",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id062] =
{
	Id = 62,
	Name = "魔王集团在骗钱。",
	Type = "Command",
	CostList = {
		{
			Value = 780001,
			Num = 20,
		},
	},
	Tags = {
		567045,
		567002,
		567087,
		567085,
	},
	Dialog = {
		{
			Quest = "回答错误…",
			Answer = "悻悻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id063] =
{
	Id = 63,
	Name = "魔王集团作弊了！",
	Type = "Command",
	GainList = {
		{
			Value = 780002,
			Num = 30,
		},
		{
			Value = 770001,
			Num = 5,
		},
	},
	Tags = {
		567046,
		567002,
		567087,
		567100,
		567088,
	},
	Dialog = {
		{
			Quest = "完全正确！",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id064] =
{
	Id = 64,
	Name = "居民们上贡的财物还不够多。",
	Type = "Command",
	GainList = {
		{
			Value = 780002,
			Num = 15,
		},
		{
			Value = 770001,
			Num = 2,
		},
	},
	Tags = {
		567047,
		567002,
		567087,
		567100,
		567088,
	},
	Dialog = {
		{
			Quest = "有点道理。",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id065] =
{
	Id = 65,
	Name = "勇者的打法有问题。",
	Type = "Command",
	CostList = {
		{
			Value = 780002,
			Num = 20,
		},
	},
	Tags = {
		567048,
		567002,
		567087,
		567100,
	},
	Dialog = {
		{
			Quest = "回答错误…",
			Answer = "悻悻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id066] =
{
	Id = 66,
	Name = "是伟大的冒险者们！",
	Type = "Command",
	GainList = {
		{
			Value = 780002,
			Num = 20,
		},
		{
			Value = 770001,
			Num = 5,
		},
	},
	Tags = {
		567049,
		567002,
		567087,
		567100,
		567088,
	},
	Dialog = {
		{
			Quest = "完全正确！",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id067] =
{
	Id = 67,
	Name = "不知道是谁…",
	Type = "Command",
	CostList = {
		{
			Value = 780002,
			Num = 20,
		},
	},
	Tags = {
		567050,
		567002,
		567087,
		567100,
	},
	Dialog = {
		{
			Quest = "回答错误…",
			Answer = "悻悻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id068] =
{
	Id = 68,
	Name = "魔王集团在骗钱！",
	Type = "Command",
	GainList = {
		{
			Value = 780002,
			Num = 30,
		},
		{
			Value = 770001,
			Num = 5,
		},
	},
	Tags = {
		567051,
		567002,
		567087,
		567100,
		567088,
	},
	Dialog = {
		{
			Quest = "完全正确！",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id069] =
{
	Id = 69,
	Name = "虽然不清楚情况，不过我反对！",
	Type = "Command",
	GainList = {
		{
			Value = 780002,
			Num = 15,
		},
		{
			Value = 770001,
			Num = 2,
		},
	},
	Tags = {
		567052,
		567002,
		567087,
		567100,
		567088,
	},
	Dialog = {
		{
			Quest = "有点道理。",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id070] =
{
	Id = 70,
	Name = "还是有点道理的。",
	Type = "Command",
	CostList = {
		{
			Value = 780002,
			Num = 20,
		},
	},
	Tags = {
		567053,
		567002,
		567087,
		567100,
	},
	Dialog = {
		{
			Quest = "回答错误…",
			Answer = "悻悻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id071] =
{
	Id = 71,
	Name = "着陆并探索",
	Type = "Discovery",
	DiscoveryId = 860001,
	Tags = {
		567054,
		567006,
	},
	Dialog = {
		{
			Quest = "经检测，空间站处于废弃状态，建议携带工具进行探索。",
			Answer = "开始探索",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id072] =
{
	Id = 72,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id073] =
{
	Id = 73,
	Name = "着陆并探索",
	Type = "Discovery",
	DiscoveryId = 860001,
	Tags = {
		567054,
		567006,
	},
	Dialog = {
		{
			Quest = "经检测，空间站处于废弃状态，建议携带工具进行探索。",
			Answer = "开始探索",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id074] =
{
	Id = 74,
	Name = "追查特殊信号来源（[FF6500]圆锯 -5[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 771017,
			Num = 5,
			Hint = "需要5个圆锯探索信号来源",
		},
	},
	CostList = {
		{
			Value = 771017,
			Num = 5,
		},
	},
	GainList = {
		{
			Value = 773001,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "已定位到信号来源，发现目标为老式保险箱。",
			Answer = "尝试切割",
		},
		{
			Quest = "消耗了大量圆锯后，终于打开了保险箱，找到了一颗宝石。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id075] =
{
	Id = 75,
	Name = "追查特殊信号来源（[FF6500]圆锯 -5[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 771017,
			Num = 5,
			Hint = "需要5个圆锯探索信号来源",
		},
	},
	CostList = {
		{
			Value = 771017,
			Num = 5,
		},
	},
	GainList = {
		{
			Value = 773006,
			Num = 1,
		},
	},
	Dialog = {
		{
			Quest = "已定位到信号来源，发现目标为老式保险箱。",
			Answer = "尝试切割",
		},
		{
			Quest = "消耗了大量圆锯后，终于打开了保险箱，找到了一颗宝石。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id076] =
{
	Id = 76,
	Name = "追查特殊信号来源（[FF6500]圆锯 -5[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 771017,
			Num = 5,
			Hint = "需要5个圆锯探索信号来源",
		},
	},
	CostList = {
		{
			Value = 771017,
			Num = 5,
		},
	},
	GainList = {
		{
			Value = 773011,
			Num = 1,
		},
	},
	Dialog = {
		{
			Quest = "已定位到信号来源，发现目标为老式保险箱。",
			Answer = "尝试切割",
		},
		{
			Quest = "消耗了大量圆锯后，终于打开了保险箱，找到了一颗宝石。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id077] =
{
	Id = 77,
	Name = "追查特殊信号来源（[FF6500]圆锯 -5[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 771017,
			Num = 5,
			Hint = "需要5个圆锯探索信号来源",
		},
	},
	CostList = {
		{
			Value = 771017,
			Num = 5,
		},
	},
	GainList = {
		{
			Value = 773016,
			Num = 1,
		},
	},
	Dialog = {
		{
			Quest = "已定位到信号来源，发现目标为老式保险箱。",
			Answer = "尝试切割",
		},
		{
			Quest = "消耗了大量圆锯后，终于打开了保险箱，找到了一颗宝石。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id078] =
{
	Id = 78,
	Name = "追查特殊信号来源（[FF6500]圆锯 -5[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 771017,
			Num = 5,
			Hint = "需要5个圆锯探索信号来源",
		},
	},
	CostList = {
		{
			Value = 771017,
			Num = 5,
		},
	},
	GainList = {
		{
			Value = 773021,
			Num = 1,
		},
	},
	Dialog = {
		{
			Quest = "已定位到信号来源，发现目标为老式保险箱。",
			Answer = "尝试切割",
		},
		{
			Quest = "消耗了大量圆锯后，终于打开了保险箱，找到了一颗宝石。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id079] =
{
	Id = 79,
	Name = "追查特殊信号来源（[FF6500]圆锯 -5[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 771017,
			Num = 5,
			Hint = "需要5个圆锯探索信号来源",
		},
	},
	CostList = {
		{
			Value = 771017,
			Num = 5,
		},
	},
	GainList = {
		{
			Value = 773026,
			Num = 1,
		},
	},
	Dialog = {
		{
			Quest = "已定位到信号来源，发现目标为老式保险箱。",
			Answer = "尝试切割",
		},
		{
			Quest = "消耗了大量圆锯后，终于打开了保险箱，找到了一颗宝石。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id080] =
{
	Id = 80,
	Name = "追查特殊信号来源（[FF6500]圆锯 -5[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 771017,
			Num = 5,
			Hint = "需要5个圆锯探索信号来源",
		},
	},
	CostList = {
		{
			Value = 771017,
			Num = 5,
		},
	},
	GainList = {
		{
			Value = 773031,
			Num = 1,
		},
	},
	Dialog = {
		{
			Quest = "已定位到信号来源，发现目标为老式保险箱。",
			Answer = "尝试切割",
		},
		{
			Quest = "消耗了大量圆锯后，终于打开了保险箱，找到了一颗宝石。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id081] =
{
	Id = 81,
	Name = "追查特殊信号来源（[FF6500]圆锯 -5[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 771017,
			Num = 5,
			Hint = "需要5个圆锯探索信号来源",
		},
	},
	CostList = {
		{
			Value = 771017,
			Num = 5,
		},
	},
	GainList = {
		{
			Value = 773036,
			Num = 1,
		},
	},
	Dialog = {
		{
			Quest = "已定位到信号来源，发现目标为老式保险箱。",
			Answer = "尝试切割",
		},
		{
			Quest = "消耗了大量圆锯后，终于打开了保险箱，找到了一颗宝石。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id082] =
{
	Id = 82,
	Name = "追查特殊信号来源（[FF6500]圆锯 -5[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 771017,
			Num = 5,
			Hint = "需要5个圆锯探索信号来源",
		},
	},
	CostList = {
		{
			Value = 771017,
			Num = 5,
		},
	},
	GainList = {
		{
			Value = 773041,
			Num = 1,
		},
	},
	Dialog = {
		{
			Quest = "已定位到信号来源，发现目标为老式保险箱。",
			Answer = "尝试切割",
		},
		{
			Quest = "消耗了大量圆锯后，终于打开了保险箱，找到了一颗宝石。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id083] =
{
	Id = 83,
	Name = "追查特殊信号来源（[FF6500]圆锯 -5[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 771017,
			Num = 5,
			Hint = "需要5个圆锯探索信号来源",
		},
	},
	CostList = {
		{
			Value = 771017,
			Num = 5,
		},
	},
	GainList = {
		{
			Value = 773046,
			Num = 1,
		},
	},
	Dialog = {
		{
			Quest = "已定位到信号来源，发现目标为老式保险箱。",
			Answer = "尝试切割",
		},
		{
			Quest = "消耗了大量圆锯后，终于打开了保险箱，找到了一颗宝石。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id084] =
{
	Id = 84,
	Name = "追查特殊信号来源（[FF6500]圆锯 -5[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 771017,
			Num = 5,
			Hint = "需要5个圆锯探索信号来源",
		},
	},
	CostList = {
		{
			Value = 771017,
			Num = 5,
		},
	},
	GainList = {
		{
			Value = 773051,
			Num = 1,
		},
	},
	Dialog = {
		{
			Quest = "已定位到信号来源，发现目标为老式保险箱。",
			Answer = "尝试切割",
		},
		{
			Quest = "消耗了大量圆锯后，终于打开了保险箱，找到了一颗宝石。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id085] =
{
	Id = 85,
	Name = "追查特殊信号来源（[FF6500]圆锯 -5[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 771017,
			Num = 5,
			Hint = "需要5个圆锯探索信号来源",
		},
	},
	CostList = {
		{
			Value = 771017,
			Num = 5,
		},
	},
	GainList = {
		{
			Value = 773056,
			Num = 1,
		},
	},
	Dialog = {
		{
			Quest = "已定位到信号来源，发现目标为老式保险箱。",
			Answer = "尝试切割",
		},
		{
			Quest = "消耗了大量圆锯后，终于打开了保险箱，找到了一颗宝石。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id086] =
{
	Id = 86,
	Name = "追查特殊信号来源（[FF6500]圆锯 -5[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 771017,
			Num = 5,
			Hint = "需要5个圆锯探索信号来源",
		},
	},
	CostList = {
		{
			Value = 771017,
			Num = 5,
		},
	},
	GainList = {
		{
			Value = 773061,
			Num = 1,
		},
	},
	Dialog = {
		{
			Quest = "已定位到信号来源，发现目标为老式保险箱。",
			Answer = "尝试切割",
		},
		{
			Quest = "消耗了大量圆锯后，终于打开了保险箱，找到了一颗宝石。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id087] =
{
	Id = 87,
	Name = "继续航行",
	Type = "Command",
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id088] =
{
	Id = 88,
	Name = "正面突破",
	Type = "Challenge",
	ChallengeId = 148052,
	Win = {
		{
			Value = 101,
			Num = 40,
		},
		{
			Value = 770001,
			Num = 2,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -40,
		},
	},
	Tags = {
		567055,
		567003,
		567089,
	},
	Dialog = {
		{
			Quest = "还想跑！今天必须好好教训你们一下！",
			Answer = "战斗！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id089] =
{
	Id = 89,
	Name = "正面突破",
	Type = "Challenge",
	ChallengeId = 148062,
	Win = {
		{
			Value = 101,
			Num = 40,
		},
		{
			Value = 770001,
			Num = 2,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -40,
		},
	},
	Tags = {
		567055,
		567003,
		567089,
	},
	Dialog = {
		{
			Quest = "还想跑！今天必须好好教训你们一下！",
			Answer = "战斗！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id090] =
{
	Id = 90,
	Name = "正面突破",
	Type = "Challenge",
	ChallengeId = 148072,
	Win = {
		{
			Value = 101,
			Num = 40,
		},
		{
			Value = 770001,
			Num = 2,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -40,
		},
	},
	Tags = {
		567055,
		567003,
		567089,
	},
	Dialog = {
		{
			Quest = "还想跑！今天必须好好教训你们一下！",
			Answer = "战斗！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id091] =
{
	Id = 91,
	Name = "正面突破",
	Type = "Challenge",
	ChallengeId = 148082,
	Win = {
		{
			Value = 101,
			Num = 40,
		},
		{
			Value = 770001,
			Num = 2,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -40,
		},
	},
	Tags = {
		567055,
		567003,
		567089,
	},
	Dialog = {
		{
			Quest = "还想跑！今天必须好好教训你们一下！",
			Answer = "战斗！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id092] =
{
	Id = 92,
	Name = "正面突破",
	Type = "Challenge",
	ChallengeId = 148092,
	Win = {
		{
			Value = 101,
			Num = 40,
		},
		{
			Value = 770001,
			Num = 2,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -40,
		},
	},
	Tags = {
		567055,
		567003,
		567089,
	},
	Dialog = {
		{
			Quest = "还想跑！今天必须好好教训你们一下！",
			Answer = "战斗！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id093] =
{
	Id = 93,
	Name = "交5个发条",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 5,
			Hint = "需要5个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 5,
		},
	},
	Tags = {
		567056,
		567002,
	},
	Dialog = {
		{
			Quest = "小朋友很懂事嘛，那就赶紧过去吧。",
			Answer = "赶紧离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id094] =
{
	Id = 94,
	Name = "补充燃料（[45FF00]燃料+300[-] [FF6500]发条-30[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 30,
			Hint = "需要30个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 30,
		},
	},
	GainList = {
		{
			Value = 101,
			Num = 300,
		},
	},
	Tags = {
		567057,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id095] =
{
	Id = 95,
	Name = "出售燃料（[45FF00]发条+5[-] [FF6500]燃料-100[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 101,
			Num = 100,
			Hint = "需要100个发条",
		},
	},
	CostList = {
		{
			Value = 101,
			Num = 100,
		},
	},
	GainList = {
		{
			Value = 770001,
			Num = 5,
		},
	},
	Tags = {
		567058,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id096] =
{
	Id = 96,
	Name = "离开",
	Type = "Command",
	Tags = {
		567059,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id097] =
{
	Id = 97,
	Name = "大吃一顿（[45FF00]食物+100[-] [FF6500]发条-10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
	},
	GainList = {
		{
			Value = 103,
			Num = 100,
		},
	},
	Tags = {
		567060,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id098] =
{
	Id = 98,
	Name = "帮忙洗盘子（[45FF00]食物+10[-]）",
	Type = "Command",
	GainList = {
		{
			Value = 103,
			Num = 10,
		},
	},
	Tags = {
		567061,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id099] =
{
	Id = 99,
	Name = "离开",
	Type = "Command",
	Tags = {
		567059,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id100] =
{
	Id = 100,
	Name = "进行交易",
	Type = "Deal",
	DealId = 850001,
	Tags = {
		567062,
		567005,
	},
	Dialog = {
		{
			Quest = "相信你一定会找到你想要的东西的，客人~",
			Answer = "进入商店",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id101] =
{
	Id = 101,
	Name = "离开",
	Type = "Command",
	Tags = {
		567059,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id102] =
{
	Id = 102,
	Name = "兑换超能物体（[FF6500]能量果实-3[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 771008,
			Num = 3,
		},
	},
	GainList = {
		{
			Value = 773001,
			Num = 1,
		},
	},
	Tags = {
		567063,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id103] =
{
	Id = 103,
	Name = "兑换超能物体（[FF6500]生命果实-3[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 771009,
			Num = 3,
		},
	},
	GainList = {
		{
			Value = 773006,
			Num = 1,
		},
	},
	Tags = {
		567063,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id104] =
{
	Id = 104,
	Name = "购买随机宝石（[FF6500]发条 -32[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 32,
			Hint = "购买宝石需要32个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 32,
		},
	},
	GainList = {
		{
			Value = 773001,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "嗯，这颗宝石非常适合客人，如果能好好利用的话，航行一定会更顺利的。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id105] =
{
	Id = 105,
	Name = "购买随机宝石（[FF6500]发条 -32[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 32,
			Hint = "购买宝石需要32个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 32,
		},
	},
	GainList = {
		{
			Value = 773006,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "嗯，这颗宝石非常适合客人，如果能好好利用的话，航行一定会更顺利的。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id106] =
{
	Id = 106,
	Name = "购买随机宝石（[FF6500]发条 -32[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 32,
			Hint = "购买宝石需要32个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 32,
		},
	},
	GainList = {
		{
			Value = 773011,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "嗯，这颗宝石非常适合客人，如果能好好利用的话，航行一定会更顺利的。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id107] =
{
	Id = 107,
	Name = "购买随机宝石（[FF6500]发条 -32[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 32,
			Hint = "购买宝石需要32个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 32,
		},
	},
	GainList = {
		{
			Value = 773016,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "嗯，这颗宝石非常适合客人，如果能好好利用的话，航行一定会更顺利的。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id108] =
{
	Id = 108,
	Name = "购买随机宝石（[FF6500]发条 -32[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 32,
			Hint = "购买宝石需要32个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 32,
		},
	},
	GainList = {
		{
			Value = 773021,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "嗯，这颗宝石非常适合客人，如果能好好利用的话，航行一定会更顺利的。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id109] =
{
	Id = 109,
	Name = "购买随机宝石（[FF6500]发条 -32[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 32,
			Hint = "购买宝石需要32个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 32,
		},
	},
	GainList = {
		{
			Value = 773026,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "嗯，这颗宝石非常适合客人，如果能好好利用的话，航行一定会更顺利的。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id110] =
{
	Id = 110,
	Name = "购买随机宝石（[FF6500]发条 -32[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 32,
			Hint = "购买宝石需要32个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 32,
		},
	},
	GainList = {
		{
			Value = 773031,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "嗯，这颗宝石非常适合客人，如果能好好利用的话，航行一定会更顺利的。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id111] =
{
	Id = 111,
	Name = "购买随机宝石（[FF6500]发条 -32[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 32,
			Hint = "购买宝石需要32个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 32,
		},
	},
	GainList = {
		{
			Value = 773036,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "嗯，这颗宝石非常适合客人，如果能好好利用的话，航行一定会更顺利的。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id112] =
{
	Id = 112,
	Name = "购买随机宝石（[FF6500]发条 -32[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 32,
			Hint = "购买宝石需要32个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 32,
		},
	},
	GainList = {
		{
			Value = 773041,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "嗯，这颗宝石非常适合客人，如果能好好利用的话，航行一定会更顺利的。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id113] =
{
	Id = 113,
	Name = "购买随机宝石（[FF6500]发条 -32[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 32,
			Hint = "购买宝石需要32个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 32,
		},
	},
	GainList = {
		{
			Value = 773046,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "嗯，这颗宝石非常适合客人，如果能好好利用的话，航行一定会更顺利的。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id114] =
{
	Id = 114,
	Name = "购买随机宝石（[FF6500]发条 -32[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 32,
			Hint = "购买宝石需要32个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 32,
		},
	},
	GainList = {
		{
			Value = 773051,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "嗯，这颗宝石非常适合客人，如果能好好利用的话，航行一定会更顺利的。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id115] =
{
	Id = 115,
	Name = "购买随机宝石（[FF6500]发条 -32[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 32,
			Hint = "购买宝石需要32个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 32,
		},
	},
	GainList = {
		{
			Value = 773056,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "嗯，这颗宝石非常适合客人，如果能好好利用的话，航行一定会更顺利的。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id116] =
{
	Id = 116,
	Name = "购买随机宝石（[FF6500]发条 -32[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 32,
			Hint = "购买宝石需要32个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 32,
		},
	},
	GainList = {
		{
			Value = 773061,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "嗯，这颗宝石非常适合客人，如果能好好利用的话，航行一定会更顺利的。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id117] =
{
	Id = 117,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773001,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773066,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更利于菜鸟队员吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id118] =
{
	Id = 118,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773006,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773071,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更利于菜鸟队员吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id119] =
{
	Id = 119,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773011,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773076,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更利于菜鸟队员吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id120] =
{
	Id = 120,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773016,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773081,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更利于菜鸟队员吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id121] =
{
	Id = 121,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773021,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773086,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更利于菜鸟队员吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id122] =
{
	Id = 122,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773026,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773091,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更利于菜鸟队员吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id123] =
{
	Id = 123,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773031,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773096,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更利于菜鸟队员吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id124] =
{
	Id = 124,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773036,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773101,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更利于菜鸟队员吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id125] =
{
	Id = 125,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773041,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773106,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更利于菜鸟队员吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id126] =
{
	Id = 126,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773046,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773111,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更利于菜鸟队员吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id127] =
{
	Id = 127,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773051,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773116,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更利于菜鸟队员吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id128] =
{
	Id = 128,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773056,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773121,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更利于菜鸟队员吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id129] =
{
	Id = 129,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773061,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773126,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更利于菜鸟队员吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id130] =
{
	Id = 130,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773001,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773131,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更富有进攻性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id131] =
{
	Id = 131,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773006,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773136,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更富有进攻性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id132] =
{
	Id = 132,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773011,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773141,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更富有进攻性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id133] =
{
	Id = 133,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773016,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773146,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更富有进攻性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id134] =
{
	Id = 134,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773021,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773151,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更富有进攻性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id135] =
{
	Id = 135,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773026,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773156,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更富有进攻性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id136] =
{
	Id = 136,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773031,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773161,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更富有进攻性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id137] =
{
	Id = 137,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773036,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773166,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更富有进攻性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id138] =
{
	Id = 138,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773041,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773171,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更富有进攻性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id139] =
{
	Id = 139,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773046,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773176,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更富有进攻性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id140] =
{
	Id = 140,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773051,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773181,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更富有进攻性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id141] =
{
	Id = 141,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773056,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773186,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更富有进攻性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id142] =
{
	Id = 142,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773061,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773191,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更富有进攻性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id143] =
{
	Id = 143,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773001,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773196,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更兼顾防护性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id144] =
{
	Id = 144,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773006,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773201,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更兼顾防护性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id145] =
{
	Id = 145,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773011,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773206,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更兼顾防护性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id146] =
{
	Id = 146,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773016,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773211,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更兼顾防护性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id147] =
{
	Id = 147,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773021,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773216,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更兼顾防护性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id148] =
{
	Id = 148,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773026,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773221,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更兼顾防护性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id149] =
{
	Id = 149,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773031,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773226,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更兼顾防护性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id150] =
{
	Id = 150,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773036,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773231,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更兼顾防护性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id151] =
{
	Id = 151,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773041,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773236,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更兼顾防护性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id152] =
{
	Id = 152,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773046,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773241,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更兼顾防护性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id153] =
{
	Id = 153,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773051,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773246,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更兼顾防护性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id154] =
{
	Id = 154,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773056,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773251,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更兼顾防护性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id155] =
{
	Id = 155,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773061,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773256,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更兼顾防护性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id156] =
{
	Id = 156,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773001,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773002,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id157] =
{
	Id = 157,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773006,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773007,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id158] =
{
	Id = 158,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773011,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773012,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id159] =
{
	Id = 159,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773016,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773017,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id160] =
{
	Id = 160,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773021,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773022,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id161] =
{
	Id = 161,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773026,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773027,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id162] =
{
	Id = 162,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773031,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773032,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id163] =
{
	Id = 163,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773036,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773037,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id164] =
{
	Id = 164,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773041,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773042,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id165] =
{
	Id = 165,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773046,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773047,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id166] =
{
	Id = 166,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773051,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773052,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id167] =
{
	Id = 167,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773056,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773057,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id168] =
{
	Id = 168,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773061,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773062,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id169] =
{
	Id = 169,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773066,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773002,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id170] =
{
	Id = 170,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773071,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773007,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id171] =
{
	Id = 171,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773076,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773012,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id172] =
{
	Id = 172,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773081,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773017,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id173] =
{
	Id = 173,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773086,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773022,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id174] =
{
	Id = 174,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773091,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773027,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id175] =
{
	Id = 175,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773096,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773032,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id176] =
{
	Id = 176,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773101,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773037,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id177] =
{
	Id = 177,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773106,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773042,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id178] =
{
	Id = 178,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773111,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773047,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id179] =
{
	Id = 179,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773116,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773052,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id180] =
{
	Id = 180,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773121,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773057,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id181] =
{
	Id = 181,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773126,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773062,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id182] =
{
	Id = 182,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773131,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773002,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id183] =
{
	Id = 183,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773136,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773007,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id184] =
{
	Id = 184,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773141,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773012,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id185] =
{
	Id = 185,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773146,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773017,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id186] =
{
	Id = 186,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773151,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773022,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id187] =
{
	Id = 187,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773156,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773027,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id188] =
{
	Id = 188,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773161,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773032,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id189] =
{
	Id = 189,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773166,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773037,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id190] =
{
	Id = 190,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773171,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773042,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id191] =
{
	Id = 191,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773176,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773047,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id192] =
{
	Id = 192,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773181,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773052,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id193] =
{
	Id = 193,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773186,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773057,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id194] =
{
	Id = 194,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773191,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773062,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id195] =
{
	Id = 195,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773196,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773002,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id196] =
{
	Id = 196,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773201,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773007,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id197] =
{
	Id = 197,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773206,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773012,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id198] =
{
	Id = 198,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773211,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773017,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id199] =
{
	Id = 199,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773216,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773022,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id200] =
{
	Id = 200,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773221,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773027,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id201] =
{
	Id = 201,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773226,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773032,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id202] =
{
	Id = 202,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773231,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773037,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id203] =
{
	Id = 203,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773236,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773042,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id204] =
{
	Id = 204,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773241,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773047,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id205] =
{
	Id = 205,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773246,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773052,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id206] =
{
	Id = 206,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773251,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773057,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id207] =
{
	Id = 207,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773256,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773062,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id208] =
{
	Id = 208,
	Name = "离开",
	Type = "Command",
	Tags = {
		567059,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id209] =
{
	Id = 209,
	Name = "与重大霸格进行战斗",
	Type = "Challenge",
	ChallengeId = 148001,
	Win = {
		{
			Value = 773011,
			Num = 1,
		},
		{
			Value = 770001,
			Num = 50,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -1500,
		},
	},
	Tags = {
		567064,
		567003,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id210] =
{
	Id = 210,
	Name = "尝试谈判",
	Type = "Chat",
	ChatId = 840047,
	Win = {
		{
			Value = 101,
			Num = 500,
		},
		{
			Value = 103,
			Num = 500,
		},
	},
	Lose = {
		{
			Value = 101,
			Num = -2500,
		},
	},
	Retreat = {
		{
			Value = 101,
			Num = -1500,
		},
	},
	Tags = {
		567065,
		567004,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id211] =
{
	Id = 211,
	Name = "贿赂重大霸格（[FF6500]发条-1000[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 1000,
			Hint = "需要1000个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 1000,
		},
	},
	Tags = {
		567066,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id212] =
{
	Id = 212,
	Name = "进行决斗",
	Type = "Challenge",
	ChallengeId = 148104,
	Win = {
		{
			Value = 101,
			Num = 70,
		},
		{
			Value = 770001,
			Num = 5,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -70,
		},
	},
	Tags = {
		567067,
		567003,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id213] =
{
	Id = 213,
	Name = "尝试谈判",
	Type = "Chat",
	ChatId = 840028,
	Win = {
		{
			Value = 103,
			Num = 40,
		},
	},
	Lose = {
		{
			Value = 101,
			Num = -40,
		},
	},
	Retreat = {
		{
			Value = 101,
			Num = -40,
		},
	},
	Tags = {
		567065,
		567004,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id214] =
{
	Id = 214,
	Name = "赠送礼物（[FF6500]发条-25[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 25,
			Hint = "需要25个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 25,
		},
	},
	GainList = {
		{
			Value = 780001,
			Num = 25,
		},
	},
	Win = {
		{
			Num = 40,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id215] =
{
	Id = 215,
	Name = "赠送礼物（[FF6500]陨铁-15[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 15,
		},
	},
	GainList = {
		{
			Value = 780001,
			Num = 25,
		},
	},
	Win = {
		{
			Num = 40,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id216] =
{
	Id = 216,
	Name = "赠送礼物（[FF6500]贝壳石-10[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
	},
	GainList = {
		{
			Value = 780001,
			Num = 25,
		},
	},
	Win = {
		{
			Num = 40,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id217] =
{
	Id = 217,
	Name = "赠送礼物（[FF6500]高能矿石-5[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 5,
		},
	},
	GainList = {
		{
			Value = 780001,
			Num = 25,
		},
	},
	Win = {
		{
			Num = 40,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id218] =
{
	Id = 218,
	Name = "赠送礼物（[FF6500]元素石-8[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 8,
		},
	},
	GainList = {
		{
			Value = 780001,
			Num = 25,
		},
	},
	Win = {
		{
			Num = 40,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id219] =
{
	Id = 219,
	Name = "偷袭对方",
	Type = "Challenge",
	ChallengeId = 148113,
	Win = {
		{
			Value = 101,
			Num = 50,
		},
		{
			Value = 770001,
			Num = 3,
		},
		{
			Value = 780001,
			Num = -20,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -50,
		},
		{
			Value = 780001,
			Num = -20,
		},
	},
	Tags = {
		567069,
		567003,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id220] =
{
	Id = 220,
	Name = "尝试谈判",
	Type = "Chat",
	ChatId = 840022,
	Win = {
		{
			Value = 103,
			Num = 40,
		},
	},
	Lose = {
		{
			Value = 101,
			Num = -40,
		},
	},
	Retreat = {
		{
			Value = 101,
			Num = -40,
		},
	},
	Tags = {
		567065,
		567004,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id221] =
{
	Id = 221,
	Name = "赠送礼物（[FF6500]发条-20[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 20,
			Hint = "需要20个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 20,
		},
	},
	GainList = {
		{
			Value = 780001,
			Num = 25,
		},
	},
	Win = {
		{
			Num = 40,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id222] =
{
	Id = 222,
	Name = "赠送礼物（[FF6500]陨铁-12[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 12,
		},
	},
	GainList = {
		{
			Value = 780001,
			Num = 25,
		},
	},
	Win = {
		{
			Num = 40,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id223] =
{
	Id = 223,
	Name = "赠送礼物（[FF6500]贝壳石-8[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 8,
		},
	},
	GainList = {
		{
			Value = 780001,
			Num = 25,
		},
	},
	Win = {
		{
			Num = 40,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id224] =
{
	Id = 224,
	Name = "赠送礼物（[FF6500]高能矿石-4[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 4,
		},
	},
	GainList = {
		{
			Value = 780001,
			Num = 25,
		},
	},
	Win = {
		{
			Num = 40,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id225] =
{
	Id = 225,
	Name = "赠送礼物（[FF6500]元素石-6[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 6,
		},
	},
	GainList = {
		{
			Value = 780001,
			Num = 25,
		},
	},
	Win = {
		{
			Num = 40,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id226] =
{
	Id = 226,
	Name = "索要补给",
	Type = "Challenge",
	ChallengeId = 148143,
	Win = {
		{
			Value = 101,
			Num = 30,
		},
		{
			Value = 770001,
			Num = 2,
		},
		{
			Value = 780001,
			Num = -20,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -30,
		},
		{
			Value = 780001,
			Num = -20,
		},
	},
	Tags = {
		567070,
		567003,
		567085,
	},
	Dialog = {
		{
			Quest = "大人这就是在为难小的们了。",
			Answer = "直接开抢！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id227] =
{
	Id = 227,
	Name = "骗取补给",
	Type = "Chat",
	ChatId = 840016,
	Win = {
		{
			Value = 103,
			Num = 40,
		},
		{
			Value = 780001,
			Num = -10,
		},
	},
	Lose = {
		{
			Value = 101,
			Num = -40,
		},
		{
			Value = 780001,
			Num = -10,
		},
	},
	Retreat = {
		{
			Value = 101,
			Num = -40,
		},
		{
			Value = 780001,
			Num = -10,
		},
	},
	Tags = {
		567071,
		567004,
		567085,
	},
	Dialog = {
		{
			Quest = "大人这么狡猾，小的们一定不是大人的对手。",
			Answer = "挑衅对方！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id228] =
{
	Id = 228,
	Name = "赠送礼物（[FF6500]发条-15[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 15,
			Hint = "需要15个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 15,
		},
	},
	GainList = {
		{
			Value = 780001,
			Num = 25,
		},
	},
	Tags = {
		567068,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id229] =
{
	Id = 229,
	Name = "赠送礼物（[FF6500]陨铁-9[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 9,
		},
	},
	GainList = {
		{
			Value = 780001,
			Num = 25,
		},
	},
	Win = {
		{
			Num = 40,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id230] =
{
	Id = 230,
	Name = "赠送礼物（[FF6500]贝壳石-6[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 6,
		},
	},
	GainList = {
		{
			Value = 780001,
			Num = 25,
		},
	},
	Win = {
		{
			Num = 40,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id231] =
{
	Id = 231,
	Name = "赠送礼物（[FF6500]高能矿石-3[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 3,
		},
	},
	GainList = {
		{
			Value = 780001,
			Num = 25,
		},
	},
	Win = {
		{
			Num = 40,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id232] =
{
	Id = 232,
	Name = "赠送礼物（[FF6500]元素石-5[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 5,
		},
	},
	GainList = {
		{
			Value = 780001,
			Num = 25,
		},
	},
	Win = {
		{
			Num = 40,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id233] =
{
	Id = 233,
	Name = "进行初级挑战（[45FF00]不降低友好度[-]）",
	Type = "Challenge",
	ChallengeId = 148133,
	Win = {
		{
			Value = 101,
			Num = 30,
		},
		{
			Value = 770001,
			Num = 2,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -30,
		},
	},
	Tags = {
		567072,
		567003,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id234] =
{
	Id = 234,
	Name = "进行交易",
	Type = "Deal",
	DealId = 850003,
	Tags = {
		567062,
		567005,
		567085,
	},
	Dialog = {
		{
			Quest = "大人开这么高级的飞船，相信平时一定是个豪爽的人。",
			Answer = "进入商店",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id235] =
{
	Id = 235,
	Name = "燃料补给（[45FF00]燃料+100[-] [FF6500]发条-8[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 8,
		},
	},
	GainList = {
		{
			Value = 101,
			Num = 100,
		},
	},
	Tags = {
		567073,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id236] =
{
	Id = 236,
	Name = "食物补给（[45FF00]食物+100[-] [FF6500]发条-8[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 8,
		},
	},
	GainList = {
		{
			Value = 103,
			Num = 100,
		},
	},
	Tags = {
		567074,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id237] =
{
	Id = 237,
	Name = "中级挑战（[45FF00]不降低友好度[-]）",
	Type = "Challenge",
	ChallengeId = 148124,
	Win = {
		{
			Value = 101,
			Num = 50,
		},
		{
			Value = 770001,
			Num = 3,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -50,
		},
	},
	Tags = {
		567075,
		567003,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id238] =
{
	Id = 238,
	Name = "进行交易",
	Type = "Deal",
	DealId = 850003,
	Tags = {
		567062,
		567005,
		567085,
	},
	Dialog = {
		{
			Quest = "大人开这么高级的飞船，相信平时一定是个豪爽的人。",
			Answer = "进入商店",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id239] =
{
	Id = 239,
	Name = "燃料补给（[45FF00]燃料+110[-] [FF6500]发条-8[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 8,
		},
	},
	GainList = {
		{
			Value = 101,
			Num = 110,
		},
	},
	Tags = {
		567073,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id240] =
{
	Id = 240,
	Name = "食物补给（[45FF00]食物+110[-] [FF6500]发条-8[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 8,
		},
	},
	GainList = {
		{
			Value = 103,
			Num = 110,
		},
	},
	Tags = {
		567074,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id241] =
{
	Id = 241,
	Name = "扩建燃料舱（[45FF00]燃料上限+100[-] [FF6500]发条-13[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 13,
		},
	},
	GainList = {
		{
			Value = 102,
			Num = 100,
		},
	},
	Tags = {
		567076,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id242] =
{
	Id = 242,
	Name = "扩建食物舱（[45FF00]食物上限+100[-] [FF6500]发条-13[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 13,
		},
	},
	GainList = {
		{
			Value = 104,
			Num = 100,
		},
	},
	Tags = {
		567077,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id243] =
{
	Id = 243,
	Name = "高级挑战（[45FF00]不降低友好度[-]）",
	Type = "Challenge",
	ChallengeId = 148145,
	Win = {
		{
			Value = 101,
			Num = 70,
		},
		{
			Value = 770001,
			Num = 5,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -70,
		},
	},
	Tags = {
		567078,
		567003,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id244] =
{
	Id = 244,
	Name = "进行交易（高级）",
	Type = "Deal",
	DealId = 850004,
	Tags = {
		567079,
		567005,
		567085,
	},
	Dialog = {
		{
			Quest = "大人平时一直这么关心小的们，这次会给您额外折扣的喲。",
			Answer = "进入商店",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id245] =
{
	Id = 245,
	Name = "燃料补给（[45FF00]燃料+120[-] [FF6500]发条-8[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 8,
		},
	},
	GainList = {
		{
			Value = 101,
			Num = 120,
		},
	},
	Tags = {
		567073,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id246] =
{
	Id = 246,
	Name = "食物补给（[45FF00]食物+120[-] [FF6500]发条-8[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 8,
		},
	},
	GainList = {
		{
			Value = 103,
			Num = 120,
		},
	},
	Tags = {
		567074,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id247] =
{
	Id = 247,
	Name = "扩建燃料舱（[45FF00]燃料上限+100[-] [FF6500]发条-11[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 11,
		},
	},
	GainList = {
		{
			Value = 102,
			Num = 100,
		},
	},
	Tags = {
		567076,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id248] =
{
	Id = 248,
	Name = "扩建食物舱（[45FF00]食物上限+100[-] [FF6500]发条-11[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 11,
		},
	},
	GainList = {
		{
			Value = 104,
			Num = 100,
		},
	},
	Tags = {
		567077,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id249] =
{
	Id = 249,
	Name = "最高级挑战(不降低声望)",
	Type = "Challenge",
	ChallengeId = 148117,
	Win = {
		{
			Value = 101,
			Num = 90,
		},
		{
			Value = 770001,
			Num = 8,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -90,
		},
	},
	Tags = {
		567080,
		567003,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id250] =
{
	Id = 250,
	Name = "进行交易（高级）",
	Type = "Deal",
	DealId = 850004,
	Tags = {
		567079,
		567005,
		567085,
	},
	Dialog = {
		{
			Quest = "大人平时一直这么关心小的们，这次会给您额外折扣的喲。",
			Answer = "进入商店",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id251] =
{
	Id = 251,
	Name = "购买超能物体信息（[45FF00]随机宝石+1[-] [FF6500]发条-200[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 200,
		},
	},
	GainList = {
		{
			Value = 773002,
			Num = 1,
		},
	},
	Tags = {
		567081,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id252] =
{
	Id = 252,
	Name = "购买超能物体信息（[45FF00]随机宝石+1[-] [FF6500]发条-200[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 200,
		},
	},
	GainList = {
		{
			Value = 773007,
			Num = 1,
		},
	},
	Tags = {
		567081,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id253] =
{
	Id = 253,
	Name = "燃料补给（[45FF00]燃料+130[-] [FF6500]发条-8[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 8,
		},
	},
	GainList = {
		{
			Value = 101,
			Num = 130,
		},
	},
	Tags = {
		567073,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id254] =
{
	Id = 254,
	Name = "食物补给（[45FF00]食物+130[-] [FF6500]发条-8[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 8,
		},
	},
	GainList = {
		{
			Value = 103,
			Num = 130,
		},
	},
	Tags = {
		567074,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id255] =
{
	Id = 255,
	Name = "扩建燃料舱（[45FF00]燃料上限+100[-] [FF6500]发条-9[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 9,
		},
	},
	GainList = {
		{
			Value = 102,
			Num = 100,
		},
	},
	Tags = {
		567076,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id256] =
{
	Id = 256,
	Name = "扩建食物舱（[45FF00]食物上限+100[-] [FF6500]发条-9[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 9,
		},
	},
	GainList = {
		{
			Value = 104,
			Num = 100,
		},
	},
	Tags = {
		567077,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id257] =
{
	Id = 257,
	Name = "杀出重围",
	Type = "Challenge",
	ChallengeId = 148154,
	Win = {
		{
			Value = 101,
			Num = 70,
		},
		{
			Value = 770001,
			Num = 5,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -70,
		},
	},
	Tags = {
		567082,
		567003,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id258] =
{
	Id = 258,
	Name = "尝试谈判",
	Type = "Chat",
	ChatId = 840088,
	Win = {
		{
			Value = 103,
			Num = 40,
		},
	},
	Lose = {
		{
			Value = 101,
			Num = -40,
		},
	},
	Retreat = {
		{
			Value = 101,
			Num = -40,
		},
	},
	Tags = {
		567065,
		567004,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id259] =
{
	Id = 259,
	Name = "赠送礼物（[FF6500]发条-25[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 25,
			Hint = "需要25个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 25,
		},
	},
	GainList = {
		{
			Value = 780002,
			Num = 25,
		},
	},
	Win = {
		{
			Num = 40,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id260] =
{
	Id = 260,
	Name = "赠送礼物（[FF6500]陨铁-15[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 15,
		},
	},
	GainList = {
		{
			Value = 780002,
			Num = 25,
		},
	},
	Win = {
		{
			Num = 40,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id261] =
{
	Id = 261,
	Name = "赠送礼物（[FF6500]贝壳石-10[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
	},
	GainList = {
		{
			Value = 780002,
			Num = 25,
		},
	},
	Win = {
		{
			Num = 40,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id262] =
{
	Id = 262,
	Name = "赠送礼物（[FF6500]高能矿石-5[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 5,
		},
	},
	GainList = {
		{
			Value = 780002,
			Num = 25,
		},
	},
	Win = {
		{
			Num = 40,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id263] =
{
	Id = 263,
	Name = "赠送礼物（[FF6500]元素石-8[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 8,
		},
	},
	GainList = {
		{
			Value = 780002,
			Num = 25,
		},
	},
	Win = {
		{
			Num = 40,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id264] =
{
	Id = 264,
	Name = "挑衅对方",
	Type = "Challenge",
	ChallengeId = 148163,
	Win = {
		{
			Value = 101,
			Num = 50,
		},
		{
			Value = 770001,
			Num = 3,
		},
		{
			Value = 780002,
			Num = -20,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -50,
		},
		{
			Value = 780002,
			Num = -20,
		},
	},
	Tags = {
		567083,
		567003,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id265] =
{
	Id = 265,
	Name = "尝试谈判",
	Type = "Chat",
	ChatId = 840082,
	Win = {
		{
			Value = 103,
			Num = 40,
		},
	},
	Lose = {
		{
			Value = 101,
			Num = -40,
		},
	},
	Retreat = {
		{
			Value = 101,
			Num = -40,
		},
	},
	Tags = {
		567065,
		567004,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id266] =
{
	Id = 266,
	Name = "赠送礼物（[FF6500]发条-20[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 20,
			Hint = "需要20个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 20,
		},
	},
	GainList = {
		{
			Value = 780002,
			Num = 25,
		},
	},
	Win = {
		{
			Num = 40,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id267] =
{
	Id = 267,
	Name = "赠送礼物（[FF6500]陨铁-12[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 12,
		},
	},
	GainList = {
		{
			Value = 780002,
			Num = 25,
		},
	},
	Win = {
		{
			Num = 40,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id268] =
{
	Id = 268,
	Name = "赠送礼物（[FF6500]贝壳石-8[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 8,
		},
	},
	GainList = {
		{
			Value = 780002,
			Num = 25,
		},
	},
	Win = {
		{
			Num = 40,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id269] =
{
	Id = 269,
	Name = "赠送礼物（[FF6500]高能矿石-4[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 4,
		},
	},
	GainList = {
		{
			Value = 780002,
			Num = 25,
		},
	},
	Win = {
		{
			Num = 40,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id270] =
{
	Id = 270,
	Name = "赠送礼物（[FF6500]元素石-6[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 6,
		},
	},
	GainList = {
		{
			Value = 780002,
			Num = 25,
		},
	},
	Win = {
		{
			Num = 40,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id271] =
{
	Id = 271,
	Name = "索要补给",
	Type = "Challenge",
	ChallengeId = 148193,
	Win = {
		{
			Value = 101,
			Num = 30,
		},
		{
			Value = 770001,
			Num = 2,
		},
		{
			Value = 780002,
			Num = -20,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -30,
		},
		{
			Value = 780002,
			Num = -20,
		},
	},
	Tags = {
		567070,
		567003,
		567100,
	},
	Dialog = {
		{
			Quest = "别逼我动剑，快滚。",
			Answer = "直接开抢！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id272] =
{
	Id = 272,
	Name = "骗取补给",
	Type = "Chat",
	ChatId = 840076,
	Win = {
		{
			Value = 103,
			Num = 40,
		},
		{
			Value = 780002,
			Num = -10,
		},
	},
	Lose = {
		{
			Value = 101,
			Num = -40,
		},
		{
			Value = 780002,
			Num = -10,
		},
	},
	Retreat = {
		{
			Value = 101,
			Num = -40,
		},
		{
			Value = 780002,
			Num = -10,
		},
	},
	Tags = {
		567071,
		567004,
		567100,
	},
	Dialog = {
		{
			Quest = "如果你能说服我，这里的食物随便你拿。",
			Answer = "准备谈判",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id273] =
{
	Id = 273,
	Name = "赠送礼物（[FF6500]发条-15[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 15,
			Hint = "需要15个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 15,
		},
	},
	GainList = {
		{
			Value = 780002,
			Num = 25,
		},
	},
	Tags = {
		567068,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id274] =
{
	Id = 274,
	Name = "赠送礼物（[FF6500]陨铁-9[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 9,
		},
	},
	GainList = {
		{
			Value = 780002,
			Num = 25,
		},
	},
	Win = {
		{
			Num = 40,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id275] =
{
	Id = 275,
	Name = "赠送礼物（[FF6500]贝壳石-6[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 6,
		},
	},
	GainList = {
		{
			Value = 780002,
			Num = 25,
		},
	},
	Win = {
		{
			Num = 40,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id276] =
{
	Id = 276,
	Name = "赠送礼物（[FF6500]高能矿石-3[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 3,
		},
	},
	GainList = {
		{
			Value = 780002,
			Num = 25,
		},
	},
	Win = {
		{
			Num = 40,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id277] =
{
	Id = 277,
	Name = "赠送礼物（[FF6500]元素石-5[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 5,
		},
	},
	GainList = {
		{
			Value = 780002,
			Num = 25,
		},
	},
	Win = {
		{
			Num = 40,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id278] =
{
	Id = 278,
	Name = "进行初级挑战（[45FF00]不降低友好度[-]）",
	Type = "Challenge",
	ChallengeId = 148183,
	Win = {
		{
			Value = 101,
			Num = 30,
		},
		{
			Value = 770001,
			Num = 2,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -30,
		},
	},
	Tags = {
		567072,
		567003,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id279] =
{
	Id = 279,
	Name = "进行交易",
	Type = "Deal",
	DealId = 850005,
	Tags = {
		567062,
		567005,
		567100,
	},
	Dialog = {
		{
			Quest = "大人开这么高级的飞船，相信平时一定是个豪爽的人。",
			Answer = "进入商店",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id280] =
{
	Id = 280,
	Name = "燃料补给（[45FF00]燃料+100[-] [FF6500]发条-8[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 8,
		},
	},
	GainList = {
		{
			Value = 101,
			Num = 100,
		},
	},
	Tags = {
		567073,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id281] =
{
	Id = 281,
	Name = "食物补给（[45FF00]食物+100[-] [FF6500]发条-8[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 8,
		},
	},
	GainList = {
		{
			Value = 103,
			Num = 100,
		},
	},
	Tags = {
		567074,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id282] =
{
	Id = 282,
	Name = "中级挑战（[45FF00]不降低友好度[-]）",
	Type = "Challenge",
	ChallengeId = 148174,
	Win = {
		{
			Value = 101,
			Num = 50,
		},
		{
			Value = 770001,
			Num = 3,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -50,
		},
	},
	Tags = {
		567075,
		567003,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id283] =
{
	Id = 283,
	Name = "进行交易",
	Type = "Deal",
	DealId = 850005,
	Tags = {
		567062,
		567005,
		567100,
	},
	Dialog = {
		{
			Quest = "大人开这么高级的飞船，相信平时一定是个豪爽的人。",
			Answer = "进入商店",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id284] =
{
	Id = 284,
	Name = "燃料补给（[45FF00]燃料+110[-] [FF6500]发条-8[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 8,
		},
	},
	GainList = {
		{
			Value = 101,
			Num = 110,
		},
	},
	Tags = {
		567073,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id285] =
{
	Id = 285,
	Name = "食物补给（[45FF00]食物+110[-] [FF6500]发条-8[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 8,
		},
	},
	GainList = {
		{
			Value = 103,
			Num = 110,
		},
	},
	Tags = {
		567074,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id286] =
{
	Id = 286,
	Name = "扩建燃料舱（[45FF00]燃料上限+100[-] [FF6500]发条-13[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 13,
		},
	},
	GainList = {
		{
			Value = 102,
			Num = 100,
		},
	},
	Tags = {
		567076,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id287] =
{
	Id = 287,
	Name = "扩建食物舱（[45FF00]食物上限+100[-] [FF6500]发条-13[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 13,
		},
	},
	GainList = {
		{
			Value = 104,
			Num = 100,
		},
	},
	Tags = {
		567077,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id288] =
{
	Id = 288,
	Name = "高级挑战（[45FF00]不降低友好度[-]）",
	Type = "Challenge",
	ChallengeId = 148195,
	Win = {
		{
			Value = 101,
			Num = 70,
		},
		{
			Value = 770001,
			Num = 5,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -70,
		},
	},
	Tags = {
		567078,
		567003,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id289] =
{
	Id = 289,
	Name = "进行交易（高级）",
	Type = "Deal",
	DealId = 850006,
	Tags = {
		567079,
		567005,
		567100,
	},
	Dialog = {
		{
			Quest = "大人平时一直这么关心小的们，这次会给您额外折扣的喲。",
			Answer = "进入商店",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id290] =
{
	Id = 290,
	Name = "燃料补给（[45FF00]燃料+120[-] [FF6500]发条-8[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 8,
		},
	},
	GainList = {
		{
			Value = 101,
			Num = 120,
		},
	},
	Tags = {
		567073,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id291] =
{
	Id = 291,
	Name = "食物补给（[45FF00]食物+120[-] [FF6500]发条-8[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 8,
		},
	},
	GainList = {
		{
			Value = 103,
			Num = 120,
		},
	},
	Tags = {
		567074,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id292] =
{
	Id = 292,
	Name = "扩建燃料舱（[45FF00]燃料上限+100[-] [FF6500]发条-11[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 11,
		},
	},
	GainList = {
		{
			Value = 102,
			Num = 100,
		},
	},
	Tags = {
		567076,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id293] =
{
	Id = 293,
	Name = "扩建食物舱（[45FF00]食物上限+100[-] [FF6500]发条-11[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 11,
		},
	},
	GainList = {
		{
			Value = 104,
			Num = 100,
		},
	},
	Tags = {
		567077,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id294] =
{
	Id = 294,
	Name = "最高级挑战(不降低声望)",
	Type = "Challenge",
	ChallengeId = 148167,
	Win = {
		{
			Value = 101,
			Num = 90,
		},
		{
			Value = 770001,
			Num = 8,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -90,
		},
	},
	Tags = {
		567080,
		567003,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id295] =
{
	Id = 295,
	Name = "进行交易（高级）",
	Type = "Deal",
	DealId = 850006,
	Tags = {
		567079,
		567005,
		567100,
	},
	Dialog = {
		{
			Quest = "大人平时一直这么关心小的们，这次会给您额外折扣的喲。",
			Answer = "进入商店",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id296] =
{
	Id = 296,
	Name = "购买超能物体信息（[45FF00]随机宝石+1[-] [FF6500]发条-200[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 200,
		},
	},
	GainList = {
		{
			Value = 773002,
			Num = 1,
		},
	},
	Tags = {
		567081,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id297] =
{
	Id = 297,
	Name = "购买超能物体信息（[45FF00]随机宝石+1[-] [FF6500]发条-200[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 200,
		},
	},
	GainList = {
		{
			Value = 773007,
			Num = 1,
		},
	},
	Tags = {
		567081,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id298] =
{
	Id = 298,
	Name = "燃料补给（[45FF00]燃料+130[-] [FF6500]发条-8[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 8,
		},
	},
	GainList = {
		{
			Value = 101,
			Num = 130,
		},
	},
	Tags = {
		567073,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id299] =
{
	Id = 299,
	Name = "食物补给（[45FF00]食物+130[-] [FF6500]发条-8[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 8,
		},
	},
	GainList = {
		{
			Value = 103,
			Num = 130,
		},
	},
	Tags = {
		567074,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id300] =
{
	Id = 300,
	Name = "扩建燃料舱（[45FF00]燃料上限+100[-] [FF6500]发条-9[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 9,
		},
	},
	GainList = {
		{
			Value = 102,
			Num = 100,
		},
	},
	Tags = {
		567076,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id301] =
{
	Id = 301,
	Name = "扩建食物舱（[45FF00]食物上限+100[-] [FF6500]发条-9[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 9,
		},
	},
	GainList = {
		{
			Value = 104,
			Num = 100,
		},
	},
	Tags = {
		567077,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id302] =
{
	Id = 302,
	Name = "接取任务：与魔王集团交易（[45FF00]魔王集团声望+10[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 780001,
			Num = 10,
		},
	},
	GoalId = 870001,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id303] =
{
	Id = 303,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id304] =
{
	Id = 304,
	Name = "接取任务：魔王集团竞答（[45FF00]魔王集团声望+10[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 780001,
			Num = 10,
		},
	},
	GoalId = 870002,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id305] =
{
	Id = 305,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id306] =
{
	Id = 306,
	Name = "接取任务：与海盗战斗（[45FF00]发条+2[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 770001,
			Num = 2,
		},
	},
	GoalId = 870003,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id307] =
{
	Id = 307,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id308] =
{
	Id = 308,
	Name = "接取任务：登陆发现（[45FF00]陨铁+1[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 771002,
			Num = 1,
		},
	},
	GoalId = 870004,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id309] =
{
	Id = 309,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id310] =
{
	Id = 310,
	Name = "接取任务：整理船舱（[45FF00]燃料+20[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 101,
			Num = 20,
		},
	},
	GoalId = 870005,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id311] =
{
	Id = 311,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id312] =
{
	Id = 312,
	Name = "接取任务：战斗考验（[45FF00]发条+2[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 770001,
			Num = 2,
		},
	},
	GoalId = 870006,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id313] =
{
	Id = 313,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id314] =
{
	Id = 314,
	Name = "接取任务：驱赶海盗（[45FF00]冒险家协会声望+10[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 780002,
			Num = 10,
		},
	},
	GoalId = 870007,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id315] =
{
	Id = 315,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id316] =
{
	Id = 316,
	Name = "接取任务：谈判专家（[45FF00]食物+20[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 103,
			Num = 20,
		},
	},
	GoalId = 870008,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id317] =
{
	Id = 317,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id318] =
{
	Id = 318,
	Name = "接取任务：矿石收集（[45FF00]发条+2[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 770001,
			Num = 2,
		},
	},
	GoalId = 870009,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id319] =
{
	Id = 319,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id320] =
{
	Id = 320,
	Name = "接取任务：矿石丰收（[45FF00]发条+2[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 770001,
			Num = 2,
		},
	},
	GoalId = 870010,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id321] =
{
	Id = 321,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id322] =
{
	Id = 322,
	Name = "接取任务：圆锯爱好者（[45FF00]发条+2[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 770001,
			Num = 2,
		},
	},
	GoalId = 870011,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id323] =
{
	Id = 323,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id324] =
{
	Id = 324,
	Name = "接取任务：圆锯大师（[45FF00]发条+2[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 770001,
			Num = 2,
		},
	},
	GoalId = 870012,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id325] =
{
	Id = 325,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id326] =
{
	Id = 326,
	Name = "接取任务：购买补给（[45FF00]发条+2[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 770001,
			Num = 2,
		},
	},
	GoalId = 870013,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id327] =
{
	Id = 327,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id328] =
{
	Id = 328,
	Name = "接取任务：补给抄底（[45FF00]发条+2[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 770001,
			Num = 2,
		},
	},
	GoalId = 870014,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id329] =
{
	Id = 329,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id330] =
{
	Id = 330,
	Name = "接取任务：出售发条（[45FF00]发条+2[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 770001,
			Num = 2,
		},
	},
	GoalId = 870015,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id331] =
{
	Id = 331,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id332] =
{
	Id = 332,
	Name = "接取任务：发条抛售（[45FF00]发条+2[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 770001,
			Num = 2,
		},
	},
	GoalId = 870016,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id333] =
{
	Id = 333,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id334] =
{
	Id = 334,
	Name = "接取任务：提交矿石（[45FF00]魔王集团声望+10[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 780001,
			Num = 10,
		},
	},
	GoalId = 870017,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id335] =
{
	Id = 335,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id336] =
{
	Id = 336,
	Name = "接取任务：使用补给（[45FF00]定点前进装置+1[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 770201,
			Num = 1,
		},
	},
	GoalId = 870018,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id337] =
{
	Id = 337,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id338] =
{
	Id = 338,
	Name = "接取任务：艺术品",
	Type = "Goal",
	GoalId = 870019,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id339] =
{
	Id = 339,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id340] =
{
	Id = 340,
	Name = "接取任务：星海航行（[45FF00]燃料+10[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 101,
			Num = 10,
		},
	},
	GoalId = 870020,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id341] =
{
	Id = 341,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id342] =
{
	Id = 342,
	Name = "接取任务：快速航行（[45FF00]燃料+10[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 101,
			Num = 10,
		},
	},
	GoalId = 870021,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id343] =
{
	Id = 343,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id344] =
{
	Id = 344,
	Name = "接取任务：魔王集团友好度（[45FF00]发条+2[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 770001,
			Num = 2,
		},
	},
	GoalId = 870022,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id345] =
{
	Id = 345,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id346] =
{
	Id = 346,
	Name = "接取任务：提升魔王集团友好度（[45FF00]发条+2[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 770001,
			Num = 2,
		},
	},
	GoalId = 870023,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id347] =
{
	Id = 347,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id348] =
{
	Id = 348,
	Name = "接取任务：合成补给（[45FF00]陨铁+1[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 771002,
			Num = 1,
		},
	},
	GoalId = 870024,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id349] =
{
	Id = 349,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id350] =
{
	Id = 350,
	Name = "整理船舱",
	Type = "Command",
	GainList = {
		{
			Value = 770001,
			Num = 2,
		},
	},
	Tags = {
		567012,
		567002,
	},
	Dialog = {
		{
			Quest = "在角落里发现了发条！",
			Answer = "捡走",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id351] =
{
	Id = 351,
	Name = "整理船舱",
	Type = "Command",
	GainList = {
		{
			Value = 101,
			Num = 20,
		},
	},
	Tags = {
		567012,
		567002,
	},
	Dialog = {
		{
			Quest = "发现了仓库里散装的燃料！",
			Answer = "加入燃料舱",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id352] =
{
	Id = 352,
	Name = "整理船舱",
	Type = "Command",
	GainList = {
		{
			Value = 103,
			Num = 20,
		},
	},
	Tags = {
		567012,
		567002,
	},
	Dialog = {
		{
			Quest = "找到了过期的饼干！",
			Answer = "大吃一顿",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id353] =
{
	Id = 353,
	Name = "整理船舱",
	Type = "Challenge",
	ChallengeId = 148093,
	Win = {
		{
			Value = 101,
			Num = 40,
		},
		{
			Value = 770001,
			Num = 2,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -40,
		},
	},
	Tags = {
		567012,
		567003,
		567089,
	},
	Dialog = {
		{
			Quest = "发现外星生物入侵飞船！",
			Answer = "准备战斗！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id354] =
{
	Id = 354,
	Name = "整理船舱",
	Type = "Command",
	GainList = {
		{
			Value = 770001,
			Num = 2,
		},
	},
	Tags = {
		567012,
		567002,
	},
	Dialog = {
		{
			Quest = "在角落里发现了发条！",
			Answer = "捡走",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id355] =
{
	Id = 355,
	Name = "整理船舱",
	Type = "Command",
	GainList = {
		{
			Value = 101,
			Num = 20,
		},
	},
	Tags = {
		567012,
		567002,
	},
	Dialog = {
		{
			Quest = "在用过的燃料罐里发现了燃料！",
			Answer = "加入燃料舱",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id356] =
{
	Id = 356,
	Name = "整理船舱",
	Type = "Command",
	GainList = {
		{
			Value = 103,
			Num = 20,
		},
	},
	Tags = {
		567012,
		567002,
	},
	Dialog = {
		{
			Quest = "在冰箱里发现了没吃完的饼干！",
			Answer = "大吃一顿",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id357] =
{
	Id = 357,
	Name = "整理船舱",
	Type = "Challenge",
	ChallengeId = 148083,
	Win = {
		{
			Value = 101,
			Num = 80,
		},
		{
			Value = 770001,
			Num = 2,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -80,
		},
	},
	Tags = {
		567012,
		567003,
		567089,
	},
	Dialog = {
		{
			Quest = "有一个外星生物入侵了飞船！",
			Answer = "准备战斗！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id358] =
{
	Id = 358,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id359] =
{
	Id = 359,
	Name = "收集信号",
	Type = "Command",
	Tags = {
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id360] =
{
	Id = 360,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id361] =
{
	Id = 361,
	Name = "进入信号站（[FF6500]圆锯 -1[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 771017,
			Num = 1,
			Hint = "需要1个圆锯",
		},
	},
	CostList = {
		{
			Value = 771017,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 771020,
			Num = 1,
		},
		{
			Value = 771018,
			Num = 5,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "使用圆锯打开了信号站的大门，里面已经空无一人。",
			Answer = "前往二楼",
		},
		{
			Quest = "二楼的信号机还在定期向附近发送信号，机箱上插着工作芯片。",
			Answer = "回收工具",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id362] =
{
	Id = 362,
	Name = "探索信号站（[FF6500]照明虫 -1[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 771014,
			Num = 1,
			Hint = "需要1个照明虫",
		},
	},
	CostList = {
		{
			Value = 771014,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 771019,
			Num = 1,
		},
		{
			Value = 771016,
			Num = 3,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "用照明虫点亮了空间站，一楼大厅已经空无一人。",
			Answer = "寻找密室",
		},
		{
			Quest = "发现了藏在海报后面的保险柜，柜门敞开着，里面放着传送装置。",
			Answer = "回收装置",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id363] =
{
	Id = 363,
	Name = "探索附近",
	Type = "Command",
	GainList = {
		{
			Value = 771018,
			Num = 3,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "大家下船伸展了一下腿脚，随便搜索一番后就吵着要回飞船了。",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id364] =
{
	Id = 364,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id365] =
{
	Id = 365,
	Name = "正面作战",
	Type = "Challenge",
	ChallengeId = 148098,
	Win = {
		{
			Value = 101,
			Num = 80,
		},
		{
			Value = 773008,
			Num = 1,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -80,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "目标中有高战斗力海盗，请小心！",
			Answer = "开战",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id366] =
{
	Id = 366,
	Name = "潜入作业点（[FF6500]进入装置 -1[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 771019,
			Num = 1,
			Hint = "进行突击需要1个进入装置",
		},
	},
	CostList = {
		{
			Value = 771019,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773003,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "发现目标区域有大量能量信号。",
			Answer = "搜索信号",
		},
		{
			Quest = "在信号中心发现了一颗能量宝石！",
			Answer = "撤退",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id367] =
{
	Id = 367,
	Name = "撤退",
	Type = "Command",
	Tags = {
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id368] =
{
	Id = 368,
	Name = "大规模开采原石（[FF6500]圆锯 -3[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 771017,
			Num = 3,
			Hint = "大规模开采需要3个圆锯",
		},
	},
	CostList = {
		{
			Value = 771017,
			Num = 3,
		},
	},
	GainList = {
		{
			Value = 771002,
			Num = 8,
		},
		{
			Value = 771003,
			Num = 8,
		},
	},
	Tags = {
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id369] =
{
	Id = 369,
	Name = "开采原石（[FF6500]圆锯 -1[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 771017,
			Num = 1,
			Hint = "开采原石需要1个圆锯",
		},
	},
	CostList = {
		{
			Value = 771017,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 771002,
			Num = 2,
		},
		{
			Value = 771003,
			Num = 2,
		},
	},
	Tags = {
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id370] =
{
	Id = 370,
	Name = "采集数据",
	Type = "Command",
	GainList = {
		{
			Value = 106,
			Num = 100,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "已采集地区数据，不过无法解析信息。",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id371] =
{
	Id = 371,
	Name = "用手刮奖",
	Type = "Command",
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "万岁！中了一等奖，奖金200个发条！",
			Answer = "一夜暴富",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id372] =
{
	Id = 372,
	Name = "用手刮奖",
	Type = "Command",
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "不错哟！中了二等奖，奖金50个发条！",
			Answer = "开心领奖",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id373] =
{
	Id = 373,
	Name = "用手刮奖",
	Type = "Command",
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "还行吧，中了安慰奖，奖金10个发条！",
			Answer = "聊胜于无",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id374] =
{
	Id = 374,
	Name = "用手刮奖",
	Type = "Command",
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "小心地刮开封条，发现第一个字是“谢”…",
			Answer = "撕掉彩票",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id375] =
{
	Id = 375,
	Name = "用脚刮奖",
	Type = "Command",
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "万岁！中了一等奖，奖金200个发条！",
			Answer = "一夜暴富",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id376] =
{
	Id = 376,
	Name = "用脚刮奖",
	Type = "Command",
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "不错哟！中了二等奖，奖金50个发条！",
			Answer = "开心领奖",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id377] =
{
	Id = 377,
	Name = "用脚刮奖",
	Type = "Command",
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "还行吧，中了安慰奖，奖金10个发条！",
			Answer = "聊胜于无",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id378] =
{
	Id = 378,
	Name = "用脚刮奖",
	Type = "Command",
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "小心地刮开封条，发现第一个字是“谢”…",
			Answer = "撕掉彩票",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id379] =
{
	Id = 379,
	Name = "用头刮奖",
	Type = "Command",
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "万岁！中了一等奖，奖金200个发条！",
			Answer = "一夜暴富",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id380] =
{
	Id = 380,
	Name = "用头刮奖",
	Type = "Command",
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "不错哟！中了二等奖，奖金50个发条！",
			Answer = "开心领奖",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id381] =
{
	Id = 381,
	Name = "用头刮奖",
	Type = "Command",
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "还行吧，中了安慰奖，奖金10个发条！",
			Answer = "聊胜于无",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id382] =
{
	Id = 382,
	Name = "用头刮奖",
	Type = "Command",
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "小心地刮开封条，发现第一个字是“谢”…",
			Answer = "撕掉彩票",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id383] =
{
	Id = 383,
	Name = "用手刮奖",
	Type = "Command",
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "万岁！中了一等奖，奖金200个发条！",
			Answer = "一夜暴富",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id384] =
{
	Id = 384,
	Name = "用手刮奖",
	Type = "Command",
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "不错哟！中了二等奖，奖金50个发条！",
			Answer = "开心领奖",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id385] =
{
	Id = 385,
	Name = "用手刮奖",
	Type = "Command",
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "还行吧，中了安慰奖，奖金10个发条！",
			Answer = "聊胜于无",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id386] =
{
	Id = 386,
	Name = "用手刮奖",
	Type = "Command",
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "小心地刮开封条，发现第一个字是“谢”…",
			Answer = "撕掉彩票",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id387] =
{
	Id = 387,
	Name = "用脚刮奖",
	Type = "Command",
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "万岁！中了一等奖，奖金200个发条！",
			Answer = "一夜暴富",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id388] =
{
	Id = 388,
	Name = "用脚刮奖",
	Type = "Command",
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "不错哟！中了二等奖，奖金50个发条！",
			Answer = "开心领奖",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id389] =
{
	Id = 389,
	Name = "用脚刮奖",
	Type = "Command",
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "还行吧，中了安慰奖，奖金10个发条！",
			Answer = "聊胜于无",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id390] =
{
	Id = 390,
	Name = "用脚刮奖",
	Type = "Command",
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "小心地刮开封条，发现第一个字是“谢”…",
			Answer = "撕掉彩票",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id391] =
{
	Id = 391,
	Name = "用头刮奖",
	Type = "Command",
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "万岁！中了一等奖，奖金200个发条！",
			Answer = "一夜暴富",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id392] =
{
	Id = 392,
	Name = "用头刮奖",
	Type = "Command",
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "不错哟！中了二等奖，奖金50个发条！",
			Answer = "开心领奖",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id393] =
{
	Id = 393,
	Name = "用头刮奖",
	Type = "Command",
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "还行吧，中了安慰奖，奖金10个发条！",
			Answer = "聊胜于无",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id394] =
{
	Id = 394,
	Name = "用头刮奖",
	Type = "Command",
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "小心地刮开封条，发现第一个字是“谢”…",
			Answer = "撕掉彩票",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id395] =
{
	Id = 395,
	Name = "协助观光团",
	Type = "Challenge",
	GainList = {
		{
			Value = 770001,
			Num = 5,
		},
	},
	ChallengeId = 148073,
	Win = {
		{
			Value = 101,
			Num = 80,
		},
		{
			Value = 770001,
			Num = 2,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -40,
		},
	},
	Tags = {
		567014,
		567003,
		567089,
	},
	Dialog = {
		{
			Quest = "警告！海盗已强行登陆我方战舰。",
			Answer = "好好教训他们！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id396] =
{
	Id = 396,
	Name = "抢劫观光团",
	Type = "Command",
	CostList = {
		{
			Value = 780010,
			Num = 100,
		},
	},
	GainList = {
		{
			Value = 770001,
			Num = 5,
		},
	},
	Tags = {
		567015,
		567002,
	},
	Dialog = {
		{
			Quest = "对方已将我们的行为记录并上报至联邦总局。",
			Answer = "赶紧离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id397] =
{
	Id = 397,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
	Dialog = {
		{
			Quest = "海盗战舰已取消锁定我方飞艇。",
			Answer = "立刻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id398] =
{
	Id = 398,
	Name = "兑换食物（[45FF00]食物+250[-] [FF6500]燃料-500[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 101,
			Num = 500,
			Hint = "燃料不足300，无法交换",
		},
	},
	CostList = {
		{
			Value = 101,
			Num = 500,
		},
	},
	GainList = {
		{
			Value = 103,
			Num = 250,
		},
	},
	Tags = {
		567016,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id399] =
{
	Id = 399,
	Name = "兑换燃料（[45FF00]燃料+250[-] [FF6500]食物-500[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 103,
			Num = 500,
			Hint = "食物不足300，无法交换",
		},
	},
	CostList = {
		{
			Value = 103,
			Num = 500,
		},
	},
	GainList = {
		{
			Value = 101,
			Num = 250,
		},
	},
	Tags = {
		567017,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id400] =
{
	Id = 400,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
	Dialog = {
		{
			Quest = "你打算离开时，听到流民小声嘀咕，说你真不会做生意。",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id401] =
{
	Id = 401,
	Name = "购买定点装置（[FF6500]发条-5[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 5,
			Hint = "发条不足，无法交易",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 4,
		},
	},
	GainList = {
		{
			Value = 770201,
			Num = 1,
		},
	},
	Tags = {
		567018,
		567002,
	},
	Dialog = {
		{
			Quest = "啊，盒子有点破了，不过东西还是可以用的。",
			Answer = "不是说全新未拆吗？",
		},
		{
			Quest = "那就再便宜一点，只收你4个发条就好啦。",
			Answer = "完成交易",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id402] =
{
	Id = 402,
	Name = "购买定点装置（[FF6500]发条-5[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 5,
			Hint = "发条不足，无法交易",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 4,
		},
	},
	GainList = {
		{
			Value = 770202,
			Num = 1,
		},
	},
	Tags = {
		567018,
		567002,
	},
	Dialog = {
		{
			Quest = "啊，盒子有点破了，不过东西还是可以用的。",
			Answer = "封条呢？",
		},
		{
			Quest = "那就再便宜一点，只收你4个发条就好啦。",
			Answer = "完成交易",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id403] =
{
	Id = 403,
	Name = "购买定点装置（[FF6500]发条-5[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 5,
			Hint = "发条不足，无法交易",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 4,
		},
	},
	GainList = {
		{
			Value = 770203,
			Num = 1,
		},
	},
	Tags = {
		567018,
		567002,
	},
	Dialog = {
		{
			Quest = "啊，盒子有点破了，不过东西还是可以用的。",
			Answer = "没有发票吗？",
		},
		{
			Quest = "那就再便宜一点，只收你4个发条就好啦。",
			Answer = "完成交易",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id404] =
{
	Id = 404,
	Name = "购买定点装置（[FF6500]发条-5[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 5,
			Hint = "发条不足，无法交易",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 4,
		},
	},
	GainList = {
		{
			Value = 770204,
			Num = 1,
		},
	},
	Tags = {
		567018,
		567002,
	},
	Dialog = {
		{
			Quest = "啊，盒子有点破了，不过东西还是可以用的。",
			Answer = "有防伪水印吗？",
		},
		{
			Quest = "那就再便宜一点，只收你4个发条就好啦。",
			Answer = "完成交易",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id405] =
{
	Id = 405,
	Name = "购买定点装置（[FF6500]发条-5[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 5,
			Hint = "发条不足，无法交易",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 4,
		},
	},
	GainList = {
		{
			Value = 770205,
			Num = 1,
		},
	},
	Tags = {
		567018,
		567002,
	},
	Dialog = {
		{
			Quest = "啊，盒子有点破了，不过东西还是可以用的。",
			Answer = "给我看看你的经营证？",
		},
		{
			Quest = "那就再便宜一点，只收你4个发条就好啦。",
			Answer = "完成交易",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id406] =
{
	Id = 406,
	Name = "购买定点装置（[FF6500]发条-5[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 5,
			Hint = "发条不足，无法交易",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 4,
		},
	},
	GainList = {
		{
			Value = 770206,
			Num = 1,
		},
	},
	Tags = {
		567018,
		567002,
	},
	Dialog = {
		{
			Quest = "啊，盒子有点破了，不过东西还是可以用的。",
			Answer = "盒子这么破，你不太想买",
		},
		{
			Quest = "那就再便宜一点，只收你4个发条就好啦。",
			Answer = "完成交易",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id407] =
{
	Id = 407,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id408] =
{
	Id = 408,
	Name = "借出圆锯（[45FF00]发条+1[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 771017,
			Num = 1,
			Hint = "没有圆锯，无法提供",
		},
	},
	GainList = {
		{
			Value = 771017,
			Num = 1,
		},
		{
			Value = 770001,
			Num = 2,
		},
	},
	Tags = {
		567019,
		567002,
	},
	Dialog = {
		{
			Quest = "对方已收到圆锯，不过修理失败，对方飞船已报废。",
			Answer = "…",
		},
		{
			Quest = "对方给了我们2个发条，希望我们不要把事情说出去。",
			Answer = "答应他",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id409] =
{
	Id = 409,
	Name = "提供氧气瓶（[45FF00]发条+12[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 771016,
			Num = 1,
			Hint = "没有氧气瓶，无法提供",
		},
	},
	CostList = {
		{
			Value = 771016,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 770001,
			Num = 15,
		},
	},
	Tags = {
		567020,
		567002,
	},
	Dialog = {
		{
			Quest = "对方已收到氧气瓶，正在进行舰外作业，不过修理失败，飞船彻底报废了。",
			Answer = "…",
		},
		{
			Quest = "对方给了我们15个发条，希望我们不要把事情说出去。",
			Answer = "答应他",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id410] =
{
	Id = 410,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id411] =
{
	Id = 411,
	Name = "提供进入装置（[FF6500]进入装置 -1[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 771019,
			Num = 1,
			Hint = "需要进入装置1个",
		},
	},
	CostList = {
		{
			Value = 771019,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773022,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "已启动进入装置，对方成功进入飞船。",
			Answer = "祝你好运",
		},
		{
			Quest = "对方表示非常感谢，向我们发送了一颗能量宝石。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id412] =
{
	Id = 412,
	Name = "提供圆锯（[FF6500]圆锯 -3[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 771017,
			Num = 3,
			Hint = "需要圆锯3个",
		},
	},
	CostList = {
		{
			Value = 771017,
			Num = 3,
		},
	},
	GainList = {
		{
			Value = 770001,
			Num = 35,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "飞船舱门极其坚固，对方锯断了3个圆锯后，舱门才勉强打开。",
			Answer = "…",
		},
		{
			Quest = "对方表示非常感谢，按照市价少许多一丢丢支付了圆锯的费用。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id413] =
{
	Id = 413,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id414] =
{
	Id = 414,
	Name = "强行通过（[FF6500]燃料-200[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 101,
			Num = 200,
		},
	},
	GainList = {
		{
			Value = 771001,
			Num = 4,
		},
	},
	Tags = {
		567021,
		567002,
	},
	Dialog = {
		{
			Quest = "已通过陨石带，飞船急需修理。",
			Answer = "修理飞船",
		},
		{
			Quest = "飞船初步修理完毕，已回收陨石碎片。",
			Answer = "回收陨铁",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id415] =
{
	Id = 415,
	Name = "强行通过（[FF6500]燃料-200[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 101,
			Num = 200,
		},
	},
	GainList = {
		{
			Value = 771001,
			Num = 6,
		},
	},
	Tags = {
		567021,
		567002,
	},
	Dialog = {
		{
			Quest = "已通过陨石带，飞船急需修理。",
			Answer = "修理飞船",
		},
		{
			Quest = "飞船初步修理完毕，已回收陨石碎片。",
			Answer = "回收陨铁",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id416] =
{
	Id = 416,
	Name = "强行通过（[FF6500]燃料-200[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 101,
			Num = 200,
		},
	},
	GainList = {
		{
			Value = 771001,
			Num = 8,
		},
	},
	Tags = {
		567021,
		567002,
	},
	Dialog = {
		{
			Quest = "已通过陨石带，飞船急需修理。",
			Answer = "修理飞船",
		},
		{
			Quest = "飞船初步修理完毕，已回收陨石碎片。",
			Answer = "回收陨铁",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id417] =
{
	Id = 417,
	Name = "静静等待（[FF6500]食物-200[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 103,
			Num = 200,
		},
	},
	Tags = {
		567022,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id418] =
{
	Id = 418,
	Name = "使设备降温（[FF6500]贝壳石-3[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 771002,
			Num = 3,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "在冷却装置中加入了贝壳石，飞船可以继续航行了。",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id419] =
{
	Id = 419,
	Name = "替换芯片（[FF6500]万能芯片-1[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 771019,
			Num = 1,
			Hint = "需要工具：万能芯片",
		},
	},
	CostList = {
		{
			Value = 771019,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "替换了故障芯片，飞船可以继续航行了。",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id420] =
{
	Id = 420,
	Name = "晒会太阳（[FF6500]食物-200[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 103,
			Num = 200,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "晒了一阵辐射风暴，大家都说头很晕。",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id421] =
{
	Id = 421,
	Name = "收集定点前进装置",
	Type = "Command",
	GainList = {
		{
			Value = 770204,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "使用机械臂抓取了道具，得到了定点前进装置4型",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id422] =
{
	Id = 422,
	Name = "收集定点前进装置",
	Type = "Command",
	GainList = {
		{
			Value = 770205,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "使用机械臂抓取了道具，得到了定点前进装置5型",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id423] =
{
	Id = 423,
	Name = "收集定点前进装置",
	Type = "Command",
	GainList = {
		{
			Value = 770206,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "使用机械臂抓取了道具，得到了定点前进装置6型",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id424] =
{
	Id = 424,
	Name = "采集空间数据",
	Type = "Command",
	GainList = {
		{
			Value = 106,
			Num = 150,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "采集了大量空间数据，不过不知道怎么用。",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id425] =
{
	Id = 425,
	Name = "帮海盗助威",
	Type = "Command",
	CostList = {
		{
			Value = 780001,
			Num = 50,
		},
	},
	Tags = {
		567023,
		567002,
	},
	Dialog = {
		{
			Quest = "海盗露出了赞许的目光，随后登上魔王飞船并反锁了门。随后，飞船内传来阵阵惨叫声。",
			Answer = "假装听不到，继续出发",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id426] =
{
	Id = 426,
	Name = "殴打海盗",
	Type = "Challenge",
	ChallengeId = 148063,
	Win = {
		{
			Value = 101,
			Num = 80,
		},
		{
			Value = 770001,
			Num = 2,
		},
		{
			Value = 780001,
			Num = 50,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -40,
		},
		{
			Value = 780001,
			Num = 30,
		},
	},
	Tags = {
		567024,
		567003,
		567089,
	},
	Dialog = {
		{
			Quest = "警告！海盗已强行登陆我方战舰。",
			Answer = "开战！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id427] =
{
	Id = 427,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id428] =
{
	Id = 428,
	Name = "提供燃料（[FF6500]燃料-200[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 101,
			Num = 200,
			Hint = "需要200个燃料",
		},
	},
	CostList = {
		{
			Value = 101,
			Num = 200,
		},
	},
	GainList = {
		{
			Value = 780001,
			Num = 100,
		},
	},
	Tags = {
		567025,
		567002,
	},
	Dialog = {
		{
			Quest = "啊，太感谢大人了，小的们终于可以回家了。",
			Answer = "安慰他们后继续出发。",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id429] =
{
	Id = 429,
	Name = "厉声呵斥！",
	Type = "Command",
	CostList = {
		{
			Value = 780001,
			Num = 50,
		},
	},
	Tags = {
		567026,
		567002,
	},
	Dialog = {
		{
			Quest = "给大人添麻烦了，那小的们先告退了。",
			Answer = "继续出发。",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id430] =
{
	Id = 430,
	Name = "趁机打劫",
	Type = "Challenge",
	ChallengeId = 148144,
	Win = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 780001,
			Num = -100,
		},
	},
	Retreat = {
		{
			Value = 101,
			Num = -100,
		},
		{
			Value = 780001,
			Num = -100,
		},
	},
	Tags = {
		567027,
		567003,
		567085,
	},
	Dialog = {
		{
			Quest = "大人这是要做什么？小的们要叫啦！",
			Answer = "你叫破喉咙也没有人会来的！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id431] =
{
	Id = 431,
	Name = "协助勇者",
	Type = "Challenge",
	ChallengeId = 148053,
	Win = {
		{
			Value = 101,
			Num = 80,
		},
		{
			Value = 770001,
			Num = 2,
		},
		{
			Value = 780002,
			Num = 50,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -40,
		},
		{
			Value = 780002,
			Num = 30,
		},
	},
	Tags = {
		567028,
		567003,
		567089,
	},
	Dialog = {
		{
			Quest = "果然是有胆有谋的好汉，那这个任务就交给你了。",
			Answer = "立刻去歼灭海盗！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id432] =
{
	Id = 432,
	Name = "婉言谢绝",
	Type = "Command",
	CostList = {
		{
			Value = 780002,
			Num = 50,
		},
	},
	Tags = {
		567029,
		567002,
	},
	Dialog = {
		{
			Quest = "真是不上路啊，那我们的作战经费你总要出点吧？",
			Answer = "再次谢绝。",
		},
		{
			Quest = "哎，最近的民众越来越不配合勇者的事业了。",
			Answer = "赶紧离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id433] =
{
	Id = 433,
	Name = "燃料支援（[FF6500]燃料-200[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 101,
			Num = 200,
			Hint = "需要200个燃料",
		},
	},
	CostList = {
		{
			Value = 101,
			Num = 200,
		},
	},
	Tags = {
		567030,
		567002,
	},
	Dialog = {
		{
			Quest = "勇者拍了拍我们的肩膀，口头表扬了我们2小时。",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id434] =
{
	Id = 434,
	Name = "提供食物（[FF6500]食物-200[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 103,
			Num = 200,
			Hint = "需要200个燃料",
		},
	},
	CostList = {
		{
			Value = 103,
			Num = 200,
		},
	},
	Tags = {
		567031,
		567002,
	},
	Dialog = {
		{
			Quest = "唔，虽然都是速冻食品，不过味道还不错。",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id435] =
{
	Id = 435,
	Name = "厉声呵斥",
	Type = "Command",
	CostList = {
		{
			Value = 780002,
			Num = 50,
		},
	},
	Tags = {
		567032,
		567002,
	},
	Dialog = {
		{
			Quest = "看在你们人多的份上，今天就算了，下次别让我遇见你！",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id436] =
{
	Id = 436,
	Name = "趁机打劫",
	Type = "Challenge",
	ChallengeId = 148174,
	Win = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 780002,
			Num = -100,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -100,
		},
		{
			Value = 780002,
			Num = -100,
		},
	},
	Tags = {
		567027,
		567003,
		567100,
	},
	Dialog = {
		{
			Quest = "嗯！光天化日你竟然敢打劫我们！",
			Answer = "速战速决！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id437] =
{
	Id = 437,
	Name = "追尾不对！（声援魔王集团）",
	Type = "Chat",
	ChatId = 840081,
	Win = {
		{
			Value = 103,
			Num = 80,
		},
		{
			Value = 780001,
			Num = 50,
		},
		{
			Value = 780002,
			Num = -50,
		},
	},
	Lose = {
		{
			Value = 101,
			Num = -40,
		},
		{
			Value = 780001,
			Num = 50,
		},
		{
			Value = 780002,
			Num = -50,
		},
	},
	Retreat = {
		{
			Value = 101,
			Num = -40,
		},
		{
			Value = 780001,
			Num = 50,
		},
		{
			Value = 780002,
			Num = -50,
		},
	},
	Tags = {
		567033,
		567004,
		567100,
	},
	Dialog = {
		{
			Quest = "勇者们很不高兴，要求与你好好讨论讨论。",
			Answer = "谈判",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id438] =
{
	Id = 438,
	Name = "急刹不对！（声援冒险家协会）",
	Type = "Chat",
	ChatId = 840022,
	Win = {
		{
			Value = 103,
			Num = 80,
		},
		{
			Value = 780002,
			Num = 50,
		},
		{
			Value = 780001,
			Num = -50,
		},
	},
	Lose = {
		{
			Value = 101,
			Num = -40,
		},
		{
			Value = 780002,
			Num = 50,
		},
		{
			Value = 780001,
			Num = -50,
		},
	},
	Retreat = {
		{
			Value = 101,
			Num = -40,
		},
		{
			Value = 780002,
			Num = 50,
		},
		{
			Value = 780001,
			Num = -50,
		},
	},
	Tags = {
		567034,
		567004,
		567085,
	},
	Dialog = {
		{
			Quest = "骨头兵们很不高兴，说今天要和你好好讨论讨论。",
			Answer = "谈判",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id439] =
{
	Id = 439,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id440] =
{
	Id = 440,
	Name = "殴打骨头兵（协助冒险家协会）",
	Type = "Challenge",
	ChallengeId = 148133,
	Win = {
		{
			Value = 101,
			Num = 80,
		},
		{
			Value = 770001,
			Num = 2,
		},
		{
			Value = 780002,
			Num = 100,
		},
		{
			Value = 780001,
			Num = -100,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -40,
		},
		{
			Value = 780002,
			Num = 50,
		},
		{
			Value = 780001,
			Num = -50,
		},
	},
	Tags = {
		567035,
		567003,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id441] =
{
	Id = 441,
	Name = "殴打勇者（协助魔王集团）",
	Type = "Challenge",
	ChallengeId = 148173,
	Win = {
		{
			Value = 101,
			Num = 80,
		},
		{
			Value = 770001,
			Num = 2,
		},
		{
			Value = 780001,
			Num = 100,
		},
		{
			Value = 780002,
			Num = -100,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -40,
		},
		{
			Value = 780001,
			Num = 50,
		},
		{
			Value = 780002,
			Num = -50,
		},
	},
	Tags = {
		567036,
		567003,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id442] =
{
	Id = 442,
	Name = "绕过去",
	Type = "Command",
	Tags = {
		567037,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id443] =
{
	Id = 443,
	Name = "副本非常有趣，游玩体验极佳！",
	Type = "Command",
	CostList = {
		{
			Value = 780001,
			Num = 10,
		},
	},
	Tags = {
		567002,
		567087,
		567085,
	},
	Dialog = {
		{
			Quest = "回答错误…",
			Answer = "悻悻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id444] =
{
	Id = 444,
	Name = "精致的服务体验，让人欲罢不能！",
	Type = "Command",
	CostList = {
		{
			Value = 780001,
			Num = 10,
		},
	},
	Tags = {
		567002,
		567087,
		567085,
	},
	Dialog = {
		{
			Quest = "回答错误…",
			Answer = "悻悻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id445] =
{
	Id = 445,
	Name = "因为太受欢迎，所以项目排队时间太长。",
	Type = "Command",
	GainList = {
		{
			Value = 780001,
			Num = 20,
		},
		{
			Value = 770001,
			Num = 5,
		},
	},
	Tags = {
		567002,
		567087,
		567085,
		567088,
	},
	Dialog = {
		{
			Quest = "完全正确！",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id446] =
{
	Id = 446,
	Name = "光元素！",
	Type = "Command",
	CostList = {
		{
			Value = 780001,
			Num = 10,
		},
	},
	Tags = {
		567002,
		567087,
		567085,
	},
	Dialog = {
		{
			Quest = "回答错误…",
			Answer = "悻悻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id447] =
{
	Id = 447,
	Name = "神秘又惹人遐想的暗元素！",
	Type = "Command",
	GainList = {
		{
			Value = 780001,
			Num = 20,
		},
		{
			Value = 770001,
			Num = 5,
		},
	},
	Tags = {
		567002,
		567087,
		567085,
		567088,
	},
	Dialog = {
		{
			Quest = "完全正确！",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id448] =
{
	Id = 448,
	Name = "太合适了，完全就是用户需求！",
	Type = "Command",
	GainList = {
		{
			Value = 780001,
			Num = 30,
		},
		{
			Value = 770001,
			Num = 5,
		},
	},
	Tags = {
		567002,
		567087,
		567085,
		567088,
	},
	Dialog = {
		{
			Quest = "完全正确！",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id449] =
{
	Id = 449,
	Name = "价格不贵的话，我可以接受。",
	Type = "Command",
	GainList = {
		{
			Value = 780001,
			Num = 15,
		},
		{
			Value = 770001,
			Num = 2,
		},
	},
	Tags = {
		567002,
		567087,
		567085,
		567088,
	},
	Dialog = {
		{
			Quest = "有点道理。",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id450] =
{
	Id = 450,
	Name = "魔王集团在骗钱。",
	Type = "Command",
	CostList = {
		{
			Value = 780001,
			Num = 20,
		},
	},
	Tags = {
		567002,
		567087,
		567085,
	},
	Dialog = {
		{
			Quest = "回答错误…",
			Answer = "悻悻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id451] =
{
	Id = 451,
	Name = "在远处欣赏",
	Type = "Command",
	CostList = {
		{
			Value = 780001,
			Num = 10,
		},
	},
	Tags = {
		567002,
		567087,
		567085,
	},
	Dialog = {
		{
			Quest = "回答错误…",
			Answer = "悻悻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id452] =
{
	Id = 452,
	Name = "过去帮忙",
	Type = "Command",
	CostList = {
		{
			Value = 780001,
			Num = 10,
		},
	},
	Tags = {
		567002,
		567087,
		567085,
	},
	Dialog = {
		{
			Quest = "回答错误…",
			Answer = "悻悻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id453] =
{
	Id = 453,
	Name = "一脚踢烂",
	Type = "Command",
	GainList = {
		{
			Value = 780001,
			Num = 20,
		},
	},
	Tags = {
		567002,
		567087,
		567085,
		567088,
	},
	Dialog = {
		{
			Quest = "完全正确！",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id454] =
{
	Id = 454,
	Name = "救他前往最近的空间站",
	Type = "Command",
	CostList = {
		{
			Value = 780001,
			Num = 20,
		},
	},
	Tags = {
		567002,
		567087,
		567085,
	},
	Dialog = {
		{
			Quest = "回答错误…",
			Answer = "悻悻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id455] =
{
	Id = 455,
	Name = "视而不见",
	Type = "Command",
	CostList = {
		{
			Value = 780001,
			Num = 10,
		},
	},
	Tags = {
		567002,
		567087,
		567085,
	},
	Dialog = {
		{
			Quest = "回答错误…",
			Answer = "悻悻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id456] =
{
	Id = 456,
	Name = "抢光他的东西",
	Type = "Command",
	GainList = {
		{
			Value = 780001,
			Num = 20,
		},
	},
	Tags = {
		567002,
		567087,
		567085,
		567088,
	},
	Dialog = {
		{
			Quest = "完全正确！",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id457] =
{
	Id = 457,
	Name = "一个漂移潇洒离开",
	Type = "Command",
	GainList = {
		{
			Value = 780001,
			Num = 20,
		},
	},
	Tags = {
		567002,
		567087,
		567085,
		567088,
	},
	Dialog = {
		{
			Quest = "完全正确！",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id458] =
{
	Id = 458,
	Name = "打右闪火后减速转弯",
	Type = "Command",
	CostList = {
		{
			Value = 780001,
			Num = 10,
		},
	},
	Tags = {
		567002,
		567087,
		567085,
	},
	Dialog = {
		{
			Quest = "回答错误…",
			Answer = "悻悻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id459] =
{
	Id = 459,
	Name = "摇下车窗看伸手示意转弯",
	Type = "Command",
	CostList = {
		{
			Value = 780001,
			Num = 10,
		},
	},
	Tags = {
		567002,
		567087,
		567085,
	},
	Dialog = {
		{
			Quest = "回答错误…",
			Answer = "悻悻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id460] =
{
	Id = 460,
	Name = "抢居民东西的剑士",
	Type = "Command",
	CostList = {
		{
			Value = 780001,
			Num = 20,
		},
	},
	Tags = {
		567002,
		567087,
		567085,
	},
	Dialog = {
		{
			Quest = "回答错误…",
			Answer = "悻悻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id461] =
{
	Id = 461,
	Name = "偷看精灵洗澡的村长",
	Type = "Command",
	CostList = {
		{
			Value = 780001,
			Num = 20,
		},
	},
	Tags = {
		567002,
		567087,
		567085,
	},
	Dialog = {
		{
			Quest = "回答错误…",
			Answer = "悻悻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id462] =
{
	Id = 462,
	Name = "做事认真负责的小魔王大人",
	Type = "Command",
	GainList = {
		{
			Value = 780001,
			Num = 20,
		},
	},
	Tags = {
		567002,
		567087,
		567085,
		567088,
	},
	Dialog = {
		{
			Quest = "完全正确！",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id463] =
{
	Id = 463,
	Name = "幻想的舞曲",
	Type = "Command",
	GainList = {
		{
			Value = 780001,
			Num = 20,
		},
	},
	Tags = {
		567002,
		567087,
		567085,
		567088,
	},
	Dialog = {
		{
			Quest = "完全正确！",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id464] =
{
	Id = 464,
	Name = "英雄之证",
	Type = "Command",
	CostList = {
		{
			Value = 780001,
			Num = 20,
		},
	},
	Tags = {
		567002,
		567087,
		567085,
	},
	Dialog = {
		{
			Quest = "回答错误…",
			Answer = "悻悻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id465] =
{
	Id = 465,
	Name = "MEGALOVANIA",
	Type = "Command",
	CostList = {
		{
			Value = 780001,
			Num = 20,
		},
	},
	Tags = {
		567002,
		567087,
		567085,
	},
	Dialog = {
		{
			Quest = "回答错误…",
			Answer = "悻悻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id466] =
{
	Id = 466,
	Name = "Kupa",
	Type = "Command",
	GainList = {
		{
			Value = 780001,
			Num = 20,
		},
	},
	Tags = {
		567002,
		567087,
		567085,
		567088,
	},
	Dialog = {
		{
			Quest = "完全正确！",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id467] =
{
	Id = 467,
	Name = "Kuba",
	Type = "Command",
	Tags = {
		567002,
		567087,
		567085,
	},
	Dialog = {
		{
			Quest = "回答错误…",
			Answer = "悻悻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id468] =
{
	Id = 468,
	Name = "Bowser",
	Type = "Command",
	Tags = {
		567002,
		567087,
		567085,
	},
	Dialog = {
		{
			Quest = "回答错误…",
			Answer = "悻悻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id469] =
{
	Id = 469,
	Name = "低级的森林地区",
	Type = "Command",
	CostList = {
		{
			Value = 780001,
			Num = 20,
		},
	},
	Tags = {
		567002,
		567087,
		567085,
	},
	Dialog = {
		{
			Quest = "回答错误…",
			Answer = "悻悻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id470] =
{
	Id = 470,
	Name = "充满危险的沼泽地区",
	Type = "Command",
	GainList = {
		{
			Value = 780001,
			Num = 20,
		},
	},
	Tags = {
		567002,
		567087,
		567085,
		567088,
	},
	Dialog = {
		{
			Quest = "完全正确！",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id471] =
{
	Id = 471,
	Name = "梦幻神秘但租金巨贵的海洋",
	Type = "Command",
	CostList = {
		{
			Value = 780001,
			Num = 20,
		},
	},
	Tags = {
		567002,
		567087,
		567085,
	},
	Dialog = {
		{
			Quest = "回答错误…",
			Answer = "悻悻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id472] =
{
	Id = 472,
	Name = "魔王集团作弊了！",
	Type = "Command",
	GainList = {
		{
			Value = 780002,
			Num = 30,
		},
		{
			Value = 770001,
			Num = 5,
		},
	},
	Tags = {
		567002,
		567087,
		567100,
		567088,
	},
	Dialog = {
		{
			Quest = "完全正确！",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id473] =
{
	Id = 473,
	Name = "居民们上贡的财物还不够多。",
	Type = "Command",
	GainList = {
		{
			Value = 780002,
			Num = 15,
		},
		{
			Value = 770001,
			Num = 2,
		},
	},
	Tags = {
		567002,
		567087,
		567100,
		567088,
	},
	Dialog = {
		{
			Quest = "有点道理。",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id474] =
{
	Id = 474,
	Name = "勇者的打法有问题。",
	Type = "Command",
	CostList = {
		{
			Value = 780002,
			Num = 20,
		},
	},
	Tags = {
		567002,
		567087,
		567100,
	},
	Dialog = {
		{
			Quest = "回答错误…",
			Answer = "悻悻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id475] =
{
	Id = 475,
	Name = "是伟大的冒险者们！",
	Type = "Command",
	GainList = {
		{
			Value = 780002,
			Num = 20,
		},
		{
			Value = 770001,
			Num = 5,
		},
	},
	Tags = {
		567002,
		567087,
		567100,
		567088,
	},
	Dialog = {
		{
			Quest = "完全正确！",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id476] =
{
	Id = 476,
	Name = "不知道是谁…",
	Type = "Command",
	CostList = {
		{
			Value = 780002,
			Num = 20,
		},
	},
	Tags = {
		567002,
		567087,
		567100,
	},
	Dialog = {
		{
			Quest = "回答错误…",
			Answer = "悻悻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id477] =
{
	Id = 477,
	Name = "魔王集团在骗钱！",
	Type = "Command",
	GainList = {
		{
			Value = 780002,
			Num = 30,
		},
		{
			Value = 770001,
			Num = 5,
		},
	},
	Tags = {
		567002,
		567087,
		567100,
		567088,
	},
	Dialog = {
		{
			Quest = "完全正确！",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id478] =
{
	Id = 478,
	Name = "虽然不清楚情况，不过我反对！",
	Type = "Command",
	GainList = {
		{
			Value = 780002,
			Num = 15,
		},
		{
			Value = 770001,
			Num = 2,
		},
	},
	Tags = {
		567002,
		567087,
		567100,
		567088,
	},
	Dialog = {
		{
			Quest = "有点道理。",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id479] =
{
	Id = 479,
	Name = "还是有点道理的。",
	Type = "Command",
	CostList = {
		{
			Value = 780002,
			Num = 20,
		},
	},
	Tags = {
		567002,
		567087,
		567100,
	},
	Dialog = {
		{
			Quest = "回答错误…",
			Answer = "悻悻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id480] =
{
	Id = 480,
	Name = "漂移过弯",
	Type = "Command",
	CostList = {
		{
			Value = 780002,
			Num = 20,
		},
	},
	Tags = {
		567002,
		567087,
		567100,
	},
	Dialog = {
		{
			Quest = "回答错误…",
			Answer = "悻悻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id481] =
{
	Id = 481,
	Name = "打右转灯后减速转弯",
	Type = "Command",
	GainList = {
		{
			Value = 780002,
			Num = 20,
		},
	},
	Tags = {
		567002,
		567087,
		567100,
		567088,
	},
	Dialog = {
		{
			Quest = "完全正确！",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id482] =
{
	Id = 482,
	Name = "伸手到窗外，示意后方要右转",
	Type = "Command",
	CostList = {
		{
			Value = 780002,
			Num = 10,
		},
	},
	Tags = {
		567002,
		567087,
		567100,
	},
	Dialog = {
		{
			Quest = "回答错误…",
			Answer = "悻悻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id483] =
{
	Id = 483,
	Name = "有节奏地打远光灯闪对面的人",
	Type = "Command",
	CostList = {
		{
			Value = 780002,
			Num = 20,
		},
	},
	Tags = {
		567002,
		567087,
		567100,
	},
	Dialog = {
		{
			Quest = "回答错误…",
			Answer = "悻悻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id484] =
{
	Id = 484,
	Name = "把所有灯打开乱闪",
	Type = "Command",
	CostList = {
		{
			Value = 780002,
			Num = 10,
		},
	},
	Tags = {
		567002,
		567087,
		567100,
	},
	Dialog = {
		{
			Quest = "回答错误…",
			Answer = "悻悻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id485] =
{
	Id = 485,
	Name = "打开报警闪光灯，示意避让",
	Type = "Command",
	GainList = {
		{
			Value = 780002,
			Num = 20,
		},
	},
	Tags = {
		567002,
		567087,
		567100,
		567088,
	},
	Dialog = {
		{
			Quest = "完全正确！",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id486] =
{
	Id = 486,
	Name = "提前减速观察、小心驾驶",
	Type = "Command",
	GainList = {
		{
			Value = 780002,
			Num = 20,
		},
	},
	Tags = {
		567002,
		567087,
		567100,
		567088,
	},
	Dialog = {
		{
			Quest = "完全正确！",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id487] =
{
	Id = 487,
	Name = "加大油门，猛冲过去",
	Type = "Command",
	CostList = {
		{
			Value = 780002,
			Num = 20,
		},
	},
	Tags = {
		567002,
		567087,
		567100,
	},
	Dialog = {
		{
			Quest = "回答错误…",
			Answer = "悻悻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id488] =
{
	Id = 488,
	Name = "停在原地不动，等夜深人静时再开",
	Type = "Command",
	CostList = {
		{
			Value = 780002,
			Num = 10,
		},
	},
	Tags = {
		567002,
		567087,
		567100,
	},
	Dialog = {
		{
			Quest = "回答错误…",
			Answer = "悻悻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id489] =
{
	Id = 489,
	Name = "塞尔达",
	Type = "Command",
	CostList = {
		{
			Value = 780002,
			Num = 20,
		},
	},
	Tags = {
		567002,
		567087,
		567100,
	},
	Dialog = {
		{
			Quest = "回答错误…",
			Answer = "悻悻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id490] =
{
	Id = 490,
	Name = "林克",
	Type = "Command",
	GainList = {
		{
			Value = 780002,
			Num = 20,
		},
	},
	Tags = {
		567002,
		567087,
		567100,
		567088,
	},
	Dialog = {
		{
			Quest = "完全正确！",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id491] =
{
	Id = 491,
	Name = "上网找作弊器",
	Type = "Command",
	CostList = {
		{
			Value = 780002,
			Num = 20,
		},
	},
	Tags = {
		567002,
		567087,
		567100,
	},
	Dialog = {
		{
			Quest = "回答错误…",
			Answer = "悻悻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id492] =
{
	Id = 492,
	Name = "练级并强化装备",
	Type = "Command",
	GainList = {
		{
			Value = 780002,
			Num = 20,
		},
	},
	Tags = {
		567002,
		567087,
		567100,
		567088,
	},
	Dialog = {
		{
			Quest = "完全正确！",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id493] =
{
	Id = 493,
	Name = "打劫NPC",
	Type = "Command",
	CostList = {
		{
			Value = 780002,
			Num = 10,
		},
	},
	Tags = {
		567002,
		567087,
		567100,
	},
	Dialog = {
		{
			Quest = "回答错误…",
			Answer = "悻悻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id494] =
{
	Id = 494,
	Name = "力量不够用",
	Type = "Command",
	GainList = {
		{
			Value = 780002,
			Num = 20,
		},
	},
	Tags = {
		567002,
		567087,
		567100,
		567088,
	},
	Dialog = {
		{
			Quest = "完全正确！",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id495] =
{
	Id = 495,
	Name = "脑子不够用",
	Type = "Command",
	CostList = {
		{
			Value = 780002,
			Num = 10,
		},
	},
	Tags = {
		567002,
		567087,
		567100,
	},
	Dialog = {
		{
			Quest = "回答错误…",
			Answer = "悻悻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id496] =
{
	Id = 496,
	Name = "钱不够用",
	Type = "Command",
	CostList = {
		{
			Value = 780002,
			Num = 10,
		},
	},
	Tags = {
		567002,
		567087,
		567100,
	},
	Dialog = {
		{
			Quest = "回答错误…",
			Answer = "悻悻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id497] =
{
	Id = 497,
	Name = "水属性，土能挡水",
	Type = "Command",
	CostList = {
		{
			Value = 780002,
			Num = 10,
		},
	},
	Tags = {
		567002,
		567087,
		567100,
	},
	Dialog = {
		{
			Quest = "回答错误…",
			Answer = "悻悻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id498] =
{
	Id = 498,
	Name = "你骗鬼啊，哪有土属性",
	Type = "Command",
	GainList = {
		{
			Value = 780002,
			Num = 20,
		},
	},
	Tags = {
		567002,
		567087,
		567100,
		567088,
	},
	Dialog = {
		{
			Quest = "完全正确！",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id499] =
{
	Id = 499,
	Name = "火属性，土能灭火",
	Type = "Command",
	CostList = {
		{
			Value = 780002,
			Num = 10,
		},
	},
	Tags = {
		567002,
		567087,
		567100,
	},
	Dialog = {
		{
			Quest = "回答错误…",
			Answer = "悻悻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id500] =
{
	Id = 500,
	Name = "上交给冒险者协会",
	Type = "Command",
	GainList = {
		{
			Value = 780002,
			Num = 20,
		},
	},
	Tags = {
		567002,
		567087,
		567100,
		567088,
	},
	Dialog = {
		{
			Quest = "完全正确！",
			Answer = "继续航行",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id501] =
{
	Id = 501,
	Name = "自己使用",
	Type = "Command",
	CostList = {
		{
			Value = 780002,
			Num = 20,
		},
	},
	Tags = {
		567002,
		567087,
		567100,
	},
	Dialog = {
		{
			Quest = "回答错误…",
			Answer = "悻悻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id502] =
{
	Id = 502,
	Name = "挂到拍卖行",
	Type = "Command",
	CostList = {
		{
			Value = 780002,
			Num = 20,
		},
	},
	Tags = {
		567002,
		567087,
		567100,
	},
	Dialog = {
		{
			Quest = "回答错误…",
			Answer = "悻悻离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id503] =
{
	Id = 503,
	Name = "着陆并探索",
	Type = "Discovery",
	DiscoveryId = 860003,
	Tags = {
		567054,
		567006,
	},
	Dialog = {
		{
			Quest = "经检测，空间站处于废弃状态，建议携带工具进行探索。",
			Answer = "开始探索",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id504] =
{
	Id = 504,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id505] =
{
	Id = 505,
	Name = "着陆并探索",
	Type = "Discovery",
	DiscoveryId = 860003,
	Tags = {
		567054,
		567006,
	},
	Dialog = {
		{
			Quest = "经检测，空间站处于废弃状态，建议携带工具进行探索。",
			Answer = "开始探索",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id506] =
{
	Id = 506,
	Name = "追查特殊信号来源（[FF6500]圆锯 -5[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 771017,
			Num = 5,
			Hint = "需要5个圆锯探索信号来源",
		},
	},
	CostList = {
		{
			Value = 771017,
			Num = 5,
		},
	},
	GainList = {
		{
			Value = 773001,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "已定位到信号来源，发现目标为老式保险箱。",
			Answer = "尝试切割",
		},
		{
			Quest = "消耗了大量圆锯后，终于打开了保险箱，找到了一颗宝石。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id507] =
{
	Id = 507,
	Name = "追查特殊信号来源（[FF6500]圆锯 -5[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 771017,
			Num = 5,
			Hint = "需要5个圆锯探索信号来源",
		},
	},
	CostList = {
		{
			Value = 771017,
			Num = 5,
		},
	},
	GainList = {
		{
			Value = 773006,
			Num = 1,
		},
	},
	Dialog = {
		{
			Quest = "已定位到信号来源，发现目标为老式保险箱。",
			Answer = "尝试切割",
		},
		{
			Quest = "消耗了大量圆锯后，终于打开了保险箱，找到了一颗宝石。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id508] =
{
	Id = 508,
	Name = "追查特殊信号来源（[FF6500]圆锯 -5[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 771017,
			Num = 5,
			Hint = "需要5个圆锯探索信号来源",
		},
	},
	CostList = {
		{
			Value = 771017,
			Num = 5,
		},
	},
	GainList = {
		{
			Value = 773011,
			Num = 1,
		},
	},
	Dialog = {
		{
			Quest = "已定位到信号来源，发现目标为老式保险箱。",
			Answer = "尝试切割",
		},
		{
			Quest = "消耗了大量圆锯后，终于打开了保险箱，找到了一颗宝石。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id509] =
{
	Id = 509,
	Name = "追查特殊信号来源（[FF6500]圆锯 -5[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 771017,
			Num = 5,
			Hint = "需要5个圆锯探索信号来源",
		},
	},
	CostList = {
		{
			Value = 771017,
			Num = 5,
		},
	},
	GainList = {
		{
			Value = 773016,
			Num = 1,
		},
	},
	Dialog = {
		{
			Quest = "已定位到信号来源，发现目标为老式保险箱。",
			Answer = "尝试切割",
		},
		{
			Quest = "消耗了大量圆锯后，终于打开了保险箱，找到了一颗宝石。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id510] =
{
	Id = 510,
	Name = "追查特殊信号来源（[FF6500]圆锯 -5[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 771017,
			Num = 5,
			Hint = "需要5个圆锯探索信号来源",
		},
	},
	CostList = {
		{
			Value = 771017,
			Num = 5,
		},
	},
	GainList = {
		{
			Value = 773021,
			Num = 1,
		},
	},
	Dialog = {
		{
			Quest = "已定位到信号来源，发现目标为老式保险箱。",
			Answer = "尝试切割",
		},
		{
			Quest = "消耗了大量圆锯后，终于打开了保险箱，找到了一颗宝石。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id511] =
{
	Id = 511,
	Name = "追查特殊信号来源（[FF6500]圆锯 -5[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 771017,
			Num = 5,
			Hint = "需要5个圆锯探索信号来源",
		},
	},
	CostList = {
		{
			Value = 771017,
			Num = 5,
		},
	},
	GainList = {
		{
			Value = 773026,
			Num = 1,
		},
	},
	Dialog = {
		{
			Quest = "已定位到信号来源，发现目标为老式保险箱。",
			Answer = "尝试切割",
		},
		{
			Quest = "消耗了大量圆锯后，终于打开了保险箱，找到了一颗宝石。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id512] =
{
	Id = 512,
	Name = "追查特殊信号来源（[FF6500]圆锯 -5[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 771017,
			Num = 5,
			Hint = "需要5个圆锯探索信号来源",
		},
	},
	CostList = {
		{
			Value = 771017,
			Num = 5,
		},
	},
	GainList = {
		{
			Value = 773031,
			Num = 1,
		},
	},
	Dialog = {
		{
			Quest = "已定位到信号来源，发现目标为老式保险箱。",
			Answer = "尝试切割",
		},
		{
			Quest = "消耗了大量圆锯后，终于打开了保险箱，找到了一颗宝石。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id513] =
{
	Id = 513,
	Name = "追查特殊信号来源（[FF6500]圆锯 -5[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 771017,
			Num = 5,
			Hint = "需要5个圆锯探索信号来源",
		},
	},
	CostList = {
		{
			Value = 771017,
			Num = 5,
		},
	},
	GainList = {
		{
			Value = 773036,
			Num = 1,
		},
	},
	Dialog = {
		{
			Quest = "已定位到信号来源，发现目标为老式保险箱。",
			Answer = "尝试切割",
		},
		{
			Quest = "消耗了大量圆锯后，终于打开了保险箱，找到了一颗宝石。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id514] =
{
	Id = 514,
	Name = "追查特殊信号来源（[FF6500]圆锯 -5[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 771017,
			Num = 5,
			Hint = "需要5个圆锯探索信号来源",
		},
	},
	CostList = {
		{
			Value = 771017,
			Num = 5,
		},
	},
	GainList = {
		{
			Value = 773041,
			Num = 1,
		},
	},
	Dialog = {
		{
			Quest = "已定位到信号来源，发现目标为老式保险箱。",
			Answer = "尝试切割",
		},
		{
			Quest = "消耗了大量圆锯后，终于打开了保险箱，找到了一颗宝石。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id515] =
{
	Id = 515,
	Name = "追查特殊信号来源（[FF6500]圆锯 -5[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 771017,
			Num = 5,
			Hint = "需要5个圆锯探索信号来源",
		},
	},
	CostList = {
		{
			Value = 771017,
			Num = 5,
		},
	},
	GainList = {
		{
			Value = 773046,
			Num = 1,
		},
	},
	Dialog = {
		{
			Quest = "已定位到信号来源，发现目标为老式保险箱。",
			Answer = "尝试切割",
		},
		{
			Quest = "消耗了大量圆锯后，终于打开了保险箱，找到了一颗宝石。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id516] =
{
	Id = 516,
	Name = "追查特殊信号来源（[FF6500]圆锯 -5[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 771017,
			Num = 5,
			Hint = "需要5个圆锯探索信号来源",
		},
	},
	CostList = {
		{
			Value = 771017,
			Num = 5,
		},
	},
	GainList = {
		{
			Value = 773051,
			Num = 1,
		},
	},
	Dialog = {
		{
			Quest = "已定位到信号来源，发现目标为老式保险箱。",
			Answer = "尝试切割",
		},
		{
			Quest = "消耗了大量圆锯后，终于打开了保险箱，找到了一颗宝石。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id517] =
{
	Id = 517,
	Name = "追查特殊信号来源（[FF6500]圆锯 -5[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 771017,
			Num = 5,
			Hint = "需要5个圆锯探索信号来源",
		},
	},
	CostList = {
		{
			Value = 771017,
			Num = 5,
		},
	},
	GainList = {
		{
			Value = 773056,
			Num = 1,
		},
	},
	Dialog = {
		{
			Quest = "已定位到信号来源，发现目标为老式保险箱。",
			Answer = "尝试切割",
		},
		{
			Quest = "消耗了大量圆锯后，终于打开了保险箱，找到了一颗宝石。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id518] =
{
	Id = 518,
	Name = "追查特殊信号来源（[FF6500]圆锯 -5[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 771017,
			Num = 5,
			Hint = "需要5个圆锯探索信号来源",
		},
	},
	CostList = {
		{
			Value = 771017,
			Num = 5,
		},
	},
	GainList = {
		{
			Value = 773061,
			Num = 1,
		},
	},
	Dialog = {
		{
			Quest = "已定位到信号来源，发现目标为老式保险箱。",
			Answer = "尝试切割",
		},
		{
			Quest = "消耗了大量圆锯后，终于打开了保险箱，找到了一颗宝石。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id519] =
{
	Id = 519,
	Name = "继续航行",
	Type = "Command",
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id520] =
{
	Id = 520,
	Name = "擒贼先擒王！",
	Type = "Challenge",
	ChallengeId = 148058,
	Win = {
		{
			Value = 101,
			Num = 240,
		},
		{
			Value = 770001,
			Num = 6,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -240,
		},
	},
	Tags = {
		567003,
		567089,
	},
	Dialog = {
		{
			Quest = "还想跑！今天必须好好教训你们一下！",
			Answer = "战斗！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id521] =
{
	Id = 521,
	Name = "擒贼先擒王！",
	Type = "Challenge",
	ChallengeId = 148068,
	Win = {
		{
			Value = 101,
			Num = 240,
		},
		{
			Value = 770001,
			Num = 6,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -240,
		},
	},
	Tags = {
		567003,
		567089,
	},
	Dialog = {
		{
			Quest = "还想跑！今天必须好好教训你们一下！",
			Answer = "战斗！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id522] =
{
	Id = 522,
	Name = "擒贼先擒王！",
	Type = "Challenge",
	ChallengeId = 148078,
	Win = {
		{
			Value = 101,
			Num = 240,
		},
		{
			Value = 770001,
			Num = 6,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -240,
		},
	},
	Tags = {
		567003,
		567089,
	},
	Dialog = {
		{
			Quest = "还想跑！今天必须好好教训你们一下！",
			Answer = "战斗！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id523] =
{
	Id = 523,
	Name = "擒贼先擒王！",
	Type = "Challenge",
	ChallengeId = 148088,
	Win = {
		{
			Value = 101,
			Num = 240,
		},
		{
			Value = 770001,
			Num = 6,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -240,
		},
	},
	Tags = {
		567003,
		567089,
	},
	Dialog = {
		{
			Quest = "还想跑！今天必须好好教训你们一下！",
			Answer = "战斗！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id524] =
{
	Id = 524,
	Name = "擒贼先擒王！",
	Type = "Challenge",
	ChallengeId = 148098,
	Win = {
		{
			Value = 101,
			Num = 240,
		},
		{
			Value = 770001,
			Num = 6,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -240,
		},
	},
	Tags = {
		567003,
		567089,
	},
	Dialog = {
		{
			Quest = "还想跑！今天必须好好教训你们一下！",
			Answer = "战斗！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id525] =
{
	Id = 525,
	Name = "正面突破",
	Type = "Challenge",
	ChallengeId = 148054,
	Win = {
		{
			Value = 101,
			Num = 80,
		},
		{
			Value = 770001,
			Num = 2,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -40,
		},
	},
	Tags = {
		567055,
		567003,
		567089,
	},
	Dialog = {
		{
			Quest = "还想跑！今天必须好好教训你们一下！",
			Answer = "战斗！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id526] =
{
	Id = 526,
	Name = "正面突破",
	Type = "Challenge",
	ChallengeId = 148064,
	Win = {
		{
			Value = 101,
			Num = 80,
		},
		{
			Value = 770001,
			Num = 2,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -40,
		},
	},
	Tags = {
		567055,
		567003,
		567089,
	},
	Dialog = {
		{
			Quest = "还想跑！今天必须好好教训你们一下！",
			Answer = "战斗！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id527] =
{
	Id = 527,
	Name = "正面突破",
	Type = "Challenge",
	ChallengeId = 148074,
	Win = {
		{
			Value = 101,
			Num = 80,
		},
		{
			Value = 770001,
			Num = 2,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -40,
		},
	},
	Tags = {
		567055,
		567003,
		567089,
	},
	Dialog = {
		{
			Quest = "还想跑！今天必须好好教训你们一下！",
			Answer = "战斗！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id528] =
{
	Id = 528,
	Name = "正面突破",
	Type = "Challenge",
	ChallengeId = 148084,
	Win = {
		{
			Value = 101,
			Num = 80,
		},
		{
			Value = 770001,
			Num = 2,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -40,
		},
	},
	Tags = {
		567055,
		567003,
		567089,
	},
	Dialog = {
		{
			Quest = "还想跑！今天必须好好教训你们一下！",
			Answer = "战斗！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id529] =
{
	Id = 529,
	Name = "正面突破",
	Type = "Challenge",
	ChallengeId = 148094,
	Win = {
		{
			Value = 101,
			Num = 80,
		},
		{
			Value = 770001,
			Num = 2,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -40,
		},
	},
	Tags = {
		567055,
		567003,
		567089,
	},
	Dialog = {
		{
			Quest = "还想跑！今天必须好好教训你们一下！",
			Answer = "战斗！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id530] =
{
	Id = 530,
	Name = "交10个发条",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "小朋友很懂事嘛，那就赶紧过去吧。",
			Answer = "赶紧离开",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id531] =
{
	Id = 531,
	Name = "补充燃料（[45FF00]燃料+220[-] [FF6500]发条-20[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 30,
			Hint = "需要30个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 30,
		},
	},
	GainList = {
		{
			Value = 101,
			Num = 300,
		},
	},
	Tags = {
		567057,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id532] =
{
	Id = 532,
	Name = "出售燃料（[45FF00]发条+15[-] [FF6500]燃料-200[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 101,
			Num = 100,
			Hint = "需要100个发条",
		},
	},
	CostList = {
		{
			Value = 101,
			Num = 100,
		},
	},
	GainList = {
		{
			Value = 770001,
			Num = 5,
		},
	},
	Tags = {
		567058,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id533] =
{
	Id = 533,
	Name = "离开",
	Type = "Command",
	Tags = {
		567059,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id534] =
{
	Id = 534,
	Name = "大吃一顿（[45FF00]食物+220[-] [FF6500]发条-20[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
	},
	GainList = {
		{
			Value = 103,
			Num = 100,
		},
	},
	Tags = {
		567060,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id535] =
{
	Id = 535,
	Name = "帮忙洗盘子（[45FF00]食物+100[-]）",
	Type = "Command",
	GainList = {
		{
			Value = 103,
			Num = 10,
		},
	},
	Tags = {
		567061,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id536] =
{
	Id = 536,
	Name = "离开",
	Type = "Command",
	Tags = {
		567059,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id537] =
{
	Id = 537,
	Name = "进行交易",
	Type = "Deal",
	DealId = 850007,
	Tags = {
		567062,
		567005,
	},
	Dialog = {
		{
			Quest = "相信你一定会找到你想要的东西的，客人~",
			Answer = "进入商店",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id538] =
{
	Id = 538,
	Name = "离开",
	Type = "Command",
	Tags = {
		567059,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id539] =
{
	Id = 539,
	Name = "兑换超能物体（[FF6500]能量果实-3[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 771008,
			Num = 3,
		},
	},
	GainList = {
		{
			Value = 773001,
			Num = 1,
		},
	},
	Tags = {
		567063,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id540] =
{
	Id = 540,
	Name = "兑换超能物体（[FF6500]生命果实-3[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 771009,
			Num = 3,
		},
	},
	GainList = {
		{
			Value = 773006,
			Num = 1,
		},
	},
	Tags = {
		567063,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id541] =
{
	Id = 541,
	Name = "升级燃料舱（[45FF00]燃料上限 +300[-] [FF6500]发条 -20[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 20,
			Hint = "需要20个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 20,
		},
	},
	GainList = {
		{
			Value = 102,
			Num = 300,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "搞定啦，客人，怎么样，是不是觉得焕然一新？",
			Answer = "启程出发！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id542] =
{
	Id = 542,
	Name = "升级食物舱（[45FF00]食物上限 +300[-] [FF6500]发条 -20[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 20,
			Hint = "需要20个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 20,
		},
	},
	GainList = {
		{
			Value = 104,
			Num = 300,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "搞定啦，客人，怎么样，是不是觉得焕然一新？",
			Answer = "启程出发！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id543] =
{
	Id = 543,
	Name = "离开",
	Type = "Command",
	Tags = {
		567059,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id544] =
{
	Id = 544,
	Name = "购买随机宝石（[FF6500]发条 -32[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 32,
			Hint = "购买宝石需要32个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 32,
		},
	},
	GainList = {
		{
			Value = 773001,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "嗯，这颗宝石非常适合客人，如果能好好利用的话，航行一定会更顺利的。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id545] =
{
	Id = 545,
	Name = "购买随机宝石（[FF6500]发条 -32[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 32,
			Hint = "购买宝石需要32个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 32,
		},
	},
	GainList = {
		{
			Value = 773006,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "嗯，这颗宝石非常适合客人，如果能好好利用的话，航行一定会更顺利的。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id546] =
{
	Id = 546,
	Name = "购买随机宝石（[FF6500]发条 -32[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 32,
			Hint = "购买宝石需要32个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 32,
		},
	},
	GainList = {
		{
			Value = 773011,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "嗯，这颗宝石非常适合客人，如果能好好利用的话，航行一定会更顺利的。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id547] =
{
	Id = 547,
	Name = "购买随机宝石（[FF6500]发条 -32[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 32,
			Hint = "购买宝石需要32个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 32,
		},
	},
	GainList = {
		{
			Value = 773016,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "嗯，这颗宝石非常适合客人，如果能好好利用的话，航行一定会更顺利的。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id548] =
{
	Id = 548,
	Name = "购买随机宝石（[FF6500]发条 -32[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 32,
			Hint = "购买宝石需要32个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 32,
		},
	},
	GainList = {
		{
			Value = 773021,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "嗯，这颗宝石非常适合客人，如果能好好利用的话，航行一定会更顺利的。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id549] =
{
	Id = 549,
	Name = "购买随机宝石（[FF6500]发条 -32[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 32,
			Hint = "购买宝石需要32个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 32,
		},
	},
	GainList = {
		{
			Value = 773026,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "嗯，这颗宝石非常适合客人，如果能好好利用的话，航行一定会更顺利的。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id550] =
{
	Id = 550,
	Name = "购买随机宝石（[FF6500]发条 -32[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 32,
			Hint = "购买宝石需要32个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 32,
		},
	},
	GainList = {
		{
			Value = 773031,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "嗯，这颗宝石非常适合客人，如果能好好利用的话，航行一定会更顺利的。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id551] =
{
	Id = 551,
	Name = "购买随机宝石（[FF6500]发条 -32[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 32,
			Hint = "购买宝石需要32个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 32,
		},
	},
	GainList = {
		{
			Value = 773036,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "嗯，这颗宝石非常适合客人，如果能好好利用的话，航行一定会更顺利的。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id552] =
{
	Id = 552,
	Name = "购买随机宝石（[FF6500]发条 -32[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 32,
			Hint = "购买宝石需要32个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 32,
		},
	},
	GainList = {
		{
			Value = 773041,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "嗯，这颗宝石非常适合客人，如果能好好利用的话，航行一定会更顺利的。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id553] =
{
	Id = 553,
	Name = "购买随机宝石（[FF6500]发条 -32[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 32,
			Hint = "购买宝石需要32个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 32,
		},
	},
	GainList = {
		{
			Value = 773046,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "嗯，这颗宝石非常适合客人，如果能好好利用的话，航行一定会更顺利的。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id554] =
{
	Id = 554,
	Name = "购买随机宝石（[FF6500]发条 -32[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 32,
			Hint = "购买宝石需要32个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 32,
		},
	},
	GainList = {
		{
			Value = 773051,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "嗯，这颗宝石非常适合客人，如果能好好利用的话，航行一定会更顺利的。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id555] =
{
	Id = 555,
	Name = "购买随机宝石（[FF6500]发条 -32[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 32,
			Hint = "购买宝石需要32个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 32,
		},
	},
	GainList = {
		{
			Value = 773056,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "嗯，这颗宝石非常适合客人，如果能好好利用的话，航行一定会更顺利的。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id556] =
{
	Id = 556,
	Name = "购买随机宝石（[FF6500]发条 -32[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 32,
			Hint = "购买宝石需要32个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 32,
		},
	},
	GainList = {
		{
			Value = 773061,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "嗯，这颗宝石非常适合客人，如果能好好利用的话，航行一定会更顺利的。",
			Answer = "收下",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id557] =
{
	Id = 557,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773001,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773066,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更利于菜鸟队员吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id558] =
{
	Id = 558,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773006,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773071,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更利于菜鸟队员吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id559] =
{
	Id = 559,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773011,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773076,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更利于菜鸟队员吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id560] =
{
	Id = 560,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773016,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773081,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更利于菜鸟队员吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id561] =
{
	Id = 561,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773021,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773086,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更利于菜鸟队员吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id562] =
{
	Id = 562,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773026,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773091,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更利于菜鸟队员吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id563] =
{
	Id = 563,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773031,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773096,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更利于菜鸟队员吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id564] =
{
	Id = 564,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773036,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773101,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更利于菜鸟队员吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id565] =
{
	Id = 565,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773041,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773106,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更利于菜鸟队员吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id566] =
{
	Id = 566,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773046,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773111,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更利于菜鸟队员吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id567] =
{
	Id = 567,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773051,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773116,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更利于菜鸟队员吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id568] =
{
	Id = 568,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773056,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773121,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更利于菜鸟队员吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id569] =
{
	Id = 569,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773061,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773126,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更利于菜鸟队员吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id570] =
{
	Id = 570,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773001,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773131,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更富有进攻性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id571] =
{
	Id = 571,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773006,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773136,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更富有进攻性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id572] =
{
	Id = 572,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773011,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773141,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更富有进攻性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id573] =
{
	Id = 573,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773016,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773146,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更富有进攻性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id574] =
{
	Id = 574,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773021,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773151,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更富有进攻性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id575] =
{
	Id = 575,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773026,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773156,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更富有进攻性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id576] =
{
	Id = 576,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773031,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773161,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更富有进攻性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id577] =
{
	Id = 577,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773036,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773166,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更富有进攻性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id578] =
{
	Id = 578,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773041,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773171,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更富有进攻性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id579] =
{
	Id = 579,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773046,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773176,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更富有进攻性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id580] =
{
	Id = 580,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773051,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773181,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更富有进攻性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id581] =
{
	Id = 581,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773056,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773186,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更富有进攻性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id582] =
{
	Id = 582,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773061,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773191,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更富有进攻性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id583] =
{
	Id = 583,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773001,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773196,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更兼顾防护性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id584] =
{
	Id = 584,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773006,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773201,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更兼顾防护性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id585] =
{
	Id = 585,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773011,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773206,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更兼顾防护性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id586] =
{
	Id = 586,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773016,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773211,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更兼顾防护性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id587] =
{
	Id = 587,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773021,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773216,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更兼顾防护性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id588] =
{
	Id = 588,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773026,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773221,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更兼顾防护性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id589] =
{
	Id = 589,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773031,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773226,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更兼顾防护性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id590] =
{
	Id = 590,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773036,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773231,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更兼顾防护性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id591] =
{
	Id = 591,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773041,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773236,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更兼顾防护性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id592] =
{
	Id = 592,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773046,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773241,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更兼顾防护性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id593] =
{
	Id = 593,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773051,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773246,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更兼顾防护性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id594] =
{
	Id = 594,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773056,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773251,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更兼顾防护性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id595] =
{
	Id = 595,
	Name = "宝石改造（[FF6500]发条 -10[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 10,
			Hint = "改造宝石需要10个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
		{
			Value = 773061,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773256,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "唔，客人的这颗宝石是非常高级的货品呢，那么，让它变得更兼顾防护性吧！",
			Answer = "改造性能",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id596] =
{
	Id = 596,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773001,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773002,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id597] =
{
	Id = 597,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773006,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773007,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id598] =
{
	Id = 598,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773011,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773012,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id599] =
{
	Id = 599,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773016,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773017,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id600] =
{
	Id = 600,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773021,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773022,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id601] =
{
	Id = 601,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773026,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773027,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id602] =
{
	Id = 602,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773031,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773032,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id603] =
{
	Id = 603,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773036,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773037,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id604] =
{
	Id = 604,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773041,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773042,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id605] =
{
	Id = 605,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773046,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773047,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id606] =
{
	Id = 606,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773051,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773052,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id607] =
{
	Id = 607,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773056,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773057,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id608] =
{
	Id = 608,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773061,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773062,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id609] =
{
	Id = 609,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773066,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773002,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id610] =
{
	Id = 610,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773071,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773007,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id611] =
{
	Id = 611,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773076,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773012,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id612] =
{
	Id = 612,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773081,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773017,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id613] =
{
	Id = 613,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773086,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773022,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id614] =
{
	Id = 614,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773091,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773027,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id615] =
{
	Id = 615,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773096,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773032,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id616] =
{
	Id = 616,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773101,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773037,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id617] =
{
	Id = 617,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773106,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773042,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id618] =
{
	Id = 618,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773111,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773047,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id619] =
{
	Id = 619,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773116,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773052,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id620] =
{
	Id = 620,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773121,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773057,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id621] =
{
	Id = 621,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773126,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773062,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id622] =
{
	Id = 622,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773131,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773002,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id623] =
{
	Id = 623,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773136,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773007,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id624] =
{
	Id = 624,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773141,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773012,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id625] =
{
	Id = 625,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773146,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773017,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id626] =
{
	Id = 626,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773151,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773022,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id627] =
{
	Id = 627,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773156,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773027,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id628] =
{
	Id = 628,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773161,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773032,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id629] =
{
	Id = 629,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773166,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773037,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id630] =
{
	Id = 630,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773171,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773042,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id631] =
{
	Id = 631,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773176,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773047,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id632] =
{
	Id = 632,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773181,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773052,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id633] =
{
	Id = 633,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773186,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773057,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id634] =
{
	Id = 634,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773191,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773062,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id635] =
{
	Id = 635,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773196,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773002,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id636] =
{
	Id = 636,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773201,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773007,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id637] =
{
	Id = 637,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773206,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773012,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id638] =
{
	Id = 638,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773211,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773017,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id639] =
{
	Id = 639,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773216,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773022,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id640] =
{
	Id = 640,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773221,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773027,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id641] =
{
	Id = 641,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773226,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773032,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id642] =
{
	Id = 642,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773231,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773037,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id643] =
{
	Id = 643,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773236,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773042,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id644] =
{
	Id = 644,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773241,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773047,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id645] =
{
	Id = 645,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773246,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773052,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id646] =
{
	Id = 646,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773251,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773057,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id647] =
{
	Id = 647,
	Name = "宝石升级（[FF6500]发条 -40[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 40,
			Hint = "升级宝石需要40个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 40,
		},
		{
			Value = 773256,
			Num = 1,
		},
	},
	GainList = {
		{
			Value = 773062,
			Num = 1,
		},
	},
	Tags = {
		567002,
	},
	Dialog = {
		{
			Quest = "哇，客人看来很豪爽呢，既然是升级宝石的话，之前的改造就一并抹掉吧！",
			Answer = "继续升级！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id648] =
{
	Id = 648,
	Name = "离开",
	Type = "Command",
	Tags = {
		567059,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id649] =
{
	Id = 649,
	Name = "与重大霸格进行战斗",
	Type = "Challenge",
	ChallengeId = 148002,
	Win = {
		{
			Value = 773011,
			Num = 1,
		},
		{
			Value = 770001,
			Num = 50,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -1500,
		},
	},
	Tags = {
		567064,
		567003,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id650] =
{
	Id = 650,
	Name = "尝试谈判",
	Type = "Chat",
	ChatId = 840047,
	Win = {
		{
			Value = 101,
			Num = 600,
		},
		{
			Value = 103,
			Num = 600,
		},
	},
	Lose = {
		{
			Value = 101,
			Num = -2500,
		},
	},
	Retreat = {
		{
			Value = 101,
			Num = -1500,
		},
	},
	Tags = {
		567065,
		567004,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id651] =
{
	Id = 651,
	Name = "贿赂重大霸格（[FF6500]发条-500[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 1000,
			Hint = "需要1000个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 1000,
		},
	},
	Tags = {
		567066,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id652] =
{
	Id = 652,
	Name = "进行决斗",
	Type = "Challenge",
	ChallengeId = 148106,
	Win = {
		{
			Value = 101,
			Num = 140,
		},
		{
			Value = 770001,
			Num = 5,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -140,
		},
	},
	Tags = {
		567067,
		567003,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id653] =
{
	Id = 653,
	Name = "尝试谈判",
	Type = "Chat",
	ChatId = 840040,
	Win = {
		{
			Value = 103,
			Num = 80,
		},
	},
	Lose = {
		{
			Value = 101,
			Num = -40,
		},
	},
	Retreat = {
		{
			Value = 101,
			Num = -80,
		},
	},
	Tags = {
		567065,
		567004,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id654] =
{
	Id = 654,
	Name = "赠送礼物（[FF6500]发条-25[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 25,
			Hint = "需要25个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 25,
		},
	},
	GainList = {
		{
			Value = 780001,
			Num = 25,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id655] =
{
	Id = 655,
	Name = "赠送礼物（[FF6500]陨铁-15[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 15,
		},
	},
	GainList = {
		{
			Value = 780001,
			Num = 25,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id656] =
{
	Id = 656,
	Name = "赠送礼物（[FF6500]贝壳石-10[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
	},
	GainList = {
		{
			Value = 780001,
			Num = 25,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id657] =
{
	Id = 657,
	Name = "赠送礼物（[FF6500]高能矿石-5[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 5,
		},
	},
	GainList = {
		{
			Value = 780001,
			Num = 25,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id658] =
{
	Id = 658,
	Name = "赠送礼物（[FF6500]元素石-8[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 8,
		},
	},
	GainList = {
		{
			Value = 780001,
			Num = 25,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id659] =
{
	Id = 659,
	Name = "偷袭对方",
	Type = "Challenge",
	ChallengeId = 148115,
	Win = {
		{
			Value = 101,
			Num = 100,
		},
		{
			Value = 770001,
			Num = 3,
		},
		{
			Value = 780001,
			Num = -20,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -100,
		},
		{
			Value = 780001,
			Num = -20,
		},
	},
	Tags = {
		567069,
		567003,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id660] =
{
	Id = 660,
	Name = "尝试谈判",
	Type = "Chat",
	ChatId = 840034,
	Win = {
		{
			Value = 103,
			Num = 80,
		},
	},
	Lose = {
		{
			Value = 101,
			Num = -40,
		},
	},
	Retreat = {
		{
			Value = 101,
			Num = -80,
		},
	},
	Tags = {
		567065,
		567004,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id661] =
{
	Id = 661,
	Name = "赠送礼物（[FF6500]发条-20[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 20,
			Hint = "需要20个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 20,
		},
	},
	GainList = {
		{
			Value = 780001,
			Num = 25,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id662] =
{
	Id = 662,
	Name = "赠送礼物（[FF6500]陨铁-12[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 12,
		},
	},
	GainList = {
		{
			Value = 780001,
			Num = 25,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id663] =
{
	Id = 663,
	Name = "赠送礼物（[FF6500]贝壳石-8[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 8,
		},
	},
	GainList = {
		{
			Value = 780001,
			Num = 25,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id664] =
{
	Id = 664,
	Name = "赠送礼物（[FF6500]高能矿石-4[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 4,
		},
	},
	GainList = {
		{
			Value = 780001,
			Num = 25,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id665] =
{
	Id = 665,
	Name = "赠送礼物（[FF6500]元素石-6[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 6,
		},
	},
	GainList = {
		{
			Value = 780001,
			Num = 25,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id666] =
{
	Id = 666,
	Name = "索要补给",
	Type = "Challenge",
	ChallengeId = 148145,
	Win = {
		{
			Value = 101,
			Num = 60,
		},
		{
			Value = 770001,
			Num = 2,
		},
		{
			Value = 780001,
			Num = -20,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -60,
		},
		{
			Value = 780001,
			Num = -20,
		},
	},
	Tags = {
		567070,
		567003,
		567085,
	},
	Dialog = {
		{
			Quest = "大人这就是在为难小的们了。",
			Answer = "直接开抢！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id667] =
{
	Id = 667,
	Name = "骗取补给",
	Type = "Chat",
	ChatId = 840028,
	Win = {
		{
			Value = 103,
			Num = 80,
		},
		{
			Value = 780001,
			Num = -10,
		},
	},
	Lose = {
		{
			Value = 101,
			Num = -40,
		},
		{
			Value = 780001,
			Num = -10,
		},
	},
	Retreat = {
		{
			Value = 101,
			Num = -80,
		},
		{
			Value = 780001,
			Num = -10,
		},
	},
	Tags = {
		567071,
		567004,
		567085,
	},
	Dialog = {
		{
			Quest = "大人这么狡猾，小的们一定不是大人的对手。",
			Answer = "挑衅对方！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id668] =
{
	Id = 668,
	Name = "赠送礼物（[FF6500]发条-15[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 15,
			Hint = "需要15个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 15,
		},
	},
	GainList = {
		{
			Value = 780001,
			Num = 25,
		},
	},
	Tags = {
		567068,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id669] =
{
	Id = 669,
	Name = "赠送礼物（[FF6500]陨铁-9[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 9,
		},
	},
	GainList = {
		{
			Value = 780001,
			Num = 25,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id670] =
{
	Id = 670,
	Name = "赠送礼物（[FF6500]贝壳石-6[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 6,
		},
	},
	GainList = {
		{
			Value = 780001,
			Num = 25,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id671] =
{
	Id = 671,
	Name = "赠送礼物（[FF6500]高能矿石-3[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 3,
		},
	},
	GainList = {
		{
			Value = 780001,
			Num = 25,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id672] =
{
	Id = 672,
	Name = "赠送礼物（[FF6500]元素石-5[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 5,
		},
	},
	GainList = {
		{
			Value = 780001,
			Num = 25,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id673] =
{
	Id = 673,
	Name = "进行初级挑战（[45FF00]不降低友好度[-]）",
	Type = "Challenge",
	ChallengeId = 148135,
	Win = {
		{
			Value = 101,
			Num = 60,
		},
		{
			Value = 770001,
			Num = 2,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -60,
		},
	},
	Tags = {
		567072,
		567003,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id674] =
{
	Id = 674,
	Name = "进行交易",
	Type = "Deal",
	DealId = 850009,
	Tags = {
		567062,
		567005,
		567085,
	},
	Dialog = {
		{
			Quest = "大人开这么高级的飞船，相信平时一定是个豪爽的人。",
			Answer = "进入商店",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id675] =
{
	Id = 675,
	Name = "燃料补给（[45FF00]燃料+100[-] [FF6500]发条-8[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 8,
		},
	},
	GainList = {
		{
			Value = 101,
			Num = 100,
		},
	},
	Tags = {
		567073,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id676] =
{
	Id = 676,
	Name = "食物补给（[45FF00]食物+100[-] [FF6500]发条-8[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 8,
		},
	},
	GainList = {
		{
			Value = 103,
			Num = 100,
		},
	},
	Tags = {
		567074,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id677] =
{
	Id = 677,
	Name = "中级挑战（[45FF00]不降低友好度[-]）",
	Type = "Challenge",
	ChallengeId = 148126,
	Win = {
		{
			Value = 101,
			Num = 100,
		},
		{
			Value = 770001,
			Num = 3,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -100,
		},
	},
	Tags = {
		567075,
		567003,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id678] =
{
	Id = 678,
	Name = "进行交易",
	Type = "Deal",
	DealId = 850009,
	Tags = {
		567062,
		567005,
		567085,
	},
	Dialog = {
		{
			Quest = "大人开这么高级的飞船，相信平时一定是个豪爽的人。",
			Answer = "进入商店",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id679] =
{
	Id = 679,
	Name = "燃料补给（[45FF00]燃料+110[-] [FF6500]发条-8[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 8,
		},
	},
	GainList = {
		{
			Value = 101,
			Num = 110,
		},
	},
	Tags = {
		567073,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id680] =
{
	Id = 680,
	Name = "食物补给（[45FF00]食物+110[-] [FF6500]发条-8[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 8,
		},
	},
	GainList = {
		{
			Value = 103,
			Num = 110,
		},
	},
	Tags = {
		567074,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id681] =
{
	Id = 681,
	Name = "扩建燃料舱（[45FF00]燃料上限+100[-] [FF6500]发条-13[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 13,
		},
	},
	GainList = {
		{
			Value = 102,
			Num = 100,
		},
	},
	Tags = {
		567076,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id682] =
{
	Id = 682,
	Name = "扩建食物舱（[45FF00]食物上限+100[-] [FF6500]发条-13[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 13,
		},
	},
	GainList = {
		{
			Value = 104,
			Num = 100,
		},
	},
	Tags = {
		567077,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id683] =
{
	Id = 683,
	Name = "高级挑战（[45FF00]不降低友好度[-]）",
	Type = "Challenge",
	ChallengeId = 148147,
	Win = {
		{
			Value = 101,
			Num = 140,
		},
		{
			Value = 770001,
			Num = 5,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -140,
		},
	},
	Tags = {
		567078,
		567003,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id684] =
{
	Id = 684,
	Name = "进行交易（高级）",
	Type = "Deal",
	DealId = 850010,
	Tags = {
		567079,
		567005,
		567085,
	},
	Dialog = {
		{
			Quest = "大人平时一直这么关心小的们，这次会给您额外折扣的喲。",
			Answer = "进入商店",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id685] =
{
	Id = 685,
	Name = "燃料补给（[45FF00]燃料+120[-] [FF6500]发条-8[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 8,
		},
	},
	GainList = {
		{
			Value = 101,
			Num = 120,
		},
	},
	Tags = {
		567073,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id686] =
{
	Id = 686,
	Name = "食物补给（[45FF00]食物+120[-] [FF6500]发条-8[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 8,
		},
	},
	GainList = {
		{
			Value = 103,
			Num = 120,
		},
	},
	Tags = {
		567074,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id687] =
{
	Id = 687,
	Name = "扩建燃料舱（[45FF00]燃料上限+100[-] [FF6500]发条-11[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 11,
		},
	},
	GainList = {
		{
			Value = 102,
			Num = 100,
		},
	},
	Tags = {
		567076,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id688] =
{
	Id = 688,
	Name = "扩建食物舱（[45FF00]食物上限+100[-] [FF6500]发条-11[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 11,
		},
	},
	GainList = {
		{
			Value = 104,
			Num = 100,
		},
	},
	Tags = {
		567077,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id689] =
{
	Id = 689,
	Name = "最高级挑战(不降低声望)",
	Type = "Challenge",
	ChallengeId = 148119,
	Win = {
		{
			Value = 101,
			Num = 180,
		},
		{
			Value = 770001,
			Num = 8,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -180,
		},
	},
	Tags = {
		567080,
		567003,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id690] =
{
	Id = 690,
	Name = "进行交易（高级）",
	Type = "Deal",
	DealId = 850010,
	Tags = {
		567079,
		567005,
		567085,
	},
	Dialog = {
		{
			Quest = "大人平时一直这么关心小的们，这次会给您额外折扣的喲。",
			Answer = "进入商店",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id691] =
{
	Id = 691,
	Name = "购买超能物体信息（[45FF00]随机宝石+1[-] [FF6500]发条-200[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 200,
		},
	},
	GainList = {
		{
			Value = 773002,
			Num = 1,
		},
	},
	Tags = {
		567081,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id692] =
{
	Id = 692,
	Name = "购买超能物体信息（[45FF00]随机宝石+1[-] [FF6500]发条-200[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 200,
		},
	},
	GainList = {
		{
			Value = 773007,
			Num = 1,
		},
	},
	Tags = {
		567081,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id693] =
{
	Id = 693,
	Name = "燃料补给（[45FF00]燃料+130[-] [FF6500]发条-8[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 8,
		},
	},
	GainList = {
		{
			Value = 101,
			Num = 130,
		},
	},
	Tags = {
		567073,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id694] =
{
	Id = 694,
	Name = "食物补给（[45FF00]食物+130[-] [FF6500]发条-8[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 8,
		},
	},
	GainList = {
		{
			Value = 103,
			Num = 130,
		},
	},
	Tags = {
		567074,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id695] =
{
	Id = 695,
	Name = "扩建燃料舱（[45FF00]燃料上限+100[-] [FF6500]发条-9[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 9,
		},
	},
	GainList = {
		{
			Value = 102,
			Num = 100,
		},
	},
	Tags = {
		567076,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id696] =
{
	Id = 696,
	Name = "扩建食物舱（[45FF00]食物上限+100[-] [FF6500]发条-9[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 9,
		},
	},
	GainList = {
		{
			Value = 104,
			Num = 100,
		},
	},
	Tags = {
		567077,
		567002,
		567085,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id697] =
{
	Id = 697,
	Name = "杀出重围",
	Type = "Challenge",
	ChallengeId = 148156,
	Win = {
		{
			Value = 101,
			Num = 140,
		},
		{
			Value = 770001,
			Num = 5,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -140,
		},
	},
	Tags = {
		567082,
		567003,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id698] =
{
	Id = 698,
	Name = "尝试谈判",
	Type = "Chat",
	ChatId = 840100,
	Win = {
		{
			Value = 103,
			Num = 80,
		},
	},
	Lose = {
		{
			Value = 101,
			Num = -40,
		},
	},
	Retreat = {
		{
			Value = 101,
			Num = -80,
		},
	},
	Tags = {
		567065,
		567004,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id699] =
{
	Id = 699,
	Name = "赠送礼物（[FF6500]发条-25[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 25,
			Hint = "需要25个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 25,
		},
	},
	GainList = {
		{
			Value = 780002,
			Num = 25,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id700] =
{
	Id = 700,
	Name = "赠送礼物（[FF6500]陨铁-15[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 15,
		},
	},
	GainList = {
		{
			Value = 780002,
			Num = 25,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id701] =
{
	Id = 701,
	Name = "赠送礼物（[FF6500]贝壳石-10[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 10,
		},
	},
	GainList = {
		{
			Value = 780002,
			Num = 25,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id702] =
{
	Id = 702,
	Name = "赠送礼物（[FF6500]高能矿石-5[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 5,
		},
	},
	GainList = {
		{
			Value = 780002,
			Num = 25,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id703] =
{
	Id = 703,
	Name = "赠送礼物（[FF6500]元素石-8[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 8,
		},
	},
	GainList = {
		{
			Value = 780002,
			Num = 25,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id704] =
{
	Id = 704,
	Name = "挑衅对方",
	Type = "Challenge",
	ChallengeId = 148165,
	Win = {
		{
			Value = 101,
			Num = 100,
		},
		{
			Value = 770001,
			Num = 3,
		},
		{
			Value = 780002,
			Num = -20,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -100,
		},
		{
			Value = 780002,
			Num = -20,
		},
	},
	Tags = {
		567083,
		567003,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id705] =
{
	Id = 705,
	Name = "尝试谈判",
	Type = "Chat",
	ChatId = 840094,
	Win = {
		{
			Value = 103,
			Num = 80,
		},
	},
	Lose = {
		{
			Value = 101,
			Num = -40,
		},
	},
	Retreat = {
		{
			Value = 101,
			Num = -80,
		},
	},
	Tags = {
		567065,
		567004,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id706] =
{
	Id = 706,
	Name = "赠送礼物（[FF6500]发条-20[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 20,
			Hint = "需要20个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 20,
		},
	},
	GainList = {
		{
			Value = 780002,
			Num = 25,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id707] =
{
	Id = 707,
	Name = "赠送礼物（[FF6500]陨铁-12[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 12,
		},
	},
	GainList = {
		{
			Value = 780002,
			Num = 25,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id708] =
{
	Id = 708,
	Name = "赠送礼物（[FF6500]贝壳石-8[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 8,
		},
	},
	GainList = {
		{
			Value = 780002,
			Num = 25,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id709] =
{
	Id = 709,
	Name = "赠送礼物（[FF6500]高能矿石-4[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 4,
		},
	},
	GainList = {
		{
			Value = 780002,
			Num = 25,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id710] =
{
	Id = 710,
	Name = "赠送礼物（[FF6500]元素石-6[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 6,
		},
	},
	GainList = {
		{
			Value = 780002,
			Num = 25,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id711] =
{
	Id = 711,
	Name = "索要补给",
	Type = "Challenge",
	ChallengeId = 148195,
	Win = {
		{
			Value = 101,
			Num = 60,
		},
		{
			Value = 770001,
			Num = 2,
		},
		{
			Value = 780002,
			Num = -20,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -60,
		},
		{
			Value = 780002,
			Num = -20,
		},
	},
	Tags = {
		567070,
		567003,
		567100,
	},
	Dialog = {
		{
			Quest = "别逼我动剑，快滚。",
			Answer = "直接开抢！",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id712] =
{
	Id = 712,
	Name = "骗取补给",
	Type = "Chat",
	ChatId = 840088,
	Win = {
		{
			Value = 103,
			Num = 80,
		},
		{
			Value = 780002,
			Num = -10,
		},
	},
	Lose = {
		{
			Value = 101,
			Num = -40,
		},
		{
			Value = 780002,
			Num = -10,
		},
	},
	Retreat = {
		{
			Value = 101,
			Num = -80,
		},
		{
			Value = 780002,
			Num = -10,
		},
	},
	Tags = {
		567071,
		567004,
		567100,
	},
	Dialog = {
		{
			Quest = "如果你能说服我，这里的食物随便你拿。",
			Answer = "准备谈判",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id713] =
{
	Id = 713,
	Name = "赠送礼物（[FF6500]发条-15[-]）",
	Type = "Command",
	NeedList = {
		{
			Value = 770001,
			Num = 15,
			Hint = "需要15个发条",
		},
	},
	CostList = {
		{
			Value = 770001,
			Num = 15,
		},
	},
	GainList = {
		{
			Value = 780002,
			Num = 25,
		},
	},
	Tags = {
		567068,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id714] =
{
	Id = 714,
	Name = "赠送礼物（[FF6500]陨铁-9[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 9,
		},
	},
	GainList = {
		{
			Value = 780002,
			Num = 25,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id715] =
{
	Id = 715,
	Name = "赠送礼物（[FF6500]贝壳石-6[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 6,
		},
	},
	GainList = {
		{
			Value = 780002,
			Num = 25,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id716] =
{
	Id = 716,
	Name = "赠送礼物（[FF6500]高能矿石-3[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 3,
		},
	},
	GainList = {
		{
			Value = 780002,
			Num = 25,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id717] =
{
	Id = 717,
	Name = "赠送礼物（[FF6500]元素石-5[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 5,
		},
	},
	GainList = {
		{
			Value = 780002,
			Num = 25,
		},
	},
	Lose = {
		{
			Num = -40,
		},
		{
			Num = -40,
		},
	},
	Tags = {
		567068,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id718] =
{
	Id = 718,
	Name = "进行初级挑战（[45FF00]不降低友好度[-]）",
	Type = "Challenge",
	ChallengeId = 148185,
	Win = {
		{
			Value = 101,
			Num = 60,
		},
		{
			Value = 770001,
			Num = 2,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -60,
		},
	},
	Tags = {
		567072,
		567003,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id719] =
{
	Id = 719,
	Name = "进行交易",
	Type = "Deal",
	DealId = 850011,
	Tags = {
		567062,
		567005,
		567100,
	},
	Dialog = {
		{
			Quest = "大人开这么高级的飞船，相信平时一定是个豪爽的人。",
			Answer = "进入商店",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id720] =
{
	Id = 720,
	Name = "燃料补给（[45FF00]燃料+100[-] [FF6500]发条-8[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 8,
		},
	},
	GainList = {
		{
			Value = 101,
			Num = 100,
		},
	},
	Tags = {
		567073,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id721] =
{
	Id = 721,
	Name = "食物补给（[45FF00]食物+100[-] [FF6500]发条-8[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 8,
		},
	},
	GainList = {
		{
			Value = 103,
			Num = 100,
		},
	},
	Tags = {
		567074,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id722] =
{
	Id = 722,
	Name = "中级挑战（[45FF00]不降低友好度[-]）",
	Type = "Challenge",
	ChallengeId = 148176,
	Win = {
		{
			Value = 101,
			Num = 100,
		},
		{
			Value = 770001,
			Num = 3,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -100,
		},
	},
	Tags = {
		567075,
		567003,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id723] =
{
	Id = 723,
	Name = "进行交易",
	Type = "Deal",
	DealId = 850011,
	Tags = {
		567062,
		567005,
		567100,
	},
	Dialog = {
		{
			Quest = "大人开这么高级的飞船，相信平时一定是个豪爽的人。",
			Answer = "进入商店",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id724] =
{
	Id = 724,
	Name = "燃料补给（[45FF00]燃料+110[-] [FF6500]发条-8[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 8,
		},
	},
	GainList = {
		{
			Value = 101,
			Num = 110,
		},
	},
	Tags = {
		567073,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id725] =
{
	Id = 725,
	Name = "食物补给（[45FF00]食物+110[-] [FF6500]发条-8[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 8,
		},
	},
	GainList = {
		{
			Value = 103,
			Num = 110,
		},
	},
	Tags = {
		567074,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id726] =
{
	Id = 726,
	Name = "扩建燃料舱（[45FF00]燃料上限+100[-] [FF6500]发条-13[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 13,
		},
	},
	GainList = {
		{
			Value = 102,
			Num = 100,
		},
	},
	Tags = {
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id727] =
{
	Id = 727,
	Name = "扩建食物舱（[45FF00]食物上限+100[-] [FF6500]发条-13[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 13,
		},
	},
	GainList = {
		{
			Value = 104,
			Num = 100,
		},
	},
	Tags = {
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id728] =
{
	Id = 728,
	Name = "高级挑战（[45FF00]不降低友好度[-]）",
	Type = "Challenge",
	ChallengeId = 148197,
	Win = {
		{
			Value = 101,
			Num = 140,
		},
		{
			Value = 770001,
			Num = 5,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -140,
		},
	},
	Tags = {
		567078,
		567003,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id729] =
{
	Id = 729,
	Name = "进行交易（高级）",
	Type = "Deal",
	DealId = 850012,
	Tags = {
		567079,
		567005,
		567100,
	},
	Dialog = {
		{
			Quest = "大人平时一直这么关心小的们，这次会给您额外折扣的喲。",
			Answer = "进入商店",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id730] =
{
	Id = 730,
	Name = "燃料补给（[45FF00]燃料+120[-] [FF6500]发条-8[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 8,
		},
	},
	GainList = {
		{
			Value = 101,
			Num = 120,
		},
	},
	Tags = {
		567073,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id731] =
{
	Id = 731,
	Name = "食物补给（[45FF00]食物+120[-] [FF6500]发条-8[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 8,
		},
	},
	GainList = {
		{
			Value = 103,
			Num = 120,
		},
	},
	Tags = {
		567074,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id732] =
{
	Id = 732,
	Name = "扩建燃料舱（[45FF00]燃料上限+100[-] [FF6500]发条-11[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 11,
		},
	},
	GainList = {
		{
			Value = 102,
			Num = 100,
		},
	},
	Tags = {
		567076,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id733] =
{
	Id = 733,
	Name = "扩建食物舱（[45FF00]食物上限+100[-] [FF6500]发条-11[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 11,
		},
	},
	GainList = {
		{
			Value = 104,
			Num = 100,
		},
	},
	Tags = {
		567077,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id734] =
{
	Id = 734,
	Name = "最高级挑战(不降低声望)",
	Type = "Challenge",
	ChallengeId = 148169,
	Win = {
		{
			Value = 101,
			Num = 180,
		},
		{
			Value = 770001,
			Num = 8,
		},
	},
	Retreat = {
		{
			Value = 103,
			Num = -180,
		},
	},
	Tags = {
		567080,
		567003,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id735] =
{
	Id = 735,
	Name = "进行交易（高级）",
	Type = "Deal",
	DealId = 850012,
	Tags = {
		567079,
		567005,
		567100,
	},
	Dialog = {
		{
			Quest = "大人平时一直这么关心小的们，这次会给您额外折扣的喲。",
			Answer = "进入商店",
		},
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id736] =
{
	Id = 736,
	Name = "购买超能物体信息（[45FF00]随机宝石+1[-] [FF6500]发条-200[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 200,
		},
	},
	GainList = {
		{
			Value = 773002,
			Num = 1,
		},
	},
	Tags = {
		567081,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id737] =
{
	Id = 737,
	Name = "购买超能物体信息（[45FF00]随机宝石+1[-] [FF6500]发条-200[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 200,
		},
	},
	GainList = {
		{
			Value = 773007,
			Num = 1,
		},
	},
	Tags = {
		567081,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id738] =
{
	Id = 738,
	Name = "燃料补给（[45FF00]燃料+130[-] [FF6500]发条-8[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 8,
		},
	},
	GainList = {
		{
			Value = 101,
			Num = 130,
		},
	},
	Tags = {
		567073,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id739] =
{
	Id = 739,
	Name = "食物补给（[45FF00]食物+130[-] [FF6500]发条-8[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 8,
		},
	},
	GainList = {
		{
			Value = 103,
			Num = 130,
		},
	},
	Tags = {
		567074,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id740] =
{
	Id = 740,
	Name = "扩建燃料舱（[45FF00]燃料上限+100[-] [FF6500]发条-9[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 9,
		},
	},
	GainList = {
		{
			Value = 102,
			Num = 100,
		},
	},
	Tags = {
		567076,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id741] =
{
	Id = 741,
	Name = "扩建食物舱（[45FF00]食物上限+100[-] [FF6500]发条-9[-]）",
	Type = "Command",
	CostList = {
		{
			Value = 770001,
			Num = 9,
		},
	},
	GainList = {
		{
			Value = 104,
			Num = 100,
		},
	},
	Tags = {
		567077,
		567002,
		567100,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id742] =
{
	Id = 742,
	Name = "接取任务：与魔王集团交易（[45FF00]魔王集团声望+10[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 780001,
			Num = 10,
		},
	},
	GoalId = 870001,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id743] =
{
	Id = 743,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id744] =
{
	Id = 744,
	Name = "接取任务：魔王集团竞答（[45FF00]魔王集团声望+10[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 780001,
			Num = 10,
		},
	},
	GoalId = 870002,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id745] =
{
	Id = 745,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id746] =
{
	Id = 746,
	Name = "接取任务：与海盗战斗（[45FF00]发条+2[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 770001,
			Num = 2,
		},
	},
	GoalId = 870003,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id747] =
{
	Id = 747,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id748] =
{
	Id = 748,
	Name = "接取任务：登陆发现（[45FF00]陨铁+1[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 771002,
			Num = 1,
		},
	},
	GoalId = 870004,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id749] =
{
	Id = 749,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id750] =
{
	Id = 750,
	Name = "接取任务：整理船舱（[45FF00]燃料+20[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 101,
			Num = 20,
		},
	},
	GoalId = 870005,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id751] =
{
	Id = 751,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id752] =
{
	Id = 752,
	Name = "接取任务：战斗考验（[45FF00]发条+2[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 770001,
			Num = 2,
		},
	},
	GoalId = 870006,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id753] =
{
	Id = 753,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id754] =
{
	Id = 754,
	Name = "接取任务：驱赶海盗（[45FF00]冒险家协会声望+10[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 780002,
			Num = 10,
		},
	},
	GoalId = 870007,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id755] =
{
	Id = 755,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id756] =
{
	Id = 756,
	Name = "接取任务：谈判专家（[45FF00]食物+20[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 103,
			Num = 20,
		},
	},
	GoalId = 870008,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id757] =
{
	Id = 757,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id758] =
{
	Id = 758,
	Name = "接取任务：矿石收集（[45FF00]发条+2[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 770001,
			Num = 2,
		},
	},
	GoalId = 870009,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id759] =
{
	Id = 759,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id760] =
{
	Id = 760,
	Name = "接取任务：矿石丰收（[45FF00]发条+2[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 770001,
			Num = 2,
		},
	},
	GoalId = 870010,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id761] =
{
	Id = 761,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id762] =
{
	Id = 762,
	Name = "接取任务：圆锯爱好者（[45FF00]发条+2[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 770001,
			Num = 2,
		},
	},
	GoalId = 870011,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id763] =
{
	Id = 763,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id764] =
{
	Id = 764,
	Name = "接取任务：圆锯大师（[45FF00]发条+2[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 770001,
			Num = 2,
		},
	},
	GoalId = 870012,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id765] =
{
	Id = 765,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id766] =
{
	Id = 766,
	Name = "接取任务：购买补给（[45FF00]发条+2[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 770001,
			Num = 2,
		},
	},
	GoalId = 870013,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id767] =
{
	Id = 767,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id768] =
{
	Id = 768,
	Name = "接取任务：补给抄底（[45FF00]发条+2[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 770001,
			Num = 2,
		},
	},
	GoalId = 870014,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id769] =
{
	Id = 769,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id770] =
{
	Id = 770,
	Name = "接取任务：出售发条（[45FF00]发条+2[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 770001,
			Num = 2,
		},
	},
	GoalId = 870015,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id771] =
{
	Id = 771,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id772] =
{
	Id = 772,
	Name = "接取任务：发条抛售（[45FF00]发条+2[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 770001,
			Num = 2,
		},
	},
	GoalId = 870016,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id773] =
{
	Id = 773,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id774] =
{
	Id = 774,
	Name = "接取任务：提交矿石（[45FF00]魔王集团声望+10[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 780001,
			Num = 10,
		},
	},
	GoalId = 870017,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id775] =
{
	Id = 775,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id776] =
{
	Id = 776,
	Name = "接取任务：使用补给（[45FF00]定点前进装置+1[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 770201,
			Num = 1,
		},
	},
	GoalId = 870018,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id777] =
{
	Id = 777,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id778] =
{
	Id = 778,
	Name = "接取任务：艺术品",
	Type = "Goal",
	GoalId = 870019,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id779] =
{
	Id = 779,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id780] =
{
	Id = 780,
	Name = "接取任务：星海航行（[45FF00]燃料+10[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 101,
			Num = 10,
		},
	},
	GoalId = 870020,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id781] =
{
	Id = 781,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id782] =
{
	Id = 782,
	Name = "接取任务：快速航行（[45FF00]燃料+10[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 101,
			Num = 10,
		},
	},
	GoalId = 870021,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id783] =
{
	Id = 783,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id784] =
{
	Id = 784,
	Name = "接取任务：魔王集团友好度（[45FF00]发条+2[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 770001,
			Num = 2,
		},
	},
	GoalId = 870022,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id785] =
{
	Id = 785,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id786] =
{
	Id = 786,
	Name = "接取任务：提升魔王集团友好度（[45FF00]发条+2[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 770001,
			Num = 2,
		},
	},
	GoalId = 870023,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id787] =
{
	Id = 787,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id788] =
{
	Id = 788,
	Name = "接取任务：合成补给（[45FF00]陨铁+1[-]）",
	Type = "Goal",
	GainList = {
		{
			Value = 771002,
			Num = 1,
		},
	},
	GoalId = 870024,
	Tags = {
		567007,
	},
}
SpaceTravelChoiceConfig[SpaceTravelChoiceID.Id789] =
{
	Id = 789,
	Name = "继续航行",
	Type = "Command",
	Tags = {
		567013,
		567002,
	},
}
