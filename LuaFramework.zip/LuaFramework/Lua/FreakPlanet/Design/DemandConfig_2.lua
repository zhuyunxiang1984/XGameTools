
DemandConfig[DemandID.Id201] =
{
	Id = 201,
	Name = "订购工具箱",
	Desc = "需要大量工具箱",
	Value = 320313,
	Active = true,
	Weight = 7360,
	PreGoal = 
	{
		308157,
	},
	GoodsId = 2200313,
	Num = 18,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 7602,
				},
			},
		},
	},
	DemandID = 410201,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id202] =
{
	Id = 202,
	Name = "0",
	Desc = "0",
	Value = 320314,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308155,
		300852,
	},
	CloseGoal = 
	{
		300880,
	},
	GoodsId = 2200314,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 11767,
				},
			},
		},
	},
	DemandID = 410202,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id203] =
{
	Id = 203,
	Name = "0",
	Desc = "0",
	Value = 320314,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308155,
		300860,
	},
	CloseGoal = 
	{
		300888,
	},
	GoodsId = 2200314,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 11767,
				},
			},
		},
	},
	DemandID = 410203,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id204] =
{
	Id = 204,
	Name = "0",
	Desc = "0",
	Value = 320314,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308155,
		300868,
	},
	CloseGoal = 
	{
		300900,
	},
	GoodsId = 2200314,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 11767,
				},
			},
		},
	},
	DemandID = 410204,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id205] =
{
	Id = 205,
	Name = "0",
	Desc = "0",
	Value = 320314,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308155,
		300880,
	},
	CloseGoal = 
	{
		301216,
	},
	GoodsId = 2200314,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 11767,
				},
			},
		},
	},
	DemandID = 410205,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id206] =
{
	Id = 206,
	Name = "0",
	Desc = "0",
	Value = 320314,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308155,
		300892,
	},
	CloseGoal = 
	{
		301232,
	},
	GoodsId = 2200314,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 11767,
				},
			},
		},
	},
	DemandID = 410206,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id207] =
{
	Id = 207,
	Name = "0",
	Desc = "0",
	Value = 320314,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308155,
		301204,
	},
	CloseGoal = 
	{
		301248,
	},
	GoodsId = 2200314,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 11767,
				},
			},
		},
	},
	DemandID = 410207,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id208] =
{
	Id = 208,
	Name = "0",
	Desc = "0",
	Value = 320314,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308155,
		301228,
	},
	CloseGoal = 
	{
		301268,
	},
	GoodsId = 2200314,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 11767,
				},
			},
		},
	},
	DemandID = 410208,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id209] =
{
	Id = 209,
	Name = "0",
	Desc = "0",
	Value = 320314,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308155,
		301248,
	},
	CloseGoal = 
	{
		301288,
	},
	GoodsId = 2200314,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 11767,
				},
			},
		},
	},
	DemandID = 410209,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id210] =
{
	Id = 210,
	Name = "0",
	Desc = "0",
	Value = 320314,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308155,
		301268,
	},
	CloseGoal = 
	{
		301314,
	},
	GoodsId = 2200314,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 11767,
				},
			},
		},
	},
	DemandID = 410210,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id211] =
{
	Id = 211,
	Name = "0",
	Desc = "0",
	Value = 320314,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308155,
		301292,
	},
	GoodsId = 2200314,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 11767,
				},
			},
		},
	},
	DemandID = 410211,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id212] =
{
	Id = 212,
	Name = "0",
	Desc = "0",
	Value = 320315,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308157,
		301220,
	},
	CloseGoal = 
	{
		301248,
	},
	GoodsId = 2300315,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 66801,
				},
			},
		},
	},
	DemandID = 410212,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id213] =
{
	Id = 213,
	Name = "0",
	Desc = "0",
	Value = 320315,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308157,
		301228,
	},
	CloseGoal = 
	{
		301256,
	},
	GoodsId = 2300315,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 66801,
				},
			},
		},
	},
	DemandID = 410213,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id214] =
{
	Id = 214,
	Name = "0",
	Desc = "0",
	Value = 320315,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308157,
		301236,
	},
	CloseGoal = 
	{
		301268,
	},
	GoodsId = 2300315,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 66801,
				},
			},
		},
	},
	DemandID = 410214,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id215] =
{
	Id = 215,
	Name = "0",
	Desc = "0",
	Value = 320315,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308157,
		301248,
	},
	CloseGoal = 
	{
		301280,
	},
	GoodsId = 2300315,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 66801,
				},
			},
		},
	},
	DemandID = 410215,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id216] =
{
	Id = 216,
	Name = "0",
	Desc = "0",
	Value = 320315,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308157,
		301260,
	},
	CloseGoal = 
	{
		301297,
	},
	GoodsId = 2300315,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 66801,
				},
			},
		},
	},
	DemandID = 410216,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id217] =
{
	Id = 217,
	Name = "0",
	Desc = "0",
	Value = 320315,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308157,
		301276,
	},
	CloseGoal = 
	{
		301314,
	},
	GoodsId = 2300315,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 66801,
				},
			},
		},
	},
	DemandID = 410217,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id218] =
{
	Id = 218,
	Name = "0",
	Desc = "0",
	Value = 320315,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308157,
		301292,
	},
	CloseGoal = 
	{
		301615,
	},
	GoodsId = 2300315,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 66801,
				},
			},
		},
	},
	DemandID = 410218,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id219] =
{
	Id = 219,
	Name = "0",
	Desc = "0",
	Value = 320315,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308157,
		301314,
	},
	CloseGoal = 
	{
		301640,
	},
	GoodsId = 2300315,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 66801,
				},
			},
		},
	},
	DemandID = 410219,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id220] =
{
	Id = 220,
	Name = "0",
	Desc = "0",
	Value = 320315,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308157,
		301615,
	},
	CloseGoal = 
	{
		301670,
	},
	GoodsId = 2300315,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 66801,
				},
			},
		},
	},
	DemandID = 410220,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id221] =
{
	Id = 221,
	Name = "0",
	Desc = "0",
	Value = 320315,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308157,
		301645,
	},
	GoodsId = 2300315,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 66801,
				},
			},
		},
	},
	DemandID = 410221,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id222] =
{
	Id = 222,
	Name = "订购纸板箱",
	Desc = "需要大量纸板箱",
	Value = 320317,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308152,
		300814,
	},
	CloseGoal = 
	{
		300844,
	},
	GoodsId = 2400317,
	Num = 2,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 844,
				},
			},
		},
	},
	DemandID = 410222,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id223] =
{
	Id = 223,
	Name = "0",
	Desc = "0",
	Value = 320317,
	Active = false,
	Weight = 0,
	GoodsId = 2420317,
	Num = 3,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 1267,
				},
			},
		},
	},
	DemandID = 410223,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id224] =
{
	Id = 224,
	Name = "0",
	Desc = "0",
	Value = 320317,
	Active = false,
	Weight = 0,
	GoodsId = 2430317,
	Num = 3,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 1267,
				},
			},
		},
	},
	DemandID = 410224,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id225] =
{
	Id = 225,
	Name = "订购纸板箱",
	Desc = "需要大量纸板箱",
	Value = 320317,
	Active = false,
	Weight = 0,
	GoodsId = 2440317,
	Num = 3,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 1267,
				},
			},
		},
	},
	DemandID = 410225,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id226] =
{
	Id = 226,
	Name = "0",
	Desc = "0",
	Value = 320317,
	Active = false,
	Weight = 0,
	GoodsId = 2450317,
	Num = 3,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 1267,
				},
			},
		},
	},
	DemandID = 410226,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id227] =
{
	Id = 227,
	Name = "订购纸板箱",
	Desc = "需要大量纸板箱",
	Value = 320317,
	Active = true,
	Weight = 3905,
	PreGoal = 
	{
		308152,
	},
	CloseGoal = 
	{
		308154,
	},
	GoodsId = 2460317,
	Num = 3,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 1267,
				},
			},
		},
	},
	DemandID = 410227,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id228] =
{
	Id = 228,
	Name = "订购纸板箱",
	Desc = "需要大量纸板箱",
	Value = 320317,
	Active = true,
	Weight = 4575,
	PreGoal = 
	{
		308154,
	},
	CloseGoal = 
	{
		308155,
	},
	GoodsId = 2470317,
	Num = 5,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 2111,
				},
			},
		},
	},
	DemandID = 410228,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id229] =
{
	Id = 229,
	Name = "订购纸板箱",
	Desc = "需要大量纸板箱",
	Value = 320317,
	Active = true,
	Weight = 5120,
	PreGoal = 
	{
		308155,
	},
	CloseGoal = 
	{
		308156,
	},
	GoodsId = 2480317,
	Num = 8,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 3378,
				},
			},
		},
	},
	DemandID = 410229,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id230] =
{
	Id = 230,
	Name = "订购纸板箱",
	Desc = "需要大量纸板箱",
	Value = 320317,
	Active = true,
	Weight = 6545,
	PreGoal = 
	{
		308156,
	},
	CloseGoal = 
	{
		308157,
	},
	GoodsId = 2490317,
	Num = 12,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5068,
				},
			},
		},
	},
	DemandID = 410230,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id231] =
{
	Id = 231,
	Name = "订购纸板箱",
	Desc = "需要大量纸板箱",
	Value = 320317,
	Active = true,
	Weight = 7280,
	PreGoal = 
	{
		308157,
	},
	GoodsId = 2500317,
	Num = 18,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 7602,
				},
			},
		},
	},
	DemandID = 410231,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id232] =
{
	Id = 232,
	Name = "0",
	Desc = "0",
	Value = 320318,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308154,
		300840,
	},
	CloseGoal = 
	{
		300868,
	},
	GoodsId = 2500318,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 11767,
				},
			},
		},
	},
	DemandID = 410232,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id233] =
{
	Id = 233,
	Name = "0",
	Desc = "0",
	Value = 320318,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308154,
		300848,
	},
	CloseGoal = 
	{
		300876,
	},
	GoodsId = 2500318,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 11767,
				},
			},
		},
	},
	DemandID = 410233,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id234] =
{
	Id = 234,
	Name = "0",
	Desc = "0",
	Value = 320318,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308154,
		300856,
	},
	CloseGoal = 
	{
		300888,
	},
	GoodsId = 2500318,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 11767,
				},
			},
		},
	},
	DemandID = 410234,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id235] =
{
	Id = 235,
	Name = "0",
	Desc = "0",
	Value = 320318,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308154,
		300868,
	},
	CloseGoal = 
	{
		300900,
	},
	GoodsId = 2500318,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 11767,
				},
			},
		},
	},
	DemandID = 410235,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id236] =
{
	Id = 236,
	Name = "0",
	Desc = "0",
	Value = 320318,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308154,
		300880,
	},
	CloseGoal = 
	{
		301220,
	},
	GoodsId = 2500318,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 11767,
				},
			},
		},
	},
	DemandID = 410236,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id237] =
{
	Id = 237,
	Name = "0",
	Desc = "0",
	Value = 320318,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308154,
		300896,
	},
	CloseGoal = 
	{
		301236,
	},
	GoodsId = 2500318,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 11767,
				},
			},
		},
	},
	DemandID = 410237,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id238] =
{
	Id = 238,
	Name = "0",
	Desc = "0",
	Value = 320318,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308154,
		301216,
	},
	CloseGoal = 
	{
		301256,
	},
	GoodsId = 2500318,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 11767,
				},
			},
		},
	},
	DemandID = 410238,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id239] =
{
	Id = 239,
	Name = "0",
	Desc = "0",
	Value = 320318,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308154,
		301236,
	},
	CloseGoal = 
	{
		301276,
	},
	GoodsId = 2500318,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 11767,
				},
			},
		},
	},
	DemandID = 410239,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id240] =
{
	Id = 240,
	Name = "0",
	Desc = "0",
	Value = 320318,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308154,
		301256,
	},
	CloseGoal = 
	{
		301301,
	},
	GoodsId = 2500318,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 11767,
				},
			},
		},
	},
	DemandID = 410240,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id241] =
{
	Id = 241,
	Name = "0",
	Desc = "0",
	Value = 320318,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308154,
		301280,
	},
	GoodsId = 2500318,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 11767,
				},
			},
		},
	},
	DemandID = 410241,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id242] =
{
	Id = 242,
	Name = "0",
	Desc = "0",
	Value = 320319,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308156,
		300904,
	},
	CloseGoal = 
	{
		301236,
	},
	GoodsId = 2600319,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 66801,
				},
			},
		},
	},
	DemandID = 410242,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id243] =
{
	Id = 243,
	Name = "0",
	Desc = "0",
	Value = 320319,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308156,
		301216,
	},
	CloseGoal = 
	{
		301244,
	},
	GoodsId = 2600319,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 66801,
				},
			},
		},
	},
	DemandID = 410243,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id244] =
{
	Id = 244,
	Name = "0",
	Desc = "0",
	Value = 320319,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308156,
		301224,
	},
	CloseGoal = 
	{
		301256,
	},
	GoodsId = 2600319,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 66801,
				},
			},
		},
	},
	DemandID = 410244,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id245] =
{
	Id = 245,
	Name = "0",
	Desc = "0",
	Value = 320319,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308156,
		301236,
	},
	CloseGoal = 
	{
		301268,
	},
	GoodsId = 2600319,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 66801,
				},
			},
		},
	},
	DemandID = 410245,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id246] =
{
	Id = 246,
	Name = "0",
	Desc = "0",
	Value = 320319,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308156,
		301248,
	},
	CloseGoal = 
	{
		301284,
	},
	GoodsId = 2600319,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 66801,
				},
			},
		},
	},
	DemandID = 410246,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id247] =
{
	Id = 247,
	Name = "0",
	Desc = "0",
	Value = 320319,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308156,
		301264,
	},
	CloseGoal = 
	{
		301301,
	},
	GoodsId = 2600319,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 66801,
				},
			},
		},
	},
	DemandID = 410247,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id248] =
{
	Id = 248,
	Name = "0",
	Desc = "0",
	Value = 320319,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308156,
		301280,
	},
	CloseGoal = 
	{
		301322,
	},
	GoodsId = 2600319,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 66801,
				},
			},
		},
	},
	DemandID = 410248,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id249] =
{
	Id = 249,
	Name = "0",
	Desc = "0",
	Value = 320319,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308156,
		301301,
	},
	CloseGoal = 
	{
		301625,
	},
	GoodsId = 2600319,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 66801,
				},
			},
		},
	},
	DemandID = 410249,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id250] =
{
	Id = 250,
	Name = "0",
	Desc = "0",
	Value = 320319,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308156,
		301322,
	},
	CloseGoal = 
	{
		301655,
	},
	GoodsId = 2600319,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 66801,
				},
			},
		},
	},
	DemandID = 410250,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id251] =
{
	Id = 251,
	Name = "0",
	Desc = "0",
	Value = 320319,
	Active = false,
	Weight = 0,
	PreGoal = 
	{
		308156,
		301630,
	},
	GoodsId = 2600319,
	Num = 1,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 66801,
				},
			},
		},
	},
	DemandID = 410251,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id252] =
{
	Id = 252,
	Name = "浪漫的哨声",
	Desc = "树叶能吹出美丽的哨声？想要些呢~",
	Value = 321001,
	Active = true,
	Weight = 20,
	PreGoal = 
	{
		300004,
	},
	CloseGoal = 
	{
		300035,
	},
	GoodsId = 2711001,
	Priority = 1001021,
	Num = 10,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 109,
				},
			},
		},
	},
	DemandID = 410252,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id253] =
{
	Id = 253,
	Name = "药师的委托",
	Desc = "需要一些树叶来熬制草药。",
	Value = 321001,
	Active = true,
	Weight = 40,
	PreGoal = 
	{
		300004,
		300013,
	},
	CloseGoal = 
	{
		300043,
	},
	GoodsId = 2721001,
	Priority = 1001022,
	Num = 10,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 109,
				},
			},
		},
	},
	DemandID = 410253,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id254] =
{
	Id = 254,
	Name = "防具师委托",
	Desc = "真头疼，最近流行自然风的防具。",
	Value = 321001,
	Active = true,
	Weight = 60,
	PreGoal = 
	{
		300004,
		300020,
	},
	CloseGoal = 
	{
		300055,
	},
	GoodsId = 2731001,
	Priority = 1001023,
	Num = 12,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 131,
				},
			},
		},
	},
	DemandID = 410254,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id255] =
{
	Id = 255,
	Name = "绿化星球",
	Desc = "为应对环境检查，急征大量树叶。",
	Value = 321001,
	Active = true,
	Weight = 90,
	PreGoal = 
	{
		300004,
		300035,
	},
	CloseGoal = 
	{
		300066,
	},
	GoodsId = 2741001,
	Priority = 1001024,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 306,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 2,
				},
				{
					Value = 1,
					Num = 106,
				},
			},
		},
	},
	DemandID = 410255,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id256] =
{
	Id = 256,
	Name = "浪漫的哨声",
	Desc = "树叶能吹出美丽的哨声？想要些呢~",
	Value = 321001,
	Active = true,
	Weight = 120,
	PreGoal = 
	{
		300004,
		300046,
	},
	CloseGoal = 
	{
		300080,
	},
	GoodsId = 2751001,
	Priority = 1001025,
	Num = 44,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 482,
				},
			},
		},
	},
	DemandID = 410256,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id257] =
{
	Id = 257,
	Name = "药师的委托",
	Desc = "需要一些树叶来熬制草药。",
	Value = 321001,
	Active = true,
	Weight = 160,
	PreGoal = 
	{
		300004,
		300062,
	},
	CloseGoal = 
	{
		300096,
	},
	GoodsId = 2761001,
	Priority = 1001026,
	Num = 60,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 657,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 5,
				},
				{
					Value = 1,
					Num = 157,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 1,
				},
				{
					Value = 1,
					Num = 157,
				},
			},
		},
	},
	DemandID = 410257,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id258] =
{
	Id = 258,
	Name = "防具师委托",
	Desc = "真头疼，最近流行自然风的防具。",
	Value = 321001,
	Active = true,
	Weight = 200,
	PreGoal = 
	{
		300004,
		300075,
	},
	CloseGoal = 
	{
		300413,
	},
	GoodsId = 2771001,
	Priority = 1001027,
	Num = 98,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 1074,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 9,
				},
				{
					Value = 1,
					Num = 174,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 1,
				},
				{
					Value = 1,
					Num = 574,
				},
			},
		},
	},
	DemandID = 410258,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id259] =
{
	Id = 259,
	Name = "绿化星球",
	Desc = "为应对环境检查，急征大量树叶。",
	Value = 321001,
	Active = true,
	Weight = 250,
	PreGoal = 
	{
		300004,
		300096,
	},
	CloseGoal = 
	{
		300431,
	},
	GoodsId = 2781001,
	Priority = 1001028,
	Num = 150,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 1644,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 13,
				},
				{
					Value = 1,
					Num = 344,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 2,
				},
				{
					Value = 1,
					Num = 644,
				},
			},
		},
	},
	DemandID = 410259,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id260] =
{
	Id = 260,
	Name = "防具师委托",
	Desc = "真头疼，最近流行自然风的防具。",
	Value = 321001,
	Active = true,
	Weight = 300,
	PreGoal = 
	{
		300004,
		300413,
	},
	CloseGoal = 
	{
		300454,
	},
	GoodsId = 2701001,
	Priority = 1001029,
	Num = 200,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 2192,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 18,
				},
				{
					Value = 1,
					Num = 392,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 3,
				},
				{
					Value = 1,
					Num = 692,
				},
			},
		},
	},
	DemandID = 410260,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id261] =
{
	Id = 261,
	Name = "绿化星球",
	Desc = "为应对环境检查，急征大量树叶。",
	Value = 321001,
	Active = true,
	Weight = 360,
	PreGoal = 
	{
		300004,
		300436,
	},
	CloseGoal = 
	{
		300478,
	},
	GoodsId = 2701001,
	Priority = 1001030,
	Num = 218,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 2389,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 20,
				},
				{
					Value = 1,
					Num = 389,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 4,
				},
				{
					Value = 1,
					Num = 389,
				},
			},
		},
	},
	DemandID = 410261,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id262] =
{
	Id = 262,
	Name = "练习空手道",
	Desc = "这次要一下子劈断好几块木头!",
	Value = 321002,
	Active = true,
	Weight = 125,
	PreGoal = 
	{
		300017,
	},
	CloseGoal = 
	{
		300046,
	},
	GoodsId = 2811002,
	Priority = 1002051,
	Num = 2,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 155,
				},
			},
		},
	},
	DemandID = 410262,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id263] =
{
	Id = 263,
	Name = "补篱笆墙",
	Desc = "村口的篱笆墙不知道被谁偷走了！",
	Value = 321002,
	Active = true,
	Weight = 175,
	PreGoal = 
	{
		300017,
		300023,
	},
	CloseGoal = 
	{
		300055,
	},
	GoodsId = 2821002,
	Priority = 1002052,
	Num = 3,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 233,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 1,
				},
				{
					Value = 320051,
					Num = 1,
				},
			},
		},
	},
	DemandID = 410263,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id264] =
{
	Id = 264,
	Name = "木质武器商",
	Desc = "要给新手们准备些木质武器~",
	Value = 321002,
	Active = true,
	Weight = 225,
	PreGoal = 
	{
		300017,
		300035,
	},
	CloseGoal = 
	{
		300066,
	},
	GoodsId = 2831002,
	Priority = 1002053,
	Num = 5,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 388,
				},
			},
		},
	},
	DemandID = 410264,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id265] =
{
	Id = 265,
	Name = "家具商委托",
	Desc = "如果有拿得出手的木材请联系我。",
	Value = 321002,
	Active = true,
	Weight = 300,
	PreGoal = 
	{
		300017,
		300046,
	},
	CloseGoal = 
	{
		300075,
	},
	GoodsId = 2841002,
	Priority = 1002054,
	Num = 6,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 466,
				},
			},
		},
	},
	DemandID = 410265,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id266] =
{
	Id = 266,
	Name = "重建森林",
	Desc = "为应对环境检查，急征大量木材。",
	Value = 321002,
	Active = true,
	Weight = 375,
	PreGoal = 
	{
		300017,
		300058,
	},
	CloseGoal = 
	{
		300091,
	},
	GoodsId = 2851002,
	Priority = 1002055,
	Num = 9,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 699,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 1,
				},
				{
					Value = 1,
					Num = 199,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 1,
				},
				{
					Value = 1,
					Num = 199,
				},
			},
		},
	},
	DemandID = 410266,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id267] =
{
	Id = 267,
	Name = "练习空手道",
	Desc = "这次要一下子劈断好几块木头!",
	Value = 321002,
	Active = true,
	Weight = 475,
	PreGoal = 
	{
		300017,
		300072,
	},
	CloseGoal = 
	{
		300406,
	},
	GoodsId = 2861002,
	Priority = 1002056,
	Num = 14,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 1087,
				},
			},
		},
	},
	DemandID = 410267,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id268] =
{
	Id = 268,
	Name = "补篱笆墙",
	Desc = "村口的篱笆墙不知道被谁偷走了！",
	Value = 321002,
	Active = true,
	Weight = 575,
	PreGoal = 
	{
		300017,
		300087,
	},
	CloseGoal = 
	{
		300424,
	},
	GoodsId = 2871002,
	Priority = 1002057,
	Num = 21,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 1631,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 15,
				},
				{
					Value = 1,
					Num = 131,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 15,
				},
				{
					Value = 1,
					Num = 131,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 3,
				},
				{
					Value = 1,
					Num = 131,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 3,
				},
				{
					Value = 1,
					Num = 131,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 9,
				},
				{
					Value = 320051,
					Num = 7,
				},
			},
		},
	},
	DemandID = 410268,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id269] =
{
	Id = 269,
	Name = "木质武器商",
	Desc = "要给新手们准备些木质武器~",
	Value = 321002,
	Active = true,
	Weight = 700,
	PreGoal = 
	{
		300017,
		300406,
	},
	CloseGoal = 
	{
		300443,
	},
	GoodsId = 2801002,
	Priority = 1002058,
	Num = 32,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 2486,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 23,
				},
				{
					Value = 1,
					Num = 186,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 23,
				},
				{
					Value = 1,
					Num = 186,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 4,
				},
				{
					Value = 1,
					Num = 486,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 4,
				},
				{
					Value = 1,
					Num = 486,
				},
			},
		},
	},
	DemandID = 410269,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id270] =
{
	Id = 270,
	Name = "家具商委托",
	Desc = "如果有拿得出手的木材请联系我。",
	Value = 321002,
	Active = true,
	Weight = 825,
	PreGoal = 
	{
		300017,
		300424,
	},
	CloseGoal = 
	{
		300466,
	},
	GoodsId = 2801002,
	Priority = 1002059,
	Num = 34,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 2641,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 24,
				},
				{
					Value = 1,
					Num = 241,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 24,
				},
				{
					Value = 1,
					Num = 241,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 4,
				},
				{
					Value = 1,
					Num = 641,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 4,
				},
				{
					Value = 1,
					Num = 641,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 15,
				},
				{
					Value = 320051,
					Num = 11,
				},
			},
		},
	},
	DemandID = 410270,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id271] =
{
	Id = 271,
	Name = "重建森林",
	Desc = "为应对环境检查，急征大量木材。",
	Value = 321002,
	Active = true,
	Weight = 975,
	PreGoal = 
	{
		300017,
		300446,
	},
	CloseGoal = 
	{
		300490,
	},
	GoodsId = 2801002,
	Priority = 1002060,
	Num = 36,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 2797,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 26,
				},
				{
					Value = 1,
					Num = 197,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 26,
				},
				{
					Value = 1,
					Num = 197,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 5,
				},
				{
					Value = 1,
					Num = 297,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 5,
				},
				{
					Value = 1,
					Num = 297,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 1,
				},
				{
					Value = 1,
					Num = 297,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 1,
				},
				{
					Value = 1,
					Num = 297,
				},
			},
		},
	},
	DemandID = 410271,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id272] =
{
	Id = 272,
	Name = "浓醇高汤",
	Desc = "老伴摔了一跤就骨折了，得补点钙。",
	Value = 321003,
	Active = true,
	Weight = 320,
	PreGoal = 
	{
		300030,
	},
	CloseGoal = 
	{
		300058,
	},
	GoodsId = 2911003,
	Priority = 1003081,
	Num = 4,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 431,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 3,
				},
				{
					Value = 1,
					Num = 131,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 3,
				},
				{
					Value = 1,
					Num = 131,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 3,
				},
				{
					Value = 320051,
					Num = 1,
				},
			},
		},
	},
	DemandID = 410272,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id273] =
{
	Id = 273,
	Name = "黑暗风饰品",
	Desc = "使用骨头作为饰品实在太酷了。",
	Value = 321003,
	Active = true,
	Weight = 400,
	PreGoal = 
	{
		300030,
		300040,
	},
	CloseGoal = 
	{
		300066,
	},
	GoodsId = 2921003,
	Priority = 1003082,
	Num = 5,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 539,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 4,
				},
				{
					Value = 1,
					Num = 139,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 4,
				},
				{
					Value = 1,
					Num = 139,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 3,
				},
				{
					Value = 320051,
					Num = 2,
				},
			},
		},
	},
	DemandID = 410273,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id274] =
{
	Id = 274,
	Name = "宠物饲养",
	Desc = "养了一条食量很大的狗狗…",
	Value = 321003,
	Active = true,
	Weight = 480,
	PreGoal = 
	{
		300030,
		300046,
	},
	CloseGoal = 
	{
		300075,
	},
	GoodsId = 2931003,
	Priority = 1003083,
	Num = 6,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 646,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 5,
				},
				{
					Value = 1,
					Num = 146,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 5,
				},
				{
					Value = 1,
					Num = 146,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 1,
				},
				{
					Value = 1,
					Num = 146,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 1,
				},
				{
					Value = 1,
					Num = 146,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 4,
				},
				{
					Value = 320051,
					Num = 2,
				},
			},
		},
	},
	DemandID = 410274,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id275] =
{
	Id = 275,
	Name = "骨雕",
	Desc = "打算开办骨雕展，需要些骨头。",
	Value = 321003,
	Active = true,
	Weight = 600,
	PreGoal = 
	{
		300030,
		300058,
	},
	CloseGoal = 
	{
		300087,
	},
	GoodsId = 2941003,
	Priority = 1003084,
	Num = 8,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 862,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 7,
				},
				{
					Value = 1,
					Num = 162,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 6,
				},
				{
					Value = 1,
					Num = 262,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 1,
				},
				{
					Value = 1,
					Num = 362,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 1,
				},
				{
					Value = 1,
					Num = 362,
				},
			},
		},
	},
	DemandID = 410275,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id276] =
{
	Id = 276,
	Name = "多米诺骨牌",
	Desc = "打算搭建可以申请吉斯记录的骨牌阵！",
	Value = 321003,
	Active = true,
	Weight = 720,
	PreGoal = 
	{
		300030,
		300069,
	},
	CloseGoal = 
	{
		300403,
	},
	GoodsId = 2951003,
	Priority = 1003085,
	Num = 10,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 1078,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 9,
				},
				{
					Value = 1,
					Num = 178,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 8,
				},
				{
					Value = 1,
					Num = 278,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 1,
				},
				{
					Value = 1,
					Num = 578,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 1,
				},
				{
					Value = 1,
					Num = 578,
				},
			},
		},
	},
	DemandID = 410276,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id277] =
{
	Id = 277,
	Name = "浓醇高汤",
	Desc = "老伴摔了一跤就骨折了，得补点钙。",
	Value = 321003,
	Active = true,
	Weight = 880,
	PreGoal = 
	{
		300030,
		300084,
	},
	CloseGoal = 
	{
		300417,
	},
	GoodsId = 2961003,
	Priority = 1003086,
	Num = 16,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 1724,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 14,
				},
				{
					Value = 1,
					Num = 324,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 13,
				},
				{
					Value = 1,
					Num = 424,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 2,
				},
				{
					Value = 1,
					Num = 724,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 2,
				},
				{
					Value = 1,
					Num = 724,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 12,
				},
				{
					Value = 320051,
					Num = 5,
				},
			},
		},
	},
	DemandID = 410277,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id278] =
{
	Id = 278,
	Name = "黑暗风饰品",
	Desc = "使用骨头作为饰品实在太酷了。",
	Value = 321003,
	Active = true,
	Weight = 1040,
	PreGoal = 
	{
		300030,
		300102,
	},
	CloseGoal = 
	{
		300436,
	},
	GoodsId = 2971003,
	Priority = 1003087,
	Num = 27,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 2910,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 24,
				},
				{
					Value = 1,
					Num = 510,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 23,
				},
				{
					Value = 1,
					Num = 610,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 4,
				},
				{
					Value = 1,
					Num = 910,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 4,
				},
				{
					Value = 1,
					Num = 910,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 20,
				},
				{
					Value = 320051,
					Num = 9,
				},
			},
		},
	},
	DemandID = 410278,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id279] =
{
	Id = 279,
	Name = "宠物饲养",
	Desc = "养了一条食量很大的狗狗…",
	Value = 321003,
	Active = true,
	Weight = 1240,
	PreGoal = 
	{
		300030,
		300417,
	},
	CloseGoal = 
	{
		300454,
	},
	GoodsId = 2901003,
	Priority = 1003088,
	Num = 30,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 3234,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 27,
				},
				{
					Value = 1,
					Num = 534,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 25,
				},
				{
					Value = 1,
					Num = 734,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 5,
				},
				{
					Value = 1,
					Num = 734,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 5,
				},
				{
					Value = 1,
					Num = 734,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 1,
				},
				{
					Value = 1,
					Num = 734,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 1,
				},
				{
					Value = 1,
					Num = 734,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 23,
				},
				{
					Value = 320051,
					Num = 9,
				},
			},
		},
	},
	DemandID = 410279,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id280] =
{
	Id = 280,
	Name = "骨雕",
	Desc = "打算开办骨雕展，需要些骨头。",
	Value = 321003,
	Active = true,
	Weight = 1440,
	PreGoal = 
	{
		300030,
		300436,
	},
	CloseGoal = 
	{
		300478,
	},
	GoodsId = 2901003,
	Priority = 1003089,
	Num = 33,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 3557,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 30,
				},
				{
					Value = 1,
					Num = 557,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 28,
				},
				{
					Value = 1,
					Num = 757,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 6,
				},
				{
					Value = 1,
					Num = 557,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 5,
				},
				{
					Value = 1,
					Num = 1057,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1057,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1057,
				},
			},
		},
	},
	DemandID = 410280,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id281] =
{
	Id = 281,
	Name = "多米诺骨牌",
	Desc = "打算搭建可以申请吉斯记录的骨牌阵！",
	Value = 321003,
	Active = true,
	Weight = 1680,
	PreGoal = 
	{
		300030,
		300458,
	},
	CloseGoal = 
	{
		300804,
	},
	GoodsId = 2901003,
	Priority = 1003090,
	Num = 35,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 3773,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 32,
				},
				{
					Value = 1,
					Num = 573,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 30,
				},
				{
					Value = 1,
					Num = 773,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 6,
				},
				{
					Value = 1,
					Num = 773,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 6,
				},
				{
					Value = 1,
					Num = 773,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1273,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1273,
				},
			},
		},
	},
	DemandID = 410281,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id282] =
{
	Id = 282,
	Name = "矿石收藏家",
	Desc = "喜欢各种不同矿石独特的质感~",
	Value = 321004,
	Active = true,
	Weight = 720,
	PreGoal = 
	{
		300046,
	},
	CloseGoal = 
	{
		300072,
	},
	GoodsId = 3011004,
	Priority = 1004121,
	Num = 6,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 734,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 6,
				},
				{
					Value = 1,
					Num = 134,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 6,
				},
				{
					Value = 1,
					Num = 134,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 1,
				},
				{
					Value = 1,
					Num = 234,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 1,
				},
				{
					Value = 1,
					Num = 234,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 4,
				},
				{
					Value = 320051,
					Num = 3,
				},
			},
		},
	},
	DemandID = 410282,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id283] =
{
	Id = 283,
	Name = "健康厨具",
	Desc = "听说铁锅能够补充铁元素。",
	Value = 321004,
	Active = true,
	Weight = 840,
	PreGoal = 
	{
		300046,
		300055,
	},
	CloseGoal = 
	{
		300080,
	},
	GoodsId = 3021004,
	Priority = 1004122,
	Num = 8,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 979,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 1,
				},
				{
					Value = 1,
					Num = 479,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 1,
				},
				{
					Value = 1,
					Num = 479,
				},
			},
		},
	},
	DemandID = 410283,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id284] =
{
	Id = 284,
	Name = "锻造武器",
	Desc = "需要更好的矿石来打造武器。",
	Value = 321004,
	Active = true,
	Weight = 960,
	PreGoal = 
	{
		300046,
		300062,
	},
	CloseGoal = 
	{
		300091,
	},
	GoodsId = 3031004,
	Priority = 1004123,
	Num = 9,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 1101,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 10,
				},
				{
					Value = 1,
					Num = 101,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 10,
				},
				{
					Value = 1,
					Num = 101,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 2,
				},
				{
					Value = 1,
					Num = 101,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 2,
				},
				{
					Value = 1,
					Num = 101,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 6,
				},
				{
					Value = 320051,
					Num = 5,
				},
			},
		},
	},
	DemandID = 410284,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id285] =
{
	Id = 285,
	Name = "锻造铠甲",
	Desc = "用这个做盔甲，新手穿上也会很耐打。",
	Value = 321004,
	Active = true,
	Weight = 1140,
	PreGoal = 
	{
		300046,
		300072,
	},
	CloseGoal = 
	{
		300403,
	},
	GoodsId = 3041004,
	Priority = 1004124,
	Num = 12,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 1469,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 13,
				},
				{
					Value = 1,
					Num = 169,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 13,
				},
				{
					Value = 1,
					Num = 169,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 2,
				},
				{
					Value = 1,
					Num = 469,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 2,
				},
				{
					Value = 1,
					Num = 469,
				},
			},
		},
	},
	DemandID = 410285,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id286] =
{
	Id = 286,
	Name = "寻找新矿石",
	Desc = "说不定新矿石就隐藏在普通矿石中！",
	Value = 321004,
	Active = true,
	Weight = 1320,
	PreGoal = 
	{
		300046,
		300084,
	},
	CloseGoal = 
	{
		300417,
	},
	GoodsId = 3051004,
	Priority = 1004125,
	Num = 16,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 1958,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 18,
				},
				{
					Value = 1,
					Num = 158,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 18,
				},
				{
					Value = 1,
					Num = 158,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 3,
				},
				{
					Value = 1,
					Num = 458,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 3,
				},
				{
					Value = 1,
					Num = 458,
				},
			},
		},
	},
	DemandID = 410286,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id287] =
{
	Id = 287,
	Name = "矿石收藏家",
	Desc = "喜欢各种不同矿石独特的质感~",
	Value = 321004,
	Active = true,
	Weight = 1560,
	PreGoal = 
	{
		300046,
		300102,
	},
	CloseGoal = 
	{
		300431,
	},
	GoodsId = 3061004,
	Priority = 1004126,
	Num = 27,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 3305,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 31,
				},
				{
					Value = 1,
					Num = 205,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 31,
				},
				{
					Value = 1,
					Num = 205,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 6,
				},
				{
					Value = 1,
					Num = 305,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 6,
				},
				{
					Value = 1,
					Num = 305,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 1,
				},
				{
					Value = 1,
					Num = 805,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 1,
				},
				{
					Value = 1,
					Num = 805,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 18,
				},
				{
					Value = 320051,
					Num = 15,
				},
			},
		},
	},
	DemandID = 410287,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id288] =
{
	Id = 288,
	Name = "健康厨具",
	Desc = "听说铁锅能够补充铁元素。",
	Value = 321004,
	Active = true,
	Weight = 1800,
	PreGoal = 
	{
		300046,
		300413,
	},
	CloseGoal = 
	{
		300450,
	},
	GoodsId = 3001004,
	Priority = 1004127,
	Num = 30,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 3672,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 34,
				},
				{
					Value = 1,
					Num = 272,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 34,
				},
				{
					Value = 1,
					Num = 272,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 6,
				},
				{
					Value = 1,
					Num = 672,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 6,
				},
				{
					Value = 1,
					Num = 672,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1172,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1172,
				},
			},
		},
	},
	DemandID = 410288,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id289] =
{
	Id = 289,
	Name = "锻造武器",
	Desc = "需要更好的矿石来打造武器。",
	Value = 321004,
	Active = true,
	Weight = 2100,
	PreGoal = 
	{
		300046,
		300431,
	},
	CloseGoal = 
	{
		300470,
	},
	GoodsId = 3001004,
	Priority = 1004128,
	Num = 32,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 3917,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 37,
				},
				{
					Value = 1,
					Num = 217,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 37,
				},
				{
					Value = 1,
					Num = 217,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 7,
				},
				{
					Value = 1,
					Num = 417,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 7,
				},
				{
					Value = 1,
					Num = 417,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1417,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1417,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 21,
				},
				{
					Value = 320051,
					Num = 18,
				},
			},
		},
	},
	DemandID = 410289,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id290] =
{
	Id = 290,
	Name = "锻造铠甲",
	Desc = "用这个做盔甲，新手穿上也会很耐打。",
	Value = 321004,
	Active = true,
	Weight = 2400,
	PreGoal = 
	{
		300046,
		300450,
	},
	CloseGoal = 
	{
		300494,
	},
	GoodsId = 3001004,
	Priority = 1004129,
	Num = 34,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 4162,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 39,
				},
				{
					Value = 1,
					Num = 262,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 39,
				},
				{
					Value = 1,
					Num = 262,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 7,
				},
				{
					Value = 1,
					Num = 662,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 7,
				},
				{
					Value = 1,
					Num = 662,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1662,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1662,
				},
			},
		},
	},
	DemandID = 410290,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id291] =
{
	Id = 291,
	Name = "寻找新矿石",
	Desc = "说不定新矿石就隐藏在普通矿石中！",
	Value = 321004,
	Active = true,
	Weight = 2760,
	PreGoal = 
	{
		300046,
		300474,
	},
	CloseGoal = 
	{
		300823,
	},
	GoodsId = 3001004,
	Priority = 1004130,
	Num = 38,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 4652,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 43,
				},
				{
					Value = 1,
					Num = 352,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 43,
				},
				{
					Value = 1,
					Num = 352,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 8,
				},
				{
					Value = 1,
					Num = 652,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 8,
				},
				{
					Value = 1,
					Num = 652,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2152,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2152,
				},
			},
		},
	},
	DemandID = 410291,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id292] =
{
	Id = 292,
	Name = "地图校对",
	Desc = "有偿回收旧版地图~",
	Value = 321005,
	Active = true,
	Weight = 1125,
	PreGoal = 
	{
		300058,
	},
	CloseGoal = 
	{
		300084,
	},
	GoodsId = 3111005,
	Priority = 1005151,
	Num = 8,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 1330,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 6,
				},
				{
					Value = 1,
					Num = 730,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 6,
				},
				{
					Value = 1,
					Num = 730,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 1,
				},
				{
					Value = 1,
					Num = 830,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 1,
				},
				{
					Value = 1,
					Num = 830,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 7,
				},
				{
					Value = 320051,
					Num = 6,
				},
			},
		},
	},
	DemandID = 410292,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id293] =
{
	Id = 293,
	Name = "纪念册",
	Desc = "冒险者很喜欢手绘的地图呢~",
	Value = 321005,
	Active = true,
	Weight = 1275,
	PreGoal = 
	{
		300058,
		300066,
	},
	CloseGoal = 
	{
		300091,
	},
	GoodsId = 3121005,
	Priority = 1005152,
	Num = 10,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 1663,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 8,
				},
				{
					Value = 1,
					Num = 863,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 8,
				},
				{
					Value = 1,
					Num = 863,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1163,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1163,
				},
			},
		},
	},
	DemandID = 410293,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id294] =
{
	Id = 294,
	Name = "制作地图集",
	Desc = "上次制作的地图集卖了个好价钱~",
	Value = 321005,
	Active = true,
	Weight = 1425,
	PreGoal = 
	{
		300058,
		300072,
	},
	CloseGoal = 
	{
		300403,
	},
	GoodsId = 3131005,
	Priority = 1005153,
	Num = 12,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 1995,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 9,
				},
				{
					Value = 1,
					Num = 1095,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 9,
				},
				{
					Value = 1,
					Num = 1095,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1495,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 1,
				},
				{
					Value = 1,
					Num = 1495,
				},
			},
		},
	},
	DemandID = 410294,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id295] =
{
	Id = 295,
	Name = "星球图集",
	Desc = "有更多地图就可以做星球图集了~~",
	Value = 321005,
	Active = true,
	Weight = 1650,
	PreGoal = 
	{
		300058,
		300084,
	},
	CloseGoal = 
	{
		300413,
	},
	GoodsId = 3141005,
	Priority = 1005154,
	Num = 16,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 2661,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 13,
				},
				{
					Value = 1,
					Num = 1361,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 13,
				},
				{
					Value = 1,
					Num = 1361,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 2,
				},
				{
					Value = 1,
					Num = 1661,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 2,
				},
				{
					Value = 1,
					Num = 1661,
				},
			},
		},
	},
	DemandID = 410295,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id296] =
{
	Id = 296,
	Name = "地图校对",
	Desc = "有偿回收旧版地图~",
	Value = 321005,
	Active = true,
	Weight = 1875,
	PreGoal = 
	{
		300058,
		300096,
	},
	CloseGoal = 
	{
		300428,
	},
	GoodsId = 3151005,
	Priority = 1005155,
	Num = 21,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 3492,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 17,
				},
				{
					Value = 1,
					Num = 1792,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 17,
				},
				{
					Value = 1,
					Num = 1792,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 3,
				},
				{
					Value = 1,
					Num = 1992,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 3,
				},
				{
					Value = 1,
					Num = 1992,
				},
			},
		},
	},
	DemandID = 410296,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id297] =
{
	Id = 297,
	Name = "纪念册",
	Desc = "冒险者很喜欢手绘的地图呢~",
	Value = 321005,
	Active = true,
	Weight = 2175,
	PreGoal = 
	{
		300058,
		300410,
	},
	CloseGoal = 
	{
		300443,
	},
	GoodsId = 3101005,
	Priority = 1005156,
	Num = 27,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 4490,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 22,
				},
				{
					Value = 1,
					Num = 2290,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 22,
				},
				{
					Value = 1,
					Num = 2290,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 4,
				},
				{
					Value = 1,
					Num = 2490,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 4,
				},
				{
					Value = 1,
					Num = 2490,
				},
			},
		},
	},
	DemandID = 410297,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id298] =
{
	Id = 298,
	Name = "制作地图集",
	Desc = "上次制作的地图集卖了个好价钱~",
	Value = 321005,
	Active = true,
	Weight = 2475,
	PreGoal = 
	{
		300058,
		300424,
	},
	CloseGoal = 
	{
		300462,
	},
	GoodsId = 3101005,
	Priority = 1005157,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 4656,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 23,
				},
				{
					Value = 1,
					Num = 2356,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 23,
				},
				{
					Value = 1,
					Num = 2356,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 4,
				},
				{
					Value = 1,
					Num = 2656,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 4,
				},
				{
					Value = 1,
					Num = 2656,
				},
			},
		},
	},
	DemandID = 410298,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id299] =
{
	Id = 299,
	Name = "星球图集",
	Desc = "有更多地图就可以做星球图集了~~",
	Value = 321005,
	Active = true,
	Weight = 2850,
	PreGoal = 
	{
		300058,
		300443,
	},
	CloseGoal = 
	{
		300482,
	},
	GoodsId = 3101005,
	Priority = 1005158,
	Num = 30,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 4989,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 24,
				},
				{
					Value = 1,
					Num = 2589,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 24,
				},
				{
					Value = 1,
					Num = 2589,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 4,
				},
				{
					Value = 1,
					Num = 2989,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 4,
				},
				{
					Value = 1,
					Num = 2989,
				},
			},
		},
	},
	DemandID = 410299,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id300] =
{
	Id = 300,
	Name = "制作地图集",
	Desc = "上次制作的地图集卖了个好价钱~",
	Value = 321005,
	Active = true,
	Weight = 3225,
	PreGoal = 
	{
		300058,
		300462,
	},
	CloseGoal = 
	{
		300810,
	},
	GoodsId = 3101005,
	Priority = 1005159,
	Num = 33,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 5488,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 27,
				},
				{
					Value = 1,
					Num = 2788,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 27,
				},
				{
					Value = 1,
					Num = 2788,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 5,
				},
				{
					Value = 1,
					Num = 2988,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 5,
				},
				{
					Value = 1,
					Num = 2988,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2988,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 1,
				},
				{
					Value = 1,
					Num = 2988,
				},
			},
		},
	},
	DemandID = 410300,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
