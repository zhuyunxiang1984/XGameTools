NewbieConfig ={};
NewbieConfig["Newbie_PlanetUI"] =
{
	Id = 1,
	Node = "PlanetUI",
	Name = "准备出发！",
	Desc = "[714747]重点：指南中的任务板点击后可以查看详细教学。[-]",
	GoalList = {
		308828,
	},
}
NewbieConfig["Newbie_Explore"] =
{
	Id = 2,
	Node = "Explore",
	Name = "探索的教学",
	Desc = "[714747]重点：探索时长可以通过食物控制。[-]",
	GoalList = {
		308801,
		308802,
		308803,
		308804,
		308805,
		308806,
	},
}
NewbieConfig["Newbie_Challenge"] =
{
	Id = 3,
	Node = "Battle",
	Name = "挑战的教学",
	Desc = "[714747]重点：熟悉元素克制及角色站位能更容易“说服”对方。[-]",
	GoalList = {
		308807,
		308808,
		308809,
	},
}
NewbieConfig["Newbie_CharacterLevelUp"] =
{
	Id = 4,
	Node = "CharacterUpgrade",
	Name = "升级的教学",
	Desc = "[714747]重点：稀有度排序为灰、蓝、紫、金、彩，稀有度越高升级越昂贵。[-]",
	GoalList = {
		308810,
		308811,
		308812,
	},
}
NewbieConfig["Newbie_Workshop"] =
{
	Id = 5,
	Node = "Work",
	Name = "打工的教学",
	Desc = "[714747]重点：每个打工点都有对应的属性要求。[-]",
	GoalList = {
		308813,
		308814,
		308815,
	},
}
NewbieConfig["Newbie_Demand"] =
{
	Id = 6,
	Node = "Demand",
	Name = "委托的教学",
	Desc = "[714747]重点：委托删除后会冷却2分钟，还是尽量完成吧。[-]",
	GoalList = {
		308816,
		308817,
		308818,
	},
}
NewbieConfig["Newbie_Equipment"] =
{
	Id = 7,
	Node = "Equipment",
	Name = "装备的教学",
	Desc = "[714747]重点：升级装备可以大幅提升属性，不过需要完成委托获得对应零件。[-]",
	GoalList = {
		308819,
		308820,
		308821,
	},
}
NewbieConfig["Newbie_Craft"] =
{
	Id = 8,
	Node = "Laboratory",
	Name = "合成的教学",
	Desc = "[714747]重点：可以合成更高级的食物和捕捉道具，以及星球合成道具。[-]",
	GoalList = {
		308822,
		308823,
		308824,
	},
}
NewbieConfig["Newbie_Skin"] =
{
	Id = 9,
	Node = "CharacterSkin",
	Name = "皮肤的教学",
	Desc = "[714747]重点：角色的故事，解锁消耗日记页，挑战胜利后解锁皮肤。[-]",
	GoalList = {
		308825,
		308826,
		308827,
	},
}

