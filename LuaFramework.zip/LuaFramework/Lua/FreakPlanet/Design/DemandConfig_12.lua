
DemandConfig[DemandID.Id2594] =
{
	Id = 2594,
	Name = "订购封条1",
	Desc = "需要一些封条",
	Value = 321407,
	Active = true,
	Weight = 31020,
	PreGoal = 
	{
		300860,
		301276,
	},
	CloseGoal = 
	{
		301322,
	},
	GoodsId = 191407,
	Num = 54,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 55554,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 524,
				},
				{
					Value = 1,
					Num = 3154,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 524,
				},
				{
					Value = 1,
					Num = 3154,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 104,
				},
				{
					Value = 1,
					Num = 3554,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 104,
				},
				{
					Value = 1,
					Num = 3554,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 20,
				},
				{
					Value = 1,
					Num = 5554,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 20,
				},
				{
					Value = 1,
					Num = 5554,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 5554,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 5554,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 333,
				},
				{
					Value = 320051,
					Num = 222,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 66,
				},
				{
					Value = 320052,
					Num = 45,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 13,
				},
				{
					Value = 320053,
					Num = 9,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412594,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2602] =
{
	Id = 2602,
	Name = "订购海洋化石1",
	Desc = "需要一些海洋化石",
	Value = 321408,
	Active = true,
	Weight = 25185,
	PreGoal = 
	{
		300872,
		300888,
	},
	CloseGoal = 
	{
		301224,
	},
	GoodsId = 131408,
	Num = 40,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 44419,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 377,
				},
				{
					Value = 1,
					Num = 6719,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 377,
				},
				{
					Value = 1,
					Num = 6719,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 75,
				},
				{
					Value = 1,
					Num = 6919,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 75,
				},
				{
					Value = 1,
					Num = 6919,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 1,
					Num = 6919,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 15,
				},
				{
					Value = 1,
					Num = 6919,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 6919,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 6919,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 266,
				},
				{
					Value = 320051,
					Num = 178,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 53,
				},
				{
					Value = 320052,
					Num = 35,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 10,
				},
				{
					Value = 320053,
					Num = 7,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 320054,
					Num = 1,
				},
			},
		},
	},
	DemandID = 412602,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2603] =
{
	Id = 2603,
	Name = "订购海洋化石1",
	Desc = "需要一些海洋化石",
	Value = 321408,
	Active = true,
	Weight = 28635,
	PreGoal = 
	{
		300872,
		301232,
	},
	CloseGoal = 
	{
		301268,
	},
	GoodsId = 161408,
	Num = 49,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 54413,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 462,
				},
				{
					Value = 1,
					Num = 8213,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 462,
				},
				{
					Value = 1,
					Num = 8213,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 92,
				},
				{
					Value = 1,
					Num = 8413,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 92,
				},
				{
					Value = 1,
					Num = 8413,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 18,
				},
				{
					Value = 1,
					Num = 9413,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 18,
				},
				{
					Value = 1,
					Num = 9413,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 16913,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 16913,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 326,
				},
				{
					Value = 320051,
					Num = 218,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 65,
				},
				{
					Value = 320052,
					Num = 43,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 13,
				},
				{
					Value = 320053,
					Num = 8,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412603,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2604] =
{
	Id = 2604,
	Name = "订购海洋化石1",
	Desc = "需要一些海洋化石",
	Value = 321408,
	Active = true,
	Weight = 33465,
	PreGoal = 
	{
		300872,
		301288,
	},
	CloseGoal = 
	{
		301615,
	},
	GoodsId = 191408,
	Num = 54,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 59965,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 509,
				},
				{
					Value = 1,
					Num = 9065,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 509,
				},
				{
					Value = 1,
					Num = 9065,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 101,
				},
				{
					Value = 1,
					Num = 9465,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 101,
				},
				{
					Value = 1,
					Num = 9465,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 20,
				},
				{
					Value = 1,
					Num = 9965,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 20,
				},
				{
					Value = 1,
					Num = 9965,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 9965,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 9965,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 359,
				},
				{
					Value = 320051,
					Num = 240,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 71,
				},
				{
					Value = 320052,
					Num = 48,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 14,
				},
				{
					Value = 320053,
					Num = 9,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412604,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2612] =
{
	Id = 2612,
	Name = "订购青面具1",
	Desc = "需要一些青面具",
	Value = 321409,
	Active = true,
	Weight = 27360,
	PreGoal = 
	{
		300884,
		300900,
	},
	CloseGoal = 
	{
		301236,
	},
	GoodsId = 131409,
	Num = 42,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 47134,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 400,
				},
				{
					Value = 1,
					Num = 7134,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 400,
				},
				{
					Value = 1,
					Num = 7134,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 80,
				},
				{
					Value = 1,
					Num = 7134,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 80,
				},
				{
					Value = 1,
					Num = 7134,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 1,
					Num = 7134,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 16,
				},
				{
					Value = 1,
					Num = 7134,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 9634,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 9634,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 282,
				},
				{
					Value = 320051,
					Num = 189,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 56,
				},
				{
					Value = 320052,
					Num = 38,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 11,
				},
				{
					Value = 320053,
					Num = 7,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 320054,
					Num = 1,
				},
			},
		},
	},
	DemandID = 412612,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2613] =
{
	Id = 2613,
	Name = "订购青面具1",
	Desc = "需要一些青面具",
	Value = 321409,
	Active = true,
	Weight = 30960,
	PreGoal = 
	{
		300884,
		301244,
	},
	CloseGoal = 
	{
		301280,
	},
	GoodsId = 161409,
	Num = 52,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 58356,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 496,
				},
				{
					Value = 1,
					Num = 8756,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 496,
				},
				{
					Value = 1,
					Num = 8756,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 99,
				},
				{
					Value = 1,
					Num = 8856,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 99,
				},
				{
					Value = 1,
					Num = 8856,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 19,
				},
				{
					Value = 1,
					Num = 10856,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 19,
				},
				{
					Value = 1,
					Num = 10856,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 20856,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 20856,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 350,
				},
				{
					Value = 320051,
					Num = 233,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 70,
				},
				{
					Value = 320052,
					Num = 46,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 14,
				},
				{
					Value = 320053,
					Num = 9,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412613,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2614] =
{
	Id = 2614,
	Name = "订购青面具1",
	Desc = "需要一些青面具",
	Value = 321409,
	Active = true,
	Weight = 36000,
	PreGoal = 
	{
		300884,
		301301,
	},
	CloseGoal = 
	{
		301630,
	},
	GoodsId = 191409,
	Num = 54,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 60600,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 515,
				},
				{
					Value = 1,
					Num = 9100,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 515,
				},
				{
					Value = 1,
					Num = 9100,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 103,
				},
				{
					Value = 1,
					Num = 9100,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 103,
				},
				{
					Value = 1,
					Num = 9100,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 20,
				},
				{
					Value = 1,
					Num = 10600,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 20,
				},
				{
					Value = 1,
					Num = 10600,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 10600,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 10600,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 363,
				},
				{
					Value = 320051,
					Num = 243,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 72,
				},
				{
					Value = 320052,
					Num = 49,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 14,
				},
				{
					Value = 320053,
					Num = 10,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412614,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2622] =
{
	Id = 2622,
	Name = "订购龙角1",
	Desc = "需要一些龙角",
	Value = 321410,
	Active = true,
	Weight = 28860,
	PreGoal = 
	{
		300892,
		301204,
	},
	CloseGoal = 
	{
		301244,
	},
	GoodsId = 131410,
	Num = 40,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 50086,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 473,
				},
				{
					Value = 1,
					Num = 2786,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 473,
				},
				{
					Value = 1,
					Num = 2786,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 94,
				},
				{
					Value = 1,
					Num = 3086,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 94,
				},
				{
					Value = 1,
					Num = 3086,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 18,
				},
				{
					Value = 1,
					Num = 5086,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 18,
				},
				{
					Value = 1,
					Num = 5086,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 12586,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 12586,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 300,
				},
				{
					Value = 320051,
					Num = 200,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 60,
				},
				{
					Value = 320052,
					Num = 40,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 12,
				},
				{
					Value = 320053,
					Num = 8,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412622,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2623] =
{
	Id = 2623,
	Name = "订购龙角1",
	Desc = "需要一些龙角",
	Value = 321410,
	Active = true,
	Weight = 32560,
	PreGoal = 
	{
		300892,
		301252,
	},
	CloseGoal = 
	{
		301288,
	},
	GoodsId = 161410,
	Num = 49,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 61355,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 579,
				},
				{
					Value = 1,
					Num = 3455,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 579,
				},
				{
					Value = 1,
					Num = 3455,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 115,
				},
				{
					Value = 1,
					Num = 3855,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 115,
				},
				{
					Value = 1,
					Num = 3855,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 23,
				},
				{
					Value = 1,
					Num = 3855,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 23,
				},
				{
					Value = 1,
					Num = 3855,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 11355,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 11355,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 368,
				},
				{
					Value = 320051,
					Num = 245,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 73,
				},
				{
					Value = 320052,
					Num = 49,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 14,
				},
				{
					Value = 320053,
					Num = 10,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412623,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2624] =
{
	Id = 2624,
	Name = "订购龙角1",
	Desc = "需要一些龙角",
	Value = 321410,
	Active = true,
	Weight = 37740,
	PreGoal = 
	{
		300892,
		301310,
	},
	CloseGoal = 
	{
		301640,
	},
	GoodsId = 191410,
	Num = 49,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 61355,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 579,
				},
				{
					Value = 1,
					Num = 3455,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 579,
				},
				{
					Value = 1,
					Num = 3455,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 115,
				},
				{
					Value = 1,
					Num = 3855,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 115,
				},
				{
					Value = 1,
					Num = 3855,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 23,
				},
				{
					Value = 1,
					Num = 3855,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 23,
				},
				{
					Value = 1,
					Num = 3855,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 11355,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 11355,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 368,
				},
				{
					Value = 320051,
					Num = 245,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 73,
				},
				{
					Value = 320052,
					Num = 49,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 14,
				},
				{
					Value = 320053,
					Num = 10,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412624,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2632] =
{
	Id = 2632,
	Name = "订购箭头1",
	Desc = "需要一些箭头",
	Value = 321411,
	Active = true,
	Weight = 31185,
	PreGoal = 
	{
		300904,
		301224,
	},
	CloseGoal = 
	{
		301256,
	},
	GoodsId = 131411,
	Num = 42,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 53049,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 450,
				},
				{
					Value = 1,
					Num = 8049,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 450,
				},
				{
					Value = 1,
					Num = 8049,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 90,
				},
				{
					Value = 1,
					Num = 8049,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 90,
				},
				{
					Value = 1,
					Num = 8049,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 18,
				},
				{
					Value = 1,
					Num = 8049,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 18,
				},
				{
					Value = 1,
					Num = 8049,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 15549,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 15549,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 318,
				},
				{
					Value = 320051,
					Num = 212,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 63,
				},
				{
					Value = 320052,
					Num = 43,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 12,
				},
				{
					Value = 320053,
					Num = 9,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412632,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2633] =
{
	Id = 2633,
	Name = "订购箭头1",
	Desc = "需要一些箭头",
	Value = 321411,
	Active = true,
	Weight = 35035,
	PreGoal = 
	{
		300904,
		301264,
	},
	CloseGoal = 
	{
		301301,
	},
	GoodsId = 161411,
	Num = 49,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 61890,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 526,
				},
				{
					Value = 1,
					Num = 9290,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 526,
				},
				{
					Value = 1,
					Num = 9290,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 105,
				},
				{
					Value = 1,
					Num = 9390,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 105,
				},
				{
					Value = 1,
					Num = 9390,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 21,
				},
				{
					Value = 1,
					Num = 9390,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 21,
				},
				{
					Value = 1,
					Num = 9390,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 11890,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 11890,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 371,
				},
				{
					Value = 320051,
					Num = 247,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 74,
				},
				{
					Value = 320052,
					Num = 49,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 14,
				},
				{
					Value = 320053,
					Num = 10,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412633,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2634] =
{
	Id = 2634,
	Name = "订购箭头1",
	Desc = "需要一些箭头",
	Value = 321411,
	Active = true,
	Weight = 40425,
	PreGoal = 
	{
		300904,
		301322,
	},
	CloseGoal = 
	{
		301655,
	},
	GoodsId = 191411,
	Num = 49,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 61890,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 526,
				},
				{
					Value = 1,
					Num = 9290,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 526,
				},
				{
					Value = 1,
					Num = 9290,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 105,
				},
				{
					Value = 1,
					Num = 9390,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 105,
				},
				{
					Value = 1,
					Num = 9390,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 21,
				},
				{
					Value = 1,
					Num = 9390,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 21,
				},
				{
					Value = 1,
					Num = 9390,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 11890,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 11890,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 371,
				},
				{
					Value = 320051,
					Num = 247,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 74,
				},
				{
					Value = 320052,
					Num = 49,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 14,
				},
				{
					Value = 320053,
					Num = 10,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412634,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2642] =
{
	Id = 2642,
	Name = "订购黄蛋壳1",
	Desc = "需要一些黄蛋壳",
	Value = 321451,
	Active = true,
	Weight = 12276,
	PreGoal = 
	{
		301143,
		300860,
	},
	CloseGoal = 
	{
		300892,
	},
	GoodsId = 131451,
	Num = 18,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 129790,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 13,
				},
				{
					Value = 1,
					Num = 17470,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 4,
				},
				{
					Value = 1,
					Num = 26110,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 1,
				},
				{
					Value = 1,
					Num = 43390,
				},
			},
		},
	},
	DemandID = 412642,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2643] =
{
	Id = 2643,
	Name = "订购黄蛋壳1",
	Desc = "需要一些黄蛋壳",
	Value = 321451,
	Active = true,
	Weight = 14136,
	PreGoal = 
	{
		301143,
		300900,
	},
	CloseGoal = 
	{
		301240,
	},
	GoodsId = 161451,
	Num = 21,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 151421,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 15,
				},
				{
					Value = 1,
					Num = 21821,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 5,
				},
				{
					Value = 1,
					Num = 21821,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 1,
				},
				{
					Value = 1,
					Num = 65021,
				},
			},
		},
	},
	DemandID = 412643,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2644] =
{
	Id = 2644,
	Name = "订购黄蛋壳1",
	Desc = "需要一些黄蛋壳",
	Value = 321451,
	Active = true,
	Weight = 16740,
	PreGoal = 
	{
		301143,
		301260,
	},
	CloseGoal = 
	{
		301306,
	},
	GoodsId = 191451,
	Num = 27,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 194685,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 20,
				},
				{
					Value = 1,
					Num = 21885,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 6,
				},
				{
					Value = 1,
					Num = 39165,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 21885,
				},
			},
		},
	},
	DemandID = 412644,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2652] =
{
	Id = 2652,
	Name = "订购黄面具1",
	Desc = "需要一些黄面具",
	Value = 321452,
	Active = true,
	Weight = 16416,
	PreGoal = 
	{
		301144,
		300900,
	},
	CloseGoal = 
	{
		301236,
	},
	GoodsId = 131452,
	Num = 18,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 153192,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 16,
				},
				{
					Value = 1,
					Num = 14952,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 5,
				},
				{
					Value = 1,
					Num = 23592,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 1,
				},
				{
					Value = 1,
					Num = 66792,
				},
			},
		},
	},
	DemandID = 412652,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2653] =
{
	Id = 2653,
	Name = "订购黄面具1",
	Desc = "需要一些黄面具",
	Value = 321452,
	Active = true,
	Weight = 18576,
	PreGoal = 
	{
		301144,
		301244,
	},
	CloseGoal = 
	{
		301280,
	},
	GoodsId = 161452,
	Num = 24,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 204256,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 21,
				},
				{
					Value = 1,
					Num = 22816,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 7,
				},
				{
					Value = 1,
					Num = 22816,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 31456,
				},
			},
		},
	},
	DemandID = 412653,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2654] =
{
	Id = 2654,
	Name = "订购黄面具1",
	Desc = "需要一些黄面具",
	Value = 321452,
	Active = true,
	Weight = 21600,
	PreGoal = 
	{
		301144,
		301301,
	},
	CloseGoal = 
	{
		301630,
	},
	GoodsId = 191452,
	Num = 24,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 204256,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 21,
				},
				{
					Value = 1,
					Num = 22816,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 7,
				},
				{
					Value = 1,
					Num = 22816,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 31456,
				},
			},
		},
	},
	DemandID = 412654,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2662] =
{
	Id = 2662,
	Name = "订购化石骨1",
	Desc = "需要一些化石骨",
	Value = 321453,
	Active = true,
	Weight = 17316,
	PreGoal = 
	{
		301145,
		301204,
	},
	CloseGoal = 
	{
		301244,
	},
	GoodsId = 131453,
	Num = 15,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 158415,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 16,
				},
				{
					Value = 1,
					Num = 20175,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 5,
				},
				{
					Value = 1,
					Num = 28815,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 1,
				},
				{
					Value = 1,
					Num = 72015,
				},
			},
		},
	},
	DemandID = 412662,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2663] =
{
	Id = 2663,
	Name = "订购化石骨1",
	Desc = "需要一些化石骨",
	Value = 321453,
	Active = true,
	Weight = 19536,
	PreGoal = 
	{
		301145,
		301252,
	},
	CloseGoal = 
	{
		301288,
	},
	GoodsId = 161453,
	Num = 18,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 190098,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 20,
				},
				{
					Value = 1,
					Num = 17298,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 6,
				},
				{
					Value = 1,
					Num = 34578,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 17298,
				},
			},
		},
	},
	DemandID = 412663,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2664] =
{
	Id = 2664,
	Name = "订购化石骨1",
	Desc = "需要一些化石骨",
	Value = 321453,
	Active = true,
	Weight = 22644,
	PreGoal = 
	{
		301145,
		301310,
	},
	CloseGoal = 
	{
		301640,
	},
	GoodsId = 191453,
	Num = 18,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 190098,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 20,
				},
				{
					Value = 1,
					Num = 17298,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 6,
				},
				{
					Value = 1,
					Num = 34578,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 17298,
				},
			},
		},
	},
	DemandID = 412664,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2672] =
{
	Id = 2672,
	Name = "订购导览图1",
	Desc = "需要一些导览图",
	Value = 321454,
	Active = true,
	Weight = 18711,
	PreGoal = 
	{
		301146,
		301224,
	},
	CloseGoal = 
	{
		301256,
	},
	GoodsId = 131454,
	Num = 18,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 196045,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 20,
				},
				{
					Value = 1,
					Num = 23245,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 6,
				},
				{
					Value = 1,
					Num = 40525,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 23245,
				},
			},
		},
	},
	DemandID = 412672,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2673] =
{
	Id = 2673,
	Name = "订购导览图1",
	Desc = "需要一些导览图",
	Value = 321454,
	Active = true,
	Weight = 21021,
	PreGoal = 
	{
		301146,
		301264,
	},
	CloseGoal = 
	{
		301301,
	},
	GoodsId = 161454,
	Num = 18,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 196045,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 20,
				},
				{
					Value = 1,
					Num = 23245,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 6,
				},
				{
					Value = 1,
					Num = 40525,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 23245,
				},
			},
		},
	},
	DemandID = 412673,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2674] =
{
	Id = 2674,
	Name = "订购导览图1",
	Desc = "需要一些导览图",
	Value = 321454,
	Active = true,
	Weight = 24255,
	PreGoal = 
	{
		301146,
		301322,
	},
	CloseGoal = 
	{
		301655,
	},
	GoodsId = 191454,
	Num = 18,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 196045,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 20,
				},
				{
					Value = 1,
					Num = 23245,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 6,
				},
				{
					Value = 1,
					Num = 40525,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 23245,
				},
			},
		},
	},
	DemandID = 412674,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2682] =
{
	Id = 2682,
	Name = "订购暗恋1",
	Desc = "需要一些暗恋",
	Value = 321601,
	Active = true,
	Weight = 31980,
	PreGoal = 
	{
		301208,
		301228,
	},
	CloseGoal = 
	{
		301260,
	},
	GoodsId = 131601,
	Num = 45,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 57493,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 488,
				},
				{
					Value = 1,
					Num = 8693,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 488,
				},
				{
					Value = 1,
					Num = 8693,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 97,
				},
				{
					Value = 1,
					Num = 8993,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 97,
				},
				{
					Value = 1,
					Num = 8993,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 19,
				},
				{
					Value = 1,
					Num = 9993,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 19,
				},
				{
					Value = 1,
					Num = 9993,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 19993,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 19993,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 344,
				},
				{
					Value = 320051,
					Num = 230,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 68,
				},
				{
					Value = 320052,
					Num = 46,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 13,
				},
				{
					Value = 320053,
					Num = 9,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412682,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2683] =
{
	Id = 2683,
	Name = "订购暗恋1",
	Desc = "需要一些暗恋",
	Value = 321601,
	Active = true,
	Weight = 35880,
	PreGoal = 
	{
		301208,
		301268,
	},
	CloseGoal = 
	{
		301306,
	},
	GoodsId = 161601,
	Num = 49,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 62604,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 532,
				},
				{
					Value = 1,
					Num = 9404,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 532,
				},
				{
					Value = 1,
					Num = 9404,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 106,
				},
				{
					Value = 1,
					Num = 9604,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 106,
				},
				{
					Value = 1,
					Num = 9604,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 21,
				},
				{
					Value = 1,
					Num = 10104,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 21,
				},
				{
					Value = 1,
					Num = 10104,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 12604,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 12604,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 375,
				},
				{
					Value = 320051,
					Num = 251,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 75,
				},
				{
					Value = 320052,
					Num = 50,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 320053,
					Num = 10,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412683,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2684] =
{
	Id = 2684,
	Name = "订购暗恋1",
	Desc = "需要一些暗恋",
	Value = 321601,
	Active = true,
	Weight = 41340,
	PreGoal = 
	{
		301208,
		301327,
	},
	CloseGoal = 
	{
		301660,
	},
	GoodsId = 191601,
	Num = 49,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 62604,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 532,
				},
				{
					Value = 1,
					Num = 9404,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 532,
				},
				{
					Value = 1,
					Num = 9404,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 106,
				},
				{
					Value = 1,
					Num = 9604,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 106,
				},
				{
					Value = 1,
					Num = 9604,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 21,
				},
				{
					Value = 1,
					Num = 10104,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 21,
				},
				{
					Value = 1,
					Num = 10104,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 12604,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 12604,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 375,
				},
				{
					Value = 320051,
					Num = 251,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 75,
				},
				{
					Value = 320052,
					Num = 50,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 320053,
					Num = 10,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412684,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2692] =
{
	Id = 2692,
	Name = "订购新闻1",
	Desc = "需要一些新闻",
	Value = 321602,
	Active = true,
	Weight = 33600,
	PreGoal = 
	{
		301505,
		301236,
	},
	CloseGoal = 
	{
		301268,
	},
	GoodsId = 131602,
	Num = 40,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 59763,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 507,
				},
				{
					Value = 1,
					Num = 9063,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 507,
				},
				{
					Value = 1,
					Num = 9063,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 101,
				},
				{
					Value = 1,
					Num = 9263,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 101,
				},
				{
					Value = 1,
					Num = 9263,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 20,
				},
				{
					Value = 1,
					Num = 9763,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 20,
				},
				{
					Value = 1,
					Num = 9763,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 9763,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 9763,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 358,
				},
				{
					Value = 320051,
					Num = 239,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 71,
				},
				{
					Value = 320052,
					Num = 48,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 14,
				},
				{
					Value = 320053,
					Num = 9,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412692,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2693] =
{
	Id = 2693,
	Name = "订购新闻1",
	Desc = "需要一些新闻",
	Value = 321602,
	Active = true,
	Weight = 37600,
	PreGoal = 
	{
		301505,
		301276,
	},
	CloseGoal = 
	{
		301314,
	},
	GoodsId = 161602,
	Num = 42,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 62751,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 533,
				},
				{
					Value = 1,
					Num = 9451,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 533,
				},
				{
					Value = 1,
					Num = 9451,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 106,
				},
				{
					Value = 1,
					Num = 9751,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 106,
				},
				{
					Value = 1,
					Num = 9751,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 21,
				},
				{
					Value = 1,
					Num = 10251,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 21,
				},
				{
					Value = 1,
					Num = 10251,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 12751,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 12751,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 376,
				},
				{
					Value = 320051,
					Num = 251,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 75,
				},
				{
					Value = 320052,
					Num = 50,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 320053,
					Num = 10,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412693,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2694] =
{
	Id = 2694,
	Name = "订购新闻1",
	Desc = "需要一些新闻",
	Value = 321602,
	Active = true,
	Weight = 43200,
	PreGoal = 
	{
		301505,
		301615,
	},
	CloseGoal = 
	{
		301670,
	},
	GoodsId = 191602,
	Num = 42,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 62751,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 533,
				},
				{
					Value = 1,
					Num = 9451,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 533,
				},
				{
					Value = 1,
					Num = 9451,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 106,
				},
				{
					Value = 1,
					Num = 9751,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 106,
				},
				{
					Value = 1,
					Num = 9751,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 21,
				},
				{
					Value = 1,
					Num = 10251,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 21,
				},
				{
					Value = 1,
					Num = 10251,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 12751,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 12751,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 376,
				},
				{
					Value = 320051,
					Num = 251,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 75,
				},
				{
					Value = 320052,
					Num = 50,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 320053,
					Num = 10,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412694,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2702] =
{
	Id = 2702,
	Name = "订购羽毛1",
	Desc = "需要一些羽毛",
	Value = 321603,
	Active = true,
	Weight = 34425,
	PreGoal = 
	{
		301224,
		301240,
	},
	CloseGoal = 
	{
		301272,
	},
	GoodsId = 131603,
	Num = 45,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 60555,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 571,
				},
				{
					Value = 1,
					Num = 3455,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 571,
				},
				{
					Value = 1,
					Num = 3455,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 114,
				},
				{
					Value = 1,
					Num = 3555,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 114,
				},
				{
					Value = 1,
					Num = 3555,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 22,
				},
				{
					Value = 1,
					Num = 5555,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 22,
				},
				{
					Value = 1,
					Num = 5555,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 10555,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 10555,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 363,
				},
				{
					Value = 320051,
					Num = 242,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 72,
				},
				{
					Value = 320052,
					Num = 49,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 14,
				},
				{
					Value = 320053,
					Num = 10,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412702,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2703] =
{
	Id = 2703,
	Name = "订购羽毛1",
	Desc = "需要一些羽毛",
	Value = 321603,
	Active = true,
	Weight = 38475,
	PreGoal = 
	{
		301224,
		301280,
	},
	CloseGoal = 
	{
		301318,
	},
	GoodsId = 161603,
	Num = 48,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 64592,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 610,
				},
				{
					Value = 1,
					Num = 3592,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 610,
				},
				{
					Value = 1,
					Num = 3592,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 122,
				},
				{
					Value = 1,
					Num = 3592,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 122,
				},
				{
					Value = 1,
					Num = 3592,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 24,
				},
				{
					Value = 1,
					Num = 4592,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 24,
				},
				{
					Value = 1,
					Num = 4592,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 14592,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 14592,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 387,
				},
				{
					Value = 320051,
					Num = 258,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 77,
				},
				{
					Value = 320052,
					Num = 52,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 320053,
					Num = 10,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412703,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2704] =
{
	Id = 2704,
	Name = "订购羽毛1",
	Desc = "需要一些羽毛",
	Value = 321603,
	Active = true,
	Weight = 44145,
	PreGoal = 
	{
		301224,
		301620,
	},
	CloseGoal = 
	{
		301675,
	},
	GoodsId = 191603,
	Num = 48,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 64592,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 610,
				},
				{
					Value = 1,
					Num = 3592,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 610,
				},
				{
					Value = 1,
					Num = 3592,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 122,
				},
				{
					Value = 1,
					Num = 3592,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 122,
				},
				{
					Value = 1,
					Num = 3592,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 24,
				},
				{
					Value = 1,
					Num = 4592,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 24,
				},
				{
					Value = 1,
					Num = 4592,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 14592,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 14592,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 387,
				},
				{
					Value = 320051,
					Num = 258,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 77,
				},
				{
					Value = 320052,
					Num = 52,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 320053,
					Num = 10,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412704,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2712] =
{
	Id = 2712,
	Name = "订购钥匙1",
	Desc = "需要一些钥匙",
	Value = 321604,
	Active = true,
	Weight = 37825,
	PreGoal = 
	{
		301240,
		301256,
	},
	CloseGoal = 
	{
		301288,
	},
	GoodsId = 131604,
	Num = 45,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 64209,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 321,
				},
				{
					Value = 1,
					Num = 32109,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 321,
				},
				{
					Value = 1,
					Num = 32109,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 64,
				},
				{
					Value = 1,
					Num = 32209,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 64,
				},
				{
					Value = 1,
					Num = 32209,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 12,
				},
				{
					Value = 1,
					Num = 34209,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 12,
				},
				{
					Value = 1,
					Num = 34209,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 39209,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 39209,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 385,
				},
				{
					Value = 320051,
					Num = 257,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 77,
				},
				{
					Value = 320052,
					Num = 51,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 320053,
					Num = 10,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412712,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2713] =
{
	Id = 2713,
	Name = "订购钥匙1",
	Desc = "需要一些钥匙",
	Value = 321604,
	Active = true,
	Weight = 42075,
	PreGoal = 
	{
		301240,
		301297,
	},
	CloseGoal = 
	{
		301615,
	},
	GoodsId = 161604,
	Num = 45,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 64209,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 321,
				},
				{
					Value = 1,
					Num = 32109,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 321,
				},
				{
					Value = 1,
					Num = 32109,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 64,
				},
				{
					Value = 1,
					Num = 32209,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 64,
				},
				{
					Value = 1,
					Num = 32209,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 12,
				},
				{
					Value = 1,
					Num = 34209,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 12,
				},
				{
					Value = 1,
					Num = 34209,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 39209,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 39209,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 385,
				},
				{
					Value = 320051,
					Num = 257,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 77,
				},
				{
					Value = 320052,
					Num = 51,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 320053,
					Num = 10,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412713,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2714] =
{
	Id = 2714,
	Name = "订购钥匙1",
	Desc = "需要一些钥匙",
	Value = 321604,
	Active = true,
	Weight = 48025,
	PreGoal = 
	{
		301240,
		301640,
	},
	CloseGoal = 
	{
		301695,
	},
	GoodsId = 191604,
	Num = 45,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 64209,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 321,
				},
				{
					Value = 1,
					Num = 32109,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 321,
				},
				{
					Value = 1,
					Num = 32109,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 64,
				},
				{
					Value = 1,
					Num = 32209,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 64,
				},
				{
					Value = 1,
					Num = 32209,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 12,
				},
				{
					Value = 1,
					Num = 34209,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 12,
				},
				{
					Value = 1,
					Num = 34209,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 39209,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 39209,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 385,
				},
				{
					Value = 320051,
					Num = 257,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 77,
				},
				{
					Value = 320052,
					Num = 51,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 320053,
					Num = 10,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412714,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2722] =
{
	Id = 2722,
	Name = "订购脚印1",
	Desc = "需要一些脚印",
	Value = 321605,
	Active = true,
	Weight = 41385,
	PreGoal = 
	{
		301518,
		301272,
	},
	CloseGoal = 
	{
		301306,
	},
	GoodsId = 131605,
	Num = 42,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 66855,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 568,
				},
				{
					Value = 1,
					Num = 10055,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 568,
				},
				{
					Value = 1,
					Num = 10055,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 113,
				},
				{
					Value = 1,
					Num = 10355,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 113,
				},
				{
					Value = 1,
					Num = 10355,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 22,
				},
				{
					Value = 1,
					Num = 11855,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 22,
				},
				{
					Value = 1,
					Num = 11855,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 16855,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 16855,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 401,
				},
				{
					Value = 320051,
					Num = 267,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 80,
				},
				{
					Value = 320052,
					Num = 53,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 320053,
					Num = 10,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412722,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2723] =
{
	Id = 2723,
	Name = "订购脚印1",
	Desc = "需要一些脚印",
	Value = 321605,
	Active = true,
	Weight = 45835,
	PreGoal = 
	{
		301518,
		301314,
	},
	CloseGoal = 
	{
		301635,
	},
	GoodsId = 161605,
	Num = 42,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 66855,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 568,
				},
				{
					Value = 1,
					Num = 10055,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 568,
				},
				{
					Value = 1,
					Num = 10055,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 113,
				},
				{
					Value = 1,
					Num = 10355,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 113,
				},
				{
					Value = 1,
					Num = 10355,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 22,
				},
				{
					Value = 1,
					Num = 11855,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 22,
				},
				{
					Value = 1,
					Num = 11855,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 16855,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 16855,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 401,
				},
				{
					Value = 320051,
					Num = 267,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 80,
				},
				{
					Value = 320052,
					Num = 53,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 320053,
					Num = 10,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412723,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2724] =
{
	Id = 2724,
	Name = "订购脚印1",
	Desc = "需要一些脚印",
	Value = 321605,
	Active = true,
	Weight = 52065,
	PreGoal = 
	{
		301518,
		301660,
	},
	CloseGoal = 
	{
		301715,
	},
	GoodsId = 191605,
	Num = 42,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 66855,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 568,
				},
				{
					Value = 1,
					Num = 10055,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 568,
				},
				{
					Value = 1,
					Num = 10055,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 113,
				},
				{
					Value = 1,
					Num = 10355,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 113,
				},
				{
					Value = 1,
					Num = 10355,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 22,
				},
				{
					Value = 1,
					Num = 11855,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 22,
				},
				{
					Value = 1,
					Num = 11855,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 16855,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 16855,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 401,
				},
				{
					Value = 320051,
					Num = 267,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 80,
				},
				{
					Value = 320052,
					Num = 53,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 320053,
					Num = 10,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412724,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2732] =
{
	Id = 2732,
	Name = "订购烟头1",
	Desc = "需要一些烟头",
	Value = 321606,
	Active = true,
	Weight = 41385,
	PreGoal = 
	{
		301256,
		301272,
	},
	CloseGoal = 
	{
		301306,
	},
	GoodsId = 131606,
	Num = 42,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 67208,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 571,
				},
				{
					Value = 1,
					Num = 10108,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 571,
				},
				{
					Value = 1,
					Num = 10108,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 114,
				},
				{
					Value = 1,
					Num = 10208,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 114,
				},
				{
					Value = 1,
					Num = 10208,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 22,
				},
				{
					Value = 1,
					Num = 12208,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 22,
				},
				{
					Value = 1,
					Num = 12208,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 17208,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 17208,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 403,
				},
				{
					Value = 320051,
					Num = 269,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 80,
				},
				{
					Value = 320052,
					Num = 54,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 320053,
					Num = 10,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412732,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2733] =
{
	Id = 2733,
	Name = "订购烟头1",
	Desc = "需要一些烟头",
	Value = 321606,
	Active = true,
	Weight = 45835,
	PreGoal = 
	{
		301256,
		301314,
	},
	CloseGoal = 
	{
		301635,
	},
	GoodsId = 161606,
	Num = 42,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 67208,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 571,
				},
				{
					Value = 1,
					Num = 10108,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 571,
				},
				{
					Value = 1,
					Num = 10108,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 114,
				},
				{
					Value = 1,
					Num = 10208,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 114,
				},
				{
					Value = 1,
					Num = 10208,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 22,
				},
				{
					Value = 1,
					Num = 12208,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 22,
				},
				{
					Value = 1,
					Num = 12208,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 17208,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 17208,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 403,
				},
				{
					Value = 320051,
					Num = 269,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 80,
				},
				{
					Value = 320052,
					Num = 54,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 320053,
					Num = 10,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412733,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2734] =
{
	Id = 2734,
	Name = "订购烟头1",
	Desc = "需要一些烟头",
	Value = 321606,
	Active = true,
	Weight = 52065,
	PreGoal = 
	{
		301256,
		301660,
	},
	CloseGoal = 
	{
		301715,
	},
	GoodsId = 191606,
	Num = 42,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 67208,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 571,
				},
				{
					Value = 1,
					Num = 10108,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 571,
				},
				{
					Value = 1,
					Num = 10108,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 114,
				},
				{
					Value = 1,
					Num = 10208,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 114,
				},
				{
					Value = 1,
					Num = 10208,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 22,
				},
				{
					Value = 1,
					Num = 12208,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 22,
				},
				{
					Value = 1,
					Num = 12208,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 17208,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 17208,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 403,
				},
				{
					Value = 320051,
					Num = 269,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 80,
				},
				{
					Value = 320052,
					Num = 54,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 320053,
					Num = 10,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412734,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2742] =
{
	Id = 2742,
	Name = "订购指纹1",
	Desc = "需要一些指纹",
	Value = 321607,
	Active = true,
	Weight = 45105,
	PreGoal = 
	{
		301272,
		301288,
	},
	CloseGoal = 
	{
		301322,
	},
	GoodsId = 131607,
	Num = 42,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 69630,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 591,
				},
				{
					Value = 1,
					Num = 10530,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 591,
				},
				{
					Value = 1,
					Num = 10530,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 118,
				},
				{
					Value = 1,
					Num = 10630,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 118,
				},
				{
					Value = 1,
					Num = 10630,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 23,
				},
				{
					Value = 1,
					Num = 12130,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 23,
				},
				{
					Value = 1,
					Num = 12130,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 19630,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 19630,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 417,
				},
				{
					Value = 320051,
					Num = 279,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 83,
				},
				{
					Value = 320052,
					Num = 56,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 320053,
					Num = 11,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412742,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2743] =
{
	Id = 2743,
	Name = "订购指纹1",
	Desc = "需要一些指纹",
	Value = 321607,
	Active = true,
	Weight = 49755,
	PreGoal = 
	{
		301272,
		301605,
	},
	CloseGoal = 
	{
		301655,
	},
	GoodsId = 161607,
	Num = 42,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 69630,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 591,
				},
				{
					Value = 1,
					Num = 10530,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 591,
				},
				{
					Value = 1,
					Num = 10530,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 118,
				},
				{
					Value = 1,
					Num = 10630,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 118,
				},
				{
					Value = 1,
					Num = 10630,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 23,
				},
				{
					Value = 1,
					Num = 12130,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 23,
				},
				{
					Value = 1,
					Num = 12130,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 19630,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 19630,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 417,
				},
				{
					Value = 320051,
					Num = 279,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 83,
				},
				{
					Value = 320052,
					Num = 56,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 320053,
					Num = 11,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412743,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2744] =
{
	Id = 2744,
	Name = "订购指纹1",
	Desc = "需要一些指纹",
	Value = 321607,
	Active = true,
	Weight = 56265,
	PreGoal = 
	{
		301272,
		301680,
	},
	GoodsId = 191607,
	Num = 42,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 69630,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 591,
				},
				{
					Value = 1,
					Num = 10530,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 591,
				},
				{
					Value = 1,
					Num = 10530,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 118,
				},
				{
					Value = 1,
					Num = 10630,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 118,
				},
				{
					Value = 1,
					Num = 10630,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 23,
				},
				{
					Value = 1,
					Num = 12130,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 23,
				},
				{
					Value = 1,
					Num = 12130,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 19630,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 19630,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 417,
				},
				{
					Value = 320051,
					Num = 279,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 83,
				},
				{
					Value = 320052,
					Num = 56,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 320053,
					Num = 11,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412744,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2752] =
{
	Id = 2752,
	Name = "订购墨水1",
	Desc = "需要一些墨水",
	Value = 321608,
	Active = true,
	Weight = 48985,
	PreGoal = 
	{
		301288,
		301306,
	},
	CloseGoal = 
	{
		301620,
	},
	GoodsId = 131608,
	Num = 39,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 71531,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 608,
				},
				{
					Value = 1,
					Num = 10731,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 608,
				},
				{
					Value = 1,
					Num = 10731,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 121,
				},
				{
					Value = 1,
					Num = 11031,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 121,
				},
				{
					Value = 1,
					Num = 11031,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 24,
				},
				{
					Value = 1,
					Num = 11531,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 24,
				},
				{
					Value = 1,
					Num = 11531,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 21531,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 21531,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 429,
				},
				{
					Value = 320051,
					Num = 286,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 85,
				},
				{
					Value = 320052,
					Num = 58,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 17,
				},
				{
					Value = 320053,
					Num = 11,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412752,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2753] =
{
	Id = 2753,
	Name = "订购墨水1",
	Desc = "需要一些墨水",
	Value = 321608,
	Active = true,
	Weight = 53835,
	PreGoal = 
	{
		301288,
		301630,
	},
	CloseGoal = 
	{
		301675,
	},
	GoodsId = 161608,
	Num = 39,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 71531,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 608,
				},
				{
					Value = 1,
					Num = 10731,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 608,
				},
				{
					Value = 1,
					Num = 10731,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 121,
				},
				{
					Value = 1,
					Num = 11031,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 121,
				},
				{
					Value = 1,
					Num = 11031,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 24,
				},
				{
					Value = 1,
					Num = 11531,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 24,
				},
				{
					Value = 1,
					Num = 11531,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 21531,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 21531,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 429,
				},
				{
					Value = 320051,
					Num = 286,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 85,
				},
				{
					Value = 320052,
					Num = 58,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 17,
				},
				{
					Value = 320053,
					Num = 11,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412753,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2754] =
{
	Id = 2754,
	Name = "订购墨水1",
	Desc = "需要一些墨水",
	Value = 321608,
	Active = true,
	Weight = 60625,
	PreGoal = 
	{
		301288,
		301700,
	},
	GoodsId = 191608,
	Num = 39,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 71531,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 608,
				},
				{
					Value = 1,
					Num = 10731,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 608,
				},
				{
					Value = 1,
					Num = 10731,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 121,
				},
				{
					Value = 1,
					Num = 11031,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 121,
				},
				{
					Value = 1,
					Num = 11031,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 24,
				},
				{
					Value = 1,
					Num = 11531,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 24,
				},
				{
					Value = 1,
					Num = 11531,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 21531,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 21531,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 429,
				},
				{
					Value = 320051,
					Num = 286,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 85,
				},
				{
					Value = 320052,
					Num = 58,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 17,
				},
				{
					Value = 320053,
					Num = 11,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412754,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2762] =
{
	Id = 2762,
	Name = "订购皮鞭1",
	Desc = "需要一些皮鞭",
	Value = 321609,
	Active = true,
	Weight = 52000,
	PreGoal = 
	{
		301535,
		301318,
	},
	CloseGoal = 
	{
		301635,
	},
	GoodsId = 131609,
	Num = 37,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 73607,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 695,
				},
				{
					Value = 1,
					Num = 4107,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 139,
				},
				{
					Value = 1,
					Num = 4107,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 27,
				},
				{
					Value = 1,
					Num = 6107,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 5,
				},
				{
					Value = 1,
					Num = 11107,
				},
			},
		},
	},
	DemandID = 412762,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2763] =
{
	Id = 2763,
	Name = "订购皮鞭1",
	Desc = "需要一些皮鞭",
	Value = 321609,
	Active = true,
	Weight = 57000,
	PreGoal = 
	{
		301535,
		301645,
	},
	CloseGoal = 
	{
		301690,
	},
	GoodsId = 161609,
	Num = 37,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 73607,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 695,
				},
				{
					Value = 1,
					Num = 4107,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 139,
				},
				{
					Value = 1,
					Num = 4107,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 27,
				},
				{
					Value = 1,
					Num = 6107,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 5,
				},
				{
					Value = 1,
					Num = 11107,
				},
			},
		},
	},
	DemandID = 412763,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2764] =
{
	Id = 2764,
	Name = "订购皮鞭1",
	Desc = "需要一些皮鞭",
	Value = 321609,
	Active = true,
	Weight = 64000,
	PreGoal = 
	{
		301535,
		301715,
	},
	GoodsId = 191609,
	Num = 37,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 73607,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 695,
				},
				{
					Value = 1,
					Num = 4107,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 139,
				},
				{
					Value = 1,
					Num = 4107,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 27,
				},
				{
					Value = 1,
					Num = 6107,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 5,
				},
				{
					Value = 1,
					Num = 11107,
				},
			},
		},
	},
	DemandID = 412764,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2772] =
{
	Id = 2772,
	Name = "订购黄瓜马赛克1",
	Desc = "需要一些黄瓜马赛克",
	Value = 321610,
	Active = true,
	Weight = 52000,
	PreGoal = 
	{
		301301,
		301318,
	},
	CloseGoal = 
	{
		301635,
	},
	GoodsId = 131610,
	Num = 37,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 70624,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 600,
				},
				{
					Value = 1,
					Num = 10624,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 600,
				},
				{
					Value = 1,
					Num = 10624,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 120,
				},
				{
					Value = 1,
					Num = 10624,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 120,
				},
				{
					Value = 1,
					Num = 10624,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 24,
				},
				{
					Value = 1,
					Num = 10624,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 24,
				},
				{
					Value = 1,
					Num = 10624,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 20624,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 20624,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 423,
				},
				{
					Value = 320051,
					Num = 283,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 84,
				},
				{
					Value = 320052,
					Num = 57,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 320053,
					Num = 12,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412772,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2773] =
{
	Id = 2773,
	Name = "订购黄瓜马赛克1",
	Desc = "需要一些黄瓜马赛克",
	Value = 321610,
	Active = true,
	Weight = 57000,
	PreGoal = 
	{
		301301,
		301645,
	},
	CloseGoal = 
	{
		301690,
	},
	GoodsId = 161610,
	Num = 37,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 70624,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 600,
				},
				{
					Value = 1,
					Num = 10624,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 600,
				},
				{
					Value = 1,
					Num = 10624,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 120,
				},
				{
					Value = 1,
					Num = 10624,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 120,
				},
				{
					Value = 1,
					Num = 10624,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 24,
				},
				{
					Value = 1,
					Num = 10624,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 24,
				},
				{
					Value = 1,
					Num = 10624,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 20624,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 20624,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 423,
				},
				{
					Value = 320051,
					Num = 283,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 84,
				},
				{
					Value = 320052,
					Num = 57,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 320053,
					Num = 12,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412773,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2774] =
{
	Id = 2774,
	Name = "订购黄瓜马赛克1",
	Desc = "需要一些黄瓜马赛克",
	Value = 321610,
	Active = true,
	Weight = 64000,
	PreGoal = 
	{
		301301,
		301715,
	},
	GoodsId = 191610,
	Num = 37,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 70624,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 600,
				},
				{
					Value = 1,
					Num = 10624,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 600,
				},
				{
					Value = 1,
					Num = 10624,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 120,
				},
				{
					Value = 1,
					Num = 10624,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 120,
				},
				{
					Value = 1,
					Num = 10624,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 24,
				},
				{
					Value = 1,
					Num = 10624,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 24,
				},
				{
					Value = 1,
					Num = 10624,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 20624,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 20624,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 423,
				},
				{
					Value = 320051,
					Num = 283,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 84,
				},
				{
					Value = 320052,
					Num = 57,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 16,
				},
				{
					Value = 320053,
					Num = 12,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412774,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2782] =
{
	Id = 2782,
	Name = "订购灵感1",
	Desc = "需要一些灵感",
	Value = 321611,
	Active = true,
	Weight = 55105,
	PreGoal = 
	{
		301314,
		301605,
	},
	CloseGoal = 
	{
		301650,
	},
	GoodsId = 131611,
	Num = 37,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 73607,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 625,
				},
				{
					Value = 1,
					Num = 11107,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 625,
				},
				{
					Value = 1,
					Num = 11107,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 125,
				},
				{
					Value = 1,
					Num = 11107,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 125,
				},
				{
					Value = 1,
					Num = 11107,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 25,
				},
				{
					Value = 1,
					Num = 11107,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 25,
				},
				{
					Value = 1,
					Num = 11107,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 5,
				},
				{
					Value = 1,
					Num = 11107,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 5,
				},
				{
					Value = 1,
					Num = 11107,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 441,
				},
				{
					Value = 320051,
					Num = 295,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 88,
				},
				{
					Value = 320052,
					Num = 59,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 17,
				},
				{
					Value = 320053,
					Num = 12,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412782,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2783] =
{
	Id = 2783,
	Name = "订购灵感1",
	Desc = "需要一些灵感",
	Value = 321611,
	Active = true,
	Weight = 60255,
	PreGoal = 
	{
		301314,
		301660,
	},
	CloseGoal = 
	{
		301705,
	},
	GoodsId = 161611,
	Num = 37,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 73607,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 625,
				},
				{
					Value = 1,
					Num = 11107,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 625,
				},
				{
					Value = 1,
					Num = 11107,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 125,
				},
				{
					Value = 1,
					Num = 11107,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 125,
				},
				{
					Value = 1,
					Num = 11107,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 25,
				},
				{
					Value = 1,
					Num = 11107,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 25,
				},
				{
					Value = 1,
					Num = 11107,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 5,
				},
				{
					Value = 1,
					Num = 11107,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 5,
				},
				{
					Value = 1,
					Num = 11107,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 441,
				},
				{
					Value = 320051,
					Num = 295,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 88,
				},
				{
					Value = 320052,
					Num = 59,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 17,
				},
				{
					Value = 320053,
					Num = 12,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412783,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2784] =
{
	Id = 2784,
	Name = "订购灵感1",
	Desc = "需要一些灵感",
	Value = 321611,
	Active = true,
	Weight = 67465,
	PreGoal = 
	{
		301314,
		301730,
	},
	GoodsId = 191611,
	Num = 37,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 73607,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 625,
				},
				{
					Value = 1,
					Num = 11107,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 625,
				},
				{
					Value = 1,
					Num = 11107,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 125,
				},
				{
					Value = 1,
					Num = 11107,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 125,
				},
				{
					Value = 1,
					Num = 11107,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 25,
				},
				{
					Value = 1,
					Num = 11107,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 25,
				},
				{
					Value = 1,
					Num = 11107,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 5,
				},
				{
					Value = 1,
					Num = 11107,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 5,
				},
				{
					Value = 1,
					Num = 11107,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 441,
				},
				{
					Value = 320051,
					Num = 295,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 88,
				},
				{
					Value = 320052,
					Num = 59,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 17,
				},
				{
					Value = 320053,
					Num = 12,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 320054,
					Num = 2,
				},
			},
		},
	},
	DemandID = 412784,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2792] =
{
	Id = 2792,
	Name = "订购营养液1",
	Desc = "需要一些营养液",
	Value = 321612,
	Active = true,
	Weight = 57225,
	PreGoal = 
	{
		301543,
		301620,
	},
	CloseGoal = 
	{
		301660,
	},
	GoodsId = 131612,
	Num = 36,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 77948,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 736,
				},
				{
					Value = 1,
					Num = 4348,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 147,
				},
				{
					Value = 1,
					Num = 4448,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 29,
				},
				{
					Value = 1,
					Num = 5448,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 5,
				},
				{
					Value = 1,
					Num = 15448,
				},
			},
		},
	},
	DemandID = 412792,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2793] =
{
	Id = 2793,
	Name = "订购营养液1",
	Desc = "需要一些营养液",
	Value = 321612,
	Active = true,
	Weight = 62475,
	PreGoal = 
	{
		301543,
		301670,
	},
	CloseGoal = 
	{
		301715,
	},
	GoodsId = 161612,
	Num = 36,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 77948,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 736,
				},
				{
					Value = 1,
					Num = 4348,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 147,
				},
				{
					Value = 1,
					Num = 4448,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 29,
				},
				{
					Value = 1,
					Num = 5448,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 5,
				},
				{
					Value = 1,
					Num = 15448,
				},
			},
		},
	},
	DemandID = 412793,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2794] =
{
	Id = 2794,
	Name = "订购营养液1",
	Desc = "需要一些营养液",
	Value = 321612,
	Active = true,
	Weight = 68775,
	PreGoal = 
	{
		301543,
		301730,
	},
	GoodsId = 191612,
	Num = 36,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 77948,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 736,
				},
				{
					Value = 1,
					Num = 4348,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 147,
				},
				{
					Value = 1,
					Num = 4448,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 29,
				},
				{
					Value = 1,
					Num = 5448,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 5,
				},
				{
					Value = 1,
					Num = 15448,
				},
			},
		},
	},
	DemandID = 412794,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2802] =
{
	Id = 2802,
	Name = "订购谣言1",
	Desc = "需要一些谣言",
	Value = 321651,
	Active = true,
	Weight = 20160,
	PreGoal = 
	{
		301556,
		301236,
	},
	CloseGoal = 
	{
		301268,
	},
	GoodsId = 131651,
	Num = 27,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 306694,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 10,
				},
				{
					Value = 1,
					Num = 47494,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 3,
				},
				{
					Value = 1,
					Num = 47494,
				},
			},
		},
	},
	DemandID = 412802,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2803] =
{
	Id = 2803,
	Name = "订购谣言1",
	Desc = "需要一些谣言",
	Value = 321651,
	Active = true,
	Weight = 22560,
	PreGoal = 
	{
		301556,
		301276,
	},
	CloseGoal = 
	{
		301314,
	},
	GoodsId = 161651,
	Num = 27,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 306694,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 10,
				},
				{
					Value = 1,
					Num = 47494,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 3,
				},
				{
					Value = 1,
					Num = 47494,
				},
			},
		},
	},
	DemandID = 412803,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2804] =
{
	Id = 2804,
	Name = "订购谣言1",
	Desc = "需要一些谣言",
	Value = 321651,
	Active = true,
	Weight = 25920,
	PreGoal = 
	{
		301556,
		301615,
	},
	CloseGoal = 
	{
		301670,
	},
	GoodsId = 191651,
	Num = 27,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 306694,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 10,
				},
				{
					Value = 1,
					Num = 47494,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 3,
				},
				{
					Value = 1,
					Num = 47494,
				},
			},
		},
	},
	DemandID = 412804,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2812] =
{
	Id = 2812,
	Name = "订购肖像侧写1",
	Desc = "需要一些肖像侧写",
	Value = 321652,
	Active = true,
	Weight = 24831,
	PreGoal = 
	{
		301557,
		301272,
	},
	CloseGoal = 
	{
		301306,
	},
	GoodsId = 131652,
	Num = 22,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 350750,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 12,
				},
				{
					Value = 1,
					Num = 39710,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 3,
				},
				{
					Value = 1,
					Num = 91550,
				},
			},
		},
	},
	DemandID = 412812,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2813] =
{
	Id = 2813,
	Name = "订购肖像侧写1",
	Desc = "需要一些肖像侧写",
	Value = 321652,
	Active = true,
	Weight = 27501,
	PreGoal = 
	{
		301557,
		301314,
	},
	CloseGoal = 
	{
		301635,
	},
	GoodsId = 161652,
	Num = 22,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 350750,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 12,
				},
				{
					Value = 1,
					Num = 39710,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 3,
				},
				{
					Value = 1,
					Num = 91550,
				},
			},
		},
	},
	DemandID = 412813,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2814] =
{
	Id = 2814,
	Name = "订购肖像侧写1",
	Desc = "需要一些肖像侧写",
	Value = 321652,
	Active = true,
	Weight = 31239,
	PreGoal = 
	{
		301557,
		301660,
	},
	CloseGoal = 
	{
		301715,
	},
	GoodsId = 191652,
	Num = 22,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 350750,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 12,
				},
				{
					Value = 1,
					Num = 39710,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 3,
				},
				{
					Value = 1,
					Num = 91550,
				},
			},
		},
	},
	DemandID = 412814,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2822] =
{
	Id = 2822,
	Name = "订购欠条1",
	Desc = "需要一些欠条",
	Value = 321653,
	Active = true,
	Weight = 29391,
	PreGoal = 
	{
		301558,
		301306,
	},
	CloseGoal = 
	{
		301620,
	},
	GoodsId = 131653,
	Num = 18,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 317454,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 11,
				},
				{
					Value = 1,
					Num = 32334,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 3,
				},
				{
					Value = 1,
					Num = 58254,
				},
			},
		},
	},
	DemandID = 412822,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2823] =
{
	Id = 2823,
	Name = "订购欠条1",
	Desc = "需要一些欠条",
	Value = 321653,
	Active = true,
	Weight = 32301,
	PreGoal = 
	{
		301558,
		301630,
	},
	CloseGoal = 
	{
		301675,
	},
	GoodsId = 161653,
	Num = 18,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 317454,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 11,
				},
				{
					Value = 1,
					Num = 32334,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 3,
				},
				{
					Value = 1,
					Num = 58254,
				},
			},
		},
	},
	DemandID = 412823,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2824] =
{
	Id = 2824,
	Name = "订购欠条1",
	Desc = "需要一些欠条",
	Value = 321653,
	Active = true,
	Weight = 36375,
	PreGoal = 
	{
		301558,
		301700,
	},
	GoodsId = 191653,
	Num = 18,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 317454,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 11,
				},
				{
					Value = 1,
					Num = 32334,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 3,
				},
				{
					Value = 1,
					Num = 58254,
				},
			},
		},
	},
	DemandID = 412824,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2832] =
{
	Id = 2832,
	Name = "订购18X1",
	Desc = "需要一些18X",
	Value = 321654,
	Active = true,
	Weight = 31200,
	PreGoal = 
	{
		301559,
		301318,
	},
	CloseGoal = 
	{
		301635,
	},
	GoodsId = 131654,
	Num = 18,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 350834,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 12,
				},
				{
					Value = 1,
					Num = 39794,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 3,
				},
				{
					Value = 1,
					Num = 91634,
				},
			},
		},
	},
	DemandID = 412832,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2833] =
{
	Id = 2833,
	Name = "订购18X1",
	Desc = "需要一些18X",
	Value = 321654,
	Active = true,
	Weight = 34200,
	PreGoal = 
	{
		301559,
		301645,
	},
	CloseGoal = 
	{
		301690,
	},
	GoodsId = 161654,
	Num = 18,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 350834,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 12,
				},
				{
					Value = 1,
					Num = 39794,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 3,
				},
				{
					Value = 1,
					Num = 91634,
				},
			},
		},
	},
	DemandID = 412833,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2834] =
{
	Id = 2834,
	Name = "订购18X1",
	Desc = "需要一些18X",
	Value = 321654,
	Active = true,
	Weight = 38400,
	PreGoal = 
	{
		301559,
		301715,
	},
	GoodsId = 191654,
	Num = 18,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 350834,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 12,
				},
				{
					Value = 1,
					Num = 39794,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 3,
				},
				{
					Value = 1,
					Num = 91634,
				},
			},
		},
	},
	DemandID = 412834,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2842] =
{
	Id = 2842,
	Name = "补充铁质",
	Desc = "最近一摔跤就骨折，医生建议我多补充铁质",
	Value = 321801,
	Active = true,
	Weight = 58300,
	PreGoal = 
	{
		301327,
		301625,
	},
	CloseGoal = 
	{
		301665,
	},
	GoodsId = 131801,
	Num = 243,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 117709,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 200,
				},
				{
					Value = 1,
					Num = 17709,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 200,
				},
				{
					Value = 1,
					Num = 17709,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 40,
				},
				{
					Value = 1,
					Num = 17709,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 40,
				},
				{
					Value = 1,
					Num = 17709,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 8,
				},
				{
					Value = 1,
					Num = 17709,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 8,
				},
				{
					Value = 1,
					Num = 17709,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 706,
				},
				{
					Value = 320051,
					Num = 471,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 141,
				},
				{
					Value = 320052,
					Num = 94,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 28,
				},
				{
					Value = 320053,
					Num = 19,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 5,
				},
				{
					Value = 320054,
					Num = 4,
				},
			},
		},
	},
	DemandID = 412842,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2843] =
{
	Id = 2843,
	Name = "补充铁质",
	Desc = "最近一摔跤就骨折，医生建议我多补充铁质",
	Value = 321801,
	Active = true,
	Weight = 63600,
	PreGoal = 
	{
		301327,
		301675,
	},
	CloseGoal = 
	{
		301720,
	},
	GoodsId = 161801,
	Num = 360,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 174384,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 296,
				},
				{
					Value = 1,
					Num = 26384,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 296,
				},
				{
					Value = 1,
					Num = 26384,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 59,
				},
				{
					Value = 1,
					Num = 26884,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 59,
				},
				{
					Value = 1,
					Num = 26884,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 11,
				},
				{
					Value = 1,
					Num = 36884,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 11,
				},
				{
					Value = 1,
					Num = 36884,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 209,
				},
				{
					Value = 320052,
					Num = 139,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 41,
				},
				{
					Value = 320053,
					Num = 28,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 8,
				},
				{
					Value = 320054,
					Num = 5,
				},
			},
		},
	},
	DemandID = 412843,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2844] =
{
	Id = 2844,
	Name = "补充铁质",
	Desc = "最近一摔跤就骨折，医生建议我多补充铁质",
	Value = 321801,
	Active = true,
	Weight = 69430,
	PreGoal = 
	{
		301327,
		301730,
	},
	GoodsId = 191801,
	Num = 474,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 229605,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 390,
				},
				{
					Value = 1,
					Num = 34605,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 390,
				},
				{
					Value = 1,
					Num = 34605,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 78,
				},
				{
					Value = 1,
					Num = 34605,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 78,
				},
				{
					Value = 1,
					Num = 34605,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 15,
				},
				{
					Value = 1,
					Num = 42105,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 15,
				},
				{
					Value = 1,
					Num = 42105,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 275,
				},
				{
					Value = 320052,
					Num = 184,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 55,
				},
				{
					Value = 320053,
					Num = 36,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 11,
				},
				{
					Value = 320054,
					Num = 7,
				},
			},
		},
	},
	DemandID = 412844,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2852] =
{
	Id = 2852,
	Name = "加点装饰",
	Desc = "最近搬了新家，想要一些珊瑚作为装饰品。",
	Value = 321802,
	Active = true,
	Weight = 60480,
	PreGoal = 
	{
		301615,
		301635,
	},
	CloseGoal = 
	{
		301675,
	},
	GoodsId = 131802,
	Num = 67,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 145244,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 246,
				},
				{
					Value = 1,
					Num = 22244,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 246,
				},
				{
					Value = 1,
					Num = 22244,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 49,
				},
				{
					Value = 1,
					Num = 22744,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 49,
				},
				{
					Value = 1,
					Num = 22744,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 9,
				},
				{
					Value = 1,
					Num = 32744,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 9,
				},
				{
					Value = 1,
					Num = 32744,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 871,
				},
				{
					Value = 320051,
					Num = 581,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 174,
				},
				{
					Value = 320052,
					Num = 116,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 34,
				},
				{
					Value = 320053,
					Num = 24,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 6,
				},
				{
					Value = 320054,
					Num = 5,
				},
			},
		},
	},
	DemandID = 412852,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2853] =
{
	Id = 2853,
	Name = "加点装饰",
	Desc = "最近搬了新家，想要一些珊瑚作为装饰品。",
	Value = 321802,
	Active = true,
	Weight = 65880,
	PreGoal = 
	{
		301615,
		301685,
	},
	CloseGoal = 
	{
		301730,
	},
	GoodsId = 161802,
	Num = 99,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 214615,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 364,
				},
				{
					Value = 1,
					Num = 32615,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 364,
				},
				{
					Value = 1,
					Num = 32615,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 72,
				},
				{
					Value = 1,
					Num = 34615,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 72,
				},
				{
					Value = 1,
					Num = 34615,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 14,
				},
				{
					Value = 1,
					Num = 39615,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 14,
				},
				{
					Value = 1,
					Num = 39615,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 257,
				},
				{
					Value = 320052,
					Num = 172,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 51,
				},
				{
					Value = 320053,
					Num = 34,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 10,
				},
				{
					Value = 320054,
					Num = 7,
				},
			},
		},
	},
	DemandID = 412853,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2854] =
{
	Id = 2854,
	Name = "加点装饰",
	Desc = "最近搬了新家，想要一些珊瑚作为装饰品。",
	Value = 321802,
	Active = true,
	Weight = 70740,
	PreGoal = 
	{
		301615,
		301730,
	},
	GoodsId = 191802,
	Num = 132,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 286153,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 486,
				},
				{
					Value = 1,
					Num = 43153,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 486,
				},
				{
					Value = 1,
					Num = 43153,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 97,
				},
				{
					Value = 1,
					Num = 43653,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 97,
				},
				{
					Value = 1,
					Num = 43653,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 19,
				},
				{
					Value = 1,
					Num = 48653,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 19,
				},
				{
					Value = 1,
					Num = 48653,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 343,
				},
				{
					Value = 320052,
					Num = 229,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 68,
				},
				{
					Value = 320053,
					Num = 46,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 13,
				},
				{
					Value = 320054,
					Num = 9,
				},
			},
		},
	},
	DemandID = 412854,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2862] =
{
	Id = 2862,
	Name = "珍珠奶茶",
	Desc = "好想喝珍珠奶茶啊，自己来做一杯吧。",
	Value = 321803,
	Active = true,
	Weight = 62700,
	PreGoal = 
	{
		301625,
		301645,
	},
	CloseGoal = 
	{
		301685,
	},
	GoodsId = 131803,
	Num = 63,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 141437,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 240,
				},
				{
					Value = 1,
					Num = 21437,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 240,
				},
				{
					Value = 1,
					Num = 21437,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 48,
				},
				{
					Value = 1,
					Num = 21437,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 48,
				},
				{
					Value = 1,
					Num = 21437,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 9,
				},
				{
					Value = 1,
					Num = 28937,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 9,
				},
				{
					Value = 1,
					Num = 28937,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 848,
				},
				{
					Value = 320051,
					Num = 566,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 169,
				},
				{
					Value = 320052,
					Num = 113,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 33,
				},
				{
					Value = 320053,
					Num = 23,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 6,
				},
				{
					Value = 320054,
					Num = 5,
				},
			},
		},
	},
	DemandID = 412862,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2863] =
{
	Id = 2863,
	Name = "珍珠奶茶",
	Desc = "好想喝珍珠奶茶啊，自己来做一杯吧。",
	Value = 321803,
	Active = true,
	Weight = 68200,
	PreGoal = 
	{
		301625,
		301695,
	},
	GoodsId = 161803,
	Num = 94,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 211033,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 358,
				},
				{
					Value = 1,
					Num = 32033,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 358,
				},
				{
					Value = 1,
					Num = 32033,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 71,
				},
				{
					Value = 1,
					Num = 33533,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 71,
				},
				{
					Value = 1,
					Num = 33533,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 14,
				},
				{
					Value = 1,
					Num = 36033,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 14,
				},
				{
					Value = 1,
					Num = 36033,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 253,
				},
				{
					Value = 320052,
					Num = 169,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 50,
				},
				{
					Value = 320053,
					Num = 34,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 10,
				},
				{
					Value = 320054,
					Num = 6,
				},
			},
		},
	},
	DemandID = 412863,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2864] =
{
	Id = 2864,
	Name = "珍珠奶茶",
	Desc = "好想喝珍珠奶茶啊，自己来做一杯吧。",
	Value = 321803,
	Active = false,
	Weight = 72050,
	PreGoal = 
	{
		301625,
		301730,
	},
	GoodsId = 191803,
	Num = 123,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 276139,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 469,
				},
				{
					Value = 1,
					Num = 41639,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 469,
				},
				{
					Value = 1,
					Num = 41639,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 93,
				},
				{
					Value = 1,
					Num = 43639,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 93,
				},
				{
					Value = 1,
					Num = 43639,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 18,
				},
				{
					Value = 1,
					Num = 51139,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 18,
				},
				{
					Value = 1,
					Num = 51139,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 331,
				},
				{
					Value = 320052,
					Num = 221,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 66,
				},
				{
					Value = 320053,
					Num = 44,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 13,
				},
				{
					Value = 320054,
					Num = 9,
				},
			},
		},
	},
	DemandID = 412864,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2872] =
{
	Id = 2872,
	Name = "深海鬼屋",
	Desc = "鬼屋明天就要开业了，需要快点把触手送过去。",
	Value = 321804,
	Active = true,
	Weight = 62700,
	PreGoal = 
	{
		301906,
		301645,
	},
	CloseGoal = 
	{
		301685,
	},
	GoodsId = 131804,
	Num = 207,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 148319,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 252,
				},
				{
					Value = 1,
					Num = 22319,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 252,
				},
				{
					Value = 1,
					Num = 22319,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 50,
				},
				{
					Value = 1,
					Num = 23319,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 50,
				},
				{
					Value = 1,
					Num = 23319,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 10,
				},
				{
					Value = 1,
					Num = 23319,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 10,
				},
				{
					Value = 1,
					Num = 23319,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 889,
				},
				{
					Value = 320051,
					Num = 594,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 177,
				},
				{
					Value = 320052,
					Num = 119,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 35,
				},
				{
					Value = 320053,
					Num = 24,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 7,
				},
				{
					Value = 320054,
					Num = 4,
				},
			},
		},
	},
	DemandID = 412872,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2873] =
{
	Id = 2873,
	Name = "深海鬼屋",
	Desc = "鬼屋明天就要开业了，需要快点把触手送过去。",
	Value = 321804,
	Active = true,
	Weight = 68200,
	PreGoal = 
	{
		301906,
		301695,
	},
	GoodsId = 161804,
	Num = 306,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 219255,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 372,
				},
				{
					Value = 1,
					Num = 33255,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 372,
				},
				{
					Value = 1,
					Num = 33255,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 74,
				},
				{
					Value = 1,
					Num = 34255,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 74,
				},
				{
					Value = 1,
					Num = 34255,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 14,
				},
				{
					Value = 1,
					Num = 44255,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 14,
				},
				{
					Value = 1,
					Num = 44255,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 263,
				},
				{
					Value = 320052,
					Num = 175,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 52,
				},
				{
					Value = 320053,
					Num = 35,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 10,
				},
				{
					Value = 320054,
					Num = 7,
				},
			},
		},
	},
	DemandID = 412873,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2874] =
{
	Id = 2874,
	Name = "深海鬼屋",
	Desc = "鬼屋明天就要开业了，需要快点把触手送过去。",
	Value = 321804,
	Active = false,
	Weight = 72050,
	PreGoal = 
	{
		301906,
		301730,
	},
	GoodsId = 191804,
	Num = 402,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 288041,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 489,
				},
				{
					Value = 1,
					Num = 43541,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 489,
				},
				{
					Value = 1,
					Num = 43541,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 97,
				},
				{
					Value = 1,
					Num = 45541,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 97,
				},
				{
					Value = 1,
					Num = 45541,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 19,
				},
				{
					Value = 1,
					Num = 50541,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 19,
				},
				{
					Value = 1,
					Num = 50541,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 345,
				},
				{
					Value = 320052,
					Num = 231,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 69,
				},
				{
					Value = 320053,
					Num = 46,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 13,
				},
				{
					Value = 320054,
					Num = 10,
				},
			},
		},
	},
	DemandID = 412874,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2882] =
{
	Id = 2882,
	Name = "偶像应援",
	Desc = "偶像的演唱会快到了，应援的物品绝对不能少！",
	Value = 321805,
	Active = true,
	Weight = 66105,
	PreGoal = 
	{
		301640,
		301660,
	},
	CloseGoal = 
	{
		301700,
	},
	GoodsId = 131805,
	Num = 63,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 147223,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 250,
				},
				{
					Value = 1,
					Num = 22223,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 250,
				},
				{
					Value = 1,
					Num = 22223,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 50,
				},
				{
					Value = 1,
					Num = 22223,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 50,
				},
				{
					Value = 1,
					Num = 22223,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 10,
				},
				{
					Value = 1,
					Num = 22223,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 10,
				},
				{
					Value = 1,
					Num = 22223,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 883,
				},
				{
					Value = 320051,
					Num = 589,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 176,
				},
				{
					Value = 320052,
					Num = 118,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 35,
				},
				{
					Value = 320053,
					Num = 23,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 7,
				},
				{
					Value = 320054,
					Num = 4,
				},
			},
		},
	},
	DemandID = 412882,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2883] =
{
	Id = 2883,
	Name = "偶像应援",
	Desc = "偶像的演唱会快到了，应援的物品绝对不能少！",
	Value = 321805,
	Active = true,
	Weight = 71755,
	PreGoal = 
	{
		301640,
		301710,
	},
	GoodsId = 161805,
	Num = 94,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 219666,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 373,
				},
				{
					Value = 1,
					Num = 33166,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 373,
				},
				{
					Value = 1,
					Num = 33166,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 74,
				},
				{
					Value = 1,
					Num = 34666,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 74,
				},
				{
					Value = 1,
					Num = 34666,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 14,
				},
				{
					Value = 1,
					Num = 44666,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 14,
				},
				{
					Value = 1,
					Num = 44666,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 263,
				},
				{
					Value = 320052,
					Num = 176,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 52,
				},
				{
					Value = 320053,
					Num = 35,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 10,
				},
				{
					Value = 320054,
					Num = 7,
				},
			},
		},
	},
	DemandID = 412883,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2884] =
{
	Id = 2884,
	Name = "偶像应援",
	Desc = "偶像的演唱会快到了，应援的物品绝对不能少！",
	Value = 321805,
	Active = false,
	Weight = 74015,
	PreGoal = 
	{
		301640,
		301730,
	},
	GoodsId = 191805,
	Num = 123,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 287436,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 488,
				},
				{
					Value = 1,
					Num = 43436,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 488,
				},
				{
					Value = 1,
					Num = 43436,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 97,
				},
				{
					Value = 1,
					Num = 44936,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 97,
				},
				{
					Value = 1,
					Num = 44936,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 19,
				},
				{
					Value = 1,
					Num = 49936,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 19,
				},
				{
					Value = 1,
					Num = 49936,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 344,
				},
				{
					Value = 320052,
					Num = 230,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 68,
				},
				{
					Value = 320053,
					Num = 46,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 13,
				},
				{
					Value = 320054,
					Num = 9,
				},
			},
		},
	},
	DemandID = 412884,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2892] =
{
	Id = 2892,
	Name = "童话城堡",
	Desc = "我最近想要建造一座梦幻岛，请给我一些美丽的礁石吧。",
	Value = 321806,
	Active = true,
	Weight = 69600,
	PreGoal = 
	{
		301655,
		301675,
	},
	CloseGoal = 
	{
		301715,
	},
	GoodsId = 131806,
	Num = 60,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 145152,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 246,
				},
				{
					Value = 1,
					Num = 22152,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 246,
				},
				{
					Value = 1,
					Num = 22152,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 49,
				},
				{
					Value = 1,
					Num = 22652,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 49,
				},
				{
					Value = 1,
					Num = 22652,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 9,
				},
				{
					Value = 1,
					Num = 32652,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 9,
				},
				{
					Value = 1,
					Num = 32652,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 870,
				},
				{
					Value = 320051,
					Num = 581,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 174,
				},
				{
					Value = 320052,
					Num = 116,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 34,
				},
				{
					Value = 320053,
					Num = 24,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 6,
				},
				{
					Value = 320054,
					Num = 5,
				},
			},
		},
	},
	DemandID = 412892,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2893] =
{
	Id = 2893,
	Name = "童话城堡",
	Desc = "我最近想要建造一座梦幻岛，请给我一些美丽的礁石吧。",
	Value = 321806,
	Active = true,
	Weight = 75400,
	PreGoal = 
	{
		301655,
		301725,
	},
	GoodsId = 161806,
	Num = 87,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 210470,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 357,
				},
				{
					Value = 1,
					Num = 31970,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 357,
				},
				{
					Value = 1,
					Num = 31970,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 71,
				},
				{
					Value = 1,
					Num = 32970,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 71,
				},
				{
					Value = 1,
					Num = 32970,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 14,
				},
				{
					Value = 1,
					Num = 35470,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 14,
				},
				{
					Value = 1,
					Num = 35470,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 252,
				},
				{
					Value = 320052,
					Num = 168,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 50,
				},
				{
					Value = 320053,
					Num = 34,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 10,
				},
				{
					Value = 320054,
					Num = 6,
				},
			},
		},
	},
	DemandID = 412893,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2894] =
{
	Id = 2894,
	Name = "童话城堡",
	Desc = "我最近想要建造一座梦幻岛，请给我一些美丽的礁石吧。",
	Value = 321806,
	Active = false,
	Weight = 75980,
	PreGoal = 
	{
		301655,
		301730,
	},
	GoodsId = 191806,
	Num = 117,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 283046,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 481,
				},
				{
					Value = 1,
					Num = 42546,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 481,
				},
				{
					Value = 1,
					Num = 42546,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 96,
				},
				{
					Value = 1,
					Num = 43046,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 96,
				},
				{
					Value = 1,
					Num = 43046,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 19,
				},
				{
					Value = 1,
					Num = 45546,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 19,
				},
				{
					Value = 1,
					Num = 45546,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 339,
				},
				{
					Value = 320052,
					Num = 227,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 67,
				},
				{
					Value = 320053,
					Num = 46,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 13,
				},
				{
					Value = 320054,
					Num = 9,
				},
			},
		},
	},
	DemandID = 412894,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2902] =
{
	Id = 2902,
	Name = "制作裙子",
	Desc = "想做一些闪闪发光的小裙子，需要鱼鳞作为素材。",
	Value = 321807,
	Active = true,
	Weight = 71980,
	PreGoal = 
	{
		301665,
		301685,
	},
	CloseGoal = 
	{
		301725,
	},
	GoodsId = 131807,
	Num = 60,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 149814,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 254,
				},
				{
					Value = 1,
					Num = 22814,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 254,
				},
				{
					Value = 1,
					Num = 22814,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 50,
				},
				{
					Value = 1,
					Num = 24814,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 50,
				},
				{
					Value = 1,
					Num = 24814,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 10,
				},
				{
					Value = 1,
					Num = 24814,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 10,
				},
				{
					Value = 1,
					Num = 24814,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 898,
				},
				{
					Value = 320051,
					Num = 600,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 179,
				},
				{
					Value = 320052,
					Num = 120,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 35,
				},
				{
					Value = 320053,
					Num = 24,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 7,
				},
				{
					Value = 320054,
					Num = 4,
				},
			},
		},
	},
	DemandID = 412902,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2903] =
{
	Id = 2903,
	Name = "制作裙子",
	Desc = "想做一些闪闪发光的小裙子，需要鱼鳞作为素材。",
	Value = 321807,
	Active = true,
	Weight = 77290,
	PreGoal = 
	{
		301665,
		301730,
	},
	GoodsId = 161807,
	Num = 87,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 217230,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 369,
				},
				{
					Value = 1,
					Num = 32730,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 369,
				},
				{
					Value = 1,
					Num = 32730,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 73,
				},
				{
					Value = 1,
					Num = 34730,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 73,
				},
				{
					Value = 1,
					Num = 34730,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 14,
				},
				{
					Value = 1,
					Num = 42230,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 14,
				},
				{
					Value = 1,
					Num = 42230,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 260,
				},
				{
					Value = 320052,
					Num = 174,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 52,
				},
				{
					Value = 320053,
					Num = 34,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 10,
				},
				{
					Value = 320054,
					Num = 7,
				},
			},
		},
	},
	DemandID = 412903,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2904] =
{
	Id = 2904,
	Name = "制作裙子",
	Desc = "想做一些闪闪发光的小裙子，需要鱼鳞作为素材。",
	Value = 321807,
	Active = false,
	Weight = 77290,
	PreGoal = 
	{
		301665,
		301730,
	},
	GoodsId = 191807,
	Num = 117,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 292137,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 496,
				},
				{
					Value = 1,
					Num = 44137,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 496,
				},
				{
					Value = 1,
					Num = 44137,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 99,
				},
				{
					Value = 1,
					Num = 44637,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 99,
				},
				{
					Value = 1,
					Num = 44637,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 19,
				},
				{
					Value = 1,
					Num = 54637,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 19,
				},
				{
					Value = 1,
					Num = 54637,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 350,
				},
				{
					Value = 320052,
					Num = 234,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 70,
				},
				{
					Value = 320053,
					Num = 46,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 14,
				},
				{
					Value = 320054,
					Num = 9,
				},
			},
		},
	},
	DemandID = 412904,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2912] =
{
	Id = 2912,
	Name = "海底舞会",
	Desc = "海底舞会开始了，这次一定要抓拍到偶像们的精彩瞬间。",
	Value = 321808,
	Active = true,
	Weight = 71980,
	PreGoal = 
	{
		301922,
		301685,
	},
	CloseGoal = 
	{
		301725,
	},
	GoodsId = 131808,
	Num = 166,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 150769,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 256,
				},
				{
					Value = 1,
					Num = 22769,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 256,
				},
				{
					Value = 1,
					Num = 22769,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 51,
				},
				{
					Value = 1,
					Num = 23269,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 51,
				},
				{
					Value = 1,
					Num = 23269,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 10,
				},
				{
					Value = 1,
					Num = 25769,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 10,
				},
				{
					Value = 1,
					Num = 25769,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 904,
				},
				{
					Value = 320051,
					Num = 603,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 180,
				},
				{
					Value = 320052,
					Num = 121,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 36,
				},
				{
					Value = 320053,
					Num = 24,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 7,
				},
				{
					Value = 320054,
					Num = 5,
				},
			},
		},
	},
	DemandID = 412912,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2913] =
{
	Id = 2913,
	Name = "海底舞会",
	Desc = "海底舞会开始了，这次一定要抓拍到偶像们的精彩瞬间。",
	Value = 321808,
	Active = true,
	Weight = 77290,
	PreGoal = 
	{
		301922,
		301730,
	},
	GoodsId = 161808,
	Num = 243,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 220704,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 375,
				},
				{
					Value = 1,
					Num = 33204,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 375,
				},
				{
					Value = 1,
					Num = 33204,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 75,
				},
				{
					Value = 1,
					Num = 33204,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 75,
				},
				{
					Value = 1,
					Num = 33204,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 15,
				},
				{
					Value = 1,
					Num = 33204,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 15,
				},
				{
					Value = 1,
					Num = 33204,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 264,
				},
				{
					Value = 320052,
					Num = 177,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 52,
				},
				{
					Value = 320053,
					Num = 36,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 10,
				},
				{
					Value = 320054,
					Num = 7,
				},
			},
		},
	},
	DemandID = 412913,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2914] =
{
	Id = 2914,
	Name = "海底舞会",
	Desc = "海底舞会开始了，这次一定要抓拍到偶像们的精彩瞬间。",
	Value = 321808,
	Active = false,
	Weight = 77290,
	PreGoal = 
	{
		301922,
		301730,
	},
	GoodsId = 191808,
	Num = 324,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 294273,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 500,
				},
				{
					Value = 1,
					Num = 44273,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 500,
				},
				{
					Value = 1,
					Num = 44273,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 100,
				},
				{
					Value = 1,
					Num = 44273,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 100,
				},
				{
					Value = 1,
					Num = 44273,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 20,
				},
				{
					Value = 1,
					Num = 44273,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 20,
				},
				{
					Value = 1,
					Num = 44273,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 353,
				},
				{
					Value = 320052,
					Num = 235,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 70,
				},
				{
					Value = 320053,
					Num = 47,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 14,
				},
				{
					Value = 320054,
					Num = 9,
				},
			},
		},
	},
	DemandID = 412914,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2922] =
{
	Id = 2922,
	Name = "蹦迪现场",
	Desc = "给我一些耳机吧，到时候大家就能一起蹦迪了。",
	Value = 321809,
	Active = true,
	Weight = 74400,
	PreGoal = 
	{
		301675,
		301695,
	},
	GoodsId = 131809,
	Num = 57,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 147302,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 250,
				},
				{
					Value = 1,
					Num = 22302,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 250,
				},
				{
					Value = 1,
					Num = 22302,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 50,
				},
				{
					Value = 1,
					Num = 22302,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 50,
				},
				{
					Value = 1,
					Num = 22302,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 10,
				},
				{
					Value = 1,
					Num = 22302,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 10,
				},
				{
					Value = 1,
					Num = 22302,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 883,
				},
				{
					Value = 320051,
					Num = 590,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 176,
				},
				{
					Value = 320052,
					Num = 118,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 35,
				},
				{
					Value = 320053,
					Num = 23,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 7,
				},
				{
					Value = 320054,
					Num = 4,
				},
			},
		},
	},
	DemandID = 412922,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2923] =
{
	Id = 2923,
	Name = "蹦迪现场",
	Desc = "给我一些耳机吧，到时候大家就能一起蹦迪了。",
	Value = 321809,
	Active = false,
	Weight = 78600,
	PreGoal = 
	{
		301675,
		301730,
	},
	GoodsId = 161809,
	Num = 84,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 217077,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 369,
				},
				{
					Value = 1,
					Num = 32577,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 369,
				},
				{
					Value = 1,
					Num = 32577,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 73,
				},
				{
					Value = 1,
					Num = 34577,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 73,
				},
				{
					Value = 1,
					Num = 34577,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 14,
				},
				{
					Value = 1,
					Num = 42077,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 14,
				},
				{
					Value = 1,
					Num = 42077,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 260,
				},
				{
					Value = 320052,
					Num = 174,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 52,
				},
				{
					Value = 320053,
					Num = 34,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 10,
				},
				{
					Value = 320054,
					Num = 7,
				},
			},
		},
	},
	DemandID = 412923,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
DemandConfig[DemandID.Id2924] =
{
	Id = 2924,
	Name = "蹦迪现场",
	Desc = "给我一些耳机吧，到时候大家就能一起蹦迪了。",
	Value = 321809,
	Active = false,
	Weight = 78600,
	PreGoal = 
	{
		301675,
		301730,
	},
	GoodsId = 191809,
	Num = 108,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 279100,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 474,
				},
				{
					Value = 1,
					Num = 42100,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 474,
				},
				{
					Value = 1,
					Num = 42100,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 94,
				},
				{
					Value = 1,
					Num = 44100,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 94,
				},
				{
					Value = 1,
					Num = 44100,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 18,
				},
				{
					Value = 1,
					Num = 54100,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 18,
				},
				{
					Value = 1,
					Num = 54100,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 334,
				},
				{
					Value = 320052,
					Num = 224,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 66,
				},
				{
					Value = 320053,
					Num = 45,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 13,
				},
				{
					Value = 320054,
					Num = 9,
				},
			},
		},
	},
	DemandID = 412924,
	DemandGroupList = {
		420010,
		420011,
		420012,
		420013,
		420014,
		420015,
	},
}
