WorkShopConfig ={};
WorkShopID = 
{
	Id001 = 160001,
	Id002 = 160002,
	Id003 = 160003,
	Id004 = 160004,
}
WorkShopConfig[WorkShopID.Id001] =
{
	Id = 1,
	Name = "道具店",
	QuickExchangeCode = "RPG",
	Picture = "RPGShop",
	Icon = "Icon_RPGShop",
	IconBG = "Icon_RPGShopBG",
	Desk = "Icon_RPGShopDesk",
	BG = "BG_RPGShop",
	BossIcon = "RPGShop_NPC",
	QuickExchangeConfirmText = "loc_workshop1_quickexchange_confirm_hint",
	DialogList = {
		{
			50001,50002,50003,50004,50005,50006,50007,50008,50011,50012,
		},
		{
			50014,50016,50018,50020,50024,
		},
		{
			50014,50016,50018,50020,50024,
		},
		{
			50014,50016,50018,50020,50024,
		},
		{
			50014,50016,50018,50020,50024,
		},
		{
			50014,50016,50018,50020,50024,
		},
		{
			50014,50016,50018,50020,50024,
		},
	},
	RewardList = {
		{
			NeedLevel = 1,
			Value = 320402,
			NeedProduction = 7200,
			Num = 1,
		},
		{
			NeedLevel = 2,
			Value = 1,
			NeedProduction = 360,
			Num = 3,
		},
		{
			NeedLevel = 3,
			Value = 320301,
			NeedProduction = 72000,
			Num = 1,
		},
	},
	LevelList = {
		{
			MaxWorkTime = 3600,
			NumCap = 1,
			TopRank = 4,
			UpgradeItemList = {
				{
					Value = 1,
					Num = 200,
				},
			},
		},
		{
			MaxWorkTime = 7200,
			NumCap = 2,
			TopRank = 7,
			UpgradeItemList = {
				{
					Value = 321003,
					Num = 10,
				},
				{
					Value = 1,
					Num = 2300,
				},
			},
		},
		{
			MaxWorkTime = 14400,
			NumCap = 3,
			TopRank = 10,
			UpgradeItemList = {
				{
					Value = 321004,
					Num = 25,
				},
				{
					Value = 1,
					Num = 5900,
				},
			},
		},
		{
			MaxWorkTime = 28800,
			NumCap = 4,
			TopRank = 13,
			UpgradeItemList = {
				{
					Value = 321052,
					Num = 5,
				},
				{
					Value = 1,
					Num = 14400,
				},
			},
		},
		{
			MaxWorkTime = 36000,
			NumCap = 5,
			TopRank = 16,
			UpgradeItemList = {
				{
					Value = 321053,
					Num = 5,
				},
				{
					Value = 1,
					Num = 33900,
				},
			},
		},
		{
			MaxWorkTime = 43200,
			NumCap = 6,
			TopRank = 19,
			UpgradeItemList = {
				{
					Value = 321054,
					Num = 45,
				},
				{
					Value = 1,
					Num = 78000,
				},
			},
		},
		{
			MaxWorkTime = 64800,
			NumCap = 7,
			TopRank = 22,
		},
	},
	RankList = {
		{
			RankText = "招工中…",
			NeedAttribute = {
				{
					Value = 200005,
					Num = 0,
				},
				{
					Value = 200006,
					Num = 0,
				},
			},
			Production = {
				0,
				0,
				0,
			},
		},
		{
			RankText = "F-",
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1,
				},
				{
					Value = 200006,
					Num = 1,
				},
			},
			Production = {
				10,
				10,
				10,
			},
		},
		{
			RankText = "F",
			NeedAttribute = {
				{
					Value = 200005,
					Num = 12,
				},
				{
					Value = 200006,
					Num = 7,
				},
			},
			Production = {
				11,
				11,
				11,
			},
		},
		{
			RankText = "F+",
			NeedAttribute = {
				{
					Value = 200005,
					Num = 21,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
			Production = {
				12,
				12,
				12,
			},
		},
		{
			RankText = "E-",
			NeedAttribute = {
				{
					Value = 200005,
					Num = 23,
				},
				{
					Value = 200006,
					Num = 13,
				},
			},
			Production = {
				13,
				13,
				13,
			},
		},
		{
			RankText = "E",
			NeedAttribute = {
				{
					Value = 200005,
					Num = 39,
				},
				{
					Value = 200006,
					Num = 23,
				},
			},
			Production = {
				14,
				14,
				14,
			},
		},
		{
			RankText = "E+",
			NeedAttribute = {
				{
					Value = 200005,
					Num = 62,
				},
				{
					Value = 200006,
					Num = 37,
				},
			},
			Production = {
				15,
				15,
				15,
			},
		},
		{
			RankText = "D-",
			NeedAttribute = {
				{
					Value = 200005,
					Num = 69,
				},
				{
					Value = 200006,
					Num = 41,
				},
			},
			Production = {
				16,
				16,
				16,
			},
		},
		{
			RankText = "D",
			NeedAttribute = {
				{
					Value = 200005,
					Num = 108,
				},
				{
					Value = 200006,
					Num = 64,
				},
			},
			Production = {
				17,
				17,
				17,
			},
		},
		{
			RankText = "D+",
			NeedAttribute = {
				{
					Value = 200005,
					Num = 153,
				},
				{
					Value = 200006,
					Num = 92,
				},
			},
			Production = {
				18,
				18,
				18,
			},
		},
		{
			RankText = "C-",
			NeedAttribute = {
				{
					Value = 200005,
					Num = 164,
				},
				{
					Value = 200006,
					Num = 98,
				},
			},
			Production = {
				19,
				19,
				19,
			},
		},
		{
			RankText = "C",
			NeedAttribute = {
				{
					Value = 200005,
					Num = 230,
				},
				{
					Value = 200006,
					Num = 138,
				},
			},
			Production = {
				20,
				20,
				20,
			},
		},
		{
			RankText = "C+",
			NeedAttribute = {
				{
					Value = 200005,
					Num = 306,
				},
				{
					Value = 200006,
					Num = 183,
				},
			},
			Production = {
				20,
				21,
				21,
			},
		},
		{
			RankText = "B-",
			NeedAttribute = {
				{
					Value = 200005,
					Num = 318,
				},
				{
					Value = 200006,
					Num = 191,
				},
			},
			Production = {
				21,
				22,
				21,
			},
		},
		{
			RankText = "B",
			NeedAttribute = {
				{
					Value = 200005,
					Num = 420,
				},
				{
					Value = 200006,
					Num = 252,
				},
			},
			Production = {
				21,
				23,
				22,
			},
		},
		{
			RankText = "B+",
			NeedAttribute = {
				{
					Value = 200005,
					Num = 533,
				},
				{
					Value = 200006,
					Num = 320,
				},
			},
			Production = {
				22,
				24,
				22,
			},
		},
		{
			RankText = "A-",
			NeedAttribute = {
				{
					Value = 200005,
					Num = 549,
				},
				{
					Value = 200006,
					Num = 329,
				},
			},
			Production = {
				22,
				25,
				23,
			},
		},
		{
			RankText = "A",
			NeedAttribute = {
				{
					Value = 200005,
					Num = 693,
				},
				{
					Value = 200006,
					Num = 415,
				},
			},
			Production = {
				23,
				26,
				23,
			},
		},
		{
			RankText = "A+",
			NeedAttribute = {
				{
					Value = 200005,
					Num = 852,
				},
				{
					Value = 200006,
					Num = 511,
				},
			},
			Production = {
				23,
				27,
				24,
			},
		},
		{
			RankText = "S-",
			NeedAttribute = {
				{
					Value = 200005,
					Num = 869,
				},
				{
					Value = 200006,
					Num = 521,
				},
			},
			Production = {
				24,
				28,
				24,
			},
		},
		{
			RankText = "S",
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1064,
				},
				{
					Value = 200006,
					Num = 638,
				},
			},
			Production = {
				24,
				29,
				25,
			},
		},
		{
			RankText = "S+",
			NeedAttribute = {
				{
					Value = 200005,
					Num = 1275,
				},
				{
					Value = 200006,
					Num = 765,
				},
			},
			Production = {
				25,
				30,
				25,
			},
		},
	},
}
WorkShopConfig[WorkShopID.Id002] =
{
	Id = 2,
	Name = "超市",
	QuickExchangeCode = "CS",
	Picture = "ConvenienceStore",
	Icon = "Icon_ConvenienceStore",
	IconBG = "Icon_ConvenienceStoreBG",
	Desk = "Icon_ConvenienceStoreDesk",
	BG = "BG_ConvenienceStore",
	BossIcon = "ConvenienceStore_NPC",
	QuickExchangeConfirmText = "loc_workshop2_quickexchange_confirm_hint",
	DialogList = {
		{
			51001,
		},
		{
			51003,51005,51013,51015,
		},
		{
			51003,51005,51013,51015,
		},
		{
			51003,51005,51013,51015,
		},
		{
			51003,51005,51013,51015,
		},
		{
			51003,51005,51013,51015,
		},
		{
			51003,51005,51013,51015,
		},
	},
	RewardList = {
		{
			NeedLevel = 1,
			Value = 320406,
			NeedProduction = 18000,
			Num = 1,
		},
		{
			NeedLevel = 2,
			Value = 1,
			NeedProduction = 360,
			Num = 3,
		},
		{
			NeedLevel = 3,
			Value = 320305,
			NeedProduction = 72000,
			Num = 1,
		},
	},
	LevelList = {
		{
			MaxWorkTime = 7200,
			NumCap = 1,
			TopRank = 4,
			UpgradeItemList = {
				{
					Value = 1,
					Num = 2200,
				},
			},
		},
		{
			MaxWorkTime = 14400,
			NumCap = 2,
			TopRank = 7,
			UpgradeItemList = {
				{
					Value = 321006,
					Num = 10,
				},
				{
					Value = 1,
					Num = 5900,
				},
			},
		},
		{
			MaxWorkTime = 21600,
			NumCap = 3,
			TopRank = 10,
			UpgradeItemList = {
				{
					Value = 321203,
					Num = 25,
				},
				{
					Value = 1,
					Num = 14800,
				},
			},
		},
		{
			MaxWorkTime = 28800,
			NumCap = 4,
			TopRank = 13,
			UpgradeItemList = {
				{
					Value = 321252,
					Num = 5,
				},
				{
					Value = 1,
					Num = 36100,
				},
			},
		},
		{
			MaxWorkTime = 36000,
			NumCap = 5,
			TopRank = 16,
			UpgradeItemList = {
				{
					Value = 321253,
					Num = 15,
				},
				{
					Value = 1,
					Num = 82300,
				},
			},
		},
		{
			MaxWorkTime = 43200,
			NumCap = 6,
			TopRank = 19,
			UpgradeItemList = {
				{
					Value = 321254,
					Num = 50,
				},
				{
					Value = 1,
					Num = 182000,
				},
			},
		},
		{
			MaxWorkTime = 64800,
			NumCap = 7,
			TopRank = 22,
		},
	},
	RankList = {
		{
			RankText = "招工中…",
			NeedAttribute = {
				{
					Value = 200006,
					Num = 0,
				},
				{
					Value = 200007,
					Num = 0,
				},
			},
			Production = {
				0,
				0,
				0,
			},
		},
		{
			RankText = "F-",
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1,
				},
				{
					Value = 200007,
					Num = 1,
				},
			},
			Production = {
				10,
				20,
				10,
			},
		},
		{
			RankText = "F",
			NeedAttribute = {
				{
					Value = 200006,
					Num = 26,
				},
				{
					Value = 200007,
					Num = 15,
				},
			},
			Production = {
				11,
				21,
				11,
			},
		},
		{
			RankText = "F+",
			NeedAttribute = {
				{
					Value = 200006,
					Num = 42,
				},
				{
					Value = 200007,
					Num = 25,
				},
			},
			Production = {
				12,
				22,
				12,
			},
		},
		{
			RankText = "E-",
			NeedAttribute = {
				{
					Value = 200006,
					Num = 46,
				},
				{
					Value = 200007,
					Num = 27,
				},
			},
			Production = {
				13,
				23,
				13,
			},
		},
		{
			RankText = "E",
			NeedAttribute = {
				{
					Value = 200006,
					Num = 75,
				},
				{
					Value = 200007,
					Num = 45,
				},
			},
			Production = {
				14,
				24,
				14,
			},
		},
		{
			RankText = "E+",
			NeedAttribute = {
				{
					Value = 200006,
					Num = 114,
				},
				{
					Value = 200007,
					Num = 68,
				},
			},
			Production = {
				15,
				25,
				15,
			},
		},
		{
			RankText = "D-",
			NeedAttribute = {
				{
					Value = 200006,
					Num = 128,
				},
				{
					Value = 200007,
					Num = 76,
				},
			},
			Production = {
				16,
				26,
				16,
			},
		},
		{
			RankText = "D",
			NeedAttribute = {
				{
					Value = 200006,
					Num = 195,
				},
				{
					Value = 200007,
					Num = 117,
				},
			},
			Production = {
				17,
				27,
				17,
			},
		},
		{
			RankText = "D+",
			NeedAttribute = {
				{
					Value = 200006,
					Num = 270,
				},
				{
					Value = 200007,
					Num = 162,
				},
			},
			Production = {
				18,
				28,
				18,
			},
		},
		{
			RankText = "C-",
			NeedAttribute = {
				{
					Value = 200006,
					Num = 288,
				},
				{
					Value = 200007,
					Num = 172,
				},
			},
			Production = {
				19,
				29,
				19,
			},
		},
		{
			RankText = "C",
			NeedAttribute = {
				{
					Value = 200006,
					Num = 400,
				},
				{
					Value = 200007,
					Num = 240,
				},
			},
			Production = {
				20,
				30,
				20,
			},
		},
		{
			RankText = "C+",
			NeedAttribute = {
				{
					Value = 200006,
					Num = 522,
				},
				{
					Value = 200007,
					Num = 313,
				},
			},
			Production = {
				20,
				31,
				21,
			},
		},
		{
			RankText = "B-",
			NeedAttribute = {
				{
					Value = 200006,
					Num = 543,
				},
				{
					Value = 200007,
					Num = 326,
				},
			},
			Production = {
				21,
				32,
				21,
			},
		},
		{
			RankText = "B",
			NeedAttribute = {
				{
					Value = 200006,
					Num = 712,
				},
				{
					Value = 200007,
					Num = 427,
				},
			},
			Production = {
				21,
				33,
				22,
			},
		},
		{
			RankText = "B+",
			NeedAttribute = {
				{
					Value = 200006,
					Num = 892,
				},
				{
					Value = 200007,
					Num = 535,
				},
			},
			Production = {
				22,
				34,
				22,
			},
		},
		{
			RankText = "A-",
			NeedAttribute = {
				{
					Value = 200006,
					Num = 918,
				},
				{
					Value = 200007,
					Num = 550,
				},
			},
			Production = {
				22,
				35,
				23,
			},
		},
		{
			RankText = "A",
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1155,
				},
				{
					Value = 200007,
					Num = 693,
				},
			},
			Production = {
				23,
				36,
				23,
			},
		},
		{
			RankText = "A+",
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1404,
				},
				{
					Value = 200007,
					Num = 842,
				},
			},
			Production = {
				23,
				37,
				24,
			},
		},
		{
			RankText = "S-",
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1433,
				},
				{
					Value = 200007,
					Num = 859,
				},
			},
			Production = {
				24,
				38,
				24,
			},
		},
		{
			RankText = "S",
			NeedAttribute = {
				{
					Value = 200006,
					Num = 1750,
				},
				{
					Value = 200007,
					Num = 1050,
				},
			},
			Production = {
				24,
				39,
				25,
			},
		},
		{
			RankText = "S+",
			NeedAttribute = {
				{
					Value = 200006,
					Num = 2079,
				},
				{
					Value = 200007,
					Num = 1247,
				},
			},
			Production = {
				25,
				40,
				25,
			},
		},
	},
}
WorkShopConfig[WorkShopID.Id003] =
{
	Id = 3,
	Name = "警察局",
	QuickExchangeCode = "PO",
	Picture = "PoliceOffice",
	Icon = "Icon_PoliceOffice",
	IconBG = "Icon_PoliceOfficeBG",
	Desk = "Icon_PoliceOfficeDesk",
	BG = "BG_PoliceOffice",
	BossIcon = "PoliceOffice_NPC",
	QuickExchangeConfirmText = "loc_workshop3_quickexchange_confirm_hint",
	DialogList = {
		{
			52001,
		},
		{
			52002,52004,52013,52016,
		},
		{
			52002,52004,52013,52016,
		},
		{
			52002,52004,52013,52016,
		},
		{
			52002,52004,52013,52016,
		},
		{
			52002,52004,52013,52016,
		},
		{
			52002,52004,52013,52016,
		},
	},
	RewardList = {
		{
			NeedLevel = 1,
			Value = 320410,
			NeedProduction = 36000,
			Num = 1,
		},
		{
			NeedLevel = 2,
			Value = 1,
			NeedProduction = 1800,
			Num = 15,
		},
		{
			NeedLevel = 3,
			Value = 320309,
			NeedProduction = 72000,
			Num = 1,
		},
	},
	LevelList = {
		{
			MaxWorkTime = 14400,
			NumCap = 1,
			TopRank = 4,
			UpgradeItemList = {
				{
					Value = 1,
					Num = 5100,
				},
			},
		},
		{
			MaxWorkTime = 18000,
			NumCap = 2,
			TopRank = 7,
			UpgradeItemList = {
				{
					Value = 321206,
					Num = 10,
				},
				{
					Value = 1,
					Num = 12800,
				},
			},
		},
		{
			MaxWorkTime = 21600,
			NumCap = 3,
			TopRank = 10,
			UpgradeItemList = {
				{
					Value = 321209,
					Num = 25,
				},
				{
					Value = 1,
					Num = 30100,
				},
			},
		},
		{
			MaxWorkTime = 28800,
			NumCap = 4,
			TopRank = 13,
			UpgradeItemList = {
				{
					Value = 321401,
					Num = 50,
				},
				{
					Value = 1,
					Num = 65400,
				},
			},
		},
		{
			MaxWorkTime = 36000,
			NumCap = 5,
			TopRank = 16,
			UpgradeItemList = {
				{
					Value = 321403,
					Num = 150,
				},
				{
					Value = 1,
					Num = 141000,
				},
			},
		},
		{
			MaxWorkTime = 43200,
			NumCap = 6,
			TopRank = 19,
			UpgradeItemList = {
				{
					Value = 321452,
					Num = 65,
				},
				{
					Value = 1,
					Num = 297000,
				},
			},
		},
		{
			MaxWorkTime = 64800,
			NumCap = 7,
			TopRank = 22,
		},
	},
	RankList = {
		{
			RankText = "招工中…",
			NeedAttribute = {
				{
					Value = 200007,
					Num = 0,
				},
				{
					Value = 200008,
					Num = 0,
				},
			},
			Production = {
				0,
				0,
				0,
			},
		},
		{
			RankText = "F-",
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1,
				},
				{
					Value = 200008,
					Num = 1,
				},
			},
			Production = {
				10,
				30,
				10,
			},
		},
		{
			RankText = "F",
			NeedAttribute = {
				{
					Value = 200007,
					Num = 48,
				},
				{
					Value = 200008,
					Num = 29,
				},
			},
			Production = {
				11,
				31,
				11,
			},
		},
		{
			RankText = "F+",
			NeedAttribute = {
				{
					Value = 200007,
					Num = 75,
				},
				{
					Value = 200008,
					Num = 45,
				},
			},
			Production = {
				12,
				32,
				12,
			},
		},
		{
			RankText = "E-",
			NeedAttribute = {
				{
					Value = 200007,
					Num = 82,
				},
				{
					Value = 200008,
					Num = 49,
				},
			},
			Production = {
				13,
				33,
				13,
			},
		},
		{
			RankText = "E",
			NeedAttribute = {
				{
					Value = 200007,
					Num = 127,
				},
				{
					Value = 200008,
					Num = 76,
				},
			},
			Production = {
				14,
				34,
				14,
			},
		},
		{
			RankText = "E+",
			NeedAttribute = {
				{
					Value = 200007,
					Num = 190,
				},
				{
					Value = 200008,
					Num = 114,
				},
			},
			Production = {
				15,
				35,
				15,
			},
		},
		{
			RankText = "D-",
			NeedAttribute = {
				{
					Value = 200007,
					Num = 213,
				},
				{
					Value = 200008,
					Num = 128,
				},
			},
			Production = {
				16,
				36,
				16,
			},
		},
		{
			RankText = "D",
			NeedAttribute = {
				{
					Value = 200007,
					Num = 315,
				},
				{
					Value = 200008,
					Num = 189,
				},
			},
			Production = {
				17,
				37,
				17,
			},
		},
		{
			RankText = "D+",
			NeedAttribute = {
				{
					Value = 200007,
					Num = 431,
				},
				{
					Value = 200008,
					Num = 258,
				},
			},
			Production = {
				18,
				38,
				18,
			},
		},
		{
			RankText = "C-",
			NeedAttribute = {
				{
					Value = 200007,
					Num = 460,
				},
				{
					Value = 200008,
					Num = 276,
				},
			},
			Production = {
				19,
				39,
				19,
			},
		},
		{
			RankText = "C",
			NeedAttribute = {
				{
					Value = 200007,
					Num = 625,
				},
				{
					Value = 200008,
					Num = 375,
				},
			},
			Production = {
				20,
				40,
				20,
			},
		},
		{
			RankText = "C+",
			NeedAttribute = {
				{
					Value = 200007,
					Num = 810,
				},
				{
					Value = 200008,
					Num = 486,
				},
			},
			Production = {
				20,
				41,
				21,
			},
		},
		{
			RankText = "B-",
			NeedAttribute = {
				{
					Value = 200007,
					Num = 843,
				},
				{
					Value = 200008,
					Num = 506,
				},
			},
			Production = {
				21,
				42,
				21,
			},
		},
		{
			RankText = "B",
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1087,
				},
				{
					Value = 200008,
					Num = 652,
				},
			},
			Production = {
				21,
				43,
				22,
			},
		},
		{
			RankText = "B+",
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1356,
				},
				{
					Value = 200008,
					Num = 813,
				},
			},
			Production = {
				22,
				44,
				22,
			},
		},
		{
			RankText = "A-",
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1395,
				},
				{
					Value = 200008,
					Num = 837,
				},
			},
			Production = {
				22,
				45,
				23,
			},
		},
		{
			RankText = "A",
			NeedAttribute = {
				{
					Value = 200007,
					Num = 1732,
				},
				{
					Value = 200008,
					Num = 1039,
				},
			},
			Production = {
				23,
				46,
				23,
			},
		},
		{
			RankText = "A+",
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2100,
				},
				{
					Value = 200008,
					Num = 1260,
				},
			},
			Production = {
				23,
				47,
				24,
			},
		},
		{
			RankText = "S-",
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2143,
				},
				{
					Value = 200008,
					Num = 1286,
				},
			},
			Production = {
				24,
				48,
				24,
			},
		},
		{
			RankText = "S",
			NeedAttribute = {
				{
					Value = 200007,
					Num = 2590,
				},
				{
					Value = 200008,
					Num = 1554,
				},
			},
			Production = {
				24,
				49,
				25,
			},
		},
		{
			RankText = "S+",
			NeedAttribute = {
				{
					Value = 200007,
					Num = 3071,
				},
				{
					Value = 200008,
					Num = 1842,
				},
			},
			Production = {
				25,
				50,
				25,
			},
		},
	},
}
WorkShopConfig[WorkShopID.Id004] =
{
	Id = 4,
	Name = "事务所",
	QuickExchangeCode = "DA",
	Picture = "DetectiveAgency",
	Icon = "Icon_DetectiveAgency",
	IconBG = "Icon_DetectiveAgencyBG",
	Desk = "Icon_DetectiveAgencyDesk",
	BG = "BG_DetectiveAgency",
	BossIcon = "DetectiveAgency_NPC",
	QuickExchangeConfirmText = "loc_workshop4_quickexchange_confirm_hint",
	DialogList = {
		{
			53001,
		},
		{
			53002,53004,53011,53015,
		},
		{
			53002,53004,53011,53015,
		},
		{
			53002,53004,53011,53015,
		},
		{
			53002,53004,53011,53015,
		},
		{
			53002,53004,53011,53015,
		},
		{
			53002,53004,53011,53015,
		},
	},
	RewardList = {
		{
			NeedLevel = 1,
			Value = 1,
			NeedProduction = 3600,
			Num = 30,
		},
		{
			NeedLevel = 2,
			Value = 320317,
			NeedProduction = 72000,
			Num = 1,
		},
		{
			NeedLevel = 3,
			Value = 320313,
			NeedProduction = 72000,
			Num = 1,
		},
	},
	LevelList = {
		{
			MaxWorkTime = 14400,
			NumCap = 1,
			TopRank = 4,
			UpgradeItemList = {
				{
					Value = 1,
					Num = 9600,
				},
			},
		},
		{
			MaxWorkTime = 18000,
			NumCap = 2,
			TopRank = 7,
			UpgradeItemList = {
				{
					Value = 321402,
					Num = 10,
				},
				{
					Value = 1,
					Num = 20800,
				},
			},
		},
		{
			MaxWorkTime = 21600,
			NumCap = 3,
			TopRank = 10,
			UpgradeItemList = {
				{
					Value = 321404,
					Num = 25,
				},
				{
					Value = 1,
					Num = 44800,
				},
			},
		},
		{
			MaxWorkTime = 28800,
			NumCap = 4,
			TopRank = 13,
			UpgradeItemList = {
				{
					Value = 321406,
					Num = 50,
				},
				{
					Value = 1,
					Num = 93900,
				},
			},
		},
		{
			MaxWorkTime = 36000,
			NumCap = 5,
			TopRank = 16,
			UpgradeItemList = {
				{
					Value = 321454,
					Num = 15,
				},
				{
					Value = 1,
					Num = 196000,
				},
			},
		},
		{
			MaxWorkTime = 43200,
			NumCap = 6,
			TopRank = 19,
			UpgradeItemList = {
				{
					Value = 321651,
					Num = 70,
				},
				{
					Value = 1,
					Num = 407000,
				},
			},
		},
		{
			MaxWorkTime = 64800,
			NumCap = 7,
			TopRank = 22,
		},
	},
	RankList = {
		{
			RankText = "招工中…",
			NeedAttribute = {
				{
					Value = 200008,
					Num = 0,
				},
				{
					Value = 200005,
					Num = 0,
				},
			},
			Production = {
				0,
				0,
				0,
			},
		},
		{
			RankText = "F-",
			NeedAttribute = {
				{
					Value = 200008,
					Num = 1,
				},
				{
					Value = 200005,
					Num = 1,
				},
			},
			Production = {
				40,
				10,
				10,
			},
		},
		{
			RankText = "F",
			NeedAttribute = {
				{
					Value = 200008,
					Num = 82,
				},
				{
					Value = 200005,
					Num = 49,
				},
			},
			Production = {
				43,
				11,
				11,
			},
		},
		{
			RankText = "F+",
			NeedAttribute = {
				{
					Value = 200008,
					Num = 120,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			Production = {
				46,
				12,
				12,
			},
		},
		{
			RankText = "E-",
			NeedAttribute = {
				{
					Value = 200008,
					Num = 132,
				},
				{
					Value = 200005,
					Num = 79,
				},
			},
			Production = {
				49,
				13,
				13,
			},
		},
		{
			RankText = "E",
			NeedAttribute = {
				{
					Value = 200008,
					Num = 195,
				},
				{
					Value = 200005,
					Num = 117,
				},
			},
			Production = {
				52,
				14,
				14,
			},
		},
		{
			RankText = "E+",
			NeedAttribute = {
				{
					Value = 200008,
					Num = 280,
				},
				{
					Value = 200005,
					Num = 168,
				},
			},
			Production = {
				55,
				15,
				15,
			},
		},
		{
			RankText = "D-",
			NeedAttribute = {
				{
					Value = 200008,
					Num = 315,
				},
				{
					Value = 200005,
					Num = 189,
				},
			},
			Production = {
				58,
				16,
				16,
			},
		},
		{
			RankText = "D",
			NeedAttribute = {
				{
					Value = 200008,
					Num = 450,
				},
				{
					Value = 200005,
					Num = 270,
				},
			},
			Production = {
				61,
				17,
				17,
			},
		},
		{
			RankText = "D+",
			NeedAttribute = {
				{
					Value = 200008,
					Num = 600,
				},
				{
					Value = 200005,
					Num = 360,
				},
			},
			Production = {
				64,
				18,
				18,
			},
		},
		{
			RankText = "C-",
			NeedAttribute = {
				{
					Value = 200008,
					Num = 640,
				},
				{
					Value = 200005,
					Num = 384,
				},
			},
			Production = {
				67,
				19,
				19,
			},
		},
		{
			RankText = "C",
			NeedAttribute = {
				{
					Value = 200008,
					Num = 850,
				},
				{
					Value = 200005,
					Num = 510,
				},
			},
			Production = {
				70,
				20,
				20,
			},
		},
		{
			RankText = "C+",
			NeedAttribute = {
				{
					Value = 200008,
					Num = 1080,
				},
				{
					Value = 200005,
					Num = 648,
				},
			},
			Production = {
				73,
				20,
				21,
			},
		},
		{
			RankText = "B-",
			NeedAttribute = {
				{
					Value = 200008,
					Num = 1125,
				},
				{
					Value = 200005,
					Num = 675,
				},
			},
			Production = {
				76,
				21,
				21,
			},
		},
		{
			RankText = "B",
			NeedAttribute = {
				{
					Value = 200008,
					Num = 1425,
				},
				{
					Value = 200005,
					Num = 855,
				},
			},
			Production = {
				79,
				21,
				22,
			},
		},
		{
			RankText = "B+",
			NeedAttribute = {
				{
					Value = 200008,
					Num = 1750,
				},
				{
					Value = 200005,
					Num = 1050,
				},
			},
			Production = {
				82,
				22,
				22,
			},
		},
		{
			RankText = "A-",
			NeedAttribute = {
				{
					Value = 200008,
					Num = 1800,
				},
				{
					Value = 200005,
					Num = 1080,
				},
			},
			Production = {
				85,
				22,
				23,
			},
		},
		{
			RankText = "A",
			NeedAttribute = {
				{
					Value = 200008,
					Num = 2205,
				},
				{
					Value = 200005,
					Num = 1323,
				},
			},
			Production = {
				88,
				23,
				23,
			},
		},
		{
			RankText = "A+",
			NeedAttribute = {
				{
					Value = 200008,
					Num = 2640,
				},
				{
					Value = 200005,
					Num = 1584,
				},
			},
			Production = {
				91,
				23,
				24,
			},
		},
		{
			RankText = "S-",
			NeedAttribute = {
				{
					Value = 200008,
					Num = 2695,
				},
				{
					Value = 200005,
					Num = 1617,
				},
			},
			Production = {
				94,
				24,
				24,
			},
		},
		{
			RankText = "S",
			NeedAttribute = {
				{
					Value = 200008,
					Num = 3220,
				},
				{
					Value = 200005,
					Num = 1932,
				},
			},
			Production = {
				97,
				24,
				25,
			},
		},
		{
			RankText = "S+",
			NeedAttribute = {
				{
					Value = 200008,
					Num = 3780,
				},
				{
					Value = 200005,
					Num = 2268,
				},
			},
			Production = {
				100,
				25,
				25,
			},
		},
	},
}

