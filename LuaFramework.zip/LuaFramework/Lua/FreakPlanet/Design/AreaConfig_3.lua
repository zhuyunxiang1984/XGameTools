
AreaConfig[AreaID.Id101] =
{
	Id = 101,
	Name = "着陆点",
	Planet = 120003,
	Level = 50,
	AreaElement = 210003,
	NumCap = 5,
	Map = "MUS_map_01",
	LevelIcon = "Icon_MUSBG01",
	LevelBG = "MUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "MUS_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140401,
			Enemy = {
				{
					Value = 242056,
					Level = 100,
					Weight = 1000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 6700,
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242056,
					Level = 100,
					Weight = 1000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 200,
					FightPower = 6700,
				},
			},
		},
	},
	Challenge = {
		140401,
	},
}
AreaConfig[AreaID.Id102] =
{
	Id = 102,
	Name = "入口大厅",
	Planet = 120003,
	Level = 53,
	AreaElement = 210001,
	NumCap = 5,
	Map = "MUS_map_02",
	LevelIcon = "Icon_MUSBG01",
	LevelBG = "MUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "MUS_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140404,
			Enemy = {
				{
					Value = 242056,
					Level = 100,
					Weight = 294,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 6700,
				},
				{
					Value = 242058,
					Level = 104,
					Weight = 352,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 8700,
				},
				{
					Value = 242059,
					Level = 108,
					Weight = 352,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 9000,
					NeedElementList = {
						{
							Element = 210004,
							Count = 2,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140403,
			Enemy = {
				{
					Value = 242056,
					Level = 100,
					Weight = 294,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 6700,
				},
				{
					Value = 242058,
					Level = 104,
					Weight = 352,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 8700,
				},
				{
					Value = 242059,
					Level = 108,
					Weight = 352,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 9000,
					NeedElementList = {
						{
							Element = 210004,
							Count = 2,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140402,
			Enemy = {
				{
					Value = 242056,
					Level = 100,
					Weight = 294,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 6700,
				},
				{
					Value = 242058,
					Level = 104,
					Weight = 352,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 8700,
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242056,
					Level = 100,
					Weight = 294,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 6700,
				},
			},
		},
	},
	Challenge = {
		140402,
		140403,
		140404,
	},
	EventList = {
		310401,
		310404,
		310402,
		310403,
	},
}
AreaConfig[AreaID.Id103] =
{
	Id = 103,
	Name = "中心广场",
	Planet = 120003,
	Level = 56,
	AreaElement = 210001,
	NumCap = 5,
	Map = "MUS_map_03",
	LevelIcon = "Icon_MUSBG02",
	LevelBG = "MUSBG02",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "MUS_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140407,
			Enemy = {
				{
					Value = 242056,
					Level = 108,
					Weight = 192,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 6700,
				},
				{
					Value = 242058,
					Level = 110,
					Weight = 230,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 8700,
				},
				{
					Value = 242060,
					Level = 112,
					Weight = 230,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 9400,
				},
				{
					Value = 242061,
					Level = 114,
					Weight = 346,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 10900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140406,
			Enemy = {
				{
					Value = 242056,
					Level = 108,
					Weight = 192,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 6700,
				},
				{
					Value = 242058,
					Level = 110,
					Weight = 230,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 8700,
				},
				{
					Value = 242060,
					Level = 112,
					Weight = 230,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 9400,
				},
				{
					Value = 242061,
					Level = 114,
					Weight = 346,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 10900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140405,
			Enemy = {
				{
					Value = 242056,
					Level = 108,
					Weight = 192,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 6700,
				},
				{
					Value = 242058,
					Level = 110,
					Weight = 230,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 8700,
				},
				{
					Value = 242060,
					Level = 112,
					Weight = 230,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 9400,
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242056,
					Level = 108,
					Weight = 192,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 6700,
				},
				{
					Value = 242058,
					Level = 110,
					Weight = 230,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 8700,
				},
			},
		},
	},
	Challenge = {
		140405,
		140406,
		140407,
	},
	EventList = {
		310405,
		310406,
		310407,
		310408,
		310409,
	},
}
AreaConfig[AreaID.Id104] =
{
	Id = 104,
	Name = "文物厅",
	Planet = 120003,
	Level = 58,
	AreaElement = 210001,
	NumCap = 5,
	Map = "MUS_map_04",
	LevelIcon = "Icon_MUSBG02",
	LevelBG = "MUSBG02",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "MUS_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140410,
			Enemy = {
				{
					Value = 242056,
					Level = 111,
					Weight = 156,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 6700,
				},
				{
					Value = 242060,
					Level = 113,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 9400,
				},
				{
					Value = 242062,
					Level = 115,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 9600,
				},
				{
					Value = 242063,
					Level = 119,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 9900,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242064,
					Level = 123,
					Weight = 281,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 11800,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140409,
			Enemy = {
				{
					Value = 242056,
					Level = 111,
					Weight = 156,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 6700,
				},
				{
					Value = 242060,
					Level = 113,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 9400,
				},
				{
					Value = 242062,
					Level = 115,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 9600,
				},
				{
					Value = 242063,
					Level = 119,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 9900,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140408,
			Enemy = {
				{
					Value = 242056,
					Level = 111,
					Weight = 156,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 6700,
				},
				{
					Value = 242060,
					Level = 113,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 9400,
				},
				{
					Value = 242062,
					Level = 115,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 9600,
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242056,
					Level = 111,
					Weight = 156,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 6700,
				},
				{
					Value = 242060,
					Level = 113,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 9400,
				},
			},
		},
	},
	Challenge = {
		140408,
		140409,
		140410,
	},
	EventList = {
		310410,
		310411,
		310412,
		310413,
	},
}
AreaConfig[AreaID.Id105] =
{
	Id = 105,
	Name = "修复室",
	Planet = 120003,
	Level = 73,
	AreaElement = 210001,
	NumCap = 5,
	Map = "MUS_map_05",
	LevelIcon = "Icon_MUSBG02",
	LevelBG = "MUSBG02",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "MUS_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140415,
			Enemy = {
				{
					Value = 242065,
					Level = 147,
					Weight = 222,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 12200,
				},
				{
					Value = 242066,
					Level = 149,
					Weight = 222,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 12300,
				},
				{
					Value = 242067,
					Level = 152,
					Weight = 222,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 12600,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242068,
					Level = 155,
					Weight = 333,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 14700,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140414,
			Enemy = {
				{
					Value = 242065,
					Level = 147,
					Weight = 222,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 12200,
				},
				{
					Value = 242066,
					Level = 149,
					Weight = 222,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 12300,
				},
				{
					Value = 242067,
					Level = 152,
					Weight = 222,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 12600,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242068,
					Level = 155,
					Weight = 333,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 14700,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140413,
			Enemy = {
				{
					Value = 242065,
					Level = 147,
					Weight = 222,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 12200,
				},
				{
					Value = 242066,
					Level = 149,
					Weight = 222,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 12300,
				},
				{
					Value = 242067,
					Level = 152,
					Weight = 222,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 12600,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140412,
			Enemy = {
				{
					Value = 242065,
					Level = 147,
					Weight = 222,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 12200,
				},
				{
					Value = 242066,
					Level = 149,
					Weight = 222,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 12300,
				},
			},
		},
		{
			NeedChallenge = 140411,
			Enemy = {
				{
					Value = 242065,
					Level = 147,
					Weight = 222,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 12200,
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242065,
					Level = 147,
					Weight = 222,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 480,
					FightPower = 12200,
				},
			},
		},
	},
	Challenge = {
		140411,
		140412,
		140413,
		140414,
		140415,
	},
	EventList = {
		310415,
		310416,
		310414,
		310417,
		310418,
	},
}
AreaConfig[AreaID.Id106] =
{
	Id = 106,
	Name = "生态园",
	Planet = 120003,
	Level = 63,
	AreaElement = 210001,
	NumCap = 5,
	Map = "MUS_map_06",
	LevelIcon = "Icon_MUSBG03",
	LevelBG = "MUSBG03",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "MUS_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140418,
			Enemy = {
				{
					Value = 242056,
					Level = 122,
					Weight = 170,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 6700,
				},
				{
					Value = 242062,
					Level = 124,
					Weight = 204,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 9600,
				},
				{
					Value = 242069,
					Level = 126,
					Weight = 204,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 10500,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242070,
					Level = 130,
					Weight = 204,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 10800,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 242071,
					Level = 134,
					Weight = 215,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 12800,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140417,
			Enemy = {
				{
					Value = 242056,
					Level = 122,
					Weight = 170,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 6700,
				},
				{
					Value = 242062,
					Level = 124,
					Weight = 204,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 9600,
				},
				{
					Value = 242069,
					Level = 126,
					Weight = 204,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 10500,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242070,
					Level = 130,
					Weight = 204,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 10800,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140416,
			Enemy = {
				{
					Value = 242056,
					Level = 122,
					Weight = 170,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 6700,
				},
				{
					Value = 242062,
					Level = 124,
					Weight = 204,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 9600,
				},
				{
					Value = 242069,
					Level = 126,
					Weight = 204,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 10500,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242056,
					Level = 122,
					Weight = 170,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 6700,
				},
				{
					Value = 242062,
					Level = 124,
					Weight = 204,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 9600,
				},
			},
		},
	},
	Challenge = {
		140416,
		140417,
		140418,
	},
	EventList = {
		310419,
		310420,
		310421,
		310422,
	},
}
AreaConfig[AreaID.Id107] =
{
	Id = 107,
	Name = "监控室",
	Planet = 120003,
	Level = 76,
	AreaElement = 210001,
	NumCap = 5,
	Map = "MUS_map_07",
	LevelIcon = "Icon_MUSBG03",
	LevelBG = "MUSBG03",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "MUS_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140421,
			Enemy = {
				{
					Value = 242057,
					Level = 152,
					Weight = 121,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 8600,
				},
				{
					Value = 242067,
					Level = 154,
					Weight = 146,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 12600,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242069,
					Level = 156,
					Weight = 146,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 10500,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242072,
					Level = 160,
					Weight = 146,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 13200,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 242073,
					Level = 165,
					Weight = 439,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 3600,
					FightPower = 17700,
					NeedElementList = {
						{
							Element = 210004,
							Count = 2,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140420,
			Enemy = {
				{
					Value = 242057,
					Level = 152,
					Weight = 121,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 8600,
				},
				{
					Value = 242067,
					Level = 154,
					Weight = 146,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 12600,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242069,
					Level = 156,
					Weight = 146,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 10500,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242072,
					Level = 160,
					Weight = 146,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 13200,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 242073,
					Level = 165,
					Weight = 439,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 3600,
					FightPower = 17700,
					NeedElementList = {
						{
							Element = 210004,
							Count = 2,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140419,
			Enemy = {
				{
					Value = 242057,
					Level = 152,
					Weight = 121,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 8600,
				},
				{
					Value = 242067,
					Level = 154,
					Weight = 146,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 12600,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242069,
					Level = 156,
					Weight = 146,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 10500,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242072,
					Level = 160,
					Weight = 146,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 13200,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242057,
					Level = 152,
					Weight = 121,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 8600,
				},
				{
					Value = 242067,
					Level = 154,
					Weight = 146,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 12600,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242069,
					Level = 156,
					Weight = 146,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 10500,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
			},
		},
	},
	Challenge = {
		140419,
		140420,
		140421,
	},
	EventList = {
		310424,
		310423,
		310425,
		310426,
	},
}
AreaConfig[AreaID.Id108] =
{
	Id = 108,
	Name = "古文明厅",
	Planet = 120003,
	Level = 68,
	AreaElement = 210001,
	NumCap = 5,
	Map = "MUS_map_08",
	LevelIcon = "Icon_MUSBG03",
	LevelBG = "MUSBG03",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "MUS_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140425,
			Enemy = {
				{
					Value = 242057,
					Level = 130,
					Weight = 140,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 8600,
				},
				{
					Value = 242063,
					Level = 132,
					Weight = 168,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 9900,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242072,
					Level = 134,
					Weight = 168,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 13200,
					NeedElementList = {
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 242074,
					Level = 136,
					Weight = 168,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 11300,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242075,
					Level = 140,
					Weight = 353,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 3600,
					FightPower = 15100,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140424,
			Enemy = {
				{
					Value = 242057,
					Level = 130,
					Weight = 140,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 8600,
				},
				{
					Value = 242063,
					Level = 132,
					Weight = 168,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 9900,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242072,
					Level = 134,
					Weight = 168,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 13200,
					NeedElementList = {
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 242074,
					Level = 136,
					Weight = 168,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 11300,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242075,
					Level = 140,
					Weight = 353,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 3600,
					FightPower = 15100,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140423,
			Enemy = {
				{
					Value = 242057,
					Level = 130,
					Weight = 140,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 8600,
				},
				{
					Value = 242063,
					Level = 132,
					Weight = 168,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 9900,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242072,
					Level = 134,
					Weight = 168,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 13200,
					NeedElementList = {
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 242074,
					Level = 136,
					Weight = 168,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 11300,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140422,
			Enemy = {
				{
					Value = 242057,
					Level = 130,
					Weight = 140,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 8600,
				},
				{
					Value = 242063,
					Level = 132,
					Weight = 168,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 9900,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242072,
					Level = 134,
					Weight = 168,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 13200,
					NeedElementList = {
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242057,
					Level = 130,
					Weight = 140,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 200,
					FightPower = 8600,
				},
				{
					Value = 242063,
					Level = 132,
					Weight = 168,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 9900,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242072,
					Level = 134,
					Weight = 168,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 13200,
					NeedElementList = {
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
			},
		},
	},
	Challenge = {
		140422,
		140423,
		140424,
		140425,
	},
	EventList = {
		310427,
		310428,
		310429,
		310430,
		310431,
		310432,
	},
}
AreaConfig[AreaID.Id109] =
{
	Id = 109,
	Name = "化石厅",
	Planet = 120003,
	Level = 72,
	AreaElement = 210001,
	NumCap = 5,
	Map = "MUS_map_09",
	LevelIcon = "Icon_MUSBG04",
	LevelBG = "MUSBG04",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "MUS_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140428,
			Enemy = {
				{
					Value = 242057,
					Level = 139,
					Weight = 172,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 8600,
				},
				{
					Value = 242067,
					Level = 141,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 12600,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242074,
					Level = 143,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 11300,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242076,
					Level = 145,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 12000,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242077,
					Level = 149,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 12300,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140427,
			Enemy = {
				{
					Value = 242057,
					Level = 139,
					Weight = 172,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 8600,
				},
				{
					Value = 242067,
					Level = 141,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 12600,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242074,
					Level = 143,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 11300,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242076,
					Level = 145,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 12000,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242077,
					Level = 149,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 12300,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140426,
			Enemy = {
				{
					Value = 242057,
					Level = 139,
					Weight = 172,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 8600,
				},
				{
					Value = 242067,
					Level = 141,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 12600,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242074,
					Level = 143,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 11300,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 242076,
					Level = 145,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 12000,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242057,
					Level = 139,
					Weight = 172,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 8600,
				},
				{
					Value = 242067,
					Level = 141,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 12600,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 242074,
					Level = 143,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 11300,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
			},
		},
	},
	Challenge = {
		140426,
		140427,
		140428,
	},
	EventList = {
		310433,
		310436,
		310434,
		310435,
	},
}
AreaConfig[AreaID.Id110] =
{
	Id = 110,
	Name = "泥塑厅",
	Planet = 120003,
	Level = 73,
	AreaElement = 210001,
	NumCap = 5,
	Map = "MUS_map_10",
	LevelIcon = "Icon_MUSBG04",
	LevelBG = "MUSBG04",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "MUS_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140430,
			Enemy = {
				{
					Value = 242057,
					Level = 142,
					Weight = 172,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 8600,
				},
				{
					Value = 242072,
					Level = 144,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 13200,
					NeedElementList = {
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 242076,
					Level = 146,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 12000,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242078,
					Level = 148,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 12200,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242079,
					Level = 152,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 12600,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140429,
			Enemy = {
				{
					Value = 242057,
					Level = 142,
					Weight = 172,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 8600,
				},
				{
					Value = 242072,
					Level = 144,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 13200,
					NeedElementList = {
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 242076,
					Level = 146,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 12000,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242078,
					Level = 148,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 12200,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242057,
					Level = 142,
					Weight = 172,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 8600,
				},
				{
					Value = 242072,
					Level = 144,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 13200,
					NeedElementList = {
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 242076,
					Level = 146,
					Weight = 206,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 12000,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
			},
		},
	},
	Challenge = {
		140429,
		140430,
	},
	EventList = {
		310437,
		310438,
		310439,
		310440,
		310441,
	},
}
AreaConfig[AreaID.Id111] =
{
	Id = 111,
	Name = "恐龙馆",
	Planet = 120003,
	Level = 79,
	AreaElement = 210001,
	NumCap = 5,
	Map = "MUS_map_11",
	LevelIcon = "Icon_MUSBG04",
	LevelBG = "MUSBG04",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "MUS_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140433,
			Enemy = {
				{
					Value = 242057,
					Level = 148,
					Weight = 156,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 8600,
				},
				{
					Value = 242070,
					Level = 152,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 10800,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 242078,
					Level = 156,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 12200,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242080,
					Level = 160,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 13200,
					NeedElementList = {
						{
							Element = 210001,
							Count = 2,
						},
					},
				},
				{
					Value = 242081,
					Level = 166,
					Weight = 281,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 15700,
					NeedElementList = {
						{
							Element = 210002,
							Count = 2,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140432,
			Enemy = {
				{
					Value = 242057,
					Level = 148,
					Weight = 156,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 8600,
				},
				{
					Value = 242070,
					Level = 152,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 10800,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 242078,
					Level = 156,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 12200,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242080,
					Level = 160,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 13200,
					NeedElementList = {
						{
							Element = 210001,
							Count = 2,
						},
					},
				},
				{
					Value = 242081,
					Level = 166,
					Weight = 281,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 15700,
					NeedElementList = {
						{
							Element = 210002,
							Count = 2,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140431,
			Enemy = {
				{
					Value = 242057,
					Level = 148,
					Weight = 156,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 8600,
				},
				{
					Value = 242070,
					Level = 152,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 10800,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 242078,
					Level = 156,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 12200,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
				{
					Value = 242080,
					Level = 160,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 13200,
					NeedElementList = {
						{
							Element = 210001,
							Count = 2,
						},
					},
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242057,
					Level = 148,
					Weight = 156,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 8600,
				},
				{
					Value = 242070,
					Level = 152,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 10800,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 242078,
					Level = 156,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 12200,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
					},
				},
			},
		},
	},
	Challenge = {
		140431,
		140432,
		140433,
	},
	EventList = {
		310442,
		310443,
		310444,
		310445,
	},
}
AreaConfig[AreaID.Id112] =
{
	Id = 112,
	Name = "出口",
	Planet = 120003,
	Level = 83,
	AreaElement = 210001,
	NumCap = 5,
	Map = "MUS_map_12",
	LevelIcon = "Icon_MUSBG01",
	LevelBG = "MUSBG01",
	LevelAtlas = "EventBG",
	LevelBundle = "packed_eventbg",
	StartScene = "MUS_StartScene",
	LevelEnemy = {
		{
			NeedChallenge = 140436,
			Enemy = {
				{
					Value = 242057,
					Level = 158,
					Weight = 156,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 8600,
				},
				{
					Value = 242072,
					Level = 160,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 13200,
					NeedElementList = {
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 242080,
					Level = 162,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 13200,
					NeedElementList = {
						{
							Element = 210001,
							Count = 2,
						},
					},
				},
				{
					Value = 242082,
					Level = 164,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 13500,
				},
				{
					Value = 242083,
					Level = 172,
					Weight = 281,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 3600,
					FightPower = 18400,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140435,
			Enemy = {
				{
					Value = 242057,
					Level = 158,
					Weight = 156,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 8600,
				},
				{
					Value = 242072,
					Level = 160,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 13200,
					NeedElementList = {
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 242080,
					Level = 162,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 13200,
					NeedElementList = {
						{
							Element = 210001,
							Count = 2,
						},
					},
				},
				{
					Value = 242082,
					Level = 164,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 13500,
				},
				{
					Value = 242083,
					Level = 172,
					Weight = 281,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 3600,
					FightPower = 18400,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
			},
		},
		{
			NeedChallenge = 140434,
			Enemy = {
				{
					Value = 242057,
					Level = 158,
					Weight = 156,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 8600,
				},
				{
					Value = 242072,
					Level = 160,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 13200,
					NeedElementList = {
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 242080,
					Level = 162,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 13200,
					NeedElementList = {
						{
							Element = 210001,
							Count = 2,
						},
					},
				},
				{
					Value = 242082,
					Level = 164,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 13500,
				},
			},
		},
		{
			Enemy = {
				{
					Value = 242057,
					Level = 158,
					Weight = 156,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 100,
					FightPower = 8600,
				},
				{
					Value = 242072,
					Level = 160,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 13200,
					NeedElementList = {
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 242080,
					Level = 162,
					Weight = 187,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 240,
					FightPower = 13200,
					NeedElementList = {
						{
							Element = 210001,
							Count = 2,
						},
					},
				},
			},
		},
	},
	Challenge = {
		140434,
		140435,
		140436,
	},
	EventList = {
		310446,
		310447,
		310448,
		310449,
	},
}
