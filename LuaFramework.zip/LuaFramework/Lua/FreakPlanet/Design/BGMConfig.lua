BGMConfig ={};
BGMConfig["BGM_Account"] =
{
	Id = 1,
	Name = "妙奇星球",
}
BGMConfig["BGM_Main_Menu"] =
{
	Id = 2,
	Name = "小猫探险队",
}
BGMConfig["BGM_Main_Menu3"] =
{
	Id = 3,
	Name = "悠闲的冒险",
}
BGMConfig["Music_SEA"] =
{
	Id = 4,
	Name = "和你一起的旅行",
}
