
EquipmentConfig[EquipmentID.Id333] =
{
	Character = 222045,
	Rarity = 4,
	UpgradeId = 930073,
	LevelList = {
		{
			Level = 1,
			Info = 920549,
			Ability = {
				{
					Value = 200001,
					Num = 75,
				},
				{
					Value = 200007,
					Num = 21,
				},
			},
		},
		{
			Level = 2,
			Info = 920549,
			Ability = {
				{
					Value = 200001,
					Num = 150,
				},
				{
					Value = 200007,
					Num = 42,
				},
			},
		},
		{
			Level = 3,
			Info = 920549,
			Ability = {
				{
					Value = 200001,
					Num = 225,
				},
				{
					Value = 200007,
					Num = 63,
				},
			},
		},
		{
			Level = 4,
			Info = 920549,
			Ability = {
				{
					Value = 200001,
					Num = 300,
				},
				{
					Value = 200007,
					Num = 84,
				},
			},
		},
		{
			Level = 5,
			Info = 920549,
			Ability = {
				{
					Value = 200001,
					Num = 375,
				},
				{
					Value = 200007,
					Num = 105,
				},
			},
		},
		{
			Level = 6,
			Info = 920549,
			Ability = {
				{
					Value = 200001,
					Num = 450,
				},
				{
					Value = 200007,
					Num = 126,
				},
			},
		},
		{
			Level = 7,
			Info = 920549,
			Ability = {
				{
					Value = 200001,
					Num = 525,
				},
				{
					Value = 200007,
					Num = 147,
				},
			},
		},
		{
			Level = 8,
			Info = 920549,
			Ability = {
				{
					Value = 200001,
					Num = 600,
				},
				{
					Value = 200007,
					Num = 168,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920549,
			Ability = {
				{
					Value = 200001,
					Num = 675,
				},
				{
					Value = 200007,
					Num = 189,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920549,
			Ability = {
				{
					Value = 200001,
					Num = 750,
				},
				{
					Value = 200007,
					Num = 210,
				},
			},
			SkillList = {
				{
					Id = 100562,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id334] =
{
	Character = 222045,
	Rarity = 4,
	UpgradeId = 930054,
	LevelList = {
		{
			Level = 1,
			Info = 920551,
			Ability = {
				{
					Value = 200002,
					Num = 54,
				},
				{
					Value = 200007,
					Num = 21,
				},
			},
		},
		{
			Level = 2,
			Info = 920551,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
				{
					Value = 200007,
					Num = 42,
				},
			},
		},
		{
			Level = 3,
			Info = 920551,
			Ability = {
				{
					Value = 200002,
					Num = 162,
				},
				{
					Value = 200007,
					Num = 63,
				},
			},
		},
		{
			Level = 4,
			Info = 920551,
			Ability = {
				{
					Value = 200002,
					Num = 216,
				},
				{
					Value = 200007,
					Num = 84,
				},
			},
		},
		{
			Level = 5,
			Info = 920551,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
				{
					Value = 200007,
					Num = 105,
				},
			},
		},
		{
			Level = 6,
			Info = 920551,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
				{
					Value = 200007,
					Num = 126,
				},
			},
		},
		{
			Level = 7,
			Info = 920551,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200007,
					Num = 147,
				},
			},
		},
		{
			Level = 8,
			Info = 920551,
			Ability = {
				{
					Value = 200002,
					Num = 432,
				},
				{
					Value = 200007,
					Num = 168,
				},
			},
			SkillList = {
				{
					Id = 100667,
					Value = 2,
				},
			},
		},
		{
			Level = 9,
			Info = 920551,
			Ability = {
				{
					Value = 200002,
					Num = 486,
				},
				{
					Value = 200007,
					Num = 189,
				},
			},
			SkillList = {
				{
					Id = 100667,
					Value = 2,
				},
			},
		},
		{
			Level = 10,
			Info = 920551,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200007,
					Num = 210,
				},
			},
			SkillList = {
				{
					Id = 100667,
					Value = 2,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id335] =
{
	Character = 222045,
	Rarity = 4,
	NeedChallenge = 145133,
	UpgradeId = 930055,
	LevelList = {
		{
			Level = 1,
			Info = 920550,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
			},
		},
		{
			Level = 2,
			Info = 920550,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
			},
		},
		{
			Level = 3,
			Info = 920550,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
		},
		{
			Level = 4,
			Info = 920550,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
			},
		},
		{
			Level = 5,
			Info = 920550,
			Ability = {
				{
					Value = 200002,
					Num = 396,
				},
				{
					Value = 200001,
					Num = 176,
				},
			},
		},
		{
			Level = 6,
			Info = 920550,
			Ability = {
				{
					Value = 200002,
					Num = 468,
				},
				{
					Value = 200001,
					Num = 208,
				},
			},
		},
		{
			Level = 7,
			Info = 920550,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200001,
					Num = 240,
				},
			},
		},
		{
			Level = 8,
			Info = 920550,
			Ability = {
				{
					Value = 200002,
					Num = 612,
				},
				{
					Value = 200001,
					Num = 272,
				},
			},
			SkillList = {
				{
					Id = 101759,
					Value = 48,
				},
			},
		},
		{
			Level = 9,
			Info = 920550,
			Ability = {
				{
					Value = 200002,
					Num = 684,
				},
				{
					Value = 200001,
					Num = 304,
				},
			},
			SkillList = {
				{
					Id = 101759,
					Value = 48,
				},
			},
		},
		{
			Level = 10,
			Info = 920550,
			Ability = {
				{
					Value = 200002,
					Num = 756,
				},
				{
					Value = 200001,
					Num = 336,
				},
			},
			SkillList = {
				{
					Id = 101759,
					Value = 48,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id336] =
{
	Character = 222046,
	Rarity = 4,
	UpgradeId = 930053,
	LevelList = {
		{
			Level = 1,
			Info = 920552,
			Ability = {
				{
					Value = 200002,
					Num = 60,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920552,
			Ability = {
				{
					Value = 200002,
					Num = 120,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920552,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920552,
			Ability = {
				{
					Value = 200002,
					Num = 240,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920552,
			Ability = {
				{
					Value = 200002,
					Num = 300,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920552,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920552,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200005,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920552,
			Ability = {
				{
					Value = 200002,
					Num = 480,
				},
				{
					Value = 200005,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 101745,
					Value = 60,
				},
			},
		},
		{
			Level = 9,
			Info = 920552,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200005,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 101745,
					Value = 60,
				},
			},
		},
		{
			Level = 10,
			Info = 920552,
			Ability = {
				{
					Value = 200002,
					Num = 600,
				},
				{
					Value = 200005,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 101745,
					Value = 60,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id337] =
{
	Character = 222046,
	Rarity = 4,
	UpgradeId = 930054,
	LevelList = {
		{
			Level = 1,
			Info = 920554,
			Ability = {
				{
					Value = 200002,
					Num = 60,
				},
				{
					Value = 200007,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920554,
			Ability = {
				{
					Value = 200002,
					Num = 120,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920554,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
				{
					Value = 200007,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920554,
			Ability = {
				{
					Value = 200002,
					Num = 240,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920554,
			Ability = {
				{
					Value = 200002,
					Num = 300,
				},
				{
					Value = 200007,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920554,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920554,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200007,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920554,
			Ability = {
				{
					Value = 200002,
					Num = 480,
				},
				{
					Value = 200007,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920554,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200007,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920554,
			Ability = {
				{
					Value = 200002,
					Num = 600,
				},
				{
					Value = 200007,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id338] =
{
	Character = 222046,
	Rarity = 4,
	NeedChallenge = 145134,
	UpgradeId = 930075,
	LevelList = {
		{
			Level = 1,
			Info = 920553,
			Ability = {
				{
					Value = 200001,
					Num = 138,
				},
			},
		},
		{
			Level = 2,
			Info = 920553,
			Ability = {
				{
					Value = 200001,
					Num = 230,
				},
			},
		},
		{
			Level = 3,
			Info = 920553,
			Ability = {
				{
					Value = 200001,
					Num = 322,
				},
			},
		},
		{
			Level = 4,
			Info = 920553,
			Ability = {
				{
					Value = 200001,
					Num = 414,
				},
			},
		},
		{
			Level = 5,
			Info = 920553,
			Ability = {
				{
					Value = 200001,
					Num = 506,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920553,
			Ability = {
				{
					Value = 200001,
					Num = 598,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920553,
			Ability = {
				{
					Value = 200001,
					Num = 690,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920553,
			Ability = {
				{
					Value = 200001,
					Num = 782,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101734,
					Value = 22,
				},
			},
		},
		{
			Level = 9,
			Info = 920553,
			Ability = {
				{
					Value = 200001,
					Num = 874,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101734,
					Value = 22,
				},
			},
		},
		{
			Level = 10,
			Info = 920553,
			Ability = {
				{
					Value = 200001,
					Num = 966,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101734,
					Value = 22,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id339] =
{
	Character = 222047,
	Rarity = 4,
	UpgradeId = 930073,
	LevelList = {
		{
			Level = 1,
			Info = 920555,
			Ability = {
				{
					Value = 200001,
					Num = 213,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920555,
			Ability = {
				{
					Value = 200001,
					Num = 426,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920555,
			Ability = {
				{
					Value = 200001,
					Num = 639,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920555,
			Ability = {
				{
					Value = 200001,
					Num = 852,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920555,
			Ability = {
				{
					Value = 200001,
					Num = 1065,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920555,
			Ability = {
				{
					Value = 200001,
					Num = 1278,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920555,
			Ability = {
				{
					Value = 200001,
					Num = 1491,
				},
				{
					Value = 200008,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920555,
			Ability = {
				{
					Value = 200001,
					Num = 1704,
				},
				{
					Value = 200008,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -50,
				},
			},
		},
		{
			Level = 9,
			Info = 920555,
			Ability = {
				{
					Value = 200001,
					Num = 1917,
				},
				{
					Value = 200008,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -50,
				},
			},
		},
		{
			Level = 10,
			Info = 920555,
			Ability = {
				{
					Value = 200001,
					Num = 2130,
				},
				{
					Value = 200008,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -50,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id340] =
{
	Character = 222047,
	Rarity = 4,
	UpgradeId = 930074,
	LevelList = {
		{
			Level = 1,
			Info = 920556,
			Ability = {
				{
					Value = 200001,
					Num = 213,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920556,
			Ability = {
				{
					Value = 200001,
					Num = 426,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920556,
			Ability = {
				{
					Value = 200001,
					Num = 639,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920556,
			Ability = {
				{
					Value = 200001,
					Num = 852,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920556,
			Ability = {
				{
					Value = 200001,
					Num = 1065,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920556,
			Ability = {
				{
					Value = 200001,
					Num = 1278,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920556,
			Ability = {
				{
					Value = 200001,
					Num = 1491,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920556,
			Ability = {
				{
					Value = 200001,
					Num = 1704,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 101722,
					Value = 378,
				},
			},
		},
		{
			Level = 9,
			Info = 920556,
			Ability = {
				{
					Value = 200001,
					Num = 1917,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 101722,
					Value = 378,
				},
			},
		},
		{
			Level = 10,
			Info = 920556,
			Ability = {
				{
					Value = 200001,
					Num = 2130,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 101722,
					Value = 378,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id341] =
{
	Character = 222047,
	Rarity = 4,
	NeedChallenge = 145135,
	UpgradeId = 930075,
	LevelList = {
		{
			Level = 1,
			Info = 920557,
			Ability = {
				{
					Value = 200001,
					Num = 426,
				},
			},
		},
		{
			Level = 2,
			Info = 920557,
			Ability = {
				{
					Value = 200001,
					Num = 710,
				},
			},
		},
		{
			Level = 3,
			Info = 920557,
			Ability = {
				{
					Value = 200001,
					Num = 994,
				},
			},
		},
		{
			Level = 4,
			Info = 920557,
			Ability = {
				{
					Value = 200001,
					Num = 1278,
				},
			},
		},
		{
			Level = 5,
			Info = 920557,
			Ability = {
				{
					Value = 200001,
					Num = 1562,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920557,
			Ability = {
				{
					Value = 200001,
					Num = 1846,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920557,
			Ability = {
				{
					Value = 200001,
					Num = 2130,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920557,
			Ability = {
				{
					Value = 200001,
					Num = 2414,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101750,
					Value = 50,
				},
			},
		},
		{
			Level = 9,
			Info = 920557,
			Ability = {
				{
					Value = 200001,
					Num = 2698,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101750,
					Value = 50,
				},
			},
		},
		{
			Level = 10,
			Info = 920557,
			Ability = {
				{
					Value = 200001,
					Num = 2982,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101750,
					Value = 50,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id342] =
{
	Character = 222048,
	Rarity = 4,
	UpgradeId = 930073,
	LevelList = {
		{
			Level = 1,
			Info = 920559,
			Ability = {
				{
					Value = 200001,
					Num = 72,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920559,
			Ability = {
				{
					Value = 200001,
					Num = 144,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920559,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920559,
			Ability = {
				{
					Value = 200001,
					Num = 288,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920559,
			Ability = {
				{
					Value = 200001,
					Num = 360,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920559,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920559,
			Ability = {
				{
					Value = 200001,
					Num = 504,
				},
				{
					Value = 200008,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920559,
			Ability = {
				{
					Value = 200001,
					Num = 576,
				},
				{
					Value = 200008,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920559,
			Ability = {
				{
					Value = 200001,
					Num = 648,
				},
				{
					Value = 200008,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920559,
			Ability = {
				{
					Value = 200001,
					Num = 720,
				},
				{
					Value = 200008,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id343] =
{
	Character = 222048,
	Rarity = 4,
	UpgradeId = 930054,
	LevelList = {
		{
			Level = 1,
			Info = 920558,
			Ability = {
				{
					Value = 200002,
					Num = 54,
				},
			},
		},
		{
			Level = 2,
			Info = 920558,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
			},
		},
		{
			Level = 3,
			Info = 920558,
			Ability = {
				{
					Value = 200002,
					Num = 162,
				},
			},
		},
		{
			Level = 4,
			Info = 920558,
			Ability = {
				{
					Value = 200002,
					Num = 216,
				},
			},
		},
		{
			Level = 5,
			Info = 920558,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
				{
					Value = 200001,
					Num = 120,
				},
			},
		},
		{
			Level = 6,
			Info = 920558,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
				{
					Value = 200001,
					Num = 144,
				},
			},
		},
		{
			Level = 7,
			Info = 920558,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200001,
					Num = 168,
				},
			},
		},
		{
			Level = 8,
			Info = 920558,
			Ability = {
				{
					Value = 200002,
					Num = 432,
				},
				{
					Value = 200001,
					Num = 192,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920558,
			Ability = {
				{
					Value = 200002,
					Num = 486,
				},
				{
					Value = 200001,
					Num = 216,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920558,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200001,
					Num = 240,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id344] =
{
	Character = 222048,
	Rarity = 4,
	NeedChallenge = 145136,
	UpgradeId = 930055,
	LevelList = {
		{
			Level = 1,
			Info = 920560,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
			},
		},
		{
			Level = 2,
			Info = 920560,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
			},
		},
		{
			Level = 3,
			Info = 920560,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
		},
		{
			Level = 4,
			Info = 920560,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
			},
		},
		{
			Level = 5,
			Info = 920560,
			Ability = {
				{
					Value = 200002,
					Num = 396,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920560,
			Ability = {
				{
					Value = 200002,
					Num = 468,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920560,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920560,
			Ability = {
				{
					Value = 200002,
					Num = 612,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101501,
					Value = -4,
				},
			},
		},
		{
			Level = 9,
			Info = 920560,
			Ability = {
				{
					Value = 200002,
					Num = 684,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101501,
					Value = -4,
				},
			},
		},
		{
			Level = 10,
			Info = 920560,
			Ability = {
				{
					Value = 200002,
					Num = 756,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101501,
					Value = -4,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id345] =
{
	Character = 222049,
	Rarity = 5,
	UpgradeId = 930057,
	LevelList = {
		{
			Level = 1,
			Info = 920561,
			Ability = {
				{
					Value = 200002,
					Num = 63,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920561,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920561,
			Ability = {
				{
					Value = 200002,
					Num = 189,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920561,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920561,
			Ability = {
				{
					Value = 200002,
					Num = 315,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920561,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920561,
			Ability = {
				{
					Value = 200002,
					Num = 441,
				},
				{
					Value = 200005,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920561,
			Ability = {
				{
					Value = 200002,
					Num = 504,
				},
				{
					Value = 200005,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920561,
			Ability = {
				{
					Value = 200002,
					Num = 567,
				},
				{
					Value = 200005,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920561,
			Ability = {
				{
					Value = 200002,
					Num = 630,
				},
				{
					Value = 200005,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id346] =
{
	Character = 222049,
	Rarity = 5,
	UpgradeId = 930078,
	LevelList = {
		{
			Level = 1,
			Info = 920562,
			Ability = {
				{
					Value = 200001,
					Num = 90,
				},
				{
					Value = 200007,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920562,
			Ability = {
				{
					Value = 200001,
					Num = 180,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920562,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200007,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920562,
			Ability = {
				{
					Value = 200001,
					Num = 360,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920562,
			Ability = {
				{
					Value = 200001,
					Num = 450,
				},
				{
					Value = 200007,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920562,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920562,
			Ability = {
				{
					Value = 200001,
					Num = 630,
				},
				{
					Value = 200007,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920562,
			Ability = {
				{
					Value = 200001,
					Num = 720,
				},
				{
					Value = 200007,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 101745,
					Value = 60,
				},
			},
		},
		{
			Level = 9,
			Info = 920562,
			Ability = {
				{
					Value = 200001,
					Num = 810,
				},
				{
					Value = 200007,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 101745,
					Value = 60,
				},
			},
		},
		{
			Level = 10,
			Info = 920562,
			Ability = {
				{
					Value = 200001,
					Num = 900,
				},
				{
					Value = 200007,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 101745,
					Value = 60,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id347] =
{
	Character = 222049,
	Rarity = 5,
	NeedChallenge = 145137,
	UpgradeId = 930079,
	LevelList = {
		{
			Level = 1,
			Info = 920563,
			Ability = {
				{
					Value = 200001,
					Num = 180,
				},
			},
		},
		{
			Level = 2,
			Info = 920563,
			Ability = {
				{
					Value = 200001,
					Num = 300,
				},
			},
		},
		{
			Level = 3,
			Info = 920563,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
			},
		},
		{
			Level = 4,
			Info = 920563,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
			},
		},
		{
			Level = 5,
			Info = 920563,
			Ability = {
				{
					Value = 200001,
					Num = 660,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920563,
			Ability = {
				{
					Value = 200001,
					Num = 780,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920563,
			Ability = {
				{
					Value = 200001,
					Num = 900,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920563,
			Ability = {
				{
					Value = 200001,
					Num = 1020,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101751,
					Value = 2,
				},
			},
		},
		{
			Level = 9,
			Info = 920563,
			Ability = {
				{
					Value = 200001,
					Num = 1140,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101751,
					Value = 2,
				},
			},
		},
		{
			Level = 10,
			Info = 920563,
			Ability = {
				{
					Value = 200001,
					Num = 1260,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101751,
					Value = 2,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id348] =
{
	Character = 222049,
	Rarity = 5,
	NeedChallenge = 145138,
	UpgradeId = 930080,
	LevelList = {
		{
			Level = 1,
			Info = 920564,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
			},
		},
		{
			Level = 2,
			Info = 920564,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
			},
		},
		{
			Level = 3,
			Info = 920564,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
			},
		},
		{
			Level = 4,
			Info = 920564,
			Ability = {
				{
					Value = 200001,
					Num = 720,
				},
			},
		},
		{
			Level = 5,
			Info = 920564,
			Ability = {
				{
					Value = 200001,
					Num = 870,
				},
				{
					Value = 200002,
					Num = 870,
				},
			},
		},
		{
			Level = 6,
			Info = 920564,
			Ability = {
				{
					Value = 200001,
					Num = 1020,
				},
				{
					Value = 200002,
					Num = 1020,
				},
			},
		},
		{
			Level = 7,
			Info = 920564,
			Ability = {
				{
					Value = 200001,
					Num = 1170,
				},
				{
					Value = 200002,
					Num = 1170,
				},
			},
		},
		{
			Level = 8,
			Info = 920564,
			Ability = {
				{
					Value = 200001,
					Num = 1320,
				},
				{
					Value = 200002,
					Num = 1320,
				},
			},
			SkillList = {
				{
					Id = 100716,
					Value = 2,
				},
			},
		},
		{
			Level = 9,
			Info = 920564,
			Ability = {
				{
					Value = 200001,
					Num = 1470,
				},
				{
					Value = 200002,
					Num = 1470,
				},
			},
			SkillList = {
				{
					Id = 100716,
					Value = 2,
				},
			},
		},
		{
			Level = 10,
			Info = 920564,
			Ability = {
				{
					Value = 200001,
					Num = 1620,
				},
				{
					Value = 200002,
					Num = 1620,
				},
			},
			SkillList = {
				{
					Id = 100716,
					Value = 2,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id349] =
{
	Character = 222050,
	Rarity = 5,
	UpgradeId = 930077,
	LevelList = {
		{
			Level = 1,
			Info = 920565,
			Ability = {
				{
					Value = 200001,
					Num = 84,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920565,
			Ability = {
				{
					Value = 200001,
					Num = 168,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920565,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920565,
			Ability = {
				{
					Value = 200001,
					Num = 336,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920565,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920565,
			Ability = {
				{
					Value = 200001,
					Num = 504,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920565,
			Ability = {
				{
					Value = 200001,
					Num = 588,
				},
				{
					Value = 200008,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920565,
			Ability = {
				{
					Value = 200001,
					Num = 672,
				},
				{
					Value = 200008,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920565,
			Ability = {
				{
					Value = 200001,
					Num = 756,
				},
				{
					Value = 200008,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920565,
			Ability = {
				{
					Value = 200001,
					Num = 840,
				},
				{
					Value = 200008,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id350] =
{
	Character = 222050,
	Rarity = 5,
	UpgradeId = 930058,
	LevelList = {
		{
			Level = 1,
			Info = 920567,
			Ability = {
				{
					Value = 200002,
					Num = 72,
				},
				{
					Value = 200006,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920567,
			Ability = {
				{
					Value = 200002,
					Num = 144,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920567,
			Ability = {
				{
					Value = 200002,
					Num = 216,
				},
				{
					Value = 200006,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920567,
			Ability = {
				{
					Value = 200002,
					Num = 288,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920567,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
				{
					Value = 200006,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920567,
			Ability = {
				{
					Value = 200002,
					Num = 432,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920567,
			Ability = {
				{
					Value = 200002,
					Num = 504,
				},
				{
					Value = 200006,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920567,
			Ability = {
				{
					Value = 200002,
					Num = 576,
				},
				{
					Value = 200006,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 101761,
					Value = 75,
				},
			},
		},
		{
			Level = 9,
			Info = 920567,
			Ability = {
				{
					Value = 200002,
					Num = 648,
				},
				{
					Value = 200006,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 101761,
					Value = 75,
				},
			},
		},
		{
			Level = 10,
			Info = 920567,
			Ability = {
				{
					Value = 200002,
					Num = 720,
				},
				{
					Value = 200006,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 101761,
					Value = 75,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id351] =
{
	Character = 222050,
	Rarity = 5,
	NeedChallenge = 145139,
	UpgradeId = 930059,
	LevelList = {
		{
			Level = 1,
			Info = 920566,
			Ability = {
				{
					Value = 200002,
					Num = 144,
				},
			},
		},
		{
			Level = 2,
			Info = 920566,
			Ability = {
				{
					Value = 200002,
					Num = 240,
				},
			},
		},
		{
			Level = 3,
			Info = 920566,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
			},
		},
		{
			Level = 4,
			Info = 920566,
			Ability = {
				{
					Value = 200002,
					Num = 432,
				},
			},
		},
		{
			Level = 5,
			Info = 920566,
			Ability = {
				{
					Value = 200002,
					Num = 528,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920566,
			Ability = {
				{
					Value = 200002,
					Num = 624,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920566,
			Ability = {
				{
					Value = 200002,
					Num = 720,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920566,
			Ability = {
				{
					Value = 200002,
					Num = 816,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101503,
					Value = -22,
				},
			},
		},
		{
			Level = 9,
			Info = 920566,
			Ability = {
				{
					Value = 200002,
					Num = 912,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101503,
					Value = -22,
				},
			},
		},
		{
			Level = 10,
			Info = 920566,
			Ability = {
				{
					Value = 200002,
					Num = 1008,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101503,
					Value = -22,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id352] =
{
	Character = 222050,
	Rarity = 5,
	NeedChallenge = 145140,
	UpgradeId = 930060,
	LevelList = {
		{
			Level = 1,
			Info = 920568,
			Ability = {
				{
					Value = 200002,
					Num = 216,
				},
			},
		},
		{
			Level = 2,
			Info = 920568,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
			},
		},
		{
			Level = 3,
			Info = 920568,
			Ability = {
				{
					Value = 200002,
					Num = 456,
				},
			},
		},
		{
			Level = 4,
			Info = 920568,
			Ability = {
				{
					Value = 200002,
					Num = 576,
				},
			},
		},
		{
			Level = 5,
			Info = 920568,
			Ability = {
				{
					Value = 200002,
					Num = 696,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920568,
			Ability = {
				{
					Value = 200002,
					Num = 816,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920568,
			Ability = {
				{
					Value = 200002,
					Num = 936,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920568,
			Ability = {
				{
					Value = 200002,
					Num = 1056,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101504,
					Value = -22,
				},
			},
		},
		{
			Level = 9,
			Info = 920568,
			Ability = {
				{
					Value = 200002,
					Num = 1176,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101504,
					Value = -22,
				},
			},
		},
		{
			Level = 10,
			Info = 920568,
			Ability = {
				{
					Value = 200002,
					Num = 1296,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101504,
					Value = -22,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id353] =
{
	Character = 223001,
	Rarity = 4,
	UpgradeId = 930033,
	LevelList = {
		{
			Level = 1,
			Info = 920569,
			Ability = {
				{
					Value = 200001,
					Num = 75,
				},
				{
					Value = 200007,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920569,
			Ability = {
				{
					Value = 200001,
					Num = 150,
				},
				{
					Value = 200007,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920569,
			Ability = {
				{
					Value = 200001,
					Num = 225,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920569,
			Ability = {
				{
					Value = 200001,
					Num = 300,
				},
				{
					Value = 200007,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920569,
			Ability = {
				{
					Value = 200001,
					Num = 375,
				},
				{
					Value = 200007,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920569,
			Ability = {
				{
					Value = 200001,
					Num = 450,
				},
				{
					Value = 200007,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920569,
			Ability = {
				{
					Value = 200001,
					Num = 525,
				},
				{
					Value = 200007,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920569,
			Ability = {
				{
					Value = 200001,
					Num = 600,
				},
				{
					Value = 200007,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
		{
			Level = 9,
			Info = 920569,
			Ability = {
				{
					Value = 200001,
					Num = 675,
				},
				{
					Value = 200007,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
		{
			Level = 10,
			Info = 920569,
			Ability = {
				{
					Value = 200001,
					Num = 750,
				},
				{
					Value = 200007,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id354] =
{
	Character = 223001,
	Rarity = 4,
	UpgradeId = 930034,
	LevelList = {
		{
			Level = 1,
			Info = 920570,
			Ability = {
				{
					Value = 200001,
					Num = 75,
				},
				{
					Value = 200006,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920570,
			Ability = {
				{
					Value = 200001,
					Num = 150,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920570,
			Ability = {
				{
					Value = 200001,
					Num = 225,
				},
				{
					Value = 200006,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920570,
			Ability = {
				{
					Value = 200001,
					Num = 300,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920570,
			Ability = {
				{
					Value = 200001,
					Num = 375,
				},
				{
					Value = 200006,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920570,
			Ability = {
				{
					Value = 200001,
					Num = 450,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920570,
			Ability = {
				{
					Value = 200001,
					Num = 525,
				},
				{
					Value = 200006,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920570,
			Ability = {
				{
					Value = 200001,
					Num = 600,
				},
				{
					Value = 200006,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 101764,
					Value = 12,
				},
			},
		},
		{
			Level = 9,
			Info = 920570,
			Ability = {
				{
					Value = 200001,
					Num = 675,
				},
				{
					Value = 200006,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 101764,
					Value = 12,
				},
			},
		},
		{
			Level = 10,
			Info = 920570,
			Ability = {
				{
					Value = 200001,
					Num = 750,
				},
				{
					Value = 200006,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 101764,
					Value = 12,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id355] =
{
	Character = 223001,
	Rarity = 4,
	NeedChallenge = 145141,
	UpgradeId = 930015,
	LevelList = {
		{
			Level = 1,
			Info = 920571,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
			},
		},
		{
			Level = 2,
			Info = 920571,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
			},
		},
		{
			Level = 3,
			Info = 920571,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
		},
		{
			Level = 4,
			Info = 920571,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
			},
		},
		{
			Level = 5,
			Info = 920571,
			Ability = {
				{
					Value = 200002,
					Num = 396,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920571,
			Ability = {
				{
					Value = 200002,
					Num = 468,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920571,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920571,
			Ability = {
				{
					Value = 200002,
					Num = 612,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100680,
					Value = 2,
				},
			},
		},
		{
			Level = 9,
			Info = 920571,
			Ability = {
				{
					Value = 200002,
					Num = 684,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100680,
					Value = 2,
				},
			},
		},
		{
			Level = 10,
			Info = 920571,
			Ability = {
				{
					Value = 200002,
					Num = 756,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100680,
					Value = 2,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id356] =
{
	Character = 223002,
	Rarity = 4,
	UpgradeId = 930013,
	LevelList = {
		{
			Level = 1,
			Info = 920572,
			Ability = {
				{
					Value = 200002,
					Num = 54,
				},
				{
					Value = 200007,
					Num = 21,
				},
			},
		},
		{
			Level = 2,
			Info = 920572,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
				{
					Value = 200007,
					Num = 42,
				},
			},
		},
		{
			Level = 3,
			Info = 920572,
			Ability = {
				{
					Value = 200002,
					Num = 162,
				},
				{
					Value = 200007,
					Num = 63,
				},
			},
		},
		{
			Level = 4,
			Info = 920572,
			Ability = {
				{
					Value = 200002,
					Num = 216,
				},
				{
					Value = 200007,
					Num = 84,
				},
			},
		},
		{
			Level = 5,
			Info = 920572,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
				{
					Value = 200007,
					Num = 105,
				},
			},
		},
		{
			Level = 6,
			Info = 920572,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
				{
					Value = 200007,
					Num = 126,
				},
			},
		},
		{
			Level = 7,
			Info = 920572,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200007,
					Num = 147,
				},
			},
		},
		{
			Level = 8,
			Info = 920572,
			Ability = {
				{
					Value = 200002,
					Num = 432,
				},
				{
					Value = 200007,
					Num = 168,
				},
			},
			SkillList = {
				{
					Id = 101703,
					Value = 300,
				},
			},
		},
		{
			Level = 9,
			Info = 920572,
			Ability = {
				{
					Value = 200002,
					Num = 486,
				},
				{
					Value = 200007,
					Num = 189,
				},
			},
			SkillList = {
				{
					Id = 101703,
					Value = 300,
				},
			},
		},
		{
			Level = 10,
			Info = 920572,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200007,
					Num = 210,
				},
			},
			SkillList = {
				{
					Id = 101703,
					Value = 300,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id357] =
{
	Character = 223002,
	Rarity = 4,
	UpgradeId = 930034,
	LevelList = {
		{
			Level = 1,
			Info = 920573,
			Ability = {
				{
					Value = 200001,
					Num = 72,
				},
				{
					Value = 200007,
					Num = 21,
				},
			},
		},
		{
			Level = 2,
			Info = 920573,
			Ability = {
				{
					Value = 200001,
					Num = 144,
				},
				{
					Value = 200007,
					Num = 42,
				},
			},
		},
		{
			Level = 3,
			Info = 920573,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200007,
					Num = 63,
				},
			},
		},
		{
			Level = 4,
			Info = 920573,
			Ability = {
				{
					Value = 200001,
					Num = 288,
				},
				{
					Value = 200007,
					Num = 84,
				},
			},
		},
		{
			Level = 5,
			Info = 920573,
			Ability = {
				{
					Value = 200001,
					Num = 360,
				},
				{
					Value = 200007,
					Num = 105,
				},
			},
		},
		{
			Level = 6,
			Info = 920573,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200007,
					Num = 126,
				},
			},
		},
		{
			Level = 7,
			Info = 920573,
			Ability = {
				{
					Value = 200001,
					Num = 504,
				},
				{
					Value = 200007,
					Num = 147,
				},
			},
		},
		{
			Level = 8,
			Info = 920573,
			Ability = {
				{
					Value = 200001,
					Num = 576,
				},
				{
					Value = 200007,
					Num = 168,
				},
			},
			SkillList = {
				{
					Id = 101722,
					Value = 378,
				},
			},
		},
		{
			Level = 9,
			Info = 920573,
			Ability = {
				{
					Value = 200001,
					Num = 648,
				},
				{
					Value = 200007,
					Num = 189,
				},
			},
			SkillList = {
				{
					Id = 101722,
					Value = 378,
				},
			},
		},
		{
			Level = 10,
			Info = 920573,
			Ability = {
				{
					Value = 200001,
					Num = 720,
				},
				{
					Value = 200007,
					Num = 210,
				},
			},
			SkillList = {
				{
					Id = 101722,
					Value = 378,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id358] =
{
	Character = 223002,
	Rarity = 4,
	NeedChallenge = 145142,
	UpgradeId = 930015,
	LevelList = {
		{
			Level = 1,
			Info = 920574,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
			},
		},
		{
			Level = 2,
			Info = 920574,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
			},
		},
		{
			Level = 3,
			Info = 920574,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
		},
		{
			Level = 4,
			Info = 920574,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
			},
		},
		{
			Level = 5,
			Info = 920574,
			Ability = {
				{
					Value = 200002,
					Num = 396,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920574,
			Ability = {
				{
					Value = 200002,
					Num = 468,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920574,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920574,
			Ability = {
				{
					Value = 200002,
					Num = 612,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101759,
					Value = 100,
				},
			},
		},
		{
			Level = 9,
			Info = 920574,
			Ability = {
				{
					Value = 200002,
					Num = 684,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101759,
					Value = 100,
				},
			},
		},
		{
			Level = 10,
			Info = 920574,
			Ability = {
				{
					Value = 200002,
					Num = 756,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101759,
					Value = 100,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id359] =
{
	Character = 223003,
	Rarity = 4,
	UpgradeId = 930013,
	LevelList = {
		{
			Level = 1,
			Info = 920575,
			Ability = {
				{
					Value = 200002,
					Num = 57,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920575,
			Ability = {
				{
					Value = 200002,
					Num = 114,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920575,
			Ability = {
				{
					Value = 200002,
					Num = 171,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920575,
			Ability = {
				{
					Value = 200002,
					Num = 228,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920575,
			Ability = {
				{
					Value = 200002,
					Num = 285,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920575,
			Ability = {
				{
					Value = 200002,
					Num = 342,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920575,
			Ability = {
				{
					Value = 200002,
					Num = 399,
				},
				{
					Value = 200005,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920575,
			Ability = {
				{
					Value = 200002,
					Num = 456,
				},
				{
					Value = 200005,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 101738,
					Value = 15,
				},
			},
		},
		{
			Level = 9,
			Info = 920575,
			Ability = {
				{
					Value = 200002,
					Num = 513,
				},
				{
					Value = 200005,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 101738,
					Value = 15,
				},
			},
		},
		{
			Level = 10,
			Info = 920575,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200005,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 101738,
					Value = 15,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id360] =
{
	Character = 223003,
	Rarity = 4,
	UpgradeId = 930034,
	LevelList = {
		{
			Level = 1,
			Info = 920576,
			Ability = {
				{
					Value = 200001,
					Num = 69,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920576,
			Ability = {
				{
					Value = 200001,
					Num = 138,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920576,
			Ability = {
				{
					Value = 200001,
					Num = 207,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920576,
			Ability = {
				{
					Value = 200001,
					Num = 276,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920576,
			Ability = {
				{
					Value = 200001,
					Num = 345,
				},
				{
					Value = 200008,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920576,
			Ability = {
				{
					Value = 200001,
					Num = 414,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920576,
			Ability = {
				{
					Value = 200001,
					Num = 483,
				},
				{
					Value = 200008,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920576,
			Ability = {
				{
					Value = 200001,
					Num = 552,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 101761,
					Value = 100,
				},
			},
		},
		{
			Level = 9,
			Info = 920576,
			Ability = {
				{
					Value = 200001,
					Num = 621,
				},
				{
					Value = 200008,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 101761,
					Value = 100,
				},
			},
		},
		{
			Level = 10,
			Info = 920576,
			Ability = {
				{
					Value = 200001,
					Num = 690,
				},
				{
					Value = 200008,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 101761,
					Value = 100,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id361] =
{
	Character = 223003,
	Rarity = 4,
	NeedChallenge = 145143,
	UpgradeId = 930035,
	LevelList = {
		{
			Level = 1,
			Info = 920577,
			Ability = {
				{
					Value = 200001,
					Num = 138,
				},
			},
		},
		{
			Level = 2,
			Info = 920577,
			Ability = {
				{
					Value = 200001,
					Num = 230,
				},
			},
		},
		{
			Level = 3,
			Info = 920577,
			Ability = {
				{
					Value = 200001,
					Num = 322,
				},
			},
		},
		{
			Level = 4,
			Info = 920577,
			Ability = {
				{
					Value = 200001,
					Num = 414,
				},
			},
		},
		{
			Level = 5,
			Info = 920577,
			Ability = {
				{
					Value = 200001,
					Num = 506,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920577,
			Ability = {
				{
					Value = 200001,
					Num = 598,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920577,
			Ability = {
				{
					Value = 200001,
					Num = 690,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920577,
			Ability = {
				{
					Value = 200001,
					Num = 782,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 7,
				},
			},
		},
		{
			Level = 9,
			Info = 920577,
			Ability = {
				{
					Value = 200001,
					Num = 874,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 7,
				},
			},
		},
		{
			Level = 10,
			Info = 920577,
			Ability = {
				{
					Value = 200001,
					Num = 966,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 7,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id362] =
{
	Character = 223004,
	Rarity = 4,
	UpgradeId = 930013,
	LevelList = {
		{
			Level = 1,
			Info = 920578,
			Ability = {
				{
					Value = 200002,
					Num = 57,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920578,
			Ability = {
				{
					Value = 200002,
					Num = 114,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920578,
			Ability = {
				{
					Value = 200002,
					Num = 171,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920578,
			Ability = {
				{
					Value = 200002,
					Num = 228,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920578,
			Ability = {
				{
					Value = 200002,
					Num = 285,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920578,
			Ability = {
				{
					Value = 200002,
					Num = 342,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920578,
			Ability = {
				{
					Value = 200002,
					Num = 399,
				},
				{
					Value = 200005,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920578,
			Ability = {
				{
					Value = 200002,
					Num = 456,
				},
				{
					Value = 200005,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100552,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920578,
			Ability = {
				{
					Value = 200002,
					Num = 513,
				},
				{
					Value = 200005,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100552,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920578,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200005,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100552,
					Value = 25,
				},
			},
		},
	},
}
