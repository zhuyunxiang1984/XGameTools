
EquipmentConfig[EquipmentID.Id151] =
{
	Character = 220131,
	Rarity = 5,
	NeedChallenge = 145061,
	UpgradeId = 930019,
	LevelList = {
		{
			Level = 1,
			Info = 920179,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
			},
		},
		{
			Level = 2,
			Info = 920179,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
			},
		},
		{
			Level = 3,
			Info = 920179,
			Ability = {
				{
					Value = 200002,
					Num = 294,
				},
			},
		},
		{
			Level = 4,
			Info = 920179,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
			},
		},
		{
			Level = 5,
			Info = 920179,
			Ability = {
				{
					Value = 200002,
					Num = 462,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920179,
			Ability = {
				{
					Value = 200002,
					Num = 546,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920179,
			Ability = {
				{
					Value = 200002,
					Num = 630,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920179,
			Ability = {
				{
					Value = 200002,
					Num = 714,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100747,
					Value = 2,
				},
			},
		},
		{
			Level = 9,
			Info = 920179,
			Ability = {
				{
					Value = 200002,
					Num = 798,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100747,
					Value = 2,
				},
			},
		},
		{
			Level = 10,
			Info = 920179,
			Ability = {
				{
					Value = 200002,
					Num = 882,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100747,
					Value = 2,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id152] =
{
	Character = 220131,
	Rarity = 5,
	NeedChallenge = 145062,
	UpgradeId = 930040,
	LevelList = {
		{
			Level = 1,
			Info = 920180,
			Ability = {
				{
					Value = 200001,
					Num = 261,
				},
			},
		},
		{
			Level = 2,
			Info = 920180,
			Ability = {
				{
					Value = 200001,
					Num = 406,
				},
			},
		},
		{
			Level = 3,
			Info = 920180,
			Ability = {
				{
					Value = 200001,
					Num = 551,
				},
			},
		},
		{
			Level = 4,
			Info = 920180,
			Ability = {
				{
					Value = 200001,
					Num = 696,
				},
			},
		},
		{
			Level = 5,
			Info = 920180,
			Ability = {
				{
					Value = 200001,
					Num = 841,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920180,
			Ability = {
				{
					Value = 200001,
					Num = 986,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920180,
			Ability = {
				{
					Value = 200001,
					Num = 1131,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920180,
			Ability = {
				{
					Value = 200001,
					Num = 1276,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101731,
					Value = 1080,
				},
			},
		},
		{
			Level = 9,
			Info = 920180,
			Ability = {
				{
					Value = 200001,
					Num = 1421,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101731,
					Value = 1080,
				},
			},
		},
		{
			Level = 10,
			Info = 920180,
			Ability = {
				{
					Value = 200001,
					Num = 1566,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101731,
					Value = 1080,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id153] =
{
	Character = 220201,
	Rarity = 3,
	UpgradeId = 930009,
	LevelList = {
		{
			Level = 1,
			Info = 920193,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200007,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920193,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920193,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200007,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920193,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920193,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200007,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920193,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920193,
			Ability = {
				{
					Value = 200002,
					Num = 294,
				},
				{
					Value = 200007,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920193,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
				{
					Value = 200007,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920193,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200007,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920193,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200007,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id154] =
{
	Character = 220201,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920194,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920194,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920194,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920194,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920194,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 101701,
					Value = 162,
				},
			},
		},
		{
			Level = 6,
			Info = 920194,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 101701,
					Value = 162,
				},
			},
		},
		{
			Level = 7,
			Info = 920194,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200006,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 101701,
					Value = 162,
				},
			},
		},
		{
			Level = 8,
			Info = 920194,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 101701,
					Value = 162,
				},
			},
		},
		{
			Level = 9,
			Info = 920194,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 101701,
					Value = 162,
				},
			},
		},
		{
			Level = 10,
			Info = 920194,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 101701,
					Value = 162,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id155] =
{
	Character = 220201,
	Rarity = 3,
	NeedChallenge = 145063,
	UpgradeId = 930031,
	LevelList = {
		{
			Level = 1,
			Info = 920195,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
			},
		},
		{
			Level = 2,
			Info = 920195,
			Ability = {
				{
					Value = 200001,
					Num = 180,
				},
			},
		},
		{
			Level = 3,
			Info = 920195,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
			},
		},
		{
			Level = 4,
			Info = 920195,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
			},
		},
		{
			Level = 5,
			Info = 920195,
			Ability = {
				{
					Value = 200001,
					Num = 396,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920195,
			Ability = {
				{
					Value = 200001,
					Num = 468,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920195,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920195,
			Ability = {
				{
					Value = 200001,
					Num = 612,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 12,
				},
			},
		},
		{
			Level = 9,
			Info = 920195,
			Ability = {
				{
					Value = 200001,
					Num = 684,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 12,
				},
			},
		},
		{
			Level = 10,
			Info = 920195,
			Ability = {
				{
					Value = 200001,
					Num = 756,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 12,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id156] =
{
	Character = 220202,
	Rarity = 3,
	UpgradeId = 930009,
	LevelList = {
		{
			Level = 1,
			Info = 920181,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920181,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920181,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920181,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920181,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200008,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920181,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920181,
			Ability = {
				{
					Value = 200002,
					Num = 294,
				},
				{
					Value = 200008,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920181,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920181,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200008,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920181,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200008,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id157] =
{
	Character = 220202,
	Rarity = 3,
	UpgradeId = 930010,
	LevelList = {
		{
			Level = 1,
			Info = 920182,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920182,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920182,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920182,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920182,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920182,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920182,
			Ability = {
				{
					Value = 200002,
					Num = 294,
				},
				{
					Value = 200005,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920182,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100748,
					Value = 2,
				},
			},
		},
		{
			Level = 9,
			Info = 920182,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100748,
					Value = 2,
				},
			},
		},
		{
			Level = 10,
			Info = 920182,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100748,
					Value = 2,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id158] =
{
	Character = 220202,
	Rarity = 3,
	NeedChallenge = 145064,
	UpgradeId = 930031,
	LevelList = {
		{
			Level = 1,
			Info = 920183,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
			},
		},
		{
			Level = 2,
			Info = 920183,
			Ability = {
				{
					Value = 200001,
					Num = 180,
				},
			},
		},
		{
			Level = 3,
			Info = 920183,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
			},
		},
		{
			Level = 4,
			Info = 920183,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
			},
		},
		{
			Level = 5,
			Info = 920183,
			Ability = {
				{
					Value = 200001,
					Num = 396,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920183,
			Ability = {
				{
					Value = 200001,
					Num = 468,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920183,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920183,
			Ability = {
				{
					Value = 200001,
					Num = 612,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 7,
				},
			},
		},
		{
			Level = 9,
			Info = 920183,
			Ability = {
				{
					Value = 200001,
					Num = 684,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 7,
				},
			},
		},
		{
			Level = 10,
			Info = 920183,
			Ability = {
				{
					Value = 200001,
					Num = 756,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 7,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id159] =
{
	Character = 220203,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920184,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200007,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920184,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920184,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200007,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920184,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920184,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200007,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920184,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920184,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200007,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920184,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200007,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 7,
				},
			},
		},
		{
			Level = 9,
			Info = 920184,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200007,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 7,
				},
			},
		},
		{
			Level = 10,
			Info = 920184,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200007,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 7,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id160] =
{
	Character = 220203,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920185,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920185,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920185,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920185,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920185,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100201,
					Value = 15,
				},
			},
		},
		{
			Level = 6,
			Info = 920185,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100201,
					Value = 15,
				},
			},
		},
		{
			Level = 7,
			Info = 920185,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200005,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100201,
					Value = 15,
				},
			},
		},
		{
			Level = 8,
			Info = 920185,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100201,
					Value = 15,
				},
			},
		},
		{
			Level = 9,
			Info = 920185,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100201,
					Value = 15,
				},
			},
		},
		{
			Level = 10,
			Info = 920185,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100201,
					Value = 15,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id161] =
{
	Character = 220203,
	Rarity = 3,
	NeedChallenge = 145065,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920186,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
			},
		},
		{
			Level = 2,
			Info = 920186,
			Ability = {
				{
					Value = 200002,
					Num = 140,
				},
			},
		},
		{
			Level = 3,
			Info = 920186,
			Ability = {
				{
					Value = 200002,
					Num = 196,
				},
			},
		},
		{
			Level = 4,
			Info = 920186,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
		},
		{
			Level = 5,
			Info = 920186,
			Ability = {
				{
					Value = 200002,
					Num = 308,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920186,
			Ability = {
				{
					Value = 200002,
					Num = 364,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920186,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920186,
			Ability = {
				{
					Value = 200002,
					Num = 476,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 7,
				},
			},
		},
		{
			Level = 9,
			Info = 920186,
			Ability = {
				{
					Value = 200002,
					Num = 532,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 7,
				},
			},
		},
		{
			Level = 10,
			Info = 920186,
			Ability = {
				{
					Value = 200002,
					Num = 588,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 7,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id162] =
{
	Character = 220204,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920187,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920187,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920187,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920187,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920187,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200008,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920187,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920187,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200008,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920187,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 7,
				},
			},
		},
		{
			Level = 9,
			Info = 920187,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200008,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 7,
				},
			},
		},
		{
			Level = 10,
			Info = 920187,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200008,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 7,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id163] =
{
	Character = 220204,
	Rarity = 3,
	UpgradeId = 930010,
	LevelList = {
		{
			Level = 1,
			Info = 920188,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920188,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920188,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920188,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920188,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100221,
					Value = 15,
				},
			},
		},
		{
			Level = 6,
			Info = 920188,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100221,
					Value = 15,
				},
			},
		},
		{
			Level = 7,
			Info = 920188,
			Ability = {
				{
					Value = 200002,
					Num = 294,
				},
				{
					Value = 200005,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100221,
					Value = 15,
				},
			},
		},
		{
			Level = 8,
			Info = 920188,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100221,
					Value = 15,
				},
			},
		},
		{
			Level = 9,
			Info = 920188,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100221,
					Value = 15,
				},
			},
		},
		{
			Level = 10,
			Info = 920188,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100221,
					Value = 15,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id164] =
{
	Character = 220204,
	Rarity = 3,
	NeedChallenge = 145066,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920189,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
			},
		},
		{
			Level = 2,
			Info = 920189,
			Ability = {
				{
					Value = 200002,
					Num = 140,
				},
			},
		},
		{
			Level = 3,
			Info = 920189,
			Ability = {
				{
					Value = 200002,
					Num = 196,
				},
			},
		},
		{
			Level = 4,
			Info = 920189,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
		},
		{
			Level = 5,
			Info = 920189,
			Ability = {
				{
					Value = 200002,
					Num = 308,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920189,
			Ability = {
				{
					Value = 200002,
					Num = 364,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920189,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920189,
			Ability = {
				{
					Value = 200002,
					Num = 476,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100605,
					Value = 36,
				},
			},
		},
		{
			Level = 9,
			Info = 920189,
			Ability = {
				{
					Value = 200002,
					Num = 532,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100605,
					Value = 36,
				},
			},
		},
		{
			Level = 10,
			Info = 920189,
			Ability = {
				{
					Value = 200002,
					Num = 588,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100605,
					Value = 36,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id165] =
{
	Character = 220205,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920190,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200006,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920190,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920190,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200006,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920190,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920190,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200006,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920190,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920190,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200006,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920190,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200006,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 7,
				},
			},
		},
		{
			Level = 9,
			Info = 920190,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200006,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 7,
				},
			},
		},
		{
			Level = 10,
			Info = 920190,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200006,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 101744,
					Value = 7,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id166] =
{
	Character = 220205,
	Rarity = 3,
	UpgradeId = 930010,
	LevelList = {
		{
			Level = 1,
			Info = 920191,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920191,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920191,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920191,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920191,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100015,
					Value = -15,
				},
			},
		},
		{
			Level = 6,
			Info = 920191,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100015,
					Value = -15,
				},
			},
		},
		{
			Level = 7,
			Info = 920191,
			Ability = {
				{
					Value = 200002,
					Num = 294,
				},
				{
					Value = 200005,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100015,
					Value = -15,
				},
			},
		},
		{
			Level = 8,
			Info = 920191,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100015,
					Value = -15,
				},
			},
		},
		{
			Level = 9,
			Info = 920191,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100015,
					Value = -15,
				},
			},
		},
		{
			Level = 10,
			Info = 920191,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100015,
					Value = -15,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id167] =
{
	Character = 220205,
	Rarity = 3,
	NeedChallenge = 145067,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920192,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
			},
		},
		{
			Level = 2,
			Info = 920192,
			Ability = {
				{
					Value = 200002,
					Num = 140,
				},
			},
		},
		{
			Level = 3,
			Info = 920192,
			Ability = {
				{
					Value = 200002,
					Num = 196,
				},
			},
		},
		{
			Level = 4,
			Info = 920192,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
		},
		{
			Level = 5,
			Info = 920192,
			Ability = {
				{
					Value = 200002,
					Num = 308,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920192,
			Ability = {
				{
					Value = 200002,
					Num = 364,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920192,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920192,
			Ability = {
				{
					Value = 200002,
					Num = 476,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101503,
					Value = -22,
				},
			},
		},
		{
			Level = 9,
			Info = 920192,
			Ability = {
				{
					Value = 200002,
					Num = 532,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101503,
					Value = -22,
				},
			},
		},
		{
			Level = 10,
			Info = 920192,
			Ability = {
				{
					Value = 200002,
					Num = 588,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101503,
					Value = -22,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id168] =
{
	Character = 220206,
	Rarity = 1,
	UpgradeId = 930021,
	LevelList = {
		{
			Level = 1,
			Info = 920196,
			Ability = {
				{
					Value = 200001,
					Num = 27,
				},
				{
					Value = 200006,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920196,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920196,
			Ability = {
				{
					Value = 200001,
					Num = 81,
				},
				{
					Value = 200006,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920196,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920196,
			Ability = {
				{
					Value = 200001,
					Num = 135,
				},
				{
					Value = 200006,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920196,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920196,
			Ability = {
				{
					Value = 200001,
					Num = 189,
				},
				{
					Value = 200006,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920196,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200006,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920196,
			Ability = {
				{
					Value = 200001,
					Num = 243,
				},
				{
					Value = 200006,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920196,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200006,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id169] =
{
	Character = 220206,
	Rarity = 1,
	NeedChallenge = 145068,
	UpgradeId = 930022,
	LevelList = {
		{
			Level = 1,
			Info = 920197,
			Ability = {
				{
					Value = 200001,
					Num = 27,
				},
			},
		},
		{
			Level = 2,
			Info = 920197,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
			},
		},
		{
			Level = 3,
			Info = 920197,
			Ability = {
				{
					Value = 200001,
					Num = 81,
				},
			},
		},
		{
			Level = 4,
			Info = 920197,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
			},
		},
		{
			Level = 5,
			Info = 920197,
			Ability = {
				{
					Value = 200001,
					Num = 135,
				},
			},
			SkillList = {
				{
					Id = 100653,
					Value = 36,
				},
			},
		},
		{
			Level = 6,
			Info = 920197,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
			},
			SkillList = {
				{
					Id = 100653,
					Value = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920197,
			Ability = {
				{
					Value = 200001,
					Num = 189,
				},
			},
			SkillList = {
				{
					Id = 100653,
					Value = 36,
				},
			},
		},
		{
			Level = 8,
			Info = 920197,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
			},
			SkillList = {
				{
					Id = 100653,
					Value = 36,
				},
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920197,
			Ability = {
				{
					Value = 200001,
					Num = 243,
				},
			},
			SkillList = {
				{
					Id = 100653,
					Value = 36,
				},
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920197,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
			},
			SkillList = {
				{
					Id = 100653,
					Value = 36,
				},
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id170] =
{
	Character = 220207,
	Rarity = 1,
	UpgradeId = 930021,
	LevelList = {
		{
			Level = 1,
			Info = 920198,
			Ability = {
				{
					Value = 200001,
					Num = 27,
				},
				{
					Value = 200007,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920198,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920198,
			Ability = {
				{
					Value = 200001,
					Num = 81,
				},
				{
					Value = 200007,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920198,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920198,
			Ability = {
				{
					Value = 200001,
					Num = 135,
				},
				{
					Value = 200007,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920198,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920198,
			Ability = {
				{
					Value = 200001,
					Num = 189,
				},
				{
					Value = 200007,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920198,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200007,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920198,
			Ability = {
				{
					Value = 200001,
					Num = 243,
				},
				{
					Value = 200007,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920198,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200007,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id171] =
{
	Character = 220207,
	Rarity = 1,
	NeedChallenge = 145069,
	UpgradeId = 930022,
	LevelList = {
		{
			Level = 1,
			Info = 920199,
			Ability = {
				{
					Value = 200001,
					Num = 27,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920199,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920199,
			Ability = {
				{
					Value = 200001,
					Num = 81,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920199,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920199,
			Ability = {
				{
					Value = 200001,
					Num = 135,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 101901,
					Value = 8,
				},
			},
		},
		{
			Level = 6,
			Info = 920199,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 101901,
					Value = 8,
				},
			},
		},
		{
			Level = 7,
			Info = 920199,
			Ability = {
				{
					Value = 200001,
					Num = 189,
				},
				{
					Value = 200006,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 101901,
					Value = 8,
				},
			},
		},
		{
			Level = 8,
			Info = 920199,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 101901,
					Value = 8,
				},
			},
		},
		{
			Level = 9,
			Info = 920199,
			Ability = {
				{
					Value = 200001,
					Num = 243,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 101901,
					Value = 8,
				},
			},
		},
		{
			Level = 10,
			Info = 920199,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 101901,
					Value = 8,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id172] =
{
	Character = 220208,
	Rarity = 1,
	UpgradeId = 930001,
	LevelList = {
		{
			Level = 1,
			Info = 920200,
			Ability = {
				{
					Value = 200002,
					Num = 21,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920200,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920200,
			Ability = {
				{
					Value = 200002,
					Num = 63,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920200,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920200,
			Ability = {
				{
					Value = 200002,
					Num = 105,
				},
				{
					Value = 200008,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920200,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920200,
			Ability = {
				{
					Value = 200002,
					Num = 147,
				},
				{
					Value = 200008,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920200,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920200,
			Ability = {
				{
					Value = 200002,
					Num = 189,
				},
				{
					Value = 200008,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920200,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200008,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id173] =
{
	Character = 220208,
	Rarity = 1,
	NeedChallenge = 145070,
	UpgradeId = 930002,
	LevelList = {
		{
			Level = 1,
			Info = 920201,
			Ability = {
				{
					Value = 200002,
					Num = 21,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920201,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920201,
			Ability = {
				{
					Value = 200002,
					Num = 63,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920201,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920201,
			Ability = {
				{
					Value = 200002,
					Num = 105,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 6,
			Info = 920201,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 7,
			Info = 920201,
			Ability = {
				{
					Value = 200002,
					Num = 147,
				},
				{
					Value = 200005,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 8,
			Info = 920201,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 9,
			Info = 920201,
			Ability = {
				{
					Value = 200002,
					Num = 189,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 10,
			Info = 920201,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id174] =
{
	Character = 220209,
	Rarity = 1,
	UpgradeId = 930021,
	LevelList = {
		{
			Level = 1,
			Info = 920202,
			Ability = {
				{
					Value = 200001,
					Num = 27,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920202,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920202,
			Ability = {
				{
					Value = 200001,
					Num = 81,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920202,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920202,
			Ability = {
				{
					Value = 200001,
					Num = 135,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920202,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920202,
			Ability = {
				{
					Value = 200001,
					Num = 189,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920202,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920202,
			Ability = {
				{
					Value = 200001,
					Num = 243,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920202,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id175] =
{
	Character = 220209,
	Rarity = 1,
	NeedChallenge = 145071,
	UpgradeId = 930002,
	LevelList = {
		{
			Level = 1,
			Info = 920203,
			Ability = {
				{
					Value = 200002,
					Num = 21,
				},
				{
					Value = 200007,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920203,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200007,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920203,
			Ability = {
				{
					Value = 200002,
					Num = 63,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920203,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200007,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920203,
			Ability = {
				{
					Value = 200002,
					Num = 105,
				},
				{
					Value = 200007,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100002,
					Value = -3,
				},
			},
		},
		{
			Level = 6,
			Info = 920203,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100002,
					Value = -3,
				},
			},
		},
		{
			Level = 7,
			Info = 920203,
			Ability = {
				{
					Value = 200002,
					Num = 147,
				},
				{
					Value = 200007,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100002,
					Value = -3,
				},
			},
		},
		{
			Level = 8,
			Info = 920203,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200007,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100002,
					Value = -3,
				},
			},
		},
		{
			Level = 9,
			Info = 920203,
			Ability = {
				{
					Value = 200002,
					Num = 189,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100002,
					Value = -3,
				},
			},
		},
		{
			Level = 10,
			Info = 920203,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200007,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100002,
					Value = -3,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id176] =
{
	Character = 220210,
	Rarity = 2,
	UpgradeId = 930025,
	LevelList = {
		{
			Level = 1,
			Info = 920204,
			Ability = {
				{
					Value = 200001,
					Num = 45,
				},
				{
					Value = 200007,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920204,
			Ability = {
				{
					Value = 200001,
					Num = 90,
				},
				{
					Value = 200007,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920204,
			Ability = {
				{
					Value = 200001,
					Num = 135,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920204,
			Ability = {
				{
					Value = 200001,
					Num = 180,
				},
				{
					Value = 200007,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920204,
			Ability = {
				{
					Value = 200001,
					Num = 225,
				},
				{
					Value = 200007,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920204,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920204,
			Ability = {
				{
					Value = 200001,
					Num = 315,
				},
				{
					Value = 200007,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920204,
			Ability = {
				{
					Value = 200001,
					Num = 360,
				},
				{
					Value = 200007,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920204,
			Ability = {
				{
					Value = 200001,
					Num = 405,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920204,
			Ability = {
				{
					Value = 200001,
					Num = 450,
				},
				{
					Value = 200007,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id177] =
{
	Character = 220210,
	Rarity = 2,
	NeedChallenge = 145072,
	UpgradeId = 930026,
	LevelList = {
		{
			Level = 1,
			Info = 920205,
			Ability = {
				{
					Value = 200001,
					Num = 45,
				},
				{
					Value = 200005,
					Num = 3,
				},
			},
		},
		{
			Level = 2,
			Info = 920205,
			Ability = {
				{
					Value = 200001,
					Num = 90,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 3,
			Info = 920205,
			Ability = {
				{
					Value = 200001,
					Num = 135,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 4,
			Info = 920205,
			Ability = {
				{
					Value = 200001,
					Num = 180,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 5,
			Info = 920205,
			Ability = {
				{
					Value = 200001,
					Num = 225,
				},
				{
					Value = 200005,
					Num = 15,
				},
			},
			SkillList = {
				{
					Id = 100666,
					Value = 3,
				},
			},
		},
		{
			Level = 6,
			Info = 920205,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
			SkillList = {
				{
					Id = 100666,
					Value = 3,
				},
			},
		},
		{
			Level = 7,
			Info = 920205,
			Ability = {
				{
					Value = 200001,
					Num = 315,
				},
				{
					Value = 200005,
					Num = 21,
				},
			},
			SkillList = {
				{
					Id = 100666,
					Value = 3,
				},
			},
		},
		{
			Level = 8,
			Info = 920205,
			Ability = {
				{
					Value = 200001,
					Num = 360,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
			SkillList = {
				{
					Id = 100666,
					Value = 3,
				},
			},
		},
		{
			Level = 9,
			Info = 920205,
			Ability = {
				{
					Value = 200001,
					Num = 405,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
			SkillList = {
				{
					Id = 100666,
					Value = 3,
				},
			},
		},
		{
			Level = 10,
			Info = 920205,
			Ability = {
				{
					Value = 200001,
					Num = 450,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100666,
					Value = 3,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id178] =
{
	Character = 220211,
	Rarity = 2,
	UpgradeId = 930025,
	LevelList = {
		{
			Level = 1,
			Info = 920206,
			Ability = {
				{
					Value = 200001,
					Num = 45,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920206,
			Ability = {
				{
					Value = 200001,
					Num = 90,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920206,
			Ability = {
				{
					Value = 200001,
					Num = 135,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920206,
			Ability = {
				{
					Value = 200001,
					Num = 180,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920206,
			Ability = {
				{
					Value = 200001,
					Num = 225,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920206,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920206,
			Ability = {
				{
					Value = 200001,
					Num = 315,
				},
				{
					Value = 200006,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920206,
			Ability = {
				{
					Value = 200001,
					Num = 360,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920206,
			Ability = {
				{
					Value = 200001,
					Num = 405,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920206,
			Ability = {
				{
					Value = 200001,
					Num = 450,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id179] =
{
	Character = 220211,
	Rarity = 2,
	NeedChallenge = 145073,
	UpgradeId = 930026,
	LevelList = {
		{
			Level = 1,
			Info = 920207,
			Ability = {
				{
					Value = 200001,
					Num = 45,
				},
				{
					Value = 200008,
					Num = 3,
				},
			},
		},
		{
			Level = 2,
			Info = 920207,
			Ability = {
				{
					Value = 200001,
					Num = 90,
				},
				{
					Value = 200008,
					Num = 6,
				},
			},
		},
		{
			Level = 3,
			Info = 920207,
			Ability = {
				{
					Value = 200001,
					Num = 135,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 4,
			Info = 920207,
			Ability = {
				{
					Value = 200001,
					Num = 180,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 5,
			Info = 920207,
			Ability = {
				{
					Value = 200001,
					Num = 225,
				},
				{
					Value = 200008,
					Num = 15,
				},
			},
			SkillList = {
				{
					Id = 100663,
					Value = 3,
				},
			},
		},
		{
			Level = 6,
			Info = 920207,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
			SkillList = {
				{
					Id = 100663,
					Value = 3,
				},
			},
		},
		{
			Level = 7,
			Info = 920207,
			Ability = {
				{
					Value = 200001,
					Num = 315,
				},
				{
					Value = 200008,
					Num = 21,
				},
			},
			SkillList = {
				{
					Id = 100663,
					Value = 3,
				},
			},
		},
		{
			Level = 8,
			Info = 920207,
			Ability = {
				{
					Value = 200001,
					Num = 360,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
			SkillList = {
				{
					Id = 100663,
					Value = 3,
				},
			},
		},
		{
			Level = 9,
			Info = 920207,
			Ability = {
				{
					Value = 200001,
					Num = 405,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
			SkillList = {
				{
					Id = 100663,
					Value = 3,
				},
			},
		},
		{
			Level = 10,
			Info = 920207,
			Ability = {
				{
					Value = 200001,
					Num = 450,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100663,
					Value = 3,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id180] =
{
	Character = 220212,
	Rarity = 2,
	UpgradeId = 930025,
	LevelList = {
		{
			Level = 1,
			Info = 920208,
			Ability = {
				{
					Value = 200001,
					Num = 42,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920208,
			Ability = {
				{
					Value = 200001,
					Num = 84,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920208,
			Ability = {
				{
					Value = 200001,
					Num = 126,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920208,
			Ability = {
				{
					Value = 200001,
					Num = 168,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920208,
			Ability = {
				{
					Value = 200001,
					Num = 210,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920208,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920208,
			Ability = {
				{
					Value = 200001,
					Num = 294,
				},
				{
					Value = 200006,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920208,
			Ability = {
				{
					Value = 200001,
					Num = 336,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920208,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920208,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
