ActivityExploreConfig ={};
ActivityExploreID = 
{
	Id001 = 630001,
	Id002 = 630002,
	Id003 = 630003,
	Id004 = 630004,
	Id005 = 630005,
	Id006 = 630006,
}
ActivityExploreConfig[ActivityExploreID.Id001] =
{
	Id = 1,
	Name = "步行街",
	NumCap = 5,
	LevelIcon = "Icon_2021SpringFestivalBG01",
	LevelBG = "2021SpringFestivalBG01",
	LevelAtlas = "EventThemeBG",
	LevelBundle = "packed_eventthemebg",
	StartScene = "ThemeExplore_StartScene",
	LevelEnemy = {
		{
			NeedActivityBattle = 18,
			Enemy = {
				{
					Value = 243004,
					Level = 70,
					Weight = 1129,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 2400,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 243005,
					Level = 80,
					Weight = 1129,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 2700,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 243006,
					Level = 90,
					Weight = 1935,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 3800,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 243007,
					Level = 94,
					Weight = 1935,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 3900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 243008,
					Level = 102,
					Weight = 1935,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 3600,
					FightPower = 4900,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 243009,
					Level = 110,
					Weight = 1935,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 3600,
					FightPower = 5300,
					NeedElementList = {
						{
							Element = 210004,
							Count = 1,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedActivityBattle = 14,
			Enemy = {
				{
					Value = 243004,
					Level = 70,
					Weight = 1129,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 2400,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 243005,
					Level = 80,
					Weight = 1129,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 2700,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 243006,
					Level = 90,
					Weight = 1935,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 3800,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 243007,
					Level = 94,
					Weight = 1935,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 3900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 243008,
					Level = 102,
					Weight = 1935,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 3600,
					FightPower = 4900,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedActivityBattle = 10,
			Enemy = {
				{
					Value = 243004,
					Level = 70,
					Weight = 1129,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 2400,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 243005,
					Level = 80,
					Weight = 1129,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 2700,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 243006,
					Level = 90,
					Weight = 1935,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 3800,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 243007,
					Level = 94,
					Weight = 1935,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 3900,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedActivityBattle = 6,
			Enemy = {
				{
					Value = 243004,
					Level = 70,
					Weight = 1129,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 2400,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 243005,
					Level = 80,
					Weight = 1129,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 2700,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 243006,
					Level = 90,
					Weight = 1935,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 3800,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedActivityBattle = 3,
			Enemy = {
				{
					Value = 243004,
					Level = 70,
					Weight = 1129,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 2400,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 243005,
					Level = 80,
					Weight = 1129,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 2700,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedActivityBattle = 0,
			Enemy = {
				{
					Value = 243004,
					Level = 70,
					Weight = 1129,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 2400,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
	},
}
ActivityExploreConfig[ActivityExploreID.Id002] =
{
	Id = 2,
	Name = "宝箱谷",
	NumCap = 5,
	LevelIcon = "Icon_StarAdventureBG01",
	LevelBG = "StarAdventureBG01",
	LevelAtlas = "EventThemeBG",
	LevelBundle = "packed_eventthemebg",
	StartScene = "ThemeExplore_StartScene",
	LevelEnemy = {
		{
			NeedActivityBattle = 8,
			Enemy = {
				{
					Value = 243010,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 2400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 243001,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 3000,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 243002,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 1800,
					FightPower = 3400,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 243011,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 1800,
					FightPower = 3400,
					NeedElementList = {
						{
							Element = 210004,
							Count = 2,
						},
					},
				},
				{
					Value = 243003,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 3600,
					FightPower = 3900,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 2,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedActivityBattle = 6,
			Enemy = {
				{
					Value = 243010,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 2400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 243001,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 3000,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 243002,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 1800,
					FightPower = 3400,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 243011,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 1800,
					FightPower = 3400,
					NeedElementList = {
						{
							Element = 210004,
							Count = 2,
						},
					},
				},
			},
		},
		{
			NeedActivityBattle = 4,
			Enemy = {
				{
					Value = 243010,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 2400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 243001,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 3000,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 243002,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 1800,
					FightPower = 3400,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedActivityBattle = 2,
			Enemy = {
				{
					Value = 243010,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 2400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
				{
					Value = 243001,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 3000,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedActivityBattle = 0,
			Enemy = {
				{
					Value = 243010,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 2400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210002,
							Count = 1,
						},
					},
				},
			},
		},
	},
}
ActivityExploreConfig[ActivityExploreID.Id003] =
{
	Id = 3,
	Name = "小吃街",
	NumCap = 5,
	LevelIcon = "Icon_DarkFoodFestivalBG01",
	LevelBG = "DarkFoodFestivalBG01",
	LevelAtlas = "EventThemeBG",
	LevelBundle = "packed_eventthemebg",
	StartScene = "ThemeExplore_StartScene",
	LevelEnemy = {
		{
			NeedActivityBattle = 8,
			Enemy = {
				{
					Value = 243012,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 2400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 243013,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 3000,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 243014,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 3000,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 243015,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 1800,
					FightPower = 3400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 2,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 243016,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 3600,
					FightPower = 3900,
					NeedElementList = {
						{
							Element = 210001,
							Count = 2,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedActivityBattle = 6,
			Enemy = {
				{
					Value = 243012,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 2400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 243013,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 3000,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 243014,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 3000,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 243015,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 1800,
					FightPower = 3400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 2,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedActivityBattle = 4,
			Enemy = {
				{
					Value = 243012,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 2400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 243013,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 3000,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 243014,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 3000,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedActivityBattle = 2,
			Enemy = {
				{
					Value = 243012,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 2400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 243013,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 3000,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedActivityBattle = 0,
			Enemy = {
				{
					Value = 243012,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 2400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
			},
		},
	},
}
ActivityExploreConfig[ActivityExploreID.Id004] =
{
	Id = 4,
	Name = "步行街",
	NumCap = 5,
	LevelIcon = "Icon_DragonBoatFestivalBG01",
	LevelBG = "DragonBoatFestivalBG01",
	LevelAtlas = "EventThemeBG",
	LevelBundle = "packed_eventthemebg",
	StartScene = "ThemeExplore_StartScene",
	LevelEnemy = {
		{
			NeedActivityBattle = 8,
			Enemy = {
				{
					Value = 243017,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 2400,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 243018,
					Level = 80,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 3400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 243019,
					Level = 90,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 3800,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 243020,
					Level = 94,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 1800,
					FightPower = 4500,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 243021,
					Level = 102,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 3600,
					FightPower = 5500,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
			},
		},
		{
			NeedActivityBattle = 6,
			Enemy = {
				{
					Value = 243017,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 2400,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 243018,
					Level = 80,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 3400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 243019,
					Level = 90,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 3800,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 243020,
					Level = 94,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 1800,
					FightPower = 4500,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedActivityBattle = 4,
			Enemy = {
				{
					Value = 243017,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 2400,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 243018,
					Level = 80,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 3400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 243019,
					Level = 90,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 3800,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedActivityBattle = 2,
			Enemy = {
				{
					Value = 243017,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 2400,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 243018,
					Level = 80,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 3400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedActivityBattle = 0,
			Enemy = {
				{
					Value = 243017,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 2400,
					NeedElementList = {
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
	},
}
ActivityExploreConfig[ActivityExploreID.Id005] =
{
	Id = 5,
	Name = "庙会街",
	NumCap = 5,
	LevelIcon = "Icon_TempleFairFestivalBG01",
	LevelBG = "TempleFairFestivalBG01",
	LevelAtlas = "EventThemeBG",
	LevelBundle = "packed_eventthemebg",
	StartScene = "ThemeExplore_StartScene",
	LevelEnemy = {
		{
			NeedActivityBattle = 8,
			Enemy = {
				{
					Value = 243022,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 2400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 243023,
					Level = 80,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 3400,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
				{
					Value = 243024,
					Level = 90,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 3800,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 243025,
					Level = 94,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 1800,
					FightPower = 4500,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 243026,
					Level = 102,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 3600,
					FightPower = 5500,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedActivityBattle = 6,
			Enemy = {
				{
					Value = 243022,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 2400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 243023,
					Level = 80,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 3400,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
				{
					Value = 243024,
					Level = 90,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 3800,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 243025,
					Level = 94,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 1800,
					FightPower = 4500,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedActivityBattle = 4,
			Enemy = {
				{
					Value = 243022,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 2400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 243023,
					Level = 80,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 3400,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
				{
					Value = 243024,
					Level = 90,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 3800,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedActivityBattle = 2,
			Enemy = {
				{
					Value = 243022,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 2400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 243023,
					Level = 80,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 3400,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
			},
		},
		{
			NeedActivityBattle = 0,
			Enemy = {
				{
					Value = 243022,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 2400,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
	},
}
ActivityExploreConfig[ActivityExploreID.Id006] =
{
	Id = 6,
	Name = "温泉别墅",
	NumCap = 5,
	LevelIcon = "Icon_WinterFestivalBG01",
	LevelBG = "WinterFestivalBG01",
	LevelAtlas = "EventThemeBG",
	LevelBundle = "packed_eventthemebg",
	StartScene = "ThemeExplore_StartScene",
	LevelEnemy = {
		{
			NeedActivityBattle = 8,
			Enemy = {
				{
					Value = 243027,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 3000,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 243028,
					Level = 80,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 3400,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
				{
					Value = 243029,
					Level = 90,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 4300,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 243030,
					Level = 94,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 1800,
					FightPower = 4500,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
				{
					Value = 243031,
					Level = 102,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 3600,
					FightPower = 5500,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedActivityBattle = 6,
			Enemy = {
				{
					Value = 243027,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 3000,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 243028,
					Level = 80,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 3400,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
				{
					Value = 243029,
					Level = 90,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 4300,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
				{
					Value = 243030,
					Level = 94,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 1800,
					FightPower = 4500,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
						{
							Element = 210005,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedActivityBattle = 4,
			Enemy = {
				{
					Value = 243027,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 3000,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 243028,
					Level = 80,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 3400,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
				{
					Value = 243029,
					Level = 90,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 4300,
					NeedElementList = {
						{
							Element = 210002,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
						{
							Element = 210004,
							Count = 1,
						},
					},
				},
			},
		},
		{
			NeedActivityBattle = 2,
			Enemy = {
				{
					Value = 243027,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 3000,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
				{
					Value = 243028,
					Level = 80,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 900,
					FightPower = 3400,
					NeedElementList = {
						{
							Element = 210003,
							Count = 2,
						},
					},
				},
			},
		},
		{
			NeedActivityBattle = 0,
			Enemy = {
				{
					Value = 243027,
					Level = 70,
					Weight = 2000,
					WeightMin = 100,
					WeightMax = 100,
					TimeCost = 300,
					FightPower = 3000,
					NeedElementList = {
						{
							Element = 210001,
							Count = 1,
						},
						{
							Element = 210003,
							Count = 1,
						},
					},
				},
			},
		},
	},
}

