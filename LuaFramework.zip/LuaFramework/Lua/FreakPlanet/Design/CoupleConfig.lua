CoupleConfig ={};
CoupleID = 
{
	Id001 = 260001,
	Id002 = 260002,
	Id003 = 260003,
	Id004 = 260004,
	Id005 = 260005,
	Id006 = 260006,
	Id007 = 260007,
	Id008 = 260008,
	Id009 = 260009,
	Id010 = 260010,
	Id011 = 260011,
	Id012 = 260012,
	Id013 = 260013,
	Id014 = 260014,
	Id015 = 260015,
	Id016 = 260016,
	Id017 = 260017,
	Id018 = 260018,
	Id019 = 260019,
	Id020 = 260020,
	Id021 = 260021,
	Id022 = 260022,
	Id023 = 260023,
	Id024 = 260024,
	Id025 = 260025,
	Id026 = 260026,
	Id027 = 260027,
	Id028 = 260028,
	Id029 = 260029,
	Id030 = 260030,
	Id031 = 260031,
	Id032 = 260032,
	Id033 = 260033,
	Id034 = 260034,
	Id035 = 260035,
	Id036 = 260036,
	Id037 = 260037,
	Id038 = 260038,
	Id039 = 260039,
	Id040 = 260040,
	Id041 = 260041,
	Id042 = 260042,
	Id043 = 260043,
	Id044 = 260044,
	Id045 = 260045,
	Id046 = 260046,
	Id047 = 260047,
	Id048 = 260048,
	Id049 = 260049,
	Id050 = 260050,
	Id051 = 260051,
	Id052 = 260052,
	Id053 = 260053,
	Id054 = 260054,
	Id055 = 260055,
	Id056 = 260056,
	Id057 = 260057,
	Id058 = 260058,
	Id059 = 260059,
	Id060 = 260060,
	Id061 = 260061,
	Id062 = 260062,
	Id063 = 260063,
	Id064 = 260064,
	Id065 = 260065,
	Id066 = 260066,
	Id067 = 260067,
	Id068 = 260068,
	Id069 = 260069,
	Id070 = 260070,
	Id071 = 260071,
}
CoupleConfig[CoupleID.Id001] =
{
	Id = 1,
	Name = "小猫探险队",
	Gallery = 950101,
	PrefabBundle = "couple",
	PrefabName = "Couple_ALL_1",
	Desc = "需要2阶冒险家呜呜(呜呜皮肤)，2阶冒险家漆漆(漆漆皮肤)",
	TypeNode = {
		Explore = "SkillType_Explore",
	},
	SkillList = {
		Desc = "探索等待时间 -{Value1}%",
		Skill = {
			{
				Id = 107001,
				Value = -12,
			},
		},
	},
	CharacterList = {
		{
			Id = 220001,
			SkinId = 232001,
			Stage = 2,
		},
		{
			Id = 220002,
			SkinId = 232002,
			Stage = 2,
		},
	},
}
CoupleConfig[CoupleID.Id002] =
{
	Id = 2,
	Name = "小猫夏令营",
	Gallery = 950101,
	PrefabBundle = "couple",
	PrefabName = "Couple_ALL_11",
	Desc = "需要2阶泳装呜呜(呜呜皮肤)，2阶泳装漆漆(漆漆皮肤)",
	TypeNode = {
		Explore = "SkillType_Explore",
	},
	SkillList = {
		Desc = "探索等待时间 -{Value1}%",
		Skill = {
			{
				Id = 107100,
				Value = -12,
			},
		},
	},
	CharacterList = {
		{
			Id = 220001,
			SkinId = 232259,
			Stage = 2,
		},
		{
			Id = 220002,
			SkinId = 232260,
			Stage = 2,
		},
	},
}
CoupleConfig[CoupleID.Id003] =
{
	Id = 3,
	Name = "不给糖就捣蛋",
	Gallery = 950101,
	PrefabBundle = "couple",
	PrefabName = "Couple_ALL_13",
	Desc = "需要2阶魔法呜呜(呜呜皮肤)，2阶南瓜漆漆(漆漆皮肤)",
	TypeNode = {
		Explore = "SkillType_Explore",
	},
	SkillList = {
		Desc = "探索等待时间 -{Value1}%",
		Skill = {
			{
				Id = 107103,
				Value = -12,
			},
		},
	},
	CharacterList = {
		{
			Id = 220001,
			SkinId = 232313,
			Stage = 2,
		},
		{
			Id = 220002,
			SkinId = 232314,
			Stage = 2,
		},
	},
}
CoupleConfig[CoupleID.Id004] =
{
	Id = 4,
	Name = "海边度假",
	Gallery = 950101,
	PrefabBundle = "couple",
	PrefabName = "Couple_ALL_2",
	Desc = "需要潜水高手(美术妹子皮肤)，泳装小泪(小泪皮肤)，泳装小瞳(小瞳皮肤)，泳装小爱(小爱皮肤)",
	TypeNode = {
		Challenge = "SkillType_Challenge",
	},
	SkillList = {
		Desc = "水元素敌人生命 -{Value1}%",
		Skill = {
			{
				Id = 107002,
				Value = -45,
			},
		},
	},
	CharacterList = {
		{
			Id = 220025,
			SkinId = 232028,
		},
		{
			Id = 220306,
			SkinId = 232124,
		},
		{
			Id = 220307,
			SkinId = 232125,
		},
		{
			Id = 220308,
			SkinId = 232126,
		},
	},
}
CoupleConfig[CoupleID.Id005] =
{
	Id = 5,
	Name = "权利巅峰",
	Gallery = 950101,
	PrefabBundle = "couple",
	PrefabName = "Couple_ALL_3",
	Desc = "需要女王登基(女王大人皮肤)，皇帝加冕(名人蜡像皮肤)",
	TypeNode = {
		Challenge = "SkillType_Challenge",
	},
	SkillList = {
		Desc = "敌人等级 -{Value1}",
		Skill = {
			{
				Id = 107003,
				Value = -40,
			},
		},
	},
	CharacterList = {
		{
			Id = 220028,
			SkinId = 232035,
		},
		{
			Id = 220229,
			SkinId = 232116,
		},
	},
}
CoupleConfig[CoupleID.Id006] =
{
	Id = 6,
	Name = "名刀与宝甲",
	Gallery = 950101,
	PrefabBundle = "couple",
	PrefabName = "Couple_ALL_4",
	Desc = "需要麒麟天装(龙骑士皮肤)，战国の青雷(武士皮肤)",
	TypeNode = {
		Challenge = "SkillType_Challenge",
		Explore = "SkillType_Explore",
	},
	SkillList = {
		Desc = "全队暴击 +{Value1}，全队忍耐 +{Value2}",
		Skill = {
			{
				Id = 107004,
				Value = 60,
			},
			{
				Id = 107005,
				Value = 60,
			},
		},
	},
	CharacterList = {
		{
			Id = 220026,
			SkinId = 232030,
		},
		{
			Id = 220228,
			SkinId = 232113,
		},
	},
}
CoupleConfig[CoupleID.Id007] =
{
	Id = 7,
	Name = "上四仙",
	Gallery = 950101,
	PrefabBundle = "couple",
	PrefabName = "Couple_ALL_5",
	Desc = "需要吕洞宾，铁拐李，汉钟离，张果老",
	TypeNode = {
		Challenge = "SkillType_Challenge",
	},
	SkillList = {
		Desc = "3回合后，每回合全队回血 {Value1}，最多5次",
		Skill = {
			{
				Id = 107006,
				Value = 1000,
			},
		},
	},
	CharacterList = {
		{
			Id = 223024,
		},
		{
			Id = 223021,
		},
		{
			Id = 223022,
		},
		{
			Id = 223023,
		},
	},
}
CoupleConfig[CoupleID.Id008] =
{
	Id = 8,
	Name = "下四仙",
	Gallery = 950101,
	PrefabBundle = "couple",
	PrefabName = "Couple_ALL_6",
	Desc = "需要曹国舅，韩湘子，蓝采和，何仙姑",
	TypeNode = {
		Challenge = "SkillType_Challenge",
		Explore = "SkillType_Explore",
	},
	SkillList = {
		Desc = "全队生命 +{Value1}",
		Skill = {
			{
				Id = 107007,
				Value = 960,
			},
		},
	},
	CharacterList = {
		{
			Id = 223028,
		},
		{
			Id = 223027,
		},
		{
			Id = 223026,
		},
		{
			Id = 223025,
		},
	},
}
CoupleConfig[CoupleID.Id009] =
{
	Id = 9,
	Name = "皇室游戏·苍白",
	Gallery = 950101,
	PrefabBundle = "couple",
	PrefabName = "Couple_ALL_7",
	Desc = "需要白国王，白皇后，白卫兵",
	TypeNode = {
		Challenge = "SkillType_Challenge",
		Explore = "SkillType_Explore",
	},
	SkillList = {
		Desc = "光元素队员生命 +{Value1}",
		Skill = {
			{
				Id = 107008,
				Value = 1000,
			},
		},
	},
	CharacterList = {
		{
			Id = 223041,
		},
		{
			Id = 223042,
		},
		{
			Id = 223046,
		},
	},
}
CoupleConfig[CoupleID.Id010] =
{
	Id = 10,
	Name = "属臣较量·苍白",
	Gallery = 950101,
	PrefabBundle = "couple",
	PrefabName = "Couple_ALL_8",
	Desc = "需要白主教，白城堡，白骑士",
	TypeNode = {
		Challenge = "SkillType_Challenge",
		Explore = "SkillType_Explore",
	},
	SkillList = {
		Desc = "光元素队员攻击 +{Value1}",
		Skill = {
			{
				Id = 107009,
				Value = 1000,
			},
		},
	},
	CharacterList = {
		{
			Id = 223043,
		},
		{
			Id = 223044,
		},
		{
			Id = 223045,
		},
	},
}
CoupleConfig[CoupleID.Id011] =
{
	Id = 11,
	Name = "临时冒险组",
	Gallery = 950001,
	PrefabBundle = "couple",
	PrefabName = "Couple_RPG_1",
	Desc = "需要10级剑士，10级弓箭手，10级魔法师",
	TypeNode = {
		Explore = "SkillType_Explore",
	},
	SkillList = {
		Desc = "冒险星敌人道具掉落率 +{Value1}%",
		Skill = {
			{
				Id = 107010,
				Value = 40,
			},
		},
	},
	CharacterList = {
		{
			Id = 220003,
			Level = 10,
		},
		{
			Id = 220004,
			Level = 10,
		},
		{
			Id = 220010,
			Level = 10,
		},
	},
}
CoupleConfig[CoupleID.Id012] =
{
	Id = 12,
	Name = "经典冒险组",
	Gallery = 950001,
	PrefabBundle = "couple",
	PrefabName = "Couple_RPG_2",
	Desc = "需要剑士，弓箭手，魔法师，牧师，刺客",
	TypeNode = {
		Challenge = "SkillType_Challenge",
		Explore = "SkillType_Explore",
	},
	SkillList = {
		Desc = "全队男队员生命 +{Value1}，女队员攻击 +{Value2}",
		Skill = {
			{
				Id = 107011,
				Value = 640,
			},
			{
				Id = 107012,
				Value = 640,
			},
		},
	},
	CharacterList = {
		{
			Id = 220003,
		},
		{
			Id = 220004,
		},
		{
			Id = 220010,
		},
		{
			Id = 220021,
		},
		{
			Id = 220020,
		},
	},
}
CoupleConfig[CoupleID.Id013] =
{
	Id = 13,
	Name = "小镇共济会",
	Gallery = 950001,
	PrefabBundle = "couple",
	PrefabName = "Couple_RPG_3",
	Desc = "需要居民NPC，铁匠，旅行商人，指路NPC",
	TypeNode = {
		Explore = "SkillType_Explore",
	},
	SkillList = {
		Desc = "全队战力 +{Value1}%，探索金币数量 +{Value2}%",
		Skill = {
			{
				Id = 107013,
				Value = 100,
			},
			{
				Id = 107014,
				Value = 50,
			},
		},
	},
	CharacterList = {
		{
			Id = 220011,
		},
		{
			Id = 220008,
		},
		{
			Id = 220015,
		},
		{
			Id = 220007,
		},
	},
}
CoupleConfig[CoupleID.Id014] =
{
	Id = 14,
	Name = "魔族的进攻",
	Gallery = 950001,
	PrefabBundle = "couple",
	PrefabName = "Couple_RPG_4",
	Desc = "需要骨头兵，小队长，小魔王，大魔王",
	TypeNode = {
		Challenge = "SkillType_Challenge",
	},
	SkillList = {
		Desc = "全队对光元素敌人伤害 +{Value1}%，受光元素敌人伤害 -{Value2}%",
		Skill = {
			{
				Id = 107015,
				Value = 50,
			},
			{
				Id = 107016,
				Value = -25,
			},
		},
	},
	CharacterList = {
		{
			Id = 220006,
		},
		{
			Id = 220016,
		},
		{
			Id = 220009,
		},
		{
			Id = 220029,
		},
	},
}
CoupleConfig[CoupleID.Id015] =
{
	Id = 15,
	Name = "夕阳红",
	Gallery = 950001,
	PrefabBundle = "couple",
	PrefabName = "Couple_RPG_5",
	Desc = "需要10级村长，10级村长夫人",
	TypeNode = {
		Challenge = "SkillType_Challenge",
		Explore = "SkillType_Explore",
		WorkShop = "SkillType_Workshop",
	},
	SkillList = {
		Desc = "全队生命 +{Value1}，亲和 +{Value2}",
		Skill = {
			{
				Id = 107017,
				Value = 320,
			},
			{
				Id = 107018,
				Value = 20,
			},
		},
	},
	CharacterList = {
		{
			Id = 220012,
			Level = 10,
		},
		{
			Id = 220013,
			Level = 10,
		},
	},
}
CoupleConfig[CoupleID.Id016] =
{
	Id = 16,
	Name = "贴身保护",
	Gallery = 950001,
	PrefabBundle = "couple",
	PrefabName = "Couple_RPG_6",
	Desc = "需要女王大人，皇家卫兵(城镇卫兵皮肤)",
	TypeNode = {
		Challenge = "SkillType_Challenge",
		Explore = "SkillType_Explore",
	},
	SkillList = {
		Desc = "女王大人受到的暴击伤害 -{Value1}%，城镇卫兵忍耐 +{Value2}",
		Skill = {
			{
				Id = 107019,
				Value = -50,
			},
			{
				Id = 107020,
				Value = 100,
			},
		},
	},
	CharacterList = {
		{
			Id = 220028,
		},
		{
			Id = 220014,
			SkinId = 232015,
		},
	},
}
CoupleConfig[CoupleID.Id017] =
{
	Id = 17,
	Name = "制作组",
	Gallery = 950001,
	PrefabBundle = "couple",
	PrefabName = "Couple_RPG_7",
	Desc = "需要除虫者，动画师，配音演员，程序猿，美术妹子",
	TypeNode = {
		Explore = "SkillType_Explore",
	},
	SkillList = {
		Desc = "打不过的怪物出现概率 -{Value1}%",
		Skill = {
			{
				Id = 107021,
				Value = -60,
			},
		},
	},
	CharacterList = {
		{
			Id = 220017,
		},
		{
			Id = 220022,
		},
		{
			Id = 220023,
		},
		{
			Id = 220024,
		},
		{
			Id = 220025,
		},
	},
}
CoupleConfig[CoupleID.Id018] =
{
	Id = 18,
	Name = "英雄与恶龙",
	Gallery = 950001,
	PrefabBundle = "couple",
	PrefabName = "Couple_RPG_8",
	Desc = "需要龙骑士，黑龙王子",
	TypeNode = {
		Challenge = "SkillType_Challenge",
	},
	SkillList = {
		Desc = "敌人暴击 -{Value1}",
		Skill = {
			{
				Id = 107022,
				Value = -60,
			},
		},
	},
	CharacterList = {
		{
			Id = 220026,
		},
		{
			Id = 220027,
		},
	},
}
CoupleConfig[CoupleID.Id019] =
{
	Id = 19,
	Name = "异形入侵",
	Gallery = 950001,
	PrefabBundle = "couple",
	PrefabName = "Couple_RPG_9",
	Desc = "需要异形(异虫霸格皮肤)，雷普利(除虫者皮肤)",
	TypeNode = {
		Challenge = "SkillType_Challenge",
	},
	SkillList = {
		Desc = "3回合后，每回合全队攻击 +{Value1}，最多5次",
		Skill = {
			{
				Id = 107023,
				Value = 600,
			},
		},
	},
	CharacterList = {
		{
			Id = 220018,
			SkinId = 232019,
		},
		{
			Id = 220017,
			SkinId = 232018,
		},
	},
}
CoupleConfig[CoupleID.Id020] =
{
	Id = 20,
	Name = "致敬名作",
	Gallery = 950001,
	PrefabBundle = "couple",
	PrefabName = "Couple_RPG_10",
	Desc = "需要西部大镖客(火枪手皮肤)，猎魔人(猎人皮肤)，假林克(剑士皮肤)",
	TypeNode = {
		Explore = "SkillType_Explore",
	},
	SkillList = {
		Desc = "金色及以上品质敌人出现概率 +{Value1}%",
		Skill = {
			{
				Id = 107024,
				Value = 60,
			},
		},
	},
	CharacterList = {
		{
			Id = 220019,
			SkinId = 232020,
		},
		{
			Id = 220005,
			SkinId = 232005,
		},
		{
			Id = 220003,
			SkinId = 232003,
		},
	},
}
CoupleConfig[CoupleID.Id021] =
{
	Id = 21,
	Name = "地城冒险家",
	Gallery = 950001,
	PrefabBundle = "couple",
	PrefabName = "Couple_RPG_11",
	Desc = "需要圣骑士，野蛮人，盗贼",
	TypeNode = {
		Challenge = "SkillType_Challenge",
	},
	SkillList = {
		Desc = "每回合全队攻击 +{Value1}，最多5次",
		Skill = {
			{
				Id = 107025,
				Value = 600,
			},
		},
	},
	CharacterList = {
		{
			Id = 223001,
		},
		{
			Id = 223002,
		},
		{
			Id = 223003,
		},
	},
}
CoupleConfig[CoupleID.Id022] =
{
	Id = 22,
	Name = "异界冒险家",
	Gallery = 950001,
	PrefabBundle = "couple",
	PrefabName = "Couple_RPG_12",
	Desc = "需要舞娘，学者，药师",
	TypeNode = {
		Challenge = "SkillType_Challenge",
	},
	SkillList = {
		Desc = "每回合全队回血 {Value1}，最多5次",
		Skill = {
			{
				Id = 107026,
				Value = 750,
			},
		},
	},
	CharacterList = {
		{
			Id = 223004,
		},
		{
			Id = 223005,
		},
		{
			Id = 223006,
		},
	},
}
CoupleConfig[CoupleID.Id023] =
{
	Id = 23,
	Name = "今天摸鱼吧",
	Gallery = 950001,
	PrefabBundle = "couple",
	PrefabName = "Couple_RPG_14",
	Desc = "需要魔界至尊(小魔王皮肤)，西域牧师(牧师皮肤)",
	TypeNode = {
		Explore = "SkillType_Explore",
	},
	SkillList = {
		Desc = "活动探索中，紫色品质敌人捕捉成功率 +{Value1}%",
		Skill = {
			{
				Id = 107102,
				Value = 50,
			},
		},
	},
	CharacterList = {
		{
			Id = 220009,
			SkinId = 232275,
		},
		{
			Id = 220021,
			SkinId = 232273,
		},
	},
}
CoupleConfig[CoupleID.Id024] =
{
	Id = 24,
	Name = "豪华车队",
	Gallery = 950002,
	PrefabBundle = "couple",
	PrefabName = "Couple_FAT_1",
	Desc = "需要奶茶王子，汽水王子，可乐王子，啤酒王子",
	TypeNode = {
		Explore = "SkillType_Explore",
	},
	SkillList = {
		Desc = "道具掉落率 +{Value1}%，无法获得金币",
		Skill = {
			{
				Id = 107027,
				Value = 100,
			},
			{
				Id = 107028,
				Value = -100,
			},
		},
	},
	CharacterList = {
		{
			Id = 220101,
		},
		{
			Id = 220102,
		},
		{
			Id = 220103,
		},
		{
			Id = 220104,
		},
	},
}
CoupleConfig[CoupleID.Id025] =
{
	Id = 25,
	Name = "公主联盟",
	Gallery = 950002,
	PrefabBundle = "couple",
	PrefabName = "Couple_FAT_2",
	Desc = "需要冰淇淋公主，蛋糕卷公主，栗子蛋糕公主，棉花糖公主",
	TypeNode = {
		Challenge = "SkillType_Challenge",
		Explore = "SkillType_Explore",
		WorkShop = "SkillType_Workshop",
	},
	SkillList = {
		Desc = "全队男队员所有属性 +{Value1}%",
		Skill = {
			{
				Id = 107029,
				Value = 50,
			},
			{
				Id = 107030,
				Value = 50,
			},
			{
				Id = 107031,
				Value = 50,
			},
			{
				Id = 107032,
				Value = 50,
			},
			{
				Id = 107033,
				Value = 50,
			},
			{
				Id = 107034,
				Value = 50,
			},
			{
				Id = 107035,
				Value = 50,
			},
			{
				Id = 107036,
				Value = 50,
			},
		},
	},
	CharacterList = {
		{
			Id = 220123,
		},
		{
			Id = 220124,
		},
		{
			Id = 220125,
		},
		{
			Id = 220122,
		},
	},
}
CoupleConfig[CoupleID.Id026] =
{
	Id = 26,
	Name = "看，彩虹！",
	Gallery = 950002,
	PrefabBundle = "couple",
	PrefabName = "Couple_FAT_3",
	Desc = "需要小红，小橙，小黄，小绿，小青，小蓝，小紫",
	TypeNode = {
		WorkShop = "SkillType_Workshop",
	},
	SkillList = {
		Desc = "打工中，最大工时 +{Value1}%",
		Skill = {
			{
				Id = 107037,
				Value = 10,
			},
		},
	},
	CharacterList = {
		{
			Id = 220105,
		},
		{
			Id = 220106,
		},
		{
			Id = 220107,
		},
		{
			Id = 220108,
		},
		{
			Id = 220109,
		},
		{
			Id = 220110,
		},
		{
			Id = 220111,
		},
	},
}
CoupleConfig[CoupleID.Id027] =
{
	Id = 27,
	Name = "破产姐妹花",
	Gallery = 950002,
	PrefabBundle = "couple",
	PrefabName = "Couple_FAT_4",
	Desc = "需要咖啡女仆，棒棒糖女仆",
	TypeNode = {
		WorkShop = "SkillType_Workshop",
	},
	SkillList = {
		Desc = "打工金币数量 +{Value1}%",
		Skill = {
			{
				Id = 107038,
				Value = 10,
			},
		},
	},
	CharacterList = {
		{
			Id = 220113,
		},
		{
			Id = 220112,
		},
	},
}
CoupleConfig[CoupleID.Id028] =
{
	Id = 28,
	Name = "甜蜜魔力",
	Gallery = 950002,
	PrefabBundle = "couple",
	PrefabName = "Couple_FAT_5",
	Desc = "需要华夫饼仙子，松饼仙子，布丁仙子",
	TypeNode = {
		Challenge = "SkillType_Challenge",
	},
	SkillList = {
		Desc = "每回合全队美食星队员回血 {Value1}，最多5次",
		Skill = {
			{
				Id = 107039,
				Value = 600,
			},
		},
	},
	CharacterList = {
		{
			Id = 220114,
		},
		{
			Id = 220115,
		},
		{
			Id = 220116,
		},
	},
}
CoupleConfig[CoupleID.Id029] =
{
	Id = 29,
	Name = "零食风暴",
	Gallery = 950002,
	PrefabBundle = "couple",
	PrefabName = "Couple_FAT_6",
	Desc = "需要妙脆角小姐，虾条小姐",
	TypeNode = {
		Challenge = "SkillType_Challenge",
	},
	SkillList = {
		Desc = "敌人暴击 -{Value1}",
		Skill = {
			{
				Id = 107040,
				Value = -60,
			},
		},
	},
	CharacterList = {
		{
			Id = 220118,
		},
		{
			Id = 220117,
		},
	},
}
CoupleConfig[CoupleID.Id030] =
{
	Id = 30,
	Name = "继母总动员",
	Gallery = 950002,
	PrefabBundle = "couple",
	PrefabName = "Couple_FAT_7",
	Desc = "需要黑巧克力皇后，薯片夫人，培根女巫，炸鸡魔后",
	TypeNode = {
		Challenge = "SkillType_Challenge",
	},
	SkillList = {
		Desc = "全队暴击伤害 +{Value1}%",
		Skill = {
			{
				Id = 107041,
				Value = 65,
			},
		},
	},
	CharacterList = {
		{
			Id = 220121,
		},
		{
			Id = 220120,
		},
		{
			Id = 220119,
		},
		{
			Id = 220129,
		},
	},
}
CoupleConfig[CoupleID.Id031] =
{
	Id = 31,
	Name = "我们结婚吧",
	Gallery = 950002,
	PrefabBundle = "couple",
	PrefabName = "Couple_FAT_8",
	Desc = "需要热狗先生，汉堡小姐",
	TypeNode = {
		Challenge = "SkillType_Challenge",
		Explore = "SkillType_Explore",
	},
	SkillList = {
		Desc = "热狗先生及汉堡小姐每回合回血 {Value1}，最多5次；全队暴击 +{Value2}",
		Skill = {
			{
				Id = 107042,
				Value = 600,
			},
			{
				Id = 107043,
				Value = 60,
			},
		},
	},
	CharacterList = {
		{
			Id = 220127,
		},
		{
			Id = 220126,
		},
	},
}
CoupleConfig[CoupleID.Id032] =
{
	Id = 32,
	Name = "有我在，陛下",
	Gallery = 950002,
	PrefabBundle = "couple",
	PrefabName = "Couple_FAT_9",
	Desc = "需要薯条国王，番茄酱侍卫",
	TypeNode = {
		Challenge = "SkillType_Challenge",
		Explore = "SkillType_Explore",
	},
	SkillList = {
		Desc = "薯条国王攻击 +{Value1}，番茄酱侍卫忍耐 +{Value2}",
		Skill = {
			{
				Id = 107044,
				Value = 1000,
			},
			{
				Id = 107045,
				Value = 60,
			},
		},
	},
	CharacterList = {
		{
			Id = 220131,
		},
		{
			Id = 220128,
		},
	},
}
CoupleConfig[CoupleID.Id033] =
{
	Id = 33,
	Name = "影院套餐",
	Gallery = 950002,
	PrefabBundle = "couple",
	PrefabName = "Couple_FAT_10",
	Desc = "需要爆米花女王，可乐王子",
	TypeNode = {
		Explore = "SkillType_Explore",
	},
	SkillList = {
		Desc = "全队战力 +{Value1}%",
		Skill = {
			{
				Id = 107046,
				Value = 120,
			},
		},
	},
	CharacterList = {
		{
			Id = 220130,
		},
		{
			Id = 220103,
		},
	},
}
CoupleConfig[CoupleID.Id034] =
{
	Id = 34,
	Name = "防盗二人组",
	Gallery = 950003,
	PrefabBundle = "couple",
	PrefabName = "Couple_MUS_1",
	Desc = "需要保安，侦探小姐",
	TypeNode = {
		Explore = "SkillType_Explore",
	},
	SkillList = {
		Desc = "敌人捕捉成功率 +{Value1}%",
		Skill = {
			{
				Id = 107047,
				Value = 40,
			},
		},
	},
	CharacterList = {
		{
			Id = 220201,
		},
		{
			Id = 220202,
		},
	},
}
CoupleConfig[CoupleID.Id035] =
{
	Id = 35,
	Name = "璀璨文明",
	Gallery = 950003,
	PrefabBundle = "couple",
	PrefabName = "Couple_MUS_2",
	Desc = "需要默艾，兵马俑，石柱人，半人马石像",
	TypeNode = {
		WorkShop = "SkillType_Workshop",
	},
	SkillList = {
		Desc = "全队智力 +{Value1}；最大工时 +{Value2}%",
		Skill = {
			{
				Id = 107048,
				Value = 60,
			},
			{
				Id = 107049,
				Value = 15,
			},
		},
	},
	CharacterList = {
		{
			Id = 220206,
		},
		{
			Id = 220207,
		},
		{
			Id = 220208,
		},
		{
			Id = 220209,
		},
	},
}
CoupleConfig[CoupleID.Id036] =
{
	Id = 36,
	Name = "圣光照耀",
	Gallery = 950003,
	PrefabBundle = "couple",
	PrefabName = "Couple_MUS_3",
	Desc = "需要创造之神，亚当",
	TypeNode = {
		WorkShop = "SkillType_Workshop",
	},
	SkillList = {
		Desc = "全队亲和 +{Value1}；最大工时 +{Value2}%",
		Skill = {
			{
				Id = 107050,
				Value = 90,
			},
			{
				Id = 107051,
				Value = 15,
			},
		},
	},
	CharacterList = {
		{
			Id = 220211,
		},
		{
			Id = 220210,
		},
	},
}
CoupleConfig[CoupleID.Id037] =
{
	Id = 37,
	Name = "错的是世界",
	Gallery = 950003,
	PrefabBundle = "couple",
	PrefabName = "Couple_MUS_4",
	Desc = "需要哭泣的女人，呐喊家",
	TypeNode = {
		Challenge = "SkillType_Challenge",
	},
	SkillList = {
		Desc = "敌人生命 -{Value1}%",
		Skill = {
			{
				Id = 107052,
				Value = -6,
			},
		},
	},
	CharacterList = {
		{
			Id = 220212,
		},
		{
			Id = 220213,
		},
	},
}
CoupleConfig[CoupleID.Id038] =
{
	Id = 38,
	Name = "摩登家族",
	Gallery = 950003,
	PrefabBundle = "couple",
	PrefabName = "Couple_MUS_5",
	Desc = "需要原始人爸爸，原始人妈妈，原始人儿子",
	TypeNode = {
		Explore = "SkillType_Explore",
	},
	SkillList = {
		Desc = "敌人捕捉成功率 +{Value1}%",
		Skill = {
			{
				Id = 107053,
				Value = 60,
			},
		},
	},
	CharacterList = {
		{
			Id = 220214,
		},
		{
			Id = 220215,
		},
		{
			Id = 220216,
		},
	},
}
CoupleConfig[CoupleID.Id039] =
{
	Id = 39,
	Name = "抢钱啦！",
	Gallery = 950003,
	PrefabBundle = "couple",
	PrefabName = "Couple_MUS_6",
	Desc = "需要浣熊大哥，浣熊二哥，浣熊小弟",
	TypeNode = {
		Explore = "SkillType_Explore",
	},
	SkillList = {
		Desc = "探索金币数量 +{Value1}%",
		Skill = {
			{
				Id = 107054,
				Value = 60,
			},
		},
	},
	CharacterList = {
		{
			Id = 220203,
		},
		{
			Id = 220204,
		},
		{
			Id = 220205,
		},
	},
}
CoupleConfig[CoupleID.Id040] =
{
	Id = 40,
	Name = "尼罗河的传说",
	Gallery = 950003,
	PrefabBundle = "couple",
	PrefabName = "Couple_MUS_7",
	Desc = "需要阿努比斯，索贝克，赛特，荷鲁斯",
	TypeNode = {
		Explore = "SkillType_Explore",
	},
	SkillList = {
		Desc = "道具掉落率 +{Value1}%",
		Skill = {
			{
				Id = 107055,
				Value = 60,
			},
		},
	},
	CharacterList = {
		{
			Id = 220223,
		},
		{
			Id = 220221,
		},
		{
			Id = 220220,
		},
		{
			Id = 220222,
		},
	},
}
CoupleConfig[CoupleID.Id041] =
{
	Id = 41,
	Name = "完美的爱情",
	Gallery = 950003,
	PrefabBundle = "couple",
	PrefabName = "Couple_MUS_8",
	Desc = "需要微笑女神，魔术师",
	TypeNode = {
		Challenge = "SkillType_Challenge",
	},
	SkillList = {
		Desc = "每3回合，魔术师{Value1}%暴击，微笑女神{Value2}%闪避",
		Skill = {
			{
				Id = 107056,
				Value = 100,
			},
			{
				Id = 107057,
				Value = 100,
			},
		},
	},
	CharacterList = {
		{
			Id = 220226,
		},
		{
			Id = 220227,
		},
	},
}
CoupleConfig[CoupleID.Id042] =
{
	Id = 42,
	Name = "听我召唤",
	Gallery = 950003,
	PrefabBundle = "couple",
	PrefabName = "Couple_MUS_9",
	Desc = "需要火焰熊猫(浣熊大哥皮肤)，风暴熊猫(浣熊二哥皮肤)，大地熊猫(浣熊小弟皮肤)",
	TypeNode = {
		Challenge = "SkillType_Challenge",
	},
	SkillList = {
		Desc = "全队对水、火、风元素敌人伤害 +{Value1}%",
		Skill = {
			{
				Id = 107058,
				Value = 33,
			},
			{
				Id = 107059,
				Value = 33,
			},
			{
				Id = 107060,
				Value = 33,
			},
		},
	},
	CharacterList = {
		{
			Id = 220203,
			SkinId = 232081,
		},
		{
			Id = 220204,
			SkinId = 232082,
		},
		{
			Id = 220205,
			SkinId = 232083,
		},
	},
}
CoupleConfig[CoupleID.Id043] =
{
	Id = 43,
	Name = "龙套",
	Gallery = 950004,
	PrefabBundle = "couple",
	PrefabName = "Couple_SUS_1",
	Desc = "需要报童，受害者，调酒师，房东太太",
	TypeNode = {
		WorkShop = "SkillType_Workshop",
	},
	SkillList = {
		Desc = "打工食物数量 +{Value1}%",
		Skill = {
			{
				Id = 107061,
				Value = 30,
			},
		},
	},
	CharacterList = {
		{
			Id = 220301,
		},
		{
			Id = 220311,
		},
		{
			Id = 220314,
		},
		{
			Id = 220313,
		},
	},
}
CoupleConfig[CoupleID.Id044] =
{
	Id = 44,
	Name = "正义必胜",
	Gallery = 950004,
	PrefabBundle = "couple",
	PrefabName = "Couple_SUS_2",
	Desc = "需要证人，正义之友(检察官皮肤)，豆豆警官",
	TypeNode = {
		Challenge = "SkillType_Challenge",
	},
	SkillList = {
		Desc = "全队对暗元素敌人伤害 +{Value1}%，受暗元素敌人伤害 -{Value2}%",
		Skill = {
			{
				Id = 107062,
				Value = 50,
			},
			{
				Id = 107063,
				Value = -25,
			},
		},
	},
	CharacterList = {
		{
			Id = 220304,
		},
		{
			Id = 220318,
			SkinId = 232136,
		},
		{
			Id = 220316,
		},
	},
}
CoupleConfig[CoupleID.Id045] =
{
	Id = 45,
	Name = "怪盗三姐妹",
	Gallery = 950004,
	PrefabBundle = "couple",
	PrefabName = "Couple_SUS_3",
	Desc = "需要小泪，小瞳，小爱",
	TypeNode = {
		Explore = "SkillType_Explore",
	},
	SkillList = {
		Desc = "道具掉落率 +{Value1}%",
		Skill = {
			{
				Id = 107064,
				Value = 40,
			},
		},
	},
	CharacterList = {
		{
			Id = 220306,
		},
		{
			Id = 220307,
		},
		{
			Id = 220308,
		},
	},
}
CoupleConfig[CoupleID.Id046] =
{
	Id = 46,
	Name = "畅销读物",
	Gallery = 950004,
	PrefabBundle = "couple",
	PrefabName = "Couple_SUS_4",
	Desc = "需要编辑长，阿加莎，翻译组(读者皮肤)",
	TypeNode = {
		WorkShop = "SkillType_Workshop",
	},
	SkillList = {
		Desc = "全队技巧 +{Value1}；最大工时 +{Value2}%",
		Skill = {
			{
				Id = 107065,
				Value = 60,
			},
			{
				Id = 107066,
				Value = 10,
			},
		},
	},
	CharacterList = {
		{
			Id = 220309,
		},
		{
			Id = 220302,
		},
		{
			Id = 220310,
			SkinId = 232128,
		},
	},
}
CoupleConfig[CoupleID.Id047] =
{
	Id = 47,
	Name = "庭上的对决",
	Gallery = 950004,
	PrefabBundle = "couple",
	PrefabName = "Couple_SUS_5",
	Desc = "需要检察官，律师，法官",
	TypeNode = {
		Challenge = "SkillType_Challenge",
		Explore = "SkillType_Explore",
	},
	SkillList = {
		Desc = "全队攻击 +{Value1}",
		Skill = {
			{
				Id = 107067,
				Value = 640,
			},
		},
	},
	CharacterList = {
		{
			Id = 220318,
		},
		{
			Id = 220312,
		},
		{
			Id = 220319,
		},
	},
}
CoupleConfig[CoupleID.Id048] =
{
	Id = 48,
	Name = "秘密行动",
	Gallery = 950004,
	PrefabBundle = "couple",
	PrefabName = "Couple_SUS_6",
	Desc = "需要女装助理(侦探助理皮肤)，律政女王(律师皮肤)，女法官(法官皮肤)",
	TypeNode = {
		Challenge = "SkillType_Challenge",
	},
	SkillList = {
		Desc = "敌人忍耐 -{Value1}",
		Skill = {
			{
				Id = 107068,
				Value = -100,
			},
		},
	},
	CharacterList = {
		{
			Id = 220320,
			SkinId = 232139,
		},
		{
			Id = 220312,
			SkinId = 232130,
		},
		{
			Id = 220319,
			SkinId = 232137,
		},
	},
}
CoupleConfig[CoupleID.Id049] =
{
	Id = 49,
	Name = "完美推理",
	Gallery = 950004,
	PrefabBundle = "couple",
	PrefabName = "Couple_SUS_7",
	Desc = "需要蓝衣小学生，大侦探，侦探助理",
	TypeNode = {
		Challenge = "SkillType_Challenge",
	},
	SkillList = {
		Desc = "每3回合，全队有{Value1}%概率无视敌人闪避",
		Skill = {
			{
				Id = 107069,
				Value = 100,
			},
		},
	},
	CharacterList = {
		{
			Id = 220322,
		},
		{
			Id = 220324,
		},
		{
			Id = 220320,
		},
	},
}
CoupleConfig[CoupleID.Id050] =
{
	Id = 50,
	Name = "卧底行动",
	Gallery = 950004,
	PrefabBundle = "couple",
	PrefabName = "Couple_SUS_8",
	Desc = "需要黑警察(豆豆警官皮肤)，黑法医(法医皮肤)",
	TypeNode = {
		Challenge = "SkillType_Challenge",
	},
	SkillList = {
		Desc = "回合中，豆豆警官与法医每次受击，攻击 +{Value1}",
		Skill = {
			{
				Id = 107070,
				Value = 400,
			},
		},
	},
	CharacterList = {
		{
			Id = 220316,
			SkinId = 232134,
		},
		{
			Id = 220317,
			SkinId = 232135,
		},
	},
}
CoupleConfig[CoupleID.Id051] =
{
	Id = 51,
	Name = "法证先锋",
	Gallery = 950004,
	PrefabBundle = "couple",
	PrefabName = "Couple_SUS_9",
	Desc = "需要法医，死者，证人",
	TypeNode = {
		Challenge = "SkillType_Challenge",
	},
	SkillList = {
		Desc = "每3回合，全队本回合暴率 +{Value1}%",
		Skill = {
			{
				Id = 107071,
				Value = 100,
			},
		},
	},
	CharacterList = {
		{
			Id = 220317,
		},
		{
			Id = 220303,
		},
		{
			Id = 220304,
		},
	},
}
CoupleConfig[CoupleID.Id052] =
{
	Id = 52,
	Name = "睡衣派对",
	Gallery = 950004,
	PrefabBundle = "couple",
	PrefabName = "Couple_SUS_10",
	Desc = "需要睡衣助理(侦探助理皮肤)，睡衣侦探(大侦探皮肤)，睡衣教授(教授皮肤)",
	TypeNode = {
		Challenge = "SkillType_Challenge",
	},
	SkillList = {
		Desc = "3回合后，每回合全队回血 {Value1}%，最多5次",
		Skill = {
			{
				Id = 107072,
				Value = 24,
			},
		},
	},
	CharacterList = {
		{
			Id = 220320,
			SkinId = 232140,
		},
		{
			Id = 220324,
			SkinId = 232145,
		},
		{
			Id = 220325,
			SkinId = 232149,
		},
	},
}
CoupleConfig[CoupleID.Id053] =
{
	Id = 53,
	Name = "改造方案",
	Gallery = 950004,
	PrefabBundle = "couple",
	PrefabName = "Couple_SUS_11",
	Desc = "需要化学教授(教授皮肤)，MK-II 加强型(博士皮肤)",
	TypeNode = {
		Challenge = "SkillType_Challenge",
	},
	SkillList = {
		Desc = "暗元素队员暴击伤害 +{Value1}%，受到暴击伤害 +{Value2}%",
		Skill = {
			{
				Id = 107073,
				Value = 75,
			},
			{
				Id = 107074,
				Value = 50,
			},
		},
	},
	CharacterList = {
		{
			Id = 220325,
			SkinId = 232150,
		},
		{
			Id = 220315,
			SkinId = 232133,
		},
	},
}
CoupleConfig[CoupleID.Id054] =
{
	Id = 54,
	Name = "反派联盟",
	Gallery = 950004,
	PrefabBundle = "couple",
	PrefabName = "Couple_SUS_12",
	Desc = "需要教授，杰克瑞波，凶手",
	TypeNode = {
		Challenge = "SkillType_Challenge",
		Explore = "SkillType_Explore",
	},
	SkillList = {
		Desc = "教授、杰克瑞波、凶手暴击 +{Value1}%，忍耐 -{Value2}%",
		Skill = {
			{
				Id = 107075,
				Value = 100,
			},
			{
				Id = 107076,
				Value = -100,
			},
		},
	},
	CharacterList = {
		{
			Id = 220325,
		},
		{
			Id = 220321,
		},
		{
			Id = 220305,
		},
	},
}
CoupleConfig[CoupleID.Id055] =
{
	Id = 55,
	Name = "五福临门",
	Gallery = 950101,
	PrefabBundle = "couple",
	PrefabName = "Couple_ALL_9",
	Desc = "需要松芊芊，休休，阿宁，倪不染，小始小终",
	TypeNode = {
		Explore = "SkillType_Explore",
	},
	SkillList = {
		Desc = "探索金币数量 +{Value1}%、道具掉落率 +{Value2}%",
		Skill = {
			{
				Id = 107077,
				Value = 50,
			},
			{
				Id = 107078,
				Value = 50,
			},
		},
	},
	CharacterList = {
		{
			Id = 223061,
		},
		{
			Id = 223062,
		},
		{
			Id = 223063,
		},
		{
			Id = 223064,
		},
		{
			Id = 223065,
		},
	},
}
CoupleConfig[CoupleID.Id056] =
{
	Id = 56,
	Name = "扭曲的力量",
	Gallery = 950001,
	PrefabBundle = "couple",
	PrefabName = "Couple_RPG_13",
	Desc = "需要魔法师，术士",
	TypeNode = {
		Challenge = "SkillType_Challenge",
	},
	SkillList = {
		Desc = "魔法师及术士攻击时无视敌人{Value1}%忍耐",
		Skill = {
			{
				Id = 107079,
				Value = 50,
			},
		},
	},
	CharacterList = {
		{
			Id = 220010,
		},
		{
			Id = 223007,
		},
	},
}
CoupleConfig[CoupleID.Id057] =
{
	Id = 57,
	Name = "摧毁意志的美食",
	Gallery = 950002,
	PrefabBundle = "couple",
	PrefabName = "Couple_FAT_11",
	Desc = "需要猪猪包，板蓝根泡面，皮蛋披萨",
	TypeNode = {
		WorkShop = "SkillType_Workshop",
	},
	SkillList = {
		Desc = "打工捕捉道具数量 +{Value1}%",
		Skill = {
			{
				Id = 107080,
				Value = 20,
			},
		},
	},
	CharacterList = {
		{
			Id = 223106,
		},
		{
			Id = 223102,
		},
		{
			Id = 223103,
		},
	},
}
CoupleConfig[CoupleID.Id058] =
{
	Id = 58,
	Name = "摧毁味觉的美食",
	Gallery = 950002,
	PrefabBundle = "couple",
	PrefabName = "Couple_FAT_12",
	Desc = "需要基维燕克，鲱鱼饭团，辣辣子",
	TypeNode = {
		Explore = "SkillType_Explore",
	},
	SkillList = {
		Desc = "道具掉落率 +{Value1}%，探索金币数量 +{Value2}%",
		Skill = {
			{
				Id = 107081,
				Value = 40,
			},
			{
				Id = 107082,
				Value = 40,
			},
		},
	},
	CharacterList = {
		{
			Id = 223105,
		},
		{
			Id = 223104,
		},
		{
			Id = 223101,
		},
	},
}
CoupleConfig[CoupleID.Id059] =
{
	Id = 59,
	Name = "Sharkalaka",
	Gallery = 950005,
	PrefabBundle = "couple",
	PrefabName = "Couple_SEA_1",
	Desc = "需要白鲨牙牙，鲸鲨依伶，虎鲸京",
	TypeNode = {
		Explore = "SkillType_Explore",
	},
	SkillList = {
		Desc = "海洋星敌人道具掉落率 +{Value1}%；海洋星敌人捕捉成功率 +{Value2}%",
		Skill = {
			{
				Id = 107083,
				Value = 36,
			},
			{
				Id = 107084,
				Value = 36,
			},
		},
	},
	CharacterList = {
		{
			Id = 220426,
		},
		{
			Id = 220427,
		},
		{
			Id = 220430,
		},
	},
}
CoupleConfig[CoupleID.Id060] =
{
	Id = 60,
	Name = "成为练习生吧！",
	Gallery = 950005,
	PrefabBundle = "couple",
	PrefabName = "Couple_SEA_2",
	Desc = "需要琵琶映冬，海豚凛",
	TypeNode = {
		Challenge = "SkillType_Challenge",
	},
	SkillList = {
		Desc = "每3回合全队回血 {Value1}，最多3次",
		Skill = {
			{
				Id = 107085,
				Value = 750,
			},
		},
	},
	CharacterList = {
		{
			Id = 220428,
		},
		{
			Id = 220401,
		},
	},
}
CoupleConfig[CoupleID.Id061] =
{
	Id = 61,
	Name = "TeaTime",
	Gallery = 950005,
	PrefabBundle = "couple",
	PrefabName = "Couple_SEA_3",
	Desc = "需要扇贝珍，海螺美莎",
	TypeNode = {
		Challenge = "SkillType_Challenge",
	},
	SkillList = {
		Desc = "每回合全队暴击 +{Value1}、忍耐 +{Value2}，最多5次",
		Skill = {
			{
				Id = 107086,
				Value = 24,
			},
			{
				Id = 107087,
				Value = 24,
			},
		},
	},
	CharacterList = {
		{
			Id = 220407,
		},
		{
			Id = 220408,
		},
	},
}
CoupleConfig[CoupleID.Id062] =
{
	Id = 62,
	Name = "RockingThanks",
	Gallery = 950005,
	PrefabBundle = "couple",
	PrefabName = "Couple_SEA_4",
	Desc = "需要蟹香菜，虾伊洛",
	TypeNode = {
		Explore = "SkillType_Explore",
	},
	SkillList = {
		Desc = "敌人捕捉成功率 +{Value1}%",
		Skill = {
			{
				Id = 107088,
				Value = 40,
			},
		},
	},
	CharacterList = {
		{
			Id = 220409,
		},
		{
			Id = 220410,
		},
	},
}
CoupleConfig[CoupleID.Id063] =
{
	Id = 63,
	Name = "深潜FoRever",
	Gallery = 950005,
	PrefabBundle = "couple",
	PrefabName = "Couple_SEA_5",
	Desc = "需要小丑遥，刺豚茉白，电鳗伊俄，海星寻沙，章鱼舞妍",
	TypeNode = {
		Explore = "SkillType_Explore",
	},
	SkillList = {
		Desc = "打不过的怪物出现概率 -{Value1}%；探索金币数量 +{Value2}%",
		Skill = {
			{
				Id = 107089,
				Value = -30,
			},
			{
				Id = 107090,
				Value = 60,
			},
		},
	},
	CharacterList = {
		{
			Id = 220412,
		},
		{
			Id = 220405,
		},
		{
			Id = 220403,
		},
		{
			Id = 220423,
		},
		{
			Id = 220424,
		},
	},
}
CoupleConfig[CoupleID.Id064] =
{
	Id = 64,
	Name = "Aquarius",
	Gallery = 950005,
	PrefabBundle = "couple",
	PrefabName = "Couple_SEA_6",
	Desc = "需要海胆小茨，海葵彩雅，斗鱼希，乌贼墨，海参橘，鮟鱇明，海蛇莱斯莉",
	TypeNode = {
		WorkShop = "SkillType_Workshop",
	},
	SkillList = {
		Desc = "全队技巧、亲和、力气、智力 +{Value1}",
		Skill = {
			{
				Id = 107091,
				Value = 60,
			},
			{
				Id = 107092,
				Value = 60,
			},
			{
				Id = 107093,
				Value = 60,
			},
			{
				Id = 107094,
				Value = 60,
			},
		},
	},
	CharacterList = {
		{
			Id = 220413,
		},
		{
			Id = 220416,
		},
		{
			Id = 220417,
		},
		{
			Id = 220402,
		},
		{
			Id = 220418,
		},
		{
			Id = 220419,
		},
		{
			Id = 220425,
		},
	},
}
CoupleConfig[CoupleID.Id065] =
{
	Id = 65,
	Name = "鱼妄想",
	Gallery = 950005,
	PrefabBundle = "couple",
	PrefabName = "Couple_SEA_7",
	Desc = "需要鱼不翻，蝠鲼凉风",
	TypeNode = {
		Explore = "SkillType_Explore",
	},
	SkillList = {
		Desc = "打不过的怪物出现概率 -{Value1}%",
		Skill = {
			{
				Id = 107095,
				Value = -40,
			},
		},
	},
	CharacterList = {
		{
			Id = 220406,
		},
		{
			Id = 220414,
		},
	},
}
CoupleConfig[CoupleID.Id066] =
{
	Id = 66,
	Name = "Sealing'sVoice",
	Gallery = 950005,
	PrefabBundle = "couple",
	PrefabName = "Couple_SEA_8",
	Desc = "需要海马希波，海豹彩",
	TypeNode = {
		Explore = "SkillType_Explore",
	},
	SkillList = {
		Desc = "道具掉落率 +{Value1}%",
		Skill = {
			{
				Id = 107096,
				Value = 40,
			},
		},
	},
	CharacterList = {
		{
			Id = 220415,
		},
		{
			Id = 220420,
		},
	},
}
CoupleConfig[CoupleID.Id067] =
{
	Id = 67,
	Name = "浅海smily",
	Gallery = 950005,
	PrefabBundle = "couple",
	PrefabName = "Couple_SEA_9",
	Desc = "需要黄金纱纱，灯塔丝丝",
	TypeNode = {
		Challenge = "SkillType_Challenge",
	},
	SkillList = {
		Desc = "每3回合全队每次受击回血 {Value1}，最多3次",
		Skill = {
			{
				Id = 107097,
				Value = 1000,
			},
		},
	},
	CharacterList = {
		{
			Id = 220421,
		},
		{
			Id = 220422,
		},
	},
}
CoupleConfig[CoupleID.Id068] =
{
	Id = 68,
	Name = "乘风破浪",
	Gallery = 950101,
	PrefabBundle = "couple",
	PrefabName = "Couple_ALL_10",
	Desc = "需要2阶龙头老大，2阶抬鼓达人，2阶桨手一号，2阶桨手二号，2阶龙尾小弟",
	TypeNode = {
		Explore = "SkillType_Explore",
	},
	SkillList = {
		Desc = "探索等待时间 -{Value1}%；打不过的敌人出现概率 -{Value2}%",
		Skill = {
			{
				Id = 107098,
				Value = -15,
			},
			{
				Id = 107099,
				Value = -30,
			},
		},
	},
	CharacterList = {
		{
			Id = 223125,
			Stage = 2,
		},
		{
			Id = 223126,
			Stage = 2,
		},
		{
			Id = 223127,
			Stage = 2,
		},
		{
			Id = 223128,
			Stage = 2,
		},
		{
			Id = 223129,
			Stage = 2,
		},
	},
}
CoupleConfig[CoupleID.Id069] =
{
	Id = 69,
	Name = "鹊桥仙",
	Gallery = 950101,
	PrefabBundle = "couple",
	PrefabName = "Couple_ALL_12",
	Desc = "需要2阶牵牛，2阶七织",
	TypeNode = {
		WorkShop = "SkillType_Workshop",
	},
	SkillList = {
		Desc = "打工食物数量 +{Value1}%",
		Skill = {
			{
				Id = 107101,
				Value = 30,
			},
		},
	},
	CharacterList = {
		{
			Id = 223130,
			Stage = 2,
		},
		{
			Id = 223137,
			Stage = 2,
		},
	},
}
CoupleConfig[CoupleID.Id070] =
{
	Id = 70,
	Name = "雪中的童话",
	Gallery = 950101,
	PrefabBundle = "couple",
	PrefabName = "Couple_ALL_14",
	Desc = "需要思诺曼，断耳熊",
	TypeNode = {
		WorkShop = "SkillType_Workshop",
	},
	SkillList = {
		Desc = "打工金币+{Value1}%，全队水元素队员亲和+{Value2}%",
		Skill = {
			{
				Id = 107104,
				Value = 20,
			},
			{
				Id = 107105,
				Value = 3,
			},
		},
	},
	CharacterList = {
		{
			Id = 223148,
		},
		{
			Id = 223145,
		},
	},
}
CoupleConfig[CoupleID.Id071] =
{
	Id = 71,
	Name = "一起泡温泉吧",
	Gallery = 950101,
	PrefabBundle = "couple",
	PrefabName = "Couple_ALL_15",
	Desc = "需要猫眼厨娘，温泉鉴赏家，健身教练，雪中猎人，编剧妹子",
	TypeNode = {
		Challenge = "SkillType_Challenge",
	},
	SkillList = {
		Desc = "前3队员偶数回合回血{Value1}，后3奇数回合攻击+{Value2}，最多各3次",
		Skill = {
			{
				Id = 107106,
				Value = 800,
			},
			{
				Id = 107107,
				Value = 800,
			},
		},
	},
	CharacterList = {
		{
			Id = 223142,
		},
		{
			Id = 223143,
		},
		{
			Id = 223144,
		},
		{
			Id = 223146,
		},
		{
			Id = 223147,
		},
	},
}

