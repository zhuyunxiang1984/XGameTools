
DemandConfig[DemandID.Id801] =
{
	Id = 801,
	Name = "订购营养液1",
	Desc = "需要一些营养液",
	Value = 321612,
	Active = false,
	Weight = 68775,
	PreGoal = 
	{
		301543,
		301730,
	},
	GoodsId = 8101612,
	Priority = 1613060,
	Num = 24,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 51965,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 490,
				},
				{
					Value = 1,
					Num = 2965,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 98,
				},
				{
					Value = 1,
					Num = 2965,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 19,
				},
				{
					Value = 1,
					Num = 4465,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 14465,
				},
			},
		},
	},
	DemandID = 410801,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id802] =
{
	Id = 802,
	Name = "订购谣言1",
	Desc = "需要一些谣言",
	Value = 321651,
	Active = true,
	Weight = 19200,
	PreGoal = 
	{
		301556,
		301220,
	},
	CloseGoal = 
	{
		301248,
	},
	GoodsId = 8201651,
	Priority = 1651801,
	Num = 16,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 181744,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 19,
				},
				{
					Value = 1,
					Num = 17584,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 6,
				},
				{
					Value = 1,
					Num = 26224,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 1,
				},
				{
					Value = 1,
					Num = 95344,
				},
			},
		},
	},
	DemandID = 410802,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id803] =
{
	Id = 803,
	Name = "订购谣言1",
	Desc = "需要一些谣言",
	Value = 321651,
	Active = true,
	Weight = 19680,
	PreGoal = 
	{
		301556,
		301228,
	},
	CloseGoal = 
	{
		301256,
	},
	GoodsId = 8201651,
	Priority = 1651802,
	Num = 16,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 181744,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 19,
				},
				{
					Value = 1,
					Num = 17584,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 6,
				},
				{
					Value = 1,
					Num = 26224,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 1,
				},
				{
					Value = 1,
					Num = 95344,
				},
			},
		},
	},
	DemandID = 410803,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id804] =
{
	Id = 804,
	Name = "订购谣言1",
	Desc = "需要一些谣言",
	Value = 321651,
	Active = true,
	Weight = 20160,
	PreGoal = 
	{
		301556,
		301236,
	},
	CloseGoal = 
	{
		301268,
	},
	GoodsId = 8201651,
	Priority = 1651803,
	Num = 18,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 204462,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 21,
				},
				{
					Value = 1,
					Num = 23022,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 7,
				},
				{
					Value = 1,
					Num = 23022,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 31662,
				},
			},
		},
	},
	DemandID = 410804,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id805] =
{
	Id = 805,
	Name = "订购谣言1",
	Desc = "需要一些谣言",
	Value = 321651,
	Active = true,
	Weight = 20880,
	PreGoal = 
	{
		301556,
		301248,
	},
	CloseGoal = 
	{
		301280,
	},
	GoodsId = 8201651,
	Priority = 1651804,
	Num = 18,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 204462,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 21,
				},
				{
					Value = 1,
					Num = 23022,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 7,
				},
				{
					Value = 1,
					Num = 23022,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 31662,
				},
			},
		},
	},
	DemandID = 410805,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id806] =
{
	Id = 806,
	Name = "订购谣言1",
	Desc = "需要一些谣言",
	Value = 321651,
	Active = true,
	Weight = 21600,
	PreGoal = 
	{
		301556,
		301260,
	},
	CloseGoal = 
	{
		301297,
	},
	GoodsId = 8201651,
	Priority = 1651805,
	Num = 18,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 204462,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 21,
				},
				{
					Value = 1,
					Num = 23022,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 7,
				},
				{
					Value = 1,
					Num = 23022,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 31662,
				},
			},
		},
	},
	DemandID = 410806,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id807] =
{
	Id = 807,
	Name = "订购谣言1",
	Desc = "需要一些谣言",
	Value = 321651,
	Active = true,
	Weight = 22560,
	PreGoal = 
	{
		301556,
		301276,
	},
	CloseGoal = 
	{
		301314,
	},
	GoodsId = 8201651,
	Priority = 1651806,
	Num = 18,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 204462,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 21,
				},
				{
					Value = 1,
					Num = 23022,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 7,
				},
				{
					Value = 1,
					Num = 23022,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 31662,
				},
			},
		},
	},
	DemandID = 410807,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id808] =
{
	Id = 808,
	Name = "订购谣言1",
	Desc = "需要一些谣言",
	Value = 321651,
	Active = true,
	Weight = 23520,
	PreGoal = 
	{
		301556,
		301292,
	},
	CloseGoal = 
	{
		301615,
	},
	GoodsId = 8201651,
	Priority = 1651807,
	Num = 18,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 204462,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 21,
				},
				{
					Value = 1,
					Num = 23022,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 7,
				},
				{
					Value = 1,
					Num = 23022,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 31662,
				},
			},
		},
	},
	DemandID = 410808,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id809] =
{
	Id = 809,
	Name = "订购谣言1",
	Desc = "需要一些谣言",
	Value = 321651,
	Active = true,
	Weight = 24720,
	PreGoal = 
	{
		301556,
		301314,
	},
	CloseGoal = 
	{
		301640,
	},
	GoodsId = 8201651,
	Priority = 1651808,
	Num = 18,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 204462,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 21,
				},
				{
					Value = 1,
					Num = 23022,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 7,
				},
				{
					Value = 1,
					Num = 23022,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 31662,
				},
			},
		},
	},
	DemandID = 410809,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id810] =
{
	Id = 810,
	Name = "订购谣言1",
	Desc = "需要一些谣言",
	Value = 321651,
	Active = true,
	Weight = 25920,
	PreGoal = 
	{
		301556,
		301615,
	},
	CloseGoal = 
	{
		301670,
	},
	GoodsId = 8201651,
	Priority = 1651809,
	Num = 18,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 204462,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 21,
				},
				{
					Value = 1,
					Num = 23022,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 7,
				},
				{
					Value = 1,
					Num = 23022,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 31662,
				},
			},
		},
	},
	DemandID = 410810,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id811] =
{
	Id = 811,
	Name = "订购谣言1",
	Desc = "需要一些谣言",
	Value = 321651,
	Active = true,
	Weight = 27360,
	PreGoal = 
	{
		301556,
		301645,
	},
	CloseGoal = 
	{
		301700,
	},
	GoodsId = 8201651,
	Priority = 1651810,
	Num = 18,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 204462,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 21,
				},
				{
					Value = 1,
					Num = 23022,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 7,
				},
				{
					Value = 1,
					Num = 23022,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 31662,
				},
			},
		},
	},
	DemandID = 410811,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id812] =
{
	Id = 812,
	Name = "订购肖像侧写1",
	Desc = "需要一些肖像侧写",
	Value = 321652,
	Active = true,
	Weight = 23763,
	PreGoal = 
	{
		301557,
		301256,
	},
	CloseGoal = 
	{
		301284,
	},
	GoodsId = 8301652,
	Priority = 1652891,
	Num = 15,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 239148,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 25,
				},
				{
					Value = 1,
					Num = 23148,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 8,
				},
				{
					Value = 1,
					Num = 31788,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 66348,
				},
			},
		},
	},
	DemandID = 410812,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id813] =
{
	Id = 813,
	Name = "订购肖像侧写1",
	Desc = "需要一些肖像侧写",
	Value = 321652,
	Active = true,
	Weight = 24297,
	PreGoal = 
	{
		301557,
		301264,
	},
	CloseGoal = 
	{
		301292,
	},
	GoodsId = 8301652,
	Priority = 1652892,
	Num = 15,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 239148,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 25,
				},
				{
					Value = 1,
					Num = 23148,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 8,
				},
				{
					Value = 1,
					Num = 31788,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 66348,
				},
			},
		},
	},
	DemandID = 410813,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id814] =
{
	Id = 814,
	Name = "订购肖像侧写1",
	Desc = "需要一些肖像侧写",
	Value = 321652,
	Active = true,
	Weight = 24831,
	PreGoal = 
	{
		301557,
		301272,
	},
	CloseGoal = 
	{
		301306,
	},
	GoodsId = 8301652,
	Priority = 1652893,
	Num = 15,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 239148,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 25,
				},
				{
					Value = 1,
					Num = 23148,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 8,
				},
				{
					Value = 1,
					Num = 31788,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 66348,
				},
			},
		},
	},
	DemandID = 410814,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id815] =
{
	Id = 815,
	Name = "订购肖像侧写1",
	Desc = "需要一些肖像侧写",
	Value = 321652,
	Active = true,
	Weight = 25632,
	PreGoal = 
	{
		301557,
		301284,
	},
	CloseGoal = 
	{
		301318,
	},
	GoodsId = 8301652,
	Priority = 1652894,
	Num = 15,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 239148,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 25,
				},
				{
					Value = 1,
					Num = 23148,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 8,
				},
				{
					Value = 1,
					Num = 31788,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 66348,
				},
			},
		},
	},
	DemandID = 410815,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id816] =
{
	Id = 816,
	Name = "订购肖像侧写1",
	Desc = "需要一些肖像侧写",
	Value = 321652,
	Active = true,
	Weight = 26433,
	PreGoal = 
	{
		301557,
		301297,
	},
	CloseGoal = 
	{
		301615,
	},
	GoodsId = 8301652,
	Priority = 1652895,
	Num = 15,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 239148,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 25,
				},
				{
					Value = 1,
					Num = 23148,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 8,
				},
				{
					Value = 1,
					Num = 31788,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 66348,
				},
			},
		},
	},
	DemandID = 410816,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id817] =
{
	Id = 817,
	Name = "订购肖像侧写1",
	Desc = "需要一些肖像侧写",
	Value = 321652,
	Active = true,
	Weight = 27501,
	PreGoal = 
	{
		301557,
		301314,
	},
	CloseGoal = 
	{
		301635,
	},
	GoodsId = 8301652,
	Priority = 1652896,
	Num = 15,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 239148,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 25,
				},
				{
					Value = 1,
					Num = 23148,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 8,
				},
				{
					Value = 1,
					Num = 31788,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 66348,
				},
			},
		},
	},
	DemandID = 410817,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id818] =
{
	Id = 818,
	Name = "订购肖像侧写1",
	Desc = "需要一些肖像侧写",
	Value = 321652,
	Active = true,
	Weight = 28569,
	PreGoal = 
	{
		301557,
		301605,
	},
	CloseGoal = 
	{
		301660,
	},
	GoodsId = 8301652,
	Priority = 1652897,
	Num = 15,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 239148,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 25,
				},
				{
					Value = 1,
					Num = 23148,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 8,
				},
				{
					Value = 1,
					Num = 31788,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 66348,
				},
			},
		},
	},
	DemandID = 410818,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id819] =
{
	Id = 819,
	Name = "订购肖像侧写1",
	Desc = "需要一些肖像侧写",
	Value = 321652,
	Active = true,
	Weight = 29904,
	PreGoal = 
	{
		301557,
		301635,
	},
	CloseGoal = 
	{
		301685,
	},
	GoodsId = 8301652,
	Priority = 1652898,
	Num = 15,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 239148,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 25,
				},
				{
					Value = 1,
					Num = 23148,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 8,
				},
				{
					Value = 1,
					Num = 31788,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 66348,
				},
			},
		},
	},
	DemandID = 410819,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id820] =
{
	Id = 820,
	Name = "订购肖像侧写1",
	Desc = "需要一些肖像侧写",
	Value = 321652,
	Active = true,
	Weight = 31239,
	PreGoal = 
	{
		301557,
		301660,
	},
	CloseGoal = 
	{
		301715,
	},
	GoodsId = 8301652,
	Priority = 1652899,
	Num = 15,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 239148,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 25,
				},
				{
					Value = 1,
					Num = 23148,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 8,
				},
				{
					Value = 1,
					Num = 31788,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 66348,
				},
			},
		},
	},
	DemandID = 410820,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id821] =
{
	Id = 821,
	Name = "订购肖像侧写1",
	Desc = "需要一些肖像侧写",
	Value = 321652,
	Active = true,
	Weight = 32841,
	PreGoal = 
	{
		301557,
		301690,
	},
	GoodsId = 8301652,
	Priority = 1652900,
	Num = 15,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 239148,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 25,
				},
				{
					Value = 1,
					Num = 23148,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 8,
				},
				{
					Value = 1,
					Num = 31788,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 66348,
				},
			},
		},
	},
	DemandID = 410821,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id822] =
{
	Id = 822,
	Name = "订购欠条1",
	Desc = "需要一些欠条",
	Value = 321653,
	Active = true,
	Weight = 28227,
	PreGoal = 
	{
		301558,
		301288,
	},
	CloseGoal = 
	{
		301318,
	},
	GoodsId = 8401653,
	Priority = 1653971,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 211636,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 22,
				},
				{
					Value = 1,
					Num = 21556,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 7,
				},
				{
					Value = 1,
					Num = 30196,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 38836,
				},
			},
		},
	},
	DemandID = 410822,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id823] =
{
	Id = 823,
	Name = "订购欠条1",
	Desc = "需要一些欠条",
	Value = 321653,
	Active = true,
	Weight = 28809,
	PreGoal = 
	{
		301558,
		301297,
	},
	CloseGoal = 
	{
		301327,
	},
	GoodsId = 8401653,
	Priority = 1653972,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 211636,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 22,
				},
				{
					Value = 1,
					Num = 21556,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 7,
				},
				{
					Value = 1,
					Num = 30196,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 38836,
				},
			},
		},
	},
	DemandID = 410823,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id824] =
{
	Id = 824,
	Name = "订购欠条1",
	Desc = "需要一些欠条",
	Value = 321653,
	Active = true,
	Weight = 29391,
	PreGoal = 
	{
		301558,
		301306,
	},
	CloseGoal = 
	{
		301620,
	},
	GoodsId = 8401653,
	Priority = 1653973,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 211636,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 22,
				},
				{
					Value = 1,
					Num = 21556,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 7,
				},
				{
					Value = 1,
					Num = 30196,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 38836,
				},
			},
		},
	},
	DemandID = 410824,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id825] =
{
	Id = 825,
	Name = "订购欠条1",
	Desc = "需要一些欠条",
	Value = 321653,
	Active = true,
	Weight = 30264,
	PreGoal = 
	{
		301558,
		301318,
	},
	CloseGoal = 
	{
		301635,
	},
	GoodsId = 8401653,
	Priority = 1653974,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 211636,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 22,
				},
				{
					Value = 1,
					Num = 21556,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 7,
				},
				{
					Value = 1,
					Num = 30196,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 38836,
				},
			},
		},
	},
	DemandID = 410825,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id826] =
{
	Id = 826,
	Name = "订购欠条1",
	Desc = "需要一些欠条",
	Value = 321653,
	Active = true,
	Weight = 31137,
	PreGoal = 
	{
		301558,
		301605,
	},
	CloseGoal = 
	{
		301655,
	},
	GoodsId = 8401653,
	Priority = 1653975,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 211636,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 22,
				},
				{
					Value = 1,
					Num = 21556,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 7,
				},
				{
					Value = 1,
					Num = 30196,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 38836,
				},
			},
		},
	},
	DemandID = 410826,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id827] =
{
	Id = 827,
	Name = "订购欠条1",
	Desc = "需要一些欠条",
	Value = 321653,
	Active = true,
	Weight = 32301,
	PreGoal = 
	{
		301558,
		301630,
	},
	CloseGoal = 
	{
		301675,
	},
	GoodsId = 8401653,
	Priority = 1653976,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 211636,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 22,
				},
				{
					Value = 1,
					Num = 21556,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 7,
				},
				{
					Value = 1,
					Num = 30196,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 38836,
				},
			},
		},
	},
	DemandID = 410827,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id828] =
{
	Id = 828,
	Name = "订购欠条1",
	Desc = "需要一些欠条",
	Value = 321653,
	Active = true,
	Weight = 33465,
	PreGoal = 
	{
		301558,
		301650,
	},
	CloseGoal = 
	{
		301700,
	},
	GoodsId = 8401653,
	Priority = 1653977,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 211636,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 22,
				},
				{
					Value = 1,
					Num = 21556,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 7,
				},
				{
					Value = 1,
					Num = 30196,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 38836,
				},
			},
		},
	},
	DemandID = 410828,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id829] =
{
	Id = 829,
	Name = "订购欠条1",
	Desc = "需要一些欠条",
	Value = 321653,
	Active = true,
	Weight = 34920,
	PreGoal = 
	{
		301558,
		301675,
	},
	CloseGoal = 
	{
		301725,
	},
	GoodsId = 8401653,
	Priority = 1653978,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 211636,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 22,
				},
				{
					Value = 1,
					Num = 21556,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 7,
				},
				{
					Value = 1,
					Num = 30196,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 38836,
				},
			},
		},
	},
	DemandID = 410829,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id830] =
{
	Id = 830,
	Name = "订购欠条1",
	Desc = "需要一些欠条",
	Value = 321653,
	Active = true,
	Weight = 36375,
	PreGoal = 
	{
		301558,
		301700,
	},
	GoodsId = 8401653,
	Priority = 1653979,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 211636,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 22,
				},
				{
					Value = 1,
					Num = 21556,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 7,
				},
				{
					Value = 1,
					Num = 30196,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 38836,
				},
			},
		},
	},
	DemandID = 410830,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id831] =
{
	Id = 831,
	Name = "订购欠条1",
	Desc = "需要一些欠条",
	Value = 321653,
	Active = false,
	Weight = 38121,
	PreGoal = 
	{
		301558,
		301730,
	},
	GoodsId = 8401653,
	Priority = 1653980,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 211636,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 22,
				},
				{
					Value = 1,
					Num = 21556,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 7,
				},
				{
					Value = 1,
					Num = 30196,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 38836,
				},
			},
		},
	},
	DemandID = 410831,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id832] =
{
	Id = 832,
	Name = "订购18X1",
	Desc = "需要一些18X",
	Value = 321654,
	Active = true,
	Weight = 30000,
	PreGoal = 
	{
		301559,
		301301,
	},
	CloseGoal = 
	{
		301605,
	},
	GoodsId = 8501654,
	Priority = 1655001,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 233889,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 24,
				},
				{
					Value = 1,
					Num = 26529,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 8,
				},
				{
					Value = 1,
					Num = 26529,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 61089,
				},
			},
		},
	},
	DemandID = 410832,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id833] =
{
	Id = 833,
	Name = "订购18X1",
	Desc = "需要一些18X",
	Value = 321654,
	Active = true,
	Weight = 30600,
	PreGoal = 
	{
		301559,
		301310,
	},
	CloseGoal = 
	{
		301620,
	},
	GoodsId = 8501654,
	Priority = 1655002,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 233889,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 24,
				},
				{
					Value = 1,
					Num = 26529,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 8,
				},
				{
					Value = 1,
					Num = 26529,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 61089,
				},
			},
		},
	},
	DemandID = 410833,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id834] =
{
	Id = 834,
	Name = "订购18X1",
	Desc = "需要一些18X",
	Value = 321654,
	Active = true,
	Weight = 31200,
	PreGoal = 
	{
		301559,
		301318,
	},
	CloseGoal = 
	{
		301635,
	},
	GoodsId = 8501654,
	Priority = 1655003,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 233889,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 24,
				},
				{
					Value = 1,
					Num = 26529,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 8,
				},
				{
					Value = 1,
					Num = 26529,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 61089,
				},
			},
		},
	},
	DemandID = 410834,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id835] =
{
	Id = 835,
	Name = "订购18X1",
	Desc = "需要一些18X",
	Value = 321654,
	Active = true,
	Weight = 32100,
	PreGoal = 
	{
		301559,
		301605,
	},
	CloseGoal = 
	{
		301650,
	},
	GoodsId = 8501654,
	Priority = 1655004,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 233889,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 24,
				},
				{
					Value = 1,
					Num = 26529,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 8,
				},
				{
					Value = 1,
					Num = 26529,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 61089,
				},
			},
		},
	},
	DemandID = 410835,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id836] =
{
	Id = 836,
	Name = "订购18X1",
	Desc = "需要一些18X",
	Value = 321654,
	Active = true,
	Weight = 33000,
	PreGoal = 
	{
		301559,
		301625,
	},
	CloseGoal = 
	{
		301670,
	},
	GoodsId = 8501654,
	Priority = 1655005,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 233889,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 24,
				},
				{
					Value = 1,
					Num = 26529,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 8,
				},
				{
					Value = 1,
					Num = 26529,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 61089,
				},
			},
		},
	},
	DemandID = 410836,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id837] =
{
	Id = 837,
	Name = "订购18X1",
	Desc = "需要一些18X",
	Value = 321654,
	Active = true,
	Weight = 34200,
	PreGoal = 
	{
		301559,
		301645,
	},
	CloseGoal = 
	{
		301690,
	},
	GoodsId = 8501654,
	Priority = 1655006,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 233889,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 24,
				},
				{
					Value = 1,
					Num = 26529,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 8,
				},
				{
					Value = 1,
					Num = 26529,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 61089,
				},
			},
		},
	},
	DemandID = 410837,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id838] =
{
	Id = 838,
	Name = "订购18X1",
	Desc = "需要一些18X",
	Value = 321654,
	Active = true,
	Weight = 35400,
	PreGoal = 
	{
		301559,
		301665,
	},
	CloseGoal = 
	{
		301715,
	},
	GoodsId = 8501654,
	Priority = 1655007,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 233889,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 24,
				},
				{
					Value = 1,
					Num = 26529,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 8,
				},
				{
					Value = 1,
					Num = 26529,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 61089,
				},
			},
		},
	},
	DemandID = 410838,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id839] =
{
	Id = 839,
	Name = "订购18X1",
	Desc = "需要一些18X",
	Value = 321654,
	Active = true,
	Weight = 36900,
	PreGoal = 
	{
		301559,
		301690,
	},
	GoodsId = 8501654,
	Priority = 1655008,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 233889,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 24,
				},
				{
					Value = 1,
					Num = 26529,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 8,
				},
				{
					Value = 1,
					Num = 26529,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 61089,
				},
			},
		},
	},
	DemandID = 410839,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id840] =
{
	Id = 840,
	Name = "订购18X1",
	Desc = "需要一些18X",
	Value = 321654,
	Active = false,
	Weight = 38400,
	PreGoal = 
	{
		301559,
		301715,
	},
	GoodsId = 8501654,
	Priority = 1655009,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 233889,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 24,
				},
				{
					Value = 1,
					Num = 26529,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 8,
				},
				{
					Value = 1,
					Num = 26529,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 61089,
				},
			},
		},
	},
	DemandID = 410840,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id841] =
{
	Id = 841,
	Name = "订购18X1",
	Desc = "需要一些18X",
	Value = 321654,
	Active = false,
	Weight = 39300,
	PreGoal = 
	{
		301559,
		301730,
	},
	GoodsId = 8501654,
	Priority = 1655010,
	Num = 12,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 233889,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 24,
				},
				{
					Value = 1,
					Num = 26529,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 8,
				},
				{
					Value = 1,
					Num = 26529,
				},
			},
		},
		{
			Weight = 40,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320003,
					Num = 2,
				},
				{
					Value = 1,
					Num = 61089,
				},
			},
		},
	},
	DemandID = 410841,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id842] =
{
	Id = 842,
	Name = "补充铁质",
	Desc = "最近一摔跤就骨折，医生建议我多补充铁质",
	Value = 321801,
	Active = true,
	Weight = 56180,
	PreGoal = 
	{
		301328,
	},
	CloseGoal = 
	{
		301640,
	},
	GoodsId = 8601801,
	Priority = 1802061,
	Num = 112,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 54252,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 461,
				},
				{
					Value = 1,
					Num = 8152,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 461,
				},
				{
					Value = 1,
					Num = 8152,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 92,
				},
				{
					Value = 1,
					Num = 8252,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 92,
				},
				{
					Value = 1,
					Num = 8252,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 18,
				},
				{
					Value = 1,
					Num = 9252,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 18,
				},
				{
					Value = 1,
					Num = 9252,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 3,
				},
				{
					Value = 1,
					Num = 16752,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 3,
				},
				{
					Value = 1,
					Num = 16752,
				},
			},
		},
	},
	DemandID = 410842,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id843] =
{
	Id = 843,
	Name = "时髦装饰",
	Desc = "从业多年，这次打算设计一款主打海洋风的饰品！",
	Value = 321801,
	Active = true,
	Weight = 57240,
	PreGoal = 
	{
		301327,
		301615,
	},
	CloseGoal = 
	{
		301650,
	},
	GoodsId = 8601801,
	Priority = 1802062,
	Num = 136,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 65878,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 559,
				},
				{
					Value = 1,
					Num = 9978,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 559,
				},
				{
					Value = 1,
					Num = 9978,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 111,
				},
				{
					Value = 1,
					Num = 10378,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 111,
				},
				{
					Value = 1,
					Num = 10378,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 22,
				},
				{
					Value = 1,
					Num = 10878,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 22,
				},
				{
					Value = 1,
					Num = 10878,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 15878,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 15878,
				},
			},
		},
	},
	DemandID = 410843,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id844] =
{
	Id = 844,
	Name = "海边救援",
	Desc = "啊，已经接到很多客人投诉了，请帮忙清理些海草。",
	Value = 321801,
	Active = true,
	Weight = 58300,
	PreGoal = 
	{
		301327,
		301625,
	},
	CloseGoal = 
	{
		301665,
	},
	GoodsId = 8601801,
	Priority = 1802063,
	Num = 162,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 78472,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 667,
				},
				{
					Value = 1,
					Num = 11772,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 667,
				},
				{
					Value = 1,
					Num = 11772,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 133,
				},
				{
					Value = 1,
					Num = 11972,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 133,
				},
				{
					Value = 1,
					Num = 11972,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 26,
				},
				{
					Value = 1,
					Num = 13472,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 26,
				},
				{
					Value = 1,
					Num = 13472,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 5,
				},
				{
					Value = 1,
					Num = 15972,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 5,
				},
				{
					Value = 1,
					Num = 15972,
				},
			},
		},
	},
	DemandID = 410844,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id845] =
{
	Id = 845,
	Name = "味增汤大师",
	Desc = "这次就用顶级的海草来给我的味增汤调味吧！",
	Value = 321801,
	Active = true,
	Weight = 59890,
	PreGoal = 
	{
		301327,
		301640,
	},
	CloseGoal = 
	{
		301680,
	},
	GoodsId = 8601801,
	Priority = 1802064,
	Num = 189,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 91551,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 778,
				},
				{
					Value = 1,
					Num = 13751,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 778,
				},
				{
					Value = 1,
					Num = 13751,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 155,
				},
				{
					Value = 1,
					Num = 14051,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 155,
				},
				{
					Value = 1,
					Num = 14051,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 31,
				},
				{
					Value = 1,
					Num = 14051,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 31,
				},
				{
					Value = 1,
					Num = 14051,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 6,
				},
				{
					Value = 1,
					Num = 16551,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 6,
				},
				{
					Value = 1,
					Num = 16551,
				},
			},
		},
	},
	DemandID = 410845,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id846] =
{
	Id = 846,
	Name = "补充铁质",
	Desc = "最近一摔跤就骨折，医生建议我多补充铁质",
	Value = 321801,
	Active = true,
	Weight = 61480,
	PreGoal = 
	{
		301327,
		301655,
	},
	CloseGoal = 
	{
		301700,
	},
	GoodsId = 8601801,
	Priority = 1802065,
	Num = 215,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 104146,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 885,
				},
				{
					Value = 1,
					Num = 15646,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 885,
				},
				{
					Value = 1,
					Num = 15646,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 177,
				},
				{
					Value = 1,
					Num = 15646,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 177,
				},
				{
					Value = 1,
					Num = 15646,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 35,
				},
				{
					Value = 1,
					Num = 16646,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 35,
				},
				{
					Value = 1,
					Num = 16646,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 7,
				},
				{
					Value = 1,
					Num = 16646,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 7,
				},
				{
					Value = 1,
					Num = 16646,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 624,
				},
				{
					Value = 320051,
					Num = 417,
				},
			},
		},
	},
	DemandID = 410846,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id847] =
{
	Id = 847,
	Name = "时髦装饰",
	Desc = "从业多年，这次打算设计一款主打海洋风的饰品！",
	Value = 321801,
	Active = true,
	Weight = 63600,
	PreGoal = 
	{
		301327,
		301675,
	},
	CloseGoal = 
	{
		301720,
	},
	GoodsId = 8601801,
	Priority = 1802066,
	Num = 240,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 116256,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 988,
				},
				{
					Value = 1,
					Num = 17456,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 988,
				},
				{
					Value = 1,
					Num = 17456,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 197,
				},
				{
					Value = 1,
					Num = 17756,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 197,
				},
				{
					Value = 1,
					Num = 17756,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 39,
				},
				{
					Value = 1,
					Num = 18756,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 39,
				},
				{
					Value = 1,
					Num = 18756,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 7,
				},
				{
					Value = 1,
					Num = 28756,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 7,
				},
				{
					Value = 1,
					Num = 28756,
				},
			},
		},
	},
	DemandID = 410847,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id848] =
{
	Id = 848,
	Name = "海边救援",
	Desc = "啊，已经接到很多客人投诉了，请帮忙清理些海草。",
	Value = 321801,
	Active = true,
	Weight = 65720,
	PreGoal = 
	{
		301327,
		301695,
	},
	GoodsId = 8601801,
	Priority = 1802067,
	Num = 266,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 128850,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 219,
				},
				{
					Value = 1,
					Num = 19350,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 219,
				},
				{
					Value = 1,
					Num = 19350,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 43,
				},
				{
					Value = 1,
					Num = 21350,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 43,
				},
				{
					Value = 1,
					Num = 21350,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 8,
				},
				{
					Value = 1,
					Num = 28850,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 8,
				},
				{
					Value = 1,
					Num = 28850,
				},
			},
		},
	},
	DemandID = 410848,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id849] =
{
	Id = 849,
	Name = "味增汤大师",
	Desc = "这次就用顶级的海草来给我的味增汤调味吧！",
	Value = 321801,
	Active = false,
	Weight = 68370,
	PreGoal = 
	{
		301327,
		301720,
	},
	GoodsId = 8601801,
	Priority = 1802068,
	Num = 292,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 141444,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 240,
				},
				{
					Value = 1,
					Num = 21444,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 240,
				},
				{
					Value = 1,
					Num = 21444,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 48,
				},
				{
					Value = 1,
					Num = 21444,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 48,
				},
				{
					Value = 1,
					Num = 21444,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 9,
				},
				{
					Value = 1,
					Num = 28944,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 9,
				},
				{
					Value = 1,
					Num = 28944,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 848,
				},
				{
					Value = 320051,
					Num = 566,
				},
			},
		},
	},
	DemandID = 410849,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id850] =
{
	Id = 850,
	Name = "补充铁质",
	Desc = "最近一摔跤就骨折，医生建议我多补充铁质",
	Value = 321801,
	Active = false,
	Weight = 69430,
	PreGoal = 
	{
		301327,
		301730,
	},
	GoodsId = 8601801,
	Priority = 1802069,
	Num = 316,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 153070,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 260,
				},
				{
					Value = 1,
					Num = 23070,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 260,
				},
				{
					Value = 1,
					Num = 23070,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 52,
				},
				{
					Value = 1,
					Num = 23070,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 52,
				},
				{
					Value = 1,
					Num = 23070,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 10,
				},
				{
					Value = 1,
					Num = 28070,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 10,
				},
				{
					Value = 1,
					Num = 28070,
				},
			},
		},
	},
	DemandID = 410850,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id851] =
{
	Id = 851,
	Name = "时髦装饰",
	Desc = "从业多年，这次打算设计一款主打海洋风的饰品！",
	Value = 321801,
	Active = false,
	Weight = 69430,
	PreGoal = 
	{
		301327,
		301730,
	},
	GoodsId = 8601801,
	Priority = 1802070,
	Num = 342,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 165664,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 281,
				},
				{
					Value = 1,
					Num = 25164,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 281,
				},
				{
					Value = 1,
					Num = 25164,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 56,
				},
				{
					Value = 1,
					Num = 25664,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 56,
				},
				{
					Value = 1,
					Num = 25664,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 11,
				},
				{
					Value = 1,
					Num = 28164,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 11,
				},
				{
					Value = 1,
					Num = 28164,
				},
			},
		},
	},
	DemandID = 410851,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id852] =
{
	Id = 852,
	Name = "加点装饰",
	Desc = "最近搬了新家，想要一些珊瑚作为装饰品。",
	Value = 321802,
	Active = true,
	Weight = 58320,
	PreGoal = 
	{
		301615,
	},
	CloseGoal = 
	{
		301650,
	},
	GoodsId = 8701802,
	Priority = 1803081,
	Num = 30,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 65034,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 552,
				},
				{
					Value = 1,
					Num = 9834,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 552,
				},
				{
					Value = 1,
					Num = 9834,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 110,
				},
				{
					Value = 1,
					Num = 10034,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 110,
				},
				{
					Value = 1,
					Num = 10034,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 22,
				},
				{
					Value = 1,
					Num = 10034,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 22,
				},
				{
					Value = 1,
					Num = 10034,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 15034,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 15034,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 390,
				},
				{
					Value = 320051,
					Num = 260,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 78,
				},
				{
					Value = 320052,
					Num = 52,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 15,
				},
				{
					Value = 320053,
					Num = 11,
				},
			},
		},
	},
	DemandID = 410852,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id853] =
{
	Id = 853,
	Name = "珊瑚首饰",
	Desc = "首饰批发厂打来电话，问最新的珊瑚什么时候送过去。",
	Value = 321802,
	Active = true,
	Weight = 59400,
	PreGoal = 
	{
		301615,
		301625,
	},
	CloseGoal = 
	{
		301660,
	},
	GoodsId = 8701802,
	Priority = 1803082,
	Num = 38,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 82377,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 700,
				},
				{
					Value = 1,
					Num = 12377,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 700,
				},
				{
					Value = 1,
					Num = 12377,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 140,
				},
				{
					Value = 1,
					Num = 12377,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 140,
				},
				{
					Value = 1,
					Num = 12377,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 28,
				},
				{
					Value = 1,
					Num = 12377,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 28,
				},
				{
					Value = 1,
					Num = 12377,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 5,
				},
				{
					Value = 1,
					Num = 19877,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 5,
				},
				{
					Value = 1,
					Num = 19877,
				},
			},
		},
	},
	DemandID = 410853,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id854] =
{
	Id = 854,
	Name = "加点装饰",
	Desc = "最近搬了新家，想要一些珊瑚作为装饰品。",
	Value = 321802,
	Active = true,
	Weight = 60480,
	PreGoal = 
	{
		301615,
		301635,
	},
	CloseGoal = 
	{
		301675,
	},
	GoodsId = 8701802,
	Priority = 1803083,
	Num = 45,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 97552,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 829,
				},
				{
					Value = 1,
					Num = 14652,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 829,
				},
				{
					Value = 1,
					Num = 14652,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 165,
				},
				{
					Value = 1,
					Num = 15052,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 165,
				},
				{
					Value = 1,
					Num = 15052,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 33,
				},
				{
					Value = 1,
					Num = 15052,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 33,
				},
				{
					Value = 1,
					Num = 15052,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 6,
				},
				{
					Value = 1,
					Num = 22552,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 6,
				},
				{
					Value = 1,
					Num = 22552,
				},
			},
		},
	},
	DemandID = 410854,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id855] =
{
	Id = 855,
	Name = "珊瑚首饰",
	Desc = "首饰批发厂打来电话，问最新的珊瑚什么时候送过去。",
	Value = 321802,
	Active = true,
	Weight = 62100,
	PreGoal = 
	{
		301615,
		301650,
	},
	CloseGoal = 
	{
		301690,
	},
	GoodsId = 8701802,
	Priority = 1803084,
	Num = 52,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 112727,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 958,
				},
				{
					Value = 1,
					Num = 16927,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 958,
				},
				{
					Value = 1,
					Num = 16927,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 191,
				},
				{
					Value = 1,
					Num = 17227,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 191,
				},
				{
					Value = 1,
					Num = 17227,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 38,
				},
				{
					Value = 1,
					Num = 17727,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 38,
				},
				{
					Value = 1,
					Num = 17727,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 7,
				},
				{
					Value = 1,
					Num = 25227,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 7,
				},
				{
					Value = 1,
					Num = 25227,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 676,
				},
				{
					Value = 320051,
					Num = 451,
				},
			},
		},
	},
	DemandID = 410855,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id856] =
{
	Id = 856,
	Name = "加点装饰",
	Desc = "最近搬了新家，想要一些珊瑚作为装饰品。",
	Value = 321802,
	Active = true,
	Weight = 63720,
	PreGoal = 
	{
		301615,
		301665,
	},
	CloseGoal = 
	{
		301710,
	},
	GoodsId = 8701802,
	Priority = 1803085,
	Num = 60,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 130069,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 221,
				},
				{
					Value = 1,
					Num = 19569,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 221,
				},
				{
					Value = 1,
					Num = 19569,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 44,
				},
				{
					Value = 1,
					Num = 20069,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 44,
				},
				{
					Value = 1,
					Num = 20069,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 8,
				},
				{
					Value = 1,
					Num = 30069,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 8,
				},
				{
					Value = 1,
					Num = 30069,
				},
			},
		},
	},
	DemandID = 410856,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id857] =
{
	Id = 857,
	Name = "珊瑚首饰",
	Desc = "首饰批发厂打来电话，问最新的珊瑚什么时候送过去。",
	Value = 321802,
	Active = true,
	Weight = 65880,
	PreGoal = 
	{
		301615,
		301685,
	},
	CloseGoal = 
	{
		301730,
	},
	GoodsId = 8701802,
	Priority = 1803086,
	Num = 66,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 143076,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 243,
				},
				{
					Value = 1,
					Num = 21576,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 243,
				},
				{
					Value = 1,
					Num = 21576,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 48,
				},
				{
					Value = 1,
					Num = 23076,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 48,
				},
				{
					Value = 1,
					Num = 23076,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 9,
				},
				{
					Value = 1,
					Num = 30576,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 9,
				},
				{
					Value = 1,
					Num = 30576,
				},
			},
		},
	},
	DemandID = 410857,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id858] =
{
	Id = 858,
	Name = "加点装饰",
	Desc = "最近搬了新家，想要一些珊瑚作为装饰品。",
	Value = 321802,
	Active = true,
	Weight = 68040,
	PreGoal = 
	{
		301615,
		301705,
	},
	GoodsId = 8701802,
	Priority = 1803087,
	Num = 74,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 160419,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 272,
				},
				{
					Value = 1,
					Num = 24419,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 272,
				},
				{
					Value = 1,
					Num = 24419,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 54,
				},
				{
					Value = 1,
					Num = 25419,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 54,
				},
				{
					Value = 1,
					Num = 25419,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 10,
				},
				{
					Value = 1,
					Num = 35419,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 10,
				},
				{
					Value = 1,
					Num = 35419,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 962,
				},
				{
					Value = 320051,
					Num = 642,
				},
			},
		},
	},
	DemandID = 410858,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id859] =
{
	Id = 859,
	Name = "珊瑚首饰",
	Desc = "首饰批发厂打来电话，问最新的珊瑚什么时候送过去。",
	Value = 321802,
	Active = false,
	Weight = 70740,
	PreGoal = 
	{
		301615,
		301730,
	},
	GoodsId = 8701802,
	Priority = 1803088,
	Num = 81,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 175594,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 298,
				},
				{
					Value = 1,
					Num = 26594,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 298,
				},
				{
					Value = 1,
					Num = 26594,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 59,
				},
				{
					Value = 1,
					Num = 28094,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 59,
				},
				{
					Value = 1,
					Num = 28094,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 11,
				},
				{
					Value = 1,
					Num = 38094,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 11,
				},
				{
					Value = 1,
					Num = 38094,
				},
			},
		},
	},
	DemandID = 410859,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id860] =
{
	Id = 860,
	Name = "加点装饰",
	Desc = "最近搬了新家，想要一些珊瑚作为装饰品。",
	Value = 321802,
	Active = false,
	Weight = 70740,
	PreGoal = 
	{
		301615,
		301730,
	},
	GoodsId = 8701802,
	Priority = 1803089,
	Num = 88,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 190769,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 324,
				},
				{
					Value = 1,
					Num = 28769,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 324,
				},
				{
					Value = 1,
					Num = 28769,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 64,
				},
				{
					Value = 1,
					Num = 30769,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 64,
				},
				{
					Value = 1,
					Num = 30769,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 12,
				},
				{
					Value = 1,
					Num = 40769,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 12,
				},
				{
					Value = 1,
					Num = 40769,
				},
			},
		},
	},
	DemandID = 410860,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id861] =
{
	Id = 861,
	Name = "珊瑚首饰",
	Desc = "首饰批发厂打来电话，问最新的珊瑚什么时候送过去。",
	Value = 321802,
	Active = false,
	Weight = 70740,
	PreGoal = 
	{
		301615,
		301730,
	},
	GoodsId = 8701802,
	Priority = 1803090,
	Num = 95,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 205943,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 350,
				},
				{
					Value = 1,
					Num = 30943,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 350,
				},
				{
					Value = 1,
					Num = 30943,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 70,
				},
				{
					Value = 1,
					Num = 30943,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 70,
				},
				{
					Value = 1,
					Num = 30943,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 14,
				},
				{
					Value = 1,
					Num = 30943,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 14,
				},
				{
					Value = 1,
					Num = 30943,
				},
			},
		},
	},
	DemandID = 410861,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id862] =
{
	Id = 862,
	Name = "珍珠奶茶",
	Desc = "好想喝珍珠奶茶啊，自己来做一杯吧。",
	Value = 321803,
	Active = true,
	Weight = 60500,
	PreGoal = 
	{
		301625,
	},
	CloseGoal = 
	{
		301660,
	},
	GoodsId = 8801803,
	Priority = 1804101,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 62861,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 534,
				},
				{
					Value = 1,
					Num = 9461,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 534,
				},
				{
					Value = 1,
					Num = 9461,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 106,
				},
				{
					Value = 1,
					Num = 9861,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 106,
				},
				{
					Value = 1,
					Num = 9861,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 21,
				},
				{
					Value = 1,
					Num = 10361,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 21,
				},
				{
					Value = 1,
					Num = 10361,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 12861,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 12861,
				},
			},
		},
	},
	DemandID = 410862,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id863] =
{
	Id = 863,
	Name = "真正的珍珠",
	Desc = "小猫说自己的便便和黑珍珠一样，让他看看真正的珍珠吧。",
	Value = 321803,
	Active = true,
	Weight = 61600,
	PreGoal = 
	{
		301625,
		301635,
	},
	CloseGoal = 
	{
		301670,
	},
	GoodsId = 8801803,
	Priority = 1804102,
	Num = 36,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 80821,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 686,
				},
				{
					Value = 1,
					Num = 12221,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 686,
				},
				{
					Value = 1,
					Num = 12221,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 137,
				},
				{
					Value = 1,
					Num = 12321,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 137,
				},
				{
					Value = 1,
					Num = 12321,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 27,
				},
				{
					Value = 1,
					Num = 13321,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 27,
				},
				{
					Value = 1,
					Num = 13321,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 5,
				},
				{
					Value = 1,
					Num = 18321,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 5,
				},
				{
					Value = 1,
					Num = 18321,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 484,
				},
				{
					Value = 320051,
					Num = 324,
				},
			},
		},
	},
	DemandID = 410863,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id864] =
{
	Id = 864,
	Name = "珍珠奶茶",
	Desc = "好想喝珍珠奶茶啊，自己来做一杯吧。",
	Value = 321803,
	Active = true,
	Weight = 62700,
	PreGoal = 
	{
		301625,
		301645,
	},
	CloseGoal = 
	{
		301685,
	},
	GoodsId = 8801803,
	Priority = 1804103,
	Num = 42,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 94291,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 801,
				},
				{
					Value = 1,
					Num = 14191,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 801,
				},
				{
					Value = 1,
					Num = 14191,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 160,
				},
				{
					Value = 1,
					Num = 14291,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 160,
				},
				{
					Value = 1,
					Num = 14291,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 32,
				},
				{
					Value = 1,
					Num = 14291,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 32,
				},
				{
					Value = 1,
					Num = 14291,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 6,
				},
				{
					Value = 1,
					Num = 19291,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 6,
				},
				{
					Value = 1,
					Num = 19291,
				},
			},
		},
	},
	DemandID = 410864,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id865] =
{
	Id = 865,
	Name = "真正的珍珠",
	Desc = "小猫说自己的便便和黑珍珠一样，让他看看真正的珍珠吧。",
	Value = 321803,
	Active = true,
	Weight = 64350,
	PreGoal = 
	{
		301625,
		301660,
	},
	CloseGoal = 
	{
		301700,
	},
	GoodsId = 8801803,
	Priority = 1804104,
	Num = 50,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 112252,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 954,
				},
				{
					Value = 1,
					Num = 16852,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 954,
				},
				{
					Value = 1,
					Num = 16852,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 190,
				},
				{
					Value = 1,
					Num = 17252,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 190,
				},
				{
					Value = 1,
					Num = 17252,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 38,
				},
				{
					Value = 1,
					Num = 17252,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 38,
				},
				{
					Value = 1,
					Num = 17252,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 7,
				},
				{
					Value = 1,
					Num = 24752,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 7,
				},
				{
					Value = 1,
					Num = 24752,
				},
			},
		},
	},
	DemandID = 410865,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id866] =
{
	Id = 866,
	Name = "珍珠奶茶",
	Desc = "好想喝珍珠奶茶啊，自己来做一杯吧。",
	Value = 321803,
	Active = true,
	Weight = 66000,
	PreGoal = 
	{
		301625,
		301675,
	},
	CloseGoal = 
	{
		301720,
	},
	GoodsId = 8801803,
	Priority = 1804105,
	Num = 56,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 125722,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 213,
				},
				{
					Value = 1,
					Num = 19222,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 213,
				},
				{
					Value = 1,
					Num = 19222,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 42,
				},
				{
					Value = 1,
					Num = 20722,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 42,
				},
				{
					Value = 1,
					Num = 20722,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 8,
				},
				{
					Value = 1,
					Num = 25722,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 8,
				},
				{
					Value = 1,
					Num = 25722,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 754,
				},
				{
					Value = 320051,
					Num = 503,
				},
			},
		},
	},
	DemandID = 410866,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id867] =
{
	Id = 867,
	Name = "真正的珍珠",
	Desc = "小猫说自己的便便和黑珍珠一样，让他看看真正的珍珠吧。",
	Value = 321803,
	Active = true,
	Weight = 68200,
	PreGoal = 
	{
		301625,
		301695,
	},
	GoodsId = 8801803,
	Priority = 1804106,
	Num = 63,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 141437,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 240,
				},
				{
					Value = 1,
					Num = 21437,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 240,
				},
				{
					Value = 1,
					Num = 21437,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 48,
				},
				{
					Value = 1,
					Num = 21437,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 48,
				},
				{
					Value = 1,
					Num = 21437,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 9,
				},
				{
					Value = 1,
					Num = 28937,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 9,
				},
				{
					Value = 1,
					Num = 28937,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 848,
				},
				{
					Value = 320051,
					Num = 566,
				},
			},
		},
	},
	DemandID = 410867,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id868] =
{
	Id = 868,
	Name = "珍珠奶茶",
	Desc = "好想喝珍珠奶茶啊，自己来做一杯吧。",
	Value = 321803,
	Active = false,
	Weight = 70400,
	PreGoal = 
	{
		301625,
		301715,
	},
	GoodsId = 8801803,
	Priority = 1804107,
	Num = 70,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 157152,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 267,
				},
				{
					Value = 1,
					Num = 23652,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 267,
				},
				{
					Value = 1,
					Num = 23652,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 53,
				},
				{
					Value = 1,
					Num = 24652,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 53,
				},
				{
					Value = 1,
					Num = 24652,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 10,
				},
				{
					Value = 1,
					Num = 32152,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 10,
				},
				{
					Value = 1,
					Num = 32152,
				},
			},
		},
	},
	DemandID = 410868,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id869] =
{
	Id = 869,
	Name = "真正的珍珠",
	Desc = "小猫说自己的便便和黑珍珠一样，让他看看真正的珍珠吧。",
	Value = 321803,
	Active = false,
	Weight = 72050,
	PreGoal = 
	{
		301625,
		301730,
	},
	GoodsId = 8801803,
	Priority = 1804108,
	Num = 76,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 170623,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 290,
				},
				{
					Value = 1,
					Num = 25623,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 290,
				},
				{
					Value = 1,
					Num = 25623,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 58,
				},
				{
					Value = 1,
					Num = 25623,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 58,
				},
				{
					Value = 1,
					Num = 25623,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 11,
				},
				{
					Value = 1,
					Num = 33123,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 11,
				},
				{
					Value = 1,
					Num = 33123,
				},
			},
		},
	},
	DemandID = 410869,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id870] =
{
	Id = 870,
	Name = "珍珠奶茶",
	Desc = "好想喝珍珠奶茶啊，自己来做一杯吧。",
	Value = 321803,
	Active = false,
	Weight = 72050,
	PreGoal = 
	{
		301625,
		301730,
	},
	GoodsId = 8801803,
	Priority = 1804109,
	Num = 82,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 184093,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 312,
				},
				{
					Value = 1,
					Num = 28093,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 312,
				},
				{
					Value = 1,
					Num = 28093,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 62,
				},
				{
					Value = 1,
					Num = 29093,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 62,
				},
				{
					Value = 1,
					Num = 29093,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 12,
				},
				{
					Value = 1,
					Num = 34093,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 12,
				},
				{
					Value = 1,
					Num = 34093,
				},
			},
		},
	},
	DemandID = 410870,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id871] =
{
	Id = 871,
	Name = "真正的珍珠",
	Desc = "小猫说自己的便便和黑珍珠一样，让他看看真正的珍珠吧。",
	Value = 321803,
	Active = false,
	Weight = 72050,
	PreGoal = 
	{
		301625,
		301730,
	},
	GoodsId = 8801803,
	Priority = 1804110,
	Num = 90,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 202053,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 343,
				},
				{
					Value = 1,
					Num = 30553,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 343,
				},
				{
					Value = 1,
					Num = 30553,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 68,
				},
				{
					Value = 1,
					Num = 32053,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 68,
				},
				{
					Value = 1,
					Num = 32053,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 13,
				},
				{
					Value = 1,
					Num = 39553,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 13,
				},
				{
					Value = 1,
					Num = 39553,
				},
			},
		},
	},
	DemandID = 410871,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id872] =
{
	Id = 872,
	Name = "深海鬼屋",
	Desc = "鬼屋明天就要开业了，需要快点把触手送过去。",
	Value = 321804,
	Active = true,
	Weight = 60500,
	PreGoal = 
	{
		301906,
		301625,
	},
	CloseGoal = 
	{
		301660,
	},
	GoodsId = 8901804,
	Priority = 1805101,
	Num = 95,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 68069,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 578,
				},
				{
					Value = 1,
					Num = 10269,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 578,
				},
				{
					Value = 1,
					Num = 10269,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 115,
				},
				{
					Value = 1,
					Num = 10569,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 115,
				},
				{
					Value = 1,
					Num = 10569,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 23,
				},
				{
					Value = 1,
					Num = 10569,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 23,
				},
				{
					Value = 1,
					Num = 10569,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 18069,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 18069,
				},
			},
		},
	},
	DemandID = 410872,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id873] =
{
	Id = 873,
	Name = "清洁工",
	Desc = "太恶心了，拜托帮我清理一下触手吧。",
	Value = 321804,
	Active = true,
	Weight = 61600,
	PreGoal = 
	{
		301906,
		301635,
	},
	CloseGoal = 
	{
		301670,
	},
	GoodsId = 8901804,
	Priority = 1805102,
	Num = 117,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 83832,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 712,
				},
				{
					Value = 1,
					Num = 12632,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 712,
				},
				{
					Value = 1,
					Num = 12632,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 142,
				},
				{
					Value = 1,
					Num = 12832,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 142,
				},
				{
					Value = 1,
					Num = 12832,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 28,
				},
				{
					Value = 1,
					Num = 13832,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 28,
				},
				{
					Value = 1,
					Num = 13832,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 5,
				},
				{
					Value = 1,
					Num = 21332,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 5,
				},
				{
					Value = 1,
					Num = 21332,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 502,
				},
				{
					Value = 320051,
					Num = 336,
				},
			},
		},
	},
	DemandID = 410873,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id874] =
{
	Id = 874,
	Name = "深海鬼屋",
	Desc = "鬼屋明天就要开业了，需要快点把触手送过去。",
	Value = 321804,
	Active = true,
	Weight = 62700,
	PreGoal = 
	{
		301906,
		301645,
	},
	CloseGoal = 
	{
		301685,
	},
	GoodsId = 8901804,
	Priority = 1805103,
	Num = 138,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 98879,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 840,
				},
				{
					Value = 1,
					Num = 14879,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 840,
				},
				{
					Value = 1,
					Num = 14879,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 168,
				},
				{
					Value = 1,
					Num = 14879,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 168,
				},
				{
					Value = 1,
					Num = 14879,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 33,
				},
				{
					Value = 1,
					Num = 16379,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 33,
				},
				{
					Value = 1,
					Num = 16379,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 6,
				},
				{
					Value = 1,
					Num = 23879,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 6,
				},
				{
					Value = 1,
					Num = 23879,
				},
			},
		},
	},
	DemandID = 410874,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id875] =
{
	Id = 875,
	Name = "清洁工",
	Desc = "太恶心了，拜托帮我清理一下触手吧。",
	Value = 321804,
	Active = true,
	Weight = 64350,
	PreGoal = 
	{
		301906,
		301660,
	},
	CloseGoal = 
	{
		301700,
	},
	GoodsId = 8901804,
	Priority = 1805104,
	Num = 160,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 114643,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 974,
				},
				{
					Value = 1,
					Num = 17243,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 974,
				},
				{
					Value = 1,
					Num = 17243,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 194,
				},
				{
					Value = 1,
					Num = 17643,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 194,
				},
				{
					Value = 1,
					Num = 17643,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 38,
				},
				{
					Value = 1,
					Num = 19643,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 38,
				},
				{
					Value = 1,
					Num = 19643,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 7,
				},
				{
					Value = 1,
					Num = 27143,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 7,
				},
				{
					Value = 1,
					Num = 27143,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 687,
				},
				{
					Value = 320051,
					Num = 459,
				},
			},
		},
	},
	DemandID = 410875,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id876] =
{
	Id = 876,
	Name = "深海鬼屋",
	Desc = "鬼屋明天就要开业了，需要快点把触手送过去。",
	Value = 321804,
	Active = true,
	Weight = 66000,
	PreGoal = 
	{
		301906,
		301675,
	},
	CloseGoal = 
	{
		301720,
	},
	GoodsId = 8901804,
	Priority = 1805105,
	Num = 182,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 130406,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 221,
				},
				{
					Value = 1,
					Num = 19906,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 221,
				},
				{
					Value = 1,
					Num = 19906,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 44,
				},
				{
					Value = 1,
					Num = 20406,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 44,
				},
				{
					Value = 1,
					Num = 20406,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 8,
				},
				{
					Value = 1,
					Num = 30406,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 8,
				},
				{
					Value = 1,
					Num = 30406,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 782,
				},
				{
					Value = 320051,
					Num = 522,
				},
			},
		},
	},
	DemandID = 410876,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id877] =
{
	Id = 877,
	Name = "清洁工",
	Desc = "太恶心了，拜托帮我清理一下触手吧。",
	Value = 321804,
	Active = true,
	Weight = 68200,
	PreGoal = 
	{
		301906,
		301695,
	},
	GoodsId = 8901804,
	Priority = 1805106,
	Num = 204,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 146170,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 248,
				},
				{
					Value = 1,
					Num = 22170,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 248,
				},
				{
					Value = 1,
					Num = 22170,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 49,
				},
				{
					Value = 1,
					Num = 23670,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 49,
				},
				{
					Value = 1,
					Num = 23670,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 9,
				},
				{
					Value = 1,
					Num = 33670,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 9,
				},
				{
					Value = 1,
					Num = 33670,
				},
			},
		},
	},
	DemandID = 410877,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id878] =
{
	Id = 878,
	Name = "深海鬼屋",
	Desc = "鬼屋明天就要开业了，需要快点把触手送过去。",
	Value = 321804,
	Active = false,
	Weight = 70400,
	PreGoal = 
	{
		301906,
		301715,
	},
	GoodsId = 8901804,
	Priority = 1805107,
	Num = 226,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 161933,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 275,
				},
				{
					Value = 1,
					Num = 24433,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 275,
				},
				{
					Value = 1,
					Num = 24433,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 55,
				},
				{
					Value = 1,
					Num = 24433,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 55,
				},
				{
					Value = 1,
					Num = 24433,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 11,
				},
				{
					Value = 1,
					Num = 24433,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 11,
				},
				{
					Value = 1,
					Num = 24433,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 971,
				},
				{
					Value = 320051,
					Num = 648,
				},
			},
		},
	},
	DemandID = 410878,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id879] =
{
	Id = 879,
	Name = "清洁工",
	Desc = "太恶心了，拜托帮我清理一下触手吧。",
	Value = 321804,
	Active = false,
	Weight = 72050,
	PreGoal = 
	{
		301906,
		301730,
	},
	GoodsId = 8901804,
	Priority = 1805108,
	Num = 248,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 177696,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 302,
				},
				{
					Value = 1,
					Num = 26696,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 302,
				},
				{
					Value = 1,
					Num = 26696,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 60,
				},
				{
					Value = 1,
					Num = 27696,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 60,
				},
				{
					Value = 1,
					Num = 27696,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 12,
				},
				{
					Value = 1,
					Num = 27696,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 12,
				},
				{
					Value = 1,
					Num = 27696,
				},
			},
		},
	},
	DemandID = 410879,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id880] =
{
	Id = 880,
	Name = "深海鬼屋",
	Desc = "鬼屋明天就要开业了，需要快点把触手送过去。",
	Value = 321804,
	Active = false,
	Weight = 72050,
	PreGoal = 
	{
		301906,
		301730,
	},
	GoodsId = 8901804,
	Priority = 1805109,
	Num = 268,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 192027,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 326,
				},
				{
					Value = 1,
					Num = 29027,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 326,
				},
				{
					Value = 1,
					Num = 29027,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 65,
				},
				{
					Value = 1,
					Num = 29527,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 65,
				},
				{
					Value = 1,
					Num = 29527,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 13,
				},
				{
					Value = 1,
					Num = 29527,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 13,
				},
				{
					Value = 1,
					Num = 29527,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 230,
				},
				{
					Value = 320052,
					Num = 154,
				},
			},
		},
	},
	DemandID = 410880,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id881] =
{
	Id = 881,
	Name = "清洁工",
	Desc = "太恶心了，拜托帮我清理一下触手吧。",
	Value = 321804,
	Active = false,
	Weight = 72050,
	PreGoal = 
	{
		301906,
		301730,
	},
	GoodsId = 8901804,
	Priority = 1805110,
	Num = 291,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 208507,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 354,
				},
				{
					Value = 1,
					Num = 31507,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 354,
				},
				{
					Value = 1,
					Num = 31507,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 70,
				},
				{
					Value = 1,
					Num = 33507,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 70,
				},
				{
					Value = 1,
					Num = 33507,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 14,
				},
				{
					Value = 1,
					Num = 33507,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 14,
				},
				{
					Value = 1,
					Num = 33507,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 250,
				},
				{
					Value = 320052,
					Num = 167,
				},
			},
		},
	},
	DemandID = 410881,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id882] =
{
	Id = 882,
	Name = "偶像应援",
	Desc = "偶像的演唱会快到了，应援的物品绝对不能少！",
	Value = 321805,
	Active = true,
	Weight = 63845,
	PreGoal = 
	{
		301640,
	},
	CloseGoal = 
	{
		301675,
	},
	GoodsId = 9001805,
	Priority = 1806131,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 65432,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 556,
				},
				{
					Value = 1,
					Num = 9832,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 556,
				},
				{
					Value = 1,
					Num = 9832,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 111,
				},
				{
					Value = 1,
					Num = 9932,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 111,
				},
				{
					Value = 1,
					Num = 9932,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 22,
				},
				{
					Value = 1,
					Num = 10432,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 22,
				},
				{
					Value = 1,
					Num = 10432,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 15432,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 15432,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 392,
				},
				{
					Value = 320051,
					Num = 262,
				},
			},
		},
	},
	DemandID = 410882,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id883] =
{
	Id = 883,
	Name = "禁止黄牛",
	Desc = "有人花重金收购偶像的应援物品，所以我打算，嘿嘿……",
	Value = 321805,
	Active = true,
	Weight = 64975,
	PreGoal = 
	{
		301640,
		301650,
	},
	CloseGoal = 
	{
		301685,
	},
	GoodsId = 9001805,
	Priority = 1806132,
	Num = 36,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 84127,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 715,
				},
				{
					Value = 1,
					Num = 12627,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 715,
				},
				{
					Value = 1,
					Num = 12627,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 143,
				},
				{
					Value = 1,
					Num = 12627,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 143,
				},
				{
					Value = 1,
					Num = 12627,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 28,
				},
				{
					Value = 1,
					Num = 14127,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 28,
				},
				{
					Value = 1,
					Num = 14127,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 5,
				},
				{
					Value = 1,
					Num = 21627,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 5,
				},
				{
					Value = 1,
					Num = 21627,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 504,
				},
				{
					Value = 320051,
					Num = 337,
				},
			},
		},
	},
	DemandID = 410883,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id884] =
{
	Id = 884,
	Name = "偶像应援",
	Desc = "偶像的演唱会快到了，应援的物品绝对不能少！",
	Value = 321805,
	Active = true,
	Weight = 66105,
	PreGoal = 
	{
		301640,
		301660,
	},
	CloseGoal = 
	{
		301700,
	},
	GoodsId = 9001805,
	Priority = 1806133,
	Num = 42,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 98148,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 834,
				},
				{
					Value = 1,
					Num = 14748,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 834,
				},
				{
					Value = 1,
					Num = 14748,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 166,
				},
				{
					Value = 1,
					Num = 15148,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 166,
				},
				{
					Value = 1,
					Num = 15148,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 33,
				},
				{
					Value = 1,
					Num = 15648,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 33,
				},
				{
					Value = 1,
					Num = 15648,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 6,
				},
				{
					Value = 1,
					Num = 23148,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 6,
				},
				{
					Value = 1,
					Num = 23148,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 588,
				},
				{
					Value = 320051,
					Num = 393,
				},
			},
		},
	},
	DemandID = 410884,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id885] =
{
	Id = 885,
	Name = "禁止黄牛",
	Desc = "有人花重金收购偶像的应援物品，所以我打算，嘿嘿……",
	Value = 321805,
	Active = true,
	Weight = 67800,
	PreGoal = 
	{
		301640,
		301675,
	},
	CloseGoal = 
	{
		301715,
	},
	GoodsId = 9001805,
	Priority = 1806134,
	Num = 50,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 116844,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 993,
				},
				{
					Value = 1,
					Num = 17544,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 993,
				},
				{
					Value = 1,
					Num = 17544,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 198,
				},
				{
					Value = 1,
					Num = 17844,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 198,
				},
				{
					Value = 1,
					Num = 17844,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 39,
				},
				{
					Value = 1,
					Num = 19344,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 39,
				},
				{
					Value = 1,
					Num = 19344,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 7,
				},
				{
					Value = 1,
					Num = 29344,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 7,
				},
				{
					Value = 1,
					Num = 29344,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 701,
				},
				{
					Value = 320051,
					Num = 467,
				},
			},
		},
	},
	DemandID = 410885,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id886] =
{
	Id = 886,
	Name = "偶像应援",
	Desc = "偶像的演唱会快到了，应援的物品绝对不能少！",
	Value = 321805,
	Active = true,
	Weight = 69495,
	PreGoal = 
	{
		301640,
		301690,
	},
	GoodsId = 9001805,
	Priority = 1806135,
	Num = 56,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 130865,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 222,
				},
				{
					Value = 1,
					Num = 19865,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 222,
				},
				{
					Value = 1,
					Num = 19865,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 44,
				},
				{
					Value = 1,
					Num = 20865,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 44,
				},
				{
					Value = 1,
					Num = 20865,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 8,
				},
				{
					Value = 1,
					Num = 30865,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 8,
				},
				{
					Value = 1,
					Num = 30865,
				},
			},
		},
	},
	DemandID = 410886,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id887] =
{
	Id = 887,
	Name = "禁止黄牛",
	Desc = "有人花重金收购偶像的应援物品，所以我打算，嘿嘿……",
	Value = 321805,
	Active = false,
	Weight = 71755,
	PreGoal = 
	{
		301640,
		301710,
	},
	GoodsId = 9001805,
	Priority = 1806136,
	Num = 63,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 147223,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 250,
				},
				{
					Value = 1,
					Num = 22223,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 250,
				},
				{
					Value = 1,
					Num = 22223,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 50,
				},
				{
					Value = 1,
					Num = 22223,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 50,
				},
				{
					Value = 1,
					Num = 22223,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 10,
				},
				{
					Value = 1,
					Num = 22223,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 10,
				},
				{
					Value = 1,
					Num = 22223,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 883,
				},
				{
					Value = 320051,
					Num = 589,
				},
			},
		},
	},
	DemandID = 410887,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id888] =
{
	Id = 888,
	Name = "偶像应援",
	Desc = "偶像的演唱会快到了，应援的物品绝对不能少！",
	Value = 321805,
	Active = false,
	Weight = 74015,
	PreGoal = 
	{
		301640,
		301730,
	},
	GoodsId = 9001805,
	Priority = 1806137,
	Num = 70,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 163581,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 278,
				},
				{
					Value = 1,
					Num = 24581,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 278,
				},
				{
					Value = 1,
					Num = 24581,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 55,
				},
				{
					Value = 1,
					Num = 26081,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 55,
				},
				{
					Value = 1,
					Num = 26081,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 11,
				},
				{
					Value = 1,
					Num = 26081,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 11,
				},
				{
					Value = 1,
					Num = 26081,
				},
			},
		},
	},
	DemandID = 410888,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id889] =
{
	Id = 889,
	Name = "禁止黄牛",
	Desc = "有人花重金收购偶像的应援物品，所以我打算，嘿嘿……",
	Value = 321805,
	Active = false,
	Weight = 74015,
	PreGoal = 
	{
		301640,
		301730,
	},
	GoodsId = 9001805,
	Priority = 1806138,
	Num = 76,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 177602,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 301,
				},
				{
					Value = 1,
					Num = 27102,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 301,
				},
				{
					Value = 1,
					Num = 27102,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 60,
				},
				{
					Value = 1,
					Num = 27602,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 60,
				},
				{
					Value = 1,
					Num = 27602,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 12,
				},
				{
					Value = 1,
					Num = 27602,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 12,
				},
				{
					Value = 1,
					Num = 27602,
				},
			},
		},
	},
	DemandID = 410889,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id890] =
{
	Id = 890,
	Name = "偶像应援",
	Desc = "偶像的演唱会快到了，应援的物品绝对不能少！",
	Value = 321805,
	Active = false,
	Weight = 74015,
	PreGoal = 
	{
		301640,
		301730,
	},
	GoodsId = 9001805,
	Priority = 1806139,
	Num = 82,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 191624,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 325,
				},
				{
					Value = 1,
					Num = 29124,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 325,
				},
				{
					Value = 1,
					Num = 29124,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 65,
				},
				{
					Value = 1,
					Num = 29124,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 65,
				},
				{
					Value = 1,
					Num = 29124,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 13,
				},
				{
					Value = 1,
					Num = 29124,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 13,
				},
				{
					Value = 1,
					Num = 29124,
				},
			},
		},
	},
	DemandID = 410890,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id891] =
{
	Id = 891,
	Name = "禁止黄牛",
	Desc = "有人花重金收购偶像的应援物品，所以我打算，嘿嘿……",
	Value = 321805,
	Active = false,
	Weight = 74015,
	PreGoal = 
	{
		301640,
		301730,
	},
	GoodsId = 9001805,
	Priority = 1806140,
	Num = 90,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 210319,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 357,
				},
				{
					Value = 1,
					Num = 31819,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 357,
				},
				{
					Value = 1,
					Num = 31819,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 71,
				},
				{
					Value = 1,
					Num = 32819,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 71,
				},
				{
					Value = 1,
					Num = 32819,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 14,
				},
				{
					Value = 1,
					Num = 35319,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 14,
				},
				{
					Value = 1,
					Num = 35319,
				},
			},
		},
	},
	DemandID = 410891,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id892] =
{
	Id = 892,
	Name = "童话城堡",
	Desc = "我最近想要建造一座梦幻岛，请给我一些美丽的礁石吧。",
	Value = 321806,
	Active = true,
	Weight = 67280,
	PreGoal = 
	{
		301655,
	},
	CloseGoal = 
	{
		301690,
	},
	GoodsId = 9101806,
	Priority = 1807161,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 67737,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 575,
				},
				{
					Value = 1,
					Num = 10237,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 575,
				},
				{
					Value = 1,
					Num = 10237,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 115,
				},
				{
					Value = 1,
					Num = 10237,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 115,
				},
				{
					Value = 1,
					Num = 10237,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 23,
				},
				{
					Value = 1,
					Num = 10237,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 23,
				},
				{
					Value = 1,
					Num = 10237,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 4,
				},
				{
					Value = 1,
					Num = 17737,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 4,
				},
				{
					Value = 1,
					Num = 17737,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 406,
				},
				{
					Value = 320051,
					Num = 271,
				},
			},
		},
	},
	DemandID = 410892,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id893] =
{
	Id = 893,
	Name = "检验锤子",
	Desc = "我新买了一把金锤子，为了检验是否坚硬，需要一些礁石。",
	Value = 321806,
	Active = true,
	Weight = 68440,
	PreGoal = 
	{
		301655,
		301665,
	},
	CloseGoal = 
	{
		301700,
	},
	GoodsId = 9101806,
	Priority = 1807162,
	Num = 34,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 82252,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 699,
				},
				{
					Value = 1,
					Num = 12352,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 699,
				},
				{
					Value = 1,
					Num = 12352,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 139,
				},
				{
					Value = 1,
					Num = 12752,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 139,
				},
				{
					Value = 1,
					Num = 12752,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 27,
				},
				{
					Value = 1,
					Num = 14752,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 27,
				},
				{
					Value = 1,
					Num = 14752,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 5,
				},
				{
					Value = 1,
					Num = 19752,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 5,
				},
				{
					Value = 1,
					Num = 19752,
				},
			},
		},
	},
	DemandID = 410893,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id894] =
{
	Id = 894,
	Name = "童话城堡",
	Desc = "我最近想要建造一座梦幻岛，请给我一些美丽的礁石吧。",
	Value = 321806,
	Active = true,
	Weight = 69600,
	PreGoal = 
	{
		301655,
		301675,
	},
	CloseGoal = 
	{
		301715,
	},
	GoodsId = 9101806,
	Priority = 1807163,
	Num = 40,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 96768,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 822,
				},
				{
					Value = 1,
					Num = 14568,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 822,
				},
				{
					Value = 1,
					Num = 14568,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 164,
				},
				{
					Value = 1,
					Num = 14768,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 164,
				},
				{
					Value = 1,
					Num = 14768,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 32,
				},
				{
					Value = 1,
					Num = 16768,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 32,
				},
				{
					Value = 1,
					Num = 16768,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 6,
				},
				{
					Value = 1,
					Num = 21768,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 6,
				},
				{
					Value = 1,
					Num = 21768,
				},
			},
		},
	},
	DemandID = 410894,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id895] =
{
	Id = 895,
	Name = "检验锤子",
	Desc = "我新买了一把金锤子，为了检验是否坚硬，需要一些礁石。",
	Value = 321806,
	Active = true,
	Weight = 71340,
	PreGoal = 
	{
		301655,
		301690,
	},
	CloseGoal = 
	{
		301730,
	},
	GoodsId = 9101806,
	Priority = 1807164,
	Num = 46,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 111283,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 945,
				},
				{
					Value = 1,
					Num = 16783,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 945,
				},
				{
					Value = 1,
					Num = 16783,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 189,
				},
				{
					Value = 1,
					Num = 16783,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 189,
				},
				{
					Value = 1,
					Num = 16783,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 37,
				},
				{
					Value = 1,
					Num = 18783,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 37,
				},
				{
					Value = 1,
					Num = 18783,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 7,
				},
				{
					Value = 1,
					Num = 23783,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 7,
				},
				{
					Value = 1,
					Num = 23783,
				},
			},
		},
	},
	DemandID = 410895,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id896] =
{
	Id = 896,
	Name = "童话城堡",
	Desc = "我最近想要建造一座梦幻岛，请给我一些美丽的礁石吧。",
	Value = 321806,
	Active = true,
	Weight = 73080,
	PreGoal = 
	{
		301655,
		301705,
	},
	GoodsId = 9101806,
	Priority = 1807165,
	Num = 52,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 125798,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 213,
				},
				{
					Value = 1,
					Num = 19298,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 213,
				},
				{
					Value = 1,
					Num = 19298,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 42,
				},
				{
					Value = 1,
					Num = 20798,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 42,
				},
				{
					Value = 1,
					Num = 20798,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 8,
				},
				{
					Value = 1,
					Num = 25798,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 8,
				},
				{
					Value = 1,
					Num = 25798,
				},
			},
		},
	},
	DemandID = 410896,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id897] =
{
	Id = 897,
	Name = "检验锤子",
	Desc = "我新买了一把金锤子，为了检验是否坚硬，需要一些礁石。",
	Value = 321806,
	Active = false,
	Weight = 75400,
	PreGoal = 
	{
		301655,
		301725,
	},
	GoodsId = 9101806,
	Priority = 1807166,
	Num = 58,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 140313,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 238,
				},
				{
					Value = 1,
					Num = 21313,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 238,
				},
				{
					Value = 1,
					Num = 21313,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 47,
				},
				{
					Value = 1,
					Num = 22813,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 47,
				},
				{
					Value = 1,
					Num = 22813,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 9,
				},
				{
					Value = 1,
					Num = 27813,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 9,
				},
				{
					Value = 1,
					Num = 27813,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 841,
				},
				{
					Value = 320051,
					Num = 562,
				},
			},
		},
	},
	DemandID = 410897,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id898] =
{
	Id = 898,
	Name = "童话城堡",
	Desc = "我最近想要建造一座梦幻岛，请给我一些美丽的礁石吧。",
	Value = 321806,
	Active = false,
	Weight = 75980,
	PreGoal = 
	{
		301655,
		301730,
	},
	GoodsId = 9101806,
	Priority = 1807167,
	Num = 66,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 159667,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 271,
				},
				{
					Value = 1,
					Num = 24167,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 271,
				},
				{
					Value = 1,
					Num = 24167,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 54,
				},
				{
					Value = 1,
					Num = 24667,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 54,
				},
				{
					Value = 1,
					Num = 24667,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 10,
				},
				{
					Value = 1,
					Num = 34667,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 10,
				},
				{
					Value = 1,
					Num = 34667,
				},
			},
		},
	},
	DemandID = 410898,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id899] =
{
	Id = 899,
	Name = "检验锤子",
	Desc = "我新买了一把金锤子，为了检验是否坚硬，需要一些礁石。",
	Value = 321806,
	Active = false,
	Weight = 75980,
	PreGoal = 
	{
		301655,
		301730,
	},
	GoodsId = 9101806,
	Priority = 1807168,
	Num = 72,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 174182,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 296,
				},
				{
					Value = 1,
					Num = 26182,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 296,
				},
				{
					Value = 1,
					Num = 26182,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 59,
				},
				{
					Value = 1,
					Num = 26682,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 59,
				},
				{
					Value = 1,
					Num = 26682,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 11,
				},
				{
					Value = 1,
					Num = 36682,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 11,
				},
				{
					Value = 1,
					Num = 36682,
				},
			},
		},
	},
	DemandID = 410899,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id900] =
{
	Id = 900,
	Name = "童话城堡",
	Desc = "我最近想要建造一座梦幻岛，请给我一些美丽的礁石吧。",
	Value = 321806,
	Active = false,
	Weight = 75980,
	PreGoal = 
	{
		301655,
		301730,
	},
	GoodsId = 9101806,
	Priority = 1807169,
	Num = 78,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 188697,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 320,
				},
				{
					Value = 1,
					Num = 28697,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 320,
				},
				{
					Value = 1,
					Num = 28697,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 64,
				},
				{
					Value = 1,
					Num = 28697,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 64,
				},
				{
					Value = 1,
					Num = 28697,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 12,
				},
				{
					Value = 1,
					Num = 38697,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 12,
				},
				{
					Value = 1,
					Num = 38697,
				},
			},
		},
	},
	DemandID = 410900,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
