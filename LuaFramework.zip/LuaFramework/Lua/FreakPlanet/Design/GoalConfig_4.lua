
GoalConfig[GoalID.Id1201] =
{
	Id = 1201,
	Name = "主线309 - 追赶三花猫",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130151,
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]2个[-][62E7E7]风元素[-]队员(或宠物)的队伍探索悬疑星[FDDE40]着陆点[-]18小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 64800,
			TagList = 
			{
				561204,
			},
			CharacterNum = 2,
			Value = 130151,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1202] =
{
	Id = 1202,
	Name = "主线310 - 小猫的成长",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130151,
		PreGoal = 
		{
			301201,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "虽然有危险，但是一路上还算顺利喵~\n[FDDE40]呜呜[-]、[FDDE40]漆漆[-]达到3阶。",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 2,
			TagList = 
			{
				561309,
			},
			Value = -1,
			Stage = 3,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1203] =
{
	Id = 1203,
	Name = "主线311 - 热闹的街道",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130151,
		PreGoal = 
		{
			301202,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]呜呜[-]、[62E7E7]漆漆[-]探索悬疑星[FDDE40]着陆点[-]18小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 64800,
			Character = 
			{
				220001,
				220002,
			},
			Value = 130151,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1204] =
{
	Id = 1204,
	Name = "主线312 - 流浪三花猫的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130151,
		PreGoal = 
		{
			301203,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败着陆点的[FDDE40]流浪三花猫[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140601,
		},
	},
	Reward = {
		{
			Value = 130152,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1205] =
{
	Id = 1205,
	Name = "主线313 - 成群的小猫",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130152,
		PreGoal = 
		{
			301204,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]1[-][62E7E7]悬疑星[-]队员(或宠物)的队伍在探索中击败[FDDE40]三花猫[-]600个，建议探索17小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 600,
			TagList = 
			{
				560106,
			},
			CharacterNum = 1,
			Value = 242084,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1206] =
{
	Id = 1206,
	Name = "主线314 - 冒险的旅费8",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130152,
		PreGoal = 
		{
			301205,
		},
	},
	GoalTrigger = 
	{
		TriggerType.DemandReward,
	},
	GoalCondition = 
	{
		{
			Name = "完成[62E7E7]委托[-]获得[FDDE40]金币[-]300000个",
			Type = ItemType.Gold,
			CountType = GoalCountType.StartNow,
			Num = 300000,
			Value = 1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1207] =
{
	Id = 1207,
	Name = "主线315 - 队员的成长",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130152,
		PreGoal = 
		{
			301206,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]50级[-][FDDE40]角色[-]1个",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = -1,
			Level = 50,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1208] =
{
	Id = 1208,
	Name = "主线316 - 告白情书的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130152,
		PreGoal = 
		{
			301207,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败甜心街的[FDDE40]告白情书[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140602,
		},
	},
	CompleteSpeech = 30120801,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1209] =
{
	Id = 1209,
	Name = "主线317 - 了解案情",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130152,
		PreGoal = 
		{
			301208,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]呜呜[-]、[62E7E7]漆漆[-]探索悬疑星[FDDE40]甜心街[-]18小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 64800,
			Character = 
			{
				220001,
				220002,
			},
			Value = 130152,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1210] =
{
	Id = 1210,
	Name = "主线318 - 强化装备9",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130152,
		PreGoal = 
		{
			301209,
		},
	},
	GoalTrigger = 
	{
		TriggerType.UpgradeEquipment,
	},
	GoalCondition = 
	{
		{
			Name = "强化[62E7E7]任意[-][FDDE40]装备[-]120次",
			Type = ItemType.Equipment,
			CountType = GoalCountType.Current,
			Num = 120,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1211] =
{
	Id = 1211,
	Name = "主线319 - 想说却无法开口",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130152,
		PreGoal = 
		{
			301210,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中获得[FDDE40]暗恋[-]40个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 40,
			Value = 321601,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1212] =
{
	Id = 1212,
	Name = "主线320 - 粉红女士的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130152,
		PreGoal = 
		{
			301211,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败甜心街的[FDDE40]粉红女士[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140603,
		},
	},
	CompleteSpeech = 30121201,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1213] =
{
	Id = 1213,
	Name = "主线321 - 寻找邮筒",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130152,
		PreGoal = 
		{
			301212,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]呜呜[-]、[62E7E7]漆漆[-]探索悬疑星[FDDE40]甜心街[-]18小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 64800,
			Character = 
			{
				220001,
				220002,
			},
			Value = 130152,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1214] =
{
	Id = 1214,
	Name = "主线322 - 拒绝表白",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130152,
		PreGoal = 
		{
			301213,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]情书[-]100个，建议探索19小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 100,
			Value = 242087,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1215] =
{
	Id = 1215,
	Name = "主线323 - 未寄出的信",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130152,
		PreGoal = 
		{
			301214,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]情书[-]8个(需要超市的空瓶)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 8,
			Value = 250087,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1216] =
{
	Id = 1216,
	Name = "主线324 - 网红邮筒的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130152,
		PreGoal = 
		{
			301215,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败甜心街的[FDDE40]网红邮筒[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140604,
		},
	},
	CompleteSpeech = 30121601,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1217] =
{
	Id = 1217,
	Name = "主线325 - 外星游客",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130152,
		PreGoal = 
		{
			301216,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]3个[-][62E7E7]非悬疑星[-]队员(或宠物)的队伍探索悬疑星[FDDE40]甜心街[-]23小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 82800,
			TagList = 
			{
				560206,
			},
			CharacterNum = 3,
			Value = 130152,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1218] =
{
	Id = 1218,
	Name = "主线326 - 拆除设施",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130152,
		PreGoal = 
		{
			301217,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]邮筒[-]30个，建议探索22小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 30,
			Value = 242089,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1219] =
{
	Id = 1219,
	Name = "主线327 - 够分量的客人",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130152,
		PreGoal = 
		{
			301218,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]3阶[-][FDDE40]角色[-]5个",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 5,
			Value = -1,
			Stage = 3,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1220] =
{
	Id = 1220,
	Name = "主线328 - 报童的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130152,
		PreGoal = 
		{
			301219,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败甜心街的[FDDE40]报童[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140605,
		},
	},
	CompleteSpeech = 30122001,
	Reward = {
		{
			Value = 130154,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1221] =
{
	Id = 1221,
	Name = "主线329 - 诗与远方",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130154,
		PreGoal = 
		{
			301220,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]1个[-][62E7E7]紫色及以上品质[-]、[62E7E7]风元素[-]队员(或宠物)的队伍探索悬疑星[FDDE40]邮局[-]12小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 43200,
			TagList = 
			{
				560034,
				561204,
			},
			CharacterNum = 1,
			Value = 130154,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1222] =
{
	Id = 1222,
	Name = "主线330 - 事务所打工2",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130154,
		PreGoal = 
		{
			301221,
		},
	},
	GoalTrigger = 
	{
		TriggerType.WorkShopRank,
	},
	GoalCondition = 
	{
		{
			Name = "在[FDDE40]事务所[-]打工获得[FDDE40]B[-]或更高评价",
			Type = ItemType.WorkShop,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 160004,
			Rank = 15,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1223] =
{
	Id = 1223,
	Name = "主线331 - 淘气的三花猫",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130154,
		PreGoal = 
		{
			301222,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "探索[62E7E7]邮局[-]击败[FDDE40]三花猫[-]350个，建议探索22小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 350,
			Value = 242084,
			Area = 130154,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1224] =
{
	Id = 1224,
	Name = "主线332 - 进口羽毛笔的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130154,
		PreGoal = 
		{
			301223,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败邮局的[FDDE40]进口羽毛笔[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140609,
		},
	},
	CompleteSpeech = 30122401,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1225] =
{
	Id = 1225,
	Name = "主线333 - 邮票将发售！",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130154,
		PreGoal = 
		{
			301224,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]1个[-][62E7E7]紫色及以上品质[-]、[62E7E7]水元素[-]队员(或宠物)的队伍探索悬疑星[FDDE40]邮局[-]12小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 43200,
			TagList = 
			{
				560034,
				561202,
			},
			CharacterNum = 1,
			Value = 130154,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1226] =
{
	Id = 1226,
	Name = "主线334 - 寄往远方",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130154,
		PreGoal = 
		{
			301225,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中获得[FDDE40]羽毛[-]25个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 25,
			Value = 321603,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1227] =
{
	Id = 1227,
	Name = "主线335 - 收集零件5",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130154,
		PreGoal = 
		{
			301226,
		},
	},
	GoalTrigger = 
	{
		TriggerType.DemandReward,
	},
	GoalCondition = 
	{
		{
			Name = "完成[62E7E7]委托[-]获得[62E7E7]A级零件[-]道具5个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 5,
			TagList = 
			{
				564355,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1228] =
{
	Id = 1228,
	Name = "主线336 - 纪念邮票的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130154,
		PreGoal = 
		{
			301227,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败邮局的[FDDE40]纪念邮票[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140610,
		},
	},
	CompleteSpeech = 30122801,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1229] =
{
	Id = 1229,
	Name = "主线337 - 投递邮件",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130154,
		PreGoal = 
		{
			301228,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]1个[-][62E7E7]紫色及以上品质[-]、[62E7E7]火元素[-]队员(或宠物)的队伍探索悬疑星[FDDE40]邮局[-]23小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 82800,
			TagList = 
			{
				560034,
				561203,
			},
			CharacterNum = 1,
			Value = 130154,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1230] =
{
	Id = 1230,
	Name = "主线338 - 收集邮票",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130154,
		PreGoal = 
		{
			301229,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]邮票[-]10个(需要警察局的纸袋)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 10,
			Value = 250093,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1231] =
{
	Id = 1231,
	Name = "主线339 - 书写邮件",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130154,
		PreGoal = 
		{
			301230,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "携带[62E7E7]邮票[-]探索悬疑星[FDDE40]邮局[-]23小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 82800,
			Pet = 250093,
			Value = 130154,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1232] =
{
	Id = 1232,
	Name = "主线340 - 精致信封的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130154,
		PreGoal = 
		{
			301231,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败邮局的[FDDE40]精致信封[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140611,
		},
	},
	CompleteSpeech = 30123201,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1233] =
{
	Id = 1233,
	Name = "主线341 - 翻查信件",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130154,
		PreGoal = 
		{
			301232,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]信封[-]25个，建议探索23小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 25,
			Value = 242094,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1234] =
{
	Id = 1234,
	Name = "主线342 - 特别新闻",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130154,
		PreGoal = 
		{
			301233,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]报童[-]探索悬疑星[FDDE40]邮局[-]23小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 82800,
			Character = 
			{
				220301,
			},
			Value = 130154,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1235] =
{
	Id = 1235,
	Name = "主线343 - 控制现场",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130154,
		PreGoal = 
		{
			301234,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]3个[-]队员(或宠物)的队伍探索悬疑星[FDDE40]邮局[-]23小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 82800,
			CharacterNum = 3,
			Value = 130154,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1236] =
{
	Id = 1236,
	Name = "主线344 - 侦探助理的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130154,
		PreGoal = 
		{
			301235,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败邮局的[FDDE40]侦探助理[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140612,
		},
	},
	CompleteSpeech = 30123601,
	Reward = {
		{
			Value = 130155,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1237] =
{
	Id = 1237,
	Name = "主线345 - 传说的助理",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130155,
		PreGoal = 
		{
			301236,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]3阶[-][FDDE40]侦探助理[-]",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220320,
			Stage = 3,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1238] =
{
	Id = 1238,
	Name = "主线346 - 侦探的法宝",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130155,
		PreGoal = 
		{
			301237,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有[FDDE40]放大镜[-](侦探助理装备)",
			Type = ItemType.Equipment,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 340278,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1239] =
{
	Id = 1239,
	Name = "主线347 - 无人的小街",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130155,
		PreGoal = 
		{
			301238,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]侦探助理[-]探索悬疑星[FDDE40]冷清街[-]12小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 43200,
			Character = 
			{
				220320,
			},
			Value = 130155,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1240] =
{
	Id = 1240,
	Name = "主线348 - 可疑门牌的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130155,
		PreGoal = 
		{
			301239,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败冷清街的[FDDE40]可疑门牌[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140613,
		},
	},
	CompleteSpeech = 30124001,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1241] =
{
	Id = 1241,
	Name = "主线349 - 阴冷的气氛",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130155,
		PreGoal = 
		{
			301240,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]1个[-][62E7E7]紫色及以上品质[-]、[62E7E7]暗元素[-]队员(或宠物)的队伍探索悬疑星[FDDE40]冷清街[-]23小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 82800,
			TagList = 
			{
				560034,
				561206,
			},
			CharacterNum = 1,
			Value = 130155,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1242] =
{
	Id = 1242,
	Name = "主线350 - 强化装备10",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130155,
		PreGoal = 
		{
			301241,
		},
	},
	GoalTrigger = 
	{
		TriggerType.UpgradeEquipment,
	},
	GoalCondition = 
	{
		{
			Name = "强化[62E7E7]任意[-][FDDE40]装备[-]150次",
			Type = ItemType.Equipment,
			CountType = GoalCountType.Current,
			Num = 150,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1243] =
{
	Id = 1243,
	Name = "主线351 - 逮捕小猫",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130155,
		PreGoal = 
		{
			301242,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "捕获宠物[FDDE40]三花猫[-]10个(需要事务所的纸板箱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.StartNow,
			Num = 10,
			Value = 250084,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1244] =
{
	Id = 1244,
	Name = "主线352 - 可疑路障的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130155,
		PreGoal = 
		{
			301243,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败冷清街的[FDDE40]可疑路障[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140614,
		},
	},
	CompleteSpeech = 30124401,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1245] =
{
	Id = 1245,
	Name = "主线353 - 寻找白猫",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130155,
		PreGoal = 
		{
			301244,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "携带[62E7E7]三花猫[-]探索悬疑星[FDDE40]冷清街[-]23小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 82800,
			Pet = 250084,
			Value = 130155,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1246] =
{
	Id = 1246,
	Name = "主线354 - 豪华美食",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130155,
		PreGoal = 
		{
			301245,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Craft,
	},
	GoalCondition = 
	{
		{
			Name = "在实验室合成获得[FDDE40]豪华便当[-]2个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 2,
			Value = 320412,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1247] =
{
	Id = 1247,
	Name = "主线355 - 猫猫的友谊",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130155,
		PreGoal = 
		{
			301246,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]呜呜[-]、[62E7E7]漆漆[-]探索悬疑星[FDDE40]冷清街[-]23小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 82800,
			Character = 
			{
				220001,
				220002,
			},
			Value = 130155,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1248] =
{
	Id = 1248,
	Name = "主线356 - 流浪白猫的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130155,
		PreGoal = 
		{
			301247,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败冷清街的[FDDE40]流浪白猫[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140615,
		},
	},
	CompleteSpeech = 30124801,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1249] =
{
	Id = 1249,
	Name = "主线357 - 继续前进",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130155,
		PreGoal = 
		{
			301248,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]呜呜[-]、[62E7E7]漆漆[-]探索悬疑星[FDDE40]冷清街[-]23小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 82800,
			Character = 
			{
				220001,
				220002,
			},
			Value = 130155,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1250] =
{
	Id = 1250,
	Name = "主线358 - 调皮的白猫",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130155,
		PreGoal = 
		{
			301249,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]白猫[-]30个，建议探索22小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 30,
			Value = 242085,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1251] =
{
	Id = 1251,
	Name = "主线359 - 丢失的钥匙",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130155,
		PreGoal = 
		{
			301250,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中获得[FDDE40]钥匙[-]30个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 30,
			Value = 321604,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1252] =
{
	Id = 1252,
	Name = "主线360 - 可疑煤气灯的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130155,
		PreGoal = 
		{
			301251,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败冷清街的[FDDE40]可疑煤气灯[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140616,
		},
	},
	CompleteSpeech = 30125201,
	Reward = {
		{
			Value = 130157,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1253] =
{
	Id = 1253,
	Name = "主线361 - Fake News",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130157,
		PreGoal = 
		{
			301252,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]报纸[-]120个，建议探索23小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 120,
			Value = 242090,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1254] =
{
	Id = 1254,
	Name = "主线362 - 冒险的旅费9",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130157,
		PreGoal = 
		{
			301253,
		},
	},
	GoalTrigger = 
	{
		TriggerType.DemandReward,
	},
	GoalCondition = 
	{
		{
			Name = "完成[62E7E7]委托[-]获得[FDDE40]金币[-]400000个",
			Type = ItemType.Gold,
			CountType = GoalCountType.StartNow,
			Num = 400000,
			Value = 1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1255] =
{
	Id = 1255,
	Name = "主线363 - 寻找烟灰缸",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130157,
		PreGoal = 
		{
			301254,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]1个[-][62E7E7]紫色及以上品质[-]、[62E7E7]火元素[-]队员(或宠物)的队伍探索悬疑星[FDDE40]警局[-]23小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 82800,
			TagList = 
			{
				560034,
				561203,
			},
			CharacterNum = 1,
			Value = 130157,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1256] =
{
	Id = 1256,
	Name = "主线364 - 超硬烟灰缸的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130157,
		PreGoal = 
		{
			301255,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败警局的[FDDE40]超硬烟灰缸[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140621,
		},
	},
	CompleteSpeech = 30125601,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1257] =
{
	Id = 1257,
	Name = "主线365 - 清理烟头",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130157,
		PreGoal = 
		{
			301256,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中获得[FDDE40]烟头[-]20个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 20,
			Value = 321606,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1258] =
{
	Id = 1258,
	Name = "主线366 - 火热的队员",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130157,
		PreGoal = 
		{
			301257,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]3阶[-][62E7E7]火元素[-][FDDE40]角色[-]5个",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 5,
			Value = -1,
			Stage = 3,
			Element = 210002,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1259] =
{
	Id = 1259,
	Name = "主线367 - 寻找手铐",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130157,
		PreGoal = 
		{
			301258,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]1个[-][62E7E7]紫色及以上品质[-]、[62E7E7]光元素[-]队员(或宠物)的队伍探索悬疑星[FDDE40]警局[-]23小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 82800,
			TagList = 
			{
				560034,
				561205,
			},
			CharacterNum = 1,
			Value = 130157,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1260] =
{
	Id = 1260,
	Name = "主线368 - 超合金手铐的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130157,
		PreGoal = 
		{
			301259,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败警局的[FDDE40]超合金手铐[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140622,
		},
	},
	CompleteSpeech = 30126001,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1261] =
{
	Id = 1261,
	Name = "主线369 - 寻找打火机",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130157,
		PreGoal = 
		{
			301260,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]1个[-][62E7E7]紫色及以上品质[-]、[62E7E7]水元素[-]队员(或宠物)的队伍探索悬疑星[FDDE40]警局[-]23小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 82800,
			TagList = 
			{
				560034,
				561202,
			},
			CharacterNum = 1,
			Value = 130157,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1262] =
{
	Id = 1262,
	Name = "主线370 - 修理门牌",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130157,
		PreGoal = 
		{
			301261,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "捕获宠物[FDDE40]门牌[-]5个(需要事务所的工具箱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.StartNow,
			Num = 5,
			Value = 250095,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1263] =
{
	Id = 1263,
	Name = "主线371 - 修理手铐",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130157,
		PreGoal = 
		{
			301262,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "捕获宠物[FDDE40]手铐[-]5个(需要事务所的纸板箱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.StartNow,
			Num = 5,
			Value = 250102,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1264] =
{
	Id = 1264,
	Name = "主线372 - 手工打火机的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130157,
		PreGoal = 
		{
			301263,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败警局的[FDDE40]手工打火机[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140623,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1265] =
{
	Id = 1265,
	Name = "主线373 - 侦探的对话",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130157,
		PreGoal = 
		{
			301264,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]侦探助理[-]探索悬疑星[FDDE40]警局[-]23小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 82800,
			Character = 
			{
				220320,
			},
			Value = 130157,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1266] =
{
	Id = 1266,
	Name = "主线374 - 查询记录",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130157,
		PreGoal = 
		{
			301265,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]8级[-][FDDE40]案件笔记[-](侦探助理装备)",
			Type = ItemType.Equipment,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 340277,
			Level = 8,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1267] =
{
	Id = 1267,
	Name = "主线375 - 对决的一刻",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130157,
		PreGoal = 
		{
			301266,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有[62E7E7]紫色及以上品质[-]至少[62E7E7]3阶[-][FDDE40]角色[-]5个",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 5,
			Value = -1,
			Rarity = 3,
			Stage = 3,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1268] =
{
	Id = 1268,
	Name = "主线376 - 蓝衣小学生的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130157,
		PreGoal = 
		{
			301267,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败警局的[FDDE40]蓝衣小学生[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140624,
		},
	},
	CompleteSpeech = 30126801,
	Reward = {
		{
			Value = 130158,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1269] =
{
	Id = 1269,
	Name = "主线377 - 小学生侦探",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130158,
		PreGoal = 
		{
			301268,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]3阶[-][FDDE40]蓝衣小学生[-]",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220322,
			Stage = 3,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1270] =
{
	Id = 1270,
	Name = "主线378 - 科学探案",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130158,
		PreGoal = 
		{
			301269,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]4级[-][FDDE40]高科技眼镜[-](蓝衣小学生装备)",
			Type = ItemType.Equipment,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 340283,
			Level = 4,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1271] =
{
	Id = 1271,
	Name = "主线379 - 绝对直觉",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130158,
		PreGoal = 
		{
			301270,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]蓝衣小学生[-]探索悬疑星[FDDE40]证物仓库[-]23小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 82800,
			Character = 
			{
				220322,
			},
			Value = 130158,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1272] =
{
	Id = 1272,
	Name = "主线380 - 超清相片的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130158,
		PreGoal = 
		{
			301271,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败证物仓库的[FDDE40]超清相片[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140625,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1273] =
{
	Id = 1273,
	Name = "主线381 - 捣蛋的小猫",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130158,
		PreGoal = 
		{
			301272,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "探索[62E7E7]证物仓库[-]击败[FDDE40]三花猫[-]240个，建议探索23小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 240,
			Value = 242084,
			Area = 130158,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1274] =
{
	Id = 1274,
	Name = "主线382 - 无声潜入",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130158,
		PreGoal = 
		{
			301273,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]1个[-][62E7E7]紫色及以上品质[-]、[62E7E7]暗元素[-]队员(或宠物)的队伍探索悬疑星[FDDE40]证物仓库[-]23小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 82800,
			TagList = 
			{
				560034,
				561206,
			},
			CharacterNum = 1,
			Value = 130158,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1275] =
{
	Id = 1275,
	Name = "主线383 - 收集证物",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130158,
		PreGoal = 
		{
			301274,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中获得[FDDE40]指纹[-]30个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 30,
			Value = 321607,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1276] =
{
	Id = 1276,
	Name = "主线384 - 超分贝报警器的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130158,
		PreGoal = 
		{
			301275,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败证物仓库的[FDDE40]超分贝报警器[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140626,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1277] =
{
	Id = 1277,
	Name = "主线385 - 查验证物",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130158,
		PreGoal = 
		{
			301276,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]豆豆警官[-]、[62E7E7]侦探助理[-]探索悬疑星[FDDE40]证物仓库[-]23小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 82800,
			Character = 
			{
				220316,
				220320,
			},
			Value = 130158,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1278] =
{
	Id = 1278,
	Name = "主线386 - 依次排查",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130158,
		PreGoal = 
		{
			301277,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "探索[62E7E7]证物仓库[-]击败[FDDE40]相片[-]90个，建议探索23小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 90,
			Value = 242104,
			Area = 130158,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1279] =
{
	Id = 1279,
	Name = "主线387 - 排除证物",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130158,
		PreGoal = 
		{
			301278,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计拥有[62E7E7]悬疑星[-][FDDE40]宠物[-]8种",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 8,
			TagList = 
			{
				560106,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1280] =
{
	Id = 1280,
	Name = "主线388 - 死者手机的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130158,
		PreGoal = 
		{
			301279,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败证物仓库的[FDDE40]死者手机[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140627,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1281] =
{
	Id = 1281,
	Name = "主线389 - 深入案件",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130158,
		PreGoal = 
		{
			301280,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]2个[-][62E7E7]金色及以上品质[-]队员(或宠物)的队伍探索悬疑星[FDDE40]证物仓库[-]47小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 169200,
			TagList = 
			{
				560035,
			},
			CharacterNum = 2,
			Value = 130158,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1282] =
{
	Id = 1282,
	Name = "主线390 - 收集零件6",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130158,
		PreGoal = 
		{
			301281,
		},
	},
	GoalTrigger = 
	{
		TriggerType.DemandReward,
	},
	GoalCondition = 
	{
		{
			Name = "完成[62E7E7]委托[-]获得[62E7E7]B级及以上零件[-]道具60个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 60,
			TagList = 
			{
				564364,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1283] =
{
	Id = 1283,
	Name = "主线391 - 切断报警器",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130158,
		PreGoal = 
		{
			301282,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "探索[62E7E7]证物仓库[-]击败[FDDE40]报警器[-]60个，建议探索22小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 60,
			Value = 242105,
			Area = 130158,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1284] =
{
	Id = 1284,
	Name = "主线392 - 天价勒索信的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130158,
		PreGoal = 
		{
			301283,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败证物仓库的[FDDE40]天价勒索信[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140628,
		},
	},
	CompleteSpeech = 30128401,
	Reward = {
		{
			Value = 130159,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1285] =
{
	Id = 1285,
	Name = "主线393 - 潜入审讯室",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130159,
		PreGoal = 
		{
			301284,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]1个[-][62E7E7]紫色及以上品质[-]、[62E7E7]暗元素[-]队员(或宠物)的队伍探索悬疑星[FDDE40]审讯大厅[-]12小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 43200,
			TagList = 
			{
				560034,
				561206,
			},
			CharacterNum = 1,
			Value = 130159,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1286] =
{
	Id = 1286,
	Name = "主线394 - 强化装备11",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130159,
		PreGoal = 
		{
			301285,
		},
	},
	GoalTrigger = 
	{
		TriggerType.UpgradeEquipment,
	},
	GoalCondition = 
	{
		{
			Name = "强化[62E7E7]任意[-][FDDE40]装备[-]180次",
			Type = ItemType.Equipment,
			CountType = GoalCountType.Current,
			Num = 180,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1287] =
{
	Id = 1287,
	Name = "主线395 - 记录工具",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130159,
		PreGoal = 
		{
			301286,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]羽毛笔[-]5个(需要警察局的纸袋)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 5,
			Value = 250092,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1288] =
{
	Id = 1288,
	Name = "主线396 - 进口蓝墨水的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130159,
		PreGoal = 
		{
			301287,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败审讯大厅的[FDDE40]进口蓝墨水[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140629,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1289] =
{
	Id = 1289,
	Name = "主线397 - 侦探出击",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130159,
		PreGoal = 
		{
			301288,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]侦探助理[-]、[62E7E7]蓝衣小学生[-]探索悬疑星[FDDE40]审讯大厅[-]23小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 82800,
			Character = 
			{
				220320,
				220322,
			},
			Value = 130159,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1290] =
{
	Id = 1290,
	Name = "主线398 - 物证在此！",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130159,
		PreGoal = 
		{
			301289,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计拥有[62E7E7]悬疑星[-]、[62E7E7]暗元素[-][FDDE40]宠物[-]3种",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 3,
			TagList = 
			{
				560106,
				561206,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1291] =
{
	Id = 1291,
	Name = "主线399 - 清理墨水",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130159,
		PreGoal = 
		{
			301290,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]蓝墨水[-]85个，建议探索23小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 85,
			Value = 242108,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1292] =
{
	Id = 1292,
	Name = "主线400 - 进口红墨水的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130159,
		PreGoal = 
		{
			301291,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败审讯大厅的[FDDE40]进口红墨水[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140630,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1293] =
{
	Id = 1293,
	Name = "主线401 - 继续审讯",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130159,
		PreGoal = 
		{
			301292,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]侦探助理[-]、[62E7E7]蓝衣小学生[-]探索悬疑星[FDDE40]审讯大厅[-]23小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 82800,
			Character = 
			{
				220320,
				220322,
			},
			Value = 130159,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1294] =
{
	Id = 1294,
	Name = "主线402 - 记录口供",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130159,
		PreGoal = 
		{
			301293,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]蓝墨水[-]10个(需要超市的空瓶)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 10,
			Value = 250108,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1295] =
{
	Id = 1295,
	Name = "主线403 - 问询时的压迫感",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130159,
		PreGoal = 
		{
			301294,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有[62E7E7]紫色及以上品质[-]至少[62E7E7]3阶[-][FDDE40]角色[-]10个",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 10,
			Value = -1,
			Rarity = 3,
			Stage = 3,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1296] =
{
	Id = 1296,
	Name = "主线404 - 办案的经费",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130159,
		PreGoal = 
		{
			301295,
		},
	},
	GoalTrigger = 
	{
		TriggerType.DemandReward,
	},
	GoalCondition = 
	{
		{
			Name = "完成[62E7E7]委托[-]获得[FDDE40]金币[-]250000个",
			Type = ItemType.Gold,
			CountType = GoalCountType.StartNow,
			Num = 250000,
			Value = 1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1297] =
{
	Id = 1297,
	Name = "主线405 - 证人的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130159,
		PreGoal = 
		{
			301296,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败审讯大厅的[FDDE40]证人[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140631,
		},
	},
	CompleteSpeech = 30129701,
	Reward = {
		{
			Value = 130161,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1298] =
{
	Id = 1298,
	Name = "主线406 - 最新连载",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130161,
		PreGoal = 
		{
			301297,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]侦探助理[-]探索悬疑星[FDDE40]编辑部[-]23小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 82800,
			Character = 
			{
				220320,
			},
			Value = 130161,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1299] =
{
	Id = 1299,
	Name = "主线407 - 事务所打工3",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130161,
		PreGoal = 
		{
			301298,
		},
	},
	GoalTrigger = 
	{
		TriggerType.WorkShopRank,
	},
	GoalCondition = 
	{
		{
			Name = "在[FDDE40]事务所[-]打工获得[FDDE40]A[-]或更高评价",
			Type = ItemType.WorkShop,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 160004,
			Rank = 18,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1300] =
{
	Id = 1300,
	Name = "主线408 - 书友会",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130161,
		PreGoal = 
		{
			301299,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "探索[62E7E7]编辑部[-]击败[FDDE40]蓝墨水[-]55个，建议探索11小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 55,
			Value = 242108,
			Area = 130161,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1301] =
{
	Id = 1301,
	Name = "主线409 - 精装水果笔记的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130161,
		PreGoal = 
		{
			301300,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败编辑部的[FDDE40]精装水果笔记[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140634,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1302] =
{
	Id = 1302,
	Name = "主线410 - 最后的拼图",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130161,
		PreGoal = 
		{
			301301,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "提交[FDDE40]黄瓜马赛克[-]30个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 30,
			Value = 321610,
		},
	},
	CompleteSpeech = 30130201,
	Reward = {
		{
			Value = 130162,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1303] =
{
	Id = 1303,
	Name = "主线411 - 查阅资料",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130161,
		PreGoal = 
		{
			301302,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]5个[-][62E7E7]紫色及以上品质[-]队员(或宠物)的队伍探索悬疑星[FDDE40]编辑部[-]24小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 86400,
			TagList = 
			{
				560034,
			},
			CharacterNum = 5,
			Value = 130161,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1304] =
{
	Id = 1304,
	Name = "主线412 - 熄灭烟头",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130161,
		PreGoal = 
		{
			301303,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "探索[62E7E7]编辑部[-]击败[FDDE40]烟灰缸[-]85个，建议探索23小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 85,
			Value = 242101,
			Area = 130161,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1305] =
{
	Id = 1305,
	Name = "主线413 - 收集资料1",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130161,
		PreGoal = 
		{
			301304,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "捕获宠物[FDDE40]水果笔记[-]8个(需要事务所的纸板箱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.StartNow,
			Num = 8,
			Value = 250112,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1306] =
{
	Id = 1306,
	Name = "主线414 - 精装蔬菜笔记的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130161,
		PreGoal = 
		{
			301305,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败编辑部的[FDDE40]精装蔬菜笔记[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140635,
		},
	},
	CompleteSpeech = 30130601,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1307] =
{
	Id = 1307,
	Name = "主线415 - 交稿期",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130161,
		PreGoal = 
		{
			301306,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]阿加莎[-]探索悬疑星[FDDE40]编辑部[-]47小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 169200,
			Character = 
			{
				220302,
			},
			Value = 130161,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1308] =
{
	Id = 1308,
	Name = "主线416 - 收集资料2",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130161,
		PreGoal = 
		{
			301307,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "捕获宠物[FDDE40]蔬菜笔记[-]3个(需要事务所的纸板箱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.StartNow,
			Num = 3,
			Value = 250113,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1309] =
{
	Id = 1309,
	Name = "主线417 - 特别素材",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130161,
		PreGoal = 
		{
			301308,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Craft,
	},
	GoalCondition = 
	{
		{
			Name = "在实验室合成获得[FDDE40]18X[-]10个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 10,
			Value = 321654,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1310] =
{
	Id = 1310,
	Name = "主线418 - 编辑长的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130161,
		PreGoal = 
		{
			301309,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败编辑部的[FDDE40]编辑长[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140636,
		},
	},
	CompleteSpeech = 30131001,
	Reward = {
		{
			Value = 130162,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1311] =
{
	Id = 1311,
	Name = "主线419 - 正义之光",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130162,
		PreGoal = 
		{
			301310,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]3阶[-][62E7E7]光元素[-][FDDE40]角色[-]5个",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 5,
			Value = -1,
			Stage = 3,
			Element = 210004,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1312] =
{
	Id = 1312,
	Name = "主线420 - 聚焦光线",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130162,
		PreGoal = 
		{
			301311,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]3个[-][62E7E7]光元素[-]队员(或宠物)的队伍探索悬疑星[FDDE40]侦探街[-]23小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 82800,
			TagList = 
			{
				561205,
			},
			CharacterNum = 3,
			Value = 130162,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1313] =
{
	Id = 1313,
	Name = "主线421 - 光学反应",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130162,
		PreGoal = 
		{
			301312,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计拥有[62E7E7]紫色及以上品质[-]、[62E7E7]光元素[-][FDDE40]宠物[-]8种",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 8,
			TagList = 
			{
				560034,
				561205,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1314] =
{
	Id = 1314,
	Name = "主线422 - 高倍放大镜的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130162,
		PreGoal = 
		{
			301313,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败侦探街的[FDDE40]高倍放大镜[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140637,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1315] =
{
	Id = 1315,
	Name = "主线423 - 悬疑星高级委托",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130162,
		PreGoal = 
		{
			301314,
		},
	},
	GoalTrigger = 
	{
		TriggerType.DemandCost,
	},
	GoalCondition = 
	{
		{
			Name = "在委托中提交[62E7E7]合成的[-]、[62E7E7]悬疑星[-]道具10个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 10,
			TagList = 
			{
				560005,
				560106,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1316] =
{
	Id = 1316,
	Name = "主线424 - 时间点",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130162,
		PreGoal = 
		{
			301315,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]3个[-][62E7E7]紫色及以上品质[-]、[62E7E7]悬疑星[-]队员(或宠物)的队伍探索悬疑星[FDDE40]侦探街[-]23小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 82800,
			TagList = 
			{
				560034,
				560106,
			},
			CharacterNum = 3,
			Value = 130162,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1317] =
{
	Id = 1317,
	Name = "主线425 - 侦探的工具",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130162,
		PreGoal = 
		{
			301316,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]放大镜[-]10个(需要事务所的纸板箱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 10,
			Value = 250114,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1318] =
{
	Id = 1318,
	Name = "主线426 - 祖传怀表的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130162,
		PreGoal = 
		{
			301317,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败侦探街的[FDDE40]祖传怀表[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140638,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1319] =
{
	Id = 1319,
	Name = "主线427 - 湿漉漉的烟草",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130162,
		PreGoal = 
		{
			301318,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]2个[-][62E7E7]紫色及以上品质[-]、[62E7E7]水元素[-]队员(或宠物)的队伍探索悬疑星[FDDE40]侦探街[-]23小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 82800,
			TagList = 
			{
				560034,
				561202,
			},
			CharacterNum = 2,
			Value = 130162,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1320] =
{
	Id = 1320,
	Name = "主线428 - 准确计时",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130162,
		PreGoal = 
		{
			301319,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "捕获宠物[FDDE40]怀表[-]5个(需要事务所的纸板箱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.StartNow,
			Num = 5,
			Value = 250115,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1321] =
{
	Id = 1321,
	Name = "主线429 - 灵感爆发",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130162,
		PreGoal = 
		{
			301320,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中获得[FDDE40]灵感[-]30个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 30,
			Value = 321611,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1322] =
{
	Id = 1322,
	Name = "主线430 - 祖传烟斗的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130162,
		PreGoal = 
		{
			301321,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败侦探街的[FDDE40]祖传烟斗[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140639,
		},
	},
	CompleteSpeech = 30132201,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1323] =
{
	Id = 1323,
	Name = "主线431 - 接近真相",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130162,
		PreGoal = 
		{
			301322,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]1个[-][62E7E7]暗元素[-]队员(或宠物)的队伍探索悬疑星[FDDE40]侦探街[-]23小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 82800,
			TagList = 
			{
				561206,
			},
			CharacterNum = 1,
			Value = 130162,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1324] =
{
	Id = 1324,
	Name = "主线432 - 嫌犯的线索",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130162,
		PreGoal = 
		{
			301323,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Craft,
	},
	GoalCondition = 
	{
		{
			Name = "在实验室合成获得[FDDE40]肖像侧写[-]30个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 30,
			Value = 321652,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1325] =
{
	Id = 1325,
	Name = "主线433 - 揭开谜底",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130162,
		PreGoal = 
		{
			301324,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]5个[-][62E7E7]悬疑星[-]队员(或宠物)的队伍探索悬疑星[FDDE40]侦探街[-]23小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 82800,
			TagList = 
			{
				560106,
			},
			CharacterNum = 5,
			Value = 130162,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1326] =
{
	Id = 1326,
	Name = "主线434 - 真相只有一个",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130162,
		PreGoal = 
		{
			301325,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]50级[-][FDDE40]蓝衣小学生[-]",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220322,
			Level = 50,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1327] =
{
	Id = 1327,
	Name = "主线435 - 凶手的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130162,
		PreGoal = 
		{
			301326,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败侦探街的[FDDE40]凶手[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140640,
		},
	},
	CompleteSpeech = 30132701,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1328] =
{
	Id = 1328,
	Name = "主线436 - 下一站，海洋星！",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130162,
		PreGoal = 
		{
			301327,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "喵？蓝蓝的星球，似乎在哪里见过喵~\n提交[FDDE40]灵感[-]20个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 321611,
		},
	},
	CompleteSpeech = 30132801,
	Reward = {
		{
			Value = 130201,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id1501] =
{
	Id = 1501,
	Name = "解锁：咖啡馆",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130152,
		PreGoal = 
		{
			301216,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "听说这家咖啡馆是本地居民经常去的~\n累计拥有[62E7E7]悬疑星[-][FDDE40]宠物[-]2种",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 2,
			TagList = 
			{
				560106,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 130153,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1502] =
{
	Id = 1502,
	Name = "支线-骑行",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130153,
		PreGoal = 
		{
			301501,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]5级[-][FDDE40]自行车[-](报童装备)",
			Type = ItemType.Equipment,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 340230,
			Level = 5,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1503] =
{
	Id = 1503,
	Name = "支线-寻找报纸",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130153,
		PreGoal = 
		{
			301502,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]报童[-]探索悬疑星[FDDE40]咖啡馆[-]23小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 82800,
			Character = 
			{
				220301,
			},
			Value = 130153,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1504] =
{
	Id = 1504,
	Name = "支线-捕捉猫咪",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130153,
		PreGoal = 
		{
			301503,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]三花猫[-]5个(需要事务所的纸板箱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 5,
			Value = 250084,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1505] =
{
	Id = 1505,
	Name = "支线-重磅新闻的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130153,
		PreGoal = 
		{
			301504,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败咖啡馆的[FDDE40]重磅新闻[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140606,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1506] =
{
	Id = 1506,
	Name = "支线-报童的成长",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130153,
		PreGoal = 
		{
			301505,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]3阶[-][FDDE40]报童[-]",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220301,
			Stage = 3,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1507] =
{
	Id = 1507,
	Name = "支线-时事闲谈",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130153,
		PreGoal = 
		{
			301506,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中获得[FDDE40]新闻[-]20个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 20,
			Value = 321602,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1508] =
{
	Id = 1508,
	Name = "支线-优雅的客人",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130153,
		PreGoal = 
		{
			301507,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]2个[-][62E7E7]悬疑星[-]、[62E7E7]女性[-]队员(或宠物)的队伍探索悬疑星[FDDE40]咖啡馆[-]23小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 82800,
			TagList = 
			{
				560106,
				561703,
			},
			CharacterNum = 2,
			Value = 130153,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1509] =
{
	Id = 1509,
	Name = "支线-帽子绅士的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130153,
		PreGoal = 
		{
			301508,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败咖啡馆的[FDDE40]帽子绅士[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140607,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1510] =
{
	Id = 1510,
	Name = "支线-驱赶闲杂人等",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130153,
		PreGoal = 
		{
			301509,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]礼帽[-]25个，建议探索31小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 25,
			Value = 242091,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1511] =
{
	Id = 1511,
	Name = "支线-旅行经历",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130153,
		PreGoal = 
		{
			301510,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "携带[62E7E7]礼帽[-]探索悬疑星[FDDE40]咖啡馆[-]30小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 108000,
			Pet = 250091,
			Value = 130153,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1512] =
{
	Id = 1512,
	Name = "支线-灵感之兽",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130153,
		PreGoal = 
		{
			301511,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]白猫[-]5个(需要事务所的纸板箱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 5,
			Value = 250085,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1513] =
{
	Id = 1513,
	Name = "支线-阿加莎的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130153,
		PreGoal = 
		{
			301512,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败咖啡馆的[FDDE40]阿加莎[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140608,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1514] =
{
	Id = 1514,
	Name = "解锁：现场",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130155,
		PreGoal = 
		{
			301252,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "危险地区，请在本地人员陪同下进入。\n派遣含有[62E7E7]3个[-][62E7E7]悬疑星[-]队员(或宠物)的队伍探索悬疑星[FDDE40]冷清街[-]23小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 82800,
			TagList = 
			{
				560106,
			},
			CharacterNum = 3,
			Value = 130155,
		},
	},
	Reward = {
		{
			Value = 130156,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1515] =
{
	Id = 1515,
	Name = "支线-拆除路障",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130156,
		PreGoal = 
		{
			301514,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]工地路障[-]180个，建议探索32小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 180,
			Value = 242096,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1516] =
{
	Id = 1516,
	Name = "支线-罪恶的下水道",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130156,
		PreGoal = 
		{
			301515,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]3阶[-][62E7E7]水元素[-][FDDE40]角色[-]3个",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 3,
			Value = -1,
			Stage = 3,
			Element = 210001,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1517] =
{
	Id = 1517,
	Name = "支线-城市的暗网",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130156,
		PreGoal = 
		{
			301516,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]3个[-][62E7E7]悬疑星[-]、[62E7E7]水元素[-]队员(或宠物)的队伍探索悬疑星[FDDE40]现场[-]23小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 82800,
			TagList = 
			{
				560106,
				561202,
			},
			CharacterNum = 3,
			Value = 130156,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1518] =
{
	Id = 1518,
	Name = "支线-窨井守卫者的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130156,
		PreGoal = 
		{
			301517,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败现场的[FDDE40]窨井守卫者[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140617,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1519] =
{
	Id = 1519,
	Name = "支线-照亮现场",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130156,
		PreGoal = 
		{
			301518,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]煤气灯[-]3个(需要事务所的工具箱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 3,
			Value = 250097,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1520] =
{
	Id = 1520,
	Name = "支线-可疑区域",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130156,
		PreGoal = 
		{
			301519,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]3个[-][62E7E7]悬疑星[-]队员(或宠物)的队伍探索悬疑星[FDDE40]现场[-]30小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 108000,
			TagList = 
			{
				560106,
			},
			CharacterNum = 3,
			Value = 130156,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1521] =
{
	Id = 1521,
	Name = "支线-一连串脚印",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130156,
		PreGoal = 
		{
			301520,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中获得[FDDE40]脚印[-]30个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 30,
			Value = 321605,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1522] =
{
	Id = 1522,
	Name = "支线-路障队长的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130156,
		PreGoal = 
		{
			301521,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败现场的[FDDE40]路障队长[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140618,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1523] =
{
	Id = 1523,
	Name = "支线-现场勘探",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130156,
		PreGoal = 
		{
			301522,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]豆豆警官[-]、[62E7E7]侦探助理[-]探索悬疑星[FDDE40]现场[-]30小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 108000,
			Character = 
			{
				220316,
				220320,
			},
			Value = 130156,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1524] =
{
	Id = 1524,
	Name = "支线-检查下水道",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130156,
		PreGoal = 
		{
			301523,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]窨井盖[-]100个，建议探索34小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 100,
			Value = 242098,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1525] =
{
	Id = 1525,
	Name = "支线-接通水管",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130156,
		PreGoal = 
		{
			301524,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计拥有[62E7E7]水元素[-][FDDE40]宠物[-]8种",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 8,
			TagList = 
			{
				561202,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1526] =
{
	Id = 1526,
	Name = "支线-消防队长的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130156,
		PreGoal = 
		{
			301525,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败现场的[FDDE40]消防队长[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140619,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1527] =
{
	Id = 1527,
	Name = "支线-破坏路障",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130156,
		PreGoal = 
		{
			301526,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]警用路障[-]25个，建议探索34小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 25,
			Value = 242099,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1528] =
{
	Id = 1528,
	Name = "支线-寻找死者",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130156,
		PreGoal = 
		{
			301527,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]3个[-][62E7E7]悬疑星[-]队员(或宠物)的队伍探索悬疑星[FDDE40]现场[-]35小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 126000,
			TagList = 
			{
				560106,
			},
			CharacterNum = 3,
			Value = 130156,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1529] =
{
	Id = 1529,
	Name = "支线-提交证物",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130156,
		PreGoal = 
		{
			301528,
		},
	},
	GoalTrigger = 
	{
		TriggerType.DemandCost,
	},
	GoalCondition = 
	{
		{
			Name = "在委托中提交[62E7E7]悬疑星[-]道具60个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 60,
			TagList = 
			{
				560106,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1530] =
{
	Id = 1530,
	Name = "支线-死者的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130156,
		PreGoal = 
		{
			301529,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败现场的[FDDE40]死者[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140620,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1531] =
{
	Id = 1531,
	Name = "解锁：失物招领局",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130159,
		PreGoal = 
		{
			301297,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "值班人员说不给点什么不想放我们进去。\n提交[FDDE40]黄瓜马赛克[-]30个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 30,
			Value = 321610,
		},
	},
	Reward = {
		{
			Value = 130160,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1532] =
{
	Id = 1532,
	Name = "支线-警局打工4",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130160,
		PreGoal = 
		{
			301531,
		},
	},
	GoalTrigger = 
	{
		TriggerType.WorkShopRank,
	},
	GoalCondition = 
	{
		{
			Name = "在[FDDE40]警察局[-]打工获得[FDDE40]S-[-]或更高评价",
			Type = ItemType.WorkShop,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 160003,
			Rank = 20,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1533] =
{
	Id = 1533,
	Name = "支线-新款手铐",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130160,
		PreGoal = 
		{
			301532,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]3个[-][62E7E7]紫色及以上品质[-]、[62E7E7]暗元素[-]队员(或宠物)的队伍探索悬疑星[FDDE40]失物招领局[-]35小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 126000,
			TagList = 
			{
				560034,
				561206,
			},
			CharacterNum = 3,
			Value = 130160,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1534] =
{
	Id = 1534,
	Name = "支线-特殊纹路",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130160,
		PreGoal = 
		{
			301533,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "携带[62E7E7]手铐[-]探索悬疑星[FDDE40]失物招领局[-]23小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 82800,
			Pet = 250102,
			Value = 130160,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1535] =
{
	Id = 1535,
	Name = "支线-可疑手铐的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130160,
		PreGoal = 
		{
			301534,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败失物招领局的[FDDE40]可疑手铐[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140632,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1536] =
{
	Id = 1536,
	Name = "支线-无人认领的爱情",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130160,
		PreGoal = 
		{
			301535,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "探索[62E7E7]失物招领局[-]击败[FDDE40]情书[-]130个，建议探索34小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 130,
			Value = 242087,
			Area = 130160,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1537] =
{
	Id = 1537,
	Name = "支线-奇怪的失物",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130160,
		PreGoal = 
		{
			301536,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中获得[FDDE40]皮鞭[-]20个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 20,
			Value = 321609,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1538] =
{
	Id = 1538,
	Name = "支线-失物招领",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130160,
		PreGoal = 
		{
			301537,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]3个[-][62E7E7]金色及以上品质[-]队员(或宠物)的队伍探索悬疑星[FDDE40]失物招领局[-]47小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 169200,
			TagList = 
			{
				560035,
			},
			CharacterNum = 3,
			Value = 130160,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1539] =
{
	Id = 1539,
	Name = "支线-可疑行李车的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130160,
		PreGoal = 
		{
			301538,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败失物招领局的[FDDE40]可疑行李车[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140633,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1540] =
{
	Id = 1540,
	Name = "解锁：实验室",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130162,
		PreGoal = 
		{
			301322,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "黑猫们盘踞在实验室入口处，需要交涉一下。\n累计拥有[62E7E7]猫科的[-][FDDE40]宠物[-]3种",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 3,
			TagList = 
			{
				561346,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 130163,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1541] =
{
	Id = 1541,
	Name = "支线-发现血迹",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130163,
		PreGoal = 
		{
			301540,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]5个[-][62E7E7]悬疑星[-]队员(或宠物)的队伍探索悬疑星[FDDE40]实验室[-]30小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 108000,
			TagList = 
			{
				560106,
			},
			CharacterNum = 5,
			Value = 130163,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1542] =
{
	Id = 1542,
	Name = "支线-仔细观察",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130163,
		PreGoal = 
		{
			301541,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]放大镜[-]180个，建议探索36小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 180,
			Value = 242114,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1543] =
{
	Id = 1543,
	Name = "支线-现场血迹的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130163,
		PreGoal = 
		{
			301542,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败实验室的[FDDE40]现场血迹[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140641,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1544] =
{
	Id = 1544,
	Name = "支线-追击黑猫",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130163,
		PreGoal = 
		{
			301543,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]2个[-][62E7E7]金色及以上品质[-]队员(或宠物)的队伍探索悬疑星[FDDE40]实验室[-]35小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 126000,
			TagList = 
			{
				560035,
			},
			CharacterNum = 2,
			Value = 130163,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1545] =
{
	Id = 1545,
	Name = "支线-金属物体",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130163,
		PreGoal = 
		{
			301544,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "探索[62E7E7]实验室[-]击败[FDDE40]豹纹手铐[-]130个，建议探索35小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 130,
			Value = 242110,
			Area = 130163,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1546] =
{
	Id = 1546,
	Name = "支线-新鲜的血液",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130163,
		PreGoal = 
		{
			301545,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "捕获宠物[FDDE40]血迹[-]10个(需要超市的空瓶)",
			Type = ItemType.Pet,
			CountType = GoalCountType.StartNow,
			Num = 10,
			Value = 250117,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1547] =
{
	Id = 1547,
	Name = "支线-恐怖黑猫的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130163,
		PreGoal = 
		{
			301546,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败实验室的[FDDE40]恐怖黑猫[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140642,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1548] =
{
	Id = 1548,
	Name = "支线-奇怪的大脑",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130163,
		PreGoal = 
		{
			301547,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]2个[-][62E7E7]金色及以上品质[-]、[62E7E7]悬疑星[-]队员(或宠物)的队伍探索悬疑星[FDDE40]实验室[-]35小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 126000,
			TagList = 
			{
				560035,
				560106,
			},
			CharacterNum = 2,
			Value = 130163,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1549] =
{
	Id = 1549,
	Name = "支线-补充营养",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130163,
		PreGoal = 
		{
			301548,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中获得[FDDE40]营养液[-]15个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 15,
			Value = 321612,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1550] =
{
	Id = 1550,
	Name = "支线-所有的线索",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130163,
		PreGoal = 
		{
			301549,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计拥有[62E7E7]悬疑星[-][FDDE40]宠物[-]33种",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 33,
			TagList = 
			{
				560106,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1551] =
{
	Id = 1551,
	Name = "支线-最强大脑的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130163,
		PreGoal = 
		{
			301550,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败实验室的[FDDE40]最强大脑[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140643,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1552] =
{
	Id = 1552,
	Name = "支线-捕获最强大脑",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130163,
		PreGoal = 
		{
			301551,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]瓶中脑[-]5个(需要事务所的纸板箱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 5,
			Value = 250118,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1553] =
{
	Id = 1553,
	Name = "支线-问答大赛",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130163,
		PreGoal = 
		{
			301552,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]50级[-][62E7E7]金色及以上品质[-][FDDE40]角色[-]5个",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 5,
			Value = -1,
			Rarity = 4,
			Level = 50,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1554] =
{
	Id = 1554,
	Name = "支线-幕后的导演",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130163,
		PreGoal = 
		{
			301553,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]2个[-][62E7E7]星际流民的[-]队员(或宠物)的队伍探索悬疑星[FDDE40]实验室[-]47小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 169200,
			TagList = 
			{
				560110,
			},
			CharacterNum = 2,
			Value = 130163,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1555] =
{
	Id = 1555,
	Name = "支线-迈克罗夫特的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130163,
		PreGoal = 
		{
			301551,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败实验室的[FDDE40]迈克罗夫特[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140644,
		},
	},
	CompleteSpeech = 30155501,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1556] =
{
	Id = 1556,
	Name = "新配方：谣言",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130153,
		PreGoal = 
		{
			301505,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "虽然是假消息，不过大家似乎很感兴趣呢~\n提交[FDDE40]新闻[-]25个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 25,
			Value = 321602,
		},
	},
	Reward = {
		{
			Value = 360351,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1557] =
{
	Id = 1557,
	Name = "新配方：肖像侧写",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130157,
		PreGoal = 
		{
			301256,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "只要从蛛丝马迹就能找到凶手的特征！\n提交[FDDE40]烟头[-]25个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 25,
			Value = 321606,
		},
	},
	Reward = {
		{
			Value = 360352,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1558] =
{
	Id = 1558,
	Name = "新配方：欠条",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130159,
		PreGoal = 
		{
			301288,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "发生财务纠纷的时候，有这个就没问题了。\n提交[FDDE40]墨水[-]25个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 25,
			Value = 321608,
		},
	},
	Reward = {
		{
			Value = 360353,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1559] =
{
	Id = 1559,
	Name = "新配方：18X",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130160,
		PreGoal = 
		{
			301535,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "这个怎么说呢？先生，你确定要吗？\n提交[FDDE40]皮鞭[-]25个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 25,
			Value = 321609,
		},
	},
	Reward = {
		{
			Value = 360354,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1560] =
{
	Id = 1560,
	Name = "地图打卡：人行道",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130152,
		PreGoal = 
		{
			301220,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "过马路时请注意安全，切勿嬉闹。\n提交[FDDE40]箭头[-]30个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 30,
			Value = 321411,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 20,
		},
		{
			Value = 320054,
			Num = 20,
		},
		{
			Value = 1,
			Num = 74300,
		},
	},
}
GoalConfig[GoalID.Id1561] =
{
	Id = 1561,
	Name = "地图打卡：咖啡广告牌",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130153,
		PreGoal = 
		{
			301513,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "游荡的猫咪占领了咖啡店的招牌…\n探索[62E7E7]咖啡馆[-]击败[FDDE40]白猫[-]20个，建议探索25小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 20,
			Value = 242085,
			Area = 130153,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 30,
		},
		{
			Value = 320054,
			Num = 30,
		},
		{
			Value = 1,
			Num = 91200,
		},
	},
}
GoalConfig[GoalID.Id1562] =
{
	Id = 1562,
	Name = "地图打卡：巨型邮筒",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130154,
		PreGoal = 
		{
			301236,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "有什么需要寄去问候的对象吗？\n累计拥有[62E7E7]纸张类的[-][FDDE40]宠物[-]3种",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 3,
			TagList = 
			{
				561343,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 40,
		},
		{
			Value = 320054,
			Num = 40,
		},
		{
			Value = 1,
			Num = 75600,
		},
	},
}
GoalConfig[GoalID.Id1563] =
{
	Id = 1563,
	Name = "地图打卡：华丽路灯",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130155,
		PreGoal = 
		{
			301252,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "在这华丽的光辉之下，冷清街道温暖了起来。\n拥有至少[62E7E7]40级[-][62E7E7]光元素[-][FDDE40]角色[-]10个",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 10,
			Value = -1,
			Level = 40,
			Element = 210004,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 50,
		},
		{
			Value = 320054,
			Num = 50,
		},
		{
			Value = 1,
			Num = 87700,
		},
	},
}
GoalConfig[GoalID.Id1564] =
{
	Id = 1564,
	Name = "地图打卡：粉笔轮廓",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130156,
		PreGoal = 
		{
			301530,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "想去事发地点的话需要问一下本地的黑猫。\n探索[62E7E7]现场[-]击败[FDDE40]黑猫[-]5个，建议探索14小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 5,
			Value = 242086,
			Area = 130156,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 60,
		},
		{
			Value = 320054,
			Num = 60,
		},
		{
			Value = 1,
			Num = 98700,
		},
	},
}
GoalConfig[GoalID.Id1565] =
{
	Id = 1565,
	Name = "地图打卡：警局登记板",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130157,
		PreGoal = 
		{
			301268,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "先生，别抽烟了，可以先带我去登记吗？\n探索[62E7E7]警局[-]击败[FDDE40]打火机[-]25个，建议探索27小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 25,
			Value = 242103,
			Area = 130157,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 70,
		},
		{
			Value = 320054,
			Num = 70,
		},
		{
			Value = 1,
			Num = 88900,
		},
	},
}
GoalConfig[GoalID.Id1566] =
{
	Id = 1566,
	Name = "地图打卡：证物柜",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130158,
		PreGoal = 
		{
			301284,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "破坏所有警报就可以安心查看证物柜了~\n探索[62E7E7]证物仓库[-]击败[FDDE40]报警器[-]50个，建议探索28小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 50,
			Value = 242105,
			Area = 130158,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 80,
		},
		{
			Value = 320054,
			Num = 80,
		},
		{
			Value = 1,
			Num = 132000,
		},
	},
}
GoalConfig[GoalID.Id1567] =
{
	Id = 1567,
	Name = "地图打卡：审讯台",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130159,
		PreGoal = 
		{
			301297,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "审讯员说，关键口供要用红墨水圈出来。\n在探索中击败[FDDE40]红墨水[-]30个，建议探索28小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 30,
			Value = 242109,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 90,
		},
		{
			Value = 320054,
			Num = 90,
		},
		{
			Value = 1,
			Num = 102600,
		},
	},
}
GoalConfig[GoalID.Id1568] =
{
	Id = 1568,
	Name = "地图打卡：失物陈列柜",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130160,
		PreGoal = 
		{
			301539,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "有些失物在此多年，已经把这里当成了家。\n[62E7E7]一次性[-]探索[62E7E7]失物招领局[-]击败[FDDE40]行李车[-]12个，建议探索28小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.OneShot,
			Num = 12,
			Value = 242111,
			Area = 130160,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 100,
		},
		{
			Value = 320054,
			Num = 100,
		},
		{
			Value = 1,
			Num = 134700,
		},
	},
}
GoalConfig[GoalID.Id1569] =
{
	Id = 1569,
	Name = "地图打卡：编辑部书架",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130161,
		PreGoal = 
		{
			301310,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "没有书本的书架是没有灵魂的！\n在探索中击败[FDDE40]蔬菜笔记[-]30个，建议探索28小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 30,
			Value = 242113,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 110,
		},
		{
			Value = 320054,
			Num = 110,
		},
		{
			Value = 1,
			Num = 113400,
		},
	},
}
GoalConfig[GoalID.Id1570] =
{
	Id = 1570,
	Name = "地图打卡：奇异电话亭",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130162,
		PreGoal = 
		{
			301327,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "听说要很有耐心才能找到那个传说中的电话亭！\n[62E7E7]一次性[-]派遣含有[62E7E7]5个[-][62E7E7]紫色及以上品质[-]、[62E7E7]悬疑星[-]队员(或宠物)的队伍探索悬疑星[FDDE40]侦探街[-]47小时",
			Type = ItemType.Time,
			CountType = GoalCountType.OneShot,
			Num = 169200,
			TagList = 
			{
				560034,
				560106,
			},
			CharacterNum = 5,
			Value = 130162,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 120,
		},
		{
			Value = 320054,
			Num = 120,
		},
		{
			Value = 1,
			Num = 114800,
		},
	},
}
GoalConfig[GoalID.Id1571] =
{
	Id = 1571,
	Name = "地图打卡：教授工作台",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130163,
		PreGoal = 
		{
			301555,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "到底是谁在这里工作呢？瓶子里放的又是谁呢？\n在探索中击败[FDDE40]瓶中脑[-]10个，建议探索29小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 10,
			Value = 242118,
		},
	},
	Reward = {
		{
			Value = 320614,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 10,
		},
		{
			Value = 1,
			Num = 193200,
		},
	},
}
GoalConfig[GoalID.Id1572] =
{
	Id = 1572,
	Name = "支线-收藏家的考验10",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130162,
		PreGoal = 
		{
			301302,
			301173,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "怎么又需要侧写了，这次又是发生了什么呢\n提交[FDDE40]肖像侧写[-]20个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 321652,
		},
	},
	CompleteSpeech = 30157201,
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1573] =
{
	Id = 1573,
	Name = "支线-丢失的小提琴1",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130162,
		PreGoal = 
		{
			301572,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "名侦探呜呜、名侦探漆漆，来了！先去案发现场搜查一下吧！\n探索悬疑星[FDDE40]侦探街[-]12小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 43200,
			Value = 130162,
		},
	},
	CompleteSpeech = 30157301,
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1574] =
{
	Id = 1574,
	Name = "支线-丢失的小提琴2",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130162,
		PreGoal = 
		{
			301573,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "漆漆不是黑猫喵！不过哪里有黑猫呢…\n累计捕捉宠物[FDDE40]黑猫[-]20个(需要事务所的纸板箱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 250086,
		},
	},
	CompleteSpeech = 30157401,
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1575] =
{
	Id = 1575,
	Name = "支线-丢失的小提琴3",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130162,
		PreGoal = 
		{
			301574,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "追……追上他！\n探索悬疑星[FDDE40]编辑部[-]18小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 64800,
			Value = 130161,
		},
	},
	CompleteSpeech = 30157501,
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1576] =
{
	Id = 1576,
	Name = "支线-丢失的小提琴4",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130162,
		PreGoal = 
		{
			301575,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityChallenge,
	},
	GoalCondition = 
	{
		{
			Name = "出现了！凶手，快快束手就擒吧！\n打败[FDDE40]凶手[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 147014,
		},
	},
	CompleteSpeech = 30157601,
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id1577] =
{
	Id = 1577,
	Name = "支线-紧急！完美的犯罪！",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130162,
		PreGoal = 
		{
			301576,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityChallenge,
	},
	GoalCondition = 
	{
		{
			Name = "这波我在大气层\n打败[FDDE40]“波罗”[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 147015,
		},
	},
	CompleteSpeech = 30157701,
	Reward = {
		{
			Value = 320538,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 5,
		},
	},
}
