require "FreakPlanet/Design/MiscConfig"
EquipmentInfoConfig ={};
EquipmentInfoID = 
{
	Id001 = 920001,
	Id002 = 920002,
	Id003 = 920003,
	Id004 = 920004,
	Id005 = 920005,
	Id006 = 920006,
	Id007 = 920007,
	Id008 = 920008,
	Id009 = 920009,
	Id010 = 920010,
	Id011 = 920011,
	Id012 = 920012,
	Id013 = 920013,
	Id014 = 920014,
	Id015 = 920015,
	Id016 = 920016,
	Id017 = 920017,
	Id018 = 920018,
	Id019 = 920019,
	Id020 = 920020,
	Id021 = 920021,
	Id022 = 920022,
	Id023 = 920023,
	Id024 = 920024,
	Id025 = 920025,
	Id026 = 920026,
	Id027 = 920027,
	Id028 = 920028,
	Id029 = 920029,
	Id030 = 920030,
	Id031 = 920031,
	Id032 = 920032,
	Id033 = 920033,
	Id034 = 920034,
	Id035 = 920035,
	Id036 = 920036,
	Id037 = 920037,
	Id038 = 920038,
	Id039 = 920039,
	Id040 = 920040,
	Id041 = 920041,
	Id042 = 920042,
	Id043 = 920043,
	Id044 = 920044,
	Id045 = 920045,
	Id046 = 920046,
	Id047 = 920047,
	Id048 = 920048,
	Id049 = 920049,
	Id050 = 920050,
	Id051 = 920051,
	Id052 = 920052,
	Id053 = 920053,
	Id054 = 920054,
	Id055 = 920055,
	Id056 = 920056,
	Id057 = 920057,
	Id058 = 920058,
	Id059 = 920059,
	Id060 = 920060,
	Id061 = 920061,
	Id062 = 920062,
	Id063 = 920063,
	Id064 = 920064,
	Id065 = 920065,
	Id066 = 920066,
	Id067 = 920067,
	Id068 = 920068,
	Id069 = 920069,
	Id070 = 920070,
	Id071 = 920071,
	Id072 = 920072,
	Id073 = 920073,
	Id074 = 920074,
	Id075 = 920075,
	Id076 = 920076,
	Id077 = 920077,
	Id078 = 920078,
	Id079 = 920079,
	Id080 = 920080,
	Id081 = 920081,
	Id082 = 920082,
	Id083 = 920083,
	Id084 = 920084,
	Id085 = 920085,
	Id086 = 920086,
	Id087 = 920087,
	Id088 = 920088,
	Id089 = 920089,
	Id090 = 920090,
	Id091 = 920091,
	Id092 = 920092,
	Id093 = 920093,
	Id094 = 920094,
	Id095 = 920095,
	Id096 = 920096,
	Id097 = 920097,
	Id098 = 920098,
	Id099 = 920099,
	Id100 = 920100,
	Id101 = 920101,
	Id102 = 920102,
	Id103 = 920103,
	Id104 = 920104,
	Id105 = 920105,
	Id106 = 920106,
	Id107 = 920107,
	Id108 = 920108,
	Id109 = 920109,
	Id110 = 920110,
	Id111 = 920111,
	Id112 = 920112,
	Id113 = 920113,
	Id114 = 920114,
	Id115 = 920115,
	Id116 = 920116,
	Id117 = 920117,
	Id118 = 920118,
	Id119 = 920119,
	Id120 = 920120,
	Id121 = 920121,
	Id122 = 920122,
	Id123 = 920123,
	Id124 = 920124,
	Id125 = 920125,
	Id126 = 920126,
	Id127 = 920127,
	Id128 = 920128,
	Id129 = 920129,
	Id130 = 920130,
	Id131 = 920131,
	Id132 = 920132,
	Id133 = 920133,
	Id134 = 920134,
	Id135 = 920135,
	Id136 = 920136,
	Id137 = 920137,
	Id138 = 920138,
	Id139 = 920139,
	Id140 = 920140,
	Id141 = 920141,
	Id142 = 920142,
	Id143 = 920143,
	Id144 = 920144,
	Id145 = 920145,
	Id146 = 920146,
	Id147 = 920147,
	Id148 = 920148,
	Id149 = 920149,
	Id150 = 920150,
	Id151 = 920151,
	Id152 = 920152,
	Id153 = 920153,
	Id154 = 920154,
	Id155 = 920155,
	Id156 = 920156,
	Id157 = 920157,
	Id158 = 920158,
	Id159 = 920159,
	Id160 = 920160,
	Id161 = 920161,
	Id162 = 920162,
	Id163 = 920163,
	Id164 = 920164,
	Id165 = 920165,
	Id166 = 920166,
	Id167 = 920167,
	Id168 = 920168,
	Id169 = 920169,
	Id170 = 920170,
	Id171 = 920171,
	Id172 = 920172,
	Id173 = 920173,
	Id174 = 920174,
	Id175 = 920175,
	Id176 = 920176,
	Id177 = 920177,
	Id178 = 920178,
	Id179 = 920179,
	Id180 = 920180,
	Id181 = 920181,
	Id182 = 920182,
	Id183 = 920183,
	Id184 = 920184,
	Id185 = 920185,
	Id186 = 920186,
	Id187 = 920187,
	Id188 = 920188,
	Id189 = 920189,
	Id190 = 920190,
	Id191 = 920191,
	Id192 = 920192,
	Id193 = 920193,
	Id194 = 920194,
	Id195 = 920195,
	Id196 = 920196,
	Id197 = 920197,
	Id198 = 920198,
	Id199 = 920199,
	Id200 = 920200,
	Id201 = 920201,
	Id202 = 920202,
	Id203 = 920203,
	Id204 = 920204,
	Id205 = 920205,
	Id206 = 920206,
	Id207 = 920207,
	Id208 = 920208,
	Id209 = 920209,
	Id210 = 920210,
	Id211 = 920211,
	Id212 = 920212,
	Id213 = 920213,
	Id214 = 920214,
	Id215 = 920215,
	Id216 = 920216,
	Id217 = 920217,
	Id218 = 920218,
	Id219 = 920219,
	Id220 = 920220,
	Id221 = 920221,
	Id222 = 920222,
	Id223 = 920223,
	Id224 = 920224,
	Id225 = 920225,
	Id226 = 920226,
	Id227 = 920227,
	Id228 = 920228,
	Id229 = 920229,
	Id230 = 920230,
	Id231 = 920231,
	Id232 = 920232,
	Id233 = 920233,
	Id234 = 920234,
	Id235 = 920235,
	Id236 = 920236,
	Id237 = 920237,
	Id238 = 920238,
	Id239 = 920239,
	Id240 = 920240,
	Id241 = 920241,
	Id242 = 920242,
	Id243 = 920243,
	Id244 = 920244,
	Id245 = 920245,
	Id246 = 920246,
	Id247 = 920247,
	Id248 = 920248,
	Id249 = 920249,
	Id250 = 920250,
	Id251 = 920251,
	Id252 = 920252,
	Id253 = 920253,
	Id254 = 920254,
	Id255 = 920255,
	Id256 = 920256,
	Id257 = 920257,
	Id258 = 920258,
	Id259 = 920259,
	Id260 = 920260,
	Id261 = 920261,
	Id262 = 920262,
	Id263 = 920263,
	Id264 = 920264,
	Id265 = 920265,
	Id266 = 920266,
	Id267 = 920267,
	Id268 = 920268,
	Id269 = 920269,
	Id270 = 920270,
	Id271 = 920271,
	Id272 = 920272,
	Id273 = 920273,
	Id274 = 920274,
	Id275 = 920275,
	Id276 = 920276,
	Id277 = 920277,
	Id278 = 920278,
	Id279 = 920279,
	Id280 = 920280,
	Id281 = 920281,
	Id282 = 920282,
	Id283 = 920283,
	Id284 = 920284,
	Id285 = 920285,
	Id286 = 920286,
	Id287 = 920287,
	Id288 = 920288,
	Id289 = 920289,
	Id290 = 920290,
	Id291 = 920291,
	Id292 = 920292,
	Id293 = 920293,
	Id294 = 920294,
	Id295 = 920295,
	Id296 = 920296,
	Id297 = 920297,
	Id298 = 920298,
	Id299 = 920299,
	Id300 = 920300,
	Id301 = 920301,
	Id302 = 920302,
	Id303 = 920303,
	Id304 = 920304,
	Id305 = 920305,
	Id306 = 920306,
	Id307 = 920307,
	Id308 = 920308,
	Id309 = 920309,
	Id310 = 920310,
	Id311 = 920311,
	Id312 = 920312,
	Id313 = 920313,
	Id314 = 920314,
	Id315 = 920315,
	Id316 = 920316,
	Id317 = 920317,
	Id318 = 920318,
	Id319 = 920319,
	Id320 = 920320,
	Id321 = 920321,
	Id322 = 920322,
	Id323 = 920323,
	Id324 = 920324,
	Id325 = 920325,
	Id326 = 920326,
	Id327 = 920327,
	Id328 = 920328,
	Id329 = 920329,
	Id330 = 920330,
	Id331 = 920331,
	Id332 = 920332,
	Id333 = 920333,
	Id334 = 920334,
	Id335 = 920335,
	Id336 = 920336,
	Id337 = 920337,
	Id338 = 920338,
	Id339 = 920339,
	Id340 = 920340,
	Id341 = 920341,
	Id342 = 920342,
	Id343 = 920343,
	Id344 = 920344,
	Id345 = 920345,
	Id346 = 920346,
	Id347 = 920347,
	Id348 = 920348,
	Id349 = 920349,
	Id350 = 920350,
	Id351 = 920351,
	Id352 = 920352,
	Id353 = 920353,
	Id354 = 920354,
	Id355 = 920355,
	Id356 = 920356,
	Id357 = 920357,
	Id358 = 920358,
	Id359 = 920359,
	Id360 = 920360,
	Id361 = 920361,
	Id362 = 920362,
	Id363 = 920363,
	Id364 = 920364,
	Id365 = 920365,
	Id366 = 920366,
	Id367 = 920367,
	Id368 = 920368,
	Id369 = 920369,
	Id370 = 920370,
	Id371 = 920371,
	Id372 = 920372,
	Id373 = 920373,
	Id374 = 920374,
	Id375 = 920375,
	Id376 = 920376,
	Id377 = 920377,
	Id378 = 920378,
	Id379 = 920379,
	Id380 = 920380,
	Id381 = 920381,
	Id382 = 920382,
	Id383 = 920383,
	Id384 = 920384,
	Id385 = 920385,
	Id386 = 920386,
	Id387 = 920387,
	Id388 = 920388,
	Id389 = 920389,
	Id390 = 920390,
	Id391 = 920391,
	Id392 = 920392,
	Id393 = 920393,
	Id394 = 920394,
	Id395 = 920395,
	Id396 = 920396,
	Id397 = 920397,
	Id398 = 920398,
	Id399 = 920399,
	Id400 = 920400,
	Id401 = 920401,
	Id402 = 920402,
	Id403 = 920403,
	Id404 = 920404,
	Id405 = 920405,
	Id406 = 920406,
	Id407 = 920407,
	Id408 = 920408,
	Id409 = 920409,
	Id410 = 920410,
	Id411 = 920411,
	Id412 = 920412,
	Id413 = 920413,
	Id414 = 920414,
	Id415 = 920415,
	Id416 = 920416,
	Id417 = 920417,
	Id418 = 920418,
	Id419 = 920419,
	Id420 = 920420,
	Id421 = 920421,
	Id422 = 920422,
	Id423 = 920423,
	Id424 = 920424,
	Id425 = 920425,
	Id426 = 920426,
	Id427 = 920427,
	Id428 = 920428,
	Id429 = 920429,
	Id430 = 920430,
	Id431 = 920431,
	Id432 = 920432,
	Id433 = 920433,
	Id434 = 920434,
	Id435 = 920435,
	Id436 = 920436,
	Id437 = 920437,
	Id438 = 920438,
	Id439 = 920439,
	Id440 = 920440,
	Id441 = 920441,
	Id442 = 920442,
	Id443 = 920443,
	Id444 = 920444,
	Id445 = 920445,
	Id446 = 920446,
	Id447 = 920447,
	Id448 = 920448,
	Id449 = 920449,
	Id450 = 920450,
	Id451 = 920451,
	Id452 = 920452,
	Id453 = 920453,
	Id454 = 920454,
	Id455 = 920455,
	Id456 = 920456,
	Id457 = 920457,
	Id458 = 920458,
	Id459 = 920459,
	Id460 = 920460,
	Id461 = 920461,
	Id462 = 920462,
	Id463 = 920463,
	Id464 = 920464,
	Id465 = 920465,
	Id466 = 920466,
	Id467 = 920467,
	Id468 = 920468,
	Id469 = 920469,
	Id470 = 920470,
	Id471 = 920471,
	Id472 = 920472,
	Id473 = 920473,
	Id474 = 920474,
	Id475 = 920475,
	Id476 = 920476,
	Id477 = 920477,
	Id478 = 920478,
	Id479 = 920479,
	Id480 = 920480,
	Id481 = 920481,
	Id482 = 920482,
	Id483 = 920483,
	Id484 = 920484,
	Id485 = 920485,
	Id486 = 920486,
	Id487 = 920487,
	Id488 = 920488,
	Id489 = 920489,
	Id490 = 920490,
	Id491 = 920491,
	Id492 = 920492,
	Id493 = 920493,
	Id494 = 920494,
	Id495 = 920495,
	Id496 = 920496,
	Id497 = 920497,
	Id498 = 920498,
	Id499 = 920499,
	Id500 = 920500,
	Id501 = 920501,
	Id502 = 920502,
	Id503 = 920503,
	Id504 = 920504,
	Id505 = 920505,
	Id506 = 920506,
	Id507 = 920507,
	Id508 = 920508,
	Id509 = 920509,
	Id510 = 920510,
	Id511 = 920511,
	Id512 = 920512,
	Id513 = 920513,
	Id514 = 920514,
	Id515 = 920515,
	Id516 = 920516,
	Id517 = 920517,
	Id518 = 920518,
	Id519 = 920519,
	Id520 = 920520,
	Id521 = 920521,
	Id522 = 920522,
	Id523 = 920523,
	Id524 = 920524,
	Id525 = 920525,
	Id526 = 920526,
	Id527 = 920527,
	Id528 = 920528,
	Id529 = 920529,
	Id530 = 920530,
	Id531 = 920531,
	Id532 = 920532,
	Id533 = 920533,
	Id534 = 920534,
	Id535 = 920535,
	Id536 = 920536,
	Id537 = 920537,
	Id538 = 920538,
	Id539 = 920539,
	Id540 = 920540,
	Id541 = 920541,
	Id542 = 920542,
	Id543 = 920543,
	Id544 = 920544,
	Id545 = 920545,
	Id546 = 920546,
	Id547 = 920547,
	Id548 = 920548,
	Id549 = 920549,
	Id550 = 920550,
	Id551 = 920551,
	Id552 = 920552,
	Id553 = 920553,
	Id554 = 920554,
	Id555 = 920555,
	Id556 = 920556,
	Id557 = 920557,
	Id558 = 920558,
	Id559 = 920559,
	Id560 = 920560,
	Id561 = 920561,
	Id562 = 920562,
	Id563 = 920563,
	Id564 = 920564,
	Id565 = 920565,
	Id566 = 920566,
	Id567 = 920567,
	Id568 = 920568,
	Id569 = 920569,
	Id570 = 920570,
	Id571 = 920571,
	Id572 = 920572,
	Id573 = 920573,
	Id574 = 920574,
	Id575 = 920575,
	Id576 = 920576,
	Id577 = 920577,
	Id578 = 920578,
	Id579 = 920579,
	Id580 = 920580,
	Id581 = 920581,
	Id582 = 920582,
	Id583 = 920583,
	Id584 = 920584,
	Id585 = 920585,
	Id586 = 920586,
	Id587 = 920587,
	Id588 = 920588,
	Id589 = 920589,
	Id590 = 920590,
	Id591 = 920591,
	Id592 = 920592,
	Id593 = 920593,
	Id594 = 920594,
	Id595 = 920595,
	Id596 = 920596,
	Id597 = 920597,
	Id598 = 920598,
	Id599 = 920599,
	Id600 = 920600,
	Id601 = 920601,
	Id602 = 920602,
	Id603 = 920603,
	Id604 = 920604,
	Id605 = 920605,
	Id606 = 920606,
	Id607 = 920607,
	Id608 = 920608,
	Id609 = 920609,
	Id610 = 920610,
	Id611 = 920611,
	Id612 = 920612,
	Id613 = 920613,
	Id614 = 920614,
	Id615 = 920615,
	Id616 = 920616,
	Id617 = 920617,
	Id618 = 920618,
	Id619 = 920619,
	Id620 = 920620,
	Id621 = 920621,
	Id622 = 920622,
	Id623 = 920623,
	Id624 = 920624,
	Id625 = 920625,
	Id626 = 920626,
	Id627 = 920627,
	Id628 = 920628,
	Id629 = 920629,
	Id630 = 920630,
	Id631 = 920631,
	Id632 = 920632,
	Id633 = 920633,
	Id634 = 920634,
	Id635 = 920635,
	Id636 = 920636,
	Id637 = 920637,
	Id638 = 920638,
	Id639 = 920639,
	Id640 = 920640,
	Id641 = 920641,
	Id642 = 920642,
	Id643 = 920643,
	Id644 = 920644,
	Id645 = 920645,
	Id646 = 920646,
	Id647 = 920647,
	Id648 = 920648,
	Id649 = 920649,
	Id650 = 920650,
	Id651 = 920651,
	Id652 = 920652,
	Id653 = 920653,
	Id654 = 920654,
	Id655 = 920655,
	Id656 = 920656,
	Id657 = 920657,
	Id658 = 920658,
	Id659 = 920659,
	Id660 = 920660,
	Id661 = 920661,
	Id662 = 920662,
	Id663 = 920663,
	Id664 = 920664,
	Id665 = 920665,
	Id666 = 920666,
	Id667 = 920667,
	Id668 = 920668,
	Id669 = 920669,
	Id670 = 920670,
	Id671 = 920671,
	Id672 = 920672,
	Id673 = 920673,
	Id674 = 920674,
	Id675 = 920675,
	Id676 = 920676,
	Id677 = 920677,
	Id678 = 920678,
	Id679 = 920679,
	Id680 = 920680,
	Id681 = 920681,
	Id682 = 920682,
	Id683 = 920683,
	Id684 = 920684,
	Id685 = 920685,
	Id686 = 920686,
	Id687 = 920687,
	Id688 = 920688,
	Id689 = 920689,
	Id690 = 920690,
	Id691 = 920691,
	Id692 = 920692,
	Id693 = 920693,
	Id694 = 920694,
	Id695 = 920695,
	Id696 = 920696,
	Id697 = 920697,
	Id698 = 920698,
	Id699 = 920699,
	Id700 = 920700,
	Id701 = 920701,
	Id702 = 920702,
	Id703 = 920703,
	Id704 = 920704,
	Id705 = 920705,
	Id706 = 920706,
	Id707 = 920707,
	Id708 = 920708,
	Id709 = 920709,
	Id710 = 920710,
	Id711 = 920711,
	Id712 = 920712,
	Id713 = 920713,
	Id714 = 920714,
	Id715 = 920715,
	Id716 = 920716,
	Id717 = 920717,
	Id718 = 920718,
	Id719 = 920719,
	Id720 = 920720,
	Id721 = 920721,
	Id722 = 920722,
	Id723 = 920723,
	Id724 = 920724,
	Id725 = 920725,
	Id726 = 920726,
	Id727 = 920727,
	Id728 = 920728,
	Id729 = 920729,
	Id730 = 920730,
	Id731 = 920731,
	Id732 = 920732,
	Id733 = 920733,
	Id734 = 920734,
	Id735 = 920735,
	Id736 = 920736,
	Id737 = 920737,
	Id738 = 920738,
	Id739 = 920739,
	Id740 = 920740,
	Id741 = 920741,
	Id742 = 920742,
	Id743 = 920743,
	Id744 = 920744,
	Id745 = 920745,
	Id746 = 920746,
	Id747 = 920747,
	Id748 = 920748,
	Id749 = 920749,
	Id750 = 920750,
	Id751 = 920751,
	Id752 = 920752,
	Id753 = 920753,
	Id754 = 920754,
	Id755 = 920755,
	Id756 = 920756,
	Id757 = 920757,
	Id758 = 920758,
	Id759 = 920759,
	Id760 = 920760,
	Id761 = 920761,
	Id762 = 920762,
	Id763 = 920763,
	Id764 = 920764,
	Id765 = 920765,
	Id766 = 920766,
	Id767 = 920767,
	Id768 = 920768,
	Id769 = 920769,
	Id770 = 920770,
	Id771 = 920771,
	Id772 = 920772,
	Id773 = 920773,
	Id774 = 920774,
	Id775 = 920775,
	Id776 = 920776,
	Id777 = 920777,
	Id778 = 920778,
	Id779 = 920779,
	Id780 = 920780,
	Id781 = 920781,
}
EquipmentInfoConfig[EquipmentInfoID.Id001] =
{
	Name = "项圈",
	Rarity = 2,
	Desc = "呜呜从小就戴着的铃铛项圈，是他很喜欢的配饰。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_wuwu_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id002] =
{
	Name = "对讲机",
	Rarity = 2,
	Desc = "由猫博士发明的通讯设备，呜呜专用配色，可以快速传递信息，但是干扰很大。\n“漆漆~这里是呜呜！收到请回复！”",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_wuwu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id003] =
{
	Name = "对讲机",
	Rarity = 2,
	Desc = "由猫博士发明的通讯设备，呜呜专用配色，可以快速传递信息，但是干扰很大。\n“漆漆~你看，我最近好像又胖了喵……”",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_wuwu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id004] =
{
	Name = "对讲机",
	Rarity = 2,
	Desc = "由猫博士发明的通讯设备，呜呜专用配色，可以快速传递信息，但是干扰很大。\n“漆漆最好了喵，会一直陪呜呜玩~”",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_wuwu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id005] =
{
	Name = "对讲机",
	Rarity = 2,
	Desc = "由猫博士发明的通讯设备，呜呜专用配色，可以快速传递信息，但是干扰很大。\n“呜呜不在的时候，漆漆会想呜呜喵？”",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_wuwu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id006] =
{
	Name = "对讲机",
	Rarity = 2,
	Desc = "由猫博士发明的通讯设备，呜呜专用配色，可以快速传递信息，但是干扰很大。\n“漆漆~我们一起吃好次的，好喵~”",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_wuwu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id007] =
{
	Name = "对讲机",
	Rarity = 2,
	Desc = "由猫博士发明的通讯设备，呜呜专用配色，可以快速传递信息，但是干扰很大。\n“漆漆~最近收到了新玩具喵，来我家玩喵~”",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_wuwu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id008] =
{
	Name = "对讲机",
	Rarity = 2,
	Desc = "由猫博士发明的通讯设备，呜呜专用配色，可以快速传递信息，但是干扰很大。\n“呜呜如果去很远的地方旅行，漆漆也会一起去喵？”",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_wuwu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id009] =
{
	Name = "对讲机",
	Rarity = 2,
	Desc = "由猫博士发明的通讯设备，呜呜专用配色，可以快速传递信息，但是干扰很大。\n“漆漆~我来找你玩了喵~~”",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_wuwu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id010] =
{
	Name = "对讲机",
	Rarity = 2,
	Desc = "由猫博士发明的通讯设备，呜呜专用配色，可以快速传递信息，但是干扰很大。\n“漆漆~有呜呜在，呜呜也会保护漆漆的喵~”",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_wuwu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id011] =
{
	Name = "对讲机",
	Rarity = 2,
	Desc = "由猫博士发明的通讯设备，呜呜专用配色，可以快速传递信息，但是干扰很大。\n“漆漆不怕喵~呜呜一直陪你喵~”",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_wuwu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id012] =
{
	Name = "铃铛",
	Rarity = 2,
	Desc = "呜呜送给漆漆的铃铛，是友情的证明。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_gugu_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id013] =
{
	Name = "对讲机",
	Rarity = 2,
	Desc = "由猫博士发明的通讯设备，漆漆专用配色，可以快速传递信息，但是干扰很大。\n“收到，收到，这里是漆漆~”",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_gugu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id014] =
{
	Name = "对讲机",
	Rarity = 2,
	Desc = "由猫博士发明的通讯设备，漆漆专用配色，可以快速传递信息，但是干扰很大。\n“喵~呜呜是橘色的，适合胖胖的喵~”",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_gugu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id015] =
{
	Name = "对讲机",
	Rarity = 2,
	Desc = "由猫博士发明的通讯设备，漆漆专用配色，可以快速传递信息，但是干扰很大。\n“喵~一起玩开心的喵~似乎马上要到冬天了喵……”",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_gugu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id016] =
{
	Name = "对讲机",
	Rarity = 2,
	Desc = "由猫博士发明的通讯设备，漆漆专用配色，可以快速传递信息，但是干扰很大。\n“喵~没有多想的喵~但是呜呜在漆漆就很高兴喵~”",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_gugu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id017] =
{
	Name = "对讲机",
	Rarity = 2,
	Desc = "由猫博士发明的通讯设备，漆漆专用配色，可以快速传递信息，但是干扰很大。\n“喵~~如果是自助餐的话一定要吃到肚皮撑住喵~”",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_gugu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id018] =
{
	Name = "对讲机",
	Rarity = 2,
	Desc = "由猫博士发明的通讯设备，漆漆专用配色，可以快速传递信息，但是干扰很大。\n“喵~~~呜呜身边的人会讨厌漆漆喵？”",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_gugu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id019] =
{
	Name = "对讲机",
	Rarity = 2,
	Desc = "由猫博士发明的通讯设备，漆漆专用配色，可以快速传递信息，但是干扰很大。\n“如果呜呜去很远的地方，漆漆会在这里等呜呜喵~”",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_gugu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id020] =
{
	Name = "对讲机",
	Rarity = 2,
	Desc = "由猫博士发明的通讯设备，漆漆专用配色，可以快速传递信息，但是干扰很大。\n“喵……感觉身体不太舒服喵……”",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_gugu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id021] =
{
	Name = "对讲机",
	Rarity = 2,
	Desc = "由猫博士发明的通讯设备，漆漆专用配色，可以快速传递信息，但是干扰很大。\n“喵~呜呜在感觉就有精神了喵~”",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_gugu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id022] =
{
	Name = "对讲机",
	Rarity = 2,
	Desc = "由猫博士发明的通讯设备，漆漆专用配色，可以快速传递信息，但是干扰很大。\n“喵~漆漆也会一直陪呜呜的喵~”",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_gugu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id023] =
{
	Name = "家传宝剑",
	Rarity = 2,
	Desc = "出门在外，以和为贵。遇到分歧，也要争取打成共识。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_05_jianshi_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id024] =
{
	Name = "主角光环",
	Rarity = 2,
	Desc = "只会在拥有坚强意志之人头上形成的光圈，出现后即成为天选之人，敌人与其作战时，会不自觉地放水。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_05_jianshi_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id025] =
{
	Name = "射膝弓",
	Rarity = 2,
	Desc = "由仁慈精灵制作的魔弓，射出来的箭会自动飞向敌人的膝盖，帮他提前退休。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_24_gongjianshou_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id026] =
{
	Name = "必中箭",
	Rarity = 2,
	Desc = "由爱之精灵制作的利箭，不过被射中后不会得到爱情，只会扣血。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_24_gongjianshou_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id027] =
{
	Name = "静心之秘药",
	Rarity = 2,
	Desc = "能够快速使人平复心情的古老药剂，每一粒都超级大，吃的时候要猛灌水，以免黏在喉咙部位，减低药效。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_16_lieren_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id028] =
{
	Name = "陷阱",
	Rarity = 2,
	Desc = "猎人自制的陷阱，是捕获白狼的重要工具，诱饵是猎人爱吃的蜂蜜肉脯，因此有时会捕获自己。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_16_lieren_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id029] =
{
	Name = "指南针",
	Rarity = 2,
	Desc = "容易迷路的人进行冒险时必备的道具，红色箭头会一直指向正北方。\n但它就是叫指南针。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_16_lieren_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id030] =
{
	Name = "卫兵头盔",
	Rarity = 2,
	Desc = "面对凶犯时必备的防具，因为常年受到击打而有多处已经变形，牢牢嵌在了头上，无法脱下。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_17_chengzhenweibing_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id031] =
{
	Name = "保暖护膝",
	Rarity = 2,
	Desc = "断送冒险生涯的有时候不是英勇牺牲，而是扭伤。卫兵找了认识的人做了一下简单处理，从此以后就落下了病根。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_17_chengzhenweibing_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id032] =
{
	Name = "自制路牌",
	Rarity = 2,
	Desc = "指路NPC特制的路牌，插在岔路口，下次经过时就不会走弯路了。令人难过的是大部分人都觉得路牌比指路NPC更有用。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_10_buluolaoda_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id033] =
{
	Name = "匹奇",
	Rarity = 2,
	Desc = "心爱的宠物猪，自从被指路NPC路见不平救了以后，就和指路NPC一直进行着指路的事业。对于那些饥肠辘辘的冒险家们来说则起到了望梅止渴的作用。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_10_buluolaoda_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id034] =
{
	Name = "地图涂鸦",
	Rarity = 2,
	Desc = "当说不清楚该怎么走时，指路NPC就会掏出这个来，让冒险家陷入更大的混乱。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_10_buluolaoda_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id035] =
{
	Name = "多功能锤",
	Rarity = 2,
	Desc = "内含大量机关的多功能锤，能够实现修理、分解、锻造、强化、改装等80余种用途，可惜每种功能都有成功率。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_31_tiejiang_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id036] =
{
	Name = "免责声明",
	Rarity = 2,
	Desc = "铁匠通过一系列手段才拿到的政府公文，里面明确指出因委托需要造成的装备损坏，铁匠不需要承担任何责任。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_31_tiejiang_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id037] =
{
	Name = "护目镜",
	Rarity = 2,
	Desc = "帅气的彩色眼镜，能够有效防护热切割时产生的火花对眼睛的伤害。不过铁匠戴着的主要原因还是因为比较时髦。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_31_tiejiang_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id038] =
{
	Name = "三条血",
	Rarity = 3,
	Desc = "副本高级雇员的特权，能带给冒险者强烈的压迫感，其实那个数字只是装饰品，并不能增加血条。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_12_xiaomowang_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id039] =
{
	Name = "魔王的大锤",
	Rarity = 3,
	Desc = "你以为是近战武器的时候，它是一个远程武器。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_12_xiaomowang_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id040] =
{
	Name = "玩家墓碑",
	Rarity = 3,
	Desc = "败倒在小魔王手中的冒险者的墓碑，小魔王挑了最好看的一座，一直带在身边，提醒自己要设计出更好更难的副本。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_12_xiaomowang_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id041] =
{
	Name = "魔杖",
	Rarity = 3,
	Desc = "威力强大的魔杖，外表看上去是一根神奇的木棍，简称神棍。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_06_mofashi_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id042] =
{
	Name = "魔法药水",
	Rarity = 3,
	Desc = "能够补充魔力的药水，不过喝完后没有地方补充。里面现在装的是魔法师爱喝的饮料。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_06_mofashi_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id043] =
{
	Name = "魔法卷轴",
	Rarity = 3,
	Desc = "记录了古代神秘魔法的羊皮卷，只有被魔法之神认可的人才能使用其中的力量，不然就得花钱买许可证了。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_06_mofashi_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id044] =
{
	Name = "勒紧的裤腰带",
	Rarity = 1,
	Desc = "家里最后一根腰带，其他东西都被细心的冒险者翻过带走了。饿了的时候，只要把腰带紧一紧就能营造出一种虚假的饱腹感。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_09_putongcunmin_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id045] =
{
	Name = "家当包裹",
	Rarity = 1,
	Desc = "塞下了全副家当的重要包裹，即使带在身边，偶尔还是会被路过的剑士询问能不能打开看看。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_09_putongcunmin_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id046] =
{
	Name = "主线任务-接",
	Rarity = 1,
	Desc = "拥有魔力的羊皮纸，只要写下要求，头上就会出现金色叹号，吸引冒险者前来帮忙。\n上面写着“……帮忙杀20个怪……”",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_20_laoyeye_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id047] =
{
	Name = "主线任务-交",
	Rarity = 1,
	Desc = "必须与主线接取卷轴配套使用的主线提交卷轴，如果不配套使用一定会被冒险者打。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_20_laoyeye_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id048] =
{
	Name = "支线任务-接",
	Rarity = 1,
	Desc = "魔力稍弱的任务卷轴，写下要求后头顶会出现蓝色叹号，只能吸引到热心的冒险者前来帮忙。\n上面写着“……提交道具20个……”",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_18_laonainai_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id049] =
{
	Name = "支线任务-交",
	Rarity = 1,
	Desc = "必须与支线接取卷轴配套使用的支线提交卷轴，如果不配套使用可能会被冒险者打。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_18_laonainai_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id050] =
{
	Name = "备用的骨头",
	Rarity = 2,
	Desc = "妈妈帮骨头兵准备的替换用骨头，如果在工作中意外受伤了，只要换上备用骨头就好了。\n不要让狗靠近。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_30_kulou_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id051] =
{
	Name = "地城工作证",
	Rarity = 2,
	Desc = "打败了300名同族竞争者后才获得的工作，是骨头兵非常珍惜的证件，背面印着它开心地笑着的照片，看上去十分惊悚。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_30_kulou_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id052] =
{
	Name = "深不见底包",
	Rarity = 2,
	Desc = "容量超级巨大的背包，旅行商人从不进货，但是却总有卖不完的货。\n莫非，旅行商人也是勇者？",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_14_lvxingshangren_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id053] =
{
	Name = "营业执照",
	Rarity = 2,
	Desc = "行商必备的资质证书，如果被警察问话的时候拿不出来，那么可能会遭到巨额罚款。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_14_lvxingshangren_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id054] =
{
	Name = "保命鞋",
	Rarity = 2,
	Desc = "拥有魔力的鞋子，感受到危险时会扇动翅膀从空中逃跑，不过飞行时鞋子的主人会大头朝下。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_14_lvxingshangren_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id055] =
{
	Name = "两条血",
	Rarity = 2,
	Desc = "精英怪物身份的象征，能够给冒险者们很大的压迫感，其实那个数字只是装饰品，并不能增加血条。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_13_dashouxiaodi_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id056] =
{
	Name = "狼牙棒",
	Rarity = 2,
	Desc = "布满尖刺的笨重铁棒，打到身上一定很疼。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_13_dashouxiaodi_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id057] =
{
	Name = "高级掉落品",
	Rarity = 2,
	Desc = "精英怪物特有掉落，不过会增加成为冒险者目标的概率。但它决定了怪物们的工资水平，所以冒着被击杀的风险也仍要带在身上。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_13_dashouxiaodi_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id058] =
{
	Name = "测试清单",
	Rarity = 2,
	Desc = "记录了过去所有霸格存在方式的清单，上面绘制了各种霸格存在的异兆。仅依靠人工核对的话，听说走完一遍就要一年的时间。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_29_QA_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id059] =
{
	Name = "全自动测试机",
	Rarity = 2,
	Desc = "由程序猿制作的性能强悍的自动测试机，能够自动筛选出99.99%的问题，极大地提升了寻找异虫霸格的效率，不过相传这个测试机本身也藏着霸格。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_29_QA_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id060] =
{
	Name = "报错配置表",
	Rarity = 2,
	Desc = "使游戏无法正常启动的关键道具，不过有时候也有很隐蔽的错误。那么这个游戏是不是也存在这样的问题呢？",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_28_bug_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id061] =
{
	Name = "死循环",
	Rarity = 2,
	Desc = "即使其内部也充满了矛盾。制造死循环，必须击败程序猿；击败程序猿，必须先制造死循环。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_28_bug_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id062] =
{
	Name = "矮人手枪",
	Rarity = 3,
	Desc = "由矮人制造的火枪，适合矮人和小孩使用。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_26_huoqiangshou_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id063] =
{
	Name = "火枪手帽",
	Rarity = 3,
	Desc = "潇洒帅气的帽子，上面的羽毛来自于火枪手第一次从天上打下来的大鸟。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_26_huoqiangshou_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id064] =
{
	Name = "黄金子弹",
	Rarity = 3,
	Desc = "拥有超强威力的黄金子弹，需要对火器进行改造后才能发射。因为造价非常昂贵，所以每次战斗结束后火枪手都会去回收这颗子弹。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_26_huoqiangshou_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id065] =
{
	Name = "左一刀",
	Rarity = 3,
	Desc = "东方世界的名刀“白楼”，因为左手拿起来更顺手，所以被改名为“左一刀”。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_08_cike_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id066] =
{
	Name = "右一刀",
	Rarity = 3,
	Desc = "东方世界的名刀“楼观”，因为右手拿起来更顺手，所以被改名为“右一刀”。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_08_cike_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id067] =
{
	Name = "狼族的证明",
	Rarity = 3,
	Desc = "狼族独特的配饰，戴上以后听觉会倍增，能够轻易发现附近的敌人,但也会下意识地对着月亮发出吼叫。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_08_cike_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id068] =
{
	Name = "神圣手杖",
	Rarity = 3,
	Desc = "特制输血手杖，用皮管子接通目标静脉后，就能直接输送血液了。\n呀，你是PK-IV血型啊？那就加不上了……",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_07_mushi_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id069] =
{
	Name = "加血奶瓶",
	Rarity = 3,
	Desc = "吊瓶改装的小奶瓶，使用外星的美味奶粉冲泡而成，渴的时候牧师自己也会喝两口。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_07_mushi_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id070] =
{
	Name = "爱心十字章",
	Rarity = 3,
	Desc = "能够给与人们爱与希望的圣物，在修道院中代代传承。据说，十字章会根据主人的性格变换中间的图案。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_07_mushi_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id071] =
{
	Name = "fiash",
	Rarity = 3,
	Desc = "动画制作的入门软件，能够轻松愉快地制作简易动画。\n别信他！我就是这么上当的！",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_27_donghua_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id072] =
{
	Name = "splne",
	Rarity = 3,
	Desc = "动画制作的晋级软件，能够应对复杂的需求，但是使用难度也同时提高，使得软件操作者的发际线也提高了。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_27_donghua_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id073] =
{
	Name = "2dmax",
	Rarity = 3,
	Desc = "动画制作的高级软件，使用了立体的骨骼系统，因此能够制作出更为复杂的立体动画，也能穿更复杂的模。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_27_donghua_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id074] =
{
	Name = "麦克风",
	Rarity = 3,
	Desc = "配音演员特制的话筒，能够很好地屏蔽噪音，只保留下配音演员美好的嗓音。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_15_peiyinyanyuan_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id075] =
{
	Name = "润喉糖",
	Rarity = 3,
	Desc = "薄荷味的糖丸，能够让疼痛的喉咙瞬间复活，副作用是会腹泻。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_15_peiyinyanyuan_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id076] =
{
	Name = "金音量勋章",
	Rarity = 3,
	Desc = "“谁是音量王”大赛中的冠军奖品，获奖者同时将获得了一百万元的配音合同，并由经纪公司帮忙推出一张专辑，专辑名为《为什么不奶我》。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_15_peiyinyanyuan_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id077] =
{
	Name = "键盘",
	Rarity = 3,
	Desc = "特别定制的机械键盘，打字时会有清脆悦耳的反馈音，听说是在11.11购物节用券后以一折价格买的。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_01_chengxuyuan_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id078] =
{
	Name = "报错日志",
	Rarity = 3,
	Desc = "能够快速定位错误的日志记录，得益于这种技巧，当代游戏的功能制作也可以越来越复杂，报错时也让人越来越头大。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_01_chengxuyuan_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id079] =
{
	Name = "再改就死刀",
	Rarity = 3,
	Desc = "一种以威慑为主的社交型武器，在面对游戏策划反复无常的提案修改时，可以有效减少其修改次数。\n“谁也别拉我，我今天一定要捅死这个策划！”",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_01_chengxuyuan_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id080] =
{
	Name = "手写笔",
	Rarity = 3,
	Desc = "特别定制的高精度画笔，能够随意画出想要的线条，然而会被用手绘板的人瞧不起。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_03_yuanhuameizi_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id081] =
{
	Name = "手绘板",
	Rarity = 3,
	Desc = "特别定制的超大块手绘板，所有专业数据都是一流水准，缺点是价格非常昂贵，会被用手写笔的人瞧不起。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_03_yuanhuameizi_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id082] =
{
	Name = "灵感",
	Rarity = 3,
	Desc = "看不见的小灯泡，需要依靠阅读及细心的生活体验才能累积的艺术感，感觉对了的时候脑中会忽然亮起来。有了它就可以同时瞧不起用手绘板和手写笔的人。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_03_yuanhuameizi_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id083] =
{
	Name = "屠龙枪",
	Rarity = 4,
	Desc = "使用陨铁锻造的传奇之枪，扳机就藏在枪柄处。\n我可没说这是什么枪，对吧？",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_25_longqishi_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id084] =
{
	Name = "龙盾牌",
	Rarity = 4,
	Desc = "使用陨铁锻造的传奇之盾，能够正面抵挡龙族的喷火器，不过因为导热性良好，被喷久了，会烫得拿不住起来。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_25_longqishi_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id085] =
{
	Name = "祖辈的项链",
	Rarity = 4,
	Desc = "传奇的龙骑士一族世代传承的龙牙项链，只有经历过长老的考验，才能够获得。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_25_longqishi_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id086] =
{
	Name = "龙族追踪雷达",
	Rarity = 4,
	Desc = "由外星的科学家帮忙制作的高性能雷达。一旦周围30米内发现有龙族的气息，就会放出悠扬的乐曲来。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_25_longqishi_4",
}
EquipmentInfoConfig[EquipmentInfoID.Id087] =
{
	Name = "喷火器",
	Rarity = 4,
	Desc = "在龙族和勇士们缔结卫生保护条例后，龙族一概使用喷火器喷火，不再直接用嘴巴喷火了，但它们还是习惯把喷火器藏在嘴里。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_23_long_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id088] =
{
	Name = "公主攻略指南",
	Rarity = 4,
	Desc = "一本粉红色的小册子，上面点缀着爱心和小星星，中间被巨大的利爪撕碎，看上去非常不和谐的画面，背后隐藏着一段不为人知的故事。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_23_long_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id089] =
{
	Name = "便携游戏机",
	Rarity = 4,
	Desc = "内置了大量小游戏的便携式游戏机，黑龙王子一看到就爱不释手。他的目标是所有游戏全白金奖杯。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_23_long_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id090] =
{
	Name = "游戏卡",
	Rarity = 4,
	Desc = "名叫怪物猎“人”的游戏，王子一看到就沉迷其中，听说可以玩几千个小时，其中一半时间是在跑图。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_23_long_4",
}
EquipmentInfoConfig[EquipmentInfoID.Id091] =
{
	Name = "红手套",
	Rarity = 4,
	Desc = "女王最喜欢的红手套，是由宫廷匠人用顶级绸缎缝制的。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_21_nvwangdaren_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id092] =
{
	Name = "来福",
	Rarity = 4,
	Desc = "从小陪伴女王成长的宠物犬来福，性格和女王一样活泼。遇到危险时，会挺身而出保护女王大人，然而大部分情况下它分不清什么才是危险。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_21_nvwangdaren_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id093] =
{
	Name = "旺财",
	Rarity = 4,
	Desc = "和女王非常投缘的小狗旺财，虽然没有血统证明，但是女王还是非常宠爱它，到哪里都会带着它。但似乎和来福关系不太好，两只狗一见面就打架。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_21_nvwangdaren_4",
}
EquipmentInfoConfig[EquipmentInfoID.Id094] =
{
	Name = "王冠",
	Rarity = 4,
	Desc = "王国的传世宝冠，上面镶嵌的超大颗蓝宝石引来了无数强盗的觊觎。据说曾经被外星盗贼偷走，最后被细心的卫兵找了回来。\n其实是被卫兵弄坏了，现在的只是玻璃赝品。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_21_nvwangdaren_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id095] =
{
	Name = "四条血",
	Rarity = 5,
	Desc = "能够很好地拖延Boss战的时间，同时也能给予冒险者恐怖的压迫感。这个数字是真的，他真的有四条血。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_11_damowang_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id096] =
{
	Name = "幽魂",
	Rarity = 5,
	Desc = "魔王家族继承人的法器，跟在历代魔王身边，必要时会根据自己的经验帮忙出主意。由于算是召唤物，因此被击杀时并不会掉落任何道具和经验。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_11_damowang_4",
}
EquipmentInfoConfig[EquipmentInfoID.Id097] =
{
	Name = "game over",
	Rarity = 5,
	Desc = "记录了冒险者圆满通关的录像带，每次看的时候大魔王都会为勇者们历经艰辛最后通关而感动，然后想办法提升魔王城堡的攻略难度。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_11_damowang_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id098] =
{
	Name = "隐藏结局",
	Rarity = 5,
	Desc = "记录了隐藏故事线的录像带，只有当冒险者做对了所有选择时，大魔王才能和冒险者一同观看。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Rpg_11_damowang_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id099] =
{
	Name = "公牛小跑",
	Rarity = 3,
	Desc = "仿照公牛豪车制作的玩具车，造型优美，是奶茶王子身份的象征。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_10_naicha_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id100] =
{
	Name = "影迷的信",
	Rarity = 3,
	Desc = "影迷们寄给奶茶王子的信件，里面充满了热烈的话语。王子表面上不在意，但是每一封都藏了起来。他不知道的是，这些其实都是手下花钱雇人写的。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_10_naicha_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id101] =
{
	Name = "提词器",
	Rarity = 3,
	Desc = "自从有了提词器后，奶茶王子现场的台词功力大幅提升，不过总是盯着提词器看，会不会被观众发现呢？",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_10_naicha_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id102] =
{
	Name = "波子小跑",
	Rarity = 3,
	Desc = "仿照超级赛车制作的玩具车，性能强悍，是汽水王子身份的象征。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_08_xuebi_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id103] =
{
	Name = "薄荷糖",
	Rarity = 3,
	Desc = "能够完美契合汽水冰爽口感的糖丸，嘴里说不出是疼痛还是刺激。哦，原来是咬到舌头了。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_08_xuebi_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id104] =
{
	Name = "修图工作站",
	Rarity = 3,
	Desc = "自从使用工作站后，王子的海报评价大幅提升，成为了家喻户晓的广告先生。有时也会接到不少学生合照的修图工作。\n“只把我修好看点就行了。”",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_08_xuebi_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id105] =
{
	Name = "捷猫小跑",
	Rarity = 3,
	Desc = "仿照奔马豪车制作的玩具车，奢华高调，是可乐王子身份的象征。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_07_kele_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id106] =
{
	Name = "荧光剂",
	Rarity = 3,
	Desc = "演唱会上粉丝会自行准备的道具，能够很好地活跃场上气氛，也可以在停电的时候抹在自己身上。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_07_kele_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id107] =
{
	Name = "调音台",
	Rarity = 3,
	Desc = "自从有了调音台后，可乐王子的演唱会再也不会翻车了。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_07_kele_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id108] =
{
	Name = "龙标小跑",
	Rarity = 3,
	Desc = "仿照最新式赛车制作的玩具车，采用了最新技术，是啤酒王子身份的象征。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_09_pijiu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id109] =
{
	Name = "隔音耳塞",
	Rarity = 3,
	Desc = "虽然酷爱音乐演奏，但是王子自己却一直戴着耳塞，因为他说最好的音乐家不是用耳朵去感受音乐的。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_09_pijiu_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id110] =
{
	Name = "醒酒药",
	Rarity = 3,
	Desc = "能够快速让醉酒之人苏醒的药丸，如果第二天要开会，那么今天不要喝得太过分。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_09_pijiu_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id111] =
{
	Name = "苹果",
	Rarity = 1,
	Desc = "代表红色糖豆味道的苹果，拥有爽脆的口感，如果希望身体瘦下来可以作为代餐食用。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_12_xiaohong_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id112] =
{
	Name = "运动短裤",
	Rarity = 1,
	Desc = "红色运动短裤，散发着苹果的香气，然而没有人会去闻。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_12_xiaohong_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id113] =
{
	Name = "橙子",
	Rarity = 1,
	Desc = "代表橙色糖豆味道的橙子，比工厂生产的橙汁要酸，但是好消息是这个不用剥皮就能吃。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_13_xiaocheng_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id114] =
{
	Name = "运动短裤",
	Rarity = 1,
	Desc = "橙色运动短裤，散发着橙子的香气，然而没有人会去闻。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_13_xiaocheng_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id115] =
{
	Name = "柠檬",
	Rarity = 1,
	Desc = "代表黄色糖豆味道的柠檬，剧烈的酸味会让吃的人忍不住唱歌。\n夢ならばどれほどよかったでしょう~",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_14_xiaohuang_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id116] =
{
	Name = "运动短裤",
	Rarity = 1,
	Desc = "黄色运动短裤，散发着柠檬的香气，然而没有人会去闻。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_14_xiaohuang_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id117] =
{
	Name = "奇异果",
	Rarity = 1,
	Desc = "代表绿色糖豆味道的奇异果，酸酸甜甜很可口，里面的小黑籽可以直接吃下去。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_15_xiaolv_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id118] =
{
	Name = "运动短裤",
	Rarity = 1,
	Desc = "绿色运动短裤，散发着奇异果的香气，然而没有人会去闻。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_15_xiaolv_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id119] =
{
	Name = "蓝莓",
	Rarity = 1,
	Desc = "代表青色糖豆味道的蓝莓，含有丰富的水分，看起来十分饱满。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_17_xiaoqing_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id120] =
{
	Name = "运动短裤",
	Rarity = 1,
	Desc = "青色运动短裤，散发着蓝莓的香气，然而没有人会去闻。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_17_xiaoqing_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id121] =
{
	Name = "薄荷",
	Rarity = 1,
	Desc = "代表蓝色糖豆味道的薄荷，拥有冰爽镇静的效果，喉咙痛的时候可以吃一颗。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_16_xiaolan_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id122] =
{
	Name = "运动短裤",
	Rarity = 1,
	Desc = "蓝色运动短裤，散发着薄荷的香气，然而没有人会去闻。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_16_xiaolan_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id123] =
{
	Name = "葡萄",
	Rarity = 1,
	Desc = "代表紫色糖豆味道的葡萄,在吃的时候经常会犹豫要不要吐皮。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_18_xiaozi_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id124] =
{
	Name = "运动短裤",
	Rarity = 1,
	Desc = "紫色运动短裤，散发着葡萄的香气，然而没有人会去闻。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_18_xiaozi_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id125] =
{
	Name = "超大糖球",
	Rarity = 2,
	Desc = "超巨大的糖球，如果不用咬的话，可能要吃一年，但它的保质期只有半年。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_05_bangbangtang_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id126] =
{
	Name = "高级行李箱",
	Rarity = 2,
	Desc = "棒棒糖女仆的全副家当，自从家里的豪宅被查封后，只能带着它到处流浪。必要的时候棒棒糖女仆自己可以住进去。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_05_bangbangtang_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id127] =
{
	Name = "咖啡豆",
	Rarity = 2,
	Desc = "咖啡女仆随身携带的高浓度咖啡豆，泡在水中十分钟，就能烹调出一杯浓郁的咖啡。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_06_kafei_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id128] =
{
	Name = "咖啡伴侣",
	Rarity = 2,
	Desc = "为想要提神但又怕苦的人专门准备的咖啡添加剂，使用奶精制成。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_06_kafei_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id129] =
{
	Name = "华夫饼",
	Rarity = 2,
	Desc = "切片的华夫饼，饿的时候可以填饱肚子。有时会跟蜂窝搞混。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_25_huafubing_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id130] =
{
	Name = "魔力打蛋器",
	Rarity = 2,
	Desc = "能够完美地将蛋液打匀的打蛋器，是仙子们通过考验后才能获得的礼物，上面还粘着没来得及撕下来的网购爆款商标。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_25_huafubing_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id131] =
{
	Name = "松饼",
	Rarity = 2,
	Desc = "美味的松饼，从上面俯视能得到完美的圆形。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_26_tongluoshao_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id132] =
{
	Name = "魔力酒精",
	Rarity = 2,
	Desc = "能够完美地去除食物中的腥味的酒精，是仙子们通过考验后才能获得的礼物。未成年人不能参加挑战。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_26_tongluoshao_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id133] =
{
	Name = "布丁",
	Rarity = 2,
	Desc = "大块的布丁，只要戳一下，就会晃个不停，里面蕴含着能让人长胖数十斤的强大魔力。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_27_buding_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id134] =
{
	Name = "布丁瓶",
	Rarity = 2,
	Desc = "把价值一百金币的布丁用价值两金币的瓶子包装起来，就可以以五百金币的价格卖出。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_27_buding_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id135] =
{
	Name = "鲜虾",
	Rarity = 2,
	Desc = "长得很像鲜虾的虾标本，让人们一看到它就能联想到美味的海鲜。\n现在你知道了吧，虾条里根本就没有虾。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_20_xiatiao_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id136] =
{
	Name = "干燥剂",
	Rarity = 2,
	Desc = "薯片夫人为女儿准备的干燥剂包，能够保持女儿松脆的口感，避免受潮。但也有一部分喜欢软绵绵口感的人和老年人对此表示不满。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_20_xiatiao_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id137] =
{
	Name = "香脆炸片",
	Rarity = 2,
	Desc = "形状和味道与众不同的香脆炸片，每包妙脆角里都会藏有一片，是其中的灵魂。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_21_miaocuijiao_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id138] =
{
	Name = "调味包",
	Rarity = 2,
	Desc = "薯片夫人为女儿特别制作的小粉包，能够满足女儿各种各样的香味需要，有时也会诞生出一些非常魔幻的味道。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_21_miaocuijiao_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id139] =
{
	Name = "超薄五花肉",
	Rarity = 3,
	Desc = "由完美刀工切出来的超薄五花肉片，戴在头上能够很好地遮住热滚滚的太阳，但不能晒得太久，否则会有油滴下来。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_23_peigen_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id140] =
{
	Name = "腌制香料",
	Rarity = 3,
	Desc = "由培根女巫制作的香料，与培根结合时会使香味急剧增长，但配方一直严格保密，绝不泄露。\n不然你以为她为什么是女巫？",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_23_peigen_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id141] =
{
	Name = "大片生菜",
	Rarity = 3,
	Desc = "可以有效缓解五花肉油腻口感的大片蔬菜，是烤肉自助后期强行吃肉不可或缺的利器，但也是某些高级肉食主义者眼中最为下贱的存在。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_23_peigen_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id142] =
{
	Name = "罐装睡袋",
	Rarity = 3,
	Desc = "长筒型的睡袋，能够让薯片夫人安心入睡。不要把盖子扣死，不然很难打开。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_19_shupian_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id143] =
{
	Name = "遮阳帽",
	Rarity = 3,
	Desc = "由名家设计的遮阳帽，很有名媛风范，唯一的问题是质地过脆，很容易断裂。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_19_shupian_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id144] =
{
	Name = "优质土豆",
	Rarity = 3,
	Desc = "被薯条国王保管的顶级土豆，据说在遥远的世界被当作服务器使用。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_19_shupian_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id145] =
{
	Name = "超黑巧克力",
	Rarity = 3,
	Desc = "纯度达到97%的超黑巧克力，吃起来像在嚼干草一样。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_11_tiantong_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id146] =
{
	Name = "诚实魔镜",
	Rarity = 3,
	Desc = "服务器的前端界面，可以用来查询星球中各大排行榜以及网红粉丝数。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_11_tiantong_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id147] =
{
	Name = "懂事魔镜",
	Rarity = 3,
	Desc = "黑巧克力皇后从女巫那里取得的另一面魔镜，相比诚实魔镜，这面镜子的回答总是非常得体，哪怕说出来的话它自己都不信。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_11_tiantong_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id148] =
{
	Name = "睡帽",
	Rarity = 3,
	Desc = "有着柔软毛边的睡帽，戴上它后就会引发人们的睡意，久而久之就会变成不戴帽子就睡不着的情况。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_04_mianhuatang_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id149] =
{
	Name = "枕头",
	Rarity = 3,
	Desc = "松软的棉花糖枕头，躺上去的时候，头就会深深地陷落，被枕头包围。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_04_mianhuatang_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id150] =
{
	Name = "魔力糖浆",
	Rarity = 3,
	Desc = "能够赋予食物一种快乐力量的糖浆，是仙子们送给棉花糖公主的礼物，一口能把血糖拉高两个数。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_27_buding_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id151] =
{
	Name = "冰淇淋球",
	Rarity = 3,
	Desc = "香浓可口的冰淇淋球，用特制的勺子舀到甜筒上，就做成了蛋筒，虽然并没有蛋的要素。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_01_songbing_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id152] =
{
	Name = "红色头饰",
	Rarity = 3,
	Desc = "冰淇淋公主从小就带着的红色蝴蝶结，充满了童话的感觉。\n注：不能变声。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_01_songbing_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id153] =
{
	Name = "缺角苹果",
	Rarity = 3,
	Desc = "冰淇淋公主最喜欢的水果，缺掉的那块卡在了喉咙里。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_01_songbing_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id154] =
{
	Name = "蛋糕卷",
	Rarity = 3,
	Desc = "烘烤时会发出诱人香味的蛋糕卷，盯着看久了会打瞌睡。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_02_dangaojuan_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id155] =
{
	Name = "草莓头饰",
	Rarity = 3,
	Desc = "被放在蛋糕卷上做装饰的水果，不过大家吃的时候都会把它拿下来丢在一边。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_02_dangaojuan_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id156] =
{
	Name = "水晶托盘",
	Rarity = 3,
	Desc = "蛋糕卷公主自制的水晶托盘，每次参加舞会都会带上，不过因为一直弄丢，所以被薯片夫人没收保管了起来。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_02_dangaojuan_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id157] =
{
	Name = "顶级栗子",
	Rarity = 3,
	Desc = "顶级的小栗子，听说越小越香糯，大颗的口感反而比较木。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_03_qiaokelidan_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id158] =
{
	Name = "慕斯发胶",
	Rarity = 3,
	Desc = "把慕斯喷在头上并不能定型，反而会增加洗头的难度。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_03_qiaokelidan_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id159] =
{
	Name = "吹风机",
	Rarity = 3,
	Desc = "可以加速慕斯黏在头发上的吹风机，让清洗更加困难。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_03_qiaokelidan_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id160] =
{
	Name = "上半片面包",
	Rarity = 3,
	Desc = "色泽金黄的烤面包，上面通常撒有芝麻。在整个汉堡中担任主食的角色。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_29_hanbao_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id161] =
{
	Name = "下半片面包",
	Rarity = 3,
	Desc = "色泽黯淡的烤面包，下面通常有点焦痕。在整个汉堡中担任主食的角色。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_29_hanbao_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id162] =
{
	Name = "肉饼",
	Rarity = 3,
	Desc = "使用碎肉制作而成的牛肉汉堡，即使单独拿出来吃味道也非常鲜美。任性一点加三片的话，会更让人满足。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_29_hanbao_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id163] =
{
	Name = "热狗面包",
	Rarity = 3,
	Desc = "松软的面包棒，烘烤过后，外皮香脆，内部松软，是绝佳的热狗面包。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_24_regou_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id164] =
{
	Name = "热狗肠",
	Rarity = 3,
	Desc = "热狗先生的秘密武器。平时很友善的热狗先生，一旦被惹急后，就会从身上掏出这根香肠多截棍，打得对方满地找牙。\n因为嚼不动。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_24_regou_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id165] =
{
	Name = "芥末酱",
	Rarity = 3,
	Desc = "与热狗肠在一起简直是绝配的芥末酱料，不仅使食物外观看起来更诱人，在口味上也让人感到不可思议。\n这是他被女孩子们拒绝的根本原因。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_24_regou_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id166] =
{
	Name = "番茄",
	Rarity = 3,
	Desc = "番茄酱侍卫随身携带的顶级番茄。刚刚从隔壁的二级菜棚摘下来，上面有着新鲜的香气。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_31_fanqiejiang_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id167] =
{
	Name = "瓶盖",
	Rarity = 3,
	Desc = "宫廷侍卫专属的帽子，非常威武，番茄酱侍卫每天都会细心清理这顶帽子，上面大部分污渍都是自己的酱。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_31_fanqiejiang_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id168] =
{
	Name = "皇家商标",
	Rarity = 3,
	Desc = "皇家认证的商标，听说必须得到薯条国王的认可，才能拥有。认证很难，但伪造很容易。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_31_fanqiejiang_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id169] =
{
	Name = "烧烤叉",
	Rarity = 4,
	Desc = "无论是插鱼或叉鸡腿，稳定性都一样优秀的特制烧烤叉。但是整个叉子都是铁做的，用手拿着烧烤可能会烫伤。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_28_jichi_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id170] =
{
	Name = "皇后礼服",
	Rarity = 4,
	Desc = "由皇家裁缝为炸鸡魔后定制的礼服，很有皇后的威严，布料上有一种油腻的味道，能够勾起人的食欲。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_28_jichi_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id171] =
{
	Name = "美味炸鸡",
	Rarity = 4,
	Desc = "经过大量调味粉腌制过的鸡翅，使用上等木炭烧烤时会散发浓烈的香味。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_28_jichi_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id172] =
{
	Name = "秘制酱料",
	Rarity = 4,
	Desc = "炸鸡魔后亲自研发的烧烤酱料，使用了夹心肉球一族不外传的秘方，配合上等原料，使酱料的水准达到了新的高度。但对于不吃辣的人来说比较遗憾。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_28_jichi_4",
}
EquipmentInfoConfig[EquipmentInfoID.Id173] =
{
	Name = "玉米",
	Rarity = 4,
	Desc = "金色的玉米粒，在爆米花机中却能够绽放出美丽的香甜礼花，如果提前打开，就会在人的脸上绽放出美丽的香甜礼花。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_22_baomihua_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id174] =
{
	Name = "精致黄油",
	Rarity = 4,
	Desc = "必须使用精致黄油才能最好地展现出爆米花的魅力，但有时会跟香皂搞混。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_22_baomihua_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id175] =
{
	Name = "套餐兑换券",
	Rarity = 4,
	Desc = "为了挽救王子电影的销量而制作的爆米花套餐兑换券，不成想却增加了爆米花的销量。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_22_baomihua_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id176] =
{
	Name = "爆米花盒",
	Rarity = 4,
	Desc = "有多种尺寸的包装盒，通常买情侣分享装要比买两个单人装划算得多，也适合单身但是饭量大的客人和自己分享。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_22_baomihua_4",
}
EquipmentInfoConfig[EquipmentInfoID.Id177] =
{
	Name = "健身背心",
	Rarity = 5,
	Desc = "薯条国王的健身背心，能够充分展现薯条国王的肌肉线条。背心上的商标是著名的快餐品牌，深受美食星居民喜爱。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_30_shutiao_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id178] =
{
	Name = "皇家植物油",
	Rarity = 5,
	Desc = "由宫廷御厨特制的植物油，薯条国王每天都会用它来泡澡，据说整个皇宫都会被香得神魂颠倒。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_30_shutiao_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id179] =
{
	Name = "杠铃",
	Rarity = 5,
	Desc = "薯条国王唯一的健身器材，不过依靠杠铃，薯条国王就能锻炼到全身所有的肌肉。\n不过薯条身上为什么会有这么多肌肉呢？",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_30_shutiao_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id180] =
{
	Name = "杠铃替换箱",
	Rarity = 5,
	Desc = "存放了薯条国王替换用的杠铃铁饼，听说连举重运动员也无法搬动。\n因为上面太油了，抓不住。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_30_shutiao_4",
}
EquipmentInfoConfig[EquipmentInfoID.Id181] =
{
	Name = "速写本",
	Rarity = 3,
	Desc = "活页速写本，侦探小姐会根据目击者描述来画出罪犯相貌，画出来的角色为什么都觉得像少女恋爱漫画里的男性角色？",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_17_zhentanxiaojie_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id182] =
{
	Name = "超长焦镜头",
	Rarity = 3,
	Desc = "由博士制造的2000倍变焦超长焦镜头，可以穿过大气层，捕捉到外星的画面。但是因为没有光而什么都看不到。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_17_zhentanxiaojie_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id183] =
{
	Name = "侦探风衣",
	Rarity = 3,
	Desc = "侦探的基本装备，男女都不例外。如果不穿的话，那不说话时和普通人就没有区别了。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_17_zhentanxiaojie_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id184] =
{
	Name = "小偷面罩-L",
	Rarity = 3,
	Desc = "从街拐口的10元店里偷来的大块方巾，罩在脸上正好匹配浣熊大哥的脸型，甚至还给胡须留了洞。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_13_dage_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id185] =
{
	Name = "超大包裹",
	Rarity = 3,
	Desc = "斑马条纹的大布包，使用囚衣改造，花纹看起来总觉得很不详。是开始爆窃事业必备的工具。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_13_dage_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id186] =
{
	Name = "铲子",
	Rarity = 3,
	Desc = "轻便的工兵铲，无论挖地道或是砸箱子都能完美胜任。是开始爆窃事业必备的工具。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_13_dage_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id187] =
{
	Name = "小偷面罩-M",
	Rarity = 3,
	Desc = "从街拐口的10元店里偷来的中等块方巾，罩在脸上正好匹配浣熊二哥的脸型，甚至还给耳朵留了洞。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_14_erge_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id188] =
{
	Name = "蓝色包袱",
	Rarity = 3,
	Desc = "柔软的大布包，能够装下大量货物。\n没想到吧，其实里面是8*8的。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_14_erge_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id189] =
{
	Name = "钳子",
	Rarity = 3,
	Desc = "装有特殊机械臂的超长钳子，可以从天花板的通风口轻松地将展柜内的珠宝夹走，但如果力量太大的话会把珠宝夹碎。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_14_erge_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id190] =
{
	Name = "小偷面罩-S",
	Rarity = 3,
	Desc = "从街拐口的10元店里偷来的小块方巾，罩在脸上正好匹配浣熊小弟的脸型，但是什么洞都没有留下。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_15_xiaodi_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id191] =
{
	Name = "隐身叶片",
	Rarity = 3,
	Desc = "由浣熊族的忍术大师特制的魔力叶片，相传只要顶在额头上就可以隐身。\n似乎，按住奔跑键还能飞？",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_15_xiaodi_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id192] =
{
	Name = "焊枪",
	Rarity = 3,
	Desc = "即使面对全钢板封锁的顶级保险库也能完全搞定的超高温喷枪，稍有不慎，可能保险柜里的东西也不复存在了……",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_15_xiaodi_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id193] =
{
	Name = "对讲机",
	Rarity = 3,
	Desc = "虽然保安队只有一个保安，但是佩戴对讲机并适时使用可以有效迷惑不法分子。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_27_baoan_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id194] =
{
	Name = "鼻涕泡",
	Rarity = 3,
	Desc = "当保安睡着的时候，鼻涕泡会感受附近的气流，一旦发现异动，就会破掉惊醒睡着的保安。\n不要拿它蹭人。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_27_baoan_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id195] =
{
	Name = "保温杯",
	Rarity = 3,
	Desc = "人过中年，远离父母，生活无依无靠，至今仍然单身，还要守夜。世态炎凉，只有这保温杯里的菊花茶还有点温度。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_27_baoan_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id196] =
{
	Name = "下半身",
	Rarity = 1,
	Desc = "说是半身，实际上根本没有一半。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_07_fuhuoshixiang_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id197] =
{
	Name = "防晒霜",
	Rarity = 1,
	Desc = "石像就不要面子的嘛？",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_07_fuhuoshixiang_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id198] =
{
	Name = "腰上的膏药",
	Rarity = 1,
	Desc = "兵马俑贴在腰上的膏药，能够缓解常年站岗引发的腰痛病。也可能只能起到心理作用，毕竟兵马俑没有关节和骨头。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_06_binmayong_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id199] =
{
	Name = "出土照片",
	Rarity = 1,
	Desc = "能够大幅提升文物待遇级别的证书，上面记载着兵马俑的出土日期、出土户籍、出土陵墓以及出土证号。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_06_binmayong_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id200] =
{
	Name = "脖子的膏药",
	Rarity = 1,
	Desc = "石柱人贴在脖子上的药膏，能够缓解常年挺立，头顶天花板而引起的颈椎病。\n不要误解了，他并不是老师。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_10_shizhuren_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id201] =
{
	Name = "保鲜膜",
	Rarity = 1,
	Desc = "为了避免风蚀而卷在身上的保鲜膜，但是保鲜膜所保护的东西的保质期比它自己还长。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_10_shizhuren_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id202] =
{
	Name = "膝盖的膏药",
	Rarity = 1,
	Desc = "半人马石像贴在膝盖上的膏药，能够缓解始终保持跑步姿势而引发的关节炎，或者说是他假装自己有关节。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_11_banrenma_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id203] =
{
	Name = "轮滑",
	Rarity = 1,
	Desc = "你以为石像就不能动吗？",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_11_banrenma_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id204] =
{
	Name = "画框",
	Rarity = 2,
	Desc = "精致的木画框，使用优质木材打造，内部设有报警器和追踪器。但当报警器响起来的时候，一般就听不到追踪器了。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_22_yadang_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id205] =
{
	Name = "灵气",
	Rarity = 2,
	Desc = "与神圣接触的那一刹，灵气来到了这个世界。\n它其实只是个会发光的球。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_22_yadang_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id206] =
{
	Name = "画框",
	Rarity = 2,
	Desc = "精致的木画框，使用优质木材打造，内部设有报警器和追踪器。但当追踪器响起来的时候，一般就听不到报警器了。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_23_chuangzaozhishen_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id207] =
{
	Name = "小天使",
	Rarity = 2,
	Desc = "飞翔在天神周围的小天使，会叽叽喳喳地说个不停。因为语言不通，大家都以为他们在背诵教条，其实只是在讨论明天中午吃什么。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_23_chuangzaozhishen_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id208] =
{
	Name = "画框",
	Rarity = 2,
	Desc = "精致的木画框，使用优质木材打造，内部设有报警器和追踪器。报警器和追踪器的声音还没她的哭声大。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_28_kuqidenvren_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id209] =
{
	Name = "错乱几何",
	Rarity = 2,
	Desc = "扭曲了真实形象的几何图形，错乱排列造成了各种不同的解读。某些考生看到这种图案就会条件反射的头痛。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_28_kuqidenvren_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id210] =
{
	Name = "画框",
	Rarity = 2,
	Desc = "精致的木画框，使用优质木材打造，内部设有报警器和追踪器。报警器和追踪器的声音还没他喊的声音大。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_19_nahan_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id211] =
{
	Name = "/恐惧",
	Rarity = 2,
	Desc = "看到后就会不自觉地想要喊出来的表情\n啊~~~~~~~~~~~~",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_19_nahan_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id212] =
{
	Name = "火腿大棒",
	Rarity = 2,
	Desc = "应该是来自一只大型动物身上的骨头棒子，看起来很难嚼的样子。\n你应该咬肉，而不是骨头。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_24_yuanshirenbaba_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id213] =
{
	Name = "私房钱",
	Rarity = 2,
	Desc = "原始人爸爸无意间得到的储蓄罐，不过用这种储蓄罐子也藏不了多少钱。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_24_yuanshirenbaba_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id214] =
{
	Name = "平底锅",
	Rarity = 2,
	Desc = "原始人妈妈为全家人烹饪用的平底锅，不过妈妈只会煮爸爸爱吃的肉，自己爱吃的鱼和儿子爱吃的蛋这3个菜。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_25_yuanshirenmama_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id215] =
{
	Name = "工资卡",
	Rarity = 2,
	Desc = "原始人爸爸的工资卡，每月发工资时，原始人妈妈会拿出50块钱给爸爸当生活费。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_25_yuanshirenmama_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id216] =
{
	Name = "大棒",
	Rarity = 2,
	Desc = "用粗重的木棍临时组成的大棒子，上面的毛刺扎进身体里会让人发炎。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_26_yuanshirenerzi_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id217] =
{
	Name = "假发",
	Rarity = 2,
	Desc = "游客参观时留下来的假发，原始人儿子捡到后就一直戴在头上。\n那其实是胡子。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_26_yuanshirenerzi_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id218] =
{
	Name = "绷带",
	Rarity = 2,
	Desc = "嘘，别告诉木乃伊，这其实是厕纸。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_05_munaiyi_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id219] =
{
	Name = "圣甲虫",
	Rarity = 2,
	Desc = "象征着日出及再生的昆虫，当死者被制成木乃伊后，他的心脏会被取出，而用缀满圣甲虫的石头代替。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_05_munaiyi_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id220] =
{
	Name = "防腐涂料",
	Rarity = 2,
	Desc = "特殊的防腐涂料，能够保持尸体始终新鲜，这样就能在末日来临那天重获新生。\n不可食用，请放在幼儿够不到的地方。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_05_munaiyi_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id221] =
{
	Name = "画框",
	Rarity = 3,
	Desc = "精致的木画框，使用优质木材打造，内部设有报警器和追踪器。\n它们都能正常运作。怎么了，你在等什么？",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_18_zhenzhuerhuan_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id222] =
{
	Name = "头巾",
	Rarity = 3,
	Desc = "使得画面整体一亮的头巾，有着鲜艳的配色，让人们感受到了年轻的活力。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_18_zhenzhuerhuan_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id223] =
{
	Name = "珍珠耳环",
	Rarity = 3,
	Desc = "在黑暗中若隐若现的珍珠耳环，为整幅画作增添了一种安静祥和的气氛。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_18_zhenzhuerhuan_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id224] =
{
	Name = "猪蹄印章",
	Rarity = 3,
	Desc = "猪蹄古董盖章专用的小印章，上面刻着“阅”。博物馆星经常有一些老师借来批暑假作业。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_20_zhutigudong_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id225] =
{
	Name = "诗集",
	Rarity = 3,
	Desc = "每当猪蹄古董发现不错的求爱诗时，都会把它摘录到这本册子里，然后翻着花样写给不同的对象。\n“烽火戏诸侯？这个点子很不错啊！”",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_20_zhutigudong_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id226] =
{
	Name = "撩人鸟玉牌",
	Rarity = 3,
	Desc = "古老又神秘的玉佩，能够读懂主人的心意，自动搜索附近可能合主人心意的女孩子。成功发现以后，会对着那边不停地发出口哨声，被打概率高达百分之九十。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_20_zhutigudong_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id227] =
{
	Name = "纷争匕首",
	Rarity = 3,
	Desc = "象征着众生的纷争的权杖，意味着生灵间的斗争永远不会停息，将伴随众生直到世界末日的到来。\n和心爱的你行至世界尽头。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_03_Set_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id228] =
{
	Name = "战争宝冠",
	Rarity = 3,
	Desc = "能带来战争的宝冠，看到宝冠的人就会充满戾气，希望通过战争解决一切问题。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_03_Set_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id229] =
{
	Name = "风暴图腾",
	Rarity = 3,
	Desc = "标志着世界之风的符号，在特定地点画出这个符文，就能引来剧烈的风暴，但也会把画符文的人卷进去。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_03_Set_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id230] =
{
	Name = "元素手杖",
	Rarity = 3,
	Desc = "象征着元素力量的权杖，意味着世界的基本构成，不过这件事情各星球科学家有截然不同的观点，比方说这个手杖是由什么元素构成的。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_04_Sobek_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id231] =
{
	Name = "守护宝冠",
	Rarity = 3,
	Desc = "能够保护人免于灾祸的宝冠，只要围在它附近就不会遭到天灾的侵害。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_04_Sobek_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id232] =
{
	Name = "四元素图腾",
	Rarity = 3,
	Desc = "绘制着构成世界的四大元素，水、火、风、还有一个已经看不清了。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_04_Sobek_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id233] =
{
	Name = "沃斯手杖",
	Rarity = 3,
	Desc = "象征着能量的权杖，能够激发人们内心的力量，使人变得更愤怒，更激动或更悲伤。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_02_Horus_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id234] =
{
	Name = "王权宝冠",
	Rarity = 3,
	Desc = "代表至高王权的小兜帽，经由荷鲁斯反馈，专门定制的休闲款。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_02_Horus_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id235] =
{
	Name = "安卡的图腾",
	Rarity = 3,
	Desc = "形状像眼睛的符号，表示着来自未知空间的注视者，让法老王恢复记忆的关键道具。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_02_Horus_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id236] =
{
	Name = "丰饶手杖",
	Rarity = 3,
	Desc = "象征着丰收的权杖，如果竖起来，就表示今年会是丰年，如果倒下来，那么今年就要饿肚子。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_01_Anubis_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id237] =
{
	Name = "阿努比斯宝石",
	Rarity = 3,
	Desc = "如同蓝色瞳孔般深邃的宝石，长时间注视会产生幻觉，觉得自己是一只黑色的大狗。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_01_Anubis_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id238] =
{
	Name = "冥神的图腾",
	Rarity = 3,
	Desc = "以未知力量连接着凡间与冥界的符号，正确地绘制能够引导幽冥重返人间。\n好了，哪里是头？",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_01_Anubis_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id239] =
{
	Name = "画框",
	Rarity = 4,
	Desc = "精致的木画框，使用优质木材打造，内部设有报警器和追踪器。但他只有一只耳朵，只能听到一种。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_08_fangao_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id240] =
{
	Name = "向日葵",
	Rarity = 4,
	Desc = "充满了对生命歌颂的向日葵。当你感到无精打采时，请试想，每天睁开眼来迎接阳光，你就已经与新一天的世界融为一体。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_08_fangao_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id241] =
{
	Name = "耳朵",
	Rarity = 4,
	Desc = "每个人的心情是他人很难感受到的，无论情绪有多么强烈，他人或许都会误读，或许这就是这只耳朵被割下来的原因。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_08_fangao_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id242] =
{
	Name = "画框",
	Rarity = 4,
	Desc = "精致的木画框，使用优质木材打造，内部设有报警器和追踪器。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_29_folida_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id243] =
{
	Name = "鲜花头饰",
	Rarity = 4,
	Desc = "生长在野外的美丽花朵，任由风吹雨打，不如温室花朵精美，但顽强的生命力和自然野性足以让人重新思考美的意义。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_29_folida_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id244] =
{
	Name = "超粗眉笔",
	Rarity = 4,
	Desc = "每天出门前，在眉毛上只需画上一笔就能搞定的特制眉笔，不过一字眉的造型好看吗？",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_29_folida_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id245] =
{
	Name = "画框",
	Rarity = 4,
	Desc = "精致的木画框，使用优质木材打造，内部设有报警器和追踪器。\n我实在编不下去了。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_21_mengnalisha_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id246] =
{
	Name = "33.33%的微笑",
	Rarity = 4,
	Desc = "这个笑容之中包含了83%的高兴、7%的厌恶、4%的恐惧和2%的愤怒。\n它们加起来并不等于百分之百。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_21_mengnalisha_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id247] =
{
	Name = "达芬奇的遗书",
	Rarity = 4,
	Desc = "致最美的夫人，这是完美微笑的秘诀：\nA*(S+T+F)-(W+L)",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_21_mengnalisha_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id248] =
{
	Name = "单眼镜片",
	Rarity = 4,
	Desc = "充满绅士气息的单片眼镜，厚重的镜片让人完全无法看到镜片后的眼睛。\n它到底是怎么固定住的？",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_16_yelifushentou_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id249] =
{
	Name = "优雅礼帽",
	Rarity = 4,
	Desc = "魔术师用来施展戏法的神奇帽子，里面经常传出各种动物的叫声。\nWhat does the fox say?",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_16_yelifushentou_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id250] =
{
	Name = "发牌器",
	Rarity = 4,
	Desc = "藏有超多机关的发牌器，只要魔术师愿意，可以发出100张黑桃A。\n也就是说他拆了100副牌。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_16_yelifushentou_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id251] =
{
	Name = "绽放玫瑰",
	Rarity = 4,
	Desc = "由魔术师亲自种植的红玫瑰。象征着爱情，也代表着怪盗的浪漫。一般都会叼在嘴里，然后被刺伤。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_16_yelifushentou_4",
}
EquipmentInfoConfig[EquipmentInfoID.Id252] =
{
	Name = "武士铠甲",
	Rarity = 4,
	Desc = "华丽的武士铠甲，打起架来有些不便，但造型非常帅气。\n会让人联想到橙子。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_09_ribenwushi_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id253] =
{
	Name = "绳结",
	Rarity = 4,
	Desc = "祭祀用的绳结，拥有驱除厄运的效果。上面是死扣。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_09_ribenwushi_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id254] =
{
	Name = "武士刀",
	Rarity = 4,
	Desc = "由名匠带着恶意制作的诅咒之刃，活人持有就会遭到厄运，据说是无上大快刀。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_09_ribenwushi_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id255] =
{
	Name = "统领配枪",
	Rarity = 5,
	Desc = "枪口所指，就是帝国的敌人！用它消灭一个敌人会获得额外的金币奖励。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_30_Napoleon_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id256] =
{
	Name = "统帅帽",
	Rarity = 5,
	Desc = "这顶帽子赋予我的，不是权力，而是责任。我将带领我的民族，我的祖国，前进，前进，再前进！",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_30_Napoleon_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id257] =
{
	Name = "增高鞋垫",
	Rarity = 5,
	Desc = "我人生的遗憾之一，将依靠这件器物来消弭。\n“如果你再出言不逊，我将高高跳起痛击你的膝盖！”",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_30_Napoleon_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id258] =
{
	Name = "小马",
	Rarity = 5,
	Desc = "很懂得主人心意的小白马，在主人成为博物馆的蜡像后，它也被人做成了蜡像，陪伴在主人身边。偶尔会被人跟另个馆区的和尚的坐骑搞混。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_MUS_30_Napoleon_4",
}
EquipmentInfoConfig[EquipmentInfoID.Id259] =
{
	Name = "羽毛笔",
	Rarity = 3,
	Desc = "从这支笔下写出的故事被无数世人阅读，而其中形象虽为虚构，却已活在人们心中。但它的墨水快用完了。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_30_ajiasha_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id260] =
{
	Name = "参考书",
	Rarity = 3,
	Desc = "写作必备的参考读物，虽然不能引用一模一样的情节，但是多多阅读却能获得不少灵感。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_30_ajiasha_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id261] =
{
	Name = "超低剂量毒药",
	Rarity = 3,
	Desc = "对于严谨的作家而言，要确保小说中新颖的作案手法切实可行。那么有时候，就需要亲自验证一下了。\n我来喝，我上了保险。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_30_ajiasha_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id262] =
{
	Name = "遗书",
	Rarity = 3,
	Desc = "上书：“请把我的硬盘烧掉，装一个带SBEAM的电脑接上网线，和骨灰盒放在一起”",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_12_sizhe_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id263] =
{
	Name = "盒饭+鸡腿",
	Rarity = 3,
	Desc = "死者最喜欢的食物，听说成为死者后就能经常吃到，所以才选择成为了死者。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_12_sizhe_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id264] =
{
	Name = "心脏起搏器",
	Rarity = 3,
	Desc = "强力心脏起搏器，有强烈求生欲的人一般都会被救回来，一天内不能死超过3次",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_12_sizhe_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id265] =
{
	Name = "眼镜",
	Rarity = 3,
	Desc = "2000度以上近视患者专用的超厚眼镜，佩戴后能够勉强恢复视力。切记不能注视任何光源五秒以上，否则会被点燃。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_08_zhenren_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id266] =
{
	Name = "模糊照片",
	Rarity = 3,
	Desc = "一旦出庭，就会被立刻推翻的证物。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_08_zhenren_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id267] =
{
	Name = "侦探小说",
	Rarity = 3,
	Desc = "畅销推理周刊，目前正连载《新日命四郎》。证人能够背出每一集的剧情。\n好了，你还有什么好说的？",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_08_zhenren_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id268] =
{
	Name = "不在场证明",
	Rarity = 3,
	Desc = "凶手控制他人的秘诀，根据被催眠的对象的不同，需要催眠的时间也不同，从1毫秒到10秒不等。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_28_heiyiren_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id269] =
{
	Name = "黑油漆",
	Rarity = 3,
	Desc = "变成凶手的高效道具，可水洗，因此不能在泳池作案。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_28_heiyiren_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id270] =
{
	Name = "动机",
	Rarity = 3,
	Desc = "凶手隐藏武器，但杀伤力却很小。通常都是些鸡毛蒜皮的原因，往往有其他人的动机会有更大的威力。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_28_heiyiren_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id271] =
{
	Name = "地址本",
	Rarity = 1,
	Desc = "厚厚的地址本，里面写着各种要送报纸的地址，背面写着这家人的各种小道消息。\n星期三，晴，主人今天又没刷牙。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_17_baotong_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id272] =
{
	Name = "自行车",
	Rarity = 1,
	Desc = "跟某个小学生那边借来的核动力自行车。最高时速为400km/h，过弯需承受10G重力。\n为什么骑着这种车的人会去送报纸呢？",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_17_baotong_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id273] =
{
	Name = "侦查型通信器",
	Rarity = 2,
	Desc = "进行变形后，能够变为无人侦察机，能够侦察到任何无人的画面。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_25_xiaolei_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id274] =
{
	Name = "好人卡",
	Rarity = 2,
	Desc = "行窃成功后，会撒在案发现场作为签名，据说会让捡到的男性立刻大哭不止。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_27_xiaoai_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id275] =
{
	Name = "音响型通信器",
	Rarity = 2,
	Desc = "小爱赠送的多功能通信器，插电后可以作为功放音响使用。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_26_xiaotong_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id276] =
{
	Name = "伸缩腰带",
	Rarity = 2,
	Desc = "看似普通腰带，实际上可以垂降100米高度。\n并不能延长腰围。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_25_xiaolei_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id277] =
{
	Name = "感应式通信器",
	Rarity = 2,
	Desc = "小爱发明的多功能通信器，打开感应功能，就能听到附近敌人的心跳。搭配M1014或UMP45使用。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_27_xiaoai_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id278] =
{
	Name = "磁力钱包",
	Rarity = 2,
	Desc = "内置了悬浮材料的钱包，无论如何行动，钱包内的物品都不会洒出来。\n并不是真正的磁铁，不要妄想用吸铁石偷钱包。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_26_xiaotong_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id279] =
{
	Name = "便携电话机",
	Rarity = 2,
	Desc = "对于每天接999通电话的编辑长来说，把电话戴在头上真是提升效率再好不过的办法了。然而这样就没法挂断骚扰电话和保险推销了。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_22_bianji_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id280] =
{
	Name = "飞镖钢笔",
	Rarity = 2,
	Desc = "为了工作减压而网购的多功能钢笔。编辑长会一边在办公室打电话催稿，一边丢这个飞镖来排解压力。玩着玩着用的时候就没有墨水了。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_22_bianji_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id281] =
{
	Name = "假发书包",
	Rarity = 2,
	Desc = "众所周知的知识，东西顶在头上走路不费劲。而书本不仅很重，看书看多了还容易秃头。这款假发书包一经推出立刻买爆了整个星际圈。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_21_duzhe_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id282] =
{
	Name = "限量版书签",
	Rarity = 2,
	Desc = "编辑部发售的限量版书签，只有杂志订阅满10年的读者才有机会获得，然而连载到现在也只有8年。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_21_duzhe_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id283] =
{
	Name = "纱布",
	Rarity = 2,
	Desc = "对于普通人来说，纱布是用来包扎的；对于受害者来说，纱布是用来区分谁是受害者的。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_07_daomeidan_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id284] =
{
	Name = "平安符",
	Rarity = 2,
	Desc = "上面写着：“大难不死”。\n因为时间太长，上面写着的内容有些模糊了，那个大原来是太字。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_07_daomeidan_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id285] =
{
	Name = "公文包",
	Rarity = 2,
	Desc = "豪华碳纤维防弹公文包。作为有钱人的律师经常被卷入各种枪战。这个包有效保护了自己和客户的安全，只要客户别太高。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_13_lvshi_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id286] =
{
	Name = "律师函",
	Rarity = 2,
	Desc = "希望通过警告震慑对方的信件！发放数量直接与每月绩效考核相关，不过发出去后通常只会使对方更生气。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_13_lvshi_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id287] =
{
	Name = "老花镜",
	Rarity = 2,
	Desc = "其实平时不太用到，是开跑车兜风时候用来防风的。上面那么多圈，带上之后基本就什么都看不清了。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_15_fangdongtaitai_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id288] =
{
	Name = "超大串钥匙",
	Rarity = 2,
	Desc = "房东太太别的不多，就是房子多，有时候忘记钥匙是哪个，开门得开个半小时。现在正在考虑把全部门锁换成密码锁。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_15_fangdongtaitai_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id289] =
{
	Name = "调酒壶",
	Rarity = 2,
	Desc = "调酒师的吃饭工具，曾因为摇的声音过于富有节奏感而被误认为乐器。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_23_tiaojiushi_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id290] =
{
	Name = "杯垫",
	Rarity = 2,
	Desc = "确认客人是接头人后，酒保意味深长地将酒杯推过去，并用手指敲了敲杯垫。客人小心翼翼地拿起杯垫，只见反面写道：“你拉链没拉。”",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_23_tiaojiushi_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id291] =
{
	Name = "行动舱",
	Rarity = 3,
	Desc = "几乎每天都要被改造更新的行动舱。被称为博士的另一个身体。目前用来装收到的快递。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_24_boshi_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id292] =
{
	Name = "发明手册",
	Rarity = 3,
	Desc = "记录了博士学会写字以来所有奇思妙想的笔记本。如果里面的发明全部成真一定可以改变整个宇宙。\n7月14日，晴，可乐拧不开，要发明一个自动拧瓶盖机。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_24_boshi_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id293] =
{
	Name = "空投装置",
	Rarity = 3,
	Desc = "因为行动舱有些大，博士额外研发了一个空投装置，避免去某些地方过于显眼。目前用来放喝了一半的饮料。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_24_boshi_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id294] =
{
	Name = "警官证",
	Rarity = 3,
	Desc = "宇宙警察厅统一颁发的警员证，警员编号4839232。\n不过登记证件号的机器只接受二进制输入。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_05_jingcha_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id295] =
{
	Name = "警灯",
	Rarity = 3,
	Desc = "平时没有什么用途的警灯，如果去抓人的时候打开只会暴露自己，所以大部分情况下用来免费上高速以及无责任闯红灯。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_05_jingcha_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id296] =
{
	Name = "防弹背心",
	Rarity = 3,
	Desc = "由悬疑星上最好的防弹材料做成，能防御各种子弹，弱点是对猫毛过敏。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_05_jingcha_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id297] =
{
	Name = "手术剪",
	Rarity = 3,
	Desc = "每一个死者的发型，法医都会先精心打理一番。对此死者虽然不满，但却无能为力。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_04_fayi_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id298] =
{
	Name = "手术刀",
	Rarity = 3,
	Desc = "纳米手术刀，锋利度绝无仅有，必须使用同材料托盘存放。一旦掉落，就会从星球的这一边掉到星球另一边去。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_04_fayi_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id299] =
{
	Name = "青蛙",
	Rarity = 3,
	Desc = "到现在都没有舍得解刨的小青蛙，是法医小时候的好朋友，但它已经快老死了。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_04_fayi_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id300] =
{
	Name = "起诉书",
	Rarity = 3,
	Desc = "“被告极度凶残，造成本案案情特别严重！情节特别恶劣！望判如所请！”",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_16_yujianlianshi_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id301] =
{
	Name = "正义象棋",
	Rarity = 3,
	Desc = "检察官喜欢的棋类游戏，一旦施展绝招，就能立刻将对方将死。\n“认输吧！看我的皇后五连动！”",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_16_yujianlianshi_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id302] =
{
	Name = "关键证据",
	Rarity = 3,
	Desc = "只要拿出这个，庭上就会一片嘘声，对方就会面如土色。但如果律师在对面，关键证据就会变成假的。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_16_yujianlianshi_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id303] =
{
	Name = "庭审锤",
	Rarity = 3,
	Desc = "高科技庭审锤，内设定向音量倍增器，保证对目标造成震耳欲聋的震慑效果。传说有不少被告因为受不了过大的音量而被迫认罪。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_14_faguan_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id304] =
{
	Name = "远程陪审机",
	Rarity = 3,
	Desc = "由星际法庭认证的智能陪审器。输入案件后，陪审器会将案情推送给对案件感兴趣的居民手中，并收集反馈信息呈交庭上。那么，全民陪审的时代终于到来了吗？",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_14_faguan_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id305] =
{
	Name = "正义天平",
	Rarity = 3,
	Desc = "法理与公义，究竟孰轻孰重？每当法官遇到棘手的案件时，就会不停地拨弄这个天平秤，直到它坏掉。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_14_faguan_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id306] =
{
	Name = "测谎听筒",
	Rarity = 3,
	Desc = "通过听取对方的心跳来了解对方的心理状态，但是只能显示yes和no，不能回答问题。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_02_huasheng_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id307] =
{
	Name = "案件笔记",
	Rarity = 3,
	Desc = "和那些超强脑力和记忆力的人不同，助理会把案件的各种信息记录到笔记中。后来意外发现了有不少人催更。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_02_huasheng_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id308] =
{
	Name = "放大镜",
	Rarity = 3,
	Desc = "现在很少看到侦探本人拿着放大镜四处看来看去的情形了，侦探助理却一直很喜欢放大镜，据说是学画画留下来的习惯。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_02_huasheng_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id309] =
{
	Name = "四十米长小刀",
	Rarity = 4,
	Desc = "暴力型罪犯的基本武器，受害者看到之后一般会放弃逃跑。目前这把刀的主人正在抗议小刀这个称呼，要求改成长刀，但一直以“不好念”的理由被驳回。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_29_kaitangshoujieke_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id310] =
{
	Name = "无声跑鞋",
	Rarity = 4,
	Desc = "作案毫无声音，也不会留下脚印，因此非常难以追踪。但透气性不是很好，出了汗之后会很臭，因此常常被警犬锁定。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_29_kaitangshoujieke_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id311] =
{
	Name = "开膛剪",
	Rarity = 4,
	Desc = "手术用具中，能用来做武器的东西实在是太多了，因此千万不要惹医生。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_29_kaitangshoujieke_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id312] =
{
	Name = "变声领带",
	Rarity = 4,
	Desc = "神奇的万能变声器，能随便模仿其他人的声音。当然，也可以用来犯罪。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_20_lanyixiaoxuesheng_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id313] =
{
	Name = "高科技眼镜",
	Rarity = 4,
	Desc = "博士制造的混合现实镜片，集合了画面捕捉、分析、信息处理于一体，缺点是待机时间很短，而且一旦没电连纠正视力的功能也会失效。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_20_lanyixiaoxuesheng_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id314] =
{
	Name = "高出力跑鞋",
	Rarity = 4,
	Desc = "博士制造的核动力跑鞋，调整至最大档后，可以一脚把易拉罐踢到外太空去，是没有物理规律可言的可怕设备。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_20_lanyixiaoxuesheng_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id315] =
{
	Name = "电击枪",
	Rarity = 4,
	Desc = "能够短时间内把人击晕的电击枪，因为功率太大而被禁止在家里充电。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_19_maikaofu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id316] =
{
	Name = "大脑增强装置",
	Rarity = 4,
	Desc = "这个增强装置可以使得人脑的活性提高数倍，用在最强大脑上更是如虎添翼，副作用就是会突然犯困",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_19_maikaofu_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id317] =
{
	Name = "蜘蛛窃听器",
	Rarity = 4,
	Desc = "拥有超强信号捕捉能力的窃听器，能够接收方圆1光年内的声音信息。要妥善处理这些情报，需要极其可观的计算量。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_19_maikaofu_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id318] =
{
	Name = "烟斗",
	Rarity = 5,
	Desc = "使用贵重的木料制作的艺术品级烟斗，是爷爷留给大侦探的礼物。因为还没到法定年龄，所以现在只是个摆设。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_01_fuermosi_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id319] =
{
	Name = "小提琴",
	Rarity = 5,
	Desc = "除解决案件外，大侦探最感兴趣的事物。当案情陷入绝境时，他就会拉一首喜欢的曲子帮助自己减压，同时也会给周围的人增压。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_01_fuermosi_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id320] =
{
	Name = "百科全书",
	Rarity = 5,
	Desc = "只要联网，就能查到任何信息的电子屏幕。不过在某些地方会显示404，此时案件的侦破将陷入绝境。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_01_fuermosi_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id321] =
{
	Name = "大侦探风衣",
	Rarity = 5,
	Desc = "作为侦探的基本要素之一是要有型，这就是为什么大部分侦探都有件风衣了，男女都不例外。\n小心骑车时别卷到轮子里。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_01_fuermosi_4",
}
EquipmentInfoConfig[EquipmentInfoID.Id322] =
{
	Name = "绅士伞",
	Rarity = 5,
	Desc = "由名匠手工制成的艺术品级雨伞，价格昂贵。撑起来就很有绅士的味道。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_03_moliyadi_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id323] =
{
	Name = "数学书",
	Rarity = 5,
	Desc = "除了给大侦探找麻烦外，教授最喜欢摆弄的东西。把已经存在的公式变为更优美的存在，是教授很感兴趣的事情。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_03_moliyadi_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id324] =
{
	Name = "变身胸针",
	Rarity = 5,
	Desc = "只要滴入目标血液，就可以立刻变身成指定目标的神奇道具，连声音也会自动模仿。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_03_moliyadi_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id325] =
{
	Name = "一发倒地枪",
	Rarity = 5,
	Desc = "超高浓度麻醉枪，只要被射中，哪怕是史前猛犸巨象也会立刻倒地。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sus_03_moliyadi_4",
}
EquipmentInfoConfig[EquipmentInfoID.Id326] =
{
	Name = "歌词本",
	Rarity = 3,
	Desc = "小时候的海豚凛，喜欢和小伙伴一起改编歌词，并把创作的词一笔一划写在小本本上。后来和伙伴分别时，小伙伴把自己的本子送给了TA。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_17_haitun_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id327] =
{
	Name = "麦克风",
	Rarity = 3,
	Desc = "小时候的玩具麦克风，但只要拿起它，就能想起过去快乐歌唱的时光，因此总是带在身边。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_17_haitun_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id328] =
{
	Name = "特制玻璃杯",
	Rarity = 3,
	Desc = "为了控制音量，特意买来练习的玻璃杯，口号是“绝对不能碎”！",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_17_haitun_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id329] =
{
	Name = "白色贝雷帽",
	Rarity = 3,
	Desc = "当墨在舞台上摘下帽子，就意味着墨色雾气将要出现了。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_03_moyu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id330] =
{
	Name = "海事可乐",
	Rarity = 3,
	Desc = "墨最喜欢的可乐，据说有让墨汁变紫的神奇效果。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_03_moyu_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id331] =
{
	Name = "墨色水枪",
	Rarity = 3,
	Desc = "墨最喜欢的玩具，因为被禁止参加喷水节，只好自己用它在家喷个痛快。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_03_moyu_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id332] =
{
	Name = "橡胶外套",
	Rarity = 4,
	Desc = "绝缘外套，在某些不能放电的正式场合中，伊俄就会换上这样一套衣服，虽然有些丑，但毕竟安全第一。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_24_haiman_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id333] =
{
	Name = "电吉他",
	Rarity = 4,
	Desc = "是伊俄擅长的乐器之一，不用插电就能发出完美的声音。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_24_haiman_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id334] =
{
	Name = "发电机",
	Rarity = 4,
	Desc = "通过伊俄自己发电才能向其他电器发电的发电器。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_24_haiman_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id335] =
{
	Name = "美颜相机",
	Rarity = 3,
	Desc = "出门必备物品，如果没有它，椰子无论如何也不愿意和别人合照。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_29_hou_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id336] =
{
	Name = "防晒霜",
	Rarity = 3,
	Desc = "夏天必备用品，虽然已经有很多人告诉TA，不出水就不用涂，但是椰子从来没有相信过。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_29_hou_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id337] =
{
	Name = "信号发射器",
	Rarity = 3,
	Desc = "离开家乡时，家人们送给自己的唯一一件礼物，据说启动发射器，即便身在远方，也可以和他们说话。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_29_hou_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id338] =
{
	Name = "《莫生气》",
	Rarity = 3,
	Desc = "其中记录了九九八十一种不同的《莫生气》口诀，当念起口诀时，仿佛世界变得平和了。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_27_hetun_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id339] =
{
	Name = "出气筒",
	Rarity = 3,
	Desc = "当心情郁闷的时候，对出气筒一通输出，心情仿佛舒畅了不少。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_27_hetun_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id340] =
{
	Name = "瘦身皮带",
	Rarity = 3,
	Desc = "如果带上瘦身皮带，就不会动不动变胖了吧？",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_27_hetun_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id341] =
{
	Name = "录音笔",
	Rarity = 3,
	Desc = "另一个鱼不翻说，自己说的话很有用，一定要拿录音笔好好记下来，鱼不翻虽然不懂，但还是照办了。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_28_fancheyu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id342] =
{
	Name = "平衡车",
	Rarity = 3,
	Desc = "鱼不翻最喜欢坐的交通工具，坐上平衡车，永远不翻车！",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_28_fancheyu_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id343] =
{
	Name = "FLAG",
	Rarity = 3,
	Desc = "插旗就是生活最大的乐趣！如果flag倒了也没关系，换一个就好了！",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_28_fancheyu_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id344] =
{
	Name = "贝壳发夹",
	Rarity = 3,
	Desc = "珍最喜欢的发夹，不管是演出还是训练，都要戴在头发上。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_19_shanbei_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id345] =
{
	Name = "珍珠",
	Rarity = 3,
	Desc = "既是装饰，也是实用的武器，能发出非常刺眼的光芒，把小偷的双眼闪瞎。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_19_shanbei_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id346] =
{
	Name = "鹅卵石",
	Rarity = 3,
	Desc = "遇到强盗打劫时，珍会迅速扔出一枚鹅卵石：“看，珍珠！”",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_19_shanbei_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id347] =
{
	Name = "扩音器",
	Rarity = 3,
	Desc = "时刻戴在头上的扩音器，直播的时候会直接拿出来大吼：“欧买噶！买它！”",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_18_hailuo_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id348] =
{
	Name = "手机支架",
	Rarity = 3,
	Desc = "直播必备物品，只要有它，就能随时随地来一场流量爆炸的直播。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_18_hailuo_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id349] =
{
	Name = "男装清单",
	Rarity = 3,
	Desc = "清单上记录着将要购买的男装，几乎都是当下最流行的款式。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_18_hailuo_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id350] =
{
	Name = "《猜拳攻略》",
	Rarity = 3,
	Desc = "和朋友玩了2356次石头剪刀布，战绩依然是平局，于是香菜决定买一本攻略，提升自己的猜拳水平。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_09_pangxie_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id351] =
{
	Name = "备用大鼓",
	Rarity = 3,
	Desc = "因为经常出现把鼓敲破的情况，所以无论何时，都要准备一面备用鼓，以备不时之需。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_09_pangxie_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id352] =
{
	Name = "钱包",
	Rarity = 3,
	Desc = "因为“有钳”，所以自称是一只“有钱蟹”，并且为了让有钱这一设定深入人心，不管在哪里出现，都要拿出厚厚的钱包。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_09_pangxie_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id353] =
{
	Name = "《猜拳攻略》",
	Rarity = 3,
	Desc = "和朋友玩了2356次石头剪刀布，战绩依然是平局，于是伊洛决定买一本攻略，提升自己的猜拳水平。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_06_longxia_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id354] =
{
	Name = "虾壳",
	Rarity = 3,
	Desc = "本来是为了保护自己不被狂热粉丝拉扯，没想到大家都很喜欢这套装扮，慢慢演变成了自己的标志。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_06_longxia_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id355] =
{
	Name = "电线保护套",
	Rarity = 3,
	Desc = "曾经失手夹断了键盘的电线，因此无法上台演出。为了避免悲剧再次发生，每次演出都会自带保护套。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_06_longxia_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id356] =
{
	Name = "名片",
	Rarity = 3,
	Desc = "幻然每隔一天就会变成另一个模样，因此养成了随手递给对方名片的良好习惯。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_05_haitu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id357] =
{
	Name = "调色盘",
	Rarity = 3,
	Desc = "当皮肤变色时，幻然会认真地拿着调色盘比对，挑选出最适合自己的色系妆容。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_05_haitu_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id358] =
{
	Name = "笔刷",
	Rarity = 3,
	Desc = "当变成奇怪的颜色时，幻然只好使用笔刷，把自己涂抹成另一种颜色。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_05_haitu_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id359] =
{
	Name = "房产证",
	Rarity = 3,
	Desc = "小屋的钥匙，只要摸到就会从心底里感到温馨。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_07_xiaochouyu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id360] =
{
	Name = "海底地图",
	Rarity = 3,
	Desc = "听说自己的族人，偶尔会消失在大海中，于是遥买来了最详细的海底地图，下定决心一定要找到TA们。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_07_xiaochouyu_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id361] =
{
	Name = "黑色披风",
	Rarity = 3,
	Desc = "因为红白相间的醒目纹理，在海洋中能被狗仔第一时间发现，为了躲避他们，特意购买了一件黑色的披风遮挡自己。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_07_xiaochouyu_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id362] =
{
	Name = "钢铁救生圈",
	Rarity = 3,
	Desc = "戳破了352个救生圈后，小茨决定去定制一个，果然，钢铁材质的救生圈就是不一样，除了浮不起来，几乎没有任何问题。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_21_haidan_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id363] =
{
	Name = "坐垫",
	Rarity = 3,
	Desc = "自从上次在礁石上坐了一天，磨破了最心爱的裤子，此后小茨不管走到哪里，都会带上软软的坐垫。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_21_haidan_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id364] =
{
	Name = "降噪耳机",
	Rarity = 3,
	Desc = "戴上耳机，听不见外界的声音，独坐的小茨就不会被任何事打扰。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_21_haidan_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id365] =
{
	Name = "黑色伞帽",
	Rarity = 3,
	Desc = "凉风最引以为傲的物品，在舞台转动帽子，就是TA最自信的时刻。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_15_manta_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id366] =
{
	Name = "文明杖",
	Rarity = 3,
	Desc = "不仅能彰显风度和身份，还能在黑暗中当做探路器，美观而实用。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_15_manta_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id367] =
{
	Name = "尖头皮鞋",
	Rarity = 3,
	Desc = "虽然不建议穿着皮鞋运动，但在凉风看来，这是TA最喜欢的一双舞鞋。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_15_manta_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id368] =
{
	Name = "海草支架",
	Rarity = 3,
	Desc = "为了哄孩子们开心，希波会随身携带支架，只要开始表演尾巴倒挂，就可以立刻吸引住孩子们的目光。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_11_haima_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id369] =
{
	Name = "螺旋桨马达",
	Rarity = 3,
	Desc = "希波拥有的速度很慢，为了跟上大部队，只好随身携带马达。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_11_haima_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id370] =
{
	Name = "神秘的袋子",
	Rarity = 3,
	Desc = "据说当小孩不听话的时候，希波就会把TA装进这个神秘的袋子里。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_11_haima_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id371] =
{
	Name = "时尚杂志",
	Rarity = 3,
	Desc = "在很小的时候，彩雅就给自己立下了人生目标：了解最新发型，走在时尚前沿。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_23_haikui_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id372] =
{
	Name = "房产证",
	Rarity = 3,
	Desc = "小屋的钥匙，被彩雅完好保存着，甚至想天天握在手心里。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_23_haikui_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id373] =
{
	Name = "自制学生证",
	Rarity = 3,
	Desc = "由于不羁的发型，上学时经常被门卫以不符合学生规范为由拦在门外，于是自己做了一本学生证，可以达到以假乱真的地步。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_23_haikui_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id374] =
{
	Name = "发胶",
	Rarity = 3,
	Desc = "能把头发稳稳固定住，风吹日晒36小时，造型依旧如初。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_02_douyu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id375] =
{
	Name = "人身保险",
	Rarity = 3,
	Desc = "因为长得凶巴巴而总被小朋友当做坏蛋，担心自己会被揍，因此早早就买好了保险。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_02_douyu_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id376] =
{
	Name = "信号增强器",
	Rarity = 3,
	Desc = "屡屡受到“你挡着我信号了”的指控，因此被迫随身携带信号增强器，似乎让周围的人安心了许多。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_02_douyu_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id377] =
{
	Name = "化妆盒",
	Rarity = 3,
	Desc = "每当站在化妆盒前，橘就觉得自己充满了力量。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_22_haisen_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id378] =
{
	Name = "《成为万人迷》",
	Rarity = 3,
	Desc = "据说是能够提高魅力值的好书，建议每日深度阅读五小时。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_22_haisen_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id379] =
{
	Name = "环保保证书",
	Rarity = 3,
	Desc = "因为惊慌失措时喷射了几次内脏，被环保局的人勒令写下了一份保证书。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_22_haisen_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id380] =
{
	Name = "备用灯泡",
	Rarity = 3,
	Desc = "因为担心头顶灯泡坏掉，而时刻准备的备用品。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_26_ankang_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id381] =
{
	Name = "《灯泡的诞生》",
	Rarity = 3,
	Desc = "很多年前买来的书，虽然现在已经成为了偶像，但灯光知识依旧不能落下。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_26_ankang_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id382] =
{
	Name = "牙齿矫正器",
	Rarity = 3,
	Desc = "由于牙齿凌乱，被经纪公司勒令整牙，只好天天戴上矫正器。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_26_ankang_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id383] =
{
	Name = "镜子",
	Rarity = 4,
	Desc = "海豹彩每一天都会照很多次镜子，并向镜子里的另一个自己问好。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_30_haibao_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id384] =
{
	Name = "调音台",
	Rarity = 4,
	Desc = "作为海洋星最著名的DJ，一来到调音台前，海豹彩就仿佛变了一个人。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_30_haibao_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id385] =
{
	Name = "代抽小广告",
	Rarity = 4,
	Desc = "作为一个抽卡欧皇，海豹彩开展了代抽业务，据说不夜城的人已经听闻此事，正在调查TA的踪迹。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_30_haibao_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id386] =
{
	Name = "化学试剂",
	Rarity = 4,
	Desc = "从黑市上买来的试剂，据说只要坚持十二个个疗程，就能让自己变成“谁摸谁死”的体质。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_01_huangjinshuimu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id387] =
{
	Name = "充电头盔",
	Rarity = 4,
	Desc = "不管谁碰了这个头盔，都会立刻被3600V电流袭击。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_01_huangjinshuimu_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id388] =
{
	Name = "金色手套",
	Rarity = 4,
	Desc = "粉丝握手会时的必备之物，只有戴着它，和粉丝握手时才会安心。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_01_huangjinshuimu_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id389] =
{
	Name = "返老还童丹",
	Rarity = 4,
	Desc = "吃了这种药，就可以实现永生，不过除了丝丝，谁也不知道返老还童丹的真相。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_04_dengtashuimu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id390] =
{
	Name = "海藻泥面膜",
	Rarity = 4,
	Desc = "具有补水、紧致、美白、祛皱等多功效的面膜，是丝丝的最爱。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_04_dengtashuimu_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id391] =
{
	Name = "旧相册",
	Rarity = 4,
	Desc = "珍藏的旧相册，不轻易向别人展示，直到有一次，朋友无意中看到了几十年前的丝丝，竟然……",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_04_dengtashuimu_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id392] =
{
	Name = "星之耳环",
	Rarity = 4,
	Desc = "海星样式的耳环，据队友说，或许耳环才是寻沙的本体。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_08_haixing_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id393] =
{
	Name = "海星印章",
	Rarity = 4,
	Desc = "画着一颗海星的印章，点评后辈时只用盖一下章，表示“还行”就足够了。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_08_haixing_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id394] =
{
	Name = "吸盘鞋",
	Rarity = 4,
	Desc = "吸力异常强大的鞋子，当寻沙想躺下休息时，没有任何人能拖动TA.",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_08_haixing_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id395] =
{
	Name = "小丸子",
	Rarity = 4,
	Desc = "最喜欢吃的小丸子，大家都说它和舞妍很配。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_10_zhangyu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id396] =
{
	Name = "竞赛奖杯",
	Rarity = 4,
	Desc = "小时候获得的“海洋星物理竞赛全国一等奖”奖杯，舞妍常常会看着它想，如果没有进入鱼乐圈，自己会不会成为一名物理学家呢？",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_10_zhangyu_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id397] =
{
	Name = "六棵海草",
	Rarity = 4,
	Desc = "为什么舞妍这么聪明？当然是因为TA从小就喝“六棵海草”啦！",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_10_zhangyu_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id398] =
{
	Name = "驯蛇师证书",
	Rarity = 4,
	Desc = "莱斯莉也忘记了什么时候获得的证书，训蛇大概是从出生就会的技能吧？",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_25_haishe_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id399] =
{
	Name = "发罩",
	Rarity = 4,
	Desc = "对于那些害怕头顶海蛇的粉丝，莱斯莉会选择戴上发罩再出席见面会。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_25_haishe_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id400] =
{
	Name = "珊瑚笛",
	Rarity = 4,
	Desc = "神奇的笛子，只要吹响就可以召唤海蛇，海蛇们把拥有珊瑚笛的人看做神明，完全不觉得自己被控制了。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_25_haishe_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id401] =
{
	Name = "鲨鱼牙套",
	Rarity = 4,
	Desc = "为了矫正零乱的尖牙，特意定制的鲨鱼专属牙套，不过目前似乎还没有效果。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_13_shayu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id402] =
{
	Name = "日记",
	Rarity = 4,
	Desc = "虽然对外宣称日记本，但里面密密麻麻记录着粉丝对自己和组合的评价。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_13_shayu_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id403] =
{
	Name = "新秀奖杯",
	Rarity = 4,
	Desc = "出道时获得的偶像新秀奖杯，这么多年一直好好保存着，看到它全身就会充满力量。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_13_shayu_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id404] =
{
	Name = "斑点束身服",
	Rarity = 4,
	Desc = "演出的必备服装，粉丝非常疑惑，为什么依伶每次总穿同样的衣服？殊不知TA买了好几套。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_12_jingsha_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id405] =
{
	Name = "好人卡",
	Rarity = 4,
	Desc = "每当公司内出现了矛盾冲突，依伶都会自告奋勇地去劝架，因此收获了一堆好人卡。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_12_jingsha_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id406] =
{
	Name = "《笑林广sea》",
	Rarity = 4,
	Desc = "在大家生气的时候，讲笑话是缓解气氛最好的办法，因此依伶买来《笑林广sea》，要求自己熟读并背诵全书。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_12_jingsha_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id407] =
{
	Name = "偶像签名",
	Rarity = 4,
	Desc = "几年前得到的签名，被裱起来并放在了家中最显眼的位置。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_16_jingyu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id408] =
{
	Name = "面试邀请函",
	Rarity = 4,
	Desc = "来自天鱼公司的面试邀请函，这是成为偶像的第一步。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_16_jingyu_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id409] =
{
	Name = "海贝手镯",
	Rarity = 4,
	Desc = "从记事起就佩戴上的手镯，据说可以带来好运。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_16_jingyu_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id410] =
{
	Name = "矿山产权证",
	Rarity = 5,
	Desc = "珊瑚家族的矿山产权证，据说海洋星所有的金矿都是TA们的，现在传到了阿卡的手中。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_20_shanhu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id411] =
{
	Name = "海洋之心",
	Rarity = 5,
	Desc = "深蓝色的钻石，是闻名全宇宙的稀世珍品。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_20_shanhu_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id412] =
{
	Name = "银行支票",
	Rarity = 5,
	Desc = "据说珊瑚家族和所有银行都有密切的联系，因此购物时只用开一张发票就好了。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_20_shanhu_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id413] =
{
	Name = "珊瑚勋章",
	Rarity = 5,
	Desc = "家族的勋章，代表家族至高无上的荣耀。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_20_shanhu_4",
}
EquipmentInfoConfig[EquipmentInfoID.Id414] =
{
	Name = "歌词本",
	Rarity = 5,
	Desc = "小时候的朋友非常珍视的歌词本，分别前夕，作为纪念，把本子送给了京。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_14_hujing_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id415] =
{
	Name = "泛黄旧照片",
	Rarity = 5,
	Desc = "童年时期和小伙伴的合照，被小心翼翼地保存在家里，然而随着时间的流失，照片渐渐泛黄模糊了。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_14_hujing_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id416] =
{
	Name = "鲸嗓子喉宝",
	Rarity = 5,
	Desc = "因为总是唱歌，声带难免有所损伤，只有靠吃药来缓解嗓子的疼痛。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_14_hujing_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id417] =
{
	Name = "过去的CD",
	Rarity = 5,
	Desc = "小时候和朋友一起录的歌，至今都被完好保存着。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_14_hujing_4",
}
EquipmentInfoConfig[EquipmentInfoID.Id418] =
{
	Name = "竖琴",
	Rarity = 5,
	Desc = "和人鱼清音形影不离的乐器，能弹奏出让所有鱼感到治愈的音乐。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_31_meirenyu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id419] =
{
	Name = "珍珠王冠",
	Rarity = 5,
	Desc = "海底最美丽的王冠，只有最美的人鱼清音才能拥有的东西。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_31_meirenyu_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id420] =
{
	Name = "三叉戟",
	Rarity = 5,
	Desc = "当遇到敌人时，TA也会拿起武器迎战，保卫海洋。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_31_meirenyu_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id421] =
{
	Name = "梳子",
	Rarity = 5,
	Desc = "每天要梳头300次，才能对得起这一头美丽的秀发。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_31_meirenyu_4",
}
EquipmentInfoConfig[EquipmentInfoID.Id422] =
{
	Name = "兜帽",
	Rarity = 3,
	Desc = "用于躲避阳光的兜帽，照射到太阳光后紫弦月性情会大变，拥有平常状态下不可比拟的魄力和行动力。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_13_shayu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id423] =
{
	Name = "黑加白",
	Rarity = 3,
	Desc = "用于调节作息的药物，对于喜欢在夜晚活动的紫弦月来说必不可少。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_13_shayu_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id424] =
{
	Name = "黑桃K",
	Rarity = 3,
	Desc = "约定之日紫弦月抽到的牌，他并不理解其中的含义，只是当作护身符一样带在身边。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_13_shayu_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id425] =
{
	Name = "绒球",
	Rarity = 4,
	Desc = "琉璃兜衣物上的装饰品，看上去很可爱。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_17_haitun_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id426] =
{
	Name = "除虫剂",
	Rarity = 4,
	Desc = "琉璃兜随身带在身上的喷雾，她最害怕地底的各种虫子。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_17_haitun_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id427] =
{
	Name = "珍珠吊兰的令牌",
	Rarity = 4,
	Desc = "与珍珠吊兰交换身份后得到的身份证明，性别处有修改的痕迹。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_17_haitun_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id428] =
{
	Name = "珍珠流星锤",
	Rarity = 4,
	Desc = "珍珠吊兰专属的武器，在外遇到土匪和无赖时，如果劝说无用，便只能换这种方式进行劝说。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_12_jingsha_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id429] =
{
	Name = "摇铃",
	Rarity = 4,
	Desc = "能发出清脆声响的乐器，具有能召集人们的不可思议力量。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_12_jingsha_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id430] =
{
	Name = "琉璃兜的ID卡",
	Rarity = 4,
	Desc = "与琉璃兜交换身份后得到的身份证明，为了防止被人怀疑而把上面的照片刮花了。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_12_jingsha_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id431] =
{
	Name = "桃心伞",
	Rarity = 4,
	Desc = "曾经是方便在劳作时遮阳的器具，现在则成了爱之蔓掩盖自己的帷幕。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_19_shanbei_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id432] =
{
	Name = "毒镖",
	Rarity = 4,
	Desc = "爱之蔓自制的暗器，毒性并不致命，但会非常疼。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_19_shanbei_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id433] =
{
	Name = "红心J",
	Rarity = 4,
	Desc = "约定之日爱之蔓抽到的牌，无论怎样，他都接受了这个结局。如果还能再来一次的话，一定要抽到王。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_19_shanbei_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id434] =
{
	Name = "熨斗",
	Rarity = 3,
	Desc = "压平衣物的道具，高砂之翁用它来对付自己满是褶皱的裙子。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_18_hailuo_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id435] =
{
	Name = "药剂X",
	Rarity = 3,
	Desc = "高砂之翁所从事的秘密研究产物，能够让身体产生一系列的变化。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_18_hailuo_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id436] =
{
	Name = "猫粮",
	Rarity = 3,
	Desc = "经过无数次实验后发现的最能适配神秘机械的道具，至于原理还在研究中。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_18_hailuo_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id437] =
{
	Name = "皇冠",
	Rarity = 2,
	Desc = "不，这并不是帽子，不是。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_16_jingyu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id438] =
{
	Name = "萧",
	Rarity = 2,
	Desc = "遥远国度的乐器，能发出悠扬缠绵的声音。但没人知道，其实这是根笛子。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_16_jingyu_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id439] =
{
	Name = "行医执照",
	Rarity = 2,
	Desc = "由仙人球亲自绘制的卡片，没有任何科学依据。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_16_jingyu_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id440] =
{
	Name = "草裙",
	Rarity = 2,
	Desc = "垂盆草身上唯一的衣物，也是他的工作服，要消毒的话就直接在叶子上擦擦。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_29_hou_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id441] =
{
	Name = "围巾",
	Rarity = 2,
	Desc = "用于遮挡脖子的装饰，如果有人抨击条纹蛇卷的演说，她就会解开围巾并从里面掏出带毒的凶器，企图用武力说服敌人。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_29_hou_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id442] =
{
	Name = "横幅",
	Rarity = 2,
	Desc = "条纹蛇卷专门定制的横幅，用来抨击族长和手下官员的无作为。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_09_pangxie_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id443] =
{
	Name = "葫芦丝",
	Rarity = 2,
	Desc = "异国的乐器，能够吹奏出悠扬的旋律，是生石花主要的娱乐方式。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_09_pangxie_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id444] =
{
	Name = "房产簿",
	Rarity = 2,
	Desc = "满满一册的房产，令人深感羡慕。福寿玉每过一段时间就会愁眉苦脸地翻看，并纠结究竟该换到哪里住。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_06_longxia_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id445] =
{
	Name = "兔耳",
	Rarity = 2,
	Desc = "碧光环获取外界消息的重要渠道，拥有非常好的听觉能力，能够听到上层人买菜时砍价的声音，因此学了不少脏话。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_06_longxia_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id446] =
{
	Name = "假期作业",
	Rarity = 2,
	Desc = "学校布置的作业，碧光环的本子上永远都是空白，因为寒暑假的时候他在休眠。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_05_haitu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id447] =
{
	Name = "芦荟面具",
	Rarity = 2,
	Desc = "一般情况下，如果戴上面具，别人就会以为你的脸不长这个样子了。芦荟也是这么希望的。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_05_haitu_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id448] =
{
	Name = "胶水",
	Rarity = 2,
	Desc = "涂在脸上就变成了芦荟胶。哇哦，太厉害了。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_07_xiaochouyu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id449] =
{
	Name = "花冠",
	Rarity = 3,
	Desc = "你以为这是皇冠，其实是她的一部分。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_07_xiaochouyu_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id450] =
{
	Name = "琵琶",
	Rarity = 3,
	Desc = "遥远国度的乐器，能发出令人心醉的声音。但没人知道，其实虹之玉根本不会弹琵琶。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_21_haidan_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id451] =
{
	Name = "星之花",
	Rarity = 3,
	Desc = "被视为神力的象征，受到地表居民崇拜，其实只是虹之玉自己开出来的花。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_21_haidan_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id452] =
{
	Name = "小熊手套",
	Rarity = 3,
	Desc = "带有绒毛的手套，据说在祭祀时带着它会让神明感觉到被抚摸的舒适感。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_28_fancheyu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id453] =
{
	Name = "祭祀服",
	Rarity = 3,
	Desc = "由绒制的祭祀服，都是真材实料，但在阳光下穿着会很热。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_28_fancheyu_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id454] =
{
	Name = "手鼓",
	Rarity = 3,
	Desc = "祭祀过程中不可或缺的乐器，会发出“咚咚”的声响，用来吵醒睡懒觉的神明。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_28_fancheyu_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id455] =
{
	Name = "玉米卷",
	Rarity = 3,
	Desc = "来自蓝星漂亮洲的风味零食，熟悉的口感能让黄丽瞬间回忆起曾经被辣哭的青葱岁月。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_15_manta_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id456] =
{
	Name = "铃鼓",
	Rarity = 3,
	Desc = "摇一下就可以发出清脆的响声，吸引周围的人们光顾。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_15_manta_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id457] =
{
	Name = "钱袋",
	Rarity = 3,
	Desc = "黄丽辛苦工作数年攒下来的嫁妆钱，可以买下整整三瓶小血瓶。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_15_manta_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id458] =
{
	Name = "团扇",
	Rarity = 3,
	Desc = "破旧不堪的团扇，看上去有十多年的历史，但姬秋丽依然不舍得丢弃。据说是碰碰香送给她的第一件礼物。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_11_haima_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id459] =
{
	Name = "账簿",
	Rarity = 3,
	Desc = "记载着旅行商人营业额的账簿，写满了计算的笔记。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_11_haima_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id460] =
{
	Name = "一沓身份证",
	Rarity = 3,
	Desc = "用于伪造身份的证件，姬秋丽已经至少有五十个假名了。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_11_haima_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id461] =
{
	Name = "苹果味沐浴液",
	Rarity = 3,
	Desc = "碰碰香爱用的沐浴液，用过之后身上会散发出苹果的香气，让人克制不住想要咬一口的冲动。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_27_hetun_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id462] =
{
	Name = "折扇",
	Rarity = 3,
	Desc = "精致小巧的折扇，看上去价格不菲，碰碰香从来没有使用过它，一直收纳在盒子里。据说是姬秋丽送给他的第一件礼物。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_27_hetun_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id463] =
{
	Name = "计算器",
	Rarity = 3,
	Desc = "做生意时会用到的便利工具，用来帮碰碰香计算复杂的十以内的加减法。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_27_hetun_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id464] =
{
	Name = "开箱叶片",
	Rarity = 3,
	Desc = "锯齿状的叶片，用于划开各种快递箱子，也可防身用。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_23_haikui_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id465] =
{
	Name = "鼓槌",
	Rarity = 3,
	Desc = "原本是需要配合着鼓才能发挥作用的乐器，但玉吊钟发现打击别的地方也可以弄出差不多的声音。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_23_haikui_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id466] =
{
	Name = "通讯簿",
	Rarity = 3,
	Desc = "上面扭扭曲曲地记载着各种渠道的货源，甚至可以看到很多意想不到的名字。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_23_haikui_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id467] =
{
	Name = "钱包",
	Rarity = 3,
	Desc = "金钱木贴身存放的钱包，上面设有铃铛、电击器、指纹识别等多重防盗措施。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_02_douyu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id468] =
{
	Name = "金纹章",
	Rarity = 3,
	Desc = "藏在金钱木内衬里的纹章，从不主动示人。上面刻着“莫洛基”三个字。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_02_douyu_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id469] =
{
	Name = "地图",
	Rarity = 3,
	Desc = "在蜿蜒曲折的地底指明道路的地图，对于邮差来说是最好的帮手。因为地底没信号，不能用GPS。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_02_douyu_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id470] =
{
	Name = "网红账号",
	Rarity = 3,
	Desc = "拥有无限变现潜力的账号，正在考虑转型。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_03_moyu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id471] =
{
	Name = "五道杠",
	Rarity = 3,
	Desc = "学生地位的标志，如果在学校里混到这个位置上，自然就会受到其他学生的崇拜。有思想的人会开始丰满自己的羽翼，并挑战其他班干部的权力。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_03_moyu_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id472] =
{
	Name = "社会实践表",
	Rarity = 3,
	Desc = "学生的假期作业，上面刻着不知道从哪个企业搞来的印章。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_03_moyu_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id473] =
{
	Name = "防撞环",
	Rarity = 3,
	Desc = "佩戴在额头上的铁器，用于防止高大的令箭荷花撞到门框。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_22_haisen_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id474] =
{
	Name = "手铃",
	Rarity = 3,
	Desc = "用来打节奏的乐器，演奏技法不够娴熟时很容易变成玩具。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_22_haisen_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id475] =
{
	Name = "令箭口香糖",
	Rarity = 3,
	Desc = "令箭荷花用自己的花蜜制造出的口香糖，意外的在地底开始流行。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_22_haisen_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id476] =
{
	Name = "武侠小说",
	Rarity = 3,
	Desc = "星际间流行的武侠小说，是小球玫瑰不为人知的爱好，她最喜欢里面名叫龙血景天的女主角。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_26_ankang_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id477] =
{
	Name = "相不对论",
	Rarity = 3,
	Desc = "星际著名的物理学著作，小球玫瑰最喜爱的读物，上面还有大物理学家的签名。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_26_ankang_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id478] =
{
	Name = "Kp4-2芯片",
	Rarity = 3,
	Desc = "小球玫瑰小时偶然间在星核捡到的芯片，直到现在她也没能研究清它的构造。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_26_ankang_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id479] =
{
	Name = "宝塔",
	Rarity = 3,
	Desc = "从地摊处淘来的宝塔，据说有着神明的力量，能够召唤异邦的神明。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_30_haibao_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id480] =
{
	Name = "神之香",
	Rarity = 3,
	Desc = "一小袋粉尘般的的东西，被茜之塔珍藏，传说是神明洗澡时搓下来的灰。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_30_haibao_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id481] =
{
	Name = "启示",
	Rarity = 3,
	Desc = "神所恩赐的智慧，每当冥思苦想之际，神明就会帮助虔诚的信徒，把启示在他们的脑海中点亮。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_30_haibao_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id482] =
{
	Name = "头上草",
	Rarity = 4,
	Desc = "蕴含神力的芽苗，每当鹿角海棠思考便会继续生长，直至成为参天大树。但直到现在，它还只是树苗。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_24_haiman_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id483] =
{
	Name = "二胡",
	Rarity = 4,
	Desc = "鹿角海棠祭祀时用的乐器，常常拉出哀婉忧伤的旋律而导致被请来的神明哭红了眼，不好意思出面。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_24_haiman_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id484] =
{
	Name = "巫女服",
	Rarity = 4,
	Desc = "鹿角海棠的工作服，怕麻烦的她也拿来当便服穿。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_24_haiman_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id485] =
{
	Name = "刺棘",
	Rarity = 4,
	Desc = "没有任何悬挂配件的耳饰，靠针刺固定在头上。对于虎刺梅来说更像是按摩。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_01_huangshuimu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id486] =
{
	Name = "铜锣",
	Rarity = 4,
	Desc = "能发出巨大声音的乐器，用来叫醒那些听玉露演奏时睡着的人。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_01_huangshuimu_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id487] =
{
	Name = "假眼",
	Rarity = 4,
	Desc = "用马克笔画在眼皮上的假眼，虎刺梅因为疲劳而打盹时反而能彰显出比平时更恐怖的威慑力。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_01_huangshuimu_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id488] =
{
	Name = "算盘",
	Rarity = 4,
	Desc = "算账用的工具，明明有更便利的计算器，但随着在地表住着的时间越来越长，雅乐之舞渐渐忘记了自己所拥有的文明。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_04_dengtashuimu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id489] =
{
	Name = "炒勺",
	Rarity = 4,
	Desc = "做菜的炒勺，因为人手短缺，作为掌柜的雅乐之舞还要担任起厨师的工作。好不好吃就是另一回事了。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_04_dengtashuimu_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id490] =
{
	Name = "抹布",
	Rarity = 4,
	Desc = "擦桌收拾的抹布，忙不过来的时候雅乐之舞就会亲自来服务客人。现在知道为什么客栈只有一个雇员了。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_04_dengtashuimu_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id491] =
{
	Name = "神格",
	Rarity = 4,
	Desc = "神灵身份的象征，为了隐藏，玉露把它压弯了戴在头顶。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_08_haixing_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id492] =
{
	Name = "玉露珍珠",
	Rarity = 4,
	Desc = "透着亮绿色珠宝的挂坠，是玉露一家代代相传的饰品，据传是由祖先的身体做成的。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_08_haixing_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id493] =
{
	Name = "竖琴",
	Rarity = 4,
	Desc = "来自外星的乐器，能演奏出柔美动听的旋律，让人昏昏欲睡。从来没有人能清醒地听完玉露演奏一曲。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_08_haixing_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id494] =
{
	Name = "族谱",
	Rarity = 4,
	Desc = "玉露一家代代相传的族谱，能够在上面看到某些神明的名字。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_08_haixing_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id495] =
{
	Name = "能量宝塔",
	Rarity = 4,
	Desc = "传说能接收宇宙能量的法宝，帮助修炼者提炼宇宙精粹，是神学爱好者不可或缺的珍贵之物。从姬秋丽那里买到的。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_10_zhangyu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id496] =
{
	Name = "防晒油",
	Rarity = 4,
	Desc = "防止日晒的乳液，对容易晒黑的黑法师来说是必备品。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_10_zhangyu_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id497] =
{
	Name = "神杖",
	Rarity = 4,
	Desc = "黑法师从地摊奸商那买来的伪装成神杖的木棍，但它其实真的是神杖。所以，到底是谁上当了？",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_10_zhangyu_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id498] =
{
	Name = "干旱之珠",
	Rarity = 4,
	Desc = "火祭佩戴在胸前的挂坠，能够吸取周围空气中的水分，有时会被拿来烘干衣服。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_25_haishe_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id499] =
{
	Name = "寒冰之坠",
	Rarity = 4,
	Desc = "火祭的耳环，一年四季都保持着冰冷的温度，不小心碰到身子会很凉。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_25_haishe_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id500] =
{
	Name = "阳炎之环",
	Rarity = 4,
	Desc = "火祭戴在无名指的戒指，具有阳光的能量，直接注视会被闪瞎双眼。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_25_haishe_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id501] =
{
	Name = "魔法阵充电器",
	Rarity = 5,
	Desc = "乍一看上去是神秘的魔法阵，其实是个无线充电器。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_20_shanhu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id502] =
{
	Name = "真·雷神之锤",
	Rarity = 5,
	Desc = "既然都写着真了，就说明其他的是假的。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_20_shanhu_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id503] =
{
	Name = "神话故事",
	Rarity = 5,
	Desc = "雷神消遣时的读物，他非常喜欢看凡人描述自己的生活，但也对那些不怎么光彩的部分感到不满。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_20_shanhu_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id504] =
{
	Name = "尖刺",
	Rarity = 5,
	Desc = "红色的针刺类暗器，用于偷偷进行攻击，每当雷神听到有凡人在说自己的坏话时，就会用这东西悄悄扎他们的屁股。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_20_shanhu_4",
}
EquipmentInfoConfig[EquipmentInfoID.Id505] =
{
	Name = "金环",
	Rarity = 5,
	Desc = "明明是神明的象征，金手指却坚持说这只是纯金打造的奢侈品，不知道哪一种更加珍贵。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_14_hujing_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id506] =
{
	Name = "宇宙之辉",
	Rarity = 5,
	Desc = "能够汇集光线能量的聚合器，但经常会闪瞎别人的眼睛。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_14_hujing_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id507] =
{
	Name = "金手指",
	Rarity = 5,
	Desc = "电子游戏作弊的道具，就是因为这个，没人愿意和她一起玩游戏。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_14_hujing_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id508] =
{
	Name = "排笛",
	Rarity = 5,
	Desc = "异国的乐器，能够演奏出空灵的音乐，在贵族之间很有人气。但她吹反了。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Sea_14_hujing_4",
}
EquipmentInfoConfig[EquipmentInfoID.Id509] =
{
	Name = "大王的王冠",
	Rarity = 3,
	Desc = "只有被推选为大王的史莱姆才能佩戴的宝冠，是史莱姆族代代相传的圣物。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPDraw_01_SlimeKing_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id510] =
{
	Name = "胃药",
	Rarity = 3,
	Desc = "因为食谱覆盖面太广，导致一些食物在身体中产生了不良化学反应，这时候就需要特制的胃药来帮助消化。注意用量不要太多，否则会消化身体。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPDraw_01_SlimeKing_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id511] =
{
	Name = "初级金币箱",
	Rarity = 3,
	Desc = "装有各种素材和人员情报的大箱子，有时会跟垃圾箱搞混，因此里面也会有一些纸屑。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPDraw_01_SlimeKing_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id512] =
{
	Name = "大杯饮料",
	Rarity = 4,
	Desc = "精灵王子最爱的饮料杯，无论喝什么饮料，都会用这个杯子装。不过似乎各种饮料的味道都已经串在一块了。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPDraw_02_ElvenPrince_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id513] =
{
	Name = "金色发胶",
	Rarity = 4,
	Desc = "能够使头发散发出迷人的金色光泽且具有定型作用的特制发胶，哪怕水洗也不会脱落。\n等等，那怎么才能弄下来？",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPDraw_02_ElvenPrince_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id514] =
{
	Name = "中级金币箱",
	Rarity = 4,
	Desc = "装有各种素材和人员情报的大箱子，里面有精灵王子在各地收集的宝物，但基本都在星际鉴宝节目中被告知为赝品。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPDraw_02_ElvenPrince_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id515] =
{
	Name = "玉璧王冠",
	Rarity = 5,
	Desc = "使用冒险者们支付的玉璧打造的纯玉王冠，散发着高贵的绿色光芒，明明价值很高，但却没什么人愿意戴上。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPDraw_03_DiamondQueen_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id516] =
{
	Name = "贵族的摇扇",
	Rarity = 5,
	Desc = "冷却效果很差，但是派头很足的贵族用品。如果这次给出的都是素材，女王就会优雅地拿扇子挡住自己的脸，是在笑吗？",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPDraw_03_DiamondQueen_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id517] =
{
	Name = "玉璧箱",
	Rarity = 5,
	Desc = "装有各种素材和人员情报的豪华箱子，不过里面还有一个装了超大量低档素材的暗格。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPDraw_03_DiamondQueen_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id518] =
{
	Name = "元气充电宝",
	Rarity = 5,
	Desc = "能够自制元气电量的强力工具，经常会自制一些元气电池卖给不知情的顾客，从中赚取差价。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPDraw_03_DiamondQueen_4",
}
EquipmentInfoConfig[EquipmentInfoID.Id519] =
{
	Name = "《心灵高汤》",
	Rarity = 3,
	Desc = "一本坊间流传的情感类读物，无论遭受何种困境，只要拿出来看两个小故事，对生活又会充满期待。\n其实都是虚构的。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPDraw_04_UnlockChief_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id520] =
{
	Name = "避雷针",
	Rarity = 3,
	Desc = "即使晴空万里，也有可能被雷劈中，全身焦黑，不过身为本族的族长，肉体上已经完全免疫了雷电的伤害。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPDraw_04_UnlockChief_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id521] =
{
	Name = "泥土",
	Rarity = 3,
	Desc = "酋长随身携带的食物，无论做什么投资都会失败，最后落到吃土果腹的下场。\n别说，他家的土挺好吃的。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPDraw_04_UnlockChief_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id522] =
{
	Name = "菜杆",
	Rarity = 2,
	Desc = "纯天然的绿叶菜，能够平衡人体需要，除了不好吃之外没有任何缺点的美食。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_01_yeji_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id523] =
{
	Name = "种子",
	Rarity = 2,
	Desc = "除了重量单位之外，有时也能用字节单位衡量。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_01_yeji_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id524] =
{
	Name = "化肥",
	Rarity = 2,
	Desc = "根据长期种菜经验配出来的强力化肥，只要撒在地上，土地就会立刻焕发活力，但它实在太臭了。\n不准用那玩意种榴莲！",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_01_yeji_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id525] =
{
	Name = "桃心帽",
	Rarity = 2,
	Desc = "桃几小姐最喜欢的帽子，经常戴着这顶帽子出席各种商业活动。经常有人搭讪问“你是不是桃子”，对此桃几小姐总是非常震惊：“你怎么知道我的名字？”",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_02_taozi_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id526] =
{
	Name = "系统公告",
	Rarity = 2,
	Desc = "一旦代言的产品遇到技术性故障，就会立刻发布的告文，在抱歉的同时，往往还会送一些玉璧作为补偿，如果不行就再送点。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_02_taozi_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id527] =
{
	Name = "VIP卡",
	Rarity = 2,
	Desc = "能够随意体验代言商品的黄金卡，只要拿出来，就能享受到特权待遇。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_02_taozi_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id528] =
{
	Name = "罗盘",
	Rarity = 3,
	Desc = "酋长妹妹从家乡带来的道具，据说根据自己的玄学知识正确使用后，可以触发一些神奇的事件。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPDraw_05_UnlockChiefSister_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id529] =
{
	Name = "黑皮钱包",
	Rarity = 3,
	Desc = "作为酋长一家人中最受宠的妹妹，虽然被告知了多次“氪不改命”，但还是坚持认为——只要氪下去，总有一天幸运会降临。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPDraw_05_UnlockChiefSister_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id530] =
{
	Name = "一杯毒奶",
	Rarity = 3,
	Desc = "曾经看到冒险家抽卡，好心地对冒险说：“你一定能抽出最好的角色！”\n后来，一无所获的冒险家送出了一瓶奶，上面写着：别喝，有毒。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPDraw_05_UnlockChiefSister_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id531] =
{
	Name = "死亡辣椒",
	Rarity = 4,
	Desc = "使用基因改造技术种植出来的变态辣椒，一般人只要看一眼，就会觉得嗓子干燥，嘴唇发烫。如果吃下去的话，就会获得喷火能力。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Pir_01_DarkCooker_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id532] =
{
	Name = "催泪洋葱",
	Rarity = 4,
	Desc = "黑暗料理大师酷爱的调味食材，一旦开始切片，附近10公里内的人都会不自觉地流下眼泪。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Pir_01_DarkCooker_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id533] =
{
	Name = "魔鬼焖烧锅",
	Rarity = 4,
	Desc = "会把任何食材都焖得稀烂的超高压锅，如果素材本身不够强大，就会被魔鬼焖烧锅焖成汤水。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Pir_01_DarkCooker_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id534] =
{
	Name = "椅垫",
	Rarity = 4,
	Desc = "经常宅在家里不出门的少女必备物品之一，软软的椅垫，坐一天都不会感到腰酸背疼。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Pir_02_SuperGirl_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id535] =
{
	Name = "氮气加速瓶",
	Rarity = 4,
	Desc = "虽然喜欢慢节奏的生活，不过遇到突发情况，又不适合使用瞬移能力时，超能力少女就会使用氮气加速瓶，使轮椅达到超音速状态。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Pir_02_SuperGirl_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id536] =
{
	Name = "封印手环",
	Rarity = 4,
	Desc = "封印了超能少女力量的科技产品，一旦解开，超能少女将释放可怕的力量。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Pir_02_SuperGirl_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id537] =
{
	Name = "全周天赛手帽",
	Rarity = 4,
	Desc = "为应对超速罚款专门设计的帽子，帽檐部分可以防止摄像头拍脸，内置镜头可以生成周围的球形信息图送入飙车王的脑部。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Pir_RacingDriver_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id538] =
{
	Name = "自制方向盘",
	Rarity = 4,
	Desc = "特制插口的方向盘，无论是飞机、轮船、汽车、自行车都能接入并正常驾驶。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Pir_RacingDriver_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id539] =
{
	Name = "自制刹车装置",
	Rarity = 4,
	Desc = "由复合材料制成的手刹棒，载具停不下来时，只要打开车门，用这根棒子插住地面减速，拖行一段距离就能成功刹车了。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Pir_RacingDriver_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id540] =
{
	Name = "保龄球瓶",
	Rarity = 4,
	Desc = "投掷用保龄球瓶，是百变怪人刚入行时经常表演的项目。不过那时候的他没少被丢鸡蛋。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Pir_ChangeableMan_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id541] =
{
	Name = "小丑礼物盒",
	Rarity = 4,
	Desc = "充满惊喜的礼物盒，不过打开时，里面“嘭”地跳出的小丑人偶，经常只能带给别人很大的惊吓。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Pir_ChangeableMan_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id542] =
{
	Name = "破碎的心",
	Rarity = 4,
	Desc = "经过复杂手术才取出的破碎的心。代表了百变怪人过去的悲伤经历，不过从此以后，他就开朗多了。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Pir_ChangeableMan_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id543] =
{
	Name = "焊工面具",
	Rarity = 4,
	Desc = "能够有效保护眼睛不受高光损伤的特制面具，透过折光玻璃，能够清晰地看到金属在高温下的变形过程。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Pir_SuperBlacksmith_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id544] =
{
	Name = "超高温喷枪",
	Rarity = 4,
	Desc = "使用袖珍型黑洞引擎驱动的高温喷枪，喷出的火焰可以融化一切金属。不过操作的时候一定要小心再小心噢~",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Pir_SuperBlacksmith_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id545] =
{
	Name = "雷神之锤",
	Rarity = 4,
	Desc = "组织从某个超级英雄手中抢来的古代神话装备，超能铁匠因为第三季度业绩良好，得到了这件奖品。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Pir_SuperBlacksmith_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id546] =
{
	Name = "完美的胡子",
	Rarity = 4,
	Desc = "因无法长出那么完美的胡子，而请人手工制作的八字胡，黏在嘴上非常牢固，同时还防水防油~",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Pir_DarkPolo_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id547] =
{
	Name = "随身鞋箱",
	Rarity = 4,
	Desc = "暗黑波罗的随身鞋箱，对于有洁癖的他而言是必不可少的道具。其中准备了应对七种地形的二十种皮鞋，每次出门时刷皮鞋也要很久……",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Pir_DarkPolo_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id548] =
{
	Name = "黄金烟斗",
	Rarity = 4,
	Desc = "仿造第三代大侦探随身物品制作的镀金烟斗，每个细节都丝毫不差，不过暗黑波罗并不喜欢抽烟斗。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Pir_DarkPolo_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id549] =
{
	Name = "漱口水",
	Rarity = 4,
	Desc = "虽然每天要吃二十顿饭，但是还是要注意口腔清洁。鲨鱼老大自调的漱口水，不过换牙频率还是非常高。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Pir_SharkBoss_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id550] =
{
	Name = "巨大船锚",
	Rarity = 4,
	Desc = "可以随意放大及缩小的超科技船锚，是鲨鱼老大在沉船海沟找到的。不过将其缩放为1/100大小时，鲨鱼老大觉得挥动起来最顺手。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Pir_SharkBoss_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id551] =
{
	Name = "狂躁吉他",
	Rarity = 4,
	Desc = "虽然已经被驱离海洋星，但是鲨鱼老大还是酷爱着电音摇滚。如果需要活跃气氛时，鲨鱼老大就会拿这个出来给大家弹上一曲。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Pir_SharkBoss_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id552] =
{
	Name = "绝情的弯刀",
	Rarity = 4,
	Desc = "传说中积聚了无数亡者灵魂的宝刀。在战斗中，配合罗曼船长独特的步法，总能从意想不到的角度刺入对手的身体。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Pir_CaptainRoamn_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id553] =
{
	Name = "瓶中船",
	Rarity = 4,
	Desc = "因违法捕捞而被海洋星扣押的黑牡蛎号风帆船，通过质效重组技术被封存在了玻璃瓶中，解禁时间是一千二百年。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Pir_CaptainRoamn_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id554] =
{
	Name = "阴郁的口琴",
	Rarity = 4,
	Desc = "罗曼船长心爱的口琴，一个人时，会坐在船沿处独自演奏。不过天气无论如何晴朗，吹出的曲调都让人觉得好像在阴雨绵绵的天气里一样。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Pir_CaptainRoamn_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id555] =
{
	Name = "防晒霜",
	Rarity = 4,
	Desc = "能够阻挡99.99%紫外线的名牌护肤品，伯爵是该品牌的VVIP会员。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Pir_DarkCount_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id556] =
{
	Name = "输血袋",
	Rarity = 4,
	Desc = "伯爵随身携带的输血袋，听说是为了防止出车祸时，医院血库没有对应血型而准备的。不过好像每天都会被用掉一些的样子，是不是错觉呢？",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Pir_DarkCount_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id557] =
{
	Name = "古老魔戒",
	Rarity = 4,
	Desc = "伯爵世代相传的魔法戒指，镶嵌着不像是来自这个世界的宝石，听说可以用来打开特别地区的大门。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Pir_DarkCount_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id558] =
{
	Name = "立场发生器",
	Rarity = 4,
	Desc = "装备在盔甲内部的立场发生器，散布特殊粒子，可以中断敌人通讯信号，并抑制能量武器的能量效应。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Pir_DarkDoctor_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id559] =
{
	Name = "义肢防滑垫",
	Rarity = 4,
	Desc = "装备在机械义肢底部的防滑垫，没有采用任何高科技，但是对“博士”来说，是非常重要的道具。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Pir_DarkDoctor_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id560] =
{
	Name = "反物质手枪",
	Rarity = 4,
	Desc = "“博士”费了不少心血，使用了自然界中根本不村在的粒子的反状态物制成的高科技手枪，暂时还不能产生湮灭反应。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Pir_DarkDoctor_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id561] =
{
	Name = "毁灭巨剑",
	Rarity = 5,
	Desc = "冒险星失窃的神器，为历代星球守护者所有。只要轻轻挥动，就能展现出无与伦比的威力。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Pir_HackerSwordsman_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id562] =
{
	Name = "扫视目镜",
	Rarity = 5,
	Desc = "组织专门为黑客剑士开发的目镜，能让其在任何场合都不落下风。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Pir_HackerSwordsman_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id563] =
{
	Name = "动力心脏",
	Rarity = 5,
	Desc = "使用新能源制作的超级心脏，能够源源不绝地为黑客剑士产生能量。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Pir_HackerSwordsman_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id564] =
{
	Name = "火之核心",
	Rarity = 5,
	Desc = "散落在星系之中的元素核心，能够为持有者提供强大的元素加持。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Pir_HackerSwordsman_4",
}
EquipmentInfoConfig[EquipmentInfoID.Id565] =
{
	Name = "辟邪面具",
	Rarity = 5,
	Desc = "能够防止魔物记住驱魔师音容气味的特制面具，戴上以后就可以不必担心魔物的复仇了噢~",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Pir_PaleBlueExorcist_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id566] =
{
	Name = "封魔符",
	Rarity = 5,
	Desc = "书写了封魔文的黄符，贴在魔物的额头后，魔物就只能听命于你了。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Pir_PaleBlueExorcist_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id567] =
{
	Name = "万妖册",
	Rarity = 5,
	Desc = "记载了苍青驱魔师一生所有需要捕捉的魔物的名册，抓到一个就可以勾掉一个，目前为止还勾了不到2%。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Pir_PaleBlueExorcist_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id568] =
{
	Name = "镇魔铃",
	Rarity = 5,
	Desc = "驱魔师的终极武器，需要以自己的血作为媒介才能激活，专门用来封印大黑天级的魔物。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Pir_PaleBlueExorcist_4",
}
EquipmentInfoConfig[EquipmentInfoID.Id569] =
{
	Name = "神圣头盔",
	Rarity = 4,
	Desc = "圣骑士力量的源泉，能够牢牢地护住头部，就算被敌人围住啪啪啪打脸，都完全没有感觉。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_RPG_101_Paladin_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id570] =
{
	Name = "圣盾",
	Rarity = 4,
	Desc = "简短的冷却后，圣骑士就又能施展一次无敌~当队友在水深火热中时，他可以笃定地开传送石回城。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_RPG_101_Paladin_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id571] =
{
	Name = "神圣法典",
	Rarity = 4,
	Desc = "由至高庭订立的神圣法典，规范了神职人员的一切行为。\n喉咙有痰只能咽下去噢！",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_RPG_101_Paladin_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id572] =
{
	Name = "罐装油彩",
	Rarity = 4,
	Desc = "虽然公会规定野蛮人必须涂油彩，但是爱干净的野蛮人只在公会风纪人员视察时才赶紧涂上。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_RPG_102_Barbarian_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id573] =
{
	Name = "烤肉架",
	Rarity = 4,
	Desc = "野蛮人最喜爱的野外活动，和森林里厉害的怪物打一架，然后吃一顿烤肉是野蛮人感到最快乐的事情。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_RPG_102_Barbarian_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id574] =
{
	Name = "战吼喇叭",
	Rarity = 4,
	Desc = "很多人好奇为什么野蛮人的呐喊如此震撼，其实是因为他们有特制的超级扩音大声公。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_RPG_102_Barbarian_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id575] =
{
	Name = "袖箭",
	Rarity = 4,
	Desc = "自从刺客加入冒险世界后，盗贼王牌物理输出的位置就被取代了，不过聪明的他很快找到了另一种输出方式。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_RPG_103_Thief_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id576] =
{
	Name = "万能钥匙",
	Rarity = 4,
	Desc = "盗贼大师的专用开锁钥匙，无论什么锁，只要“滴”一下就能打开了。原理是什么呢？",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_RPG_103_Thief_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id577] =
{
	Name = "暗影斗篷",
	Rarity = 4,
	Desc = "盗贼从粗心的精灵那里偷来的魔法斗篷，披着它就能随意进入别人家里盗窃了",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_RPG_103_Thief_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id578] =
{
	Name = "星光宝石",
	Rarity = 4,
	Desc = "随着舞娘情绪而变换光芒的魔法宝石，使舞娘表演时随时处于光芒照耀之下。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_RPG_104_DancingGirl_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id579] =
{
	Name = "红色绑绳",
	Rarity = 4,
	Desc = "从小就绑在舞娘脚腕处的红色绳带，只有真爱之人才能为舞娘解开，而解开之时也就是舞娘生涯结束之时。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_RPG_104_DancingGirl_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id580] =
{
	Name = "魔律铃",
	Rarity = 4,
	Desc = "流传在这个世界的魔法铃铛的一种。当舞娘起舞时，其受到晃动而发出的音律会让人不自觉地沉迷于舞娘的身姿。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_RPG_104_DancingGirl_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id581] =
{
	Name = "魔法宝珠",
	Rarity = 4,
	Desc = "凝聚了学者城法师智慧精华的灵能宝珠，只要轻轻抚摸，就能感到魔法流动产生的涟漪。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_RPG_105_Scholar_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id582] =
{
	Name = "皇家学位证书",
	Rarity = 4,
	Desc = "皇家学院的毕业证书，普通人至少花费25年才能获得，学者仅用了7年就完成了所有课程。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_RPG_105_Scholar_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id583] =
{
	Name = "万能书",
	Rarity = 4,
	Desc = "只有得到皇家学位证书的学者才能获得的全知之书，使用古老文字记录了宇宙奥秘，学者目前也没有全部看懂。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_RPG_105_Scholar_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id584] =
{
	Name = "药筐",
	Rarity = 4,
	Desc = "药师亲手编织而成的竹制箩筐，能够放下大量药草，而且背起来非常轻盈。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_RPG_106_Pharmacist_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id585] =
{
	Name = "研磨碗",
	Rarity = 4,
	Desc = "药师父亲留给药师的草药制作道具，并再三嘱托，如在外面时饿着了，可用此碗问别人要口饭吃。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_RPG_106_Pharmacist_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id586] =
{
	Name = "万灵解毒草",
	Rarity = 4,
	Desc = "每个药师都有自己的万灵解毒药配方，当药师因意外中毒时，这颗灵丹往往可以起到救命的功效。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_RPG_106_Pharmacist_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id587] =
{
	Name = "水之碎片",
	Rarity = 4,
	Desc = "收集了999个水之恶魔的魂器制作的法器，不过因为操作不当而爆炸，如今只剩下碎片。术士一直在寻找能修复这个法器的工匠。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_RPG_108_Warlock_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id588] =
{
	Name = "恶魔字典",
	Rarity = 4,
	Desc = "异界出版社倾情推出的恶魔学者专用工具书，收录了大量恶魔世界冷僻字以及文字来源的小故事，无聊的时候看一下也会觉得很有趣。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_RPG_108_Warlock_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id589] =
{
	Name = "恶魔之角",
	Rarity = 4,
	Desc = "从黑市买来的恶魔之角，卖家说是很了不起的法器，如果不是和术士特别投缘的话，是绝不会出售的。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_RPG_108_Warlock_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id590] =
{
	Name = "小熊饼干",
	Rarity = 5,
	Desc = "专门为座下的小熊烘制的饼干，每袋装了各种各样的花式。不过德鲁伊自己偶尔也会吃一些充饥，每当此时，小熊都会斜着眼看她。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_RPG_107_Druid_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id591] =
{
	Name = "百花香水",
	Rarity = 5,
	Desc = "拥有芬芳气味的香水，一旦打开，就会吸引附近的精灵来到自己身边。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_RPG_107_Druid_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id592] =
{
	Name = "禽类翻译鸡",
	Rarity = 5,
	Desc = "精通鸟语和德鲁伊语的特殊禽类，每次当德鲁伊需要与鸟类沟通时，都能通过它来转达。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_RPG_107_Druid_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id593] =
{
	Name = "枯荣树枝",
	Rarity = 5,
	Desc = "由世界之树上折落的魔法树枝，蕴含其中的魔法力量让这一节树枝永远在枯荣之间轮回。象征着生命的盛放与衰败。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_RPG_107_Druid_4",
}
EquipmentInfoConfig[EquipmentInfoID.Id594] =
{
	Name = "降龙拐",
	Rarity = 4,
	Desc = "铁拐李的招牌法宝，相传是由蓝星天庭的蟠桃木制成，拥有非常强大的神力。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_EightImmortal_TieGuaiLi_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id595] =
{
	Name = "百灵葫芦",
	Rarity = 4,
	Desc = "储存了世间各种灵丹的宝葫芦，不过离开蓝星后，葫芦里的灵丹都失去了功效。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_EightImmortal_TieGuaiLi_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id596] =
{
	Name = "残疾证",
	Rarity = 4,
	Desc = "流浪在外，铁拐李为了方便才在联邦政府办理的相关证明，凭此证，坐宇宙巴士可以优先坐座位，排队时也可以走快速通道。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_EightImmortal_TieGuaiLi_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id597] =
{
	Name = "芭蕉扇",
	Rarity = 4,
	Desc = "使用仙藤编织的法宝，只要轻轻一挥，就能扇出巨大的风力。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_EightImmortal_HanZhongLi_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id598] =
{
	Name = "冰贴",
	Rarity = 4,
	Desc = "夏日冰爽一贴，能够瞬间驱走暑气的法宝。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_EightImmortal_HanZhongLi_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id599] =
{
	Name = "飘带",
	Rarity = 4,
	Desc = "仙风傲然的光丝飘带，事实上是免水洗的高效吸水汗巾，可以瞬间吸走汗渍，保持干爽。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_EightImmortal_HanZhongLi_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id600] =
{
	Name = "渔鼓",
	Rarity = 4,
	Desc = "一头用鱼鳔蒙住的仙器渔鼓。用手轻轻拍打时，清脆的鼓声中会隐然响起道士念经的声音。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_EightImmortal_ZhangGuoLao_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id601] =
{
	Name = "叠纸驴",
	Rarity = 4,
	Desc = "张果老的专属坐骑，平时可以收纳在包里，需要的时候喷一口水就能化作小毛驴。时速120星际里，属危险载具。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_EightImmortal_ZhangGuoLao_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id602] =
{
	Name = "后视镜",
	Rarity = 4,
	Desc = "和人打赌失败，张果老只能倒骑毛驴，为了交通安全，特地拿在手里的后视镜，可以清楚看到前方路况。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_EightImmortal_ZhangGuoLao_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id603] =
{
	Name = "纯阳剑",
	Rarity = 4,
	Desc = "吕洞宾的贴身佩剑，相传只要告诉它仇人姓名住址，宝剑便会化作青龙，飞去咬伤仇人，并拍照带回。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_EightImmortal_LvDongBin_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id604] =
{
	Name = "便携式洗衣机",
	Rarity = 4,
	Desc = "吕洞宾总是仙风道骨的秘诀，只要身上的道袍永远干净，就会让人以为自己一尘不染。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_EightImmortal_LvDongBin_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id605] =
{
	Name = "快干晾衣架",
	Rarity = 4,
	Desc = "配合便携式洗衣机使用的快干晾衣架，既要风度，也不能着凉。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_EightImmortal_LvDongBin_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id606] =
{
	Name = "荷花",
	Rarity = 3,
	Desc = "全身是宝的荷花，各个部位都能入药。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_EightImmortal_HeXianGu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id607] =
{
	Name = "莲花座",
	Rarity = 3,
	Desc = "何仙姑的独门法宝，不过似乎佛教的很多佛祖也拥有同款坐垫...",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_EightImmortal_HeXianGu_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id608] =
{
	Name = "仙桃",
	Rarity = 3,
	Desc = "只要吃一口就能让人三天三夜不知饿不知困的强力提神仙果。一次食用太多可能会过度亢奋。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_EightImmortal_HeXianGu_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id609] =
{
	Name = "缩地花篮",
	Rarity = 3,
	Desc = "能够随心所愿地变出任何道具的仙篮，离开蓝星后，似乎已经无法正常运作了。否则，随便变1亿玉璧出来也是很轻松的~",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_EightImmortal_LanCaiHe_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id610] =
{
	Name = "拍板",
	Rarity = 3,
	Desc = "蓝采和最喜欢的乐器，节拍不断，打油诗歌就不断。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_EightImmortal_LanCaiHe_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id611] =
{
	Name = "另一只鞋",
	Rarity = 3,
	Desc = "蓝采和没穿的那只鞋，不知道是不是因为尺码不对才一直收起来不穿的。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_EightImmortal_LanCaiHe_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id612] =
{
	Name = "紫金箫",
	Rarity = 3,
	Desc = "韩湘子的独门法宝，正所谓“紫箫吹度千波静”，悠扬的箫声会让凶猛的动物也平静下来。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_EightImmortal_HanXiangZi_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id613] =
{
	Name = "随身听",
	Rarity = 3,
	Desc = "旧星际时代潮流一族必备的装备，能够随时随地听到自己喜欢的歌曲。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_EightImmortal_HanXiangZi_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id614] =
{
	Name = "入耳式耳机",
	Rarity = 3,
	Desc = "韩湘子在科技产品店定制的高端耳机，戴上它，仿佛徜徉在音乐的海洋之中。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_EightImmortal_HanXiangZi_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id615] =
{
	Name = "云阳板",
	Rarity = 3,
	Desc = "国舅入道前就已随身携带的玉板，入道后玉板也拥有了法力，可大可小，可乘风，可渡河。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_EightImmortal_CaoGuoJiu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id616] =
{
	Name = "BP机",
	Rarity = 3,
	Desc = "为了更好经营推销组织，国舅爷专门配备的BP机，听说比二手手机便宜好几十块钱。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_EightImmortal_CaoGuoJiu_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id617] =
{
	Name = "大哥大",
	Rarity = 3,
	Desc = "国舅爷从电器城买回来的二手电话，虽然以一折价200元入手，但是维修费目前已超6000元。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_EightImmortal_CaoGuoJiu_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id618] =
{
	Name = "皇冠",
	Rarity = 4,
	Desc = "决定战场胜负之人才能佩戴的宝冠，一旦此人在战场上牺牲，就表示这场战争已经输了。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_Chess_WhiteKing_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id619] =
{
	Name = "进攻计划",
	Rarity = 4,
	Desc = "作为先手的白棋，这份作战计划中记录着如何在先发局面下保持优势，包括乱说不存在的规则，挪子，掀桌子等。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_Chess_WhiteKing_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id620] =
{
	Name = "小白旗",
	Rarity = 4,
	Desc = "当自己移动后就会被将死时，只要挥动小白旗就能立刻达成和解。从而使对方立刻退兵，且无法得分。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_Chess_WhiteKing_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id621] =
{
	Name = "后冠",
	Rarity = 4,
	Desc = "华丽程度完胜皇冠的后冠，听说国王暗中打造了好几顶后冠，打算将来送给其他人。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_Chess_WhiteQueen_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id622] =
{
	Name = "定情信物",
	Rarity = 4,
	Desc = "皇后在故国时与初恋情人交换的定情信物，虽然联姻后来到黑棋国，不过心中始终挂念着最初的爱人。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_Chess_WhiteQueen_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id623] =
{
	Name = "地图炮",
	Rarity = 4,
	Desc = "相传是来自娘家的超必杀武器，能够在战场上对横直交叉路径上的任意敌军进行强力打击。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_Chess_WhiteQueen_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id624] =
{
	Name = "主教头冠",
	Rarity = 4,
	Desc = "代表着宗教神权的高冠，在战场上可以斜着走。除了不能穿越己方队友，斜着走多少步都没有人能管。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_Chess_WhiteBishop_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id625] =
{
	Name = "权杖",
	Rarity = 4,
	Desc = "教廷下发的节杖，杖头镶嵌了昂贵的红宝石。当主教无法教化对方时，就会趁对方不注意用权杖打爆对方的头。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_Chess_WhiteBishop_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id626] =
{
	Name = "权戒",
	Rarity = 4,
	Desc = "刻有主教签字的印戒，用来封印签署的官方文件。当主教去世后，权戒会由国王回收并礼仪性地压碎，不过国王好像每次都会偷梁换柱，自己留下真的权戒。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_Chess_WhiteBishop_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id627] =
{
	Name = "城堡头冠",
	Rarity = 4,
	Desc = "战车的专属宝冠，在战场上可以横着走。虽然平时嚣张跋扈，但是一旦国王有需要，他们就会立刻来到国王身旁。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_Chess_WhiteRook_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id628] =
{
	Name = "混凝土砖",
	Rarity = 4,
	Desc = "使用现代技术制造而成的建材，使得城堡大大加固，使用寿命长达100年之久，不过因为维修成本远大于重制成本，所以每次翻新时，国王都要扒拉算盘好一阵。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_Chess_WhiteRook_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id629] =
{
	Name = "钢刺车轮",
	Rarity = 4,
	Desc = "能够使战车一路上畅通无阻前进的装备。不过依然无法穿过己方棋子。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_Chess_WhiteRook_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id630] =
{
	Name = "骑士头冠",
	Rarity = 4,
	Desc = "帅气的鬃毛头冠，很配合骑士耿直的马头造型。佩戴后，可以在战场上越子行走，隔排打击对手。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_Chess_WhiteKnight_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id631] =
{
	Name = "黑铁马掌",
	Rarity = 4,
	Desc = "打在马蹄上的铁质防护物，防止战马在糟糕的路面上奔跑时受伤。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_Chess_WhiteKnight_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id632] =
{
	Name = "撑杆",
	Rarity = 4,
	Desc = "长达3米的撑杆，是骑士能够越子的关键装备。每一个好的骑士，都有一手过硬的撑杆跳本领。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_Chess_WhiteKnight_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id633] =
{
	Name = "主教头冠",
	Rarity = 3,
	Desc = "禁卫兵随身携带的主教头冠，一旦触底后便能按照国王命令掏出来戴上，从此就能斜着走了。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_Chess_WhitePawn_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id634] =
{
	Name = "城堡头冠",
	Rarity = 3,
	Desc = "禁卫兵随身携带的战车头冠，一旦触底后便能按照国王命令掏出来戴上，从此就能横着走了。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_Chess_WhitePawn_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id635] =
{
	Name = "骑士头冠",
	Rarity = 3,
	Desc = "禁卫兵随身携带的骑士头冠，一旦触底后便能按照国王命令掏出来戴上，从此就能跳着走了。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_Chess_WhitePawn_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id636] =
{
	Name = "寿",
	Rarity = 3,
	Desc = "（拼音：shòu），笔画数7，部首寸。——蓝星《新华字典》",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_Longevity_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id637] =
{
	Name = "比",
	Rarity = 3,
	Desc = "（拼音：bǐ），笔画数4，部首比。——蓝星《新华字典》",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_Longevity_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id638] =
{
	Name = "南",
	Rarity = 3,
	Desc = "（拼音：nán），笔画数9，部首十。——蓝星《新华字典》",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_Longevity_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id639] =
{
	Name = "山",
	Rarity = 3,
	Desc = "（拼音：shān），笔画数3，部首山。——蓝星《新华字典》",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_Longevity_4",
}
EquipmentInfoConfig[EquipmentInfoID.Id640] =
{
	Name = "恭",
	Rarity = 3,
	Desc = "（拼音：gōng），笔画数10，部首小。——蓝星《新华字典》",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_GetRich_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id641] =
{
	Name = "喜",
	Rarity = 3,
	Desc = "（拼音：xǐ），笔画数12，部首口。——蓝星《新华字典》",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_GetRich_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id642] =
{
	Name = "发",
	Rarity = 3,
	Desc = "（拼音：fā），笔画数5，部首又。——蓝星《新华字典》",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_GetRich_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id643] =
{
	Name = "财",
	Rarity = 3,
	Desc = "（拼音：cái），笔画数7，部首贝。——蓝星《新华字典》",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_GetRich_4",
}
EquipmentInfoConfig[EquipmentInfoID.Id644] =
{
	Name = "健",
	Rarity = 3,
	Desc = "（拼音：jiàn），笔画数10，部首亻。——蓝星《新华字典》",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_Healthy_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id645] =
{
	Name = "康",
	Rarity = 3,
	Desc = "（拼音：kāng），笔画数11，部首广。——蓝星《新华字典》",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_Healthy_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id646] =
{
	Name = "安",
	Rarity = 3,
	Desc = "（拼音：ān），笔画数6，部首宀。——蓝星《新华字典》",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_Healthy_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id647] =
{
	Name = "宁",
	Rarity = 3,
	Desc = "（拼音：níng），笔画数5，部首宀。——蓝星《新华字典》",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_Healthy_4",
}
EquipmentInfoConfig[EquipmentInfoID.Id648] =
{
	Name = "品",
	Rarity = 3,
	Desc = "（拼音：pǐn），笔画数9，部首口。——蓝星《新华字典》",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_Morality_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id649] =
{
	Name = "德",
	Rarity = 3,
	Desc = "（拼音：dé），笔画数15，部首彳。——蓝星《新华字典》",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_Morality_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id650] =
{
	Name = "高",
	Rarity = 3,
	Desc = "（拼音：gāo），笔画数10，部首高。——蓝星《新华字典》",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_Morality_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id651] =
{
	Name = "尚",
	Rarity = 3,
	Desc = "（拼音：shàng），笔画数8，部首小。——蓝星《新华字典》",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_Morality_4",
}
EquipmentInfoConfig[EquipmentInfoID.Id652] =
{
	Name = "有",
	Rarity = 4,
	Desc = "（拼音：yǒu），笔画数6，部首月。——蓝星《新华字典》",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_BeginEnd_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id653] =
{
	Name = "始",
	Rarity = 4,
	Desc = "（拼音：shǐ），笔画数8，部首女。——蓝星《新华字典》",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_BeginEnd_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id654] =
{
	Name = "有",
	Rarity = 4,
	Desc = "（拼音：yǒu），笔画数6，部首月。——蓝星《新华字典》",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_BeginEnd_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id655] =
{
	Name = "终",
	Rarity = 4,
	Desc = "（拼音：zhōng），笔画数8，部首纟。——蓝星《新华字典》",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_BeginEnd_4",
}
EquipmentInfoConfig[EquipmentInfoID.Id656] =
{
	Name = "受愿邮箱",
	Rarity = 4,
	Desc = "锦鲤鲤成为年度吉祥生物后专门申请的邮箱，不过任何时刻都处于爆满状态，导致锦鲤鲤无法登录阅读许愿信。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_LuckyFish_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id657] =
{
	Name = "鲤鱼旗",
	Rarity = 4,
	Desc = "使用自己为原型制作的好运鲤鱼旗，是锦鲤鲤目前经营的主要周边。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_LuckyFish_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id658] =
{
	Name = "自制火箭",
	Rarity = 4,
	Desc = "进入宇宙纪元后，鲤鱼族前往龙门空间站的必备载具，由每个鲤鱼阅读完《火箭制作速成》后自行制造。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_LuckyFish_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id659] =
{
	Name = "长耳风帽",
	Rarity = 5,
	Desc = "既能御寒，又能降低爆竹噪音的特制帽子，是年大人过年时外出惹事的必备装备。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_NewYearBeast_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id660] =
{
	Name = "墨镜",
	Rarity = 5,
	Desc = "造型拉风的墨镜，并且能够有效隔绝红色对年大人情绪造成的影响。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_NewYearBeast_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id661] =
{
	Name = "滋水枪",
	Rarity = 5,
	Desc = "年大人苦思多年自制的远距离对烟花武器，射程长达25厘米。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_NewYearBeast_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id662] =
{
	Name = "年历",
	Rarity = 5,
	Desc = "画满“正”的台历，听其他年大人说，只要画满73个，就可以坐飞船去其他星球胡闹了。说起来，闰年好像要多画一笔才行。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_All_NewYearBeast_4",
}
EquipmentInfoConfig[EquipmentInfoID.Id663] =
{
	Name = "回信",
	Rarity = 3,
	Desc = "世上独一无二的信纸，被洒满了催泪药水，不管谁看了都会感动到流泪。是情书信纸的不二之选。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_32_baiseqiaokeli_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id664] =
{
	Name = "爱心魔杖",
	Rarity = 3,
	Desc = "与丘比特弓箭的材料相同，据说可以帮助所来询问之人，测出这段爱情的幸运色。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_32_baiseqiaokeli_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id665] =
{
	Name = "巧克力食谱",
	Rarity = 3,
	Desc = "美食星最详细的巧克力食谱，其中包含了88种奇妙口味，酸甜苦辣，总有一款适合你。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_32_baiseqiaokeli_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id666] =
{
	Name = "《脑筋不转弯》",
	Rarity = 3,
	Desc = "好不容易买到的书，据说里面记载了很多有趣的问答题，长时间阅读有利于提高自己的智商。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_03_yuren_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id667] =
{
	Name = "补脑核桃",
	Rarity = 3,
	Desc = "为了变得聪明而买的核桃，因为不知道怎么吃，最后变成了手里的玩具。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_03_yuren_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id668] =
{
	Name = "2×2魔方",
	Rarity = 3,
	Desc = "鱼罐头小时候路过文具店被老板哄骗着买下的益智玩具，不过玩了超过1200个小时，目前也没有能够还原。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_03_yuren_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id669] =
{
	Name = "辣度表",
	Rarity = 3,
	Desc = "过了某个点就真的会辣死人，某种程度上也可以看做是毒药配置表。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_103_GhostChili_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id670] =
{
	Name = "医院锦旗",
	Rarity = 3,
	Desc = "医院某某科送来的锦旗，感谢她每年送来的病人，让医院业绩连年攀升。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_103_GhostChili_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id671] =
{
	Name = "捣辣椒罐",
	Rarity = 3,
	Desc = "因常年使用，罐子周边布满辣椒，碰一下就会喊「好辣好辣」，需要戴手套才能安全捧起。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_103_GhostChili_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id672] =
{
	Name = "板蓝根冲剂",
	Rarity = 3,
	Desc = "价格便宜，口感甘甜，清热解火，在夏天还是一些买不起大杯奶茶人的选择。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_104_IsatisNoodle_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id673] =
{
	Name = "刻度量杯",
	Rarity = 3,
	Desc = "只有配以适量的水，板蓝根才能兼顾口感和健康。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_104_IsatisNoodle_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id674] =
{
	Name = "温泉蛋",
	Rarity = 3,
	Desc = "适合搭配泡面，目前在和火腿肠争夺「泡面伴侣」的位置。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_104_IsatisNoodle_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id675] =
{
	Name = "雕花小刀",
	Rarity = 3,
	Desc = "皮蛋被剥开后如果没有花纹，就要用这把小刀细心雕刻出松花。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_106_PreservedEggPizza_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id676] =
{
	Name = "腌蛋坛",
	Rarity = 3,
	Desc = "腌制不同的鸭蛋会用不同的坛子，真正的皮蛋匠人甚至会给每个坛子都起一个名字。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_106_PreservedEggPizza_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id677] =
{
	Name = "腌蛋泥",
	Rarity = 3,
	Desc = "均匀地抹在鸭蛋上的泥，有配方的，不要随便从地上弄点泥就乱涂啊！",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_106_PreservedEggPizza_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id678] =
{
	Name = "密封罐头",
	Rarity = 4,
	Desc = "用剩下的鲱鱼部位会放入密封罐头，通常卖给警局作为烟雾弹的替代品。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_105_HerringRiceBall_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id679] =
{
	Name = "除臭剂",
	Rarity = 4,
	Desc = "在客人吃完饭团后会贴心地为他们喷一些除臭剂，毕竟有些人接下来还要去公共场合。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_105_HerringRiceBall_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id680] =
{
	Name = "鼻夹子",
	Rarity = 4,
	Desc = "自己做饭团时会用的夹子，对外宣称是为了防止自己患上鼻炎。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_105_HerringRiceBall_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id681] =
{
	Name = "呕吐袋",
	Rarity = 4,
	Desc = "贴心地给买料理的客人送一个呕吐袋，XXXXXL尺寸，连前天的早饭都能容纳。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_107_Kiviac_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id682] =
{
	Name = "拉链",
	Rarity = 4,
	Desc = "据说这个拉链用了100万次会自动脱落，再也拉不上。用作裤链时，千万记得使用次数。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_107_Kiviac_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id683] =
{
	Name = "小海燕",
	Rarity = 4,
	Desc = "这个小海燕栩栩如生、惟妙惟肖、活灵活现——从描述看出什么异常了吗？",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_107_Kiviac_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id684] =
{
	Name = "三层蒸笼",
	Rarity = 4,
	Desc = "为了营造生意很好的假象而定做的三层蒸笼，但每次只用一层。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_108_SteamedBun_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id685] =
{
	Name = "擀面杖",
	Rarity = 4,
	Desc = "上好的红木制作的擀面杖，通体油亮、手感沉重，不仅可以擀面，走夜路时还能防身。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_108_SteamedBun_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id686] =
{
	Name = "防滑筷",
	Rarity = 4,
	Desc = "夹起食物后可让食物不再滑落，但是不能防止手滑导致的食物滑落。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_108_SteamedBun_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id687] =
{
	Name = "铲屎铲",
	Rarity = 4,
	Desc = "可100%将地上的屎铲走，不会有任何残留。由「真有两把铲子」公司制造。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_102_KopiLuwak_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id688] =
{
	Name = "铃铛变声器",
	Rarity = 4,
	Desc = "可以将自己说的话变成各种动物声音，从而吸引小动物前来。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_102_KopiLuwak_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id689] =
{
	Name = "手磨咖啡器",
	Rarity = 4,
	Desc = "将咖啡豆研磨成粉的工具。不要被名字骗了，手动只是需要按下开关。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_102_KopiLuwak_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id690] =
{
	Name = "镶钻瓶塞",
	Rarity = 5,
	Desc = "999切面钻石制造的豪华瓶塞，如果不买瓶塞，就会发现酒很便宜了。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_101_Brandy_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id691] =
{
	Name = "防伪标签",
	Rarity = 5,
	Desc = "表面看用二维码制造的防伪标签。其实是自己画的迷宫图，扫不出任何信息。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_101_Brandy_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id692] =
{
	Name = "夜光杯",
	Rarity = 5,
	Desc = "利用太阳能板制作的杯子，需要在户外放一段时间才能在夜里发光。开关在杯底。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_101_Brandy_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id693] =
{
	Name = "酒精检测仪",
	Rarity = 5,
	Desc = "被用来检测酒精度是否达标的仪器，喝一口吹一口气，只有数值爆表才表示这批酒合格。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_Fat_101_Brandy_4",
}
EquipmentInfoConfig[EquipmentInfoID.Id694] =
{
	Name = "充电桩",
	Rarity = 3,
	Desc = "220V的充电桩，当失去清扫动力时，扫地鸡会用它为自己打气，一通操作后，自己又元气满满了。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_04_saodiji_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id695] =
{
	Name = "异次元尘袋",
	Rarity = 3,
	Desc = "据说会把放进去的垃圾传送到另一个次元，自从有了它，扫地鸡就拥有了随手捡垃圾的良好习惯。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_04_saodiji_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id696] =
{
	Name = "替换扫把头",
	Rarity = 3,
	Desc = "当扫把头太脏无法清理时，换一个就好了——这个解决方式真是太棒啦。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_04_saodiji_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id697] =
{
	Name = "花瓣发卡",
	Rarity = 3,
	Desc = "以蔷薇花瓣为形状的发卡，据说是由蔷薇花梗幻化而来。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_05_baiqiangwei_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id698] =
{
	Name = "尖刺",
	Rarity = 3,
	Desc = "随身携带的尖刺，可以保护自己，也能伤害自己。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_05_baiqiangwei_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id699] =
{
	Name = "蔷薇种子",
	Rarity = 3,
	Desc = "刺破自己的身体前，白蔷薇向土地撒下了一把希望的种子。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_05_baiqiangwei_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id700] =
{
	Name = "苹果",
	Rarity = 3,
	Desc = "咬了一口的红苹果，据小红帽说，咀嚼果肉有助于在游戏中理性思考。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_06_xiaohongmao_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id701] =
{
	Name = "帽子",
	Rarity = 3,
	Desc = "可爱的红色帽子，是小红帽出门一定会带上的物品，但要小心别让它被大风吹走。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_06_xiaohongmao_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id702] =
{
	Name = "平民卡牌",
	Rarity = 3,
	Desc = "据说至今为止，小红帽已经抽过1197次平民卡牌了，当抽到它时，小红帽总会唉声叹气。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_06_xiaohongmao_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id703] =
{
	Name = "毛笔",
	Rarity = 5,
	Desc = "随身携带的毛笔，散发出清新的墨香，据说蕴藏着巨大力量，但失忆的灵均并未发现其中关窍。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_07_quyuan_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id704] =
{
	Name = "结绳",
	Rarity = 5,
	Desc = "香草制成的结绳，馥郁芬芳，是灵均的护身符。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_07_quyuan_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id705] =
{
	Name = "玉佩",
	Rarity = 5,
	Desc = "挂在腰间的玉佩，当灵均在各地行走时，经常和其他物品发生碰撞，发出叮当叮当的响声。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_07_quyuan_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id706] =
{
	Name = "诗集",
	Rarity = 5,
	Desc = "灵均写下的诗赋合集，是宇宙中的宝物，常常引来外人争抢。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_07_quyuan_4",
}
EquipmentInfoConfig[EquipmentInfoID.Id707] =
{
	Name = "初级龙角",
	Rarity = 4,
	Desc = "必须时刻佩戴的龙角，虽然现在只是初级木制的，但龙头老大坚信，未来它一定会变成骨质高级的龙角。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_08_longtoulaoda_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id708] =
{
	Name = "龙须",
	Rarity = 4,
	Desc = "贴在脸上的龙须，据说这样做可以提高自己的威严感。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_08_longtoulaoda_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id709] =
{
	Name = "修理工具箱",
	Rarity = 4,
	Desc = "作为应急课程100分的龙头老大，不管去哪里都要带上工具箱，以免龙舟突然出现故障。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_08_longtoulaoda_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id710] =
{
	Name = "鼓棒",
	Rarity = 4,
	Desc = "别在腰间的鼓棒，当双手握住它时，仿佛整个人都燃烧起来了。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_09_taigudaren_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id711] =
{
	Name = "鼓环",
	Rarity = 4,
	Desc = "在鼓的边缘放置的鼓环，当抬鼓的时候，会发出叮咚的清脆响声。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_09_taigudaren_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id712] =
{
	Name = "红布",
	Rarity = 4,
	Desc = "当鼓不被使用的时候，总是被一块红布好好地遮盖着。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_09_taigudaren_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id713] =
{
	Name = "船桨",
	Rarity = 3,
	Desc = "时刻不离手的船桨，只有握着它，一号妹子才能安心。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_10_jiangshou01_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id714] =
{
	Name = "眼镜",
	Rarity = 3,
	Desc = "用来探测航道深浅、水流速度效果极佳，探测的准确率达到98.9256%",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_10_jiangshou01_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id715] =
{
	Name = "计算器",
	Rarity = 3,
	Desc = "当获得了船只速度、风力等级等多个信息后，再运用它算出龙头朝向和角度，是帮助队伍获胜最强大的武器。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_10_jiangshou01_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id716] =
{
	Name = "救生衣",
	Rarity = 3,
	Desc = "为了偷偷从龙舟上溜走而准备的救生衣，使用率极高，遁走成功率极低。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_11_jiangshou02_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id717] =
{
	Name = "黑色口罩",
	Rarity = 3,
	Desc = "为了遁走以后不被队友发现抓回，而准备的黑色口罩，但是使用率极低。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_11_jiangshou02_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id718] =
{
	Name = "墨镜",
	Rarity = 3,
	Desc = "不喜欢划龙舟时被太阳照射，于是每次上船时都会带上一副黑色墨镜。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_11_jiangshou02_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id719] =
{
	Name = "粽子",
	Rarity = 3,
	Desc = "龙尾小弟喜欢把粽子揣怀里，当开始划船时，会趁着无人注意的时候偷吃几口。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_12_longweixiaodi_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id720] =
{
	Name = "雄黄酒壶",
	Rarity = 3,
	Desc = "携带在身上的酒壶，据说需要在划龙舟时将酒洒入河中，但究竟是倒进了河里还是小弟的肚子里，就无人知晓了。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_12_longweixiaodi_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id721] =
{
	Name = "饭盒",
	Rarity = 3,
	Desc = "热气腾腾的饭盒，据说里面装着龙舟饭和龙舟面。\n不吃饱，哪来的力气干活呢？",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_12_longweixiaodi_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id722] =
{
	Name = "方格领带",
	Rarity = 3,
	Desc = "学院风领带，服装店老板一眼看见就非常喜欢，要求牵牛来打工时必须时时刻刻戴上它。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_13_QianNiu_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id723] =
{
	Name = "眼镜盒",
	Rarity = 3,
	Desc = "随身携带的眼镜盒，为了避免被大家叫“四眼仔”，牵牛会把名为“眼镜”的罪魁祸首，装在这个盒子里。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_13_QianNiu_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id724] =
{
	Name = "服装店工牌",
	Rarity = 3,
	Desc = "服装店员工的证明，只有带上工牌刷卡，才能在店中的各个房间穿梭自如。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_13_QianNiu_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id725] =
{
	Name = "按摩爪",
	Rarity = 4,
	Desc = "作为班级的管理者，调皮的同学们常常让人头疼，于是一心特意去商场里买了一箱头皮按摩爪。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_14_YiXin_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id726] =
{
	Name = "红墨水钢笔",
	Rarity = 4,
	Desc = "绝不离身的钢笔，钢笔的主人现在还保留着写便签条提醒自己的习惯。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_14_YiXin_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id727] =
{
	Name = "红色三角巾",
	Rarity = 4,
	Desc = "方块领结的备用品，当领结上沾上了墨水或油渍，就是红色三角巾出场的时刻了。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_14_YiXin_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id728] =
{
	Name = "单反相机",
	Rarity = 4,
	Desc = "从跳蚤市场中收购的相机，使用率极高，但其中只有风景，没有人像。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_15_ErJv_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id729] =
{
	Name = "望远镜",
	Rarity = 4,
	Desc = "当相机焦距拉到最大时，二橘看到了远方的星空，为了看得更清楚一点，第二天立刻买来了一架望远镜。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_15_ErJv_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id730] =
{
	Name = "调焦手电筒",
	Rarity = 4,
	Desc = "虽然只是一把普通的调焦手电，但据说可以为摄影带来光照上的大改变。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_15_ErJv_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id731] =
{
	Name = "猫耳发箍",
	Rarity = 4,
	Desc = "某次集市上买来的发箍，因为设计成猫耳，还有黄黑白三种花色，让三花觉得这仿佛是为她量身定制的一般。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_16_SanHua_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id732] =
{
	Name = "逗猫棒",
	Rarity = 4,
	Desc = "书包里必备的道具，是可以和街上遇到的流浪猫拉进关系、培养感情的好物品。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_16_SanHua_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id733] =
{
	Name = "棕黄眼影盘",
	Rarity = 4,
	Desc = "在看到网络主播教学“猫眼化妆术”后，三花买了主播推荐的眼影盘，并对猫眼的画法进行了深度学习。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_16_SanHua_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id734] =
{
	Name = "芥末酱",
	Rarity = 4,
	Desc = "看上去与抹茶别无二致，但口感完全不同，并且一定不能多吃，否则会发生不好的事情。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_17_SiLi_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id735] =
{
	Name = "夹心饼干",
	Rarity = 4,
	Desc = "四荔加工后的特质夹心饼干，里面是浓郁的芥末，这次，四荔会把它送给哪个幸运儿呢？",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_17_SiLi_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id736] =
{
	Name = "假蜘蛛",
	Rarity = 4,
	Desc = "整蛊姐妹的必备道具，屡试不爽，不过总是被受到惊吓的姐妹们扔掉，这已经是四荔买的第284个蜘蛛了。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_17_SiLi_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id737] =
{
	Name = "改装领结",
	Rarity = 3,
	Desc = "因为看了某部动漫，想像主角一样，拥有一个可以改变自己声音的领结。但努力改装到现在，仍然是个半成品。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_18_WuXing_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id738] =
{
	Name = "猎鹿帽",
	Rarity = 3,
	Desc = "效仿自己喜欢的侦探而购买的猎鹿帽，但因为和自己的穿衣风格大相径庭，于是被束之高阁。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_18_WuXing_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id739] =
{
	Name = "公文包",
	Rarity = 3,
	Desc = "和其他侦探一样，五行也有一个公文包，唯一区别是，其他侦探携带的是文件和证据，而五行的包里只有文具和作业。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_18_WuXing_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id740] =
{
	Name = "兔兔玩偶",
	Rarity = 3,
	Desc = "粉色的兔兔玩偶，从六瑶小时候就陪伴着她，距今已经有15个年岁了，可以给六瑶温暖与安全感。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_19_LiuYao_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id741] =
{
	Name = "辣椒喷雾",
	Rarity = 3,
	Desc = "担心在外遇到不好的事情，于是听妈妈的话，带上了可以保护自己的辣椒喷雾。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_19_LiuYao_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id742] =
{
	Name = "玉佛吊坠",
	Rarity = 3,
	Desc = "小时候收到的礼物，被家人要求一直戴着，据说找大师开过光，可以保佑自己平安顺遂。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_19_LiuYao_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id743] =
{
	Name = "线团",
	Rarity = 3,
	Desc = "成团的毛线，是能让蹦蹦跳跳的七织立刻安静下来的神器。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_20_QiZhi_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id744] =
{
	Name = "糖葫芦",
	Rarity = 3,
	Desc = "七织最喜欢的零食，就算长了蛀牙也决不放弃，几乎做到了手不离糖葫芦的地步。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_20_QiZhi_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id745] =
{
	Name = "棒针",
	Rarity = 3,
	Desc = "运用各种针法技巧，能够创造出各种精美的纺织品，七织对此颇有研究。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_20_QiZhi_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id746] =
{
	Name = "牛头面具",
	Rarity = 5,
	Desc = "被逐出天上人间婚介所后，受到了某种诅咒，必须带上牛头面具，不得以真面目示人。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_21_YueLao_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id747] =
{
	Name = "红伞",
	Rarity = 5,
	Desc = "天街香满瑞云生，红伞凝空景日明。遮阳挡雨，一把红伞足矣。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_21_YueLao_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id748] =
{
	Name = "红线",
	Rarity = 5,
	Desc = "据说被牵上红线的两人，会对对方产生好感，但真相是，红线本身并没有魔力，“好感”只来源于心理暗示而已。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_21_YueLao_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id749] =
{
	Name = "姻缘簿",
	Rarity = 5,
	Desc = "被月佬凑成一对的人，会被他开心地记录在姻缘簿上，待到二人分手后，他们的名字会被划掉。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_21_YueLao_4",
}
EquipmentInfoConfig[EquipmentInfoID.Id750] =
{
	Name = "邮包",
	Rarity = 3,
	Desc = "干净的方形邮包，里面装着大大小小的信件，和漂泊者沉甸甸的思乡之心。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_22_TuanYuan_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id751] =
{
	Name = "制服帽",
	Rarity = 3,
	Desc = "公司要求统一佩戴的制服帽，因为总是被小孩错认成交警帽，圆圆把它改成了符合人设的可爱模样。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_22_TuanYuan_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id752] =
{
	Name = "团圆铭牌",
	Rarity = 3,
	Desc = "上面写着“团圆公司荣誉邮差”，是团圆圆身份和荣誉的证明，只要认准团圆铭牌，找她送信回家准没错。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_22_TuanYuan_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id753] =
{
	Name = "铁网口罩",
	Rarity = 4,
	Desc = "在每个月圆之夜，迪斯科野狼会失去控制，攻击人类。为了不让他们在夜晚受到伤害，迪斯科野狼会主动戴上口罩，把自己禁锢在房间里。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_23_LangRen_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id754] =
{
	Name = "Ag感应器",
	Rarity = 4,
	Desc = "银是迪斯科野狼的克星，即便只是触碰到，皮肤也会产生难以忍受的灼痛。为安全起见，迪斯科野狼会把探测银制品的仪器放在身上。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_23_LangRen_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id755] =
{
	Name = "乌头草标本",
	Rarity = 4,
	Desc = "第一次变成狼时候，迪斯科野狼在狂暴之下，踩碎了盛开的乌头草。他把乌头草做成标本，作为自己变狼的纪念。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_23_LangRen_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id756] =
{
	Name = "僵尸假面",
	Rarity = 5,
	Desc = "带在脸上的假面，面孔惨白，瞳仁空洞，看上去恐怖惊悚，不管谁看了都会被吓得面容失色。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_24_XueShen_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id757] =
{
	Name = "排箫",
	Rarity = 5,
	Desc = "做工精美的排箫，能吹出动听的乐曲。不管雪神吹出什么旋律，总能恰到好处地表达她此刻的心情。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_24_XueShen_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id758] =
{
	Name = "风雪扇",
	Rarity = 5,
	Desc = "可以控制风雪的器具。只需打开扇子，山上将立刻风雪大作；相反，将扇子合上，风雪便会停息。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_24_XueShen_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id759] =
{
	Name = "蓝色蝴蝶",
	Rarity = 5,
	Desc = "蓝色的蝴蝶，常在冰雪中飞舞盘旋，象征着残酷冰雪下却生机勃勃的顽强生命。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_24_XueShen_4",
}
EquipmentInfoConfig[EquipmentInfoID.Id760] =
{
	Name = "高级厨师帽",
	Rarity = 5,
	Desc = "由入门水平进化为初级、中级，最终达到高级水平的厨师帽，同时也象征着猫眼厨娘在厨艺界的地位与水准。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_25_MaoYanChuNiang_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id761] =
{
	Name = "纯金锅铲",
	Rarity = 5,
	Desc = "由纯金打造的锅铲，不知道是厨具还是武器。\n据说打起人来可疼了。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_25_MaoYanChuNiang_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id762] =
{
	Name = "发圈收纳盒",
	Rarity = 5,
	Desc = "放在房间中的收纳盒，里面装满了各种各样的发圈，不过这些发圈总会莫名其妙消失。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_25_MaoYanChuNiang_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id763] =
{
	Name = "鎏金高脚杯",
	Rarity = 5,
	Desc = "一看就知不同凡响的高脚杯，是第二十八届酒酿厨艺大赛冠军的奖品。\n据说获胜的菜品名为：酒酿豆腐圆子。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_25_MaoYanChuNiang_4",
}
EquipmentInfoConfig[EquipmentInfoID.Id764] =
{
	Name = "薯片大礼包",
	Rarity = 4,
	Desc = "透明的大礼包，其中装着孜然味、麻辣味、黄瓜味、番茄味、可乐味、啤酒味的薯片。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_26_WenQuanJianShanJia_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id765] =
{
	Name = "四宫格水盆",
	Rarity = 4,
	Desc = "分成四个格子的水盆，盛满四种不同类型不同味道的温泉后，再进行比较记录分析。\n不能用来吃火锅。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_26_WenQuanJianShanJia_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id766] =
{
	Name = "特制搓澡巾",
	Rarity = 4,
	Desc = "据说可以把身上所有死皮全部搓下来的特制搓澡巾，会有疼痛，但也很享受。\n不是每一个人都能从它身上获得快乐。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_26_WenQuanJianShanJia_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id767] =
{
	Name = "万能秤",
	Rarity = 4,
	Desc = "能够测出体重、体脂、心跳等数据的万能称，总是被教练携带在身上。他对自己和所指导的学员们，有一样严格的要求。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_27_JianShenJiaoLian_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id768] =
{
	Name = "雀实纸尿裤",
	Rarity = 4,
	Desc = "任何一位带过孩子的家长，对它都不会陌生。对于教练来说，给孩子换纸尿裤的操作已经达成了异常纯熟的地步。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_27_JianShenJiaoLian_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id769] =
{
	Name = "好爸爸奶瓶",
	Rarity = 4,
	Desc = "“好爸爸”牌奶瓶，奶瓶上画着一个壮硕的肌肉猛男父亲，和一个崇拜他的小婴儿。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_27_JianShenJiaoLian_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id770] =
{
	Name = "朴素的领带",
	Rarity = 3,
	Desc = "平平无奇的领带，但因为是同样身为玩具熊的亲人送的，所以格外珍惜。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_28_DuanErXiong_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id771] =
{
	Name = "绒毛助听器",
	Rarity = 3,
	Desc = "猫耳厨娘送给断耳熊的礼物，听说戴上它后，坏掉的耳朵也能听到一些声音。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_28_DuanErXiong_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id772] =
{
	Name = "小熊雕像",
	Rarity = 3,
	Desc = "断耳熊的朋友们以她为原型，雕刻出的镂空小金人。栩栩如生，让断耳熊爱不释手。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_28_DuanErXiong_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id773] =
{
	Name = "高倍速猎枪",
	Rarity = 4,
	Desc = "发射子弹速度极快的猎枪，据生产商家表示，射击速度是火枪手武器的0.25倍。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_29_XueZhongLieRen_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id774] =
{
	Name = "冬帽",
	Rarity = 4,
	Desc = "一般过冬的装备，由耗牛牛毛和蜘蛛丝制成。虽然没有极度保暖，但有总比没有强。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_29_XueZhongLieRen_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id775] =
{
	Name = "防寒登山靴",
	Rarity = 4,
	Desc = "攀登雪山的专用鞋，由猪皮、草绳、牛毛制成。一般情况下可以防滑。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_29_XueZhongLieRen_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id776] =
{
	Name = "mini笔记本",
	Rarity = 4,
	Desc = "小型笔记本，可以随时随地坐下来码字和记录灵感。\n当然，拿来砸核桃也是可以的。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_30_BianJuMeiZi_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id777] =
{
	Name = "《宇宙辞典》",
	Rarity = 4,
	Desc = "既是字典也是词典，其中还囊括了成语、歇后语、俗语和谚语等内容。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_30_BianJuMeiZi_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id778] =
{
	Name = "危险的刀片",
	Rarity = 4,
	Desc = "粉丝寄来的礼物，寄来时被放在粉色礼品盒中，还有一张贺卡：\n作者大大，我要给你寄刀片！\n危险行为，请勿模仿。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_30_BianJuMeiZi_3",
}
EquipmentInfoConfig[EquipmentInfoID.Id779] =
{
	Name = "可替换鼻子",
	Rarity = 3,
	Desc = "当胡萝卜鼻子被害虫钻出洞后，这个替换物就派上了用场。除了不好用，没有其他缺点。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_31_SiNuoMan_1",
}
EquipmentInfoConfig[EquipmentInfoID.Id780] =
{
	Name = "制冰机",
	Rarity = 3,
	Desc = "即便是在炎炎夏日也能生产出冰块的机器，有它在身边，思诺曼就可以自由到山下游玩了。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_31_SiNuoMan_2",
}
EquipmentInfoConfig[EquipmentInfoID.Id781] =
{
	Name = "方格围巾",
	Rarity = 3,
	Desc = "思诺曼一定要戴上的东西，据他所说，如果自己不戴围巾，在视觉上就和裸体出门无异，有伤风化。",
	IconAtlas = "Equipment",
	IconBundle = "atlas_equipment",
	Icon = "Equipment_SPBUS_31_SiNuoMan_3",
}

