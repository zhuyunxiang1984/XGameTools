SpaceTravelFriendlinessConfig ={};
SpaceTravelFriendlinessID = 
{
	Id001 = 780001,
	Id002 = 780002,
	Id003 = 780003,
	Id004 = 780004,
	Id005 = 780005,
	Id006 = 780006,
	Id007 = 780007,
	Id008 = 780008,
	Id009 = 780009,
	Id010 = 780010,
	Id011 = 780011,
}
SpaceTravelFriendlinessConfig[SpaceTravelFriendlinessID.Id001] =
{
	Id = 1,
	Name = "魔王集团",
	Desc = "由历代魔王主持的大型副本连锁集团，垄断了冒险世界的所有副本业务。",
	Icon = "SpaceTravel_CampEnemy_1",
	FriendlinessInit = 2250,
	FriendlinessMax = 4000,
	DescList = {
		{
			Value = 4500,
			Desc = "莫逆之交",
		},
		{
			Value = 4000,
			Desc = "极佳",
		},
		{
			Value = 3500,
			Desc = "良好",
		},
		{
			Value = 3000,
			Desc = "合作",
		},
		{
			Value = 2500,
			Desc = "合作",
		},
		{
			Value = 2000,
			Desc = "普通",
		},
		{
			Value = 1500,
			Desc = "糟糕",
		},
		{
			Value = 1000,
			Desc = "恶劣",
		},
		{
			Value = 500,
			Desc = "很恶劣",
		},
		{
			Value = 0,
			Desc = "见一次打一次",
		},
	},
}
SpaceTravelFriendlinessConfig[SpaceTravelFriendlinessID.Id002] =
{
	Id = 2,
	Name = "冒险家协会",
	Desc = "虽然冒险能力0分，但是拥有大量冒险理论储备的组织",
	Icon = "SpaceTravel_CampEnemy_2",
	FriendlinessInit = 2250,
	FriendlinessMax = 4000,
	DescList = {
		{
			Value = 4500,
			Desc = "莫逆之交",
		},
		{
			Value = 4000,
			Desc = "极佳",
		},
		{
			Value = 3500,
			Desc = "良好",
		},
		{
			Value = 3000,
			Desc = "合作",
		},
		{
			Value = 2500,
			Desc = "合作",
		},
		{
			Value = 2000,
			Desc = "普通",
		},
		{
			Value = 1500,
			Desc = "糟糕",
		},
		{
			Value = 1000,
			Desc = "恶劣",
		},
		{
			Value = 500,
			Desc = "很恶劣",
		},
		{
			Value = 0,
			Desc = "见一次打一次",
		},
	},
}
SpaceTravelFriendlinessConfig[SpaceTravelFriendlinessID.Id003] =
{
	Id = 3,
	Name = "传销组织",
	Desc = "通过一拖三传播法，在短短2年间遍布宇宙各地的强大商业组织，听说最近正受到联邦政府的调查。",
	Icon = "SpaceTravel_CampEnemy_3",
	FriendlinessInit = 2250,
	FriendlinessMax = 4000,
	DescList = {
		{
			Value = 4500,
			Desc = "莫逆之交",
		},
		{
			Value = 4000,
			Desc = "极佳",
		},
		{
			Value = 3500,
			Desc = "良好",
		},
		{
			Value = 3000,
			Desc = "合作",
		},
		{
			Value = 2500,
			Desc = "合作",
		},
		{
			Value = 2000,
			Desc = "普通",
		},
		{
			Value = 1500,
			Desc = "糟糕",
		},
		{
			Value = 1000,
			Desc = "恶劣",
		},
		{
			Value = 500,
			Desc = "很恶劣",
		},
		{
			Value = 0,
			Desc = "见一次打一次",
		},
	},
}
SpaceTravelFriendlinessConfig[SpaceTravelFriendlinessID.Id004] =
{
	Id = 4,
	Name = "厨神联盟",
	Desc = "来自桃花村尚添客栈的厨师们，拿到年终奖后，团建参加了星际旅行，经过美食星时，盘缠用尽，只能现场摆起小摊，做些食物给其他游客来赚取回家路费。",
	Icon = "SpaceTravel_CampEnemy_11",
	FriendlinessInit = 2250,
	FriendlinessMax = 4000,
	DescList = {
		{
			Value = 4500,
			Desc = "莫逆之交",
		},
		{
			Value = 4000,
			Desc = "极佳",
		},
		{
			Value = 3500,
			Desc = "良好",
		},
		{
			Value = 3000,
			Desc = "合作",
		},
		{
			Value = 2500,
			Desc = "合作",
		},
		{
			Value = 2000,
			Desc = "普通",
		},
		{
			Value = 1500,
			Desc = "糟糕",
		},
		{
			Value = 1000,
			Desc = "恶劣",
		},
		{
			Value = 500,
			Desc = "很恶劣",
		},
		{
			Value = 0,
			Desc = "见一次打一次",
		},
	},
}
SpaceTravelFriendlinessConfig[SpaceTravelFriendlinessID.Id005] =
{
	Id = 5,
	Name = "保安大队",
	Desc = "大型保安公安，宇宙各地的保安都是其成员。",
	Icon = "SpaceTravel_CampEnemy_4",
	FriendlinessInit = 2250,
	FriendlinessMax = 4000,
	DescList = {
		{
			Value = 4500,
			Desc = "莫逆之交",
		},
		{
			Value = 4000,
			Desc = "极佳",
		},
		{
			Value = 3500,
			Desc = "良好",
		},
		{
			Value = 3000,
			Desc = "合作",
		},
		{
			Value = 2500,
			Desc = "合作",
		},
		{
			Value = 2000,
			Desc = "普通",
		},
		{
			Value = 1500,
			Desc = "糟糕",
		},
		{
			Value = 1000,
			Desc = "恶劣",
		},
		{
			Value = 500,
			Desc = "很恶劣",
		},
		{
			Value = 0,
			Desc = "见一次打一次",
		},
	},
}
SpaceTravelFriendlinessConfig[SpaceTravelFriendlinessID.Id006] =
{
	Id = 6,
	Name = "小浣熊自强会",
	Desc = "虽然自身很弱小，生活也很艰辛，但是当它们成千上百只聚集在一起时，就能发挥非同凡响的力量。",
	Icon = "SpaceTravel_CampEnemy_5",
	FriendlinessInit = 2250,
	FriendlinessMax = 4000,
	DescList = {
		{
			Value = 4500,
			Desc = "莫逆之交",
		},
		{
			Value = 4000,
			Desc = "极佳",
		},
		{
			Value = 3500,
			Desc = "良好",
		},
		{
			Value = 3000,
			Desc = "合作",
		},
		{
			Value = 2500,
			Desc = "合作",
		},
		{
			Value = 2000,
			Desc = "普通",
		},
		{
			Value = 1500,
			Desc = "糟糕",
		},
		{
			Value = 1000,
			Desc = "恶劣",
		},
		{
			Value = 500,
			Desc = "很恶劣",
		},
		{
			Value = 0,
			Desc = "见一次打一次",
		},
	},
}
SpaceTravelFriendlinessConfig[SpaceTravelFriendlinessID.Id007] =
{
	Id = 7,
	Name = "罪犯联盟",
	Desc = "由黑衣人组成的罪犯联盟，其大部分成员都在监狱中。因此组织已经很久没有召开一次人员完整的会议了。",
	Icon = "SpaceTravel_CampEnemy_6",
	FriendlinessInit = 2250,
	FriendlinessMax = 4000,
	DescList = {
		{
			Value = 4500,
			Desc = "莫逆之交",
		},
		{
			Value = 4000,
			Desc = "极佳",
		},
		{
			Value = 3500,
			Desc = "良好",
		},
		{
			Value = 3000,
			Desc = "合作",
		},
		{
			Value = 2500,
			Desc = "合作",
		},
		{
			Value = 2000,
			Desc = "普通",
		},
		{
			Value = 1500,
			Desc = "糟糕",
		},
		{
			Value = 1000,
			Desc = "恶劣",
		},
		{
			Value = 500,
			Desc = "很恶劣",
		},
		{
			Value = 0,
			Desc = "见一次打一次",
		},
	},
}
SpaceTravelFriendlinessConfig[SpaceTravelFriendlinessID.Id008] =
{
	Id = 8,
	Name = "高星实验室",
	Desc = "由激进科学家们组成的神秘实验室，似乎在寻找世界本质的秘密。",
	Icon = "SpaceTravel_CampEnemy_7",
	FriendlinessInit = 2250,
	FriendlinessMax = 4000,
	DescList = {
		{
			Value = 4500,
			Desc = "莫逆之交",
		},
		{
			Value = 4000,
			Desc = "极佳",
		},
		{
			Value = 3500,
			Desc = "良好",
		},
		{
			Value = 3000,
			Desc = "合作",
		},
		{
			Value = 2500,
			Desc = "合作",
		},
		{
			Value = 2000,
			Desc = "普通",
		},
		{
			Value = 1500,
			Desc = "糟糕",
		},
		{
			Value = 1000,
			Desc = "恶劣",
		},
		{
			Value = 500,
			Desc = "很恶劣",
		},
		{
			Value = 0,
			Desc = "见一次打一次",
		},
	},
}
SpaceTravelFriendlinessConfig[SpaceTravelFriendlinessID.Id009] =
{
	Id = 9,
	Name = "狂热粉丝团",
	Desc = "由各大偶像的狂热粉丝们组成的超大型粉丝团，经常为了维护各自的偶像而进行内部斗争。",
	Icon = "SpaceTravel_CampEnemy_8",
	FriendlinessInit = 2250,
	FriendlinessMax = 4000,
	DescList = {
		{
			Value = 4500,
			Desc = "莫逆之交",
		},
		{
			Value = 4000,
			Desc = "极佳",
		},
		{
			Value = 3500,
			Desc = "良好",
		},
		{
			Value = 3000,
			Desc = "合作",
		},
		{
			Value = 2500,
			Desc = "合作",
		},
		{
			Value = 2000,
			Desc = "普通",
		},
		{
			Value = 1500,
			Desc = "糟糕",
		},
		{
			Value = 1000,
			Desc = "恶劣",
		},
		{
			Value = 500,
			Desc = "很恶劣",
		},
		{
			Value = 0,
			Desc = "见一次打一次",
		},
	},
}
SpaceTravelFriendlinessConfig[SpaceTravelFriendlinessID.Id010] =
{
	Id = 10,
	Name = "星际联邦",
	Desc = "维护怪咖星系治安的政府部门，各式各样的豆豆警官将在海陆空各大领域维护爱与和平。",
	Icon = "SpaceTravel_CampEnemy_9",
	FriendlinessInit = 2250,
	FriendlinessMax = 4000,
	DescList = {
		{
			Value = 4500,
			Desc = "莫逆之交",
		},
		{
			Value = 4000,
			Desc = "极佳",
		},
		{
			Value = 3500,
			Desc = "良好",
		},
		{
			Value = 3000,
			Desc = "合作",
		},
		{
			Value = 2500,
			Desc = "合作",
		},
		{
			Value = 2000,
			Desc = "普通",
		},
		{
			Value = 1500,
			Desc = "糟糕",
		},
		{
			Value = 1000,
			Desc = "恶劣",
		},
		{
			Value = 500,
			Desc = "很恶劣",
		},
		{
			Value = 0,
			Desc = "见一次打一次",
		},
	},
}
SpaceTravelFriendlinessConfig[SpaceTravelFriendlinessID.Id011] =
{
	Id = 11,
	Name = "合体研究所",
	Desc = "由博士们组成的研究所，热衷于新发明，每年都能获得数以万计的专利。",
	Icon = "SpaceTravel_CampEnemy_10",
	FriendlinessInit = 2250,
	FriendlinessMax = 4000,
	DescList = {
		{
			Value = 4500,
			Desc = "莫逆之交",
		},
		{
			Value = 4000,
			Desc = "极佳",
		},
		{
			Value = 3500,
			Desc = "良好",
		},
		{
			Value = 3000,
			Desc = "合作",
		},
		{
			Value = 2500,
			Desc = "合作",
		},
		{
			Value = 2000,
			Desc = "普通",
		},
		{
			Value = 1500,
			Desc = "糟糕",
		},
		{
			Value = 1000,
			Desc = "恶劣",
		},
		{
			Value = 500,
			Desc = "很恶劣",
		},
		{
			Value = 0,
			Desc = "见一次打一次",
		},
	},
}
