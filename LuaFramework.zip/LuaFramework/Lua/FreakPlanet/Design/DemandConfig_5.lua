
DemandConfig[DemandID.Id501] =
{
	Id = 501,
	Name = "订购红豆冰1",
	Desc = "需要一些红豆冰",
	Value = 321251,
	Active = true,
	Weight = 5760,
	PreGoal = 
	{
		300740,
		300852,
	},
	CloseGoal = 
	{
		300896,
	},
	GoodsId = 5101251,
	Priority = 1251310,
	Num = 10,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 33684,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 3,
				},
				{
					Value = 1,
					Num = 7764,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 1,
				},
				{
					Value = 1,
					Num = 7764,
				},
			},
		},
	},
	DemandID = 410501,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id502] =
{
	Id = 502,
	Name = "订购蛋糕1",
	Desc = "需要一些蛋糕",
	Value = 321252,
	Active = true,
	Weight = 3267,
	PreGoal = 
	{
		300741,
		300424,
	},
	CloseGoal = 
	{
		300450,
	},
	GoodsId = 5201252,
	Priority = 1252331,
	Num = 5,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 20149,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 2,
				},
				{
					Value = 1,
					Num = 2869,
				},
			},
		},
	},
	DemandID = 410502,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id503] =
{
	Id = 503,
	Name = "订购蛋糕1",
	Desc = "需要一些蛋糕",
	Value = 321252,
	Active = true,
	Weight = 3465,
	PreGoal = 
	{
		300741,
		300431,
	},
	CloseGoal = 
	{
		300458,
	},
	GoodsId = 5201252,
	Priority = 1252332,
	Num = 6,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 24179,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 2,
				},
				{
					Value = 1,
					Num = 6899,
				},
			},
		},
	},
	DemandID = 410503,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id504] =
{
	Id = 504,
	Name = "订购蛋糕1",
	Desc = "需要一些蛋糕",
	Value = 321252,
	Active = true,
	Weight = 3663,
	PreGoal = 
	{
		300741,
		300439,
	},
	CloseGoal = 
	{
		300470,
	},
	GoodsId = 5201252,
	Priority = 1252333,
	Num = 6,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 24179,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 2,
				},
				{
					Value = 1,
					Num = 6899,
				},
			},
		},
	},
	DemandID = 410504,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id505] =
{
	Id = 505,
	Name = "订购蛋糕1",
	Desc = "需要一些蛋糕",
	Value = 321252,
	Active = true,
	Weight = 3960,
	PreGoal = 
	{
		300741,
		300450,
	},
	CloseGoal = 
	{
		300482,
	},
	GoodsId = 5201252,
	Priority = 1252334,
	Num = 6,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 24179,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 2,
				},
				{
					Value = 1,
					Num = 6899,
				},
			},
		},
	},
	DemandID = 410505,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id506] =
{
	Id = 506,
	Name = "订购蛋糕1",
	Desc = "需要一些蛋糕",
	Value = 321252,
	Active = true,
	Weight = 4257,
	PreGoal = 
	{
		300741,
		300462,
	},
	CloseGoal = 
	{
		300499,
	},
	GoodsId = 5201252,
	Priority = 1252335,
	Num = 6,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 24179,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 2,
				},
				{
					Value = 1,
					Num = 6899,
				},
			},
		},
	},
	DemandID = 410506,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id507] =
{
	Id = 507,
	Name = "订购蛋糕1",
	Desc = "需要一些蛋糕",
	Value = 321252,
	Active = true,
	Weight = 4653,
	PreGoal = 
	{
		300741,
		300478,
	},
	CloseGoal = 
	{
		300819,
	},
	GoodsId = 5201252,
	Priority = 1252336,
	Num = 6,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 24179,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 2,
				},
				{
					Value = 1,
					Num = 6899,
				},
			},
		},
	},
	DemandID = 410507,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id508] =
{
	Id = 508,
	Name = "订购蛋糕1",
	Desc = "需要一些蛋糕",
	Value = 321252,
	Active = true,
	Weight = 5049,
	PreGoal = 
	{
		300741,
		300494,
	},
	CloseGoal = 
	{
		300840,
	},
	GoodsId = 5201252,
	Priority = 1252337,
	Num = 6,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 24179,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 2,
				},
				{
					Value = 1,
					Num = 6899,
				},
			},
		},
	},
	DemandID = 410508,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id509] =
{
	Id = 509,
	Name = "订购蛋糕1",
	Desc = "需要一些蛋糕",
	Value = 321252,
	Active = true,
	Weight = 5544,
	PreGoal = 
	{
		300741,
		300819,
	},
	CloseGoal = 
	{
		300860,
	},
	GoodsId = 5201252,
	Priority = 1252338,
	Num = 8,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 32239,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 3,
				},
				{
					Value = 1,
					Num = 6319,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 1,
				},
				{
					Value = 1,
					Num = 6319,
				},
			},
		},
	},
	DemandID = 410509,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id510] =
{
	Id = 510,
	Name = "订购蛋糕1",
	Desc = "需要一些蛋糕",
	Value = 321252,
	Active = true,
	Weight = 6039,
	PreGoal = 
	{
		300741,
		300840,
	},
	CloseGoal = 
	{
		300884,
	},
	GoodsId = 5201252,
	Priority = 1252339,
	Num = 9,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 36269,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 3,
				},
				{
					Value = 1,
					Num = 10349,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10349,
				},
			},
		},
	},
	DemandID = 410510,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id511] =
{
	Id = 511,
	Name = "订购蛋糕1",
	Desc = "需要一些蛋糕",
	Value = 321252,
	Active = true,
	Weight = 6633,
	PreGoal = 
	{
		300741,
		300864,
	},
	CloseGoal = 
	{
		301204,
	},
	GoodsId = 5201252,
	Priority = 1252340,
	Num = 10,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 40299,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 4,
				},
				{
					Value = 1,
					Num = 5739,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 1,
				},
				{
					Value = 1,
					Num = 14379,
				},
			},
		},
	},
	DemandID = 410511,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id512] =
{
	Id = 512,
	Name = "订购米醋1",
	Desc = "需要一些米醋",
	Value = 321253,
	Active = true,
	Weight = 5292,
	PreGoal = 
	{
		300742,
		300458,
	},
	CloseGoal = 
	{
		300486,
	},
	GoodsId = 5301253,
	Priority = 1253421,
	Num = 6,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 31971,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 3,
				},
				{
					Value = 1,
					Num = 6051,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 1,
				},
				{
					Value = 1,
					Num = 6051,
				},
			},
		},
	},
	DemandID = 410512,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id513] =
{
	Id = 513,
	Name = "订购米醋1",
	Desc = "需要一些米醋",
	Value = 321253,
	Active = true,
	Weight = 5544,
	PreGoal = 
	{
		300742,
		300466,
	},
	CloseGoal = 
	{
		300494,
	},
	GoodsId = 5301253,
	Priority = 1253422,
	Num = 6,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 31971,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 3,
				},
				{
					Value = 1,
					Num = 6051,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 1,
				},
				{
					Value = 1,
					Num = 6051,
				},
			},
		},
	},
	DemandID = 410513,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id514] =
{
	Id = 514,
	Name = "订购米醋1",
	Desc = "需要一些米醋",
	Value = 321253,
	Active = true,
	Weight = 5796,
	PreGoal = 
	{
		300742,
		300474,
	},
	CloseGoal = 
	{
		300810,
	},
	GoodsId = 5301253,
	Priority = 1253423,
	Num = 6,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 31971,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 3,
				},
				{
					Value = 1,
					Num = 6051,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 1,
				},
				{
					Value = 1,
					Num = 6051,
				},
			},
		},
	},
	DemandID = 410514,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id515] =
{
	Id = 515,
	Name = "订购米醋1",
	Desc = "需要一些米醋",
	Value = 321253,
	Active = true,
	Weight = 6174,
	PreGoal = 
	{
		300742,
		300486,
	},
	CloseGoal = 
	{
		300823,
	},
	GoodsId = 5301253,
	Priority = 1253424,
	Num = 6,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 31971,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 3,
				},
				{
					Value = 1,
					Num = 6051,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 1,
				},
				{
					Value = 1,
					Num = 6051,
				},
			},
		},
	},
	DemandID = 410515,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id516] =
{
	Id = 516,
	Name = "订购米醋1",
	Desc = "需要一些米醋",
	Value = 321253,
	Active = true,
	Weight = 6552,
	PreGoal = 
	{
		300742,
		300499,
	},
	CloseGoal = 
	{
		300840,
	},
	GoodsId = 5301253,
	Priority = 1253425,
	Num = 6,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 31971,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 3,
				},
				{
					Value = 1,
					Num = 6051,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 1,
				},
				{
					Value = 1,
					Num = 6051,
				},
			},
		},
	},
	DemandID = 410516,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id517] =
{
	Id = 517,
	Name = "订购米醋1",
	Desc = "需要一些米醋",
	Value = 321253,
	Active = true,
	Weight = 7056,
	PreGoal = 
	{
		300742,
		300819,
	},
	CloseGoal = 
	{
		300856,
	},
	GoodsId = 5301253,
	Priority = 1253426,
	Num = 8,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 42628,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 4,
				},
				{
					Value = 1,
					Num = 8068,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 1,
				},
				{
					Value = 1,
					Num = 16708,
				},
			},
		},
	},
	DemandID = 410517,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id518] =
{
	Id = 518,
	Name = "订购米醋1",
	Desc = "需要一些米醋",
	Value = 321253,
	Active = true,
	Weight = 7560,
	PreGoal = 
	{
		300742,
		300836,
	},
	CloseGoal = 
	{
		300876,
	},
	GoodsId = 5301253,
	Priority = 1253427,
	Num = 8,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 42628,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 4,
				},
				{
					Value = 1,
					Num = 8068,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 1,
				},
				{
					Value = 1,
					Num = 16708,
				},
			},
		},
	},
	DemandID = 410518,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id519] =
{
	Id = 519,
	Name = "订购米醋1",
	Desc = "需要一些米醋",
	Value = 321253,
	Active = true,
	Weight = 8190,
	PreGoal = 
	{
		300742,
		300856,
	},
	CloseGoal = 
	{
		300896,
	},
	GoodsId = 5301253,
	Priority = 1253428,
	Num = 9,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 47956,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 5,
				},
				{
					Value = 1,
					Num = 4756,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 1,
				},
				{
					Value = 1,
					Num = 22036,
				},
			},
		},
	},
	DemandID = 410519,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id520] =
{
	Id = 520,
	Name = "订购米醋1",
	Desc = "需要一些米醋",
	Value = 321253,
	Active = true,
	Weight = 8820,
	PreGoal = 
	{
		300742,
		300876,
	},
	CloseGoal = 
	{
		301224,
	},
	GoodsId = 5301253,
	Priority = 1253429,
	Num = 10,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 53285,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 5,
				},
				{
					Value = 1,
					Num = 10085,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 1,
				},
				{
					Value = 1,
					Num = 27365,
				},
			},
		},
	},
	DemandID = 410520,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id521] =
{
	Id = 521,
	Name = "订购米醋1",
	Desc = "需要一些米醋",
	Value = 321253,
	Active = true,
	Weight = 9576,
	PreGoal = 
	{
		300742,
		300900,
	},
	CloseGoal = 
	{
		301248,
	},
	GoodsId = 5301253,
	Priority = 1253430,
	Num = 10,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 53285,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 5,
				},
				{
					Value = 1,
					Num = 10085,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 1,
				},
				{
					Value = 1,
					Num = 27365,
				},
			},
		},
	},
	DemandID = 410521,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id522] =
{
	Id = 522,
	Name = "订购海鲜酱1",
	Desc = "需要一些海鲜酱",
	Value = 321254,
	Active = true,
	Weight = 6075,
	PreGoal = 
	{
		300743,
		300470,
	},
	CloseGoal = 
	{
		300499,
	},
	GoodsId = 5401254,
	Priority = 1254451,
	Num = 6,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 39618,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 4,
				},
				{
					Value = 1,
					Num = 5058,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 1,
				},
				{
					Value = 1,
					Num = 13698,
				},
			},
		},
	},
	DemandID = 410522,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id523] =
{
	Id = 523,
	Name = "订购海鲜酱1",
	Desc = "需要一些海鲜酱",
	Value = 321254,
	Active = true,
	Weight = 6345,
	PreGoal = 
	{
		300743,
		300478,
	},
	CloseGoal = 
	{
		300810,
	},
	GoodsId = 5401254,
	Priority = 1254452,
	Num = 6,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 39618,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 4,
				},
				{
					Value = 1,
					Num = 5058,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 1,
				},
				{
					Value = 1,
					Num = 13698,
				},
			},
		},
	},
	DemandID = 410523,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id524] =
{
	Id = 524,
	Name = "订购海鲜酱1",
	Desc = "需要一些海鲜酱",
	Value = 321254,
	Active = true,
	Weight = 6615,
	PreGoal = 
	{
		300743,
		300486,
	},
	CloseGoal = 
	{
		300823,
	},
	GoodsId = 5401254,
	Priority = 1254453,
	Num = 6,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 39618,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 4,
				},
				{
					Value = 1,
					Num = 5058,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 1,
				},
				{
					Value = 1,
					Num = 13698,
				},
			},
		},
	},
	DemandID = 410524,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id525] =
{
	Id = 525,
	Name = "订购海鲜酱1",
	Desc = "需要一些海鲜酱",
	Value = 321254,
	Active = true,
	Weight = 7020,
	PreGoal = 
	{
		300743,
		300499,
	},
	CloseGoal = 
	{
		300836,
	},
	GoodsId = 5401254,
	Priority = 1254454,
	Num = 6,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 39618,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 4,
				},
				{
					Value = 1,
					Num = 5058,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 1,
				},
				{
					Value = 1,
					Num = 13698,
				},
			},
		},
	},
	DemandID = 410525,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id526] =
{
	Id = 526,
	Name = "订购海鲜酱1",
	Desc = "需要一些海鲜酱",
	Value = 321254,
	Active = true,
	Weight = 7425,
	PreGoal = 
	{
		300743,
		300814,
	},
	CloseGoal = 
	{
		300852,
	},
	GoodsId = 5401254,
	Priority = 1254455,
	Num = 6,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 39618,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 4,
				},
				{
					Value = 1,
					Num = 5058,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 1,
				},
				{
					Value = 1,
					Num = 13698,
				},
			},
		},
	},
	DemandID = 410526,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id527] =
{
	Id = 527,
	Name = "订购海鲜酱1",
	Desc = "需要一些海鲜酱",
	Value = 321254,
	Active = true,
	Weight = 7965,
	PreGoal = 
	{
		300743,
		300832,
	},
	CloseGoal = 
	{
		300868,
	},
	GoodsId = 5401254,
	Priority = 1254456,
	Num = 6,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 39618,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 4,
				},
				{
					Value = 1,
					Num = 5058,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 1,
				},
				{
					Value = 1,
					Num = 13698,
				},
			},
		},
	},
	DemandID = 410527,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id528] =
{
	Id = 528,
	Name = "订购海鲜酱1",
	Desc = "需要一些海鲜酱",
	Value = 321254,
	Active = true,
	Weight = 8505,
	PreGoal = 
	{
		300743,
		300848,
	},
	CloseGoal = 
	{
		300888,
	},
	GoodsId = 5401254,
	Priority = 1254457,
	Num = 8,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 52824,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 5,
				},
				{
					Value = 1,
					Num = 9624,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 1,
				},
				{
					Value = 1,
					Num = 26904,
				},
			},
		},
	},
	DemandID = 410528,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id529] =
{
	Id = 529,
	Name = "订购海鲜酱1",
	Desc = "需要一些海鲜酱",
	Value = 321254,
	Active = true,
	Weight = 9180,
	PreGoal = 
	{
		300743,
		300868,
	},
	CloseGoal = 
	{
		301204,
	},
	GoodsId = 5401254,
	Priority = 1254458,
	Num = 8,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 52824,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 5,
				},
				{
					Value = 1,
					Num = 9624,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 1,
				},
				{
					Value = 1,
					Num = 26904,
				},
			},
		},
	},
	DemandID = 410529,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id530] =
{
	Id = 530,
	Name = "订购海鲜酱1",
	Desc = "需要一些海鲜酱",
	Value = 321254,
	Active = true,
	Weight = 9855,
	PreGoal = 
	{
		300743,
		300888,
	},
	CloseGoal = 
	{
		301236,
	},
	GoodsId = 5401254,
	Priority = 1254459,
	Num = 9,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 59427,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 6,
				},
				{
					Value = 1,
					Num = 7587,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 2,
				},
				{
					Value = 1,
					Num = 7587,
				},
			},
		},
	},
	DemandID = 410530,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id531] =
{
	Id = 531,
	Name = "订购海鲜酱1",
	Desc = "需要一些海鲜酱",
	Value = 321254,
	Active = true,
	Weight = 10665,
	PreGoal = 
	{
		300743,
		301216,
	},
	CloseGoal = 
	{
		301260,
	},
	GoodsId = 5401254,
	Priority = 1254460,
	Num = 10,
	RewardList = {
		{
			Weight = 0,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 66031,
				},
			},
		},
		{
			Weight = 80,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320001,
					Num = 6,
				},
				{
					Value = 1,
					Num = 14191,
				},
			},
		},
		{
			Weight = 60,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320002,
					Num = 2,
				},
				{
					Value = 1,
					Num = 14191,
				},
			},
		},
	},
	DemandID = 410531,
	DemandGroupList = {
		420003,
		420008,
		420009,
	},
}
DemandConfig[DemandID.Id532] =
{
	Id = 532,
	Name = "订购入场券1",
	Desc = "需要一些入场券",
	Value = 321401,
	Active = true,
	Weight = 14045,
	PreGoal = 
	{
		300807,
		300804,
	},
	CloseGoal = 
	{
		300836,
	},
	GoodsId = 5501401,
	Priority = 1401531,
	Num = 22,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 17309,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 147,
				},
				{
					Value = 1,
					Num = 2609,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 147,
				},
				{
					Value = 1,
					Num = 2609,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 29,
				},
				{
					Value = 1,
					Num = 2809,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 29,
				},
				{
					Value = 1,
					Num = 2809,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 5,
				},
				{
					Value = 1,
					Num = 4809,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 5,
				},
				{
					Value = 1,
					Num = 4809,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 4809,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 4809,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 103,
				},
				{
					Value = 320051,
					Num = 70,
				},
			},
		},
	},
	DemandID = 410532,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id533] =
{
	Id = 533,
	Name = "订购入场券1",
	Desc = "需要一些入场券",
	Value = 321401,
	Active = true,
	Weight = 14575,
	PreGoal = 
	{
		300807,
		300814,
	},
	CloseGoal = 
	{
		300844,
	},
	GoodsId = 5501401,
	Priority = 1401532,
	Num = 24,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 18883,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 160,
				},
				{
					Value = 1,
					Num = 2883,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 160,
				},
				{
					Value = 1,
					Num = 2883,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 32,
				},
				{
					Value = 1,
					Num = 2883,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 32,
				},
				{
					Value = 1,
					Num = 2883,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 6,
				},
				{
					Value = 1,
					Num = 3883,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 6,
				},
				{
					Value = 1,
					Num = 3883,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 6383,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 6383,
				},
			},
		},
	},
	DemandID = 410533,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id534] =
{
	Id = 534,
	Name = "订购入场券1",
	Desc = "需要一些入场券",
	Value = 321401,
	Active = true,
	Weight = 15105,
	PreGoal = 
	{
		300807,
		300823,
	},
	CloseGoal = 
	{
		300856,
	},
	GoodsId = 5501401,
	Priority = 1401533,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 19670,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 167,
				},
				{
					Value = 1,
					Num = 2970,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 167,
				},
				{
					Value = 1,
					Num = 2970,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 33,
				},
				{
					Value = 1,
					Num = 3170,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 33,
				},
				{
					Value = 1,
					Num = 3170,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 6,
				},
				{
					Value = 1,
					Num = 4670,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 6,
				},
				{
					Value = 1,
					Num = 4670,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 7170,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 7170,
				},
			},
		},
	},
	DemandID = 410534,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id535] =
{
	Id = 535,
	Name = "订购入场券1",
	Desc = "需要一些入场券",
	Value = 321401,
	Active = true,
	Weight = 15900,
	PreGoal = 
	{
		300807,
		300836,
	},
	CloseGoal = 
	{
		300868,
	},
	GoodsId = 5501401,
	Priority = 1401534,
	Num = 26,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 20456,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 173,
				},
				{
					Value = 1,
					Num = 3156,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 173,
				},
				{
					Value = 1,
					Num = 3156,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 34,
				},
				{
					Value = 1,
					Num = 3456,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 34,
				},
				{
					Value = 1,
					Num = 3456,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 6,
				},
				{
					Value = 1,
					Num = 5456,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 6,
				},
				{
					Value = 1,
					Num = 5456,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 7956,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 7956,
				},
			},
		},
	},
	DemandID = 410535,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id536] =
{
	Id = 536,
	Name = "订购入场券1",
	Desc = "需要一些入场券",
	Value = 321401,
	Active = true,
	Weight = 16695,
	PreGoal = 
	{
		300807,
		300848,
	},
	CloseGoal = 
	{
		300884,
	},
	GoodsId = 5501401,
	Priority = 1401535,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 22030,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 187,
				},
				{
					Value = 1,
					Num = 3330,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 187,
				},
				{
					Value = 1,
					Num = 3330,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 37,
				},
				{
					Value = 1,
					Num = 3530,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 37,
				},
				{
					Value = 1,
					Num = 3530,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 7,
				},
				{
					Value = 1,
					Num = 4530,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 7,
				},
				{
					Value = 1,
					Num = 4530,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 9530,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 9530,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 132,
				},
				{
					Value = 320051,
					Num = 88,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 26,
				},
				{
					Value = 320052,
					Num = 18,
				},
			},
		},
	},
	DemandID = 410536,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id537] =
{
	Id = 537,
	Name = "订购入场券1",
	Desc = "需要一些入场券",
	Value = 321401,
	Active = true,
	Weight = 17755,
	PreGoal = 
	{
		300807,
		300864,
	},
	CloseGoal = 
	{
		300900,
	},
	GoodsId = 5501401,
	Priority = 1401536,
	Num = 30,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 23604,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 200,
				},
				{
					Value = 1,
					Num = 3604,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 200,
				},
				{
					Value = 1,
					Num = 3604,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 40,
				},
				{
					Value = 1,
					Num = 3604,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 40,
				},
				{
					Value = 1,
					Num = 3604,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 8,
				},
				{
					Value = 1,
					Num = 3604,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 8,
				},
				{
					Value = 1,
					Num = 3604,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 11104,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 11104,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 141,
				},
				{
					Value = 320051,
					Num = 95,
				},
			},
		},
	},
	DemandID = 410537,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id538] =
{
	Id = 538,
	Name = "订购入场券1",
	Desc = "需要一些入场券",
	Value = 321401,
	Active = true,
	Weight = 18815,
	PreGoal = 
	{
		300807,
		300880,
	},
	CloseGoal = 
	{
		301224,
	},
	GoodsId = 5501401,
	Priority = 1401537,
	Num = 32,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 25177,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 214,
				},
				{
					Value = 1,
					Num = 3777,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 214,
				},
				{
					Value = 1,
					Num = 3777,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 42,
				},
				{
					Value = 1,
					Num = 4177,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 42,
				},
				{
					Value = 1,
					Num = 4177,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 8,
				},
				{
					Value = 1,
					Num = 5177,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 8,
				},
				{
					Value = 1,
					Num = 5177,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 12677,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 12677,
				},
			},
		},
	},
	DemandID = 410538,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id539] =
{
	Id = 539,
	Name = "订购入场券1",
	Desc = "需要一些入场券",
	Value = 321401,
	Active = true,
	Weight = 20140,
	PreGoal = 
	{
		300807,
		300900,
	},
	CloseGoal = 
	{
		301244,
	},
	GoodsId = 5501401,
	Priority = 1401538,
	Num = 35,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 27538,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 234,
				},
				{
					Value = 1,
					Num = 4138,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 234,
				},
				{
					Value = 1,
					Num = 4138,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 46,
				},
				{
					Value = 1,
					Num = 4538,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 46,
				},
				{
					Value = 1,
					Num = 4538,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 9,
				},
				{
					Value = 1,
					Num = 5038,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 9,
				},
				{
					Value = 1,
					Num = 5038,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 15038,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 15038,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 165,
				},
				{
					Value = 320051,
					Num = 110,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 33,
				},
				{
					Value = 320052,
					Num = 22,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 6,
				},
				{
					Value = 320053,
					Num = 5,
				},
			},
		},
	},
	DemandID = 410539,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id540] =
{
	Id = 540,
	Name = "订购入场券1",
	Desc = "需要一些入场券",
	Value = 321401,
	Active = true,
	Weight = 21465,
	PreGoal = 
	{
		300807,
		301224,
	},
	CloseGoal = 
	{
		301268,
	},
	GoodsId = 5501401,
	Priority = 1401539,
	Num = 38,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 29898,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 254,
				},
				{
					Value = 1,
					Num = 4498,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 254,
				},
				{
					Value = 1,
					Num = 4498,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 50,
				},
				{
					Value = 1,
					Num = 4898,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 50,
				},
				{
					Value = 1,
					Num = 4898,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 10,
				},
				{
					Value = 1,
					Num = 4898,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 10,
				},
				{
					Value = 1,
					Num = 4898,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 4898,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 4898,
				},
			},
		},
	},
	DemandID = 410540,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id541] =
{
	Id = 541,
	Name = "订购入场券1",
	Desc = "需要一些入场券",
	Value = 321401,
	Active = true,
	Weight = 23055,
	PreGoal = 
	{
		300807,
		301248,
	},
	CloseGoal = 
	{
		301292,
	},
	GoodsId = 5501401,
	Priority = 1401540,
	Num = 42,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 33045,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 280,
				},
				{
					Value = 1,
					Num = 5045,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 280,
				},
				{
					Value = 1,
					Num = 5045,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 56,
				},
				{
					Value = 1,
					Num = 5045,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 56,
				},
				{
					Value = 1,
					Num = 5045,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 11,
				},
				{
					Value = 1,
					Num = 5545,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 11,
				},
				{
					Value = 1,
					Num = 5545,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 8045,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 8045,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 198,
				},
				{
					Value = 320051,
					Num = 132,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 39,
				},
				{
					Value = 320052,
					Num = 27,
				},
			},
		},
	},
	DemandID = 410541,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id542] =
{
	Id = 542,
	Name = "订购考古刷1",
	Desc = "需要一些考古刷",
	Value = 321402,
	Active = true,
	Weight = 15680,
	PreGoal = 
	{
		300819,
	},
	CloseGoal = 
	{
		300848,
	},
	GoodsId = 5601402,
	Priority = 1402561,
	Num = 22,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 18821,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 177,
				},
				{
					Value = 1,
					Num = 1121,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 177,
				},
				{
					Value = 1,
					Num = 1121,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 35,
				},
				{
					Value = 1,
					Num = 1321,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 35,
				},
				{
					Value = 1,
					Num = 1321,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 7,
				},
				{
					Value = 1,
					Num = 1321,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 7,
				},
				{
					Value = 1,
					Num = 1321,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 6321,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 6321,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 112,
				},
				{
					Value = 320051,
					Num = 76,
				},
			},
		},
	},
	DemandID = 410542,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id543] =
{
	Id = 543,
	Name = "订购考古刷1",
	Desc = "需要一些考古刷",
	Value = 321402,
	Active = true,
	Weight = 16240,
	PreGoal = 
	{
		300819,
		300827,
	},
	CloseGoal = 
	{
		300856,
	},
	GoodsId = 5601402,
	Priority = 1402562,
	Num = 24,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 20532,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 193,
				},
				{
					Value = 1,
					Num = 1232,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 193,
				},
				{
					Value = 1,
					Num = 1232,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 38,
				},
				{
					Value = 1,
					Num = 1532,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 38,
				},
				{
					Value = 1,
					Num = 1532,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 7,
				},
				{
					Value = 1,
					Num = 3032,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 7,
				},
				{
					Value = 1,
					Num = 3032,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 8032,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 8032,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 123,
				},
				{
					Value = 320051,
					Num = 82,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 24,
				},
				{
					Value = 320052,
					Num = 17,
				},
			},
		},
	},
	DemandID = 410543,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id544] =
{
	Id = 544,
	Name = "订购考古刷1",
	Desc = "需要一些考古刷",
	Value = 321402,
	Active = true,
	Weight = 16800,
	PreGoal = 
	{
		300819,
		300836,
	},
	CloseGoal = 
	{
		300868,
	},
	GoodsId = 5601402,
	Priority = 1402563,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 21388,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 202,
				},
				{
					Value = 1,
					Num = 1188,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 202,
				},
				{
					Value = 1,
					Num = 1188,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 40,
				},
				{
					Value = 1,
					Num = 1388,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 40,
				},
				{
					Value = 1,
					Num = 1388,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 8,
				},
				{
					Value = 1,
					Num = 1388,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 8,
				},
				{
					Value = 1,
					Num = 1388,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 8888,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 8888,
				},
			},
		},
	},
	DemandID = 410544,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id545] =
{
	Id = 545,
	Name = "订购考古刷1",
	Desc = "需要一些考古刷",
	Value = 321402,
	Active = true,
	Weight = 17640,
	PreGoal = 
	{
		300819,
		300848,
	},
	CloseGoal = 
	{
		300880,
	},
	GoodsId = 5601402,
	Priority = 1402564,
	Num = 26,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 22244,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 210,
				},
				{
					Value = 1,
					Num = 1244,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 210,
				},
				{
					Value = 1,
					Num = 1244,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 42,
				},
				{
					Value = 1,
					Num = 1244,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 42,
				},
				{
					Value = 1,
					Num = 1244,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 8,
				},
				{
					Value = 1,
					Num = 2244,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 8,
				},
				{
					Value = 1,
					Num = 2244,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 9744,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 9744,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 133,
				},
				{
					Value = 320051,
					Num = 89,
				},
			},
		},
	},
	DemandID = 410545,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id546] =
{
	Id = 546,
	Name = "订购考古刷1",
	Desc = "需要一些考古刷",
	Value = 321402,
	Active = true,
	Weight = 18480,
	PreGoal = 
	{
		300819,
		300860,
	},
	CloseGoal = 
	{
		300896,
	},
	GoodsId = 5601402,
	Priority = 1402565,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 23955,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 226,
				},
				{
					Value = 1,
					Num = 1355,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 226,
				},
				{
					Value = 1,
					Num = 1355,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 45,
				},
				{
					Value = 1,
					Num = 1455,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 45,
				},
				{
					Value = 1,
					Num = 1455,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 9,
				},
				{
					Value = 1,
					Num = 1455,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 9,
				},
				{
					Value = 1,
					Num = 1455,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 11455,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 11455,
				},
			},
		},
	},
	DemandID = 410546,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id547] =
{
	Id = 547,
	Name = "订购考古刷1",
	Desc = "需要一些考古刷",
	Value = 321402,
	Active = true,
	Weight = 19600,
	PreGoal = 
	{
		300819,
		300876,
	},
	CloseGoal = 
	{
		301216,
	},
	GoodsId = 5601402,
	Priority = 1402566,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 23955,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 226,
				},
				{
					Value = 1,
					Num = 1355,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 226,
				},
				{
					Value = 1,
					Num = 1355,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 45,
				},
				{
					Value = 1,
					Num = 1455,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 45,
				},
				{
					Value = 1,
					Num = 1455,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 9,
				},
				{
					Value = 1,
					Num = 1455,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 9,
				},
				{
					Value = 1,
					Num = 1455,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 11455,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 11455,
				},
			},
		},
	},
	DemandID = 410547,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id548] =
{
	Id = 548,
	Name = "订购考古刷1",
	Desc = "需要一些考古刷",
	Value = 321402,
	Active = true,
	Weight = 20720,
	PreGoal = 
	{
		300819,
		300892,
	},
	CloseGoal = 
	{
		301236,
	},
	GoodsId = 5601402,
	Priority = 1402567,
	Num = 32,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 27377,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 258,
				},
				{
					Value = 1,
					Num = 1577,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 258,
				},
				{
					Value = 1,
					Num = 1577,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 51,
				},
				{
					Value = 1,
					Num = 1877,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 51,
				},
				{
					Value = 1,
					Num = 1877,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 10,
				},
				{
					Value = 1,
					Num = 2377,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 10,
				},
				{
					Value = 1,
					Num = 2377,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 2377,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 2377,
				},
			},
		},
	},
	DemandID = 410548,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id549] =
{
	Id = 549,
	Name = "订购考古刷1",
	Desc = "需要一些考古刷",
	Value = 321402,
	Active = true,
	Weight = 22120,
	PreGoal = 
	{
		300819,
		301216,
	},
	CloseGoal = 
	{
		301256,
	},
	GoodsId = 5601402,
	Priority = 1402568,
	Num = 35,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 29943,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 282,
				},
				{
					Value = 1,
					Num = 1743,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 282,
				},
				{
					Value = 1,
					Num = 1743,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 56,
				},
				{
					Value = 1,
					Num = 1943,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 56,
				},
				{
					Value = 1,
					Num = 1943,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 11,
				},
				{
					Value = 1,
					Num = 2443,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 11,
				},
				{
					Value = 1,
					Num = 2443,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 4943,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 4943,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 179,
				},
				{
					Value = 320051,
					Num = 120,
				},
			},
		},
	},
	DemandID = 410549,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id550] =
{
	Id = 550,
	Name = "订购考古刷1",
	Desc = "需要一些考古刷",
	Value = 321402,
	Active = true,
	Weight = 23520,
	PreGoal = 
	{
		300819,
		301236,
	},
	CloseGoal = 
	{
		301280,
	},
	GoodsId = 5601402,
	Priority = 1402569,
	Num = 38,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 32510,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 307,
				},
				{
					Value = 1,
					Num = 1810,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 307,
				},
				{
					Value = 1,
					Num = 1810,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 61,
				},
				{
					Value = 1,
					Num = 2010,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 61,
				},
				{
					Value = 1,
					Num = 2010,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 12,
				},
				{
					Value = 1,
					Num = 2510,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 12,
				},
				{
					Value = 1,
					Num = 2510,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 7510,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 7510,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 195,
				},
				{
					Value = 320051,
					Num = 130,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 39,
				},
				{
					Value = 320052,
					Num = 26,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 7,
				},
				{
					Value = 320053,
					Num = 6,
				},
			},
		},
	},
	DemandID = 410550,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id551] =
{
	Id = 551,
	Name = "订购考古刷1",
	Desc = "需要一些考古刷",
	Value = 321402,
	Active = true,
	Weight = 25200,
	PreGoal = 
	{
		300819,
		301260,
	},
	CloseGoal = 
	{
		301306,
	},
	GoodsId = 5601402,
	Priority = 1402570,
	Num = 40,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 34221,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 323,
				},
				{
					Value = 1,
					Num = 1921,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 323,
				},
				{
					Value = 1,
					Num = 1921,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 64,
				},
				{
					Value = 1,
					Num = 2221,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 64,
				},
				{
					Value = 1,
					Num = 2221,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 12,
				},
				{
					Value = 1,
					Num = 4221,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 12,
				},
				{
					Value = 1,
					Num = 4221,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 9221,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 9221,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 205,
				},
				{
					Value = 320051,
					Num = 137,
				},
			},
		},
	},
	DemandID = 410551,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id552] =
{
	Id = 552,
	Name = "订购焚香1",
	Desc = "需要一些焚香",
	Value = 321403,
	Active = true,
	Weight = 17405,
	PreGoal = 
	{
		300832,
	},
	CloseGoal = 
	{
		300860,
	},
	GoodsId = 5701403,
	Priority = 1403591,
	Num = 24,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 20779,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 176,
				},
				{
					Value = 1,
					Num = 3179,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 176,
				},
				{
					Value = 1,
					Num = 3179,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 35,
				},
				{
					Value = 1,
					Num = 3279,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 35,
				},
				{
					Value = 1,
					Num = 3279,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 7,
				},
				{
					Value = 1,
					Num = 3279,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 7,
				},
				{
					Value = 1,
					Num = 3279,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 8279,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 8279,
				},
			},
		},
	},
	DemandID = 410552,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id553] =
{
	Id = 553,
	Name = "订购焚香1",
	Desc = "需要一些焚香",
	Value = 321403,
	Active = true,
	Weight = 17995,
	PreGoal = 
	{
		300832,
		300840,
	},
	CloseGoal = 
	{
		300868,
	},
	GoodsId = 5701403,
	Priority = 1403592,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 21645,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 183,
				},
				{
					Value = 1,
					Num = 3345,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 183,
				},
				{
					Value = 1,
					Num = 3345,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 36,
				},
				{
					Value = 1,
					Num = 3645,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 36,
				},
				{
					Value = 1,
					Num = 3645,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 7,
				},
				{
					Value = 1,
					Num = 4145,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 7,
				},
				{
					Value = 1,
					Num = 4145,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 9145,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 9145,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 129,
				},
				{
					Value = 320051,
					Num = 87,
				},
			},
		},
	},
	DemandID = 410553,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id554] =
{
	Id = 554,
	Name = "订购焚香1",
	Desc = "需要一些焚香",
	Value = 321403,
	Active = true,
	Weight = 18585,
	PreGoal = 
	{
		300832,
		300848,
	},
	CloseGoal = 
	{
		300880,
	},
	GoodsId = 5701403,
	Priority = 1403593,
	Num = 26,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 22511,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 191,
				},
				{
					Value = 1,
					Num = 3411,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 191,
				},
				{
					Value = 1,
					Num = 3411,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 38,
				},
				{
					Value = 1,
					Num = 3511,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 38,
				},
				{
					Value = 1,
					Num = 3511,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 7,
				},
				{
					Value = 1,
					Num = 5011,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 7,
				},
				{
					Value = 1,
					Num = 5011,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10011,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 10011,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 135,
				},
				{
					Value = 320051,
					Num = 90,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 27,
				},
				{
					Value = 320052,
					Num = 18,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 5,
				},
				{
					Value = 320053,
					Num = 4,
				},
			},
		},
	},
	DemandID = 410554,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id555] =
{
	Id = 555,
	Name = "订购焚香1",
	Desc = "需要一些焚香",
	Value = 321403,
	Active = true,
	Weight = 19470,
	PreGoal = 
	{
		300832,
		300860,
	},
	CloseGoal = 
	{
		300892,
	},
	GoodsId = 5701403,
	Priority = 1403594,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 24243,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 206,
				},
				{
					Value = 1,
					Num = 3643,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 206,
				},
				{
					Value = 1,
					Num = 3643,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 41,
				},
				{
					Value = 1,
					Num = 3743,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 41,
				},
				{
					Value = 1,
					Num = 3743,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 8,
				},
				{
					Value = 1,
					Num = 4243,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 8,
				},
				{
					Value = 1,
					Num = 4243,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 11743,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 11743,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 145,
				},
				{
					Value = 320051,
					Num = 97,
				},
			},
		},
	},
	DemandID = 410555,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id556] =
{
	Id = 556,
	Name = "订购焚香1",
	Desc = "需要一些焚香",
	Value = 321403,
	Active = true,
	Weight = 20355,
	PreGoal = 
	{
		300832,
		300872,
	},
	CloseGoal = 
	{
		301204,
	},
	GoodsId = 5701403,
	Priority = 1403595,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 24243,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 206,
				},
				{
					Value = 1,
					Num = 3643,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 206,
				},
				{
					Value = 1,
					Num = 3643,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 41,
				},
				{
					Value = 1,
					Num = 3743,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 41,
				},
				{
					Value = 1,
					Num = 3743,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 8,
				},
				{
					Value = 1,
					Num = 4243,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 8,
				},
				{
					Value = 1,
					Num = 4243,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 11743,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 11743,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 145,
				},
				{
					Value = 320051,
					Num = 97,
				},
			},
		},
	},
	DemandID = 410556,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id557] =
{
	Id = 557,
	Name = "订购焚香1",
	Desc = "需要一些焚香",
	Value = 321403,
	Active = true,
	Weight = 21535,
	PreGoal = 
	{
		300832,
		300888,
	},
	CloseGoal = 
	{
		301228,
	},
	GoodsId = 5701403,
	Priority = 1403596,
	Num = 30,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 25974,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 220,
				},
				{
					Value = 1,
					Num = 3974,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 220,
				},
				{
					Value = 1,
					Num = 3974,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 44,
				},
				{
					Value = 1,
					Num = 3974,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 44,
				},
				{
					Value = 1,
					Num = 3974,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 8,
				},
				{
					Value = 1,
					Num = 5974,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 8,
				},
				{
					Value = 1,
					Num = 5974,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 13474,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 13474,
				},
			},
		},
	},
	DemandID = 410557,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id558] =
{
	Id = 558,
	Name = "订购焚香1",
	Desc = "需要一些焚香",
	Value = 321403,
	Active = true,
	Weight = 22715,
	PreGoal = 
	{
		300832,
		300904,
	},
	CloseGoal = 
	{
		301248,
	},
	GoodsId = 5701403,
	Priority = 1403597,
	Num = 34,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 29438,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 250,
				},
				{
					Value = 1,
					Num = 4438,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 250,
				},
				{
					Value = 1,
					Num = 4438,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 50,
				},
				{
					Value = 1,
					Num = 4438,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 50,
				},
				{
					Value = 1,
					Num = 4438,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 10,
				},
				{
					Value = 1,
					Num = 4438,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 10,
				},
				{
					Value = 1,
					Num = 4438,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 4438,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 4438,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 176,
				},
				{
					Value = 320051,
					Num = 118,
				},
			},
		},
	},
	DemandID = 410558,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id559] =
{
	Id = 559,
	Name = "订购焚香1",
	Desc = "需要一些焚香",
	Value = 321403,
	Active = true,
	Weight = 24190,
	PreGoal = 
	{
		300832,
		301228,
	},
	CloseGoal = 
	{
		301268,
	},
	GoodsId = 5701403,
	Priority = 1403598,
	Num = 36,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 31169,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 264,
				},
				{
					Value = 1,
					Num = 4769,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 264,
				},
				{
					Value = 1,
					Num = 4769,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 52,
				},
				{
					Value = 1,
					Num = 5169,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 52,
				},
				{
					Value = 1,
					Num = 5169,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 10,
				},
				{
					Value = 1,
					Num = 6169,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 10,
				},
				{
					Value = 1,
					Num = 6169,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 6169,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 6169,
				},
			},
		},
	},
	DemandID = 410559,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id560] =
{
	Id = 560,
	Name = "订购焚香1",
	Desc = "需要一些焚香",
	Value = 321403,
	Active = true,
	Weight = 25665,
	PreGoal = 
	{
		300832,
		301248,
	},
	CloseGoal = 
	{
		301292,
	},
	GoodsId = 5701403,
	Priority = 1403599,
	Num = 40,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 34633,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 294,
				},
				{
					Value = 1,
					Num = 5233,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 294,
				},
				{
					Value = 1,
					Num = 5233,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 58,
				},
				{
					Value = 1,
					Num = 5633,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 58,
				},
				{
					Value = 1,
					Num = 5633,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 11,
				},
				{
					Value = 1,
					Num = 7133,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 11,
				},
				{
					Value = 1,
					Num = 7133,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 9633,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 9633,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 207,
				},
				{
					Value = 320051,
					Num = 139,
				},
			},
		},
	},
	DemandID = 410560,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id561] =
{
	Id = 561,
	Name = "订购焚香1",
	Desc = "需要一些焚香",
	Value = 321403,
	Active = true,
	Weight = 27435,
	PreGoal = 
	{
		300832,
		301272,
	},
	CloseGoal = 
	{
		301318,
	},
	GoodsId = 5701403,
	Priority = 1403600,
	Num = 40,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 34633,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 294,
				},
				{
					Value = 1,
					Num = 5233,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 294,
				},
				{
					Value = 1,
					Num = 5233,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 58,
				},
				{
					Value = 1,
					Num = 5633,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 58,
				},
				{
					Value = 1,
					Num = 5633,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 11,
				},
				{
					Value = 1,
					Num = 7133,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 11,
				},
				{
					Value = 1,
					Num = 7133,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 9633,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 9633,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 207,
				},
				{
					Value = 320051,
					Num = 139,
				},
			},
		},
	},
	DemandID = 410561,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id562] =
{
	Id = 562,
	Name = "订购碎瓷片1",
	Desc = "需要一些碎瓷片",
	Value = 321404,
	Active = true,
	Weight = 18605,
	PreGoal = 
	{
		300840,
	},
	CloseGoal = 
	{
		300868,
	},
	GoodsId = 5801404,
	Priority = 1404611,
	Num = 22,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 24615,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 209,
				},
				{
					Value = 1,
					Num = 3715,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 209,
				},
				{
					Value = 1,
					Num = 3715,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 41,
				},
				{
					Value = 1,
					Num = 4115,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 41,
				},
				{
					Value = 1,
					Num = 4115,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 8,
				},
				{
					Value = 1,
					Num = 4615,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 8,
				},
				{
					Value = 1,
					Num = 4615,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 12115,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 12115,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 147,
				},
				{
					Value = 320051,
					Num = 99,
				},
			},
		},
	},
	DemandID = 410562,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id563] =
{
	Id = 563,
	Name = "订购碎瓷片1",
	Desc = "需要一些碎瓷片",
	Value = 321404,
	Active = true,
	Weight = 19215,
	PreGoal = 
	{
		300840,
		300848,
	},
	CloseGoal = 
	{
		300876,
	},
	GoodsId = 5801404,
	Priority = 1404612,
	Num = 22,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 24615,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 209,
				},
				{
					Value = 1,
					Num = 3715,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 209,
				},
				{
					Value = 1,
					Num = 3715,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 41,
				},
				{
					Value = 1,
					Num = 4115,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 41,
				},
				{
					Value = 1,
					Num = 4115,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 8,
				},
				{
					Value = 1,
					Num = 4615,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 8,
				},
				{
					Value = 1,
					Num = 4615,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 12115,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 12115,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 147,
				},
				{
					Value = 320051,
					Num = 99,
				},
			},
		},
	},
	DemandID = 410563,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id564] =
{
	Id = 564,
	Name = "订购碎瓷片1",
	Desc = "需要一些碎瓷片",
	Value = 321404,
	Active = true,
	Weight = 19825,
	PreGoal = 
	{
		300840,
		300856,
	},
	CloseGoal = 
	{
		300888,
	},
	GoodsId = 5801404,
	Priority = 1404613,
	Num = 24,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 26853,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 228,
				},
				{
					Value = 1,
					Num = 4053,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 228,
				},
				{
					Value = 1,
					Num = 4053,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 45,
				},
				{
					Value = 1,
					Num = 4353,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 45,
				},
				{
					Value = 1,
					Num = 4353,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 9,
				},
				{
					Value = 1,
					Num = 4353,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 9,
				},
				{
					Value = 1,
					Num = 4353,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 14353,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 14353,
				},
			},
		},
	},
	DemandID = 410564,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id565] =
{
	Id = 565,
	Name = "订购碎瓷片1",
	Desc = "需要一些碎瓷片",
	Value = 321404,
	Active = true,
	Weight = 20740,
	PreGoal = 
	{
		300840,
		300868,
	},
	CloseGoal = 
	{
		300900,
	},
	GoodsId = 5801404,
	Priority = 1404614,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 27972,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 237,
				},
				{
					Value = 1,
					Num = 4272,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 237,
				},
				{
					Value = 1,
					Num = 4272,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 47,
				},
				{
					Value = 1,
					Num = 4472,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 47,
				},
				{
					Value = 1,
					Num = 4472,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 9,
				},
				{
					Value = 1,
					Num = 5472,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 9,
				},
				{
					Value = 1,
					Num = 5472,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 15472,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 15472,
				},
			},
		},
	},
	DemandID = 410565,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id566] =
{
	Id = 566,
	Name = "订购碎瓷片1",
	Desc = "需要一些碎瓷片",
	Value = 321404,
	Active = true,
	Weight = 21655,
	PreGoal = 
	{
		300840,
		300880,
	},
	CloseGoal = 
	{
		301220,
	},
	GoodsId = 5801404,
	Priority = 1404615,
	Num = 26,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 29090,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 247,
				},
				{
					Value = 1,
					Num = 4390,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 247,
				},
				{
					Value = 1,
					Num = 4390,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 49,
				},
				{
					Value = 1,
					Num = 4590,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 49,
				},
				{
					Value = 1,
					Num = 4590,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 9,
				},
				{
					Value = 1,
					Num = 6590,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 9,
				},
				{
					Value = 1,
					Num = 6590,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 16590,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 16590,
				},
			},
		},
	},
	DemandID = 410566,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id567] =
{
	Id = 567,
	Name = "订购碎瓷片1",
	Desc = "需要一些碎瓷片",
	Value = 321404,
	Active = true,
	Weight = 22875,
	PreGoal = 
	{
		300840,
		300896,
	},
	CloseGoal = 
	{
		301236,
	},
	GoodsId = 5801404,
	Priority = 1404616,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 31328,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 266,
				},
				{
					Value = 1,
					Num = 4728,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 266,
				},
				{
					Value = 1,
					Num = 4728,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 53,
				},
				{
					Value = 1,
					Num = 4828,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 53,
				},
				{
					Value = 1,
					Num = 4828,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 10,
				},
				{
					Value = 1,
					Num = 6328,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 10,
				},
				{
					Value = 1,
					Num = 6328,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 6328,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 6328,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 187,
				},
				{
					Value = 320051,
					Num = 126,
				},
			},
		},
	},
	DemandID = 410567,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id568] =
{
	Id = 568,
	Name = "订购碎瓷片1",
	Desc = "需要一些碎瓷片",
	Value = 321404,
	Active = true,
	Weight = 24095,
	PreGoal = 
	{
		300840,
		301216,
	},
	CloseGoal = 
	{
		301256,
	},
	GoodsId = 5801404,
	Priority = 1404617,
	Num = 30,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 33566,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 285,
				},
				{
					Value = 1,
					Num = 5066,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 285,
				},
				{
					Value = 1,
					Num = 5066,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 57,
				},
				{
					Value = 1,
					Num = 5066,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 57,
				},
				{
					Value = 1,
					Num = 5066,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 11,
				},
				{
					Value = 1,
					Num = 6066,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 11,
				},
				{
					Value = 1,
					Num = 6066,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 8566,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 8566,
				},
			},
		},
	},
	DemandID = 410568,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id569] =
{
	Id = 569,
	Name = "订购碎瓷片1",
	Desc = "需要一些碎瓷片",
	Value = 321404,
	Active = true,
	Weight = 25620,
	PreGoal = 
	{
		300840,
		301236,
	},
	CloseGoal = 
	{
		301276,
	},
	GoodsId = 5801404,
	Priority = 1404618,
	Num = 33,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 36923,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 313,
				},
				{
					Value = 1,
					Num = 5623,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 313,
				},
				{
					Value = 1,
					Num = 5623,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 62,
				},
				{
					Value = 1,
					Num = 5923,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 62,
				},
				{
					Value = 1,
					Num = 5923,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 12,
				},
				{
					Value = 1,
					Num = 6923,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 12,
				},
				{
					Value = 1,
					Num = 6923,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 11923,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 11923,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 221,
				},
				{
					Value = 320051,
					Num = 148,
				},
			},
		},
	},
	DemandID = 410569,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id570] =
{
	Id = 570,
	Name = "订购碎瓷片1",
	Desc = "需要一些碎瓷片",
	Value = 321404,
	Active = true,
	Weight = 27145,
	PreGoal = 
	{
		300840,
		301256,
	},
	CloseGoal = 
	{
		301301,
	},
	GoodsId = 5801404,
	Priority = 1404619,
	Num = 36,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 40279,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 342,
				},
				{
					Value = 1,
					Num = 6079,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 342,
				},
				{
					Value = 1,
					Num = 6079,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 68,
				},
				{
					Value = 1,
					Num = 6279,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 68,
				},
				{
					Value = 1,
					Num = 6279,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 13,
				},
				{
					Value = 1,
					Num = 7779,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 13,
				},
				{
					Value = 1,
					Num = 7779,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 15279,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 15279,
				},
			},
		},
	},
	DemandID = 410570,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id571] =
{
	Id = 571,
	Name = "订购碎瓷片1",
	Desc = "需要一些碎瓷片",
	Value = 321404,
	Active = true,
	Weight = 28975,
	PreGoal = 
	{
		300840,
		301280,
	},
	CloseGoal = 
	{
		301327,
	},
	GoodsId = 5801404,
	Priority = 1404620,
	Num = 36,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 40279,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 342,
				},
				{
					Value = 1,
					Num = 6079,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 342,
				},
				{
					Value = 1,
					Num = 6079,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 68,
				},
				{
					Value = 1,
					Num = 6279,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 68,
				},
				{
					Value = 1,
					Num = 6279,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 13,
				},
				{
					Value = 1,
					Num = 7779,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 13,
				},
				{
					Value = 1,
					Num = 7779,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 15279,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 15279,
				},
			},
		},
	},
	DemandID = 410571,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id572] =
{
	Id = 572,
	Name = "订购绿蛋壳1",
	Desc = "需要一些绿蛋壳",
	Value = 321405,
	Active = true,
	Weight = 19220,
	PreGoal = 
	{
		300844,
	},
	CloseGoal = 
	{
		300872,
	},
	GoodsId = 5901405,
	Priority = 1405621,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 23677,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 223,
				},
				{
					Value = 1,
					Num = 1377,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 44,
				},
				{
					Value = 1,
					Num = 1677,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 8,
				},
				{
					Value = 1,
					Num = 3677,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 11177,
				},
			},
		},
	},
	DemandID = 410572,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id573] =
{
	Id = 573,
	Name = "订购绿蛋壳1",
	Desc = "需要一些绿蛋壳",
	Value = 321405,
	Active = true,
	Weight = 19840,
	PreGoal = 
	{
		300844,
		300852,
	},
	CloseGoal = 
	{
		300880,
	},
	GoodsId = 5901405,
	Priority = 1405622,
	Num = 26,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 24624,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 232,
				},
				{
					Value = 1,
					Num = 1424,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 46,
				},
				{
					Value = 1,
					Num = 1624,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 9,
				},
				{
					Value = 1,
					Num = 2124,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 12124,
				},
			},
		},
	},
	DemandID = 410573,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id574] =
{
	Id = 574,
	Name = "订购绿蛋壳1",
	Desc = "需要一些绿蛋壳",
	Value = 321405,
	Active = true,
	Weight = 20460,
	PreGoal = 
	{
		300844,
		300860,
	},
	CloseGoal = 
	{
		300892,
	},
	GoodsId = 5901405,
	Priority = 1405623,
	Num = 27,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 25571,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 241,
				},
				{
					Value = 1,
					Num = 1471,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 48,
				},
				{
					Value = 1,
					Num = 1571,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 9,
				},
				{
					Value = 1,
					Num = 3071,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 13071,
				},
			},
		},
	},
	DemandID = 410574,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id575] =
{
	Id = 575,
	Name = "订购绿蛋壳1",
	Desc = "需要一些绿蛋壳",
	Value = 321405,
	Active = true,
	Weight = 21390,
	PreGoal = 
	{
		300844,
		300872,
	},
	CloseGoal = 
	{
		300904,
	},
	GoodsId = 5901405,
	Priority = 1405624,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 26518,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 250,
				},
				{
					Value = 1,
					Num = 1518,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 50,
				},
				{
					Value = 1,
					Num = 1518,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 10,
				},
				{
					Value = 1,
					Num = 1518,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 1518,
				},
			},
		},
	},
	DemandID = 410575,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id576] =
{
	Id = 576,
	Name = "订购绿蛋壳1",
	Desc = "需要一些绿蛋壳",
	Value = 321405,
	Active = true,
	Weight = 22320,
	PreGoal = 
	{
		300844,
		300884,
	},
	CloseGoal = 
	{
		301224,
	},
	GoodsId = 5901405,
	Priority = 1405625,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 26518,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 250,
				},
				{
					Value = 1,
					Num = 1518,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 50,
				},
				{
					Value = 1,
					Num = 1518,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 10,
				},
				{
					Value = 1,
					Num = 1518,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 1518,
				},
			},
		},
	},
	DemandID = 410576,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id577] =
{
	Id = 577,
	Name = "订购绿蛋壳1",
	Desc = "需要一些绿蛋壳",
	Value = 321405,
	Active = true,
	Weight = 23560,
	PreGoal = 
	{
		300844,
		300900,
	},
	CloseGoal = 
	{
		301240,
	},
	GoodsId = 5901405,
	Priority = 1405626,
	Num = 32,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 30307,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 286,
				},
				{
					Value = 1,
					Num = 1707,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 57,
				},
				{
					Value = 1,
					Num = 1807,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 11,
				},
				{
					Value = 1,
					Num = 2807,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 5307,
				},
			},
		},
	},
	DemandID = 410577,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id578] =
{
	Id = 578,
	Name = "订购绿蛋壳1",
	Desc = "需要一些绿蛋壳",
	Value = 321405,
	Active = true,
	Weight = 24800,
	PreGoal = 
	{
		300844,
		301220,
	},
	CloseGoal = 
	{
		301260,
	},
	GoodsId = 5901405,
	Priority = 1405627,
	Num = 34,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 32201,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 304,
				},
				{
					Value = 1,
					Num = 1801,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 60,
				},
				{
					Value = 1,
					Num = 2201,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 12,
				},
				{
					Value = 1,
					Num = 2201,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 7201,
				},
			},
		},
	},
	DemandID = 410578,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id579] =
{
	Id = 579,
	Name = "订购绿蛋壳1",
	Desc = "需要一些绿蛋壳",
	Value = 321405,
	Active = true,
	Weight = 26350,
	PreGoal = 
	{
		300844,
		301240,
	},
	CloseGoal = 
	{
		301280,
	},
	GoodsId = 5901405,
	Priority = 1405628,
	Num = 38,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 35989,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 339,
				},
				{
					Value = 1,
					Num = 2089,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 67,
				},
				{
					Value = 1,
					Num = 2489,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 13,
				},
				{
					Value = 1,
					Num = 3489,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 10989,
				},
			},
		},
	},
	DemandID = 410579,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id580] =
{
	Id = 580,
	Name = "订购绿蛋壳1",
	Desc = "需要一些绿蛋壳",
	Value = 321405,
	Active = true,
	Weight = 27900,
	PreGoal = 
	{
		300844,
		301260,
	},
	CloseGoal = 
	{
		301306,
	},
	GoodsId = 5901405,
	Priority = 1405629,
	Num = 40,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 37884,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 357,
				},
				{
					Value = 1,
					Num = 2184,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 71,
				},
				{
					Value = 1,
					Num = 2384,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 14,
				},
				{
					Value = 1,
					Num = 2884,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 12884,
				},
			},
		},
	},
	DemandID = 410580,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id581] =
{
	Id = 581,
	Name = "订购绿蛋壳1",
	Desc = "需要一些绿蛋壳",
	Value = 321405,
	Active = true,
	Weight = 29760,
	PreGoal = 
	{
		300844,
		301284,
	},
	CloseGoal = 
	{
		301605,
	},
	GoodsId = 5901405,
	Priority = 1405630,
	Num = 40,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 37884,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 357,
				},
				{
					Value = 1,
					Num = 2184,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 71,
				},
				{
					Value = 1,
					Num = 2384,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 14,
				},
				{
					Value = 1,
					Num = 2884,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 12884,
				},
			},
		},
	},
	DemandID = 410581,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id582] =
{
	Id = 582,
	Name = "订购监控录像1",
	Desc = "需要一些监控录像",
	Value = 321406,
	Active = true,
	Weight = 20480,
	PreGoal = 
	{
		300852,
	},
	CloseGoal = 
	{
		300880,
	},
	GoodsId = 6001406,
	Priority = 1406641,
	Num = 21,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 26295,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 223,
				},
				{
					Value = 1,
					Num = 3995,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 223,
				},
				{
					Value = 1,
					Num = 3995,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 44,
				},
				{
					Value = 1,
					Num = 4295,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 44,
				},
				{
					Value = 1,
					Num = 4295,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 8,
				},
				{
					Value = 1,
					Num = 6295,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 8,
				},
				{
					Value = 1,
					Num = 6295,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 13795,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 13795,
				},
			},
		},
	},
	DemandID = 410582,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id583] =
{
	Id = 583,
	Name = "订购监控录像1",
	Desc = "需要一些监控录像",
	Value = 321406,
	Active = true,
	Weight = 21120,
	PreGoal = 
	{
		300852,
		300860,
	},
	CloseGoal = 
	{
		300888,
	},
	GoodsId = 6001406,
	Priority = 1406642,
	Num = 22,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 27547,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 234,
				},
				{
					Value = 1,
					Num = 4147,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 234,
				},
				{
					Value = 1,
					Num = 4147,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 46,
				},
				{
					Value = 1,
					Num = 4547,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 46,
				},
				{
					Value = 1,
					Num = 4547,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 9,
				},
				{
					Value = 1,
					Num = 5047,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 9,
				},
				{
					Value = 1,
					Num = 5047,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 15047,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 15047,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 165,
				},
				{
					Value = 320051,
					Num = 110,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 33,
				},
				{
					Value = 320052,
					Num = 22,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 6,
				},
				{
					Value = 320053,
					Num = 5,
				},
			},
		},
	},
	DemandID = 410583,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id584] =
{
	Id = 584,
	Name = "订购监控录像1",
	Desc = "需要一些监控录像",
	Value = 321406,
	Active = true,
	Weight = 21760,
	PreGoal = 
	{
		300852,
		300868,
	},
	CloseGoal = 
	{
		300900,
	},
	GoodsId = 6001406,
	Priority = 1406643,
	Num = 22,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 27547,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 234,
				},
				{
					Value = 1,
					Num = 4147,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 234,
				},
				{
					Value = 1,
					Num = 4147,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 46,
				},
				{
					Value = 1,
					Num = 4547,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 46,
				},
				{
					Value = 1,
					Num = 4547,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 9,
				},
				{
					Value = 1,
					Num = 5047,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 9,
				},
				{
					Value = 1,
					Num = 5047,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 15047,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 15047,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 165,
				},
				{
					Value = 320051,
					Num = 110,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 33,
				},
				{
					Value = 320052,
					Num = 22,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 6,
				},
				{
					Value = 320053,
					Num = 5,
				},
			},
		},
	},
	DemandID = 410584,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id585] =
{
	Id = 585,
	Name = "订购监控录像1",
	Desc = "需要一些监控录像",
	Value = 321406,
	Active = true,
	Weight = 22720,
	PreGoal = 
	{
		300852,
		300880,
	},
	CloseGoal = 
	{
		301216,
	},
	GoodsId = 6001406,
	Priority = 1406644,
	Num = 24,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 30051,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 255,
				},
				{
					Value = 1,
					Num = 4551,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 255,
				},
				{
					Value = 1,
					Num = 4551,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 51,
				},
				{
					Value = 1,
					Num = 4551,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 51,
				},
				{
					Value = 1,
					Num = 4551,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 10,
				},
				{
					Value = 1,
					Num = 5051,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 10,
				},
				{
					Value = 1,
					Num = 5051,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 5051,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 5051,
				},
			},
		},
	},
	DemandID = 410585,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id586] =
{
	Id = 586,
	Name = "订购监控录像1",
	Desc = "需要一些监控录像",
	Value = 321406,
	Active = true,
	Weight = 23680,
	PreGoal = 
	{
		300852,
		300892,
	},
	CloseGoal = 
	{
		301232,
	},
	GoodsId = 6001406,
	Priority = 1406645,
	Num = 26,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 32556,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 276,
				},
				{
					Value = 1,
					Num = 4956,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 276,
				},
				{
					Value = 1,
					Num = 4956,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 55,
				},
				{
					Value = 1,
					Num = 5056,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 55,
				},
				{
					Value = 1,
					Num = 5056,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 11,
				},
				{
					Value = 1,
					Num = 5056,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 11,
				},
				{
					Value = 1,
					Num = 5056,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 7556,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 7556,
				},
			},
		},
	},
	DemandID = 410586,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id587] =
{
	Id = 587,
	Name = "订购监控录像1",
	Desc = "需要一些监控录像",
	Value = 321406,
	Active = true,
	Weight = 24960,
	PreGoal = 
	{
		300852,
		301204,
	},
	CloseGoal = 
	{
		301248,
	},
	GoodsId = 6001406,
	Priority = 1406646,
	Num = 27,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 33808,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 287,
				},
				{
					Value = 1,
					Num = 5108,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 287,
				},
				{
					Value = 1,
					Num = 5108,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 57,
				},
				{
					Value = 1,
					Num = 5308,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 57,
				},
				{
					Value = 1,
					Num = 5308,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 11,
				},
				{
					Value = 1,
					Num = 6308,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 11,
				},
				{
					Value = 1,
					Num = 6308,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 8808,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 8808,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 202,
				},
				{
					Value = 320051,
					Num = 136,
				},
			},
		},
	},
	DemandID = 410587,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id588] =
{
	Id = 588,
	Name = "订购监控录像1",
	Desc = "需要一些监控录像",
	Value = 321406,
	Active = true,
	Weight = 26240,
	PreGoal = 
	{
		300852,
		301228,
	},
	CloseGoal = 
	{
		301268,
	},
	GoodsId = 6001406,
	Priority = 1406647,
	Num = 30,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 37564,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 319,
				},
				{
					Value = 1,
					Num = 5664,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 319,
				},
				{
					Value = 1,
					Num = 5664,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 63,
				},
				{
					Value = 1,
					Num = 6064,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 63,
				},
				{
					Value = 1,
					Num = 6064,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 12,
				},
				{
					Value = 1,
					Num = 7564,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 12,
				},
				{
					Value = 1,
					Num = 7564,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 12564,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 12564,
				},
			},
		},
	},
	DemandID = 410588,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id589] =
{
	Id = 589,
	Name = "订购监控录像1",
	Desc = "需要一些监控录像",
	Value = 321406,
	Active = true,
	Weight = 27840,
	PreGoal = 
	{
		300852,
		301248,
	},
	CloseGoal = 
	{
		301288,
	},
	GoodsId = 6001406,
	Priority = 1406648,
	Num = 33,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 41321,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 351,
				},
				{
					Value = 1,
					Num = 6221,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 351,
				},
				{
					Value = 1,
					Num = 6221,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 70,
				},
				{
					Value = 1,
					Num = 6321,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 70,
				},
				{
					Value = 1,
					Num = 6321,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 14,
				},
				{
					Value = 1,
					Num = 6321,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 14,
				},
				{
					Value = 1,
					Num = 6321,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 16321,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 16321,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 247,
				},
				{
					Value = 320051,
					Num = 166,
				},
			},
		},
	},
	DemandID = 410589,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id590] =
{
	Id = 590,
	Name = "订购监控录像1",
	Desc = "需要一些监控录像",
	Value = 321406,
	Active = true,
	Weight = 29440,
	PreGoal = 
	{
		300852,
		301268,
	},
	CloseGoal = 
	{
		301314,
	},
	GoodsId = 6001406,
	Priority = 1406649,
	Num = 33,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 41321,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 351,
				},
				{
					Value = 1,
					Num = 6221,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 351,
				},
				{
					Value = 1,
					Num = 6221,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 70,
				},
				{
					Value = 1,
					Num = 6321,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 70,
				},
				{
					Value = 1,
					Num = 6321,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 14,
				},
				{
					Value = 1,
					Num = 6321,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 14,
				},
				{
					Value = 1,
					Num = 6321,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 16321,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 16321,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 247,
				},
				{
					Value = 320051,
					Num = 166,
				},
			},
		},
	},
	DemandID = 410590,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id591] =
{
	Id = 591,
	Name = "订购监控录像1",
	Desc = "需要一些监控录像",
	Value = 321406,
	Active = true,
	Weight = 31360,
	PreGoal = 
	{
		300852,
		301292,
	},
	CloseGoal = 
	{
		301620,
	},
	GoodsId = 6001406,
	Priority = 1406650,
	Num = 33,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 41321,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 351,
				},
				{
					Value = 1,
					Num = 6221,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 351,
				},
				{
					Value = 1,
					Num = 6221,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 70,
				},
				{
					Value = 1,
					Num = 6321,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 70,
				},
				{
					Value = 1,
					Num = 6321,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 14,
				},
				{
					Value = 1,
					Num = 6321,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 14,
				},
				{
					Value = 1,
					Num = 6321,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 16321,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 16321,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 247,
				},
				{
					Value = 320051,
					Num = 166,
				},
			},
		},
	},
	DemandID = 410591,
	DemandGroupList = {
		420001,
		420002,
		420003,
		420005,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id592] =
{
	Id = 592,
	Name = "订购封条1",
	Desc = "需要一些封条",
	Value = 321407,
	Active = true,
	Weight = 21780,
	PreGoal = 
	{
		300860,
	},
	CloseGoal = 
	{
		300888,
	},
	GoodsId = 6101407,
	Priority = 1407661,
	Num = 25,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 25719,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 242,
				},
				{
					Value = 1,
					Num = 1519,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 242,
				},
				{
					Value = 1,
					Num = 1519,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 48,
				},
				{
					Value = 1,
					Num = 1719,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 48,
				},
				{
					Value = 1,
					Num = 1719,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 9,
				},
				{
					Value = 1,
					Num = 3219,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 9,
				},
				{
					Value = 1,
					Num = 3219,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 1,
				},
				{
					Value = 1,
					Num = 13219,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 1,
				},
				{
					Value = 1,
					Num = 13219,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 154,
				},
				{
					Value = 320051,
					Num = 103,
				},
			},
		},
	},
	DemandID = 410592,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id593] =
{
	Id = 593,
	Name = "订购封条1",
	Desc = "需要一些封条",
	Value = 321407,
	Active = true,
	Weight = 22440,
	PreGoal = 
	{
		300860,
		300868,
	},
	CloseGoal = 
	{
		300896,
	},
	GoodsId = 6101407,
	Priority = 1407662,
	Num = 26,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 26748,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 252,
				},
				{
					Value = 1,
					Num = 1548,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 252,
				},
				{
					Value = 1,
					Num = 1548,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 50,
				},
				{
					Value = 1,
					Num = 1748,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 50,
				},
				{
					Value = 1,
					Num = 1748,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 10,
				},
				{
					Value = 1,
					Num = 1748,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 10,
				},
				{
					Value = 1,
					Num = 1748,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 1748,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 1748,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 160,
				},
				{
					Value = 320051,
					Num = 107,
				},
			},
		},
	},
	DemandID = 410593,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id594] =
{
	Id = 594,
	Name = "订购封条1",
	Desc = "需要一些封条",
	Value = 321407,
	Active = true,
	Weight = 23100,
	PreGoal = 
	{
		300860,
		300876,
	},
	CloseGoal = 
	{
		301204,
	},
	GoodsId = 6101407,
	Priority = 1407663,
	Num = 27,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 27777,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 262,
				},
				{
					Value = 1,
					Num = 1577,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 262,
				},
				{
					Value = 1,
					Num = 1577,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 52,
				},
				{
					Value = 1,
					Num = 1777,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 52,
				},
				{
					Value = 1,
					Num = 1777,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 10,
				},
				{
					Value = 1,
					Num = 2777,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 10,
				},
				{
					Value = 1,
					Num = 2777,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 2777,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 2777,
				},
			},
		},
	},
	DemandID = 410594,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id595] =
{
	Id = 595,
	Name = "订购封条1",
	Desc = "需要一些封条",
	Value = 321407,
	Active = true,
	Weight = 24090,
	PreGoal = 
	{
		300860,
		300888,
	},
	CloseGoal = 
	{
		301224,
	},
	GoodsId = 6101407,
	Priority = 1407664,
	Num = 28,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 28806,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 272,
				},
				{
					Value = 1,
					Num = 1606,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 272,
				},
				{
					Value = 1,
					Num = 1606,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 54,
				},
				{
					Value = 1,
					Num = 1806,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 54,
				},
				{
					Value = 1,
					Num = 1806,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 10,
				},
				{
					Value = 1,
					Num = 3806,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 10,
				},
				{
					Value = 1,
					Num = 3806,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 3806,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 3806,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 172,
				},
				{
					Value = 320051,
					Num = 116,
				},
			},
		},
	},
	DemandID = 410595,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id596] =
{
	Id = 596,
	Name = "订购封条1",
	Desc = "需要一些封条",
	Value = 321407,
	Active = true,
	Weight = 25080,
	PreGoal = 
	{
		300860,
		300900,
	},
	CloseGoal = 
	{
		301240,
	},
	GoodsId = 6101407,
	Priority = 1407665,
	Num = 30,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 30863,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 291,
				},
				{
					Value = 1,
					Num = 1763,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 291,
				},
				{
					Value = 1,
					Num = 1763,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 58,
				},
				{
					Value = 1,
					Num = 1863,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 58,
				},
				{
					Value = 1,
					Num = 1863,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 11,
				},
				{
					Value = 1,
					Num = 3363,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 11,
				},
				{
					Value = 1,
					Num = 3363,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 5863,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 5863,
				},
			},
		},
	},
	DemandID = 410596,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id597] =
{
	Id = 597,
	Name = "订购封条1",
	Desc = "需要一些封条",
	Value = 321407,
	Active = true,
	Weight = 26400,
	PreGoal = 
	{
		300860,
		301220,
	},
	CloseGoal = 
	{
		301256,
	},
	GoodsId = 6101407,
	Priority = 1407666,
	Num = 32,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 32921,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 310,
				},
				{
					Value = 1,
					Num = 1921,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 310,
				},
				{
					Value = 1,
					Num = 1921,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 62,
				},
				{
					Value = 1,
					Num = 1921,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 62,
				},
				{
					Value = 1,
					Num = 1921,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 12,
				},
				{
					Value = 1,
					Num = 2921,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 12,
				},
				{
					Value = 1,
					Num = 2921,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 7921,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 7921,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 197,
				},
				{
					Value = 320051,
					Num = 132,
				},
			},
		},
	},
	DemandID = 410597,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id598] =
{
	Id = 598,
	Name = "订购封条1",
	Desc = "需要一些封条",
	Value = 321407,
	Active = true,
	Weight = 27720,
	PreGoal = 
	{
		300860,
		301236,
	},
	CloseGoal = 
	{
		301276,
	},
	GoodsId = 6101407,
	Priority = 1407667,
	Num = 35,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 36007,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 340,
				},
				{
					Value = 1,
					Num = 2007,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 340,
				},
				{
					Value = 1,
					Num = 2007,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 68,
				},
				{
					Value = 1,
					Num = 2007,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 68,
				},
				{
					Value = 1,
					Num = 2007,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 13,
				},
				{
					Value = 1,
					Num = 3507,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 13,
				},
				{
					Value = 1,
					Num = 3507,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 11007,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 11007,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 216,
				},
				{
					Value = 320051,
					Num = 144,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 43,
				},
				{
					Value = 320052,
					Num = 29,
				},
			},
		},
	},
	DemandID = 410598,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id599] =
{
	Id = 599,
	Name = "订购封条1",
	Desc = "需要一些封条",
	Value = 321407,
	Active = true,
	Weight = 29370,
	PreGoal = 
	{
		300860,
		301256,
	},
	CloseGoal = 
	{
		301297,
	},
	GoodsId = 6101407,
	Priority = 1407668,
	Num = 36,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 37036,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 349,
				},
				{
					Value = 1,
					Num = 2136,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 349,
				},
				{
					Value = 1,
					Num = 2136,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 69,
				},
				{
					Value = 1,
					Num = 2536,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 69,
				},
				{
					Value = 1,
					Num = 2536,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 13,
				},
				{
					Value = 1,
					Num = 4536,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 13,
				},
				{
					Value = 1,
					Num = 4536,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 12036,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 12036,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 222,
				},
				{
					Value = 320051,
					Num = 148,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 44,
				},
				{
					Value = 320052,
					Num = 30,
				},
			},
		},
	},
	DemandID = 410599,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
DemandConfig[DemandID.Id600] =
{
	Id = 600,
	Name = "订购封条1",
	Desc = "需要一些封条",
	Value = 321407,
	Active = true,
	Weight = 31020,
	PreGoal = 
	{
		300860,
		301276,
	},
	CloseGoal = 
	{
		301322,
	},
	GoodsId = 6101407,
	Priority = 1407669,
	Num = 36,
	RewardList = {
		{
			Weight = 100,
			DiamondCount = 0,
			Reward = {
				{
					Value = 1,
					Num = 37036,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 349,
				},
				{
					Value = 1,
					Num = 2136,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320051,
					Num = 349,
				},
				{
					Value = 1,
					Num = 2136,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 69,
				},
				{
					Value = 1,
					Num = 2536,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320052,
					Num = 69,
				},
				{
					Value = 1,
					Num = 2536,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320043,
					Num = 13,
				},
				{
					Value = 1,
					Num = 4536,
				},
			},
		},
		{
			Weight = 110,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320053,
					Num = 13,
				},
				{
					Value = 1,
					Num = 4536,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320044,
					Num = 2,
				},
				{
					Value = 1,
					Num = 12036,
				},
			},
		},
		{
			Weight = 90,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320054,
					Num = 2,
				},
				{
					Value = 1,
					Num = 12036,
				},
			},
		},
		{
			Weight = 150,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320041,
					Num = 222,
				},
				{
					Value = 320051,
					Num = 148,
				},
			},
		},
		{
			Weight = 130,
			DiamondCount = 0,
			Reward = {
				{
					Value = 320042,
					Num = 44,
				},
				{
					Value = 320052,
					Num = 30,
				},
			},
		},
	},
	DemandID = 410600,
	DemandGroupList = {
		420002,
		420004,
		420005,
		420006,
		420007,
		420009,
	},
}
