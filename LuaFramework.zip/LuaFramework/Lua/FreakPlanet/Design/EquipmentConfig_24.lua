
EquipmentConfig[EquipmentID.Id723] =
{
	Character = 223140,
	Rarity = 4,
	UpgradeId = 930034,
	LevelList = {
		{
			Level = 1,
			Info = 920754,
			Ability = {
				{
					Value = 200001,
					Num = 75,
				},
				{
					Value = 200007,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920754,
			Ability = {
				{
					Value = 200001,
					Num = 150,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920754,
			Ability = {
				{
					Value = 200001,
					Num = 225,
				},
				{
					Value = 200007,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920754,
			Ability = {
				{
					Value = 200001,
					Num = 300,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920754,
			Ability = {
				{
					Value = 200001,
					Num = 375,
				},
				{
					Value = 200007,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920754,
			Ability = {
				{
					Value = 200001,
					Num = 450,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920754,
			Ability = {
				{
					Value = 200001,
					Num = 525,
				},
				{
					Value = 200007,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920754,
			Ability = {
				{
					Value = 200001,
					Num = 600,
				},
				{
					Value = 200007,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
		{
			Level = 9,
			Info = 920754,
			Ability = {
				{
					Value = 200001,
					Num = 675,
				},
				{
					Value = 200007,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
		{
			Level = 10,
			Info = 920754,
			Ability = {
				{
					Value = 200001,
					Num = 750,
				},
				{
					Value = 200007,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id724] =
{
	Character = 223140,
	Rarity = 4,
	NeedChallenge = 145282,
	UpgradeId = 930015,
	LevelList = {
		{
			Level = 1,
			Info = 920755,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
			},
		},
		{
			Level = 2,
			Info = 920755,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
			},
		},
		{
			Level = 3,
			Info = 920755,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
		},
		{
			Level = 4,
			Info = 920755,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
			},
		},
		{
			Level = 5,
			Info = 920755,
			Ability = {
				{
					Value = 200002,
					Num = 396,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920755,
			Ability = {
				{
					Value = 200002,
					Num = 468,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920755,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920755,
			Ability = {
				{
					Value = 200002,
					Num = 612,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101907,
					Value = 100,
				},
			},
		},
		{
			Level = 9,
			Info = 920755,
			Ability = {
				{
					Value = 200002,
					Num = 684,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101907,
					Value = 100,
				},
			},
		},
		{
			Level = 10,
			Info = 920755,
			Ability = {
				{
					Value = 200002,
					Num = 756,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101907,
					Value = 100,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id725] =
{
	Character = 223141,
	Rarity = 5,
	UpgradeId = 930037,
	LevelList = {
		{
			Level = 1,
			Info = 920756,
			Ability = {
				{
					Value = 200001,
					Num = 84,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920756,
			Ability = {
				{
					Value = 200001,
					Num = 168,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920756,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920756,
			Ability = {
				{
					Value = 200001,
					Num = 336,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920756,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920756,
			Ability = {
				{
					Value = 200001,
					Num = 504,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920756,
			Ability = {
				{
					Value = 200001,
					Num = 588,
				},
				{
					Value = 200005,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920756,
			Ability = {
				{
					Value = 200001,
					Num = 672,
				},
				{
					Value = 200005,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 101763,
					Value = 48,
				},
			},
		},
		{
			Level = 9,
			Info = 920756,
			Ability = {
				{
					Value = 200001,
					Num = 756,
				},
				{
					Value = 200005,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 101763,
					Value = 48,
				},
			},
		},
		{
			Level = 10,
			Info = 920756,
			Ability = {
				{
					Value = 200001,
					Num = 840,
				},
				{
					Value = 200005,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 101763,
					Value = 48,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id726] =
{
	Character = 223141,
	Rarity = 5,
	UpgradeId = 930018,
	LevelList = {
		{
			Level = 1,
			Info = 920757,
			Ability = {
				{
					Value = 200002,
					Num = 39,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920757,
			Ability = {
				{
					Value = 200002,
					Num = 78,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920757,
			Ability = {
				{
					Value = 200002,
					Num = 117,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920757,
			Ability = {
				{
					Value = 200002,
					Num = 156,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920757,
			Ability = {
				{
					Value = 200002,
					Num = 195,
				},
				{
					Value = 200008,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920757,
			Ability = {
				{
					Value = 200002,
					Num = 234,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920757,
			Ability = {
				{
					Value = 200002,
					Num = 273,
				},
				{
					Value = 200008,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920757,
			Ability = {
				{
					Value = 200002,
					Num = 312,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 101706,
					Value = 72,
				},
			},
		},
		{
			Level = 9,
			Info = 920757,
			Ability = {
				{
					Value = 200002,
					Num = 351,
				},
				{
					Value = 200008,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 101706,
					Value = 72,
				},
			},
		},
		{
			Level = 10,
			Info = 920757,
			Ability = {
				{
					Value = 200002,
					Num = 390,
				},
				{
					Value = 200008,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 101706,
					Value = 72,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id727] =
{
	Character = 223141,
	Rarity = 5,
	NeedChallenge = 145283,
	UpgradeId = 930019,
	LevelList = {
		{
			Level = 1,
			Info = 920758,
			Ability = {
				{
					Value = 200002,
					Num = 78,
				},
			},
		},
		{
			Level = 2,
			Info = 920758,
			Ability = {
				{
					Value = 200002,
					Num = 130,
				},
			},
		},
		{
			Level = 3,
			Info = 920758,
			Ability = {
				{
					Value = 200002,
					Num = 182,
				},
			},
		},
		{
			Level = 4,
			Info = 920758,
			Ability = {
				{
					Value = 200002,
					Num = 234,
				},
			},
		},
		{
			Level = 5,
			Info = 920758,
			Ability = {
				{
					Value = 200002,
					Num = 286,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920758,
			Ability = {
				{
					Value = 200002,
					Num = 338,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920758,
			Ability = {
				{
					Value = 200002,
					Num = 390,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920758,
			Ability = {
				{
					Value = 200002,
					Num = 442,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101503,
					Value = -22,
				},
			},
		},
		{
			Level = 9,
			Info = 920758,
			Ability = {
				{
					Value = 200002,
					Num = 494,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101503,
					Value = -22,
				},
			},
		},
		{
			Level = 10,
			Info = 920758,
			Ability = {
				{
					Value = 200002,
					Num = 546,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101503,
					Value = -22,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id728] =
{
	Character = 223141,
	Rarity = 5,
	NeedChallenge = 145284,
	UpgradeId = 930020,
	LevelList = {
		{
			Level = 1,
			Info = 920759,
			Ability = {
				{
					Value = 200002,
					Num = 117,
				},
			},
		},
		{
			Level = 2,
			Info = 920759,
			Ability = {
				{
					Value = 200002,
					Num = 182,
				},
			},
		},
		{
			Level = 3,
			Info = 920759,
			Ability = {
				{
					Value = 200002,
					Num = 247,
				},
			},
		},
		{
			Level = 4,
			Info = 920759,
			Ability = {
				{
					Value = 200002,
					Num = 312,
				},
			},
		},
		{
			Level = 5,
			Info = 920759,
			Ability = {
				{
					Value = 200002,
					Num = 377,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920759,
			Ability = {
				{
					Value = 200002,
					Num = 442,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920759,
			Ability = {
				{
					Value = 200002,
					Num = 507,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920759,
			Ability = {
				{
					Value = 200002,
					Num = 572,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100668,
					Value = 3,
				},
			},
		},
		{
			Level = 9,
			Info = 920759,
			Ability = {
				{
					Value = 200002,
					Num = 637,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100668,
					Value = 3,
				},
			},
		},
		{
			Level = 10,
			Info = 920759,
			Ability = {
				{
					Value = 200002,
					Num = 702,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100668,
					Value = 3,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id729] =
{
	Character = 223142,
	Rarity = 5,
	UpgradeId = 930037,
	LevelList = {
		{
			Level = 1,
			Info = 920760,
			Ability = {
				{
					Value = 200001,
					Num = 84,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920760,
			Ability = {
				{
					Value = 200001,
					Num = 168,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920760,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920760,
			Ability = {
				{
					Value = 200001,
					Num = 336,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920760,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920760,
			Ability = {
				{
					Value = 200001,
					Num = 504,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920760,
			Ability = {
				{
					Value = 200001,
					Num = 588,
				},
				{
					Value = 200005,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920760,
			Ability = {
				{
					Value = 200001,
					Num = 672,
				},
				{
					Value = 200005,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920760,
			Ability = {
				{
					Value = 200001,
					Num = 756,
				},
				{
					Value = 200005,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920760,
			Ability = {
				{
					Value = 200001,
					Num = 840,
				},
				{
					Value = 200005,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id730] =
{
	Character = 223142,
	Rarity = 5,
	UpgradeId = 930018,
	LevelList = {
		{
			Level = 1,
			Info = 920761,
			Ability = {
				{
					Value = 200002,
					Num = 72,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920761,
			Ability = {
				{
					Value = 200002,
					Num = 144,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920761,
			Ability = {
				{
					Value = 200002,
					Num = 216,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920761,
			Ability = {
				{
					Value = 200002,
					Num = 288,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920761,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
				{
					Value = 200008,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920761,
			Ability = {
				{
					Value = 200002,
					Num = 432,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920761,
			Ability = {
				{
					Value = 200002,
					Num = 504,
				},
				{
					Value = 200008,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920761,
			Ability = {
				{
					Value = 200002,
					Num = 576,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920761,
			Ability = {
				{
					Value = 200002,
					Num = 648,
				},
				{
					Value = 200008,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920761,
			Ability = {
				{
					Value = 200002,
					Num = 720,
				},
				{
					Value = 200008,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id731] =
{
	Character = 223142,
	Rarity = 5,
	NeedChallenge = 145285,
	UpgradeId = 930039,
	LevelList = {
		{
			Level = 1,
			Info = 920762,
			Ability = {
				{
					Value = 200001,
					Num = 168,
				},
			},
		},
		{
			Level = 2,
			Info = 920762,
			Ability = {
				{
					Value = 200001,
					Num = 280,
				},
			},
		},
		{
			Level = 3,
			Info = 920762,
			Ability = {
				{
					Value = 200001,
					Num = 392,
				},
			},
		},
		{
			Level = 4,
			Info = 920762,
			Ability = {
				{
					Value = 200001,
					Num = 504,
				},
			},
		},
		{
			Level = 5,
			Info = 920762,
			Ability = {
				{
					Value = 200001,
					Num = 616,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920762,
			Ability = {
				{
					Value = 200001,
					Num = 728,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920762,
			Ability = {
				{
					Value = 200001,
					Num = 840,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920762,
			Ability = {
				{
					Value = 200001,
					Num = 952,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101759,
					Value = 48,
				},
			},
		},
		{
			Level = 9,
			Info = 920762,
			Ability = {
				{
					Value = 200001,
					Num = 1064,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101759,
					Value = 48,
				},
			},
		},
		{
			Level = 10,
			Info = 920762,
			Ability = {
				{
					Value = 200001,
					Num = 1176,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101759,
					Value = 48,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id732] =
{
	Character = 223142,
	Rarity = 5,
	NeedChallenge = 145286,
	UpgradeId = 930020,
	LevelList = {
		{
			Level = 1,
			Info = 920763,
			Ability = {
				{
					Value = 200002,
					Num = 216,
				},
			},
		},
		{
			Level = 2,
			Info = 920763,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
			},
		},
		{
			Level = 3,
			Info = 920763,
			Ability = {
				{
					Value = 200002,
					Num = 456,
				},
			},
		},
		{
			Level = 4,
			Info = 920763,
			Ability = {
				{
					Value = 200002,
					Num = 576,
				},
			},
		},
		{
			Level = 5,
			Info = 920763,
			Ability = {
				{
					Value = 200002,
					Num = 696,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920763,
			Ability = {
				{
					Value = 200002,
					Num = 816,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920763,
			Ability = {
				{
					Value = 200002,
					Num = 936,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920763,
			Ability = {
				{
					Value = 200002,
					Num = 1056,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100605,
					Value = 36,
				},
			},
		},
		{
			Level = 9,
			Info = 920763,
			Ability = {
				{
					Value = 200002,
					Num = 1176,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100605,
					Value = 36,
				},
			},
		},
		{
			Level = 10,
			Info = 920763,
			Ability = {
				{
					Value = 200002,
					Num = 1296,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100605,
					Value = 36,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id733] =
{
	Character = 223143,
	Rarity = 4,
	UpgradeId = 930033,
	LevelList = {
		{
			Level = 1,
			Info = 920764,
			Ability = {
				{
					Value = 200001,
					Num = 75,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920764,
			Ability = {
				{
					Value = 200001,
					Num = 150,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920764,
			Ability = {
				{
					Value = 200001,
					Num = 225,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920764,
			Ability = {
				{
					Value = 200001,
					Num = 300,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920764,
			Ability = {
				{
					Value = 200001,
					Num = 375,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920764,
			Ability = {
				{
					Value = 200001,
					Num = 450,
				},
				{
					Value = 200006,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920764,
			Ability = {
				{
					Value = 200001,
					Num = 525,
				},
				{
					Value = 200006,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920764,
			Ability = {
				{
					Value = 200001,
					Num = 600,
				},
				{
					Value = 200006,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920764,
			Ability = {
				{
					Value = 200001,
					Num = 675,
				},
				{
					Value = 200006,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920764,
			Ability = {
				{
					Value = 200001,
					Num = 750,
				},
				{
					Value = 200006,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id734] =
{
	Character = 223143,
	Rarity = 4,
	UpgradeId = 930014,
	LevelList = {
		{
			Level = 1,
			Info = 920765,
			Ability = {
				{
					Value = 200002,
					Num = 54,
				},
				{
					Value = 200007,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920765,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920765,
			Ability = {
				{
					Value = 200002,
					Num = 162,
				},
				{
					Value = 200007,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920765,
			Ability = {
				{
					Value = 200002,
					Num = 216,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920765,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
				{
					Value = 200007,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920765,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920765,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200007,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920765,
			Ability = {
				{
					Value = 200002,
					Num = 432,
				},
				{
					Value = 200007,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 101706,
					Value = 63,
				},
			},
		},
		{
			Level = 9,
			Info = 920765,
			Ability = {
				{
					Value = 200002,
					Num = 486,
				},
				{
					Value = 200007,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 101706,
					Value = 63,
				},
			},
		},
		{
			Level = 10,
			Info = 920765,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200007,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 101706,
					Value = 63,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id735] =
{
	Character = 223143,
	Rarity = 4,
	NeedChallenge = 145287,
	UpgradeId = 930035,
	LevelList = {
		{
			Level = 1,
			Info = 920766,
			Ability = {
				{
					Value = 200001,
					Num = 150,
				},
			},
		},
		{
			Level = 2,
			Info = 920766,
			Ability = {
				{
					Value = 200001,
					Num = 250,
				},
			},
		},
		{
			Level = 3,
			Info = 920766,
			Ability = {
				{
					Value = 200001,
					Num = 350,
				},
			},
		},
		{
			Level = 4,
			Info = 920766,
			Ability = {
				{
					Value = 200001,
					Num = 450,
				},
			},
		},
		{
			Level = 5,
			Info = 920766,
			Ability = {
				{
					Value = 200001,
					Num = 550,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920766,
			Ability = {
				{
					Value = 200001,
					Num = 650,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920766,
			Ability = {
				{
					Value = 200001,
					Num = 750,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920766,
			Ability = {
				{
					Value = 200001,
					Num = 850,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101909,
					Value = 10,
				},
			},
		},
		{
			Level = 9,
			Info = 920766,
			Ability = {
				{
					Value = 200001,
					Num = 950,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101909,
					Value = 10,
				},
			},
		},
		{
			Level = 10,
			Info = 920766,
			Ability = {
				{
					Value = 200001,
					Num = 1050,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101909,
					Value = 10,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id736] =
{
	Character = 223144,
	Rarity = 4,
	UpgradeId = 930033,
	LevelList = {
		{
			Level = 1,
			Info = 920767,
			Ability = {
				{
					Value = 200001,
					Num = 72,
				},
				{
					Value = 200007,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920767,
			Ability = {
				{
					Value = 200001,
					Num = 144,
				},
				{
					Value = 200007,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920767,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920767,
			Ability = {
				{
					Value = 200001,
					Num = 288,
				},
				{
					Value = 200007,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920767,
			Ability = {
				{
					Value = 200001,
					Num = 360,
				},
				{
					Value = 200007,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920767,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200007,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920767,
			Ability = {
				{
					Value = 200001,
					Num = 504,
				},
				{
					Value = 200007,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920767,
			Ability = {
				{
					Value = 200001,
					Num = 576,
				},
				{
					Value = 200007,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920767,
			Ability = {
				{
					Value = 200001,
					Num = 648,
				},
				{
					Value = 200007,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920767,
			Ability = {
				{
					Value = 200001,
					Num = 720,
				},
				{
					Value = 200007,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id737] =
{
	Character = 223144,
	Rarity = 4,
	UpgradeId = 930034,
	LevelList = {
		{
			Level = 1,
			Info = 920768,
			Ability = {
				{
					Value = 200001,
					Num = 72,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920768,
			Ability = {
				{
					Value = 200001,
					Num = 144,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920768,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920768,
			Ability = {
				{
					Value = 200001,
					Num = 288,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920768,
			Ability = {
				{
					Value = 200001,
					Num = 360,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920768,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920768,
			Ability = {
				{
					Value = 200001,
					Num = 504,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920768,
			Ability = {
				{
					Value = 200001,
					Num = 576,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 101763,
					Value = 48,
				},
			},
		},
		{
			Level = 9,
			Info = 920768,
			Ability = {
				{
					Value = 200001,
					Num = 648,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 101763,
					Value = 48,
				},
			},
		},
		{
			Level = 10,
			Info = 920768,
			Ability = {
				{
					Value = 200001,
					Num = 720,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 101763,
					Value = 48,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id738] =
{
	Character = 223144,
	Rarity = 4,
	NeedChallenge = 145288,
	UpgradeId = 930035,
	LevelList = {
		{
			Level = 1,
			Info = 920769,
			Ability = {
				{
					Value = 200001,
					Num = 144,
				},
			},
		},
		{
			Level = 2,
			Info = 920769,
			Ability = {
				{
					Value = 200001,
					Num = 240,
				},
			},
		},
		{
			Level = 3,
			Info = 920769,
			Ability = {
				{
					Value = 200001,
					Num = 336,
				},
			},
		},
		{
			Level = 4,
			Info = 920769,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
			},
		},
		{
			Level = 5,
			Info = 920769,
			Ability = {
				{
					Value = 200001,
					Num = 528,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920769,
			Ability = {
				{
					Value = 200001,
					Num = 624,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920769,
			Ability = {
				{
					Value = 200001,
					Num = 720,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920769,
			Ability = {
				{
					Value = 200001,
					Num = 816,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101910,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920769,
			Ability = {
				{
					Value = 200001,
					Num = 912,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101910,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920769,
			Ability = {
				{
					Value = 200001,
					Num = 1008,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101910,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id739] =
{
	Character = 223145,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920770,
			Ability = {
				{
					Value = 200001,
					Num = 60,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920770,
			Ability = {
				{
					Value = 200001,
					Num = 120,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920770,
			Ability = {
				{
					Value = 200001,
					Num = 180,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920770,
			Ability = {
				{
					Value = 200001,
					Num = 240,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920770,
			Ability = {
				{
					Value = 200001,
					Num = 300,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920770,
			Ability = {
				{
					Value = 200001,
					Num = 360,
				},
				{
					Value = 200006,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920770,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
				{
					Value = 200006,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920770,
			Ability = {
				{
					Value = 200001,
					Num = 480,
				},
				{
					Value = 200006,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920770,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200006,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920770,
			Ability = {
				{
					Value = 200001,
					Num = 600,
				},
				{
					Value = 200006,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id740] =
{
	Character = 223145,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920771,
			Ability = {
				{
					Value = 200001,
					Num = 60,
				},
				{
					Value = 200007,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920771,
			Ability = {
				{
					Value = 200001,
					Num = 120,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920771,
			Ability = {
				{
					Value = 200001,
					Num = 180,
				},
				{
					Value = 200007,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920771,
			Ability = {
				{
					Value = 200001,
					Num = 240,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920771,
			Ability = {
				{
					Value = 200001,
					Num = 300,
				},
				{
					Value = 200007,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920771,
			Ability = {
				{
					Value = 200001,
					Num = 360,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920771,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
				{
					Value = 200007,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920771,
			Ability = {
				{
					Value = 200001,
					Num = 480,
				},
				{
					Value = 200007,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 101759,
					Value = 48,
				},
			},
		},
		{
			Level = 9,
			Info = 920771,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200007,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 101759,
					Value = 48,
				},
			},
		},
		{
			Level = 10,
			Info = 920771,
			Ability = {
				{
					Value = 200001,
					Num = 600,
				},
				{
					Value = 200007,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 101759,
					Value = 48,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id741] =
{
	Character = 223145,
	Rarity = 3,
	NeedChallenge = 145289,
	UpgradeId = 930031,
	LevelList = {
		{
			Level = 1,
			Info = 920772,
			Ability = {
				{
					Value = 200001,
					Num = 120,
				},
			},
		},
		{
			Level = 2,
			Info = 920772,
			Ability = {
				{
					Value = 200001,
					Num = 200,
				},
			},
		},
		{
			Level = 3,
			Info = 920772,
			Ability = {
				{
					Value = 200001,
					Num = 280,
				},
			},
		},
		{
			Level = 4,
			Info = 920772,
			Ability = {
				{
					Value = 200001,
					Num = 360,
				},
			},
		},
		{
			Level = 5,
			Info = 920772,
			Ability = {
				{
					Value = 200001,
					Num = 440,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920772,
			Ability = {
				{
					Value = 200001,
					Num = 520,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920772,
			Ability = {
				{
					Value = 200001,
					Num = 600,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920772,
			Ability = {
				{
					Value = 200001,
					Num = 680,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101911,
					Value = 100,
				},
			},
		},
		{
			Level = 9,
			Info = 920772,
			Ability = {
				{
					Value = 200001,
					Num = 760,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101911,
					Value = 100,
				},
			},
		},
		{
			Level = 10,
			Info = 920772,
			Ability = {
				{
					Value = 200001,
					Num = 840,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101911,
					Value = 100,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id742] =
{
	Character = 223146,
	Rarity = 4,
	UpgradeId = 930033,
	LevelList = {
		{
			Level = 1,
			Info = 920774,
			Ability = {
				{
					Value = 200001,
					Num = 69,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920774,
			Ability = {
				{
					Value = 200001,
					Num = 138,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920774,
			Ability = {
				{
					Value = 200001,
					Num = 207,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920774,
			Ability = {
				{
					Value = 200001,
					Num = 276,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920774,
			Ability = {
				{
					Value = 200001,
					Num = 345,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920774,
			Ability = {
				{
					Value = 200001,
					Num = 414,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920774,
			Ability = {
				{
					Value = 200001,
					Num = 483,
				},
				{
					Value = 200005,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920774,
			Ability = {
				{
					Value = 200001,
					Num = 552,
				},
				{
					Value = 200005,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920774,
			Ability = {
				{
					Value = 200001,
					Num = 621,
				},
				{
					Value = 200005,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920774,
			Ability = {
				{
					Value = 200001,
					Num = 690,
				},
				{
					Value = 200005,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id743] =
{
	Character = 223146,
	Rarity = 4,
	UpgradeId = 930034,
	LevelList = {
		{
			Level = 1,
			Info = 920775,
			Ability = {
				{
					Value = 200001,
					Num = 69,
				},
				{
					Value = 200007,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920775,
			Ability = {
				{
					Value = 200001,
					Num = 138,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920775,
			Ability = {
				{
					Value = 200001,
					Num = 207,
				},
				{
					Value = 200007,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920775,
			Ability = {
				{
					Value = 200001,
					Num = 276,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920775,
			Ability = {
				{
					Value = 200001,
					Num = 345,
				},
				{
					Value = 200007,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920775,
			Ability = {
				{
					Value = 200001,
					Num = 414,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920775,
			Ability = {
				{
					Value = 200001,
					Num = 483,
				},
				{
					Value = 200007,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920775,
			Ability = {
				{
					Value = 200001,
					Num = 552,
				},
				{
					Value = 200007,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
		{
			Level = 9,
			Info = 920775,
			Ability = {
				{
					Value = 200001,
					Num = 621,
				},
				{
					Value = 200007,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
		{
			Level = 10,
			Info = 920775,
			Ability = {
				{
					Value = 200001,
					Num = 690,
				},
				{
					Value = 200007,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id744] =
{
	Character = 223146,
	Rarity = 4,
	NeedChallenge = 145290,
	UpgradeId = 930015,
	LevelList = {
		{
			Level = 1,
			Info = 920773,
			Ability = {
				{
					Value = 200002,
					Num = 78,
				},
			},
		},
		{
			Level = 2,
			Info = 920773,
			Ability = {
				{
					Value = 200002,
					Num = 130,
				},
			},
		},
		{
			Level = 3,
			Info = 920773,
			Ability = {
				{
					Value = 200002,
					Num = 182,
				},
			},
		},
		{
			Level = 4,
			Info = 920773,
			Ability = {
				{
					Value = 200002,
					Num = 234,
				},
			},
		},
		{
			Level = 5,
			Info = 920773,
			Ability = {
				{
					Value = 200002,
					Num = 286,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920773,
			Ability = {
				{
					Value = 200002,
					Num = 338,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920773,
			Ability = {
				{
					Value = 200002,
					Num = 390,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920773,
			Ability = {
				{
					Value = 200002,
					Num = 442,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101912,
					Value = 100,
				},
			},
		},
		{
			Level = 9,
			Info = 920773,
			Ability = {
				{
					Value = 200002,
					Num = 494,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101912,
					Value = 100,
				},
			},
		},
		{
			Level = 10,
			Info = 920773,
			Ability = {
				{
					Value = 200002,
					Num = 546,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101912,
					Value = 100,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id745] =
{
	Character = 223147,
	Rarity = 4,
	UpgradeId = 930033,
	LevelList = {
		{
			Level = 1,
			Info = 920776,
			Ability = {
				{
					Value = 200001,
					Num = 69,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920776,
			Ability = {
				{
					Value = 200001,
					Num = 138,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920776,
			Ability = {
				{
					Value = 200001,
					Num = 207,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920776,
			Ability = {
				{
					Value = 200001,
					Num = 276,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920776,
			Ability = {
				{
					Value = 200001,
					Num = 345,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920776,
			Ability = {
				{
					Value = 200001,
					Num = 414,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920776,
			Ability = {
				{
					Value = 200001,
					Num = 483,
				},
				{
					Value = 200008,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920776,
			Ability = {
				{
					Value = 200001,
					Num = 552,
				},
				{
					Value = 200008,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920776,
			Ability = {
				{
					Value = 200001,
					Num = 621,
				},
				{
					Value = 200008,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920776,
			Ability = {
				{
					Value = 200001,
					Num = 690,
				},
				{
					Value = 200008,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id746] =
{
	Character = 223147,
	Rarity = 4,
	UpgradeId = 930014,
	LevelList = {
		{
			Level = 1,
			Info = 920777,
			Ability = {
				{
					Value = 200002,
					Num = 57,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920777,
			Ability = {
				{
					Value = 200002,
					Num = 114,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920777,
			Ability = {
				{
					Value = 200002,
					Num = 171,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920777,
			Ability = {
				{
					Value = 200002,
					Num = 228,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920777,
			Ability = {
				{
					Value = 200002,
					Num = 285,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920777,
			Ability = {
				{
					Value = 200002,
					Num = 342,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920777,
			Ability = {
				{
					Value = 200002,
					Num = 399,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920777,
			Ability = {
				{
					Value = 200002,
					Num = 456,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 101745,
					Value = 60,
				},
			},
		},
		{
			Level = 9,
			Info = 920777,
			Ability = {
				{
					Value = 200002,
					Num = 513,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 101745,
					Value = 60,
				},
			},
		},
		{
			Level = 10,
			Info = 920777,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 101745,
					Value = 60,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id747] =
{
	Character = 223147,
	Rarity = 4,
	NeedChallenge = 145291,
	UpgradeId = 930015,
	LevelList = {
		{
			Level = 1,
			Info = 920778,
			Ability = {
				{
					Value = 200002,
					Num = 114,
				},
			},
		},
		{
			Level = 2,
			Info = 920778,
			Ability = {
				{
					Value = 200002,
					Num = 190,
				},
			},
		},
		{
			Level = 3,
			Info = 920778,
			Ability = {
				{
					Value = 200002,
					Num = 266,
				},
			},
		},
		{
			Level = 4,
			Info = 920778,
			Ability = {
				{
					Value = 200002,
					Num = 342,
				},
			},
		},
		{
			Level = 5,
			Info = 920778,
			Ability = {
				{
					Value = 200002,
					Num = 418,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920778,
			Ability = {
				{
					Value = 200002,
					Num = 494,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920778,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920778,
			Ability = {
				{
					Value = 200002,
					Num = 646,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 101731,
					Value = 900,
				},
			},
		},
		{
			Level = 9,
			Info = 920778,
			Ability = {
				{
					Value = 200002,
					Num = 722,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 101731,
					Value = 900,
				},
			},
		},
		{
			Level = 10,
			Info = 920778,
			Ability = {
				{
					Value = 200002,
					Num = 798,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 101731,
					Value = 900,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id748] =
{
	Character = 223148,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920779,
			Ability = {
				{
					Value = 200001,
					Num = 60,
				},
				{
					Value = 200006,
					Num = 15,
				},
			},
		},
		{
			Level = 2,
			Info = 920779,
			Ability = {
				{
					Value = 200001,
					Num = 120,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
		},
		{
			Level = 3,
			Info = 920779,
			Ability = {
				{
					Value = 200001,
					Num = 180,
				},
				{
					Value = 200006,
					Num = 45,
				},
			},
		},
		{
			Level = 4,
			Info = 920779,
			Ability = {
				{
					Value = 200001,
					Num = 240,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
		},
		{
			Level = 5,
			Info = 920779,
			Ability = {
				{
					Value = 200001,
					Num = 300,
				},
				{
					Value = 200006,
					Num = 75,
				},
			},
		},
		{
			Level = 6,
			Info = 920779,
			Ability = {
				{
					Value = 200001,
					Num = 360,
				},
				{
					Value = 200006,
					Num = 90,
				},
			},
		},
		{
			Level = 7,
			Info = 920779,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
				{
					Value = 200006,
					Num = 105,
				},
			},
		},
		{
			Level = 8,
			Info = 920779,
			Ability = {
				{
					Value = 200001,
					Num = 480,
				},
				{
					Value = 200006,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
		{
			Level = 9,
			Info = 920779,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200006,
					Num = 135,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
		{
			Level = 10,
			Info = 920779,
			Ability = {
				{
					Value = 200001,
					Num = 600,
				},
				{
					Value = 200006,
					Num = 150,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id749] =
{
	Character = 223148,
	Rarity = 3,
	UpgradeId = 930010,
	LevelList = {
		{
			Level = 1,
			Info = 920780,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200006,
					Num = 15,
				},
			},
		},
		{
			Level = 2,
			Info = 920780,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
		},
		{
			Level = 3,
			Info = 920780,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200006,
					Num = 45,
				},
			},
		},
		{
			Level = 4,
			Info = 920780,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
		},
		{
			Level = 5,
			Info = 920780,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200006,
					Num = 75,
				},
			},
		},
		{
			Level = 6,
			Info = 920780,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200006,
					Num = 90,
				},
			},
		},
		{
			Level = 7,
			Info = 920780,
			Ability = {
				{
					Value = 200002,
					Num = 294,
				},
				{
					Value = 200006,
					Num = 105,
				},
			},
		},
		{
			Level = 8,
			Info = 920780,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
				{
					Value = 200006,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 101908,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920780,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200006,
					Num = 135,
				},
			},
			SkillList = {
				{
					Id = 101908,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920780,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200006,
					Num = 150,
				},
			},
			SkillList = {
				{
					Id = 101908,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id750] =
{
	Character = 223148,
	Rarity = 3,
	NeedChallenge = 145292,
	UpgradeId = 930031,
	LevelList = {
		{
			Level = 1,
			Info = 920781,
			Ability = {
				{
					Value = 200001,
					Num = 120,
				},
			},
		},
		{
			Level = 2,
			Info = 920781,
			Ability = {
				{
					Value = 200001,
					Num = 200,
				},
			},
		},
		{
			Level = 3,
			Info = 920781,
			Ability = {
				{
					Value = 200001,
					Num = 280,
				},
			},
		},
		{
			Level = 4,
			Info = 920781,
			Ability = {
				{
					Value = 200001,
					Num = 360,
				},
			},
		},
		{
			Level = 5,
			Info = 920781,
			Ability = {
				{
					Value = 200001,
					Num = 440,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920781,
			Ability = {
				{
					Value = 200001,
					Num = 520,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920781,
			Ability = {
				{
					Value = 200001,
					Num = 600,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920781,
			Ability = {
				{
					Value = 200001,
					Num = 680,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
		{
			Level = 9,
			Info = 920781,
			Ability = {
				{
					Value = 200001,
					Num = 760,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
		{
			Level = 10,
			Info = 920781,
			Ability = {
				{
					Value = 200001,
					Num = 840,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -25,
				},
			},
		},
	},
}
