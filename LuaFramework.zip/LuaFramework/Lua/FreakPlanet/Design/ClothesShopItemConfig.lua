ClothesShopItemConfig ={};
ClothesShopItemID = 
{
	Id001 = 640001,
	Id002 = 640002,
	Id003 = 640003,
	Id004 = 640004,
	Id005 = 640005,
	Id006 = 640006,
	Id007 = 640007,
	Id008 = 640008,
	Id009 = 640009,
	Id010 = 640010,
	Id011 = 640011,
	Id012 = 640012,
	Id013 = 640013,
	Id014 = 640014,
	Id015 = 640015,
	Id016 = 640016,
	Id017 = 640017,
	Id018 = 640018,
	Id019 = 640019,
	Id020 = 640020,
	Id021 = 640021,
	Id022 = 640022,
	Id023 = 640023,
	Id024 = 640024,
	Id025 = 640025,
	Id026 = 640026,
	Id027 = 640027,
	Id028 = 640028,
	Id029 = 640029,
	Id030 = 640030,
	Id031 = 640031,
	Id032 = 640032,
	Id033 = 640033,
	Id034 = 640034,
	Id035 = 640035,
	Id036 = 640036,
	Id037 = 640037,
	Id038 = 640038,
	Id1001 = 641001,
	Id1002 = 641002,
	Id1003 = 641003,
	Id1004 = 641004,
	Id1005 = 641005,
	Id1006 = 641006,
	Id1007 = 641007,
}
ClothesShopItemConfig[ClothesShopItemID.Id001] =
{
	Id = 1,
	Name = "美术妹子",
	Type = 2,
	Icon = "Rpg_03_yuanhuameizi_cos20",
	Limit = 1,
	CostItem = {
		{
			Value = 2,
			Num = 1500,
		},
		{
			Value = 320104,
			Num = 6,
		},
	},
	ItemList = {
		{
			Value = 232270,
			Num = 1,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id002] =
{
	Id = 2,
	Name = "剑士",
	Type = 2,
	Icon = "Rpg_05_jianshi_cos30",
	Limit = 1,
	CostItem = {
		{
			Value = 2,
			Num = 1000,
		},
		{
			Value = 320103,
			Num = 4,
		},
	},
	ItemList = {
		{
			Value = 232271,
			Num = 1,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id003] =
{
	Id = 3,
	Name = "魔法师",
	Type = 2,
	Icon = "Rpg_06_mofashi_cos20",
	Limit = 1,
	CostItem = {
		{
			Value = 2,
			Num = 1500,
		},
		{
			Value = 320104,
			Num = 6,
		},
	},
	ItemList = {
		{
			Value = 232272,
			Num = 1,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id004] =
{
	Id = 4,
	Name = "刺客",
	Type = 2,
	Icon = "Rpg_08_cike_cos30",
	Limit = 1,
	CostItem = {
		{
			Value = 2,
			Num = 1500,
		},
		{
			Value = 320104,
			Num = 6,
		},
	},
	ItemList = {
		{
			Value = 232274,
			Num = 1,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id005] =
{
	Id = 5,
	Name = "猎人",
	Type = 2,
	Icon = "Rpg_16_lieren_cos20",
	Limit = 1,
	CostItem = {
		{
			Value = 2,
			Num = 1000,
		},
		{
			Value = 320103,
			Num = 4,
		},
	},
	ItemList = {
		{
			Value = 232276,
			Num = 1,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id006] =
{
	Id = 6,
	Name = "弓箭手",
	Type = 2,
	Icon = "Rpg_24_gongjianshou_cos20",
	Limit = 1,
	CostItem = {
		{
			Value = 2,
			Num = 1000,
		},
		{
			Value = 320103,
			Num = 4,
		},
	},
	ItemList = {
		{
			Value = 232277,
			Num = 1,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id007] =
{
	Id = 7,
	Name = "冰淇淋公主",
	Type = 2,
	Icon = "Fat_01_songbing_cos20",
	Limit = 1,
	CostItem = {
		{
			Value = 2,
			Num = 1500,
		},
		{
			Value = 320104,
			Num = 6,
		},
	},
	ItemList = {
		{
			Value = 232278,
			Num = 1,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id008] =
{
	Id = 8,
	Name = "蛋糕卷公主",
	Type = 2,
	Icon = "Fat_02_dangaojuan_cos20",
	Limit = 1,
	CostItem = {
		{
			Value = 2,
			Num = 1500,
		},
		{
			Value = 320104,
			Num = 6,
		},
	},
	ItemList = {
		{
			Value = 232279,
			Num = 1,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id009] =
{
	Id = 9,
	Name = "栗子蛋糕公主",
	Type = 2,
	Icon = "Fat_03_qiaokelidan_cos20",
	Limit = 1,
	CostItem = {
		{
			Value = 2,
			Num = 1500,
		},
		{
			Value = 320104,
			Num = 6,
		},
	},
	ItemList = {
		{
			Value = 232280,
			Num = 1,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id010] =
{
	Id = 10,
	Name = "棉花糖公主",
	Type = 2,
	Icon = "Fat_04_mianhuatang_cos20",
	Limit = 1,
	CostItem = {
		{
			Value = 2,
			Num = 1500,
		},
		{
			Value = 320104,
			Num = 6,
		},
	},
	ItemList = {
		{
			Value = 232281,
			Num = 1,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id011] =
{
	Id = 11,
	Name = "汽水王子",
	Type = 2,
	Icon = "Fat_08_xuebi_cos20",
	Limit = 1,
	CostItem = {
		{
			Value = 2,
			Num = 1500,
		},
		{
			Value = 320104,
			Num = 6,
		},
	},
	ItemList = {
		{
			Value = 232282,
			Num = 1,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id012] =
{
	Id = 12,
	Name = "啤酒王子",
	Type = 2,
	Icon = "Fat_09_pijiu_cos20",
	Limit = 1,
	CostItem = {
		{
			Value = 2,
			Num = 1500,
		},
		{
			Value = 320104,
			Num = 6,
		},
	},
	ItemList = {
		{
			Value = 232283,
			Num = 1,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id013] =
{
	Id = 13,
	Name = "奶茶王子",
	Type = 2,
	Icon = "Fat_10_naicha_cos20",
	Limit = 1,
	CostItem = {
		{
			Value = 2,
			Num = 1500,
		},
		{
			Value = 320104,
			Num = 6,
		},
	},
	ItemList = {
		{
			Value = 232284,
			Num = 1,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id014] =
{
	Id = 14,
	Name = "黑巧克力皇后",
	Type = 2,
	Icon = "Fat_11_tiantong_cos20",
	Limit = 1,
	CostItem = {
		{
			Value = 2,
			Num = 1500,
		},
		{
			Value = 320104,
			Num = 6,
		},
	},
	ItemList = {
		{
			Value = 232285,
			Num = 1,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id015] =
{
	Id = 15,
	Name = "保安",
	Type = 2,
	Icon = "MUS_27_baoan_cos20",
	Limit = 1,
	CostItem = {
		{
			Value = 2,
			Num = 1500,
		},
		{
			Value = 320104,
			Num = 6,
		},
	},
	ItemList = {
		{
			Value = 232286,
			Num = 1,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id016] =
{
	Id = 16,
	Name = "带珍珠的少女",
	Type = 2,
	Icon = "MUS_18_zhenzhuerhuan_cos20",
	Limit = 1,
	CostItem = {
		{
			Value = 2,
			Num = 1500,
		},
		{
			Value = 320104,
			Num = 6,
		},
	},
	ItemList = {
		{
			Value = 232287,
			Num = 1,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id017] =
{
	Id = 17,
	Name = "亚当",
	Type = 2,
	Icon = "MUS_22_yadang_cos20",
	Limit = 1,
	CostItem = {
		{
			Value = 2,
			Num = 1000,
		},
		{
			Value = 320103,
			Num = 4,
		},
	},
	ItemList = {
		{
			Value = 232288,
			Num = 1,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id018] =
{
	Id = 18,
	Name = "创造之神",
	Type = 2,
	Icon = "MUS_23_chuangzaozhishen_cos20",
	Limit = 1,
	CostItem = {
		{
			Value = 2,
			Num = 1000,
		},
		{
			Value = 320103,
			Num = 4,
		},
	},
	ItemList = {
		{
			Value = 232289,
			Num = 1,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id019] =
{
	Id = 19,
	Name = "弗里达",
	Type = 2,
	Icon = "MUS_29_folida_cos30",
	Limit = 1,
	CostItem = {
		{
			Value = 2,
			Num = 2000,
		},
		{
			Value = 320104,
			Num = 9,
		},
	},
	ItemList = {
		{
			Value = 232290,
			Num = 1,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id020] =
{
	Id = 20,
	Name = "侦探小姐",
	Type = 2,
	Icon = "MUS_17_zhentanxiaojie_cos20",
	Limit = 1,
	CostItem = {
		{
			Value = 2,
			Num = 1500,
		},
		{
			Value = 320104,
			Num = 6,
		},
	},
	ItemList = {
		{
			Value = 232292,
			Num = 1,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id021] =
{
	Id = 21,
	Name = "木乃伊",
	Type = 2,
	Icon = "MUS_05_munaiyi_cos20",
	Limit = 1,
	CostItem = {
		{
			Value = 2,
			Num = 1000,
		},
		{
			Value = 320103,
			Num = 4,
		},
	},
	ItemList = {
		{
			Value = 232293,
			Num = 1,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id022] =
{
	Id = 22,
	Name = "微笑女神",
	Type = 2,
	Icon = "MUS_21_mengnalisha_cos30",
	Limit = 1,
	CostItem = {
		{
			Value = 2,
			Num = 2000,
		},
		{
			Value = 320104,
			Num = 9,
		},
	},
	ItemList = {
		{
			Value = 232291,
			Num = 1,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id023] =
{
	Id = 23,
	Name = "法医",
	Type = 2,
	Icon = "Sus_04_fayi_cos20",
	Limit = 1,
	CostItem = {
		{
			Value = 2,
			Num = 1500,
		},
		{
			Value = 320104,
			Num = 6,
		},
	},
	ItemList = {
		{
			Value = 232294,
			Num = 1,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id024] =
{
	Id = 24,
	Name = "迈克罗夫特",
	Type = 2,
	Icon = "Sus_19_maikaofu_cos20",
	Limit = 1,
	CostItem = {
		{
			Value = 2,
			Num = 2000,
		},
		{
			Value = 320104,
			Num = 9,
		},
	},
	ItemList = {
		{
			Value = 232295,
			Num = 1,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id025] =
{
	Id = 25,
	Name = "豆豆警官",
	Type = 2,
	Icon = "Sus_05_jingcha_cos20",
	Limit = 1,
	CostItem = {
		{
			Value = 2,
			Num = 1500,
		},
		{
			Value = 320104,
			Num = 6,
		},
	},
	ItemList = {
		{
			Value = 232296,
			Num = 1,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id026] =
{
	Id = 26,
	Name = "小爱",
	Type = 2,
	Icon = "Sus_27_xiaoai_cos20",
	Limit = 1,
	CostItem = {
		{
			Value = 2,
			Num = 1000,
		},
		{
			Value = 320103,
			Num = 4,
		},
	},
	ItemList = {
		{
			Value = 232297,
			Num = 1,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id027] =
{
	Id = 27,
	Name = "小瞳",
	Type = 2,
	Icon = "Sus_26_xiaotong_cos20",
	Limit = 1,
	CostItem = {
		{
			Value = 2,
			Num = 1000,
		},
		{
			Value = 320103,
			Num = 4,
		},
	},
	ItemList = {
		{
			Value = 232298,
			Num = 1,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id028] =
{
	Id = 28,
	Name = "小泪",
	Type = 2,
	Icon = "Sus_25_xiaolei_cos20",
	Limit = 1,
	CostItem = {
		{
			Value = 2,
			Num = 1000,
		},
		{
			Value = 320103,
			Num = 4,
		},
	},
	ItemList = {
		{
			Value = 232299,
			Num = 1,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id029] =
{
	Id = 29,
	Name = "杰克瑞波",
	Type = 2,
	Icon = "Sus_29_kaitangshoujieke_cos20",
	Limit = 1,
	CostItem = {
		{
			Value = 2,
			Num = 2000,
		},
		{
			Value = 320104,
			Num = 9,
		},
	},
	ItemList = {
		{
			Value = 232300,
			Num = 1,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id030] =
{
	Id = 30,
	Name = "检察官",
	Type = 2,
	Icon = "Sus_16_yujianlianshi_cos20",
	Limit = 1,
	CostItem = {
		{
			Value = 2,
			Num = 1500,
		},
		{
			Value = 320104,
			Num = 6,
		},
	},
	ItemList = {
		{
			Value = 232301,
			Num = 1,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id031] =
{
	Id = 31,
	Name = "黄金纱纱",
	Type = 2,
	Icon = "Sea_01_huangshuimu_cos20",
	Limit = 1,
	CostItem = {
		{
			Value = 2,
			Num = 2000,
		},
		{
			Value = 320104,
			Num = 9,
		},
	},
	ItemList = {
		{
			Value = 232302,
			Num = 1,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id032] =
{
	Id = 32,
	Name = "灯塔丝丝",
	Type = 2,
	Icon = "Sea_04_dengtashuimu_cos20",
	Limit = 1,
	CostItem = {
		{
			Value = 2,
			Num = 2000,
		},
		{
			Value = 320104,
			Num = 9,
		},
	},
	ItemList = {
		{
			Value = 232303,
			Num = 1,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id033] =
{
	Id = 33,
	Name = "虎鲸京",
	Type = 2,
	Icon = "Sea_14_hujing_cos20",
	Limit = 1,
	CostItem = {
		{
			Value = 2,
			Num = 3000,
		},
		{
			Value = 320105,
			Num = 12,
		},
	},
	ItemList = {
		{
			Value = 232304,
			Num = 1,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id034] =
{
	Id = 34,
	Name = "珊瑚阿卡",
	Type = 2,
	Icon = "Sea_20_shanhu_cos20",
	Limit = 1,
	CostItem = {
		{
			Value = 2,
			Num = 3000,
		},
		{
			Value = 320105,
			Num = 12,
		},
	},
	ItemList = {
		{
			Value = 232305,
			Num = 1,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id035] =
{
	Id = 35,
	Name = "海豚凛",
	Type = 2,
	Icon = "Sea_17_haitun_cos20",
	Limit = 1,
	CostItem = {
		{
			Value = 2,
			Num = 1500,
		},
		{
			Value = 320104,
			Num = 6,
		},
	},
	ItemList = {
		{
			Value = 232306,
			Num = 1,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id036] =
{
	Id = 36,
	Name = "海豹彩",
	Type = 2,
	Icon = "Sea_30_haibao_cos20",
	Limit = 1,
	CostItem = {
		{
			Value = 2,
			Num = 2000,
		},
		{
			Value = 320104,
			Num = 9,
		},
	},
	ItemList = {
		{
			Value = 232307,
			Num = 1,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id037] =
{
	Id = 37,
	Name = "海蛇莱斯莉",
	Type = 2,
	Icon = "Sea_25_haishe_cos20",
	Limit = 1,
	CostItem = {
		{
			Value = 2,
			Num = 2000,
		},
		{
			Value = 320104,
			Num = 9,
		},
	},
	ItemList = {
		{
			Value = 232308,
			Num = 1,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id038] =
{
	Id = 38,
	Name = "琵琶映冬",
	Type = 2,
	Icon = "Sea_16_jingyu_cos20",
	Limit = 1,
	CostItem = {
		{
			Value = 2,
			Num = 2000,
		},
		{
			Value = 320104,
			Num = 9,
		},
	},
	ItemList = {
		{
			Value = 232309,
			Num = 1,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id1001] =
{
	Id = 1001,
	Name = "玉璧×200",
	Type = 1,
	Limit = 10,
	ItemList = {
		{
			Value = 2,
			Num = 200,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id1002] =
{
	Id = 1002,
	Name = "强化零件A×1",
	Type = 1,
	Limit = 20,
	ItemList = {
		{
			Value = 320044,
			Num = 1,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id1003] =
{
	Id = 1003,
	Name = "固化零件A×1",
	Type = 1,
	Limit = 20,
	ItemList = {
		{
			Value = 320054,
			Num = 1,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id1004] =
{
	Id = 1004,
	Name = "危险电池×1",
	Type = 1,
	Limit = 30,
	ItemList = {
		{
			Value = 320021,
			Num = 1,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id1005] =
{
	Id = 1005,
	Name = "低量电池×1",
	Type = 1,
	Limit = 20,
	ItemList = {
		{
			Value = 320001,
			Num = 1,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id1006] =
{
	Id = 1006,
	Name = "高能电池×1",
	Type = 1,
	Limit = 10,
	ItemList = {
		{
			Value = 320002,
			Num = 1,
			Weight = 100,
		},
	},
}
ClothesShopItemConfig[ClothesShopItemID.Id1007] =
{
	Id = 1007,
	Name = "超能电池×1",
	Type = 1,
	Limit = 5,
	ItemList = {
		{
			Value = 320003,
			Num = 1,
			Weight = 100,
		},
	},
}

