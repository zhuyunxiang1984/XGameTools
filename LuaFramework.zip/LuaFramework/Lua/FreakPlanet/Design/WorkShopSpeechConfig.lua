WorkShopSpeechConfig ={};
WorkShopSpeechID = 
{
	Id50001 = 50001,
	Id50002 = 50002,
	Id50003 = 50003,
	Id50004 = 50004,
	Id50005 = 50005,
	Id50006 = 50006,
	Id50007 = 50007,
	Id50008 = 50008,
	Id50009 = 50009,
	Id50010 = 50010,
	Id50011 = 50011,
	Id50012 = 50012,
	Id50013 = 50013,
	Id50014 = 50014,
	Id50015 = 50015,
	Id50016 = 50016,
	Id50017 = 50017,
	Id50018 = 50018,
	Id50019 = 50019,
	Id50020 = 50020,
	Id50021 = 50021,
	Id50022 = 50022,
	Id50023 = 50023,
	Id50024 = 50024,
	Id50025 = 50025,
	Id50026 = 50026,
	Id50027 = 50027,
	Id51001 = 51001,
	Id51002 = 51002,
	Id51003 = 51003,
	Id51004 = 51004,
	Id51005 = 51005,
	Id51006 = 51006,
	Id51007 = 51007,
	Id51008 = 51008,
	Id51009 = 51009,
	Id51010 = 51010,
	Id51011 = 51011,
	Id51012 = 51012,
	Id51013 = 51013,
	Id51014 = 51014,
	Id51015 = 51015,
	Id51016 = 51016,
	Id52001 = 52001,
	Id52002 = 52002,
	Id52003 = 52003,
	Id52004 = 52004,
	Id52005 = 52005,
	Id52006 = 52006,
	Id52007 = 52007,
	Id52008 = 52008,
	Id52009 = 52009,
	Id52010 = 52010,
	Id52011 = 52011,
	Id52012 = 52012,
	Id52013 = 52013,
	Id52014 = 52014,
	Id52015 = 52015,
	Id52016 = 52016,
	Id52017 = 52017,
	Id53001 = 53001,
	Id53002 = 53002,
	Id53003 = 53003,
	Id53004 = 53004,
	Id53005 = 53005,
	Id53006 = 53006,
	Id53007 = 53007,
	Id53008 = 53008,
	Id53009 = 53009,
	Id53010 = 53010,
	Id53011 = 53011,
	Id53012 = 53012,
	Id53013 = 53013,
	Id53014 = 53014,
	Id53015 = 53015,
	Id53016 = 53016,
	Id53017 = 53017,
	Id53018 = 53018,
}
WorkShopSpeechConfig[WorkShopSpeechID.Id50001] =
{
	Id = 50001,
	Position = 1,
	Text = "好累…",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id50002] =
{
	Id = 50002,
	Position = 1,
	Text = "好像没人看着，赶紧休息会",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id50003] =
{
	Id = 50003,
	Position = 1,
	Text = "一个人好无聊啊",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id50004] =
{
	Id = 50004,
	Position = 1,
	Text = "想吃零食了",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id50005] =
{
	Id = 50005,
	Position = 1,
	Text = "欢迎光临！",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id50006] =
{
	Id = 50006,
	Position = 1,
	Text = "来看看刚出锅的药水啊！",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id50007] =
{
	Id = 50007,
	Position = 1,
	Text = "带两瓶药水回去尝尝",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id50008] =
{
	Id = 50008,
	Position = 1,
	NextID = 50009,
	Text = "忘了对账了！",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id50009] =
{
	Id = 50009,
	Position = 1,
	NextID = 50010,
	Text = "账本呢？",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id50010] =
{
	Id = 50010,
	Position = 1,
	Text = "好像搞丢了…",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id50011] =
{
	Id = 50011,
	Position = 1,
	Text = "想上厕所了…",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id50012] =
{
	Id = 50012,
	Position = 1,
	NextID = 50013,
	Text = "今天一共来了3个客人",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id50013] =
{
	Id = 50013,
	Position = 1,
	Text = "不过看了看就都走了…",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id50014] =
{
	Id = 50014,
	Position = 1,
	NextID = 50015,
	Text = "好累…",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id50015] =
{
	Id = 50015,
	Position = 2,
	Text = "再坚持一会儿。",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id50016] =
{
	Id = 50016,
	Position = 1,
	NextID = 50017,
	Text = "努力工作，天天向上！",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id50017] =
{
	Id = 50017,
	Position = 2,
	Text = "老说些虚的…",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id50018] =
{
	Id = 50018,
	Position = 1,
	NextID = 50019,
	Text = "饭来了吗？",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id50019] =
{
	Id = 50019,
	Position = 2,
	Text = "还没有。",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id50020] =
{
	Id = 50020,
	Position = 1,
	NextID = 50021,
	Text = "最近好像店里生意还不错。",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id50021] =
{
	Id = 50021,
	Position = 2,
	NextID = 50022,
	Text = "大概是因为新研制的药水。",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id50022] =
{
	Id = 50022,
	Position = 1,
	NextID = 50023,
	Text = "诶！那个不是喝了会有幻觉吗！",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id50023] =
{
	Id = 50023,
	Position = 2,
	Text = "但是听说味道还不错。",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id50024] =
{
	Id = 50024,
	Position = 1,
	NextID = 50025,
	Text = "老板最近在干嘛？",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id50025] =
{
	Id = 50025,
	Position = 2,
	NextID = 50026,
	Text = "好像又在熬制新药了。",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id50026] =
{
	Id = 50026,
	Position = 1,
	NextID = 50027,
	Text = "闻起来不太舒服。",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id50027] =
{
	Id = 50027,
	Position = 2,
	Text = "反正又不要我们喝。",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id51001] =
{
	Id = 51001,
	Position = 1,
	Text = "好想休息…",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id51002] =
{
	Id = 51002,
	Position = 2,
	Text = "肚子饿了…",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id51003] =
{
	Id = 51003,
	Position = 1,
	NextID = 51004,
	Text = "道具店老是有股药水味道。",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id51004] =
{
	Id = 51004,
	Position = 2,
	Text = "再闻几天就习惯了。",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id51005] =
{
	Id = 51005,
	Position = 1,
	NextID = 51006,
	Text = "最近牛奶买一送一。",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id51006] =
{
	Id = 51006,
	Position = 2,
	NextID = 51007,
	Text = "我们要不要也买点？",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id51007] =
{
	Id = 51007,
	Position = 1,
	NextID = 51008,
	Text = "我感觉可以屯一些。",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id51008] =
{
	Id = 51008,
	Position = 2,
	NextID = 51009,
	Text = "好像保质期是今天结束。",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id51009] =
{
	Id = 51009,
	Position = 1,
	NextID = 51010,
	Text = "那快点喝。",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id51010] =
{
	Id = 51010,
	Position = 2,
	NextID = 51011,
	Text = "喝奶中…",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id51011] =
{
	Id = 51011,
	Position = 1,
	NextID = 51012,
	Text = "喝奶中…",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id51012] =
{
	Id = 51012,
	Position = 2,
	Text = "我感觉我快喝死了…",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id51013] =
{
	Id = 51013,
	Position = 1,
	NextID = 51014,
	Text = "好像新进了一种方便面。",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id51014] =
{
	Id = 51014,
	Position = 2,
	Text = "嗯，榴莲味的，卖得不错。",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id51015] =
{
	Id = 51015,
	Position = 1,
	NextID = 51016,
	Text = "我想明天请假。",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id51016] =
{
	Id = 51016,
	Position = 2,
	Text = "那我也请。",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id52001] =
{
	Id = 52001,
	Position = 1,
	Text = "怎么有这么多文件要处理？",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id52002] =
{
	Id = 52002,
	Position = 1,
	NextID = 52003,
	Text = "怎么有这么多文件要处理？",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id52003] =
{
	Id = 52003,
	Position = 2,
	Text = "我还剩3份。",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id52004] =
{
	Id = 52004,
	Position = 1,
	NextID = 52005,
	Text = "隔壁组抓了一个卖假导航器的。",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id52005] =
{
	Id = 52005,
	Position = 2,
	NextID = 52006,
	Text = "抓住了判多久？",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id52006] =
{
	Id = 52006,
	Position = 1,
	NextID = 52007,
	Text = "好像是根据错误导航的星际里程算的。",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id52007] =
{
	Id = 52007,
	Position = 2,
	NextID = 52008,
	Text = "噢。",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id52008] =
{
	Id = 52008,
	Position = 1,
	NextID = 52009,
	Text = "听说要判六千多年。",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id52009] =
{
	Id = 52009,
	Position = 2,
	NextID = 52010,
	Text = "怎么这么久？",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id52010] =
{
	Id = 52010,
	Position = 1,
	NextID = 52011,
	Text = "好像是虫洞序号是自己随便填的。",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id52011] =
{
	Id = 52011,
	Position = 2,
	NextID = 52012,
	Text = "噢…",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id52012] =
{
	Id = 52012,
	Position = 1,
	Text = "去年有人导航去上班，现在还没到公司。",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id52013] =
{
	Id = 52013,
	Position = 1,
	NextID = 52014,
	Text = "今天提审队列有32个犯人。",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id52014] =
{
	Id = 52014,
	Position = 2,
	NextID = 52015,
	Text = "我们要去吗？",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id52015] =
{
	Id = 52015,
	Position = 1,
	Text = "这个要专业的星际警探资格。",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id52016] =
{
	Id = 52016,
	Position = 1,
	NextID = 52017,
	Text = "好像有罪犯越狱了。",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id52017] =
{
	Id = 52017,
	Position = 2,
	Text = "这种事情我们就别管了。",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id53001] =
{
	Id = 53001,
	Position = 1,
	Text = "最近生意好冷清。",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id53002] =
{
	Id = 53002,
	Position = 1,
	NextID = 53003,
	Text = "最近生意好冷清。",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id53003] =
{
	Id = 53003,
	Position = 2,
	Text = "只要来一单生意就够开张半年了。",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id53004] =
{
	Id = 53004,
	Position = 1,
	NextID = 53005,
	Text = "老板让我们去发传单。",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id53005] =
{
	Id = 53005,
	Position = 2,
	NextID = 53006,
	Text = "我不想动…",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id53006] =
{
	Id = 53006,
	Position = 1,
	NextID = 53007,
	Text = "老板说不发出去3万张，今天就别吃饭了。",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id53007] =
{
	Id = 53007,
	Position = 2,
	NextID = 53008,
	Text = "大不了不吃了！",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id53008] =
{
	Id = 53008,
	Position = 1,
	NextID = 53009,
	Text = "听说今天的饭里有两个荤菜。",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id53009] =
{
	Id = 53009,
	Position = 2,
	NextID = 53010,
	Text = "…",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id53010] =
{
	Id = 53010,
	Position = 2,
	Text = "我觉得我能发出去6万张…",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id53011] =
{
	Id = 53011,
	Position = 1,
	NextID = 53012,
	Text = "好可爱的猫！",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id53012] =
{
	Id = 53012,
	Position = 2,
	NextID = 53013,
	Text = "是客人寄放在这里的。",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id53013] =
{
	Id = 53013,
	Position = 1,
	NextID = 53014,
	Text = "这种活不是应该找宠物店吗？",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id53014] =
{
	Id = 53014,
	Position = 2,
	Text = "听说宠物店收费比较贵…",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id53015] =
{
	Id = 53015,
	Position = 1,
	NextID = 53016,
	Text = "隔壁警察局好忙…",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id53016] =
{
	Id = 53016,
	Position = 2,
	NextID = 53017,
	Text = "好像又有大案子了。",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id53017] =
{
	Id = 53017,
	Position = 1,
	NextID = 53018,
	Text = "我们怎么这么清闲？",
}
WorkShopSpeechConfig[WorkShopSpeechID.Id53018] =
{
	Id = 53018,
	Position = 2,
	Text = "清闲好像也不是什么坏事…",
}

