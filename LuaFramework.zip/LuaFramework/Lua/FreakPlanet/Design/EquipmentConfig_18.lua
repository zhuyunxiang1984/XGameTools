
EquipmentConfig[EquipmentID.Id543] =
{
	Character = 220517,
	Rarity = 3,
	NeedChallenge = 145215,
	UpgradeId = 930031,
	LevelList = {
		{
			Level = 1,
			Info = 920466,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
			},
		},
		{
			Level = 2,
			Info = 920466,
			Ability = {
				{
					Value = 200001,
					Num = 190,
				},
			},
		},
		{
			Level = 3,
			Info = 920466,
			Ability = {
				{
					Value = 200001,
					Num = 266,
				},
			},
		},
		{
			Level = 4,
			Info = 920466,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
			},
		},
		{
			Level = 5,
			Info = 920466,
			Ability = {
				{
					Value = 200001,
					Num = 418,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920466,
			Ability = {
				{
					Value = 200001,
					Num = 494,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920466,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920466,
			Ability = {
				{
					Value = 200001,
					Num = 646,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
		},
		{
			Level = 9,
			Info = 920466,
			Ability = {
				{
					Value = 200001,
					Num = 722,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
		},
		{
			Level = 10,
			Info = 920466,
			Ability = {
				{
					Value = 200001,
					Num = 798,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id544] =
{
	Character = 220518,
	Rarity = 3,
	UpgradeId = 930009,
	LevelList = {
		{
			Level = 1,
			Info = 920467,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200007,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920467,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920467,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200007,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920467,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920467,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200007,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920467,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920467,
			Ability = {
				{
					Value = 200002,
					Num = 294,
				},
				{
					Value = 200007,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920467,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
				{
					Value = 200007,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920467,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200007,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920467,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200007,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id545] =
{
	Character = 220518,
	Rarity = 3,
	UpgradeId = 930010,
	LevelList = {
		{
			Level = 1,
			Info = 920468,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200008,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920468,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920468,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920468,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920468,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920468,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920468,
			Ability = {
				{
					Value = 200002,
					Num = 294,
				},
				{
					Value = 200008,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920468,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920468,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920468,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id546] =
{
	Character = 220518,
	Rarity = 3,
	NeedChallenge = 145216,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920469,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
			},
		},
		{
			Level = 2,
			Info = 920469,
			Ability = {
				{
					Value = 200002,
					Num = 140,
				},
			},
		},
		{
			Level = 3,
			Info = 920469,
			Ability = {
				{
					Value = 200002,
					Num = 196,
				},
			},
		},
		{
			Level = 4,
			Info = 920469,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
		},
		{
			Level = 5,
			Info = 920469,
			Ability = {
				{
					Value = 200002,
					Num = 308,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920469,
			Ability = {
				{
					Value = 200002,
					Num = 364,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920469,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920469,
			Ability = {
				{
					Value = 200002,
					Num = 476,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
		},
		{
			Level = 9,
			Info = 920469,
			Ability = {
				{
					Value = 200002,
					Num = 532,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
		},
		{
			Level = 10,
			Info = 920469,
			Ability = {
				{
					Value = 200002,
					Num = 588,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id547] =
{
	Character = 220519,
	Rarity = 3,
	UpgradeId = 930009,
	LevelList = {
		{
			Level = 1,
			Info = 920470,
			Ability = {
				{
					Value = 200002,
					Num = 45,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920470,
			Ability = {
				{
					Value = 200002,
					Num = 90,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920470,
			Ability = {
				{
					Value = 200002,
					Num = 135,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920470,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920470,
			Ability = {
				{
					Value = 200002,
					Num = 225,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920470,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920470,
			Ability = {
				{
					Value = 200002,
					Num = 315,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920470,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920470,
			Ability = {
				{
					Value = 200002,
					Num = 405,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920470,
			Ability = {
				{
					Value = 200002,
					Num = 450,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id548] =
{
	Character = 220519,
	Rarity = 3,
	UpgradeId = 930010,
	LevelList = {
		{
			Level = 1,
			Info = 920471,
			Ability = {
				{
					Value = 200002,
					Num = 45,
				},
				{
					Value = 200008,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920471,
			Ability = {
				{
					Value = 200002,
					Num = 90,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920471,
			Ability = {
				{
					Value = 200002,
					Num = 135,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920471,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920471,
			Ability = {
				{
					Value = 200002,
					Num = 225,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920471,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920471,
			Ability = {
				{
					Value = 200002,
					Num = 315,
				},
				{
					Value = 200008,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920471,
			Ability = {
				{
					Value = 200002,
					Num = 360,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920471,
			Ability = {
				{
					Value = 200002,
					Num = 405,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920471,
			Ability = {
				{
					Value = 200002,
					Num = 450,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id549] =
{
	Character = 220519,
	Rarity = 3,
	NeedChallenge = 145217,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920472,
			Ability = {
				{
					Value = 200002,
					Num = 90,
				},
			},
		},
		{
			Level = 2,
			Info = 920472,
			Ability = {
				{
					Value = 200002,
					Num = 150,
				},
			},
		},
		{
			Level = 3,
			Info = 920472,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
			},
		},
		{
			Level = 4,
			Info = 920472,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
			},
		},
		{
			Level = 5,
			Info = 920472,
			Ability = {
				{
					Value = 200002,
					Num = 330,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920472,
			Ability = {
				{
					Value = 200002,
					Num = 390,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920472,
			Ability = {
				{
					Value = 200002,
					Num = 450,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920472,
			Ability = {
				{
					Value = 200002,
					Num = 510,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
		},
		{
			Level = 9,
			Info = 920472,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
		},
		{
			Level = 10,
			Info = 920472,
			Ability = {
				{
					Value = 200002,
					Num = 630,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id550] =
{
	Character = 220520,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920473,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920473,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920473,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920473,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920473,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920473,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920473,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920473,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920473,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920473,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id551] =
{
	Character = 220520,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920474,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200008,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920474,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920474,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920474,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920474,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920474,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920474,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200008,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920474,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100565,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920474,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100565,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920474,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100565,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id552] =
{
	Character = 220520,
	Rarity = 3,
	NeedChallenge = 145218,
	UpgradeId = 930031,
	LevelList = {
		{
			Level = 1,
			Info = 920475,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
			},
		},
		{
			Level = 2,
			Info = 920475,
			Ability = {
				{
					Value = 200001,
					Num = 180,
				},
			},
		},
		{
			Level = 3,
			Info = 920475,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
			},
		},
		{
			Level = 4,
			Info = 920475,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
			},
		},
		{
			Level = 5,
			Info = 920475,
			Ability = {
				{
					Value = 200001,
					Num = 396,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920475,
			Ability = {
				{
					Value = 200001,
					Num = 468,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920475,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920475,
			Ability = {
				{
					Value = 200001,
					Num = 612,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
		},
		{
			Level = 9,
			Info = 920475,
			Ability = {
				{
					Value = 200001,
					Num = 684,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
		},
		{
			Level = 10,
			Info = 920475,
			Ability = {
				{
					Value = 200001,
					Num = 756,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id553] =
{
	Character = 220521,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920476,
			Ability = {
				{
					Value = 200001,
					Num = 60,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920476,
			Ability = {
				{
					Value = 200001,
					Num = 120,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920476,
			Ability = {
				{
					Value = 200001,
					Num = 180,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920476,
			Ability = {
				{
					Value = 200001,
					Num = 240,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920476,
			Ability = {
				{
					Value = 200001,
					Num = 300,
				},
				{
					Value = 200008,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920476,
			Ability = {
				{
					Value = 200001,
					Num = 360,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920476,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
				{
					Value = 200008,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920476,
			Ability = {
				{
					Value = 200001,
					Num = 480,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920476,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200008,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920476,
			Ability = {
				{
					Value = 200001,
					Num = 600,
				},
				{
					Value = 200008,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id554] =
{
	Character = 220521,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920477,
			Ability = {
				{
					Value = 200001,
					Num = 60,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920477,
			Ability = {
				{
					Value = 200001,
					Num = 120,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920477,
			Ability = {
				{
					Value = 200001,
					Num = 180,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920477,
			Ability = {
				{
					Value = 200001,
					Num = 240,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920477,
			Ability = {
				{
					Value = 200001,
					Num = 300,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920477,
			Ability = {
				{
					Value = 200001,
					Num = 360,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920477,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
				{
					Value = 200005,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920477,
			Ability = {
				{
					Value = 200001,
					Num = 480,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920477,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920477,
			Ability = {
				{
					Value = 200001,
					Num = 600,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id555] =
{
	Character = 220521,
	Rarity = 3,
	NeedChallenge = 145219,
	UpgradeId = 930031,
	LevelList = {
		{
			Level = 1,
			Info = 920478,
			Ability = {
				{
					Value = 200001,
					Num = 120,
				},
			},
		},
		{
			Level = 2,
			Info = 920478,
			Ability = {
				{
					Value = 200001,
					Num = 200,
				},
			},
		},
		{
			Level = 3,
			Info = 920478,
			Ability = {
				{
					Value = 200001,
					Num = 280,
				},
			},
		},
		{
			Level = 4,
			Info = 920478,
			Ability = {
				{
					Value = 200001,
					Num = 360,
				},
			},
		},
		{
			Level = 5,
			Info = 920478,
			Ability = {
				{
					Value = 200001,
					Num = 440,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920478,
			Ability = {
				{
					Value = 200001,
					Num = 520,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920478,
			Ability = {
				{
					Value = 200001,
					Num = 600,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920478,
			Ability = {
				{
					Value = 200001,
					Num = 680,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
		},
		{
			Level = 9,
			Info = 920478,
			Ability = {
				{
					Value = 200001,
					Num = 760,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
		},
		{
			Level = 10,
			Info = 920478,
			Ability = {
				{
					Value = 200001,
					Num = 840,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id556] =
{
	Character = 220522,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920479,
			Ability = {
				{
					Value = 200001,
					Num = 57,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920479,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920479,
			Ability = {
				{
					Value = 200001,
					Num = 171,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920479,
			Ability = {
				{
					Value = 200001,
					Num = 228,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920479,
			Ability = {
				{
					Value = 200001,
					Num = 285,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920479,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920479,
			Ability = {
				{
					Value = 200001,
					Num = 399,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920479,
			Ability = {
				{
					Value = 200001,
					Num = 456,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920479,
			Ability = {
				{
					Value = 200001,
					Num = 513,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920479,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id557] =
{
	Character = 220522,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920480,
			Ability = {
				{
					Value = 200001,
					Num = 57,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920480,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920480,
			Ability = {
				{
					Value = 200001,
					Num = 171,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920480,
			Ability = {
				{
					Value = 200001,
					Num = 228,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920480,
			Ability = {
				{
					Value = 200001,
					Num = 285,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920480,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920480,
			Ability = {
				{
					Value = 200001,
					Num = 399,
				},
				{
					Value = 200006,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920480,
			Ability = {
				{
					Value = 200001,
					Num = 456,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920480,
			Ability = {
				{
					Value = 200001,
					Num = 513,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920480,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id558] =
{
	Character = 220522,
	Rarity = 3,
	NeedChallenge = 145220,
	UpgradeId = 930031,
	LevelList = {
		{
			Level = 1,
			Info = 920481,
			Ability = {
				{
					Value = 200001,
					Num = 114,
				},
			},
		},
		{
			Level = 2,
			Info = 920481,
			Ability = {
				{
					Value = 200001,
					Num = 190,
				},
			},
		},
		{
			Level = 3,
			Info = 920481,
			Ability = {
				{
					Value = 200001,
					Num = 266,
				},
			},
		},
		{
			Level = 4,
			Info = 920481,
			Ability = {
				{
					Value = 200001,
					Num = 342,
				},
			},
		},
		{
			Level = 5,
			Info = 920481,
			Ability = {
				{
					Value = 200001,
					Num = 418,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920481,
			Ability = {
				{
					Value = 200001,
					Num = 494,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920481,
			Ability = {
				{
					Value = 200001,
					Num = 570,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920481,
			Ability = {
				{
					Value = 200001,
					Num = 646,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
		},
		{
			Level = 9,
			Info = 920481,
			Ability = {
				{
					Value = 200001,
					Num = 722,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
		},
		{
			Level = 10,
			Info = 920481,
			Ability = {
				{
					Value = 200001,
					Num = 798,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id559] =
{
	Character = 220523,
	Rarity = 4,
	UpgradeId = 930013,
	LevelList = {
		{
			Level = 1,
			Info = 920482,
			Ability = {
				{
					Value = 200002,
					Num = 54,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920482,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920482,
			Ability = {
				{
					Value = 200002,
					Num = 162,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920482,
			Ability = {
				{
					Value = 200002,
					Num = 216,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920482,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920482,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920482,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200008,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920482,
			Ability = {
				{
					Value = 200002,
					Num = 432,
				},
				{
					Value = 200008,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920482,
			Ability = {
				{
					Value = 200002,
					Num = 486,
				},
				{
					Value = 200008,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920482,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200008,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id560] =
{
	Character = 220523,
	Rarity = 4,
	UpgradeId = 930014,
	LevelList = {
		{
			Level = 1,
			Info = 920483,
			Ability = {
				{
					Value = 200002,
					Num = 54,
				},
				{
					Value = 200006,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920483,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920483,
			Ability = {
				{
					Value = 200002,
					Num = 162,
				},
				{
					Value = 200006,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920483,
			Ability = {
				{
					Value = 200002,
					Num = 216,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920483,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
				{
					Value = 200006,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920483,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920483,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200006,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920483,
			Ability = {
				{
					Value = 200002,
					Num = 432,
				},
				{
					Value = 200006,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920483,
			Ability = {
				{
					Value = 200002,
					Num = 486,
				},
				{
					Value = 200006,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920483,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200006,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100553,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id561] =
{
	Character = 220523,
	Rarity = 4,
	NeedChallenge = 145221,
	UpgradeId = 930015,
	LevelList = {
		{
			Level = 1,
			Info = 920484,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
			},
		},
		{
			Level = 2,
			Info = 920484,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
			},
		},
		{
			Level = 3,
			Info = 920484,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
		},
		{
			Level = 4,
			Info = 920484,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
			},
		},
		{
			Level = 5,
			Info = 920484,
			Ability = {
				{
					Value = 200002,
					Num = 396,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920484,
			Ability = {
				{
					Value = 200002,
					Num = 468,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920484,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920484,
			Ability = {
				{
					Value = 200002,
					Num = 612,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
		},
		{
			Level = 9,
			Info = 920484,
			Ability = {
				{
					Value = 200002,
					Num = 684,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
		},
		{
			Level = 10,
			Info = 920484,
			Ability = {
				{
					Value = 200002,
					Num = 756,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id562] =
{
	Character = 220524,
	Rarity = 4,
	UpgradeId = 930013,
	LevelList = {
		{
			Level = 1,
			Info = 920485,
			Ability = {
				{
					Value = 200002,
					Num = 54,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920485,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920485,
			Ability = {
				{
					Value = 200002,
					Num = 162,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920485,
			Ability = {
				{
					Value = 200002,
					Num = 216,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920485,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920485,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920485,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200008,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920485,
			Ability = {
				{
					Value = 200002,
					Num = 432,
				},
				{
					Value = 200008,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100552,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920485,
			Ability = {
				{
					Value = 200002,
					Num = 486,
				},
				{
					Value = 200008,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100552,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920485,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200008,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100552,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id563] =
{
	Character = 220524,
	Rarity = 4,
	UpgradeId = 930014,
	LevelList = {
		{
			Level = 1,
			Info = 920486,
			Ability = {
				{
					Value = 200002,
					Num = 54,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920486,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920486,
			Ability = {
				{
					Value = 200002,
					Num = 162,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920486,
			Ability = {
				{
					Value = 200002,
					Num = 216,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920486,
			Ability = {
				{
					Value = 200002,
					Num = 270,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920486,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920486,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920486,
			Ability = {
				{
					Value = 200002,
					Num = 432,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100552,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920486,
			Ability = {
				{
					Value = 200002,
					Num = 486,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100552,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920486,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100552,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id564] =
{
	Character = 220524,
	Rarity = 4,
	NeedChallenge = 145222,
	UpgradeId = 930015,
	LevelList = {
		{
			Level = 1,
			Info = 920487,
			Ability = {
				{
					Value = 200002,
					Num = 108,
				},
			},
		},
		{
			Level = 2,
			Info = 920487,
			Ability = {
				{
					Value = 200002,
					Num = 180,
				},
			},
		},
		{
			Level = 3,
			Info = 920487,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
		},
		{
			Level = 4,
			Info = 920487,
			Ability = {
				{
					Value = 200002,
					Num = 324,
				},
			},
		},
		{
			Level = 5,
			Info = 920487,
			Ability = {
				{
					Value = 200002,
					Num = 396,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920487,
			Ability = {
				{
					Value = 200002,
					Num = 468,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920487,
			Ability = {
				{
					Value = 200002,
					Num = 540,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920487,
			Ability = {
				{
					Value = 200002,
					Num = 612,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
		},
		{
			Level = 9,
			Info = 920487,
			Ability = {
				{
					Value = 200002,
					Num = 684,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
		},
		{
			Level = 10,
			Info = 920487,
			Ability = {
				{
					Value = 200002,
					Num = 756,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id565] =
{
	Character = 220525,
	Rarity = 4,
	UpgradeId = 930033,
	LevelList = {
		{
			Level = 1,
			Info = 920488,
			Ability = {
				{
					Value = 200001,
					Num = 69,
				},
				{
					Value = 200008,
					Num = 21,
				},
			},
		},
		{
			Level = 2,
			Info = 920488,
			Ability = {
				{
					Value = 200001,
					Num = 138,
				},
				{
					Value = 200008,
					Num = 42,
				},
			},
		},
		{
			Level = 3,
			Info = 920488,
			Ability = {
				{
					Value = 200001,
					Num = 207,
				},
				{
					Value = 200008,
					Num = 63,
				},
			},
		},
		{
			Level = 4,
			Info = 920488,
			Ability = {
				{
					Value = 200001,
					Num = 276,
				},
				{
					Value = 200008,
					Num = 84,
				},
			},
		},
		{
			Level = 5,
			Info = 920488,
			Ability = {
				{
					Value = 200001,
					Num = 345,
				},
				{
					Value = 200008,
					Num = 105,
				},
			},
		},
		{
			Level = 6,
			Info = 920488,
			Ability = {
				{
					Value = 200001,
					Num = 414,
				},
				{
					Value = 200008,
					Num = 126,
				},
			},
		},
		{
			Level = 7,
			Info = 920488,
			Ability = {
				{
					Value = 200001,
					Num = 483,
				},
				{
					Value = 200008,
					Num = 147,
				},
			},
		},
		{
			Level = 8,
			Info = 920488,
			Ability = {
				{
					Value = 200001,
					Num = 552,
				},
				{
					Value = 200008,
					Num = 168,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920488,
			Ability = {
				{
					Value = 200001,
					Num = 621,
				},
				{
					Value = 200008,
					Num = 189,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920488,
			Ability = {
				{
					Value = 200001,
					Num = 690,
				},
				{
					Value = 200008,
					Num = 210,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id566] =
{
	Character = 220525,
	Rarity = 4,
	UpgradeId = 930034,
	LevelList = {
		{
			Level = 1,
			Info = 920489,
			Ability = {
				{
					Value = 200001,
					Num = 69,
				},
				{
					Value = 200008,
					Num = 21,
				},
			},
		},
		{
			Level = 2,
			Info = 920489,
			Ability = {
				{
					Value = 200001,
					Num = 138,
				},
				{
					Value = 200008,
					Num = 42,
				},
			},
		},
		{
			Level = 3,
			Info = 920489,
			Ability = {
				{
					Value = 200001,
					Num = 207,
				},
				{
					Value = 200008,
					Num = 63,
				},
			},
		},
		{
			Level = 4,
			Info = 920489,
			Ability = {
				{
					Value = 200001,
					Num = 276,
				},
				{
					Value = 200008,
					Num = 84,
				},
			},
		},
		{
			Level = 5,
			Info = 920489,
			Ability = {
				{
					Value = 200001,
					Num = 345,
				},
				{
					Value = 200008,
					Num = 105,
				},
			},
		},
		{
			Level = 6,
			Info = 920489,
			Ability = {
				{
					Value = 200001,
					Num = 414,
				},
				{
					Value = 200008,
					Num = 126,
				},
			},
		},
		{
			Level = 7,
			Info = 920489,
			Ability = {
				{
					Value = 200001,
					Num = 483,
				},
				{
					Value = 200008,
					Num = 147,
				},
			},
		},
		{
			Level = 8,
			Info = 920489,
			Ability = {
				{
					Value = 200001,
					Num = 552,
				},
				{
					Value = 200008,
					Num = 168,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920489,
			Ability = {
				{
					Value = 200001,
					Num = 621,
				},
				{
					Value = 200008,
					Num = 189,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920489,
			Ability = {
				{
					Value = 200001,
					Num = 690,
				},
				{
					Value = 200008,
					Num = 210,
				},
			},
			SkillList = {
				{
					Id = 100564,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id567] =
{
	Character = 220525,
	Rarity = 4,
	NeedChallenge = 145223,
	UpgradeId = 930035,
	LevelList = {
		{
			Level = 1,
			Info = 920490,
			Ability = {
				{
					Value = 200001,
					Num = 138,
				},
			},
		},
		{
			Level = 2,
			Info = 920490,
			Ability = {
				{
					Value = 200001,
					Num = 230,
				},
			},
		},
		{
			Level = 3,
			Info = 920490,
			Ability = {
				{
					Value = 200001,
					Num = 322,
				},
			},
		},
		{
			Level = 4,
			Info = 920490,
			Ability = {
				{
					Value = 200001,
					Num = 414,
				},
			},
		},
		{
			Level = 5,
			Info = 920490,
			Ability = {
				{
					Value = 200001,
					Num = 506,
				},
				{
					Value = 200003,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920490,
			Ability = {
				{
					Value = 200001,
					Num = 598,
				},
				{
					Value = 200003,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920490,
			Ability = {
				{
					Value = 200001,
					Num = 690,
				},
				{
					Value = 200003,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920490,
			Ability = {
				{
					Value = 200001,
					Num = 782,
				},
				{
					Value = 200003,
					Num = 40,
				},
			},
		},
		{
			Level = 9,
			Info = 920490,
			Ability = {
				{
					Value = 200001,
					Num = 874,
				},
				{
					Value = 200003,
					Num = 45,
				},
			},
		},
		{
			Level = 10,
			Info = 920490,
			Ability = {
				{
					Value = 200001,
					Num = 966,
				},
				{
					Value = 200003,
					Num = 50,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id568] =
{
	Character = 220526,
	Rarity = 4,
	UpgradeId = 930013,
	LevelList = {
		{
			Level = 1,
			Info = 920491,
			Ability = {
				{
					Value = 200002,
					Num = 57,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920491,
			Ability = {
				{
					Value = 200002,
					Num = 114,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920491,
			Ability = {
				{
					Value = 200002,
					Num = 171,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920491,
			Ability = {
				{
					Value = 200002,
					Num = 228,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920491,
			Ability = {
				{
					Value = 200002,
					Num = 285,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920491,
			Ability = {
				{
					Value = 200002,
					Num = 342,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920491,
			Ability = {
				{
					Value = 200002,
					Num = 399,
				},
				{
					Value = 200008,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920491,
			Ability = {
				{
					Value = 200002,
					Num = 456,
				},
				{
					Value = 200008,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920491,
			Ability = {
				{
					Value = 200002,
					Num = 513,
				},
				{
					Value = 200008,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920491,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200008,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id569] =
{
	Character = 220526,
	Rarity = 4,
	UpgradeId = 930014,
	LevelList = {
		{
			Level = 1,
			Info = 920492,
			Ability = {
				{
					Value = 200002,
					Num = 57,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920492,
			Ability = {
				{
					Value = 200002,
					Num = 114,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920492,
			Ability = {
				{
					Value = 200002,
					Num = 171,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920492,
			Ability = {
				{
					Value = 200002,
					Num = 228,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920492,
			Ability = {
				{
					Value = 200002,
					Num = 285,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920492,
			Ability = {
				{
					Value = 200002,
					Num = 342,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920492,
			Ability = {
				{
					Value = 200002,
					Num = 399,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920492,
			Ability = {
				{
					Value = 200002,
					Num = 456,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920492,
			Ability = {
				{
					Value = 200002,
					Num = 513,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920492,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100551,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id570] =
{
	Character = 220526,
	Rarity = 4,
	NeedChallenge = 145224,
	UpgradeId = 930015,
	LevelList = {
		{
			Level = 1,
			Info = 920493,
			Ability = {
				{
					Value = 200002,
					Num = 114,
				},
			},
		},
		{
			Level = 2,
			Info = 920493,
			Ability = {
				{
					Value = 200002,
					Num = 190,
				},
			},
		},
		{
			Level = 3,
			Info = 920493,
			Ability = {
				{
					Value = 200002,
					Num = 266,
				},
			},
		},
		{
			Level = 4,
			Info = 920493,
			Ability = {
				{
					Value = 200002,
					Num = 342,
				},
			},
		},
		{
			Level = 5,
			Info = 920493,
			Ability = {
				{
					Value = 200002,
					Num = 418,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920493,
			Ability = {
				{
					Value = 200002,
					Num = 494,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920493,
			Ability = {
				{
					Value = 200002,
					Num = 570,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920493,
			Ability = {
				{
					Value = 200002,
					Num = 646,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
		},
		{
			Level = 9,
			Info = 920493,
			Ability = {
				{
					Value = 200002,
					Num = 722,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
		},
		{
			Level = 10,
			Info = 920493,
			Ability = {
				{
					Value = 200002,
					Num = 798,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id571] =
{
	Character = 220527,
	Rarity = 4,
	UpgradeId = 930033,
	LevelList = {
		{
			Level = 1,
			Info = 920495,
			Ability = {
				{
					Value = 200001,
					Num = 72,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 2,
			Info = 920495,
			Ability = {
				{
					Value = 200001,
					Num = 144,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 3,
			Info = 920495,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
		},
		{
			Level = 4,
			Info = 920495,
			Ability = {
				{
					Value = 200001,
					Num = 288,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
		},
		{
			Level = 5,
			Info = 920495,
			Ability = {
				{
					Value = 200001,
					Num = 360,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
		},
		{
			Level = 6,
			Info = 920495,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200006,
					Num = 72,
				},
			},
		},
		{
			Level = 7,
			Info = 920495,
			Ability = {
				{
					Value = 200001,
					Num = 504,
				},
				{
					Value = 200006,
					Num = 84,
				},
			},
		},
		{
			Level = 8,
			Info = 920495,
			Ability = {
				{
					Value = 200001,
					Num = 576,
				},
				{
					Value = 200006,
					Num = 96,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920495,
			Ability = {
				{
					Value = 200001,
					Num = 648,
				},
				{
					Value = 200006,
					Num = 108,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920495,
			Ability = {
				{
					Value = 200001,
					Num = 720,
				},
				{
					Value = 200006,
					Num = 120,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id572] =
{
	Character = 220527,
	Rarity = 4,
	UpgradeId = 930034,
	LevelList = {
		{
			Level = 1,
			Info = 920496,
			Ability = {
				{
					Value = 200001,
					Num = 72,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920496,
			Ability = {
				{
					Value = 200001,
					Num = 144,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920496,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920496,
			Ability = {
				{
					Value = 200001,
					Num = 288,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920496,
			Ability = {
				{
					Value = 200001,
					Num = 360,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920496,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920496,
			Ability = {
				{
					Value = 200001,
					Num = 504,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920496,
			Ability = {
				{
					Value = 200001,
					Num = 576,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920496,
			Ability = {
				{
					Value = 200001,
					Num = 648,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920496,
			Ability = {
				{
					Value = 200001,
					Num = 720,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100563,
					Value = -5,
				},
			},
		},
	},
}
