
GoalConfig[GoalID.Id401] =
{
	Id = 401,
	Name = "主线104 - 收集零件2",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130051,
	},
	GoalTrigger = 
	{
		TriggerType.DemandReward,
	},
	GoalCondition = 
	{
		{
			Name = "升级高级装备时需要用到的重要道具！\n完成[62E7E7]委托[-]获得[62E7E7]C级及以上零件[-]道具20个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 20,
			TagList = 
			{
				564363,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 4,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id402] =
{
	Id = 402,
	Name = "主线105 - 童话与美食之国",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130051,
		PreGoal = 
		{
			300401,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "来了旅游胜地，那就自由活动2小时吧~\n探索美食星[FDDE40]着陆点[-]2小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 7200,
			Value = 130051,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 4,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id403] =
{
	Id = 403,
	Name = "主线106 - 草莓推销员的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130051,
		PreGoal = 
		{
			300402,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "呜呜说，这种水果洗一洗他可以吃十斤！\n打败着陆点的[FDDE40]草莓推销员[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140201,
		},
	},
	CompleteSpeech = 30040301,
	Reward = {
		{
			Value = 130052,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id404] =
{
	Id = 404,
	Name = "主线107 - 新的“伙伴”",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130052,
		PreGoal = 
		{
			300403,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]草莓[-]1个(需要超市的空瓶)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 250028,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 4,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id405] =
{
	Id = 405,
	Name = "主线108 - 红豆的香气",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130052,
		PreGoal = 
		{
			300404,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "老家那里，每到秋季就会煮红豆~\n派遣[62E7E7]呜呜[-]、[62E7E7]漆漆[-]探索美食星[FDDE40]鲷鱼镇[-]8小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 28800,
			Character = 
			{
				220001,
				220002,
			},
			Value = 130052,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 4,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id406] =
{
	Id = 406,
	Name = "主线109 - 鱼头老板的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130052,
		PreGoal = 
		{
			300405,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "看着很凶悍，其实是甜点来着。\n打败鲷鱼镇的[FDDE40]鱼头老板[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140202,
		},
	},
	CompleteSpeech = 30040601,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id407] =
{
	Id = 407,
	Name = "主线110 - 地方特产",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130052,
		PreGoal = 
		{
			300406,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中获得[FDDE40]豆沙[-]50个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 50,
			Value = 321201,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 4,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id408] =
{
	Id = 408,
	Name = "主线111 - 不能错过的美食",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130052,
		PreGoal = 
		{
			300407,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "猫总管让我们寄点土特产回去给他。\n提交[FDDE40]豆沙[-]20个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 321201,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 4,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id409] =
{
	Id = 409,
	Name = "主线112 - 猫科的警觉",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130052,
		PreGoal = 
		{
			300408,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]2阶[-][FDDE40]漆漆[-]",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220002,
			Stage = 2,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 4,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id410] =
{
	Id = 410,
	Name = "主线113 - 鱼尾老板的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130052,
		PreGoal = 
		{
			300409,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "说是要为鱼头老大报仇来着…\n打败鲷鱼镇的[FDDE40]鱼尾老板[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140203,
		},
	},
	CompleteSpeech = 30041001,
	Reward = {
		{
			Value = 130054,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id411] =
{
	Id = 411,
	Name = "主线114 - 赚取零花钱",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130054,
		PreGoal = 
		{
			300410,
		},
	},
	GoalTrigger = 
	{
		TriggerType.DemandReward,
	},
	GoalCondition = 
	{
		{
			Name = "虽然要求越来越过分，不过委托主也更大方了！\n完成[62E7E7]委托[-]获得[FDDE40]金币[-]20000个",
			Type = ItemType.Gold,
			CountType = GoalCountType.StartNow,
			Num = 20000,
			Value = 1,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 4,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id412] =
{
	Id = 412,
	Name = "主线115 - 双重甜食",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130054,
		PreGoal = 
		{
			300411,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "探索[62E7E7]糖果镇[-]击败[FDDE40]阿头[-]36个，建议探索9小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 36,
			Value = 242032,
			Area = 130054,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 4,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id413] =
{
	Id = 413,
	Name = "主线116 - 水果糖新秀的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130054,
		PreGoal = 
		{
			300412,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败糖果镇的[FDDE40]水果糖新秀[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140208,
		},
	},
	CompleteSpeech = 30041301,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id414] =
{
	Id = 414,
	Name = "主线117 - 瓶装的回忆",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130054,
		PreGoal = 
		{
			300413,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有[FDDE40]脏脏的瓶子[-]5个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 5,
			Value = 320305,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 4,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id415] =
{
	Id = 415,
	Name = "主线118 - 童年的快乐回忆",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130054,
		PreGoal = 
		{
			300414,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "捕获宠物[FDDE40]水果小糖[-]1个(需要超市的空瓶)",
			Type = ItemType.Pet,
			CountType = GoalCountType.StartNow,
			Num = 1,
			Value = 250037,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 4,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id416] =
{
	Id = 416,
	Name = "主线119 - 成分确认",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130054,
		PreGoal = 
		{
			300415,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]呜呜[-]在探索中获得[FDDE40]牛奶[-]30个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 30,
			Character = 
			{
				220001,
			},
			Value = 321203,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 4,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id417] =
{
	Id = 417,
	Name = "主线120 - 奶糖新秀的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130054,
		PreGoal = 
		{
			300416,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败糖果镇的[FDDE40]奶糖新秀[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140209,
		},
	},
	CompleteSpeech = 30041701,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id418] =
{
	Id = 418,
	Name = "主线121 - 红红火火",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130054,
		PreGoal = 
		{
			300417,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]25级[-][62E7E7]火元素[-][FDDE40]角色[-]1个",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = -1,
			Level = 25,
			Element = 210002,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 4,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id419] =
{
	Id = 419,
	Name = "主线122 - 水果味道",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130054,
		PreGoal = 
		{
			300418,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "咦？捕捉10个草莓后，草莓就会升级？\n累计捕捉宠物[FDDE40]草莓[-]10个(需要超市的空瓶)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 10,
			Value = 250028,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 4,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id420] =
{
	Id = 420,
	Name = "主线123 - 草莓奶糖",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130054,
		PreGoal = 
		{
			300419,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "听说是那位公主最爱的食物！\n携带[62E7E7]草莓[-]探索[62E7E7]糖果镇[-]击败[FDDE40]奶小糖[-]10个，建议探索8小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 10,
			Pet = 250028,
			Value = 242038,
			Area = 130054,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 4,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id421] =
{
	Id = 421,
	Name = "主线124 - 小红的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130054,
		PreGoal = 
		{
			300420,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败糖果镇的[FDDE40]小红[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140210,
		},
	},
	Reward = {
		{
			Value = 130055,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id422] =
{
	Id = 422,
	Name = "主线125 - 制作特大血瓶",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130055,
		PreGoal = 
		{
			300421,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "战斗时喝这个能回血吗？什么！功能没做！\n拥有[FDDE40]特大血瓶[-]4个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 4,
			Value = 320404,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 4,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id423] =
{
	Id = 423,
	Name = "主线126 - 超速行驶",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130055,
		PreGoal = 
		{
			300422,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "[62E7E7]一次性[-]派遣含有[62E7E7]1个[-][62E7E7]风元素[-]队员(或宠物)的队伍探索美食星[FDDE40]甜食工厂[-]12小时",
			Type = ItemType.Time,
			CountType = GoalCountType.OneShot,
			Num = 43200,
			TagList = 
			{
				561204,
			},
			CharacterNum = 1,
			Value = 130055,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 4,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id424] =
{
	Id = 424,
	Name = "主线127 - 冠军芒果滋的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130055,
		PreGoal = 
		{
			300423,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "路上有一股香甜的芒果味~\n打败甜食工厂的[FDDE40]冠军芒果滋[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140211,
		},
	},
	CompleteSpeech = 30042401,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id425] =
{
	Id = 425,
	Name = "主线128 - 快速充能",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130055,
		PreGoal = 
		{
			300424,
		},
	},
	GoalTrigger = 
	{
		TriggerType.DemandReward,
	},
	GoalCondition = 
	{
		{
			Name = "是时候充充电了。\n完成[62E7E7]委托[-]获得[62E7E7]低量及以上电池[-]道具1个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 1,
			TagList = 
			{
				564392,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 4,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id426] =
{
	Id = 426,
	Name = "主线129 - 截停！",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130055,
		PreGoal = 
		{
			300425,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "甜食工厂的探索急需优秀的风元素队员！\n拥有至少[62E7E7]25级[-][62E7E7]风元素[-][FDDE40]角色[-]2个",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 2,
			Value = -1,
			Level = 25,
			Element = 210003,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 4,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id427] =
{
	Id = 427,
	Name = "主线130 - 城市追击",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130055,
		PreGoal = 
		{
			300426,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "[62E7E7]一次性[-]派遣含有[62E7E7]2个[-][62E7E7]风元素[-]队员(或宠物)的队伍探索美食星[FDDE40]甜食工厂[-]12小时",
			Type = ItemType.Time,
			CountType = GoalCountType.OneShot,
			Num = 43200,
			TagList = 
			{
				561204,
			},
			CharacterNum = 2,
			Value = 130055,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 4,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id428] =
{
	Id = 428,
	Name = "主线131 - 冠军多拿滋的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130055,
		PreGoal = 
		{
			300427,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败甜食工厂的[FDDE40]冠军多拿滋[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140212,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id429] =
{
	Id = 429,
	Name = "主线132 - 美食星之旅",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130055,
		PreGoal = 
		{
			300428,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "这些是要入队的新伙伴，请大家把口水擦一擦…\n累计拥有[62E7E7]美食星[-][FDDE40]宠物[-]4种",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 4,
			TagList = 
			{
				560104,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 4,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id430] =
{
	Id = 430,
	Name = "主线133 - 闪光的美食",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130055,
		PreGoal = 
		{
			300429,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]1个[-][62E7E7]暗元素[-]队员(或宠物)的队伍探索美食星[FDDE40]甜食工厂[-]12小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 43200,
			TagList = 
			{
				561206,
			},
			CharacterNum = 1,
			Value = 130055,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 4,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id431] =
{
	Id = 431,
	Name = "主线134 - 超Q布丁呆的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130055,
		PreGoal = 
		{
			300430,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "广告说纯天然，但口感分明是布丁粉！\n打败甜食工厂的[FDDE40]超Q布丁呆[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140213,
		},
	},
	CompleteSpeech = 30043101,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id432] =
{
	Id = 432,
	Name = "主线135 - 瓶装汽水",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130055,
		PreGoal = 
		{
			300431,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Craft,
	},
	GoalCondition = 
	{
		{
			Name = "直到目前，也没人知道空瓶的合成原理…\n在实验室合成获得[FDDE40]玻璃瓶[-]1个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 1,
			Value = 320306,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 4,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id433] =
{
	Id = 433,
	Name = "主线136 - 公主在哪儿1",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130055,
		PreGoal = 
		{
			300432,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "请不要以为我只能打工！By小红\n派遣[62E7E7]小红[-]探索美食星[FDDE40]甜食工厂[-]8小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 28800,
			Character = 
			{
				220105,
			},
			Value = 130055,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 4,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id434] =
{
	Id = 434,
	Name = "主线137 - 超级甜食",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130055,
		PreGoal = 
		{
			300433,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]奶小糖[-]1个(需要超市的空瓶)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 250038,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 4,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id435] =
{
	Id = 435,
	Name = "主线138 - 王子的安保工作",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130055,
		PreGoal = 
		{
			300434,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]布丁呆[-]10个，建议探索9小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 10,
			Value = 242041,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 4,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id436] =
{
	Id = 436,
	Name = "主线139 - 汽水王子的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130055,
		PreGoal = 
		{
			300435,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败甜食工厂的[FDDE40]汽水王子[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140214,
		},
	},
	CompleteSpeech = 30043601,
	Reward = {
		{
			Value = 130057,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id437] =
{
	Id = 437,
	Name = "主线140 - 王子的排面1",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130057,
		PreGoal = 
		{
			300436,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "王子加入了队伍，不过很难伺候的样子。\n拥有至少[62E7E7]15级[-][FDDE40]汽水王子[-]",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220102,
			Level = 15,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 5,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id438] =
{
	Id = 438,
	Name = "主线141 - 寻找桃几",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130057,
		PreGoal = 
		{
			300437,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]1个[-][62E7E7]身为美食星王子的[-]队员(或宠物)的队伍探索美食星[FDDE40]饭团镇[-]8小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 28800,
			TagList = 
			{
				562907,
			},
			CharacterNum = 1,
			Value = 130057,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 5,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id439] =
{
	Id = 439,
	Name = "主线142 - 桃几推销员的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130057,
		PreGoal = 
		{
			300438,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "哇，看质感水分就很足的样子~\n打败饭团镇的[FDDE40]桃几推销员[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140219,
		},
	},
	CompleteSpeech = 30043901,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id440] =
{
	Id = 440,
	Name = "主线143 - 警局打工1",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130057,
		PreGoal = 
		{
			300439,
		},
	},
	GoalTrigger = 
	{
		TriggerType.WorkShopRank,
	},
	GoalCondition = 
	{
		{
			Name = "人员足够的话务必协助空间站的警察局。\n在[FDDE40]警察局[-]打工获得[FDDE40]F-[-]或更高评价",
			Type = ItemType.WorkShop,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 160003,
			Rank = 2,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 5,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id441] =
{
	Id = 441,
	Name = "主线144 - 自备水果",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130057,
		PreGoal = 
		{
			300440,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]桃几[-]1个(需要超市的空瓶)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 250030,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 5,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id442] =
{
	Id = 442,
	Name = "主线145 - 自制便当",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130057,
		PreGoal = 
		{
			300441,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ExploreCost,
	},
	GoalCondition = 
	{
		{
			Name = "探索[62E7E7]饭团镇[-]消耗[FDDE40]小便当[-]10个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 10,
			Value = 320410,
			Area = 130057,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 5,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id443] =
{
	Id = 443,
	Name = "主线146 - 和音饭团的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130057,
		PreGoal = 
		{
			300442,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败饭团镇的[FDDE40]和音饭团[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140220,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id444] =
{
	Id = 444,
	Name = "主线147 - 本地水果",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130057,
		PreGoal = 
		{
			300443,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "嗯，抓够10个的话桃子就能2级了。\n累计捕捉宠物[FDDE40]桃几[-]10个(需要超市的空瓶)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 10,
			Value = 250030,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 5,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id445] =
{
	Id = 445,
	Name = "主线148 - 再添一碗饭！",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130057,
		PreGoal = 
		{
			300444,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "部分队员没有特长，就胃口特别好...\n在探索中获得[FDDE40]米饭[-]30个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 30,
			Value = 321206,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 5,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id446] =
{
	Id = 446,
	Name = "主线149 - 和音黑米团的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130057,
		PreGoal = 
		{
			300445,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "关于白米黑米哪个香，船员分成了两派…\n打败饭团镇的[FDDE40]和音黑米团[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140221,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id447] =
{
	Id = 447,
	Name = "主线150 - 香糯的白米团",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130057,
		PreGoal = 
		{
			300446,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "探索[62E7E7]饭团镇[-]击败[FDDE40]饭团[-]15个，建议探索4小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 15,
			Value = 242044,
			Area = 130057,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 5,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id448] =
{
	Id = 448,
	Name = "主线151 - 筋道的黑米团",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130057,
		PreGoal = 
		{
			300447,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "探索[62E7E7]饭团镇[-]击败[FDDE40]黑米团[-]15个，建议探索4小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 15,
			Value = 242045,
			Area = 130057,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 5,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id449] =
{
	Id = 449,
	Name = "主线152 - 第三种口味",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130057,
		PreGoal = 
		{
			300448,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "哇，这种口味，看来是地区限定呢！\n派遣含有[62E7E7]1个[-][62E7E7]风元素[-]队员(或宠物)的队伍探索美食星[FDDE40]饭团镇[-]4小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 14400,
			TagList = 
			{
				561204,
			},
			CharacterNum = 1,
			Value = 130057,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 5,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id450] =
{
	Id = 450,
	Name = "主线153 - 和音泡菜团的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130057,
		PreGoal = 
		{
			300449,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败饭团镇的[FDDE40]和音泡菜团[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140222,
		},
	},
	CompleteSpeech = 30045001,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id451] =
{
	Id = 451,
	Name = "主线154 - 环保打包袋",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130057,
		PreGoal = 
		{
			300450,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有[FDDE40]简易纸袋[-]6个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 6,
			Value = 320309,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 5,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id452] =
{
	Id = 452,
	Name = "主线155 - 横扫饭团镇",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130057,
		PreGoal = 
		{
			300451,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "如果打不过那个怪物的话，就不会抓到了吧？\n累计拥有[62E7E7]饭团类的[-][FDDE40]宠物[-]3种",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 3,
			TagList = 
			{
				561357,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 5,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id453] =
{
	Id = 453,
	Name = "主线156 - 公主在哪儿2",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130057,
		PreGoal = 
		{
			300452,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "守护公主们的一定都是骑士吗？\n派遣含有[62E7E7]1个[-][62E7E7]风元素[-]、[62E7E7]女性[-]队员(或宠物)的队伍探索美食星[FDDE40]饭团镇[-]8小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 28800,
			TagList = 
			{
				561204,
				561703,
			},
			CharacterNum = 1,
			Value = 130057,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 5,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id454] =
{
	Id = 454,
	Name = "主线157 - 小橙的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130057,
		PreGoal = 
		{
			300453,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败饭团镇的[FDDE40]小橙[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140223,
		},
	},
	Reward = {
		{
			Value = 130058,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id455] =
{
	Id = 455,
	Name = "主线158 - 寿司小镇",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130058,
		PreGoal = 
		{
			300454,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]呜呜[-]、[62E7E7]漆漆[-]在探索中击败[FDDE40]黑脸鱼子军舰[-]25个，建议探索5小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 25,
			Character = 
			{
				220001,
				220002,
			},
			Value = 242042,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 5,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id456] =
{
	Id = 456,
	Name = "主线159 - 食材交易",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130058,
		PreGoal = 
		{
			300455,
		},
	},
	GoalTrigger = 
	{
		TriggerType.DemandCost,
	},
	GoalCondition = 
	{
		{
			Name = "如果查看图鉴，就能了解哪些是美食星道具啦。\n在委托中提交[62E7E7]美食星[-]道具20个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 20,
			TagList = 
			{
				560104,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 5,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id457] =
{
	Id = 457,
	Name = "主线160 - 强化装备4",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130058,
		PreGoal = 
		{
			300456,
		},
	},
	GoalTrigger = 
	{
		TriggerType.UpgradeEquipment,
	},
	GoalCondition = 
	{
		{
			Name = "强化[62E7E7]任意[-][FDDE40]装备[-]48次",
			Type = ItemType.Equipment,
			CountType = GoalCountType.Current,
			Num = 48,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 5,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id458] =
{
	Id = 458,
	Name = "主线161 - 超Q夹心肉球的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130058,
		PreGoal = 
		{
			300457,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "肉质Q到飞起的夹心肉球，咬开要小心噢~\n打败煮物镇的[FDDE40]超Q夹心肉球[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140224,
		},
	},
	CompleteSpeech = 30045801,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id459] =
{
	Id = 459,
	Name = "主线162 - 英雄与魔王的较量",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130058,
		PreGoal = 
		{
			300458,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "小魔王说，比赛吃肉他从来没有输过。\n派遣[62E7E7]剑士[-]、[62E7E7]小魔王[-]在探索中击败[FDDE40]夹心肉球[-]30个，建议探索8小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 30,
			Character = 
			{
				220003,
				220009,
			},
			Value = 242047,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 5,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id460] =
{
	Id = 460,
	Name = "主线163 - 打包带走",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130058,
		PreGoal = 
		{
			300459,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "小份的，打包带走。\n累计捕捉宠物[FDDE40]夹心肉球[-]3个(需要超市的空瓶)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 3,
			Value = 250047,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 5,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id461] =
{
	Id = 461,
	Name = "主线164 - 爆浆肉球",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130058,
		PreGoal = 
		{
			300460,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中获得[FDDE40]料酒[-]30个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 30,
			Value = 321207,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 5,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id462] =
{
	Id = 462,
	Name = "主线165 - 超烫铛噗灵的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130058,
		PreGoal = 
		{
			300461,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "关于白菜馅和芹菜馅，船员再次起了争执…\n打败煮物镇的[FDDE40]超烫铛噗灵[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140225,
		},
	},
	CompleteSpeech = 30046201,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id463] =
{
	Id = 463,
	Name = "主线166 - 充分准备1",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130058,
		PreGoal = 
		{
			300462,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "稀有度较低的角色，升级费用也会更便宜。\n拥有至少[62E7E7]30级[-][FDDE40]角色[-]2个",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 2,
			Value = -1,
			Level = 30,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 5,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id464] =
{
	Id = 464,
	Name = "主线167 - 充分准备2",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130058,
		PreGoal = 
		{
			300463,
		},
	},
	GoalTrigger = 
	{
		TriggerType.UpgradeEquipment,
	},
	GoalCondition = 
	{
		{
			Name = "强化[62E7E7]任意[-][FDDE40]装备[-]64次",
			Type = ItemType.Equipment,
			CountType = GoalCountType.Current,
			Num = 64,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 5,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id465] =
{
	Id = 465,
	Name = "主线168 - 王子的友谊",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130058,
		PreGoal = 
		{
			300464,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]1[-][62E7E7]身为美食星王子的[-]队员(或宠物)的队伍探索[62E7E7]煮物镇[-]击败[FDDE40]铛噗灵[-]20个，建议探索18小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 20,
			TagList = 
			{
				562907,
			},
			CharacterNum = 1,
			Value = 242048,
			Area = 130058,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 5,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id466] =
{
	Id = 466,
	Name = "主线169 - 可乐王子的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130058,
		PreGoal = 
		{
			300465,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败煮物镇的[FDDE40]可乐王子[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140226,
		},
	},
	CompleteSpeech = 30046601,
	Reward = {
		{
			Value = 130059,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id467] =
{
	Id = 467,
	Name = "主线170 - 海鲜与米饭之乡",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130059,
		PreGoal = 
		{
			300466,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "探索美食星[FDDE40]寿司镇[-]12小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 43200,
			Value = 130059,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 5,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id468] =
{
	Id = 468,
	Name = "主线171 - 醋饭的材料",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130059,
		PreGoal = 
		{
			300467,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Craft,
	},
	GoalCondition = 
	{
		{
			Name = "在实验室合成获得[FDDE40]米醋[-]10个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 10,
			Value = 321253,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 5,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id469] =
{
	Id = 469,
	Name = "主线172 - 美食星高级委托",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130059,
		PreGoal = 
		{
			300468,
		},
	},
	GoalTrigger = 
	{
		TriggerType.DemandCost,
	},
	GoalCondition = 
	{
		{
			Name = "在委托中提交[62E7E7]合成的[-]、[62E7E7]美食星[-]道具1个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 1,
			TagList = 
			{
				560005,
				560104,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 5,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id470] =
{
	Id = 470,
	Name = "主线173 - 金牌玉子龟龟的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130059,
		PreGoal = 
		{
			300469,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败寿司镇的[FDDE40]金牌玉子龟龟[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140227,
		},
	},
	CompleteSpeech = 30047001,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id471] =
{
	Id = 471,
	Name = "主线174 - 游车河1",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130059,
		PreGoal = 
		{
			300470,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有[FDDE40]波子小跑[-](汽水王子装备)",
			Type = ItemType.Equipment,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 340078,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 5,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id472] =
{
	Id = 472,
	Name = "主线175 - 制作快餐",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130059,
		PreGoal = 
		{
			300471,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Craft,
	},
	GoalCondition = 
	{
		{
			Name = "在实验室合成获得[FDDE40]全家桶[-]2个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 2,
			Value = 320408,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 5,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id473] =
{
	Id = 473,
	Name = "主线176 - 快餐吃快餐",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130059,
		PreGoal = 
		{
			300472,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ExploreCost,
	},
	GoalCondition = 
	{
		{
			Name = "探索[62E7E7]寿司镇[-]消耗[FDDE40]全家桶[-]2个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 2,
			Value = 320408,
			Area = 130059,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 5,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id474] =
{
	Id = 474,
	Name = "主线177 - 金牌寿司龟龟的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130059,
		PreGoal = 
		{
			300473,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败寿司镇的[FDDE40]金牌寿司龟龟[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140228,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id475] =
{
	Id = 475,
	Name = "主线178 - 游车河2",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130059,
		PreGoal = 
		{
			300474,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有[FDDE40]捷猫小跑[-](可乐王子装备)",
			Type = ItemType.Equipment,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 340081,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 5,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id476] =
{
	Id = 476,
	Name = "主线179 - 寿司与海苔的研究",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130059,
		PreGoal = 
		{
			300475,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中获得[FDDE40]海苔[-]25个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 25,
			Value = 321208,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 5,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id477] =
{
	Id = 477,
	Name = "主线180 - 警局打工2",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130059,
		PreGoal = 
		{
			300476,
		},
	},
	GoalTrigger = 
	{
		TriggerType.WorkShopRank,
	},
	GoalCondition = 
	{
		{
			Name = "最近在警察局工作还顺利吗？要注意安全。\n在[FDDE40]警察局[-]打工获得[FDDE40]E-[-]或更高评价",
			Type = ItemType.WorkShop,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 160003,
			Rank = 5,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 5,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id478] =
{
	Id = 478,
	Name = "主线181 - 金牌甜虾龟龟的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130059,
		PreGoal = 
		{
			300477,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败寿司镇的[FDDE40]金牌甜虾龟龟[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140229,
		},
	},
	CompleteSpeech = 30047801,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id479] =
{
	Id = 479,
	Name = "主线182 - 大战寿司",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130059,
		PreGoal = 
		{
			300478,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "探索[62E7E7]寿司镇[-]击败[FDDE40]甜虾龟龟[-]15个，建议探索6小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 15,
			Value = 242051,
			Area = 130059,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 5,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id480] =
{
	Id = 480,
	Name = "主线183 - 收集零件3",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130059,
		PreGoal = 
		{
			300479,
		},
	},
	GoalTrigger = 
	{
		TriggerType.DemandReward,
	},
	GoalCondition = 
	{
		{
			Name = "装备达到一定等级后会用到更高级的零件。\n完成[62E7E7]委托[-]获得[62E7E7]B级及以上零件[-]道具20个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 20,
			TagList = 
			{
				564364,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 5,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id481] =
{
	Id = 481,
	Name = "主线184 - 糖豆间的默契",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130059,
		PreGoal = 
		{
			300480,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "糖豆们也有他们必须保护的对象~\n派遣含有[62E7E7]2个[-][62E7E7]糖豆组[-]队员(或宠物)的队伍探索美食星[FDDE40]寿司镇[-]8小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 28800,
			TagList = 
			{
				562909,
			},
			CharacterNum = 2,
			Value = 130059,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 5,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id482] =
{
	Id = 482,
	Name = "主线185 - 小绿的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130059,
		PreGoal = 
		{
			300481,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败寿司镇的[FDDE40]小绿[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140230,
		},
	},
	Reward = {
		{
			Value = 130060,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id483] =
{
	Id = 483,
	Name = "主线186 - 强化装备5",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130060,
		PreGoal = 
		{
			300482,
		},
	},
	GoalTrigger = 
	{
		TriggerType.UpgradeEquipment,
	},
	GoalCondition = 
	{
		{
			Name = "强化[62E7E7]任意[-][FDDE40]装备[-]72次",
			Type = ItemType.Equipment,
			CountType = GoalCountType.Current,
			Num = 72,
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id484] =
{
	Id = 484,
	Name = "主线187 - 肉香满溢的小镇",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130060,
		PreGoal = 
		{
			300483,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]呜呜[-]、[62E7E7]漆漆[-]探索美食星[FDDE40]烤肉镇[-]6小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 21600,
			Character = 
			{
				220001,
				220002,
			},
			Value = 130060,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id485] =
{
	Id = 485,
	Name = "主线188 - 捕捉苹狗",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130060,
		PreGoal = 
		{
			300484,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "嗯，就一次性把苹狗升到2级吧！\n累计捕捉宠物[FDDE40]苹狗[-]10个(需要超市的空瓶)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 10,
			Value = 250031,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id486] =
{
	Id = 486,
	Name = "主线189 - 苹狗推销员的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130060,
		PreGoal = 
		{
			300485,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "从神话时期就与人类文明纠缠不清的水果。\n打败烤肉镇的[FDDE40]苹狗推销员[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140231,
		},
	},
	CompleteSpeech = 30048601,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id487] =
{
	Id = 487,
	Name = "主线190 - 烤肉镇的煮物",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130060,
		PreGoal = 
		{
			300486,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "探索[62E7E7]烤肉镇[-]击败[FDDE40]夹心肉球[-]20个，建议探索4小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 20,
			Value = 242047,
			Area = 130060,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id488] =
{
	Id = 488,
	Name = "主线191 - 超市打工2",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130060,
		PreGoal = 
		{
			300487,
		},
	},
	GoalTrigger = 
	{
		TriggerType.WorkShopRank,
	},
	GoalCondition = 
	{
		{
			Name = "在超市搬货的时候要小心，不要拉伤噢~\n在[FDDE40]超市[-]打工获得[FDDE40]C-[-]或更高评价",
			Type = ItemType.WorkShop,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 160002,
			Rank = 11,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id489] =
{
	Id = 489,
	Name = "主线192 - 汽水与烤肉片",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130060,
		PreGoal = 
		{
			300488,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]2个[-][62E7E7]身为美食星王子的[-]队员(或宠物)的队伍探索美食星[FDDE40]烤肉镇[-]12小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 43200,
			TagList = 
			{
				562907,
			},
			CharacterNum = 2,
			Value = 130060,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id490] =
{
	Id = 490,
	Name = "主线193 - 冠军培根的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130060,
		PreGoal = 
		{
			300489,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败烤肉镇的[FDDE40]冠军培根[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140232,
		},
	},
	CompleteSpeech = 30049001,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id491] =
{
	Id = 491,
	Name = "主线194 - 切片肉",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130060,
		PreGoal = 
		{
			300490,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "捕获宠物[FDDE40]培根[-]1个(需要警察局的纸袋)",
			Type = ItemType.Pet,
			CountType = GoalCountType.StartNow,
			Num = 1,
			Value = 250052,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id492] =
{
	Id = 492,
	Name = "主线195 - 可乐与烤肉块",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130060,
		PreGoal = 
		{
			300491,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣[62E7E7]可乐王子[-]在探索中获得[FDDE40]五花肉[-]20个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 20,
			Character = 
			{
				220103,
			},
			Value = 321209,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id493] =
{
	Id = 493,
	Name = "主线196 - 火腿猪的最爱",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130060,
		PreGoal = 
		{
			300492,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "提交[FDDE40]蛋糕[-]5个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 5,
			Value = 321252,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id494] =
{
	Id = 494,
	Name = "主线197 - 冠军火腿猪的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130060,
		PreGoal = 
		{
			300493,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "表皮松脆，但是肉质嫩滑，想吃吗？\n打败烤肉镇的[FDDE40]冠军火腿猪[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140233,
		},
	},
	CompleteSpeech = 30049401,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id495] =
{
	Id = 495,
	Name = "主线198 - 烤肉镇的酒香",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130060,
		PreGoal = 
		{
			300494,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "如果带上能生产料酒的宠物，会容易很多吧？\n在探索中获得[FDDE40]料酒[-]12个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 12,
			Value = 321207,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id496] =
{
	Id = 496,
	Name = "主线199 - 饮料间的对抗1",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130060,
		PreGoal = 
		{
			300495,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]2阶[-][FDDE40]汽水王子[-]",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220102,
			Stage = 2,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id497] =
{
	Id = 497,
	Name = "主线200 - 饮料间的对抗2",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130060,
		PreGoal = 
		{
			300496,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]2阶[-][FDDE40]可乐王子[-]",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 220103,
			Stage = 2,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id498] =
{
	Id = 498,
	Name = "主线201 - 王子们的友谊",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130060,
		PreGoal = 
		{
			300497,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "可乐加汽水就能兑换出外观100%的啤酒了。\n派遣[62E7E7]汽水王子[-]、[62E7E7]可乐王子[-]探索美食星[FDDE40]烤肉镇[-]12小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 43200,
			Character = 
			{
				220102,
				220103,
			},
			Value = 130060,
		},
	},
	Reward = {
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id499] =
{
	Id = 499,
	Name = "主线202 - 啤酒王子的挑战",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130060,
		PreGoal = 
		{
			300498,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败烤肉镇的[FDDE40]啤酒王子[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140234,
		},
	},
	CompleteSpeech = 30049901,
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id500] =
{
	Id = 500,
	Name = "主线203 - 下一站，博物馆星！",
	GoalType = GoalType.Main,
	ShowFirst = true,
	PreCondition = {
		PreArea = 130060,
		PreGoal = 
		{
			300499,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "说到燃料，要不先用这个吧！\n提交[FDDE40]五花肉[-]20个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 321209,
		},
	},
	CompleteSpeech = 30050001,
	Reward = {
		{
			Value = 130101,
			Num = 1,
		},
		{
			Value = 330001,
			Num = 7,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id701] =
{
	Id = 701,
	Name = "解锁：冰淇淋港",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130052,
		PreGoal = 
		{
			300410,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "去那里的话要注意保暖噢~\n拥有至少[62E7E7]2阶[-][62E7E7]火元素[-][FDDE40]角色[-]3个",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 3,
			Value = -1,
			Stage = 2,
			Element = 210002,
		},
	},
	Reward = {
		{
			Value = 130053,
			Num = 1,
		},
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id702] =
{
	Id = 702,
	Name = "支线-团队聚会",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130053,
		PreGoal = 
		{
			300701,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Craft,
	},
	GoalCondition = 
	{
		{
			Name = "在实验室合成获得[FDDE40]纷享桶[-]5个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 5,
			Value = 320407,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id703] =
{
	Id = 703,
	Name = "支线-夏日香草",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130053,
		PreGoal = 
		{
			300702,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "马上就能吃到冰淇淋了！\n探索[62E7E7]冰淇淋港[-]击败[FDDE40]草莓[-]150个，建议探索10小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 150,
			Value = 242028,
			Area = 130053,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id704] =
{
	Id = 704,
	Name = "支线-超浓克林姆的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130053,
		PreGoal = 
		{
			300703,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败冰淇淋港的[FDDE40]超浓克林姆[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140204,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id705] =
{
	Id = 705,
	Name = "支线-捕捉克林姆",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130053,
		PreGoal = 
		{
			300704,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "捕获宠物[FDDE40]克林姆[-]1个(需要超市的空瓶)",
			Type = ItemType.Pet,
			CountType = GoalCountType.StartNow,
			Num = 1,
			Value = 250034,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id706] =
{
	Id = 706,
	Name = "支线-冰淇淋之行",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130053,
		PreGoal = 
		{
			300705,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "携带[62E7E7]克林姆[-]探索美食星[FDDE40]冰淇淋港[-]8小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 28800,
			Pet = 250034,
			Value = 130053,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id707] =
{
	Id = 707,
	Name = "支线-爽朗海风",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130053,
		PreGoal = 
		{
			300706,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]20级[-][62E7E7]风元素[-][FDDE40]角色[-]2个",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 2,
			Value = -1,
			Level = 20,
			Element = 210003,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id708] =
{
	Id = 708,
	Name = "支线-超浓茶克林姆的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130053,
		PreGoal = 
		{
			300707,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败冰淇淋港的[FDDE40]超浓茶克林姆[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140205,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id709] =
{
	Id = 709,
	Name = "支线-自制红豆冰",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130053,
		PreGoal = 
		{
			300708,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Craft,
	},
	GoalCondition = 
	{
		{
			Name = "在实验室合成获得[FDDE40]红豆冰[-]8个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 8,
			Value = 321251,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id710] =
{
	Id = 710,
	Name = "支线-奶茶多冰",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130053,
		PreGoal = 
		{
			300709,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "要快点，马上要变成水了！\n在探索中获得[FDDE40]冰块[-]30个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 30,
			Value = 321202,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id711] =
{
	Id = 711,
	Name = "支线-凉爽夏日",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130053,
		PreGoal = 
		{
			300710,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]3个[-][62E7E7]蓝色及以上品质[-]队员(或宠物)的队伍探索美食星[FDDE40]冰淇淋港[-]12小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 43200,
			TagList = 
			{
				560033,
			},
			CharacterNum = 3,
			Value = 130053,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id712] =
{
	Id = 712,
	Name = "支线-超浓巧克林姆的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130053,
		PreGoal = 
		{
			300711,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败冰淇淋港的[FDDE40]超浓巧克林姆[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140206,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id713] =
{
	Id = 713,
	Name = "支线-奶茶的考验",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130053,
		PreGoal = 
		{
			300712,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]30级[-][62E7E7]水元素[-][FDDE40]角色[-]1个",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = -1,
			Level = 30,
			Element = 210001,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id714] =
{
	Id = 714,
	Name = "支线-兜售冰块",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130053,
		PreGoal = 
		{
			300713,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "提交[FDDE40]冰块[-]15个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 15,
			Value = 321202,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id715] =
{
	Id = 715,
	Name = "支线-寻找奶茶王子",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130053,
		PreGoal = 
		{
			300714,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]1[-][62E7E7]水元素[-]队员(或宠物)的队伍在探索中击败[FDDE40]茶克林姆[-]30个，建议探索10小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 30,
			TagList = 
			{
				561202,
			},
			CharacterNum = 1,
			Value = 242035,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id716] =
{
	Id = 716,
	Name = "支线-奶茶王子的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130053,
		PreGoal = 
		{
			300715,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败冰淇淋港的[FDDE40]奶茶王子[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140207,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id717] =
{
	Id = 717,
	Name = "解锁：风味镇",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130055,
		PreGoal = 
		{
			300436,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "提交[FDDE40]豆沙[-]10个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 10,
			Value = 321201,
		},
	},
	Reward = {
		{
			Value = 130056,
			Num = 1,
		},
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id718] =
{
	Id = 718,
	Name = "支线-偶尔出行",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130056,
		PreGoal = 
		{
			300717,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "头一次到外星旅游，就是飞船坐着头晕…\n派遣[62E7E7]村长[-]、[62E7E7]村长夫人[-]探索美食星[FDDE40]风味镇[-]12小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 43200,
			Character = 
			{
				220012,
				220013,
			},
			Value = 130056,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id719] =
{
	Id = 719,
	Name = "支线-梨几推销员的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130056,
		PreGoal = 
		{
			300718,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败风味镇的[FDDE40]梨几推销员[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140215,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id720] =
{
	Id = 720,
	Name = "支线-海与水",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130056,
		PreGoal = 
		{
			300719,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]2阶[-][62E7E7]水元素[-][FDDE40]角色[-]1个",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = -1,
			Stage = 2,
			Element = 210001,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id721] =
{
	Id = 721,
	Name = "支线-来自大海的美味",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130056,
		PreGoal = 
		{
			300720,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]1个[-][62E7E7]水元素[-]队员(或宠物)的队伍探索美食星[FDDE40]风味镇[-]12小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 43200,
			TagList = 
			{
				561202,
			},
			CharacterNum = 1,
			Value = 130056,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id722] =
{
	Id = 722,
	Name = "支线-黑脸鱼子母舰的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130056,
		PreGoal = 
		{
			300721,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败风味镇的[FDDE40]黑脸鱼子母舰[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140216,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id723] =
{
	Id = 723,
	Name = "支线-美食的光芒",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130056,
		PreGoal = 
		{
			300722,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]30级[-][62E7E7]光元素[-][FDDE40]角色[-]1个",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = -1,
			Level = 30,
			Element = 210004,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id724] =
{
	Id = 724,
	Name = "支线-海苔与鱼子",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130056,
		PreGoal = 
		{
			300723,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]1个[-][62E7E7]光元素[-]队员(或宠物)的队伍探索美食星[FDDE40]风味镇[-]18小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 64800,
			TagList = 
			{
				561205,
			},
			CharacterNum = 1,
			Value = 130056,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id725] =
{
	Id = 725,
	Name = "支线-鱼子在口中爆炸",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130056,
		PreGoal = 
		{
			300724,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "捕获宠物[FDDE40]黑脸鱼子军舰[-]2个(需要道具店的陷阱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.StartNow,
			Num = 2,
			Value = 250042,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id726] =
{
	Id = 726,
	Name = "支线-超烫塔可桑的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130056,
		PreGoal = 
		{
			300725,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败风味镇的[FDDE40]超烫塔可桑[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140217,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id727] =
{
	Id = 727,
	Name = "支线-临时午餐",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130056,
		PreGoal = 
		{
			300726,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "在探索中击败[FDDE40]塔可桑[-]6个，建议探索17小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 6,
			Value = 242043,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id728] =
{
	Id = 728,
	Name = "支线-补充水分",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130056,
		PreGoal = 
		{
			300727,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "嗓子不舒服的队员要来杯雪梨汁吗？\n累计捕捉宠物[FDDE40]梨几[-]10个(需要超市的空瓶)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 10,
			Value = 250029,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id729] =
{
	Id = 729,
	Name = "支线-公主在哪儿4",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130056,
		PreGoal = 
		{
			300728,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "糖豆们似乎在到处寻找美丽的公主~\n派遣含有[62E7E7]1个[-][62E7E7]美食星[-]、[62E7E7]女性[-]队员(或宠物)的队伍探索美食星[FDDE40]风味镇[-]18小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 64800,
			TagList = 
			{
				560104,
				561703,
			},
			CharacterNum = 1,
			Value = 130056,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id730] =
{
	Id = 730,
	Name = "支线-小黄的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130056,
		PreGoal = 
		{
			300729,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败风味镇的[FDDE40]小黄[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140218,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id731] =
{
	Id = 731,
	Name = "解锁：香浓镇",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130060,
		PreGoal = 
		{
			300494,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "开启通往高热量的天堂的道路！\n累计拥有[62E7E7]光元素[-][FDDE40]宠物[-]5种",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 5,
			TagList = 
			{
				561205,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 130061,
			Num = 1,
		},
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id732] =
{
	Id = 732,
	Name = "支线-海鲜芝士",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130061,
		PreGoal = 
		{
			300731,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Craft,
	},
	GoalCondition = 
	{
		{
			Name = "在实验室合成获得[FDDE40]海鲜酱[-]10个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 10,
			Value = 321254,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id733] =
{
	Id = 733,
	Name = "支线-光之料理",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130061,
		PreGoal = 
		{
			300732,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计拥有[62E7E7]美食星[-]、[62E7E7]光元素[-][FDDE40]宠物[-]3种",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 3,
			TagList = 
			{
				560104,
				561205,
			},
			Value = -1,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id734] =
{
	Id = 734,
	Name = "支线-浓香四溢的小镇",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130061,
		PreGoal = 
		{
			300733,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "派遣含有[62E7E7]1个[-][62E7E7]紫色及以上品质[-]、[62E7E7]风元素[-]队员(或宠物)的队伍探索美食星[FDDE40]香浓镇[-]18小时",
			Type = ItemType.Time,
			CountType = GoalCountType.StartNow,
			Num = 64800,
			TagList = 
			{
				560034,
				561204,
			},
			CharacterNum = 1,
			Value = 130061,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id735] =
{
	Id = 735,
	Name = "支线-招牌芝士软泥的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130061,
		PreGoal = 
		{
			300734,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败香浓镇的[FDDE40]招牌芝士软泥[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140235,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id736] =
{
	Id = 736,
	Name = "支线-五人份披萨",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130061,
		PreGoal = 
		{
			300735,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有至少[62E7E7]40级[-][FDDE40]角色[-]5个",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 5,
			Value = -1,
			Level = 40,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id737] =
{
	Id = 737,
	Name = "支线-自备芝士",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130061,
		PreGoal = 
		{
			300736,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "累计捕捉宠物[FDDE40]芝士软泥[-]3个(需要超市的空瓶)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 3,
			Value = 250054,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id738] =
{
	Id = 738,
	Name = "支线-芝士大赛",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130061,
		PreGoal = 
		{
			300737,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "如果带上芝士软泥的话应该会轻松很多！\n在探索中获得[FDDE40]芝士[-]40个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 40,
			Value = 321210,
		},
	},
	Reward = {
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id739] =
{
	Id = 739,
	Name = "支线-金牌比撒的挑战",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130061,
		PreGoal = 
		{
			300738,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Challenge,
	},
	GoalCondition = 
	{
		{
			Name = "打败香浓镇的[FDDE40]金牌比撒[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 140236,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id740] =
{
	Id = 740,
	Name = "新配方：红豆冰",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130053,
		PreGoal = 
		{
			300704,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "累的时候来份甜品会有不错的效果哦~~\n提交[FDDE40]冰块[-]15个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 15,
			Value = 321202,
		},
	},
	Reward = {
		{
			Value = 360251,
			Num = 1,
		},
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id741] =
{
	Id = 741,
	Name = "新配方：蛋糕",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130055,
		PreGoal = 
		{
			300424,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "使用牛奶和蛋就能制作松软蛋糕了~\n提交[FDDE40]高标蛋[-]15个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 15,
			Value = 321204,
		},
	},
	Reward = {
		{
			Value = 360252,
			Num = 1,
		},
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id742] =
{
	Id = 742,
	Name = "新配方：米醋",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130058,
		PreGoal = 
		{
			300458,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "需要放段时间才能酿出独特的酸味来~\n提交[FDDE40]料酒[-]15个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 15,
			Value = 321207,
		},
	},
	Reward = {
		{
			Value = 360253,
			Num = 1,
		},
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id743] =
{
	Id = 743,
	Name = "新配方：海鲜酱",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130059,
		PreGoal = 
		{
			300470,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "酱料的发明让很多食物焕然新生！\n提交[FDDE40]海苔[-]15个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 15,
			Value = 321208,
		},
	},
	Reward = {
		{
			Value = 360254,
			Num = 1,
		},
		{
			Value = 330002,
			Num = 1,
		},
		{
			Value = 2,
			Num = 30,
		},
	},
}
GoalConfig[GoalID.Id744] =
{
	Id = 744,
	Name = "地图打卡：鱼之屋",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130052,
		PreGoal = 
		{
			300410,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "秋季来临，镇民们就会在鱼屋里堆起豆沙~\n拥有[FDDE40]豆沙[-]150个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 150,
			Value = 321201,
		},
	},
	Reward = {
		{
			Value = 320042,
			Num = 20,
		},
		{
			Value = 320052,
			Num = 20,
		},
		{
			Value = 1,
			Num = 14000,
		},
	},
}
GoalConfig[GoalID.Id745] =
{
	Id = 745,
	Name = "地图打卡：甜之海",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130053,
		PreGoal = 
		{
			300716,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "呜~~~请注意，前往甜之海的船即将启程~\n提交[FDDE40]牛奶[-]20个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 321203,
		},
	},
	Reward = {
		{
			Value = 320042,
			Num = 30,
		},
		{
			Value = 320052,
			Num = 30,
		},
		{
			Value = 1,
			Num = 17100,
		},
	},
}
GoalConfig[GoalID.Id746] =
{
	Id = 746,
	Name = "地图打卡：风车糖",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130054,
		PreGoal = 
		{
			300421,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "狭道的风带起风车，糖粒被吹入千家万户。\n[62E7E7]一次性[-]在探索中击败[FDDE40]奶小糖[-]16个，建议探索12小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.OneShot,
			Num = 16,
			Value = 242038,
		},
	},
	Reward = {
		{
			Value = 320042,
			Num = 40,
		},
		{
			Value = 320052,
			Num = 40,
		},
		{
			Value = 1,
			Num = 17200,
		},
	},
}
GoalConfig[GoalID.Id747] =
{
	Id = 747,
	Name = "地图打卡：饮料工厂",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130055,
		PreGoal = 
		{
			300436,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "听说，这里的工人每天只要上班5分钟。\n提交[FDDE40]高标蛋[-]20个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 321204,
		},
	},
	Reward = {
		{
			Value = 320042,
			Num = 50,
		},
		{
			Value = 320052,
			Num = 50,
		},
		{
			Value = 1,
			Num = 23400,
		},
	},
}
GoalConfig[GoalID.Id748] =
{
	Id = 748,
	Name = "地图打卡：关东煮",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130056,
		PreGoal = 
		{
			300730,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "我要这个！错啦，不是这个，是左边这个！\n累计捕捉宠物[FDDE40]黑脸鱼子军舰[-]6个(需要道具店的陷阱)",
			Type = ItemType.Pet,
			CountType = GoalCountType.Current,
			Num = 6,
			Value = 250042,
		},
	},
	Reward = {
		{
			Value = 320042,
			Num = 60,
		},
		{
			Value = 320052,
			Num = 60,
		},
		{
			Value = 1,
			Num = 35300,
		},
	},
}
GoalConfig[GoalID.Id749] =
{
	Id = 749,
	Name = "地图打卡：大号饭团",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130057,
		PreGoal = 
		{
			300454,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "请旅客们证明一下自己对米饭的喜爱噢~\n拥有[FDDE40]米饭[-]200个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 200,
			Value = 321206,
		},
	},
	Reward = {
		{
			Value = 320042,
			Num = 70,
		},
		{
			Value = 320052,
			Num = 70,
		},
		{
			Value = 1,
			Num = 22200,
		},
	},
}
GoalConfig[GoalID.Id750] =
{
	Id = 750,
	Name = "地图打卡：高脚火锅",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130058,
		PreGoal = 
		{
			300466,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Craft,
	},
	GoalCondition = 
	{
		{
			Name = "这种锅底啊，一定要搭配油碟和醋的！\n在实验室合成获得[FDDE40]米醋[-]20个",
			Type = ItemType.Goods,
			CountType = GoalCountType.StartNow,
			Num = 20,
			Value = 321253,
		},
	},
	Reward = {
		{
			Value = 320042,
			Num = 80,
		},
		{
			Value = 320052,
			Num = 80,
		},
		{
			Value = 1,
			Num = 30000,
		},
	},
}
GoalConfig[GoalID.Id751] =
{
	Id = 751,
	Name = "地图打卡：寿司拼盘",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130059,
		PreGoal = 
		{
			300482,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "欢迎光临新鲜的寿司自助，海苔请自备噢~\n提交[FDDE40]海苔[-]20个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 20,
			Value = 321208,
		},
	},
	Reward = {
		{
			Value = 320042,
			Num = 90,
		},
		{
			Value = 320052,
			Num = 90,
		},
		{
			Value = 1,
			Num = 27900,
		},
	},
}
GoalConfig[GoalID.Id752] =
{
	Id = 752,
	Name = "地图打卡：国王烤肉",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130060,
		PreGoal = 
		{
			300499,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "这可是经过128道工序制成的顶级火腿噢~\n在探索中击败[FDDE40]火腿猪[-]24个，建议探索22小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 24,
			Value = 242053,
		},
	},
	Reward = {
		{
			Value = 320042,
			Num = 100,
		},
		{
			Value = 320052,
			Num = 100,
		},
		{
			Value = 1,
			Num = 33100,
		},
	},
}
GoalConfig[GoalID.Id753] =
{
	Id = 753,
	Name = "地图打卡：松软堡",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130061,
		PreGoal = 
		{
			300739,
		},
	},
	GoalTrigger = 
	{
		TriggerType.Explore,
	},
	GoalCondition = 
	{
		{
			Name = "先生，您的披萨+20份芝士实在做不了…\n在探索中击败[FDDE40]比撒[-]8个，建议探索23小时以上",
			Type = ItemType.Enemy,
			CountType = GoalCountType.StartNow,
			Num = 8,
			Value = 242055,
		},
	},
	Reward = {
		{
			Value = 320612,
			Num = 1,
		},
		{
			Value = 330003,
			Num = 10,
		},
		{
			Value = 1,
			Num = 59700,
		},
	},
}
GoalConfig[GoalID.Id754] =
{
	Id = 754,
	Name = "支线-收藏家的考验4",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130054,
		PreGoal = 
		{
			300421,
			300350,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "零件配对！阁下仓库里现在有这个吗？\n拥有[FDDE40]强化零件D[-]999个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 999,
			Value = 320041,
		},
	},
	CompleteSpeech = 30075401,
	Reward = {
		{
			Value = 320051,
			Num = 999,
		},
	},
}
GoalConfig[GoalID.Id755] =
{
	Id = 755,
	Name = "支线-收藏家的考验5",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130054,
		PreGoal = 
		{
			300754,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "拥有[FDDE40]强化零件C[-]199个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 199,
			Value = 320042,
		},
	},
	CompleteSpeech = 30075501,
	Reward = {
		{
			Value = 320052,
			Num = 199,
		},
	},
}
GoalConfig[GoalID.Id756] =
{
	Id = 756,
	Name = "支线-收藏家的考验6",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130060,
		PreGoal = 
		{
			300494,
			300755,
		},
	},
	GoalTrigger = 
	{
		TriggerType.SubmitGoods,
	},
	GoalCondition = 
	{
		{
			Name = "吃了可怕的食物，急需美味冰点清理味蕾！\n提交[FDDE40]红豆冰[-]10个",
			Type = ItemType.Goods,
			CountType = GoalCountType.Current,
			Num = 10,
			Value = 321251,
		},
	},
	CompleteSpeech = 30075601,
	Reward = {
		{
			Value = 1,
			Num = 50000,
		},
	},
}
GoalConfig[GoalID.Id757] =
{
	Id = 757,
	Name = "支线-黑暗料理家来袭1",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130054,
		PreGoal = 
		{
			300756,
		},
	},
	GoalTrigger = 
	{
		TriggerType.CollectItem,
	},
	GoalCondition = 
	{
		{
			Name = "如果是榴莲的话，该不会是那个家伙？\n拥有[62E7E7]美食星[-][FDDE40]角色[-]20个",
			Type = ItemType.Character,
			CountType = GoalCountType.Current,
			Num = 20,
			TagList = 
			{
				560104,
			},
			Value = -1,
		},
	},
	CompleteSpeech = 30075701,
	Reward = {
		{
			Value = 330003,
			Num = 2,
		},
		{
			Value = 2,
			Num = 20,
		},
	},
}
GoalConfig[GoalID.Id758] =
{
	Id = 758,
	Name = "支线-黑暗料理家来袭2",
	GoalType = GoalType.Main,
	ShowFirst = false,
	PreCondition = {
		PreArea = 130054,
		PreGoal = 
		{
			300757,
		},
	},
	GoalTrigger = 
	{
		TriggerType.ActivityChallenge,
	},
	GoalCondition = 
	{
		{
			Name = "“嘿嘿嘿嘿，这次就要把你们一网打尽！”\n打败[FDDE40]黑暗料理师[-]",
			Type = ItemType.Challenge,
			CountType = GoalCountType.Current,
			Num = 1,
			Value = 147005,
		},
	},
	CompleteSpeech = 30075801,
	Reward = {
		{
			Value = 320201,
			Num = 500,
		},
		{
			Value = 330003,
			Num = 5,
		},
	},
}
