SpaceTravelDealConfig ={};
SpaceTravelDealID = 
{
	Id001 = 850001,
	Id002 = 850002,
	Id003 = 850003,
	Id004 = 850004,
	Id005 = 850005,
	Id006 = 850006,
	Id007 = 850007,
	Id008 = 850008,
	Id009 = 850009,
	Id010 = 850010,
	Id011 = 850011,
	Id012 = 850012,
}
SpaceTravelDealConfig[SpaceTravelDealID.Id001] =
{
	Id = 1,
	Name = "破旧杂货店",
	ShopIcon = "SpaceTravel_CampEnemy_3",
	ShopName = "潦倒的商人",
	SaleList = {
		{
			Value = 770001,
			Num = 50,
			Price = 100,
		},
		{
			Value = 770101,
			Num = 3,
			Price = 1000,
		},
		{
			Value = 770102,
			Num = 1,
			Price = 2000,
		},
		{
			Value = 770121,
			Num = 3,
			Price = 1000,
		},
		{
			Value = 770122,
			Num = 1,
			Price = 2000,
		},
		{
			Value = 771017,
			Num = 1,
			Price = 500,
		},
		{
			Value = 771016,
			Num = 1,
			Price = 500,
		},
		{
			Value = 770201,
			Num = 1,
			Price = 600,
		},
		{
			Value = 770202,
			Num = 1,
			Price = 600,
		},
		{
			Value = 770205,
			Num = 1,
			Price = 600,
		},
		{
			Value = 773001,
			Num = 1,
			Price = 4800,
		},
		{
			Value = 773006,
			Num = 1,
			Price = 4800,
		},
	},
	TagList = {
		{
			TagId = 561609,
			Abs = 0,
			Percent = -50,
		},
	},
	Dialog = {
		"本店资金充足，客人如果有什么要出售的，请尽快拿来。",
	},
	DealDialog = {
		{
			NeedPrice = 1000,
			Dialog = "很久没看到像你这么爽快的客人了。",
		},
		{
			NeedPrice = 600,
			Dialog = "真的这样成交吗？客人，你实在太大方了！",
		},
		{
			NeedPrice = 200,
			Dialog = "欢迎下次光临~~",
		},
		{
			NeedPrice = 10,
			Dialog = "哎，现在赚点钱真是不容易。",
		},
		{
			NeedPrice = 0,
			Dialog = "没见过像你这么小气的客人，你说行就行吧。",
		},
		{
			NeedPrice = -9999,
			Dialog = "你是来抢劫的？(无法成交)",
		},
	},
	FriendlinessChange = {
		-200,
		200,
	},
	FriendlinessAddValue = 10,
	ProfitMin = 0,
}
SpaceTravelDealConfig[SpaceTravelDealID.Id002] =
{
	Id = 2,
	Name = "联邦商城",
	ShopIcon = "SpaceTravel_CampEnemy_9",
	ShopName = "售货员乙",
	SaleList = {
		{
			Value = 770101,
			Num = 10,
			Price = 1000,
		},
		{
			Value = 770102,
			Num = 10,
			Price = 2000,
		},
		{
			Value = 770103,
			Num = 10,
			Price = 3000,
		},
		{
			Value = 770104,
			Num = 10,
			Price = 4000,
		},
		{
			Value = 770121,
			Num = 10,
			Price = 1000,
		},
		{
			Value = 770122,
			Num = 10,
			Price = 2000,
		},
		{
			Value = 770123,
			Num = 10,
			Price = 3000,
		},
		{
			Value = 770124,
			Num = 10,
			Price = 4000,
		},
		{
			Value = 773001,
			Num = 1,
			Price = 4800,
		},
		{
			Value = 773006,
			Num = 1,
			Price = 4800,
		},
	},
	TagList = {
		{
			TagId = 561609,
			Abs = 0,
			Percent = -100,
		},
	},
	Dialog = {
		"小店只接受发条噢~喜欢什么还请随便看看~",
	},
	DealDialog = {
		{
			NeedPrice = 1000,
			Dialog = "很久没看到像你这么爽快的客人了。",
		},
		{
			NeedPrice = 600,
			Dialog = "真的这样成交吗？客人，你实在太大方了！",
		},
		{
			NeedPrice = 200,
			Dialog = "欢迎下次光临~~",
		},
		{
			NeedPrice = 10,
			Dialog = "哎，现在赚点钱真是不容易。",
		},
		{
			NeedPrice = 0,
			Dialog = "没见过像你这么小气的客人，你说行就行吧。",
		},
		{
			NeedPrice = -9999,
			Dialog = "你是来抢劫的？(无法成交)",
		},
	},
	FriendlinessChange = {
		-200,
		200,
	},
	FriendlinessAddValue = 10,
	ProfitMin = 0,
}
SpaceTravelDealConfig[SpaceTravelDealID.Id003] =
{
	Id = 3,
	Name = "魔王商城",
	FriendlinessId = 780001,
	ShopIcon = "SpaceTravel_CampEnemy_1",
	ShopName = "骨头兵接待员",
	SaleList = {
		{
			Value = 770001,
			Num = 50,
			Price = 100,
		},
		{
			Value = 770101,
			Num = 3,
			Price = 1000,
		},
		{
			Value = 770102,
			Num = 1,
			Price = 2000,
		},
		{
			Value = 770121,
			Num = 3,
			Price = 1000,
		},
		{
			Value = 770122,
			Num = 1,
			Price = 2000,
		},
		{
			Value = 771017,
			Num = 1,
			Price = 500,
		},
		{
			Value = 771016,
			Num = 1,
			Price = 500,
		},
		{
			Value = 770201,
			Num = 1,
			Price = 600,
		},
		{
			Value = 770202,
			Num = 1,
			Price = 600,
		},
		{
			Value = 770205,
			Num = 1,
			Price = 600,
		},
		{
			Value = 770206,
			Num = 1,
			Price = 600,
		},
		{
			Value = 773011,
			Num = 1,
			Price = 4000,
		},
	},
	TagList = {
		{
			TagId = 561609,
			Abs = 0,
			Percent = -50,
		},
		{
			TagId = 561647,
			Abs = 0,
			Percent = 50,
		},
	},
	Dialog = {
		"小店急需矿石，如果能把矿石带来，小店会额外作价的。",
	},
	DealDialog = {
		{
			NeedPrice = 1000,
			Dialog = "很久没看到像大人这么爽快的客人了。(声望 {Value})",
		},
		{
			NeedPrice = 600,
			Dialog = "真的这样成交吗？大人，您实在太大方了！(声望 {Value})",
		},
		{
			NeedPrice = 200,
			Dialog = "大人真是爽快啊，欢迎下次光临~~(声望{Value})",
		},
		{
			NeedPrice = 10,
			Dialog = "大人肯让点利润给小的们，那是最好啦。(声望{Value})",
		},
		{
			NeedPrice = 0,
			Dialog = "虽然能成交，不过大人真的一点小费也不给吗？(声望{Value})",
		},
		{
			NeedPrice = -9999,
			Dialog = "大人，这不太合适吧？(无法成交)",
		},
	},
	FriendlinessChange = {
		-200,
		200,
	},
	FriendlinessAddValue = 10,
	ProfitMin = 0,
}
SpaceTravelDealConfig[SpaceTravelDealID.Id004] =
{
	Id = 4,
	Name = "魔王商城",
	FriendlinessId = 780001,
	ShopIcon = "SpaceTravel_CampEnemy_1",
	ShopName = "骨头兵接待员",
	SaleList = {
		{
			Value = 770001,
			Num = 500,
			Price = 90,
		},
		{
			Value = 770101,
			Num = 3,
			Price = 900,
		},
		{
			Value = 770102,
			Num = 1,
			Price = 1800,
		},
		{
			Value = 770121,
			Num = 3,
			Price = 900,
		},
		{
			Value = 770122,
			Num = 1,
			Price = 1800,
		},
		{
			Value = 771017,
			Num = 1,
			Price = 450,
		},
		{
			Value = 771016,
			Num = 1,
			Price = 450,
		},
		{
			Value = 770201,
			Num = 1,
			Price = 540,
		},
		{
			Value = 770202,
			Num = 1,
			Price = 540,
		},
		{
			Value = 770205,
			Num = 1,
			Price = 540,
		},
		{
			Value = 770206,
			Num = 1,
			Price = 540,
		},
		{
			Value = 773011,
			Num = 1,
			Price = 3000,
		},
	},
	TagList = {
		{
			TagId = 561609,
			Abs = 0,
			Percent = -50,
		},
		{
			TagId = 561647,
			Abs = 0,
			Percent = 50,
		},
	},
	Dialog = {
		"鉴于阁下是VIP客户，价格上会给予优惠的。",
		"小店急需矿石，如果能把矿石带来，小店会额外作价的。",
	},
	DealDialog = {
		{
			NeedPrice = 1000,
			Dialog = "很久没看到像大人这么爽快的客人了。(声望 {Value})",
		},
		{
			NeedPrice = 600,
			Dialog = "真的这样成交吗？大人，您实在太大方了！(声望 {Value})",
		},
		{
			NeedPrice = 200,
			Dialog = "大人真是爽快啊，欢迎下次光临~~(声望{Value})",
		},
		{
			NeedPrice = 10,
			Dialog = "大人肯让点利润给小的们，那是最好啦。(声望{Value})",
		},
		{
			NeedPrice = 0,
			Dialog = "虽然能成交，不过大人真的一点小费也不给吗？(声望{Value})",
		},
		{
			NeedPrice = -9999,
			Dialog = "大人，这不太合适吧？(无法成交)",
		},
	},
	FriendlinessChange = {
		-200,
		200,
	},
	FriendlinessAddValue = 10,
	ProfitMin = -100,
}
SpaceTravelDealConfig[SpaceTravelDealID.Id005] =
{
	Id = 5,
	Name = "冒险家商城",
	FriendlinessId = 780002,
	ShopIcon = "SpaceTravel_CampEnemy_2",
	ShopName = "带货的冒险家",
	SaleList = {
		{
			Value = 770001,
			Num = 50,
			Price = 100,
		},
		{
			Value = 770101,
			Num = 3,
			Price = 1000,
		},
		{
			Value = 770102,
			Num = 1,
			Price = 2000,
		},
		{
			Value = 770121,
			Num = 3,
			Price = 1000,
		},
		{
			Value = 770122,
			Num = 1,
			Price = 2000,
		},
		{
			Value = 771017,
			Num = 1,
			Price = 500,
		},
		{
			Value = 771016,
			Num = 1,
			Price = 500,
		},
		{
			Value = 770201,
			Num = 1,
			Price = 600,
		},
		{
			Value = 770202,
			Num = 1,
			Price = 600,
		},
		{
			Value = 770205,
			Num = 1,
			Price = 600,
		},
		{
			Value = 770206,
			Num = 1,
			Price = 600,
		},
		{
			Value = 773001,
			Num = 1,
			Price = 4000,
		},
	},
	TagList = {
		{
			TagId = 561609,
			Abs = 0,
			Percent = -50,
		},
		{
			TagId = 561647,
			Abs = 0,
			Percent = 50,
		},
	},
	Dialog = {
		"小店急需矿石，如果能把矿石带来，小店会额外作价的。",
	},
	DealDialog = {
		{
			NeedPrice = 1000,
			Dialog = "很久没看到像你这么爽快的客人了。(声望 {Value})",
		},
		{
			NeedPrice = 600,
			Dialog = "真的这样成交吗？客人，你实在太大方了！(声望 {Value})",
		},
		{
			NeedPrice = 200,
			Dialog = "客人真是爽快啊，欢迎下次光临~~(声望{Value})",
		},
		{
			NeedPrice = 10,
			Dialog = "客人肯让点利润给小店，那是最好啦。(声望{Value})",
		},
		{
			NeedPrice = 0,
			Dialog = "银货两讫了，不过阁下真的是小气啊！(声望{Value})",
		},
		{
			NeedPrice = -9999,
			Dialog = "就这样也想成交，别逼我找人打你哦！(无法成交)",
		},
	},
	FriendlinessChange = {
		-200,
		200,
	},
	FriendlinessAddValue = 10,
	ProfitMin = 0,
}
SpaceTravelDealConfig[SpaceTravelDealID.Id006] =
{
	Id = 6,
	Name = "冒险家商城",
	FriendlinessId = 780002,
	ShopIcon = "SpaceTravel_CampEnemy_2",
	ShopName = "带货的冒险家",
	SaleList = {
		{
			Value = 770001,
			Num = 500,
			Price = 90,
		},
		{
			Value = 770101,
			Num = 3,
			Price = 900,
		},
		{
			Value = 770102,
			Num = 1,
			Price = 1800,
		},
		{
			Value = 770121,
			Num = 3,
			Price = 900,
		},
		{
			Value = 770122,
			Num = 1,
			Price = 1800,
		},
		{
			Value = 771017,
			Num = 1,
			Price = 450,
		},
		{
			Value = 771016,
			Num = 1,
			Price = 450,
		},
		{
			Value = 770201,
			Num = 1,
			Price = 540,
		},
		{
			Value = 770202,
			Num = 1,
			Price = 540,
		},
		{
			Value = 770205,
			Num = 1,
			Price = 540,
		},
		{
			Value = 770206,
			Num = 1,
			Price = 540,
		},
		{
			Value = 773001,
			Num = 1,
			Price = 3000,
		},
	},
	TagList = {
		{
			TagId = 561609,
			Abs = 0,
			Percent = -50,
		},
		{
			TagId = 561647,
			Abs = 0,
			Percent = 50,
		},
	},
	Dialog = {
		"鉴于阁下是VIP客户，价格上会给予优惠的。",
		"小店急需矿石，如果能把矿石带来，小店会额外作价的。",
	},
	DealDialog = {
		{
			NeedPrice = 1000,
			Dialog = "很久没看到像你这么爽快的客人了。(声望 {Value})",
		},
		{
			NeedPrice = 600,
			Dialog = "真的这样成交吗？客人，你实在太大方了！(声望 {Value})",
		},
		{
			NeedPrice = 200,
			Dialog = "客人真是爽快啊，欢迎下次光临~~(声望{Value})",
		},
		{
			NeedPrice = 10,
			Dialog = "客人肯让点利润给小店，那是最好啦。(声望{Value})",
		},
		{
			NeedPrice = 0,
			Dialog = "银货两讫了，不过阁下真的是小气啊！(声望{Value})",
		},
		{
			NeedPrice = -9999,
			Dialog = "就这样也想成交，别逼我找人打你哦！(无法成交)",
		},
	},
	FriendlinessChange = {
		-200,
		200,
	},
	FriendlinessAddValue = 10,
	ProfitMin = -100,
}
SpaceTravelDealConfig[SpaceTravelDealID.Id007] =
{
	Id = 7,
	Name = "破旧杂货店",
	ShopIcon = "SpaceTravel_CampEnemy_3",
	ShopName = "潦倒的商人",
	SaleList = {
		{
			Value = 770001,
			Num = 50,
			Price = 100,
		},
		{
			Value = 770101,
			Num = 3,
			Price = 1000,
		},
		{
			Value = 770102,
			Num = 1,
			Price = 2000,
		},
		{
			Value = 770121,
			Num = 3,
			Price = 1000,
		},
		{
			Value = 770122,
			Num = 1,
			Price = 2000,
		},
		{
			Value = 771017,
			Num = 1,
			Price = 500,
		},
		{
			Value = 770201,
			Num = 1,
			Price = 600,
		},
		{
			Value = 770202,
			Num = 1,
			Price = 600,
		},
		{
			Value = 770205,
			Num = 1,
			Price = 600,
		},
		{
			Value = 773001,
			Num = 1,
			Price = 4800,
		},
		{
			Value = 773006,
			Num = 1,
			Price = 4800,
		},
	},
	TagList = {
		{
			TagId = 561609,
			Abs = 0,
			Percent = -50,
		},
	},
	Dialog = {
		"本店资金充足，客人如果有什么要出售的，请尽快拿来。",
	},
	DealDialog = {
		{
			NeedPrice = 1000,
			Dialog = "很久没看到像你这么爽快的客人了。",
		},
		{
			NeedPrice = 600,
			Dialog = "真的这样成交吗？客人，你实在太大方了！",
		},
		{
			NeedPrice = 200,
			Dialog = "欢迎下次光临~~",
		},
		{
			NeedPrice = 10,
			Dialog = "哎，现在赚点钱真是不容易。",
		},
		{
			NeedPrice = 0,
			Dialog = "没见过像你这么小气的客人，你说行就行吧。",
		},
		{
			NeedPrice = -9999,
			Dialog = "你是来抢劫的？(无法成交)",
		},
	},
	FriendlinessChange = {
		-200,
		200,
	},
	FriendlinessAddValue = 10,
	ProfitMin = 0,
}
SpaceTravelDealConfig[SpaceTravelDealID.Id008] =
{
	Id = 8,
	Name = "联邦商城",
	ShopIcon = "SpaceTravel_CampEnemy_9",
	ShopName = "售货员乙",
	SaleList = {
		{
			Value = 770101,
			Num = 10,
			Price = 1000,
		},
		{
			Value = 770102,
			Num = 10,
			Price = 2000,
		},
		{
			Value = 770121,
			Num = 10,
			Price = 1000,
		},
		{
			Value = 770122,
			Num = 10,
			Price = 2000,
		},
		{
			Value = 771016,
			Num = 1,
			Price = 500,
		},
		{
			Value = 773001,
			Num = 1,
			Price = 4800,
		},
		{
			Value = 773006,
			Num = 1,
			Price = 4800,
		},
	},
	TagList = {
		{
			TagId = 561609,
			Abs = 0,
			Percent = -100,
		},
	},
	Dialog = {
		"小店只接受发条噢~喜欢什么还请随便看看~",
	},
	DealDialog = {
		{
			NeedPrice = 1000,
			Dialog = "很久没看到像你这么爽快的客人了。",
		},
		{
			NeedPrice = 600,
			Dialog = "真的这样成交吗？客人，你实在太大方了！",
		},
		{
			NeedPrice = 200,
			Dialog = "欢迎下次光临~~",
		},
		{
			NeedPrice = 10,
			Dialog = "哎，现在赚点钱真是不容易。",
		},
		{
			NeedPrice = 0,
			Dialog = "没见过像你这么小气的客人，你说行就行吧。",
		},
		{
			NeedPrice = -9999,
			Dialog = "你是来抢劫的？(无法成交)",
		},
	},
	FriendlinessChange = {
		-200,
		200,
	},
	FriendlinessAddValue = 10,
	ProfitMin = 0,
}
SpaceTravelDealConfig[SpaceTravelDealID.Id009] =
{
	Id = 9,
	Name = "魔王商城",
	FriendlinessId = 780001,
	ShopIcon = "SpaceTravel_CampEnemy_1",
	ShopName = "骨头兵接待员",
	SaleList = {
		{
			Value = 770001,
			Num = 50,
			Price = 100,
		},
		{
			Value = 770101,
			Num = 3,
			Price = 1000,
		},
		{
			Value = 770102,
			Num = 1,
			Price = 2000,
		},
		{
			Value = 770121,
			Num = 3,
			Price = 1000,
		},
		{
			Value = 770122,
			Num = 1,
			Price = 2000,
		},
		{
			Value = 771017,
			Num = 1,
			Price = 500,
		},
		{
			Value = 771016,
			Num = 1,
			Price = 500,
		},
		{
			Value = 770301,
			Num = 1,
			Price = 10,
		},
		{
			Value = 773011,
			Num = 1,
			Price = 4000,
		},
	},
	TagList = {
		{
			TagId = 561609,
			Abs = 0,
			Percent = -50,
		},
		{
			TagId = 561647,
			Abs = 0,
			Percent = 50,
		},
	},
	Dialog = {
		"小店急需矿石，如果能把矿石带来，小店会额外作价的。",
	},
	DealDialog = {
		{
			NeedPrice = 1000,
			Dialog = "很久没看到像大人这么爽快的客人了。(声望 {Value})",
		},
		{
			NeedPrice = 600,
			Dialog = "真的这样成交吗？大人，您实在太大方了！(声望 {Value})",
		},
		{
			NeedPrice = 200,
			Dialog = "大人真是爽快啊，欢迎下次光临~~(声望{Value})",
		},
		{
			NeedPrice = 10,
			Dialog = "大人肯让点利润给小的们，那是最好啦。(声望{Value})",
		},
		{
			NeedPrice = 0,
			Dialog = "虽然能成交，不过大人真的一点小费也不给吗？(声望{Value})",
		},
		{
			NeedPrice = -9999,
			Dialog = "大人，这不太合适吧？(无法成交)",
		},
	},
	FriendlinessChange = {
		-200,
		200,
	},
	FriendlinessAddValue = 10,
	ProfitMin = 0,
}
SpaceTravelDealConfig[SpaceTravelDealID.Id010] =
{
	Id = 10,
	Name = "魔王商城",
	FriendlinessId = 780001,
	ShopIcon = "SpaceTravel_CampEnemy_1",
	ShopName = "骨头兵接待员",
	SaleList = {
	},
	TagList = {
		{
			TagId = 561609,
			Abs = 0,
			Percent = -50,
		},
		{
			TagId = 561647,
			Abs = 0,
			Percent = 50,
		},
	},
	Dialog = {
		"鉴于阁下是VIP客户，价格上会给予优惠的。",
		"小店急需矿石，如果能把矿石带来，小店会额外作价的。",
	},
	DealDialog = {
		{
			NeedPrice = 1000,
			Dialog = "很久没看到像大人这么爽快的客人了。(声望 {Value})",
		},
		{
			NeedPrice = 600,
			Dialog = "真的这样成交吗？大人，您实在太大方了！(声望 {Value})",
		},
		{
			NeedPrice = 200,
			Dialog = "大人真是爽快啊，欢迎下次光临~~(声望{Value})",
		},
		{
			NeedPrice = 10,
			Dialog = "大人肯让点利润给小的们，那是最好啦。(声望{Value})",
		},
		{
			NeedPrice = 0,
			Dialog = "虽然能成交，不过大人真的一点小费也不给吗？(声望{Value})",
		},
		{
			NeedPrice = -9999,
			Dialog = "大人，这不太合适吧？(无法成交)",
		},
	},
	FriendlinessChange = {
		-200,
		200,
	},
	FriendlinessAddValue = 10,
	ProfitMin = -100,
}
SpaceTravelDealConfig[SpaceTravelDealID.Id011] =
{
	Id = 11,
	Name = "冒险家商城",
	FriendlinessId = 780002,
	ShopIcon = "SpaceTravel_CampEnemy_2",
	ShopName = "带货的冒险家",
	SaleList = {
		{
			Value = 770001,
			Num = 50,
			Price = 100,
		},
		{
			Value = 770101,
			Num = 3,
			Price = 1000,
		},
		{
			Value = 770102,
			Num = 1,
			Price = 2000,
		},
		{
			Value = 770121,
			Num = 3,
			Price = 1000,
		},
		{
			Value = 770122,
			Num = 1,
			Price = 2000,
		},
		{
			Value = 770202,
			Num = 1,
			Price = 600,
		},
		{
			Value = 770205,
			Num = 1,
			Price = 600,
		},
		{
			Value = 770304,
			Num = 1,
			Price = 10,
		},
		{
			Value = 773001,
			Num = 1,
			Price = 4000,
		},
	},
	TagList = {
		{
			TagId = 561609,
			Abs = 0,
			Percent = -50,
		},
		{
			TagId = 561647,
			Abs = 0,
			Percent = 50,
		},
	},
	Dialog = {
		"小店急需矿石，如果能把矿石带来，小店会额外作价的。",
	},
	DealDialog = {
		{
			NeedPrice = 1000,
			Dialog = "很久没看到像你这么爽快的客人了。(声望 {Value})",
		},
		{
			NeedPrice = 600,
			Dialog = "真的这样成交吗？客人，你实在太大方了！(声望 {Value})",
		},
		{
			NeedPrice = 200,
			Dialog = "客人真是爽快啊，欢迎下次光临~~(声望{Value})",
		},
		{
			NeedPrice = 10,
			Dialog = "客人肯让点利润给小店，那是最好啦。(声望{Value})",
		},
		{
			NeedPrice = 0,
			Dialog = "银货两讫了，不过阁下真的是小气啊！(声望{Value})",
		},
		{
			NeedPrice = -9999,
			Dialog = "就这样也想成交，别逼我找人打你哦！(无法成交)",
		},
	},
	FriendlinessChange = {
		-200,
		200,
	},
	FriendlinessAddValue = 10,
	ProfitMin = 0,
}
SpaceTravelDealConfig[SpaceTravelDealID.Id012] =
{
	Id = 12,
	Name = "冒险家商城",
	FriendlinessId = 780002,
	ShopIcon = "SpaceTravel_CampEnemy_2",
	ShopName = "带货的冒险家",
	SaleList = {
		{
			Value = 770001,
			Num = 50,
			Price = 90,
		},
		{
			Value = 770101,
			Num = 3,
			Price = 900,
		},
		{
			Value = 770102,
			Num = 1,
			Price = 1800,
		},
		{
			Value = 770121,
			Num = 3,
			Price = 900,
		},
		{
			Value = 770122,
			Num = 1,
			Price = 1800,
		},
		{
			Value = 770202,
			Num = 1,
			Price = 540,
		},
		{
			Value = 770205,
			Num = 1,
			Price = 540,
		},
		{
			Value = 770304,
			Num = 1,
			Price = 9,
		},
		{
			Value = 773001,
			Num = 1,
			Price = 3600,
		},
	},
	TagList = {
		{
			TagId = 561609,
			Abs = 0,
			Percent = -50,
		},
		{
			TagId = 561647,
			Abs = 0,
			Percent = 50,
		},
	},
	Dialog = {
		"鉴于阁下是VIP客户，价格上会给予优惠的。",
		"小店急需矿石，如果能把矿石带来，小店会额外作价的。",
	},
	DealDialog = {
		{
			NeedPrice = 1000,
			Dialog = "很久没看到像你这么爽快的客人了。(声望 {Value})",
		},
		{
			NeedPrice = 600,
			Dialog = "真的这样成交吗？客人，你实在太大方了！(声望 {Value})",
		},
		{
			NeedPrice = 200,
			Dialog = "客人真是爽快啊，欢迎下次光临~~(声望{Value})",
		},
		{
			NeedPrice = 10,
			Dialog = "客人肯让点利润给小店，那是最好啦。(声望{Value})",
		},
		{
			NeedPrice = 0,
			Dialog = "银货两讫了，不过阁下真的是小气啊！(声望{Value})",
		},
		{
			NeedPrice = -9999,
			Dialog = "就这样也想成交，别逼我找人打你哦！(无法成交)",
		},
	},
	FriendlinessChange = {
		-200,
		200,
	},
	FriendlinessAddValue = 10,
	ProfitMin = -100,
}
