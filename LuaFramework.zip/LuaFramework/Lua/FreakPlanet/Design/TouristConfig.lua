TouristConfig ={};
TouristID = 
{
	Id001 = 430001,
	Id002 = 430002,
	Id003 = 430003,
	Id004 = 430004,
	Id005 = 430005,
	Id006 = 430006,
	Id007 = 430007,
	Id008 = 430008,
	Id009 = 430009,
	Id010 = 430010,
	Id011 = 430011,
	Id012 = 430012,
	Id013 = 430013,
	Id014 = 430014,
	Id015 = 430015,
	Id016 = 430016,
	Id017 = 430017,
	Id018 = 430018,
	Id019 = 430019,
	Id020 = 430020,
	Id021 = 430021,
	Id022 = 430022,
	Id023 = 430023,
	Id024 = 430024,
	Id025 = 430025,
	Id026 = 430026,
	Id027 = 430027,
	Id028 = 430028,
	Id029 = 430029,
	Id030 = 430030,
	Id031 = 430031,
}
TouristConfig[TouristID.Id001] =
{
	Id = 1,
	Name = "外星观光团1",
	Desc = "即将招待来自冒险星的观光团，客人们希望能看到新奇的稀有生物！",
	PreChallenge = 
	{
		140201,
	},
	Weight = 1000,
	ResultText = "稀有指数",
	TagList = {
		{
			Value = 560203,
			Score = 60,
			LevelScore = 12,
		},
		{
			Value = 560103,
			Score = -25,
			LevelScore = 5,
		},
		{
			Value = 560026,
			Score = 50,
			LevelScore = 10,
		},
		{
			Value = 560025,
			Score = 40,
			LevelScore = 8,
		},
		{
			Value = 560024,
			Score = 30,
			LevelScore = 6,
		},
		{
			Value = 560023,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 560022,
			Score = 10,
			LevelScore = 2,
		},
	},
	RewardList = {
		{
			Score = 800,
			ResultText = "太棒了！",
			RewardList = {
				{
					Value = 2,
					Num = 100,
				},
				{
					Value = 1,
					Num = 30000,
				},
			},
		},
		{
			Score = 600,
			ResultText = "非常好~",
			RewardList = {
				{
					Value = 2,
					Num = 75,
				},
				{
					Value = 1,
					Num = 25000,
				},
			},
		},
		{
			Score = 400,
			ResultText = "不错诶！",
			RewardList = {
				{
					Value = 2,
					Num = 50,
				},
				{
					Value = 1,
					Num = 20000,
				},
			},
		},
		{
			Score = 200,
			ResultText = "很一般…",
			RewardList = {
				{
					Value = 2,
					Num = 30,
				},
				{
					Value = 1,
					Num = 15000,
				},
			},
		},
		{
			Score = -1000,
			ResultText = "什么鬼！！",
			RewardList = {
				{
					Value = 2,
					Num = 10,
				},
				{
					Value = 1,
					Num = 10000,
				},
			},
		},
	},
	RankTextList = {
		{
			CommentatorName = "博物馆馆长",
			CommentatorInfo = "关注：53 粉丝：181.0万",
			BadgeIcon = {
				"TouristBadge_1",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_13",
			DescList = {
				{
					NeedScore = 500,
					Desc = "如果让我为自己经历过最美妙的事情写下记录，那么一定就是这一次观光冒险了~",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "精灵公主",
			CommentatorInfo = "关注：13 粉丝：179.4万",
			BadgeIcon = {
				"TouristBadge_2",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_4",
			DescList = {
				{
					NeedScore = 500,
					Desc = "难以置信竟然能一次性看到这么多不可思议的生物！",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "剑圣",
			CommentatorInfo = "关注：92 粉丝：122.2万",
			BadgeIcon = {
				"TouristBadge_3",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_3",
			DescList = {
				{
					NeedScore = 500,
					Desc = "即使以专业的眼光来看，也是一次很优秀的演出~",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "前任女王",
			CommentatorInfo = "关注：63 粉丝：486.5万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_2",
			DescList = {
				{
					NeedScore = 500,
					Desc = "对于我这种不太出来的人而言，实在是很不错的体验。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "骑士团长",
			CommentatorInfo = "关注：92 粉丝：183.1万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_5",
			DescList = {
				{
					NeedScore = 500,
					Desc = "呼！原来还有这样的怪物，如果不是看了表演，完全不知道呢！",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "魔王的妹妹",
			CommentatorInfo = "关注：29 粉丝：244.5万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_6",
			DescList = {
				{
					NeedScore = 500,
					Desc = "一直在魔界城堡，每天都是看那些怪物，挺没劲的，忽然看到这么多怪物真是高兴啊~",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "一言堂大师",
			CommentatorInfo = "关注：61 粉丝：291.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_14",
			DescList = {
				{
					NeedScore = 500,
					Desc = "如果怪物不是新奇有趣的，在下一定一锤敲醒组织者。不过这次在下只有一句话，精彩又给力！",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "收藏家D先生",
			CommentatorInfo = "关注：75 粉丝：461.8万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_17",
			DescList = {
				{
					NeedScore = 500,
					Desc = "啊，都是新奇的生物，真希望带两只回去，使本人的收藏变得更丰富。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "网红小浣熊",
			CommentatorInfo = "关注：39 粉丝：327.8万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_18",
			DescList = {
				{
					NeedScore = 500,
					Desc = "哇~太厉害了~~一下子见到了这么多罕见的怪物呼~~",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "假释的怪盗先生",
			CommentatorInfo = "关注：29 粉丝：205.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_16",
			DescList = {
				{
					NeedScore = 500,
					Desc = "这是一次很快乐的旅程，能够和这么多有趣的生物打交道，整个人都觉得很放松。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
	},
}
TouristConfig[TouristID.Id002] =
{
	Id = 2,
	Name = "外星观光团2",
	Desc = "即将招待怕冷的观光者，客人们希望能看到热乎乎的生物！",
	PreChallenge = 
	{
		140029,
	},
	Weight = 1000,
	ResultText = "火热指数",
	TagList = {
		{
			Value = 563406,
			Score = 90,
			LevelScore = 18,
		},
		{
			Value = 563405,
			Score = 70,
			LevelScore = 14,
		},
		{
			Value = 563404,
			Score = 30,
			LevelScore = 6,
		},
		{
			Value = 563403,
			Score = 0,
			LevelScore = 1,
		},
		{
			Value = 563402,
			Score = -20,
			LevelScore = 4,
		},
		{
			Value = 560026,
			Score = 35,
			LevelScore = 7,
		},
		{
			Value = 560025,
			Score = 30,
			LevelScore = 6,
		},
		{
			Value = 560024,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 560023,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 560022,
			Score = 15,
			LevelScore = 3,
		},
	},
	RewardList = {
		{
			Score = 800,
			ResultText = "太棒了！",
			RewardList = {
				{
					Value = 2,
					Num = 100,
				},
				{
					Value = 1,
					Num = 30000,
				},
			},
		},
		{
			Score = 600,
			ResultText = "非常好~",
			RewardList = {
				{
					Value = 2,
					Num = 75,
				},
				{
					Value = 1,
					Num = 25000,
				},
			},
		},
		{
			Score = 400,
			ResultText = "不错诶！",
			RewardList = {
				{
					Value = 2,
					Num = 50,
				},
				{
					Value = 1,
					Num = 20000,
				},
			},
		},
		{
			Score = 200,
			ResultText = "很一般…",
			RewardList = {
				{
					Value = 2,
					Num = 30,
				},
				{
					Value = 1,
					Num = 15000,
				},
			},
		},
		{
			Score = -1000,
			ResultText = "什么鬼！！",
			RewardList = {
				{
					Value = 2,
					Num = 10,
				},
				{
					Value = 1,
					Num = 10000,
				},
			},
		},
	},
	RankTextList = {
		{
			CommentatorName = "精灵公主",
			CommentatorInfo = "关注：13 粉丝：179.4万",
			BadgeIcon = {
				"TouristBadge_1",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_4",
			DescList = {
				{
					NeedScore = 500,
					Desc = "哇~观光的过程中似乎感受到了恒星般的温暖，太棒了！",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "前任女王",
			CommentatorInfo = "关注：63 粉丝：486.5万",
			BadgeIcon = {
				"TouristBadge_2",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_2",
			DescList = {
				{
					NeedScore = 500,
					Desc = "以我在高温区生活了50年的经验来看，这次的观光值得满分。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "魔王的妹妹",
			CommentatorInfo = "关注：29 粉丝：244.5万",
			BadgeIcon = {
				"TouristBadge_3",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_6",
			DescList = {
				{
					NeedScore = 500,
					Desc = "完全没有寒冷感，连毛孔里都透出了热气~",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "酒乡的醉先生",
			CommentatorInfo = "关注：24 粉丝：182.5万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_7",
			DescList = {
				{
					NeedScore = 500,
					Desc = "啊，热乎乎的，太舒服了~~",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "米其森主评委",
			CommentatorInfo = "关注：100 粉丝：229.4万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_8",
			DescList = {
				{
					NeedScore = 500,
					Desc = "可能是因为胃寒的关系，最近一直喜欢暖洋洋的感觉。看到这个观光团以后，一下子就觉得胃舒畅了起来。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "米其森副评委",
			CommentatorInfo = "关注：11 粉丝：437.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_9",
			DescList = {
				{
					NeedScore = 500,
					Desc = "如主任所言，胃寒就会感到全身不适，虽然本人没有胃部问题，但是看到暖洋洋的表演，也感到非常舒服。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "顶级大厨",
			CommentatorInfo = "关注：65 粉丝：160.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_10",
			DescList = {
				{
					NeedScore = 500,
					Desc = "食物就要趁热吃才能感受到100%的美味。像今天这样热乎乎的表演，就让本人非常赞赏。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "奇迹的蛋糕师",
			CommentatorInfo = "关注：50 粉丝：453.7万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_11",
			DescList = {
				{
					NeedScore = 500,
					Desc = "如同火焰一般散发出了热量，啊！有灵感了！我要做一款熔岩火山蛋糕，让所有人都吃到喷出热气的蛋糕。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "卖系统的盖茨比",
			CommentatorInfo = "关注：78 粉丝：407.4万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_24",
			DescList = {
				{
					NeedScore = 500,
					Desc = "虽然住在寒冷地区，但是其实本人喜欢的是热乎乎的感觉，看了今天的表演后，本人决定换两只能让房子热乎乎的宠物。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "艺术少女",
			CommentatorInfo = "关注：16 粉丝：440.0万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_19",
			DescList = {
				{
					NeedScore = 500,
					Desc = "虽然四季各有其美妙之处。不过本人独爱夏日的酷热，那样才能正大光明地穿泳衣。其实今天也穿了好看的泳衣来看表演噢~",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
	},
}
TouristConfig[TouristID.Id003] =
{
	Id = 3,
	Name = "外星观光团3",
	Desc = "即将招待机械爱好者，客人们希望这次观光充满机械的稀有感觉！",
	PreChallenge = 
	{
		140401,
	},
	Weight = 1000,
	ResultText = "科技指数",
	TagList = {
		{
			Value = 564056,
			Score = 100,
			LevelScore = 20,
		},
		{
			Value = 564055,
			Score = 80,
			LevelScore = 16,
		},
		{
			Value = 564054,
			Score = 60,
			LevelScore = 12,
		},
		{
			Value = 564053,
			Score = 40,
			LevelScore = 8,
		},
		{
			Value = 564052,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 560026,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 560025,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 560024,
			Score = 15,
			LevelScore = 3,
		},
		{
			Value = 560023,
			Score = 10,
			LevelScore = 2,
		},
		{
			Value = 560022,
			Score = 5,
			LevelScore = 1,
		},
		{
			Value = 564051,
			Score = -25,
			LevelScore = 5,
		},
		{
			Value = 564050,
			Score = -20,
			LevelScore = 4,
		},
		{
			Value = 564049,
			Score = -15,
			LevelScore = 3,
		},
		{
			Value = 564048,
			Score = -10,
			LevelScore = 2,
		},
		{
			Value = 564047,
			Score = -5,
			LevelScore = 1,
		},
	},
	RewardList = {
		{
			Score = 800,
			ResultText = "太棒了！",
			RewardList = {
				{
					Value = 2,
					Num = 100,
				},
				{
					Value = 1,
					Num = 30000,
				},
			},
		},
		{
			Score = 600,
			ResultText = "非常好~",
			RewardList = {
				{
					Value = 2,
					Num = 75,
				},
				{
					Value = 1,
					Num = 25000,
				},
			},
		},
		{
			Score = 400,
			ResultText = "不错诶！",
			RewardList = {
				{
					Value = 2,
					Num = 50,
				},
				{
					Value = 1,
					Num = 20000,
				},
			},
		},
		{
			Score = 200,
			ResultText = "很一般…",
			RewardList = {
				{
					Value = 2,
					Num = 30,
				},
				{
					Value = 1,
					Num = 15000,
				},
			},
		},
		{
			Score = -1000,
			ResultText = "什么鬼！！",
			RewardList = {
				{
					Value = 2,
					Num = 10,
				},
				{
					Value = 1,
					Num = 10000,
				},
			},
		},
	},
	RankTextList = {
		{
			CommentatorName = "卖系统的盖茨比",
			CommentatorInfo = "关注：78 粉丝：407.4万",
			BadgeIcon = {
				"TouristBadge_1",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_24",
			DescList = {
				{
					NeedScore = 500,
					Desc = "充满了机械设计感，真是一次完美的观光体验！",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "天使投资王少爷",
			CommentatorInfo = "关注：59 粉丝：455.6万",
			BadgeIcon = {
				"TouristBadge_2",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_25",
			DescList = {
				{
					NeedScore = 500,
					Desc = "齿轮，液压杆，联动结构，实在是太完美了！",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "一言堂大师",
			CommentatorInfo = "关注：61 粉丝：291.6万",
			BadgeIcon = {
				"TouristBadge_3",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_14",
			DescList = {
				{
					NeedScore = 500,
					Desc = "如此合理的设计，在别的地方是绝对看不到的。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "收藏家D先生",
			CommentatorInfo = "关注：75 粉丝：461.8万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_17",
			DescList = {
				{
					NeedScore = 500,
					Desc = "如果下次还有这样的观光，请务必让我再次参加！",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "网红小浣熊",
			CommentatorInfo = "关注：39 粉丝：327.8万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_18",
			DescList = {
				{
					NeedScore = 500,
					Desc = "虽然不是很懂得机械结构，但是小浣熊完全被这些齿轮结构吸引了。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "假释的怪盗先生",
			CommentatorInfo = "关注：29 粉丝：205.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_16",
			DescList = {
				{
					NeedScore = 500,
					Desc = "唔，非常精密的结构，真是不由得让鄙人再次感叹上帝造物之神奇，令我们找到了如此可靠的机械。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "退休警察局长",
			CommentatorInfo = "关注：10 粉丝：279.4万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_20",
			DescList = {
				{
					NeedScore = 500,
					Desc = "机械设备运作时，请所有人务必远离，如果夹到衣物也请不要慌张，尽快向附近工作人员求助。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "企鹅岛的马先生",
			CommentatorInfo = "关注：17 粉丝：208.2万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_23",
			DescList = {
				{
					NeedScore = 500,
					Desc = "世界的发展果然离不开人类的智慧，如果没有这些发明，我们又能走多远呢？",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "骑士团长",
			CommentatorInfo = "关注：92 粉丝：183.1万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_5",
			DescList = {
				{
					NeedScore = 500,
					Desc = "无论时代如何进步，在下都不会放弃手中的长枪和胯下的战马，让我们继续向着征途前进吧！",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "怕辣的美食博主",
			CommentatorInfo = "关注：22 粉丝：333.2万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_12",
			DescList = {
				{
					NeedScore = 500,
					Desc = "哇，齿轮一直咔哧咔哧作响呢，太有意思了！",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
	},
}
TouristConfig[TouristID.Id004] =
{
	Id = 4,
	Name = "外星观光团4",
	Desc = "即将招待喜欢动物的观光团，如果能看到有活力的动物们一定会很开心！",
	PreChallenge = 
	{
		140029,
	},
	Weight = 1000,
	ResultText = "活力指数",
	TagList = {
		{
			Value = 561303,
			Score = 60,
			LevelScore = 12,
		},
		{
			Value = 564016,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 564015,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 564014,
			Score = 15,
			LevelScore = 3,
		},
		{
			Value = 564013,
			Score = 10,
			LevelScore = 2,
		},
		{
			Value = 564012,
			Score = 5,
			LevelScore = 1,
		},
		{
			Value = 563206,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 563205,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 563204,
			Score = 15,
			LevelScore = 3,
		},
		{
			Value = 563203,
			Score = 10,
			LevelScore = 2,
		},
		{
			Value = 563202,
			Score = 5,
			LevelScore = 1,
		},
		{
			Value = 564146,
			Score = -25,
			LevelScore = 5,
		},
		{
			Value = 564145,
			Score = -20,
			LevelScore = 4,
		},
		{
			Value = 564144,
			Score = -15,
			LevelScore = 3,
		},
		{
			Value = 564143,
			Score = -10,
			LevelScore = 2,
		},
		{
			Value = 564142,
			Score = -5,
			LevelScore = 1,
		},
		{
			Value = 564056,
			Score = -25,
			LevelScore = 5,
		},
		{
			Value = 564055,
			Score = -20,
			LevelScore = 4,
		},
		{
			Value = 564054,
			Score = -15,
			LevelScore = 3,
		},
		{
			Value = 564053,
			Score = -10,
			LevelScore = 2,
		},
		{
			Value = 564052,
			Score = -5,
			LevelScore = 1,
		},
	},
	RewardList = {
		{
			Score = 800,
			ResultText = "太棒了！",
			RewardList = {
				{
					Value = 2,
					Num = 100,
				},
				{
					Value = 1,
					Num = 30000,
				},
			},
		},
		{
			Score = 600,
			ResultText = "非常好~",
			RewardList = {
				{
					Value = 2,
					Num = 75,
				},
				{
					Value = 1,
					Num = 25000,
				},
			},
		},
		{
			Score = 400,
			ResultText = "不错诶！",
			RewardList = {
				{
					Value = 2,
					Num = 50,
				},
				{
					Value = 1,
					Num = 20000,
				},
			},
		},
		{
			Score = 200,
			ResultText = "很一般…",
			RewardList = {
				{
					Value = 2,
					Num = 30,
				},
				{
					Value = 1,
					Num = 15000,
				},
			},
		},
		{
			Score = -1000,
			ResultText = "什么鬼！！",
			RewardList = {
				{
					Value = 2,
					Num = 10,
				},
				{
					Value = 1,
					Num = 10000,
				},
			},
		},
	},
	RankTextList = {
		{
			CommentatorName = "艺术少女",
			CommentatorInfo = "关注：16 粉丝：440.0万",
			BadgeIcon = {
				"TouristBadge_1",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_19",
			DescList = {
				{
					NeedScore = 500,
					Desc = "哇，毛茸茸软乎乎，太可爱了~",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "骑士团长",
			CommentatorInfo = "关注：92 粉丝：183.1万",
			BadgeIcon = {
				"TouristBadge_2",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_5",
			DescList = {
				{
					NeedScore = 500,
					Desc = "虽然平时在生活中是一个铁血硬汉，但是看到这么多美丽的生物我还是落下泪来。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "前任女王",
			CommentatorInfo = "关注：63 粉丝：486.5万",
			BadgeIcon = {
				"TouristBadge_3",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_2",
			DescList = {
				{
					NeedScore = 500,
					Desc = "哇，如果能够领养的话就太好了~~",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "博物馆馆长",
			CommentatorInfo = "关注：53 粉丝：181.0万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_13",
			DescList = {
				{
					NeedScore = 500,
					Desc = "这是大自然赐给我们的礼物呢~",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "网红小浣熊",
			CommentatorInfo = "关注：39 粉丝：327.8万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_18",
			DescList = {
				{
					NeedScore = 500,
					Desc = "唔~~是小动物呢~~~好想和它们一起玩~~",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "米其森主评委",
			CommentatorInfo = "关注：100 粉丝：229.4万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_8",
			DescList = {
				{
					NeedScore = 500,
					Desc = "嗯，很少和活的小动物打交道，看到它们的一刹那感觉身心都被治愈了。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "米其森副评委",
			CommentatorInfo = "关注：11 粉丝：437.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_9",
			DescList = {
				{
					NeedScore = 500,
					Desc = "如主任所言，这是一次完美的动物观光表演，不过动物们的味道不太好闻。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "阿里山的马先生",
			CommentatorInfo = "关注：86 粉丝：160.0万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_22",
			DescList = {
				{
					NeedScore = 500,
					Desc = "想起了小时候和同伴们一起追赶隔壁邻居家的小动物，真是快乐的回忆啊。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "收藏家D先生",
			CommentatorInfo = "关注：75 粉丝：461.8万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_17",
			DescList = {
				{
					NeedScore = 500,
					Desc = "嗯，细腻柔滑的毛发，完美的皮毛，忽然间有想收集动物的欲望了。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "顶级大厨",
			CommentatorInfo = "关注：65 粉丝：160.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_10",
			DescList = {
				{
					NeedScore = 500,
					Desc = "只有尊重动物，才能制作出最顶级的料理！",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
	},
}
TouristConfig[TouristID.Id005] =
{
	Id = 5,
	Name = "外星观光团5",
	Desc = "即将招待冒险协会观光团，怪物太没有威胁性是不行的！",
	PreChallenge = 
	{
		140029,
	},
	Weight = 1000,
	ResultText = "危险指数",
	TagList = {
		{
			Value = 564031,
			Score = 55,
			LevelScore = 11,
		},
		{
			Value = 564030,
			Score = 45,
			LevelScore = 9,
		},
		{
			Value = 564029,
			Score = 35,
			LevelScore = 7,
		},
		{
			Value = 564028,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 564027,
			Score = 15,
			LevelScore = 3,
		},
		{
			Value = 563206,
			Score = 30,
			LevelScore = 6,
		},
		{
			Value = 563205,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 563204,
			Score = 10,
			LevelScore = 2,
		},
		{
			Value = 563203,
			Score = 0,
			LevelScore = 1,
		},
		{
			Value = 563202,
			Score = -10,
			LevelScore = 2,
		},
		{
			Value = 560026,
			Score = 55,
			LevelScore = 11,
		},
		{
			Value = 560025,
			Score = 45,
			LevelScore = 9,
		},
		{
			Value = 560024,
			Score = 35,
			LevelScore = 7,
		},
		{
			Value = 560023,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 560022,
			Score = 15,
			LevelScore = 3,
		},
		{
			Value = 564021,
			Score = -35,
			LevelScore = 7,
		},
		{
			Value = 564020,
			Score = -30,
			LevelScore = 6,
		},
		{
			Value = 564019,
			Score = -25,
			LevelScore = 5,
		},
		{
			Value = 564018,
			Score = -20,
			LevelScore = 4,
		},
		{
			Value = 564017,
			Score = -15,
			LevelScore = 3,
		},
	},
	RewardList = {
		{
			Score = 800,
			ResultText = "太棒了！",
			RewardList = {
				{
					Value = 2,
					Num = 100,
				},
				{
					Value = 1,
					Num = 30000,
				},
			},
		},
		{
			Score = 600,
			ResultText = "非常好~",
			RewardList = {
				{
					Value = 2,
					Num = 75,
				},
				{
					Value = 1,
					Num = 25000,
				},
			},
		},
		{
			Score = 400,
			ResultText = "不错诶！",
			RewardList = {
				{
					Value = 2,
					Num = 50,
				},
				{
					Value = 1,
					Num = 20000,
				},
			},
		},
		{
			Score = 200,
			ResultText = "很一般…",
			RewardList = {
				{
					Value = 2,
					Num = 30,
				},
				{
					Value = 1,
					Num = 15000,
				},
			},
		},
		{
			Score = -1000,
			ResultText = "什么鬼！！",
			RewardList = {
				{
					Value = 2,
					Num = 10,
				},
				{
					Value = 1,
					Num = 10000,
				},
			},
		},
	},
	RankTextList = {
		{
			CommentatorName = "剑圣",
			CommentatorInfo = "关注：92 粉丝：122.2万",
			BadgeIcon = {
				"TouristBadge_1",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_3",
			DescList = {
				{
					NeedScore = 500,
					Desc = "呼，看到怪物的一刹那，就不自觉地拔出了手中的剑，感觉太棒了。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "酒乡的醉先生",
			CommentatorInfo = "关注：24 粉丝：182.5万",
			BadgeIcon = {
				"TouristBadge_2",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_7",
			DescList = {
				{
					NeedScore = 500,
					Desc = "原来这就是boss级敌人的威严，太精彩了！",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "亲切的历史学者",
			CommentatorInfo = "关注：90 粉丝：269.0万",
			BadgeIcon = {
				"TouristBadge_3",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_15",
			DescList = {
				{
					NeedScore = 500,
					Desc = "怀着忐忑的心情报了这个观光团，虽然中途就吓晕了，但是活动效果真的非常棒！",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "精灵公主",
			CommentatorInfo = "关注：13 粉丝：179.4万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_4",
			DescList = {
				{
					NeedScore = 500,
					Desc = "哇，好多稀有敌人，隔着安全栏看，感觉就是不一样啊~",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "魔王的妹妹",
			CommentatorInfo = "关注：29 粉丝：244.5万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_6",
			DescList = {
				{
					NeedScore = 500,
					Desc = "呼，虽然经常在哥哥的城堡里看到，但总觉得今天的比平时的更精彩。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "骑士团长",
			CommentatorInfo = "关注：92 粉丝：183.1万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_5",
			DescList = {
				{
					NeedScore = 500,
					Desc = "呼哈！就是这样的魔物，鄙人生存的价值就是从这些魔物之中救出贫民百姓啊！",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "博物馆馆长",
			CommentatorInfo = "关注：53 粉丝：181.0万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_13",
			DescList = {
				{
					NeedScore = 500,
					Desc = "演出过程中，观众们一言不发，看来都已经被吓到了。博物馆里是不是也应该引进类似的展出品呢？",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "退休警察局长",
			CommentatorInfo = "关注：10 粉丝：279.4万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_20",
			DescList = {
				{
					NeedScore = 500,
					Desc = "在生活中遇到歹徒对你进行威胁时，切勿冲动，安抚歹徒，在确认自身安全后尽快报警。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "米其森主评委",
			CommentatorInfo = "关注：100 粉丝：229.4万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_8",
			DescList = {
				{
					NeedScore = 500,
					Desc = "哇哦，看得吓出了一身汗，等会要多吃两碗饭补补身体了。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "米其森副评委",
			CommentatorInfo = "关注：11 粉丝：437.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_9",
			DescList = {
				{
					NeedScore = 500,
					Desc = "呼！如主任所言，真的是很惊人的演出，在下全程不敢说一句话，生怕被怪物盯住呢。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
	},
}
TouristConfig[TouristID.Id006] =
{
	Id = 6,
	Name = "外星观光团6",
	Desc = "即将招待无精打采的观光团，希望看到有活力跑得快的生物！",
	PreChallenge = 
	{
		140029,
	},
	Weight = 1000,
	ResultText = "高速指数",
	TagList = {
		{
			Value = 564016,
			Score = 60,
			LevelScore = 12,
		},
		{
			Value = 564015,
			Score = 50,
			LevelScore = 10,
		},
		{
			Value = 564014,
			Score = 40,
			LevelScore = 8,
		},
		{
			Value = 564013,
			Score = 30,
			LevelScore = 6,
		},
		{
			Value = 564012,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 563206,
			Score = 60,
			LevelScore = 12,
		},
		{
			Value = 563205,
			Score = 50,
			LevelScore = 10,
		},
		{
			Value = 563204,
			Score = 40,
			LevelScore = 8,
		},
		{
			Value = 563203,
			Score = 30,
			LevelScore = 6,
		},
		{
			Value = 563202,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 564006,
			Score = -40,
			LevelScore = 8,
		},
		{
			Value = 564005,
			Score = -35,
			LevelScore = 7,
		},
		{
			Value = 564004,
			Score = -30,
			LevelScore = 6,
		},
		{
			Value = 564003,
			Score = -25,
			LevelScore = 5,
		},
		{
			Value = 564002,
			Score = -20,
			LevelScore = 4,
		},
	},
	RewardList = {
		{
			Score = 800,
			ResultText = "太棒了！",
			RewardList = {
				{
					Value = 2,
					Num = 100,
				},
				{
					Value = 1,
					Num = 30000,
				},
			},
		},
		{
			Score = 600,
			ResultText = "非常好~",
			RewardList = {
				{
					Value = 2,
					Num = 75,
				},
				{
					Value = 1,
					Num = 25000,
				},
			},
		},
		{
			Score = 400,
			ResultText = "不错诶！",
			RewardList = {
				{
					Value = 2,
					Num = 50,
				},
				{
					Value = 1,
					Num = 20000,
				},
			},
		},
		{
			Score = 200,
			ResultText = "很一般…",
			RewardList = {
				{
					Value = 2,
					Num = 30,
				},
				{
					Value = 1,
					Num = 15000,
				},
			},
		},
		{
			Score = -1000,
			ResultText = "什么鬼！！",
			RewardList = {
				{
					Value = 2,
					Num = 10,
				},
				{
					Value = 1,
					Num = 10000,
				},
			},
		},
	},
	RankTextList = {
		{
			CommentatorName = "退休警察局长",
			CommentatorInfo = "关注：10 粉丝：279.4万",
			BadgeIcon = {
				"TouristBadge_1",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_20",
			DescList = {
				{
					NeedScore = 500,
					Desc = "趁着放假时间来观光，本以为是些无聊把戏，不成想如同观看了一场赛车比赛一般，太刺激了。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "酒乡的醉先生",
			CommentatorInfo = "关注：24 粉丝：182.5万",
			BadgeIcon = {
				"TouristBadge_2",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_7",
			DescList = {
				{
					NeedScore = 500,
					Desc = "唯一的缺点是，快得我根本看不清。不过，鄙人所追求的就是这样的感觉。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "骑士团长",
			CommentatorInfo = "关注：92 粉丝：183.1万",
			BadgeIcon = {
				"TouristBadge_3",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_5",
			DescList = {
				{
					NeedScore = 500,
					Desc = "精神为之一振，感觉如同被打了强心针一般。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "博物馆馆长",
			CommentatorInfo = "关注：53 粉丝：181.0万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_13",
			DescList = {
				{
					NeedScore = 500,
					Desc = "看着怪物跑动，能感到自己的心脏在胸腔里“咚咚”狂跳，整个人都有活力了。(还是心血管疾病加剧了呢？)",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "假释的怪盗先生",
			CommentatorInfo = "关注：29 粉丝：205.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_16",
			DescList = {
				{
					NeedScore = 500,
					Desc = "竟然有速度足以与鄙人比肩的生物，真是一趟不容小觑的演出啊。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "剑圣",
			CommentatorInfo = "关注：92 粉丝：122.2万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_3",
			DescList = {
				{
					NeedScore = 500,
					Desc = "那只最快的动物似乎比鄙人的剑十三式更快，看来在下还要继续苦练剑技。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "怕辣的美食博主",
			CommentatorInfo = "关注：22 粉丝：333.2万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_12",
			DescList = {
				{
					NeedScore = 500,
					Desc = "哈哈哈~~~就好像屁股着了火一样在飞速奔跑呢，想起来在下吃了辣椒后找水喝的样子了。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "阿里山的马先生",
			CommentatorInfo = "关注：86 粉丝：160.0万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_22",
			DescList = {
				{
					NeedScore = 500,
					Desc = "竟然有这么快的速度，我觉得我们物流公司应该考虑训练这些宠物来送快递！",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "顶级大厨",
			CommentatorInfo = "关注：65 粉丝：160.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_10",
			DescList = {
				{
					NeedScore = 500,
					Desc = "哇，哇，哇，简直可以和在下的光速切菜的节拍对上了，太厉害了~",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "亲切的历史学者",
			CommentatorInfo = "关注：90 粉丝：269.0万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_15",
			DescList = {
				{
					NeedScore = 500,
					Desc = "一切都在飞速地奔跑着，就如同历史前进的脚步，永远都在飞速前进着。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
	},
}
TouristConfig[TouristID.Id007] =
{
	Id = 7,
	Name = "外星观光团7",
	Desc = "即将招待吸猫爱好者们，对于猫科或毛茸茸的生物没有抵抗能力！",
	PreChallenge = 
	{
		140601,
	},
	Weight = 0,
	ResultText = "猫猫指数",
	TagList = {
		{
			Value = 561346,
			Score = 100,
			LevelScore = 20,
		},
		{
			Value = 563706,
			Score = 50,
			LevelScore = 10,
		},
		{
			Value = 563705,
			Score = 50,
			LevelScore = 10,
		},
		{
			Value = 563704,
			Score = 40,
			LevelScore = 10,
		},
		{
			Value = 563703,
			Score = 30,
			LevelScore = 10,
		},
		{
			Value = 563702,
			Score = 20,
			LevelScore = 10,
		},
		{
			Value = 563811,
			Score = -50,
			LevelScore = 5,
		},
		{
			Value = 563810,
			Score = -40,
			LevelScore = 5,
		},
		{
			Value = 563809,
			Score = -30,
			LevelScore = 5,
		},
		{
			Value = 563808,
			Score = -20,
			LevelScore = 5,
		},
		{
			Value = 563807,
			Score = -10,
			LevelScore = 5,
		},
	},
	RewardList = {
		{
			Score = 800,
			ResultText = "太棒了！",
			RewardList = {
				{
					Value = 2,
					Num = 100,
				},
				{
					Value = 1,
					Num = 30000,
				},
			},
		},
		{
			Score = 600,
			ResultText = "非常好~",
			RewardList = {
				{
					Value = 2,
					Num = 75,
				},
				{
					Value = 1,
					Num = 25000,
				},
			},
		},
		{
			Score = 400,
			ResultText = "不错诶！",
			RewardList = {
				{
					Value = 2,
					Num = 50,
				},
				{
					Value = 1,
					Num = 20000,
				},
			},
		},
		{
			Score = 200,
			ResultText = "很一般…",
			RewardList = {
				{
					Value = 2,
					Num = 30,
				},
				{
					Value = 1,
					Num = 15000,
				},
			},
		},
		{
			Score = -1000,
			ResultText = "什么鬼！！",
			RewardList = {
				{
					Value = 2,
					Num = 10,
				},
				{
					Value = 1,
					Num = 10000,
				},
			},
		},
	},
	RankTextList = {
		{
			CommentatorName = "艺术少女",
			CommentatorInfo = "关注：16 粉丝：440.0万",
			BadgeIcon = {
				"TouristBadge_1",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_19",
			DescList = {
				{
					NeedScore = 500,
					Desc = "毛茸茸的，太可爱了，我要晕倒了！",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "亲切的历史学者",
			CommentatorInfo = "关注：90 粉丝：269.0万",
			BadgeIcon = {
				"TouristBadge_2",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_15",
			DescList = {
				{
					NeedScore = 500,
					Desc = "优雅的体态，灵动的身姿，太完美了。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "精灵公主",
			CommentatorInfo = "关注：13 粉丝：179.4万",
			BadgeIcon = {
				"TouristBadge_3",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_4",
			DescList = {
				{
					NeedScore = 500,
					Desc = "光是爪子上的爱心肉垫我就可以看一年。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "前任女王",
			CommentatorInfo = "关注：63 粉丝：486.5万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_2",
			DescList = {
				{
					NeedScore = 500,
					Desc = "唔！尾巴竖起来了，两只眼睛正看着我呢，太棒了！",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "网红小浣熊",
			CommentatorInfo = "关注：39 粉丝：327.8万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_18",
			DescList = {
				{
					NeedScore = 500,
					Desc = "系统默认好评",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "骑士团长",
			CommentatorInfo = "关注：92 粉丝：183.1万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_5",
			DescList = {
				{
					NeedScore = 500,
					Desc = "系统默认好评",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "顶级大厨",
			CommentatorInfo = "关注：65 粉丝：160.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_10",
			DescList = {
				{
					NeedScore = 500,
					Desc = "系统默认好评",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "怕辣的美食博主",
			CommentatorInfo = "关注：22 粉丝：333.2万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_12",
			DescList = {
				{
					NeedScore = 500,
					Desc = "系统默认好评",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "假释的怪盗先生",
			CommentatorInfo = "关注：29 粉丝：205.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_16",
			DescList = {
				{
					NeedScore = 500,
					Desc = "系统默认好评",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "退休警察局长",
			CommentatorInfo = "关注：10 粉丝：279.4万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_20",
			DescList = {
				{
					NeedScore = 500,
					Desc = "系统默认好评",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
	},
}
TouristConfig[TouristID.Id008] =
{
	Id = 8,
	Name = "外星观光团8",
	Desc = "即将招待绿化爱好者们，客人们希望看到富有生机的绿色植物！",
	Weight = 1000,
	ResultText = "生机指数",
	TagList = {
		{
			Value = 561320,
			Score = 25,
			LevelScore = 12,
		},
		{
			Value = 564146,
			Score = 30,
			LevelScore = 10,
		},
		{
			Value = 564145,
			Score = 25,
			LevelScore = 8,
		},
		{
			Value = 564144,
			Score = 20,
			LevelScore = 6,
		},
		{
			Value = 564143,
			Score = 15,
			LevelScore = 5,
		},
		{
			Value = 564142,
			Score = 10,
			LevelScore = 3,
		},
		{
			Value = 563941,
			Score = 20,
			LevelScore = 10,
		},
		{
			Value = 563940,
			Score = 16,
			LevelScore = 8,
		},
		{
			Value = 563939,
			Score = 12,
			LevelScore = 6,
		},
		{
			Value = 563938,
			Score = 8,
			LevelScore = 4,
		},
		{
			Value = 563937,
			Score = 4,
			LevelScore = 2,
		},
		{
			Value = 564051,
			Score = 20,
			LevelScore = 10,
		},
		{
			Value = 564050,
			Score = 16,
			LevelScore = 8,
		},
		{
			Value = 564049,
			Score = 12,
			LevelScore = 6,
		},
		{
			Value = 564048,
			Score = 8,
			LevelScore = 4,
		},
		{
			Value = 564047,
			Score = 4,
			LevelScore = 2,
		},
		{
			Value = 561321,
			Score = -50,
			LevelScore = 5,
		},
		{
			Value = 561303,
			Score = -50,
			LevelScore = 5,
		},
	},
	RewardList = {
		{
			Score = 800,
			ResultText = "太棒了！",
			RewardList = {
				{
					Value = 2,
					Num = 100,
				},
				{
					Value = 1,
					Num = 30000,
				},
			},
		},
		{
			Score = 600,
			ResultText = "非常好~",
			RewardList = {
				{
					Value = 2,
					Num = 75,
				},
				{
					Value = 1,
					Num = 25000,
				},
			},
		},
		{
			Score = 400,
			ResultText = "不错诶！",
			RewardList = {
				{
					Value = 2,
					Num = 50,
				},
				{
					Value = 1,
					Num = 20000,
				},
			},
		},
		{
			Score = 200,
			ResultText = "很一般…",
			RewardList = {
				{
					Value = 2,
					Num = 30,
				},
				{
					Value = 1,
					Num = 15000,
				},
			},
		},
		{
			Score = -1000,
			ResultText = "什么鬼！！",
			RewardList = {
				{
					Value = 2,
					Num = 10,
				},
				{
					Value = 1,
					Num = 10000,
				},
			},
		},
	},
	RankTextList = {
		{
			CommentatorName = "米其森副评委",
			CommentatorInfo = "关注：11 粉丝：437.6万",
			BadgeIcon = {
				"TouristBadge_1",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_9",
			DescList = {
				{
					NeedScore = 500,
					Desc = "绿油油的一大片，感觉整个人都放松了下来。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "阿里山的马先生",
			CommentatorInfo = "关注：86 粉丝：160.0万",
			BadgeIcon = {
				"TouristBadge_2",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_22",
			DescList = {
				{
					NeedScore = 500,
					Desc = "平时生活在繁忙的都市里，根本看不到绿化，这次感觉补充了一年份的活力。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "博物馆馆长",
			CommentatorInfo = "关注：53 粉丝：181.0万",
			BadgeIcon = {
				"TouristBadge_3",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_13",
			DescList = {
				{
					NeedScore = 500,
					Desc = "虽然本人也是植物学家，不过看到这些植物被照顾得如此出色，还是非常感动。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "顶级大厨",
			CommentatorInfo = "关注：65 粉丝：160.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_10",
			DescList = {
				{
					NeedScore = 500,
					Desc = "看到这些宠物，我打算回去好好养些花草了。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "网红小浣熊",
			CommentatorInfo = "关注：39 粉丝：327.8万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_18",
			DescList = {
				{
					NeedScore = 500,
					Desc = "哇~~重新回到大自然了~~一直在人类世界生活的小浣熊都有点不习惯了呢~",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "俏江北餐饮董事",
			CommentatorInfo = "关注：46 粉丝：473.9万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_21",
			DescList = {
				{
					NeedScore = 500,
					Desc = "本餐饮集团最近正隆重推出斋菜套餐，在下强烈建议不忍杀生的人士尝试一下~",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "退休警察局长",
			CommentatorInfo = "关注：10 粉丝：279.4万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_20",
			DescList = {
				{
					NeedScore = 500,
					Desc = "退休以后就学别人在家里养养花花草草，本来以为养得不错，看了今天的表演，才知道家里那些只能算杂草。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "魔王的妹妹",
			CommentatorInfo = "关注：29 粉丝：244.5万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_6",
			DescList = {
				{
					NeedScore = 500,
					Desc = "和哥哥城堡里红色基调的豪华装饰相比，我还是更喜欢绿色的自然风格。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "艺术少女",
			CommentatorInfo = "关注：16 粉丝：440.0万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_19",
			DescList = {
				{
					NeedScore = 500,
					Desc = "每当我没有灵感时，就会通过美丽的自然风光放松心情。今天的表演给了我一整年份的放松心情，感谢~",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "奇迹的蛋糕师",
			CommentatorInfo = "关注：50 粉丝：453.7万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_11",
			DescList = {
				{
					NeedScore = 500,
					Desc = "灵感来了！！就是这个，大自然气息的美味蛋糕，含有微微的植物苦味，但是一定能让客人们重新认识世界。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
	},
}
TouristConfig[TouristID.Id009] =
{
	Id = 9,
	Name = "外星观光团9",
	Desc = "即将招待来自怪味料理爱好者们，客人们喜欢看起来像黑暗料理的宠物~",
	Weight = 1000,
	ResultText = "怪味指数",
	TagList = {
		{
			Value = 561340,
			Score = 30,
			LevelScore = 6,
		},
		{
			Value = 563616,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 563615,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 563614,
			Score = 15,
			LevelScore = 3,
		},
		{
			Value = 563613,
			Score = 10,
			LevelScore = 2,
		},
		{
			Value = 563612,
			Score = 5,
			LevelScore = 1,
		},
		{
			Value = 563611,
			Score = 30,
			LevelScore = 6,
		},
		{
			Value = 563610,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 563609,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 563608,
			Score = 15,
			LevelScore = 3,
		},
		{
			Value = 563607,
			Score = 10,
			LevelScore = 2,
		},
		{
			Value = 563711,
			Score = 30,
			LevelScore = 6,
		},
		{
			Value = 563710,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 563709,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 563708,
			Score = 15,
			LevelScore = 3,
		},
		{
			Value = 563707,
			Score = 10,
			LevelScore = 2,
		},
		{
			Value = 564106,
			Score = 100,
			LevelScore = 25,
		},
		{
			Value = 564105,
			Score = 60,
			LevelScore = 15,
		},
		{
			Value = 564104,
			Score = 50,
			LevelScore = 12,
		},
		{
			Value = 564103,
			Score = 40,
			LevelScore = 10,
		},
		{
			Value = 564102,
			Score = 30,
			LevelScore = 7,
		},
		{
			Value = 564151,
			Score = 30,
			LevelScore = 6,
		},
		{
			Value = 564150,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 564149,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 564148,
			Score = 15,
			LevelScore = 3,
		},
		{
			Value = 564147,
			Score = 10,
			LevelScore = 2,
		},
		{
			Value = 564026,
			Score = 70,
			LevelScore = 17,
		},
		{
			Value = 564025,
			Score = 60,
			LevelScore = 15,
		},
		{
			Value = 564024,
			Score = 50,
			LevelScore = 12,
		},
		{
			Value = 564023,
			Score = 40,
			LevelScore = 10,
		},
		{
			Value = 564022,
			Score = 30,
			LevelScore = 7,
		},
		{
			Value = 564171,
			Score = 70,
			LevelScore = 17,
		},
		{
			Value = 564170,
			Score = 60,
			LevelScore = 15,
		},
		{
			Value = 564169,
			Score = 50,
			LevelScore = 12,
		},
		{
			Value = 564168,
			Score = 40,
			LevelScore = 10,
		},
		{
			Value = 564167,
			Score = 30,
			LevelScore = 7,
		},
		{
			Value = 563816,
			Score = 30,
			LevelScore = 6,
		},
		{
			Value = 563815,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 563814,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 563813,
			Score = 15,
			LevelScore = 3,
		},
		{
			Value = 563812,
			Score = 10,
			LevelScore = 2,
		},
		{
			Value = 561306,
			Score = 0,
			LevelScore = 5,
		},
	},
	RewardList = {
		{
			Score = 800,
			ResultText = "太棒了！",
			RewardList = {
				{
					Value = 2,
					Num = 100,
				},
				{
					Value = 1,
					Num = 30000,
				},
			},
		},
		{
			Score = 600,
			ResultText = "非常好~",
			RewardList = {
				{
					Value = 2,
					Num = 75,
				},
				{
					Value = 1,
					Num = 25000,
				},
			},
		},
		{
			Score = 400,
			ResultText = "不错诶！",
			RewardList = {
				{
					Value = 2,
					Num = 50,
				},
				{
					Value = 1,
					Num = 20000,
				},
			},
		},
		{
			Score = 200,
			ResultText = "很一般…",
			RewardList = {
				{
					Value = 2,
					Num = 30,
				},
				{
					Value = 1,
					Num = 15000,
				},
			},
		},
		{
			Score = -1000,
			ResultText = "什么鬼！！",
			RewardList = {
				{
					Value = 2,
					Num = 10,
				},
				{
					Value = 1,
					Num = 10000,
				},
			},
		},
	},
	RankTextList = {
		{
			CommentatorName = "米其森主评委",
			CommentatorInfo = "关注：100 粉丝：229.4万",
			BadgeIcon = {
				"TouristBadge_1",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_8",
			DescList = {
				{
					NeedScore = 500,
					Desc = "听说有专门参观怪味料理的旅行团，原本不抱有任何期望，不过真正看到时才发现原来食物也可以这样。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "魔王的妹妹",
			CommentatorInfo = "关注：29 粉丝：244.5万",
			BadgeIcon = {
				"TouristBadge_2",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_6",
			DescList = {
				{
					NeedScore = 500,
					Desc = "啊，都是怪怪的气味，好像回到了老家的魔王城堡了~~真是让人怀念啊~",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "怕辣的美食博主",
			CommentatorInfo = "关注：22 粉丝：333.2万",
			BadgeIcon = {
				"TouristBadge_3",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_12",
			DescList = {
				{
					NeedScore = 500,
					Desc = "虽然不能吃辣，但是看到这些奇奇怪怪的东西却食欲大增。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "骑士团长",
			CommentatorInfo = "关注：92 粉丝：183.1万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_5",
			DescList = {
				{
					NeedScore = 500,
					Desc = "抱着修炼嗅觉及味觉的心情参加此次观光团，旅行过程中的确得到了很大的历练。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "酒乡的醉先生",
			CommentatorInfo = "关注：24 粉丝：182.5万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_7",
			DescList = {
				{
					NeedScore = 500,
					Desc = "呼！这个味道…真是绝了！酒一下子就醒了。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "艺术少女",
			CommentatorInfo = "关注：16 粉丝：440.0万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_19",
			DescList = {
				{
					NeedScore = 500,
					Desc = "听说审美到了最后就是审丑，感觉美味也是如此。这次闻到的味道让我对香味有了新的认识。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "顶级大厨",
			CommentatorInfo = "关注：65 粉丝：160.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_10",
			DescList = {
				{
					NeedScore = 500,
					Desc = "虽然大家只闻到了奇怪的气味，不过我却从中感受到了新的美味！",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "奇迹的蛋糕师",
			CommentatorInfo = "关注：50 粉丝：453.7万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_11",
			DescList = {
				{
					NeedScore = 500,
					Desc = "如前辈所言，我也有了新的灵感！",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "退休警察局长",
			CommentatorInfo = "关注：10 粉丝：279.4万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_20",
			DescList = {
				{
					NeedScore = 500,
					Desc = "让人没有食欲的味道，最适合给正在减肥时期的我了。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "收藏家D先生",
			CommentatorInfo = "关注：75 粉丝：461.8万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_17",
			DescList = {
				{
					NeedScore = 500,
					Desc = "这种独特的收藏一定能凸显收藏家独特的品味，这次的观光让我非常满意。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
	},
}
TouristConfig[TouristID.Id010] =
{
	Id = 10,
	Name = "外星观光团10",
	Desc = "即将招待新康复的色盲患者们，客人们希望看到五彩缤纷的宠物们。",
	Weight = 1000,
	ResultText = "缤纷指数",
	TagList = {
		{
			Value = 563506,
			Score = 75,
			LevelScore = 15,
		},
		{
			Value = 563505,
			Score = 55,
			LevelScore = 11,
		},
		{
			Value = 563504,
			Score = 35,
			LevelScore = 7,
		},
		{
			Value = 563503,
			Score = 15,
			LevelScore = 3,
		},
		{
			Value = 563502,
			Score = -5,
			LevelScore = 1,
		},
		{
			Value = 563921,
			Score = 35,
			LevelScore = 7,
		},
		{
			Value = 563920,
			Score = 30,
			LevelScore = 6,
		},
		{
			Value = 563919,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 563918,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 563917,
			Score = 15,
			LevelScore = 3,
		},
		{
			Value = 563941,
			Score = 35,
			LevelScore = 7,
		},
		{
			Value = 563940,
			Score = 30,
			LevelScore = 6,
		},
		{
			Value = 563939,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 563938,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 563937,
			Score = 15,
			LevelScore = 3,
		},
		{
			Value = 563936,
			Score = 35,
			LevelScore = 7,
		},
		{
			Value = 563935,
			Score = 30,
			LevelScore = 6,
		},
		{
			Value = 563934,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 563933,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 563932,
			Score = 15,
			LevelScore = 3,
		},
		{
			Value = 563931,
			Score = -25,
			LevelScore = 8,
		},
		{
			Value = 563930,
			Score = -20,
			LevelScore = 6,
		},
		{
			Value = 563929,
			Score = -15,
			LevelScore = 5,
		},
		{
			Value = 563928,
			Score = -10,
			LevelScore = 3,
		},
		{
			Value = 563927,
			Score = -5,
			LevelScore = 1,
		},
		{
			Value = 563916,
			Score = -25,
			LevelScore = 8,
		},
		{
			Value = 563915,
			Score = -20,
			LevelScore = 6,
		},
		{
			Value = 563914,
			Score = -15,
			LevelScore = 5,
		},
		{
			Value = 563913,
			Score = -10,
			LevelScore = 3,
		},
		{
			Value = 563912,
			Score = -5,
			LevelScore = 1,
		},
		{
			Value = 563906,
			Score = -25,
			LevelScore = 8,
		},
		{
			Value = 563905,
			Score = -20,
			LevelScore = 6,
		},
		{
			Value = 563904,
			Score = -15,
			LevelScore = 5,
		},
		{
			Value = 563903,
			Score = -10,
			LevelScore = 3,
		},
		{
			Value = 563902,
			Score = -5,
			LevelScore = 1,
		},
	},
	RewardList = {
		{
			Score = 800,
			ResultText = "太棒了！",
			RewardList = {
				{
					Value = 2,
					Num = 100,
				},
				{
					Value = 1,
					Num = 30000,
				},
			},
		},
		{
			Score = 600,
			ResultText = "非常好~",
			RewardList = {
				{
					Value = 2,
					Num = 75,
				},
				{
					Value = 1,
					Num = 25000,
				},
			},
		},
		{
			Score = 400,
			ResultText = "不错诶！",
			RewardList = {
				{
					Value = 2,
					Num = 50,
				},
				{
					Value = 1,
					Num = 20000,
				},
			},
		},
		{
			Score = 200,
			ResultText = "很一般…",
			RewardList = {
				{
					Value = 2,
					Num = 30,
				},
				{
					Value = 1,
					Num = 15000,
				},
			},
		},
		{
			Score = -1000,
			ResultText = "什么鬼！！",
			RewardList = {
				{
					Value = 2,
					Num = 10,
				},
				{
					Value = 1,
					Num = 10000,
				},
			},
		},
	},
	RankTextList = {
		{
			CommentatorName = "艺术少女",
			CommentatorInfo = "关注：16 粉丝：440.0万",
			BadgeIcon = {
				"TouristBadge_1",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_19",
			DescList = {
				{
					NeedScore = 500,
					Desc = "缤纷又杂乱的色彩，真是让人心醉。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "假释的怪盗先生",
			CommentatorInfo = "关注：29 粉丝：205.6万",
			BadgeIcon = {
				"TouristBadge_2",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_16",
			DescList = {
				{
					NeedScore = 500,
					Desc = "已经看过无数杰出展品的我，对于如此丰富的色彩演出也只能表示叹为观止。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "网红小浣熊",
			CommentatorInfo = "关注：39 粉丝：327.8万",
			BadgeIcon = {
				"TouristBadge_3",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_18",
			DescList = {
				{
					NeedScore = 500,
					Desc = "哇~~~好漂亮的颜色~~感觉胃口都开了~",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "酒乡的醉先生",
			CommentatorInfo = "关注：24 粉丝：182.5万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_7",
			DescList = {
				{
					NeedScore = 500,
					Desc = "赤橙黄绿青蓝紫，谁持彩练当空舞？",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "剑圣",
			CommentatorInfo = "关注：92 粉丝：122.2万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_3",
			DescList = {
				{
					NeedScore = 500,
					Desc = "绚烂的色彩如烟火般灿烂，嗯，我领悟到了新的绝技！",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "精灵公主",
			CommentatorInfo = "关注：13 粉丝：179.4万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_4",
			DescList = {
				{
					NeedScore = 500,
					Desc = "本来只是想慰问一下色盲患者们，想不到能看到如此美妙的演出~~",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "奇迹的蛋糕师",
			CommentatorInfo = "关注：50 粉丝：453.7万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_11",
			DescList = {
				{
					NeedScore = 500,
					Desc = "如果多彩的景色能够让你提起精神，那么请一定不要错过在下的新品——彩虹蛋糕城！",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "卖系统的盖茨比",
			CommentatorInfo = "关注：78 粉丝：407.4万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_24",
			DescList = {
				{
					NeedScore = 500,
					Desc = "如果想在你的设备上重现如此富有质感和层次的多彩照片，那装上Doors系统就对了！",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "一言堂大师",
			CommentatorInfo = "关注：61 粉丝：291.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_14",
			DescList = {
				{
					NeedScore = 500,
					Desc = "感谢节目组给我的这次免费旅游机会，能看到这么特别的演出，我真的很高兴。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "退休警察局长",
			CommentatorInfo = "关注：10 粉丝：279.4万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_20",
			DescList = {
				{
					NeedScore = 500,
					Desc = "世界原本就是如此美丽，所以我们更要珍爱生命，远离犯罪。这样才能去感受世界的美好。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
	},
}
TouristConfig[TouristID.Id011] =
{
	Id = 11,
	Name = "外星观光团11",
	Desc = "即将招待怕热的观光者，客人们希望能看到凉飕飕的宠物！",
	Weight = 1000,
	ResultText = "寒冷指数",
	TagList = {
		{
			Value = 563402,
			Score = 50,
			LevelScore = 10,
		},
		{
			Value = 563403,
			Score = 35,
			LevelScore = 8,
		},
		{
			Value = 563404,
			Score = 20,
			LevelScore = 6,
		},
		{
			Value = 563405,
			Score = 5,
			LevelScore = 4,
		},
		{
			Value = 563406,
			Score = -10,
			LevelScore = 2,
		},
		{
			Value = 561202,
			Score = 50,
			LevelScore = 10,
		},
		{
			Value = 561203,
			Score = 10,
			LevelScore = 10,
		},
	},
	RewardList = {
		{
			Score = 800,
			ResultText = "太棒了！",
			RewardList = {
				{
					Value = 2,
					Num = 100,
				},
				{
					Value = 1,
					Num = 30000,
				},
			},
		},
		{
			Score = 600,
			ResultText = "非常好~",
			RewardList = {
				{
					Value = 2,
					Num = 75,
				},
				{
					Value = 1,
					Num = 25000,
				},
			},
		},
		{
			Score = 400,
			ResultText = "不错诶！",
			RewardList = {
				{
					Value = 2,
					Num = 50,
				},
				{
					Value = 1,
					Num = 20000,
				},
			},
		},
		{
			Score = 200,
			ResultText = "很一般…",
			RewardList = {
				{
					Value = 2,
					Num = 30,
				},
				{
					Value = 1,
					Num = 15000,
				},
			},
		},
		{
			Score = -1000,
			ResultText = "什么鬼！！",
			RewardList = {
				{
					Value = 2,
					Num = 10,
				},
				{
					Value = 1,
					Num = 10000,
				},
			},
		},
	},
	RankTextList = {
		{
			CommentatorName = "冒险家协会会长",
			CommentatorInfo = "关注：25 粉丝：151.1万",
			BadgeIcon = {
				"TouristBadge_1",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_1",
			DescList = {
				{
					NeedScore = 500,
					Desc = "看到如此震撼的演出，让我感觉仿佛进入了雪山之中，体内多余的热量被瞬间吸走了。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "骑士团长",
			CommentatorInfo = "关注：92 粉丝：183.1万",
			BadgeIcon = {
				"TouristBadge_2",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_5",
			DescList = {
				{
					NeedScore = 500,
					Desc = "啊，我这个人是最怕热的了，每次大战结束，就想抱着冰块畅快地睡一觉。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "怕辣的美食博主",
			CommentatorInfo = "关注：22 粉丝：333.2万",
			BadgeIcon = {
				"TouristBadge_3",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_12",
			DescList = {
				{
					NeedScore = 500,
					Desc = "今天尝试在寒冷的环境里吃下了一整份生鱼片，新鲜的三文鱼加阵阵寒风，绝对是特别的体验！噢哟，肚子有点痛…",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "剑圣",
			CommentatorInfo = "关注：92 粉丝：122.2万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_3",
			DescList = {
				{
					NeedScore = 500,
					Desc = "虽然温暖的阳光可以让人感到舒适，但是冰冷的感觉更加能够让人打起精神来。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "企鹅岛的马先生",
			CommentatorInfo = "关注：17 粉丝：208.2万",
			BadgeIcon = {
				"TouristBadge_1",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_23",
			DescList = {
				{
					NeedScore = 500,
					Desc = "终于看到了期望已久的演出，家里的企鹅们都表示这次演出非常完美！",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "假释的怪盗先生",
			CommentatorInfo = "关注：29 粉丝：205.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_16",
			DescList = {
				{
					NeedScore = 500,
					Desc = "看够了给人温暖感的表演，这次的冬季主题实在是别开生面，不枉在下交了额外的保释金来这里看了一回。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "亲切的历史学者",
			CommentatorInfo = "关注：90 粉丝：269.0万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_15",
			DescList = {
				{
					NeedScore = 500,
					Desc = "今天的表演让本人亲临了一场可怕的小冰期，接下来我会以更谨慎的态度处理被时间尘封的历史。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "酒乡的醉先生",
			CommentatorInfo = "关注：24 粉丝：182.5万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_7",
			DescList = {
				{
					NeedScore = 500,
					Desc = "比起炎热感的表演，还是更喜欢冰冷感的表演，毕竟在大热天喝酒就实在是太热了。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "奇迹的蛋糕师",
			CommentatorInfo = "关注：50 粉丝：453.7万",
			BadgeIcon = {
				"TouristBadge_1",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_11",
			DescList = {
				{
					NeedScore = 500,
					Desc = "最近正在研究新式的冰淇淋蛋糕，最适合在这种寒冷的环境下食用了~",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "卖系统的盖茨比",
			CommentatorInfo = "关注：78 粉丝：407.4万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_24",
			DescList = {
				{
					NeedScore = 500,
					Desc = "最近因为机房散热问题一直很头痛，最后把机房建到了海底，不过如果早知道有这样的宠物，可能放两只在机房就没有问题了。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
	},
}
TouristConfig[TouristID.Id012] =
{
	Id = 12,
	Name = "外星观光团12",
	Desc = "即将招待皇家女子学院的女学生们，客人们希望看到可爱的动物。",
	Weight = 1000,
	ResultText = "可爱指数",
	TagList = {
		{
			Value = 564021,
			Score = 90,
			LevelScore = 18,
		},
		{
			Value = 564020,
			Score = 75,
			LevelScore = 15,
		},
		{
			Value = 564019,
			Score = 60,
			LevelScore = 12,
		},
		{
			Value = 564018,
			Score = 45,
			LevelScore = 9,
		},
		{
			Value = 564017,
			Score = 30,
			LevelScore = 6,
		},
		{
			Value = 563826,
			Score = 30,
			LevelScore = 6,
		},
		{
			Value = 563825,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 563824,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 563823,
			Score = 15,
			LevelScore = 3,
		},
		{
			Value = 563822,
			Score = 10,
			LevelScore = 2,
		},
		{
			Value = 560026,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 560025,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 560024,
			Score = 15,
			LevelScore = 3,
		},
		{
			Value = 560023,
			Score = 10,
			LevelScore = 2,
		},
		{
			Value = 560022,
			Score = 5,
			LevelScore = 1,
		},
		{
			Value = 564031,
			Score = -40,
			LevelScore = 8,
		},
		{
			Value = 564030,
			Score = -30,
			LevelScore = 6,
		},
		{
			Value = 564029,
			Score = -20,
			LevelScore = 4,
		},
		{
			Value = 564028,
			Score = -10,
			LevelScore = 2,
		},
		{
			Value = 564027,
			Score = 0,
			LevelScore = 1,
		},
		{
			Value = 564041,
			Score = -40,
			LevelScore = 8,
		},
		{
			Value = 564040,
			Score = -30,
			LevelScore = 6,
		},
		{
			Value = 564039,
			Score = -20,
			LevelScore = 4,
		},
		{
			Value = 564038,
			Score = -10,
			LevelScore = 2,
		},
		{
			Value = 564037,
			Score = 0,
			LevelScore = 1,
		},
	},
	RewardList = {
		{
			Score = 800,
			ResultText = "太棒了！",
			RewardList = {
				{
					Value = 2,
					Num = 100,
				},
				{
					Value = 1,
					Num = 30000,
				},
			},
		},
		{
			Score = 600,
			ResultText = "非常好~",
			RewardList = {
				{
					Value = 2,
					Num = 75,
				},
				{
					Value = 1,
					Num = 25000,
				},
			},
		},
		{
			Score = 400,
			ResultText = "不错诶！",
			RewardList = {
				{
					Value = 2,
					Num = 50,
				},
				{
					Value = 1,
					Num = 20000,
				},
			},
		},
		{
			Score = 200,
			ResultText = "很一般…",
			RewardList = {
				{
					Value = 2,
					Num = 30,
				},
				{
					Value = 1,
					Num = 15000,
				},
			},
		},
		{
			Score = -1000,
			ResultText = "什么鬼！！",
			RewardList = {
				{
					Value = 2,
					Num = 10,
				},
				{
					Value = 1,
					Num = 10000,
				},
			},
		},
	},
	RankTextList = {
		{
			CommentatorName = "前任女王",
			CommentatorInfo = "关注：63 粉丝：486.5万",
			BadgeIcon = {
				"TouristBadge_1",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_2",
			DescList = {
				{
					NeedScore = 500,
					Desc = "能够带着年轻的学生们参观可爱的动物，让我感到自己又重新年轻了起来。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "魔王的妹妹",
			CommentatorInfo = "关注：29 粉丝：244.5万",
			BadgeIcon = {
				"TouristBadge_2",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_6",
			DescList = {
				{
					NeedScore = 500,
					Desc = "和城堡里的魔物们果然是完全不同的风格，蓬松的毛和柔软的肚子，感觉它们和自己很亲近呢~",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "阿里山的马先生",
			CommentatorInfo = "关注：86 粉丝：160.0万",
			BadgeIcon = {
				"TouristBadge_3",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_22",
			DescList = {
				{
					NeedScore = 500,
					Desc = "未来社会，宠物将成为人们重要的陪伴，公司目前正关注该领域，相信将来宠物一定会走进千家万户。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "精灵公主",
			CommentatorInfo = "关注：13 粉丝：179.4万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_4",
			DescList = {
				{
					NeedScore = 500,
					Desc = "哇，可爱的动物，完全治愈了因旅途而感到疲惫的我。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "艺术少女",
			CommentatorInfo = "关注：16 粉丝：440.0万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_19",
			DescList = {
				{
					NeedScore = 500,
					Desc = "最近一直赶着准备作品，感觉整个人都晕头转向的，不过看到小动物的那一刻，觉得一下子轻松了下来。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "网红小浣熊",
			CommentatorInfo = "关注：39 粉丝：327.8万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_18",
			DescList = {
				{
					NeedScore = 500,
					Desc = "唔，我的爪子洗得很干净了，可以上去摸一下吗？",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "怕辣的美食博主",
			CommentatorInfo = "关注：22 粉丝：333.2万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_12",
			DescList = {
				{
					NeedScore = 500,
					Desc = "小动物们太可爱了~令吃了很多小动物的我感到无比惭愧…我向你们谢罪。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "天使投资王少爷",
			CommentatorInfo = "关注：59 粉丝：455.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_25",
			DescList = {
				{
					NeedScore = 500,
					Desc = "应学院邀请，陪同学生们一同来参观动物，表演者登场的那一刻，感觉就连反射弧特别长的我也立刻被萌到了。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "米其森副评委",
			CommentatorInfo = "关注：11 粉丝：437.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_9",
			DescList = {
				{
					NeedScore = 500,
					Desc = "代表美食协会来参观动物表演，不过看完表演后我决定从此只吃素菜了。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "亲切的历史学者",
			CommentatorInfo = "关注：90 粉丝：269.0万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_15",
			DescList = {
				{
					NeedScore = 500,
					Desc = "啊~小动物什么的最喜欢了，它们可是和我们一样的历史见证者啊。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
	},
}
TouristConfig[TouristID.Id013] =
{
	Id = 13,
	Name = "外星观光团13",
	Desc = "即将招待来自矿石星球的工匠们，钢铁硬汉们喜欢刚强的质感！",
	Weight = 1000,
	ResultText = "钢铁指数",
	TagList = {
		{
			Value = 561325,
			Score = 40,
			LevelScore = 8,
		},
		{
			Value = 564116,
			Score = 45,
			LevelScore = 9,
		},
		{
			Value = 564115,
			Score = 35,
			LevelScore = 7,
		},
		{
			Value = 564114,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 564113,
			Score = 15,
			LevelScore = 3,
		},
		{
			Value = 564112,
			Score = 5,
			LevelScore = 1,
		},
		{
			Value = 563816,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 563815,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 563814,
			Score = 15,
			LevelScore = 3,
		},
		{
			Value = 563813,
			Score = 10,
			LevelScore = 2,
		},
		{
			Value = 563812,
			Score = 5,
			LevelScore = 1,
		},
		{
			Value = 563811,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 563810,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 563809,
			Score = 15,
			LevelScore = 3,
		},
		{
			Value = 563808,
			Score = 10,
			LevelScore = 2,
		},
		{
			Value = 563807,
			Score = 5,
			LevelScore = 1,
		},
		{
			Value = 560026,
			Score = 50,
			LevelScore = 10,
		},
		{
			Value = 560025,
			Score = 40,
			LevelScore = 8,
		},
		{
			Value = 560024,
			Score = 30,
			LevelScore = 6,
		},
		{
			Value = 560023,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 560022,
			Score = 10,
			LevelScore = 2,
		},
		{
			Value = 561347,
			Score = -40,
			LevelScore = 1,
		},
		{
			Value = 563611,
			Score = -25,
			LevelScore = 1,
		},
		{
			Value = 563610,
			Score = -20,
			LevelScore = 1,
		},
		{
			Value = 563609,
			Score = -15,
			LevelScore = 1,
		},
		{
			Value = 563608,
			Score = -10,
			LevelScore = 1,
		},
		{
			Value = 563607,
			Score = -5,
			LevelScore = 1,
		},
	},
	RewardList = {
		{
			Score = 800,
			ResultText = "太棒了！",
			RewardList = {
				{
					Value = 2,
					Num = 100,
				},
				{
					Value = 1,
					Num = 30000,
				},
			},
		},
		{
			Score = 600,
			ResultText = "非常好~",
			RewardList = {
				{
					Value = 2,
					Num = 75,
				},
				{
					Value = 1,
					Num = 25000,
				},
			},
		},
		{
			Score = 400,
			ResultText = "不错诶！",
			RewardList = {
				{
					Value = 2,
					Num = 50,
				},
				{
					Value = 1,
					Num = 20000,
				},
			},
		},
		{
			Score = 200,
			ResultText = "很一般…",
			RewardList = {
				{
					Value = 2,
					Num = 30,
				},
				{
					Value = 1,
					Num = 15000,
				},
			},
		},
		{
			Score = -1000,
			ResultText = "什么鬼！！",
			RewardList = {
				{
					Value = 2,
					Num = 10,
				},
				{
					Value = 1,
					Num = 10000,
				},
			},
		},
	},
	RankTextList = {
		{
			CommentatorName = "剑圣",
			CommentatorInfo = "关注：92 粉丝：122.2万",
			BadgeIcon = {
				"TouristBadge_1",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_3",
			DescList = {
				{
					NeedScore = 500,
					Desc = "唔，如此优秀的坚硬物质，是不是能够锻造出一把新的绝世兵器呢？ @超能铁匠 ",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "骑士团长",
			CommentatorInfo = "关注：92 粉丝：183.1万",
			BadgeIcon = {
				"TouristBadge_2",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_5",
			DescList = {
				{
					NeedScore = 500,
					Desc = "哈！就是这个，如同我们钢铁男儿意志般坚强的生物，我的刚勇之魂又被唤醒了！",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "收藏家D先生",
			CommentatorInfo = "关注：75 粉丝：461.8万",
			BadgeIcon = {
				"TouristBadge_3",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_17",
			DescList = {
				{
					NeedScore = 500,
					Desc = "就是这个！质地坚实的稀有矿石，真想把它们都带回去啊~这样我的3号展柜就完满了。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "假释的怪盗先生",
			CommentatorInfo = "关注：29 粉丝：205.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_16",
			DescList = {
				{
					NeedScore = 500,
					Desc = "被人问起怎么哪里都有我，其实是因为假释期间只能报特定团出行，不过今天的演出还是让见惯了宝石的在下感到与众不同。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "一言堂大师",
			CommentatorInfo = "关注：61 粉丝：291.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_14",
			DescList = {
				{
					NeedScore = 500,
					Desc = "我一直和我的学生们说，最好的宝藏都是天然的，今天我拍了3T的照片，回去给大家分享一下。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "亲切的历史学者",
			CommentatorInfo = "关注：90 粉丝：269.0万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_15",
			DescList = {
				{
					NeedScore = 500,
					Desc = "一直对罕见的石头情有独钟，因为它们比我们更长久，也见证了更多世界的变化。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "网红小浣熊",
			CommentatorInfo = "关注：39 粉丝：327.8万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_18",
			DescList = {
				{
					NeedScore = 500,
					Desc = "啊！就是它们，以前我拿苹果时被它们追着打过呢！不过今天买了票来看表演心情就完全不一样了。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "艺术少女",
			CommentatorInfo = "关注：16 粉丝：440.0万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_19",
			DescList = {
				{
					NeedScore = 500,
					Desc = "美丽自然的造型，找到了很好的临摹素材~",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "冒险家协会会长",
			CommentatorInfo = "关注：25 粉丝：151.1万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_1",
			DescList = {
				{
					NeedScore = 500,
					Desc = "说到珍惜的石头，那就一定要去冒险星看啦，不过这里的表演也丝毫不逊色呢~",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "博物馆馆长",
			CommentatorInfo = "关注：53 粉丝：181.0万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_13",
			DescList = {
				{
					NeedScore = 500,
					Desc = "这样的表演很别开生面，我们馆方下次也要举办像这样的石头展览，还请游客们期待。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
	},
}
TouristConfig[TouristID.Id014] =
{
	Id = 14,
	Name = "外星观光团14",
	Desc = "即将招待大胃王大赛的获奖选手们，客人表示如果能够看到高热量美食，那么就会很高兴。",
	PreChallenge = 
	{
		140211,
	},
	Weight = 1000,
	ResultText = "热量指数",
	TagList = {
		{
			Value = 561306,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 561319,
			Score = 35,
			LevelScore = 7,
		},
		{
			Value = 561312,
			Score = 35,
			LevelScore = 7,
		},
		{
			Value = 561332,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 561334,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 561333,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 561331,
			Score = 10,
			LevelScore = 2,
		},
		{
			Value = 564206,
			Score = 70,
			LevelScore = 14,
		},
		{
			Value = 564205,
			Score = 50,
			LevelScore = 10,
		},
		{
			Value = 564204,
			Score = 30,
			LevelScore = 6,
		},
		{
			Value = 564203,
			Score = 10,
			LevelScore = 2,
		},
		{
			Value = 564202,
			Score = -10,
			LevelScore = 2,
		},
		{
			Value = 561320,
			Score = -20,
			LevelScore = 4,
		},
	},
	RewardList = {
		{
			Score = 800,
			ResultText = "太棒了！",
			RewardList = {
				{
					Value = 2,
					Num = 100,
				},
				{
					Value = 1,
					Num = 30000,
				},
			},
		},
		{
			Score = 600,
			ResultText = "非常好~",
			RewardList = {
				{
					Value = 2,
					Num = 75,
				},
				{
					Value = 1,
					Num = 25000,
				},
			},
		},
		{
			Score = 400,
			ResultText = "不错诶！",
			RewardList = {
				{
					Value = 2,
					Num = 50,
				},
				{
					Value = 1,
					Num = 20000,
				},
			},
		},
		{
			Score = 200,
			ResultText = "很一般…",
			RewardList = {
				{
					Value = 2,
					Num = 30,
				},
				{
					Value = 1,
					Num = 15000,
				},
			},
		},
		{
			Score = -1000,
			ResultText = "什么鬼！！",
			RewardList = {
				{
					Value = 2,
					Num = 10,
				},
				{
					Value = 1,
					Num = 10000,
				},
			},
		},
	},
	RankTextList = {
		{
			CommentatorName = "怕辣的美食博主",
			CommentatorInfo = "关注：22 粉丝：333.2万",
			BadgeIcon = {
				"TouristBadge_1",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_12",
			DescList = {
				{
					NeedScore = 500,
					Desc = "今天受邀与大胃王们一同参加了热量的盛宴，食物一个一个表演后，连非常注意饮食健康的我也忍不住食指大动。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "精灵公主",
			CommentatorInfo = "关注：13 粉丝：179.4万",
			BadgeIcon = {
				"TouristBadge_2",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_4",
			DescList = {
				{
					NeedScore = 500,
					Desc = "因为形象的原因一直没法畅快地和高热量的食品打交道，不过能够一次性看到这么多跳动着的热量，我也感到满足了。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "艺术少女",
			CommentatorInfo = "关注：16 粉丝：440.0万",
			BadgeIcon = {
				"TouristBadge_3",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_19",
			DescList = {
				{
					NeedScore = 500,
					Desc = "太棒了！表演中途我就忍不住用“饿了呢”下单了炸鸡和可乐，等会要立刻回家变胖！",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "顶级大厨",
			CommentatorInfo = "关注：65 粉丝：160.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_10",
			DescList = {
				{
					NeedScore = 500,
					Desc = "鄙人一生都在用自己的大勺与这样的食物交战，不过今天闻到味道时，我就知道鄙人的征途还有很长距离要走。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "企鹅岛的马先生",
			CommentatorInfo = "关注：17 粉丝：208.2万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_23",
			DescList = {
				{
					NeedScore = 500,
					Desc = "看到这些食物不禁回想起刚创业时，月底全公司只有150块钱，只能买高热量的食物填饱全公司150个人的肚子。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "退休警察局长",
			CommentatorInfo = "关注：10 粉丝：279.4万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_20",
			DescList = {
				{
					NeedScore = 500,
					Desc = "以前办案子的时候时间紧张，只能靠这些美食填饱肚子继续工作，现在人老了，已经吃不动了，不过看到也很高兴。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "奇迹的蛋糕师",
			CommentatorInfo = "关注：50 粉丝：453.7万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_11",
			DescList = {
				{
					NeedScore = 500,
					Desc = "在某些问题上晚辈与厨神前辈有些分歧，不过晚辈还是认为像这样的美食偶尔食用依然是给予我们幸福感的。 @顶级大厨",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "网红小浣熊",
			CommentatorInfo = "关注：39 粉丝：327.8万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_18",
			DescList = {
				{
					NeedScore = 500,
					Desc = "唔，首先要认错，刚刚看表演的时候没忍住挖了一块食物吃。其次，这次的表演真的很棒！",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "酒乡的醉先生",
			CommentatorInfo = "关注：24 粉丝：182.5万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_7",
			DescList = {
				{
					NeedScore = 500,
					Desc = "虽然不是太适合做下酒菜的食物，不过看起来色泽饱满，闻起来也很有食欲，如果哪天没酒了，我一定会尝一下。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "米其森副评委",
			CommentatorInfo = "关注：11 粉丝：437.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_9",
			DescList = {
				{
					NeedScore = 500,
					Desc = "这样的食物我还是不能认同，不过看到大家幸福的样子，某一刻在下的心中也有一丝疑惑。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
	},
}
TouristConfig[TouristID.Id015] =
{
	Id = 15,
	Name = "外星观光团15",
	Desc = "即将招待来自博物馆星的客人们，客人们希望看到富有艺术气息的宠物。",
	PreChallenge = 
	{
		140416,
	},
	Weight = 1000,
	ResultText = "艺术指数",
	TagList = {
		{
			Value = 561336,
			Score = 35,
			LevelScore = 6,
		},
		{
			Value = 561339,
			Score = 35,
			LevelScore = 6,
		},
		{
			Value = 561340,
			Score = 35,
			LevelScore = 6,
		},
		{
			Value = 561341,
			Score = 35,
			LevelScore = 6,
		},
		{
			Value = 561302,
			Score = 35,
			LevelScore = 6,
		},
		{
			Value = 564046,
			Score = 60,
			LevelScore = 12,
		},
		{
			Value = 564045,
			Score = 50,
			LevelScore = 10,
		},
		{
			Value = 564044,
			Score = 40,
			LevelScore = 8,
		},
		{
			Value = 564043,
			Score = 30,
			LevelScore = 6,
		},
		{
			Value = 564042,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 560026,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 560025,
			Score = 15,
			LevelScore = 3,
		},
		{
			Value = 560024,
			Score = 10,
			LevelScore = 2,
		},
		{
			Value = 560023,
			Score = 5,
			LevelScore = 1,
		},
		{
			Value = 560022,
			Score = 0,
			LevelScore = 1,
		},
	},
	RewardList = {
		{
			Score = 800,
			ResultText = "太棒了！",
			RewardList = {
				{
					Value = 2,
					Num = 100,
				},
				{
					Value = 1,
					Num = 30000,
				},
			},
		},
		{
			Score = 600,
			ResultText = "非常好~",
			RewardList = {
				{
					Value = 2,
					Num = 75,
				},
				{
					Value = 1,
					Num = 25000,
				},
			},
		},
		{
			Score = 400,
			ResultText = "不错诶！",
			RewardList = {
				{
					Value = 2,
					Num = 50,
				},
				{
					Value = 1,
					Num = 20000,
				},
			},
		},
		{
			Score = 200,
			ResultText = "很一般…",
			RewardList = {
				{
					Value = 2,
					Num = 30,
				},
				{
					Value = 1,
					Num = 15000,
				},
			},
		},
		{
			Score = -1000,
			ResultText = "什么鬼！！",
			RewardList = {
				{
					Value = 2,
					Num = 10,
				},
				{
					Value = 1,
					Num = 10000,
				},
			},
		},
	},
	RankTextList = {
		{
			CommentatorName = "博物馆馆长",
			CommentatorInfo = "关注：53 粉丝：181.0万",
			BadgeIcon = {
				"TouristBadge_1",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_13",
			DescList = {
				{
					NeedScore = 500,
					Desc = "在博物馆星球外也看到了非常不错的艺术展，虽然很多艺术品都似曾相识，不过看到艺术发扬光大还是很欣慰。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "亲切的历史学者",
			CommentatorInfo = "关注：90 粉丝：269.0万",
			BadgeIcon = {
				"TouristBadge_2",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_15",
			DescList = {
				{
					NeedScore = 500,
					Desc = "这些艺术品不仅是过去人们生活智慧的及艺术智慧的结晶，也是时代的见证者啊！",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "网红小浣熊",
			CommentatorInfo = "关注：39 粉丝：327.8万",
			BadgeIcon = {
				"TouristBadge_3",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_18",
			DescList = {
				{
					NeedScore = 500,
					Desc = "哇~~~太棒了，看到了和博物馆星一样出色的艺术展，而且没有门票~等等一定要洗好爪子摸一摸。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "收藏家D先生",
			CommentatorInfo = "关注：75 粉丝：461.8万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_17",
			DescList = {
				{
					NeedScore = 500,
					Desc = "以D某人专业的眼光看也算是还不错的展览会了，虽然这些藏品D某人也都有，不过看到同好还是要赞一下。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "一言堂大师",
			CommentatorInfo = "关注：61 粉丝：291.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_14",
			DescList = {
				{
					NeedScore = 500,
					Desc = "以在下的性格，如果看到了赝品就一定要杂碎它，不过今天看到的都是挺不错的艺术品。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "阿里山的马先生",
			CommentatorInfo = "关注：86 粉丝：160.0万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_22",
			DescList = {
				{
					NeedScore = 500,
					Desc = "本人对艺术品也略有研究，今天的艺术随团游竟然能看到如此优质的艺术展还是让本人始料未及。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "退休警察局长",
			CommentatorInfo = "关注：10 粉丝：279.4万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_20",
			DescList = {
				{
					NeedScore = 500,
					Desc = "看到这些艺术品的第一反应就是该团体可能与多起博物馆星失窃事件有关，不过查阅了相关证件后才知道冤枉了阁下。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "假释的怪盗先生",
			CommentatorInfo = "关注：29 粉丝：205.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_16",
			DescList = {
				{
					NeedScore = 500,
					Desc = "哦吼？有点意思，想不到宇宙里还有另一位和鄙人有着相同收藏喜好的收藏家，不知阁下是否也曾…嘿嘿。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "艺术少女",
			CommentatorInfo = "关注：16 粉丝：440.0万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_19",
			DescList = {
				{
					NeedScore = 500,
					Desc = "久闻外星也在积极开展艺术展，今天来拔草。看了所有的演出后，发现泪水竟不自觉划过脸庞，真的很好，多谢了。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "俏江北餐饮董事",
			CommentatorInfo = "关注：46 粉丝：473.9万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_21",
			DescList = {
				{
					NeedScore = 500,
					Desc = "对古玩和瓷器特别喜欢，我认为这是东方艺术带给世界的瑰宝，今天能够见到，令人非常欣慰。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
	},
}
TouristConfig[TouristID.Id016] =
{
	Id = 16,
	Name = "外星观光团16",
	Desc = "即将招待来自英雄世家的冒险者们，客人们希望看到难以驯服的生物！",
	PreChallenge = 
	{
		140029,
	},
	Weight = 1000,
	ResultText = "桀骜指数",
	TagList = {
		{
			Value = 561338,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 561303,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 563302,
			Score = 50,
			LevelScore = 10,
		},
		{
			Value = 563303,
			Score = 35,
			LevelScore = 7,
		},
		{
			Value = 563304,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 563305,
			Score = 5,
			LevelScore = 1,
		},
		{
			Value = 563306,
			Score = -10,
			LevelScore = 2,
		},
		{
			Value = 564041,
			Score = 30,
			LevelScore = 6,
		},
		{
			Value = 564040,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 564039,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 564038,
			Score = 15,
			LevelScore = 3,
		},
		{
			Value = 564037,
			Score = 10,
			LevelScore = 2,
		},
		{
			Value = 560026,
			Score = 35,
			LevelScore = 7,
		},
		{
			Value = 560025,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 560024,
			Score = 15,
			LevelScore = 3,
		},
		{
			Value = 560023,
			Score = 5,
			LevelScore = 1,
		},
		{
			Value = 560022,
			Score = -5,
			LevelScore = 1,
		},
	},
	RewardList = {
		{
			Score = 800,
			ResultText = "太棒了！",
			RewardList = {
				{
					Value = 2,
					Num = 100,
				},
				{
					Value = 1,
					Num = 30000,
				},
			},
		},
		{
			Score = 600,
			ResultText = "非常好~",
			RewardList = {
				{
					Value = 2,
					Num = 75,
				},
				{
					Value = 1,
					Num = 25000,
				},
			},
		},
		{
			Score = 400,
			ResultText = "不错诶！",
			RewardList = {
				{
					Value = 2,
					Num = 50,
				},
				{
					Value = 1,
					Num = 20000,
				},
			},
		},
		{
			Score = 200,
			ResultText = "很一般…",
			RewardList = {
				{
					Value = 2,
					Num = 30,
				},
				{
					Value = 1,
					Num = 15000,
				},
			},
		},
		{
			Score = -1000,
			ResultText = "什么鬼！！",
			RewardList = {
				{
					Value = 2,
					Num = 10,
				},
				{
					Value = 1,
					Num = 10000,
				},
			},
		},
	},
	RankTextList = {
		{
			CommentatorName = "剑圣",
			CommentatorInfo = "关注：92 粉丝：122.2万",
			BadgeIcon = {
				"TouristBadge_1",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_3",
			DescList = {
				{
					NeedScore = 500,
					Desc = "嘿，看见老朋友们了，能筹备出这么了不起的展会，相信阁下也费了不少功夫吧。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "前任女王",
			CommentatorInfo = "关注：63 粉丝：486.5万",
			BadgeIcon = {
				"TouristBadge_2",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_2",
			DescList = {
				{
					NeedScore = 500,
					Desc = "啊，看到了好多了不起的凶猛之物，这些东西平时无论在哪里出现都是会让人头疼的呢。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "怕辣的美食博主",
			CommentatorInfo = "关注：22 粉丝：333.2万",
			BadgeIcon = {
				"TouristBadge_3",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_12",
			DescList = {
				{
					NeedScore = 500,
					Desc = "小时候的愿望是长大成为了不起的冒险家，如今虽然只能当一个美食博主，不过今天看到了这样的表演也算了了心愿呢~",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "骑士团长",
			CommentatorInfo = "关注：92 粉丝：183.1万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_5",
			DescList = {
				{
					NeedScore = 500,
					Desc = "在下一生都在与这些生物，或说是生命体们对抗，想不到它们也有被人驯服的一天。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "网红小浣熊",
			CommentatorInfo = "关注：39 粉丝：327.8万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_18",
			DescList = {
				{
					NeedScore = 500,
					Desc = "唔…那个怪物叫了好大一声…我要去厕所换裤子了…",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "亲切的历史学者",
			CommentatorInfo = "关注：90 粉丝：269.0万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_15",
			DescList = {
				{
					NeedScore = 500,
					Desc = "大自然自有其美妙之处，而其最伟大的地方就是既能创造出杰出的艺术品，也能创造出令人震撼的危险品。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "退休警察局长",
			CommentatorInfo = "关注：10 粉丝：279.4万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_20",
			DescList = {
				{
					NeedScore = 500,
					Desc = "噢哟！原来外星还有这样的东西存在，要是在本星球遇上了，那可真是棘手了。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "天使投资王少爷",
			CommentatorInfo = "关注：59 粉丝：455.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_25",
			DescList = {
				{
					NeedScore = 500,
					Desc = "用两个月的零花钱托人买了一模一样的演出配置，这样在家也能天天欣赏了。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "奇迹的蛋糕师",
			CommentatorInfo = "关注：50 粉丝：453.7万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_11",
			DescList = {
				{
					NeedScore = 500,
					Desc = "如此伟大的生命，让我有了新的灵感，我要制作出让人感到害怕，但是又想吃的蛋糕！",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "魔王的妹妹",
			CommentatorInfo = "关注：29 粉丝：244.5万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_6",
			DescList = {
				{
					NeedScore = 500,
					Desc = "和魔王城堡的生物有得一拼，不知道哥哥大人看到的话会作何感想。 @大魔王",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
	},
}
TouristConfig[TouristID.Id017] =
{
	Id = 17,
	Name = "外星观光团17",
	Desc = "即将招待海洋爱好者们，如果能感受到海洋的气息就会很高兴。",
	PreChallenge = 
	{
		140231,
	},
	Weight = 1000,
	ResultText = "海洋指数",
	TagList = {
		{
			Value = 561330,
			Score = 50,
			LevelScore = 10,
		},
		{
			Value = 561342,
			Score = 50,
			LevelScore = 10,
		},
		{
			Value = 561341,
			Score = 35,
			LevelScore = 7,
		},
		{
			Value = 561350,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 564111,
			Score = 75,
			LevelScore = 15,
		},
		{
			Value = 564110,
			Score = 65,
			LevelScore = 13,
		},
		{
			Value = 564109,
			Score = 55,
			LevelScore = 11,
		},
		{
			Value = 564108,
			Score = 45,
			LevelScore = 9,
		},
		{
			Value = 564107,
			Score = 35,
			LevelScore = 7,
		},
		{
			Value = 560026,
			Score = 10,
			LevelScore = 5,
		},
		{
			Value = 560025,
			Score = 8,
			LevelScore = 4,
		},
		{
			Value = 560024,
			Score = 6,
			LevelScore = 3,
		},
		{
			Value = 560023,
			Score = 4,
			LevelScore = 2,
		},
		{
			Value = 560022,
			Score = 2,
			LevelScore = 1,
		},
		{
			Value = 561351,
			Score = -40,
			LevelScore = 1,
		},
	},
	RewardList = {
		{
			Score = 800,
			ResultText = "太棒了！",
			RewardList = {
				{
					Value = 2,
					Num = 100,
				},
				{
					Value = 1,
					Num = 30000,
				},
			},
		},
		{
			Score = 600,
			ResultText = "非常好~",
			RewardList = {
				{
					Value = 2,
					Num = 75,
				},
				{
					Value = 1,
					Num = 25000,
				},
			},
		},
		{
			Score = 400,
			ResultText = "不错诶！",
			RewardList = {
				{
					Value = 2,
					Num = 50,
				},
				{
					Value = 1,
					Num = 20000,
				},
			},
		},
		{
			Score = 200,
			ResultText = "很一般…",
			RewardList = {
				{
					Value = 2,
					Num = 30,
				},
				{
					Value = 1,
					Num = 15000,
				},
			},
		},
		{
			Score = -1000,
			ResultText = "什么鬼！！",
			RewardList = {
				{
					Value = 2,
					Num = 10,
				},
				{
					Value = 1,
					Num = 10000,
				},
			},
		},
	},
	RankTextList = {
		{
			CommentatorName = "顶级大厨",
			CommentatorInfo = "关注：65 粉丝：160.6万",
			BadgeIcon = {
				"TouristBadge_1",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_10",
			DescList = {
				{
					NeedScore = 500,
					Desc = "客人们已经厌倦了普通的海鲜料理，令在下头痛不已。不过看了今天的演出后，灵感瞬间爆发了。新菜已在积极研发，各位可以订座了~",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "酒乡的醉先生",
			CommentatorInfo = "关注：24 粉丝：182.5万",
			BadgeIcon = {
				"TouristBadge_2",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_7",
			DescList = {
				{
					NeedScore = 500,
					Desc = "自从家乡建造了大型港口后，就搬去了内陆居住。已经很久没有闻到海的味道了。啊~这时候得来一口海之酒。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "怕辣的美食博主",
			CommentatorInfo = "关注：22 粉丝：333.2万",
			BadgeIcon = {
				"TouristBadge_3",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_12",
			DescList = {
				{
					NeedScore = 500,
					Desc = "新鲜的海鲜料理是平时最喜欢的美食之一，不过因为肠胃问题经常不能吃太多。现在看一看，感觉也不错~",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "骑士团长",
			CommentatorInfo = "关注：92 粉丝：183.1万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_5",
			DescList = {
				{
					NeedScore = 500,
					Desc = "在下的征途中，唯有大海是禁区。在台下看到精彩的海洋表演，也算是慰藉了在下无法征服大海的心。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "俏江北餐饮董事",
			CommentatorInfo = "关注：46 粉丝：473.9万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_21",
			DescList = {
				{
					NeedScore = 500,
					Desc = "计划在旗舰店里建设一个新的大型水族箱，正愁不知道该怎么设计才更具冲击力，今天的表演倒是提供了完美案例！",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "米其森主评委",
			CommentatorInfo = "关注：100 粉丝：229.4万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_8",
			DescList = {
				{
					NeedScore = 500,
					Desc = "原本以为会是海鲜美食的盛宴，连筷子都拿在手上了，想不到全程都是表演秀，不过…就表演效果而言是没得说的！",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "米其森副评委",
			CommentatorInfo = "关注：11 粉丝：437.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_9",
			DescList = {
				{
					NeedScore = 500,
					Desc = "如主任所言，我也拿了刀叉在手里，不过因为表演太精彩，最后竟然忘了它们其实也是美味的海鲜。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "天使投资王少爷",
			CommentatorInfo = "关注：59 粉丝：455.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_25",
			DescList = {
				{
					NeedScore = 500,
					Desc = "海鲜已经吃过很多了，想不到这次竟然是看海鲜主题的演出，确实很别致，算是我们和海中生物打交道的另一种方式吧。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "前任女王",
			CommentatorInfo = "关注：63 粉丝：486.5万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_2",
			DescList = {
				{
					NeedScore = 500,
					Desc = "波涛滚滚的表演，如同整个人都置身于海洋一般，真是非常奇妙的感受。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "退休警察局长",
			CommentatorInfo = "关注：10 粉丝：279.4万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_20",
			DescList = {
				{
					NeedScore = 500,
					Desc = "因为对海鲜过敏，所以很少去海边旅游，这次竟然看到了海洋主题的表演，非常难忘。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
	},
}
TouristConfig[TouristID.Id018] =
{
	Id = 18,
	Name = "外星观光团18",
	Desc = "即将招待星际球类协会的成员们，客人们希望看到圆滚滚又有弹性的宠物。",
	Weight = 1000,
	ResultText = "弹性指数",
	TagList = {
		{
			Value = 563621,
			Score = 60,
			LevelScore = 12,
		},
		{
			Value = 563620,
			Score = 50,
			LevelScore = 10,
		},
		{
			Value = 563619,
			Score = 40,
			LevelScore = 8,
		},
		{
			Value = 563618,
			Score = 30,
			LevelScore = 6,
		},
		{
			Value = 563617,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 563806,
			Score = 65,
			LevelScore = 13,
		},
		{
			Value = 563805,
			Score = 55,
			LevelScore = 11,
		},
		{
			Value = 563804,
			Score = 45,
			LevelScore = 9,
		},
		{
			Value = 563803,
			Score = 35,
			LevelScore = 7,
		},
		{
			Value = 563802,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 563816,
			Score = -25,
			LevelScore = 5,
		},
		{
			Value = 563815,
			Score = -20,
			LevelScore = 4,
		},
		{
			Value = 563814,
			Score = -15,
			LevelScore = 3,
		},
		{
			Value = 563813,
			Score = -10,
			LevelScore = 2,
		},
		{
			Value = 563812,
			Score = -5,
			LevelScore = 1,
		},
		{
			Value = 563811,
			Score = -25,
			LevelScore = 5,
		},
		{
			Value = 563810,
			Score = -20,
			LevelScore = 4,
		},
		{
			Value = 563809,
			Score = -15,
			LevelScore = 3,
		},
		{
			Value = 563808,
			Score = -10,
			LevelScore = 2,
		},
		{
			Value = 563807,
			Score = -5,
			LevelScore = 1,
		},
	},
	RewardList = {
		{
			Score = 800,
			ResultText = "太棒了！",
			RewardList = {
				{
					Value = 2,
					Num = 100,
				},
				{
					Value = 1,
					Num = 30000,
				},
			},
		},
		{
			Score = 600,
			ResultText = "非常好~",
			RewardList = {
				{
					Value = 2,
					Num = 75,
				},
				{
					Value = 1,
					Num = 25000,
				},
			},
		},
		{
			Score = 400,
			ResultText = "不错诶！",
			RewardList = {
				{
					Value = 2,
					Num = 50,
				},
				{
					Value = 1,
					Num = 20000,
				},
			},
		},
		{
			Score = 200,
			ResultText = "很一般…",
			RewardList = {
				{
					Value = 2,
					Num = 30,
				},
				{
					Value = 1,
					Num = 15000,
				},
			},
		},
		{
			Score = -1000,
			ResultText = "什么鬼！！",
			RewardList = {
				{
					Value = 2,
					Num = 10,
				},
				{
					Value = 1,
					Num = 10000,
				},
			},
		},
	},
	RankTextList = {
		{
			CommentatorName = "精灵公主",
			CommentatorInfo = "关注：13 粉丝：179.4万",
			BadgeIcon = {
				"TouristBadge_1",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_4",
			DescList = {
				{
					NeedScore = 500,
					Desc = "圆滚滚的小怪物们在台上弹来弹去呢~画面太有趣了。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "顶级大厨",
			CommentatorInfo = "关注：65 粉丝：160.6万",
			BadgeIcon = {
				"TouristBadge_2",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_10",
			DescList = {
				{
					NeedScore = 500,
					Desc = "看到这些圆滚滚的小东西，我忽然想到在美味的牛奶与红茶中加入有弹性的粉圆，一定会创造新的美味！",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "魔王的妹妹",
			CommentatorInfo = "关注：29 粉丝：244.5万",
			BadgeIcon = {
				"TouristBadge_3",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_6",
			DescList = {
				{
					NeedScore = 500,
					Desc = "本来以为只有我喜欢圆嘟嘟的小可爱们，想不到在场的还有很多其他冒险者。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "前任女王",
			CommentatorInfo = "关注：63 粉丝：486.5万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_2",
			DescList = {
				{
					NeedScore = 500,
					Desc = "不知道是不是像极了球类，小家伙们在台上表演的时候，我的阿布一直想冲上去，可能是因为犬类对球的特殊喜好吧。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "网红小浣熊",
			CommentatorInfo = "关注：39 粉丝：327.8万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_18",
			DescList = {
				{
					NeedScore = 500,
					Desc = "呼~咚溜溜，咚溜溜~想起来以前自己小时候也是圆溜溜的。嘿嘿，那时候的自己一定也很可爱。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "剑圣",
			CommentatorInfo = "关注：92 粉丝：122.2万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_3",
			DescList = {
				{
					NeedScore = 500,
					Desc = "以前还是冒险者的时候似乎击败了很多这样的怪物…想不到它们也有如此可爱的一面。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "艺术少女",
			CommentatorInfo = "关注：16 粉丝：440.0万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_19",
			DescList = {
				{
					NeedScore = 500,
					Desc = "因为场上的表演太有趣了，所以当场临摹了很多画作~不过离场的时候觉得画得不怎么样，所以全部撕掉了。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "酒乡的醉先生",
			CommentatorInfo = "关注：24 粉丝：182.5万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_7",
			DescList = {
				{
					NeedScore = 500,
					Desc = "呼，入场前喝了两口，看到满场都是圆滚滚的东西跳来跳去，没有忍住就吐了，希望前面那位观众海涵…不过表演真的很棒…",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "博物馆馆长",
			CommentatorInfo = "关注：53 粉丝：181.0万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_13",
			DescList = {
				{
					NeedScore = 500,
					Desc = "相比于刻板的方形，更喜欢弧形的设计。看到台上这么多圆形的宠物，让我觉得大自然果然有创造美的能力。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "企鹅岛的马先生",
			CommentatorInfo = "关注：17 粉丝：208.2万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_23",
			DescList = {
				{
					NeedScore = 500,
					Desc = "果然球类运动就是男人的浪漫，忽然想要和高中同学们来一场激烈的足球比赛。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
	},
}
TouristConfig[TouristID.Id019] =
{
	Id = 19,
	Name = "外星观光团19",
	Desc = "即将招待来自悬疑星的侦探们，客人们希望看到富有神秘感的宠物。",
	PreChallenge = 
	{
		140613,
	},
	Weight = 1000,
	ResultText = "神秘指数",
	TagList = {
		{
			Value = 561206,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 564026,
			Score = 80,
			LevelScore = 16,
		},
		{
			Value = 564025,
			Score = 65,
			LevelScore = 13,
		},
		{
			Value = 564024,
			Score = 50,
			LevelScore = 10,
		},
		{
			Value = 564023,
			Score = 35,
			LevelScore = 7,
		},
		{
			Value = 564022,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 560026,
			Score = 35,
			LevelScore = 7,
		},
		{
			Value = 560025,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 560024,
			Score = 15,
			LevelScore = 3,
		},
		{
			Value = 560023,
			Score = 5,
			LevelScore = 1,
		},
		{
			Value = 560022,
			Score = -5,
			LevelScore = 1,
		},
	},
	RewardList = {
		{
			Score = 800,
			ResultText = "太棒了！",
			RewardList = {
				{
					Value = 2,
					Num = 100,
				},
				{
					Value = 1,
					Num = 30000,
				},
			},
		},
		{
			Score = 600,
			ResultText = "非常好~",
			RewardList = {
				{
					Value = 2,
					Num = 75,
				},
				{
					Value = 1,
					Num = 25000,
				},
			},
		},
		{
			Score = 400,
			ResultText = "不错诶！",
			RewardList = {
				{
					Value = 2,
					Num = 50,
				},
				{
					Value = 1,
					Num = 20000,
				},
			},
		},
		{
			Score = 200,
			ResultText = "很一般…",
			RewardList = {
				{
					Value = 2,
					Num = 30,
				},
				{
					Value = 1,
					Num = 15000,
				},
			},
		},
		{
			Score = -1000,
			ResultText = "什么鬼！！",
			RewardList = {
				{
					Value = 2,
					Num = 10,
				},
				{
					Value = 1,
					Num = 10000,
				},
			},
		},
	},
	RankTextList = {
		{
			CommentatorName = "收藏家D先生",
			CommentatorInfo = "关注：75 粉丝：461.8万",
			BadgeIcon = {
				"TouristBadge_1",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_17",
			DescList = {
				{
					NeedScore = 500,
					Desc = "今天的表演太合我口味了，为了烘托神秘感，表演者们全程一言不发，加上其神秘的外貌，真的是完全勾起了我的好奇心。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "亲切的历史学者",
			CommentatorInfo = "关注：90 粉丝：269.0万",
			BadgeIcon = {
				"TouristBadge_2",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_15",
			DescList = {
				{
					NeedScore = 500,
					Desc = "感觉每个表演者身上都藏满了秘密，真相好好一探究竟。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "冒险家协会会长",
			CommentatorInfo = "关注：25 粉丝：151.1万",
			BadgeIcon = {
				"TouristBadge_3",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_1",
			DescList = {
				{
					NeedScore = 500,
					Desc = "看到它们，我就相信这个世界依然有无穷的未知等待着我们去探索。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "魔王的妹妹",
			CommentatorInfo = "关注：29 粉丝：244.5万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_6",
			DescList = {
				{
					NeedScore = 500,
					Desc = "魔物们想说什么，但是又不愿意告诉我。让我想起了哥哥也经常有话想对我说，但是最后又什么都不说。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "骑士团长",
			CommentatorInfo = "关注：92 粉丝：183.1万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_5",
			DescList = {
				{
					NeedScore = 500,
					Desc = "啊，啊！真是伤脑筋，到底是什么意思？好像旁边的人也不知道呢，究竟为什么要看这样的表演，但是完全欲罢不能。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "企鹅岛的马先生",
			CommentatorInfo = "关注：17 粉丝：208.2万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_23",
			DescList = {
				{
					NeedScore = 500,
					Desc = "我认为只要有足够的数据，即使对方不愿意告诉我们答案，我们也能自己找到答案！",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "博物馆馆长",
			CommentatorInfo = "关注：53 粉丝：181.0万",
			BadgeIcon = {
				"TouristBadge_2",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_13",
			DescList = {
				{
					NeedScore = 500,
					Desc = "好像我们博物馆也住着很多这样的居民，每次看到它们不知道在做什么，但是又鬼鬼祟祟的样子，我就忍不住想上去问问。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "网红小浣熊",
			CommentatorInfo = "关注：39 粉丝：327.8万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_18",
			DescList = {
				{
					NeedScore = 500,
					Desc = "小浣熊最喜欢探寻秘密了，不过表演者们真的很能藏住秘密，脑袋想得好疼呼。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "一言堂大师",
			CommentatorInfo = "关注：61 粉丝：291.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_14",
			DescList = {
				{
					NeedScore = 500,
					Desc = "世界有时就像一个最神秘悬疑的故事，处处都给予了我们想象的空间。虽然今天的演出虽然充满了悬疑，但是不知道答案也挺好的。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "假释的怪盗先生",
			CommentatorInfo = "关注：29 粉丝：205.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_16",
			DescList = {
				{
					NeedScore = 500,
					Desc = "看到这些生物我才发现自己原来并不神秘，或者说我的神秘是自己营造的，而它们才是真的神秘啊~",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
	},
}
TouristConfig[TouristID.Id020] =
{
	Id = 20,
	Name = "外星观光团20",
	Desc = "即将招待皇家图书馆的阅读爱好者们，客人们希望有知识的宠物。",
	PreChallenge = 
	{
		140613,
	},
	Weight = 1000,
	ResultText = "知识指数",
	TagList = {
		{
			Value = 561343,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 561347,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 564061,
			Score = 75,
			LevelScore = 15,
		},
		{
			Value = 564060,
			Score = 65,
			LevelScore = 13,
		},
		{
			Value = 564059,
			Score = 55,
			LevelScore = 11,
		},
		{
			Value = 564058,
			Score = 45,
			LevelScore = 9,
		},
		{
			Value = 564057,
			Score = 35,
			LevelScore = 7,
		},
		{
			Value = 564046,
			Score = 30,
			LevelScore = 6,
		},
		{
			Value = 564045,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 564044,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 564043,
			Score = 15,
			LevelScore = 3,
		},
		{
			Value = 564042,
			Score = 10,
			LevelScore = 2,
		},
		{
			Value = 560026,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 560025,
			Score = 15,
			LevelScore = 3,
		},
		{
			Value = 560024,
			Score = 10,
			LevelScore = 2,
		},
		{
			Value = 560023,
			Score = 5,
			LevelScore = 1,
		},
		{
			Value = 560022,
			Score = 0,
			LevelScore = 1,
		},
	},
	RewardList = {
		{
			Score = 800,
			ResultText = "太棒了！",
			RewardList = {
				{
					Value = 2,
					Num = 100,
				},
				{
					Value = 1,
					Num = 30000,
				},
			},
		},
		{
			Score = 600,
			ResultText = "非常好~",
			RewardList = {
				{
					Value = 2,
					Num = 75,
				},
				{
					Value = 1,
					Num = 25000,
				},
			},
		},
		{
			Score = 400,
			ResultText = "不错诶！",
			RewardList = {
				{
					Value = 2,
					Num = 50,
				},
				{
					Value = 1,
					Num = 20000,
				},
			},
		},
		{
			Score = 200,
			ResultText = "很一般…",
			RewardList = {
				{
					Value = 2,
					Num = 30,
				},
				{
					Value = 1,
					Num = 15000,
				},
			},
		},
		{
			Score = -1000,
			ResultText = "什么鬼！！",
			RewardList = {
				{
					Value = 2,
					Num = 10,
				},
				{
					Value = 1,
					Num = 10000,
				},
			},
		},
	},
	RankTextList = {
		{
			CommentatorName = "卖系统的盖茨比",
			CommentatorInfo = "关注：78 粉丝：407.4万",
			BadgeIcon = {
				"TouristBadge_1",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_24",
			DescList = {
				{
					NeedScore = 500,
					Desc = "虽然大家现在都用Doors系统在网上查阅资料了，不过阅读书本知识确实更具有仪式感。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "退休警察局长",
			CommentatorInfo = "关注：10 粉丝：279.4万",
			BadgeIcon = {
				"TouristBadge_2",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_20",
			DescList = {
				{
					NeedScore = 500,
					Desc = "退休以后依然保持了每天读报的习惯，想不到平时忽略的读物原来也能做出如此有趣的表演。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "艺术少女",
			CommentatorInfo = "关注：16 粉丝：440.0万",
			BadgeIcon = {
				"TouristBadge_3",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_19",
			DescList = {
				{
					NeedScore = 500,
					Desc = "相比看文字更喜欢看图片，像今天这样的演出就非常符合我的心意~",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "阿里山的马先生",
			CommentatorInfo = "关注：86 粉丝：160.0万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_22",
			DescList = {
				{
					NeedScore = 500,
					Desc = "文字，是一个文明的立足之本。我喜欢文字，它可以说故事，讲道理，明是非。以后，我们企业会加强线上图书的售卖，还请各位期待。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "博物馆馆长",
			CommentatorInfo = "关注：53 粉丝：181.0万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_13",
			DescList = {
				{
					NeedScore = 500,
					Desc = "这些文字作品只要好好保管，未来就是很好的历史素材啊~我们馆必须尽快加盖文史保留馆了，届时还请游客们多多捧场。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "亲切的历史学者",
			CommentatorInfo = "关注：90 粉丝：269.0万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_15",
			DescList = {
				{
					NeedScore = 500,
					Desc = "虽然现在都在电脑上编辑文档，不过我还是更习惯用纸笔来做记录。这样的表演很亲切，让我感到很温暖。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "网红小浣熊",
			CommentatorInfo = "关注：39 粉丝：327.8万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_18",
			DescList = {
				{
					NeedScore = 500,
					Desc = "唔…小浣熊看不懂…不过小浣熊知道它们都是很厉害的发明呼~听说极大地推动了文明进步呼！",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "剑圣",
			CommentatorInfo = "关注：92 粉丝：122.2万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_3",
			DescList = {
				{
					NeedScore = 500,
					Desc = "以前因为学习不好，才被送进了剑术学校。现在成名以后再来看这些读物，真是别有一番感受啊~",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "魔王的妹妹",
			CommentatorInfo = "关注：29 粉丝：244.5万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_6",
			DescList = {
				{
					NeedScore = 500,
					Desc = "虽然一直生活在魔界，但是特别喜欢人类的书本。尤其是童话书，我也好想成为一名公主啊~有没有王子来救我呢？ @剑士",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "冒险家协会会长",
			CommentatorInfo = "关注：25 粉丝：151.1万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_1",
			DescList = {
				{
					NeedScore = 500,
					Desc = "充满了文化与涵养的一场表演，和我们星球打打杀杀的表演确实不同，看来有必要组织协会的冒险者多参观这样的演出。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
	},
}
TouristConfig[TouristID.Id021] =
{
	Id = 21,
	Name = "外星观光团21",
	Desc = "即将招待美食星的美食家们，客人们希望看到让人有食欲的宠物。",
	PreChallenge = 
	{
		140211,
	},
	Weight = 1000,
	ResultText = "美味指数",
	TagList = {
		{
			Value = 561306,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 561319,
			Score = 35,
			LevelScore = 7,
		},
		{
			Value = 561312,
			Score = 35,
			LevelScore = 7,
		},
		{
			Value = 561332,
			Score = 30,
			LevelScore = 6,
		},
		{
			Value = 561334,
			Score = 30,
			LevelScore = 6,
		},
		{
			Value = 561331,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 561333,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 564126,
			Score = 35,
			LevelScore = 7,
		},
		{
			Value = 564125,
			Score = 30,
			LevelScore = 6,
		},
		{
			Value = 564124,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 564123,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 564122,
			Score = 15,
			LevelScore = 3,
		},
		{
			Value = 564141,
			Score = 35,
			LevelScore = 7,
		},
		{
			Value = 564140,
			Score = 30,
			LevelScore = 6,
		},
		{
			Value = 564139,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 564138,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 564137,
			Score = 15,
			LevelScore = 3,
		},
		{
			Value = 564111,
			Score = 30,
			LevelScore = 6,
		},
		{
			Value = 564110,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 564109,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 564108,
			Score = 15,
			LevelScore = 3,
		},
		{
			Value = 564107,
			Score = 10,
			LevelScore = 2,
		},
		{
			Value = 564131,
			Score = 30,
			LevelScore = 6,
		},
		{
			Value = 564130,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 564129,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 564128,
			Score = 15,
			LevelScore = 3,
		},
		{
			Value = 564127,
			Score = 10,
			LevelScore = 2,
		},
		{
			Value = 564136,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 564135,
			Score = 15,
			LevelScore = 3,
		},
		{
			Value = 564134,
			Score = 10,
			LevelScore = 2,
		},
		{
			Value = 564133,
			Score = 5,
			LevelScore = 1,
		},
		{
			Value = 564132,
			Score = 0,
			LevelScore = 1,
		},
		{
			Value = 564121,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 564120,
			Score = 15,
			LevelScore = 3,
		},
		{
			Value = 564119,
			Score = 10,
			LevelScore = 2,
		},
		{
			Value = 564118,
			Score = 5,
			LevelScore = 1,
		},
		{
			Value = 564117,
			Score = 0,
			LevelScore = 1,
		},
		{
			Value = 561320,
			Score = -30,
			LevelScore = 6,
		},
		{
			Value = 561321,
			Score = -80,
			LevelScore = 1,
		},
		{
			Value = 561344,
			Score = -80,
			LevelScore = 1,
		},
		{
			Value = 561305,
			Score = -80,
			LevelScore = 1,
		},
	},
	RewardList = {
		{
			Score = 800,
			ResultText = "太棒了！",
			RewardList = {
				{
					Value = 2,
					Num = 100,
				},
				{
					Value = 1,
					Num = 30000,
				},
			},
		},
		{
			Score = 600,
			ResultText = "非常好~",
			RewardList = {
				{
					Value = 2,
					Num = 75,
				},
				{
					Value = 1,
					Num = 25000,
				},
			},
		},
		{
			Score = 400,
			ResultText = "不错诶！",
			RewardList = {
				{
					Value = 2,
					Num = 50,
				},
				{
					Value = 1,
					Num = 20000,
				},
			},
		},
		{
			Score = 200,
			ResultText = "很一般…",
			RewardList = {
				{
					Value = 2,
					Num = 30,
				},
				{
					Value = 1,
					Num = 15000,
				},
			},
		},
		{
			Score = -1000,
			ResultText = "什么鬼！！",
			RewardList = {
				{
					Value = 2,
					Num = 10,
				},
				{
					Value = 1,
					Num = 10000,
				},
			},
		},
	},
	RankTextList = {
		{
			CommentatorName = "骑士团长",
			CommentatorInfo = "关注：92 粉丝：183.1万",
			BadgeIcon = {
				"TouristBadge_1",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_5",
			DescList = {
				{
					NeedScore = 500,
					Desc = "哇，太不错了~各种各样的美食，感觉像是去了国王的宴会呢~",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "精灵公主",
			CommentatorInfo = "关注：13 粉丝：179.4万",
			BadgeIcon = {
				"TouristBadge_2",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_4",
			DescList = {
				{
					NeedScore = 500,
					Desc = "丰富的口味，即使是身为公主的我也很难抗拒，等会演出结束后，就稍微去附近的夜排档看一下吧~",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "魔王的妹妹",
			CommentatorInfo = "关注：29 粉丝：244.5万",
			BadgeIcon = {
				"TouristBadge_3",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_6",
			DescList = {
				{
					NeedScore = 500,
					Desc = "哇~和魔界每顿都吃味道怪怪的绿色食物比，这里的食物实在是太丰富了~",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "怕辣的美食博主",
			CommentatorInfo = "关注：22 粉丝：333.2万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_12",
			DescList = {
				{
					NeedScore = 500,
					Desc = "虽然平时经常做美食主播，不过看美食们表演还是很特别。那么，大家最近想看我吃什么，请给我留言。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "收藏家D先生",
			CommentatorInfo = "关注：75 粉丝：461.8万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_17",
			DescList = {
				{
					NeedScore = 500,
					Desc = "虽然本人一直很注重饮食健康，不过偶尔吃一顿好的犒劳自己也是理所应当。哈，这都是因为看了今天的美食演出啊。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "酒乡的醉先生",
			CommentatorInfo = "关注：24 粉丝：182.5万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_7",
			DescList = {
				{
					NeedScore = 500,
					Desc = "唔，今天的美食如果都能来一份的话，就太适合做下酒菜了。独斟独酌，也是一番风味。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "奇迹的蛋糕师",
			CommentatorInfo = "关注：50 粉丝：453.7万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_11",
			DescList = {
				{
					NeedScore = 500,
					Desc = "啊，有灵感了！下一个蛋糕是100种食物的混合风暴，相信一定能让吃惯了普通蛋糕的人大开眼界。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "顶级大厨",
			CommentatorInfo = "关注：65 粉丝：160.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_10",
			DescList = {
				{
					NeedScore = 500,
					Desc = "别开生面的美食宴会，虽然可以看出台上的食物并不都是顶级料理，但是认真表演的神态还是很让鄙人感动。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "退休警察局长",
			CommentatorInfo = "关注：10 粉丝：279.4万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_20",
			DescList = {
				{
					NeedScore = 500,
					Desc = "不用再与罪犯打交道，每天看看美食表演真是不错的退休生活啊。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "阿里山的马先生",
			CommentatorInfo = "关注：86 粉丝：160.0万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_22",
			DescList = {
				{
					NeedScore = 500,
					Desc = "食物的核心就是新鲜与卫生，一道食物想要好吃又健康，不仅要使用正确的烹饪方法，也要在对的渠道购买。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
	},
}
TouristConfig[TouristID.Id022] =
{
	Id = 22,
	Name = "外星观光团22",
	Desc = "即将招待食肉委员会的干事们，客人们说只要看到肉就很高兴！",
	PreChallenge = 
	{
		140211,
	},
	Weight = 1000,
	ResultText = "肉感指数",
	TagList = {
		{
			Value = 561303,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 561329,
			Score = 50,
			LevelScore = 10,
		},
		{
			Value = 561312,
			Score = 70,
			LevelScore = 14,
		},
		{
			Value = 561330,
			Score = 50,
			LevelScore = 10,
		},
		{
			Value = 564126,
			Score = 55,
			LevelScore = 11,
		},
		{
			Value = 564125,
			Score = 45,
			LevelScore = 9,
		},
		{
			Value = 564124,
			Score = 35,
			LevelScore = 7,
		},
		{
			Value = 564123,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 564122,
			Score = 15,
			LevelScore = 3,
		},
		{
			Value = 564111,
			Score = 50,
			LevelScore = 10,
		},
		{
			Value = 564110,
			Score = 40,
			LevelScore = 8,
		},
		{
			Value = 564109,
			Score = 30,
			LevelScore = 6,
		},
		{
			Value = 564108,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 564107,
			Score = 10,
			LevelScore = 2,
		},
		{
			Value = 564141,
			Score = 50,
			LevelScore = 10,
		},
		{
			Value = 564140,
			Score = 40,
			LevelScore = 8,
		},
		{
			Value = 564139,
			Score = 30,
			LevelScore = 6,
		},
		{
			Value = 564138,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 564137,
			Score = 10,
			LevelScore = 2,
		},
		{
			Value = 561320,
			Score = -80,
			LevelScore = 1,
		},
		{
			Value = 561321,
			Score = -80,
			LevelScore = 1,
		},
		{
			Value = 561344,
			Score = -80,
			LevelScore = 1,
		},
		{
			Value = 561305,
			Score = -80,
			LevelScore = 1,
		},
	},
	RewardList = {
		{
			Score = 800,
			ResultText = "太棒了！",
			RewardList = {
				{
					Value = 2,
					Num = 100,
				},
				{
					Value = 1,
					Num = 30000,
				},
			},
		},
		{
			Score = 600,
			ResultText = "非常好~",
			RewardList = {
				{
					Value = 2,
					Num = 75,
				},
				{
					Value = 1,
					Num = 25000,
				},
			},
		},
		{
			Score = 400,
			ResultText = "不错诶！",
			RewardList = {
				{
					Value = 2,
					Num = 50,
				},
				{
					Value = 1,
					Num = 20000,
				},
			},
		},
		{
			Score = 200,
			ResultText = "很一般…",
			RewardList = {
				{
					Value = 2,
					Num = 30,
				},
				{
					Value = 1,
					Num = 15000,
				},
			},
		},
		{
			Score = -1000,
			ResultText = "什么鬼！！",
			RewardList = {
				{
					Value = 2,
					Num = 10,
				},
				{
					Value = 1,
					Num = 10000,
				},
			},
		},
	},
	RankTextList = {
		{
			CommentatorName = "骑士团长",
			CommentatorInfo = "关注：92 粉丝：183.1万",
			BadgeIcon = {
				"TouristBadge_1",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_5",
			DescList = {
				{
					NeedScore = 500,
					Desc = "说起对肉的喜爱，那在下在全宇宙中应该也是排得上号的！今天的肉食演出真的很棒！",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "米其森主评委",
			CommentatorInfo = "关注：100 粉丝：229.4万",
			BadgeIcon = {
				"TouristBadge_2",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_8",
			DescList = {
				{
					NeedScore = 500,
					Desc = "肉食要达到美味的地步，一定需要在烹调前经过充分的运动，这样肉质才会更细腻嫩滑…相信今天的表演者如果下锅一定很美味…",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "米其森副评委",
			CommentatorInfo = "关注：11 粉丝：437.6万",
			BadgeIcon = {
				"TouristBadge_3",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_9",
			DescList = {
				{
					NeedScore = 500,
					Desc = "如主任所言，今天的肉食非常能引发人的食欲。个人建议，观看此类演出建议先吃些东西垫垫肚子，否则会很馋。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "顶级大厨",
			CommentatorInfo = "关注：65 粉丝：160.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_10",
			DescList = {
				{
					NeedScore = 500,
					Desc = "不错，不错，表演有力且充满热情。虽然旁边的人看完后都表示饿了，不过在我眼中，这却是另一种食物的艺术。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "怕辣的美食博主",
			CommentatorInfo = "关注：22 粉丝：333.2万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_12",
			DescList = {
				{
					NeedScore = 500,
					Desc = "看到今天的演出，忍不住想起小时候吃的辣味肉料理，虽然辣的狂喝水，但是味道确实很不错。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "魔王的妹妹",
			CommentatorInfo = "关注：29 粉丝：244.5万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_6",
			DescList = {
				{
					NeedScore = 500,
					Desc = "比起魔界的巨型昆虫的肉，这些肉看起来都好健康好好吃。哎，我以后再也不吃魔界的食物了。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "奇迹的蛋糕师",
			CommentatorInfo = "关注：50 粉丝：453.7万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_11",
			DescList = {
				{
					NeedScore = 500,
					Desc = "啊，有灵感了！大家都怕蛋糕和肉一起吃会胖，我要制作一款既保有蛋糕美味，又不会和肉类发生反应的蛋糕！",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "俏江北餐饮董事",
			CommentatorInfo = "关注：46 粉丝：473.9万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_21",
			DescList = {
				{
					NeedScore = 500,
					Desc = "原来观看肉食表演可以有效提升观众的食欲，看来有必要在餐饮场所增加一些表演类项目。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "假释的怪盗先生",
			CommentatorInfo = "关注：29 粉丝：205.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_16",
			DescList = {
				{
					NeedScore = 500,
					Desc = "和艺术迥然不同的演出风格，不过鄙人也觉得非常有趣。不过其实，个人喜欢的是鸡肉料理。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "剑圣",
			CommentatorInfo = "关注：92 粉丝：122.2万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_3",
			DescList = {
				{
					NeedScore = 500,
					Desc = "嘿，想起了曾经打败的一头巨大野猪怪，一刀解决了对方以后，那家伙的肉让附近村子里所有人吃了二十多天才吃完。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
	},
}
TouristConfig[TouristID.Id023] =
{
	Id = 23,
	Name = "外星观光团23",
	Desc = "即将招待素食委员会的干事们，客人们说只要看到草就很高兴！",
	Weight = 1000,
	ResultText = "清淡指数",
	TagList = {
		{
			Value = 561320,
			Score = 55,
			LevelScore = 11,
		},
		{
			Value = 564146,
			Score = 55,
			LevelScore = 11,
		},
		{
			Value = 564145,
			Score = 45,
			LevelScore = 9,
		},
		{
			Value = 564144,
			Score = 35,
			LevelScore = 7,
		},
		{
			Value = 564143,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 564142,
			Score = 15,
			LevelScore = 3,
		},
		{
			Value = 564121,
			Score = 50,
			LevelScore = 10,
		},
		{
			Value = 564120,
			Score = 40,
			LevelScore = 8,
		},
		{
			Value = 564119,
			Score = 30,
			LevelScore = 6,
		},
		{
			Value = 564118,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 564117,
			Score = 10,
			LevelScore = 1,
		},
		{
			Value = 561303,
			Score = -80,
			LevelScore = 1,
		},
		{
			Value = 561321,
			Score = -80,
			LevelScore = 1,
		},
		{
			Value = 561344,
			Score = -80,
			LevelScore = 1,
		},
		{
			Value = 561305,
			Score = -80,
			LevelScore = 1,
		},
	},
	RewardList = {
		{
			Score = 800,
			ResultText = "太棒了！",
			RewardList = {
				{
					Value = 2,
					Num = 100,
				},
				{
					Value = 1,
					Num = 30000,
				},
			},
		},
		{
			Score = 600,
			ResultText = "非常好~",
			RewardList = {
				{
					Value = 2,
					Num = 75,
				},
				{
					Value = 1,
					Num = 25000,
				},
			},
		},
		{
			Score = 400,
			ResultText = "不错诶！",
			RewardList = {
				{
					Value = 2,
					Num = 50,
				},
				{
					Value = 1,
					Num = 20000,
				},
			},
		},
		{
			Score = 200,
			ResultText = "很一般…",
			RewardList = {
				{
					Value = 2,
					Num = 30,
				},
				{
					Value = 1,
					Num = 15000,
				},
			},
		},
		{
			Score = -1000,
			ResultText = "什么鬼！！",
			RewardList = {
				{
					Value = 2,
					Num = 10,
				},
				{
					Value = 1,
					Num = 10000,
				},
			},
		},
	},
	RankTextList = {
		{
			CommentatorName = "精灵公主",
			CommentatorInfo = "关注：13 粉丝：179.4万",
			BadgeIcon = {
				"TouristBadge_1",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_4",
			DescList = {
				{
					NeedScore = 500,
					Desc = "为了保持完美的少女身材，一直都只能吃些低热量的食物。看了今天的演出后，忽然觉得素食也不那么乏味了。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "骑士团长",
			CommentatorInfo = "关注：92 粉丝：183.1万",
			BadgeIcon = {
				"TouristBadge_2",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_5",
			DescList = {
				{
					NeedScore = 500,
					Desc = "在我看来，食物里的素菜只是摆盘时的摆设而已。不过今天的表演倒是让我也想试试看素食了。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "天使投资王少爷",
			CommentatorInfo = "关注：59 粉丝：455.6万",
			BadgeIcon = {
				"TouristBadge_3",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_25",
			DescList = {
				{
					NeedScore = 500,
					Desc = "为了调理肠胃，连续几天没有大鱼大肉了，嘴巴里发苦。今天看了素食们的演出，觉得自己坚持一下可以再吃两天。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "魔王的妹妹",
			CommentatorInfo = "关注：29 粉丝：244.5万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_6",
			DescList = {
				{
					NeedScore = 500,
					Desc = "这里的根茎类植物长得看起来都好无害，魔界的植物可是肉食性质的呢~而且只要你经过，它就会“啊呜”一口整个吞下~",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "剑圣",
			CommentatorInfo = "关注：92 粉丝：122.2万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_3",
			DescList = {
				{
					NeedScore = 500,
					Desc = "哈，想起了曾经击败的一株巨大菌菇怪，很难想象竟然可以长那么大，一刀解决后，受到村民感谢，喝了一年的菌菇汤…",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "退休警察局长",
			CommentatorInfo = "关注：10 粉丝：279.4万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_20",
			DescList = {
				{
					NeedScore = 500,
					Desc = "哎，自从去年体检查出来心血管系统老化后，就只能吃些蔬菜了，本来实在是不想再看到素菜了。不过今天的表演倒还不错。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "顶级大厨",
			CommentatorInfo = "关注：65 粉丝：160.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_10",
			DescList = {
				{
					NeedScore = 500,
					Desc = "素菜虽然口味一般，但是非常健康。其实我正在秘密研制一种万能的素菜酱料，希望既能保证口感，又能兼顾健康。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "米其森主评委",
			CommentatorInfo = "关注：100 粉丝：229.4万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_8",
			DescList = {
				{
					NeedScore = 500,
					Desc = "在下遍尝宇宙美食，也曾吃过不少非常美味的素食。不过像今天这样，看到素食如此原生态的表演还是第一次。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "米其森副评委",
			CommentatorInfo = "关注：11 粉丝：437.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_9",
			DescList = {
				{
					NeedScore = 500,
					Desc = "如主任所言，今天的表演非常别出心裁。虽然没有能够提起多少食欲，但是光是看就觉得非常健康。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "前任女王",
			CommentatorInfo = "关注：63 粉丝：486.5万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_2",
			DescList = {
				{
					NeedScore = 500,
					Desc = "看到台上的表演的第一刻，我还以为是园林景观表演，原来是素食表演啊，嗯，似乎也不错。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
	},
}
TouristConfig[TouristID.Id024] =
{
	Id = 24,
	Name = "外星观光团24",
	Desc = "即将招待未康复的色盲患者，医生建议展示宠物颜色尽量要少些，避免刺激患者。",
	Weight = 1000,
	ResultText = "灰白指数",
	TagList = {
		{
			Value = 563502,
			Score = 75,
			LevelScore = 15,
		},
		{
			Value = 563503,
			Score = 45,
			LevelScore = 9,
		},
		{
			Value = 563504,
			Score = 15,
			LevelScore = 3,
		},
		{
			Value = 563505,
			Score = -15,
			LevelScore = 3,
		},
		{
			Value = 563506,
			Score = -45,
			LevelScore = 9,
		},
		{
			Value = 563931,
			Score = 30,
			LevelScore = 6,
		},
		{
			Value = 563930,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 563929,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 563928,
			Score = 15,
			LevelScore = 3,
		},
		{
			Value = 563927,
			Score = 10,
			LevelScore = 2,
		},
		{
			Value = 563916,
			Score = 30,
			LevelScore = 6,
		},
		{
			Value = 563915,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 563914,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 563913,
			Score = 15,
			LevelScore = 3,
		},
		{
			Value = 563912,
			Score = 10,
			LevelScore = 2,
		},
		{
			Value = 563906,
			Score = 30,
			LevelScore = 6,
		},
		{
			Value = 563905,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 563904,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 563903,
			Score = 15,
			LevelScore = 3,
		},
		{
			Value = 563902,
			Score = 10,
			LevelScore = 2,
		},
		{
			Value = 563921,
			Score = -25,
			LevelScore = 5,
		},
		{
			Value = 563920,
			Score = -20,
			LevelScore = 4,
		},
		{
			Value = 563919,
			Score = -15,
			LevelScore = 3,
		},
		{
			Value = 563918,
			Score = -10,
			LevelScore = 2,
		},
		{
			Value = 563917,
			Score = -5,
			LevelScore = 1,
		},
		{
			Value = 563926,
			Score = -25,
			LevelScore = 5,
		},
		{
			Value = 563925,
			Score = -20,
			LevelScore = 4,
		},
		{
			Value = 563924,
			Score = -15,
			LevelScore = 3,
		},
		{
			Value = 563923,
			Score = -10,
			LevelScore = 2,
		},
		{
			Value = 563922,
			Score = -5,
			LevelScore = 1,
		},
		{
			Value = 563936,
			Score = -25,
			LevelScore = 5,
		},
		{
			Value = 563935,
			Score = -20,
			LevelScore = 4,
		},
		{
			Value = 563934,
			Score = -15,
			LevelScore = 3,
		},
		{
			Value = 563933,
			Score = -10,
			LevelScore = 2,
		},
		{
			Value = 563932,
			Score = -5,
			LevelScore = 1,
		},
	},
	RewardList = {
		{
			Score = 800,
			ResultText = "太棒了！",
			RewardList = {
				{
					Value = 2,
					Num = 100,
				},
				{
					Value = 1,
					Num = 30000,
				},
			},
		},
		{
			Score = 600,
			ResultText = "非常好~",
			RewardList = {
				{
					Value = 2,
					Num = 75,
				},
				{
					Value = 1,
					Num = 25000,
				},
			},
		},
		{
			Score = 400,
			ResultText = "不错诶！",
			RewardList = {
				{
					Value = 2,
					Num = 50,
				},
				{
					Value = 1,
					Num = 20000,
				},
			},
		},
		{
			Score = 200,
			ResultText = "很一般…",
			RewardList = {
				{
					Value = 2,
					Num = 30,
				},
				{
					Value = 1,
					Num = 15000,
				},
			},
		},
		{
			Score = -1000,
			ResultText = "什么鬼！！",
			RewardList = {
				{
					Value = 2,
					Num = 10,
				},
				{
					Value = 1,
					Num = 10000,
				},
			},
		},
	},
	RankTextList = {
		{
			CommentatorName = "魔王的妹妹",
			CommentatorInfo = "关注：29 粉丝：244.5万",
			BadgeIcon = {
				"TouristBadge_1",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_6",
			DescList = {
				{
					NeedScore = 500,
					Desc = "看到统一又整洁的颜色，感到心情非常舒畅，情绪也变得平和下来。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "剑圣",
			CommentatorInfo = "关注：92 粉丝：122.2万",
			BadgeIcon = {
				"TouristBadge_2",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_3",
			DescList = {
				{
					NeedScore = 500,
					Desc = "HO~不禁想起曾经打败的黑白双龙，一个口吐黑火，一个口吐白冰，若不是在下剑法登峰造极，那次可能就挂了。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "骑士团长",
			CommentatorInfo = "关注：92 粉丝：183.1万",
			BadgeIcon = {
				"TouristBadge_3",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_5",
			DescList = {
				{
					NeedScore = 500,
					Desc = "其实在下很喜欢这样的演出形式。对于骑士而言，五彩斑斓始终不够严肃，像这样单调的颜色才是属于男人的浪漫。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "卖系统的盖茨比",
			CommentatorInfo = "关注：78 粉丝：407.4万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_24",
			DescList = {
				{
					NeedScore = 500,
					Desc = "公司目前正在研发一款自带色盲矫正系统的系统，相信不久就能让所有的世界重新五彩缤纷起来。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "艺术少女",
			CommentatorInfo = "关注：16 粉丝：440.0万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_19",
			DescList = {
				{
					NeedScore = 500,
					Desc = "虽然很多艺术作品需要大量颜色才能完美表现，不过今天台上的表演证明并非所有艺术都需要应用到大量刺激性的色彩。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "退休警察局长",
			CommentatorInfo = "关注：10 粉丝：279.4万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_20",
			DescList = {
				{
					NeedScore = 500,
					Desc = "黑、白、灰，正是人们用来区分道德的颜色。今天的演出充满了深刻的主题，令我不禁陷入沉思。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "冒险家协会会长",
			CommentatorInfo = "关注：25 粉丝：151.1万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_1",
			DescList = {
				{
					NeedScore = 500,
					Desc = "在冒险世界里纯色象征着高贵的血统，相比表演者们在各自的族群里都是相当有地位的怪物。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "奇迹的蛋糕师",
			CommentatorInfo = "关注：50 粉丝：453.7万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_11",
			DescList = {
				{
					NeedScore = 500,
					Desc = "以往的蛋糕都是白色奶油和黄色蛋糕胚，今天我来尝试制作一款灰色的蛋糕吧！",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "企鹅岛的马先生",
			CommentatorInfo = "关注：17 粉丝：208.2万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_23",
			DescList = {
				{
					NeedScore = 500,
					Desc = "啊~好舒服的视觉感受，和我们公司吉祥物的颜色很相配呢~~",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "亲切的历史学者",
			CommentatorInfo = "关注：90 粉丝：269.0万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_15",
			DescList = {
				{
					NeedScore = 500,
					Desc = "其实本人也患有色弱，至今无法拿到驾照。不过看了今天的表演，倒是让在下觉得只用简单的颜色也可以构建出美妙的视觉体验。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
	},
}
TouristConfig[TouristID.Id025] =
{
	Id = 25,
	Name = "外星观光团25",
	Desc = "即将招待互助委员会的成员，希望看到虽然弱小，但是努力在提升等级的宠物~",
	Weight = 1000,
	ResultText = "努力指数",
	TagList = {
		{
			Value = 560022,
			Score = 90,
			LevelScore = 30,
		},
		{
			Value = 560023,
			Score = 75,
			LevelScore = 25,
		},
		{
			Value = 560024,
			Score = 0,
			LevelScore = 36,
		},
		{
			Value = 560025,
			Score = -30,
			LevelScore = 38,
		},
		{
			Value = 560026,
			Score = -60,
			LevelScore = 40,
		},
	},
	RewardList = {
		{
			Score = 800,
			ResultText = "太棒了！",
			RewardList = {
				{
					Value = 2,
					Num = 100,
				},
				{
					Value = 1,
					Num = 30000,
				},
			},
		},
		{
			Score = 600,
			ResultText = "非常好~",
			RewardList = {
				{
					Value = 2,
					Num = 75,
				},
				{
					Value = 1,
					Num = 25000,
				},
			},
		},
		{
			Score = 400,
			ResultText = "不错诶！",
			RewardList = {
				{
					Value = 2,
					Num = 50,
				},
				{
					Value = 1,
					Num = 20000,
				},
			},
		},
		{
			Score = 200,
			ResultText = "很一般…",
			RewardList = {
				{
					Value = 2,
					Num = 30,
				},
				{
					Value = 1,
					Num = 15000,
				},
			},
		},
		{
			Score = -1000,
			ResultText = "什么鬼！！",
			RewardList = {
				{
					Value = 2,
					Num = 10,
				},
				{
					Value = 1,
					Num = 10000,
				},
			},
		},
	},
	RankTextList = {
		{
			CommentatorName = "剑圣",
			CommentatorInfo = "关注：92 粉丝：122.2万",
			BadgeIcon = {
				"TouristBadge_1",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_3",
			DescList = {
				{
					NeedScore = 500,
					Desc = "每个生灵都在努力地活下去吗？鄙人感受到你们的心意了，以后不会再对你们轻易出手了。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "魔王的妹妹",
			CommentatorInfo = "关注：29 粉丝：244.5万",
			BadgeIcon = {
				"TouristBadge_2",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_6",
			DescList = {
				{
					NeedScore = 500,
					Desc = "忽然想起了为公司打工的骨头兵们，也在很认真地工作这~虽然总是被勇士打败，但是勇敢站起来的那刻，他们也是勇者。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "艺术少女",
			CommentatorInfo = "关注：16 粉丝：440.0万",
			BadgeIcon = {
				"TouristBadge_3",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_19",
			DescList = {
				{
					NeedScore = 500,
					Desc = "比起树林中生长的参天大树，悬崖边努力生存的野草更令人感动，就如同这些怪物，虽然弱小但是依然在努力变强。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "骑士团长",
			CommentatorInfo = "关注：92 粉丝：183.1万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_5",
			DescList = {
				{
					NeedScore = 500,
					Desc = "秉承着骑士之道，在下很少和弱小的魔物们打交道。不过今天看了表演才发现，强大与弱小往往没有绝对。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "退休警察局长",
			CommentatorInfo = "关注：10 粉丝：279.4万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_20",
			DescList = {
				{
					NeedScore = 500,
					Desc = "因为工作原因，以前很少接触各种魔物。现在看来，他们也有其可爱之处~",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "企鹅岛的马先生",
			CommentatorInfo = "关注：17 粉丝：208.2万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_23",
			DescList = {
				{
					NeedScore = 500,
					Desc = "企业创立之初也是一家小规模公司，凭着大家的努力才有了今天的规模。看到这些魔物们的表演，我很感动。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "假释的怪盗先生",
			CommentatorInfo = "关注：29 粉丝：205.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_16",
			DescList = {
				{
					NeedScore = 500,
					Desc = "作为宠物，无论是弱小的怪物或是强大的怪物，鄙人都有幸养过，不得不说的是，这些弱小魔物确实更亲近人一些。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "网红小浣熊",
			CommentatorInfo = "关注：39 粉丝：327.8万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_18",
			DescList = {
				{
					NeedScore = 500,
					Desc = "以前流浪的时候，和弱小魔物也是要抢食物吃的，不过如果对方真的很饿，小浣熊就会把食物让给对方。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "精灵公主",
			CommentatorInfo = "关注：13 粉丝：179.4万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_4",
			DescList = {
				{
					NeedScore = 500,
					Desc = "其实我还是希望我们的世界充满和平和爱，如果冒险者与怪物们也能和谐共处，那就最好了。嗯，表演真的很棒的。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "酒乡的醉先生",
			CommentatorInfo = "关注：24 粉丝：182.5万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_7",
			DescList = {
				{
					NeedScore = 500,
					Desc = "小时候欺负过家门口路过的史莱姆，现在感到太懊恼了，对不起，魔物们，你们也是了不起的生命啊。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
	},
}
TouristConfig[TouristID.Id026] =
{
	Id = 26,
	Name = "外星观光团26",
	Desc = "即将招待“弱贝尔数学奖”的候选人们，大家喜欢研究几何形状的物体。",
	PreChallenge = 
	{
		140416,
	},
	Weight = 1000,
	ResultText = "工整指数",
	TagList = {
		{
			Value = 563606,
			Score = 100,
			LevelScore = 20,
		},
		{
			Value = 563605,
			Score = 85,
			LevelScore = 17,
		},
		{
			Value = 563604,
			Score = 70,
			LevelScore = 14,
		},
		{
			Value = 563603,
			Score = 55,
			LevelScore = 11,
		},
		{
			Value = 563602,
			Score = 40,
			LevelScore = 8,
		},
		{
			Value = 563621,
			Score = 100,
			LevelScore = 20,
		},
		{
			Value = 563620,
			Score = 85,
			LevelScore = 17,
		},
		{
			Value = 563619,
			Score = 70,
			LevelScore = 14,
		},
		{
			Value = 563618,
			Score = 55,
			LevelScore = 11,
		},
		{
			Value = 563617,
			Score = 40,
			LevelScore = 8,
		},
		{
			Value = 563626,
			Score = 40,
			LevelScore = 8,
		},
		{
			Value = 563625,
			Score = 35,
			LevelScore = 7,
		},
		{
			Value = 563624,
			Score = 30,
			LevelScore = 6,
		},
		{
			Value = 563623,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 563622,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 563816,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 563815,
			Score = 16,
			LevelScore = 3,
		},
		{
			Value = 563814,
			Score = 12,
			LevelScore = 2,
		},
		{
			Value = 563813,
			Score = 8,
			LevelScore = 1,
		},
		{
			Value = 563812,
			Score = 4,
			LevelScore = 1,
		},
		{
			Value = 563611,
			Score = -50,
			LevelScore = 10,
		},
		{
			Value = 563610,
			Score = -40,
			LevelScore = 8,
		},
		{
			Value = 563609,
			Score = -30,
			LevelScore = 6,
		},
		{
			Value = 563608,
			Score = -20,
			LevelScore = 4,
		},
		{
			Value = 563607,
			Score = -10,
			LevelScore = 2,
		},
		{
			Value = 563616,
			Score = -30,
			LevelScore = 6,
		},
		{
			Value = 563615,
			Score = -25,
			LevelScore = 5,
		},
		{
			Value = 563614,
			Score = -20,
			LevelScore = 4,
		},
		{
			Value = 563613,
			Score = -15,
			LevelScore = 3,
		},
		{
			Value = 563612,
			Score = -10,
			LevelScore = 2,
		},
		{
			Value = 563711,
			Score = -20,
			LevelScore = 4,
		},
		{
			Value = 563710,
			Score = -15,
			LevelScore = 3,
		},
		{
			Value = 563709,
			Score = -10,
			LevelScore = 2,
		},
		{
			Value = 563708,
			Score = -5,
			LevelScore = 1,
		},
		{
			Value = 563707,
			Score = 0,
			LevelScore = 0,
		},
	},
	RewardList = {
		{
			Score = 800,
			ResultText = "太棒了！",
			RewardList = {
				{
					Value = 2,
					Num = 100,
				},
				{
					Value = 1,
					Num = 30000,
				},
			},
		},
		{
			Score = 600,
			ResultText = "非常好~",
			RewardList = {
				{
					Value = 2,
					Num = 75,
				},
				{
					Value = 1,
					Num = 25000,
				},
			},
		},
		{
			Score = 400,
			ResultText = "不错诶！",
			RewardList = {
				{
					Value = 2,
					Num = 50,
				},
				{
					Value = 1,
					Num = 20000,
				},
			},
		},
		{
			Score = 200,
			ResultText = "很一般…",
			RewardList = {
				{
					Value = 2,
					Num = 30,
				},
				{
					Value = 1,
					Num = 15000,
				},
			},
		},
		{
			Score = -1000,
			ResultText = "什么鬼！！",
			RewardList = {
				{
					Value = 2,
					Num = 10,
				},
				{
					Value = 1,
					Num = 10000,
				},
			},
		},
	},
	RankTextList = {
		{
			CommentatorName = "博物馆馆长",
			CommentatorInfo = "关注：53 粉丝：181.0万",
			BadgeIcon = {
				"TouristBadge_1",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_13",
			DescList = {
				{
					NeedScore = 500,
					Desc = "想不到如此简单的图形也能有这么优秀的演出效果。虽然只是方形和圆形的组合，但是视觉感受却美轮美奂。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "剑圣",
			CommentatorInfo = "关注：92 粉丝：122.2万",
			BadgeIcon = {
				"TouristBadge_2",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_3",
			DescList = {
				{
					NeedScore = 500,
					Desc = "啊，非常规整的形状，让我想起了在某一届剑术大赛上为评委们演示的一剑切圆，那真的是完美的圆形。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "退休警察局长",
			CommentatorInfo = "关注：10 粉丝：279.4万",
			BadgeIcon = {
				"TouristBadge_3",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_20",
			DescList = {
				{
					NeedScore = 500,
					Desc = "曾经经手过的案件里，就有使用几何原理布置机关的，当时由衷感叹几何的奥妙。想不到今天又看见了，",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "网红小浣熊",
			CommentatorInfo = "关注：39 粉丝：327.8万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_18",
			DescList = {
				{
					NeedScore = 500,
					Desc = "小时候在马戏团也被训练要按照命令选出正确的形状呢，那时候小浣熊可是马戏团第一名噢~啊，这个演出真不错。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "一言堂大师",
			CommentatorInfo = "关注：61 粉丝：291.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_14",
			DescList = {
				{
					NeedScore = 500,
					Desc = "本来想看到名不副实的演出，就冲上前去用手中的正义之锤粉碎它们，不过发现表演如此完美，在下就无可奈何了。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "收藏家D先生",
			CommentatorInfo = "关注：75 粉丝：461.8万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_17",
			DescList = {
				{
					NeedScore = 500,
					Desc = "比起规整的图形，更喜欢艺术感的形状。而确切地说，艺术是没有形状的。不过看了这场表演，我也确实能感受到规整的美。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "米其森主评委",
			CommentatorInfo = "关注：100 粉丝：229.4万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_8",
			DescList = {
				{
					NeedScore = 500,
					Desc = "世间的道理都是相通的，漂亮的食物其实也暗合几何形状。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "米其森副评委",
			CommentatorInfo = "关注：11 粉丝：437.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_9",
			DescList = {
				{
					NeedScore = 500,
					Desc = "如主任所言，以后在为食物打分时，也会参考食物的形状是否符合优秀的几何性质。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "艺术少女",
			CommentatorInfo = "关注：16 粉丝：440.0万",
			BadgeIcon = {
				"TouristBadge_1",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_19",
			DescList = {
				{
					NeedScore = 500,
					Desc = "完美的几何图形，充满了整洁感！",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "骑士团长",
			CommentatorInfo = "关注：92 粉丝：183.1万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_5",
			DescList = {
				{
					NeedScore = 500,
					Desc = "如此有趣的形状，如果不是冒险家协会会长为在下科普，实在是很难现象它们也是怪物呢。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
	},
}
TouristConfig[TouristID.Id027] =
{
	Id = 27,
	Name = "外星观光团27",
	Desc = "即将招待来自猎人协会的见习生们，客人们很想看一下用陷阱捕捉的宠物。",
	PreChallenge = 
	{
		140015,
	},
	Weight = 1000,
	ResultText = "稀有指数",
	TagList = {
		{
			Value = 563102,
			Score = 80,
			LevelScore = 16,
		},
		{
			Value = 563103,
			Score = -80,
			LevelScore = 1,
		},
		{
			Value = 563104,
			Score = -80,
			LevelScore = 1,
		},
		{
			Value = 563105,
			Score = -80,
			LevelScore = 1,
		},
		{
			Value = 563106,
			Score = -80,
			LevelScore = 1,
		},
		{
			Value = 560026,
			Score = 30,
			LevelScore = 6,
		},
		{
			Value = 560025,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 560024,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 560023,
			Score = 15,
			LevelScore = 3,
		},
		{
			Value = 560022,
			Score = 10,
			LevelScore = 2,
		},
	},
	RewardList = {
		{
			Score = 800,
			ResultText = "太棒了！",
			RewardList = {
				{
					Value = 2,
					Num = 100,
				},
				{
					Value = 1,
					Num = 30000,
				},
			},
		},
		{
			Score = 600,
			ResultText = "非常好~",
			RewardList = {
				{
					Value = 2,
					Num = 75,
				},
				{
					Value = 1,
					Num = 25000,
				},
			},
		},
		{
			Score = 400,
			ResultText = "不错诶！",
			RewardList = {
				{
					Value = 2,
					Num = 50,
				},
				{
					Value = 1,
					Num = 20000,
				},
			},
		},
		{
			Score = 200,
			ResultText = "很一般…",
			RewardList = {
				{
					Value = 2,
					Num = 30,
				},
				{
					Value = 1,
					Num = 15000,
				},
			},
		},
		{
			Score = -1000,
			ResultText = "什么鬼！！",
			RewardList = {
				{
					Value = 2,
					Num = 10,
				},
				{
					Value = 1,
					Num = 10000,
				},
			},
		},
	},
	RankTextList = {
		{
			CommentatorName = "冒险家协会会长",
			CommentatorInfo = "关注：25 粉丝：151.1万",
			BadgeIcon = {
				"TouristBadge_1",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_1",
			DescList = {
				{
					NeedScore = 500,
					Desc = "在此提醒大家，如果收养了宠物就一定要好好照顾宠物，千万不要随意遗弃它们。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "怕辣的美食博主",
			CommentatorInfo = "关注：22 粉丝：333.2万",
			BadgeIcon = {
				"TouristBadge_2",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_12",
			DescList = {
				{
					NeedScore = 500,
					Desc = "小时候和哥哥就制作过简易的陷阱，捕捉家门口啄食的鸟雀呢~啊，真是勾起同年回忆的演出啊。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "退休警察局长",
			CommentatorInfo = "关注：10 粉丝：279.4万",
			BadgeIcon = {
				"TouristBadge_3",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_20",
			DescList = {
				{
					NeedScore = 500,
					Desc = "警方再次提醒，和野生动物打交道时，请一定要保持距离，如果被咬伤，记得尽快就医。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "网红小浣熊",
			CommentatorInfo = "关注：39 粉丝：327.8万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_18",
			DescList = {
				{
					NeedScore = 500,
					Desc = "听说陷阱里会摆上野生怪物们喜欢的诱饵，我想就算是小浣熊我也很难抗拒，一定会在拿诱饵时被抓住的。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "天使投资王少爷",
			CommentatorInfo = "关注：59 粉丝：455.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_25",
			DescList = {
				{
					NeedScore = 500,
					Desc = "原来星际图鉴上的宠物捕捉是这个意思。亏我研究了半天，最后给了差评…得去撤销差评了。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "前任女王",
			CommentatorInfo = "关注：63 粉丝：486.5万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_2",
			DescList = {
				{
					NeedScore = 500,
					Desc = "好像无论多大多小的生物都能捕捉，实在是太奇妙了。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "魔王的妹妹",
			CommentatorInfo = "关注：29 粉丝：244.5万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_6",
			DescList = {
				{
					NeedScore = 500,
					Desc = "虽然演出很精彩，但是还是想提醒小动物们，如果遇到天上掉下来的食物，千万要当心噢~",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "假释的怪盗先生",
			CommentatorInfo = "关注：29 粉丝：205.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_16",
			DescList = {
				{
					NeedScore = 500,
					Desc = "用简单的机械机构就完成了捕捉，人类从某种方面来说，真是自然的克星啊。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "酒乡的醉先生",
			CommentatorInfo = "关注：24 粉丝：182.5万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_7",
			DescList = {
				{
					NeedScore = 500,
					Desc = "哈哈哈哈，看了这么有趣的表演，忽然想起来自己有次喝醉酒，晃晃悠悠地撞进了陷阱，第二天人家还以为抓到了大野猪呢~",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "顶级大厨",
			CommentatorInfo = "关注：65 粉丝：160.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_10",
			DescList = {
				{
					NeedScore = 500,
					Desc = "野生动物们因为受了诱惑而被人们捉住，人们又何尝不是受了各种诱惑，而被贪念逮住呢？",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
	},
}
TouristConfig[TouristID.Id028] =
{
	Id = 28,
	Name = "外星观光团28",
	Desc = "即将招待来自空瓶回收站的工作者们，客人们很想看一下用空瓶捕捉的宠物。",
	PreChallenge = 
	{
		140204,
	},
	Weight = 1000,
	ResultText = "稀有指数",
	TagList = {
		{
			Value = 563103,
			Score = 80,
			LevelScore = 16,
		},
		{
			Value = 563102,
			Score = -80,
			LevelScore = 1,
		},
		{
			Value = 563104,
			Score = -80,
			LevelScore = 1,
		},
		{
			Value = 563105,
			Score = -80,
			LevelScore = 1,
		},
		{
			Value = 563106,
			Score = -80,
			LevelScore = 1,
		},
		{
			Value = 560026,
			Score = 30,
			LevelScore = 6,
		},
		{
			Value = 560025,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 560024,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 560023,
			Score = 15,
			LevelScore = 3,
		},
		{
			Value = 560022,
			Score = 10,
			LevelScore = 2,
		},
	},
	RewardList = {
		{
			Score = 800,
			ResultText = "太棒了！",
			RewardList = {
				{
					Value = 2,
					Num = 100,
				},
				{
					Value = 1,
					Num = 30000,
				},
			},
		},
		{
			Score = 600,
			ResultText = "非常好~",
			RewardList = {
				{
					Value = 2,
					Num = 75,
				},
				{
					Value = 1,
					Num = 25000,
				},
			},
		},
		{
			Score = 400,
			ResultText = "不错诶！",
			RewardList = {
				{
					Value = 2,
					Num = 50,
				},
				{
					Value = 1,
					Num = 20000,
				},
			},
		},
		{
			Score = 200,
			ResultText = "很一般…",
			RewardList = {
				{
					Value = 2,
					Num = 30,
				},
				{
					Value = 1,
					Num = 15000,
				},
			},
		},
		{
			Score = -1000,
			ResultText = "什么鬼！！",
			RewardList = {
				{
					Value = 2,
					Num = 10,
				},
				{
					Value = 1,
					Num = 10000,
				},
			},
		},
	},
	RankTextList = {
		{
			CommentatorName = "冒险家协会会长",
			CommentatorInfo = "关注：25 粉丝：151.1万",
			BadgeIcon = {
				"TouristBadge_1",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_1",
			DescList = {
				{
					NeedScore = 500,
					Desc = "刚听说喝剩的空瓶竟然可以捕捉怪物时，我还以为只是开玩笑而已。想不到竟然真的有这么多怪物可以用空瓶捕捉。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "精灵公主",
			CommentatorInfo = "关注：13 粉丝：179.4万",
			BadgeIcon = {
				"TouristBadge_2",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_4",
			DescList = {
				{
					NeedScore = 500,
					Desc = "听说人们会用空瓶捕捉潜入人间的妖精，不过今天看来，似乎种类非常繁多呢~",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "网红小浣熊",
			CommentatorInfo = "关注：39 粉丝：327.8万",
			BadgeIcon = {
				"TouristBadge_3",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_18",
			DescList = {
				{
					NeedScore = 500,
					Desc = "被捕捉的时候一定感到很害怕吧。回想起来，小浣熊刚出生的时候就是在马戏团里的，而且一直被人很友善地对待着呢。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "收藏家D先生",
			CommentatorInfo = "关注：75 粉丝：461.8万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_17",
			DescList = {
				{
					NeedScore = 500,
					Desc = "确实是与众不同的演出，原来这些野外的怪物们可以用如此朴素的道具捕捉，真是大开眼界了。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "奇迹的蛋糕师",
			CommentatorInfo = "关注：50 粉丝：453.7万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_11",
			DescList = {
				{
					NeedScore = 500,
					Desc = "原来空瓶还有这样的用处，感觉之前丢掉的都浪费了呢。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "骑士团长",
			CommentatorInfo = "关注：92 粉丝：183.1万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_5",
			DescList = {
				{
					NeedScore = 500,
					Desc = "之前也尝试过用空瓶捕捉怪物，不过好像我都失败了，看来应该还有其他的窍门需要注意。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "酒乡的醉先生",
			CommentatorInfo = "关注：24 粉丝：182.5万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_7",
			DescList = {
				{
					NeedScore = 500,
					Desc = "嘿嘿，看来都是好那瓶中之物的家伙，要不然怎么会被这样的东西抓住呢？",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "魔王的妹妹",
			CommentatorInfo = "关注：29 粉丝：244.5万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_6",
			DescList = {
				{
					NeedScore = 500,
					Desc = "哇，很难想象它们在瓶子里会是什么样的呢~太调皮了，就这么被抓住了。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "艺术少女",
			CommentatorInfo = "关注：16 粉丝：440.0万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_19",
			DescList = {
				{
					NeedScore = 500,
					Desc = "我一直很好奇冒险家们是怎么捕捉怪物的呢，原来竟然是用这么普通的道具呀~",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "阿里山的马先生",
			CommentatorInfo = "关注：86 粉丝：160.0万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_22",
			DescList = {
				{
					NeedScore = 500,
					Desc = "要多发现多利用我们身边的资源，你比方说这个空瓶，我就没想到还能这样用，但是有人就想到了，是吧？",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
	},
}
TouristConfig[TouristID.Id029] =
{
	Id = 29,
	Name = "外星观光团29",
	Desc = "即将招待来自打包协会的专家们，客人们很想看一下用纸袋捕捉的宠物。",
	PreChallenge = 
	{
		140219,
	},
	Weight = 1000,
	ResultText = "稀有指数",
	TagList = {
		{
			Value = 563104,
			Score = 80,
			LevelScore = 16,
		},
		{
			Value = 563102,
			Score = -80,
			LevelScore = 1,
		},
		{
			Value = 563103,
			Score = -80,
			LevelScore = 1,
		},
		{
			Value = 563105,
			Score = -80,
			LevelScore = 1,
		},
		{
			Value = 563106,
			Score = -80,
			LevelScore = 1,
		},
		{
			Value = 560026,
			Score = 30,
			LevelScore = 6,
		},
		{
			Value = 560025,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 560024,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 560023,
			Score = 15,
			LevelScore = 3,
		},
		{
			Value = 560022,
			Score = 10,
			LevelScore = 2,
		},
	},
	RewardList = {
		{
			Score = 800,
			ResultText = "太棒了！",
			RewardList = {
				{
					Value = 2,
					Num = 100,
				},
				{
					Value = 1,
					Num = 30000,
				},
			},
		},
		{
			Score = 600,
			ResultText = "非常好~",
			RewardList = {
				{
					Value = 2,
					Num = 75,
				},
				{
					Value = 1,
					Num = 25000,
				},
			},
		},
		{
			Score = 400,
			ResultText = "不错诶！",
			RewardList = {
				{
					Value = 2,
					Num = 50,
				},
				{
					Value = 1,
					Num = 20000,
				},
			},
		},
		{
			Score = 200,
			ResultText = "很一般…",
			RewardList = {
				{
					Value = 2,
					Num = 30,
				},
				{
					Value = 1,
					Num = 15000,
				},
			},
		},
		{
			Score = -1000,
			ResultText = "什么鬼！！",
			RewardList = {
				{
					Value = 2,
					Num = 10,
				},
				{
					Value = 1,
					Num = 10000,
				},
			},
		},
	},
	RankTextList = {
		{
			CommentatorName = "奇迹的蛋糕师",
			CommentatorInfo = "关注：50 粉丝：453.7万",
			BadgeIcon = {
				"TouristBadge_1",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_11",
			DescList = {
				{
					NeedScore = 500,
					Desc = "非常有趣的表演~原来平时用来打包蛋糕的纸袋还能有这样的用处。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "网红小浣熊",
			CommentatorInfo = "关注：39 粉丝：327.8万",
			BadgeIcon = {
				"TouristBadge_2",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_18",
			DescList = {
				{
					NeedScore = 500,
					Desc = "之前订购外卖的时候用的就是这种包装纸，啊，太有趣了，小浣熊自己也钻进去过了，里面还挺暖和挺舒服的。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "米其森主评委",
			CommentatorInfo = "关注：100 粉丝：229.4万",
			BadgeIcon = {
				"TouristBadge_3",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_8",
			DescList = {
				{
					NeedScore = 500,
					Desc = "很少评价外送食品，正在研究纸袋打包对食物的影响，所以才报了这个团，不过没想到的是表演竟然这么精彩，完全忘了研究的事情…",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "米其森副评委",
			CommentatorInfo = "关注：11 粉丝：437.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_9",
			DescList = {
				{
					NeedScore = 500,
					Desc = "如主任所言，正打算拓展评价业务。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "艺术少女",
			CommentatorInfo = "关注：16 粉丝：440.0万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_19",
			DescList = {
				{
					NeedScore = 500,
					Desc = "之前帮助几家外送公司做过包装设计呢~不知道好看的包装会不会更容易抓到怪物呢？",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "奇迹的蛋糕师",
			CommentatorInfo = "关注：50 粉丝：453.7万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_11",
			DescList = {
				{
					NeedScore = 500,
					Desc = "因为参观了今天的纸袋捕捉秀，忽然来了灵感！鄙人打算拓展外送业务了~现在快递这么发达，生意一定很好！",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "顶级大厨",
			CommentatorInfo = "关注：65 粉丝：160.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_10",
			DescList = {
				{
					NeedScore = 500,
					Desc = "鄙人一生都在用自己的大勺与这样的食物交战，不过今天闻到味道时，我就知道鄙人的征途还有很长距离要走。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "俏江北餐饮董事",
			CommentatorInfo = "关注：46 粉丝：473.9万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_21",
			DescList = {
				{
					NeedScore = 500,
					Desc = "本店最近也加入了外送打包服务，使用的是最高级的恒温",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "退休警察局长",
			CommentatorInfo = "关注：10 粉丝：279.4万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_20",
			DescList = {
				{
					NeedScore = 500,
					Desc = "说起来真是不好意思，这些似乎都是我们警局每天点外卖后丢弃的外送打包盒呢…",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "假释的怪盗先生",
			CommentatorInfo = "关注：29 粉丝：205.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_16",
			DescList = {
				{
					NeedScore = 500,
					Desc = "其实关押期间，看到狱警们每天都只吃外卖，在下也感到很心酸，以后我会尽量不给警方添麻烦的。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
	},
}
TouristConfig[TouristID.Id030] =
{
	Id = 30,
	Name = "外星观光团30",
	Desc = "即将招待来自工具之家的动手爱好者们，客人们很想看一下用工具箱捕捉的宠物。",
	PreChallenge = 
	{
		140416,
	},
	Weight = 1000,
	ResultText = "稀有指数",
	TagList = {
		{
			Value = 563105,
			Score = 80,
			LevelScore = 16,
		},
		{
			Value = 563102,
			Score = -80,
			LevelScore = 1,
		},
		{
			Value = 563103,
			Score = -80,
			LevelScore = 1,
		},
		{
			Value = 563104,
			Score = -80,
			LevelScore = 1,
		},
		{
			Value = 563106,
			Score = -80,
			LevelScore = 1,
		},
		{
			Value = 560026,
			Score = 30,
			LevelScore = 6,
		},
		{
			Value = 560025,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 560024,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 560023,
			Score = 15,
			LevelScore = 3,
		},
		{
			Value = 560022,
			Score = 10,
			LevelScore = 2,
		},
	},
	RewardList = {
		{
			Score = 800,
			ResultText = "太棒了！",
			RewardList = {
				{
					Value = 2,
					Num = 100,
				},
				{
					Value = 1,
					Num = 30000,
				},
			},
		},
		{
			Score = 600,
			ResultText = "非常好~",
			RewardList = {
				{
					Value = 2,
					Num = 75,
				},
				{
					Value = 1,
					Num = 25000,
				},
			},
		},
		{
			Score = 400,
			ResultText = "不错诶！",
			RewardList = {
				{
					Value = 2,
					Num = 50,
				},
				{
					Value = 1,
					Num = 20000,
				},
			},
		},
		{
			Score = 200,
			ResultText = "很一般…",
			RewardList = {
				{
					Value = 2,
					Num = 30,
				},
				{
					Value = 1,
					Num = 15000,
				},
			},
		},
		{
			Score = -1000,
			ResultText = "什么鬼！！",
			RewardList = {
				{
					Value = 2,
					Num = 10,
				},
				{
					Value = 1,
					Num = 10000,
				},
			},
		},
	},
	RankTextList = {
		{
			CommentatorName = "卖系统的盖茨比",
			CommentatorInfo = "关注：78 粉丝：407.4万",
			BadgeIcon = {
				"TouristBadge_1",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_24",
			DescList = {
				{
					NeedScore = 500,
					Desc = "小时候就喜欢在家里的车库里倒腾发明，虽然现在已经有很多钱了，但是还是感到自己动手很有乐趣。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "网红小浣熊",
			CommentatorInfo = "关注：39 粉丝：327.8万",
			BadgeIcon = {
				"TouristBadge_2",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_18",
			DescList = {
				{
					NeedScore = 500,
					Desc = "唔，自从关注的人有了100w了以后，小浣熊也有了自己的工作箱呢~不过里面放的都是平时爱吃的小零食。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "米其森主评委",
			CommentatorInfo = "关注：100 粉丝：229.4万",
			BadgeIcon = {
				"TouristBadge_3",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_8",
			DescList = {
				{
					NeedScore = 500,
					Desc = "哇，太了不起了。在下可是完全的工具白痴，之前从网上订购了一个自拼装椅子，最后也没有装起来。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "米其森副评委",
			CommentatorInfo = "关注：11 粉丝：437.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_9",
			DescList = {
				{
					NeedScore = 500,
					Desc = "如主任所言，那些让用户自己拼装的家具务必要给足够的提示啊！！否则买回去装不起来就麻烦了。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "剑圣",
			CommentatorInfo = "关注：92 粉丝：122.2万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_3",
			DescList = {
				{
					NeedScore = 500,
					Desc = "虽然很少使用工具，但是看到工匠们灵活地使用工具箱来进行各种作业，在下还是非常钦佩。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "阿里山的马先生",
			CommentatorInfo = "关注：86 粉丝：160.0万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_22",
			DescList = {
				{
					NeedScore = 500,
					Desc = "公司在上升时期曾经依靠卖工具箱大赚了一笔，广告语是每个男人这辈子都应该有个自己的工具箱。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "奇迹的蛋糕师",
			CommentatorInfo = "关注：50 粉丝：453.7万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_11",
			DescList = {
				{
					NeedScore = 500,
					Desc = "看来也是买个工具箱的时候了~",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "博物馆馆长",
			CommentatorInfo = "关注：53 粉丝：181.0万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_13",
			DescList = {
				{
					NeedScore = 500,
					Desc = "其实这样的工具箱我们博物馆的库房里还有很多。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "天使投资王少爷",
			CommentatorInfo = "关注：59 粉丝：455.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_25",
			DescList = {
				{
					NeedScore = 500,
					Desc = "作为喜欢亲自动手的富二代，在下也有自己的工具箱噢~",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "冒险家协会会长",
			CommentatorInfo = "关注：25 粉丝：151.1万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_1",
			DescList = {
				{
					NeedScore = 500,
					Desc = "如果是外出冒险的话，一定要做足准备工作。有时候一件简单的道具就能救你一命噢~",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
	},
}
TouristConfig[TouristID.Id031] =
{
	Id = 31,
	Name = "外星观光团31",
	Desc = "即将招待来自网购星的购物爱好者们，客人们很想看一下用纸板箱捕捉的宠物。",
	PreChallenge = 
	{
		140613,
	},
	Weight = 1000,
	ResultText = "稀有指数",
	TagList = {
		{
			Value = 563106,
			Score = 80,
			LevelScore = 16,
		},
		{
			Value = 563102,
			Score = -80,
			LevelScore = 1,
		},
		{
			Value = 563103,
			Score = -80,
			LevelScore = 1,
		},
		{
			Value = 563104,
			Score = -80,
			LevelScore = 1,
		},
		{
			Value = 563105,
			Score = -80,
			LevelScore = 1,
		},
		{
			Value = 560026,
			Score = 30,
			LevelScore = 6,
		},
		{
			Value = 560025,
			Score = 25,
			LevelScore = 5,
		},
		{
			Value = 560024,
			Score = 20,
			LevelScore = 4,
		},
		{
			Value = 560023,
			Score = 15,
			LevelScore = 3,
		},
		{
			Value = 560022,
			Score = 10,
			LevelScore = 2,
		},
	},
	RewardList = {
		{
			Score = 800,
			ResultText = "太棒了！",
			RewardList = {
				{
					Value = 2,
					Num = 100,
				},
				{
					Value = 1,
					Num = 30000,
				},
			},
		},
		{
			Score = 600,
			ResultText = "非常好~",
			RewardList = {
				{
					Value = 2,
					Num = 75,
				},
				{
					Value = 1,
					Num = 25000,
				},
			},
		},
		{
			Score = 400,
			ResultText = "不错诶！",
			RewardList = {
				{
					Value = 2,
					Num = 50,
				},
				{
					Value = 1,
					Num = 20000,
				},
			},
		},
		{
			Score = 200,
			ResultText = "很一般…",
			RewardList = {
				{
					Value = 2,
					Num = 30,
				},
				{
					Value = 1,
					Num = 15000,
				},
			},
		},
		{
			Score = -1000,
			ResultText = "什么鬼！！",
			RewardList = {
				{
					Value = 2,
					Num = 10,
				},
				{
					Value = 1,
					Num = 10000,
				},
			},
		},
	},
	RankTextList = {
		{
			CommentatorName = "阿里山的马先生",
			CommentatorInfo = "关注：86 粉丝：160.0万",
			BadgeIcon = {
				"TouristBadge_1",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_22",
			DescList = {
				{
					NeedScore = 500,
					Desc = "最好的快递包装就是你的快递出库时和到你手里时是一模一样的，这就是我们企业正在打造的新标准！",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "顶级大厨",
			CommentatorInfo = "关注：65 粉丝：160.6万",
			BadgeIcon = {
				"TouristBadge_2",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_10",
			DescList = {
				{
					NeedScore = 500,
					Desc = "想起来一次糟糕的网购体验…那次购买的鲜鱼，一年后才收到，不过商家贴心地帮忙换成了咸鱼了。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "亲切的历史学者",
			CommentatorInfo = "关注：90 粉丝：269.0万",
			BadgeIcon = {
				"TouristBadge_3",
			},
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_15",
			DescList = {
				{
					NeedScore = 500,
					Desc = "和以前比，现在实在是方便太多了。只要待在家里用网络就能买到各种必备物资了。",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "退休警察局长",
			CommentatorInfo = "关注：10 粉丝：279.4万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_20",
			DescList = {
				{
					NeedScore = 500,
					Desc = "最近流行炸弹邮件诈骗，当电话通知你你的包裹涉险违法时，请不要着急，更不要轻信对方进行转账操作！",
				},
				{
					NeedScore = -1000,
					Desc = "虽然没有得到预期的体验，不过还是感受到了主办方的热情。",
				},
			},
		},
		{
			CommentatorName = "精灵公主",
			CommentatorInfo = "关注：13 粉丝：179.4万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_4",
			DescList = {
				{
					NeedScore = 500,
					Desc = "多亏了网上购物，自从精灵城铺设了5G网络后，我也能买到外星的特产了~",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "艺术少女",
			CommentatorInfo = "关注：16 粉丝：440.0万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_19",
			DescList = {
				{
					NeedScore = 500,
					Desc = "平时一直在网上购买需要的东西，无论是书本或是学习用具，真的是非常方便呢~",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "剑圣",
			CommentatorInfo = "关注：92 粉丝：122.2万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_3",
			DescList = {
				{
					NeedScore = 500,
					Desc = "因为四处漂泊，所以从来没有享受到过快递服务的便利，不过那个纸箱看起来真的很坚固。",
				},
				{
					NeedScore = -1000,
					Desc = "系统默认好评",
				},
			},
		},
		{
			CommentatorName = "骑士团长",
			CommentatorInfo = "关注：92 粉丝：183.1万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_5",
			DescList = {
				{
					NeedScore = 500,
					Desc = "在下的想法和剑圣先生一样，如同铠甲般结识的纸箱，相信对其中的物品一定起到了至关重要的保护。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "一言堂大师",
			CommentatorInfo = "关注：61 粉丝：291.6万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_14",
			DescList = {
				{
					NeedScore = 500,
					Desc = "上次想用在下那把杂碎一切赝品的锤子拆快递，不过想不到纸板箱那么结识，最后在下的锤子反而坏了。",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
		{
			CommentatorName = "网红小浣熊",
			CommentatorInfo = "关注：39 粉丝：327.8万",
			Bundle = "atlas_zoo",
			Atlas = "Zoo",
			Icon = "TouristCritic_18",
			DescList = {
				{
					NeedScore = 500,
					Desc = "小浣熊平时喜欢把不用的纸板箱都留着，需要的时候可以放东西用呢~~",
				},
				{
					NeedScore = -1000,
					Desc = "该怎么说呢，似乎也花了心思，但是总觉得哪里不对。",
				},
			},
		},
	},
}

