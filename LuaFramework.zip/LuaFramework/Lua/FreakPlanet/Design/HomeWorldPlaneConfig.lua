---------------------
---这个lua为自动导出配置
---------------------



HomeWorldPlaneConfig = {}

HomeWorldPlaneConfig["Ground"] = 
{
	GridType = 1,
	ColCount = 73,
	RowCount = 76,
	Zones = 
	{
		{x = 0, y = 60, w = 1, h = 16, },
		{x = 1, y = 61, w = 1, h = 15, },
		{x = 2, y = 62, w = 1, h = 14, },
		{x = 3, y = 63, w = 1, h = 13, },
		{x = 4, y = 64, w = 1, h = 12, },
		{x = 5, y = 65, w = 1, h = 11, },
		{x = 6, y = 66, w = 1, h = 10, },
		{x = 7, y = 67, w = 1, h = 9, },
		{x = 8, y = 68, w = 1, h = 8, },
		{x = 9, y = 69, w = 1, h = 7, },
		{x = 10, y = 70, w = 1, h = 6, },
		{x = 11, y = 71, w = 1, h = 5, },
		{x = 12, y = 72, w = 1, h = 4, },
		{x = 13, y = 73, w = 1, h = 3, },
		{x = 14, y = 74, w = 1, h = 2, },
		{x = 15, y = 75, w = 1, h = 1, },
	},
}
HomeWorldPlaneConfig["Wall1"] = 
{
	GridType = 2,
	ColCount = 58,
	RowCount = 20,
}
HomeWorldPlaneConfig["Wall2"] = 
{
	GridType = 3,
	ColCount = 55,
	RowCount = 20,
}
HomeWorldPlaneConfig["Garden"] = 
{
	GridType = 1,
	ColCount = 33,
	RowCount = 35,
	Zones = 
	{
		{x = 0, y = 19, w = 4, h = 12, },
		{x = 32, y = 30, w = 1, h = 5, },
		{x = 31, y = 27, w = 2, h = 3, },
		{x = 30, y = 25, w = 3, h = 2, },
		{x = 29, y = 22, w = 4, h = 3, },
		{x = 28, y = 20, w = 5, h = 2, },
		{x = 27, y = 18, w = 6, h = 2, },
		{x = 26, y = 16, w = 7, h = 2, },
		{x = 25, y = 14, w = 8, h = 2, },
		{x = 24, y = 12, w = 9, h = 2, },
		{x = 23, y = 11, w = 10, h = 1, },
		{x = 22, y = 9, w = 11, h = 2, },
		{x = 21, y = 8, w = 11, h = 1, },
		{x = 20, y = 6, w = 13, h = 2, },
		{x = 19, y = 5, w = 14, h = 1, },
		{x = 18, y = 4, w = 15, h = 1, },
		{x = 17, y = 2, w = 16, h = 2, },
		{x = 16, y = 1, w = 17, h = 1, },
		{x = 15, y = 0, w = 18, h = 1, },
		{x = 0, y = 0, w = 0, h = 0, },
	},
}
