PlanetAvatarConfig ={};
PlanetAvatarConfig["Planet_1_1"] =
{
	PreCondition = {
		PreGoalList = {
			300335,
		},
	},
}
PlanetAvatarConfig["Planet_1_2"] =
{
	PreCondition = {
		PreGoalList = {
			300336,
		},
	},
}
PlanetAvatarConfig["Planet_1_3"] =
{
	PreCondition = {
		PreGoalList = {
			300337,
		},
	},
}
PlanetAvatarConfig["Planet_1_4"] =
{
	PreCondition = {
		PreGoalList = {
			300338,
		},
	},
}
PlanetAvatarConfig["Planet_1_5"] =
{
	PreCondition = {
		PreGoalList = {
			300339,
		},
	},
}
PlanetAvatarConfig["Planet_1_6"] =
{
	PreCondition = {
		PreGoalList = {
			300340,
		},
	},
}
PlanetAvatarConfig["Planet_1_7"] =
{
	PreCondition = {
		PreGoalList = {
			300341,
		},
	},
}
PlanetAvatarConfig["Planet_1_8"] =
{
	PreCondition = {
		PreGoalList = {
			300342,
		},
	},
}
PlanetAvatarConfig["Planet_1_9"] =
{
	PreCondition = {
		PreGoalList = {
			300344,
		},
	},
}
PlanetAvatarConfig["Planet_1_10"] =
{
	PreCondition = {
		PreGoalList = {
			300343,
		},
	},
}
PlanetAvatarConfig["Planet_1_11"] =
{
	PreCondition = {
		PreGoalList = {
			300345,
		},
	},
}
PlanetAvatarConfig["Planet_2_1"] =
{
	PreCondition = {
		PreGoalList = {
			300744,
		},
	},
}
PlanetAvatarConfig["Planet_2_2"] =
{
	PreCondition = {
		PreGoalList = {
			300745,
		},
	},
}
PlanetAvatarConfig["Planet_2_3"] =
{
	PreCondition = {
		PreGoalList = {
			300746,
		},
	},
}
PlanetAvatarConfig["Planet_2_4"] =
{
	PreCondition = {
		PreGoalList = {
			300747,
		},
	},
}
PlanetAvatarConfig["Planet_2_5"] =
{
	PreCondition = {
		PreGoalList = {
			300748,
		},
	},
}
PlanetAvatarConfig["Planet_2_6"] =
{
	PreCondition = {
		PreGoalList = {
			300749,
		},
	},
}
PlanetAvatarConfig["Planet_2_7"] =
{
	PreCondition = {
		PreGoalList = {
			300750,
		},
	},
}
PlanetAvatarConfig["Planet_2_8"] =
{
	PreCondition = {
		PreGoalList = {
			300751,
		},
	},
}
PlanetAvatarConfig["Planet_2_9"] =
{
	PreCondition = {
		PreGoalList = {
			300752,
		},
	},
}
PlanetAvatarConfig["Planet_2_10"] =
{
	PreCondition = {
		PreGoalList = {
			300753,
		},
	},
}
PlanetAvatarConfig["Planet_3_1"] =
{
}
PlanetAvatarConfig["Planet_3_2"] =
{
	PreCondition = {
		PreGoalList = {
			301147,
		},
	},
}
PlanetAvatarConfig["Planet_3_3"] =
{
	PreCondition = {
		PreGoalList = {
			301148,
		},
	},
}
PlanetAvatarConfig["Planet_3_4"] =
{
	PreCondition = {
		PreGoalList = {
			301150,
		},
	},
}
PlanetAvatarConfig["Planet_3_5"] =
{
	PreCondition = {
		PreGoalList = {
			301149,
		},
	},
}
PlanetAvatarConfig["Planet_3_6"] =
{
	PreCondition = {
		PreGoalList = {
			301151,
		},
	},
}
PlanetAvatarConfig["Planet_3_7"] =
{
	PreCondition = {
		PreGoalList = {
			301152,
		},
	},
}
PlanetAvatarConfig["Planet_3_8"] =
{
	PreCondition = {
		PreGoalList = {
			301153,
		},
	},
}
PlanetAvatarConfig["Planet_3_9"] =
{
	PreCondition = {
		PreGoalList = {
			301154,
		},
	},
}
PlanetAvatarConfig["Planet_3_10"] =
{
	PreCondition = {
		PreGoalList = {
			301155,
		},
	},
}
PlanetAvatarConfig["Planet_3_11"] =
{
	PreCondition = {
		PreGoalList = {
			301156,
		},
	},
}
PlanetAvatarConfig["Planet_4_1"] =
{
}
PlanetAvatarConfig["Planet_4_2"] =
{
	PreCondition = {
		PreGoalList = {
			301560,
		},
	},
}
PlanetAvatarConfig["Planet_4_3"] =
{
	PreCondition = {
		PreGoalList = {
			301561,
		},
	},
}
PlanetAvatarConfig["Planet_4_4"] =
{
	PreCondition = {
		PreGoalList = {
			301562,
		},
	},
}
PlanetAvatarConfig["Planet_4_5"] =
{
	PreCondition = {
		PreGoalList = {
			301563,
		},
	},
}
PlanetAvatarConfig["Planet_4_6"] =
{
	PreCondition = {
		PreGoalList = {
			301564,
		},
	},
}
PlanetAvatarConfig["Planet_4_7"] =
{
	PreCondition = {
		PreGoalList = {
			301565,
		},
	},
}
PlanetAvatarConfig["Planet_4_8"] =
{
	PreCondition = {
		PreGoalList = {
			301566,
		},
	},
}
PlanetAvatarConfig["Planet_4_9"] =
{
	PreCondition = {
		PreGoalList = {
			301567,
		},
	},
}
PlanetAvatarConfig["Planet_4_10"] =
{
	PreCondition = {
		PreGoalList = {
			301568,
		},
	},
}
PlanetAvatarConfig["Planet_4_11"] =
{
	PreCondition = {
		PreGoalList = {
			301569,
		},
	},
}
PlanetAvatarConfig["Planet_4_12"] =
{
	PreCondition = {
		PreGoalList = {
			301570,
		},
	},
}
PlanetAvatarConfig["Planet_5_1"] =
{
	PreCondition = {
		PreGoalList = {
			301976,
		},
	},
}
PlanetAvatarConfig["Planet_5_2"] =
{
	PreCondition = {
		PreGoalList = {
			301977,
		},
	},
}
PlanetAvatarConfig["Planet_5_3"] =
{
	PreCondition = {
		PreGoalList = {
			301969,
		},
	},
}
PlanetAvatarConfig["Planet_5_4"] =
{
	PreCondition = {
		PreGoalList = {
			301978,
		},
	},
}
PlanetAvatarConfig["Planet_5_5"] =
{
	PreCondition = {
		PreGoalList = {
			301972,
		},
	},
}
PlanetAvatarConfig["Planet_5_6"] =
{
	PreCondition = {
		PreGoalList = {
			301610,
		},
	},
}
PlanetAvatarConfig["Planet_5_7"] =
{
	PreCondition = {
		PreGoalList = {
			301973,
		},
	},
}
PlanetAvatarConfig["Planet_5_8"] =
{
	PreCondition = {
		PreGoalList = {
			301974,
		},
	},
}
PlanetAvatarConfig["Planet_5_9"] =
{
	PreCondition = {
		PreGoalList = {
			301975,
		},
	},
}
PlanetAvatarConfig["Planet_5_10"] =
{
	PreCondition = {
		PreGoalList = {
			301971,
		},
	},
}
PlanetAvatarConfig["Planet_5_11"] =
{
	PreCondition = {
		PreGoalList = {
			301979,
		},
	},
}
PlanetAvatarConfig["Planet_5_12"] =
{
	PreCondition = {
		PreGoalList = {
			301970,
		},
	},
}
PlanetAvatarConfig["Planet_5_13"] =
{
	PreCondition = {
		PreGoalList = {
			301981,
		},
	},
}
PlanetAvatarConfig["Planet_5_14"] =
{
	PreCondition = {
		PreGoalList = {
			301980,
		},
	},
}

