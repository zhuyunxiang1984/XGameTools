IAPCustomPackageConfig ={};
IAPCustomPackageID = 
{
	Id001 = 720001,
	Id002 = 720002,
	Id003 = 720003,
	Id004 = 720004,
	Id005 = 720005,
	Id006 = 720006,
	Id007 = 720007,
	Id008 = 720008,
	Id009 = 720009,
	Id010 = 720010,
	Id011 = 720011,
	Id012 = 720012,
	Id013 = 720013,
	Id014 = 720014,
	Id015 = 720015,
	Id016 = 720016,
	Id017 = 720017,
	Id018 = 720018,
	Id019 = 720019,
	Id020 = 720020,
	Id021 = 720021,
	Id022 = 720022,
	Id023 = 720023,
	Id024 = 720024,
	Id025 = 720025,
	Id026 = 720026,
	Id027 = 720027,
	Id028 = 720028,
	Id029 = 720029,
	Id030 = 720030,
	Id031 = 720031,
	Id032 = 720032,
	Id033 = 720033,
	Id034 = 720034,
	Id035 = 720035,
	Id036 = 720036,
	Id037 = 720037,
	Id038 = 720038,
	Id039 = 720039,
	Id040 = 720040,
	Id041 = 720041,
	Id042 = 720042,
	Id043 = 720043,
	Id044 = 720044,
	Id045 = 720045,
	Id046 = 720046,
	Id047 = 720047,
	Id048 = 720048,
	Id049 = 720049,
	Id050 = 720050,
	Id051 = 720051,
	Id052 = 720052,
	Id053 = 720053,
}
IAPCustomPackageConfig[IAPCustomPackageID.Id001] =
{
	Id = 1,
	Name = "新兵礼包",
	Desc = "10次玉璧抽卡，独此一份",
	Price = 12,
	ButtonDesc = "12元礼包",
	Icon = "Package_Default",
	PackageRate = 600,
	Priority = 53,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.CompleteGoal,
			Value = 300023,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.LoginDays,
			NumMin = 3,
			NumMax = 9999,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720001,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 10,
		},
		{
			Value = 1,
			Num = 12000,
		},
		{
			Value = 320403,
			Num = 5,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id002] =
{
	Id = 2,
	Name = "不夜城礼包",
	Desc = "50次玉璧抽卡，验证血统",
	Price = 60,
	ButtonDesc = "60元礼包",
	Icon = "Package_Default",
	PackageRate = 500,
	Priority = 52,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.DrawCount,
			NumMin = 50,
			NumMax = 99999,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.DrawCount,
			NumMin = 100,
			NumMax = 99999,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720002,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 50,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id003] =
{
	Id = 3,
	Name = "不夜城大礼包",
	Desc = "130次玉璧抽卡，这次必欧",
	Price = 198,
	ButtonDesc = "198元礼包",
	Icon = "Package_Default",
	PackageRate = 400,
	Priority = 51,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.DrawCount,
			NumMin = 150,
			NumMax = 99999,
		},
		{
			Condition = PackageCondition.BuyPackage,
			Value = 720002,
			NumMin = 1,
			NumMax = 1,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.DrawCount,
			NumMin = 200,
			NumMax = 99999,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720003,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 330003,
			Num = 130,
		},
		{
			Value = 1,
			Num = 12000,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id004] =
{
	Id = 4,
	Name = "超值金币礼包",
	Desc = "超值金币，角色升级无忧",
	Price = 6,
	ButtonDesc = "6元礼包",
	Icon = "Package_Default",
	PackageRate = 800,
	Priority = 50,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.CharacterNum,
			NumMin = 5,
			NumMax = 999,
			RarityMin = 3,
			RarityMax = 5,
			LevelMin = 1,
			LevelMax = 999,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.SumPay,
			NumMin = 6,
			NumMax = 99999,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720004,
			NumMin = 0,
			NumMax = 5,
		},
	},
	Reward = {
		{
			Value = 1,
			Num = 48000,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id005] =
{
	Id = 5,
	Name = "大量金币礼包",
	Desc = "大量金币，角色升级无忧",
	Price = 18,
	ButtonDesc = "18元礼包",
	Icon = "Package_Default",
	PackageRate = 700,
	Priority = 49,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.CharacterNum,
			NumMin = 5,
			NumMax = 999,
			RarityMin = 3,
			RarityMax = 5,
			LevelMin = 20,
			LevelMax = 999,
		},
		{
			Condition = PackageCondition.BuyPackage,
			Value = 720004,
			NumMin = 1,
			NumMax = 1,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.SumPay,
			NumMin = 18,
			NumMax = 99999,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720005,
			NumMin = 0,
			NumMax = 4,
		},
	},
	Reward = {
		{
			Value = 1,
			Num = 126000,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id006] =
{
	Id = 6,
	Name = "海量金币礼包",
	Desc = "海量金币，角色升级无忧",
	Price = 60,
	ButtonDesc = "60元礼包",
	Icon = "Package_Default",
	PackageRate = 600,
	Priority = 48,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.CharacterNum,
			NumMin = 5,
			NumMax = 999,
			RarityMin = 4,
			RarityMax = 5,
			LevelMin = 1,
			LevelMax = 999,
		},
		{
			Condition = PackageCondition.BuyPackage,
			Value = 720005,
			NumMin = 1,
			NumMax = 1,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.SumPay,
			NumMin = 60,
			NumMax = 99999,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720006,
			NumMin = 0,
			NumMax = 3,
		},
	},
	Reward = {
		{
			Value = 1,
			Num = 360000,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id007] =
{
	Id = 7,
	Name = "超量金币礼包",
	Desc = "超量金币，角色升级无忧",
	Price = 128,
	ButtonDesc = "128元礼包",
	Icon = "Package_Default",
	PackageRate = 500,
	Priority = 47,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.CharacterNum,
			NumMin = 5,
			NumMax = 999,
			RarityMin = 4,
			RarityMax = 5,
			LevelMin = 20,
			LevelMax = 999,
		},
		{
			Condition = PackageCondition.BuyPackage,
			Value = 720006,
			NumMin = 1,
			NumMax = 1,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.SumPay,
			NumMin = 128,
			NumMax = 99999,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720007,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 1,
			Num = 640000,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id008] =
{
	Id = 8,
	Name = "紫色角色2阶包",
	Desc = "紫色角色轻松2阶",
	Price = 12,
	ButtonDesc = "12元礼包",
	Icon = "Package_Default",
	PackageRate = 600,
	Priority = 46,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.CharacterNum,
			NumMin = 2,
			NumMax = 999,
			RarityMin = 3,
			RarityMax = 3,
			LevelMin = 20,
			LevelMax = 20,
		},
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320001,
			NumMin = 0,
			NumMax = 9,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.CharacterNum,
			NumMin = 3,
			NumMax = 999,
			RarityMin = 3,
			RarityMax = 3,
			LevelMin = 20,
			LevelMax = 20,
		},
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320001,
			NumMin = 0,
			NumMax = 9,
		},
		{
			Condition = PackageCondition.SumPay,
			NumMin = 6,
			NumMax = 99999,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720008,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 320001,
			Num = 5,
		},
		{
			Value = 1,
			Num = 30000,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id009] =
{
	Id = 9,
	Name = "紫色角色3阶包",
	Desc = "紫色角色轻松3阶",
	Price = 68,
	ButtonDesc = "68元礼包",
	Icon = "Package_Default",
	PackageRate = 600,
	Priority = 45,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.CharacterNum,
			NumMin = 2,
			NumMax = 999,
			RarityMin = 3,
			RarityMax = 3,
			LevelMin = 40,
			LevelMax = 40,
		},
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320002,
			NumMin = 0,
			NumMax = 29,
		},
		{
			Condition = PackageCondition.SumPay,
			NumMin = 30,
			NumMax = 99999,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.CharacterNum,
			NumMin = 3,
			NumMax = 999,
			RarityMin = 3,
			RarityMax = 3,
			LevelMin = 40,
			LevelMax = 40,
		},
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320002,
			NumMin = 0,
			NumMax = 29,
		},
		{
			Condition = PackageCondition.SumPay,
			NumMin = 60,
			NumMax = 99999,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720009,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 320002,
			Num = 15,
		},
		{
			Value = 1,
			Num = 20000,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id010] =
{
	Id = 10,
	Name = "金彩角色2阶包",
	Desc = "金彩角色轻松2阶",
	Price = 18,
	ButtonDesc = "18元礼包",
	Icon = "Package_Default",
	PackageRate = 600,
	Priority = 44,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.CharacterNum,
			NumMin = 1,
			NumMax = 999,
			RarityMin = 4,
			RarityMax = 5,
			LevelMin = 20,
			LevelMax = 20,
		},
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320002,
			NumMin = 0,
			NumMax = 11,
		},
		{
			Condition = PackageCondition.SumPay,
			NumMin = 9,
			NumMax = 99999,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.CharacterNum,
			NumMin = 2,
			NumMax = 999,
			RarityMin = 4,
			RarityMax = 5,
			LevelMin = 20,
			LevelMax = 20,
		},
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320002,
			NumMin = 0,
			NumMax = 11,
		},
		{
			Condition = PackageCondition.SumPay,
			NumMin = 18,
			NumMax = 99999,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720010,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 320002,
			Num = 4,
		},
		{
			Value = 1,
			Num = 4500,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id011] =
{
	Id = 11,
	Name = "金彩角色3阶包",
	Desc = "金彩角色轻松3阶",
	Price = 128,
	ButtonDesc = "128元礼包",
	Icon = "Package_Default",
	PackageRate = 680,
	Priority = 43,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.CharacterNum,
			NumMin = 1,
			NumMax = 999,
			RarityMin = 4,
			RarityMax = 5,
			LevelMin = 40,
			LevelMax = 40,
		},
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320003,
			NumMin = 0,
			NumMax = 29,
		},
		{
			Condition = PackageCondition.SumPay,
			NumMin = 60,
			NumMax = 99999,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.CharacterNum,
			NumMin = 2,
			NumMax = 999,
			RarityMin = 4,
			RarityMax = 5,
			LevelMin = 40,
			LevelMax = 40,
		},
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320003,
			NumMin = 0,
			NumMax = 29,
		},
		{
			Condition = PackageCondition.SumPay,
			NumMin = 128,
			NumMax = 99999,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720011,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 320003,
			Num = 10,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id012] =
{
	Id = 12,
	Name = "紫装零件礼包1",
	Desc = "含紫色角色装备5级前零件",
	Price = 12,
	ButtonDesc = "12元礼包",
	Icon = "Package_Default",
	PackageRate = 500,
	Priority = 42,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.EquipmentNum,
			NumMin = 6,
			NumMax = 999,
			RarityMin = 3,
			RarityMax = 5,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320042,
			NumMin = 0,
			NumMax = 100,
		},
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320052,
			NumMin = 0,
			NumMax = 100,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.EquipmentNum,
			NumMin = 10,
			NumMax = 999,
			RarityMin = 3,
			RarityMax = 5,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320042,
			NumMin = 0,
			NumMax = 80,
		},
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320052,
			NumMin = 0,
			NumMax = 80,
		},
		{
			Condition = PackageCondition.SumPay,
			NumMin = 12,
			NumMax = 99999,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720012,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 320043,
			Num = 5,
		},
		{
			Value = 320053,
			Num = 5,
		},
		{
			Value = 320042,
			Num = 30,
		},
		{
			Value = 320052,
			Num = 30,
		},
		{
			Value = 320041,
			Num = 100,
		},
		{
			Value = 320051,
			Num = 100,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id013] =
{
	Id = 13,
	Name = "龙骑士装备包1",
	Desc = "含龙骑士装备5级前零件",
	Price = 30,
	ButtonDesc = "30元礼包",
	Icon = "Package_Default",
	PackageRate = 400,
	Priority = 41,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320053,
			NumMin = 0,
			NumMax = 210,
		},
		{
			Condition = PackageCondition.OwnCharacter,
			Value = 220026,
			LevelMin = 1,
			LevelMax = 999,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340060,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340061,
			LevelMin = 0,
			LevelMax = 5,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320053,
			NumMin = 0,
			NumMax = 70,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340060,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340061,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720013,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 320054,
			Num = 4,
		},
		{
			Value = 320053,
			Num = 20,
		},
		{
			Value = 320042,
			Num = 25,
		},
		{
			Value = 320052,
			Num = 22,
		},
		{
			Value = 320041,
			Num = 110,
		},
		{
			Value = 1,
			Num = 18520,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id014] =
{
	Id = 14,
	Name = "黑龙王子装备包1",
	Desc = "含黑龙王子装备5级前零件",
	Price = 30,
	ButtonDesc = "30元礼包",
	Icon = "Package_Default",
	PackageRate = 400,
	Priority = 40,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320053,
			NumMin = 0,
			NumMax = 210,
		},
		{
			Condition = PackageCondition.OwnCharacter,
			Value = 220027,
			LevelMin = 1,
			LevelMax = 999,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340063,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340064,
			LevelMin = 0,
			LevelMax = 5,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320053,
			NumMin = 0,
			NumMax = 70,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340063,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340064,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720014,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 320054,
			Num = 4,
		},
		{
			Value = 320053,
			Num = 20,
		},
		{
			Value = 320042,
			Num = 25,
		},
		{
			Value = 320052,
			Num = 22,
		},
		{
			Value = 320041,
			Num = 110,
		},
		{
			Value = 1,
			Num = 18520,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id015] =
{
	Id = 15,
	Name = "女王大人装备包1",
	Desc = "含女王大人装备5级前零件",
	Price = 30,
	ButtonDesc = "30元礼包",
	Icon = "Package_Default",
	PackageRate = 400,
	Priority = 39,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 210,
		},
		{
			Condition = PackageCondition.OwnCharacter,
			Value = 220028,
			LevelMin = 1,
			LevelMax = 999,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340066,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340067,
			LevelMin = 0,
			LevelMax = 5,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 70,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340066,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340067,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720015,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 4,
		},
		{
			Value = 320043,
			Num = 20,
		},
		{
			Value = 320042,
			Num = 22,
		},
		{
			Value = 320052,
			Num = 25,
		},
		{
			Value = 320051,
			Num = 110,
		},
		{
			Value = 1,
			Num = 18520,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id016] =
{
	Id = 16,
	Name = "炸鸡魔后装备包1",
	Desc = "含炸鸡魔后装备5级前零件",
	Price = 30,
	ButtonDesc = "30元礼包",
	Icon = "Package_Default",
	PackageRate = 400,
	Priority = 38,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 140,
		},
		{
			Condition = PackageCondition.OwnCharacter,
			Value = 220129,
			LevelMin = 1,
			LevelMax = 999,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340143,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340144,
			LevelMin = 0,
			LevelMax = 5,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 45,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340143,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340144,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720016,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 4,
		},
		{
			Value = 320043,
			Num = 15,
		},
		{
			Value = 320053,
			Num = 5,
		},
		{
			Value = 320042,
			Num = 25,
		},
		{
			Value = 320052,
			Num = 22,
		},
		{
			Value = 320041,
			Num = 110,
		},
		{
			Value = 1,
			Num = 18520,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id017] =
{
	Id = 17,
	Name = "爆米花女王装备包1",
	Desc = "含爆米花女王装备5级前零件",
	Price = 30,
	ButtonDesc = "30元礼包",
	Icon = "Package_Default",
	PackageRate = 400,
	Priority = 37,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 140,
		},
		{
			Condition = PackageCondition.OwnCharacter,
			Value = 220130,
			LevelMin = 1,
			LevelMax = 999,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340146,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340147,
			LevelMin = 0,
			LevelMax = 5,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 45,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340146,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340147,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720017,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 4,
		},
		{
			Value = 320043,
			Num = 15,
		},
		{
			Value = 320053,
			Num = 5,
		},
		{
			Value = 320042,
			Num = 25,
		},
		{
			Value = 320052,
			Num = 22,
		},
		{
			Value = 320041,
			Num = 110,
		},
		{
			Value = 1,
			Num = 18520,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id018] =
{
	Id = 18,
	Name = "独耳画像装备包1",
	Desc = "含独耳画像装备5级前零件",
	Price = 30,
	ButtonDesc = "30元礼包",
	Icon = "Package_Default",
	PackageRate = 400,
	Priority = 36,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 140,
		},
		{
			Condition = PackageCondition.OwnCharacter,
			Value = 220224,
			LevelMin = 1,
			LevelMax = 999,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340210,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340211,
			LevelMin = 0,
			LevelMax = 5,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 45,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340210,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340211,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720018,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 4,
		},
		{
			Value = 320043,
			Num = 15,
		},
		{
			Value = 320053,
			Num = 5,
		},
		{
			Value = 320052,
			Num = 47,
		},
		{
			Value = 320051,
			Num = 110,
		},
		{
			Value = 1,
			Num = 18520,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id019] =
{
	Id = 19,
	Name = "弗里达装备包1",
	Desc = "含弗里达装备5级前零件",
	Price = 30,
	ButtonDesc = "30元礼包",
	Icon = "Package_Default",
	PackageRate = 400,
	Priority = 35,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 210,
		},
		{
			Condition = PackageCondition.OwnCharacter,
			Value = 220225,
			LevelMin = 1,
			LevelMax = 999,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340213,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340214,
			LevelMin = 0,
			LevelMax = 5,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 70,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340213,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340214,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720019,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 4,
		},
		{
			Value = 320043,
			Num = 20,
		},
		{
			Value = 320042,
			Num = 22,
		},
		{
			Value = 320052,
			Num = 25,
		},
		{
			Value = 320051,
			Num = 110,
		},
		{
			Value = 1,
			Num = 18520,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id020] =
{
	Id = 20,
	Name = "微笑女神装备包1",
	Desc = "含微笑女神装备5级前零件",
	Price = 30,
	ButtonDesc = "30元礼包",
	Icon = "Package_Default",
	PackageRate = 400,
	Priority = 34,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 210,
		},
		{
			Condition = PackageCondition.OwnCharacter,
			Value = 220226,
			LevelMin = 1,
			LevelMax = 999,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340216,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340217,
			LevelMin = 0,
			LevelMax = 5,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 70,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340216,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340217,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720020,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 4,
		},
		{
			Value = 320043,
			Num = 20,
		},
		{
			Value = 320042,
			Num = 22,
		},
		{
			Value = 320052,
			Num = 25,
		},
		{
			Value = 320051,
			Num = 110,
		},
		{
			Value = 1,
			Num = 18520,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id021] =
{
	Id = 21,
	Name = "魔术师装备包1",
	Desc = "含魔术师装备5级前零件",
	Price = 30,
	ButtonDesc = "30元礼包",
	Icon = "Package_Default",
	PackageRate = 400,
	Priority = 33,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 140,
		},
		{
			Condition = PackageCondition.OwnCharacter,
			Value = 220227,
			LevelMin = 1,
			LevelMax = 999,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340219,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340220,
			LevelMin = 0,
			LevelMax = 5,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 45,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340219,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340220,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720021,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 4,
		},
		{
			Value = 320043,
			Num = 15,
		},
		{
			Value = 320053,
			Num = 5,
		},
		{
			Value = 320042,
			Num = 25,
		},
		{
			Value = 320052,
			Num = 22,
		},
		{
			Value = 320041,
			Num = 110,
		},
		{
			Value = 1,
			Num = 18520,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id022] =
{
	Id = 22,
	Name = "武士装备包1",
	Desc = "含武士装备5级前零件",
	Price = 30,
	ButtonDesc = "30元礼包",
	Icon = "Package_Default",
	PackageRate = 400,
	Priority = 32,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 140,
		},
		{
			Condition = PackageCondition.OwnCharacter,
			Value = 220228,
			LevelMin = 1,
			LevelMax = 999,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340222,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340223,
			LevelMin = 0,
			LevelMax = 5,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 45,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340222,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340223,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720022,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 4,
		},
		{
			Value = 320043,
			Num = 15,
		},
		{
			Value = 320053,
			Num = 5,
		},
		{
			Value = 320052,
			Num = 47,
		},
		{
			Value = 320051,
			Num = 110,
		},
		{
			Value = 1,
			Num = 18520,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id023] =
{
	Id = 23,
	Name = "杰克瑞波装备包1",
	Desc = "含杰克瑞波装备5级前零件",
	Price = 30,
	ButtonDesc = "30元礼包",
	Icon = "Package_Default",
	PackageRate = 400,
	Priority = 31,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 210,
		},
		{
			Condition = PackageCondition.OwnCharacter,
			Value = 220321,
			LevelMin = 1,
			LevelMax = 999,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340279,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340280,
			LevelMin = 0,
			LevelMax = 5,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 70,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340279,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340280,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720023,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 4,
		},
		{
			Value = 320043,
			Num = 20,
		},
		{
			Value = 320042,
			Num = 47,
		},
		{
			Value = 320041,
			Num = 110,
		},
		{
			Value = 1,
			Num = 18520,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id024] =
{
	Id = 24,
	Name = "蓝衣小学生装备包1",
	Desc = "含蓝衣小学生装备5级前零件",
	Price = 30,
	ButtonDesc = "30元礼包",
	Icon = "Package_Default",
	PackageRate = 400,
	Priority = 30,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 140,
		},
		{
			Condition = PackageCondition.OwnCharacter,
			Value = 220322,
			LevelMin = 1,
			LevelMax = 999,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340282,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340283,
			LevelMin = 0,
			LevelMax = 5,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 45,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340282,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340283,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720024,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 4,
		},
		{
			Value = 320043,
			Num = 15,
		},
		{
			Value = 320053,
			Num = 5,
		},
		{
			Value = 320042,
			Num = 25,
		},
		{
			Value = 320052,
			Num = 22,
		},
		{
			Value = 320041,
			Num = 110,
		},
		{
			Value = 1,
			Num = 18520,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id025] =
{
	Id = 25,
	Name = "迈克罗夫特装备包1",
	Desc = "含迈克罗夫特装备5级前零件",
	Price = 30,
	ButtonDesc = "30元礼包",
	Icon = "Package_Default",
	PackageRate = 400,
	Priority = 29,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 140,
		},
		{
			Condition = PackageCondition.OwnCharacter,
			Value = 220323,
			LevelMin = 1,
			LevelMax = 999,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340285,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340286,
			LevelMin = 0,
			LevelMax = 5,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 45,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340285,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340286,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720025,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 320054,
			Num = 4,
		},
		{
			Value = 320043,
			Num = 5,
		},
		{
			Value = 320053,
			Num = 15,
		},
		{
			Value = 320042,
			Num = 47,
		},
		{
			Value = 320041,
			Num = 110,
		},
		{
			Value = 1,
			Num = 18520,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id026] =
{
	Id = 26,
	Name = "龙骑士装备包2",
	Desc = "含龙骑士装备8级前零件",
	Price = 128,
	ButtonDesc = "128元礼包",
	Icon = "Package_Default",
	PackageRate = 480,
	Priority = 28,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320053,
			NumMin = 0,
			NumMax = 360,
		},
		{
			Condition = PackageCondition.OwnCharacter,
			Value = 220026,
			LevelMin = 1,
			LevelMax = 999,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340060,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340061,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340062,
			LevelMin = 5,
			LevelMax = 8,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320053,
			NumMin = 0,
			NumMax = 120,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340060,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340061,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340062,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720026,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 320054,
			Num = 39,
		},
		{
			Value = 320043,
			Num = 25,
		},
		{
			Value = 320053,
			Num = 25,
		},
		{
			Value = 320042,
			Num = 135,
		},
		{
			Value = 1,
			Num = 98000,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id027] =
{
	Id = 27,
	Name = "黑龙王子装备包2",
	Desc = "含黑龙王子装备8级前零件",
	Price = 128,
	ButtonDesc = "128元礼包",
	Icon = "Package_Default",
	PackageRate = 480,
	Priority = 27,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320053,
			NumMin = 0,
			NumMax = 360,
		},
		{
			Condition = PackageCondition.OwnCharacter,
			Value = 220027,
			LevelMin = 1,
			LevelMax = 999,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340063,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340064,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340065,
			LevelMin = 5,
			LevelMax = 8,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320053,
			NumMin = 0,
			NumMax = 120,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340063,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340064,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340065,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720027,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 320054,
			Num = 39,
		},
		{
			Value = 320043,
			Num = 25,
		},
		{
			Value = 320053,
			Num = 25,
		},
		{
			Value = 320042,
			Num = 135,
		},
		{
			Value = 1,
			Num = 98000,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id028] =
{
	Id = 28,
	Name = "女王大人装备包2",
	Desc = "含女王大人装备8级前零件",
	Price = 128,
	ButtonDesc = "128元礼包",
	Icon = "Package_Default",
	PackageRate = 480,
	Priority = 26,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 360,
		},
		{
			Condition = PackageCondition.OwnCharacter,
			Value = 220028,
			LevelMin = 1,
			LevelMax = 999,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340066,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340067,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340068,
			LevelMin = 5,
			LevelMax = 8,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 120,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340066,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340067,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340068,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720028,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 39,
		},
		{
			Value = 320043,
			Num = 25,
		},
		{
			Value = 320053,
			Num = 25,
		},
		{
			Value = 320052,
			Num = 135,
		},
		{
			Value = 1,
			Num = 98000,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id029] =
{
	Id = 29,
	Name = "炸鸡魔后装备包2",
	Desc = "含炸鸡魔后装备8级前零件",
	Price = 128,
	ButtonDesc = "128元礼包",
	Icon = "Package_Default",
	PackageRate = 480,
	Priority = 25,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320053,
			NumMin = 0,
			NumMax = 360,
		},
		{
			Condition = PackageCondition.OwnCharacter,
			Value = 220129,
			LevelMin = 1,
			LevelMax = 999,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340143,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340144,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340145,
			LevelMin = 5,
			LevelMax = 8,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320053,
			NumMin = 0,
			NumMax = 120,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340143,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340144,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340145,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720029,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 34,
		},
		{
			Value = 320054,
			Num = 5,
		},
		{
			Value = 320043,
			Num = 25,
		},
		{
			Value = 320053,
			Num = 25,
		},
		{
			Value = 320042,
			Num = 135,
		},
		{
			Value = 1,
			Num = 98000,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id030] =
{
	Id = 30,
	Name = "爆米花女王装备包2",
	Desc = "含爆米花女王装备8级前零件",
	Price = 128,
	ButtonDesc = "128元礼包",
	Icon = "Package_Default",
	PackageRate = 480,
	Priority = 24,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320053,
			NumMin = 0,
			NumMax = 360,
		},
		{
			Condition = PackageCondition.OwnCharacter,
			Value = 220130,
			LevelMin = 1,
			LevelMax = 999,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340146,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340147,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340148,
			LevelMin = 5,
			LevelMax = 8,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320053,
			NumMin = 0,
			NumMax = 120,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340146,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340147,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340148,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720030,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 34,
		},
		{
			Value = 320054,
			Num = 5,
		},
		{
			Value = 320043,
			Num = 25,
		},
		{
			Value = 320053,
			Num = 25,
		},
		{
			Value = 320042,
			Num = 135,
		},
		{
			Value = 1,
			Num = 98000,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id031] =
{
	Id = 31,
	Name = "独耳画像装备包2",
	Desc = "含独耳画像装备8级前零件",
	Price = 128,
	ButtonDesc = "128元礼包",
	Icon = "Package_Default",
	PackageRate = 480,
	Priority = 23,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320053,
			NumMin = 0,
			NumMax = 455,
		},
		{
			Condition = PackageCondition.OwnCharacter,
			Value = 220224,
			LevelMin = 1,
			LevelMax = 999,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340210,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340211,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340212,
			LevelMin = 5,
			LevelMax = 8,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320053,
			NumMin = 0,
			NumMax = 150,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340210,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340211,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340212,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720031,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 34,
		},
		{
			Value = 320054,
			Num = 5,
		},
		{
			Value = 320053,
			Num = 50,
		},
		{
			Value = 320052,
			Num = 135,
		},
		{
			Value = 1,
			Num = 98000,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id032] =
{
	Id = 32,
	Name = "弗里达装备包2",
	Desc = "含弗里达装备8级前零件",
	Price = 128,
	ButtonDesc = "128元礼包",
	Icon = "Package_Default",
	PackageRate = 480,
	Priority = 22,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 360,
		},
		{
			Condition = PackageCondition.OwnCharacter,
			Value = 220225,
			LevelMin = 1,
			LevelMax = 999,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340213,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340214,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340215,
			LevelMin = 5,
			LevelMax = 8,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 120,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340213,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340214,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340215,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720032,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 39,
		},
		{
			Value = 320043,
			Num = 25,
		},
		{
			Value = 320053,
			Num = 25,
		},
		{
			Value = 320052,
			Num = 135,
		},
		{
			Value = 1,
			Num = 98000,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id033] =
{
	Id = 33,
	Name = "微笑女神装备包2",
	Desc = "含微笑女神装备8级前零件",
	Price = 128,
	ButtonDesc = "128元礼包",
	Icon = "Package_Default",
	PackageRate = 480,
	Priority = 21,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 360,
		},
		{
			Condition = PackageCondition.OwnCharacter,
			Value = 220226,
			LevelMin = 1,
			LevelMax = 999,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340216,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340217,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340218,
			LevelMin = 5,
			LevelMax = 8,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 120,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340216,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340217,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340218,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720033,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 39,
		},
		{
			Value = 320043,
			Num = 25,
		},
		{
			Value = 320053,
			Num = 25,
		},
		{
			Value = 320052,
			Num = 135,
		},
		{
			Value = 1,
			Num = 98000,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id034] =
{
	Id = 34,
	Name = "魔术师装备包2",
	Desc = "含魔术师装备8级前零件",
	Price = 128,
	ButtonDesc = "128元礼包",
	Icon = "Package_Default",
	PackageRate = 480,
	Priority = 20,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320053,
			NumMin = 0,
			NumMax = 360,
		},
		{
			Condition = PackageCondition.OwnCharacter,
			Value = 220227,
			LevelMin = 1,
			LevelMax = 999,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340219,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340220,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340221,
			LevelMin = 5,
			LevelMax = 8,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320053,
			NumMin = 0,
			NumMax = 120,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340219,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340220,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340221,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720034,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 34,
		},
		{
			Value = 320054,
			Num = 5,
		},
		{
			Value = 320043,
			Num = 25,
		},
		{
			Value = 320053,
			Num = 25,
		},
		{
			Value = 320042,
			Num = 135,
		},
		{
			Value = 1,
			Num = 98000,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id035] =
{
	Id = 35,
	Name = "武士装备包2",
	Desc = "含武士装备8级前零件",
	Price = 128,
	ButtonDesc = "128元礼包",
	Icon = "Package_Default",
	PackageRate = 480,
	Priority = 19,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320053,
			NumMin = 0,
			NumMax = 455,
		},
		{
			Condition = PackageCondition.OwnCharacter,
			Value = 220228,
			LevelMin = 1,
			LevelMax = 999,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340222,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340223,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340224,
			LevelMin = 5,
			LevelMax = 8,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320053,
			NumMin = 0,
			NumMax = 150,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340222,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340223,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340224,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720035,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 34,
		},
		{
			Value = 320054,
			Num = 5,
		},
		{
			Value = 320053,
			Num = 50,
		},
		{
			Value = 320052,
			Num = 135,
		},
		{
			Value = 1,
			Num = 98000,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id036] =
{
	Id = 36,
	Name = "杰克瑞波装备包2",
	Desc = "含杰克瑞波装备8级前零件",
	Price = 128,
	ButtonDesc = "128元礼包",
	Icon = "Package_Default",
	PackageRate = 480,
	Priority = 18,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 210,
		},
		{
			Condition = PackageCondition.OwnCharacter,
			Value = 220321,
			LevelMin = 1,
			LevelMax = 999,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340279,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340280,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340281,
			LevelMin = 5,
			LevelMax = 8,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 70,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340279,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340280,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340281,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720036,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 39,
		},
		{
			Value = 320043,
			Num = 50,
		},
		{
			Value = 320042,
			Num = 135,
		},
		{
			Value = 1,
			Num = 98000,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id037] =
{
	Id = 37,
	Name = "蓝衣小学生装备包2",
	Desc = "含蓝衣小学生装备8级前零件",
	Price = 128,
	ButtonDesc = "128元礼包",
	Icon = "Package_Default",
	PackageRate = 480,
	Priority = 17,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320053,
			NumMin = 0,
			NumMax = 360,
		},
		{
			Condition = PackageCondition.OwnCharacter,
			Value = 220322,
			LevelMin = 1,
			LevelMax = 999,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340282,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340283,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340284,
			LevelMin = 5,
			LevelMax = 8,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320053,
			NumMin = 0,
			NumMax = 120,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340282,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340283,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340284,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720037,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 34,
		},
		{
			Value = 320054,
			Num = 5,
		},
		{
			Value = 320043,
			Num = 25,
		},
		{
			Value = 320053,
			Num = 25,
		},
		{
			Value = 320042,
			Num = 135,
		},
		{
			Value = 1,
			Num = 98000,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id038] =
{
	Id = 38,
	Name = "迈克罗夫特装备包2",
	Desc = "含迈克罗夫特装备8级前零件",
	Price = 128,
	ButtonDesc = "128元礼包",
	Icon = "Package_Default",
	PackageRate = 480,
	Priority = 16,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320053,
			NumMin = 0,
			NumMax = 360,
		},
		{
			Condition = PackageCondition.OwnCharacter,
			Value = 220323,
			LevelMin = 1,
			LevelMax = 999,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340285,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340286,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340287,
			LevelMin = 5,
			LevelMax = 8,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320053,
			NumMin = 0,
			NumMax = 120,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340285,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340286,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340287,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720038,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 5,
		},
		{
			Value = 320054,
			Num = 34,
		},
		{
			Value = 320043,
			Num = 50,
		},
		{
			Value = 320042,
			Num = 135,
		},
		{
			Value = 1,
			Num = 98000,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id039] =
{
	Id = 39,
	Name = "大魔王装备包1",
	Desc = "含大魔王装备5级前零件",
	Price = 198,
	ButtonDesc = "198元礼包",
	Icon = "Package_Default",
	PackageRate = 430,
	Priority = 15,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320053,
			NumMin = 0,
			NumMax = 710,
		},
		{
			Condition = PackageCondition.OwnCharacter,
			Value = 220029,
			LevelMin = 1,
			LevelMax = 999,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340069,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340070,
			LevelMin = 0,
			LevelMax = 5,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320053,
			NumMin = 0,
			NumMax = 240,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340069,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340070,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720039,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 20,
		},
		{
			Value = 320043,
			Num = 89,
		},
		{
			Value = 320053,
			Num = 70,
		},
		{
			Value = 320042,
			Num = 97,
		},
		{
			Value = 320052,
			Num = 97,
		},
		{
			Value = 1,
			Num = 103650,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id040] =
{
	Id = 40,
	Name = "薯条装备包1",
	Desc = "含薯条国王装备5级前零件",
	Price = 198,
	ButtonDesc = "198元礼包",
	Icon = "Package_Default",
	PackageRate = 430,
	Priority = 14,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 855,
		},
		{
			Condition = PackageCondition.OwnCharacter,
			Value = 220131,
			LevelMin = 1,
			LevelMax = 999,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340149,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340150,
			LevelMin = 0,
			LevelMax = 5,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 280,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340149,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340150,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720040,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 320054,
			Num = 20,
		},
		{
			Value = 320043,
			Num = 70,
		},
		{
			Value = 320053,
			Num = 89,
		},
		{
			Value = 320042,
			Num = 97,
		},
		{
			Value = 320052,
			Num = 97,
		},
		{
			Value = 1,
			Num = 103650,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id041] =
{
	Id = 41,
	Name = "名人装备包1",
	Desc = "含名人蜡像装备5级前零件",
	Price = 198,
	ButtonDesc = "198元礼包",
	Icon = "Package_Default",
	PackageRate = 430,
	Priority = 13,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 710,
		},
		{
			Condition = PackageCondition.OwnCharacter,
			Value = 220229,
			LevelMin = 1,
			LevelMax = 999,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340225,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340226,
			LevelMin = 0,
			LevelMax = 5,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 240,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340225,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340226,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720041,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 320054,
			Num = 20,
		},
		{
			Value = 320043,
			Num = 70,
		},
		{
			Value = 320053,
			Num = 89,
		},
		{
			Value = 320042,
			Num = 97,
		},
		{
			Value = 320052,
			Num = 97,
		},
		{
			Value = 1,
			Num = 103650,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id042] =
{
	Id = 42,
	Name = "大侦探装备包1",
	Desc = "含大侦探装备5级前零件",
	Price = 198,
	ButtonDesc = "198元礼包",
	Icon = "Package_Default",
	PackageRate = 430,
	Priority = 12,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 855,
		},
		{
			Condition = PackageCondition.OwnCharacter,
			Value = 220324,
			LevelMin = 1,
			LevelMax = 999,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340288,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340289,
			LevelMin = 0,
			LevelMax = 5,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 280,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340288,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340289,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720042,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 320054,
			Num = 20,
		},
		{
			Value = 320043,
			Num = 70,
		},
		{
			Value = 320053,
			Num = 89,
		},
		{
			Value = 320042,
			Num = 194,
		},
		{
			Value = 1,
			Num = 103650,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id043] =
{
	Id = 43,
	Name = "教授装备包1",
	Desc = "含教授装备5级前零件",
	Price = 198,
	ButtonDesc = "198元礼包",
	Icon = "Package_Default",
	PackageRate = 430,
	Priority = 11,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320053,
			NumMin = 0,
			NumMax = 710,
		},
		{
			Condition = PackageCondition.OwnCharacter,
			Value = 220325,
			LevelMin = 1,
			LevelMax = 999,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340292,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340293,
			LevelMin = 0,
			LevelMax = 5,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320053,
			NumMin = 0,
			NumMax = 240,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340292,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340293,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720043,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 20,
		},
		{
			Value = 320043,
			Num = 89,
		},
		{
			Value = 320053,
			Num = 70,
		},
		{
			Value = 320042,
			Num = 194,
		},
		{
			Value = 1,
			Num = 103650,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id044] =
{
	Id = 44,
	Name = "玉璧女王装备包1",
	Desc = "含玉璧女王装备5级前零件",
	Price = 198,
	ButtonDesc = "198元礼包",
	Icon = "Package_Default",
	PackageRate = 430,
	Priority = 10,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 1355,
		},
		{
			Condition = PackageCondition.OwnCharacter,
			Value = 221003,
			LevelMin = 1,
			LevelMax = 999,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340302,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340303,
			LevelMin = 0,
			LevelMax = 5,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 450,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340302,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340303,
			LevelMin = 0,
			LevelMax = 5,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720044,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 20,
		},
		{
			Value = 320043,
			Num = 159,
		},
		{
			Value = 320042,
			Num = 97,
		},
		{
			Value = 320052,
			Num = 97,
		},
		{
			Value = 1,
			Num = 103650,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id045] =
{
	Id = 45,
	Name = "大魔王装备包2",
	Desc = "含大魔王装备8级前零件",
	Price = 328,
	ButtonDesc = "328元礼包",
	Icon = "Package_Default",
	PackageRate = 500,
	Priority = 9,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320053,
			NumMin = 0,
			NumMax = 2015,
		},
		{
			Condition = PackageCondition.OwnCharacter,
			Value = 220029,
			LevelMin = 999,
			LevelMax = 999,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340069,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340070,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340071,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340072,
			LevelMin = 5,
			LevelMax = 8,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320053,
			NumMin = 0,
			NumMax = 670,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340069,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340070,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340071,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340072,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720045,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 216,
		},
		{
			Value = 320054,
			Num = 46,
		},
		{
			Value = 320053,
			Num = 200,
		},
		{
			Value = 320042,
			Num = 280,
		},
		{
			Value = 320052,
			Num = 280,
		},
		{
			Value = 1,
			Num = 528400,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id046] =
{
	Id = 46,
	Name = "薯条装备包2",
	Desc = "含薯条国王装备8级前零件",
	Price = 328,
	ButtonDesc = "328元礼包",
	Icon = "Package_Default",
	PackageRate = 500,
	Priority = 8,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 2740,
		},
		{
			Condition = PackageCondition.OwnCharacter,
			Value = 220131,
			LevelMin = 1,
			LevelMax = 999,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340149,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340150,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340151,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340152,
			LevelMin = 5,
			LevelMax = 8,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 910,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340149,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340150,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340151,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340152,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720046,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 46,
		},
		{
			Value = 320054,
			Num = 216,
		},
		{
			Value = 320043,
			Num = 200,
		},
		{
			Value = 320042,
			Num = 280,
		},
		{
			Value = 320052,
			Num = 280,
		},
		{
			Value = 1,
			Num = 528400,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id047] =
{
	Id = 47,
	Name = "名人装备包2",
	Desc = "含名人蜡像装备8级前零件",
	Price = 328,
	ButtonDesc = "328元礼包",
	Icon = "Package_Default",
	PackageRate = 500,
	Priority = 7,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 2015,
		},
		{
			Condition = PackageCondition.OwnCharacter,
			Value = 220229,
			LevelMin = 999,
			LevelMax = 999,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340225,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340226,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340227,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340228,
			LevelMin = 5,
			LevelMax = 8,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 670,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340225,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340226,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340227,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340228,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720047,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 46,
		},
		{
			Value = 320054,
			Num = 216,
		},
		{
			Value = 320043,
			Num = 200,
		},
		{
			Value = 320042,
			Num = 280,
		},
		{
			Value = 320052,
			Num = 280,
		},
		{
			Value = 1,
			Num = 528400,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id048] =
{
	Id = 48,
	Name = "大侦探装备包2",
	Desc = "含大侦探装备8级前零件",
	Price = 328,
	ButtonDesc = "328元礼包",
	Icon = "Package_Default",
	PackageRate = 500,
	Priority = 6,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 2740,
		},
		{
			Condition = PackageCondition.OwnCharacter,
			Value = 220324,
			LevelMin = 999,
			LevelMax = 999,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340288,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340289,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340290,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340291,
			LevelMin = 5,
			LevelMax = 8,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 910,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340288,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340289,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340290,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340291,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720048,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 57,
		},
		{
			Value = 320054,
			Num = 205,
		},
		{
			Value = 320043,
			Num = 200,
		},
		{
			Value = 320042,
			Num = 560,
		},
		{
			Value = 1,
			Num = 528400,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id049] =
{
	Id = 49,
	Name = "教授装备包2",
	Desc = "含教授装备8级前零件",
	Price = 328,
	ButtonDesc = "328元礼包",
	Icon = "Package_Default",
	PackageRate = 500,
	Priority = 5,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320053,
			NumMin = 0,
			NumMax = 2015,
		},
		{
			Condition = PackageCondition.OwnCharacter,
			Value = 220325,
			LevelMin = 999,
			LevelMax = 999,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340292,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340293,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340294,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340295,
			LevelMin = 5,
			LevelMax = 8,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320053,
			NumMin = 0,
			NumMax = 670,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340292,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340293,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340294,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340295,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720049,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 227,
		},
		{
			Value = 320054,
			Num = 35,
		},
		{
			Value = 320053,
			Num = 200,
		},
		{
			Value = 320042,
			Num = 560,
		},
		{
			Value = 1,
			Num = 528400,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id050] =
{
	Id = 50,
	Name = "玉璧女王装备包2",
	Desc = "含玉璧女王装备8级前零件",
	Price = 328,
	ButtonDesc = "328元礼包",
	Icon = "Package_Default",
	PackageRate = 500,
	Priority = 4,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 2740,
		},
		{
			Condition = PackageCondition.OwnCharacter,
			Value = 221003,
			LevelMin = 999,
			LevelMax = 999,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340302,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340303,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340304,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340305,
			LevelMin = 5,
			LevelMax = 8,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 320043,
			NumMin = 0,
			NumMax = 910,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340302,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340303,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340304,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.OwnEquipment,
			Value = 340305,
			LevelMin = 5,
			LevelMax = 8,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720050,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 320044,
			Num = 251,
		},
		{
			Value = 320054,
			Num = 11,
		},
		{
			Value = 320043,
			Num = 200,
		},
		{
			Value = 320042,
			Num = 280,
		},
		{
			Value = 320052,
			Num = 280,
		},
		{
			Value = 1,
			Num = 528400,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id051] =
{
	Id = 51,
	Name = "资源补充包1",
	Desc = "高倍优惠，有备无患",
	Price = 18,
	ButtonDesc = "18元礼包",
	Icon = "Package_Default",
	PackageRate = 600,
	Priority = 4,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.SumPay,
			NumMin = 60,
			NumMax = 99999,
		},
		{
			Condition = PackageCondition.OwnAssets,
			Value = 1,
			NumMin = 0,
			NumMax = 200000,
		},
		{
			Condition = PackageCondition.OwnAssets,
			Value = 2,
			NumMin = 0,
			NumMax = 2000,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 1,
			NumMin = 0,
			NumMax = 200000,
		},
		{
			Condition = PackageCondition.OwnAssets,
			Value = 2,
			NumMin = 0,
			NumMax = 2000,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720051,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 1080,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id052] =
{
	Id = 52,
	Name = "资源补充包2",
	Desc = "多多益善，有备无患",
	Price = 30,
	ButtonDesc = "30元礼包",
	Icon = "Package_Default",
	PackageRate = 500,
	Priority = 4,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.SumPay,
			NumMin = 78,
			NumMax = 99999,
		},
		{
			Condition = PackageCondition.BuyPackage,
			Value = 720051,
			NumMin = 1,
			NumMax = 1,
		},
		{
			Condition = PackageCondition.OwnAssets,
			Value = 1,
			NumMin = 0,
			NumMax = 200000,
		},
		{
			Condition = PackageCondition.OwnAssets,
			Value = 2,
			NumMin = 0,
			NumMax = 2000,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 1,
			NumMin = 0,
			NumMax = 200000,
		},
		{
			Condition = PackageCondition.OwnAssets,
			Value = 2,
			NumMin = 0,
			NumMax = 2000,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720052,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 1620,
		},
	},
}
IAPCustomPackageConfig[IAPCustomPackageID.Id053] =
{
	Id = 53,
	Name = "资源补充包3",
	Desc = "多多益善，有备无患",
	Price = 68,
	ButtonDesc = "68元礼包",
	Icon = "Package_Default",
	PackageRate = 400,
	Priority = 4,
	DurationTime = 86400,
	PurchaseCD = 86400,
	TimeOutCD = 86400,
	FirstCondition = {
		{
			Condition = PackageCondition.SumPay,
			NumMin = 138,
			NumMax = 99999,
		},
		{
			Condition = PackageCondition.BuyPackage,
			Value = 720052,
			NumMin = 1,
			NumMax = 1,
		},
		{
			Condition = PackageCondition.OwnAssets,
			Value = 1,
			NumMin = 0,
			NumMax = 200000,
		},
		{
			Condition = PackageCondition.OwnAssets,
			Value = 2,
			NumMin = 0,
			NumMax = 2000,
		},
	},
	RepeatCondition = {
		{
			Condition = PackageCondition.OwnAssets,
			Value = 1,
			NumMin = 0,
			NumMax = 200000,
		},
		{
			Condition = PackageCondition.OwnAssets,
			Value = 2,
			NumMin = 0,
			NumMax = 2000,
			LevelMin = 5,
			LevelMax = 10,
		},
		{
			Condition = PackageCondition.ShowPackage,
			Value = 720053,
			NumMin = 0,
			NumMax = 2,
		},
	},
	Reward = {
		{
			Value = 2,
			Num = 2700,
		},
	},
}

