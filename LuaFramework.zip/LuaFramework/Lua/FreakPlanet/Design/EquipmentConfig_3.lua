
EquipmentConfig[EquipmentID.Id091] =
{
	Character = 220108,
	Rarity = 1,
	UpgradeId = 930001,
	LevelList = {
		{
			Level = 1,
			Info = 920117,
			Ability = {
				{
					Value = 200002,
					Num = 21,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920117,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920117,
			Ability = {
				{
					Value = 200002,
					Num = 63,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920117,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920117,
			Ability = {
				{
					Value = 200002,
					Num = 105,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920117,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920117,
			Ability = {
				{
					Value = 200002,
					Num = 147,
				},
				{
					Value = 200005,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920117,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920117,
			Ability = {
				{
					Value = 200002,
					Num = 189,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920117,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id092] =
{
	Character = 220108,
	Rarity = 1,
	NeedChallenge = 145038,
	UpgradeId = 930002,
	LevelList = {
		{
			Level = 1,
			Info = 920118,
			Ability = {
				{
					Value = 200002,
					Num = 21,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920118,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920118,
			Ability = {
				{
					Value = 200002,
					Num = 63,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920118,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920118,
			Ability = {
				{
					Value = 200002,
					Num = 105,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 6,
			Info = 920118,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 7,
			Info = 920118,
			Ability = {
				{
					Value = 200002,
					Num = 147,
				},
				{
					Value = 200006,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 8,
			Info = 920118,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 9,
			Info = 920118,
			Ability = {
				{
					Value = 200002,
					Num = 189,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 10,
			Info = 920118,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id093] =
{
	Character = 220109,
	Rarity = 1,
	UpgradeId = 930021,
	LevelList = {
		{
			Level = 1,
			Info = 920119,
			Ability = {
				{
					Value = 200001,
					Num = 27,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920119,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920119,
			Ability = {
				{
					Value = 200001,
					Num = 81,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920119,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920119,
			Ability = {
				{
					Value = 200001,
					Num = 135,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920119,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920119,
			Ability = {
				{
					Value = 200001,
					Num = 189,
				},
				{
					Value = 200006,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920119,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920119,
			Ability = {
				{
					Value = 200001,
					Num = 243,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920119,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id094] =
{
	Character = 220109,
	Rarity = 1,
	NeedChallenge = 145039,
	UpgradeId = 930022,
	LevelList = {
		{
			Level = 1,
			Info = 920120,
			Ability = {
				{
					Value = 200001,
					Num = 27,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920120,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920120,
			Ability = {
				{
					Value = 200001,
					Num = 81,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920120,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920120,
			Ability = {
				{
					Value = 200001,
					Num = 135,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 6,
			Info = 920120,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 7,
			Info = 920120,
			Ability = {
				{
					Value = 200001,
					Num = 189,
				},
				{
					Value = 200005,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 8,
			Info = 920120,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 9,
			Info = 920120,
			Ability = {
				{
					Value = 200001,
					Num = 243,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 10,
			Info = 920120,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id095] =
{
	Character = 220110,
	Rarity = 1,
	UpgradeId = 930021,
	LevelList = {
		{
			Level = 1,
			Info = 920121,
			Ability = {
				{
					Value = 200001,
					Num = 27,
				},
				{
					Value = 200008,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920121,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920121,
			Ability = {
				{
					Value = 200001,
					Num = 81,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920121,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920121,
			Ability = {
				{
					Value = 200001,
					Num = 135,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920121,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920121,
			Ability = {
				{
					Value = 200001,
					Num = 189,
				},
				{
					Value = 200008,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920121,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920121,
			Ability = {
				{
					Value = 200001,
					Num = 243,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920121,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id096] =
{
	Character = 220110,
	Rarity = 1,
	NeedChallenge = 145040,
	UpgradeId = 930022,
	LevelList = {
		{
			Level = 1,
			Info = 920122,
			Ability = {
				{
					Value = 200001,
					Num = 27,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920122,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920122,
			Ability = {
				{
					Value = 200001,
					Num = 81,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920122,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920122,
			Ability = {
				{
					Value = 200001,
					Num = 135,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 6,
			Info = 920122,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 7,
			Info = 920122,
			Ability = {
				{
					Value = 200001,
					Num = 189,
				},
				{
					Value = 200005,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 8,
			Info = 920122,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200005,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 9,
			Info = 920122,
			Ability = {
				{
					Value = 200001,
					Num = 243,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 10,
			Info = 920122,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200005,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id097] =
{
	Character = 220111,
	Rarity = 1,
	UpgradeId = 930001,
	LevelList = {
		{
			Level = 1,
			Info = 920123,
			Ability = {
				{
					Value = 200002,
					Num = 21,
				},
				{
					Value = 200008,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920123,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920123,
			Ability = {
				{
					Value = 200002,
					Num = 63,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920123,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920123,
			Ability = {
				{
					Value = 200002,
					Num = 105,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920123,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920123,
			Ability = {
				{
					Value = 200002,
					Num = 147,
				},
				{
					Value = 200008,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920123,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920123,
			Ability = {
				{
					Value = 200002,
					Num = 189,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920123,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id098] =
{
	Character = 220111,
	Rarity = 1,
	NeedChallenge = 145041,
	UpgradeId = 930002,
	LevelList = {
		{
			Level = 1,
			Info = 920124,
			Ability = {
				{
					Value = 200002,
					Num = 21,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920124,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920124,
			Ability = {
				{
					Value = 200002,
					Num = 63,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920124,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920124,
			Ability = {
				{
					Value = 200002,
					Num = 105,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 6,
			Info = 920124,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 7,
			Info = 920124,
			Ability = {
				{
					Value = 200002,
					Num = 147,
				},
				{
					Value = 200006,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 8,
			Info = 920124,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 9,
			Info = 920124,
			Ability = {
				{
					Value = 200002,
					Num = 189,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
		{
			Level = 10,
			Info = 920124,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 101904,
					Value = 8,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id099] =
{
	Character = 220112,
	Rarity = 2,
	UpgradeId = 930005,
	LevelList = {
		{
			Level = 1,
			Info = 920125,
			Ability = {
				{
					Value = 200002,
					Num = 33,
				},
				{
					Value = 200008,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920125,
			Ability = {
				{
					Value = 200002,
					Num = 66,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920125,
			Ability = {
				{
					Value = 200002,
					Num = 99,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920125,
			Ability = {
				{
					Value = 200002,
					Num = 132,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920125,
			Ability = {
				{
					Value = 200002,
					Num = 165,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920125,
			Ability = {
				{
					Value = 200002,
					Num = 198,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920125,
			Ability = {
				{
					Value = 200002,
					Num = 231,
				},
				{
					Value = 200008,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920125,
			Ability = {
				{
					Value = 200002,
					Num = 264,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920125,
			Ability = {
				{
					Value = 200002,
					Num = 297,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920125,
			Ability = {
				{
					Value = 200002,
					Num = 330,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id100] =
{
	Character = 220112,
	Rarity = 2,
	NeedChallenge = 145042,
	UpgradeId = 930026,
	LevelList = {
		{
			Level = 1,
			Info = 920126,
			Ability = {
				{
					Value = 200001,
					Num = 42,
				},
				{
					Value = 200005,
					Num = 3,
				},
			},
		},
		{
			Level = 2,
			Info = 920126,
			Ability = {
				{
					Value = 200001,
					Num = 84,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 3,
			Info = 920126,
			Ability = {
				{
					Value = 200001,
					Num = 126,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 4,
			Info = 920126,
			Ability = {
				{
					Value = 200001,
					Num = 168,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 5,
			Info = 920126,
			Ability = {
				{
					Value = 200001,
					Num = 210,
				},
				{
					Value = 200005,
					Num = 15,
				},
			},
			SkillList = {
				{
					Id = 101901,
					Value = 8,
				},
			},
		},
		{
			Level = 6,
			Info = 920126,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
			SkillList = {
				{
					Id = 101901,
					Value = 8,
				},
			},
		},
		{
			Level = 7,
			Info = 920126,
			Ability = {
				{
					Value = 200001,
					Num = 294,
				},
				{
					Value = 200005,
					Num = 21,
				},
			},
			SkillList = {
				{
					Id = 101901,
					Value = 8,
				},
			},
		},
		{
			Level = 8,
			Info = 920126,
			Ability = {
				{
					Value = 200001,
					Num = 336,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
			SkillList = {
				{
					Id = 101901,
					Value = 8,
				},
			},
		},
		{
			Level = 9,
			Info = 920126,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
			SkillList = {
				{
					Id = 101901,
					Value = 8,
				},
			},
		},
		{
			Level = 10,
			Info = 920126,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 101901,
					Value = 8,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id101] =
{
	Character = 220113,
	Rarity = 2,
	UpgradeId = 930005,
	LevelList = {
		{
			Level = 1,
			Info = 920127,
			Ability = {
				{
					Value = 200002,
					Num = 33,
				},
				{
					Value = 200007,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920127,
			Ability = {
				{
					Value = 200002,
					Num = 66,
				},
				{
					Value = 200007,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920127,
			Ability = {
				{
					Value = 200002,
					Num = 99,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920127,
			Ability = {
				{
					Value = 200002,
					Num = 132,
				},
				{
					Value = 200007,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920127,
			Ability = {
				{
					Value = 200002,
					Num = 165,
				},
				{
					Value = 200007,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920127,
			Ability = {
				{
					Value = 200002,
					Num = 198,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920127,
			Ability = {
				{
					Value = 200002,
					Num = 231,
				},
				{
					Value = 200007,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920127,
			Ability = {
				{
					Value = 200002,
					Num = 264,
				},
				{
					Value = 200007,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920127,
			Ability = {
				{
					Value = 200002,
					Num = 297,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920127,
			Ability = {
				{
					Value = 200002,
					Num = 330,
				},
				{
					Value = 200007,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id102] =
{
	Character = 220113,
	Rarity = 2,
	NeedChallenge = 145043,
	UpgradeId = 930006,
	LevelList = {
		{
			Level = 1,
			Info = 920128,
			Ability = {
				{
					Value = 200002,
					Num = 33,
				},
				{
					Value = 200005,
					Num = 3,
				},
			},
		},
		{
			Level = 2,
			Info = 920128,
			Ability = {
				{
					Value = 200002,
					Num = 66,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 3,
			Info = 920128,
			Ability = {
				{
					Value = 200002,
					Num = 99,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 4,
			Info = 920128,
			Ability = {
				{
					Value = 200002,
					Num = 132,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 5,
			Info = 920128,
			Ability = {
				{
					Value = 200002,
					Num = 165,
				},
				{
					Value = 200005,
					Num = 15,
				},
			},
			SkillList = {
				{
					Id = 101902,
					Value = 8,
				},
			},
		},
		{
			Level = 6,
			Info = 920128,
			Ability = {
				{
					Value = 200002,
					Num = 198,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
			SkillList = {
				{
					Id = 101902,
					Value = 8,
				},
			},
		},
		{
			Level = 7,
			Info = 920128,
			Ability = {
				{
					Value = 200002,
					Num = 231,
				},
				{
					Value = 200005,
					Num = 21,
				},
			},
			SkillList = {
				{
					Id = 101902,
					Value = 8,
				},
			},
		},
		{
			Level = 8,
			Info = 920128,
			Ability = {
				{
					Value = 200002,
					Num = 264,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
			SkillList = {
				{
					Id = 101902,
					Value = 8,
				},
			},
		},
		{
			Level = 9,
			Info = 920128,
			Ability = {
				{
					Value = 200002,
					Num = 297,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
			SkillList = {
				{
					Id = 101902,
					Value = 8,
				},
			},
		},
		{
			Level = 10,
			Info = 920128,
			Ability = {
				{
					Value = 200002,
					Num = 330,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 101902,
					Value = 8,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id103] =
{
	Character = 220114,
	Rarity = 2,
	UpgradeId = 930005,
	LevelList = {
		{
			Level = 1,
			Info = 920129,
			Ability = {
				{
					Value = 200002,
					Num = 33,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920129,
			Ability = {
				{
					Value = 200002,
					Num = 66,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920129,
			Ability = {
				{
					Value = 200002,
					Num = 99,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920129,
			Ability = {
				{
					Value = 200002,
					Num = 132,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920129,
			Ability = {
				{
					Value = 200002,
					Num = 165,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920129,
			Ability = {
				{
					Value = 200002,
					Num = 198,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920129,
			Ability = {
				{
					Value = 200002,
					Num = 231,
				},
				{
					Value = 200006,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920129,
			Ability = {
				{
					Value = 200002,
					Num = 264,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920129,
			Ability = {
				{
					Value = 200002,
					Num = 297,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920129,
			Ability = {
				{
					Value = 200002,
					Num = 330,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id104] =
{
	Character = 220114,
	Rarity = 2,
	NeedChallenge = 145044,
	UpgradeId = 930006,
	LevelList = {
		{
			Level = 1,
			Info = 920130,
			Ability = {
				{
					Value = 200002,
					Num = 33,
				},
				{
					Value = 200008,
					Num = 3,
				},
			},
		},
		{
			Level = 2,
			Info = 920130,
			Ability = {
				{
					Value = 200002,
					Num = 66,
				},
				{
					Value = 200008,
					Num = 6,
				},
			},
		},
		{
			Level = 3,
			Info = 920130,
			Ability = {
				{
					Value = 200002,
					Num = 99,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 4,
			Info = 920130,
			Ability = {
				{
					Value = 200002,
					Num = 132,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 5,
			Info = 920130,
			Ability = {
				{
					Value = 200002,
					Num = 165,
				},
				{
					Value = 200008,
					Num = 15,
				},
			},
			SkillList = {
				{
					Id = 100666,
					Value = 3,
				},
			},
		},
		{
			Level = 6,
			Info = 920130,
			Ability = {
				{
					Value = 200002,
					Num = 198,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
			SkillList = {
				{
					Id = 100666,
					Value = 3,
				},
			},
		},
		{
			Level = 7,
			Info = 920130,
			Ability = {
				{
					Value = 200002,
					Num = 231,
				},
				{
					Value = 200008,
					Num = 21,
				},
			},
			SkillList = {
				{
					Id = 100666,
					Value = 3,
				},
			},
		},
		{
			Level = 8,
			Info = 920130,
			Ability = {
				{
					Value = 200002,
					Num = 264,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
			SkillList = {
				{
					Id = 100666,
					Value = 3,
				},
			},
		},
		{
			Level = 9,
			Info = 920130,
			Ability = {
				{
					Value = 200002,
					Num = 297,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
			SkillList = {
				{
					Id = 100666,
					Value = 3,
				},
			},
		},
		{
			Level = 10,
			Info = 920130,
			Ability = {
				{
					Value = 200002,
					Num = 330,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100666,
					Value = 3,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id105] =
{
	Character = 220115,
	Rarity = 2,
	UpgradeId = 930005,
	LevelList = {
		{
			Level = 1,
			Info = 920131,
			Ability = {
				{
					Value = 200002,
					Num = 33,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920131,
			Ability = {
				{
					Value = 200002,
					Num = 66,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920131,
			Ability = {
				{
					Value = 200002,
					Num = 99,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920131,
			Ability = {
				{
					Value = 200002,
					Num = 132,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920131,
			Ability = {
				{
					Value = 200002,
					Num = 165,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920131,
			Ability = {
				{
					Value = 200002,
					Num = 198,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920131,
			Ability = {
				{
					Value = 200002,
					Num = 231,
				},
				{
					Value = 200006,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920131,
			Ability = {
				{
					Value = 200002,
					Num = 264,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920131,
			Ability = {
				{
					Value = 200002,
					Num = 297,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920131,
			Ability = {
				{
					Value = 200002,
					Num = 330,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id106] =
{
	Character = 220115,
	Rarity = 2,
	NeedChallenge = 145045,
	UpgradeId = 930006,
	LevelList = {
		{
			Level = 1,
			Info = 920132,
			Ability = {
				{
					Value = 200002,
					Num = 33,
				},
				{
					Value = 200008,
					Num = 3,
				},
			},
		},
		{
			Level = 2,
			Info = 920132,
			Ability = {
				{
					Value = 200002,
					Num = 66,
				},
				{
					Value = 200008,
					Num = 6,
				},
			},
		},
		{
			Level = 3,
			Info = 920132,
			Ability = {
				{
					Value = 200002,
					Num = 99,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 4,
			Info = 920132,
			Ability = {
				{
					Value = 200002,
					Num = 132,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 5,
			Info = 920132,
			Ability = {
				{
					Value = 200002,
					Num = 165,
				},
				{
					Value = 200008,
					Num = 15,
				},
			},
			SkillList = {
				{
					Id = 100664,
					Value = 3,
				},
			},
		},
		{
			Level = 6,
			Info = 920132,
			Ability = {
				{
					Value = 200002,
					Num = 198,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
			SkillList = {
				{
					Id = 100664,
					Value = 3,
				},
			},
		},
		{
			Level = 7,
			Info = 920132,
			Ability = {
				{
					Value = 200002,
					Num = 231,
				},
				{
					Value = 200008,
					Num = 21,
				},
			},
			SkillList = {
				{
					Id = 100664,
					Value = 3,
				},
			},
		},
		{
			Level = 8,
			Info = 920132,
			Ability = {
				{
					Value = 200002,
					Num = 264,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
			SkillList = {
				{
					Id = 100664,
					Value = 3,
				},
			},
		},
		{
			Level = 9,
			Info = 920132,
			Ability = {
				{
					Value = 200002,
					Num = 297,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
			SkillList = {
				{
					Id = 100664,
					Value = 3,
				},
			},
		},
		{
			Level = 10,
			Info = 920132,
			Ability = {
				{
					Value = 200002,
					Num = 330,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100664,
					Value = 3,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id107] =
{
	Character = 220116,
	Rarity = 2,
	UpgradeId = 930005,
	LevelList = {
		{
			Level = 1,
			Info = 920133,
			Ability = {
				{
					Value = 200002,
					Num = 33,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920133,
			Ability = {
				{
					Value = 200002,
					Num = 66,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920133,
			Ability = {
				{
					Value = 200002,
					Num = 99,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920133,
			Ability = {
				{
					Value = 200002,
					Num = 132,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920133,
			Ability = {
				{
					Value = 200002,
					Num = 165,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920133,
			Ability = {
				{
					Value = 200002,
					Num = 198,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920133,
			Ability = {
				{
					Value = 200002,
					Num = 231,
				},
				{
					Value = 200006,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920133,
			Ability = {
				{
					Value = 200002,
					Num = 264,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920133,
			Ability = {
				{
					Value = 200002,
					Num = 297,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920133,
			Ability = {
				{
					Value = 200002,
					Num = 330,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id108] =
{
	Character = 220116,
	Rarity = 2,
	NeedChallenge = 145046,
	UpgradeId = 930006,
	LevelList = {
		{
			Level = 1,
			Info = 920134,
			Ability = {
				{
					Value = 200002,
					Num = 33,
				},
				{
					Value = 200008,
					Num = 3,
				},
			},
		},
		{
			Level = 2,
			Info = 920134,
			Ability = {
				{
					Value = 200002,
					Num = 66,
				},
				{
					Value = 200008,
					Num = 6,
				},
			},
		},
		{
			Level = 3,
			Info = 920134,
			Ability = {
				{
					Value = 200002,
					Num = 99,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 4,
			Info = 920134,
			Ability = {
				{
					Value = 200002,
					Num = 132,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 5,
			Info = 920134,
			Ability = {
				{
					Value = 200002,
					Num = 165,
				},
				{
					Value = 200008,
					Num = 15,
				},
			},
		},
		{
			Level = 6,
			Info = 920134,
			Ability = {
				{
					Value = 200002,
					Num = 198,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 7,
			Info = 920134,
			Ability = {
				{
					Value = 200002,
					Num = 231,
				},
				{
					Value = 200008,
					Num = 21,
				},
			},
		},
		{
			Level = 8,
			Info = 920134,
			Ability = {
				{
					Value = 200002,
					Num = 264,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
			SkillList = {
				{
					Id = 100555,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920134,
			Ability = {
				{
					Value = 200002,
					Num = 297,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
			SkillList = {
				{
					Id = 100555,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920134,
			Ability = {
				{
					Value = 200002,
					Num = 330,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100555,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id109] =
{
	Character = 220117,
	Rarity = 2,
	UpgradeId = 930005,
	LevelList = {
		{
			Level = 1,
			Info = 920135,
			Ability = {
				{
					Value = 200002,
					Num = 33,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920135,
			Ability = {
				{
					Value = 200002,
					Num = 66,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920135,
			Ability = {
				{
					Value = 200002,
					Num = 99,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920135,
			Ability = {
				{
					Value = 200002,
					Num = 132,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920135,
			Ability = {
				{
					Value = 200002,
					Num = 165,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920135,
			Ability = {
				{
					Value = 200002,
					Num = 198,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920135,
			Ability = {
				{
					Value = 200002,
					Num = 231,
				},
				{
					Value = 200006,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920135,
			Ability = {
				{
					Value = 200002,
					Num = 264,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920135,
			Ability = {
				{
					Value = 200002,
					Num = 297,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920135,
			Ability = {
				{
					Value = 200002,
					Num = 330,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id110] =
{
	Character = 220117,
	Rarity = 2,
	NeedChallenge = 145047,
	UpgradeId = 930026,
	LevelList = {
		{
			Level = 1,
			Info = 920136,
			Ability = {
				{
					Value = 200001,
					Num = 42,
				},
				{
					Value = 200005,
					Num = 3,
				},
			},
		},
		{
			Level = 2,
			Info = 920136,
			Ability = {
				{
					Value = 200001,
					Num = 84,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 3,
			Info = 920136,
			Ability = {
				{
					Value = 200001,
					Num = 126,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 4,
			Info = 920136,
			Ability = {
				{
					Value = 200001,
					Num = 168,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 5,
			Info = 920136,
			Ability = {
				{
					Value = 200001,
					Num = 210,
				},
				{
					Value = 200005,
					Num = 15,
				},
			},
			SkillList = {
				{
					Id = 100102,
					Value = -7,
				},
			},
		},
		{
			Level = 6,
			Info = 920136,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
			SkillList = {
				{
					Id = 100102,
					Value = -7,
				},
			},
		},
		{
			Level = 7,
			Info = 920136,
			Ability = {
				{
					Value = 200001,
					Num = 294,
				},
				{
					Value = 200005,
					Num = 21,
				},
			},
			SkillList = {
				{
					Id = 100102,
					Value = -7,
				},
			},
		},
		{
			Level = 8,
			Info = 920136,
			Ability = {
				{
					Value = 200001,
					Num = 336,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
			SkillList = {
				{
					Id = 100102,
					Value = -7,
				},
			},
		},
		{
			Level = 9,
			Info = 920136,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
			SkillList = {
				{
					Id = 100102,
					Value = -7,
				},
			},
		},
		{
			Level = 10,
			Info = 920136,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100102,
					Value = -7,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id111] =
{
	Character = 220118,
	Rarity = 2,
	UpgradeId = 930005,
	LevelList = {
		{
			Level = 1,
			Info = 920137,
			Ability = {
				{
					Value = 200002,
					Num = 33,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920137,
			Ability = {
				{
					Value = 200002,
					Num = 66,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920137,
			Ability = {
				{
					Value = 200002,
					Num = 99,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920137,
			Ability = {
				{
					Value = 200002,
					Num = 132,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920137,
			Ability = {
				{
					Value = 200002,
					Num = 165,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920137,
			Ability = {
				{
					Value = 200002,
					Num = 198,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920137,
			Ability = {
				{
					Value = 200002,
					Num = 231,
				},
				{
					Value = 200006,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920137,
			Ability = {
				{
					Value = 200002,
					Num = 264,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920137,
			Ability = {
				{
					Value = 200002,
					Num = 297,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920137,
			Ability = {
				{
					Value = 200002,
					Num = 330,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id112] =
{
	Character = 220118,
	Rarity = 2,
	NeedChallenge = 145048,
	UpgradeId = 930026,
	LevelList = {
		{
			Level = 1,
			Info = 920138,
			Ability = {
				{
					Value = 200001,
					Num = 42,
				},
				{
					Value = 200005,
					Num = 3,
				},
			},
		},
		{
			Level = 2,
			Info = 920138,
			Ability = {
				{
					Value = 200001,
					Num = 84,
				},
				{
					Value = 200005,
					Num = 6,
				},
			},
		},
		{
			Level = 3,
			Info = 920138,
			Ability = {
				{
					Value = 200001,
					Num = 126,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 4,
			Info = 920138,
			Ability = {
				{
					Value = 200001,
					Num = 168,
				},
				{
					Value = 200005,
					Num = 12,
				},
			},
		},
		{
			Level = 5,
			Info = 920138,
			Ability = {
				{
					Value = 200001,
					Num = 210,
				},
				{
					Value = 200005,
					Num = 15,
				},
			},
			SkillList = {
				{
					Id = 100104,
					Value = -7,
				},
			},
		},
		{
			Level = 6,
			Info = 920138,
			Ability = {
				{
					Value = 200001,
					Num = 252,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
			SkillList = {
				{
					Id = 100104,
					Value = -7,
				},
			},
		},
		{
			Level = 7,
			Info = 920138,
			Ability = {
				{
					Value = 200001,
					Num = 294,
				},
				{
					Value = 200005,
					Num = 21,
				},
			},
			SkillList = {
				{
					Id = 100104,
					Value = -7,
				},
			},
		},
		{
			Level = 8,
			Info = 920138,
			Ability = {
				{
					Value = 200001,
					Num = 336,
				},
				{
					Value = 200005,
					Num = 24,
				},
			},
			SkillList = {
				{
					Id = 100104,
					Value = -7,
				},
			},
		},
		{
			Level = 9,
			Info = 920138,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
			SkillList = {
				{
					Id = 100104,
					Value = -7,
				},
			},
		},
		{
			Level = 10,
			Info = 920138,
			Ability = {
				{
					Value = 200001,
					Num = 420,
				},
				{
					Value = 200005,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100104,
					Value = -7,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id113] =
{
	Character = 220119,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920139,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920139,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920139,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920139,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920139,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200008,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920139,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920139,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200008,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920139,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920139,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200008,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920139,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200008,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id114] =
{
	Character = 220119,
	Rarity = 3,
	UpgradeId = 930010,
	LevelList = {
		{
			Level = 1,
			Info = 920140,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200006,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920140,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200006,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920140,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200006,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920140,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200006,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920140,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200006,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920140,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200006,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920140,
			Ability = {
				{
					Value = 200002,
					Num = 294,
				},
				{
					Value = 200006,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920140,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
				{
					Value = 200006,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920140,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200006,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920140,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200006,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100652,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id115] =
{
	Character = 220119,
	Rarity = 3,
	NeedChallenge = 145049,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920141,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
			},
		},
		{
			Level = 2,
			Info = 920141,
			Ability = {
				{
					Value = 200002,
					Num = 140,
				},
			},
		},
		{
			Level = 3,
			Info = 920141,
			Ability = {
				{
					Value = 200002,
					Num = 196,
				},
			},
		},
		{
			Level = 4,
			Info = 920141,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
		},
		{
			Level = 5,
			Info = 920141,
			Ability = {
				{
					Value = 200002,
					Num = 308,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920141,
			Ability = {
				{
					Value = 200002,
					Num = 364,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920141,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920141,
			Ability = {
				{
					Value = 200002,
					Num = 476,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100661,
					Value = 13,
				},
			},
		},
		{
			Level = 9,
			Info = 920141,
			Ability = {
				{
					Value = 200002,
					Num = 532,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100661,
					Value = 13,
				},
			},
		},
		{
			Level = 10,
			Info = 920141,
			Ability = {
				{
					Value = 200002,
					Num = 588,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100661,
					Value = 13,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id116] =
{
	Character = 220120,
	Rarity = 3,
	UpgradeId = 930029,
	LevelList = {
		{
			Level = 1,
			Info = 920142,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200008,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920142,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920142,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200008,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920142,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920142,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200008,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 6,
			Info = 920142,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 7,
			Info = 920142,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200008,
					Num = 63,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 8,
			Info = 920142,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200008,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 9,
			Info = 920142,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200008,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
		{
			Level = 10,
			Info = 920142,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200008,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100651,
					Value = 5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id117] =
{
	Character = 220120,
	Rarity = 3,
	UpgradeId = 930030,
	LevelList = {
		{
			Level = 1,
			Info = 920143,
			Ability = {
				{
					Value = 200001,
					Num = 54,
				},
				{
					Value = 200007,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920143,
			Ability = {
				{
					Value = 200001,
					Num = 108,
				},
				{
					Value = 200007,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920143,
			Ability = {
				{
					Value = 200001,
					Num = 162,
				},
				{
					Value = 200007,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920143,
			Ability = {
				{
					Value = 200001,
					Num = 216,
				},
				{
					Value = 200007,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920143,
			Ability = {
				{
					Value = 200001,
					Num = 270,
				},
				{
					Value = 200007,
					Num = 30,
				},
			},
		},
		{
			Level = 6,
			Info = 920143,
			Ability = {
				{
					Value = 200001,
					Num = 324,
				},
				{
					Value = 200007,
					Num = 36,
				},
			},
		},
		{
			Level = 7,
			Info = 920143,
			Ability = {
				{
					Value = 200001,
					Num = 378,
				},
				{
					Value = 200007,
					Num = 42,
				},
			},
		},
		{
			Level = 8,
			Info = 920143,
			Ability = {
				{
					Value = 200001,
					Num = 432,
				},
				{
					Value = 200007,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 9,
			Info = 920143,
			Ability = {
				{
					Value = 200001,
					Num = 486,
				},
				{
					Value = 200007,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
		{
			Level = 10,
			Info = 920143,
			Ability = {
				{
					Value = 200001,
					Num = 540,
				},
				{
					Value = 200007,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100561,
					Value = -5,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id118] =
{
	Character = 220120,
	Rarity = 3,
	NeedChallenge = 145050,
	UpgradeId = 930011,
	LevelList = {
		{
			Level = 1,
			Info = 920144,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
			},
		},
		{
			Level = 2,
			Info = 920144,
			Ability = {
				{
					Value = 200002,
					Num = 140,
				},
			},
		},
		{
			Level = 3,
			Info = 920144,
			Ability = {
				{
					Value = 200002,
					Num = 196,
				},
			},
		},
		{
			Level = 4,
			Info = 920144,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
			},
		},
		{
			Level = 5,
			Info = 920144,
			Ability = {
				{
					Value = 200002,
					Num = 308,
				},
				{
					Value = 200004,
					Num = 25,
				},
			},
		},
		{
			Level = 6,
			Info = 920144,
			Ability = {
				{
					Value = 200002,
					Num = 364,
				},
				{
					Value = 200004,
					Num = 30,
				},
			},
		},
		{
			Level = 7,
			Info = 920144,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200004,
					Num = 35,
				},
			},
		},
		{
			Level = 8,
			Info = 920144,
			Ability = {
				{
					Value = 200002,
					Num = 476,
				},
				{
					Value = 200004,
					Num = 40,
				},
			},
			SkillList = {
				{
					Id = 100662,
					Value = 13,
				},
			},
		},
		{
			Level = 9,
			Info = 920144,
			Ability = {
				{
					Value = 200002,
					Num = 532,
				},
				{
					Value = 200004,
					Num = 45,
				},
			},
			SkillList = {
				{
					Id = 100662,
					Value = 13,
				},
			},
		},
		{
			Level = 10,
			Info = 920144,
			Ability = {
				{
					Value = 200002,
					Num = 588,
				},
				{
					Value = 200004,
					Num = 50,
				},
			},
			SkillList = {
				{
					Id = 100662,
					Value = 13,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id119] =
{
	Character = 220121,
	Rarity = 3,
	UpgradeId = 930009,
	LevelList = {
		{
			Level = 1,
			Info = 920145,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200005,
					Num = 9,
				},
			},
		},
		{
			Level = 2,
			Info = 920145,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200005,
					Num = 18,
				},
			},
		},
		{
			Level = 3,
			Info = 920145,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200005,
					Num = 27,
				},
			},
		},
		{
			Level = 4,
			Info = 920145,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200005,
					Num = 36,
				},
			},
		},
		{
			Level = 5,
			Info = 920145,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200005,
					Num = 45,
				},
			},
		},
		{
			Level = 6,
			Info = 920145,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200005,
					Num = 54,
				},
			},
		},
		{
			Level = 7,
			Info = 920145,
			Ability = {
				{
					Value = 200002,
					Num = 294,
				},
				{
					Value = 200005,
					Num = 63,
				},
			},
		},
		{
			Level = 8,
			Info = 920145,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
				{
					Value = 200005,
					Num = 72,
				},
			},
			SkillList = {
				{
					Id = 100554,
					Value = 25,
				},
			},
		},
		{
			Level = 9,
			Info = 920145,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200005,
					Num = 81,
				},
			},
			SkillList = {
				{
					Id = 100554,
					Value = 25,
				},
			},
		},
		{
			Level = 10,
			Info = 920145,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200005,
					Num = 90,
				},
			},
			SkillList = {
				{
					Id = 100554,
					Value = 25,
				},
			},
		},
	},
}
EquipmentConfig[EquipmentID.Id120] =
{
	Character = 220121,
	Rarity = 3,
	UpgradeId = 930010,
	LevelList = {
		{
			Level = 1,
			Info = 920146,
			Ability = {
				{
					Value = 200002,
					Num = 42,
				},
				{
					Value = 200008,
					Num = 6,
				},
			},
		},
		{
			Level = 2,
			Info = 920146,
			Ability = {
				{
					Value = 200002,
					Num = 84,
				},
				{
					Value = 200008,
					Num = 12,
				},
			},
		},
		{
			Level = 3,
			Info = 920146,
			Ability = {
				{
					Value = 200002,
					Num = 126,
				},
				{
					Value = 200008,
					Num = 18,
				},
			},
		},
		{
			Level = 4,
			Info = 920146,
			Ability = {
				{
					Value = 200002,
					Num = 168,
				},
				{
					Value = 200008,
					Num = 24,
				},
			},
		},
		{
			Level = 5,
			Info = 920146,
			Ability = {
				{
					Value = 200002,
					Num = 210,
				},
				{
					Value = 200008,
					Num = 30,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -15,
				},
			},
		},
		{
			Level = 6,
			Info = 920146,
			Ability = {
				{
					Value = 200002,
					Num = 252,
				},
				{
					Value = 200008,
					Num = 36,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -15,
				},
			},
		},
		{
			Level = 7,
			Info = 920146,
			Ability = {
				{
					Value = 200002,
					Num = 294,
				},
				{
					Value = 200008,
					Num = 42,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -15,
				},
			},
		},
		{
			Level = 8,
			Info = 920146,
			Ability = {
				{
					Value = 200002,
					Num = 336,
				},
				{
					Value = 200008,
					Num = 48,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -15,
				},
			},
		},
		{
			Level = 9,
			Info = 920146,
			Ability = {
				{
					Value = 200002,
					Num = 378,
				},
				{
					Value = 200008,
					Num = 54,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -15,
				},
			},
		},
		{
			Level = 10,
			Info = 920146,
			Ability = {
				{
					Value = 200002,
					Num = 420,
				},
				{
					Value = 200008,
					Num = 60,
				},
			},
			SkillList = {
				{
					Id = 100606,
					Value = -15,
				},
			},
		},
	},
}
