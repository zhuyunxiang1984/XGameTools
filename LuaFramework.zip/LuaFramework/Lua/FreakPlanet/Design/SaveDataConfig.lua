SaveDataConfig = {}

SaveDataName = {
	Default = "Default",
	Middle = "Middle",
	VIP = "VIP",
}

SaveDataConfig[SaveDataName.Default] = {
	Gold = 100,
	Diamond = 100,
	Team = 1,
	UnlockAllAreas = 0,
	UnlockAreas = {
		130001,
	},
	UnlockAllCharacter = 0,
	UnlockCharacters = {
		220001, 220002,
	},
	UnlockAllGoods = 0,
	UnlockGoods = {
		{Value = 320401, Num = 1},
	},
	UnlockAllLabRecipes = 0,
	UnlockLabRecipes = {},
	UnlockAllPets = 0,
	UnlockPets = {
	},
	UnlockAllWorkShops = 0,
	UnlockWorkShops = {
	},
	SkipTutorial = false,
}

SaveDataConfig[SaveDataName.Middle] = {
	Gold = 100000000,
	Diamond = 100000000,
	Team = 1,
	UnlockAllAreas = 1,
	UnlockAreas = {
	},
	UnlockAllCharacter = 0,
	UnlockCharacters = {
		220001, 220002,
	},
	UnlockAllGoods = 0,
	UnlockGoods = {
		{Value = 320401, Num = 1},
	},
	UnlockAllLabRecipes = 0,
	UnlockLabRecipes = {},
	UnlockAllPets = 0,
	UnlockPets = {
	},
	UnlockAllWorkShops = 0,
	UnlockWorkShops = {
	},
	SkipTutorial = true,
}

SaveDataConfig[SaveDataName.VIP] = {
	Gold = 10000000,
	Diamond = 10000000,
	Team = 4,
	UnlockAllAreas = 1,
	UnlockAreas = {
	},
	UnlockAllCharacter = 50,
	UnlockCharacters = {
	},
	UnlockAllGoods = 999,
	UnlockGoods = {
	},
	UnlockAllLabRecipes = 1,
	UnlockLabRecipes = {
	},
	UnlockAllPets = 150,
	UnlockPets = {
	},
	UnlockAllWorkShops = 7,
	UnlockWorkShops = {
	},
	SkipTutorial = true,
}